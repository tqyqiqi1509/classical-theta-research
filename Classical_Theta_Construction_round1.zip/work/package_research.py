#!/usr/bin/env python3
"""Compact research checkpoint / final archive; source papers are not copied."""
from pathlib import Path
import argparse, hashlib, json, zipfile

ROOT=Path(__file__).resolve().parent.parent
EXCLUDED={'history','references','library_helpers_20261113','__pycache__','.git'}
SOURCE_TEXTS={'bridgeland1603.00416v4.txt','krause1409.7051v3.txt'}
ap=argparse.ArgumentParser()
ap.add_argument('--kind',choices=['stage','total'],default='stage')
args=ap.parse_args()
out=ROOT/'deliverables'/f'classical_high_rank_greedy_{args.kind}.zip'
out.parent.mkdir(exist_ok=True)
files=[]
for p in (ROOT/'work').rglob('*'):
    if not p.is_file() or EXCLUDED.intersection(p.parts): continue
    if p.suffix.lower() in {'.pdf','.zip','.pyc'} or p.name.lower().startswith('lipan') or p.name in SOURCE_TEXTS: continue
    files.append(p)
manifest=[]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):
        data=p.read_bytes()
        if p.suffix=='.json':
            try: json.loads(data)
            except (ValueError,UnicodeDecodeError):
                # Preserve the raw record, but explicitly flag incomplete JSON.
                json_valid=False
            else: json_valid=True
        else: json_valid=None
        rel=str(p.relative_to(ROOT))
        z.writestr(rel,data)
        manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'json_valid':json_valid})
    report=ROOT/'work'/'FINAL_REPORT_ZH.md'
    if report.exists(): z.writestr('START_HERE.md',report.read_bytes())
    core=ROOT/'work'/'agent_pieri_diamond'
    if (core/'CORE_MANIFEST.json').exists():
        cm=json.loads((core/'CORE_MANIFEST.json').read_text())
        for rel in sorted(set([x['path'] for x in cm['files']]+cm['inputs']+['CORE_MANIFEST.json'])):
            p=core/rel
            data=p.read_bytes()
            z.writestr('main_program/'+rel,data)
            manifest.append({'path':'main_program/'+rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'json_valid':True if p.suffix=='.json' else None})
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out) as z:
    failure=z.testzip()
    assert failure is None,failure
print(json.dumps({'path':str(out),'files':len(manifest),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'invalid_json':[x['path'] for x in manifest if x['json_valid'] is False]}))
