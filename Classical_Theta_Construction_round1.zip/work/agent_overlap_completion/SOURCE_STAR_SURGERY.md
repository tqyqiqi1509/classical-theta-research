# A source/sink surgery with positive lower-rank theta slices

2026-11-13. Classical acyclic skew-symmetrizable principal coefficients.
This is a proved comparison/constraint mechanism, not yet a uniqueness theorem
for a high-rank greedy basis. The algorithmic inequalities use only finite
binomial arithmetic and lower-rank coefficient tables.

## Source surgery

Let i be a source in the convention b_ij>=0 for all j. Set

    b_j=b_ij, c_j=-b_ji (j!=i), L(p)=sum_(j!=i) b_j p_j.

Thus d_i*b_j=d_j*c_j. Add a mutable vertex w and extend the principal matrix by

    Bbar_iw=-1, Bbar_wi=1,
    Bbar_wj=-b_j, Bbar_jw=c_j (j!=i).

Append d_i to the symmetrizer D, and give this rank n+1 matrix its OWN
principal coefficients eta_1,...,eta_n,eta_w. The extended initial matrix is
usually cyclic. Mutation at w gives:

* the original principal submatrix B0 with all edges incident to i deleted;
* i -> w -> j for every original edge i -> j;
* the original acyclic orientation among j!=i unchanged.

The mutated extended seed is therefore acyclic. The original rank n
submatrix after freezing w is the disconnected product of isolated i and
B_rest. This is the rank reduction.

Let F_g(z)=sum_(p in P) a_p z^p be the old theta F-polynomial. Take any known
finite carrier P containing its support, for example the acyclic standard
box, and choose

    lambda >= max_(p in P)(L(p)-p_i), lambda>=0.

The standard-box choice sum b_j*d_j is explicit; the already-computed exact
Newton carrier gives the sharper maximum. Form H=x^g*w^lambda*F_g(zbar_old),
where zbar_old uses the first n columns of the extended principal seed.
Its w-exponents are

    r_p=lambda+p_i-L(p)>=0.

## Why the old theta extends to ONE theta of the enlarged algebra

For each original mutable direction, H is Laurent in the adjacent chart
because the frozen-w seed is a monomial coefficient extension of the original
seed. For the new w direction, r_p>=0 makes substitution of the exchange
binomial manifestly Laurent. Hence H lies in the initial upper bound.

Principal coefficients make the extended exchange matrix full column rank,
which is preserved under mutation. BFZ Proposition1.8 and Corollary1.9 identify
that upper bound with U for this entire mutation class. Since mutation at w
is acyclic, U has a finite theta basis under the already audited acyclic
comparison inputs. Thus H has a finite theta expansion in the extended
algebra, even though the INITIAL extended principal matrix is cyclic.

Apply valuative independence to this finite expansion. The Newton polytope
of EVERY nonzero theta summand is contained in Newt(H). In the independent
extended exchange-column coordinates, H has degree zero in the new direction
w. Therefore each summand has zero F_w-degree. Qin's freezing identity then
identifies it with a theta element of the frozen-w algebra. Linear independence
of the old theta basis forces the original single frozen theta H to have just
one summand, with coefficient1. This proves H is one extended theta.

This argument uses finite theta expansion, VIT and freezing explicitly; it
does NOT infer theta identity from Laurent positivity alone.

## Explicit finite slice formula

Mutate w. The leading labels are

    g'_i=g_i, g'_j=g_j+c_j*lambda (j!=i), g'_w=-lambda.

Write v for the new F-coordinate in direction w. The transformed F-polynomial
is the following entirely finite binomial expression:

    F_new(z,v)=sum_p a_p z^p v^(L(p)) (1+v)^(lambda+p_i-L(p)).

Consequently the v^t slice is

    A_t(z)=sum_p a_p binom(lambda+p_i-L(p),t-L(p)) z^p,

with binomial coefficients zero outside their ordinary range. Only
0<=t<=lambda+max_p p_i need be considered. The effective old labels are

    h_i(t)=g_i+t,
    h_j(t)=g_j+c_j*(lambda-t) (j!=i).

By positive theta slicing, A_t has a nonnegative INTEGER expansion in shifted
theta polynomials for B0:

    A_t=sum_q m_(t,q) z^q F^[B0]_(h(t)+B0 q),   m_(t,q)>=0.

Because B0 is disconnected, its tables are exactly the rank-one binomial
tables times the rank n-1 theta tables. For n=3 these are explicit LLZ Dyck
tables; no unknown high-rank theta coefficient is used to FORM the constraints.

The coefficients m_(t,q) are extracted by finite unitriangular elimination,
so each inequality is an explicit integer linear inequality in the original
a_p. This gives a general family of constraints reducing rank, unlike merely
sampling more initial-star charts.

## Sink variant

Let i be a sink, write b_j=-b_ij>=0 and c_j=b_ji>=0, and set L(p)=sum b_j p_j.
Use Bbar_iw=1, Bbar_wi=-1, Bbar_wj=b_j, Bbar_jw=-c_j. Again D_w=d_i and
mutation at w makes i isolated in the old principal submatrix, while the
extended target is acyclic. Choose

    lambda>=max_(p in P)(p_i-L(p)), lambda>=0.

Then r_p=lambda-p_i+L(p)>=0, and the transformed F-polynomial is

    sum_p a_p z^p v^(p_i)(1+v)^(lambda-p_i+L(p)).

Its v^t slice has coefficients a_p*binom(lambda-p_i+L(p),t-p_i), with labels

    h_i(t)=g_i+lambda-t,
    h_j(t)=g_j+c_j*t (j!=i).

The same positive rank-one times rank-(n-1) expansion applies.

## Scope still requiring work

The argument proves soundness of these constraints in arbitrary acyclic rank
and nonconstant symmetrizers. It does not show that they determine F_g, that
their normalized cone has a least point, or that a recursive selector is
mutation-compatible. It is also being checked whether some source/sink cuts
are consequences of existing neighbor pair-slice and lower-rank Pieri rules;
the rank reduction itself remains exact even where the inequalities are
redundant. More general intermediate-vertex surgeries may have additional
force but need a separate finite-theta/acyclic-target argument.
