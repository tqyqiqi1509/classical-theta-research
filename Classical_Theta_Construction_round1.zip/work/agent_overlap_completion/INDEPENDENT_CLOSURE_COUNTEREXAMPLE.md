# Finite independent-chart closure depends on the starting orientation

## Exact statement

The finite independent-chart pair cone on the exact minimal theta Newton
carrier need not have a coefficientwise least point, even in a classical
acyclic skew-symmetric rank-three seed.

Start with

    B = [[0,0,3],[0,0,2],[-3,-2,0]],
    g = (-8,-7,29), d=(8,7,9).

The previously certified enhanced cone has coefficientwise least point
F=F59085. Its comparison with theta was not assumed. Put

    A = u v w (1+u)^5 (1+v)^5,
    C = u^6 v^5 w^3 (1+v),
    D47 = A-C, H=F+D47.

Mutate the sink 2. The new data are

    B' = [[0,0,-3],[0,0,-2],[3,2,0]],
    g' = (79,51,-29), d'=(8,7,29).

Let F',H',D47' be their exact Laurent/F-coordinate resets. Then H' is an
integer feasible point of the finite independent-chart pair cone at this
new seed. It lowers three coefficients of F':

| p | F'_p | D47'_p | H'_p |
|---|---:|---:|---:|
| (6,5,25) | 104 | -1 | 103 |
| (6,5,26) | 924 | -1 | 923 |
| (6,6,27) | 195 | -1 | 194 |

The first negative coefficient follows immediately from the C term: at
(p0,p1)=(6,5), the old color-2 exponent is r=29-18-10=1, so
-u^6 v^5 w^3 becomes -u^6 v^5 (w')^25(1+w'). The A term starts later in
that fiber.

## Correct carrier and full constraint checks

The target carrier has 972 lattice points and eight vertices. The artifact
contains exact integer facet inequalities; every vertex of their bounded
intersection was enumerated by rational three-facet intersections and lies
in the support of F'. Both F' and H' have coefficient one at every vertex
and exactly the same convex hull.

This is the correct theta Newton carrier. The old carrier was already
certified independently of interior coefficients. A subtraction-free
coordinate mutation pulls tropical valuations back by its tropical map.
Therefore any two Laurent-positive old functions with the same old Newton
polytope have the same new Newton polytope. Apply this to old theta and F;
their interior coefficients need not be identified. The same argument
applies to H. No conjectural higher-rank theta table enters this step.

Direct exact divisions verify every one-color star quotient and the joint
independent-color quotient of H' is nonnegative. All rank-two LLZ slices in
all independent mutation charts of B' were then computed: all 4,955
distinct rows are nonnegative on H'. The same function violates one of the
old enhanced-cone rows, with value -1. Thus the change of initial seed loses
a genuine critical overlap.

## Unique mass minimum and absence of a coefficientwise least point

The target finite cone includes the initial pair conditions of the original
seed, because its independent set {2} returns to that seed. In rank three
these imply its old star constraints; the disconnected pair {0,1} also
supplies the old common-binomial cube quotient.

Consequently every target-feasible point, after transport back, lies in the
old initial-pair cone. Its difference from F lies in the previously
complete-DD-certified 56-ray tangent cone. The target mass functional is
strictly positive on all 56 rays; the smallest ray value is 1. Hence F'
is the unique target mass minimum, of value 6,586,129,065. H' has mass
6,678,393,125.

Any coefficientwise least point would also be a mass minimum, hence would
equal F'. But H' lowers its three displayed coefficients. There is thus no
coefficientwise least point in this target cone. A separate exact primal
and dual calculation gives the minimum of coefficient (6,5,25) as 21.

The mass selector itself still chooses F' in this example. Its general
mutation behavior is not settled by this counterexample.

## Reproducible files

* `independent_closure_counterexample.py` and
  `independent_closure_counterexample.json`: target polynomials, carrier,
  exact star/cube divisions, all finite chart checks, one mass LP proposal,
  and the exact coefficient-minimum certificate.
* `mutated_mass_tangent_certificate.json`: all 56 strictly positive target
  mass values. This supplies the exact mass proof independently of the
  unresolved numerical LP dual.
* `hard_inverse_covariance_results.json`: the adjacent-seed comparison.
* `hard_covariance_tangent_results.json`: the forward implication of 5,097
  new rows remains correct; the inverse implication is what fails.

The source orientation has Cartan*d=(-11,-4,-20), whereas the mutated
orientation has a strict source/sink box descent back to it. This motivates
an orientation-normalization mechanism; it does not prove that mechanism.
