#!/usr/bin/env python3
"""General independent-chart pair cones on certified minimal Newton carriers.

Floating linear programming only proposes candidates. Every reported primal,
dual and coordinatewise lower bound is verified over Q by the shared exact
implementations. No finite sample is promoted to a general theorem.
"""
from pathlib import Path
import sys, json, time, math, argparse
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
sys.path[:0]=[str(WORK/'agent_packet_propagation'),str(WORK/'agent_acceptance')]
from mandatory_support import build_logic
from packet_coordinate_minima import exact_vector
from schofield_carrier import finite_dual
from commuting_packets import augment as cube_augment
from ranktwo_packets import augment as pair_augment
from independent_chart_closure import augment as chart_augment
from linear_carrier import exact_conic

def compact_dual(d):
    if not d.get('valid'):return d
    return {'valid':True,'value':d['value'],
            'lambda':[[i,a] for i,a in enumerate(d['lambda']) if a[0]]}

def dump_poly(F):return [{'p':p,'a':str(a)} for p,a in sorted(F.items()) if a]

def run_case(case, chart_cap=12000, coordinate_limit=None):
    tic=time.time();B=case['B'];g=case['g']
    C=case.get('carrier') or {'d':case['d'],'vertices':case['vertices'],'lattice_points':case['points']}
    out={'B':B,'g':g,'d':C['d'],'carrier_points':len(C['lattice_points']),
         'vertices':C['vertices'],'points':C['lattice_points'],'D':case.get('D')}
    M,R,S=build_logic(B,g,C)[:3]
    out['space']=S
    M,R,ci=cube_augment(B,g,C,M,R)
    M,R,pi=pair_augment(B,g,C,M,R)
    M,R,oi=chart_augment(B,g,C,M,R,cap=chart_cap)
    out.update({'coordinates':len(R),'cube_rows':ci.get('new_coordinates'),
                'pair_rows':pi.get('new_coordinates'),'chart_rows':oi['new_coordinates'],
                'chart_count':len(oi['charts']),'construction_seconds':time.time()-tic})
    lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':30})
    out['lp_status']=int(lp.status)
    if lp.x is None:return {**out,'status':'mass_lp_unresolved','seconds':time.time()-tic}
    x=exact_vector(M,lp.x)
    if x is None:return {**out,'status':'mass_primal_not_exact','lp_mass':float(lp.fun),'seconds':time.time()-tic}
    F={p:x[i] for p,i in M['ids'].items() if x[i]}
    mass=sum(F.values());out['F']=dump_poly(F);out['mass']=str(mass)
    out['integral']=all(a.denominator==1 for a in x)
    md=finite_dual(M,lp.eqlin.marginals)
    out['mass_dual']=compact_dual(md)
    out['mass_optimal_proved']=bool(md.get('valid') and Fraction(*md['value'])==mass)
    if not out['mass_optimal_proved']:
        origin=M['ids'][(0,)*len(g)]
        target=tuple(sum(R[i][j] for i in M['ids'].values())-mass*R[origin][j] for j in range(len(R[0])))
        proof=exact_conic(target,R)
        if proof is not None:
            out['mass_optimal_proved']=True
            out['mass_conic_certificate']=[[i,str(a)] for i,a in proof]
    if not out['mass_optimal_proved']:
        return {**out,'status':'mass_dual_unresolved','seconds':time.time()-tic}
    origin=M['ids'][(0,)*len(g)];positive=[i for p,i in M['ids'].items() if x[i]>0]
    # Large coefficients first expose high-degree disagreements quickly.
    positive.sort(key=lambda i:(-sum(M['columns'][i][1]),-x[i],i))
    proofs=[];unknown=[];checked=0
    for i in positive:
        if coordinate_limit is not None and checked>=coordinate_limit:break
        checked+=1
        if R[i]==tuple(x[i]*a for a in R[origin]):
            proofs.append({'column':i,'kind':'fixed_by_linear_equations','value':str(x[i])});continue
        cost=np.zeros(len(R));cost[i]=1
        lp2=linprog(cost,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':20})
        if lp2.x is None:
            unknown.append({'column':i,'reason':'lp_unresolved','lp_status':int(lp2.status)});continue
        y=exact_vector(M,lp2.x)
        if y is not None and y[i]<x[i]:
            G={p:y[j] for p,j in M['ids'].items() if y[j]}
            out['failure']={'p':M['columns'][i][1],'selected':str(x[i]),'smaller':str(y[i]),
                            'smaller_integral':all(a.denominator==1 for a in y),'F':dump_poly(G)}
            out.update({'status':'exact_a_least_counterexample','checked_coordinates':checked,
                        'coordinate_certificates':proofs,'unresolved_coordinates':unknown,
                        'seconds':time.time()-tic})
            return out
        MM=dict(M);MM['c']=cost;du=finite_dual(MM,lp2.eqlin.marginals)
        if du.get('valid') and Fraction(*du['value'])>=x[i]:
            proofs.append({'column':i,'value':str(x[i]),'dual':compact_dual(du)});continue
        target=tuple(a-x[i]*b for a,b in zip(R[i],R[origin]))
        cp=exact_conic(target,R)
        if cp is not None:
            proofs.append({'column':i,'value':str(x[i]),'conic_certificate':[[j,str(a)] for j,a in cp]})
        else:unknown.append({'column':i,'reason':'exact_dual_unresolved','lp_value':float(lp2.fun)})
    out.update({'positive_coefficients':len(positive),'checked_coordinates':checked,
                'coordinate_certificates':proofs,'unresolved_coordinates':unknown,
                'a_least_proved':checked==len(positive) and not unknown,'seconds':time.time()-tic})
    out['status']='a_least_proved' if out['a_least_proved'] else 'partial_exact_certificates'
    return out

def atomic_json(path,obj):
    tmp=path.with_suffix('.writing');tmp.write_text(json.dumps(obj,separators=(',',':')));tmp.replace(path)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=43)
    ap.add_argument('--input',default=str(WORK/'agent_packet_propagation'/'large_origin_screen_results.json'))
    ap.add_argument('--output',default='large_overlap_batch_results.json');ap.add_argument('--coordinate-limit',type=int)
    ar=ap.parse_args();raw=json.loads(Path(ar.input).read_text());cases=raw['results'] if isinstance(raw,dict) else raw
    tic=time.time();results=[]
    for ci in range(ar.start,min(ar.stop,len(cases))):
        c=cases[ci]
        if not isinstance(c.get('points'),list) and 'carrier' not in c:continue
        print('START',ci,'rank',len(c['g']),'d',c['d'],flush=True)
        t=time.time()
        try:r=run_case(c,coordinate_limit=ar.coordinate_limit)
        except (OverflowError,ArithmeticError,ValueError) as e:r={'B':c['B'],'g':c['g'],'d':c['d'],'status':'resource_or_exact_check_unresolved','reason':str(e),'seconds':time.time()-t}
        r['source_index']=ci;results.append(r)
        atomic_json(HERE/ar.output,{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'mass',r.get('mass'),'integer',r.get('integral'),'seconds',r['seconds'],flush=True)
        if r.get('failure'):print('COUNTEREXAMPLE',ci,r['failure']['p'],r['failure']['selected'],r['failure']['smaller'],flush=True)

if __name__=='__main__':main()
