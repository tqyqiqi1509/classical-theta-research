# Source/sink mutation charts as a finite phase set over one integer layer

2026-11-13. Elementary general combinatorial reduction; this is NOT a finite
positivity atlas theorem. It applies to every connected acyclic valued
exchange graph, with arbitrary edge multiplicities and symmetrizer.

## Height states

Choose the initial acyclic orientation. For every initial arrow u -> v impose

    h_v <= h_u <= h_v + 1,        h in Z^n.

Orient that edge as u -> v when h_u=h_v and as v -> u when h_u=h_v+1.
Starting at h=0, a mutation at a source i is h -> h+e_i; a mutation at a
sink i is h -> h-e_i. The displayed inequalities prove this directly on
every incident edge. Source/sink mutation creates no two-step arrows, so the
underlying valued graph and its edge multiplicities remain fixed.

The feasible height set H is closed under coordinatewise minimum and maximum.
For example, the two difference constraints h_v-h_u<=0 and h_u-h_v<=1 are
preserved by both min and max. Every finite interval [a,b] in H is therefore
a finite distributive lattice, with covering edges changing one coordinate
by one. A cover h -> h+e_i is exactly a legal source mutation.

For completeness, every h can be reached: choose integers L<=min_i h_i and
U>=max_i h_i. A topological source order changes L*1 into (L+1)*1. Within
the interval [L*1,U*1], the event poset has events (i,r) for
L<r<=U. For every initial edge u -> v, impose

    (u,r) < (v,r) < (u,r+1)

whenever the displayed events exist, and impose the same-color order.
An order ideal is precisely a feasible height vector. Hence any linear
extension of the ideal corresponding to h supplies a legal source word.

## Independence of paths to a height state

Any two increasing paths in a finite distributive lattice differ by exchanges
of adjacent incomparable events. Two events that can be exchanged cannot
have adjacent colors: adjacent-color events are ordered by the relations
above. Therefore their cluster mutations commute. General paths can be
compared inside a finite height interval by the usual square moves and
backtrack cancellations of an order-ideal lattice. Both operations preserve
the full seed, including principal frozen data.

Consequently there is a well-defined seed attached to each h in H, and EVERY
source/sink mutation word reaches one of these seeds. Different h can give
the same seed, e.g. in finite type; no injectivity is asserted.

## Finite phases

Along an edge, |h_u-h_v|<=1. Connectedness gives

    max_i h_i-min_i h_i <= diameter(graph) <= n-1.

Write h=m*1+delta, where m=min_i h_i. Then delta belongs to the finite set

    Delta={delta in H: min_i delta_i=0, 0<=delta_i<=n-1}.

In particular |Delta|<=n^n. The inequality constraints generally give a much
smaller set, and it is explicitly enumerable by integer arithmetic.

Let C be one fixed topological source order, each vertex used exactly once.
It maps k*1 to (k+1)*1. For each delta choose a fixed linear extension w_delta
of its event ideal, of length at most n(n-1). The seed at h=m*1+delta is
obtained by C^m followed by w_delta, interpreting C^{-1} as the reverse sink
order. Thus the whole source/sink atlas has the explicit description

    finite set of phases Delta  x  integer Coxeter layer m.

This uses only a finite graph and integer event orders, and does not introduce
scattering walls, broken lines, or a representation-theoretic construction.

## What this does and does not settle

It replaces an arbitrary branching word search by finitely many bi-infinite
sequences. To get a finite atlas for a prescribed coefficient degree N, one
must still prove an effective tail statement: beyond computable layers, the
normalized degree-N transports contribute no new inequalities, or all their
rows lie in the previously generated cone.

The fact that individual preprojective root heights grow is not alone such a
proof. Tropical changes of the label, possible exceptional linear subspaces,
and the effect of intervening high-degree mutations must be controlled.
Nor does the source/sink atlas exhaust all mutation charts in general.

## Audited literature interface

Parkinson--Yau, arXiv:2107.09962v3, Theorem 3.28 and its proof (PDF pp.27--28),
gives a genuinely finite regular-completion theorem for a locally constant
Coxeter-group partition with finitely many root-wall boundaries. The proof
embeds it into the finite partition by n-small inversion sets and bounds the
number of refinements by the number of those states. This is a possible
mechanism for the required tail/control theorem; its hypothesis has not been
proved for our coefficient signatures, which involve arbitrary positive
degree vectors, not just real roots.

Hohlweg--Nadeau--Williams, arXiv:1510.01607v2, Definitions 1.1,3.7--3.8 and
Theorems 1.2,3.9 were read from the primary PDF. Its automata recognize reduced
Coxeter words; that fact alone does not decide arbitrary cluster-jet reachability.

Dyer--Hohlweg--Fishel--Mark, arXiv:2303.16569v2, Theorems 4.4 and4.6 were
checked for scope. The latter records general bipodality of m-small roots and
the Garside-shadow property of m-low elements, superseding restricted older
statements. Metadata needs care: arXiv's fixed v2 is dated24June2024, while
the HTML's body reportedly has a2026 date. We identify it by fixed version
and do not infer a2026 mathematical update from that inconsistent date.

Macauley--Mortveit, arXiv:0910.4376v2, is a relevant primary lead on admissible
source-to-sink sequences and orientation classes. Its abstract was read; the
elementary height-lattice proof above does not rely on an unverified theorem
from that paper.
