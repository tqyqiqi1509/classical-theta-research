#!/usr/bin/env python3
"""Finite source/sink surgery coefficients in rank three.

All rows use integer binomial coefficients and explicit LLZ recurrence on
the remaining pair. The geometric/theta comparison is documented separately.
"""
from overlap_batch import *
from functools import lru_cache
from itertools import product
from collections import defaultdict
from linear_carrier import add,primitive
from ranktwo_packets import greedy
from scipy.sparse import coo_matrix,hstack,vstack
from independent_chart_closure import coefficient_references

@lru_cache(None)
def disconnected_greedy(Bt,h,i):
    n=len(h)
    if n!=3:raise ValueError('this explicit implementation uses rank1 times rank2')
    B=[list(r) for r in Bt];rest=[j for j in range(n) if j!=i]
    if B[rest[0]][rest[1]]<0:rest.reverse()
    b=B[rest[0]][rest[1]];c=-B[rest[1]][rest[0]]
    pair=greedy(b,c,(h[rest[0]],h[rest[1]]));d=max(-h[i],0)
    out={}
    for s in range(d+1):
        for p,a in pair.items():
            q=[0]*n;q[i]=s;q[rest[0]]=p[0];q[rest[1]]=p[1]
            out[tuple(q)]=math.comb(d,s)*a
    return out

def divisors(m):
    return [a for a in range(1,m+1) if m%a==0] if m else [1]

def source_sink_rows(B,g,Frows,points=None,step_cap=50000,all_factors=False):
    n=len(g)
    if n!=3:raise ValueError('explicit rank1 times rank2 implementation requires n=3')
    width=len(next(iter(Frows.values())));zero=(0,)*width
    P=list(Frows) if points is None else list(map(tuple,points))
    rows=[];info=[]
    for i in range(n):
        signs=[]
        if all(B[i][j]>=0 for j in range(n)):signs.append(1)
        if all(B[i][j]<=0 for j in range(n)):signs.append(-1)
        factors=[(1,1)]
        if all_factors:
            factors=list(product(divisors(math.gcd(*(abs(B[i][j]) for j in range(n) if j!=i))),
                                 divisors(math.gcd(*(abs(B[j][i]) for j in range(n) if j!=i)))))
        for sign,(ss,tt) in product(signs,factors):
            roww=tuple(sign*tt if j==i else -B[i][j]//ss for j in range(n))
            colw=tuple(-sign*ss if j==i else -B[j][i]//tt for j in range(n))
            lam=max(0,max(-sum(roww[j]*p[j] for j in range(n)) for p in P))
            B0=tuple(tuple(0 if j==i or k==i else B[j][k] for k in range(n)) for j in range(n))
            gp=tuple(g[j]+max(colw[j],0)*lam for j in range(n))
            slices=defaultdict(dict);counts=0
            for p,a in Frows.items():
                rr=lam+sum(roww[j]*p[j] for j in range(n));alpha=sum(max(-roww[j],0)*p[j] for j in range(n))
                if rr<0:raise ArithmeticError('invalid surgery carrier bound')
                for j in range(rr+1):
                    t=alpha+j;slices[t][p]=tuple(math.comb(rr,j)*v for v in a)
            for t,rem in sorted(slices.items()):
                h=tuple(gp[j]-colw[j]*t for j in range(n));steps=0
                while rem:
                    if steps>=step_cap:raise OverflowError('surgery triangular expansion cap')
                    steps+=1;p=min(rem,key=lambda x:(sum(x),x));a=rem[p]
                    label=tuple(h[j]+sum(B0[j][k]*p[k] for k in range(n)) for j in range(n))
                    key=('surgery',i,sign,ss,tt,lam,t,p,label)
                    rows.append((key,a));counts+=1
                    for q,c in disconnected_greedy(B0,label,i).items():
                        r=tuple(p[j]+q[j] for j in range(n));z=add(rem.get(r,zero),a,-c)
                        if any(z):rem[r]=z
                        elif r in rem:del rem[r]
            info.append({'vertex':i,'kind':'source' if sign==1 else 'sink','factors':[ss,tt],'lambda':lam,
                         'target_B':B0,'slice_count':len(slices),'coefficient_rows':counts})
    return rows,info

def augment(B,g,C,M,R):
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])};new,info=source_sink_rows(B,g,source,C['lattice_points'])
    refs=coefficient_references(M,R);seen={primitive(tuple(row)) for row in R};keep=[]
    for key,row in new:
        row=primitive(row)
        if row in seen:continue
        seen.add(row);keep.append((key,row))
    old=len(R);nc=len(keep);rr=[];cc=[];vv=[];ids=[]
    for t,(key,row) in enumerate(keep):
        coeff=[Fraction(a,d) for a,(j,d) in zip(row,refs)];den=math.lcm(*(a.denominator for a in coeff))
        rr.append(t);cc.append(old+t);vv.append(den);raw=[]
        for a,(j,d) in zip(coeff,refs):
            if not a:continue
            w=int(a*den)
            if abs(w)>=2**53 or den>=2**53:raise OverflowError('surgery integer float representation cap')
            rr.append(t);cc.append(j);vv.append(-w);raw.append([j,w])
        ids.append({'key':key,'denominator':den,'raw':raw})
    extra=coo_matrix((vv,(rr,cc)),shape=(nc,old+nc)).tocsc()
    N=dict(M);N['A']=vstack([hstack([M['A'],coo_matrix((M['A'].shape[0],nc))]),extra]).tocsc()
    N['b']=np.r_[M['b'],np.zeros(nc)];N['c']=np.r_[M['c'],np.zeros(nc)]
    N['columns']=list(M['columns'])+[key for key,row in keep]
    return N,list(R)+[row for key,row in keep],{'surgery_info':info,'new_coordinates':nc,'identities':ids}

def hard_case(all_factors=False):
    folder=WORK/'agent_packet_propagation'
    raw=json.loads((folder/'large_origin_exact_failure_2.json').read_text());B,g,C=raw['B'],raw['g'],raw['carrier']
    M,R,S=build_logic(B,g,C)[:3];Frows={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    rows,info=source_sink_rows(B,g,Frows,C['lattice_points'],all_factors=all_factors);refs=coefficient_references(M,R)
    cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    F={tuple(a['p']):Fraction(a['a']) for a in cand['F']}
    rays=json.loads((folder/'pair_tangent_circuits_results.json').read_text())['rays']
    polys=[F]+[{tuple(a['p']):Fraction(a['a']) for a in r['coefficient_polynomial']} for r in rays]
    pars=[[P.get(M['columns'][j][1],Fraction(0))/d for j,d in refs] for P in polys]
    pars=[[(j,int(a) if a.denominator==1 else a) for j,a in enumerate(pp) if a] for pp in pars]
    results=[];badF=[];active_rows=[]
    for key,row in rows:
        values=[sum(row[j]*b for j,b in pp) for pp in pars]
        if values[0]<0:badF.append({'key':key,'value':str(values[0])})
        if values[0]==0 and any(a<0 for a in values[1:]):
            active_rows.append({'key':key,'ray_values':[[i,str(a)] for i,a in enumerate(values[1:]) if a]})
    out={'B':B,'g':g,'rows':len(rows),'info':info,'F_feasible':not badF,'negative_F_rows':badF,
         'active_rows_negative_on_old_tangent':active_rows}
    name='hard_valued_source_surgery_results.json' if all_factors else 'hard_source_surgery_results.json'
    atomic_json(HERE/name,out)
    print('rows',len(rows),'F_feasible',not badF,'new_active_cuts',len(active_rows),flush=True)
    for a in active_rows[:10]:print(a,flush=True)

if __name__=='__main__':hard_case(all_factors='--all-factors' in sys.argv)
