# Finite overlap completion: literature and route log

## 2026-11-13 07:35 UTC

### Source/sink surgery

The general rank-reduction formula is proved in `SOURCE_STAR_SURGERY.md` and
independently checked by the interior and source-surgery agents. The initial
extension can be cyclic; its one-step acyclic mutation, full-rank BFZ upper
bound invariance, finite theta expansion, valuative independence, and freezing
are all needed in the comparison proof. Positive Laurent coefficients alone
are not an identification theorem.

The complete joint rank-one times rank-two expansion was computed on the hard
fork. Unit star surgery gives 8,442 rows. All finite integral star
factorizations give 14,049 rows. Both families accept F59085 and neither
removes any old tangent ray at that point. Thus the surgery formula supplies a
rank-reduction interface but does not resolve interior rigidity. Increasing
lambda does not rescue this: Pascal's identity and positive Pieri show that
all larger lambda constraints follow from the minimal lambda constraints.

The next computational question is whole-cone mutation covariance of the
finite independent-chart pair completion. The entire Laurent space is
transported, then additional actual rank-two greedy-slice rows are tested for
exact conic implication. An accepted candidate on a collection of examples
is not confused with invariance of the entire cone.

### New primary literature, checked scope

1. Rupel--Stella--Williams, *On Generalized Minors and Quiver
   Representations*, arXiv:1606.03440v2 (22 March 2017), Section 3.1,
   Lemma 3.1 and its full proof, Theorem 3.3's exchange relations:
   https://arxiv.org/html/1606.03440v2 .
   **Useful and verified at the stated scope.** For connected non-finite-type
   acyclic skew-symmetrizable B, it explicitly computes all c-vectors on the
   two-sided Coxeter belt. The proof is a sign-coherent mutation induction
   using reduced prefixes of the repeated Coxeter word. It gives precisely
   the finite families of Coxeter root orbits needed for an effective belt
   cutoff. It does not identify arbitrary theta coefficients, nor does it
   assert that all mutation seeds are source/sink reachable.

2. Chonev--Ouaknine--Worrell, *On the Complexity of the Orbit Problem*,
   arXiv:1303.2981v3 (22 June 2016), introduction and Theorems 2.1--2.2:
   https://arxiv.org/pdf/1303.2981 .
   **Useful interface; full algorithm not reimplemented here.** Exact
   point-to-point rational matrix-orbit reachability is decidable (the
   Kannan--Lipton problem). The paper gives explicit computable witness
   bounds even for target spaces of dimension at most three. One must use
   finitely many exact vector targets, not replace this with the much more
   difficult unrestricted subspace/Skolem problem. Root is auditing the
   original Kannan--Lipton source independently.

3. Current searches returned Tang, arXiv:2609.30387, *Quantum Laurent
   positivity in rank three*. The abstract says its argument depends on a
   companion mutation-acyclic positivity manuscript. The official full-page
   retrieval returned DisabledError. **No conclusion adopted.** It is
   quantum and not a substitute for the classical combinatorial mechanism.

4. Current searches again returned Li--Pan2201.01440 and recent repostings of
   rank-two greedy/theta results. **No Li--Pan theorem adopted.** Search
   result metadata such as a recent crawl date is not treated as a new
   mathematical result. Existing rank-two LLZ recurrence is used only at its
   already audited rank-two scope.

### Effective source/sink tail interface

The height-lattice proof already reduces source/sink seeds to finitely many
phases times a Coxeter period. A stronger observation identifies transition
roots directly: a source mutation at height h is an event (i,h_i+1) in the
finite event poset. Extending its prefix to a constant height and commuting
independent events identifies its inversion root with the same-color
occurrence in the standard Coxeter belt. In a connected non-finite component,
the Coxeter word is reduced to every length, so these transition roots are
distinct and their Coxeter orbits are not periodic. The negative tail starts
from the all-red seed of height -1 and is analogous.

Therefore a prospective degree-N cutoff can enumerate the finite integer
vectors p>=0 with total degree at most N, solve point-orbit queries for each
of the finitely many belt root orbits, and take the largest returned event
height. Height spread at most n-1 then bounds the central region containing
all low-degree source/sink transitions. This is a concrete termination
interface. The remaining comparison must check that the normalized
y-adic coefficient rows under consideration really stabilize when all
unsigned pivot roots have degree greater than N. It is not a result for the
full mutation atlas and is not yet a theta selector.

## 2026-11-13 07:55--08:06 UTC: route correction and replacement

The exact height-event root formula was completed and independently checked
on60 valued matrices and23,520 mutations. The RSW primary proof supplies the
standard belt formula; the new event-poset argument extends transition roots
to the full source/sink height graph. Parent is auditing an elementary
effective orbit cutoff, so no unchecked orbit implementation is used.

The finite independent-chart cone passed extensive one-direction implication
tests, including the full hard-fork cone. The inverse direction nevertheless
fails after mutating its sink. On the correct972-point target Newton
carrier, the integer H'=F'+D47' satisfies all4,955 finite rows but lowers
three ordinary coefficients. Exact tangent masses prove F' remains the
unique mass minimum, so this target cone has no coordinatewise least point.
The initial successful examples are therefore not promoted to a general
mutation-covariance theorem.

A new general upper-product interface was derived using the already audited
classical strong theta multiplication and freezing inputs. Any rank-two
subset gives explicit LLZ-times-binomial coefficient upper bounds in every
acyclic rank and nonconstant symmetrizer. The old fractional hard optimum is
excluded by four zero bounds. Initial star plus these upper bounds already
has exact least point F59085, with rational mass and every-coefficient
certificates. Full creator/Pieri remainder decomposition is the next general
mechanism; higher-rank cached tables remain explicitly conditional.

Fullstar, partialstar, all divisor factorizations, lower independent charts,
and expanded auxiliary pair slices did not remove D47. These failures are
retained; they are not rebranded as rigidity results. This agent hands off
at08:06 so a fresh agent can pursue the stronger upper-product mechanism.
