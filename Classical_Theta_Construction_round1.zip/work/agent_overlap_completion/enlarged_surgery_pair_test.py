#!/usr/bin/env python3
"""True rank-two slices involving the new surgery vertex.

No lower-rank theta table is used. The auxiliary mutation is explicit and
the target matrix is acyclic. Rows are transported on the full old U-space.
"""
from partial_star_pair_test import *
from linear_carrier import mutate_matrix,mutate_g

def extension(B,g,Frows,P,i,a,ss=1,tt=1):
    n=len(g);sign=1 if all(B[i][j]>=0 for j in range(n)) else -1
    c=[0 if j==i or not B[i][j] else int(Fraction(a[j]*abs(B[j][i]),abs(B[i][j]))) for j in range(n)]
    assert all(a[j]%ss==0 and c[j]%tt==0 for j in range(n))
    roww=[sign*tt if j==i else -sign*a[j]//ss for j in range(n)]
    colw=[-sign*ss if j==i else sign*c[j]//tt for j in range(n)]
    E=[B[j]+[colw[j]] for j in range(n)]+[roww+[0]]
    lam=max(0,max(-sum(roww[j]*p[j] for j in range(n)) for p in P))
    gg=tuple(g)+ (lam,);BB=mutate_matrix(E,n);hh=mutate_g(E,gg,n)
    new={}
    for p,row in Frows.items():
        r=lam+sum(roww[j]*p[j] for j in range(n));alpha=sum(max(-roww[j],0)*p[j] for j in range(n))
        assert r>=0
        for k in range(r+1):new[tuple(p)+(alpha+k,)]=tuple(math.comb(r,k)*v for v in row)
    return BB,hh,new,{'vertex':i,'removed_weights':a,'factors':[ss,tt],'lambda':lam,
                      'extended_initial_B':E,'extended_target_B':BB,'extended_target_g':hh,'target_points':len(new)}

def main():
    folder=WORK/'agent_packet_propagation';raw=json.loads((folder/'large_origin_exact_failure_2.json').read_text())
    B,g,C=raw['B'],raw['g'],raw['carrier'];M,R,S=build_logic(B,g,C)[:3]
    Frows={p:R[j] for p,j in M['ids'].items() if any(R[j])};refs=coefficient_references(M,R)
    cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    F={tuple(a['p']):Fraction(a['a']) for a in cand['F']}
    rays=json.loads((folder/'pair_tangent_circuits_results.json').read_text())['rays']
    polys=[F]+[{tuple(a['p']):Fraction(a['a']) for a in r['coefficient_polynomial']} for r in rays]
    pp=[[P.get(M['columns'][j][1],Fraction(0))/d for j,d in refs] for P in polys]
    params=[[(j,int(a) if a.denominator==1 else a) for j,a in enumerate(z) if a] for z in pp]
    families=[(0,[0,0,3],s,t) for s,t in product([1,3],repeat=2)]
    families += [(1,[0,0,2],s,t) for s,t in product([1,2],repeat=2)]
    families += [(0,[0,0,1],1,1),(0,[0,0,2],1,1),(1,[0,0,1],1,1)]
    out=[];tic=time.time()
    for i,a,s,t in families:
        BB,hh,T,info=extension(B,g,Frows,C['lattice_points'],i,a,s,t)
        print('START',i,a,s,t,'points',len(T),flush=True)
        rows,ri=section_rows(BB,hh,T,step_cap=50000);badF=[];cuts=[];count=0
        for key,row in rows:
            if len(g) not in key[1]:continue
            count+=1;v=[sum(row[j]*x for j,x in par) for par in params]
            if v[0]<0:badF.append({'key':key,'value':str(v[0])})
            if v[0]==0 and any(x<0 for x in v[1:]):
                cuts.append({'key':key,'row':row,'ray_values':[[j,str(x)] for j,x in enumerate(v[1:]) if x]})
        rec={**info,'tested_rows_involving_auxiliary':count,'F_feasible':not badF,'negative_F_rows':badF,'active_cuts':cuts}
        out.append(rec);atomic_json(HERE/'enlarged_surgery_pair_results.json',{'B':B,'g':g,'families':out,'seconds':time.time()-tic})
        print('END',i,a,s,t,'rows',count,'feasible',not badF,'new active cuts',len(cuts),flush=True)
        for z in cuts[:3]:print('CUT',z['key'],z['ray_values'],flush=True)

if __name__=='__main__':main()
