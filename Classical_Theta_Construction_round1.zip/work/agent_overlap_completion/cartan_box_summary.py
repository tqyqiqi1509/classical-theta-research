#!/usr/bin/env python3
"""Record orientation and exact source/sink box descents for every batch input."""
from overlap_batch import *
from linear_carrier import mutate_matrix,mutate_g
from schofield_carrier import acyclic_dimension

def describe(c):
    B,g,d=c['B'],c['g'],c['d'];n=len(g)
    A=[[2 if i==j else -abs(B[i][j]) for j in range(n)] for i in range(n)]
    ad=[sum(A[i][j]*d[j] for j in range(n)) for i in range(n)]
    moves=[]
    for i in range(n):
        kinds=[]
        if all(B[i][j]>=0 for j in range(n)):kinds.append('source')
        if all(B[i][j]<=0 for j in range(n)):kinds.append('sink')
        if not kinds:continue
        BB=mutate_matrix(B,i);gg=mutate_g(B,g,i);dd,v,order=acyclic_dimension(BB,gg)
        moves.append({'vertex':i,'kind':kinds,'new_d':dd,'new_g':gg,'total_box_change':sum(dd)-sum(d),
                      'new_box_volume':math.prod(x+1 for x in dd),'new_topological_order':order})
    return {'B':B,'g':g,'D':c.get('D'),'d':d,'Cartan_times_d':ad,
            'fundamental_imaginary_inequalities':all(a<=0 for a in ad),
            'topological_order':acyclic_dimension(B,g)[2],
            'source_sink_moves':moves,'locally_minimal_total_box':all(m['total_box_change']>=0 for m in moves),
            'has_strict_box_descent':any(m['total_box_change']<0 for m in moves)}

def main():
    out=[]
    recovered={1,19}
    for batch,file in [('large','large_overlap_batch_results.json'),('valued','valued_overlap_results.json')]:
        cases=json.loads((HERE/file).read_text())['results']
        for c in cases:
            if not all(k in c for k in ('B','g','d')):continue
            r=describe(c);i=c['source_index'];r.update({'batch':batch,'source_index':i,'reported_status':c['status'],
                'a_least_certified':bool(c.get('a_least_proved') or batch=='large' and i in recovered or batch=='valued' and i==21)})
            out.append(r)
    new=json.loads((HERE/'independent_closure_counterexample.json').read_text())
    r=describe({'B':new['new_B'],'g':new['new_g'],'d':new['new_d']});r.update({'batch':'sink_mutation_counterexample','a_least_certified':False,'no_a_least_proved':True});out.append(r)
    summaries={}
    for batch in sorted({r['batch'] for r in out}):
        subset=[r for r in out if r['batch']==batch]
        summaries[batch]={'count':len(subset),'certified_a_least':sum(r['a_least_certified'] for r in subset),
                          'fundamental':sum(r['fundamental_imaginary_inequalities'] for r in subset),
                          'locally_minimal_total_box':sum(r['locally_minimal_total_box'] for r in subset),
                          'with_strict_source_sink_descent':sum(r['has_strict_box_descent'] for r in subset)}
    atomic_json(HERE/'cartan_box_batch_summary.json',{'summaries':summaries,'results':out})
    print(summaries)

if __name__=='__main__':main()
