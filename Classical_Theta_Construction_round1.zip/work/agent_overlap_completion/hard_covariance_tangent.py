#!/usr/bin/env python3
"""Whole-cone covariance certificates via the complete hard-fork tangent cone."""
from critical_overlap_covariance import *

def main():
    folder=WORK/'agent_packet_propagation'
    case=json.loads((folder/'large_origin_exact_failure_2.json').read_text())
    cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    rays=json.loads((folder/'independent_chart_closure_results.json').read_text())['tangent_ray_records']
    M,R,S,T=prepare(case);B,g=case['B'],case['g'];refs=coefficient_references(M,R)
    F={tuple(z['p']):Fraction(z['a']) for z in cand['F']}
    polys=[F]+[{tuple(z['p']):Fraction(z['a']) for z in ray['coefficient_polynomial']} for ray in rays]
    pars=[[P.get(M['columns'][i][1],Fraction(0))/d for i,d in refs] for P in polys]
    pars=[[(i,int(a) if a.denominator==1 else a) for i,a in enumerate(z) if a] for z in pars]
    seen={primitive(row) for row in R};out=[];tic=time.time();total=0;bad=[]
    for first in range(len(g)):
        one,err=mutate_rows(B,g,T,first,cap=100000);assert not err
        for mask in range(1,1<<len(g)):
            I=tuple(i for i in range(len(g)) if mask>>i&1)
            if first in I or not all(one[0][i][j]==0 for i in I for j in I):continue
            state=one
            for i in I:
                state,err=mutate_rows(*state,i,cap=100000);assert not err
            print('CHART',first,I,'terms',len(state[2]),flush=True)
            rows,info=section_rows(*state,step_cap=100000);count=0;neg=[];minimum=None
            for key,row in rows:
                row=primitive(row)
                if row in seen:continue
                seen.add(row);count+=1;total+=1
                vals=[sum(row[i]*a for i,a in pp) for pp in pars]
                minimum=min(vals) if minimum is None else min(minimum,min(vals))
                if any(a<0 for a in vals):
                    rec={'word':[first,*I],'key':key,'row':row,'F_value':str(vals[0]),
                         'negative_tangent_rays':[[i,str(a)] for i,a in enumerate(vals[1:]) if a<0]}
                    neg.append(rec);bad.append(rec)
            out.append({'word':[first,*I],'target_B':state[0],'target_g':state[1],
                        'transport_points':len(state[2]),'new_rows':count,'minimum_value':str(minimum),'nonnegative_on_F_and_all_tangent_rays':not neg,'failures':neg})
            atomic_json(HERE/'hard_covariance_tangent_results.json',{'B':B,'g':g,'charts':out,'new_rows':total,
                 'tangent_source':'agent_packet_propagation/independent_chart_closure_results.json','rays':len(rays),
                 'all_checked_rows_implied':not bad,'failures':bad,'seconds':time.time()-tic})
            print('END',first,I,'new',count,'negative tests',len(neg),flush=True)
    print('TOTAL',total,'negative tests',len(bad),'seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
