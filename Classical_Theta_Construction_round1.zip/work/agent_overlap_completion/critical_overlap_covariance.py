#!/usr/bin/env python3
"""Audit finite independent-chart cones under one more mutation.

The whole finite Laurent space is transported. The new constraints come from
actual rank-two LLZ sections. A failed implication is reported only together
with an exact normalized polynomial satisfying every original inequality.
An unresolved LP is never counted as either a proof or a counterexample.
"""
from overlap_batch import *
from linear_carrier import mutate_rows,primitive
from independent_chart_closure import coefficient_references
from ranktwo_packets import section_rows
import sympy as sp

def exact_conic_scaled(target,generators):
    """Positive column/target scaling improves numerical proposals only."""
    if not any(target):return []
    if target in generators:return [(generators.index(target),Fraction(1))]
    norms=np.array([max(1,max(abs(a) for a in row)) for row in generators],dtype=float)
    A=np.array(generators,dtype=float).T/norms[None,:]
    norm=max(abs(a) for a in target)
    lp=linprog(np.zeros(len(generators)),A_eq=A,b_eq=np.array(target,dtype=float)/norm,
               bounds=(0,None),method='highs')
    if lp.x is None:return None
    for eps in [1e-9,1e-12,0]:
        active=[i for i,x in enumerate(lp.x) if x>eps]
        if not active:continue
        AA=sp.Matrix.hstack(*(sp.Matrix(generators[i]) for i in active))
        try:sol,params=AA.gauss_jordan_solve(sp.Matrix(target))
        except ValueError:continue
        if params.rows:sol=sol.subs({p:0 for p in params})
        if any(x<0 for x in sol) or AA*sol!=sp.Matrix(target):continue
        return [(i,Fraction(int(x.p),int(x.q))) for i,x in zip(active,sol) if x]
    return None

def prepare(case):
    B,g=case['B'],case['g']
    C=case.get('carrier') or {'d':case['d'],'vertices':case['vertices'],'lattice_points':case['points']}
    M,R,S=build_logic(B,g,C)[:3]
    M,R,_=cube_augment(B,g,C,M,R)
    M,R,_=pair_augment(B,g,C,M,R)
    M,R,_=chart_augment(B,g,C,M,R)
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    return M,R,S,source

def exact_point(raw,R,origin):
    if raw is None:return None
    x=[Fraction(float(v)).limit_denominator(10**7) for v in raw]
    if sum(a*b for a,b in zip(origin,x))!=1:return None
    if any(sum(a*b for a,b in zip(row,x))<0 for row in R):return None
    return x

def run_case(case,stop_at_failure=True,row_cap=20000):
    tic=time.time();B,g=case['B'],case['g'];n=len(g)
    M,R,S,source=prepare(case)
    RR=list(dict.fromkeys(primitive(r) for r in R if any(r)))
    origin=source[(0,)*n]
    A=-np.array(RR,dtype=float)
    scales=np.maximum(np.max(np.abs(A),axis=1),1)
    A=A/scales[:,None]
    seen=set(RR);records=[];checked=0;implied=0;unknown=[];failure=None
    for first in range(n):
        initial,err=mutate_rows(B,g,source,first,cap=row_cap)
        if err:raise OverflowError(('first transport',first,err))
        BB,gg,T=initial
        # Each independent subset in the neighbor graph gives an actual chart.
        # Testing all rank-two rows subsumes ordinary coefficient positivity.
        for mask in range(1,1<<n):
            I=tuple(i for i in range(n) if mask>>i&1)
            if first in I:continue  # cancels/commutes back to an old chart
            if not all(BB[i][j]==0 for i in I for j in I):continue
            state=initial
            for k in I:
                state,err=mutate_rows(*state,k,cap=row_cap)
                if err:raise OverflowError(('critical chart',first,I,err))
            B2,g2,T2=state
            print('CHART',first,I,'points',len(T2),'elapsed',round(time.time()-tic,2),flush=True)
            rows,info=section_rows(B2,g2,T2)
            print('SECTION_ROWS',len(rows),'elapsed',round(time.time()-tic,2),flush=True)
            new=0;proofs=[]
            for key,row in rows:
                row=primitive(row)
                if row in seen:continue
                seen.add(row);new+=1;checked+=1
                if checked%100==0:print('ROW',checked,'implied',implied,'elapsed',round(time.time()-tic,2),flush=True)
                scale=max(1,max(abs(a) for a in row))
                lp=linprog(np.array(row,dtype=float)/scale,A_ub=A,b_ub=np.zeros(len(RR)),
                           A_eq=[origin],b_eq=[1],bounds=(None,None),method='highs',options={'time_limit':15})
                x=exact_point(lp.x,RR,origin)
                if lp.status==3:
                    # A bounded auxiliary LP supplies a reviewable witness;
                    # this box is not used to assert an implication.
                    lp=linprog(np.array(row,dtype=float)/scale,A_ub=A,b_ub=np.zeros(len(RR)),
                               A_eq=[origin],b_eq=[1],bounds=(-10**6,10**6),method='highs',options={'time_limit':15})
                    x=exact_point(lp.x,RR,origin)
                if x is not None:
                    val=sum(a*b for a,b in zip(row,x))
                    if val<0:
                        F={p:sum(a*b for a,b in zip(rr,x)) for p,rr in source.items()}
                        failure={'word':[first,*I],'key':key,'value':str(val),
                                 'row':row,'parameters':[str(a) for a in x],
                                 'F':dump_poly(F),'all_original_rows_nonnegative':True,
                                 'integral_F':all(a.denominator==1 for a in F.values())}
                        if stop_at_failure:break
                cp=exact_conic(row,RR)
                if cp is None:cp=exact_conic_scaled(row,RR)
                if cp is not None:
                    implied+=1;proofs.append({'key':key,'row':row,'combination':[[i,str(a)] for i,a in cp]})
                else:unknown.append({'word':[first,*I],'key':key,'lp_status':int(lp.status),'lp_value':None if lp.fun is None else float(lp.fun)*scale})
            records.append({'word':[first,*I],'target_B':B2,'target_g':g2,
                            'transport_points':len(T2),'new_rows':new,'proofs':proofs})
            if failure and stop_at_failure:break
        if failure and stop_at_failure:break
    return {'B':B,'g':g,'D':case.get('D'),'dimension':S['dimension'],
            'original_rows':len(RR),'checked_new_rows':checked,'exact_implied_rows':implied,
            'unresolved':unknown,'failure':failure,'charts':records,'seconds':time.time()-tic,
            'status':'exact_covariance_counterexample' if failure else ('all_checked_rows_implied' if not unknown else 'unresolved_rows')}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',default=str(HERE/'large_overlap_batch_results.json'))
    ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=10)
    ap.add_argument('--output',default='critical_overlap_covariance_results.json')
    ar=ap.parse_args();data=json.loads(Path(ar.input).read_text());cases=data['results']
    results=[];tic=time.time()
    for ci in range(ar.start,min(len(cases),ar.stop)):
        case=cases[ci]
        print('START',ci,'rank',len(case['g']),'dim',case.get('space',{}).get('dimension'),flush=True)
        try:r=run_case(case)
        except (OverflowError,ArithmeticError,ValueError) as e:r={'B':case['B'],'g':case['g'],'status':'resource_or_exact_check_unresolved','reason':str(e)}
        r['source_index']=ci;results.append(r);atomic_json(HERE/ar.output,{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'checked',r.get('checked_new_rows'),'seconds',r.get('seconds'),flush=True)
        if r.get('failure'):print('FAILURE',r['failure']['word'],r['failure']['key'],r['failure']['value'],flush=True)

if __name__=='__main__':main()
