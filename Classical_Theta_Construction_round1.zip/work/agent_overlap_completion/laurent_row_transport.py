#!/usr/bin/env python3
"""Exact principal reset transport allowing Laurent coefficient shifts.

Unlike pointed single-theta carriers, a positive sum z^q F_h can acquire
negative z-exponents after mutation. The full Laurent shift must be retained.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_packet_propagation'))
from linear_carrier import *

def mutate_laurent_rows(B,g,F,k,cap=24000):
    n=len(g);m=len(next(iter(F.values())));zero=(0,)*m
    fibres=defaultdict(dict)
    for p,row in F.items():fibres[p[:k]+p[k+1:]][p[k]]=row
    out={}
    for off,f in fibres.items():
        p=off[:k]+(0,)+off[k:]
        r=g[k]+sum(B[k][j]*p[j] for j in range(n));d=max(-r,0)
        alpha=max(-g[k],0)+sum(max(-B[k][j],0)*p[j] for j in range(n))
        lo,hi=min(f),max(f);N=hi-lo
        if N>cap or max(r,0)>cap:return None,{'resource':'fibre_length','N':N,'r':r}
        q=[]
        for s in range(N+1):
            a=f.get(lo+s,zero)
            for j in range(1,min(d,s)+1):a=add(a,q[s-j],-math.comb(d,j))
            q.append(a)
        if any(any(q[s]) for s in range(max(0,N-d+1),N+1)):
            raise ArithmeticError(('Laurent fibre not divisible',k,off,r))
        for s,row in enumerate(q):
            if not any(row):continue
            for j in range(max(r,0)+1):
                e=alpha-d-lo-s+j
                target=off[:k]+(e,)+off[k:]
                out[target]=add(out.get(target,zero),row,math.comb(max(r,0),j))
                if len(out)>cap:return None,{'resource':'terms','count':len(out)}
    out={p:row for p,row in out.items() if any(row)}
    return (mutate_matrix(B,k),mutate_g(B,g,k),out),None

def verify():
    import json
    cases=json.loads((ROOT/'agent_packet_propagation'/'carrier_space_census.json').read_text())
    checked=0
    for case in cases[:30]:
        B,g=case['B'],case['g'];F,meta=divisibility_space(B,g,case['points'])
        for k in range(len(g)):
            old,err=mutate_rows(B,g,F,k)
            new,err2=mutate_laurent_rows(B,g,F,k)
            assert err==err2 and old==new
            rev,err=mutate_laurent_rows(*new,k)
            assert not err and rev[0]==B and tuple(rev[1])==tuple(g) and rev[2]==F
            # An arbitrary Laurent monomial shift changes the label by -Bq.
            shift=tuple(-2 if j%2 else 1 for j in range(len(g)))
            gg=tuple(g[j]-sum(B[j][l]*shift[l] for l in range(len(g))) for j in range(len(g)))
            FF={tuple(p[j]+shift[j] for j in range(len(g))):row for p,row in F.items()}
            nxt,err=mutate_laurent_rows(B,gg,FF,k)
            rev,err2=mutate_laurent_rows(*nxt,k)
            assert not err and not err2 and rev[0]==B and tuple(rev[1])==gg and rev[2]==FF
            checked+=1
    print('exact forward agreement and Laurent shifted involutions',checked)

if __name__=='__main__':verify()
