#!/usr/bin/env python3
"""Exact orientation-dependent failure on the correct minimal Newton carrier.

The original seed has an independently certified least point F. After a
single sink mutation, the integer polynomial H=F+D47 satisfies every finite
independent-chart condition, yet lowers three ordinary coefficients. All
arithmetic below used for assertions is over Q. LPs only propose additional
optima; unresolved proposals never affect the counterexample.
"""
from critical_overlap_covariance import *
from scipy.spatial import ConvexHull
from itertools import combinations,product
from collections import defaultdict
from schofield_carrier import acyclic_dimension

def parameters(P,M,refs):
    return [P.get(M['columns'][i][1],Fraction(0))/d for i,d in refs]

def evaluate(row,x):return sum(a*b for a,b in zip(row,x))

def divide_color(B,g,P,k):
    fibres=defaultdict(dict);n=len(g)
    for p,a in P.items():fibres[p[:k]+p[k+1:]][p[k]]=a
    out={};proof=[]
    for off,f in fibres.items():
        base=off[:k]+(0,)+off[k:]
        d=max(-g[k]-sum(B[k][j]*base[j] for j in range(n)),0)
        lo,hi=min(f),max(f);q=[]
        for s in range(hi-lo+1):
            a=f.get(lo+s,Fraction(0))
            for j in range(1,min(d,s)+1):a-=math.comb(d,j)*q[s-j]
            q.append(a)
        assert all(a==0 for a in q[max(0,len(q)-d):]) if d else True
        for s,a in enumerate(q):
            if a:out[off[:k]+(lo+s,)+off[k:]]=a
        proof.append({'outside':off,'divisor_power':d,'quotient_coefficients':[str(a) for a in q]})
    return out,proof

def direct_packets(B,g,P):
    records=[];n=len(g)
    for mask in range(1,1<<n):
        I=tuple(i for i in range(n) if mask>>i&1)
        if not all(B[i][j]==0 for i in I for j in I):continue
        Q=P;steps=[]
        for i in I:
            Q,proof=divide_color(B,g,Q,i);steps.append({'color':i,'fibres':proof})
        assert all(a>=0 for a in Q.values())
        records.append({'independent_set':I,'quotient_nonnegative':True,'steps':steps})
    return records

def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b):return sum(x*y for x,y in zip(a,b))

def exact_hull(F,H,d):
    pts=list(F);hull=ConvexHull(np.array(pts,dtype=float));facets=set()
    for simplex in hull.simplices:
        p,q,r=[pts[j] for j in simplex];v=cross(tuple(q[j]-p[j] for j in range(3)),tuple(r[j]-p[j] for j in range(3)))
        gd=math.gcd(*v);assert gd
        v=tuple(a//gd for a in v);bound=dot(v,p);vals=[dot(v,p)-bound for p in pts]
        assert min(vals)>=0 or max(vals)<=0
        if max(vals)>0:v=tuple(-a for a in v);bound=-bound
        facets.add((v,bound))
    # Box bounds give an elementary boundedness certificate for the facet
    # intersection. Enumerating its exact vertices certifies hull completeness.
    for i in range(3):
        v=tuple(int(i==j) for j in range(3));facets.add((v,d[i]));facets.add((tuple(-a for a in v),0))
    facets=sorted(facets);V=set()
    for (a,aa),(b,bb),(c,cc) in combinations(facets,3):
        bc,ca,ab=cross(b,c),cross(c,a),cross(a,b);det=dot(a,bc)
        if not det:continue
        nums=tuple(aa*bc[j]+bb*ca[j]+cc*ab[j] for j in range(3))
        p=tuple(Fraction(v,det) for v in nums)
        if all(dot(v,p)<=bound for v,bound in facets):V.add(p)
    assert V and all(all(a.denominator==1 for a in p) and tuple(map(int,p)) in F for p in V)
    V=sorted(tuple(map(int,p)) for p in V)
    assert all(F[p]==H.get(p)==1 for p in V)
    assert all(all(dot(v,p)<=bound for v,bound in facets) for p in H)
    P=[p for p in product(*(range(x+1) for x in d)) if all(dot(v,p)<=bound for v,bound in facets)]
    return {'d':d,'vertices':V,'lattice_points':P,'facets':[{'normal':v,'bound':b} for v,b in facets],
            'exact_intersection_vertices_certified':True,'both_vertex_coefficients_one':True,
            'same_hull_certified':True,'theta_carrier_reason':'positive birational tropical pullback of the already certified original theta Newton polytope'}

def propose_optimum(cost,RR,origin):
    scales=np.array([max(1,max(abs(a) for a in row)) for row in RR],float)
    A=-np.array(RR,dtype=float)/scales[:,None];cn=max(1,max(abs(a) for a in cost))
    lp=linprog(np.array(cost,dtype=float)/cn,A_ub=A,b_ub=np.zeros(len(RR)),A_eq=[origin],b_eq=[1],
               bounds=(None,None),method='highs',options={'time_limit':40})
    x=exact_point(lp.x,RR,origin)
    if x is None:return {'status':'unresolved_exact_primal','lp_status':int(lp.status)}
    value=evaluate(cost,x);target=tuple(a-value*b for a,b in zip(cost,origin))
    cp=exact_conic_scaled(target,RR)
    return {'status':'exact_optimum' if cp is not None else 'exact_feasible_primal_only','value':str(value),
            'parameters':[str(a) for a in x],'dual':None if cp is None else [[i,str(a)] for i,a in cp]}

def main():
    tic=time.time();folder=WORK/'agent_packet_propagation'
    case=json.loads((folder/'large_origin_exact_failure_2.json').read_text())
    cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    rays=json.loads((folder/'pair_tangent_circuits_results.json').read_text())['rays']
    M,R,S,T=prepare(case);B,g=case['B'],case['g'];refs=coefficient_references(M,R)
    F={tuple(z['p']):Fraction(z['a']) for z in cand['F']}
    D={tuple(z['p']):Fraction(z['a']) for z in rays[47]['coefficient_polynomial']}
    H={p:F.get(p,Fraction(0))+D.get(p,Fraction(0)) for p in set(F)|set(D)};H={p:a for p,a in H.items() if a}
    assert all(a>=0 for a in H.values()) and all(H[tuple(v)]==F[tuple(v)]==1 for v in case['carrier']['vertices'])
    xf,xd,xh=(parameters(P,M,refs) for P in (F,D,H))
    target,err=mutate_rows(B,g,T,2,cap=100000);assert not err
    BB,gg,TT=target
    FF={p:evaluate(row,xf) for p,row in TT.items()};FF={p:a for p,a in FF.items() if a}
    HH={p:evaluate(row,xh) for p,row in TT.items()};HH={p:a for p,a in HH.items() if a}
    DD={p:evaluate(row,xd) for p,row in TT.items()};DD={p:a for p,a in DD.items() if a}
    assert all(a>=0 and a.denominator==1 for a in FF.values())
    assert all(a>=0 and a.denominator==1 for a in HH.values())
    d,_,_=acyclic_dimension(BB,gg);C=exact_hull(FF,HH,d)
    packets=direct_packets(BB,gg,HH)
    RR=[];keys=[];seen=set();charts=[]
    for mask in range(1<<len(g)):
        I=tuple(i for i in range(len(g)) if mask>>i&1)
        if not all(BB[i][j]==0 for i in I for j in I):continue
        state=target
        for i in I:
            state,err=mutate_rows(*state,i,cap=100000);assert not err
        rows,info=section_rows(*state,step_cap=100000);count=0;minH=None
        for key,row in rows:
            row=primitive(row)
            if row in seen:continue
            seen.add(row);RR.append(row);keys.append((I,key));count+=1
            a=evaluate(row,xh);assert a>=0
            minH=a if minH is None else min(a,minH)
        charts.append({'independent_set':I,'new_rows':count,'minimum_H_coordinate':str(minH),'all_nonnegative':True})
    oldbad=[{'column':i,'key':M['columns'][i],'value':str(evaluate(row,xh))} for i,row in enumerate(R) if evaluate(row,xh)<0]
    assert oldbad
    decreases=[{'p':p,'F':str(FF.get(p,Fraction(0))),'D':str(a),'H':str(HH.get(p,Fraction(0)))} for p,a in DD.items() if a<0]
    record={'old_B':B,'old_g':g,'new_B':BB,'new_g':gg,'mutation':2,'new_d':d,
            'carrier':C,'H_star_and_cube_certificates':packets,'independent_chart_checks':charts,
            'distinct_new_cone_rows':len(RR),'all_new_rows_nonnegative_exact':True,
            'old_violations':oldbad,'decreased_coefficients':decreases,'F_mass':str(sum(FF.values())),
            'H_mass':str(sum(HH.values())),'F':dump_poly(FF),'H':dump_poly(HH),'D47':dump_poly(DD),
            'all_coefficients_integral':True,'seconds':time.time()-tic}
    atomic_json(HERE/'independent_closure_counterexample.json',record)
    print('COUNTEREXAMPLE VERIFIED','carrier',len(C['lattice_points']),'vertices',len(C['vertices']),'rows',len(RR),'decreases',decreases,flush=True)
    origin=T[(0,)*len(g)];mass=tuple(sum(row[j] for row in TT.values()) for j in range(len(R[0])))
    record['one_mass_optimization']=propose_optimum(mass,RR,origin)
    record['one_coordinate_optimization']=propose_optimum(TT[(6,5,25)],RR,origin)
    record['seconds']=time.time()-tic
    atomic_json(HERE/'independent_closure_counterexample.json',record)
    print('MASS',record['one_mass_optimization']['status'],record['one_mass_optimization'].get('value'),flush=True)
    print('COEFFICIENT',record['one_coordinate_optimization']['status'],record['one_coordinate_optimization'].get('value'),flush=True)

if __name__=='__main__':main()
