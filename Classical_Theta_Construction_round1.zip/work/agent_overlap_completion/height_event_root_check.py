#!/usr/bin/env python3
"""Exact extended matrix mutations versus the event-root theorem.

This is an independent algebraic implementation on connected non-finite
valued matrices. It checks signs and the negative-tail index shifts.
"""
from pathlib import Path
import random,json,math,time
import sympy as sp

HERE=Path(__file__).resolve().parent

def mutate(E,k):
    m=len(E);n=len(E[0])
    return [[-E[i][j] if i==k or j==k else
             E[i][j]+max(E[i][k],0)*max(E[k][j],0)-max(-E[i][k],0)*max(-E[k][j],0)
             for j in range(n)] for i in range(m)]

def test(B,D,steps=200,cycles=12,rng=None):
    n=len(B);rng=rng or random.Random(73)
    A=sp.Matrix([[2 if i==j else -abs(B[i][j]) for j in range(n)] for i in range(n)])
    S=[]
    for i in range(n):
        s=sp.eye(n)
        for j in range(n):s[i,j]-=A[i,j]
        S.append(s)
    C=sp.eye(n)
    for s in S:C=C*s
    bp=[];bm=[]
    for i in range(n):
        w=sp.eye(n)
        for j in range(i):w=w*S[j]
        bp.append(w[:,i]);w=sp.eye(n)
        for j in range(n-1,i,-1):w=w*S[j]
        bm.append(w[:,i])
        assert C.inv()*bp[i]==-bm[i]
    powers={0:sp.eye(n)}
    def power(k):
        if k not in powers:powers[k]=C**k
        return powers[k]
    E=[r[:] for r in B]+[[int(i==j) for j in range(n)] for i in range(n)]
    h=[0]*n;count=0;minh=0;maxh=0
    def one(i,sign):
        nonlocal E,count,minh,maxh
        assert all(sign*E[i][j]>=0 for j in range(n))
        k=h[i];actual=sp.Matrix([E[n+j][i] for j in range(n)])
        if sign==1:
            expected=power(k)*bp[i] if k>=0 else (-sp.eye(n)[:,i] if k==-1 else power(k+2)*bm[i])
        else:
            expected=-power(k-1)*bp[i] if k>=1 else (sp.eye(n)[:,i] if k==0 else -power(k+1)*bm[i])
        if actual!=expected:raise ArithmeticError({'B':B,'D':D,'h':h,'i':i,'sign':sign,'actual':list(actual),'expected':list(expected)})
        E=mutate(E,i);h[i]+=sign;count+=1;minh=min(minh,min(h));maxh=max(maxh,max(h))
        for u in range(n):
            for v in range(u+1,n):
                if B[u][v]:assert h[v]<=h[u]<=h[v]+1
    for rep in range(cycles):
        for i in range(n):one(i,1)
    for rep in range(2*cycles):
        for i in reversed(range(n)):one(i,-1)
    for rep in range(cycles):
        for i in range(n):one(i,1)
    for rep in range(steps):
        moves=[(i,s) for i in range(n) for s in (-1,1) if all(s*E[i][j]>=0 for j in range(n))]
        one(*rng.choice(moves))
    return {'rank':n,'B':B,'D':D,'checked_mutations':count,'minimum_height':minh,'maximum_height':maxh,'all_exact':True}

def main():
    rng=random.Random(737184561);results=[];tic=time.time()
    for n in range(2,7):
        for rep in range(12):
            D=[rng.choice([1,2,3]) for _ in range(n)];B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    w=rng.choice([0,0,1,2])
                    if j==i+1:w=max(w,1)
                    if (i,j)==(0,1):w=2 # connected non-finite Cartan component
                    B[i][j]=w*D[j]//math.gcd(D[i],D[j]);B[j][i]=-w*D[i]//math.gcd(D[i],D[j])
            r=test(B,D,rng=rng);results.append(r)
            print('PASS',n,rep,r['checked_mutations'],flush=True)
    out={'results':results,'matrices':len(results),'checked_mutations':sum(r['checked_mutations'] for r in results),'seconds':time.time()-tic}
    (HERE/'height_event_root_results.json').write_text(json.dumps(out,separators=(',',':')))
    print('TOTAL',out['matrices'],out['checked_mutations'],out['seconds'])

if __name__=='__main__':main()
