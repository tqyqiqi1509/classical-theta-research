#!/usr/bin/env python3
"""Independent overlap constraints in arbitrary acyclic valued orientations.

Every carrier starts from the full acyclic standard-product box and is
certified by exact Newton pruning. No valued Schofield identification is used.
"""
from overlap_batch import *
import random
from theta_newton_pruning import prune

def inputs():
    rng=random.Random(713184561)
    for n,reps,choices in [(3,24,[3,4,5,6]),(4,18,[2,3,4]),(5,12,[1,2,3])]:
        for rep in range(reps):
            D=[rng.choice([1,2,3]) for _ in range(n)]
            if len(set(D))==1:D[-1]=2 if D[0]!=2 else 1
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    w=rng.choice([0,0,1,2,3])
                    # Three families: chain-connected, fork/bipartite, dense.
                    if rep%3==0 and j==i+1:w=max(w,1)
                    if rep%3==1:
                        w=rng.choice([1,2,3]) if (i<n//2<=j) else 0
                    if rep%3==2:w=rng.choice([1,2,3])
                    b=w*D[j]//math.gcd(D[i],D[j]);c=w*D[i]//math.gcd(D[i],D[j])
                    B[i][j]=b;B[j][i]=-c
            d=[rng.choice(choices) for _ in range(n)]
            g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n)]
            assert all(D[i]*B[i][j]==-D[j]*B[j][i] for i in range(n) for j in range(n))
            yield {'B':B,'D':D,'g':g,'d':d}

def main():
    folder=HERE/'valued_carriers';folder.mkdir(exist_ok=True)
    results=[];tic=time.time()
    for ci,c in enumerate(inputs()):
        print('START',ci,'rank',len(c['g']),'D',c['D'],'d',c['d'],flush=True)
        tt=time.time()
        try:
            path=folder/f'carrier_{ci:03d}.json'
            if path.exists():C=json.loads(path.read_text())
            else:
                C=prune(c['B'],c['g'],cap=1800)
                atomic_json(path,C)
            case={**c,'carrier':C}
            r=run_case(case,chart_cap=12000)
            r.update({'carrier_seconds':C['seconds'],'carrier_file':str(path.relative_to(WORK)),
                      'total_case_seconds':time.time()-tt})
        except (OverflowError,ArithmeticError,ValueError) as e:
            r={**c,'status':'resource_or_exact_check_unresolved','reason':str(e),'seconds':time.time()-tt}
        r['source_index']=ci;results.append(r)
        atomic_json(HERE/'valued_overlap_results.json',{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'mass',r.get('mass'),'integer',r.get('integral'),'secs',time.time()-tt,flush=True)
        if r.get('failure'):print('EXACT_COUNTEREXAMPLE',r['failure']['p'],r['failure']['selected'],r['failure']['smaller'],flush=True)

if __name__=='__main__':main()
