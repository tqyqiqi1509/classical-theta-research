#!/usr/bin/env python3
"""Can an adjacent finite chart cone forget the old critical overlap?"""
from hard_covariance_tangent import *

def main():
    folder=WORK/'agent_packet_propagation';case=json.loads((folder/'large_origin_exact_failure_2.json').read_text())
    cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    oldrays=json.loads((folder/'pair_tangent_circuits_results.json').read_text())['rays']
    M,R,S,T=prepare(case);B,g=case['B'],case['g'];refs=coefficient_references(M,R)
    F={tuple(z['p']):Fraction(z['a']) for z in cand['F']}
    D={tuple(z['p']):Fraction(z['a']) for z in oldrays[47]['coefficient_polynomial']}
    pars=[[P.get(M['columns'][i][1],Fraction(0))/d for i,d in refs] for P in (F,D)]
    pars=[[(i,int(a) if a.denominator==1 else a) for i,a in enumerate(z) if a] for z in pars]
    results=[]
    for base in range(len(g)):
        initial,err=mutate_rows(B,g,T,base,cap=100000);assert not err
        seen=set();rows=[]
        for mask in range(1<<len(g)):
            I=tuple(i for i in range(len(g)) if mask>>i&1)
            if not all(initial[0][i][j]==0 for i in I for j in I):continue
            state=initial
            for i in I:
                state,err=mutate_rows(*state,i,cap=100000);assert not err
            sec,info=section_rows(*state,step_cap=100000)
            for key,row in sec:
                row=primitive(row)
                if row in seen:continue
                seen.add(row);rows.append(((I,key),row))
        activecuts=[];ratio=[];badF=[]
        for key,row in rows:
            f,d=(sum(row[i]*a for i,a in par) for par in pars)
            if f<0:badF.append({'key':key,'value':str(f)})
            if f==0 and d<0:activecuts.append({'key':key,'D47_value':str(d)})
            if f>0 and d<0:ratio.append(Fraction(f,-d))
        eps=min([Fraction(1)]+ratio)/2
        oldbad=[j for j,row in enumerate(R) if sum(row[i]*(a+eps*b) for i,(a,b) in enumerate(zip(
            [sum(v for k,v in pars[0] if k==j) for j in range(len(R[0]))],
            [sum(v for k,v in pars[1] if k==j) for j in range(len(R[0]))])) )<0] if not activecuts else []
        out={'base_mutation':base,'new_rows':len(rows),'F_feasible':not badF,'D47_active_cuts':activecuts,
             'feasible_epsilon_if_no_active_cut':str(eps),'old_inequalities_violated':oldbad,
             'strict_old_cone_containment_witness':not activecuts and not badF and bool(oldbad)}
        results.append(out);atomic_json(HERE/'hard_inverse_covariance_results.json',{'results':results})
        print('BASE',base,'rows',len(rows),'D47 cuts',len(activecuts),'strict counter',out['strict_old_cone_containment_witness'],flush=True)

if __name__=='__main__':main()
