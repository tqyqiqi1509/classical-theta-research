# Handoff: finite overlaps, exact failure, and new rank-two upper caps

**2026-11-13 08:06 UTC.** Parent `/root` requested this agent stop and be
replaced with a fresh context. User six-hour endpoint remains 10:12:08 UTC.
All work here is classical, first skew-symmetric and then nonconstant D.
Root packages/persists these artifacts. This is not the final user report.

## Highest priority: a genuinely new general finite constraint

Read `PAIR_UPPER_CAPS.md` and `pair_upper_caps.py` first.

For acyclic B, standard box d, A_ij=[-B_ij]_+, any pair I with complement J
gives the rigorous theta coefficient cap

    a_p <= product_(j in J) binom(d_j,p_j) * LLZ_(B_II,h_I)(p_I),
    h_I = g_I-A_IJ d_J.

Proof: multiply the true rank-two frozen theta by the ordinary positive
product of (x_j')^(d_j). Its leading coefficient is one at label g, so theta_g
occurs once and all other theta summands are nonnegative. This is independent
of every unverified high-rank lower candidate table and of Li--Pan.

### Hard input: exact success of star plus upper caps

    B=[[0,0,3],[0,0,2],[-3,-2,0]], g=(-8,-7,29), d=(8,7,9).

`pair_upper_caps_hard_results.json` certifies:

* **Initial star + true LLZ pair upper caps** has coefficientwise least point
  F59085. Exact mass optimum and every positive coefficient lower bound have
  rational conic certificates. No pair lower slices or independent-chart
  completion are needed for this result.
* Adding initial pair lower slices preserves that exact least point.
* The old fractional star optimum59030 is excluded by four zero caps at
  (3,3,2),(3,4,2),(3,5,2),(3,6,2), where it had
  15/4,45/4,45/4,15/4 respectively.
* The cap at (1,1,1) for pair I={0,2} is zero, whereas F+D47 has coefficient
  one. Its lower genuine rank-two label is (-8,15), b=c=3.

**API:**

    pair_upper_caps(B,g,d,points) -> (caps_by_point, family_records)

The cap rows on an existing Laurent-space coefficient matrix are
`caps[p]*origin_row - coefficient_row[p] >= 0`. `run_case(B,g,C,F,pairwise)`
tests a provided candidate F and returns exact mass/least certificates.
For constructing a new candidate, use its mass optimum parameters and
evaluate the original coefficient rows. Do not assume the old independent
closure candidate remains feasible under the new necessary caps.

### Stronger creation/Pieri direction, highest theoretical priority

For active i, a_i=-e_i+A e_i and d(g-a_i)=d-e_i. The positive product

    (1+z_i) F_(g-a_i)

contains F_g plus nonnegative shifted theta terms with strictly smaller
boxes. Full decomposition of that difference is stronger than coefficient
upper caps. Parent is developing this with fresh agents.

Exact pair upper caps kill 41 of the 56 initial-pair tangent rays, including
the sole coefficient-negative ray47. Fifteen nonnegative rays remain, so
leastness is not yet theta identification. Using all 24 powers of creation
with the existing **unidentified higher-rank candidate cache** kills54 rays,
leaving1 and41; this calculation is explicitly conditional:
`creation_all_power_caps_conditional.json`. The three one-step cache checks
are in `creation_upper_quick_check.json`.

## Decisive correction: finite independent closure is not seed invariant

Read `INDEPENDENT_CLOSURE_COUNTEREXAMPLE.md` and
`independent_closure_counterexample.json`.

After the single sink mutation2, the hard input becomes

    B'=[[0,0,-3],[0,0,-2],[3,2,0]],
    g'=(79,51,-29), d'=(8,7,29).

The integer H=F+D47 transports to a feasible point H' of this seed's finite
independent-chart cone. It lowers three coefficients of F':

    p=(6,5,25):104 ->103,
    p=(6,5,26):924 ->923,
    p=(6,6,27):195 ->194.

This is on the **correct** theta Newton carrier, 972 points and8 vertices.
Exact facet intersections, all one-color and common-binomial quotients, and
all4,955 distinct pair rows were verified. The exact minimum of coefficient
(6,5,25) is21, with a rational dual certificate.

F' is the unique mass minimum, mass6,586,129,065. The numerical LP dual alone
was unresolved, but an independent exact proof evaluates target mass on the
complete old56-ray tangent cone: every value is strictly positive, minimum1.
The new cone includes the old initial-pair constraints via its return
mutation2; these imply old star/cube constraints. See
`mutated_mass_tangent_certificate.json`. Thus this new cone has **no**
coefficientwise least point. The mass selector itself still chooses F' here;
do not claim that the mass selector was disproved.

The earlier forward implication remains true:5,097 new rows in all one-step
neighbor independent charts are nonnegative on F and the complete56-ray
**enhanced** tangent cone. The inverse inclusion fails. Files:
`hard_covariance_tangent_results.json`,
`hard_inverse_covariance_results.json`.

## Broad numerical batches and exact status

### Old independent-chart closure batch

* `large_overlap_batch_results.json`:43 larger rank3--5 skew-symmetric
  inputs.41 direct exact least/integrality certificates; source indices1
  and19 recovered from exact old star least plus feasibility in all new
  rows, recorded in `large_overlap_recovered_cases.json`. Report43/43 with
  that recovery qualification.
* `valued_overlap_results.json`: **still running**, see sessions below.
  Latest completed index44 means45 inputs completed. Index21's mass dual
  failure is rigorously recovered in `valued_case21_recovery.json`.
  Index43 is a resource cap at independent chart(0,1),12,001 transport
  terms; not a counterexample. Other completed inputs have exact integral
  a-least certificates. Every carrier starts from a full acyclic box and
  exact Newton pruning, including nonconstant symmetrizers.

### Whole-cone one-direction implication screens

`critical_overlap_small_results.json`:16 rank3--5 inputs of dimensions3--7;
all1,163 additional rows have exact positive-combination certificates.

`critical_overlap_medium_results.json`:12 inputs, dimensions8--14, mostly
nonconstant D. Fully certified case indices0,2,4,5,6,8,11. Index3 has one
numerical unresolved row, recovered exactly with3 terms in
`critical_overlap_medium_recovery.json`. Index9 has3 unresolved numerical
rows; index10 has16. Indices1,7 hit transport resource caps. No exact
counterexample in this forward-only screen. The reverse hard example above
already rules out general seed-invariance, so do not keep increasing these
counts as the main research direction.

### Orientation and Cartan*d

`cartan_box_batch_summary.py` regenerates
`cartan_box_batch_summary.json` from the current batch files. It records each
d, Cartan*d, topological order, source/sink mutations, new d, and box-size
changes. At the earlier snapshot:

*43 large cases:38 fundamental (Cartan*d<=0),40 locally minimal total box,
  3 have a strict source/sink box descent despite being least.
*44 valued inputs:36 fundamental and36 locally minimal;8 have a descent.

Thus descent is not equivalent to failure. The hard original d has
Cartan*d=(-11,-4,-20); its mutated d' has a descent back. Parent's proposed
orientation-normalization route remains a hypothesis, not a theorem.

## Source/sink height mechanism: formal theorem completed

Read `HEIGHT_EVENT_ROOT_FORMULA.md` and
`SOURCE_SINK_HEIGHT_LATTICE.md`.

For connected non-finite acyclic valued B, C=S1...Sn,
beta_i+=S1...S_(i-1)e_i, beta_i-=Sn...S_(i+1)e_i. At a source of height k,
the signed pivot c-vector is

    C^k beta_i+          k>=0,
    -e_i                k=-1,
    C^(k+2) beta_i-      k<=-2.

The sink formulas are inverse-edge negatives. The proof uses the event
poset and invariance of pivot c-vectors under commuting mutations, then the
audited Rupel--Stella--Williams1606.03440v2 Lemma3.1. It applies to the whole
source/sink height graph, not the full mutation graph.60 valued matrices
rank2--6 and23,520 mutations independently checked all signs and shifts:
`height_event_root_results.json`.

Parent is replacing the Orbit-problem black box by a direct effective
integer-matrix orbit cutoff using Krylov coordinates, Kronecker's theorem,
and repeated cyclotomic roots. Do not duplicate that work.

## Surgery: sound formula, insufficient rigidity

`SOURCE_STAR_SURGERY.md` gives the general auxiliary-vertex surgery, its
finite-theta extension proof, and exact lower-rank slice formula. The
initial extension may be cyclic; the one-step acyclic target, full-rank BFZ
upper-bound invariance, VIT, and freezing are essential.

Tests, all accepting F and failing to remove old D47:

* Unit fullstar joint rank1×rank2:8,442 rows.
* All finite integral star factorizations:14,049 rows, exact re-run completed.
* Three partial-source families initial pair rows:8,397 rows.
* Those partial families plus lower independent charts:30,690 rows.
* Expanded rank4 pair slices containing the new vertex:11 families,
  5,214 rows.

Files `partial_star_pair_*`, `enlarged_surgery_pair_*`,
`hard_valued_source_surgery_results.json`. Do not repeat those weak tests.
Source-surgery agent owns general partial-star rank/box induction proofs.

For shifted positive theta sums, pointed `mutate_rows` is insufficient:
negative coefficient exponents after reset are legitimate. Use
`laurent_row_transport.py`, which retains Laurent shifts and passed66 exact
forward and double-mutation checks. Sparse dot-products use exact integer
or Fraction entries. A zero-default float issue in preliminary surgery
evaluation was corrected; fullstar factorizations and initial partial
families were re-run exactly with unchanged outcomes. Do not reintroduce
`P.get(...,0)/d` in a dense rational dot-product; use Fraction(0) and/or omit
zero entries.

## Still-running tool sessions -- parent/fresh agent may poll

1. **44180**: `valued_overlap_screen.py`,54 total inputs, latest index44
   completed, index45 likely active. Updates its result JSON atomically.
2. **48523**: old large forward-covariance screen, first input dimension73,
   command `critical_overlap_covariance.py --start0 --stop6`. It has produced
   no completed case yet and is not needed for the new direction. It was
   launched before progress printing was added. Do not wait on it to resume
   the research. If it eventually completes, record the result honestly.

All other sessions launched by this agent have completed. Do not call
functions.wait for these IDs; use tools.write_stdin.

## Literature and version cautions

`LITERATURE_AND_ROUTE_LOG.md` records the07:35 audit and the new source/sink
interface. Primary sources read directly:

* RSW1606.03440v2 Lemma3.1/Theorem3.3, full proof and all-valued scope.
* Chonev--Ouaknine--Worrell1303.2981v3, exact point-orbit interface and
  computable witness bounds; no Skolem decidability assumed.
* BFZ upper-bound mutation invariance, full-rank/coprime hypotheses. Its
  signed elimination proof is not a positivity proof.
* Coxeter finite-partition papers2107.09962v3,1510.01607v2,2303.16569v2.
  The latter's HTML header is June2024 but internal Date August2026;
  fixed version used, not treated as a2026 new theorem.

Current Tang2609.30387 full-page fetch was blocked; no quantum conclusion
was adopted. No Li--Pan conclusion was used.
