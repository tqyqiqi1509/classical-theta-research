#!/usr/bin/env python3
"""Lower-edge source/sink surgery followed by true rank-two LLZ slices."""
from source_surgery import *
from ranktwo_packets import section_rows
from linear_carrier import primitive
from laurent_row_transport import mutate_laurent_rows

def partial_rows(B,g,Frows,points,i,a,charts=False):
    n=len(g);sign=1 if all(B[i][j]>=0 for j in range(n)) else -1
    if not all(sign*B[i][j]>=0 for j in range(n)):raise ValueError('not source or sink')
    c=[]
    for j in range(n):
        if j==i or not B[i][j]:
            if a[j]:raise ValueError('removed nonexistent edge')
            c.append(0);continue
        cc=Fraction(a[j]*abs(B[j][i]),abs(B[i][j]))
        if cc.denominator!=1:raise ValueError('nonintegral valued substar')
        if not 0<=a[j]<=abs(B[i][j]):raise ValueError('invalid removed edge weight')
        c.append(int(cc))
    roww=tuple(sign if j==i else -sign*a[j] for j in range(n))
    colw=tuple(-sign if j==i else sign*c[j] for j in range(n))
    lam=max(0,max(-sum(roww[j]*p[j] for j in range(n)) for p in points))
    BB=[r[:] for r in B]
    for j in range(n):
        if j!=i:BB[i][j]-=sign*a[j];BB[j][i]+=sign*c[j]
    gp=tuple(g[j]+max(colw[j],0)*lam for j in range(n))
    slices=defaultdict(dict)
    for p,row in Frows.items():
        r=lam+sum(roww[j]*p[j] for j in range(n));alpha=sum(max(-roww[j],0)*p[j] for j in range(n))
        if r<0:raise ArithmeticError('lambda insufficient')
        for j in range(r+1):slices[alpha+j][p]=tuple(math.comb(r,j)*v for v in row)
    info={'vertex':i,'kind':'source' if sign==1 else 'sink','removed_weights':a,'opposite_weights':c,
          'lambda':lam,'target_B':BB,'slice_count':len(slices)}
    for t,T in sorted(slices.items()):
        h=tuple(gp[j]-colw[j]*t for j in range(n))
        rows,ri=section_rows(BB,h,T)
        if charts:
            seen={primitive(row) for key,row in rows};chart_data=[]
            for mask in range(1,1<<n):
                I=tuple(j for j in range(n) if mask>>j&1)
                if not all(BB[j][k]==0 for j in I for k in I):continue
                state=(BB,h,T)
                for k in I:
                    state,err=mutate_laurent_rows(*state,k,cap=24000)
                    if err:raise OverflowError(('partial-surgery chart transport',i,a,t,I,err))
                B2,h2,T2=state;new,ci=section_rows(B2,h2,T2);kept=0
                for key,row in new:
                    pr=primitive(row)
                    if pr in seen:continue
                    seen.add(pr);rows.append((('chart',I,key),row));kept+=1
                chart_data.append({'I':I,'transport_points':len(T2),'new_rows':kept})
            ri['charts']=chart_data
        yield info,t,h,rows,ri

def main(all_substars=False,charts=False):
    folder=WORK/'agent_packet_propagation';raw=json.loads((folder/'large_origin_exact_failure_2.json').read_text())
    B,g,C=raw['B'],raw['g'],raw['carrier'];M,R,S=build_logic(B,g,C)[:3]
    Frows={p:R[j] for p,j in M['ids'].items() if any(R[j])};refs=coefficient_references(M,R)
    cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    F={tuple(a['p']):Fraction(a['a']) for a in cand['F']}
    rays=json.loads((folder/'pair_tangent_circuits_results.json').read_text())['rays']
    polys=[F]+[{tuple(a['p']):Fraction(a['a']) for a in r['coefficient_polynomial']} for r in rays]
    pars=[[P.get(M['columns'][j][1],Fraction(0))/d for j,d in refs] for P in polys]
    pars=[[(j,int(a) if a.denominator==1 else a) for j,a in enumerate(pp) if a] for pp in pars]
    families=[(0,[0,0,1]),(0,[0,0,2]),(1,[0,0,1])]
    if all_substars:
        families=[]
        for i in range(len(g)):
            if not (all(B[i][j]>=0 for j in range(len(g))) or all(B[i][j]<=0 for j in range(len(g)))):continue
            for a in product(*(range(abs(B[i][j])+1) for j in range(len(g)))):
                if not any(a) or all(a[j]==abs(B[i][j]) for j in range(len(g))):continue
                families.append((i,list(a)))
    out=[];tic=time.time()
    for i,a in families:
        print('START',i,a,flush=True);badF=[];cuts=[];count=0;slices=[]
        for info,t,h,rows,ri in partial_rows(B,g,Frows,C['lattice_points'],i,a,charts=charts):
            slices.append({'t':t,'h':h,**ri})
            for key,row in rows:
                count+=1;values=[sum(row[j]*b for j,b in pp) for pp in pars]
                if values[0]<0:badF.append({'t':t,'h':h,'key':key,'value':str(values[0])})
                if values[0]==0 and any(v<0 for v in values[1:]):
                    cuts.append({'t':t,'h':h,'key':key,'row':row,'ray_values':[[j,str(v)] for j,v in enumerate(values[1:]) if v]})
        r={**info,'rows':count,'F_feasible':not badF,'negative_F_rows':badF,'active_cuts':cuts,'slices':slices}
        out.append(r);name='all_substar_pair_results.json' if all_substars else 'partial_star_pair_results.json'
        if charts:name=name.replace('_results.json','_chart_results.json')
        atomic_json(HERE/name,{'B':B,'g':g,'families':out,'seconds':time.time()-tic})
        print('END',i,a,'rows',count,'F feasible',not badF,'new active cuts',len(cuts),flush=True)
        for c in cuts[:5]:print('CUT',c['t'],c['key'],c['ray_values'],flush=True)

if __name__=='__main__':main('--all-substars' in sys.argv,'--charts' in sys.argv)
