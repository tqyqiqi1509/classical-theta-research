#!/usr/bin/env python3
"""Finite all-rank upper coefficients from true rank-two theta products.

For I of size two, remove the complementary standard-box directions using
the cluster variables x_j'. Strong positivity and the leading coefficient
one give the elementary cap

 a_p <= prod_{j outside I} binom(d_j,p_j) F_I(p_I),

where F_I is the genuine rank-two LLZ polynomial at the shifted label.
The code uses only integer binomials and the existing LLZ recurrence.
"""
from critical_overlap_covariance import *
from ranktwo_packets import greedy
from itertools import combinations
from independent_closure_counterexample import propose_optimum

def pair_upper_caps(B,g,d,points):
    n=len(g);caps={tuple(p):None for p in points};families=[]
    A=[[max(-B[i][j],0) for j in range(n)] for i in range(n)]
    for pair in combinations(range(n),2):
        I=pair if B[pair[0]][pair[1]]>=0 else tuple(reversed(pair));J=tuple(j for j in range(n) if j not in I)
        h=tuple(g[i]-sum(A[i][j]*d[j] for j in J) for i in I)
        G=greedy(B[I[0]][I[1]],-B[I[1]][I[0]],h)
        families.append({'I':I,'J':J,'rank_two_label':h,'rank_two_F':dump_poly(G)})
        for p in caps:
            bound=G.get(tuple(p[i] for i in I),0)
            for j in J:bound*=math.comb(d[j],p[j]) if 0<=p[j]<=d[j] else 0
            if caps[p] is None or bound<caps[p]:caps[p]=bound
    return caps,families

def run_case(B,g,C,F,pairwise=False):
    tic=time.time();M,R,S=build_logic(B,g,C)[:3]
    if pairwise:
        M,R,_=cube_augment(B,g,C,M,R);M,R,_=pair_augment(B,g,C,M,R)
    origin=R[M['ids'][(0,)*len(g)]]
    caps,families=pair_upper_caps(B,g,C['d'],M['ids'])
    caprows=[tuple(bound*a-b for a,b in zip(origin,R[M['ids'][p]])) for p,bound in caps.items()]
    RR=list(dict.fromkeys(primitive(row) for row in R+caprows if any(row)))
    cost=tuple(sum(R[j][k] for j in M['ids'].values()) for k in range(S['dimension']))
    opt=propose_optimum(cost,RR,origin)
    out={'pairwise':pairwise,'B':B,'g':g,'d':C['d'],'space':S,'constraint_rows':len(RR),
         'families':families,'coefficient_upper_bounds':[{'p':p,'upper':v} for p,v in caps.items()],
         'F_feasible':all(F.get(p,0)<=v for p,v in caps.items()),'mass_optimization':opt}
    print('CAP CONE','pairwise',pairwise,'mass',opt['status'],opt.get('value'),flush=True)
    proofs=[];unknown=[];failure=None
    for p,a in F.items():
        row=R[M['ids'][p]];target=tuple(v-a*w for v,w in zip(row,origin))
        cp=exact_conic_scaled(target,RR)
        if cp is not None:
            proofs.append({'p':p,'value':str(a),'certificate':[[i,str(v)] for i,v in cp]});continue
        low=propose_optimum(row,RR,origin)
        if low.get('parameters') and Fraction(low['value'])<a:
            failure={'p':p,'F_value':str(a),'lower_value':low['value'],'proposal':low};break
        unknown.append({'p':p,'optimization':low})
    out.update({'a_least_proved':not failure and not unknown,'coordinate_proofs':proofs,
                'coordinate_failure':failure,'unresolved':unknown,'seconds':time.time()-tic})
    return out

def main():
    folder=WORK/'agent_packet_propagation';case=json.load(open(folder/'large_origin_exact_failure_2.json'))
    F={tuple(z['p']):Fraction(z['a']) for z in json.load(open(folder/'pair_completion_fork_8_7_9.json'))['F']}
    bad={tuple(z['p']):Fraction(z['a']) for z in case['F']};C=case['carrier']
    caps,families=pair_upper_caps(case['B'],case['g'],C['d'],C['lattice_points'])
    failures=[{'p':p,'fractional_value':str(a),'upper':caps[p]} for p,a in bad.items() if a>caps[p]]
    print('FRACTIONAL EXCLUDED',len(failures),failures[:10],flush=True)
    out={'fractional_59030_upper_violations':failures,'results':[]}
    for pairwise in [False,True]:
        r=run_case(case['B'],case['g'],C,F,pairwise=pairwise);out['results'].append(r)
        atomic_json(HERE/'pair_upper_caps_hard_results.json',out)
        print('DONE','pairwise',pairwise,'least',r['a_least_proved'],'counter',r['coordinate_failure'],'unknown',len(r['unresolved']),flush=True)

if __name__=='__main__':main()
