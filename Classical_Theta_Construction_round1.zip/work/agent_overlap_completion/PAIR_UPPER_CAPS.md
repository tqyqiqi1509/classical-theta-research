# All-rank coefficient upper bounds from rank-two greedy tables

Classical acyclic skew-symmetrizable principal coefficients. 2026-11-13.

This is a general sound finite constraint, derived independently of Li--Pan.
Its construction uses only integer binomial coefficients, the exchange
matrix, and the genuine rank-two LLZ recurrence. The proof compares it with
the theta basis using the already audited strong positivity and freezing
inputs. It is not, by itself, a uniqueness theorem in arbitrary rank.

## Formula

Let A_ij=[-B_ij]_+, and write the standard acyclic box and decoration as

    g = v-d+A d,       d>=0, v>=0, d_i v_i=0.

For any subset I, put J=[n]\I. Let d^I agree with d on I and be zero on J.
For j in J the adjacent cluster variable is

    x_j' = x^(a_j) (1+z_j),       a_j=-e_j+A e_j.

Set

    h = g-sum_(j in J) d_j a_j = v-d^I+A d^I.

The acyclic triangular box recursion therefore gives exactly d(h)=d^I.
Freezing J identifies F_h with the rank-|I| theta polynomial for B_II at
label

    h_I = g_I-A_IJ d_J = v_I-d_I+A_II d_I.

The following coefficient upper bound holds for every p>=0:

    [z^p] F_g <=
       (prod_(j in J) binom(d_j,p_j))
       [z_I^(p_I)] F^(B_II)_(h_I).

For |I|=2 the right-hand side is an explicit Dyck/LLZ integer. Taking all
pairs gives finitely many inequalities, or equivalently their pointwise
minimum. These apply in every acyclic rank and with nonconstant
symmetrizers.

## Proof of the upper bound

Consider the positive theta product

    P_I = (prod_(j in J) (x_j')^(d_j)) theta_h.

Its leading label is g and its normalized polynomial is

    (prod_(j in J) (1+z_j)^(d_j)) F_h(z_I).

Strong theta multiplication writes this product as a nonnegative integer
sum of theta elements times frozen monomials. Homogeneity writes its
normalized expansion as

    sum_q m_q z^q F_(g+Bq),      m_q>=0.

All q are nonnegative: a negative coordinate of q would appear in the
leading monomial of a positive summand, whereas the product has no negative
z-exponents. The constant term of the product is one, so m_0=1. Thus the
sum contains theta_g exactly once, and subtracting it leaves a polynomial
with nonnegative coefficients. This gives the displayed bound.

No claim that the other summands vanish is made. The variables x_j' need
not belong to a single cluster; strong positivity applies successively to
their ordinary product.

## Relation to creation/Pieri recursion

For a single active i, use only one power x_i' and the lower label
g-a_i. Its box is d-e_i. The product

    (1+z_i) F_(g-a_i)

contains F_g plus positive shifted theta terms. Every nonleading term has
the form z^q F_(g+Bq), q>0. Since its support is inside the box d, its box
satisfies q+d(g+Bq)<=d and is strictly smaller in total size. This supplies
a well-founded *upper* Pieri family, distinct from the previously tested
lowering/derivative families. A general uniqueness theorem for the combined
families remains the next task.

## Exact hard-fork outcome

For B=[[0,0,3],[0,0,2],[-3,-2,0]], g=(-8,-7,29), d=(8,7,9), the three
rank-two product caps at p=(1,1,1) are respectively 32,0,504. In particular,
the rank-two factor for I={0,2} has b=c=3 and label (-8,15); its (1,1)
coefficient is zero. This strictly excludes F+D47, whose (1,1,1)
coefficient is one, without any unverified higher-rank lower table.

The fractional star optimum 59030 violates four zero caps:
(3,3,2),(3,4,2),(3,5,2),(3,6,2), with coefficients respectively
15/4,45/4,45/4,15/4. The original star cone plus these pair upper bounds has
the exact coefficientwise least point F59085. Its mass optimum and every
positive coefficient lower bound have exact rational conic certificates in
`pair_upper_caps_hard_results.json`. Adding initial rank-two lower slices
retains the same exact least point.

On the complete 56-ray tangent cone of the original initial-pair system,
tight pair-upper rows force 41 rays to vanish, including the unique ray with
negative ordinary coefficients. Fifteen nonnegative rays remain, so these
caps do not yet prove that the feasible point is unique or equal to theta.
Testing all 24 creation powers using the existing higher-rank candidate
cache kills 54 rays, leaving rays 1 and 41; that latter calculation is
explicitly conditional on the unproved cache comparison.
