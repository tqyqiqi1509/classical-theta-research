# Exact transition roots for the whole source/sink height graph

Classical acyclic skew-symmetrizable principal coefficients. 2026-11-13.

## Conventions and scope

Assume the underlying graph is connected and its Cartan companion is not of
finite type. Relabel vertices so that B_ij>=0 when i<j. A source has a
nonnegative row of B. A source mutation increases its height by one; a sink
mutation decreases its height by one. Initial height is zero. The feasible
height vectors satisfy

    h_v <= h_u <= h_v+1              for each initial edge u -> v.

Write A_ii=2 and A_ij=-|B_ij|. Let S_i be the matrix of the simple reflection
acting on root-coordinate columns: S_i(e_j)=e_j-A_ij e_i. Thus all rows of
S_i except row i are identity rows. Products act on the rightmost vector
first. Define

    C = S_1 S_2 ... S_n,
    beta_i^+ = S_1 ... S_(i-1) e_i,
    beta_i^- = S_n ... S_(i+1) e_i.

These conventions agree with a source word 1,2,...,n, repeated. In particular

    C^(-1) beta_i^+ = - beta_i^-.

The input matrices here are integer matrices. A nonconstant symmetrizer does
not change any of the formulas. Finite-type components are to be handled
separately by their finite seed dynamics; these infinite-tail formulas are
not asserted for them.

## The event-root theorem

For a feasible height h and a source i, let alpha(h,i) be the actual signed
i-th c-vector immediately before mutating i. It depends only on i and h_i:

    alpha(h,i) = C^(h_i) beta_i^+       if h_i >= 0,
                 -e_i                  if h_i = -1,
                 C^(h_i+2) beta_i^-    if h_i <= -2.

The first and third displayed vectors are positive roots. For a sink i,
immediately before decreasing h_i, the signed c-vector is

    alpha(h,i) = -C^(h_i-1) beta_i^+   if h_i >= 1,
                 e_i                  if h_i = 0,
                -C^(h_i+1) beta_i^-   if h_i <= -1.

Consequently all unsigned transition roots in the entire source/sink graph
belong to the finite families

    {e_i}, {C^k beta_i^+ : k>=0}, {C^(-k) beta_i^- : k>=0}.

The result concerns transition roots, not arbitrary columns at arbitrary
seeds. It does not identify the full mutation graph with this graph.

## Proof of independence from the other heights

Take a finite interval between two constant heights -M*1 and M*1 containing
the proposed edge. Every source-only path across the interval is a linear
extension of the same finite event poset. The event increasing color i from
r-1 to r is labelled (i,r). Initial edge u->v gives the order relations

    (u,r) < (v,r) < (u,r+1),

together with the order on repeated events of each color. These relations
are equivalent to the feasible-height inequalities.

Any two linear extensions differ by exchanges of consecutive incomparable
events. Such events have distinct nonadjacent colors: events of the same
color or adjacent colors are comparable. Their mutations commute. Moreover,
when B_ij=0, mutation j leaves c_i unchanged, directly from extended matrix
mutation. Thus exchanging the two events preserves the c-vector attached to
each event, not merely the final seed. Every event therefore has a
well-defined signed transition root independent of its linear extension.

In particular, its root can be evaluated in the repeated standard source
word. This proves the claimed dependence on i and h_i alone, including
intervals crossing height zero. Sink mutations are the inverse edges, and
their signed pivot c-vector is the negative of the corresponding source
pivot.

## Evaluation on the standard word and exact negative-tail shift

Rupel--Stella--Williams, arXiv:1606.03440v2, Lemma 3.1, proves the c-matrix
formula along the two-sided standard belt for this precise all-valued scope.
It follows by reflection mutation and the reducedness of every prefix of
the repeated Coxeter word. At constant height k>=0 the c-matrix is C^k;
before color i in its next cycle it is C^k S_1...S_(i-1). Its pivot is
C^k beta_i^+.

At constant height k<=-1 the c-matrix is -C^(k+1). At k=-1, moving through
the next source cycle flips the negative simple c-columns individually,
giving pivot -e_i. At k<=-2 the corresponding pivot is

    -C^(k+1) beta_i^+
      = C^(k+2) beta_i^-.

The identity C^(-1) beta_i^+=-beta_i^- establishes the second expression and
fixes the otherwise easy-to-miss shift by two. Inverting an edge with source
height h_i-1 gives exactly the sink formulas above.

## Distinctness and effective bounded-degree events

The vectors C^k beta_i^+ occur as the successive inversion roots of the
infinite reduced word C C C ... . Inversion roots of a reduced word are
pairwise distinct. The vectors C^(-k) beta_i^- have the same property for the
opposite word. Hence each of these one-sided root orbits is nonperiodic and
can hit a given vector at most once.

For a fixed degree cutoff N, enumerate the finite target set

    T_N = {p in Z^n : p>=0, 1<=sum p_i<=N}.

For each of the 2n root-orbit families and each p in T_N, exact matrix-orbit
decidability determines whether a hit exists. If the decision procedure only
returns yes/no, a yes answer can be followed by direct integer enumeration,
which must terminate and returns the unique exponent. No rate of root-height
growth and no empirical plateau stopping rule is required.

Let K be the largest returned exponent, with K=-1 when there are no hits.
The formulas above give an explicit finite set of permitted color heights
for all transition roots of degree at most N. Every such height belongs to
[-K-2,K+1], with the central simple-root events included separately. The
feasible-height inequalities imply that all other coordinates are within the
graph distance, at most n-1, of that height. Thus all degree-at-most-N
transitions lie in one explicit finite box of height states.

This establishes a finite reachability reduction for bounded-degree
source/sink transition data. A subsequent use for coefficient positivity or
theta characterization must separately prove that its chosen data depend
only on these bounded-degree transitions. Formal jet stabilization alone is
not asserted here to characterize unrestricted Laurent positivity.

## Primary sources audited

* Rupel--Stella--Williams, arXiv:1606.03440v2, Section 3.1, Lemma 3.1 and
  Theorem 3.3: https://arxiv.org/html/1606.03440v2 . Full proof of Lemma 3.1
  was read; its hypotheses include connected non-finite Cartan type.
* Exact point-to-point matrix-orbit decidability: Kannan--Lipton (1986),
  independently audited by root. The interface and computable-witness
  discussion are also stated in Chonev--Ouaknine--Worrell,
  arXiv:1303.2981v3: https://arxiv.org/pdf/1303.2981 . No general subspace
  or Skolem decidability is assumed.
