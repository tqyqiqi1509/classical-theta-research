# Handoff at 2026-11-13 08:03 UTC

## Main usable result

`UNIT_BOX_ORDER_IDEAL_THEOREM.md` proves, for every classical acyclic skew-symmetrizable principal-coefficient seed whose standard capacity vector has entries in {0,1}, that theta is the order-ideal polynomial of the active induced quiver. The proof identifies Laurent divisibility with a toggle graph and uses the root project's audited minimum Newton containment to remove the other components. It neither assumes a head classification nor uses a scattering construction. This is a general squarefree lifting interface, not the arbitrary-capacity solution.

The exact consistency script checked 17,894 instances and 143,085 states, including 6000 nontrivial skew-symmetrizable samples, with zero failures. Data and code are adjacent.

## Exact obstruction requiring a quotient

Every positive bipartite slot fold has a nonnegative Bernstein transform because its transformed coefficients count parent unions. For the (3,3) greedy element with g=(-8,15), d=(8,9), its v^3 fiber is 91u^6+160u^7+84u^8 and the transform is 91t^6-22t^7+15t^8. Thus a single such fold is impossible. Python and Wolfram independently verified the certificate. All regular-cover/minimum enumeration was stopped; sample minima are not global claims.

## Primitive routes resolved or still missing

`PRIMITIVE_QUOTIENT_ATTEMPTS.md` gives:

* Raw marked deletion has zero positive-capacity primitive character kernel, since d_i F=E_i F+z_i D_i F.
* A fully explicit finite integer cut-product complex preserves the edgeless rank-one case but kills every nonempty Euler product, because any cut product divides it. This is too strong to be a correction.
* The raw Euler-image/KLR candidate was already disproved in local history by the full m>=2 family H=Q[x,y]/(x^m,y^2), E=-m x^(m-1)y, rank 1 versus greedy coefficient 0. No repeat testing or old theta/head claim was inherited.
* Tight blocks and independent-center shuffle filtrations were investigated. No map from marked carriers to a relative filtered primitive quotient was found. Naming this missing map “BPS primitives” would conceal the gap.

## Interface with the new root upper-Pieri caps

The root's rank-deletion cap P_i=(1+z_i)^(d_i) F_(g-d_i a_i) is a genuinely new finite capacity constraint. If lower-rank objects are known, each P_i has a finite carrier C_i consisting of d_i Boolean slots times those objects. A common theta graph would need canonical maps/relations among all C_i, respecting marked deletion and overlaps. Coefficientwise upper bounds alone give no such maps. In unit capacity the common ambient Boolean cube and its toggle component solve this; arbitrary capacities remain open. This is the best interface for the refreshed slot to pursue.

## Literature and secondary lemma

`LITERATURE_AUDIT.md` records exact primary sources and audited scopes, especially the 2026 shuffle papers. Jindal–Neguţ's operative symmetric-quiver restriction must not be lost despite broad abstract wording. Qiyue §4 supplies a conditional primitive-filtration template, not an arbitrary-g theta graph theorem.

The root's elementary Krylov/Coxeter bounded-orbit lemma was independently checked: the rational left-inverse polynomial congruence, expanding-root logarithmic bound, repeated-cyclotomic derivative bound, and squarefree-cyclotomic period alternative are correct; beta=0 and negative powers must be separated. This was already messaged to root.

## State at handoff

No arbitrary-capacity primitive quotient or higher-rank greedy construction has been proved by this branch. All files are ready for the root's ongoing research archive. The slot should now be refreshed as requested; do not continue cover enumeration, raw Euler-image tests, or generic Hopf rephrasing.
