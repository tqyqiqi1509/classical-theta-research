# Marked primitives and explicit relative-quotient attempts

2026-11-13, 07:34–08:05 UTC research branch. Classical only. These are records of general mechanisms investigated, including failures. None is asserted to construct the arbitrary-rank theta basis.

## 1. The marked deletion coalgebra does not itself select a primitive character

For a capacity vector d and polynomial F, remove the harmless Laurent monomial shifts from the selected/unselected mark maps. Their polynomial parts are

    D_i F = partial_i F,
    E_i F = d_i F - z_i partial_i F.

They satisfy the exact identity

    d_i F = E_i F + z_i D_i F.

Consequently, if d_i>0, the map F -> (E_i F,D_i F) is injective over Q. The common kernel of all proper single-slot deletion maps is zero on every positive-capacity component. Iterating the maps into a Boolean coproduct therefore cannot create the desired nonzero primitive characters. A graph-level kernel could exist in the kernel of the character map, but that alone determines no coefficient.

This does not rule out a relative quotient or an associated-graded coproduct. It proves that such a quotient/filter is essential extra data, and cannot be suppressed by calling the already-constructed marked maps a primitive coproduct.

Independent Wolfram check: for all 1<=d<=120 and 0<=p<=d, it simplified (d-p)z^p+z p z^(p-1)-d z^p. Output {7380,0}: 7380 tested identities and zero nonzero remainders. The displayed symbolic identity is the proof.

## 2. Finite integer cut complex: fully specified but uniformly overkills

Work first in a finite labeled-root ring H=Z[x_v:v in V]/(x_v^(N_v):v in V), with explicit positive integer capacities N_v and monomial basis 0<=deg_(x_v)<N_v. More general finite free root-splitting rings can replace H. Let G be a finite loopless interaction multigraph and let ell_e=x_v-x_w for its oriented edge e=(v,w). Put E=product_e ell_e. The Euler-image candidate has character dim_Q(E H_Q). This construction is made before symmetric invariants: individual cut products need not be Schur-symmetric, so it would be incorrect to pretend they were automatically multiplication operators on the unsplit Grassmann ring.

For each nonempty bond C of G put p_C=product_(e in C) ell_e. Multiplication and monomial reduction give an explicit finite integer matrix of rows and columns indexed by the bounded exponent vectors for

    delta: direct_sum_(nonempty bonds C) H[-deg p_C] -> H,
    delta((h_C)_C) = sum_C p_C h_C.

The corresponding relative image candidate is

    im(E:H_Q->H_Q) / (im E intersect im delta_Q),

equivalently the image of E in coker delta_Q. The matrices and capacities are completely finite; no BPS space is left undefined.

For an edgeless rank-one graph there are no nonempty bonds, so delta=0 and the candidate retains the ordinary rank-one Grassmann/binomial character. It also deletes the historical m-Kronecker spurious rank-one Euler image discussed below.

However, whenever G has an edge, it has a nonempty bond C; p_C divides E. Hence E lies in im delta and E H is contained in im delta. The candidate is identically zero on every nonempty interaction graph. Thus the unframed bond quotient cannot distinguish spurious overlap multiplicity from required mixed contributions. This is a uniform algebraic failure, not a collection of low-rank tests.

Any useful repair must impose relative framing/block conditions so that the relations are not simply factors of the full Euler product. No such selection rule was established here.

## 3. Historical Euler-image failure was found before repeating it

The local historical note

    work/history/package_1/agents/acyclic_quantum/MODULAR_KRONECKER_INFINITE_FAMILY.md

already gives, for every m>=2, denominator vector (m,2) and split u=v=1,

    H_Q = Q[x,y]/(x^m,y^2),
    (x-y)^m = -m x^(m-1)y in H_Q.

Multiplication has rank 1, whereas rank-two greedy e(1,1)=max(m[2-m]_+,2[m-m]_+)=0. This is already a classical characteristic-zero disagreement. No conclusion about theta classification from the older framed-head manuscripts was inherited. After locating this exact formula, no further raw Euler-image tests were run.

## 4. New upper-Pieri information and what it still needs

The root project supplied a new rank-deletion cap: with a_i=-e_i+A e_i and d_i>0,

    d(g-d_i a_i)=d-d_i e_i,
    F_g <= (1+z_i)^(d_i) F_(g-d_i a_i)

coefficientwise, by theta-positive multiplication. The right hand side is lower rank after freezing i.

If lower-rank theta polynomials have finite combinatorial objects, this gives a finite carrier C_i consisting of all subsets of d_i i-colored slots times those lower-rank objects. The comparison proof gives dimensions, not a canonical common embedding into all C_i. A relative primitive construction would need explicit integer maps between these carriers, compatible with markings and with overlapping vertex deletions. Ordinary marked coproduct injectivity and the bond quotient above do not supply those maps.

The unit-box theorem in the accompanying note resolves this compatibility at capacities zero or one: every carrier can be placed in the same Boolean cube, and Laurent toggles identify the origin component with order ideals. It does not resolve arbitrary capacities.

## 5. Tight blocks and independent-center shuffle filtrations

Rank-two tight compatible gradings supply an explicit primitive-looking block notion. Their shadow condition is directional and depends on epsilon; it is not in general a mutual-shadow requirement. The determinant condition and one-direction shadow condition are special to two-dimensional ordered boundary data. No order-independent extension to three colors that repairs overlap multiplicities was extracted.

The independent-center shuffle filtration is a more general possible interface: retain block centers, impose degree inequalities on every proper split, and take the primitive kernel only after passing to the associated graded. This genuinely differs from the injective raw marked coproduct. But a map from our finite marked/Schur carriers to that filtration, together with proof that its primitive character is theta, remains absent. Using the word primitive without supplying these maps would only conceal the main gap.

See LITERATURE_AUDIT.md for the primary-source scopes and conditional points. No result in this branch turns a scattering or Hall wall factorization into a purported pure finite graph construction.
