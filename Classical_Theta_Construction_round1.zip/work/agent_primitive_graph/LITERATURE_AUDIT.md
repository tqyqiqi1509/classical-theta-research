# Primary literature audit and route record

Research interval 2026-11-13 07:34–08:03 UTC. This audit distinguishes useful interfaces from assumptions that were not transported. No Li–Pan conclusion was used.

## Qiyue Tang, Hexagon 2611.00239v1, 2026-11-09

Primary: https://hexagonmath.org/pdf/2611.00239v1

Read §§3.1–3.2 and §§4.1–4.4, including separated restrictions, symbol multiplication/coproduct, Eulerian logarithm and Weyl-pair arguments. Formal PBW and Weyl-pair deductions appear sound conditional on the preceding bialgebra construction; no error was established there. Its independent-center associated graded is a useful primitive-extraction interface. The raw marking coalgebra has no such filtration automatically. Its fixed-slope symmetry uses the two-dimensional collinearity setting and cannot simply be transferred to arbitrary higher-rank slope data. The paper's cluster positivity application retains actual mutation words and wall/path comparison; no general theta graph formula was extracted or inherited. Status: useful, conditionally audited interface; not a solution theorem for this task.

## Jindal–Neguţ, arXiv 2604.00124v2, 2026-06-18

Primary: https://arxiv.org/pdf/2604.00124

Read Proposition 2.7 and its filtration recursion, §§3.9–3.10 primitive/PBW argument, and stated geometric inputs. The abstract's broad language must be checked against §2.1, which assumes symmetric arrow multiplicities, and §3.4, which explicitly restricts to symmetric quivers. The recursive split/translation degree conditions are a concrete possible finite filtration. Their identification uses integrality/BPS results, and no classical oriented exchange-quiver theta identification follows. The tripled-quiver corollary also has a stated conjectural hypothesis. Status: useful filtration template; direct application to our oriented quiver rejected on scope, not an assertion that the source theorem is false.

## Reineke–Rhoades–Tewari, arXiv 2207.11861

Primary: https://arxiv.org/pdf/2207.11861

Read cocircuit ideals, primitive quotient, covering graph, Lemma 4.2 and Corollary 4.3. The explicit cut-product ideal and central zonotopal space are useful integer algebra templates. Its symmetric-quiver hypotheses include loops and the connected covering-graph setting. These hypotheses and its DT conclusion do not supply a framed module for loopless oriented exchange matrices. The direct cut quotient attempted here has a complete overkilling proof, recorded separately. Status: useful concrete construction; attempted transfer failed.

## Burcroff–Lee–Mou, PNAS 2025

Primary: https://pmc.ncbi.nlm.nih.gov/articles/PMC12067233/

Read compatible gradings and Definitions 1.6 and 1.8. Tightness uses one directional shadow inclusion depending on epsilon, together with the determinant/gcd constraint. It should not be restated as unconditional mutual shadow containment. This is a possible primitive-block template in rank two. The factorization comparison does not furnish a higher-rank finite graph model, and the announcement refers detailed proofs elsewhere. Status: useful exact rank-two definition; no higher-rank conclusion used.

## Burcroff–Lee–Mou–Musiker–Reineke, arXiv 2511.14672v1

Primary: https://arxiv.org/pdf/2511.14672

Read introduction and scope only. Rank-two tight tilings/Weyl symmetries may inform blocks, but no theorem from this paper was used in our general claims. The 2026 journal publication is not an independently audited extension. Status: lead recorded, not adopted.

## Aguiar–Mahajan, Hopf monoids in the category of species

Primary: https://pi.math.cornell.edu/~maguiar/hmonoid.pdf

Read definitions and the Eulerian-idempotent discussion, not the whole PBW proof. Compatibility of product and coproduct is additional structure beyond commuting marks. Status: formal background; no imported basis-identification theorem.

## Bridgeland, Scattering diagrams, Hall algebras and stability conditions

Primary: https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf

The primary excerpt around Theorem 10.1 gives framed Hall theta functions for positive framing. The source explicitly notes the lack of that moduli description for general lattice labels. Extending it to arbitrary g would leave the exact mixed-sign issue unresolved. Status: boundary of available theorem recorded; not imported as a solution.

## Other leads, not adopted

arXiv 2407.19431v2 (bizonotopal graphical algebras, 2026 revision), arXiv 1902.09507, 2024 quiver-cover scattering work, and transverse Grassmannians were searched as possible interfaces. Full relevant hypotheses/proofs were not audited here, so no substantive conclusion from them enters any theorem in this branch.
