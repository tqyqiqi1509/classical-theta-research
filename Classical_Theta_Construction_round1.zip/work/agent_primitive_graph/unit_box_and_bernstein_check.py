"""Exact integer verification of the unit-box poset interface.
The theorem is proved in the accompanying note; this independently checks
its coefficient-equality graph, including arbitrary positive symmetrizers.
"""
from itertools import product,combinations
from math import gcd,comb
from pathlib import Path
from collections import deque,defaultdict
import random,json,time,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'agent_division'))
from rank2_saturation_check import llz_F

def check(B,D,d,v):
    n=len(d);g=tuple(v[i]-d[i]+sum(-B[i][j]*d[j]for j in range(i))for i in range(n))
    active=[i for i in range(n)if d[i]];states=list(product(range(2),repeat=len(active)))
    Ps=[];ids={};adj=[];ideal=[];edges=0
    for k,s in enumerate(states):
        p=[0]*n
        for i,b in zip(active,s):p[i]=b
        p=tuple(p);Ps.append(p);ids[p]=k;adj.append([])
        ideal.append(all(not p[i] or p[j]for i in active for j in active if j<i and B[j][i]>0))
    for k,p in enumerate(Ps):
        for i in range(n):
            r=g[i]+sum(B[i][j]*p[j]for j in range(n))
            decomposed=v[i]-d[i]+sum(-B[i][j]*(d[j]-p[j])for j in range(i))+sum(B[i][j]*p[j]for j in range(i+1,n))
            assert r==decomposed and r>=-d[i]
            assert D[i]*B[i][i]==0
            if d[i] and r==-1:
                q=list(p);q[i]=1-q[i];adj[k].append(ids[tuple(q)]);edges+=1
    seen={0};todo=[0]
    for k in todo:
        for j in adj[k]:
            if j not in seen:seen.add(j);todo.append(j)
    assert seen=={k for k,b in enumerate(ideal)if b}
    assert all(D[i]*B[i][j]==-D[j]*B[j][i]for i in range(n)for j in range(n))
    return len(Ps),len(seen),edges//2

def run():
    start=time.time();stats={'instances':0,'states':0,'origin_vertices':0,'toggle_edges':0,'failures':0}
    for n in range(1,5):
        pairs=list(combinations(range(n),2))
        for weights in product(range(3),repeat=len(pairs)):
            B=[[0]*n for _ in range(n)]
            for (i,j),w in zip(pairs,weights):B[i][j]=w;B[j][i]=-w
            for d in product(range(2),repeat=n):
                v=tuple(0 if d[i]else (i+sum(weights))%3 for i in range(n))
                s,o,e=check(B,[1]*n,d,v)
                stats['instances']+=1;stats['states']+=s;stats['origin_vertices']+=o;stats['toggle_edges']+=e
    rng=random.Random(3437)
    for _ in range(6000):
        n=rng.randint(2,9);D=[rng.randint(1,12)for i in range(n)];B=[[0]*n for _ in range(n)]
        for i,j in combinations(range(n),2):
            w=rng.randrange(4);c=gcd(D[i],D[j]);B[i][j]=w*D[j]//c;B[j][i]=-w*D[i]//c
        d=tuple(rng.randrange(2)for i in range(n));v=tuple(0 if d[i]else rng.randrange(5)for i in range(n))
        s,o,e=check(B,D,d,v)
        stats['instances']+=1;stats['states']+=s;stats['origin_vertices']+=o;stats['toggle_edges']+=e
    F,d=llz_F(3,3,(-8,15));q3=[F.get((p,3),0)for p in range(9)]
    bern=defaultdict(int)
    for p,c in enumerate(q3):
        for j in range(8-p+1):bern[p+j]+=c*comb(8-p,j)*(-1)**j
    assert bern[7]==-22
    out={'unit_box':stats,'rank_two_certificate':{'B':[[0,3],[-3,0]],'g':[-8,15],'d':list(d),'v3_fiber':q3,'bernstein_v3_fiber':[bern[p]for p in range(9)],'negative':[7,3,-22]},'seconds':time.time()-start,'method':'Exact Python integer arithmetic; independent LLZ recurrence is only a comparison oracle.'}
    (HERE/'unit_box_and_bernstein_results.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))

if __name__=='__main__':run()
