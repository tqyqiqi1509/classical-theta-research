"""Finite regular slot covers: a correction test for a general lifting mechanism.

The cover has m labelled perfect matchings between N source and sink copies.
The active capacities are initial segments of sizes a,b. Its multilinear theta
character is the order-ideal polynomial of the active induced bipartite graph.
No scattering computation enters the cover polynomial. Rank-two LLZ is used
only as an independent comparison of the proposed fold/minimum mechanism.
"""
from collections import defaultdict
from math import comb
from pathlib import Path
import json,random,sys,time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agent_division'))
from rank2_saturation_check import llz_F

def cover_polynomial(matchings,a,b):
    parents=[0]*b
    for perm in matchings:
        for i,j in enumerate(perm):
            if i<a and j<b: parents[j]|=1<<i
    F=defaultdict(int)
    unions=[0]*(1<<b)
    for mask in range(1<<b):
        if mask:
            lsb=mask & -mask
            unions[mask]=unions[mask^lsb] | parents[lsb.bit_length()-1]
        r=unions[mask].bit_count();q=mask.bit_count()
        for p in range(r,a+1):F[p,q]+=comb(a-r,p-r)
    return dict(F),parents

def bernstein_coefficients(F,a):
    out=defaultdict(int)
    for (p,q),v in F.items():
        for j in range(a-p+1):out[p+j,q]+=v*comb(a-p,j)*(-1)**j
    return {k:v for k,v in out.items()if v}

def run(m,a,b,count=10000,seed=731):
    rng=random.Random(seed);N=max(a,b);theta,_=llz_F(m,m,(-a,m*a-b))
    lower={p:10**20 for p in [(i,j)for i in range(a+1)for j in range(b+1)]}
    witnesses={};below=[];equal=0;bestmass=None;best=None;first=None
    for k in range(count):
        perms=[list(range(N))]
        for _ in range(m-1):
            q=list(range(N));rng.shuffle(q);perms.append(q)
        F,parents=cover_polynomial(perms,a,b)
        if first is None:first=F
        mass=sum(F.values())
        if bestmass is None or mass<bestmass:bestmass=mass;best={'matchings':perms,'parents':parents,'coefficients':[[*p,c]for p,c in sorted(F.items())]}
        if F==theta:equal+=1
        bad=[[*p,F.get(p,0),v]for p,v in theta.items()if F.get(p,0)<v]
        if bad and len(below)<5:below.append({'matchings':perms,'violations':bad})
        for p in lower:
            v=F.get(p,0)
            if v<lower[p]:lower[p]=v;witnesses[str(p)]=perms
    return {'m':m,'capacity':[a,b],'samples':count,'seed':seed,'theta_mass':sum(theta.values()),'best_mass':bestmass,'equal_cases':equal,'below_theta':below,'minimum_mismatches':[[*p,v,theta.get(p,0)]for p,v in lower.items()if v!=theta.get(p,0)],'theta_bernstein_negative':[[*p,c]for p,c in bernstein_coefficients(theta,a).items()if c<0],'best':best,'minimum_witnesses':witnesses}

if __name__=='__main__':
    start=time.time();data=[]
    for m,a,b,n in [(2,3,3,200),(3,7,8,4000),(3,8,9,12000),(3,5,5,1000),(4,7,8,3000)]:
        x=run(m,a,b,n);data.append(x)
        print({k:x[k]for k in ['m','capacity','samples','theta_mass','best_mass','equal_cases','theta_bernstein_negative']}|{'below':len(x['below_theta']),'minimum_mismatches':x['minimum_mismatches'][:10]},flush=True)
    out={'seconds':time.time()-start,'records':data,'status':'Finite correction tests; no general folding or coefficient-minimum theorem assumed.'}
    (Path(__file__).parent/'slot_cover_results.json').write_text(json.dumps(out,indent=2))
