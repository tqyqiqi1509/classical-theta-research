# Exact computation receipt

2026-11-13. All local calculations used exact Python integers, not floating point optimization. Wolfram was also used independently as requested.

## General unit-box consistency check

Script: unit_box_and_bernstein_check.py. Machine output: unit_box_and_bernstein_results.json.

The script exhausts ranks 1 through 4, upper triangular skew-symmetric entries in {0,1,2}, and every zero/one capacity. It additionally samples 6000 skew-symmetrizable matrices of ranks 2 through 9 using arbitrary positive symmetrizer entries in {1,...,12}. It checks the exponent identity, absence of divisibility beyond degree one, and equality of the origin toggle component with the order ideals.

Results: 17,894 instances; 143,085 Boolean states; 67,129 origin-component vertices; 69,362 toggle edges; zero failures. These checks support an independently written general proof; they are not the proof.

## Exact single-fold Bernstein obstruction

For B=[[0,3],[-3,0]], g=(-8,15), standard box d=(8,9), the independent LLZ recursion gives the v^3 coefficient

    91u^6 + 160u^7 + 84u^8.

At 2026-11-13 about 08:00 UTC, the Wolfram evaluator independently returned

    91*t^6 - 22*t^7 + 15*t^8

for Together[(1-t)^8 (91 (t/(1-t))^6+160 (t/(1-t))^7+84 (t/(1-t))^8)] // Expand.

Every positive bipartite slot fold has a nonnegative integral Bernstein transform because those coefficients count parent-set unions. The negative coefficient -22 therefore excludes a single positive fold of this entire class. It does not exclude relative quotients, signed combinations, or more general graph models.

## Earlier finite cover tests, then stopped

slot_cover_probe.py and slot_cover_results.json retain 20,200 finite regular-cover tests across five capacities. They used random seed 731 and exact parent-union bitmasks. No tested fold coefficient was below the comparison theta coefficient. Some capacities had equality and others did not in this sample. No sample minimum is asserted to be the global minimum. Enumeration stopped when the structural Bernstein obstruction was established and the root instructed a route correction.

## Marked coproduct identity

Wolfram checked 7380 monomials for d_i F=E_i F+z_i D_i F, returning zero failures. The symbolic equality is immediate and is recorded in PRIMITIVE_QUOTIENT_ATTEMPTS.md.
