#!/usr/bin/env python3
"""Mechanism stress test with provably non-cluster-monomial labels.

B[0:2,0:2]=r-Kronecker (r>=2), g[0:2]=(-m,m), m>0.
Rank-two g-fan classification + freezing of cluster monomials proves non-CM.
This is not an inference from failure of a bounded seed search.
"""
from finite_atlas_cone import *
from scan_mass import safe_transport
from math import lcm
import hashlib

def acyclic_carrier(B,g,cap=20000):
    n=len(g);out=[]
    def rec(prefix):
        if len(out)>cap:raise OverflowError('point cap')
        k=len(prefix)
        if k==n:out.append(tuple(prefix));return
        bound=max(-g[k],0)+sum(max(-B[k][j],0)*prefix[j] for j in range(k))
        for a in range(bound+1):rec(prefix+[a])
    assert all(B[i][j]>=0 for i in range(n) for j in range(i+1,n))
    rec([]);return out

def family_matrix(n,r,kind,valued):
    D=[1,1]+([2,3,1][:n-2] if valued else [1]*(n-2));B=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1,n):
            w=r if (i,j)==(0,1) else (1 if kind=='dense' or j==i+1 else 0)
            s=lcm(D[i],D[j])*w;B[i][j]=s//D[i];B[j][i]=-s//D[j]
    if kind=='cycle':
        s=lcm(D[0],D[-1]);B[-1][0]=s//D[-1];B[0][-1]=-s//D[0]
    return B,D

def optimize(B,g,points,seconds=5):
    M=build(B,g,points);lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':seconds})
    F=exact_primal(M,lp.x);out={'points':len(points),'variables':len(M['columns']),'lp_status':int(lp.status)}
    if lp.x is not None and lp.eqlin.marginals is not None:
        d=exact_global_dual(M,lp.eqlin.marginals)
        if not d.get('valid'):d=solve_global_dual(M,seconds=seconds)
        out['dual']=d
    if F is None:
        mi=milp(M['c'],integrality=np.ones(len(M['columns'])),bounds=Bounds(0,np.inf),
                constraints=LinearConstraint(M['A'],M['b'],M['b']),options={'time_limit':seconds})
        F=exact_primal(M,mi.x);out['milp_status']=int(mi.status)
    if F is not None:
        C=sum(F.values());out['mass']=C;out['support']=len(F)
        out['global_minimum_certified']=out.get('dual',{}).get('valid') and Fraction(out['dual']['mu'])>C-1
        if len(M['columns'])<4000:out['uniqueness']=uniqueness_from_dual(M,out.get('dual',{}),C)
        else:out['uniqueness_resource_cap']=True
    return out,F,M

def run():
    stats=defaultdict(int);start=time.time();saved=set();rng=random.Random(20261113)
    with open('work/agent_mass/noncluster_scan.jsonl','w') as log:
        for n in [4,5]:
          for r in [2,3,4]:
           for kind in ['chain','dense','cycle']:
            for valued in [False,True]:
             B,D=family_matrix(n,r,kind,valued)
             # Mixed outside labels include mandatory higher-rank support.
             outside=list(product([-1,0,1],repeat=n-2))
             rng.shuffle(outside)
             for m in [1,2]:
              for tail in outside:
                g=(-m,m)+tail;stats['instances']+=1
                result={'B':B,'D':D,'g':g,'rank2_r':r,'rank2_m':m,'family':kind,
                        'classification':'nonCM_by_rank2_restriction_and_freezing'}
                try:
                    if kind!='cycle':points=acyclic_carrier(B,g,cap=20000);result['domain']='complete_acyclic_carrier'
                    else:points=carrier_points(B,g,5);result['domain']='box_5_intersect_normalized_carrier'
                except OverflowError:
                    result['resource_cap']='20000 carrier points';stats['carrier_point_cap']+=1;log.write(json.dumps(result)+'\n');log.flush();continue
                out,F,M=optimize(B,g,points,seconds=5);result.update(out);stats['cone_solves']+=1
                if F is not None:
                    stats['feasible']+=1
                    if result.get('global_minimum_certified'):stats['global_minimum_certified']+=1
                    if result.get('uniqueness',{}) and result['uniqueness']['unique']:stats['global_unique_certified']+=1
                    full=any(all(p[i]>0 for i in range(n)) for p in F)
                    result['all_variables_interact_in_support']=full
                    if full:stats['full_support_interaction']+=1
                    checks,fail=safe_transport(B,g,F,maxdepth=3,maxsteps=500,max_exponent=150,maxterms=10000)
                    result['transport']=checks;stats['transport_steps']+=checks['steps']
                    for k,v in checks['pruned'].items():stats['transport_pruned_'+k]+=v
                    if fail:
                        result['transport_failure']=fail;result['F']=dump_table(F);stats['transport_failures']+=1
                        fn='work/agent_mass/noncluster_failure_%05d.json'%stats['instances']
                        pathlib.Path(fn).write_text(json.dumps(result,indent=2));print(json.dumps({'FOUND':fn}),flush=True)
                    key=n,r,kind,valued
                    if full and key not in saved:
                        saved.add(key);witness=dict(result);witness['F']=dump_table(F)
                        fn='work/agent_mass/noncluster_sample_%d_%d_%s_%d.json'%(n,r,kind,int(valued))
                        pathlib.Path(fn).write_text(json.dumps(witness,indent=2));result['witness']=fn
                    result['coefficient_table_sha256']=hashlib.sha256(json.dumps(dump_table(F)).encode()).hexdigest()
                else:stats['no_candidate_in_test_domain']+=1
                if 'dual' in result:result['dual']={k:v for k,v in result['dual'].items() if k!='certificate'}
                log.write(json.dumps(result)+'\n');log.flush()
                if stats['instances']%20==0:print(json.dumps({'stats':dict(stats),'seconds':time.time()-start}),flush=True)
    stats['seconds']=time.time()-start
    pathlib.Path('work/agent_mass/noncluster_summary.json').write_text(json.dumps(dict(stats),indent=2))
    print(json.dumps(dict(stats)),flush=True)

if __name__=='__main__':run()
