#!/usr/bin/env python3
from packet_minimum import *
from scan_mass import safe_transport

def lower_coefficient_candidate(M,target,mass_cap,seconds=10):
    P=len(M['points']);N=len(M['columns']);w=np.zeros(N);w[:P]=1
    w[M['ids'][target]]+=mass_cap+1
    massrow=coo_matrix((np.ones(P),(np.zeros(P,int),np.arange(P))),shape=(1,N)).tocsc()
    A=vstack([M['A'],massrow]).tocsc();lo=np.r_[M['b'],0];hi=np.r_[M['b'],mass_cap]
    r=milp(w,integrality=np.ones(N),bounds=Bounds(0,np.inf),constraints=LinearConstraint(A,lo,hi),
           options={'time_limit':seconds})
    return exact_primal(M,r.x),int(r.status)

def run():
    records=[json.loads(line) for line in open('work/agent_mass/mass_scan.jsonl')]
    records=[r for r in records if r.get('mass',0)>1]
    stats=defaultdict(int);tic=time.time()
    with open('work/agent_mass/leastness_scan.jsonl','w') as out:
        for ri,r in enumerate(records):
            B,g,F=r['B'],r['g'],load_table(r['F']);C=sum(F.values())
            # Slightly larger than discovery box whenever tractable.
            L=max(r['L'],3);M=build(B,g,carrier_points(B,g,L))
            points=sorted(F,key=lambda p:(sum(p),p),reverse=True)
            targets=[p for p in points if sum(p)>1]
            stats['instances']+=1;ans={'B':B,'g':g,'L':L,'mass':C,'targets':[]}
            for target in targets:
                d=solve_global_dual(M,seconds=3,weight=lambda p:int(p==target));stats['dual_solves']+=1
                ok=d.get('valid',False) and Fraction(d['mu'])>F[target]-1
                entry={'target':target,'coefficient':F[target],'bound':d.get('mu'),'exact_valid':d.get('valid',False),
                       'certified':ok}
                if ok:stats['coefficient_lower_bounds_certified']+=1
                else:
                    H,status=lower_coefficient_candidate(M,target,6*C,seconds=3);stats['primal_searches']+=1
                    entry['milp_status']=status
                    if H is not None and H.get(target,0)<F[target]:
                        stats['leastness_failures']+=1;entry['lower_candidate']=dump_table(H)
                        tc,err=safe_transport(B,g,H,maxdepth=3)
                        entry['transport']=tc;entry['transport_failure']=err
                        witness={'base':r,'target':target,'candidate':dump_table(H),'test':entry}
                        fn='work/agent_mass/leastness_failure_%04d_%03d.json'%(ri,stats['leastness_failures'])
                        pathlib.Path(fn).write_text(json.dumps(witness,indent=2))
                        print(json.dumps({'FOUND':fn,'base_certified':r.get('global_mass_minimum_certified')}),flush=True)
                        # Find what mutation-weight objective may expose this.
                        entry['neighbor_masses']=[]
                        for k in range(len(g)):
                            S,er=mutate(B,g,H,k);T,et=mutate(B,g,F,k)
                            if er or et:continue
                            BB,gg,HH=S;_,_,FF=T
                            valid,error=all_neighbors(BB,gg,HH)
                            entry['neighbor_masses'].append({'k':k,'base':sum(FF.values()),'candidate':sum(HH.values()),
                                                             'candidate_local':valid,'error':error})
                ans['targets'].append(entry)
            ans['coefficientwise_least_certified']=all(t['certified'] for t in ans['targets'])
            if ans['coefficientwise_least_certified']:stats['least_elements_certified']+=1
            out.write(json.dumps(ans)+'\n');out.flush()
            if ri%10==0:print(json.dumps({'stats':dict(stats),'seconds':time.time()-tic}),flush=True)
    stats['seconds']=time.time()-tic
    pathlib.Path('work/agent_mass/leastness_summary.json').write_text(json.dumps(dict(stats),indent=2))
    print(json.dumps(dict(stats)),flush=True)

if __name__=='__main__':run()
