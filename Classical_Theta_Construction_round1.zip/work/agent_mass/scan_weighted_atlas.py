#!/usr/bin/env python3
from finite_atlas_cone import *

def run():
    records=[json.loads(line) for line in open('work/agent_mass/mass_scan.jsonl')]
    records=[r for r in records if r.get('global_mass_minimum_certified') and r.get('mass',0)>1]
    stats=defaultdict(int);tic=time.time()
    with open('work/agent_mass/weighted_atlas_scan.jsonl','w') as out:
        for ri,r in enumerate(records):
            B,g,F=r['B'],r['g'],load_table(r['F']);n=len(g);stats['instances']+=1
            for k in range(n):
                baseline,err=mutate(B,g,F,k)
                if err:raise AssertionError(err)
                BB,gg,FF=baseline;C=sum(FF.values());L=min(5,r['L']+1)
                M=build_atlas(B,g,carrier_points(B,g,L),[(k,)])
                result={'instance':ri,'B':B,'g':g,'k':k,'L':L,'base_root_mass':r['mass'],
                        'base_neighbor_mass':C,'rows':len(M['rows']),'variables':len(M['columns'])}
                if len(M['rows'])>50000:result['skip']='row_cap';stats['skipped_row_cap']+=1;out.write(json.dumps(result)+'\n');continue
                objective=np.zeros(len(M['columns']))
                for (t,p),col in M['aids'].items():
                    if t==1:objective[col]=1
                lp=linprog(objective,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':3})
                H=verify_root(M,lp.x);stats['weighted_solves']+=1
                result['lp_status']=int(lp.status);result['lp_fun']=None if lp.fun is None else float(lp.fun)
                if H is None:
                    mi=milp(objective,integrality=np.ones(len(objective)),bounds=Bounds(0,np.inf),
                            constraints=LinearConstraint(M['A'],M['b'],M['b']),options={'time_limit':3})
                    H=verify_root(M,mi.x);result['milp_status']=int(mi.status);stats['milp_solves']+=1
                if H is not None:
                    state,er=mutate(B,g,H,k)
                    if er:raise AssertionError(er)
                    HH=state[2];CH=sum(HH.values());result['found_root_mass']=sum(H.values());result['found_neighbor_mass']=CH
                    stats['verified_weighted_candidates']+=1
                    if CH<C:
                        stats['covariance_failures']+=1
                        result.update({'base_F':dump_table(F),'H':dump_table(H),'neighbor_H':dump_table(HH),
                                       'base_global_dual':r['dual']})
                        fn='work/agent_mass/weighted_covariance_failure_%04d_%d.json'%(ri,k)
                        pathlib.Path(fn).write_text(json.dumps(result,indent=2));print(json.dumps({'FOUND_FAILURE':fn}),flush=True)
                    elif CH==C and HH!=FF:
                        result['equal_mass_distinct']=True;stats['equal_mass_distinct']+=1
                        M2=build(BB,gg,M['nodes'][1]['points']);dual=solve_global_dual(M2,seconds=5)
                        result['neighbor_global_dual']=dual
                        if dual.get('valid') and Fraction(dual['mu'])>C-1:
                            stats['certified_nonunique_minimum']+=1
                            result.update({'base_F':dump_table(F),'H':dump_table(H),'neighbor_F':dump_table(FF),'neighbor_H':dump_table(HH)})
                            fn='work/agent_mass/nonunique_minimum_%04d_%d.json'%(ri,k)
                            pathlib.Path(fn).write_text(json.dumps(result,indent=2));print(json.dumps({'FOUND_NONUNIQUE':fn}),flush=True)
                out.write(json.dumps(result)+'\n');out.flush()
            if ri%10==0:print(json.dumps({'stats':dict(stats),'seconds':time.time()-tic}),flush=True)
    stats['seconds']=time.time()-tic
    pathlib.Path('work/agent_mass/weighted_atlas_summary.json').write_text(json.dumps(dict(stats),indent=2))
    print(json.dumps(dict(stats)),flush=True)

if __name__=='__main__':run()
