#!/usr/bin/env python3
"""Broad mechanism test: local minimum mass, uniqueness, mutation covariance.
This is a discovery experiment over structural families, not a list of cases.
Every retained polynomial and dual certificate uses exact checking.
"""
from packet_minimum import *
from collections import deque
from math import lcm
import argparse

def safe_transport(B,g,F,maxdepth=3,maxsteps=350,maxterms=5000,max_exponent=120):
    queue=deque([(B,tuple(g),F,())]);seen=set();steps=0;pruned=defaultdict(int)
    while queue and steps<maxsteps:
        BB,gg,FF,w=queue.popleft()
        key=(tuple(map(tuple,BB)),gg,tuple(sorted(FF.items())))
        if key in seen:continue
        seen.add(key)
        if len(w)>=maxdepth:continue
        for k in range(len(g)):
            if w and w[-1]==k:continue
            # Protect exact expansion against enormous integer exponents.
            predicted=max(max(p[k],abs(gg[k]+sum(BB[k][j]*p[j] for j in range(len(g)))))
                          for p in FF)
            if predicted>max_exponent:pruned['large_exponent']+=1;continue
            if len(FF)>maxterms:pruned['large_support']+=1;continue
            state,err=mutate(BB,gg,FF,k);steps+=1
            if err:return {'steps':steps,'pruned':dict(pruned)}, {'word':w+(k,), 'error':err}
            B2,g2,F2=state
            queue.append((B2,g2,F2,w+(k,)))
    if queue:pruned['step_limit']+=len(queue)
    return {'steps':steps,'pruned':dict(pruned),'seen':len(seen)},None

def matrices(n,count,rng):
    result=[]
    # Directed cycle, cycle with chords, bipartite and transitive types.
    for weights in ([1]*n,[2]*n,[1+(i%2) for i in range(n)]):
        B=[[0]*n for _ in range(n)]
        for i,w in enumerate(weights):j=(i+1)%n;B[i][j]=w;B[j][i]=-w
        result.append((B,[1]*n,'cycle'))
    for t in range(count):
        D=[1]*n if t%2==0 else [rng.choice([1,2,3]) for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                w=rng.choice([-2,-1,-1,0,0,1,1,2]);s=lcm(D[i],D[j])*w
                B[i][j]=s//D[i];B[j][i]=-s//D[j]
        # skip disconnected patterns
        reachable={0}
        for _ in range(n):reachable|={j for i in reachable for j in range(n) if B[i][j]}
        if len(reachable)==n:result.append((B,D,'random'))
    return result

def run(output,count=18,seed=20261113):
    rng=random.Random(seed);stats=defaultdict(int);start=time.time()
    path=pathlib.Path(output);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w') as out:
        for n in [4,5]:
            mats=matrices(n,count,rng)
            for mi,(B,D,family) in enumerate(mats):
                labels=[(-1,)*n,tuple(-1 if i<2 else 0 for i in range(n)),
                        tuple(-1 if i==0 else 1 for i in range(n)),
                        tuple(1 if i%2 else -1 for i in range(n))]
                labels += [tuple(rng.choice([-2,-1,0,1,2]) for _ in range(n)) for _ in range(8)]
                for gi,g in enumerate(labels):
                    stats['instances']+=1
                    if stats['instances']%10==0:
                        print(json.dumps({'stats':dict(stats),'elapsed_seconds':time.time()-start}),flush=True)
                    final=None;F=None
                    for L in [2,3,4]:
                        stats['cone_solves']+=1
                        result,F=solve(B,g,L,seconds=3,alternatives=0)
                        result.update({'matrix_index':mi,'label_index':gi,'family':family,'D':D})
                        if F is not None:
                            final=result;break
                        # record failed finite domain, no claim global infeasible
                        result['scope']='finite_domain_only'
                        out.write(json.dumps(result)+'\n');out.flush()
                    if F is None:stats['no_finite_candidate_in_test_domains']+=1;continue
                    stats['feasible']+=1
                    if final.get('global_mass_minimum_certified'):stats['global_minimum_certified']+=1
                    if final.get('uniqueness',{}) and final['uniqueness']['unique']:stats['global_unique_certified']+=1
                    if not (final.get('uniqueness') and final['uniqueness']['unique']):
                        alt_result,_=solve(B,g,final['L'],seconds=3,alternatives=3)
                        stats['alternative_solves']+=3
                        final['alternatives']=alt_result.get('alternatives',[])
                        if final['alternatives']:stats['equal_mass_alternatives']+=len(final['alternatives'])
                    checks,fail=safe_transport(B,g,F,maxdepth=3,maxsteps=350)
                    final['transport']=checks;stats['transport_steps']+=checks['steps']
                    for k,v in checks['pruned'].items():stats['transport_pruned_'+k]+=v
                    if fail:
                        final['transport_failure']=fail;stats['transport_failures']+=1
                        witness=path.parent/('mass_failure_%05d.json'%stats['instances'])
                        witness.write_text(json.dumps(final,indent=2))
                        print(json.dumps({'FOUND_FAILURE':str(witness),'certified':final.get('global_mass_minimum_certified')}),flush=True)
                    # Prove non-covariance by finding a strictly lighter neighbor.
                    # No global optimality claim is needed about the new candidate.
                    if final.get('global_mass_minimum_certified') and not fail:
                        neighbor_records=[]
                        for k in range(n):
                            state,err=mutate(B,g,F,k)
                            if err:continue
                            B2,g2,F2=state;C2=sum(F2.values())
                            if C2<=1:continue
                            L2=min(4,max(max(p) for p in F2))
                            nr,H=solve(B2,g2,L2,seconds=2,alternatives=0);stats['neighbor_solves']+=1
                            record={'k':k,'transported_mass':C2,'found_mass':nr.get('mass'),
                                    'new_global_certificate':nr.get('global_mass_minimum_certified',False)}
                            neighbor_records.append(record)
                            if H is not None and sum(H.values())<C2:
                                final['covariance_failure']={'k':k,'neighbor':nr,'transported_F':dump_table(F2)}
                                stats['covariance_failures']+=1
                                witness=path.parent/('covariance_failure_%05d.json'%stats['instances'])
                                witness.write_text(json.dumps(final,indent=2))
                                print(json.dumps({'FOUND_COVARIANCE_FAILURE':str(witness)}),flush=True)
                                break
                        final['neighbor_checks']=neighbor_records
                    out.write(json.dumps(final)+'\n');out.flush()
    stats['elapsed_seconds']=time.time()-start
    (path.parent/'scan_summary.json').write_text(json.dumps(dict(stats),indent=2))
    print(json.dumps(dict(stats)),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--count',type=int,default=18)
    parser.add_argument('--output',default='work/agent_mass/mass_scan.jsonl')
    args=parser.parse_args();run(args.output,args.count)
