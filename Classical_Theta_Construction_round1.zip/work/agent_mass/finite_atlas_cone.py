#!/usr/bin/env python3
"""Positive packet cones on a finite mutation tree, with global dual checks.

The finite tree specifies only constraints. All coefficient exponent domains
are infinite in the mathematical problem. Finite-support dual potentials are
checked on every packet meeting their support, so a verified lower bound is
not a box-optimality claim.
"""
from packet_minimum import *
from normalized_fibers import mutate_matrix,mutate_g

def node_tree(B,g,words):
    prefixes={()}
    for word in words:
        for z in range(len(word)+1):prefixes.add(tuple(word[:z]))
    paths=sorted(prefixes,key=lambda w:(len(w),w));ids={w:i for i,w in enumerate(paths)}
    nodes=[]
    for w in paths:
        if not w:nodes.append({'word':w,'B':B,'g':tuple(g)});continue
        parent=nodes[ids[w[:-1]]];k=w[-1]
        nodes.append({'word':w,'parent':ids[w[:-1]],'k':k,
                      'B':mutate_matrix(parent['B'],k),'g':mutate_g(parent['B'],parent['g'],k)})
    return nodes

def edge_parameters(node,k,off):
    B,g=node['B'],node['g'];n=len(g);p=off[:k]+(0,)+off[k:]
    r=g[k]+sum(B[k][j]*p[j] for j in range(n));d=max(-r,0);e=max(r,0)
    alpha=max(-g[k],0)+sum(max(-B[k][j],0)*p[j] for j in range(n))
    return d,e,alpha

def local_packet(node,k,off,s):
    d=packet_degree(node['B'],node['g'],k,off)
    return [(off[:k]+(s+j,)+off[k:],comb(d,j)) for j in range(d+1)]

def edge_packet(node,k,off,s):
    d,e,alpha=edge_parameters(node,k,off)
    if s<0 or s>alpha-d:return None
    source=[(off[:k]+(s+j,)+off[k:],comb(d,j)) for j in range(d+1)]
    target=[(off[:k]+(alpha-d-s+j,)+off[k:],comb(e,j)) for j in range(e+1)]
    return source,target

def build_atlas(B,g,points,words):
    nodes=node_tree(B,g,words);n=len(g);nodes[0]['points']=set(points)
    for t,node in enumerate(nodes[1:],1):
        parent=nodes[node['parent']];k=node['k'];S=parent['points'];T=set()
        for p in S:
            off=p[:k]+p[k+1:];s=p[k];packet=edge_packet(parent,k,off,s)
            if packet is None:continue
            source,target=packet
            if all(q in S for q,a in source) and all(in_container(node['B'],node['g'],q) for q,a in target):
                T.update(q for q,a in target)
        node['points']=T
    groups=[];types=[]
    for t,node in enumerate(nodes):
        for k in range(n):
            gr=len(groups);groups.append({'node':t,'k':k})
            types.append({'kind':'local','node':t,'k':k,'groups':[gr]})
    for t,node in enumerate(nodes[1:],1):
        parent=node['parent'];k=node['k'];gr=len(groups)
        groups.extend([{'node':parent,'k':k},{'node':t,'k':k}])
        types.append({'kind':'edge','node':parent,'target':t,'k':k,'groups':[gr,gr+1]})
    rows={};cols=[];aids={};rr=[];cc=[];vv=[]
    for t,node in enumerate(nodes):
        for p in sorted(node['points']):aids[t,p]=len(cols);cols.append(('a',t,p))
    for gr,group in enumerate(groups):
        t=group['node']
        for p in sorted(nodes[t]['points']):
            row=len(rows);rows[gr,p]=row
            rr.append(row);cc.append(aids[t,p]);vv.append(1)
    for typ,record in enumerate(types):
        t=record['node'];node=nodes[t];k=record['k'];S=node['points']
        for p in sorted(S):
            off=p[:k]+p[k+1:];s=p[k]
            terms=packet_terms(nodes,record,off,s,finite=True)
            if terms is None:continue
            col=len(cols);cols.append(('q',typ,off,s))
            for gr,q,a in terms:rr.append(rows[gr,q]);cc.append(col);vv.append(-a)
    nr=len(rows);zero=(0,)*n
    if (0,zero) not in aids:raise ValueError('origin absent')
    rr.append(nr);cc.append(aids[0,zero]);vv.append(1)
    A=coo_matrix((np.array(vv,float),(rr,cc)),shape=(nr+1,len(cols))).tocsc()
    b=np.zeros(nr+1);b[-1]=1;c=np.zeros(len(cols))
    for (t,p),col in aids.items():
        if t==0:c[col]=1
    return {'nodes':nodes,'groups':groups,'types':types,'rows':rows,'columns':cols,'aids':aids,'A':A,'b':b,'c':c}

def packet_terms(nodes,record,off,s,finite=False):
    t=record['node'];node=nodes[t];k=record['k'];gr=record['groups']
    if record['kind']=='local':
        p=local_packet(node,k,off,s)
        if any(not in_container(node['B'],node['g'],q) for q,a in p):return None
        if finite and any(q not in node['points'] for q,a in p):return None
        return [(gr[0],q,a) for q,a in p]
    pair=edge_packet(node,k,off,s)
    if pair is None:return None
    source,target=pair;other=nodes[record['target']]
    if any(not in_container(node['B'],node['g'],q) for q,a in source):return None
    if any(not in_container(other['B'],other['g'],q) for q,a in target):return None
    if finite and (any(q not in node['points'] for q,a in source) or any(q not in other['points'] for q,a in target)):return None
    return [(gr[0],q,a) for q,a in source]+[(gr[1],q,a) for q,a in target]

def touching_packets(M,support_rows=None):
    if support_rows is None:support_rows=M['rows']
    offs=defaultdict(dict)
    for gr,p in support_rows:
        k=M['groups'][gr]['k'];off=p[:k]+p[k+1:]
        offs[gr][off]=max(offs[gr].get(off,-1),p[k])
    for typ,record in enumerate(M['types']):
        alloff=set().union(*(set(offs[gr]) for gr in record['groups']))
        for off in alloff:
            if record['kind']=='local':maxs=offs[record['groups'][0]][off]
            else:
                d,e,alpha=edge_parameters(M['nodes'][record['node']],record['k'],off);maxs=alpha-d
            for s in range(maxs+1):
                terms=packet_terms(M['nodes'],record,off,s,finite=False)
                if terms is not None:yield typ,off,s,terms

def exact_dual(M,z,weight=None):
    if weight is None:weight=lambda t,p:int(t==0)
    lam={key:Fraction(float(z[row])).limit_denominator(100000) for key,row in M['rows'].items() if abs(z[row])>1e-10}
    mu=Fraction(float(z[-1])).limit_denominator(100000);n=len(M['nodes'][0]['g']);zero=(0,)*n
    bynode=defaultdict(set)
    for gr,p in lam:bynode[M['groups'][gr]['node']].add(p)
    bynode[0].add(zero)
    coeff_checks=0
    for t,points in bynode.items():
        for p in points:
            value=sum((lam.get((gr,p),Fraction(0)) for gr,G in enumerate(M['groups']) if G['node']==t),Fraction(0))
            if t==0 and p==zero:value+=mu
            if value>weight(t,p):return {'valid':False,'kind':'coefficient','node':t,'p':p,'lhs':str(value)}
            coeff_checks+=1
    checks=0
    for typ,off,s,terms in touching_packets(M,lam):
        value=sum((a*lam.get((gr,p),Fraction(0)) for gr,p,a in terms),Fraction(0));checks+=1
        if value<0:return {'valid':False,'kind':'packet','type':typ,'off':off,'s':s,'lhs':str(value)}
    return {'valid':True,'mu':str(mu),'coefficient_checks':coeff_checks,'packet_checks':checks,
            'certificate':{'mu':[mu.numerator,mu.denominator],
              'lambda':[{'group':gr,'p':p,'value':[v.numerator,v.denominator]} for (gr,p),v in sorted(lam.items())]}}

def global_dual(M,weight=None,seconds=10):
    if weight is None:weight=lambda t,p:int(t==0)
    nr=len(M['rows'])+1;rr=[];cc=[];vv=[];rhs=[];row=0;n=len(M['nodes'][0]['g']);zero=(0,)*n
    for t,p in M['aids']:
        for gr,G in enumerate(M['groups']):
            if G['node']==t:rr.append(row);cc.append(M['rows'][gr,p]);vv.append(1)
        if t==0 and p==zero:rr.append(row);cc.append(nr-1);vv.append(1)
        rhs.append(float(weight(t,p)));row+=1
    for typ,off,s,terms in touching_packets(M):
        for gr,p,a in terms:
            col=M['rows'].get((gr,p))
            if col is not None:rr.append(row);cc.append(col);vv.append(-a)
        rhs.append(0);row+=1
    A=coo_matrix((np.array(vv,float),(rr,cc)),shape=(row,nr)).tocsc();c=np.zeros(nr);c[-1]=-1
    result=linprog(c,A_ub=A,b_ub=rhs,bounds=(None,None),method='highs',options={'time_limit':seconds})
    if result.x is None:return {'valid':False,'status':int(result.status)}
    return exact_dual(M,result.x,weight)

def verify_root(M,x):
    if x is None:return None
    F={p:int(round(x[col])) for (t,p),col in M['aids'].items() if t==0 and round(x[col])}
    n=len(M['nodes'][0]['g'])
    if F.get((0,)*n)!=1 or any(a<0 for a in F.values()):return None
    states=[F]
    for t,node in enumerate(M['nodes']):
        if t:
            par=M['nodes'][node['parent']]
            state,err=mutate(par['B'],par['g'],states[node['parent']],node['k'])
            if err:return None
            states.append(state[2])
        if not all_neighbors(node['B'],node['g'],states[t])[0]:return None
    return F

def solve_atlas(B,g,L,words,seconds=10,objective=None):
    M=build_atlas(B,g,carrier_points(B,g,L),words)
    c=M['c'].copy()
    if objective is not None:
        for (t,p),col in M['aids'].items():c[col]=float(objective(t,p))
    r=linprog(c,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':seconds})
    F=verify_root(M,r.x)
    result={'B':B,'g':g,'L':L,'words':words,'nodes':len(M['nodes']),'variables':len(M['columns']),
            'rows':len(M['rows']),'lp_status':int(r.status),'lp_fun':None if r.fun is None else float(r.fun)}
    if F is None:
        m=milp(c,integrality=np.ones(len(c)),bounds=Bounds(0,np.inf),constraints=LinearConstraint(M['A'],M['b'],M['b']),
               options={'time_limit':seconds});F=verify_root(M,m.x);result['milp_status']=int(m.status)
    if F is not None:result.update({'mass':sum(F.values()),'F':dump_table(F)})
    result['dual']=global_dual(M,objective,seconds)
    return result,F,M

if __name__=='__main__':
    old=json.load(open('work/agent_mass/leastness_failure_0089_001.json'))
    B,g=old['base']['B'],old['base']['g'];target=tuple(old['target'])
    r,F,M=solve_atlas(B,g,4,[(1,)],seconds=10)
    r['target_dual']=global_dual(M,weight=lambda t,p:int(t==0 and p==target),seconds=10)
    print(json.dumps(r,indent=2))
