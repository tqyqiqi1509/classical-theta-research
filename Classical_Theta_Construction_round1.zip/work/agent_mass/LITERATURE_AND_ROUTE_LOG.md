# Literature and route log, second wave

Time window: 2026-11-13 approximately04:44--05:15UTC. This is a continuation
of the parent's six-hour research run, not a new six-hour run.

## Primary-source checks

1. Lee--Li--Zelevinsky, *Greedy elements in rank2 cluster algebras*,
   arXiv:1208.2391v3 (9 November2012),
   https://arxiv.org/pdf/1208.2391 . Reopened and read Definitions1.2--1.3,
   Proposition1.5 and its setup. Useful for the genuine rank-two coordinate
   convention and three-chart positivity inequalities. **Not used** as a
   coefficientwise-least theorem: the recurrence has alternating signs,
   so the attempted monotone-induction inference was explicitly withdrawn.
   No error in LLZ is asserted.

2. Fan Qin, *Applications of the freezing operators on cluster algebras*,
   arXiv:2407.03186v1, https://arxiv.org/pdf/2407.03186 . Parent and previous
   agent read Theorem5.11 and Remark1.2. Theorem5.11 is used as an external
   correctness input solely to classify high-rank labels via a rank-two
   restriction: a cluster monomial restricts to a localized cluster monomial.
   Its proof uses scattering, as the author says. The algorithms constructed
   here do not call scattering data, theta coefficients, or that proof.

3. Coates--Kasprzyk--Pitton--Tveiten, *Maximally mutable Laurent polynomials*,
   arXiv:2107.14253v1 (29 July2021), https://arxiv.org/pdf/2107.14253 . Reopened
   original, read the introduction and Definitions2.5--2.6 (PDFp9). Their
   rigidity concerns fixed Newton polytope and the full mutation graph.
   Useful as the fixed-carrier linear-algebra interface. It does not provide
   a finite all-seed stopping rule or a canonical cluster-basis selector.
   The large PDF contains extensive tables; no table computation was imported.

4. Qiyue Tang, *Positive polytopes and the full Fock--Goncharov conjecture*,
   Hexagon2611.00015v1, https://hexagonmath.org/pdf/2611.00015v1 . Found during
   the2026 refresh, checked title, version, abstract and provenance only.
   **Not adopted as a theorem:** a strong proof audit was not completed by
   this agent. Its origin-interior polytope criterion is not an immediate
   integer-packet construction or selection theorem. No correctness verdict
   on its full argument is made here.

## Refresh queries

At approximately04:57UTC, searched general combinations of greedy bases,
positive divisibility, coefficientwise minimality, arbitrary rank,
F-polynomial local positivity, and maximally mutable Laurent polynomial
rigidity. A2026-specific system1 query located the Tang paper above. Search
engine crawl dates were not treated as publication dates; the MMLP source
is2021, not a new2026 result.

## Route changes and outcomes

- Local mass minimization: initially plausible;254 feasible broad rank4/5
  cases gave252 global mass certificates and242 uniqueness certificates.
  Their cluster-monomial status was not determined, so those cases are marked
  classification unknown.
- Coefficientwise leastness:2056 exact lower coefficient certificates in
  2119 attempts;212 of219 examined candidates certified least within the
  normalized local cone. One valued rank4 example conclusively disproves
  unconditional leastness. Seven incompletely certified instances are not
  declared failures merely because the certificate search did not finish.
- Adjacent weighted mass:955 exact two-chart optimizations on217 initial
  candidates found no failure. These computations were not taken as a proof.
- Non-CM structural families: use r-Kronecker restrictions with labels
  (-m,m), r>=2,m>0. At476 completed instances,416 were feasible,368 had global
  mass certificates,343 had uniqueness certificates.277 feasible examples
  had source/sink irreducible cores of rank>=3,219 of them with all variables
  appearing jointly in the support. Eight transport failures were found.
- The single-chart mass proposal was then decisively refuted by a rank4
  nonuniqueness certificate and a rank5 unique-minimum normalization failure.
  The broad scan was stopped when this became clear; it was not run to
  completion merely to accumulate examples.
- Repair: finite mutation-tree packet equations and globally checked finite
  duals. The rank4 obstruction is resolved without changing mass25; the
  rank5 one forces a certified increase44->46. These are exact tests of the
  general finite-phase method, not a claim that the repaired candidates pass
  every seed.
- New general reduction: sign-compatible source/sink vertices give exact
  positive cone isomorphisms by binomial substitution. Ordinary mass becomes
  a weighted objective, so no unjustified mass-invariance corollary is used.

## Computation scope and independent checks

All stored candidate tables are checked by exact integer binomial division.
Rationalized LP duals are checked against every globally admissible packet
meeting their finite support. Modular rank is exact, not floating-point rank.
The rank4 two-minimum face was additionally computed with an exact SymPy
nullspace and a primitive integer parameter interval. The rank5 failure was
independently checked by direct rational substitutions in SymPy, bypassing
the packet division implementation.

The Wolfram Language plugin independently verified the A3 global mass dual:
mass27, dual bound27, all coefficient slacks and packet slacks nonnegative,
30 global packet checks. The plugin returned harmless undefined-symbol
warnings together with the exact valid result; the original output is saved
without omitting those warnings.

Transport resource cutoffs are recorded in every summary. In the non-CM
partial scan they include1199 large-exponent branches and802 large-support
branches. A pruned branch is never counted as an all-path pass.
