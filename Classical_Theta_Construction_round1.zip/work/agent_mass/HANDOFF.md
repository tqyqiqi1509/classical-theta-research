# Second-wave handoff: mass selection and finite packet potentials

Time: 2026-11-13 approximately04:44--05:15UTC. Parent task remains active.
Work directory: `work/agent_mass/`. No other agent's files were modified.

## Main outcomes to retain

1. **General finite-potential theorem.** A finite rational/integer potential
   on the positive binomial packet equations can be checked against the
   entire infinite exponent cone by inspecting only packets touching its
   support. It gives a global lower bound, not just a finite-box optimum.
   At exact mass equality, all minimum solutions have finite support forced
   by the dual; zero-slack full column rank gives uniqueness. Full proofs in
   `FINITE_PACKET_DUALITY.md`.

2. **Finite mutation-tree extension.** Source and target binomial packets
   on each mutation edge share one nonnegative multiplicity. Finite duals
   on this system still admit global checks over all exponent degrees.
   Implementation: `finite_atlas_cone.py`.

3. **The naive one-chart minimum-mass rule is genuinely false.** Two exact
   skew-symmetric, provably non-CM labels settle both uniqueness and
   covariance issues. They are not merely artificially bounded searches:

   - Rank4 chain B12=4,B23=B34=1,g=(-1,1,1,1): global minimum25 has exactly
     two integer solutions. The full zero-slack affine face has primitive
     integer parameter interval[-1,0]. One candidate has a negative quotient
     after(3,4). Adding the mutation3 node removes it and leaves the other
     at the same mass25.
   - Rank5 chain B12=2,B23=B34=B45=1,g=(-2,2,-1,1,1): global minimum44 is
     unique, certified by dual44 and772 zero-slack columns of rank772 modulo
     1000003. After(3,4), it has a negative reset exponent. Independent SymPy
     direct rational substitution gives reduced denominator y4. Adding the
     mutation3 node raises the certified optimum to46.

   These disprove the local mass proposal, not the full Li--Pan construction
   and not the main possibility of a high-rank greedy/theta construction.

4. **Fixed-mass cutting-plane mechanism.** The parent's observation is now
   proved in `FIXED_MASS_CUTTING_PLANES.md`: an exact finite dual at mass C
   forces a finite root carrier for every later surviving mass-C candidate.
   More mutation constraints cannot create new mass-C candidates outside it.
   Each finite failure word removes one of finitely many candidates. This
   closes the central-tail escape issue for a fixed phase. An all-seed
   acceptance/stopping certificate remains missing.

5. **General source/sink cone isomorphism.** For a sink k with g_k=-a<=0,

   `F=(1+y_k)^a H(y_j(1+y_k)^(-b_kj))`

   is a bijection of normalized local positive cones with the smaller matrix.
   The inverse is y_k=0 and normalized mutation sends F to H. A source with
   g_k>=0 is simply frozen. Complete positive binomial proof for arbitrary
   skew-symmetrizable B is in `SOURCE_SINK_REDUCTION.md`. Mass becomes a
   weighted evaluation, so ordinary-mass invariance does not follow.

6. **Do not inherit the withdrawn rank2 leastness inference.** LLZ
   Proposition1.5 has alternating-sign right sides. It does not immediately
   imply coefficientwise leastness by monotone induction. The source/sink
   cone theorem is independent and remains proved; propagation of a least
   element is only conditional on having one in the smaller cone.

## Exact data files

- `rank4_all_mass_minima.json`: both mass25 candidates, global dual,
  zero-slack column list, exact primitive nullvector and interval.
- `rank4_same_mass_cut.json`: the two-chart repair at unchanged mass25.
- `noncluster_failure_00355.json`: unique mass44 candidate, global dual,
  modular rank certificate and exact failure location.
- `independent_sympy_minimum_failure.json`: independent first-neighbor and
  two-step rational substitution check of the rank5 failure.
- `noncluster_two_chart_repair.json`: new mass46 candidate and global dual46.
- `leastness_failure_0089_001.json`: earlier valued rank4 failure of
  coefficientwise leastness, with global minimum65 and a larger mass68
  candidate that lowers one coefficient. Difference:
  `H-F=y1*y2*y4*((1+y2)^2*y4^2-1)`.
- `two_chart_repair_certificate.json`: an eight-potential ±1 certificate
  restoring the missing coefficient inequality in that valued example.
- `a3_mass_certificate.json`: basic finite-potential and uniqueness example;
  Wolfram independently checked its global dual27.

## Code entry points

`packet_minimum.py`:

- `build(B,g,points)` builds the finite coefficient/packet matrix.
- `solve(B,g,L,shape='box',...)` discovers and exactly verifies a candidate.
- `exact_global_dual(M,z,weight=None)` checks a zero-extended finite dual on
  **all** touching global packets. A failed check is a failed certificate.
- `solve_global_dual(M,weight=None,...)` explicitly includes the touching
  global packet inequalities and then checks the rational result.
- `uniqueness_from_dual(M,cert,mass,prime=1000003)` proves uniqueness when the
  exact zero-slack column matrix has full rank modulo the prime.

`finite_atlas_cone.py`:

- `build_atlas(B,g,points,words)` builds the finite mutation-tree system.
- `global_dual(M,weight=None,...)` and `exact_dual(...)` perform global
  finite-potential certification for that tree.
- `solve_atlas(B,g,L,words,...)` returns `(report,F,M)`.
- Default cost is root mass. A callable `weight(t,p)` permits another node's
  mass or a coefficient lower bound. All costs used are nonnegative.

`scan_noncluster_family.py` also provides `acyclic_carrier(B,g,cap=...)` for
upper-positive acyclic matrices; it enumerates the **whole** normalized
carrier via triangular inequalities, not a guessed box.

No computation session remains running. The broad non-CM scan was
deliberately interrupted after the mass hypothesis was conclusively refuted.

## Computation totals and their proper interpretation

- Initial broad scan:504 matrix/label instances,1119 finite cone solves,
  254 feasible candidates;252 exact global mass bounds,242 global uniqueness
  certificates;16518 transport steps. CM classification was unknown.
- Coefficient leastness scan:219 candidates,2119 coefficient dual searches,
  2056 exact successful lower bounds;212 candidates certified coefficientwise
  least in their local cone. A failed dual search is not itself a counterexample.
- Weighted two-chart scan:955 exact optimizations on217 candidates; no
  counterexample in that first batch.
- Non-CM structural scan:476 completed instances (324 rank4,152 rank5),
  416 feasible,368 global mass certificates,343 uniqueness certificates,
  23067 transport steps.277 feasible cases had source/sink irreducible core
  rank>=3;219 of those had full joint variable support. Eight finite transport
  failures were found, with the two rigorous representative conclusions above.
- Non-CM resource cutoffs:1199 large-exponent branches and802 large-support
  branches. These branches were not verified. Sixty domains had no candidate
  in the chosen finite domain; no general nonexistence claim was made.

All statistics are in the corresponding summary JSONs, especially
`noncluster_partial_summary.json`. The rank5 repaired mass46 candidate's
depth-four check had225 actual steps and no pruning; it is still only a
finite check. The rank4 repaired candidate's depth-five test had27 pruned
branches and therefore must not be described as an unpruned pass.

## Most productive next task

Attack a **finite all-seed acceptance criterion for the multichart packet
minimum**, or prove a mutation rule for an optimal potential that certifies
the next chart without searching indefinitely. The single-chart mass
statement is false and must not be retried.

An especially concrete interface is common principal pointedness. In the
rank5 failure, the original acyclic carrier already has only163 points:
p1<=2,p2<=4,p3<=5,p4<=5,p5<=5. It is the cross-seed normalization, not an
unbounded original support, that fails. One could examine precise
copointed/bipointed and injective-reachable theorems, but no theorem reducing
all-seed pointedness to two specified charts has been established here.

Primary-source review notes and withdrawn implications are in
`LITERATURE_AND_ROUTE_LOG.md`. No2026 paper was used without the noted audit
scope; the newly found Tang polytope criterion was not adopted as a theorem.
