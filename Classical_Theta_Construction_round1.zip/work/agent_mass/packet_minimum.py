#!/usr/bin/env python3
"""Sparse packet cone and finite-support global LP dual certificates.

All solver discoveries are rechecked using exact integer/rational arithmetic.
The full cone has an a_p variable only on the normalized one-step carrier;
the rows are the fiber convolution equations for every direction and p.
A dual with finite support can be checked against *all* infinite-cone columns.
This is stronger than certifying a merely boxed optimum.
"""
from __future__ import annotations
from itertools import product
from math import comb
from fractions import Fraction
from collections import defaultdict
import sys, pathlib, json, random, time
import numpy as np
from scipy.sparse import coo_matrix, vstack
from scipy.optimize import linprog, milp, Bounds, LinearConstraint

OLD=pathlib.Path(__file__).resolve().parents[1]/'agent_polytope'
sys.path.insert(0,str(OLD))
from normalized_fibers import in_container, all_neighbors, mutate

def dump_table(F):return [{'p':list(p),'a':int(a)} for p,a in sorted(F.items())]
def load_table(F):return {tuple(x['p']):int(x['a']) for x in F}

def simplex(n,L,prefix=()):
    if n==0:
        yield prefix;return
    for a in range(L+1):yield from simplex(n-1,L-a,prefix+(a,))

def packet_degree(B,g,k,off):
    p=off[:k]+(0,)+off[k:]
    return max(0,-g[k]-sum(B[k][j]*p[j] for j in range(len(g))))

def carrier_points(B,g,L,shape='box'):
    raw=product(range(L+1),repeat=len(g)) if shape=='box' else simplex(len(g),L)
    return sorted(p for p in raw if in_container(B,g,p))

def build(B,g,points):
    n=len(g); points=sorted(set(points));ids={p:i for i,p in enumerate(points)}
    if (0,)*n not in ids:raise ValueError('missing origin')
    rowids={(k,p):k*len(points)+i for k in range(n) for i,p in enumerate(points)}
    rr=[];cc=[];vv=[]; colkeys=[('a',p) for p in points]
    for (k,p),row in rowids.items():rr.append(row);cc.append(ids[p]);vv.append(1)
    fibers=[defaultdict(list) for k in range(n)]
    for k in range(n):
        for p in points:fibers[k][p[:k]+p[k+1:]].append(p[k])
        for off,ss in fibers[k].items():
            d=packet_degree(B,g,k,off);sset=set(ss)
            for s in ss:
                if not all(s+j in sset for j in range(d+1)):continue
                col=len(colkeys);colkeys.append(('q',k,off,s,d))
                for j in range(d+1):
                    p=off[:k]+(s+j,)+off[k:]
                    rr.append(rowids[k,p]);cc.append(col);vv.append(-comb(d,j))
    normrow=len(rowids);rr.append(normrow);cc.append(ids[(0,)*n]);vv.append(1)
    A=coo_matrix((np.asarray(vv,float),(rr,cc)),shape=(normrow+1,len(colkeys))).tocsc()
    b=np.zeros(normrow+1);b[-1]=1
    c=np.zeros(len(colkeys));c[:len(points)]=1
    return {'B':B,'g':g,'points':points,'ids':ids,'rows':rowids,'columns':colkeys,'A':A,'b':b,'c':c}

def exact_primal(M,x):
    if x is None:return None
    z=[int(round(v)) for v in x]
    if any(v<0 for v in z):return None
    F={p:z[i] for i,p in enumerate(M['points']) if z[i]}
    ok,err=all_neighbors(M['B'],M['g'],F)
    if not ok or F.get((0,)*len(M['g']))!=1:return None
    # Convolution verification independent of the rounding residual.
    return F

def exact_global_dual(M,dual,max_den=100000,weight=None):
    """Zero-extend row dual and check every infinite packet touching it.
    a_p columns obey sum_k lambda(k,p)+mu*1[p=0]<=1 on carrier.
    q_(k,off,s) columns obey sum_j binom(d,j)lambda(k,off,s+j)>=0.
    Any other column sees only zero and is automatically valid.
    """
    if weight is None:weight=lambda p:1
    n=len(M['g']); lam={key:Fraction(float(dual[row])).limit_denominator(max_den)
                         for key,row in M['rows'].items() if abs(dual[row])>1e-10}
    mu=Fraction(float(dual[-1])).limit_denominator(max_den)
    for p in {p for k,p in lam}|{(0,)*n}:
        if in_container(M['B'],M['g'],p):
            value=sum((lam.get((k,p),Fraction(0)) for k in range(n)),Fraction(0))
            if p==(0,)*n:value+=mu
            if value>weight(p):return {'valid':False,'kind':'coefficient','p':p,'lhs':str(value),'rhs':str(weight(p))}
    touched=defaultdict(set)
    for (k,p),v in lam.items():
        off=p[:k]+p[k+1:];d=packet_degree(M['B'],M['g'],k,off)
        for s in range(max(0,p[k]-d),p[k]+1):touched[k,off,d].add(s)
    checks=0;violations=[]
    for (k,off,d),starts in touched.items():
        for s in starts:
            # A positive packet crossing outside the normalized carrier is
            # forced to have zero weight, so is not a cone generator.
            if not all(in_container(M['B'],M['g'],off[:k]+(s+j,)+off[k:])
                       for j in range(d+1)):continue
            checks+=1
            value=sum((comb(d,j)*lam.get((k,off[:k]+(s+j,)+off[k:]),Fraction(0))
                       for j in range(d+1)),Fraction(0))
            if value<0:
                violations.append({'k':k,'off':off,'s':s,'d':d,'lhs':str(value)})
                if len(violations)>=30:break
        if len(violations)>=30:break
    result={'valid':not violations,'mu':str(mu),'bound':float(mu),'nonzero_rows':len(lam),
            'packet_checks':checks,'violations':violations}
    if not violations:
        result['certificate']={'mu':[mu.numerator,mu.denominator],
                              'lambda':[{'k':k,'p':p,'value':[v.numerator,v.denominator]}
                                        for (k,p),v in sorted(lam.items())]}
    return result

def solve_global_dual(M,seconds=10,weight=None):
    """Maximize a finite-row-support dual, with *all* touching global packets.
    The optimization is finite even if the normalized carrier is unbounded.
    """
    if weight is None:weight=lambda p:1
    n=len(M['g']);nr=len(M['rows'])+1;rr=[];cc=[];vv=[];rhs=[]
    row=0
    for p in M['points']:
        for k in range(n):rr.append(row);cc.append(M['rows'][k,p]);vv.append(1)
        if p==(0,)*n:rr.append(row);cc.append(nr-1);vv.append(1)
        rhs.append(float(weight(p)));row+=1
    touched=defaultdict(set)
    for k,p in M['rows']:
        off=p[:k]+p[k+1:];d=packet_degree(M['B'],M['g'],k,off)
        for s in range(max(0,p[k]-d),p[k]+1):touched[k,off,d].add(s)
    for (k,off,d),ss in touched.items():
        for s in ss:
            packet=[off[:k]+(s+j,)+off[k:] for j in range(d+1)]
            if not all(in_container(M['B'],M['g'],p) for p in packet):continue
            for j,p in enumerate(packet):
                col=M['rows'].get((k,p))
                if col is not None:rr.append(row);cc.append(col);vv.append(-comb(d,j))
            rhs.append(0);row+=1
    A=coo_matrix((np.array(vv,float),(rr,cc)),shape=(row,nr)).tocsc()
    c=np.zeros(nr);c[-1]=-1
    result=linprog(c,A_ub=A,b_ub=rhs,bounds=(None,None),method='highs',
                   options={'time_limit':seconds})
    if result.x is None:return {'valid':False,'global_dual_status':int(result.status)}
    return exact_global_dual(M,result.x,weight=weight)

def uniqueness_from_dual(M,cert,mass,prime=1000003):
    """Full column rank modulo a prime proves uniqueness over Q.
    Only zero-dual-slack columns can occur in any mass-optimal solution.
    Positive slack outside the finite row support proves all such solutions
    are supported on M['points'], regardless of the initial search domain.
    """
    if not cert.get('valid') or Fraction(cert['mu'])!=mass:return None
    C=cert['certificate'];mu=Fraction(*C['mu'])
    lam={(z['k'],tuple(z['p'])):Fraction(*z['value']) for z in C['lambda']}
    keep=[];n=len(M['g']);nr=len(M['rows'])
    for col,key in enumerate(M['columns']):
        if key[0]=='a':
            p=key[1];slack=1-sum((lam.get((k,p),Fraction(0)) for k in range(n)),Fraction(0))
            if p==(0,)*n:slack-=mu
        else:
            _,k,off,s,d=key
            slack=sum((comb(d,j)*lam.get((k,off[:k]+(s+j,)+off[k:]),Fraction(0))
                       for j in range(d+1)),Fraction(0))
        if slack<0:raise AssertionError('invalid dual slack')
        if slack==0:keep.append(col)
    pivots={}
    for col in keep:
        key=M['columns'][col]
        if key[0]=='a':
            p=key[1];v={M['rows'][k,p]:1 for k in range(n)}
            if p==(0,)*n:v[nr]=1
        else:
            _,k,off,s,d=key
            v={M['rows'][k,off[:k]+(s+j,)+off[k:]]:(-comb(d,j))%prime for j in range(d+1)}
        while v:
            row=min(v);a=v[row]
            if row not in pivots:
                inv=pow(a,-1,prime);v={r:(z*inv)%prime for r,z in v.items()};pivots[row]=v;break
            pivot=pivots[row]
            for r,z in pivot.items():
                new=(v.get(r,0)-a*z)%prime
                if new:v[r]=new
                elif r in v:del v[r]
    return {'unique':len(pivots)==len(keep),'zero_slack_columns':len(keep),
            'rank_mod_prime':len(pivots),'prime':prime,
            'global_support_bound':len(M['points'])}

def solve(B,g,L,shape='box',seconds=10,alternatives=0,check_transport_depth=0):
    points=carrier_points(B,g,L,shape);M=build(B,g,points)
    tic=time.time();lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',
                              options={'time_limit':seconds})
    result={'B':B,'g':g,'L':L,'shape':shape,'points':len(points),'variables':len(M['columns']),
            'lp_status':int(lp.status),'lp_fun':None if lp.fun is None else float(lp.fun)}
    F=exact_primal(M,lp.x)
    if lp.x is not None and lp.eqlin.marginals is not None:
        result['dual']=exact_global_dual(M,lp.eqlin.marginals)
        if not result['dual']['valid']:
            result['initial_dual_failure']=result['dual'];result['dual']=solve_global_dual(M,seconds)
    if F is None:
        mi=milp(M['c'],integrality=np.ones(len(M['columns'])),bounds=Bounds(0,np.inf),
                constraints=LinearConstraint(M['A'],M['b'],M['b']),options={'time_limit':seconds})
        result['milp_status']=int(mi.status);F=exact_primal(M,mi.x)
    result['seconds']=time.time()-tic
    if F is None:return result,None
    C=sum(F.values());result.update({'mass':C,'support':len(F),'F':dump_table(F)})
    result['global_mass_minimum_certified']=result.get('dual',{}).get('valid',False) and \
        Fraction(result['dual']['mu'])>C-1
    result['uniqueness']=uniqueness_from_dual(M,result.get('dual',{}),C)
    if alternatives:
        massrow=coo_matrix((np.ones(len(points)),(np.zeros(len(points),int),np.arange(len(points)))),
                          shape=(1,len(M['columns']))).tocsc()
        A=vstack([M['A'],massrow]).tocsc();b=np.r_[M['b'],C]
        rng=np.random.default_rng(20261113); alts=[]
        for _ in range(alternatives):
            c=np.zeros(len(M['columns']));c[:len(points)]=rng.integers(-50,51,size=len(points))
            ar=milp(c,integrality=np.ones(len(M['columns'])),bounds=Bounds(0,np.inf),
                    constraints=LinearConstraint(A,b,b),options={'time_limit':seconds})
            F2=exact_primal(M,ar.x)
            if F2 is not None and F2!=F and F2 not in alts:alts.append(F2)
        result['alternatives']=[dump_table(H) for H in alts]
    return result,F

def random_transport(B,g,F,rng,walks=20,length=10,max_terms=25000,max_bits=100000):
    counts={'steps':0,'truncated_terms':0,'truncated_bits':0,'walks':walks,'length':length}
    for trial in range(walks):
        BB=B;gg=tuple(g);FF=F;word=[];last=None
        for step in range(length):
            options=[k for k in range(len(g)) if k!=last];k=rng.choice(options)
            state,err=mutate(BB,gg,FF,k)
            counts['steps']+=1;word.append(k)
            if err:return counts,{'word':word,'error':err,'last_F':dump_table(FF),'last_B':BB,'last_g':gg}
            BB,gg,FF=state;last=k
            if len(FF)>max_terms:counts['truncated_terms']+=1;break
            if any(abs(a).bit_length()>max_bits for a in FF.values()):counts['truncated_bits']+=1;break
    return counts,None

if __name__=='__main__':
    B=[[0,1,-1],[-1,0,1],[1,-1,0]];g=(-1,-1,-1)
    result,F=solve(B,g,3,alternatives=3)
    print(json.dumps(result,indent=2))
