# Exact source/sink reduction of the normalized local packet cone

This is a general integer-combinatorial reduction, independent of scattering
diagrams, broken lines, or geometric representation theory. It does not by
itself prove global mutation covariance of a selected basis.

Use the local cone K(B,g) defined in FINITE_PACKET_DUALITY.md. Matrix conventions
are those of the existing exact engine: a term at p has mutable exponent
g+Bp, and the local support inequality in direction k is

`p_k <= [-g_k]_+ + sum_j[-b_kj]_+p_j`.

## Sink with nonpositive label

Suppose `b_jk>=0` for all j, equivalently `b_kj<=0`, and write g_k=-a with a>=0.
Put `v_j=-b_kj>=0`. Delete index k from B and g, obtaining Bbar,gbar.

Then the following maps are inverse positive linear order isomorphisms:

`K(Bbar,gbar) -> K(B,g)`:

`H -> F=(1+y_k)^a H(y_j(1+y_k)^(v_j): j!=k)`,

and `F -> H=F|_(y_k=0)`.

### Necessity and uniqueness of the lift

On each k-fiber, r=-a-sum_j v_j p_j<=0 and

`d=-r=a+sum_jv_jp_j=alpha`.

The positive quotient condition and the normalized degree bound therefore
force the quotient to be constant. This gives precisely the displayed lift.
At p_k=0, every other positive fiber condition and support inequality becomes
the corresponding condition for Bbar,gbar. Hence H belongs to the smaller
cone.

### Sufficiency

Fix j!=k and all coordinates except p_j and p_k. Write the corresponding
j-fiber of H as

`P(u)=(1+u)^d Q(u)`, `Q>=0`,

where d=[-r0]_+. Put A=a+sum_(l!=j,k)v_l p_l>=0 and v=v_j.
The p_k=m slice of the lift is

`[t^m](1+t)^A (1+u(1+t)^v)^d Q(u(1+t)^v)`.

If v=0, then b_jk=0 and the old positive quotient is unchanged up to a
nonnegative scalar. If v>0, then b_jk=w is a positive integer. Expand

`1+u(1+t)^v=(1+u)+u((1+t)^v-1)`.

A term using h copies of the second summand has t-degree at least h; thus
only h<=m contributes. Its u-polynomial is divisible positively by
`(1+u)^[d-m]_+`. The required exponent in the lifted j-fiber is

`[-r0-w*m]_+ <= [d-m]_+`,

because w>=1. Therefore the desired positive division holds. The u-degree
does not increase under coefficient extraction, so the smaller cone's
normalized j-degree bound also remains valid; the k-coordinate contributes
nothing to that bound because b_jk>=0.

This proves sufficiency for arbitrary skew-symmetrizable B. Unequal values of
v_j and b_jk cause no problem; no symmetry assumption was used.

## Source with nonnegative label

If `b_kj>=0` for all j and g_k>=0, the normalized k-bound is p_k<=0. Therefore
F is independent of y_k. The k-positive-division condition is automatic,
because `r=g_k+sum_jb_kj p_j>=0`. Every other condition is exactly the smaller
one. Thus deletion and insertion of an unused variable identify the cones.

## Relation to mutation

For the sink/nonpositive case, mutation k changes the label to

`g'_k=a`, `g'_j=g_j` for j!=k,

leaves the principal submatrix on the other vertices unchanged, and sends F
to H by the exact normalized fiber formula. The new k-vertex is a source
with nonnegative label. Thus this source/sink pair is a genuine mutation
equivalence of local cones, not merely an implication in one direction.

## What it does and does not preserve

The maps preserve coefficientwise order, because both lift and evaluation
y_k=0 have nonnegative coefficients. Therefore, **if** a coefficientwise least
element exists in the smaller cone, its lift is least in the larger cone.
The statement is conditional; no unrestricted least-element theorem is used.

Ordinary coefficient mass changes to

`F(1,...,1)=2^a H(2^(v_j):j!=k)`.

So ordinary mass minimization becomes a weighted evaluation objective in the
smaller cone. A mass minimum alone need not be preserved without an additional
weighted-minimality theorem. This is exactly the issue that the new finite
packet duals can test and certify.

Repeated reductions are finite and yield explicit products and substitutions
with positive integer binomial weights. They provide a combinatorial lift from
an irreducible core. A core of rank at most two connects to the genuine LLZ
recursion after the correct g/denominator coordinate conversion.

**Caution about that endpoint:** LLZ Proposition1.5 supplies inequalities whose
right sides have alternating signs. One cannot conclude a global
coefficientwise least property simply by monotone induction. The current agent
has not independently closed that stronger rank-two local-cone assertion, so
the conditional least-element propagation above must not be promoted to an
unconditional arbitrary-rank theorem.

This reduction also helps classify computation: a large-rank example that
reduces to rank two is recorded separately from a genuine core of rank>=3.
Failure to find a mutation leading to such a reduction is not a certificate
that none exists.
