# Finite integer potentials for positive packet constraints

Research session: 2026-11-13, second agent wave. All statements below concern
classical skew-symmetrizable exchange matrices. No conclusion of Li--Pan is
used. No theta construction, basis theorem, or mutation invariance theorem is
claimed here.

## 1. The infinite local cone

Fix an integral skew-symmetrizable matrix B and g in Z^n. We use

`f=x^g F(y_j x^(B e_j))`, `F=sum_p a_p y^p`, `a_0=1`.

Let

`S={p in N^n: p_k <= [-g_k]_+ + sum_j [-b_kj]_+ p_j, for every k}`.

For direction k and off-k tuple eta, put

`r=g_k+sum_{j!=k} b_kj eta_j`, `d=[-r]_+`.

A positive binomial packet starting at s has coefficients

`binom(d,j)` at `p(eta,s+j)`, for `0<=j<=d`.

Call such a packet admissible if all these points belong to S. Introduce a
nonnegative packet multiplicity `q_(k,eta,s)` for every admissible packet.
The local normalized positive cone consists exactly of the finite-support
nonnegative integer coefficient tables satisfying

`a_p = sum_(s+j=p_k) binom(d,j) q_(k,eta,s)`

for every k,p, together with a0=1. The packet multiplicities in each fiber are
unique, since division by `(1+t)^d` is injective. Packets crossing outside S
must have zero multiplicity: otherwise their positive coefficients would
force a nonzero coefficient outside the normalized support bound.

This formulation is valid at arbitrary rank. The symmetrizer is not needed
inside the formula; its role is to ensure that B is a legitimate classical
exchange matrix.

## 2. A global lower bound with a finite certificate

Let c_p be any nonnegative rational costs. Choose finitely supported rational
potentials lambda_(k,p), with p in S, and a rational mu. Suppose:

1. `sum_k lambda_(k,p) + mu*1_(p=0) <= c_p` for every p in S.
2. For each admissible packet,

   `sum_(j=0)^d binom(d,j) lambda_(k,p(eta,s+j)) >= 0`.

Then every finite normalized local candidate satisfies

`sum_p c_p a_p >= mu`.

### Proof

Multiply each fiber convolution equation by lambda_(k,p), sum, and use a0=1.
One obtains the exact identity

`sum_p c_p a_p - mu`

`= sum_p [c_p-sum_k lambda_(k,p)-mu*1_(p=0)] a_p`

`  + sum_(k,eta,s) q_(k,eta,s) sum_j binom(d,j)lambda_(k,p(eta,s+j))`.

Both sums have nonnegative terms. Every candidate has finite support, so no
exchange of divergent series is involved. This proves the assertion.

### Why verification is finite even when S is unbounded

Outside the finite support of lambda and the origin, coefficient inequalities
are automatic because c_p>=0. A packet not meeting the support of lambda has
zero potential sum. For a supported point p in direction k, a packet that
contains it must have the same off-k tuple eta and starting index

`max(0,p_k-d) <= s <= p_k`.

There are finitely many such packets. Checking their admissibility and their
potential sums uses only integer binomial coefficients and rational arithmetic.
After clearing common denominators, the certificate has only integer weights.

This is an explicit specialization of linear-programming weak duality to the
infinite positive-packet system, not a claim of new abstract LP duality.
In particular, a solver's finite-box optimality report is insufficient. The
zero extension of its dual must pass all the additional touching-packet tests.

The implementation initially tried a boxed LP dual. Several such duals fail
the touching-packet check; they are recorded as failed certificates. The
implemented repair solves a second finite LP containing every touching global
packet, then verifies its rationalized output exactly. No dual completeness or
unconditional finite-support dual existence theorem has been proved.

## 3. The same certificate can force finite support and uniqueness

Take c_p=1. Suppose a candidate F has mass C=sum a_p and a verified finite
potential certificate has mu=C. Every term on the right of the identity is
then zero for every mass-C candidate.

For p outside the finite support of lambda and outside the origin, the
coefficient slack is exactly 1. Hence **every global mass-minimizer is
supported in the finite support of lambda together with the origin**.

This conclusion does not assume that S is bounded, and it does not assume a
Newton carrier in advance. It can be much smaller than the elementary
mass-simplex bound `|p|_1<=C-1`.

Furthermore, every variable with strictly positive dual slack vanishes at an
optimum. Restrict the finite packet equations and a0=1 to the remaining
zero-slack columns. Full column rank implies that the optimum is unique.
Full column rank modulo a prime proves full column rank over Q; thus it gives
an exact integer certificate without floating-point rank decisions.

If the verified bound is only `C-1<mu<C`, integrality still proves minimum
mass C, but the support and zero-slack uniqueness conclusions do not follow.
The implementation makes this distinction.

## 4. Extension to a finite mutation tree

Choose finitely many mutation words and include their prefixes. At each node
t, calculate B_t,g_t by ordinary integer mutation. Give it a nonnegative
coefficient table a_(t,p), restricted to its local normalized carrier, and all
its local positive-packet equations.

For an edge t --k--> t', a quotient monomial of degree s in a k-fiber produces
the source packet

`t^s (1+t)^d`

and the target packet

`t^(alpha-d-s) (1+t)^e`,

where `d=[-r]_+`, `e=[r]_+`, and

`alpha=[-g_k]_+ + sum_j[-b_kj]_+ eta_j`.

Use one nonnegative integer q for both packets. Thus source and target tables
are linked by exact linear equations. This gives a finite mutation-tree cone
whose mathematical exponent domains are still infinite.

Finite potentials can be placed on all these coefficient equations. A packet
column receives the sum of the source and target weighted binomial potentials.
The same weak-duality identity proves a lower bound on any nonnegative linear
objective, for example the mass in the root chart, the mass in a chosen
neighbor, or a single root coefficient.

Again only finitely many packets meet the potential support. On a mutation
edge, for a fixed off-k tuple the allowable starts satisfy
`0<=s<=alpha-d`; the source and target degrees determine all possibilities.
The global certificate checker enumerates these starts and checks both
carriers. This is not a check restricted to the search boxes.

The root-mass zero-slack argument still forces finite root support if mu=C.
The tables at the other finitely many nodes are then uniquely determined by
exact mutation of the root table. No theorem asserting that a finite mutation
tree suffices for all seeds has been established.

## 5. A precise limitation of single-chart selection and its repair

The normalized local cone need not have a coefficientwise least element.
Here is a verified certificate of that fact in the valued case:

`B=[[0,0,-1,1],[0,0,0,-1],[1,0,0,-1],[-2,3,2,0]]`,

`D=diag(2,3,2,1)`, `g=(-1,1,2,-2)`.

The full coefficient tables F,H are in
`leastness_failure_0089_001.json`. Both satisfy every initial positive
binomial quotient condition and every initial reset-degree bound. F has
mass 65, with a verified finite-potential global lower bound mu=65. H has
mass 68. At p=(1,1,0,1), the coefficient of F is 1 and that of H is 0.

If a least element L existed, L<=F would imply mass(L)<=65. Global minimum
mass is 65, so L=F coefficientwise. But F is not <=H. This proves the claim
without needing uniqueness of the mass minimizer.

The difference is especially simple:

`H-F = y1*y2*y4*((1+y2)^2*y4^2-1)`.

H is not a mass minimum. It fails after mutations 2,4, so this is **not** a
counterexample to the proposed minimum-mass selection rule and **not** a
counterexample to the full Li--Pan construction.

Adding the node reached by mutation 2 and all its local packet constraints
repairs exactly the missing lower coefficient bound. The finite-tree dual in
`two_chart_repair_certificate.json` proves `a_(1,1,0,1)>=1` with eight potentials
equal to +1 or -1. There is also a verified mass lower bound 65 on this tree.
The coefficient inequality has a short direct explanation:

1. The initial direction-1 zero fiber gives a1000=1.
2. After mutation 2, a'1000=1.
3. In that chart, direction 4 has r=-1 on the relevant fiber, forcing
   a'1001>=a'1000=1.
4. The mutation-2 fiber reversal identifies a'1001 with initial a1101.

The general lesson is constructive: multi-step compatibility can be encoded
by additional finite packet variables and detected by finite integer
potentials. The example is a diagnostic of that mechanism, not a substitute
for the arbitrary-rank goal.

## 6. What remains needed for the main goal

The finite potentials give independently checkable lower bounds, support
bounds, and sometimes uniqueness. They do not yet provide any of the
following general statements:

- existence of a finite candidate for every intended label;
- existence of a finite potential attaining its minimum;
- invariance of the minimum-mass candidate under every mutation;
- a finite rule deciding which mutation-tree constraints suffice;
- a theta identification, linear basis theorem, or positive multiplication.

Subsequent computation refuted the single-chart minimum-mass proposal itself:
the four-vertex example in FIXED_MASS_CUTTING_PLANES.md has two distinct global
mass minima, and the five-vertex example has a globally unique mass minimum
which loses normalization after two steps. Thus the next proof problem must
use the multi-chart cone, not attempt to prove the false local statement.
The finite-potential method survives and gives a fixed-mass finite-candidate
phase as explained in that companion note. Its all-seed acceptance test is
still missing.
