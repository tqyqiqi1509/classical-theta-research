# Finite candidate phases from exact packet duals

This records a general constructive consequence suggested by the parent
agent and made precise here. It uses the exact finite-potential theorem in
FINITE_PACKET_DUALITY.md. It is not a complete algorithm for the theta basis.

## Setup

For a finite set W of mutation words, let K_W(B,g) be the finite-support
integer coefficient tables which are positive normalized polynomials at the
specified nodes and satisfy the specified positive packet equations. The
implementation includes every local direction at each node in W, together
with all source/target packet matching equations on the prefix tree.

Fix a candidate F of mass C. Suppose there is a finite supported dual with
root mass objective and value **exactly C**. Let T be the finite set of root
coefficient positions appearing in the dual support, together with zero.

## Fixed-mass phase theorem

Every candidate in K_W of mass C is supported on T. If W is enlarged to W',
the same dual is still a valid lower bound, because K_W' is a subcone of K_W.
Consequently every surviving mass-C candidate in every later constraint set
is still supported on T.

There are finitely many such nonnegative integer coefficient tables with
a0=1. A crude bound, when T has q elements, is

`binom(C+q-2,q-1)`.

The positive packet equations and inequalities select a finite subset of
these tables. If a tested candidate develops a negative quotient, a nonzero
division tail, or a negative normalized exponent at some finite word, adding
that word's exact packet constraints removes it permanently. Every strict
exclusion decreases the finite candidate set. Thus a fixed-C phase cannot
generate infinitely many different candidates by escaping along an unbounded
central Newton direction.

If the candidate list at mass C becomes empty, it is valid to increase the
mass lower bound. An explicit dual at the next phase may jump several
integer mass values at once.

## Conditional bounded number of mass phases

If a genuine globally normalized positive finite candidate of mass Cstar is
known, and finite duals attaining the actual integer optimum exist whenever a
new phase is entered, the optimum cannot exceed Cstar. There are at most
Cstar distinct positive integer masses. Together with the fixed-phase
finiteness, this prevents an unbounded sequence of distinct bad candidates
under those hypotheses.

The hypotheses matter. An integer optimum need not coincide with the
rational LP optimum, and finite-support dual attainment for the infinite
coefficient cone is not proved in general. A bound `C-1<mu<C` proves integer
minimum C but does **not** imply the zero-slack support conclusion used here.

## Why this still does not supply a stopping test

Every invalid candidate has a finite failure word, by definition. Enumerating
mutation words will eventually reject each invalid candidate in a finite
list. A valid candidate, however, may have no finite failure and no known
finite acceptance certificate. Even if only one candidate remains, it is not
legitimate to stop merely because all paths examined so far pass.

One still needs a finite all-seed certificate: for example a genuinely
mutation-closed combinatorial realization, a finite invariant family of
positive packet models, or an independently proved comparison with a known
universally normalized positive construction. A bounded-degree signature
theorem alone does not control all degrees that can appear in distant seeds.

## Complete finite-phase demonstrations found in this run

### A fixed mass with two candidates

For the skew-symmetric four-vertex chain with B12=4, B23=B34=1, and
g=(-1,1,1,1), the local minimum mass is 25. The exact global dual leaves
142 zero-slack variables. The exact rational matrix has one-dimensional
kernel, and its primitive integer parameter runs over [-1,0]. Therefore
there are precisely two integer mass minima.

One has a negative quotient after the word (3,4). Adding the node reached
by mutation3 and its local constraints removes that candidate and retains
the other at the same mass25. Data and exact nullvector are in
`rank4_all_mass_minima.json` and `rank4_same_mass_cut.json`.

### A strict mass increase

For the skew-symmetric five-vertex chain with B12=2 and
B23=B34=B45=1, and g=(-2,2,-1,1,1), the local mass minimum44 is globally
unique. The exact finite dual value is44; the zero-slack matrix has772
columns and rank772 modulo1000003.

That candidate loses polynomial normalization after (3,4). Independent
SymPy rational substitution confirms that all five first mutations are
positive polynomials, whereas the two-step expression has reduced
denominator y4. Thus the failure is specifically normalized polynomialness,
not a claim of ordinary Laurent negativity.

Adding the mutation3 node raises the optimum to46; a separate finite global
dual has value46. The new candidate passes the recorded depth-four test,
but that finite test is not an all-seed theorem. Files:
`noncluster_failure_00355.json`, `independent_sympy_minimum_failure.json`,
`noncluster_two_chart_repair.json`.

Both labels are provably non-cluster-monomial labels: their restriction to
the first two vertices is (-m,m) for an r-Kronecker submatrix, r>=2. The
rank-two g-fan excludes this ray (affine when r=2, inside the imaginary gap
when r>2); freezing a cluster monomial would give a cluster monomial on this
submatrix. This is an external classification input, not a conclusion from
bounded search.
