"""Track universal finite cluster coefficient jets by images of initial x_i.

No inactive branch pruning is made. Universal jets distinguish transforms
independently of one possibly exceptional g-label. The x_i images determine the
full formal algebra automorphism, so all g-matrices of coefficient transforms can
be reconstructed without revisiting the seed graph.
"""
from pathlib import Path
import sys,time
from collections import deque
from functools import lru_cache
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'agent_division'))
from atlas_bfs_study import total_exponents
from truncated_atlas import symmetrizer
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E
from positive_cuts import generalized_binomial

def universal_graph(B,degree,maxdepth,seed_cap=250000,bit_cap=2048):
    n=len(B);D=symmetrizer(B);ee=total_exponents(n,degree);idx={p:i for i,p in enumerate(ee)}
    unit=(1,)+(0,)*(len(ee)-1);H0=(unit,)*n;E0=initial_E(B)
    HH=[H0];hindex={H0:0};words=[()];cache={}
    q=deque([(E0,0,(),-1)]);seen={E0:0};levels={};pruned_bits=0;pruned_limit=0
    dup=0;signchecks=0;start=time.time();edges=set()
    while q:
        E,tid,word,last=q.popleft();lev=len(word)
        levels[lev]=levels.get(lev,0)+1
        if lev>=maxdepth:continue
        for k in range(n):
            if k==last:continue
            EE=mutate_matrix(E,k)
            if max(abs(a).bit_length()for row in EE for a in row)>bit_cap:
                pruned_bits+=1;continue
            c=tuple(E[n+i][k]for i in range(n));alpha=tuple(abs(a)for a in c);signchecks+=1
            if any(a>0 for a in c)and any(a<0 for a in c):raise AssertionError('c sign')
            if sum(alpha)>degree:ntid=tid
            else:
                key=(tid,c,D[k]);ntid=cache.get(key)
                if ntid is None:
                    coeff=[]
                    for h in range(n):
                        out=list(HH[tid][h])
                        for ip,p in enumerate(ee):
                            lim=min(p[i]//alpha[i]for i in range(n)if alpha[i])
                            if not lim:continue
                            num=sum(c[i]*D[i]*(int(i==h)+sum(B[i][j]*p[j]for j in range(n)))for i in range(n))
                            assert num%D[k]==0;r=num//D[k]
                            for j in range(1,lim+1):
                                p0=tuple(p[i]-j*alpha[i]for i in range(n))
                                out[ip]+=generalized_binomial(r,j)*HH[tid][h][idx[p0]]
                        coeff.append(tuple(out))
                    H=tuple(coeff);ntid=hindex.get(H)
                    if ntid is None:
                        ntid=len(HH);hindex[H]=ntid;HH.append(H);words.append(word+(k,))
                    cache[key]=ntid
            edges.add(tuple(sorted((tid,ntid))))
            if EE in seen:
                dup+=1
                if seen[EE]!=ntid:raise AssertionError(('universal duplicate',word+(k,)))
                continue
            if len(seen)>=seed_cap:
                pruned_limit+=1;continue
            seen[EE]=ntid;q.append((EE,ntid,word+(k,),k))
    return {'B':B,'D':D,'degree':degree,'depth':maxdepth,'seeds':len(seen),'jets':len(HH),
            'levels':levels,'duplicate_checks':dup,'sign_checks':signchecks,
            'pruned_seed_limit':pruned_limit,'pruned_bit_limit':pruned_bits,'seconds':time.time()-start},ee,HH,words,sorted(edges)

class JetRing:
    def __init__(self,ee):
        self.ee=ee;self.idx={p:i for i,p in enumerate(ee)};self.n=len(ee[0]);self.N=max(map(sum,ee));self.m=len(ee)
        self.unit=(1,)+(0,)*(self.m-1)
        self.products=[[]for _ in range(self.m)]
        for i,p in enumerate(ee):
            for j,q in enumerate(ee):
                r=tuple(a+b for a,b in zip(p,q));k=self.idx.get(r)
                if k is not None:self.products[k].append((i,j))
    def mul(self,a,b):
        return tuple(sum(a[i]*b[j]for i,j in pairs if a[i]and b[j])for pairs in self.products)
    @lru_cache(maxsize=100000)
    def power(self,a,e):
        assert a[0]==1
        if e==0:return self.unit
        if e==1:return a
        tail=(0,)+a[1:];out=list(self.unit);pwr=self.unit
        for j in range(1,self.N+1):
            pwr=self.mul(pwr,tail);b=generalized_binomial(e,j)
            if b:
                out=[v+b*w for v,w in zip(out,pwr)]
        return tuple(out)
    def transform(self,B,g,H):
        cols=[]
        for q in self.ee:
            z=self.unit
            for i in range(self.n):
                a=g[i]+sum(B[i][j]*q[j]for j in range(self.n))
                z=self.mul(z,self.power(H[i],a))
            col=[]
            for p in self.ee:
                pq=tuple(a-b for a,b in zip(p,q));k=self.idx.get(pq)
                col.append(z[k]if k is not None else 0)
            cols.append(col)
        return tuple(tuple(col[i]for col in cols)for i in range(self.m))

