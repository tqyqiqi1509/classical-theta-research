"""Exact large-label greedy cuts in Q[N], with no numerical interpolation.

A finite list of actual mutation words defines the cut atlas. Completeness is
recorded separately. Polynomial comparisons use their eventual sign, and the
returned shifted-coefficient bounds certify the chosen branch for that finite atlas.
"""
from pathlib import Path
import sys, math, json, time
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agent_division'))
sys.path.insert(0,str(ROOT/'agent_cutcones'))
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E
from truncated_atlas import symmetrizer
from atlas_bfs_study import total_exponents
from universal_atlas import universal_atlas

ZERO=(); ONE=(Q(1),)
def trim(p):
    p=list(p)
    while p and not p[-1]:p.pop()
    return tuple(p)
def add(a,b):
    c=list(a)+[Q(0)]*max(0,len(b)-len(a))
    for i,x in enumerate(b):c[i]+=x
    return trim(c)
def neg(a):return tuple(-x for x in a)
def sub(a,b):return add(a,neg(b))
def scale(a,c):return trim(x*c for x in a)
def mul(a,b):
    if not a or not b:return ZERO
    if len(a)==1:return scale(b,a[0])
    if len(b)==1:return scale(a,b[0])
    c=[Q(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        if x:
            for j,y in enumerate(b):
                if y:c[i+j]+=x*y
    return trim(c)
def eventual_cmp(a,b):
    d=sub(a,b)
    return 0 if not d else 1 if d[-1]>0 else -1
@lru_cache(maxsize=300000)
def eventual_nonnegative_bound(p):
    """Certify positivity by nonnegative coefficients after N=M+t.

    This is exact and usually much sharper than a generic root bound. Once all
    shifted coefficients are nonnegative the property persists for larger M.
    """
    if not p:return 1
    if p[-1]<0:raise ValueError('eventually negative')
    if len(p)==1:return 1
    def good(M):
        return all(sum(p[i]*math.comb(i,j)*M**(i-j) for i in range(j,len(p)))>=0
                   for j in range(len(p)))
    M=1
    while not good(M):M*=2
    lo=1;hi=M
    while lo<hi:
        mid=(lo+hi)//2
        if good(mid):hi=mid
        else:lo=mid+1
    return lo
def evaluate(p,N):
    r=Q(0)
    for c in reversed(p):r=r*N+c
    return r
@lru_cache(maxsize=None)
def binomial_linear(a,b,j):
    p=ONE
    for k in range(j):p=scale(mul(p,(Q(b-k),Q(a))),Q(1,k+1))
    return p

class SymbolicAtlas:
    def __init__(self,B,h,ee,words):
        self.B=tuple(map(tuple,B));self.h=tuple(h);self.n=len(h)
        self.D=symmetrizer(B);self.ee=ee;self.idx={p:i for i,p in enumerate(ee)}
        self.words=words;self.m=len(ee)
        E0=initial_E(B);T0=tuple({i:ONE} for i in range(self.m))
        self.prefix={(): (E0,T0)}
        self.transforms=[self.build(tuple(w))[1] for w in words]

    def build(self,w):
        if w in self.prefix:return self.prefix[w]
        E,T=self.build(w[:-1]);k=w[-1];c=tuple(E[self.n+i][k] for i in range(self.n))
        alpha=tuple(abs(x) for x in c)
        A=sum(c[i]*self.D[i]*self.h[i] for i in range(self.n))
        assert A%self.D[k]==0;A//=self.D[k]
        rows=[]
        for ip,p in enumerate(self.ee):
            lim=min(p[i]//alpha[i] for i in range(self.n) if alpha[i])
            if not lim:rows.append(T[ip]);continue
            b=sum(c[i]*self.D[i]*sum(self.B[i][j]*p[j] for j in range(self.n)) for i in range(self.n))
            assert b%self.D[k]==0;b//=self.D[k]
            row=dict(T[ip])
            for j in range(1,lim+1):
                pol=binomial_linear(A,b,j)
                if not pol:continue
                q=tuple(p[i]-j*alpha[i] for i in range(self.n));iq=self.idx[q]
                for z,v in T[iq].items():
                    nv=add(row.get(z,ZERO),mul(pol,v))
                    if nv:row[z]=nv
                    elif z in row:del row[z]
            rows.append(row)
        value=(mutate_matrix(E,k),tuple(rows));self.prefix[w]=value;return value

    def greedy(self):
        A=[ONE];winners=[0];bound=1;allcuts=[]
        for ip,p in enumerate(self.ee[1:],1):
            cuts=[]
            for T in self.transforms:
                v=ZERO
                for j,w in T[ip].items():
                    if j!=ip:v=sub(v,mul(w,A[j]))
                cuts.append(v)
            best=0
            for j in range(1,len(cuts)):
                if eventual_cmp(cuts[j],cuts[best])>0:best=j
            win=cuts[best]
            bound=max(bound,*(eventual_nonnegative_bound(sub(win,z)) for z in cuts))
            assert len(win)<=sum(p)+1
            assert not win or not win[0]
            A.append(win);winners.append(best);allcuts.append(cuts)
        return A,winners,bound

    def series_mul(self,A,B):
        out=[ZERO]*self.m
        for i,p in enumerate(self.ee):
            if not A[i]:continue
            for j,q in enumerate(self.ee):
                if not B[j]:continue
                ij=self.idx.get(tuple(a+b for a,b in zip(p,q)))
                if ij is not None:out[ij]=add(out[ij],mul(A[i],B[j]))
        return out

    def series_log(self,A):
        # Euler derivative: |p| A_p = sum_(0<q<=p) |q| L_q A_(p-q).
        out=[ZERO]*self.m
        for i,p in enumerate(self.ee[1:],1):
            d=sum(p);value=A[i]
            for j,q in enumerate(self.ee[1:i],1):
                if not out[j]:continue
                pq=tuple(a-b for a,b in zip(p,q));k=self.idx.get(pq)
                if k is not None and A[k]:value=sub(value,scale(mul(out[j],A[k]),Q(sum(q),d)))
            out[i]=value
        return out

def rank2_words(B,N):
    b=B[0][1];c=-B[1][0];assert b>0 and c>0
    E0=initial_E(B);words=[()];cert=[]
    for first in (0,1):
        E=E0;seen={E};roots=[];w=[]
        for d in range(1,10000):
            k=(first+d-1)%2;root=tuple(abs(E[2+i][k]) for i in range(2));roots.append(root)
            w.append(k);E=mutate_matrix(E,k);words.append(tuple(w))
            if E in seen:cert.append({'kind':'repeat','depth':d});break
            seen.add(E)
            if b*c>=4 and d>=10:
                tr=b*c-2
                checks=all(all(roots[j][i]==tr*roots[j-2][i]-roots[j-4][i] for i in range(2)) for j in (d-2,d-1))
                growing=all(all(roots[j][i]>=roots[j-2][i] for i in range(2)) for j in (d-2,d-1))
                if checks and growing and sum(roots[-1])>N and sum(roots[-2])>N:
                    cert.append({'kind':'monotone_root_tail','depth':d,'trace':tr,'roots':roots[-4:]});break
        else:raise RuntimeError('rank2 cutoff')
    return words,cert

def serialize(p):return [[x.numerator,x.denominator] for x in p]
def case(B,h,N,depth=12):
    start=time.time()
    if len(B)==2:
        ee=total_exponents(2,N);words,cert=rank2_words(B,N)
        meta={'kind':'rank2 exact rays','complete':True,'certificates':cert,'words':len(words)}
    else:
        meta,ee,HH,words=universal_atlas(B,N,depth,seed_cap=250000,bit_cap=4096)
        meta['complete']=False
    S=SymbolicAtlas(B,h,ee,words);A,w,bound=S.greedy();L=S.series_log(A)
    nonlinear=[{'p':p,'polynomial':serialize(a),'greedy':serialize(A[i]),'witness':words[w[i]]}
               for i,(p,a) in enumerate(zip(ee,L)) if len(a)>2]
    return {'B':B,'h':h,'degree':N,'atlas':meta,'threshold':bound,'nonlinear':nonlinear,
            'coefficients':[[p,serialize(a)] for p,a in zip(ee,L) if a],
            'greedy':[[p,serialize(a),words[w[i]]] for i,(p,a) in enumerate(zip(ee,A)) if a],
            'seconds':time.time()-start}

if __name__=='__main__':
    samples=[
      ([[0,3],[-3,0]],(-2,3),10),
      ([[0,2],[-2,0]],(-1,1),10),
      ([[0,1],[-5,0]],(-2,3),10),
      ([[0,2,-2],[-2,0,2],[2,-2,0]],(-2,-3,-5),6),
      ([[0,2,-2],[-2,0,3],[2,-3,0]],(-2,1,-3),6),
      ([[0,3,1],[-3,0,2],[-1,-2,0]],(-2,3,-1),6),
    ]
    out=[];dest=Path(__file__).parent/'initial_results.json'
    for B,h,N in samples:
        r=case(B,h,N);out.append(r)
        dest.write_text(json.dumps({'completed':False,'results':out},indent=2))
        print('rank',len(B),'h',h,'N',N,'nonlinear',len(r['nonlinear']),'bound',r['threshold'],'sec',round(r['seconds'],2),flush=True)
    dest.write_text(json.dumps({'completed':True,'results':out},indent=2))
