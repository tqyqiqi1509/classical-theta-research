# Handoff: exact large-label logarithms and actual-seed support witnesses

Branch: /root/large_label_canonical_coordinates
Worked: 2026-11-13 05:38–06:04 UTC.
Status: this branch is ready for context refresh. All launched computations have
finished. No unattended process remains from this branch.

## Main new theorem

Read LOG_LINEARITY_PARTITION_CRITERION.md first. Assuming all proper lower
logarithmic coefficients are N-linear, the next logarithmic coefficient is
N-linear **if and only if some actual seed has no support decomposition p=q+r
into two nonzero lower eventual coefficients**. This is exact, and applies to
the complete actual atlas or to a declared finite actual subatlas separately.

For a seed t, write

    [z^p] T_t^(Nh) G_(Nh) = L_p(N) + N delta_t + P_t(N),
    P_t(N) = [z^p] exp(N K_(t,<p)).

Lower eventual positivity forces every nonzero P_t to have degree >=2 and
positive highest coefficient. The proof recursively replaces negative log
atoms by positive partitions; a partition of maximum length cannot contain a
negative atom. Since

    L_p(N)=max_t(-P_t(N)-N delta_t),

linearity is equivalent to existence of P_t=0. When such seeds exist, one that
maximizes -delta_t eventually dominates all actual cuts at this exponent.
The witnessing seed may depend on p. A single common seed for all p is not
assumed.

This is the concrete unresolved all-rank mutation assertion: construct an
actual seed with the stated support property from the inductively determined
lower greedy coefficients. Finite signatures alone do not prove it.

## Eventual polynomiality and integer coordinates

STABLE_INTEGER_COORDINATES.md contains a self-contained proof of eventual
polynomiality: transport entries have bounded polynomial degree in g; finite
actual rows and induction turn the greedy maximum into one eventual rational
polynomial P_p(N), with P_p(0)=0 and a fixed actual sharpness witness.

It also proves that P_p(m) is an integer for every integer m. Therefore stable
coordinates F_h=sum_p P_p(1)z^p are integral formal series. If higher log
linearity holds, G_(Nh)=F_h^N coefficientwise for sufficiently large N, with
coefficient-dependent thresholds, and F_(a h)=F_h^a for positive integer a.
Conditional on the support-witness assertion on a region, the stabilized log
coefficients are homogeneous piecewise-linear functions of h on finite
rational polyhedral subdivisions at each fixed degree.

**Do not call these positive basis elements.** With a complete rank-two atlas,
B12=-B21=3, h=(-3,4), the stable polynomial at p=(5,2) gives P_p(1)=-6.
For h=(-2,3) it gives -48. Thus N=1 evaluation does not recover the finite-label
positive greedy series. It can supply signed coordinates for a later exact
finite-label construction, but does not solve that latter step.

## Closure mechanisms: two failures and a viable candidate

Read LOCAL_CLOSURE_BOUNDARIES.md.

1. Connectedness/prefix closure is insufficient. For cyclic weights(2,3,2),
   h=(-2,-3,-2), the atlas consisting of identity and all one-step seeds gives
   [z111]log=-20N^2 despite correct lower coefficients. Its winner is0.
   Adding its neighbor02 changes no lower coefficient and yields log10N.
   Exact row and cut are in ball1_repair_results.json.

2. Monotone ascent from an arbitrary single seed, even allowing flat paths,
   is false. Complete rank-two B12=-B21=3, h=(-1,-2), p=(1,2): the entire
   alternating ray beginning0 has cut 2N^3-13N^2+6N and partition polynomial
   18N^2. Leaving the plateau requires passing through the smaller identity
   cut0. The other ray already has the maximum2N^3+5N^2+3N at seed1.
   This is certified by the root tail, not merely depth truncation.

3. Candidate using all lower sharpness witnesses. For every q<p choose a
   shortest actual seed t_q with transformed coefficient q equal to0. Add
   all one-mutation neighbors of these seeds and identity. In exact symbolic
   checks this closure always contained a seed with P_t=0:

   - complete rank two,25 integral directions,degree12:2,250 exponent tests;
   - sampled rank three,35 directions,degree6:2,905 exponent tests;
   - sampled rank four,20 directions,degree5:2,500 exponent tests.

   Total7,655 tests; no blocking failure. This is a candidate general assertion,
   not a theorem. The closure did miss the optimal *linear* cut in37 tests
   (8,18,11 respectively). Thus it might prove log linearity but cannot simply
   replace the whole atlas in the finite-label greedy algorithm.

   Reproduce with lower_witness_closure.py; all data and completeness labels
   are in lower_witness_closure_results.json. The higher-rank atlas runs hit
   no seed or bit caps, but are still not certified complete.

## Exact computation engine and evidence

`eventual_polynomial.py` works in Q[N] with Fraction coefficients. There is no
floating interpolation. Binomial transport factors are expanded exactly;
cut comparisons use the highest nonzero polynomial coefficient. A returned
threshold M is certified by checking that all coefficients of every cut
 difference after substituting N=M+t are nonnegative.

Higher-degree results:

| Matrix/direction | Degree | Coverage | Threshold | Nonlinear log terms |
|---|---:|---|---:|---:|
| rank2(3,3),h=(-3,4) |24|complete two rays/root tails|10|0|
| Markov2,h=(-2,-3,-5) |12|49,150 seeds/172 jets,depth14|6|0|
| cyclic223,h=(-2,1,-3) |12|35,340 seeds/145 jets,depth14|11|0|
| acyclic(3,1,2),h=(-2,3,-1)|10|43,700 seeds/67 jets,depth14|9|0|

A further168 integral directions across three rank-three matrices (including
nontrivial symmetrizer) and two rank-four matrices gave15,960 nonconstant
coefficient tests with no nonlinear log term. This does not certify the
all-rank conjecture. Data: generic_direction_results.json.

Wolfram computational plugin was also used independently. The exact check for

    f=1+nu*a*u+nu*b*v+nu*c*w
      +(nu^2*a*b+nu*s)*u*v
      +(nu^2*b*c+nu*t)*v*w
      +(nu^2*c*a+nu*r)*w*u
      +(nu^3*a*b*c+nu^2*(c*s+a*t+b*r))*u*v*w

returned [u v w]log(f)=0 and [u v]log(f)|_(w=0)=nu*s.
The first call accidentally used protected symbol N and was discarded; a clean
Module call with nu returned {0,nu$84003*s$84003}. The exact independent Python
engine does not depend on this plugin check.

## Files worth retaining

- LOG_LINEARITY_PARTITION_CRITERION.md — main proved theorem and proof.
- STABLE_INTEGER_COORDINATES.md — polynomiality/integrality and N=1 limitation.
- LOCAL_CLOSURE_BOUNDARIES.md — actual closure mechanisms and failed alternatives.
- eventual_polynomial.py — exact symbolic-N transport/greedy engine.
- initial_results.json, higher_degree_results.json — complete coefficient data.
- lower_witness_closure.py and lower_witness_closure_results.json — next general
  mechanism experiment.
- ball1_repair.py and ball1_repair_results.json — clean actual neighbor repair.
- jet_graph.py, local_improvement_test.py, local_improvement_results.json — bad
  local plateau test; rank-two failure is independently explained in the note.
- batch_generic.py and generic_direction_results.json — broader exact scan.
- RESEARCH_LOG.md — route/literature review record.

Other sparse/prefix-subatlas experiment files can be compressed in the final
ZIP; they are diagnostic provenance, not the main result.

## Literature review / 2026 audit boundary

Latest refresh at06:00UTC. Reading–Stella2603.19391v4 / SIGMA22(2026),109 was
verified from journal and arXiv, published2026-11-08. Parent already had the
strong audit and the Example5.9 max/min correction. For the new interface,
Theorem5.7 and Lemmas5.11–5.12 were re-read: they do not prove actual-cut
neighbor improvement. No conclusion from them is used in the new theorem.
Burcroff2024 Dyck-path formulas were located but not used to assert an unproved
large-label consequence. Official links and source IDs are in the branch
messages; parent should reopen any it cites.

## Recommended fresh-context next step

Parent has now developed work/THETA_NEWTON_PRUNING.md. The next branch should
use that finite Newton support theorem to attack the bridge between its
internal coefficients and formal-greedy sharpness, with the exact partition
criterion as an optional local test. Do not spend another cycle on the already
false single-seed ascent or on pretending stable N=1 coordinates are positive.
The lower-witness one-neighbor assertion remains open if it becomes relevant.
