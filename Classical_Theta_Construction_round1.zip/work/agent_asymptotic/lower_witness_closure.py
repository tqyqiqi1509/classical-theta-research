import sys,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from eventual_polynomial import *
rng=random.Random(169267)

def residual(S,T,A,i):
 out=ZERO
 for j,c in T[i].items():out=add(out,mul(c,A[j]))
 return out

def check(B,h,N,ee,words):
 S=SymbolicAtlas(B,h,ee,words);A,w,M=S.greedy();L=S.series_log(A)
 if any(len(a)>2 for a in L):return {'nonlinear_full':True}
 canonical=[]
 for i,p in enumerate(ee):
  sharp=[j for j,T in enumerate(S.transforms) if not residual(S,T,A,i)] if i else [0]
  canonical.append(min((tuple(words[j]) for j in sharp),key=lambda word:(len(word),word)))
 failures=[];nonmax=[];closed_witnesses=[]
 for i,p in enumerate(ee[1:],1):
  W={()}
  for j,q in enumerate(ee[:i]):
   if all(a<=b for a,b in zip(q,p)):W.add(canonical[j])
  original=sorted(W,key=lambda x:(len(x),x))
  for word in original:
   for k in range(len(B)):
    new=word[:-1] if word and word[-1]==k else word+(k,)
    W.add(new)
  rs=[(word,residual(S,S.build(word)[1],A,i)) for word in W]
  blocked=[word for word,r in rs if len(r)<=2]
  if not blocked:
   failures.append({'p':p,'lower_witnesses':original,'closure':sorted(W,key=lambda w:(len(w),w)),'full_witness':canonical[i],'residuals':[[word,serialize(r)] for word,r in rs]})
  if not any(not r for word,r in rs):
   nonmax.append({'p':p,'lower_witnesses':original,'full_witness':canonical[i],'best_residual':serialize(min((r for _,r in rs),key=lambda r:(len(r),list(reversed(r)))))})
  closed_witnesses.append(len(W))
 return {'h':h,'degree':N,'blocking_failures':failures,'sharpness_failures':nonmax,'max_closure_size':max(closed_witnesses)}

report=[]
for B,N,depth,count in [([[0,3],[-3,0]],12,16,25),([[0,2,-2],[-2,0,3],[2,-3,0]],6,13,35),([[0,2,-1,1],[-2,0,2,-1],[1,-2,0,2],[-1,1,-2,0]],5,9,20)]:
 if len(B)==2:ee=total_exponents(2,N);words,cert=rank2_words(B,N);meta={'complete':True,'certificates':cert}
 else:meta,ee,HH,words=universal_atlas(B,N,depth,seed_cap=180000,bit_cap=4096);meta['complete']=False
 records=[]
 for j in range(count):
  h=tuple(rng.choice([-6,-5,-4,-3,-2,-1,1,2,3,4,5,6]) for _ in B)
  res=check(B,h,N,ee,words);records.append(res)
  if res.get('blocking_failures'):
   print('BLOCKING FAIL',len(B),h,res['blocking_failures'][0],flush=True);break
  if j%5==0:print('progress',len(B),j,'sharpnessfail',len(res['sharpness_failures']),flush=True)
 report.append({'B':B,'degree':N,'atlas':meta,'attempts':j+1,'results':records})
 Path(__file__).with_name('lower_witness_closure_results.json').write_text(json.dumps({'complete':False,'results':report},indent=2))
Path(__file__).with_name('lower_witness_closure_results.json').write_text(json.dumps({'complete':True,'results':report},indent=2))
