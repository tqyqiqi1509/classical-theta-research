# Actual-seed closure: what the exact experiments establish

Date: 2026-11-13. Variables are zero-indexed in mutation words.

## 1. Connectedness and prefix closure are insufficient

The connected atlas {empty,0,1,2} for

    B=[[0,2,-2],[-2,0,3],[2,-3,0]], h=(-2,-3,-2)

has the correct coefficients below p=(1,1,1) but yields log coefficient
-20N^2. Its winner is seed0. The adjacent seed02 changes no lower coefficient
and changes the p-cut to 12N^3+38N^2+10N, hence gives log coefficient10N.
The complete exact row and comparisons are in ball1_repair_results.json.
This is an example of the general support criterion working via a neighboring
seed, but is not a proof that a neighbor always exists.

## 2. A monotone walk from any single optimal seed is false

Use the complete rank-two actual atlas, B12=-B21=3, h=(-1,-2), p=(1,2).
The correct lower greedy coefficients give the full cut maximum

    C_max(N)=2N^3+5N^2+3N,

attained already at seed1. At seed0 the cut is

    C_0(N)=2N^3-13N^2+6N.

Every seed farther along the alternating ray beginning with0 has the same
p-cut: subsequent positive roots have first coordinate at least3, exceeding
p_1=1, and cannot affect this row. This is an exact root-tail argument, not a
finite-depth observation. The only path leaving this plateau goes through
the identity, where the p-cut is0, strictly smaller than C_0 for large N.
Yet the transformed coefficient on the plateau equals

    C_max-C_0=18N^2-3N,

so its partition polynomial is18N^2, not0. Thus this plateau is a bad local
maximum for eventual polynomial order. A proof of logarithmic linearity cannot
use an assertion that every nonzero-partition local maximum has an improving
neighbor, even if flat paths are allowed.

The support obstruction can instead be removed by seed1, which is a lower
sharpness witness for the exponent(0,1). This motivates using the family of
lower witnesses jointly.

## 3. Candidate closure of lower sharpness witnesses

Assume the correct lower coefficients through a downset are known. For each
0<q<p choose an actual seed t_q where the transported q coefficient is zero,
using the shortest mutation word and lexicographic tie-break in the program.
Let W_p consist of these seeds, the identity, and all their one-mutation
neighbors. The candidate assertion is:

    Some seed in W_p prevents every decomposition p=q+r of nonzero lower
    eventual support, equivalently has P_t=0.

If this were proved generally, the partition criterion would prove higher
logarithmic linearity by induction. It would not require W_p to contain the
cut with the best linear coefficient. In fact the latter stronger statement
already fails in exact rank-two experiments.

The executable lower_witness_closure.py records separate blocking failures
and failures to hit a sharp top coefficient. The rank-two runs use complete
alternating-ray atlases. Rank-three and rank-four runs use sampled actual
atlases and make no completeness assertion. The final counts are recorded
in lower_witness_closure_results.json and HANDOFF.md.

No proof of the candidate assertion was obtained in this branch. No general
claim about all choices of lower witnesses, or about an effective enumeration
of the complete all-rank actual atlas, is implicit in the successful tests.
