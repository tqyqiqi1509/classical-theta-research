# Stable integer coordinates and the finite-label boundary

Date: 2026-11-13. This note concerns the actual all-seed formal greedy recursion,
or a specifically declared finite actual subatlas. It does not assert that a
finite sampled atlas equals the all-seed atlas.

## 1. Eventual polynomials (self-contained proof)

At a fixed exponent p, actual transport entries from q to p are polynomials in
the label g with rational coefficients and degree at most |p-q|. Indeed each
signed-c generator contributes a binomial

    binom((c^T D(g+Bp))/d_k, j)

of degree at most j, while raising exponent degree by j|c|>=j. Composition
preserves the bound. Finite signatures imply finitely many distinct actual
operator rows, uniformly in g. Inductively, all lower greedy coefficients
along g=Nh are eventually polynomials. Every competing cut for p is then a
polynomial of degree at most |p|. Pairwise polynomial comparisons stabilize,
so their maximum is one fixed polynomial P_p(N) for all sufficiently large N.
One actual seed attaining that cut witnesses sharpness throughout the tail.

At N=0, induction makes all nonconstant predecessor polynomials vanish.
The remaining transport entry from the constant monomial vanishes because
T_t(1)=1. Thus P_p(0)=0 for p!=0. The polynomial has integer values at every
sufficiently large integer, since the integer recursion does.

The degree bound for P_p alone does not imply logarithmic linearity. The exact
extra condition is the actual-seed support criterion proved in
LOG_LINEARITY_PARTITION_CRITERION.md.

## 2. Integer-valued extension is automatic

**Proposition.** P_p(m) is an integer for every integer m, including m=1.

Proof. Choose an integer M after the stable threshold, and d>=deg P_p. Newton
interpolation, as an identity of rational polynomials, gives

    P_p(N) = sum_(k=0)^d Delta^k P_p(M) binom(N-M,k).

Each finite difference is an integer. Generalized binomial coefficients are
integers for every integer upper argument, including negative arguments. QED.

Therefore

    F_h(z) = sum_p P_p(1) z^p

is a well-defined series in 1+(z) Z[[z]], independently of whether higher
logarithmic linearity has been established.

If logarithmic linearity holds at every degree, then

    G_(Nh) = F_h^N

holds coefficientwise for all sufficiently large N (the threshold may depend
on the coefficient). It is not a statement that one fixed N works in every
degree. Conversely, such coefficientwise eventual powers imply logarithmic
linearity.

For every positive integer a, eventual polynomiality implies
P_p^(a h)(N)=P_p^h(aN). Under logarithmic linearity this yields F_(a h)=F_h^a.
These are integral formal coordinates along positive rational rays. Positivity,
finite support, an invertible rank-n chart, and global seed-reset compatibility
are separate properties and have not been supplied by this argument.

## 3. The stable coordinate can have negative coefficients

This is already visible with a complete rank-two atlas, not an artifact of a
sampled high-rank seed set. For B=[[0,3],[-3,0]]:

- h=(-3,4): the stable polynomial at p=(5,2) has P_p(1)=-6.
- h=(-2,3): the corresponding stable polynomial has P_p(1)=-48.

Exact polynomial data, actual cut witnesses, and root-tail certificates are
in higher_degree_results.json and initial_results.json. Consequently F_h is
not the finite-label positive greedy element in general. A signed integer
coordinate can still be used to express subsequent finite-label conditions,
but evaluating the stable branch at N=1 does not construct the requested
positive basis.

## 4. Conditional chamberwise linearity

For a fixed finite downset, suppose the actual-seed support criterion holds
for every h in a region. Inductively refine the region into polyhedral cones
on which every lower ell_q(h) is linear. Each transported lower logarithmic
coefficient k_(t,q)(h) is then linear. Its sign is constant after a finite
rational hyperplane subdivision. The condition P_t=0 depends only on which
of these k_(t,q) are positive. On such a cell it is fixed, and

    ell_p(h)=max_(t:P_t=0)(-delta_t(h))

is a maximum of finitely many linear functions. A further rational hyperplane
subdivision makes it linear. Thus, conditional on the witness assertion, the
stable logarithms define homogeneous piecewise-linear functions of h at every
fixed degree. On a common linear cone, F_(h+h')=F_h F_h' through that degree.
This is an independent algebraic route toward formal charts; the assertion
providing an actual partition-blocking seed remains the missing theorem.
