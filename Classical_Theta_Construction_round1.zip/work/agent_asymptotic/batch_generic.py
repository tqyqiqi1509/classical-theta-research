import sys,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from eventual_polynomial import *
rng=random.Random(582617)
cases=[
([[0,2,-2],[-2,0,3],[2,-3,0]],6,13,40),
([[0,2,-3],[-2,0,2],[3,-2,0]],6,13,40),
([[0,1,-1],[-2,0,2],[3,-3,0]],6,13,40),
([[0,2,-1,1],[-2,0,2,-1],[1,-2,0,2],[-1,1,-2,0]],5,9,24),
([[0,1,1,0],[-1,0,1,1],[-1,-1,0,2],[0,-1,-2,0]],5,9,24),
]
report={'complete':False,'cases':[],'found_nonlinear':[]};dest=Path(__file__).parent/'generic_direction_results.json'
for B,degree,depth,count in cases:
 start=time.time();meta,ee,H,words=universal_atlas(B,degree,depth,seed_cap=180000,bit_cap=4096)
 meta['complete']=False; results=[]
 for j in range(count):
  h=tuple(rng.choice([-5,-4,-3,-2,-1,1,2,3,4,5]) for _ in B)
  if j==0:h=tuple(-x for x in range(2,len(B)+2))
  S=SymbolicAtlas(B,h,ee,words);A,w,M=S.greedy();L=S.series_log(A)
  bad=[{'p':p,'polynomial':serialize(a),'witness':words[w[i]]} for i,(p,a) in enumerate(zip(ee,L)) if len(a)>2]
  results.append({'h':h,'threshold':M,'nonlinear':bad})
  if bad:
   report['found_nonlinear'].append({'B':B,'h':h,'degree':degree,'nonlinear':bad})
   print('NONLINEAR',B,h,bad,flush=True)
  if j%10==0:print('progress',len(B),degree,j,'/',count,flush=True)
  del S
 report['cases'].append({'B':B,'degree':degree,'atlas':meta,'results':results,'seconds':time.time()-start})
 dest.write_text(json.dumps(report,indent=2))
 print('done',len(B),degree,count,'sec',time.time()-start,flush=True)
report['complete']=True;dest.write_text(json.dumps(report,indent=2))
