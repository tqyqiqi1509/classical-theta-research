# A support criterion exactly equivalent to large-label logarithmic linearity

Date: 2026-11-13. Scope: classical skew-symmetrizable principal seeds. This is an
independent algebraic statement about the actual integer transport operators;
no scattering diagram, broken line, or representation-theoretic definition is
used. It identifies a concrete missing mutation statement, rather than claiming
that statement has been proved.

## 1. Setup

Fix a finite downset of coefficient exponents and an exponent p. The order q<p
below means componentwise q<=p, q!=p. Write the actual normalized seed transport
as

    T_t^g(F) = H_t^g F(z_1 H_t^{B[:,1]}, ..., z_n H_t^{B[:,n]}),

where H_t^g=product_i H_{t,i}^{g_i}, H_{t,i}(0)=1. In particular, it is
multiplicative in the label and the series:

    T_t^(g+g')(F F') = T_t^g(F) T_t^g'(F').

Actual transport jets form a finite set at a fixed downset (the finite-signature
result). Everything below also applies to any specified finite subatlas that
contains the identity. Distinguish those two applications: a sampled subatlas
is not asserted to be complete.

Let A_q(N) be the eventual polynomial selected by the triangular greedy maximum
for label Nh. Its transformed coefficients at all seeds of the atlas are
nonnegative for sufficiently large integral N. Suppose inductively that

    [z^q] log G_(Nh) = N ell_q                 for every 0<q<p.

The coefficient at p, denoted L_p(N), is not assumed linear. Put

    L_<p = sum_(0<q<p) ell_q z^q.

For each actual seed t define the rational numbers k_(t,q), q<p, and delta_t by

    log T_t^h(exp L_<p)
        = sum_(0<q<p) k_(t,q) z^q + delta_t z^p  modulo terms outside the downset.

The exponent at p enters every transport with diagonal coefficient one.
Multiplicativity consequently gives

    [z^p] T_t^(Nh)(G_(Nh))
        = L_p(N) + N delta_t + P_t(N),

where

    P_t(N) = [z^p] exp(N sum_(0<q<p) k_(t,q) z^q).

P_t has neither constant nor linear term.

## 2. Lemma: a nonzero partition polynomial has positive leading coefficient

Let K=sum_(0<q<p) k_q z^q have real coefficients. Assume every coefficient
[z^q] exp(NK), 0<q<p, is eventually nonnegative as N tends to positive infinity.
Then P(N)=[z^p]exp(NK) is either identically zero, or has degree at least two and
strictly positive highest coefficient.

Proof. First show by induction on |q| that whenever k_q<0, q is a sum of at
least two exponents r with k_r>0. The polynomial [z^q]exp(NK) has negative
linear term N k_q; eventual nonnegativity forces a nonzero higher term. Thus
q admits a partition into at least two smaller exponents with nonzero K
coefficients. Replace each negative factor by its positive partition, already
provided by induction. The degree-one induction begins because a negative
coefficient there would violate eventual nonnegativity.

Now suppose p has at least one partition into exponents of nonzero K support.
Choose a partition of maximum number of parts. If any factor has negative K
coefficient, replacing it by its positive partition strictly increases the
number of parts, a contradiction. Every maximum-length partition therefore
has exclusively positive factors. The highest power of N in P is a sum of
positive products divided by positive factorials, so its coefficient is
strictly positive. If there is no partition, P is zero. QED.

The statement is stronger than ordinary leading-term heuristics: cancellations
between signed logarithmic coefficients are explicitly excluded at the
maximum partition length.

## 3. Exact criterion

Under the lower-degree induction above, the following are equivalent:

1. L_p(N) is eventually exactly linear in N.
2. There is an actual seed t in the specified atlas with P_t(N)=0 identically.
3. There is an actual seed t for which p cannot be expressed as a sum of at
   least two exponents from the positive support {q<p : k_(t,q)>0}.
4. There is an actual seed t with no decomposition p=q+r into nonzero proper
   exponents for which both [z^q]T_t^(Nh)(G_(Nh)) and
   [z^r]T_t^(Nh)(G_(Nh)) are nonzero eventual polynomials.

Proof. Greedy sharpness gives the exact eventual polynomial identity

    L_p(N) = max_t ( -P_t(N) - N delta_t ),

where max means eventual comparison of polynomials. By the lemma each nonzero
P_t has degree at least two and positive leading coefficient. If a zero P_t
exists, every nonzero-P_t competitor is eventually smaller than every linear
competitor. Hence

    L_p(N) = N max_(t:P_t=0)(-delta_t).

If no zero P_t exists, finiteness of the actual jets means the maximum is one
of finitely many polynomials of degree at least two with negative leading
coefficient. It is therefore not linear. This proves 1<=>2. The lemma's
positive-partition argument proves 2<=>3. The same argument says that the
nonzero eventual support of exp(NK) is precisely the truncated additive monoid
of its positive K support; this proves 3<=>4. QED.

## 4. What has and has not been reduced

This supplies a necessary-and-sufficient local seed witness at each degree,
not merely a sufficient positivity bound. Once such a seed exists, one seed
that maximizes -delta_t among these witnesses dominates all actual cuts for
large N at that degree. The lower coefficients need not have one common
sharpness seed, and the witnessing seed may vary with p.

The remaining all-rank mutation assertion is:

    For the inductively greedy lower coefficients, some actual seed prevents
    every proper support decomposition of p.

Calling this assertion 'obvious from finite signatures', replacing actual
seeds by all abstract sign vectors, or assuming one common seed for all p
would be invalid. Genericity of h has not yet proved this assertion.

A useful possible proof mechanism is mutation improvement: whenever P_t is
nonzero and its cut is currently optimal, exhibit an adjacent seed (possibly
a finite flat sequence followed by an adjacent seed) with a strictly larger
cut in eventual polynomial order. Finite actual jets would then force
termination at P_t=0, provided the improvement assertion is established for
all nonzero-P_t local maxima. No such general improvement theorem is claimed
here.

## 5. Exact connected-atlas failure and one-step repair

Take

    B = [[0,2,-2],[-2,0,3],[2,-3,0]],  h=(-2,-3,-2),

and only the identity and the three single-mutation seeds. This is already
connected and prefix-closed. Exact rational polynomial recursion gives

    A_111(N)=12N^3+18N^2,
    [z_1 z_2 z_3]log G_(Nh)=-20N^2.

The old winning cut is seed word (0). Add its neighbor (0,2). None of the
lower-degree coefficients changes. The new exact row at p=(1,1,1) is

    A_111 - 2N A_011 + (-1-2N) A_110
             + (4N^2-2N-2) A_010.

Its nonnegativity requires

    A_111 >= 12N^3+38N^2+10N,

which wins eventually and yields logarithmic coefficient 10N. The alternative
length-two words (1,0) and (2,1) also remove the quadratic obstruction but give
the weaker linear logarithmic coefficient -4N.

All formulas are exact, with no numerical interpolation. The data and every
row are in ball1_repair_results.json; executable code is ball1_repair.py.
This example disproves the sufficiency of prefix-closure and illustrates the
needed improvement from an old optimal cut to an adjacent cut.

## 6. Exact symbolic evidence, with coverage separated

The engine eventual_polynomial.py computes in Q[N]. Branch comparisons use
the highest nonzero coefficient. Thresholds are certified by shifting N=M+t
and checking that every coefficient of every winning-cut difference is
nonnegative; no floating fitting or unverified numerical threshold is used.

- Rank two B12=-B21=3, h=(-3,4), all coefficients through total degree 24 are
  logarithmically linear, with a certified common threshold N>=10. The two
  alternating rays and their monotone root tails certify the atlas at this
  degree.
- Markov B12=B23=B31=2, h=(-2,-3,-5), total degree 12: linear for the sampled
  actual atlas (49,150 seeds, 172 jets, depth 14), threshold N>=6. This atlas
  is not certified complete.
- Cyclic weights (2,3,2), h=(-2,1,-3), degree 12: linear for the sampled actual
  atlas, threshold N>=11.
- Acyclic B=[[0,3,1],[-3,0,2],[-1,-2,0]], h=(-2,3,-1), degree 10: linear for
  the sampled actual atlas, threshold N>=9.

These computations support the missing support-witness assertion; they do not
prove it, and they are not a replacement for investigating that assertion.
