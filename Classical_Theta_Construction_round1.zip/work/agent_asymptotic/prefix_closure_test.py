import sys,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from eventual_polynomial import *
rng=random.Random(61716)
Bs=[[[0,2,-2],[-2,0,3],[2,-3,0]],[[0,1,-1],[-2,0,2],[3,-3,0]],[[0,2,-1,1],[-2,0,2,-1],[1,-2,0,2],[-1,1,-2,0]]]
records=[];found=[];start=time.time()
for B in Bs:
 n=len(B);ee=total_exponents(n,6 if n==3 else 5)
 for typ in ['prefix','prefix_all_one_step','ball1','ball2','ball3']:
  for j in range(80 if n==3 else 25):
   h=tuple(rng.choice([-5,-4,-3,-2,-1,1,2,3,4,5]) for _ in B)
   words={()}
   if typ.startswith('ball'):
    depth=int(typ[-1]);front=[()]
    for _ in range(depth):
     nxt=[w+(k,) for w in front for k in range(n) if not w or k!=w[-1]]
     words.update(nxt);front=nxt
   else:
    if typ=='prefix_all_one_step':words.update((k,) for k in range(n))
    for _ in range(rng.randint(1,8)):
     w=()
     for _ in range(rng.randint(1,9)):
      k=rng.choice([x for x in range(n) if not w or x!=w[-1]]);w+=k,;words.add(w)
   words=sorted(words,key=lambda w:(len(w),w));S=SymbolicAtlas(B,h,ee,words);A,w,M=S.greedy();L=S.series_log(A)
   bad=[{'p':p,'polynomial':serialize(a),'witness':words[w[i]]} for i,(p,a) in enumerate(zip(ee,L)) if len(a)>2]
   if bad:
    rec={'B':B,'h':h,'kind':typ,'words':words,'nonlinear':bad,'threshold':M};found.append(rec)
    print('FOUND',n,typ,h,bad[:2],flush=True)
    break
  records.append({'B':B,'kind':typ,'attempts':j+1,'found':bool(bad)})
  Path(__file__).with_name('prefix_closure_results.json').write_text(json.dumps({'complete':False,'records':records,'found':found,'seconds':time.time()-start},indent=2))
  print('done',n,typ,j+1,flush=True)
Path(__file__).with_name('prefix_closure_results.json').write_text(json.dumps({'complete':True,'records':records,'found':found,'seconds':time.time()-start},indent=2))
