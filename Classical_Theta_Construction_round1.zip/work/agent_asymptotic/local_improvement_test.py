import sys,json,time,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from eventual_polynomial import *
from jet_graph import universal_graph
from collections import defaultdict
rng=random.Random(91674)

def analyze(S,A,edges,words,h,B):
 m=len(S.ee);nt=len(words);adj=[set() for _ in words]
 for u,v in edges:
  if u!=v:adj[u].add(v);adj[v].add(u)
 bad=[]
 for ip,p in enumerate(S.ee[1:],1):
  cuts=[];residue=[]
  for T in S.transforms:
   v=ZERO
   for j,c in T[ip].items():
    if j!=ip:v=sub(v,mul(c,A[j]))
   cuts.append(v);residue.append(sub(A[ip],v))
  done=set()
  for t in range(nt):
   if t in done:continue
   stack=[t];done.add(t);component=[];better=False
   while stack:
    v=stack.pop();component.append(v)
    for u in adj[v]:
     cmp=eventual_cmp(cuts[u],cuts[v])
     if cmp>0:better=True
     elif cmp==0 and u not in done:done.add(u);stack.append(u)
   if not better and len(residue[t])>2:
    bad.append({'p':p,'cut':serialize(cuts[t]),'residue':serialize(residue[t]),'plateau_words':[words[x] for x in component],'neighbor_words':[words[x] for x in set().union(*(adj[v] for v in component))-set(component)]})
 return bad
report=[]
for B,N,depth,count in [([[0,3],[-3,0]],12,15,30),([[0,2,-2],[-2,0,3],[2,-3,0]],6,12,50),([[0,2,-1,1],[-2,0,2,-1],[1,-2,0,2],[-1,1,-2,0]],5,9,30)]:
 meta,ee,HH,words,edges=universal_graph(B,N,depth,seed_cap=180000,bit_cap=4096);records=[]
 for j in range(count):
  h=tuple(rng.choice([-5,-4,-3,-2,-1,1,2,3,4,5]) for _ in B)
  S=SymbolicAtlas(B,h,ee,words);A,w,M=S.greedy();L=S.series_log(A)
  assert all(len(a)<=2 for a in L)
  bad=analyze(S,A,edges,words,h,B)
  if bad:
   print('BAD',len(B),h,len(bad),bad[0],flush=True);records.append({'h':h,'bad':bad});break
  if j%10==0:print('progress',len(B),j,flush=True)
 report.append({'B':B,'degree':N,'atlas':meta,'jet_edges':len(edges),'attempts':j+1,'bad_cases':records})
 Path(__file__).with_name('local_improvement_results.json').write_text(json.dumps({'complete':False,'results':report},indent=2))
Path(__file__).with_name('local_improvement_results.json').write_text(json.dumps({'complete':True,'results':report},indent=2))
