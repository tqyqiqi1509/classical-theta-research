# Large-label canonical-coordinate research log

Started 2026-11-13 05:38 UTC. Classical skew-symmetric and skew-symmetrizable only.

## Initial route and exact engine

Read all predecessor handoffs and proofs. The task is logarithmic linearity beyond the already proved eventual polynomiality. Implemented exact polynomial cuts in Q[N], comparison by eventual leading sign, and a finite positivity certificate for the selected branch: substitute N=M+t and check every coefficient is nonnegative. The resulting finite-atlas thresholds are exact sufficient bounds, not fitted thresholds.

Initial six tests: three rank-two cases (including wild and nontrivial symmetrizer), degree 10, with exact alternating-ray tail certificates; three rank-three non-CM/mixed directions, degree 6, sampled through depth 12 without resource pruning. Every log coefficient is exactly linear in N. Rank-three full-atlas completeness is not inferred from numerical stability.

Primary searches on asymptotic theta multiples, greedy stabilization and cluster canonical coordinates found no direct theorem furnishing this cluster-only mechanism. Existing scattering constructions are not substituted for the desired algorithm. The known Gupta1812.01910 stabilization result concerns a different mutation-sequence setting and is not adopted as a large-label result.

Wolfram evaluator independently computed the squarefree cubic logarithmic cancellation. The first call had an avoidable protected-symbol warning from N; reran inside Module with nu. Clean output is {0, nu*s} (with local symbol formatting), confirming the cubic matched-monomer/edge form has zero cubic cumulant and the mixed cumulant is linear.

## 2026-11-13 06:00 UTC: route and literature review

Exact Q[N] computation expanded to complete rank-two degree 24 and sampled
rank-three degree 12; 168 additional integral direction tests in ranks three
and four found no nonlinear logarithmic term. These are evidence with atlas
coverage explicitly separated, not an all-rank theorem.

A general necessary-and-sufficient mechanism was proved: assuming lower
logarithmic coefficients are N-linear, the coefficient at p is N-linear iff
some actual seed prevents all decompositions p=q+r from its nonzero lower
asymptotic support. The proof rules out leading partition cancellations by
recursively replacing every negative logarithmic atom with positive atoms.
See LOG_LINEARITY_PARTITION_CRITERION.md.

This led to targeted actual-seed closure tests, not more degree accumulation.
The original sparse-subatlas failure was caused by omitting a single mutation.
A sharper prefix-closed one-step atlas has a quadratic cubic-log obstruction;
adding a neighbor of its optimal seed repairs it without changing lower terms.
However arbitrary local plateau ascent fails even in complete rank two:
B12=3, h=(-1,-2), p=(1,2) has a bad local maximum along one entire alternating
ray. Therefore a general proof must use several lower sharpness witnesses,
not a monotone walk from an arbitrary single seed. A test of one-step closure
of canonical lower sharpness witnesses is currently running.

Stable jets evaluated at N=1 have integer coefficients, by integer-valued
polynomial finite differences, but can have negative coefficients even in
complete rank two. This is a signed formal coordinate construction, not a
positive basis element or a replacement for the finite-label greedy recursion.

Literature refresh used primary official SIGMA and arXiv sources. Reading–
Stella, Mutation of Theta Functions, SIGMA22(2026),109, arXiv2603.19391v4 was
published 2026-11-08. Its identity and version were checked against the journal
and arXiv. Parent's existing strong audit already found the Example5.9 max/min
typo. Re-reading Theorem5.7 and Lemmas5.11–5.12 for the new interface shows that
they control products inside a mutation-fan cone via pointedness; they do not
supply an improvement of an actual greedy cut. This source is useful context,
not adopted as a proof of the missing assertion. No 2026 result is used without
recording that boundary. Rank-two Dyck-path formulas of Burcroff(2024),
DOI10.5802/alco.343, were also located; no unproved large-label consequence was
attributed to them.

## 2026-11-13 06:04 UTC: branch handoff

The lower-witness closure computation finished:7,655 exponent tests across
complete rank two and sampled ranks three/four; no failure to find a
partition-blocking seed, but37 failures to contain the strongest linear cut.
This supports a narrowly stated general witness assertion without mistaking
it for a full greedy algorithm. Proof attempts did not establish the assertion.
Parent requested context refresh toward the new finite Newton pruning theorem.
All programs have finished; HANDOFF.md contains the proved statements,
limitations, counterexamples, and executable paths.
