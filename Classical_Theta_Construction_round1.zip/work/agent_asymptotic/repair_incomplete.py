import sys,json,time,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from eventual_polynomial import *
def dotrow(row,A):
 v=ZERO
 for j,c in row.items():v=add(v,mul(c,A[j]))
 return v
def enc_L(S,A):return [[p,serialize(a)] for p,a in zip(S.ee,S.series_log(A)) if a]
source=json.load(open(Path(__file__).parent/'incomplete_atlas_results.json'))
report=[]
for data in source['nonlinear']:
 B=data['B'];h=data['h'];old=[tuple(w) for w in data['words']];N=5
 meta,ee,HH,allwords=universal_atlas(B,N,12,seed_cap=100000,bit_cap=4096)
 A0S=SymbolicAtlas(B,h,ee,old);A0,w0,M0=A0S.greedy();L0=A0S.series_log(A0)
 FS=SymbolicAtlas(B,h,ee,allwords);FA,FW,FM=FS.greedy();FL=FS.series_log(FA)
 diffs=[{'p':p,'old':serialize(A0[i]),'full':serialize(FA[i]),'fullwitness':allwords[FW[i]]} for i,p in enumerate(ee) if A0[i]!=FA[i]]
 additions=[];shortest=None
 for word,T in sorted(zip(allwords,FS.transforms),key=lambda pair:(len(pair[0]),pair[0])):
  if tuple(word) in old:continue
  if shortest is not None and len(word)>shortest:break
  violations=[{'p':p,'polynomial':serialize(v)} for p,v in [(p,dotrow(T[i],A0)) for i,p in enumerate(ee)] if v and v[-1]<0]
  if not violations:continue
  S=SymbolicAtlas(B,h,ee,old+[tuple(word)]);A,w,M=S.greedy();L=S.series_log(A)
  nonlinear=[{'p':p,'polynomial':serialize(a)} for p,a in zip(ee,L) if len(a)>2]
  change=[{'p':p,'old':serialize(L0[i]),'new':serialize(L[i]),'new_witness':(old+[tuple(word)])[w[i]]} for i,p in enumerate(ee) if L0[i]!=L[i]]
  rec={'word':word,'violations':violations,'new_nonlinear':nonlinear,'changed_log':change,'threshold':M}
  if not nonlinear:shortest=len(word);additions.append(rec)
 target=tuple(data['nonlinear'][0]['p']);ip=ee.index(target)
 rec={'B':B,'h':h,'old_words':old,'target':target,'old_target_greedy':serialize(A0[ip]),'old_target_log':serialize(L0[ip]),'old_winner':old[w0[ip]],'full_target_greedy':serialize(FA[ip]),'full_target_log':serialize(FL[ip]),'full_winner':allwords[FW[ip]],'all_greedy_differences':diffs,'shortest_repair_length':shortest,'shortest_repairs':additions,'atlas':meta}
 report.append(rec)
 print('h',h,'shortest repair length',shortest,'repair words',[r['word'] for r in additions],flush=True)
Path(__file__).with_name('repair_incomplete_results.json').write_text(json.dumps(report,indent=2))
