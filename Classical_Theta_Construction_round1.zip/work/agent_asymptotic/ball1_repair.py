import sys,json,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from eventual_polynomial import *
B=[[0,2,-2],[-2,0,3],[2,-3,0]];h=(-2,-3,-2);ee=total_exponents(3,3);base=[(),(0,),(1,),(2,)]
S=SymbolicAtlas(B,h,ee,base);A,w,M=S.greedy();L=S.series_log(A);ip=ee.index((1,1,1))
words=[w for l in range(1,5) for w in itertools.product(range(3),repeat=l) if all(w[i]!=w[i+1] for i in range(l-1))]
repairs=[]
for word in words:
 T=S.build(word)[1]
 cut=ZERO
 for i,c in T[ip].items():
  if i!=ip:cut=sub(cut,mul(c,A[i]))
 SS=SymbolicAtlas(B,h,ee,base+[word]);AA,WW,MM=SS.greedy();LL=SS.series_log(AA)
 if len(LL[ip])<=2:
  repairs.append({'word':word,'targetcut_with_old_lower':serialize(cut),'new_A111':serialize(AA[ip]),'new_L111':serialize(LL[ip]),'changed_lower':[ee[i] for i in range(ip) if A[i]!=AA[i]],'row':[[ee[i],serialize(c)] for i,c in T[ip].items()],'new_witness':(base+[word])[WW[ip]]})
 if repairs and len(word)>len(repairs[0]['word']):break
res={'B':B,'h':h,'base':base,'coeffs':[[p,serialize(A[i]),serialize(L[i]),base[w[i]]] for i,p in enumerate(ee)],'shortest_repairs':[r for r in repairs if len(r['word'])==len(repairs[0]['word'])]}
Path(__file__).with_name('ball1_repair_results.json').write_text(json.dumps(res,indent=2))
print(json.dumps({'h':h,'oldA111':serialize(A[ip]),'oldL111':serialize(L[ip]),'repairs':res['shortest_repairs']},indent=2))
