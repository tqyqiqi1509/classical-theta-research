# Fundamental capacities and source/sink transport

Research interface, 2026-11-13. This is a general reduction observation,
not a proof that the graph-capacity selector is a theta construction.

Let B be an acyclic skew-symmetrizable matrix and C its Cartan companion,
C_ii=2 and C_ij=-|B_ij| for i!=j. Put A=[-B]_+ and use the canonical
capacity label g_d=-d+Ad with d>=0. Capacities are independent of inactive
monomial factors, but the statements below start with those factors zero.

## 1. A source or sink reflects the capacity

For a source or sink k, tropical mutation of g_d and the elementary
triangular capacity recursion give

    d'_j=d_j (j!=k),
    d'_k=max(0, sum_(j!=k)|B_kj| d_j-d_k).

When the expression on the second line is nonnegative, d'=s_k d, where
s_k d=d-(Cd)_k e_k. The transformed inactive monomial part remains zero.
If the expression is negative, the new capacity at k is zero and its
absolute value becomes an inactive initial monomial factor. This is an
ordinary integer mutation calculation, with no representation assumption.

For a source, g_k=-d_k and the other g-coordinates change by B_ik*d_k.
Move k to the last position in a topological order after mutation. The
capacity recursion leaves all other d_j unchanged and gives the formula
at k. For a sink, g_k=sum_j|B_kj|d_j-d_k; move k to the first position.
The two signs of g_k give the displayed positive part and inactive factor.

## 2. Fundamental capacities never get smaller under such transport

Suppose d>=0 and Cd<=0. For every Weyl-group word w,

    w d-d belongs to the nonnegative real span of the simple roots.

This is the standard dominant-chamber argument applied to -d. To spell
out the sign: along a reduced expression of w, the inversion coroots
are positive combinations of simple coroots. Their pairings with d are
nonpositive. The reflection difference is a sum of positive roots with
the negatives of these pairings as coefficients. In integral Cartan data
the resulting difference is an integral nonnegative vector.

Consequently any admissible sequence of source/sink mutations starting
at this capacity has no negative reflected coordinate and has capacity
w d>=d. Its capacity sum never falls below |d|, even though it can decrease
along later individual steps after an earlier increase. The starting
capacity is therefore globally minimal in its source/sink orbit.

Equality w d=d can occur on walls Cd_i=0; it does not prove uniqueness of
the seed or of a combinatorial representative. No statement is made that
every positive capacity can be brought into Cd<=0 by admissible reflections.
That additional assertion would require proof and is not needed here.

## 3. Why this is the current test

All verified failures so far of the complete one-seed graph-allocation
upper bounds plus initial pair lower bounds occur at non-fundamental
capacities. In the rank-four failure the source capacity is(8,7,9,2),
whereas its mutated capacity is(21,7,9,2); for the latter(Cd)_0=13.
This suggests testing the complete graph construction in a minimal
capacity frame, followed by actual Laurent transport.

**08:47 correction: the selector proposal in this section is false.**
For the topologically oriented K4 with all edge weights1 and capacity
d=(4,5,5,6), Cd=(-8,-5,-5,-2) is strictly negative. Enumerating all185220
allocations gives81897 distinct graph products, a173-point common support
and a47-dimensional Laurent space. The exact mass minimizer has mass1829,
but an exact feasible competitor lowers the coefficient at(3,2,2,1) from6
to2. Thus there is no coefficientwise least element even in the strict
fundamental region. Data are in
agent_creation_caps/fundamental_results_6_8.json.

The reflection and minimal-orbit observations in Sections1–2 remain valid.
An independent Wolfram calculation checked10000 random skew-symmetrizable
source/sink capacity mutations with zero failures. This is arithmetic
verification, not evidence for the now-refuted selector. The selector
route has been stopped; current work uses genuine two-sided inventory
identities, including their positive-resource exchange constraints.
