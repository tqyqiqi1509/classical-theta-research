# Independent Wolfram evaluations during this run

These are actual calls to the connected Wolfram Language evaluator, separate from the Python engines. They verify algebra and implementation conventions; finite checks are not used as substitutes for the stated general proofs.

## Two-step coefficient identity

The earlier root evaluation of the cyclic A3 mixed cut returned `-2*c0-c1+c2`. It also verified that the displayed cluster-monomial F-polynomial has central coefficient 4. See the exact two-step proof and independent substitution engine in `agent_division/`.

## Quadratic mixed coefficient formula

Parameters a,b each ranged from 1 to 7; g_i,g_j each ranged from -7 to 7. With P=[-g_i]_+, Q=[-g_j]_+, the maximum of the five exact endpoint cuts was compared with

    P Q + Max[b P - Min[P,a] Max[g_j,0], 0].

The evaluator returned `tested -> 11025, mismatch -> 0`. It also issued harmless undefined-global-symbol warnings from the symbolic setup; no mismatch or evaluation failure occurred. The proof in `agent_support/SECOND_ORDER_FINITE_CRITERION.md` is symbolic and covers all parameters, including the zero-edge case separately.

## Weighted Lie bracket

Take D=diag(d1,d2,d3), an arbitrary symbolic skew matrix S, and B=D^{-1}S. For arbitrary symbolic p,q,h, the evaluator expanded

    (q^T D h)(p^T D(h+Bq))
    -(p^T D h)(q^T D(h+Bp))
    -(p^T D B q)((p+q)^T D h).

The exact result was 0. It also returned `p^T D B p = 0`. This independently checks the sign and symmetrizer conventions in the finite-signature proof's commutator identity.

