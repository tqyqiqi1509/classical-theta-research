# Creation products and induced-subquiver coefficient bounds

2026-11-13, discovered around07:56UTC. General theorem for classical acyclic
skew-symmetrizable principal coefficients. Independently checked by the
source-surgery branch. No Li--Pan result is used.

## 1. The exact lowering of the standard box

Take a topological order, put A=[-B]_+ (strictly lower triangular), and write

    d_i=[-g_i+sum_(j<i) A_ij d_j]_+,
    v=g+(I-A)d,  v>=0,  v_i d_i=0.

Let a_i=-e_i+A e_i be the initial g-vector of the adjacent cluster variable

    x_i'=x^(a_i)(1+z_i),  z_j=y_j x^(B[:,j]).

For any vector r with 0<=r<=d, set g_r=g-sum_i r_i a_i. Then

    g_r=v-(I-A)(d-r).

The pair (v,d-r) still satisfies nonnegativity and complementary support.
Uniqueness of the triangular recursion therefore gives

    d(g_r)=d-r.                                             (1)

This works at every active vertex, not only sources. In particular a
nonempty r gives a strictly smaller total box.

## 2. General creation majorant

Let F_g be the theta F-polynomial. Strong theta multiplication and the
leading coefficient1 imply

    product_i (1+z_i)^(r_i) F_(g_r)(z)
       = F_g(z) + sum_(q>0) c_q z^q F_(g+Bq)(z),             (2)

where c_q are nonnegative integers. This is the homogeneous expansion of
product_i(x_i')^(r_i) theta_(g_r).

Here q>=0 is not an assumption about coefficient specialization. Every theta
summand has a nonnegative initial Laurent expansion and a coefficient-one
leading monomial. Since the product has no negative original frozen degree,
positivity prevents a summand with negative q. Its constant coefficient1
forces the sole q=0 contribution to be theta_g with coefficient1.

The product on the left is supported in [0,d]. Each summand on the right
is positive, so its support stays in that box. The elementary box lower
bound then gives

    q+d(g+Bq)<=d.                                           (3)

For q>0 its intrinsic standard box has smaller total size. Consequently
both F_(g_r) and every other polynomial in (2) are strictly smaller-box
objects. Equation (2) is a finite recursive interface, in contrast to
assuming unknown same-size theta structure constants.

In particular,

    [z^p]F_g <= [z^p](product_i(1+z_i)^(r_i)F_(g_r)).         (4)

For r=e_i this is a new upper-Pieri constraint. It is distinct from the
previous lowering condition on x_i theta_g and from selected/unselected
marking positivity.

## 3. Entirely explicit pair caps in every rank

Choose a subset I of vertices, put J=I^c, and take r_j=d_j for j in J,
r_i=0 for i in I. The lower object has zero width on every vertex in J.
Freezing identifies its F-polynomial with that for the induced exchange
matrix B_II and label

    gamma_I=g_I-A_IJ d_J=v_I-d_I+A_II d_I.                  (5)

Therefore

    a_p(g) <= product_(j in J) binom(d_j,p_j)
                 * a_(p_I)^(B_II)(gamma_I).               (6)

For |I|<=2 the right side is completely explicit: ordinary binomial
coefficients and the classical LLZ compatible-pair recurrence. Thus **every
acyclic rank has rigorous finite numerical upper bounds derived only from
rank-two greedy coefficients**, without treating any higher-rank computed
candidate as theta. They strengthen the standard product bounds obtained
by I empty. A zero right side is an exact support-hole certificate.

For general proper I, formula (6) is a rank recursion. More strongly,
subtracting F_g from the complete majorant in (2) must have a nonnegative
expansion in the already smaller-box basis. That imposes extra linear
inequalities beyond raw coefficient upper bounds once the lower objects
are established.

## 4. Why this repairs a real failure of the previous necessary conditions

For the diagnostic fork

    B=[[0,0,3],[0,0,2],[-3,-2,0]],
    g=(-8,-7,29), d=(8,7,9),

the old initial-pair/Pieri cone allowed the integer direction

    D47=uvw(1+u)^5(1+v)^5-u^6v^5w^3(1+v).

Take J={1} (zero-based vertex1). Then g_r=(-8,0,15), its width at vertex1
is zero, and its remaining rank-two seed has b=c=3 and label(-8,15).
The exact LLZ coefficient at(1,1) is zero. Formula (6) consequently gives

    a_(1,1,1)(g)<=binom(7,1)*0=0.

The candidate F59085 has this coefficient0, whereas F59085+D47 has it1.
This excludes that deformation by a general rank-deletion theorem and a
genuine rank-two computation, with no higher-rank candidate identification.

The one-step lower caches also give this bound but were only conditional;
the seven-step rank deletion above removes that logical dependence. This
example is a diagnostic of the general mechanism, not its scope.

## 5. What has not been proved

Creation positivity does not alone identify theta. Even in the Kronecker
case B12=2, g=(-2,2), d=(2,2), the two one-step creation products have a
common lower theta contribution2uv. Their greatest common lower element
in the lower-basis order is F_g+2uv, not F_g. Thus merely taking a minimum
of creation-product expansion coefficients is incorrect.

The current target is the interaction of creation majorants, Laurent
packet equations, positive lower-rank slices, and lowering/marking rules.
General integrality, coefficientwise leastness, mutation compatibility,
and theta identification still require proof. Numerical candidates remain
labelled as such.

## Proof inputs

The construction of the caps uses only integer matrix data, the triangular
box recursion, and lower-rank polynomials (rank-two LLZ in (6)). The theorem
comparing them with theta uses audited strong positivity, acyclic finite
theta expansion, freezing, and the elementary box lemma established in
this run. It does not replace the requested combinatorial construction by
scattering data.

