from pathlib import Path
import sys, json, time, random
import sympy as sp
from integer_orbit_cutoff import *

HERE = Path(__file__).resolve().parent
tic = time.time()
results = []


def check(A, beta, N, tag):
    A, beta = sp.Matrix(A), sp.Matrix(beta)
    hits, cert = bounded_orbit(A, beta, N)
    AA, bb, K, L, m = cyclic_data(A, beta)
    p = beta
    extra = 37
    if cert['case'] == 'periodic':
        final = 3 * cert['period'] + extra
    else:
        final = max(0, cert['last_possible_index']) + extra
    hit_indices = []
    for k in range(final + 1):
        if K.cols:
            v = L * p
            assert K * v == p
            q = sp.Poly(sum(v[j] * T ** j for j in range(K.cols)), T)
            assert sp.rem(sp.Poly(T ** k, T), m) == q
        if sum(abs(x) for x in p) <= N:
            hit_indices.append(k)
            if cert['case'] not in ['periodic', 'zero']:
                assert k <= cert['last_possible_index']
        p = A * p
    if 'root_certificate' in cert:
        c = cert['root_certificate']
        assert c['rho'] > 1 and c['rho'] ** 2 < c['min_modulus_squared']
        assert cert['excluded_power'] > cert['value_bound']
    results.append({'tag': tag, 'A': A, 'beta': beta, 'N': N,
                    'certificate': cert, 'hits': hits, 'checked_indices': final + 1})
    if len(results) % 20 == 0:
        print('checked', len(results), 'seconds', round(time.time()-tic, 2), flush=True)


for n in range(1, 7):
    I = sp.eye(n)
    for i in range(n-1): I[i, i+1] = 1
    check(I, sp.eye(n)[:, n-1], 20, 'unipotent_'+str(n))
    cycle = sp.zeros(n)
    for j in range(n): cycle[(j+1) % n, j] = 1
    check(cycle, sp.eye(n)[:, 0], 20, 'periodic_'+str(n))
check([[0,0,0,-1],[1,0,0,0],[0,1,0,-3],[0,0,1,0]], [1,0,0,0], 25,
      'genuinely_nonreal_expanding_roots')

inputs = json.loads((HERE/'agent_overlap_completion/height_event_root_results.json').read_text())['results']
for case, row in enumerate(inputs):
    n, B = row['rank'], row['B']
    cartan = sp.Matrix([[2 if i==j else -abs(B[i][j]) for j in range(n)] for i in range(n)])
    S = []
    for i in range(n):
        s = sp.eye(n)
        for j in range(n): s[i,j] -= cartan[i,j]
        S.append(s)
    C = sp.eye(n)
    for s in S: C = C*s
    for i in range(n):
        w = sp.eye(n)
        for j in range(i): w=w*S[j]
        bp = w[:,i]
        w = sp.eye(n)
        for j in range(n-1, i, -1): w=w*S[j]
        bm = w[:,i]
        check(C, bp, 12, f'case{case}_positive{i}')
        check(C.inv(), bm, 12, f'case{case}_negative{i}')

out = {'cases': len(results), 'checked_indices': sum(x['checked_indices'] for x in results),
       'seconds': time.time()-tic, 'all_exact': True, 'results': results}
(HERE/'integer_orbit_cutoff_results.json').write_text(json.dumps(jsonable(out), separators=(',', ':')))
print('DONE', out['cases'], out['checked_indices'], round(out['seconds'], 3), flush=True)
