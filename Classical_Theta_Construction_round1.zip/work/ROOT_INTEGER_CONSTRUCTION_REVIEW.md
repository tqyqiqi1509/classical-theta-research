# Root independent review of the finite integer reconstruction

2026-11-13 09:15 UTC. The scope is arbitrary-rank **acyclic skew-symmetric**
classical principal cluster algebras. This review is not a claim about
mutation-cyclic classes, all symmetrizers, or a cancellation-free formula.

## Independently checked proof chain

1. The standard capacity recursion and full-rank principal upper-bound
   membership give a finite box and exact integer neighbor equations.
2. The graded standard product has the displayed phase -R, with no missing
   normalization of its leading monomial. DM positivity plus bar symmetry
   gives the quadratic support bound. It applies to the theta comparator,
   not to an arbitrary classical positive basis.
3. The generic-prefix proof was checked formula by formula. In particular,
   Ur=-v-U^T e bounds every far-corner contributor in a fixed finite root box.
   The maximal-lambda choice followed by componentwise maximality really
   removes signed cancellations; no convexity of the quadratic carrier is
   assumed. The four constants in the explicit N threshold bound all
   remaining error terms. The far-corner coefficient1 follows from successive
   binomial divisibility, not from an unsupported intrinsic-degree assertion.
4. The capacity active-set boundaries have nonnegative path-count normals,
   bounded by rows of (I-A)^(-1). Thus u=M(g+Bp)+1 avoids both their boundaries
   and every required finite positive-normal hyperplane. The same active set
   is retained by Nu and Nu+e_i for the stated common N. On that set the
   induced capacity and freezing formulas are exact.
5. The large-jet search is finite and consists entirely of bounded integer
   arrays and binomial equations. Existence uses the true theta polynomial
   only in the proof. Prefix uniqueness makes the output independent of the
   arbitrary lexicographic completion. Exact rational/Bareiss elimination is
   an implementation alternative, not an oracle for unknown coefficients.
6. The ratio direction is correct: R_i=F_(Nu+e_i)/F_(Nu) gives the map from
   the comparison coordinates into initial coordinates. Hence the extractor
   is the inverse unitriangular matrix. The exponent in its forward matrix
   is g+Bq, not g alone. Frozen y_j are fixed; consequently z_j transforms
   by product_i R_i^(B_ij). These checks prevent the usual sign/coordinate
   mistakes.
7. The comparison proof only needs the last possible nontrivial bend. Its
   primitive positive normal alpha has degree at most K because a bend adds
   kE alpha with k>=1 and all increments are nonnegative. The backwards ray
   Q+t(g+Bp) stays off every such hyperplane under the explicit sign rule.
   This excludes every bent contribution to the extracted exponent. If
   Bp=0 but p is nonzero, the full frozen exponent still differs, so there
   is no unbent contribution either.
8. The finite target box is downward closed. A triangular substitution can
   only increase root degree componentwise; omitted indices outside the box
   cannot return. The inverse row therefore gives an exact recurrence using
   only q<p already computed. Its initial condition is1. The genuine theta
   coefficients satisfy the recurrence, proving equality by induction.

## Explicit combinatorial object and honest meaning

Let D=[0,d] intersect Z^n. Make a directed edge q->p for every strict
componentwise inequality q<p, with integer weight

    w(q->p)=-T^(u_p,g)_(p,q).

Then the target coefficient a_p is the sum over every directed path from0
to p of the product of its edge weights (with the empty path having weight1).
This follows by grouping paths by their last edge. The weights themselves
are specified by finite integer array enumeration, leading-unit power
series recursion, and unitriangular inversion; no wall functions, theta
coefficients, representation varieties, or broken lines are computed.

The weights may be negative. This is exactly an integer-weighted finite
combinatorial recurrence, not a positive-cardinality matching model.
Its identification with theta still uses audited existing theta results
and the last-bend comparison. A requirement that the *correctness proof*
also avoid all theta/scattering theory would be stronger and is not met.

The proof has been checked internally by root and two separate agents.
This is a research proof with explicit dependencies, not independent
external certification or a formal proof-assistant verification.

## Literature audit relevant to this final bridge

Davison--Mandel1910.12915v3, publisher Section3.3.5, Theorem3.16 proof,
was re-opened: it explicitly extracts a theta expansion coefficient by
choosing a nearby endpoint so that a proposed final monomial has no bent
contribution. The present argument uses an explicit containing arrangement
of every positive normal of degree<=K and proves a numerical bound for the
large-label monomial truncations. It does not assume cluster-atlas atomicity.

CMMM2505.09585v2 Sections3.4-3.5 were re-opened. Theorems3.7-3.8 imply the
Newton containment used here for finite theta expansions. Their Section3.8
references Li--Pan in background, but the VIT proof used here does not use
Li--Pan's asserted polytope-basis conclusions. No such conclusion enters
this construction.
