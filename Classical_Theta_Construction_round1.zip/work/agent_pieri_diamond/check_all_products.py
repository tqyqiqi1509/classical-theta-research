#!/usr/bin/env python3
from pathlib import Path
import json
P=Path(__file__).parent
R=[json.loads(f.read_text()) for f in (P/'cache').glob('d_*.json')]
R.sort(key=lambda x:(sum(x['d']),x['d']))
with (P/'capacity_basis_input.txt').open('w') as f:
 print(len(R),file=f)
 for r in R:
  print(*r['d'],len(r['F']),file=f)
  for t in r['F']:print(*t['p'],int(t['a']),file=f)
