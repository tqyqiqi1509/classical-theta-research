#!/usr/bin/env python3
"""Mechanism scan: is charged-slot Laurent elimination itself nonnegative?"""
import sys,json,time,random,math
from pathlib import Path
from itertools import product
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'agent_creation_caps'),str(BASE/'agent_positive_inventory')]
from cap_batch import pair_upper_caps
from linear_carrier import divisibility_space
from charged_caps import charged_caps
rng=random.Random(1372026);out=Path(__file__).with_name('charged_linear_scan.ndjson')
fail=[];stats={};tic=time.time()
with out.open('w') as f:
 for trial in range(300):
  n=3 if trial<100 else 4 if trial<250 else 5
  B=[[0]*n for _ in range(n)]
  for i in range(n):
   for j in range(i+1,n):
    w=rng.choices([0,1,2,3],[1,5,2,1])[0];B[i][j]=w;B[j][i]=-w
  d=tuple(rng.randint(1,7 if n==3 else 5 if n==4 else 3) for _ in range(n));g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n));points=list(product(*(range(a+1) for a in d)));caps,_=pair_upper_caps(B,g,d,points);S=[p for p in points if caps[p]];cc=charged_caps(B,d,S);S=[p for p in S if cc[p]]
  t=time.time();fr,space=divisibility_space(B,g,S);origin=fr[(0,)*n]
  neg=[(p,r) for p,r in fr.items() if min(r)<0]
  status='nonnegative_RREF' if not neg else 'signed_RREF';stats[status]=stats.get(status,0)+1
  rec={'trial':trial,'B':B,'d':d,'g':g,'status':status,'points':len(S),'space':space,'origin':origin,'negative_rows':len(neg),'seconds':time.time()-t}
  if neg:
   rec['example_negative_row']=neg[0]
   if len(fail)<15:fail.append({**rec,'fr':[[p,r] for p,r in fr.items()],'caps':[{'p':p,'a':min(caps[p],cc[p])} for p in S]})
  f.write(json.dumps(rec)+'\n');f.flush()
  if trial%10==0 or neg:print(trial,status,'n',n,'d',d,'dim',space['dimension'],'neg',len(neg),'seconds',round(time.time()-tic,2),flush=True)
Path(__file__).with_name('charged_linear_scan_summary.json').write_text(json.dumps({'stats':stats,'seconds':time.time()-tic,'first_failures':fail},separators=(',',':')))
