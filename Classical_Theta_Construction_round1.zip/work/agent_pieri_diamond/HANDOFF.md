# Handoff at 09:28 UTC — strict Pieri to a finite integer theta reconstruction

## Main outcome

The branch started by strengthening the full recursive Pieri experiment. It then independently reviewed the new Q-prefix theorem and implemented the finite ratio/extraction reconstruction. **The K4 target d=(4,5,5,6), g=(-4,-1,4,8), is now genuinely identified with classical theta under the separately reviewed reconstruction theorem**, not merely selected as an LP least point.

Read these first:

1. `../agent_asymptotic_detector/FINITE_INTEGER_THETA_RECONSTRUCTION.md` — general theorem and proof, owned by the asymptotic agent.
2. `integer_ratio_reconstruction.py` — standalone reference implementation, only Python/SymPy dependencies.
3. `CLUSTER_ACCELERATOR_AND_API.md` — full operational/certificate proof and direction conventions.
4. `integer_ratio_k4.json` — completed high-rank output and all six extraction certificates.
5. `PREFIX_RIGIDITY_INDEPENDENT_REVIEW.md` — my independent proof review.

## Exact completed reconstruction

For unit topological K4, the **raw Q carrier** has 173 points and Laurent dimension7. This is different from the earlier graph∩Q carrier, which has130 points and dimension6. No graph cap is used in the new K4 reconstruction.

The six extraction roots and zero-based actual mutation words are:

- p=(2,3,2,1), word empty;
- p=(3,2,3,1), word empty;
- p=(3,3,2,2), word empty;
- p=(2,2,1,1), word(1);
- p=(3,2,1,1), word(1,2,3,1,2);
- p=(3,2,2,1), word(1,2,3,1,2,3).

The resulting exact parameter rows are the six coordinate unit rows, in the saved target nullspace basis; normalization fixes its final parameter. Output is integral and nonnegative, mass1829, equal as a polynomial to the earlier strict-Pieri least candidate. The last two roots were the actual missing selectors; using later RREF monomials p3332/p3433 gives identically zero extraction rows because those are descendants of earlier theta roots.

`integer_ratio_primitive.json` reconstructs the transitive triangle d=(2,2,2), mass14, with central t=0. This is the reduced version of the previous K4 d0222 obstruction. Its target mutable exponent is zero, so the initial chart extractor already kills t. `integer_ratio_wild2.json` gives the b=c=3, d=(3,4) output, mass26.

## The actual Q/Laurent branch was also executed

The reference implementation does not merely call a cluster oracle. With B12=3, directionu=(-5,3), N=4, prefix box(1,1), three Q carriers of493,439,479 points have full Laurent dimensions8,9,10. Every required prefix row is nevertheless exactly proportional to the origin row. The computed ratios are

- R1=1−z1−3z1z2;
- R2=1−3z1z2,

modulo the box. Only **after** computing these without an oracle was a classical LLZ prefix formula evaluated for an independent comparison; it agrees. Files: `noncluster_ratio_certificate.json`, `noncluster_jet_certificates/`. Runtime approximately28seconds.

## Key code conventions

`R_i=F_(Nu+e_i)/F_(Nu)` gives **psi=iota_initial o iota_u inverse**, not its inverse. Frozen y variables are fixed. Therefore the normalized matrix is

`A_pq=[z^(p−q)] R^(g+Bq)`.

The extractor is the p row of **A inverse**. The code implements triangular peeling directly.

The optional actual-cluster accelerator mutates `(B;I)`, records C, uses G inverse=C transpose, and checks `G inverse(Nu+e_i)>=0`. F jets come from the exact exchange binomial recurrence. Its finite cone search is only an optimization; if it fails, baseline Q/Laurent solving remains. The code has explicit point/box resource caps and records a resource stop honestly. Earlier large literal-box failures are saved and were resolved for the K4 test by the actual cluster certificates, not suppressed.

Root found and I fixed a minor completeness bound: the capacity path bound in `direction()` is the maximum row sum of **U inverse transpose**, not U inverse. The code also verifies the actual finite normal and capacity conditions, so prior computed certificates were valid before that correction.

## Earlier strict-Pieri results and their limited status

`strict_pieri.py` accepts every nontrivial layer only after exact coefficientwise leastness certificates. No mass-only lower candidate is inserted.

All1260 capacities below d4556 passed full smaller-basis lowering and creation. Classification:

-170 genuine rank≤2 bases;
-34 genuine-cap Laurent unique spaces;
-1056 recursively least higher-rank candidates.

The zero-diamond residual affine dimensions among those1056 are 0/1/2/3 in808/224/23/1 cases. No graph/all-split fallback was necessary. These1260 records do **not** all become theta-identified merely because the top target was reconstructed separately.

Every unordered proper capacity split was then tested by exact integer C++ expansion: **91,404 products**, all nonnegative, with3,721,691 positive lower coordinates. This is finite coherent-basis evidence, not an all-capacity proof. Files: `check_all_products.cpp`, `check_all_products.py`, `capacity_basis_input.txt`, `all_products_summary.json`.

## Failed routes retained

- Charged cap+pair constraints alone have the least mass1829 but leave a nonunique five-parameter feasible family. Never equate that minimum alone with theta.
- The first charged recursion that demanded theta identification stopped at d0222, where all proper split/local inventories leave t∈[0,1]. This was resolved only by the new extractor.
- Literal “Q-truncated Laurent RREF has all nonnegative columns” is false:22 signed RREFs in a300-input weighted acyclic rank3–5 mechanism scan. Some origin columns are negative as well. See `charged_linear_scan_summary.json`. This failed route was stopped rather than extrapolated.

## Audits and literature records

`RESEARCH_LOG.md` and `LITERATURE_REVIEW.json` record the routes and the09:05 refresh. Qiyue Tang Hexagon2610.00025v3 Sections3–5 supplied an interface idea only; no quantum rank-two conclusion was imported as a classical theorem. The new generic prefix proof was checked independently here in full. Another branch is independently reviewing the final ratio theorem and code certificates.

## Runtime state and next work

No computation is intentionally left running. All reported outputs are observed completed artifacts. The overall parent research continues until10:12:08UTC. At09:28, useful next tasks are: a small independent direct-mutation check of the two nontrivial K4 chart certificates; careful extension of the proof to skew-symmetrizable inputs only after the Q comparison is genuinely available; and improving large-box integer elimination without weakening the certified uniqueness checks. The general acyclic skew construction should now be the main deliverable, with broader scope limits explicit.
