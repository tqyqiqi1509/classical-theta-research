# Reference API and the certified cluster acceleration

## Scope

`integer_ratio_reconstruction.py` constructs finite coefficients for a classical acyclic skew-symmetric principal-coefficient input. Its correctness comparison is the theorem in `../agent_asymptotic_detector/FINITE_INTEGER_THETA_RECONSTRUCTION.md`; that theorem has been reviewed separately. This code takes no theta coefficients, scattering data, wall functions, or broken lines as input. It uses exact rational linear algebra internally, and checks every emitted jet and final coefficient is integral.

The standalone script depends only on Python and SymPy. The implementation deliberately exposes finite computational budgets. A resource stop is neither a negative mathematical result nor a completed reconstruction.

## Baseline operations

`canonical(B,g)` computes `g=v-(I-[-B]_+)d` by topological forward substitution, with nonnegative complementary `d,v`.

`Qsupport(B,d)` enumerates the integer box and retains

\[
Q_d(p)=(d-p)^T(I-[B]_+)p\geq 0.
\]

`divisibility_space(B,g,S)` constructs the exact homogeneous Laurent space on a finite support `S`. In a fiber in direction `i`, put `r=max(-g_i-sum_j B_ij p_j,0)`. The coefficient equations are the first `r` derivatives at `t=-1`, with integer entries `binom(p_i,j)(-1)^(p_i-j)`. They are exactly divisibility by `(1+t)^r`.

`IntegerJets.jet(B,g,box)` computes a finite prefix from this Laurent space. It accepts the prefix only when every required coefficient row is exactly proportional to the origin row. Thus free parameters in the full Laurent space are never arbitrarily set to zero. Rank-zero and rank-one cases use their immediate unique binomial fiber solutions. A finite A2 exchange-fan acceleration is also available. Optional support pruning removes an entire fiber if its number of allowed monomials is at most its divisibility order: the corresponding falling-factorial Vandermonde matrix has full column rank, so all its coefficients must vanish.

`IntegerJets.ratios(B,m,box)` chooses a certified direction near `m`, obtains the required large-label jets, and returns

\[
R_i=F_{Nu+e_i}/F_{Nu}.
\]

If the requested prefix is not unique at the current certified ray threshold, the code increases `N`. The baseline geometric box and point budgets are explicit. The mathematical theorem supplies a terminating finite threshold without these implementation budgets.

## Exact direction and ray certificates

For a coefficient box of total degree `K`, the code tests the finite normal set `q>=0`, `0<|q|<=K`. It chooses `u=M m+ones` such that every nonzero `q dot m` keeps its sign, every `q dot u` is nonzero, and the canonical capacity decomposition of `u` is in an open cell. A sufficient search bound is `M>max(K,C_B)`, where `C_B` is the maximum row sum of `U^(-T)`, `U=I-[B]_+`. The program tests the actual conditions, including the capacity condition, rather than assuming them from an approximate bound.

For each normal q, put `s=sign(q dot u)`. The minimum of

` s q dot (N u+h+B beta) `

for `h` in `{0,e_i}` and `beta>=0`, `|beta|<=K`, is bounded below by

`N abs(q dot u) + min(0,min_i s q_i) + K min(0,min_j s (q^T B)_j)`.

`ray_threshold` chooses an integer N making all these bounds strictly positive. This involves only finite integer arithmetic.

## Actual cluster cone acceleration

The optional search mutates the actual extended exchange matrix starting from `(B;I)`. It records its finite mutation word and final matrices `B_t,C_t`. For a skew-symmetric principal seed, the computed g-matrix is `G_t=C_t^(-T)`. A candidate direction is accepted only when its exact cone coordinates `alpha=C_t^T u` are nonnegative. If some vanish, the code moves into the cone using `u'=M u+G_t ones`; M is chosen by explicit finite normal inequalities so that the relevant hyperplane cell is unchanged. Then every coordinate of `C_t^T u'` is strictly positive.

The final N also satisfies

\[
N\alpha_j+(G_t^{-1})_{ji}\geq0
\quad\hbox{for every }i,j.
\]

Consequently `Nu` and every `Nu+e_i` are genuine nonnegative cluster-monomial labels in the recorded actual seed. Their F-polynomials are computed by the exchange recurrence

\[
F'_k=\frac{z^{[C_{*k}]_+}\prod_jF_j^{[b_{jk}]_+}
+z^{[-C_{*k}]_+}\prod_jF_j^{[-b_{jk}]_+}}{F_k}.
\]

Formal division is integral since `F_k(0)=1`, and the finite prefix is sufficient for every operation. Their large powers cancel in the ratio, giving the exact formula

\[
R_i=\prod_jF_j^{(G_t^{-1})_{ji}}.
\]

Thus the acceleration uses an explicit finite cluster certificate and binomial exchanges. It is not an assumption that every generic direction belongs to a cluster cone. The bounded search may fail; the Q/Laurent solver then remains the general baseline.

## Extraction direction

The ratios give `psi=iota_initial o iota_u^(-1)`, hence

\[
\psi(x_i)=x_iR_i,\quad\psi(y_j)=y_j,\quad
\psi(z_j)=z_j\prod_iR_i^{B_{ij}}.
\]

On homogeneous degree g, its matrix is

\[
A_{pq}=[z^{p-q}]\prod_iR_i^{g_i+(Bq)_i}.
\]

It is unitriangular. `extract_row` computes a row of **A inverse** by exact triangular peeling. It does not mistakenly use A itself. At a nonzero root p, choosing the direction near `m=g+Bp` makes this inverse row vanish on the desired basis element. These equations, together with origin coefficient one, determine the finite target Laurent polynomial.

`reconstruct_space(B,g,S,engine,outfile)` obtains these rows adaptively until their rank is the full dimension of the target Laurent space. The order favors inexpensive actual cluster charts, but every added row has a complete certificate. A full-rank system is required before output is labeled a reconstruction. The general coefficient-by-coefficient version is the same unitriangular recurrence without this linear-space acceleration.

## Reproduction

Run:

```bash
python work/agent_pieri_diamond/integer_ratio_reconstruction.py --case primitive
python work/agent_pieri_diamond/integer_ratio_reconstruction.py --case k4
python work/agent_pieri_diamond/integer_ratio_reconstruction.py --case wild2
```

The K4 run uses its raw Q carrier: 173 points, Laurent dimension7. Six exact extraction rows plus normalization determine an integral nonnegative polynomial of mass1829. Its two longest chart certificates are the zero-based words `(1,2,3,1,2)` and `(1,2,3,1,2,3)`. This is a genuine reconstruction under the comparison theorem, whereas the earlier strict Pieri candidate by itself was only a certified least candidate.

`noncluster_ratio_certificate.json` and `noncluster_jet_certificates/` document a distinct test of the actual Q/Laurent baseline: B12=3, u=(-5,3), N=4, prefix box(1,1). The three full Laurent spaces have dimensions8,9,10 but all required prefix rows are exactly fixed. A separate LLZ calculation was used only after the no-oracle computation, as an independent check.
