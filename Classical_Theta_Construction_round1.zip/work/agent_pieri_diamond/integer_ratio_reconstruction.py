#!/usr/bin/env python3
"""Pure integer/binomial Laurent reconstruction; theta is not an input.

At each requested coefficient choose a finite integer direction. Large-label
jets come from exact Laurent divisibility inside the quadratic carrier; each
jet must be uniquely certified. Rank-zero/one fibers are evaluated directly
by their unique binomial solution. Ratios produce psi, inverse triangular
peeling produces the extraction row. No greedy/theta oracle is called.
"""
from pathlib import Path
from itertools import product
from functools import lru_cache
from fractions import Fraction
from collections import defaultdict
from collections import deque
from math import comb,gcd
import sys,json,time,hashlib
BASE=Path(__file__).resolve().parents[1]
import sympy as sp

def atomic(path,obj):
 path=Path(path);tmp=path.with_suffix('.writing');tmp.write_text(json.dumps(obj,separators=(',',':')));tmp.replace(path)
def dump_poly(F):return [{'p':p,'a':str(a)} for p,a in sorted(F.items(),key=lambda item:(sum(item[0]),item[0])) if a]
def divisibility_space(B,g,points):
 """Exact binomial Laurent equations; only B,g and integer points are used."""
 points=tuple(map(tuple,points));ids={p:i for i,p in enumerate(points)};rows=[]
 for k in range(len(g)):
  fibers=defaultdict(list)
  for p in points:fibers[p[:k]+p[k+1:]].append(p)
  for off,P in fibers.items():
   p=off[:k]+(0,)+off[k:];order=max(-g[k]-sum(B[k][j]*p[j] for j in range(len(g))),0)
   for j in range(min(order,max(p[k] for p in P)+1)):
    row=[0]*len(points)
    for p in P:
     if p[k]>=j:row[ids[p]]=comb(p[k],j)*(-1)**(p[k]-j)
    if any(row):rows.append(row)
 A=sp.Matrix(rows) if rows else sp.zeros(0,len(points));null=A.nullspace();cols=[]
 for v in null:
  den=sp.ilcm(*[x.q for x in v]) if len(v)>1 else v[0].q
  cols.append([int(x*den) for x in v])
 fr={p:tuple(v[i] for v in cols) for i,p in enumerate(points)};fr={p:r for p,r in fr.items() if any(r)}
 return fr,{'points':len(points),'equations':A.rows,'dimension':len(cols),'rank':len(points)-len(cols)}


def pts(box):return sorted(product(*(range(a+1) for a in box)),key=lambda p:(sum(p),p))
def degree_pts(n,K):return [p for p in pts((K,)*n) if 0<sum(p)<=K]
def inside(p,box):return all(0<=a<=b for a,b in zip(p,box))
def addp(p,q):return tuple(a+b for a,b in zip(p,q))
def subp(p,q):return tuple(a-b for a,b in zip(p,q))
def mul(F,G,box):
 H=defaultdict(int)
 for p,a in F.items():
  for q,b in G.items():
   r=addp(p,q)
   if inside(r,box):H[r]+=a*b
 return {p:a for p,a in H.items() if a}
def inv(F,box):
 zz=(0,)*len(box);assert F.get(zz)==1
 H={zz:1}
 for p in pts(box)[1:]:
  a=-sum(v*H.get(subp(p,q),0) for q,v in F.items() if any(q) and inside(q,p))
  if a:H[p]=a
 return H
def power(F,k,box):
 if k<0:return power(inv(F,box),-k,box)
 H={(0,)*len(box):1}
 while k:
  if k&1:H=mul(H,F,box)
  k//=2
  if k:F=mul(F,F,box)
 return H
def monomial_image(R,h,box):
 H={(0,)*len(box):1}
 for F,k in zip(R,h):
  if k:H=mul(H,power({p:a for p,a in F.items() if inside(p,box)},k,box),box)
 return H

def canonical(B,g):
 n=len(g);d=[];v=[]
 for i in range(n):
  t=g[i]-sum(max(-B[i][j],0)*d[j] for j in range(i))
  d.append(max(-t,0));v.append(max(t,0))
 return tuple(d),tuple(v)

def direction(B,m,K):
 n=len(m);Q=degree_pts(n,K);U=sp.eye(n)-sp.Matrix([[max(B[i][j],0) for j in range(n)] for i in range(n)])
 C=max(sum(int(abs(a)) for a in row) for row in U.inv().T.tolist())
 for M in range(1,max(K,int(C))+2):
  u=tuple(M*a+1 for a in m)
  if not any(u):continue
  if any(sum(q[i]*u[i] for i in range(n))==0 or (sum(q[i]*m[i] for i in range(n))*sum(q[i]*u[i] for i in range(n))<0) for q in Q):continue
  d,v=canonical(B,u)
  if any(d[i]==v[i]==0 for i in range(n)):continue
  gg=gcd(*u);u=tuple(a//gg for a in u)
  return u,{'M':M,'capacity_path_bound':int(C),'normal_count':len(Q)}
 raise ArithmeticError(('no certified direction',B,m,K))

def ray_threshold(B,u,K):
 n=len(u);N=1
 for q in degree_pts(n,K):
  dot=sum(a*b for a,b in zip(q,u));assert dot
  sign=1 if dot>0 else -1
  # Minimum over offsets {0,e_i} and all beta>=0, |beta|<=K.
  off=min(0,min(sign*a for a in q))
  beta=K*min(0,min(sign*sum(q[i]*B[i][j] for i in range(n)) for j in range(n)))
  N=max(N,(-(off+beta))//abs(dot)+1)
 return N

def seed_mutate(B,C,k):
 n=len(B)
 def update(r,is_mutable):
  return tuple(-r[j] if j==k or (is_mutable and is_mutable-1==k) else r[j]+max(r[k],0)*max(B[k][j],0)-max(-r[k],0)*max(-B[k][j],0) for j in range(n))
 BB=tuple(update(B[i],i+1) for i in range(n));CC=tuple(update(C[i],0) for i in range(n))
 return BB,CC

def cluster_chart(B,u,K,max_states=30000,max_depth=16):
 """Search accelerator only; returns an explicit actual-seed cone witness."""
 n=len(B);B=tuple(map(tuple,B));C=tuple(tuple(int(i==j) for j in range(n)) for i in range(n));todo=deque([(B,C,())]);seen={(B,C)}
 while todo:
  BB,C,w=todo.popleft();alpha=tuple(sum(C[j][i]*u[j] for j in range(n)) for i in range(n))
  if min(alpha)>=0:
   Gi=sp.Matrix(C).T;G=Gi.inv();assert all(a.q==1 for a in G)
   if not min(alpha):
    shift=tuple(int(sum(G[i,j] for j in range(n))) for i in range(n));M=1
    for q in degree_pts(n,K):
     old=sum(a*b for a,b in zip(q,u));delta=sum(a*b for a,b in zip(q,shift));assert old
     M=max(M,abs(delta)//abs(old)+1)
    u=tuple(M*a+b for a,b in zip(u,shift));alpha=tuple(int(a) for a in Gi*sp.Matrix(u));assert min(alpha)>0
   return {'word':w,'B':BB,'C':C,'G_inverse':[[int(a) for a in row] for row in Gi.tolist()],'u':u,'cone_coordinates':alpha,'visited':len(seen)}
  if len(w)>=max_depth:continue
  # A target cone is approached only through currently violated faces.
  for k in range(n):
   if alpha[k]>=0:continue
   B2,C2=seed_mutate(BB,C,k);key=(B2,C2)
   if key in seen:continue
   seen.add(key);todo.append((B2,C2,w+(k,)))
   if len(seen)>=max_states:return None
 return None

def cluster_F_jets(B,word,box):
 n=len(B);zz=(0,)*n;B=tuple(map(tuple,B));C=tuple(tuple(int(i==j) for j in range(n)) for i in range(n));F=[{zz:1} for _ in range(n)]
 for k in word:
  terms=[]
  for sign in (1,-1):
   p=tuple(max(sign*C[i][k],0) for i in range(n));P={p:1} if inside(p,box) else {}
   for j in range(n):
    a=max(sign*B[j][k],0)
    if a:P=mul(P,power(F[j],a,box),box)
   terms.append(P)
  H=defaultdict(int)
  for P in terms:
   for p,a in P.items():H[p]+=a
  F[k]=mul(dict(H),inv(F[k],box),box);assert F[k].get(zz)==1
  B,C=seed_mutate(B,C,k)
 return F

def prune(B,g,S):
 S=set(S);rounds=0
 while True:
  bad=set()
  for k in range(len(g)):
   fibers=defaultdict(list)
   for p in S:fibers[p[:k]+p[k+1:]].append(p)
   for off,P in fibers.items():
    p=P[0];r=max(-g[k]-sum(B[k][j]*p[j] for j in range(len(g))),0)
    if len(P)<=r:bad.update(P)
  if not bad:return sorted(S,key=lambda p:(sum(p),p)),rounds
  S.difference_update(bad);rounds+=1

class JetFailure(Exception):pass

class IntegerJets:
 def __init__(self,directory=None,point_budget=16000,box_budget=2000000):
  self.cache={};self.records=[];self.point_budget=point_budget;self.box_budget=box_budget;self.path=Path(directory) if directory else None
  if self.path:self.path.mkdir(parents=True,exist_ok=True)
 def jet(self,B,g,box):
  B=tuple(map(tuple,B));g=tuple(g);box=tuple(box);n=len(g);d,v=canonical(B,g);I=tuple(i for i,a in enumerate(d) if a)
  key=(B,d,box)
  if key in self.cache:return self.cache[key]
  zz=(0,)*n
  if len(I)<=1:
   F={zz:1}
   if I:
    i=I[0]
    F={tuple(k if j==i else 0 for j in range(n)):comb(d[i],k) for k in range(min(d[i],box[i])+1)}
   self.records.append({'g':g,'d':d,'box':box,'active':I,'status':'unique_binomial_fiber','terms':len(F)})
   self.cache[key]=F;return F
  BB=tuple(tuple(B[i][j] for j in I) for i in I);dd=tuple(d[i] for i in I);gg=tuple(g[i] for i in I);bb=tuple(box[i] for i in I)
  if len(I)==2 and BB[0][1]==1:
   # Exact five-seed A2 exchange computation, used only as an accelerator.
   # Every listed polynomial follows by the exchange binomial; no basis
   # or theta coefficients are supplied. Adjacent g columns are unimodular.
   z=(0,0);one={z:1}
   fan=[((1,0),one),((0,1),one),((-1,1),{z:1,(1,0):1}),((-1,0),{z:1,(1,0):1,(1,1):1}),((0,-1),{z:1,(0,1):1})]
   for k in range(5):
    a,P=fan[k];b,H=fan[(k+1)%5];det=a[0]*b[1]-a[1]*b[0]
    x=Fraction(gg[0]*b[1]-gg[1]*b[0],det);y=Fraction(a[0]*gg[1]-a[1]*gg[0],det)
    if x.denominator==y.denominator==1 and min(x,y)>=0:
     FF=mul(power(P,int(x),bb),power(H,int(y),bb),bb);F={}
     for p,c in FF.items():
      pp=[0]*n
      for i,beta in zip(I,p):pp[i]=beta
      F[tuple(pp)]=c
     self.records.append({'g':g,'d':d,'box':box,'active':I,'status':'exact_exchange_cluster_monomial','seed_g_columns':[a,b],'nonnegative_powers':[int(x),int(y)]})
     self.cache[key]=F;return F
   raise ArithmeticError(('A2 fan incomplete',gg))
  total=1
  for a in dd:total*=a+1
  if total>self.box_budget:raise JetFailure({'status':'box_resource','g':g,'d':d,'box_points':total})
  S=[]
  for p in product(*(range(a+1) for a in dd)):
   Q=sum(p[i]*(dd[i]-p[i]) for i in range(len(I)))-sum(BB[i][j]*(dd[i]-p[i])*p[j] for i in range(len(I)) for j in range(i+1,len(I)))
   if Q>=0:S.append(p)
  raw=len(S);S,rounds=prune(BB,gg,S)
  if len(S)>self.point_budget:raise JetFailure({'status':'point_resource','g':g,'d':d,'points':len(S),'raw':raw})
  print('PROBE',g,'capacity',d,'active',I,'Qpoints',raw,'pruned',len(S),'box',box,flush=True)
  t=time.time();fr,space=divisibility_space(BB,gg,S);origin=fr[(0,)*len(I)];j=next(j for j,a in enumerate(origin) if a);F={};unfixed=[]
  for p in pts(bb):
   row=fr.get(p,(0,)*len(origin));a=Fraction(row[j],origin[j])
   if any(Fraction(v)!=a*w for v,w in zip(row,origin)):
    unfixed.append(p);continue
   if a:
    assert a.denominator==1,('nonintegral unique theta jet',g,p,a)
    pp=[0]*n
    for i,b in zip(I,p):pp[i]=b
    F[tuple(pp)]=int(a)
  rec={'B':B,'g':g,'d':d,'box':box,'active':I,'status':'exact_unique_prefix' if not unfixed else 'unfixed_prefix','space':space,'raw_Q_points':raw,'prune_rounds':rounds,'seconds':time.time()-t,'unfixed':unfixed[:10]}
  self.records.append(rec)
  if unfixed:raise JetFailure(rec)
  if self.path:
   tag=hashlib.sha256(repr(key).encode()).hexdigest()[:16]
   atomic(self.path/(tag+'.json'),{**rec,'prefix':dump_poly(F),'origin':origin,'coefficient_rows':[[p,row] for p,row in fr.items()]})
  self.cache[key]=F;return F
 def ratios(self,B,m,box,max_tries=4):
  n=len(m);K=sum(box);u,detail=direction(B,m,K);N=ray_threshold(B,u,K);attempts=[]
  chart=cluster_chart(B,u,K)
  if chart is not None:
   u=tuple(chart['u']);Gi=chart['G_inverse'];alpha=chart['cone_coordinates'];N=ray_threshold(B,u,K)
   for j in range(n):
    for i in range(n):N=max(N,(-Gi[j][i])//alpha[j]+1)
   assert all(N*alpha[j]+Gi[j][i]>=0 for i in range(n) for j in range(n))
   F=cluster_F_jets(B,chart['word'],box)
   R=[monomial_image(F,tuple(Gi[j][i] for j in range(n)),box) for i in range(n)]
   rec={'status':'actual_cluster_cone_accelerator','box':box,'chart':chart,'N':N,'ray_threshold':ray_threshold(B,u,K)};self.records.append(rec)
   return R,{'u':u,'N':N,'ray_threshold':ray_threshold(B,u,K),'direction':detail,'cluster_certificate':chart,'attempts':attempts,'probe_count':len(self.records)}
  # This is a certified search: exact finite ray inequalities and uniqueness
  # are checked at the chosen N; no observed stabilization is substituted.
  for attempt in range(max_tries):
   try:
    g=tuple(N*a for a in u);F=self.jet(B,g,box);G=inv(F,box);R=[]
    for i in range(n):
     h=tuple(g[j]+(i==j) for j in range(n));R.append(mul(self.jet(B,h,box),G,box))
    return R,{'u':u,'N':N,'ray_threshold':ray_threshold(B,u,K),'direction':detail,'attempts':attempts,'probe_count':len(self.records)}
   except JetFailure as e:
    attempts.append(e.args[0]);N*=2
  raise JetFailure({'m':m,'box':box,'u':u,'attempts':attempts})

def extract_row(B,g,p,R,fr):
 width=len(next(iter(fr.values())));zero=(0,)*width;rem={q:tuple(fr.get(q,zero)) for q in pts(p)}
 for q in pts(p):
  row=rem.pop(q,zero)
  if q==p:return row
  if not any(row):continue
  h=tuple(g[i]+sum(B[i][j]*q[j] for j in range(len(g))) for i in range(len(g)))
  T=monomial_image(R,h,subp(p,q))
  for r,a in T.items():
   if not any(r):continue
   t=addp(q,r);old=rem.get(t,zero);rem[t]=tuple(x-a*y for x,y in zip(old,row))
 raise ArithmeticError('missing extraction row')

def reconstruct_space(B,g,S,probe_engine,outfile):
 fr,space=divisibility_space(B,g,S);width=space['dimension'];zz=(0,)*len(g);origin=fr[zz];rows=[origin];rhs=[1];steps=[];tic=time.time()
 # A free-column monomial is a useful pivot proposal, never an oracle.
 oj=next(j for j,a in enumerate(origin) if a)
 def cheapness(p):
  m=tuple(g[i]+sum(B[i][j]*p[j] for j in range(len(g))) for i in range(len(g)))
  dd,_=canonical(B,m)
  return (sum(a>0 for a in dd),sum(a!=0 for a in fr[p])!=1,sum(p),p)
 candidates=sorted((p for p in fr if any(p) and any(Fraction(a)*origin[oj]!=Fraction(fr[p][oj])*b for a,b in zip(fr[p],origin))),key=cheapness)
 for p in candidates:
  if sp.Matrix(rows).rank()==width:break
  m=tuple(g[i]+sum(B[i][j]*p[j] for j in range(len(g))) for i in range(len(g)));R,cert=probe_engine.ratios(B,m,p);row=extract_row(B,g,p,R,fr)
  if not any(row):continue
  nr=sp.Matrix(rows+[row]).rank()
  if nr>len(rows):
   rows.append(row);rhs.append(0);steps.append({'p':p,'m':m,'row':row,'ratio_certificate':cert,'R':[dump_poly(x) for x in R]})
   print('EXTRACT',p,'mutable',m,'rank',nr,'of',width,'N',cert['N'],'u',cert['u'],flush=True)
 sol,pars=sp.Matrix(rows).gauss_jordan_solve(sp.Matrix(rhs));assert not pars.rows,('not unique',space,len(rows))
 F={p:sum(a*b for a,b in zip(row,sol)) for p,row in fr.items()};assert all(a.q==1 for a in F.values());F={p:int(a) for p,a in F.items() if a}
 result={'B':B,'g':g,'space':space,'status':'exact_integer_reconstruction','F':dump_poly(F),'mass':sum(F.values()),'nonnegative':all(a>=0 for a in F.values()),'parameters':[str(a) for a in sol],'steps':steps,'jet_records':probe_engine.records,'seconds':time.time()-tic,'scope':'construction uses Q carrier, binomial Laurent equations and integer ratios only; theta identification by independent finite chart comparison theorem'}
 atomic(outfile,result);return F,result

def Qsupport(B,d):
 return [p for p in pts(d) if sum(p[i]*(d[i]-p[i]) for i in range(len(d)))-sum(B[i][j]*(d[i]-p[i])*p[j] for i in range(len(d)) for j in range(i+1,len(d)))>=0]

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--case',default='k4',choices=['k4','primitive','a2','wild2','weighted3']);ar=ap.parse_args();out=Path(__file__).parent
 engine=IntegerJets(out/'ratio_jet_certificates')
 if ar.case=='k4':
  B=[[1 if i<j else -1 if i>j else 0 for j in range(4)] for i in range(4)];g=[-4,-1,4,8];d=[4,5,5,6];S=Qsupport(B,d)
 elif ar.case=='primitive':B=[[0,1,1],[-1,0,1],[-1,-1,0]];d=[2,2,2];g=[-2,0,2];S=Qsupport(B,d)
 elif ar.case=='a2':B=[[0,1],[-1,0]];d=[2,3];g=[-2,-1];S=Qsupport(B,d)
 elif ar.case=='wild2':B=[[0,3],[-3,0]];d=[3,4];g=[-3,5];S=Qsupport(B,d)
 else:B=[[0,1,2],[-1,0,2],[-2,-2,0]];d=[6,7,6];g=[-6,-1,20];S=Qsupport(B,d)
 try:
  F,result=reconstruct_space(B,g,S,engine,out/('integer_ratio_'+ar.case+'.json'))
  print('DONE',ar.case,result['space'],'mass',result['mass'],'nonnegative',result['nonnegative'],'seconds',result['seconds'],flush=True)
 except JetFailure as e:
  atomic(out/('integer_ratio_'+ar.case+'_failure.json'),{'failure':e.args[0],'records':engine.records});print('STOP',ar.case,e.args[0],flush=True)
