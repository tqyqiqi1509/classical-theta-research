#!/usr/bin/env python3
"""Strict finite capacity recursion: stop before choosing any non-least layer.

Rank <=2 is LLZ. Dimension-one true-cap Laurent carriers identify theta.
Other certified least layers remain conditional candidates. All LP answers
are checked over Q, and no failed layer enters the cache.
"""
from pathlib import Path
import sys,json,time,math
from itertools import product
from fractions import Fraction
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_creation_caps'),str(ROOT/'agent_overlap_completion'),str(ROOT/'agent_interior')]
from cap_batch import pair_upper_caps,primitive,exact_conic_scaled,propose_optimum,evaluate,dump_poly,quotient_rows
from linear_carrier import divisibility_space
from ranktwo_packets import section_rows
from schofield_carrier import acyclic_dimension
from block_upper_caps import block_polynomial,block_upper_caps,multiply
from pieri_recursive import addrow,rank_mod
import sympy as sp


def atomic(path,obj):
 p=Path(path);t=p.with_suffix('.writing');t.write_text(json.dumps(obj,separators=(',',':')));t.replace(p)

def asrow(row,points,fr,width):
 ans=[0]*width
 for k,c in row.items():
  for j,a in enumerate(fr.get(points[k],(0,)*width)):ans[j]+=c*a
 return tuple(ans)

class StopLayer(Exception):pass

class StrictPieri:
 def __init__(self,B,directory,all_splits=False,graph_on_failure=True,charged=False,require_identified=False):
  self.B=tuple(map(tuple,B));self.n=len(B);self.A=[[max(-B[i][j],0) for j in range(self.n)] for i in range(self.n)]
  self.path=Path(directory);self.path.mkdir(parents=True,exist_ok=True);self.cache={};self.records={};self.active=set();self.start=time.time()
  self.all_splits=all_splits;self.graph_on_failure=graph_on_failure;self.last=None
  self.charged=charged;self.require_identified=require_identified
  for f in self.path.glob('d_*.json'):
   r=json.loads(f.read_text());d=tuple(r['d'])
   if r.get('accepted'):
    self.cache[d]={tuple(q['p']):int(q['a']) for q in r['F']};self.records[d]=r
 def label(self,d):return tuple(-d[i]+sum(self.A[i][j]*d[j] for j in range(self.n)) for i in range(self.n))
 def save(self,d,r,F=None):
  r.update(B=self.B,d=d,g=self.label(d))
  if F is not None:r['F']=dump_poly(F)
  atomic(self.path/('d_'+'_'.join(map(str,d))+'.json'),r)
  if r.get('accepted'):
   self.cache[d]=F;self.records[d]=r
  return F
 def expand_rows(self,g,d,points,initial):
  rem={p:dict(r) for p,r in initial.items()};out={};zero=[];deps=set()
  for q in points:
   row=rem.pop(q,{})
   if not row:continue
   h=tuple(g[k]+sum(self.B[k][j]*q[j] for j in range(self.n)) for k in range(self.n))
   dh=tuple(acyclic_dimension(self.B,h)[0])
   if all(q[k]+dh[k]<=d[k] for k in range(self.n)) and sum(dh)<sum(d):
    H=self.get(dh);deps.add(dh);out[q]=row
    for p,a in H.items():
     if not any(p):continue
     r=tuple(q[k]+p[k] for k in range(self.n));rem[r]=addrow(rem.get(r,{}),row,-a)
   else:zero.append(row)
  if any(rem.values()):raise ArithmeticError('expansion escaped box')
  return out,zero,deps
 def solve(self,fr,origin,RR):
  width=len(origin);RR=list(dict.fromkeys(primitive(r) for r in RR if any(r)))
  cost=tuple(sum(r[j] for r in fr.values()) for j in range(width));opt=propose_optimum(cost,RR,origin)
  out={'constraints':len(RR),'mass_optimization':opt}
  if not opt.get('parameters'):return None,dict(out,status='unresolved_mass'),RR
  x=list(map(Fraction,opt['parameters']));F={p:evaluate(row,x) for p,row in fr.items() if evaluate(row,x)}
  assert evaluate(origin,x)==1 and all(evaluate(r,x)>=0 for r in RR)
  out.update(mass=str(sum(F.values())),integral=all(a.denominator==1 for a in F.values()))
  active=[r for r in RR if evaluate(r,x)==0];active+= [origin,tuple(-a for a in origin)]
  proofs=[];unknown=[]
  for p,a in sorted(F.items(),key=lambda z:(-sum(z[0]),-z[1],z[0])):
   target=tuple(v-a*w for v,w in zip(fr[p],origin));cert=exact_conic_scaled(target,active)
   if cert is None:
    low=propose_optimum(fr[p],RR,origin)
    if low.get('parameters') and Fraction(low['value'])<a:
     xx=list(map(Fraction,low['parameters']));G={q:evaluate(r,xx) for q,r in fr.items() if evaluate(r,xx)}
     out.update(status='exact_coordinate_tradeoff',failure={'p':p,'value':str(a),'lower':low['value'],'optimum':low,'F_other':dump_poly(G),'integer_other':all(v.denominator==1 for v in G.values())},proofs=proofs)
     return F,out,RR
    unknown.append({'p':p,'result':low})
   else:proofs.append({'p':p,'value':str(a),'dual':[[i,str(v)] for i,v in cert]})
  out.update(status='exact_least' if not unknown and out['integral'] else ('fractional_least' if not unknown else 'unresolved_coordinates'),proofs=proofs,unknown=unknown,active_rows=active)
  return F,out,RR
 def get(self,d):
  d=tuple(d)
  if d in self.cache:return self.cache[d]
  if d in self.active:raise ArithmeticError(('cycle',d))
  self.active.add(d);tic=time.time();g=self.label(d);act=[i for i,a in enumerate(d) if a]
  if len(act)<=2:
   F=block_polynomial(self.B,d);self.active.remove(d)
   return self.save(d,{'accepted':True,'status':'genuine_rank_two_base','theta_identified':True,'mass':sum(F.values())},F)
  points=sorted(product(*(range(a+1) for a in d)),key=lambda p:(sum(p),p));ids={p:i for i,p in enumerate(points)};zz=(0,)*self.n
  caps,_=pair_upper_caps(self.B,g,d,points)
  if self.charged:
   sys.path.insert(0,str(ROOT/'agent_positive_inventory'))
   from charged_caps import charged_caps
   charge=charged_caps(self.B,d,points)
   caps={p:min(a,charge[p]) for p,a in caps.items()}
  S=[p for p in points if caps[p]]
  fr,space=divisibility_space(self.B,g,S);width=space['dimension'];origin=fr[zz]
  print('START',d,'support',len(S),'dimension',width,flush=True)
  if width==1:
   F={p:Fraction(row[0],origin[0]) for p,row in fr.items() if row[0]}
   assert all(a.denominator==1 and a>=0 for a in F.values())
   F={p:int(a) for p,a in F.items()};self.active.remove(d)
   return self.save(d,{'accepted':True,'status':'unique_genuine_cap_Laurent_space','theta_identified':True,'space':space,'seconds':time.time()-tic,'mass':sum(F.values())},F)
  lowers={};lowerraw={};creators={};creationraw={};deps=set();zeros=[]
  initial={p:{ids[p]:1} for p in points}
  for j in act:
   gj=tuple(g[k]+(k==j) for k in range(self.n))
   out,z,dep=self.expand_rows(gj,d,points,initial);deps|=dep;zeros+=z;lowerraw[j]=out
   lowers[j]={q:asrow(r,points,fr,width) for q,r in out.items()}
  for i in act:
   di=tuple(d[k]-(k==i) for k in range(self.n));H=self.get(di);deps.add(di);P=dict(H)
   for p,a in H.items():
    q=tuple(p[k]+(k==i) for k in range(self.n));P[q]=P.get(q,0)+a
   creators[i]=P
   ini={p:addrow({ids[zz]:P.get(p,0)},{ids[p]:1},-1) for p in points};ini={p:r for p,r in ini.items() if r}
   out,z,dep=self.expand_rows(g,d,points,ini);deps|=dep;zeros+=z
   creationraw[i]=out
  creations={i:{q:asrow(r,points,fr,width) for q,r in out.items()} for i,out in creationraw.items()}
  RR=list(fr.values())+quotient_rows(self.B,g,fr)
  rr,info=section_rows(self.B,g,fr);RR += [r for key,r in rr]
  RR += [tuple(caps[p]*a-b for a,b in zip(origin,row)) for p,row in fr.items()]
  RR += [r for dic in lowers.values() for r in dic.values()]+[r for dic in creations.values() for r in dic.values()]
  for r in zeros:
   v=asrow(r,points,fr,width)
   if any(v):RR +=[v,tuple(-a for a in v)]
  diamond_rows=[];diamonds=[];negative_a=[]
  # Each full raw lowering functional is evaluated on every creator. Its
  # zero coefficients force the matching b row and all positively incident c.
  for j in act:
   for i in act:
    P=creators[i]
    for q,row in lowerraw[j].items():
     aa=sum(a*P.get(points[k],0) for k,a in row.items())
     if aa<0:negative_a.append({'i':i,'j':j,'q':q,'a':aa})
     if aa==0:
      br=lowers[j][q]
      if any(br):diamond_rows.append(br)
      forced=[]
      for r,cr in creations[i].items():
       if not any(cr) or not all(r[k]<=q[k] for k in range(self.n)):continue
       h=tuple(g[k]+sum(self.B[k][l]*r[l] for l in range(self.n)) for k in range(self.n))
       dh=tuple(acyclic_dimension(self.B,h)[0]);Hp=self.get(dh);deps.add(dh)
       mm=0
       for k,a in row.items():
        p=tuple(points[k][l]-r[l] for l in range(self.n))
        if min(p)>=0:mm+=a*Hp.get(p,0)
       if mm<0:raise ArithmeticError(('negative_M',d,i,j,q,r,mm))
       if mm>0:diamond_rows.append(cr);forced.append([r,mm])
      if any(br) or forced:diamonds.append({'i':i,'j':j,'root':q,'a':0,'forced_c':forced})
  dr=list(dict.fromkeys(primitive(r) for r in diamond_rows if any(r)))
  rank=int(sp.Matrix([origin]+dr).rank())
  assert not negative_a,('negative lower right inventory',d,negative_a)
  report={'accepted':False,'theta_identified':False,'space':space,'pair_cap_points':len(S),'zero_diamond_equations':len(dr),'zero_diamond_rank_including_origin':rank,'zero_diamond_remaining_affine_dimension':width-rank,'zero_diamonds':diamonds,'zero_rows':dr,'dependencies':[list(x) for x in sorted(deps)],'scope':'strict recursively least candidate family; higher-rank theta identification not assumed'}
  F,sol,RR=self.solve(fr,origin,RR);report['basic_full_pieri']=sol
  stages=['full_pieri_pair']
  def identify(sol,RR):
   if sol['status']!='exact_least' or not all(self.records[z].get('theta_identified') for z in deps):return False,[]
   if rank==width:return True,[]
   x=list(map(Fraction,sol['mass_optimization']['parameters']));proof=[]
   for j in range(width):
    target=tuple(int(k==j)-x[j]*origin[k] for k in range(width))
    both=[]
    for sign in (1,-1):
     cert=exact_conic_scaled(tuple(sign*a for a in target),RR)
     if cert is None:return False,proof
     both.append([[k,str(a)] for k,a in cert])
    proof.append({'parameter':j,'value':str(x[j]),'two_sided_duals':both})
   return True,proof
  identified,idproof=identify(sol,RR)
  if (sol['status']!='exact_least' or (self.require_identified and not identified)) and self.graph_on_failure:
   gc,fs,_=block_upper_caps(self.B,d,S,graph=True)
   RR +=[tuple(gc[p]*a-b for a,b in zip(origin,row)) for p,row in fr.items()]
   F,sol,RR=self.solve(fr,origin,RR);report['with_graph_caps']=sol;stages.append('all_graph_caps')
   identified,idproof=identify(sol,RR)
  if sol['status']!='exact_least' or self.all_splits or (self.require_identified and not identified):
   splitrows=[];count=0
   for e in points:
    f=tuple(d[k]-e[k] for k in range(self.n))
    if not any(e) or not any(f) or e>f:continue
    E=self.get(e);H=self.get(f);deps|={e,f};P=multiply(E,H)
    ini={p:addrow({ids[zz]:P.get(p,0)},{ids[p]:1},-1) for p in points};ini={p:r for p,r in ini.items() if r}
    out,z,dep=self.expand_rows(g,d,points,ini);deps|=dep
    splitrows +=[asrow(r,points,fr,width) for r in out.values()]
    for r in z:
     v=asrow(r,points,fr,width)
     if any(v):splitrows +=[v,tuple(-a for a in v)]
    count+=1
   RR+=splitrows;F,sol,RR=self.solve(fr,origin,RR);report['with_all_splits']=sol;report['capacity_splits']=count;stages.append('all_capacity_splits')
   identified,idproof=identify(sol,RR)
  report.update(status=sol['status'],accepted=sol['status']=='exact_least' and (not self.require_identified or identified),theta_identified=identified,identification_proofs=idproof,charged_caps=self.charged,seconds=time.time()-tic,stages=stages,dependencies=[list(x) for x in sorted(deps)])
  if sol['status']=='exact_least' and self.require_identified and not identified:report['status']='least_but_theta_not_identified'
  if report['accepted']:
   F={p:int(a) for p,a in F.items()};self.active.remove(d);self.save(d,report,F)
   print('ACCEPT',d,'mass',sum(F.values()),'dim',width,'zero_remaining',width-rank,'stage',stages[-1],'seconds',round(time.time()-tic,3),flush=True)
   return F
  self.save(d,report,F);self.last={'d':d,'g':g,'points':points,'fr':fr,'origin':origin,'RR':RR,'report':report,'F':F,'lowers':lowers,'creations':creations}
  atomic(self.path.parent/'first_failure.json',{**report,'B':self.B,'d':d,'g':g,'F':dump_poly(F) if F else None,'coefficient_rows':[[p,row] for p,row in fr.items()],'origin':origin,'all_constraint_rows':RR})
  print('STOP',d,sol['status'],'stage',stages[-1],flush=True)
  raise StopLayer(d)

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--all-splits',action='store_true');ap.add_argument('--charged',action='store_true');ap.add_argument('--require-identified',action='store_true');ap.add_argument('--target',nargs=4,type=int,default=[4,5,5,6]);ar=ap.parse_args()
 B=tuple(tuple(1 if i<j else -1 if i>j else 0 for j in range(4)) for i in range(4));target=tuple(ar.target)
 dirname='cache'+('_charged' if ar.charged else '')+('_identified' if ar.require_identified else '')+('_all_splits' if ar.all_splits else '')
 C=StrictPieri(B,Path(__file__).parent/dirname,all_splits=ar.all_splits,charged=ar.charged,require_identified=ar.require_identified)
 try:
  for d in sorted(product(*(range(a+1) for a in target)),key=lambda d:(sum(d),d)):C.get(d)
  atomic(C.path.parent/(dirname+'_completion.json'),{'status':'all_strict_least','count':len(C.cache),'target':target,'seconds':time.time()-C.start})
 except StopLayer as e:
  atomic(C.path.parent/(dirname+'_completion.json'),{'status':'stopped_first_ambiguity','d':e.args[0],'accepted_count':len(C.cache),'seconds':time.time()-C.start})
 print('DONE',len(C.cache),'seconds',time.time()-C.start,flush=True)
