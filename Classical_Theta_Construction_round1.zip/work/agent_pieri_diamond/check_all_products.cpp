#include <algorithm>
#include <array>
#include <chrono>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
using D=array<int,4>;
struct Term{int p;long long a;};
struct Poly{D d;vector<Term> F;};
int enc(D d){return ((d[0]*6+d[1])*6+d[2])*7+d[3];}
D dec(int v){D d;d[3]=v%7;v/=7;d[2]=v%6;v/=6;d[1]=v%6;v/=6;d[0]=v;return d;}
int sm(D d){return d[0]+d[1]+d[2]+d[3];}
bool le(D a,D b){for(int i=0;i<4;i++)if(a[i]>b[i])return false;return true;}
void vec(D d){cout<<"["<<d[0]<<","<<d[1]<<","<<d[2]<<","<<d[3]<<"]";}
int main(){
 ifstream in("work/agent_pieri_diamond/capacity_basis_input.txt");int N;in>>N;
 vector<Poly> polys(N);vector<int> ids(N,-1),order(N);vector<D> points(N);for(int k=0;k<N;k++){points[k]=dec(k);order[k]=k;}
 sort(order.begin(),order.end(),[&](int a,int b){if(sm(points[a])!=sm(points[b]))return sm(points[a])<sm(points[b]);return a<b;});
 for(int k=0;k<N;k++){int m;auto &p=polys[k];in>>p.d[0]>>p.d[1]>>p.d[2]>>p.d[3]>>m;ids[enc(p.d)]=k;for(int j=0;j<m;j++){D q;long long a;in>>q[0]>>q[1]>>q[2]>>q[3]>>a;p.F.push_back({enc(q),a});}}
 long long tested=0,total_terms=0,max_coefficient=0;auto start=chrono::steady_clock::now();
 for(int k=0;k<N;k++){
  auto &p=polys[k];D g;int acc=0;for(int i=0;i<4;i++){g[i]=acc-p.d[i];acc+=p.d[i];}
  vector<int> lower_order;vector<int> frame(N,-1);
  for(int qi:order)if(le(points[qi],p.d)){
   D q=points[qi],h,dd;for(int i=0;i<4;i++){h[i]=g[i];for(int j=0;j<4;j++)h[i]+=(j>i?1:j<i?-1:0)*q[j];}
   int s=0;bool fits=true;for(int i=0;i<4;i++){dd[i]=max(s-h[i],0);s+=dd[i];if(dd[i]+q[i]>p.d[i])fits=false;}
   if(fits&&sm(dd)<sm(p.d))frame[qi]=ids[enc(dd)];lower_order.push_back(qi);
  }
  int num_here=0;
  for(int ei:lower_order){D e=points[ei],f;for(int i=0;i<4;i++)f[i]=p.d[i]-e[i];int fi=enc(f);if(!sm(e)||!sm(f)||ei>fi)continue;
   auto &E=polys[ids[ei]],&H=polys[ids[fi]];vector<long long> r(N,0);
   for(auto a:E.F)for(auto b:H.F)r[a.p+b.p]+=a.a*b.a;
   for(auto a:p.F)r[a.p]-=a.a;
   for(int qi:lower_order){long long a=r[qi];if(!a)continue;int zi=frame[qi];if(a<0||zi<0){
     cout<<"{\"status\":\""<<(a<0?"negative_product_coordinate":"unexpandable_coordinate")<<"\",\"d\":";vec(p.d);cout<<",\"e\":";vec(e);cout<<",\"f\":";vec(f);cout<<",\"root\":";vec(points[qi]);cout<<",\"coefficient\":"<<a<<",\"tested_before\":"<<tested<<"}"<<endl;return 2;}
    total_terms++;max_coefficient=max(max_coefficient,a);for(auto b:polys[zi].F)r[qi+b.p]-=a*b.a;
   }
   for(auto a:r)if(a){cerr<<"leftover"<<endl;return 3;}
   tested++;num_here++;
  }
  if(num_here&& (k%100==0||k==N-1))cout<<"progress "<<k<<" products "<<tested<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
 }
 cout<<"{\"status\":\"all_proper_capacity_products_nonnegative\",\"layers\":"<<N<<",\"unordered_products\":"<<tested<<",\"positive_lower_coordinates\":"<<total_terms<<",\"max_coordinate\":"<<max_coefficient<<",\"seconds\":"<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"}"<<endl;
}
