# Independent review of the generic prefix theorem

Reviewed 2026-11-13 09:07 UTC by the Pieri/diamond branch.

I read `../agent_asymptotic_detector/GENERIC_LARGE_LABEL_PREFIX_RIGIDITY.md` completely. Given its four explicitly stated comparison inputs, Sections 2–6 are valid. No further genericity for differences of large-corner roots is necessary.

The identities were independently expanded: B=U^T−U, L=U^(−T)U, L^TU=U^T, and L^TUL=U. The capacity relation is Ur=−v−U^Te, hence r≤−U^(−1)U^Te because U^(−1) is entrywise nonnegative. This proves the finite root box for every possible contributor to a far corner, including signed expansions.

In the negative-slope induction, every smaller contributing root with nonnegative slope leaves a strictly negative-slope displacement; its theta coefficient vanishes by Q. In the positive-slope argument, a largest slope followed by a componentwise maximal far corner excludes equal-slope cancellation. Equal far corners imply equal roots because L is invertible. Strictly smaller slopes have negative Q at the relevant inward displacement.

The four displayed threshold constants bound all constant terms. The W bound needs no factor two because each difference of two roots in [0,R] has absolute coordinate at most R. Integer nonzero slopes have magnitude at least one, so the stated N0 need not depend on the size of the positive integer direction a.

Full principal Newton containment really does imply r≥0 and r+c_r≤d: each translated theta summand has its constant and far-corner frozen monomials, and signed VIT contains its full Newton polytope in that of the difference. Far-corner coefficient one follows directly from successive one-variable Laurent divisibility along the topological corner chain.

The finite theta expansion/VIT and the classical Q bound are comparison inputs previously audited by the root team. I did not independently re-prove their published foundations here. The theorem does not identify arbitrary finite-label theta functions by itself; the new ratio/extraction theorem provides that next step.
