# Pieri, charged carriers, and integer reconstruction: route log

## 08:49–09:00: full strict recursion and its precise limits

Read the two-sided Pieri handoff and zero-inventory diamond proof completely before writing the new recursion. The new code accepts a nontrivial layer only after exact rational primal and coordinatewise dual certificates establish an integral coefficientwise least solution. It never substitutes a mass-only optimizer for a smaller basis.

All 1260 capacities below (4,5,5,6) for the topological unit K4 passed full smaller-basis lowering and one-step creation. The initial pair support was sufficient; no graph or all-split fallback was needed. Of 1056 nontrivial least layers, forced zero diamonds leave affine dimensions 0/1/2/3 in 808/224/23/1 layers. Genuine theta identification at that stage was restricted to 170 rank≤2 bases and 34 unique genuine-cap Laurent spaces.

The independent exact C++ product check then tested every unordered proper capacity split in this lower box: 91,404 products, all nonnegative in the candidate family, with 3,721,691 positive lower coordinates. This is finite coherence evidence for the general multiplication interface, not an all-capacity theorem. All arithmetic is integral and fits signed 64-bit integers: every standard product mass is at most 2^20 in this box.

## 08:53–09:05: charged carrier and the remaining primitive degree

Q≥0 intersects the previous graph carrier in 130 points and reduces its Laurent dimension 47→6. Charged numerical caps plus existing pair inequalities yield an exact coefficientwise least solution of mass1829. The feasible normalized family is nevertheless nonunique: five parameter intervals are [0,2],[0,1],[0,6],[0,2],[0,1]. No theta identification followed merely from these caps.

A stricter charged recursion that demanded genuine theta identification stopped at d=(0,2,2,2), after 139 genuinely identified lower layers. Its single central coefficient t remains in [0,1] under all creation, lowering, graph caps, and 13 proper split products. The least member has t=0 and mass14. This exposes the primitive-cycle selection issue without assigning an arbitrary value.

The conjecture that Q truncation always makes every Laurent RREF column nonnegative was tested structurally and rejected. A fixed 300-case weighted acyclic rank3–5 scan found 22 signed RREFs. The first has B=((0,3,1),(-3,0,2),(-1,-2,0)), d=(4,6,7), with a_(3,1,1)=x−y. It does not refute a more general positive cone elimination; some other cases also have negative normalized origin columns, so simply setting all free variables to zero is not a general rule. The failed conjecture was stopped.

## 09:05–09:10: literature refresh and proof interface

The primary 2014 LLRZ quantum-greedy paper was checked for its explicit support/divisibility characterization and warning that triangular and greedy bases differ. Qin 1902.09507 was located as a classification interface, not adopted as a finite coefficient selector. Qiyue Tang, Hexagon2610.00025v3, Sections3–5, was read for finite rigidity, monomial truncation, and coefficient extraction. Its theorem concerns a quantum rank-two strongly positive basis under divisibility assumptions and uses scattering for comparison. Its conclusion was not imported into the classical all-rank problem. The idea of extracting coefficients from large-label ratios was rebuilt using the new integer Q/Laurent rigidity theorem.

Independent review found the new generic large-label prefix proof valid under its explicitly audited comparison inputs. The review is in PREFIX_RIGIDITY_INDEPENDENT_REVIEW.md.

## 09:10–09:25: finite ratios and a complete reconstruction

Construction uses only integer B, canonical capacities, Q≥0, binomial Laurent equations, exact linear algebra, formal ratios, and triangular coefficient peeling. The frozen variables are fixed. If R_i=F_(Nu+e_i)/F_(Nu), then psi(x_i)=x_iR_i and psi(y_j)=y_j. Its normalized matrix is A_pq=[z^(p−q)]R^(g+Bq); the extractor is A inverse, not A.

The first literal large-box attempts honestly stopped at resource caps. A general actual-cluster-cone acceleration was then added: a finite mutation word supplies C and G inverse=C transpose; all large-label cone coordinates are checked nonnegative, and every F polynomial is computed by exchange-binomial recursion. This does not use a theta oracle. Failure to find such a cone simply falls back to the finite Q/Laurent solver.

The raw Q carrier for the K4 target has 173 points and Laurent dimension7. Six exact extractor rows, with mutation words [],[],[],[1],[1,2,3,1,2],[1,2,3,1,2,3] in zero-based indexing, determine its normalized polynomial uniquely. The output is integral, nonnegative, mass1829, and equals the earlier least candidate. This is the first genuine theta identification for this target under the separately reviewed reconstruction theorem. The primitive t parameter is independently extracted as zero.

The non-cluster Q solver branch was also executed independently: B12=3, u=(−5,3), N=4, box-prefix(1,1). Three Q carriers of sizes493,439,479 have Laurent dimensions8,9,10, yet every requested prefix coefficient is exactly fixed. Ratios are R1=1−z1−3z1z2 and R2=1−3z1z2 in the box. Only after obtaining them without an oracle was a separate classical LLZ prefix calculation run; it agrees exactly.

The reference implementation is standalone apart from SymPy. Its rational linear-algebra intermediates are exact; all emitted prefix and reconstructed coefficients are checked to be integers. The mathematical integer-only implementation can equivalently use Smith elimination; no claim is made that this Python implementation avoids rational intermediates.

## 09:28–09:44: ordinary negative frame and signed integer factorization

The cyclic bridge branch supplied the crucial ordinary-frame interface. Compute the full ordinary exchange polynomials I_i=x_i^-1 H_i, hence the total leading-unit substitution Phi(x_i)=x_i/H_i, Phi(y)=y. On a finite downward root box, its matrix is determined entirely by integer coefficients of products of powers of H_i. Unique positive/negative sign factorization gives the desired chart extractor without computing any wall. This was independently implemented in signed_lu_reconstruction.py and compared coefficientwise with the earlier ratio method.

The main frame CLI was then stripped of Q, quantum positivity, large-label searches and Laurent-space assumptions. Both valued rank2 and genuinely mutation-cyclic rank6 were run by the literal full-carrier coefficient recurrence under python -S. Rank6 uses all 58 positive carrier points and returns 22 terms of mass27; valued rank2 returns 10 terms of mass32. All finite factorization identities are checked entry by entry. Independent rank6 full-frame exchange uses 17 steps, each exact polynomial division multiplied back to its numerator.

The attempted full K4 Laurent-space acceleration was stopped: the complete canonical1260-point carrier has a 960-dimensional star-neighbor Laurent space, so iterating symbolic rank updates was the wrong acceleration. No incomplete run was labeled a completed theta calculation. This computation was superseded by the halfspace recurrence below, which does compute the complete carrier.

## 09:40–09:48: literature refresh and novelty correction

Nakanishi, arXiv:2111.00800, was read directly. Section2.3 Lemma2.15 and Proposition2.16 already give the underlying positive/zero/negative group factorization, with attribution to the proof of GHKK Theorem1.17. Therefore unique sign factorization itself is not claimed as a newly discovered theorem. The concrete construction here is the ordinary exchange input, finite integral matrix realization, explicit carrier, and coefficient extraction by finite signed chains. The source also fixes B=Delta Omega and D=Delta^-1, confirming that the relevant sign pairing is u^T D alpha. The normalization was checked against the valued computations rather than guessed from the skew case.

## 09:49–09:56: different-seed negative products and the halfspace simplification

The negative-product construction was independently implemented in negative_product_recovery.py. A collection of ordinary seed variables with positive powers has leading sum h<0. For each positive increment delta choose one variable with g_tj^T D delta<0; compute its seed transport C_t and inverse S_t. The zero coefficient of S_t C in that increment determines each entry of the total C by a triangular integer recurrence. The seed is allowed to vary with delta. No common negative cluster enters this recovery.

Full comparison checks passed: valued rank3 with D=(1,3,1), three single-mutation seeds and powers(1,2,9) gives h=(-1,-1,-1); all216 comparable entries in the27-point box agree with an independent reference frame. Six prefixes of the actual cyclic rank6 word recover all729 comparable entries in the64-point box, also equal to the separately computed full transport. Both seed inverse products and every used vanishing equation are checked exactly. The valued rank3 transport independently agrees at all216 entries with the new acyclic generalized-binomial closed formula.

Root then eliminated sign factorization entirely from coefficient computation. For target p, m=g+Bp, retain I_p={p} union {q<=p:m^T D(p-q)<0}; the extraction row is the final row of C[I_p,I_p]^-1. Equal pairings belong outside the strict halfspace. This is implemented as integer chain inversion, retaining all intermediate points even when a final coefficient is known to vanish by the positive carrier.

The acyclic total C has an explicit generalized-binomial product, so the recommended main program halfspace_chain.py takes only B,D,g for acyclic seeds. It computes the complete K4 1260-point box in approximately0.5s: 122 nonzero terms, mass1829, full coefficient identity with independent ratio and LU outputs. This result uses no Q support and no linear Laurent solver. Valued rank2 and genuine cyclic rank6 agree coefficientwise with the independent literal direct-LU outputs.

The negative-product mechanism was also connected end to end: H^N provides the positive carrier with g-Nh>=0, its total C is recovered from the different ordinary seeds, and the same halfspace recursion is applied. The valued rank3 three-seed input computes all60 carrier points and returns28 terms, mass666, in0.044s, identical to the separate B-only closed-binomial computation. No reference frame is supplied to this main mode.

## 09:57–10:00: uniform folding interface

A general uniform-block folding implementation verifies equal orbit sizes, blockwise constant covering B, zero internal blocks, orbit-constant D, folded skew-symmetrizability and independence of the chosen orbit representative after aggregating every exact frame H_i. The target total transport is then fed to the same halfspace-chain API.

The rank6 cover with orbits(0,5),(1,4),(2,3) gives the Markov matrix ((0,-2,2),(2,0,-2),(-2,2,0)). For g=(-1,-1,1), all31 carrier points are processed:16 nonzero terms, mass27, nonnegative, all16 initial star-Laurent equations hold exactly. The finite computation supplies no target negative frame. Theta identification is kept logically separate, resting on the uniform-folding normalization and negative-orthant monomial comparison currently audited by root and the valued branch. General folding is not silently promoted to a full U-basis theorem; the Markov full-basis statement has its own literature hypothesis.

At10:00 root confirmed the primary-source folding audit. The implementation now restricts the cover to skew-symmetric B and common scalar D, in addition to equal orbit sizes and block constancy. Its output cites the independently proved comparison theorem; it still does not assert a general U-basis theorem. An initial validation-script comparison failed only because in-memory point tuples were compared directly with JSON point lists; comparison was corrected to integer coefficient dictionaries, after which all seven independent polynomial identities passed. No coefficient, recurrence, or mathematical claim changed in that correction.

## 10:02–10:05: nonuniform orbit normalization

Root, the cyclic bridge and valued branch independently completed the nonuniform normalization proof. The implementation was generalized to arbitrary positive orbit sizes while retaining skew cover B and common scalar cover D. The formula is Bbar_ab=|O_a| b_ab, a row scaling, and Dbar_a=lcm(|O|)/|O_a|. This is now implemented in block_folded_halfspace.py; the former uniform entry point remains compatible.

The A3 cover with orbit sizes(2,1) folds to B=((0,2),(-1,0)),D=(1,2). For g=(-3,-2), the full18-point folded positive carrier returns18 terms, mass108; all18 star-Laurent equations pass and the entire polynomial equals the separately run B-only acyclic formula. This validates the normalization in a genuinely valued target. The Markov equal-orbit run was repeated through the general code with unchanged16 terms and mass27. This closes the computational interface for the audited nonuniform mechanism, not an assertion that every valued target has such a cover.
