#!/usr/bin/env python3
"""Exact checks for the zero-temperature periodic transform, arXiv 2508.05603v4.

This is a literature-formula audit, not a cluster-theta construction.
"""
import json
import random
from pathlib import Path


def pitman(x, y):
    n = len(x)
    delta = tuple(x[(i + 1) % n] - y[i] for i in range(n))
    # A_i is the maximum of the empty and all proper cyclic interval sums (i,j].
    a = tuple(max(sum(delta[(i + r) % n] for r in range(1, k + 1))
                  for k in range(n)) for i in range(n))
    d = tuple(x[(i + 1) % n] + a[i] - a[(i - 1) % n] for i in range(n))
    t = tuple(x[i] + y[i] - d[i] for i in range(n))
    return t, d


def braid(rows, left):
    rows = list(rows)
    for i in ((0, 1, 0) if left else (1, 0, 1)):
        rows[i], rows[i + 1] = pitman(rows[i], rows[i + 1])
    return tuple(rows)


def hproduct(x, y, lo, hi):
    n = len(x)
    return max(sum(x[i % n] for i in range(lo, split + 1))
               + sum(y[i % n] for i in range(split, hi + 1))
               for split in range(lo, hi + 1))


def audit():
    rng = random.Random(250805603)
    pair = braid_count = interval_count = 0
    for _ in range(5000):
        n = rng.randrange(2, 9)
        rows = tuple(tuple(rng.randrange(7) for _ in range(n)) for _ in range(3))
        x, y, _ = rows
        t, d = pitman(x, y)
        assert min(t + d) >= 0
        assert sum(t) == sum(y) and sum(d) == sum(x)
        assert pitman(t, d) == (x, y)
        assert tuple(t[i] + d[i] for i in range(n)) == tuple(x[i] + y[i] for i in range(n))
        pair += 1
        assert braid(rows, True) == braid(rows, False)
        braid_count += 1
        for lo in range(n):
            for length in (0, 1, n - 1, n, 2 * n):
                hi = lo + length
                assert hproduct(x, y, lo, hi) == hproduct(t, d, lo, hi)
                interval_count += 1
    result = dict(pair_checks=pair, braid_checks=braid_count,
                  interval_max_matrix_checks=interval_count,
                  status="all exact checks passed",
                  scope="finite integer formula and max path weights; no path-count or theta identification")
    Path(__file__).with_name("pitman2026_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    audit()
