# Partial source-star surgery and a finite smaller-box recursion

2026-11-13, prepared by 07:45 UTC. Classical skew-symmetrizable cluster algebras. This extends the independently checked full-star surgery; no Li--Pan statement is used. Parent requested the hard-case numerical test separately, assigned to `finite_overlap_completion`.

## 1. Data and mutation

Let B be acyclic and i a source. Put b_j=B_ij>=0 and c_j=-B_ji>=0 for j != i, with D_i b_j=D_j c_j. Choose a nonzero integral substar

    0<=a_j<=b_j, 0<=e_j<=c_j, D_i a_j=D_j e_j.

Write B^- for the matrix obtained by replacing its source entries by

    B^-_ij=b_j-a_j, B^-_ji=-(c_j-e_j),

and leaving all other entries unchanged. The source remains a source, and B^- is acyclic in the same topological order.

More generally choose positive integers sigma,tau with sigma dividing every a_j and tau dividing every e_j. Adjoin w by

    B_iw=-sigma, B_wi=tau,
    B_wj=-a_j/sigma, B_jw=e_j/tau,
    D_w=D_i sigma/tau.

Scale the symmetrizer to integers if necessary. A direct mutation at w gives old principal block B^-. The new full quiver has i -> w -> supp(a), all residual arrows i -> R, and the old acyclic R subquiver. It is acyclic. The initial enlarged quiver need not be acyclic.

## 2. A single enlarged theta and its polynomial transform

Let theta_g=x^g F_g(z), F_g=sum_p f_p z^p, with finite Newton carrier P. Put

    L(p)=sum_j a_j p_j/sigma,
    lambda=max_(p in P)(L(p)-tau p_i)>=0.

The upper-bound argument is exactly the one in `INDEPENDENT_SURGERY_PROOF.md`: the monomial coefficient extension w^lambda theta_g has every w exponent lambda+tau p_i-L(p)>=0, hence is Laurent in the new w-neighbor as well as all old neighbors. Independent principal coefficients give full rank. BFZ Proposition1.8 and Corollary1.9 identify this upper bound with U. Mutation at w is acyclic, so the finite theta basis exists. Valuative independence and freezing identify the extension with a single enlarged theta.

The exchange is

    w w'=eta_w product_j x_j^(e_j/tau)+x_i^sigma.

In the new normalized variables, with v=x_i^sigma/(eta_w product_j x_j^(e_j/tau)),

    z_i(old)=z_i(new)(1+v)^tau,
    z_j(old)=z_j(new)(v/(1+v))^(a_j/sigma).

Therefore

    F_new=sum_p f_p z^p v^L(p)(1+v)^(lambda+tau p_i-L(p)).

At outside degree k, define

    A_k(z)=sum_p f_p binom(lambda+tau p_i-L(p),k-L(p)) z^p,
    h_i(k)=g_i+sigma k,
    h_R(k)=g_R+(e/tau)(lambda-k).

The general positive-slice theorem yields

    A_k(z)=sum_(q>=0) beta_(k,q) z^q F^[B^-]_(h(k)+B^-q)(z),
    beta_(k,q) in N.

This retains the residual source edges. Hence it tests actual interactions between i and R, which the complete-star surgery discards by making i isolated.

## 3. Uniform width decrease

Let d=d_B(g) be the standard acyclic box, and set A=d_i=[-g_i]_+. If A=0, the original theta polynomial is independent of z_i and the existing freezing theorem already reduces rank. Thus consider A>0, so g_i=-A.

For every nonzero slice, 0<=k<=lambda+tau A. At the source,

    d^[B^-]_i(h(k))=[A-sigma k]_+.

The difference between the new and old source contributions to the downstream acyclic dimension recurrence at vertex j is exactly

    (c_j-e_j)[A-sigma k]_+ - c_j A - (e_j/tau)(lambda-k)
      = -(c_j-e_j) min(sigma k,A)
        -(e_j/tau)(lambda+tau A-k)
      <=0.

All remaining entries of the recurrence are the same nonnegative coefficients. Topological induction therefore gives

    d^[B^-](h(k))<=d_B(g) coordinatewise.

For k>0 the source width is strictly smaller. Moreover every positive summand in the displayed slice expansion has

    q+d^[B^-](h(k)+B^-q)<=d,

because positivity prevents cancellation of the shifted support, and the standard corner d^[B^-](...) belongs to that theta support. The source component is at most [A-sigma k]_+, since the source row of B^- is nonnegative. Thus every required theta table in a k>0 slice has strictly smaller total width sum_j d_j.

At k=0, the binomial coefficient is nonzero only when L(p)=0. Since all a_j>=0,

    A_0=F_g restricted to z_j=0 for every j in J={j:a_j>0}.

Every positive summand also has zero degree in each j in J. Freeze J and apply the usual lower-rank positive-slice theorem. This case is computed in rank n-|J| and requires no same-width rank n oracle.

Consequently the partial-star necessary conditions are well founded using the lexicographic measure (total standard-box width, mutable rank). The recursion only sees matrices formed by decreasing source-edge weights and taking principal submatrices. At fixed input those matrices form a finite set.

## 4. An explicit finite recurrence on coefficients

Once all required smaller tables are known, expand each A_k by pointed triangular elimination:

    beta_(k,q)=[z^q]A_k
       -sum_(r<q) beta_(k,r)
          [z^(q-r)]F^[B^-]_(h(k)+B^-r).

The roots range over 0<=q<=d and are allowed only if their shifted standard boxes fit the ambient d. Exiting coefficients must vanish. Every beta is an integer linear form in the unknown f_p; require beta>=0 and all exit coefficients zero. This is finite, uses purely integer polynomial data, and needs no higher-rank theta oracle. The k=0 case uses the frozen-rank tables instead.

As in the full-star family, lambda+1 contributes no additional inequalities: normalized Pascal degree elevation is multiplication by x_i^sigma and x_R^(e/tau), both initial cluster monomials of the B^- algebra. Their theta multiplication is positive. Use the smallest carrier-based lambda.

## 5. What this proves and the remaining selection statement

Proved: each theta polynomial passes these finite recursively lower-data tests; all right-hand tables have smaller total box or smaller rank. Partial deletion is potentially stronger than full deletion because it retains residual source interactions.

Not proved: the cone defined by all such tests has a least integral normalized element; that a lexicographic selector is theta; or that it is invariant under mutation. These are the same central selection statements and must be established before calling this a higher-rank greedy construction.

The immediate numerical question is whether partial deletion cuts the hard surviving direction D47 in the (3,2) fork. The first inexpensive test imposes only already-known rank2 positive slices of each A_k for B^-=(2,2),(1,2),(3,1). If these do not cut, the next test is full smaller-box theta expansion, using independently constructed lower input tables. Candidate lower tables must not be silently treated as proved theta functions.

## 6. Exact numerical feedback, received before 07:55 UTC

The following are exact necessary-condition tests, with no unproved full lower-rank selector substituted for theta.

- Initial rank2 slices of the three partial families: 1583, 4880, and 1934 rows. All pass at F59085, and no active row is negative on the 56 old all-pair tangent rays.
- All independent-chart rank2 slices of those partial outputs: 4538, 20280, and 5872 rows, totaling 30690. The same result holds.
- Rank2 slices containing the auxiliary vertex w in the full enlarged rank4 polynomial: eight full-star divisor-factor cases plus three partial cases, 474 rows each, totaling 5214. Again no old tangent ray is cut at F59085.

Files in `../agent_overlap_completion/`: `partial_star_pair_results.json`, `partial_star_pair_chart_results.json`, `enlarged_surgery_pair_results.json`. These calculations are owned by `finite_overlap_completion` and are not duplicated here.

This rules out the expectation that merely taking more rank2 slices of these surgeries resolves the hard direction. The full smaller-box theta expansion is a different question. If attempted through `PieriCache`, its non-rank2 output must be labelled a candidate unless theta identity is independently proved.

An implementation correction in that audit is mathematically relevant: A_k is a positive sum of shifted theta functions, not necessarily a single pointed polynomial with fixed reset exponent. When transporting to another coefficient frame, a common Laurent monomial shift must be retained; applying the previous single-pointed transport routine can incorrectly reject negative reset exponents. The new exact transport helper was checked on 66 comparisons and shifted double-mutation involutions by the computing agent.
