#!/usr/bin/env python3
"""Shared rational-circle slots with canonical two-direction deficit flows.

Rank two agrees exactly with classical compatible pairs. Higher rank is an
explicit candidate; no theta identity is asserted.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from math import comb
from pathlib import Path
import json


def common_word(widths):
    return tuple((i, k - 1) for _, i, k in sorted(
        (Fraction(k, d), i, k) for i, d in enumerate(widths)
        for k in range(1, d + 1)))


def dyck(a, b):
    out = []
    last = 0
    for k in range(1, a + 1):
        out.append('H')
        level = b * k // a
        out.extend('V' for _ in range(level - last))
        last = level
    return ''.join(out)


class PairFlows:
    def __init__(self, a, b, horizontal_grade, vertical_grade):
        self.a, self.b = a, b
        self.word = common_word((a, b))
        self.n = a + b
        self.hp = {k: p for p, (i, k) in enumerate(self.word) if i == 0}
        self.vp = {k: p for p, (i, k) in enumerate(self.word) if i == 1}
        self.hreturns = [self.returns(mask, 0, horizontal_grade)
                         for mask in range(1 << a)]
        self.vreturns = [self.returns(mask, 1, vertical_grade)
                         for mask in range(1 << b)]

    def returns(self, mask, color, grade):
        locations = self.hp if color == 0 else self.vp
        direction = 1 if color == 0 else -1
        out = {}
        for k, start in locations.items():
            active = not (mask >> k & 1) if color == 0 else bool(mask >> k & 1)
            if not active:
                continue
            value = 0
            stop = self.n
            for length in range(self.n):
                i, j = self.word[(start + direction * length) % self.n]
                if i != color:
                    value -= 1
                else:
                    bit = mask >> j & 1
                    value += grade * ((1 - bit) if color == 0 else bit)
                if value == 0:
                    stop = length
                    break
            out[k] = stop
        return out

    def compatible(self, hmask, vmask):
        for h, ht in self.hreturns[hmask].items():
            for v, vt in self.vreturns[vmask].items():
                delta = (self.vp[v] - self.hp[h]) % self.n
                if ht >= delta and vt >= delta:
                    return False
        return True

    def character(self):
        out = Counter()
        for hm, vm in product(range(1 << self.a), range(1 << self.b)):
            if self.compatible(hm, vm):
                out[hm.bit_count(), vm.bit_count()] += 1
        return dict(out)


def llz(a, d, b, c):
    coefficients = {(0, 0): 1}
    for total in range(1, a + d + 1):
        for p in range(max(0, total - a), min(d, total) + 1):
            q = total - p
            value = 0
            if d - c * q > 0:
                value = max(value, sum((-1) ** (k - 1) * comb(d - c * q + k - 1, k)
                                       * coefficients.get((p - k, q), 0)
                                       for k in range(1, p + 1)))
            if a - b * p > 0:
                value = max(value, sum((-1) ** (k - 1) * comb(a - b * p + k - 1, k)
                                       * coefficients.get((p, q - k), 0)
                                       for k in range(1, q + 1)))
            if value:
                coefficients[p, q] = value
    return {(a - q, p): value for (p, q), value in coefficients.items()}


def fork_character(a, b, c, weight_a, weight_b):
    pair_a = PairFlows(a, c, weight_a, weight_a)
    pair_b = PairFlows(b, c, weight_b, weight_b)
    out = Counter()
    for vm in range(1 << c):
        ca = Counter(hm.bit_count() for hm in range(1 << a)
                     if pair_a.compatible(hm, vm))
        cb = Counter(hm.bit_count() for hm in range(1 << b)
                     if pair_b.compatible(hm, vm))
        for pa, pb in product(ca, cb):
            out[pa, pb, vm.bit_count()] += ca[pa] * cb[pb]
    return dict(out)


def star_audit(F, B, g):
    report = []
    for i in range(len(g)):
        fibers = defaultdict(dict)
        for p, value in F.items():
            fibers[tuple(p[j] for j in range(len(g)) if j != i)][p[i]] = value
        bad, negative = [], []
        for outside, coeff in fibers.items():
            p = [0] * len(g)
            for j, q in zip((j for j in range(len(g)) if j != i), outside):
                p[j] = q
            m = max(0, -g[i] - sum(B[i][j] * p[j] for j in range(len(g))))
            degree = max(coeff)
            quotient = []
            for k in range(degree + 1):
                quotient.append(coeff.get(k, 0) - sum(comb(m, s) * quotient[k - s]
                                for s in range(1, min(k, m) + 1)))
            if degree < m or any(quotient[k] for k in range(max(0, degree - m + 1), degree + 1)):
                bad.append(dict(outside=outside, m=m, formalquotient=quotient))
            elif min(quotient) < 0:
                negative.append(dict(outside=outside, m=m, quotient=quotient))
        report.append(dict(i=i, fibers=len(fibers), nondivisible_count=len(bad),
                           negativequotient_count=len(negative), first_nondivisible=bad[:1],
                           first_negative=negative[:1]))
    return report


def run():
    circular_checks = 0
    for a, b in product(range(1, 31), repeat=2):
        w = ''.join('HV'[i] for i, _ in common_word((a, b)))
        assert dyck(a, b) in w + w
        circular_checks += 1
    rank_two = 0
    for a, d, b, c in product(range(1, 6), range(1, 6), range(1, 4), range(1, 4)):
        got = PairFlows(a, d, c, b).character()
        expected = llz(a, d, b, c)
        assert got == expected, (a, d, b, c, got, expected)
        rank_two += 1
    hard = fork_character(8, 7, 9, 3, 2)
    result = dict(circular_dyck_checks=circular_checks,
                  exact_rank_two_polynomial_checks=rank_two,
                  hard_fork_mass=sum(hard.values()),
                  known_finite_selector_mass=59085,
                  hard_fork_polynomial=[[list(p), value] for p, value in sorted(hard.items())],
                  scope="shared-slot two-color flow candidate; rank-two exact, higher theta unproved")
    result['full_initial_star_audit'] = star_audit(
        hard, ((0, 0, 3), (0, 0, 2), (-3, -2, 0)), (-8, -7, 29))
    prior = Path(__file__).resolve().parents[1] / 'agent_packet_propagation'
    carrier_file = prior / 'large_origin_exact_failure_2.json'
    selector_file = prior / 'pair_completion_fork_8_7_9.json'
    if carrier_file.exists() and selector_file.exists():
        carrier = json.loads(carrier_file.read_text())['carrier']
        points = set(map(tuple, carrier['lattice_points']))
        outside = [(p, value) for p, value in hard.items() if p not in points]
        selector = {tuple(q['p']): Fraction(q['a'])
                    for q in json.loads(selector_file.read_text())['F']}
        difference = [(p, str(hard.get(p, 0) - selector.get(p, 0)))
                      for p in sorted(set(hard) | set(selector))
                      if hard.get(p, 0) != selector.get(p, 0)]
        result['newton_carrier_audit'] = dict(carrier_points=len(points),
                                            candidate_support=len(hard), outside_points=outside)
        result['selector_difference'] = dict(nonzero_coordinates=len(difference),
                    first=difference[:15], negative=[(p, v) for p, v in difference if Fraction(v) < 0])
    Path(__file__).with_name('common_slot_flow_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print({k: v for k, v in result.items() if k != 'hard_fork_polynomial'})


if __name__ == '__main__':
    run()
