# Source-star surgery: independent proof and finite rank recursion interface

2026-11-13, begun 07:25 UTC. This branch independently checks the construction of `finite_overlap_completion`. All statements concern classical cluster algebras. No Li--Pan conclusion is used.

## 1. Matrix and coefficient conventions

Let B be acyclic and skew-symmetrizable, with source i. Write

    b_j=B_ij>=0, c_j=-B_ji>=0  (j != i),
    D_i b_j=D_j c_j.

Append a mutable vertex w with

    B_iw=-1, B_wi=1,
    B_wj=-b_j, B_jw=c_j,
    D_w=D_i.

Use independent principal coefficients eta_1,...,eta_n,eta_w for this enlarged matrix. The enlarged initial mutable matrix is generally cyclic. Mutating w cancels every edge between i and the old remaining set R, leaves B_R unchanged, and produces i -> w -> R. The full new mutable matrix is acyclic, because B_R is acyclic and i,w can be placed first in that order. The old principal block after deleting w is B0=0_(i) direct_sum B_R.

The source data b,c must be distinguished in the skew-symmetrizable case. Interchanging them silently would invalidate the formula below.

## 2. The finite theta extension is justified by a full-rank upper bound

Let theta_g=x^g F_g(z) for the old principal seed, with F_g=sum_p a_p z^p and a_0=1. Let P be its finite Newton carrier, obtained for example by the finite pruning theorem. Put

    L(p)=sum_(j in R) b_j p_j,
    lambda=max_(p in P)(L(p)-p_i).

The maximum is an integer and is nonnegative since 0 belongs to P. The explicit box bound sum_j b_j d_j can be used if the exact carrier has not been computed.

Treat w as an additional frozen variable for the old seed and set

    H=w^lambda x^g F_g(z_i(w),z_R(w)),
    z_i(w)=eta_i w x^(B e_i),
    z_j(w)=eta_j w^(-b_j) x^(B e_j), j in R.

Every monomial of H has w-exponent lambda+p_i-L(p)>=0. H is Laurent in every old adjacent cluster because it is the old theta function with a monomial coefficient extension. The w exchange is

    w w' = eta_w product_(j in R) x_j^c_j + x_i.

Its substitution into H is Laurent because every w-exponent is nonnegative. Thus H lies in the initial upper bound of the enlarged principal seed.

This is enough for H in U, even though the initial enlarged seed is cyclic. BFZ, `math/0305434v3`, Proposition 1.8 says that every seed in a full-rank geometric mutation class is coprime; Corollary 1.9 then identifies every initial upper bound with U. The principal extended matrix here has full column rank. The independent audit read the exact statements of Theorem 1.5, Corollary 1.7, Proposition 1.8 and Corollary 1.9 from the primary PDF (web ref turn327view0, pages4--5). No acyclicity assumption is inserted into this use.

The mutation at w is acyclic, so A=U and the full finite theta basis is available for the enlarged algebra. The element H is pointed at full label (g,lambda;0) and has degree zero in the new F-direction w (equivalently it is independent of eta_w). Finite theta-valuative independence puts the Newton polytope of the theta function with that label inside Newt(H). Consequently that theta function also has zero new F-direction. Freezing w identifies it with precisely H, by the already-audited theta freezing theorem and monomial coefficient variation. Thus H itself is one enlarged theta function.

This argument imports existing theta comparison properties, but neither the transform nor the finite inequalities use theta data in rank n+1.

## 3. Exact transform and lower-rank positive slices

Write

    v=x_i/(eta_w product_j x_j^c_j),

the new F-variable for w. In the new seed the old normalized F-variables satisfy

    z_i(old)=z_i(new)(1+v),
    z_j(old)=z_j(new)(v/(1+v))^b_j, j in R.

The new leading label has old part (g_i,g_R+c lambda) and w part -lambda. Its F-polynomial is therefore

    F' = sum_p a_p z^p v^L(p)(1+v)^(lambda+p_i-L(p)).

For 0<=t<=lambda+d_i define

    A_t(z)=sum_p a_p binom(lambda+p_i-L(p),t-L(p)) z^p,
    h_t=(g_i+t, g_R+c(lambda-t)).

Binomial coefficients outside 0<=k<=N are zero. The positive-slice theorem applied to the enlarged theta function at its acyclic new seed gives

    A_t(z)=sum_(q>=0) beta_(t,q) z^q
              F^[B0]_(h_t+B0 q)(z),
    beta_(t,q) in N.

Since B0 has isolated vertex i,

    F^[B0]_(h_t+B0q)
      =(1+z_i)^[ -g_i-t ]_+
         F^[B_R]_(g_R+c(lambda-t)+B_R q_R)(z_R).

Only theta data of rank n-1 occurs on the right. In rank3 these are exactly the LLZ Dyck-compatible-pair tables. The source quotient and the lower-rank expansion must be imposed jointly: checking them separately is weaker.

## 4. Fully explicit finite coefficient recurrence

Let k_t=[-g_i-t]_+. Divide A_t by (1+z_i)^k_t in ascending z_i degree. For each source degree s, expand the resulting coefficient polynomial in the lower-rank theta tables by the standard pointed triangular recurrence. Equivalently order (s,q_R) by any extension of coordinatewise order and set

    beta_(t,s,q_R)
       = [z_i^s z_R^q_R] A_t
         - sum_(a,r)<(s,q_R) beta_(t,a,r)
             binom(k_t,s-a)
             [z_R^(q_R-r)] F_R(h_R(t)+B_R r).

All entries are integer linear forms in the finitely many unknown a_p. A root is allowed only if its shifted lower character fits the ambient old box; all exiting coefficients must vanish. In particular

    q_R+d_R(h_R(t)+B_R q_R)<=d_R(old),
    s+k_t<=d_i(old)

are necessary conditions for a nonzero positive summand. These bounds make the table of lower labels finite and do not depend on an infinite mutation atlas.

## 5. Enlarging lambda is rigorously redundant

With the same F, Pascal's identity gives

    A_t^(lambda+1)=A_t^lambda+A_(t-1)^lambda.

The correct normalized functions satisfy

    x^h_t(lambda+1) A_t^(lambda+1)
      = x_R^c * x^h_t(lambda) A_t^lambda
        + x_i * x^h_(t-1)(lambda) A_(t-1)^lambda.

The two multipliers are initial cluster monomials in the disconnected B0 algebra, so both have nonnegative theta multiplication matrices. Thus positivity of every joint slice at lambda implies it at lambda+1. No larger lambda supplies an additional inequality. The minimum carrier value in Section2 is the strongest member of this family.

This identity is also a finite branching graph: the two edge types are multiplication by x_i and multiplication by x_R^c. The latter is an explicitly computable nonnegative Pieri matrix in the rank n-1 theta tables. This is the precise Bratteli/Pascal interface; it does not yet specify a higher-rank Dyck compatibility condition selecting the original a_p.

## 6. Present limitations and active research

The transform supplies a new sound finite rank-reduction family of constraints. It does not by itself prove that the unique integral greedy character exists, that a minimum is theta, or that a chosen minimum is independent of seed. The known hard direction F+D47 survives these source-surgery inequalities in the first independent exact computation, so that example must not be advertised as excluded by the surgery.

To obtain an actual Dyck construction from the branching graph one must supply a deterministic matching rule compatible with the source binomial quotient, prove its confluence, and show that its coefficient character is the least admissible pointed element. Nonnegative multiplication matrices alone do not give compatible bijections among their path sets. This is the same substantive three-color compatibility issue already isolated in the packet branch, now in a rank-recursive form.

The rank decrease is real: all right-hand coefficients use B_R. The missing result is a completeness/selection theorem, not termination of the displayed finite transform.

## 7. Finite nonunit star factorizations

There is a genuinely different finite family of slopes. Let positive integers sigma and tau satisfy

    sigma | gcd_(j in R) b_j,   tau | gcd_(j in R) c_j.

For a nonzero star these give finitely many pairs. Replace the added entries by

    B_iw=-sigma, B_wi=tau,
    B_wj=-b_j/sigma, B_jw=c_j/tau,
    D_w=D_i sigma/tau.

The symmetrizer may initially be rational; multiplying all entries by a common positive integer gives an integer symmetrizer. Indeed D_w tau=D_i sigma and D_w b_j/sigma=D_j c_j/tau. Mutation at w still cancels the old star exactly and leaves B_R unchanged. The new full seed is again acyclic.

Put L_sigma(p)=sum_j b_j p_j/sigma and take

    lambda=max_(p in P)(L_sigma(p)-tau p_i)>=0.

The full-rank upper-bound and freezing proof in Section2 applies without change. The exchange is

    w w'=eta_w product_j x_j^(c_j/tau)+x_i^sigma,

and, writing v=x_i^sigma/(eta_w product_j x_j^(c_j/tau)), the normalized transform is

    z_i(old)=z_i(new)(1+v)^tau,
    z_j(old)=z_j(new)(v/(1+v))^(b_j/sigma),
    F'=sum_p a_p z^p v^L_sigma(p)
                     (1+v)^(lambda+tau p_i-L_sigma(p)).

The slice of degree k has coefficient multiplier

    binom(lambda+tau p_i-L_sigma(p), k-L_sigma(p)),

and the old leading label is

    h_i(k)=g_i+sigma k,
    h_R(k)=g_R+(c/tau)(lambda-k).

The same finite joint disconnected-theta recurrence applies, now with isolated factor (1+z_i)^[-g_i-sigma k]_+. The support bound is 0<=k<=lambda+tau d_i.

The minimal lambda is again strongest: raising it by one is the normalized Pascal sum with multipliers x_i^sigma and x_R^(c/tau). Both are initial cluster monomials of the disconnected lower-rank algebra.

Independent numerical feedback received 07:35 UTC: the complete finite divisor family gives 14049 rows on the hard rank3 example and all are satisfied by F59085. No F-active row is negative on any of the 56 previously computed tangent rays. Thus the nonunit family still does not remove D47. This is recorded as a valid necessary-condition theorem, not an empirically complete selector. Numerical source: ../agent_overlap_completion/hard_valued_source_surgery_results.json.

## 8. Multiplicativity and the precise graph interface

For fixed matrix and source-factorization data, write S_lambda(F) for the polynomial in Section7. Direct substitution proves

    S_(lambda+mu)(F G)=S_lambda(F) S_mu(G),
    A_k(F G;lambda+mu)=sum_(r+s=k) A_r(F;lambda) A_s(G;mu).

The normalized old labels add as well. Hence, whenever two inputs have positive disconnected-theta slices, their product does too. This establishes a genuine positive semiring transform. Its degree-elevation branching graph has two edge operators, multiplication by x_i^sigma and multiplication by x_R^(c/tau), whose matrices are computed from already-known rank n-1 theta multiplication and the elementary rank1 basis.

For a fixed finite carrier only finitely many labels and edges occur. This graph counts positive decompositions once the original coefficients are known, but it does not by itself recover them: distinct admissible inputs can survive all these tests. Replacing a Dyck vertical edge by a Pieri matrix is therefore a mathematically precise proposal only after a compatibility/matching rule is supplied and proved confluent. Matrix positivity and commutation of scalar multiplication operators alone do not supply such a rule on individual paths.

## 9. Literature and route review, 07:40 UTC

1. BFZ math/0305434v3, Proposition1.8 and Corollary1.9: primary full text checked; useful and applicable as stated. They require full rank, not acyclicity. The larger seed's acyclicity is used only after mutation, for A=U and finite theta expansions.
2. Mandel arXiv:1605.03202v2, all three pages checked from the primary PDF. Theorem1 characterizes atomicity for the scattering atlas. The introduction explicitly recalls that cluster-atlas atomic functions can be linearly dependent already in rank2; its coefficient-extraction argument requires a chart near each theta label. It cannot supply a completeness theorem for source/sink or all-cluster positivity. Useful scope correction, not adopted as a construction.
3. Rupel arXiv:1309.2567v1, primary text opened and Sections2/4 under review. It gives graded-compatible-pair greedy bases for rank2 generalized exchange polynomials; no higher-rank conclusion is imported. The potential interface is the shadow/reflection proof of compatibility, not its theorem outside its stated rank.
4. Burcroff arXiv:2211.15569 and ALCO DOI10.5802/alco.343: search-level lead only. Scope is Dyck expansions of rank2 cluster variables. No theorem used.
5. Burcroff--Lee--Mou arXiv:2409.15235: search-level lead only. Tight gradings compute rank2 wall functions and prove generalized positivity via scattering. This cannot be presented as a scattering-free construction merely by renaming its objects. No theorem used in this branch.

Route assessment: unit and nonunit source-star surgery rigorously reduce the test basis rank, but the hard surviving direction shows that more such degree-elevation tests do not establish selection. Continue toward a nonlocal compatibility rule or a proof of redundancy with existing marked/neighbor conditions; do not advertise repeated slope tests as progress on the missing theorem.
