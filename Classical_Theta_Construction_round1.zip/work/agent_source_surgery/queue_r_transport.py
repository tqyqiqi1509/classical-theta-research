#!/usr/bin/env python3
"""Finite integer queue transports for the multicolor-shadow interface.

This computes existing combinatorial R maps; it does NOT compute cluster theta
coefficients. The purpose is to make a candidate path-level coherence mechanism
available, while explicitly testing its admissible-state requirements.

Primary formulas:
  Aas--Grinberg--Scrimshaw, arXiv:1810.08157v2, Section 6 (binary queues).
  Inoue--Lam--Pylyavskyy, arXiv:1607.00722v2, Section 4.1, tropicalized
  (nonnegative integer occupancy rows).
"""
from __future__ import annotations

import json
import random
import time
from functools import lru_cache
from itertools import product
from pathlib import Path


@lru_cache(None)
def binary_r(a: int, b: int, n: int) -> tuple[int, int]:
    """Cyclic parenthesis duality, with two binary rows on n common sites."""
    opens: list[int] = []
    closes: list[int] = []
    for j in range(n):
        aj, bj = (a >> j) & 1, (b >> j) & 1
        if aj == bj:
            continue  # both occupied is a locally matched pair
        if aj:
            opens.append(j)
        elif opens:
            opens.pop()
        else:
            closes.append(j)
    # Remaining end-of-word opens match beginning-of-word closes cyclically.
    wrap = min(len(opens), len(closes))
    if wrap:
        opens = opens[:-wrap]
        closes = closes[wrap:]
    unmatched = sum(1 << j for j in opens + closes)
    return a ^ unmatched, b ^ unmatched


@lru_cache(None)
def integer_r(x: tuple[int, ...], y: tuple[int, ...]):
    """The one-row affine type-A combinatorial R in explicit min form.

    Output first row has sum(y); output second row has sum(x).
    Indices in the primary formula are cyclic. This version allows arbitrary
    nonnegative integer occupancies, including internal partial arrow bundles.
    """
    n = len(x)
    if len(y) != n or n < 2 or min(x + y) < 0:
        raise ValueError("two nonnegative rows of equal length >=2 are required")
    kappa = tuple(
        min(
            sum(x[(i - ell) % n] for ell in range(1, j + 1))
            + sum(y[(i - ell) % n] for ell in range(j + 2, n + 1))
            for j in range(n)
        )
        for i in range(n)
    )
    xx = tuple(y[i] + kappa[(i + 1) % n] - kappa[i] for i in range(n))
    yy = tuple(x[i] + kappa[i] - kappa[(i + 1) % n] for i in range(n))
    return xx, yy


def braid_left(rows, operation):
    a, b, c = rows
    a, b = operation(a, b)
    b, c = operation(b, c)
    a, b = operation(a, b)
    return a, b, c


def braid_right(rows, operation):
    a, b, c = rows
    b, c = operation(b, c)
    a, b = operation(a, b)
    b, c = operation(b, c)
    return a, b, c


def circular_park(free: frozenset[int], arrival: int, n: int):
    if not free:
        return free
    chosen = min(free, key=lambda x: (x - arrival) % n)
    return free - {chosen}


def audit():
    start = time.monotonic()
    counts = {"binary_pair_checks": 0, "binary_braid_checks": 0,
              "integer_pair_checks": 0, "integer_braid_checks": 0,
              "parking_adjacent_commutations": 0}
    for n in range(2, 7):
        for a, b in product(range(1 << n), repeat=2):
            aa, bb = binary_r(a, b, n)
            assert aa.bit_count() == b.bit_count()
            assert bb.bit_count() == a.bit_count()
            assert aa | bb == a | b and aa & bb == a & b
            assert binary_r(aa, bb, n) == (a, b)
            counts["binary_pair_checks"] += 1
        op = lambda a, b, nn=n: binary_r(a, b, nn)
        for rows in product(range(1 << n), repeat=3):
            assert braid_left(rows, op) == braid_right(rows, op)
            counts["binary_braid_checks"] += 1
        for mask in range(1 << n):
            free = frozenset(i for i in range(n) if mask >> i & 1)
            for a, b in product(range(n), repeat=2):
                lhs = circular_park(circular_park(free, a, n), b, n)
                rhs = circular_park(circular_park(free, b, n), a, n)
                assert lhs == rhs
                counts["parking_adjacent_commutations"] += 1

    rng = random.Random(20261113)
    for _ in range(20000):
        n = rng.randrange(2, 9)
        rows = tuple(tuple(rng.randrange(7) for _ in range(n)) for _ in range(3))
        x, y, z = rows
        xx, yy = integer_r(x, y)
        assert min(xx + yy) >= 0
        assert sum(xx) == sum(y) and sum(yy) == sum(x)
        assert tuple(a + b for a, b in zip(xx, yy)) == tuple(a + b for a, b in zip(x, y))
        assert integer_r(xx, yy) == (x, y)
        assert braid_left(rows, integer_r) == braid_right(rows, integer_r)
        counts["integer_pair_checks"] += 1
        counts["integer_braid_checks"] += 1

    # A classical all-or-nothing arrow bundle need not remain all-or-nothing.
    x, y = (3, 0), (0, 2)
    changed = integer_r(x, y)
    result = {"status": "all exact checks passed", "counts": counts,
              "weighted_bundle_example": {"input": [x, y], "output": changed},
              "seconds": time.monotonic() - start,
              "scope": "queue transport only; no theta identification asserted"}
    Path(__file__).with_name("queue_r_transport_audit.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    audit()
