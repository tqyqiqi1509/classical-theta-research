# Integer queue transport for the multicolor shadow problem

Prepared 2026-11-13, 08:00 UTC. This is an explicit combinatorial interface, not a claimed construction of the theta basis. It identifies what can supply actual path-level coherence, and what additional coupling remains to be proved.

## 1. What the rank2 shadow proof actually preserves

The primary text of Rupel, arXiv:1309.2567v1, was read in Sections4.1--4.2. For a vertical grading S on a maximal Dyck path, write

    f_S(I)=sum_(vertical v in I) S(v)-number_of_horizontal_edges_in_I.

The local shadow ending at a vertical edge is the shortest interval on which this deficit returns to zero. Local shadows are disjoint or nested (Lemma4.10). Remote shadows remove the immediate, same-height forced horizontal edges (Definition4.11).

The relevant mutation argument is substantially stronger than preservation of the total number of selected edges. Under the reflection/complement of the vertical grading, Lemma4.17 reverses the interval deficits. Lemma4.16 expresses each remote-shadow block length using minima of two interval deficits. Corollary4.18 proves equality of corresponding block lengths; the map Omega then uses the unique order-preserving matching in each block. Lemma4.19 preserves the deficit of the transported horizontal grading on the relevant subintervals, and Proposition4.20 deduces compatibility.

Thus a higher-rank replacement for the vertical side must retain interval deficits and matching ownership, rather than only a nonnegative Pieri matrix or the number of currently free slots.

Primary URL: https://arxiv.org/pdf/1309.2567 . Scope: rank2 generalized exchange polynomials; its higher-rank theorem is not being assumed.

## 2. A rigorous queue interpretation of the ordinary shadow

Replace each horizontal edge by one opening parenthesis, and a vertical edge v by S(v) closing parentheses. Match parentheses cyclically, with nested matches allowed. The horizontal endpoints of the matched pairs are precisely the ordinary shadow of S. If the total demand is at least the number of horizontal edges, all horizontal edges belong to the shadow.

To see this, the outermost matching interval ending at a specified demand is exactly the shortest preceding interval with zero deficit. Nested matched intervals have zero total deficit, so removing them leaves the same first-return condition. Taking the union over demands gives the shadow. This also directly recovers its cardinality min(number_of_horizontal_edges,total_demand).

Remote shadows require the additional same-height removal and ownership blocks from Section1. Discarding this extra data returns to the already-failed simple parking graph.

## 3. Binary queue R is an actual bijection

Aas--Grinberg--Scrimshaw, arXiv:1810.08157v2, Section6, gives a concrete map on two binary rows A,B occupying a common cyclic set of N sites:

1. At a site occupied only by A write an opening parenthesis, only by B a closing parenthesis, and by both a locally matched pair.
2. Match cyclically.
3. Move every unmatched parenthesis to the other row, leaving matched entries fixed.

Call the resulting two rows R(A,B). It exchanges the row cardinalities, preserves the occupancy of each individual site, and is an involution. Proposition6.3 proves the braid identity

    R_12 R_23 R_12 = R_23 R_12 R_23.

Proposition6.12 and the proof of Theorem3.1 show compatibility with the queue action on words. These are actual finite bijections, not equalities of path counts. Their proof was read, including the embedding into a word and the parenthesis-signature operators. The interpretation as an affine type-A combinatorial R-matrix is Proposition7.3.

Primary URL: https://arxiv.org/pdf/1810.08157 . The use here is the explicit queue bijection; no assertion is made that arbitrary cluster exchange matrices define this crystal.

## 4. Arbitrary integer occupancy rows

For nonnegative integer N-tuples x,y, cyclically indexed, define

    kappa_i(x,y)=min_(0<=j<N) [sum_(ell=1)^j x_(i-ell)
                              +sum_(ell=j+2)^N y_(i-ell)].

Then set

    R(x,y)_first,i = y_i+kappa_(i+1)-kappa_i,
    R(x,y)_second,i = x_i+kappa_i-kappa_(i+1).

This is the integer piecewise-linear version of the geometric R formula in Inoue--Lam--Pylyavskyy, arXiv:1607.00722v2, Section4.1. The output is nonnegative integral, it exchanges row totals, preserves x_i+y_i at every site, is involutive, and satisfies the braid identity. The formula is also a finite combinatorial optimization: kappa_i is the minimum cost among N one-switch paths, with edge costs from the two rows.

At fixed column totals and a fixed finite number of rows, the entire state set is finite. Consequently it supplies a rigorously finite, fully integer method for transporting internal multicolor path states.

Primary URLs:

- https://arxiv.org/pdf/1607.00722 , Sections3--4. Its cluster realization is specifically a triangular-grid quiver on a cylinder; Theorem4.2 must not be used as an arbitrary-quiver theta transport theorem.
- https://arxiv.org/pdf/1003.3948 , Section3.1, which states the corresponding combinatorial R formula and its affine-crystal interpretation.

## 5. Exact implementation audit

`queue_r_transport.py` implements both the binary parenthesis map and the integer min formula. Its exact audit reports:

- 5456 exhaustive binary pair checks (row sizes, site weights, involution);
- 299584 exhaustive binary braid checks, for all three-row states on 2 through6 sites;
- 20000 integer pair checks and 20000 integer braid checks with arbitrary occupancies from0 through6 and 2 through8 sites;
- 3448 adjacent-commutation checks of same-direction cyclic parking.

All passed. The machine-readable record is `queue_r_transport_audit.json`. These calculations check the formula/interface, not a special cluster family.

## 6. Two concrete requirements for a usable cluster construction

### 6.1 Reordering free-slot parking alone cannot change its character

Fix a cyclic set of free service sites. Two successive forward arrivals commute as maps on the *remaining free set*. If their first free sites differ, each takes its own; if those sites agree, the two arrivals take that site and the next free site, regardless of order. Adjacent exchanges prove independence of an arbitrary arrival ordering, including repeated unit arrivals from weighted bundles.

Therefore a Yang--Baxter reordering that retains only the final free set cannot repair the known fork failures of the parking graph. A new model has to retain matching ownership or additional internal occupancy states and use them when another color is changed.

### 6.2 Classical all-or-nothing bundles are not closed under integer R

An exact smallest transparent example is

    R((3,0),(0,2))=((2,0),(1,2)).

The second output is no longer an all-or-nothing weight3 bundle. A direct attempt to represent an arrow of multiplicity b by b tied copies of one bit therefore fails to be closed under the required transport when different arrow weights interact.

This suggests a specific positive construction problem: allow internal integer occupancies from0 throughb, while keeping the original all-or-nothing bits as boundary data. Such internal states are compatible with binomial marking/counting in the source-surgery transform, but no correspondence between that transform and R has yet been proved. It is essential not to assert this missing correspondence merely because both involve binomial coefficients.

## 7. A finite criterion that would turn the interface into a proof

For each lower-rank Pieri path state, one needs an injective encoding into a finite tuple of occupancy rows with specified boundary weights. The rank2 remote-shadow mutation map must agree, under this encoding, with the same R maps and a specified reversal/complement operation. In a three-color fiber the encodings must share their common rows, rather than choosing separate orderings for each pair. Finally the admissible boundary subset must be preserved by the resulting transport.

If these properties hold, all reassociation of the corresponding adjacent three-row transports follows from the explicit braid identity; this is a genuine path-level coherence theorem. The unresolved part is constructing those simultaneous encodings for arbitrary acyclic B and proving the boundary subset corresponds to the greedy object. The known nonnegative Pieri matrices do not supply this encoding by themselves.

Current route: pursue the simultaneous interval-deficit encoding with internal integer occupancy states. Do not claim success by replacing each scalar Dyck weight with a matrix, by reordering the old parking demands, or by importing the special triangular-grid cluster R theorem to general B.
