# Independent audit of the creation Pieri lemma

Recorded 2026-11-13, approximately 08:07 UTC.

Let B be topologically ordered and acyclic, A=[-B]+, and let

\[
d_i=\max(0,-g_i+\sum_{j<i}A_{ij}d_j),\quad
v=g+(I-A)d.
\]

Thus v,d are nonnegative and v_i d_i=0. For d_i>0 put

\[
a_i=-e_i+Ae_i=g(x_i'),\qquad g^- =g-a_i.
\]

Then

\[
g^-+(I-A)(d-e_i)=v.
\]

The same complementarity remains valid because v_i=0. Uniqueness of the triangular complementarity recursion proves

\[
d(g^-)=d-e_i.
\]

The product x_i' theta_(g^-) is pointed at g with normalized polynomial

\[
P_i=(1+z_i)F_{g^-}.
\]

Its support is contained in [0,d], and its constant coefficient is one. Theta multiplication positivity, in the established acyclic setting, gives

\[
P_i=F_g+\sum_{q\ne0}c_{i,q}z^qF_{g+Bq},\qquad c_{i,q}\in\mathbb N.
\]

Every q is nonnegative: a negative coefficient exponent in a positive theta summand would occur in the product's initial Laurent expansion, which has none. The q=0 coefficient is exactly one by the constant term. Every shifted summand has its top standard-box corner present with coefficient one, so positivity and the product's box bound give

\[
q+d(g+Bq)\le d.
\]

For q!=0 the lower term has strictly smaller total box width. There is no hidden sign or label correction needed. This is a genuine finite upper constraint using only smaller boxes, distinct from the earlier lowering Pieri constraint.

## Why a greatest common lower bound is insufficient

For B=[[0,2],[-2,0]], g=(-2,2), d=(2,2), the rank-two theta/greedy polynomial is

\[
F=1+2u+u^2+2u^2v+u^2v^2.
\]

The two creation products are

\[
P_0=(1+u)[1+u(1+v)^2],\quad
P_1=(1+v)[(1+u)^2+u^2v].
\]

Direct subtraction gives

\[
P_0-F=2uv+uv^2,\qquad P_1-F=v+2uv.
\]

Both differences contain the same lower term 2uv. Consequently F+2uv satisfies both upper comparisons and is their larger common lower bound in the positive lower-theta order. The creation lemma therefore does not, by itself, justify selecting the greatest common lower bound. A minimum selector or another rigidity mechanism remains essential. This diagnostic is a logical check of the proposed general operation, not a proposed special-case construction.
