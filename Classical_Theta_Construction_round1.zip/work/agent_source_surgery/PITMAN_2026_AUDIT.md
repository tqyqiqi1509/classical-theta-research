# Periodic Pitman transform: audited interface

Audit date: 2026-11-13, approximately 08:06 UTC.

## Primary-source record

Engel et al., *The discrete periodic Pitman transform: invariances, braid relations, and Burke properties*, [arXiv:2508.05603v4](https://arxiv.org/abs/2508.05603v4), revised 2026-09-30; IMRN 2026, rnag232, published 2026-10-16. The initially retrieved v3 metadata was obsolete.

Read: definitions, Theorems 1.1/1.4/1.8/1.9, Lemma 2.2, Proposition 2.7, Lemma 2.8 and its proof, Section 3, Appendix A.2. Matrix refactorization is justified entrywise by finite sums; uniqueness follows from the first-row total and backward reconstruction. The braid proof additionally imports one identity from Corwin–Gu–Sorensen. Multipath invariance requires uniquely paired nonintersecting endpoints and a permutation preserving every endpoint boundary. It follows through single-path matrix entries and LGV, not an explicit path bijection. The tropical statement preserves maximal path weights, not multiplicities.

Detected local slips: Lemma 2.8's induction line prints W2 where W1-prime is needed; Definition 1.11's stated geometric support excludes zero despite its formula. Both are repairable typographical issues. No substantive flaw was found in the inspected matrix and limit arguments. No claim concerning arbitrary cluster matrices is made in the paper.

Disposition: useful for transfer-matrix coherence; not adopted as a theta construction. Full Burke/distributional results were not audited or used.

## Independent finite-integer calculation

For periodic integer arrays x,y of common length N define

\[
\delta_i=x_{i+1}-y_i,\qquad
A_i=\max_{0\leq k<N}\sum_{r=1}^{k}\delta_{i+r}.
\]

The implemented transform is

\[
d_i=x_{i+1}+A_i-A_{i-1},\qquad t_i=x_i+y_i-d_i.
\]

The local potential A retains the whole cyclic interval deficit, which ordinary final-vacancy parking discards. The independent implementation is `pitman2026_audit.py`; its exact results are in `pitman2026_audit.json`.

For integer inputs, integer outputs and finiteness follow directly from this formula. Nonnegative closure, swapped row totals, involutivity, the three-row braid, and all sampled two-column interval maxima are checked exactly, with no floating point.

## A concrete general interface, still unproved for the cluster problem

Suppose an ordered-color combinatorial model has finite transfer matrices H(s) satisfying:

1. Two-color remote-shadow reflection changes a pair (a,b) into (a',b') with H(a)H(b)=H(a')H(b').
2. Two-factor reconstruction is unique once its matrix product and one boundary grading are prescribed.
3. One output of the two three-color reflection routes agrees by a direct interval-deficit identity.

Then cancellation and uniqueness prove the remaining outputs agree. This is a route to three-color coherence requiring more structure than positive Pieri coefficients alone. For the desired general B, none of the needed transfer-matrix encoding, reconstruction property, or remote-shadow identification has yet been established.

Even if those properties are supplied, zero-temperature maxima alone cannot recover coefficients of F-polynomials. A counting refinement, with admissible boundary states closed under transport, remains necessary. This records the interface without replacing the main coefficient-selection gap by a matrix identity.
