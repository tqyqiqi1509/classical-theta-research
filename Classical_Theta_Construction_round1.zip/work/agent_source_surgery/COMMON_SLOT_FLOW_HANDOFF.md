# Shared slots, canonical integer flows, and the remaining counting identity

Prepared 2026-11-13, approximately 08:15 UTC. This is a concrete finite object and a proved rank-two interface. Its unmodified higher-rank character is disproved by the exact Newton-carrier check below.

## 1. A common circular word for every pair

For positive widths d_i, place slot (i,k), 1<=k<=d_i, at k/d_i on the rational circle. Sort all slots by this rational number, breaking ties by a fixed topological order of colors. Slots retain their global identities when other colors are deleted. Call the resulting circular word W(d).

**Lemma.** For i<j, the two-color projection of W(d) is a circular rotation of the maximal Dyck word with d_i horizontal and d_j vertical edges.

**Proof.** Write a=d_i, b=d_j, r=gcd(a,b). Give H increment b and V increment -a. Immediately after a non-simultaneous H event k/a, the prefix height is bk-a floor(bk/a), between 0 and a-r. Immediately after a non-simultaneous V event l/b it is b floor(al/b)-al, between -b+r and 0. At simultaneous events H precedes V; the two heights are a and 0. Hence all prefix heights lie in [-b+r,a], a range of width a+b-r. Rotate after a minimum prefix. Every resulting height lies in [0,a+b-r]. A downward V step is possible precisely when the height is at least a; if it is below a, the next step must be H. Conversely, an H step from height at least a would exceed the allowed range. Thus the rotated path takes V as soon as staying below the diagonal permits, which characterizes the maximal Dyck path. The argument also covers r>1, with repeated primitive periods. QED.

This supplies one simultaneous ordering, rather than choosing unrelated Dyck orders for different pairs. The code checks all 900 pairs 1<=a,b<=30 as a guard against endpoint/tie errors.

## 2. A finite integer-flow object with no multiplicity inflation

Assign one bit epsilon_(i,k) to every global slot. For an arrow i->j put b=B_ij, c=-B_ji. In its two-color projection define horizontal grading c(1-epsilon_i) and vertical grading b epsilon_j.

For each selected horizontal slot h, scan forward from h for at most a+b edges. Start an integer queue at zero; add the horizontal grading at H edges and subtract one at V edges. Stop at its first return to zero, or record the sentinel a+b when none occurs. Write tau_H(h) for the edge distance to that return. Define tau_V(v) in the same way scanning backward, adding vertical gradings and subtracting one at H edges.

The entire queue trajectory is retained, including its starting slot. This is a canonical path in a finite directed graph with states (starting slot, elapsed edges, queue size, stopped flag). Queue sizes are bounded by c d_i and b d_j, respectively. They are determined by the bits, so one boundary bit assignment contributes exactly one object, not one object for every possible witness or flow choice.

For a selected pair h,v, let delta(h,v) be their forward circular distance. Declare it admissible exactly when

\[
\tau_H(h)<\delta(h,v)\quad\text{or}\quad
\tau_V(v)<\delta(h,v).
\]

Require this for every selected pair and every arrow. The character is the ordinary counting polynomial

\[
C_{B,d}(z)=\sum_{\epsilon\ \mathrm{admissible}}
  \prod_i z_i^{\sum_k\epsilon_{i,k}}.
\]

All data are finite integers and rational slot comparisons. There are at most 2^(sum d_i) boundary assignments. This is counting, not a maximum-weight partition function.

## 3. Exact rank-two and remote-shadow interface

The first-return inequality is equivalent to the classical HGC/VGC definition: a proper subpath with zero deficit exists exactly when the first return occurs strictly before the opposite endpoint. Consequently, in rank two C is the LLZ compatible-pair polynomial, with horizontal selected edges corresponding to bit 0 and vertical selected edges to bit 1.

The full remote-shadow data are recoverable without choices. The local vertical shadow at v consists of horizontal slots whose distance to v is at most tau_V(v). Take their union. Remove up to S_V(v) horizontal slots in the same consecutive horizontal run immediately preceding each v. For each remaining h, its owner is the first v after h whose local shadow contains h. Together with the number of vertical edges preceding h in the Dyck rotation, this gives the ownership-height blocks used by the rank-two remote-shadow bijection. The horizontal construction is dual.

Thus the queues retain the exact objects needed by the order-preserving block map Omega, including ownership; they do not merely recover shadow cardinalities. This identification follows directly from the definitions and was checked against Rupel's primary text, arXiv:1309.2567, Definitions 4.1, 4.5, 4.11, 4.12. No higher-rank conclusion from that text is used.

## 4. A finite reservoir for the rank-two reflection

There is an additional exact integer interface to complement/reflection. Assume 0<=a<=rb. In the maximal Dyck path D(a,b), let

\[
\eta_j=\lceil ja/b\rceil-\lceil (j-1)a/b\rceil
\]

be the number of H slots just before the j-th V slot. Regard them as occupied cells in a reservoir of r cells for each j. In D(rb-a,b), its corresponding block sizes satisfy

\[
\eta'_j=r-\eta_{b+1-j}.
\]

This identity follows immediately by rewriting ceilings as complementary floors. The reflected vertical grading is likewise S'_j=r-S_(b+1-j). Thus both service capacity and demand live in a common finite r-by-b reservoir, with reflection acting by reversal/complement. The remote-shadow transport is the unique order-preserving matching of its equal ownership blocks. This is a concrete rank-two counting transport.

What is **not** proved is that this block transport equals one of the explicit integer R operations in the same global reservoir coordinates when several neighbors with different r interact. Different arrows prescribe different reservoirs; identifying their shared boundary slots is possible via W(d), but identifying their internal cells and preserving admissibility is an additional condition.

## 5. Exact checks and rejection of the bare higher-rank rule

`common_slot_flows.py` implements this object. It agrees coefficient by coefficient with the independent LLZ integer recurrence for all 225 combinations 1<=a,b<=5 and 1<=exchange weights<=3.

For the hard fork B=[[0,0,3],[0,0,2],[-3,-2,0]], g=(-8,-7,29), d=(8,7,9), the raw character has mass 65098. The established finite selector has mass 59085. The difference has 77 nonzero coefficients, all positive, with total 6013.

Every initial one-color test passes exactly: 42, 34, and 72 fibers respectively are divisible by the required (1+z_i) power, with nonnegative integral quotient. However, its support contains two points outside the proved 252-point theta Newton carrier:

\[
[z^{(6,3,4)}]C=2,\qquad[z^{(7,3,4)}]C=3.
\]

Therefore the bare shared-slot pair compatibility rule cannot be a theta model. The failure is already the Newton support requirement, before any claimed global mutation transport. The code and `common_slot_flow_audit.json` retain this result. The per-color exact tests were run separately and appended to that JSON.

## 6. The precise missing identities

A usable construction needs a local admissibility rule on the **joint** ownership data that removes the overcount while preserving the rank-two restriction. Merely imposing the numerical Newton carrier would be an external filter, not the requested explanation.

For a proposed encoding E of the joint reservoir states, the transport obligation is a concrete conjugacy:

\[
E_{\mathrm{reflected}}\,\Omega_i
 =\rho_i\,R_{i,i_1}\cdots R_{i,i_s}\,E_{\mathrm{initial}},
\]

where rho_i performs the specified finite reversal/complement, all R maps act on the same identified cells, and the admissible boundary subset is preserved. Neither this equality nor closure of the required boundary subset has been proved. Integer R and Pitman braid identities alone do not imply them.

The creation-Pieri lemma offers a second concrete requirement: a weight-preserving injection of the desired object set at g into a binary choice times the smaller-box object set at g-a_i. Its complement must decompose into shifted smaller-box object sets. This would explain the upper bounds by actual counting. For the raw common-slot object, such an injection has not been established and must not be assumed from coefficient positivity.

Recommended fresh task: keep the proved common circular slots and reservoir identity; seek a joint ownership rule or an actual creation-Pieri injection. Do not further expand the family of maximum identities or treat independent two-color compatibility as sufficient.

## 7. Source/sink leaf reddening: independently checked side result

For a source leaf w with initial row r>=0, along an old reddening sequence its row is rC. This follows inductively from sign-coherence: all terms in each column of C have one sign, so the nonnegative linear combination rC follows the same mutation branch. Its sign is opposite to the old-to-w column, so all old frozen rows retain zero in column w. At C=-P the w row is -rP. Mutating w once therefore gives C_ext=-diag(P,1). A sink leaf is handled in the reverse block order. The same argument works for skew-symmetrizable matrices because the symmetrizer preserves opposite signs.

Literature check: Cao--Li, arXiv:1712.00973, Theorem 4.5 and Remark 4.6 state the general triangular-extension result; the constructive direction of the proof was read. Bucher--Machacek, SIGMA 2020.049, Lemma 2.3 records it. The leaf argument above is independent and does not use any Li--Pan polyhedral-basis conclusion.
