"""Exact tests of the proposed dual-g-cone radical property.

Finite searches do not establish universal nonnegativity. Negative witnesses
are exact. Any conjectural all-word conclusions are kept separate.
"""
import sys, json, time
from collections import deque
sys.path.insert(0, '/workspace/scratch/184561e83b72/work/agent_division')
from principal_cluster import mutate_matrix

def probe(B, points, depth, bit_cap=100000, seed_cap=300000):
    n=len(B);E0=tuple(map(tuple,B))+tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
    G0=tuple(tuple(int(i==j) for i in range(n)) for j in range(n)) # columns
    q=deque([(E0,G0,(),-1)]);seen={E0};negative={};mins=[None]*len(points);pruned=0;bit_pruned=0;nrays=0;maxbit=0
    while q:
        E,G,w,last=q.popleft();nrays+=n
        for pi,p in enumerate(points):
            for j,g in enumerate(G):
                s=sum(a*b for a,b in zip(p,g))
                mins[pi]=s if mins[pi] is None else min(mins[pi],s)
                if s<0 and pi not in negative:negative[pi]={'p':p,'g':g,'word':w,'vertex':j,'pairing':s}
        if len(w)>=depth:continue
        for k in range(n):
            if k==last:continue
            c=[E[n+i][k] for i in range(n)]
            assert all(x>=0 for x in c) or all(x<=0 for x in c)
            eps=1 if any(x>0 for x in c) else -1
            ng=tuple(-G[k][r]+sum(max(-eps*E[i][k],0)*G[i][r] for i in range(n)) for r in range(n))
            GG=list(G);GG[k]=ng;GG=tuple(GG)
            EE=mutate_matrix(E,k)
            if EE in seen:continue
            b=max(abs(v).bit_length() for row in EE for v in row);maxbit=max(maxbit,b)
            if b>bit_cap:bit_pruned+=1;continue
            if len(seen)>=seed_cap:pruned+=1;continue
            seen.add(EE);q.append((EE,GG,w+(k,),k))
    return {'B':B,'points':points,'depth':depth,'seeds':len(seen),'rays_with_repetition':nrays,'negative_witnesses':list(negative.values()),'minimum_pairings':mins,'bit_pruned':bit_pruned,'seed_pruned':pruned,'maximum_entry_bits':maxbit}

if __name__=='__main__':
    out=[];start=time.time()
    for a in [2,3,4,5]:
        B=[[0,a,-a],[-a,0,a],[a,-a,0]]
        p=[[1,1,1],[1,1,2],[2,2,3],[10,10,11],[1,2,3]]
        r=probe(B,p,14);out.append(r)
        print('a',a,'seeds',r['seeds'],'minimum',r['minimum_pairings'],'cuts',r['bit_pruned'],r['seed_pruned'],flush=True)
    with open('/workspace/scratch/184561e83b72/work/agent_frame/dual_cone_probe.json','w') as f:json.dump({'seconds':time.time()-start,'results':out},f,indent=2)
