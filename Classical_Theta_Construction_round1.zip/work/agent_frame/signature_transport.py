"""Validate the finite-signature theorem using exact integer mutation.

This script updates each H_i coefficient table directly, independently of the
older full linear-transform matrix interning implementation. It never prunes
inactive descendants. All truncation, state limits and integer limits are
reported. A finite computation is not used as the proof.
"""
import sys, math, json, time, random
from itertools import product
from collections import deque
sys.path.insert(0, '/workspace/scratch/184561e83b72/work/agent_division')
from principal_cluster import mutate_matrix
from truncated_atlas import symmetrizer

def binom(a,j):
    if j<0:return 0
    if j==0:return 1
    if a>=0:return math.comb(a,j) if j<=a else 0
    return (-1)**j*math.comb(-a+j-1,j)

def exponents(n,N):
    return sorted((p for p in product(range(N+1),repeat=n) if sum(p)<=N),key=lambda p:(sum(p),p))

def validate(B,N,depth,state_cap=150000,bit_cap=12000):
    n=len(B);D=symmetrizer(B);ee=exponents(n,N);index={p:i for i,p in enumerate(ee)}
    roots=[p for p in ee if any(p) and math.gcd(*p)==1]
    E0=tuple(map(tuple,B))+tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
    G0=tuple(tuple(int(i==j) for i in range(n)) for j in range(n))
    H0=tuple(tuple(int(not any(p)) for p in ee) for i in range(n))
    signature_H={};signature_w={};q=deque([(E0,G0,H0,(),-1)]);seen={E0:(G0,H0)}
    transitions=0;inactive=0;zero_seeds=0;zero_pairs=0;duplicates=0;root_length_checks=0;sign_checks=0;duality_checks=0
    bit_pruned=0;state_pruned=0;maxH=0;maxbits=0;firstnew={}
    while q:
        E,G,H,w,last=q.popleft()
        gs=[sum(G[j][i] for j in range(n)) for i in range(n)]
        vals=[sum(D[i]*p[i]*gs[i] for i in range(n)) for p in roots]
        zeros=sum(v==0 for v in vals);zero_seeds+=bool(zeros);zero_pairs+=zeros
        sig=tuple(v>=0 for v in vals)
        if sig in signature_H:
            assert signature_H[sig]==H, ('SIGNATURE CONFLICT',B,N,w,signature_w[sig],sig,H,signature_H[sig])
        else:
            signature_H[sig]=H;signature_w[sig]=w;firstnew[len(w)]=firstnew.get(len(w),0)+1
        maxH=max(maxH,max(max(h) for h in H))
        assert min(min(h) for h in H)>=0,('negative initial-variable transport',B,w,H)
        if len(w)>=depth:continue
        for k in range(n):
            if k==last:continue
            c=tuple(E[n+i][k] for i in range(n));alpha=tuple(abs(v) for v in c)
            sign_checks+=1
            assert all(v>=0 for v in c) or all(v<=0 for v in c)
            assert math.gcd(*(D[i]*abs(c[i]) for i in range(n)))==D[k]
            root_length_checks+=1
            eps=1 if any(v>0 for v in c) else -1
            ng=tuple(-G[k][r]+sum(max(-eps*E[i][k],0)*G[i][r] for i in range(n)) for r in range(n))
            GG=list(G);GG[k]=ng;GG=tuple(GG)
            EE=mutate_matrix(E,k)
            if sum(alpha)>N:
                HH=H;inactive+=1
            else:
                HH=[]
                for i in range(n):
                    hh=[]
                    for p in ee:
                        base=sum(c[r]*D[r]*(int(r==i)+sum(B[r][s]*p[s] for s in range(n))) for r in range(n))
                        assert base%D[k]==0
                        a=base//D[k]
                        m=min((p[j]//alpha[j] for j in range(n) if alpha[j]),default=0)
                        v=0
                        for z in range(m+1):
                            pp=tuple(p[j]-z*alpha[j] for j in range(n))
                            v+=binom(a,z)*H[i][index[pp]]
                        hh.append(v)
                    HH.append(tuple(hh))
                HH=tuple(HH)
            transitions+=1
            if transitions%101==0:
                # G^T D C = D, with G stored as columns.
                assert all(sum(GG[i][r]*D[r]*EE[n+r][j] for r in range(n))==D[i]*int(i==j) for i in range(n) for j in range(n))
                duality_checks+=1
            if EE in seen:
                duplicates+=1
                assert seen[EE]==(GG,HH),('duplicate seed mismatch',B,w+(k,))
                continue
            b=max(abs(v).bit_length() for row in EE for v in row);maxbits=max(maxbits,b)
            if b>bit_cap:bit_pruned+=1;continue
            if len(seen)>=state_cap:state_pruned+=1;continue
            seen[EE]=(GG,HH);q.append((EE,GG,HH,w+(k,),k))
    M=len(roots)
    arrangement_bound=2*sum(math.comb(M-1,k) for k in range(min(n,M))) if M else 1
    return {'B':B,'D':D,'rank':n,'degree':N,'depth':depth,'seed_count':len(seen),'transitions':transitions,'distinct_signatures':len(signature_H),'distinct_H':len(set(signature_H.values())),'primitive_directions':M,'arrangement_upper_bound':arrangement_bound,'zero_signature_seed_count':zero_seeds,'zero_signature_pair_count':zero_pairs,'duplicate_seed_checks':duplicates,'root_length_checks':root_length_checks,'c_sign_checks':sign_checks,'duality_checks':duality_checks,'inactive_transitions':inactive,'max_H_coefficient':maxH,'max_entry_bits':maxbits,'state_pruned':state_pruned,'bit_pruned':bit_pruned,'new_signature_depths':firstnew}

def samples():
    out=[]
    for a,b,c in product([1,2],[-2,-1,1,2],[-2,-1,1,2]):
        out.append(('rank3_'+str((a,b,c)),[[0,a,b],[-a,0,c],[-b,-c,0]],12))
    for a in [3,4,5]:out.append(('cyclic_rank3_weight'+str(a),[[0,a,-a],[-a,0,a],[a,-a,0]],12))
    rng=random.Random(202611130453)
    for n,count,dep in [(4,16,8),(5,12,6)]:
        for z in range(count):
            D=[1]*n if z<count//2 else [rng.randint(1,4) for _ in range(n)]
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    a=rng.choice([-2,-1,0,1,2]);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
            out.append(('rank'+str(n)+'_'+str(z),B,dep))
    out.extend([('rank1',[[0]],5),('zero_rank3',[[0]*3 for _ in range(3)],5),('disconnected_rank4',[[0,2,0,0],[-3,0,0,0],[0,0,0,1],[0,0,-1,0]],8)])
    return out

if __name__=='__main__':
    start=time.time();out=[]
    target='/workspace/scratch/184561e83b72/work/agent_frame/signature_transport_validation.json'
    for name,B,depth in samples():
        t=time.time();r=validate(B,3,depth);r['name']=name;r['seconds']=time.time()-t;out.append(r)
        data={'cases':len(out),'seconds':time.time()-start,'total_seeds':sum(x['seed_count'] for x in out),'total_transitions':sum(x['transitions'] for x in out),'results':out}
        with open(target,'w') as f:json.dump(data,f,indent=2)
        print(name,'seeds',r['seed_count'],'sig',r['distinct_signatures'],'H',r['distinct_H'],'zero',r['zero_signature_seed_count'],'cuts',r['bit_pruned'],r['state_pruned'],'seconds',round(r['seconds'],3),flush=True)
