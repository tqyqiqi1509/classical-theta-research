# Finite signatures for all truncated classical cluster transports

Date: 2026-11-13. Status: proved here, subject to independent verification by the parent. This is a general mechanism, not a completed construction of a higher-rank greedy or theta basis. The statement is for arbitrary finite-rank skew-symmetrizable integer exchange matrices. No scattering diagram, broken line, or representation-theoretic object is used in the construction or proof below. Standard classical cluster positivity, principal-coefficient constant terms, and tropical duality are explicit external inputs.

## 1. Conventions and normalized transports

Let B be an n by n integer exchange matrix and D=diag(d_1,...,d_n) a positive integral symmetrizer, so DB is skew-symmetric. Start with principal coefficients y_1,...,y_n and write

\[
z_j=y_jx^{B[:,j]}.
\]

We work in the formal y-adic Laurent algebra over Q. Every expression considered has nonnegative y degree. Its degree is total y degree, equivalently total z degree in an expansion x^g F(z).

For a seed t, G_t denotes the initial g-matrix, with columns g_{j;t}. A normalized transport T_t is obtained by expressing an initial Laurent function in seed t and identifying the mutable monomial x_t^{G_t^{-1}g} with the formal symbol x^g. It fixes the original y variables. Consequently

\[
T_t(x^gF(z))=x^gH_t(z)^g
 F\left(z_j\prod_iH_{i,t}(z)^{B_{ij}}\right),
\tag{1}
\]

where H_{i,t} is the normalized expansion of the initial cluster variable x_i. It is convenient to write T_t^g(F) for the coefficient factor after x^g.

Each H_{i,t}(0)=1. More generally, if f is a cluster variable from any seed u, written initially as x^{g_f}F_f(z), then

\[
T_t^{g_f}(F_f)\in\mathbb N[z],\qquad
T_u^{g_{j;u}}(F_{j;u})=1.
\tag{2}
\]

### Why original frozen degrees remain nonnegative

This detail must not be replaced by an unproved coefficient-reset assertion. Classical Laurent positivity expresses f in seed t as a finite nonnegative Laurent sum in x_t and original y, with a priori possibly negative y exponents. Set y_i=epsilon^{w_i}, where every w_i>0, and fix all initial x_i>0. The principal-coefficient separation formula and F(0)=1 give x_{j;t}->x^{g_{j;t}}>0, and f also has a finite nonzero limit. A positive Laurent summand with y exponent q satisfying q.w<0 would diverge and cannot be canceled. Thus every q satisfies q.w>=0 for every positive w, hence q_i>=0 for every i. Homogeneity then gives its mutable exponent as G_t^{-1}(g_f+Bq). At q=0, invertibility of G_t and the constant-term formula force the single coefficient 1. This proves (2), as well as the asserted properties of H_i.

## 2. The finite integer generators

Suppose the mutation t->t' has signed c-column c, write alpha=|c|, and let epsilon be its common sign. Tropical duality and unimodularity imply

\[
\delta_\alpha:=\gcd_i(d_i\alpha_i)=d_k
\]

for its current vertex k. The normalized mutation is the formal automorphism

\[
U_{\alpha,\epsilon}(x^g z^q)
=x^g z^q(1+z^\alpha)^{\epsilon\alpha^TD(g+Bq)/\delta_\alpha}.
\tag{3}
\]

Thus, on a coefficient vector A,

\[
(U_{\alpha,\epsilon}^{g}A)_p
=\sum_{j\ge0}
\binom{\epsilon\alpha^TD(g+Bp)/\delta_\alpha}{j}
A_{p-j\alpha}.
\tag{4}
\]

The upper index is independent of j because alpha^TDBalpha=0. Formula (4) is an integer, finite calculation at any finite degree. If |alpha|_1>N it is the identity modulo degrees greater than N. Actual c-columns are primitive integer vectors, so the nonidentity alphabet consists of at most 2M letters, where

\[
P_N=\{p\in\mathbb N^n\setminus\{0\}:|p|_1\le N,\ \gcd_i p_i=1\},\quad M=|P_N|.
\tag{5}
\]

Allowing every p in P_N as an abstract letter produces an over-approximation: most such letters need not be actual c-vectors.

## 3. One-dimensional lowest-order differences

For p>0 define the derivation

\[
E_p(x^g y^q)=\langle Dp,g\rangle z^p x^g y^q.
\tag{6}
\]

The y variables are held fixed. A direct calculation gives

\[
[E_p,E_q]=(p^TDBq)E_{p+q}.
\tag{7}
\]

In the nilpotent quotient modulo total degree greater than N,

\[
\log U_{\alpha,\epsilon}
=\frac{\epsilon}{\delta_\alpha}
\sum_{m|\alpha|_1\le N}\frac{(-1)^{m+1}}{m^2}E_{m\alpha}.
\tag{8}
\]

Indeed E_alpha(z^alpha)=0, so exponentiating the displayed derivation multiplies x^g by the required binomial power. Equations (7)-(8) show that logarithms of all relative transports lie in the graded Lie algebra spanned by the E_p. This is a finite rational calculation in each quotient, even though every actual coefficient transport is integral.

If T_s and T_t coincide below total degree r, their relative transport is identity below r, and its degree r part is

\[
\sum_{|p|_1=r}\lambda_p E_p.
\]

Therefore, for any initial pointed expression x^gF(z), F(0)=1,

\[
[z^p]\bigl(T_s^g(F)-T_t^g(F)\bigr)
=\lambda_p\langle Dp,g\rangle\qquad(|p|_1=r).
\tag{9}
\]

The same lambda_p works for every g and every such F. This conclusion is the essential restriction; arbitrary unipotent integer matrices do not satisfy it.

## 4. Endpoint positivity lemma

Under the preceding lower-degree agreement, apply (9) to the n cluster variables of seed t. Their normalized expansion at t is exactly 1, whereas their expansion at s is nonnegative. Thus

\[
\lambda_p\langle Dp,g_{j;t}\rangle\ge0\quad\text{for every }j.
\tag{10}
\]

Using instead the cluster variables of seed s gives

\[
-\lambda_p\langle Dp,g_{j;s}\rangle\ge0\quad\text{for every }j.
\tag{11}
\]

If lambda_p>0, all pairings with the columns of G_t are nonnegative and all pairings with columns of G_s are nonpositive. Each list has a nonzero entry, since G is invertible and Dp is nonzero. Hence

\[
\langle Dp,G_t\mathbf1\rangle>0,
\qquad\langle Dp,G_s\mathbf1\rangle<0.
\tag{12}
\]

For lambda_p<0, the strict signs are reversed. In particular, nonzero lowest-order differences force opposite strict signs of these two scalar tests.

This also explains why the earlier proposed polar-cone/radical assertion is unnecessary: if all cluster g-vectors pair nonnegatively with p, equations (10)-(11) already force lambda_p=0, whether or not Bp=0.

## 5. Finite-signature theorem

For each seed t define the binary signature

\[
\sigma_N(t)_p=
\begin{cases}
1,&\langle Dp,G_t\mathbf1\rangle\ge0,\\
0,&\langle Dp,G_t\mathbf1\rangle<0,
\end{cases}\qquad p\in P_N.
\tag{13}
\]

**Theorem.** If sigma_N(s)=sigma_N(t), then T_s=T_t modulo degrees greater than N, as formal automorphisms. Consequently the equality holds for coefficient operators of every fixed g, not merely for a tested label.

**Proof.** At degree zero all transports are identity. Induct on r=1,...,N. Assuming equality below r, every degree r difference has the form (9). A positive multiple p of a primitive p_0 has the same signature sign as p_0. Equal signatures exclude the opposite strict signs in (12), so lambda_p=0 for every |p|=r. This proves the induction. The convention assigning zero to the nonnegative class is harmless because a nonzero lambda_p forces both scalar tests to be strictly nonzero. QED.

### Uniform number of signatures

The signatures are chambers of the central hyperplane arrangement

\[
\langle Dp,v\rangle=0,\qquad p\in P_N.
\]

A vector v lying on a hyperplane has our tie-to-positive signature realized by v+epsilon*1 for sufficiently small epsilon>0: all normals Dp have nonnegative coordinates and are nonzero. Hence boundary signatures add no extra patterns. The elementary hyperplane-insertion recurrence gives the uniform bound

\[
S(n,N)=2\sum_{j=0}^{n-1}\binom{M-1}{j}
\tag{14}
\]

for M>0, with binomial coefficients outside their usual range zero. For N=0 take S=1. No general-position hypothesis is needed for an upper bound. The bound can be replaced by the actual number of chambers, computed by rational linear inequalities.

In particular, every exchange matrix B of fixed rank has at most S(n,N) normalized transport jets at degree N. This statement is unconditional on reddening, existence of a negative positive frame, or mutation-finiteness.

## 6. A bounded abstract word, and explicit integer bounds

Consider any actual finite mutation path from the initial seed to t. Record sigma_N at its successive vertices. If a signature repeats, the two normalized transport automorphisms are equal by the theorem, so the intervening product of mutation generators is the identity in the truncated group. Delete that segment algebraically. Repeat until the signature walk has no repeated vertex. The remaining word has at most S(n,N)-1 letters. Remove every inactive letter, since it is the identity.

**Bounded-word corollary.** Every actual degree-N normalized transport is a product of at most S(n,N)-1 members of

\[
\{U_{\alpha,+},U_{\alpha,-}:\alpha\in P_N\}.
\tag{15}
\]

The retained letters need not form a legal mutation path after deletion. This is an algebraic representation and a finite computable over-approximation, not a reachability-preserving seed reduction.

For a fixed g, one may enumerate every word in (15) up to that length using the explicit integer matrices (4). This yields a finite superset containing all actual coefficient transports. A numerical coefficient bound follows even without enumerating the words. Put

\[
R=\max_{\alpha\in P_N,\ |p|\le N}
\left|\frac{\alpha^TD(g+Bp)}{\delta_\alpha}\right|,
\qquad K=(N+1)\binom{R+N}{N}.
\tag{16}
\]

Each generator matrix has absolute row sum at most K, because each row has at most N+1 generalized binomial entries and each such entry has magnitude at most the displayed binomial. Therefore every actual transport matrix has absolute row sum at most

\[
K^{S(n,N)-1}.
\tag{17}
\]

This is usually an extremely loose bound, but it is explicit, integral, and depends only on B,D,g,N. It removes the negative-frame hypothesis from the earlier finite-bound mechanism. The earlier frame bound may remain much sharper when a frame is available.

## 7. The unresolved construction problem

This theorem solves neither of the following by itself:

1. Determining which signatures are realized by actual seeds, with a terminating algorithm.
2. Showing that positivity inequalities from every abstract word in (15) are legitimate for the desired basis construction.

The second point is particularly important. An arbitrary word in the finite alphabet can be non-realizable, and its positivity test can be strictly stronger than every actual-seed test. Consequently, the finite superset must not simply be substituted for the true cluster atlas.

The next general target is a computable, coefficient-cut-complete superset: extra operators must give inequalities already implied by genuine paths, as was achieved in the separate degree-two endpoint argument. Neither the finite-signature theorem nor the bounded-word corollary proves theta identification, finite Laurent support of a candidate, or a basis theorem.

## 8. Independent implementation checks

`signature_transport.py` updates the n initial-variable coefficient arrays directly by (4), tracks G independently by its matrix mutation, and checks that equal signatures give equal complete H jets. It includes nontrivial symmetrizers, zero scalar signature entries, zero/disconnected matrices, and inactive mutation steps without pruning descendants. It also checks repeated extended matrices, c-sign coherence, the gcd root length, and tropical duality. All state and integer resource cuts are recorded. Numerical results are stored separately and are evidence for implementation, not the proof above.

The completed degree-three run covered 66 matrices of ranks 1 through 5, including 15 with nonconstant symmetrizer, 467,512 actual seeds and 480,781 transitions. There were 16,933 seeds with at least one zero scalar signature entry, 30,516 zero signature pairs, 13,335 duplicate-seed comparisons, and 4,727 independent duality checks. No signature collision, sign failure, coefficient negativity, root-length failure, or resource pruning occurred. Runtime was approximately 58.28 seconds. See `signature_transport_validation.json` and the retained log.

Wolfram independently expanded the symbolic rank-three skew-symmetrizable bracket identity with B=D^{-1}S for a fully symbolic skew-symmetric S. The difference simplified to 0. Exact code is in `wolfram_bracket_verification.wl`; observed output was `{0, {{0,0,0},{0,0,0},{0,0,0}}}`.

`ENDPOINT_CUT_CERTIFICATES.md` develops the sharper coordinatewise version: at most two actual top values above fixed proper lower data, attained minimum/maximum certificates from one endpoint seed, and a label-specific positive-frame/recession lemma.
