# Endpoint certificates and label-specific positive frames

Date: 2026-11-13. This note continues `FINITE_SIGNATURE_THEOREM.md` and keeps its conventions. It records proved general lemmas and the exact remaining gap. It does not claim a higher-rank basis construction.

## 1. Coordinatewise truncations

Fix a nonzero p in N^n. Work in the finite quotient retaining monomials z^q with 0<=q<=p. Its proper lower indices are q<=p, q!=p. If two actual normalized transports agree on all proper lower indices, their difference at p is one-dimensional:

\[
[z^p](T_s^gF-T_t^gF)=\lambda\langle Dp,g\rangle
\quad\text{when }F(0)=1.
\tag{1}
\]

Indeed, in this quotient z^p is the sole remaining positive top degree, and the graded Lie algebra argument in the main note gives lambda E_p. No equality of unrelated total-degree coefficients is required.

Choose a reference transport in a fixed proper-lower class and use lambda_t as the resulting scalar coordinate of each actual seed t in that class.

## 2. At most two actual top-degree values

**Proposition.** A fixed proper-lower class has at most two different actual values of lambda_t.

**Proof.** Suppose a<b<c are realized by seeds s,t,u. Comparing the a and b transports and testing the variables of the middle seed t shows every entry of G_t^T Dp is nonpositive. Comparing b and c and testing the same variables shows every entry is nonnegative. Hence G_t^T Dp=0, contrary to invertibility of G_t and p!=0. QED.

This proposition was independently noticed by the higher-degree-cut agent and follows from the same endpoint positivity argument. For the degree-two rank-two parameter tau, once both 0 and 1 are realized, no intermediate value can be realized by an actual seed with the same lower data. The convex interval remains useful as an outer set for inequalities.

## 3. A single seed can certify an extremum

**Proposition.** Let t be an actual seed in a fixed proper-lower class.

1. If G_t^T Dp is entrywise nonnegative, lambda_t is the minimum of all actual lambda values in the class.
2. If G_t^T Dp is entrywise nonpositive, lambda_t is the maximum.
3. If G_t^T Dp contains both a positive and a negative entry, lambda_t is the only value.

**Proof.** The variables of t have normalized expansion exactly 1 at t. At any other seed s in the class their p coefficients are

\[
(\lambda_s-\lambda_t)\langle Dp,g_{j;t}\rangle\ge0.
\]

An entrywise nonnegative list has at least one positive entry because G_t is invertible; this forces lambda_s>=lambda_t. The nonpositive case is analogous. A mixed list forces equality. QED.

For a target label g, write v=\langle Dp,g\rangle. A nonnegative endpoint seed gives the attained worst positivity cut whenever v>0. A nonpositive endpoint seed gives the attained worst cut whenever v<0. If v=0, the coefficient does not depend on the top scalar. Thus a single seed can certify a worst coefficient without enumerating the entire class.

If two distinct actual scalar values are known, the preceding at-most-two result certifies the whole class. Its operator rows are the two endpoints; every intermediate real scalar produces a convex combination of their rows and hence no stronger positivity inequality.

The unresolved singleton case is precise: only one value has been observed, all available endpoint seeds have a uniform sign opposite to the target objective, and there is no independent reason excluding the other sign. Finite signatures alone do not decide that case.

## 4. A local positive-frame lemma for a chosen label

The earlier global frame method required a known positive expression with strictly negative g-vector. That hypothesis is unnecessary for bounding a single target objective in a fixed lower class.

Let f_l=x^{h_l}P_l(z), l=1,...,m, be finitely many known universally positive pointed expressions, P_l(0)=1. They may be cluster variables or products supplied by finite mutation words. With the proper lower transport fixed, their target coefficients are affine functions of the remaining scalar:

\[
[z^p]T_\lambda^{h_l}(P_l)=b_l+\lambda d_l,
\qquad d_l=\langle Dp,h_l\rangle.
\tag{2}
\]

Therefore every actual scalar lies in the interval/polyhedron

\[
\mathcal P=\{\lambda\in\mathbb R:b_l+\lambda d_l\ge0\ \forall l\}.
\tag{3}
\]

The constants b_l are finite rational calculations from the fixed lower transport and the supplied P_l; with an integral reference transport they are integral.

**Label-specific bound.** Suppose

\[
g=\sum_l \rho_l h_l,\qquad \rho_l\ge0.
\tag{4}
\]

Then lambda\langle Dp,g\rangle is bounded below on the nonempty set P. More explicitly,

\[
\lambda\langle Dp,g\rangle
\ge-\sum_l\rho_l b_l.
\tag{5}
\]

**Proof.** Multiply the inequalities in (3) by rho_l and add. Equivalently, every recession direction u of P satisfies u d_l>=0, hence u\langle Dp,g\rangle>=0. QED.

For a candidate F with target coefficient

\[
[z^p]T_\lambda^g(F)=b_F+\lambda\langle Dp,g\rangle,
\]

equation (5) yields the explicit lower bound b_F-sum_l rho_l b_l. It is a nonnegative linear-combination certificate valid uniformly for all actual seeds in the class. A rational representation in (4) can be found by a finite linear program; an explicitly known product with leading label g gives nonnegative integer rho_l immediately.

In fact, one known universally positive pointed product P=x^gF_P suffices: take m=1, h_1=g, rho_1=1. If the target pairing is negative, this same-label test supplies the upper bound on lambda needed for the objective; if positive, it supplies the lower bound. Thus the relevant optimization cannot escape in an adverse unbounded direction merely because no strictly negative global frame exists.

## 5. What this does and does not make algorithmic

These lemmas give finite, exact certificates for many coefficient cuts:

- mixed endpoint: complete class;
- two distinct endpoints: complete class;
- one endpoint with the target sign: attained worst cut;
- a same-label positive product: a finite objective bound, even without a global negative frame.

The last certificate need not be sharp. A positive product of incompatible cluster variables need not become a monomial in any chart, so its coefficient inequality need not be attained. No argument here proves that finitely many known cluster-variable tests always yield a sharp outer interval, or that every target label admits such a positive product. Those are additional problems.

The parent and the higher-degree-cut agent are studying whether rows from short genuine mutation words generate all necessary cuts by nonnegative rational combinations. The experimentally suggested depth 2N-1 is not proved by these endpoint lemmas. In particular, inactive excursions cannot simply be deleted as seed paths, even though inactive letters are identities in the coefficient quotient.
