Module[{p={p1,p2,p3},q={q1,q2,q3},g={g1,g2,g3},
  dd=DiagonalMatrix[{d1,d2,d3}],
  ss={{0,a,b},{-a,0,c},{-b,-c,0}},bb,lhs,rhs},
 bb=Inverse[dd].ss;
 lhs=(q.dd.g)*(p.dd.(g+bb.q))-(p.dd.g)*(q.dd.(g+bb.p));
 rhs=(p.dd.bb.q)*((p+q).dd.g);
 {Simplify[lhs-rhs],Simplify[dd.bb+Transpose[dd.bb]]}
]
