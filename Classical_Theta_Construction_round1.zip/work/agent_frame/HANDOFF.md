# Handoff: unconditional finite transport signatures

Subtask interval: approximately 2026-11-13 04:46-05:04 UTC. Parent research run remains active; this is only a context refresh.

## Main proved result

Read `FINITE_SIGNATURE_THEOREM.md` first. For arbitrary integral skew-symmetrizable B and principal coefficients, the degree-N normalized transport is determined by the finite binary signature

    sign_nonnegative( (D p) dot (G_t * 1) )

for primitive p>=0, 0<sum(p)<=N. Zero is assigned to the nonnegative side. This determines the entire formal automorphism, simultaneously for every label g.

Proof core: the lowest relative difference is lambda_p E_p, with E_p(x^g)=<D p,g> z^p x^g and [E_p,E_q]=(p^T D B q)E_{p+q}. The cluster variables from the two endpoint seeds yield lambda_p G_t^T Dp>=0 and -lambda_p G_s^T Dp>=0. Nonzero lambda forces opposite strict signs of the two scalar sums; matching signatures therefore forces equality by induction.

If M is the number of primitive nonnegative p with sum(p)<=N, the number of possible signatures is at most

    S = 2 sum_{j=0}^{n-1} binom(M-1,j).

Loop-erasing repeated signatures along an actual seed path gives an **abstract** signed-c word of length at most S-1 representing its degree-N transport. It need not remain a legal seed path. This gives a finite computable operator superset and explicit integer coefficient bounds for every B,D,g,N, with no negative-frame, reddening, or mutation-finite hypothesis.

## Sharpenings for coefficient cuts

Read `ENDPOINT_CUT_CERTIFICATES.md`.

- Fixing proper coordinatewise lower jets at a target p leaves at most two actual scalar values.
- An actual endpoint with G_t^T Dp>=0 certifies the minimum scalar; <=0 certifies the maximum; mixed signs certify uniqueness.
- Two distinct actual endpoints certify the entire class; intermediate real scalars give convex combinations of their rows.
- For target label g in the nonnegative cone of finitely many known universally positive labels h_l, their positivity tests bound the target LP objective below. A known positive product with leading label g is already enough. This removes the need for a globally negative frame when bounding that target objective.

The final point gives a valid finite bound, not automatically a sharp one.

## Computational record

`signature_transport.py` is independent of the old full-transform-matrix code: it directly transports the n initial-variable H coefficient arrays and independently mutates G.

Completed degree-three study:

- 66 matrices, ranks 1-5;
- 15 nonconstant symmetrizers;
- 467,512 actual seeds;
- 480,781 transitions;
- 16,933 seeds with zero signature entries, 30,516 zero pairs;
- 13,335 duplicate-seed comparisons;
- 4,727 independent tropical-duality checks;
- no resource pruning, no failed assertions, no signature collisions.

Results: `signature_transport_validation.json`; progress log retained. Runtime about 58.28 seconds.

Wolfram also verified the generic symbolic skew-symmetrizable bracket identity; exact code in `wolfram_bracket_verification.wl`, observed result zero.

## Superseded route and sources

The proposed statement `polar(cluster-g cone) subset ker(B)` was investigated but is no longer needed. Equal-weight cyclic rank-three probes suggest it may be false for weights greater than 2; a 2026 Akagi-Chen positive-cone theorem is a relevant lead but was not fully audited or used. Do not present the finite probe as a proof of a counterexample.

Full route/source record: `RESEARCH_LOG.md`. No 2026 theorem is an input to the finite-signature proof.

## Genuine remaining gap

The finite abstract word set contains nonrealizable words. Imposing all their positivity inequalities can be false. The next step is a coefficient-cut-complete computable outer family, not merely finite operator bounds.

The parent's/higher-degree agent's candidate `genuine mutation words of length <=2N-1 generate all degree-N cuts` is still experimental. This subtask did not prove it. Inactive seed excursions cannot be erased simply because their coefficient letters are identities. A short **abstract** word is not the same as a short actual mutation word.

Potential next connection already discussed with parent: full-support localization via freezing and normalized monomial changes, followed by higher-degree positive endpoint tests. The main proofs in this directory are ready for independent review and reuse; avoid re-proving finite signatures from scratch unless checking a concrete issue.
