# Positive-frame generalization: research and source record

Start: 2026-11-13 approximately 04:46 UTC. This is the second-wave subtask, separate from the parent run beginning 04:12 UTC. Classical skew-symmetric matrices first, then integral skew-symmetrizable matrices. No quantum basis result is used.

## Route A: polar of the cluster-g cone versus the radical

Proposed hypothesis: every nonnegative vector pairing nonnegatively with every cluster g-vector belongs to ker(B). Purpose: find a negative-pairing positive function for each non-radical degree and hence extend the earlier negative-frame bound.

Exact experiment: `dual_cone_probe.py` explores equal-weight cyclic rank-three matrices with weights 2,3,4,5 through length 14. Each case has 49,150 visited extended matrices, with no state or bit pruning. It tests five specified nonnegative vectors. For weight 2 all tested nonsymmetric vectors have negative witnesses; for weights 3,4,5 several nonsymmetric vectors remain nonnegative throughout the finite search. This is not a proof of global nonnegativity. The results made the proposed radical assertion doubtful rather than supporting it.

New source found: Ryota Akagi and Zhichao Chen, *Geometric structures of G-fans associated with rank 3 cluster-cyclic exchange matrices*, arXiv:2603.16326v2, revised 8 June 2026, 59 pages. Primary source: https://arxiv.org/abs/2603.16326 and https://arxiv.org/pdf/2603.16326 . Metadata, introduction, definitions around the quadratic cone, and statements/proof structure of Theorems 4.12 and 10.11 were inspected. Version history explicitly says v2 corrects an error in Example 9.4. The uniform positive Lorentz-cone bound under its minimum assumption appears capable of proving that the radical hypothesis is false for weights greater than 2. However, the complete dependency chain of this 2026 result was not re-proved here; it is **not an accepted theorem input** and no claimed counterexample is based on it. It is recorded as a useful lead only.

Related source discovered but not used: Akagi and Chen, *Fractal phenomenon in c- and g-vectors of the Markov quiver*, arXiv:2605.10072. Only abstract-level scope was inspected; no general-rank theorem was taken from it.

Route A was superseded rather than pursued into an exclusion project. The endpoint argument below handles the lack of negative witnesses directly, without requiring the proposed polar/radical statement.

## Route B: endpoint positivity and a finite sign signature

The new argument compares two actual normalized transports with identical lower jets. Their lowest difference is a single Hamiltonian derivation per degree. Cluster variables of the two endpoint seeds give inequalities with opposite signs. Therefore a nonzero difference forces the endpoint g-cones to lie on opposite sides of that degree's hyperplane.

This yields an unconditional finite-signature theorem for arbitrary integral skew-symmetrizable B, explicit hyperplane-arrangement cardinality bounds, a bounded abstract generator word, and explicit integer matrix bounds. Complete proof: `FINITE_SIGNATURE_THEOREM.md`. It uses standard principal-coefficient normalization, tropical duality, and classical Laurent positivity; it does not invoke a scattering diagram, broken line, or geometric representation in the construction or proof.

Independent exact computation: 66 inputs of ranks 1-5, including 15 nonconstant symmetrizers, 467,512 seeds, 480,781 transitions, no pruning. Equal signatures always had equal H jets. Zero signatures and disconnected matrices were included. Detailed counts are in the main proof and `signature_transport_validation.json`.

Independent computation plugin: Wolfram symbolically verified [E_p,E_q]=(p^TDBq)E_{p+q} with B=D^{-1}S and a generic symbolic rank-three skew-symmetric S. The output difference was exactly zero; source code retained as `.wl`. Wolfram's preliminary semantic search had no useful mathematical result and is not cited as a proof.

Novelty search: targeted primary-source searches for truncated F-polynomials, bounded coefficient transports, and hyperplane-sign determination did not locate a matching elementary endpoint proof. This limited search is not a priority claim. Finite-order constructions in scattering theory already provide nearby structural information; the substantive point here is the independent positivity-and-integer-transport argument and its use in the ongoing combinatorial construction.

## Route C: exact endpoint cuts and local frames

The higher-degree-cut agent independently identified the at-most-two strengthening. Above fixed proper coordinatewise lower data, at most two actual top scalar values occur. A single endpoint seed with nonnegative or nonpositive g-pairings certifies the appropriate extremum; a mixed endpoint certifies uniqueness. Complete statements and proofs: `ENDPOINT_CUT_CERTIFICATES.md`.

The parent proposed using a known positive product with the target label rather than a globally negative frame. The resulting recession lemma was proved: if the target g lies in the nonnegative span of finitely many known positive-function labels, their coefficient inequalities bound the target affine objective below. This gives finite valid lower bounds but does not imply that the outer LP is sharp.

Remaining gap: determining a finite family of genuine-path coefficient cuts that dominates every actual-path cut, or proving that a computable outer set has no stronger cuts. The bounded abstract alphabet alone is not sufficient: nonrealizable words may impose false constraints.

## Route D: proposed short-word bound

The parent reported large computations suggesting that genuine words of length 2N-1 may suffice for degree-N positivity cuts, although entire transport sets can require longer words. The current endpoint lemmas do not prove that bound. Inactive excursions remain the central issue: identity action on a coefficient quotient does not justify deletion from the seed evolution.

Literature searches for c-vector height versus mutation distance, short mutation realizations, denominator-distance bounds, and brick composition length did not produce a verified general theorem adequate for this step. Relevant but unused primary leads include arXiv:2410.08510 (quadratic equations for c-vectors along fork-preserving paths), arXiv:1803.02341 (gradings and mutation-cyclic matrices), and arXiv:1612.05387 (cluster distance in Grassmannian settings). These have restricted scopes and were not promoted to an arbitrary-rank length theorem. No new proof of the 2N-1 claim is asserted.

## Additional recent-source lead, not used

Qiyue Tang, *Positive polytopes and the full Fock-Goncharov conjecture*, Hexagon2611.00015v1, 2 November 2026, https://hexagonmath.org/pdf/2611.00015v1 . The abstract and opening scope were inspected during the novelty search. Its criterion assumes a bounded positive polytope with the origin in its interior and its proof uses scattering/broken-line input. It is not a finite cluster-only coefficient algorithm, and no theorem from it is used here. Full correctness review was not attempted because it is not needed for the endpoint mechanism.
