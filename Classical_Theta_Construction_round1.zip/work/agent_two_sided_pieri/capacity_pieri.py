"""Finite candidate recursion with both lowering and one-step creation.

Every higher-rank result remains a candidate.  Capacity keys are justified
by freezing inactive coordinates, not by treating old candidates as theta.
"""
from pathlib import Path
import sys,json,time,math
from itertools import product
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agent_interior'))
from pieri_recursive import *
from capped_interval import caps


class CapacityPieri:
    def __init__(self,B,directory,creation=True,pair_caps=True):
        self.B=tuple(map(tuple,B));self.n=len(B)
        self.A=[[max(-B[i][j],0) for j in range(self.n)] for i in range(self.n)]
        self.directory=Path(directory);self.directory.mkdir(parents=True,exist_ok=True)
        self.cache={};self.records={};self.active=set();self.creation=creation
        self.pair_caps=pair_caps;self.start=time.time();self.full_count=0
        for file in self.directory.glob('d_*.json'):
            r=json.loads(file.read_text())
            if r.get('F') is not None:
                d=tuple(r['d']);self.cache[d]={tuple(z['p']):int(z['a']) for z in r['F']};self.records[d]=r

    def label(self,d):
        return tuple(-d[i]+sum(self.A[i][j]*d[j] for j in range(self.n)) for i in range(self.n))

    def save(self,d,F,r):
        r.update(B=self.B,d=d,g=self.label(d),F=[{'p':p,'a':a} for p,a in sorted(F.items())])
        self.cache[d]=F;self.records[d]=r
        (self.directory/('d_'+'_'.join(map(str,d))+'.json')).write_text(json.dumps(r,separators=(',',':')))
        return F

    def get(self,d):
        d=tuple(d)
        if d in self.cache:return self.cache[d]
        if d in self.active:raise ArithmeticError('capacity recursion cycle')
        self.active.add(d);tic=time.time();g=self.label(d)
        act=[i for i,a in enumerate(d) if a]
        if len(act)<=2:
            if not act:F={(0,)*self.n:1}
            elif len(act)==1:
                i=act[0];F={tuple(t if j==i else 0 for j in range(self.n)):math.comb(d[i],t) for t in range(d[i]+1)}
            else:
                i,j=act
                H,_=llz_F(self.B[i][j],-self.B[j][i],(g[i],g[j]))
                F={tuple(p[act.index(k)] if k in act else 0 for k in range(self.n)):a for p,a in H.items()}
            self.active.remove(d)
            return self.save(d,F,{'status':'exact_lower_rank_base','mass':sum(F.values())})
        points=sorted(product(*(range(a+1) for a in d)),key=lambda p:(sum(p),p))
        ids={p:i for i,p in enumerate(points)};origin=ids[(0,)*self.n]
        ineq=[];zero=[];deps=set();groups=[]

        # Positivity of x_i F in all smaller capacity objects.
        for i in act:
            remainder={p:{ids[p]:1} for p in points};count=0
            for q in points:
                row=remainder.pop(q,{})
                h=tuple(g[k]+(k==i)+sum(self.B[k][j]*q[j] for j in range(self.n)) for k in range(self.n))
                dh=tuple(acyclic_dimension(self.B,h)[0])
                okay=all(q[k]+dh[k]<=d[k] for k in range(self.n)) and sum(dh)<sum(d)
                if okay:
                    H=self.get(dh);deps.add(dh);count+=1
                    if row:ineq.append(row)
                    for p,a in H.items():
                        if not any(p):continue
                        r=tuple(q[k]+p[k] for k in range(self.n))
                        remainder[r]=addrow(remainder.get(r,{}),row,-a)
                elif row:zero.append(row)
            groups.append({'kind':'lowering','direction':i,'roots':count})

        # Simultaneous affine expressions c_q for M-F in the lower basis.
        ell_min_nonnegative=True
        if self.creation:
            std={p:math.prod(math.comb(d[k],p[k]) for k in range(self.n)) for p in points}
            rem={p:addrow({origin:std[p]},{ids[p]:1},-1) for p in points}
            creators=[]
            for i in act:
                dd=tuple(d[j]-(j==i) for j in range(self.n))
                H=self.get(dd);deps.add(dd);P=dict(H)
                for p,a in H.items():
                    q=tuple(p[j]+(j==i) for j in range(self.n));P[q]=P.get(q,0)+a
                creators.append({p:std[p]-P.get(p,0) for p in points})
            count=0
            for q in points:
                row=rem.pop(q,{})
                numeric=[z.pop(q,0) for z in creators]
                if not any(q):
                    assert not row and not any(numeric);continue
                h=tuple(g[k]+sum(self.B[k][j]*q[j] for j in range(self.n)) for k in range(self.n))
                dh=tuple(acyclic_dimension(self.B,h)[0])
                okay=all(q[k]+dh[k]<=d[k] for k in range(self.n)) and sum(dh)<sum(d)
                if okay:
                    H=self.get(dh);deps.add(dh);count+=1
                    ell=max(numeric)
                    if min(numeric)<0:ell_min_nonnegative=False
                    upperrow=addrow(row,{origin:1},-ell)
                    if upperrow:ineq.append(upperrow)
                    for p,a in H.items():
                        if not any(p):continue
                        r=tuple(q[k]+p[k] for k in range(self.n))
                        rem[r]=addrow(rem.get(r,{}),row,-a)
                        for z,c in zip(creators,numeric):z[r]=z.get(r,0)-c*a
                else:
                    if row:zero.append(row)
                    if any(numeric):raise ArithmeticError(('creation remainder not in lower Laurent span',d,q,numeric))
            groups.append({'kind':'creation','roots':count,'all_M_minus_P_lower_positive':ell_min_nonnegative})

        if self.pair_caps:
            upper=caps(self.B,g,d,points)
            for p,u in upper.items():
                row=addrow({origin:u},{ids[p]:1},-1)
                if row:ineq.append(row)

        F,solve=solve_coefficients(points,ineq,zero,time_limit=60)
        if F is None:raise RuntimeError(('two-sided construction failed',d,solve))
        ok,error=all_neighbors(self.B,g,F)
        if not ok:raise ArithmeticError(('candidate not star-positive',d,error))
        C=hull_carrier(self.B,g,d,F);P=set(map(tuple,C['lattice_points']))
        if any(p not in P for p in F):
            F,solve2=solve_coefficients(points,ineq,zero,allowed=P,time_limit=60)
            if F is None:raise RuntimeError(('exact carrier infeasible',d,solve2))
            solve['exact_carrier_resolve']=solve2
        self.active.remove(d);self.full_count+=1
        r={'status':'two_sided_Pieri_candidate','comparison_status':'not identified with theta',
           'mass':sum(F.values()),'solve':solve,'carrier':C,'groups':groups,
           'dependencies':[list(x) for x in sorted(deps)],'seconds':time.time()-tic}
        self.save(d,F,r)
        print('TWO_SIDED',d,'mass',r['mass'],'full',self.full_count,'cache',len(self.cache),
              'status',solve['status'],'unique',solve.get('dual',{}).get('unique_optimum'),
              'seconds',round(time.time()-tic,3),flush=True)
        return F


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--case',default='dense222');args=ap.parse_args()
    if args.case=='dense222':B=[[0,2,2],[-2,0,2],[-2,-2,0]];d=(7,6,9)
    elif args.case=='dense211':B=[[0,2,1],[-2,0,1],[-1,-1,0]];d=(8,7,9)
    elif args.case=='fork':B=[[0,0,3],[0,0,2],[-3,-2,0]];d=(8,7,9)
    else:raise ValueError(args.case)
    C=CapacityPieri(B,Path(__file__).parent/('capacity_cache_'+args.case))
    F=C.get(d)
    print('DONE',args.case,'mass',sum(F.values()),'records',len(C.cache),'seconds',time.time()-C.start,flush=True)
