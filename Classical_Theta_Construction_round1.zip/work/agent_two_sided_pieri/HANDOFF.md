# Fresh handoff: full Pieri leastness and zero-inventory diamonds

2026-11-13 about08:48 UTC. This child turn began08:03. No live computation
needs preserving. Root continues the six-hour task until10:12:08 UTC.

## Immediate next task

Use the newly found smaller **general mechanism failure**:

    B_ij=1 for i<j, B_ij=-1 for i>j (complete rank-four graph),
    d=(4,5,5,6), g=-d+[-B]_+ d.

Its Cartan product is (-8,-5,-5,-2), so fundamental-region normalization
does not repair the issue. Pure graph caps plus star and pair lower
positivity have dimension47 and exact mass minimum1829, but no
coefficientwise least point: a_(3,2,2,1) can drop6 to2.
Inputs/results are in the sibling directory:

    work/agent_creation_caps/fundamental_input_6.json
    work/agent_creation_caps/fundamental_results_6_8.json

Do two things, with no unannounced fallback to an arbitrary mass selector:

1. Recursively impose **full smaller-basis initial lowering plus one-step
   creation**. At every capacity prove coefficientwise leastness exactly.
   If it fails, stop and save the first such lower capacity and an exact
   tradeoff certificate. Do not commit a chosen mass minimum as a basis.
2. At every layer compute the **zero-inventory diamond equations** below.
   Measure their exact rank against the unknown affine coefficient space.
   Determine whether they already force the candidate or leave a genuine
   positive-resource exchange problem. This is the next general mechanism
   question; the input is a diagnostic, not a special-case objective.

This smaller full box has1260 capacities; the earlier rank-four target
d=(21,7,9,2) has5280. The existing unoptimized code is not safely a
10–20-minute complete run with exact leastness added. The dense rank-three
560-capacity run took35.5s for mass selection only; the sum of all box sizes
for the larger target is about54 times larger, before exact leastness
certificates. Use the smaller K4 input, strict |d|-order, early stop, support
pruning, and sparse/direct creation remainders instead of materializing
the full standard-product box whenever practical.

## Main new general mechanism

Read `PIERI_DIAMOND_ZERO_INVENTORY.md` first. For creator
P_i=x_i' b_(g-a_i), smaller origin-zero frame H_q, and active lowering x_j,

    P_i-F = sum c_q H_q,
    b=[x_j F], M=[x_j H_q], a=[x_j P_i],
    b+Mc=a.

All a and M are constructed entirely in strictly smaller capacities.
For i≠j commute x_j past x_i': lowering first drops the lower input to
at most |d|-2, then creation raises by at most1. For i=j use the exchange
relation. With correct lower data, a,M,b,c are nonnegative integers.

If a_r=0, then b_r=0 and c_q=0 for every M_(r,q)>0. An isolated entry1
gives exactly opposite upper/lower inequalities and forces an equality.

**Index convention for the diagonal claim:**

    H_q=y^q b_(g+Bq),
    K_r=y^r b_(g+e_j+Br).

For multiplication by the initial variable x_j (not a derivative or
marking operator), pointed leading monomials give M_(q,q)=1 and
M_(r,q)=0 unless r>=q coordinatewise. These are frozen-root coordinates;
there is no q_j multiplicity. Every K_q exists below d since multiplication
by an initial variable never increases intrinsic capacity. Marks and
derivatives have different diagonal factors and are not included in this
unit-diagonal assertion.

The positive-resource exchange/least theorem remains open. Triangularity
and zero-row coverage alone do not prove it. In fact individual positive
H-column coverage by an active zero row is automatic at a positive mass
minimum; mixed signed H-directions are the real difficulty.

## Other proved general statements

`CAPACITY_PRODUCTS_AND_GRAPH_CAPS.md` proves:

- Capacity invariance F_(v+g_d)=F_d by freezing inactive coordinates.
- All canonical capacity splits F_e F_f-F_(e+f) have a positive smaller
  expansion for the true basis.
- For a capacity-indexed pointed basis, positivity of **all** proper
  capacity splits and initial-variable lowering implies full strong
  positivity: b_gb_h=x^(v+w)(b_(g_e)b_(g_f)). This does not prove a locally
  chosen lower family extends or is theta.
- Arbitrary products of genuine rank-at-most-two capacity blocks are
  dominated by one actual graph-edge allocation product. Merge repeated
  edge blocks by rank-two strong positivity, split nonedges, and absorb
  singletons. Count≤product_i binom(d_i+deg_i-1,deg_i-1).

`SINGLE_STEP_CREATION_AND_PACKING.md` proves mixed creation redundancy
once the smaller positive products are established. Do not enumerate all
mixed binomial creation powers. General capacity split products are
stronger and not covered by that redundancy.

## Existing recursive code

`capacity_pieri.py` contains `CapacityPieri(B,directory)`:

- Base active rank≤2 is exact LLZ.
- Uses all smaller-basis x_i lowering coordinates, all one-step creation
  coordinates, true pair upper caps, and exact Newton carrier.
- **Currently chooses a minimum-mass integer point and does not certify
  coefficientwise leastness. Must be strengthened before a fresh run.**
- It stores selected candidates explicitly as candidates, never theta.
- It was written assuming a topological ordering for the two-active-node
  LLZ base. Reorient that pair if using an arbitrarily relabeled B.

`capacity_product_check.py` provides exact triangular `lower_expand` and
`check_top`. The complete dense222 family0≤d≤(7,6,9) has560 capacities;
all27,200 unordered splits passed exact positive expansion. This finite
internal-coherence test does not prove theta identification or extension.

## Lazy graph-selected lower probing API

`graph_lower_probe.py`:

    GraphCache(B,name).get(d)
    expand(C,g,F,box,zero_allowed=False,stop_negative=True)
    probe(case,cache_name,output,overrides=())

Each requested smaller capacity is selected independently by the pure
graph algorithm. Its full exact status/certificate is retained. Some
have no least point, so these are diagnostic candidates only. `probe`
tests all active xi lowering and one-step creation; `overrides` changes
the in-memory entries without corrupting the original cache records.

`symbolic_creation.py` exports exact affine rows in the `build_logic`
parameter basis. `root_bound` restricts to a coordinatewise downset,
which is exact for every returned coefficient. `symbolic_lowering.py`
does the same for xi lowering. These are useful for a finite diamond
prefix without building all capacities.

## Rank-four target: what happened and what is actually valid

The larger target is

    B=((0,0,-3,-1),(0,0,2,0),(3,-2,0,0),(1,0,0,0)),
    g=(8,-7,5,-2), d=(21,7,9,2).

Pure graph exact massmin15151164 has no coefficientwise least property.
Transporting the source candidate gives mass15151380. With the initially
chosen graph lower table, creation1 seemed to exclude both, with-9/-18
at rootq=(2,3,2,2), lowercapacity(3,3,1,0). Its apparent row was

    a_(8,6,4,2)-a_(5,6,3,2)+33>=0.

**That row was conditional and wrong as a theta constraint.** The smaller
creator d=(21,6,9,2) was itself missing a legitimate neighboring-seed
rank-two lower constraint. In the source orientation the wrong polynomial
is deficient by the true rank-two positive summand

    18 z^(6,3,2,2) [(1+z1)^2+z1^2 z2].

Exactly one source pair coordinate is-18: pair(1,2), outside(0,3)=(6,2),
root(3,2), label(-2,3); every source star quotient is nonnegative.
The creation-cap sibling repaired it by actual neighboring-seed rows:

    creator(21,6,9,2) mass14900652→14900868,
    work/agent_creation_caps/creator_neighbor_repair_results.json.

This changes the target creation constant33→51. A second creator,
d=(21,7,9,1), had no least point in its graph cone. I repaired it with the
same valid neighboring-seed family:

    mass10090704→10090920, exactleast,
    creator3_neighbor_repair_results.json.

With both repairs, target lowering3 at q gives

    a_(5,6,3,2)-a_(8,6,4,2)-51>=0.

It is exactly the negative of the corrected creation1 row. Independent
source-pair positivity gives the same lower row, so this particular row
has a valid proof apart from any unproved whole lower table.

Exact direct computation confirms the diamond:

    [x3 P1]_q=0;
    the relevant row of M3 has only M_(q,q)=1.

Files: `pieri_diamond_identity.json`,
`graph_target_lowering3_symbolic.json`,
`graph_target_two_corrected_massmin_pieri.json`,
`graph_target_two_corrected_transported_pieri.json`.

The massmin fails corrected lowering3 by-9. The transported candidate
passes all eight tested directions. This still does not establish all
capacity-split positivity, a full coherent lower table, or theta identity.

## Literature and record keeping

`RESEARCH_LOG.md` records every success/failure above, including the invalid
initial cache-derived row and its correction. Fresh literature during
this turn revisited Mandel's scattering-atlas distinction and the already
audited2026 Lusztig note; no new2026 conclusion was imported. Root handles
Library persistence and final ZIP. Do not duplicate storage or user-facing
packaging in this child task.
