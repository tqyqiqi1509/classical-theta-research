# Capacity products, strong positivity, and finite graph caps

2026-11-13. Classical acyclic skew-symmetrizable cluster algebras with
principal coefficients. This note separates proved structural statements
from the still open least-element and extension questions.

Let B be in a topological order, A=[-B]_+, and put

\[
g_d=-d+Ad,\qquad d\in\mathbb N^n.
\]

Every label has the unique standard decomposition

\[
g=v+g_d,\qquad v,d\ge0,\quad v_i d_i=0.
\]

The preceding root notes establish the finite standard box [0,d], the
smaller-box positive slice theorem, and the creation theorem. Those
theorems are comparison tools here; none of the computed higher-rank
candidate tables is identified with theta.

## 1. Capacity invariance

**Proposition.** The acyclic theta F-polynomial at g=v+g_d is independent
of v. It equals the F-polynomial at g_d.

**Proof.** Set I={i:d_i>0}. The standard box forces every monomial of F_g
to have zero exponent in each coordinate outside I. Freeze the complement
of I. The established freezing identity identifies the remaining
polynomial with the theta polynomial of B_II at the restricted label g_I.
For i in I, v_i=0 and d_j=0 for j outside I. Consequently

\[
g_I=-d_I+A_{II}d_I,
\]

which is independent of v. The same freezing computation applies to
g_d. This proves the assertion. The rank-two blocks below therefore use
ordinary LLZ polynomials at canonical capacity labels, embedded in the
full set of variables.

The statement has an elementary Laurent-space analogue. In an inactive
direction i, the smallest x_i exponent is at least v_i>=0, so adding v_i
does not introduce a binomial divisibility constraint. On active
directions the labels do not change.

## 2. Every capacity split gives a positive upper product

**Proposition.** If d=e+f, then

\[
F_eF_f-F_d
 =\sum_{q>0}c_qz^qF_{d(g_d+Bq)},\qquad c_q\in\mathbb N,
\]

and every term satisfies q+d(g_d+Bq)<=d coordinatewise. In particular,
every polynomial on the right has strictly smaller intrinsic capacity
sum than |d|.

**Proof.** The canonical labels add: g_e+g_f=g_d. Apply strong positivity
to the two genuine theta elements. Their product has leading monomial
x^(g_d), with coefficient one, so the q=0 theta summand is theta_(g_d)
with coefficient one. Every remaining frozen root is q>0. Positivity and
the standard boxes of the two factors put the entire product in [0,e+f].
The established box lower-bound lemma then gives q+d(g_d+Bq)<=d.

For comparison with one-step creation, a split with e=e_i has
F_e=1+z_i. General e gives genuinely new products: F_e is usually smaller
than the standard binomial product associated with e. Thus the earlier
redundancy of mixed creation does not make arbitrary capacity splits
redundant.

## 3. Finite recursive characterization of strong positivity

Consider a capacity-indexed family F_d with integer coefficients and
constant term one, and define

\[
b_{v+g_d}=x^{v+g_d}F_d(z),\qquad v_i d_i=0.
\]

Assume these elements form the intended pointed Laurent basis. This is
an algebraic basis premise, not a conclusion of positivity tests.

Suppose the following two kinds of identities hold for every d:

1. For every active i, x_i b_(g_d) has a nonnegative expansion in the
   basis, with every resulting capacity strictly smaller than d in total
   size and coordinatewise bounded by d after its frozen shift.
2. For every nontrivial d=e+f, the product b_(g_e)b_(g_f) has leading term
   b_(g_d), and its remainder has a nonnegative expansion in the strictly
   smaller shifted basis elements in [0,d].

**Theorem.** These two conditions are sufficient for all basis products
to have nonnegative integer structure constants. Conversely, a strongly
positive capacity-indexed basis with these box properties satisfies both
conditions.

**Proof of sufficiency.** First all initial variables act positively. For
an inactive coordinate, multiplying by x_i merely raises v_i. For an
active coordinate, use condition 1. Multiplication of that identity by
x^v preserves its coefficients and simply translates each lower label:
where v_i>0 the original d_i is zero, and all lower capacities are also
zero in that coordinate. Thus no new active direction appears in this
translation. This proves positive action of x_i at every basis label.
Repeated action gives positive multiplication by every initial monomial.

For arbitrary g=v+g_e and h=w+g_f, capacity invariance gives the identity

\[
b_gb_h=x^{v+w}\bigl(b_{g_e}b_{g_f}\bigr).
\]

Condition 2 expands the parenthesized product positively. The positive
initial-monomial action just proved expands each resulting term
positively. This is the desired strong positivity. If one of e,f is
zero, the product is already an initial-monomial action. Necessity is
immediate from strong positivity and the assumed leading/box properties.

### Why this is a finite inductive interface

For fixed d there are finitely many proper splits e+f=d. Both inputs have
smaller total capacity, and every nonleading output has smaller total
capacity. The conditions at d are therefore finitely many linear
inequalities in the unknown coefficients of F_d, once the earlier levels
have been constructed. The same holds for lowering.

This theorem does not show that an arbitrary feasible choice at one level
extends to all higher levels, does not prove coefficientwise leastness,
and does not identify a candidate family with theta. Existence of the
theta family alone is not an explicit finite rule for choosing an
infinitely extendible branch. A valid construction still needs an
exchange/least theorem or another deterministic selector with a proof.

## 4. True rank-two product caps indexed by finite graph allocations

Let G be the underlying simple undirected graph of B: {i,j} is an edge
exactly when B_ij is nonzero. For each nonisolated vertex i, distribute its
capacity among incident edges:

\[
d_i=\sum_{e\ni i}d_{i,e},\qquad d_{i,e}\in\mathbb N.
\]

Let d^e have coordinates d_(i,e), d_(j,e) at the endpoints of e and zero
elsewhere. For an isolated vertex retain its singleton capacity. Define

\[
P_{\mathcal A}(z)=
 \prod_{e=\{i,j\}\in E(G)}F^{\mathrm{LLZ},B_{\{i,j\}}}_{d^e}(z_i,z_j)
 \prod_{i\text{ isolated}}(1+z_i)^{d_i}.
\]

Every factor is supplied by the genuine rank-one or rank-two integer
recursion. The full polynomial is therefore computable by finite
convolution of Dyck compatible-pair counting polynomials.

**Graph-cap theorem.** Every P_A contains the target theta polynomial F_d
with coefficient one and a nonnegative expansion in strictly smaller
shifted theta polynomials. Moreover these graph-allocation products
dominate, in the useful direction, the entire family of products over
arbitrary capacity partitions into blocks of support at most two: for
each such product Q there is a graph allocation A with

\[
Q-P_{\mathcal A}\in\mathbb N\text{-span of shifted smaller theta elements}.
\]

In particular P_A<=Q coefficientwise.

**Proof.** The first claim follows by repeated application of the
capacity-split product proposition: the canonical labels of all factors
add to g_d, their constant terms are one, and their standard boxes add to
[0,d].

For the domination claim, a two-vertex block on a nonedge is disconnected,
so its polynomial is exactly the product of the two singleton binomial
polynomials. Split every such block. At a fixed edge merge all its blocks:
the rank-two capacity-split identity gives

\[
F_aF_b-F_{a+b}\ge0
\]

both coefficientwise and in the true rank-two theta cone. Embedding and
multiplying by the remaining true positive factors preserves positivity.
Finally, absorb each singleton at a nonisolated vertex into any incident
edge block; the same rank-two inequality applies, including when the
other endpoint currently has zero capacity. Singleton factors at isolated
vertices remain. This finite process yields exactly one block per edge,
allowing zero blocks, and proves the stated comparison.

There are at most

\[
\prod_{i:\deg(i)>0}\binom{d_i+\deg(i)-1}{\deg(i)-1}
\]

allocations. This counts weak compositions at each vertex; different
allocations can yield the same polynomial, so it is an upper bound on
distinct caps. No unknown higher-rank candidate is used in any cap.

### Consequence for the finite packing coordinates

Using the smaller-basis coordinates F=M-sum_q c_q H_q from
`SINGLE_STEP_CREATION_AND_PACKING.md`, each graph cap P_A supplies the
coordinate floor c_q>=ell_(A,q), where M-P_A=sum_q ell_(A,q)H_q. Raw
coefficient caps remain valid even before the higher-rank smaller basis
is certified. Their combination with the pair lower inventories is
substantially stronger than either type alone in the computations below.

## 5. Computation of a complete bounded capacity family

The matrix

\[
B=\begin{pmatrix}0&2&2\\-2&0&2\\-2&-2&0\end{pmatrix}
\]

was used to test the general recursive interface on every capacity
0<=d<=(7,6,9). The code `capacity_pieri.py` chooses an integer minimum-mass
candidate using full smaller-basis lowering, one-step creation, true
rank-two deletion caps, and the exact Newton carrier. It labels every
higher-rank output a candidate. Rank at most two is the genuine LLZ base.

The initial top computation built 558 records in 35.46 seconds. Completing
the rectangular capacity set gives 560 capacities. Across this entire
downset, all 27,200 nontrivial unordered splits passed exact lower-basis
expansion with no negative structure constant, in 15.83 seconds. Every
M-P_i also had nonnegative lower-basis coordinates. The top mass is 3160.

This is finite internal coherence of a candidate family. It neither
certifies an infinite extension nor identifies any rank-three entry with
theta. The complete compact verification record is
`all_capacity_products_dense222.json`.

## 6. The outstanding combinatorial exchange question

The graph-cap products are explicit compatible-pair inventories. The pair
lower conditions express each coordinate section as a nonnegative
integer combination of LLZ inventories. A sought construction must glue
these inventories into a common finite collection, with multiplicities
independent of the order in which pair constraints are imposed.

The necessary statement is stronger than finiteness or positivity of the
individual inventories: simultaneous lower inventories and graph upper
capacities must admit a coefficientwise least integral common inventory,
and its selection must be compatible with the capacity-split and lowering
identities. General nonnegative packing systems lack this property. No
generic flow or discrete-concavity theorem is being asserted for these
specific Laurent matrices without a proof of its hypotheses.

**Later exact correction.** The creation-cap branch has now found a
rank-four counterexample to leastness for the graph caps combined only
with initial-star and initial rank-two lower positivity. Thus that
particular proposed gluing theorem is false as stated. The graph-cap
theorem itself remains valid. Full capacity-split and lowering relations
are stronger information and remain a possible interface, but the lazy
tests below demonstrate why their lower inputs must be independently
justified or constructed with proved coherence.

## 7. Conditional Pieri failures can come from a wrong smaller selection

At the new rank-four target with

\[
B=\begin{pmatrix}
0&0&-3&-1\\0&0&2&0\\3&-2&0&0\\1&0&0&0
\end{pmatrix},\quad g=(8,-7,5,-2),\quad d=(21,7,9,2),
\]

the pure graph selector has exact minimum mass15151164, whereas a
transported source candidate has mass15151380. Neither is called theta.
Using independently selected smaller graph candidates, their creation
remainders in direction1 initially give coefficients-9 and-18 at root
q=(2,3,2,2). The symbolic row is

\[
a_{(8,6,4,2)}-a_{(5,6,3,2)}+33\ge0.
\]

This is only a condition relative to that selected smaller family. The
smaller creator at capacity(21,6,9,2) itself violates a legitimate
rank-two lower condition after a source/sink mutation. Repairing that
node changes the constant33 to51; the apparent violations become+9 and0.
Thus the old negative signs cannot be promoted to necessary theta
inequalities. Both the failed and repaired records are retained.

The smaller error has a compact exact certificate. In the opposite
orientation the independently selected source polynomial exceeds the
transported target one by

\[
18z^{(6,3,2,2)}\bigl((1+z_1)^2+z_1^2z_2\bigr).
\]

The factor in parentheses is a genuine rank-two LLZ polynomial. The
transported target polynomial has exactly one negative rank-two section
coordinate there: pair(1,2), outside exponents(6,2), root(3,2), label(-2,3),
value-18. Its initial-star quotients are nevertheless all nonnegative.

After the creator repair, the target mass selector passes all four
lowering and all four one-step creation tests against the updated finite
lower table. It still fails the independently valid neighboring-seed
constraints. These observations neither refute the full infinite Pieri
criterion nor identify any candidate with theta: they exhibit the exact
danger of assuming that a locally selected lower table is already a
coherent basis.

## 8. Why individual zero-row coverage does not prove leastness

Suppose a finite feasible set has the packing form established in the
earlier note, and F minimizes a strictly positive sum of its coefficient
coordinates. Let H be a nonzero coefficientwise nonnegative origin-zero
direction in its Laurent carrier. If decreasing F by a small epsilon H
makes every upper-creation condition weaker and all active lower rows
vanish on H, then the finitely many inactive lower inequalities remain
satisfied for sufficiently small epsilon. The mass strictly decreases,
a contradiction. If H leaves the coefficient carrier, a zero coefficient
outside the carrier already blocks the subtraction.

Hence coverage of every individual positive H by some active zero row is
automatic at an exact mass minimum under these hypotheses. It can hold
even where no coefficientwise least feasible point exists. The actual
exchange problem concerns mixed signed combinations of H-directions. In
linear dual language, all coordinate functionals must lie in the
nonnegative cone of the active constraints, rather than each H-column
merely being seen by one row. This distinction rules out another tempting
but insufficient route to a general leastness proof.
