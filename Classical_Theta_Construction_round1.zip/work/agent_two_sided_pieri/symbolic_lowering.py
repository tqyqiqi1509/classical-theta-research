"""Exact lowering rows for a finite coefficient prefix."""
from symbolic_creation import *


def lowering_rows(C,B,g,d,source,direction,root_bound):
    n=len(g);width=len(next(iter(source.values())));zero=(0,)*width
    gg=tuple(g[j]+(j==direction) for j in range(n))
    inside=lambda p:all(p[i]<=root_bound[i] for i in range(n))
    rem={p:row for p,row in source.items() if inside(p) and any(row)};rows=[]
    while rem:
        q=min(rem,key=lambda p:(sum(p),p));row=rem.pop(q)
        h=tuple(gg[k]+sum(B[k][j]*q[j] for j in range(n)) for k in range(n))
        dh=tuple(acyclic_dimension(B,h)[0])
        if not all(q[k]+dh[k]<=d[k] for k in range(n)) or sum(dh)>=sum(d):
            raise ArithmeticError(('outside smaller Laurent span',q,dh,row))
        rows.append({'root':q,'capacity':dh,'row':[str(a) for a in row]})
        F=C.get(dh)
        for p,a in F.items():
            if not any(p):continue
            s=tuple(q[k]+p[k] for k in range(n))
            if not inside(s):continue
            rr=tuple(b-a*c for b,c in zip(rem.get(s,zero),row))
            if any(rr):rem[s]=rr
            elif s in rem:del rem[s]
    return rows


if __name__=='__main__':
    case=json.loads((WORK/'agent_creation_caps/graph_transport_current_input.json').read_text())
    B,g,d=case['B'],case['g'],case['d'];M,R,S=build_logic(B,g,case['carrier'])[:3]
    origin=R[M['ids'][(0,)*len(g)]];source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    C=GraphCache(B,'graph_target_lower_cache')
    for name in [WORK/'agent_creation_caps/creator_neighbor_repair_results.json',HERE/'creator3_neighbor_repair_results.json']:
        rr=json.loads(name.read_text());dd=tuple(rr['d']);C.cache[dd]=exact_poly(rr['F']);C.records[dd]=rr
    rows=lowering_rows(C,B,g,d,source,3,root_bound=(2,3,2,2))
    target=next(r for r in rows if r['root']==(2,3,2,2))
    out={'B':B,'g':g,'d':d,'parameter_dimension':len(origin),'direction':3,
         'root_bound':(2,3,2,2),'target_row':target,'rows':rows,
         'comparison_status':'candidate lower basis with two independently valid neighboring-seed repairs'}
    atomic(HERE/'graph_target_lowering3_symbolic.json',out)
    print('DONE',len(rows),'target',target,flush=True)
