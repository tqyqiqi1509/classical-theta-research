"""Independent graph selection before/after mutation of a creator capacity."""
from graph_lower_probe import *
sys.path.insert(0,str(WORK/'agent_polytope'))
from normalized_fibers import mutate


if __name__=='__main__':
    targetB=[[0,0,-3,-1],[0,0,2,0],[3,-2,0,0],[1,0,0,0]]
    target=GraphCache(targetB,'graph_target_lower_cache');d=(21,6,9,2)
    F=target.get(d);g=target.label(d)
    state,err=mutate(targetB,g,F,0)
    if err:raise ArithmeticError(err)
    B2,g2,G=state;dd=tuple(acyclic_dimension(B2,g2)[0])
    source=GraphCache(B2,'graph_source_lower_cache');H=source.get(dd)
    deltas=[{'p':p,'transport':str(G.get(p,0)),'independent':str(H.get(p,0)),
             'delta':str(G.get(p,0)-H.get(p,0))}
            for p in sorted(set(G)|set(H)) if G.get(p,0)!=H.get(p,0)]
    result={'target_B':targetB,'target_g':g,'target_d':d,
            'source_B':B2,'source_g':g2,'source_d':dd,
            'target_status':target.records[d]['status'],'source_status':source.records[dd]['status'],
            'equal':G==H,'transport_mass':str(sum(G.values())),
            'independent_mass':str(sum(H.values())),'differences':deltas}
    atomic(HERE/'creator_transport_results.json',result)
    print('TRANSPORT',result,flush=True)
    r=source.records[dd]
    back,err=mutate(B2,g2,H,0)
    if err:raise ArithmeticError(err)
    _,_,P=back
    atomic(HERE/'creator_source_transported_to_target.json',
           {'B':targetB,'g':g,'d':d,'F':[{'p':p,'a':str(a)} for p,a in P.items()]})
