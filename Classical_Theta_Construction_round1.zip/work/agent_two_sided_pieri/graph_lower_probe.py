"""Full smaller-basis Pieri probes for the graph-cap candidate family.

Each smaller F is selected independently by the new graph algorithm.
All outputs remain candidate relations; exact lower statuses are retained.
"""
from pathlib import Path
import sys,json,time,math
from itertools import product
from fractions import Fraction
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
sys.path.insert(0,str(WORK/'agent_creation_caps'))
from cap_batch import run_case,atomic,exact_poly
from block_upper_caps import block_upper_caps,multiply
from schofield_carrier import acyclic_dimension


class GraphCache:
    def __init__(self,B,name):
        self.B=B;self.n=len(B);self.A=[[max(-b,0) for b in row] for row in B]
        self.directory=HERE/name;self.directory.mkdir(exist_ok=True)
        self.cache={};self.records={}
        for file in self.directory.glob('d_*.json'):
            r=json.loads(file.read_text());d=tuple(r['d'])
            if r.get('F'):self.cache[d]=exact_poly(r['F']);self.records[d]=r
    def label(self,d):return tuple(-d[i]+sum(self.A[i][j]*d[j] for j in range(self.n)) for i in range(self.n))
    def get(self,d):
        d=tuple(d)
        if d in self.cache:return self.cache[d]
        tic=time.time();g=self.label(d)
        points=list(product(*(range(a+1) for a in d)))
        caps,families,_=block_upper_caps(self.B,d,points,graph=True)
        P=[p for p in points if caps[p]]
        carrier={'kind':'graph_capacity_support','d':d,'vertices':[],'lattice_points':P}
        case={'B':self.B,'g':g,'d':d,'carrier':carrier,
              'precomputed_graph_caps':[{'p':p,'a':caps[p]} for p in P],
              'precomputed_graph_families':families}
        r=run_case(case,mode='graph_pair')
        if not r.get('F'):raise ArithmeticError(('graph selector failed',d,r.get('status')))
        # Retain exact certificates, omit reproducible allocation descriptions.
        r.pop('families',None);r.pop('block_families',None)
        r['comparison_status']='candidate; not theta identification'
        atomic(self.directory/('d_'+'_'.join(map(str,d))+'.json'),r)
        F=exact_poly(r['F']);self.cache[d]=F;self.records[d]=r
        print('LOWER',d,'status',r['status'],'mass',r['mass'],'points',len(P),'seconds',round(time.time()-tic,3),flush=True)
        return F


def expand(C,g,F,box,zero_allowed=False,stop_negative=True):
    remaining=dict(F);terms=[]
    while remaining:
        q=min(remaining,key=lambda p:(sum(p),p));a=remaining.pop(q)
        if not a:continue
        h=tuple(g[k]+sum(C.B[k][j]*q[j] for j in range(C.n)) for k in range(C.n))
        dh=tuple(acyclic_dimension(C.B,h)[0])
        term={'root':q,'capacity':dh,'coefficient':str(a)};terms.append(term)
        if not any(q) and not zero_allowed:raise ArithmeticError(('nonzero leading term',term))
        if not all(q[k]+dh[k]<=box[k] for k in range(C.n)) or sum(dh)>=sum(box):
            return {'status':'outside_strict_lower_span','term':term,'terms':terms}
        if a<0 and stop_negative:
            return {'status':'negative_coefficient','term':term,'terms':terms}
        H=C.get(dh)
        for p,b in H.items():
            if not any(p):continue
            s=tuple(q[k]+p[k] for k in range(C.n))
            remaining[s]=remaining.get(s,0)-a*b
            if not remaining[s]:del remaining[s]
    return {'status':'positive','terms':terms}


def probe(case,cache_name,output,overrides=()):
    B,g,d=case['B'],case['g'],tuple(case['d']);F=exact_poly(case['F'])
    C=GraphCache(B,cache_name);results=[]
    for record in overrides:
        dd=tuple(record['d']);C.cache[dd]=exact_poly(record['F']);C.records[dd]=record
    for i in range(len(B)):
        if not d[i]:continue
        gg=tuple(g[j]+(j==i) for j in range(len(B)))
        print('START lowering',i,flush=True)
        r=expand(C,gg,F,d,zero_allowed=True);r.update(kind='lowering',direction=i)
        results.append(r);atomic(output,{'B':B,'g':g,'d':d,'results':results})
        print('END lowering',i,r['status'],r.get('term'),flush=True)
        dd=tuple(d[j]-(j==i) for j in range(len(B)))
        print('START creation',i,flush=True)
        H=C.get(dd);P=dict(H)
        for p,a in H.items():
            q=tuple(p[j]+(j==i) for j in range(len(B)));P[q]=P.get(q,0)+a
        for p,a in F.items():
            P[p]=P.get(p,0)-a
            if not P[p]:del P[p]
        r=expand(C,g,P,d);r.update(kind='creation',direction=i)
        results.append(r);atomic(output,{'B':B,'g':g,'d':d,'results':results})
        print('END creation',i,r['status'],r.get('term'),flush=True)
    return results


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--transported',action='store_true');args=ap.parse_args()
    base=json.loads((WORK/'agent_creation_caps/graph_transport_current_input.json').read_text())
    if isinstance(base,list):base=base[0]
    if not args.transported:
        data=json.loads((WORK/'agent_creation_caps/graph_transport_extension_results.json').read_text())
        rs=data['results'] if isinstance(data,dict) else data
        # The exact target recomputation is nested in transport records.
        def find(obj):
            if isinstance(obj,dict):
                if obj.get('g')==[8,-7,5,-2] and obj.get('mass')=='15151164' and obj.get('F'):return obj
                for x in obj.values():
                    got=find(x)
                    if got:return got
            if isinstance(obj,list):
                for x in obj:
                    got=find(x)
                    if got:return got
            return None
        case=find(rs)
        if case is None:raise ArithmeticError('mass selector target not found')
    else:case=base
    suffix='transported' if args.transported else 'massmin'
    probe(case,'graph_target_lower_cache',HERE/f'graph_target_{suffix}_pieri.json')
