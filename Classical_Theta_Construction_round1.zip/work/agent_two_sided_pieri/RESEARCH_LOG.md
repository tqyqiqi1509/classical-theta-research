# Research log

## 2026-11-13 08:03–08:13 UTC

Read root creation theorem, positive-slice proof and prior primitive handoff. Independently derived mixed-creation redundancy by multiplying an established smaller-box positive identity. Derived finite coordinates of the entire origin-zero Laurent space using shifted smaller theta objects, and the nonnegative packing normal form. These conclusions do not assume candidate tables are theta.

Implemented capped interval propagation on original packet equations and on full affine parameter equations. Two small rank4/5 records close exactly. The hard rank3 carrier stops with five coefficient deficits and lower mass58713, so elementary interval propagation is incomplete despite exact star+pair-cap leastness. No extra brute-force mixed-r enumeration is needed after the redundancy theorem.

A fresh external search on combinatorial exchange/packing interfaces is next; no theorem about generic packing polytopes is adopted as a special Laurent-matrix theorem.

## 2026-11-13 08:13–08:27 UTC

Derived capacity invariance by freezing inactive coordinates. This reduces
the recursive cache from arbitrary labels to the finite capacity downset.
Implemented full smaller-basis lowering and one-step creation. For dense
rank-three B_ij=2 above the diagonal and d=(7,6,9), built the initial 558
records in 35.46 seconds; filling the rectangle yields 560 capacities.
All 27,200 unordered capacity-split products in this complete downset have
nonnegative expansion in the selected smaller candidate family. Every
M-P_i expansion is also nonnegative. These are conditional finite-family
coherence checks; no higher-rank entry is called theta.

Proved that arbitrary capacity-split positivity together with initial
variable lowering positivity implies full strong positivity, using
b_g=x^v b_(g_d). The converse holds with the usual box properties. This
gives finite inductive relations at each capacity, but does not prove that
arbitrary lower choices extend or that the per-level feasible set has a
least member.

Proved graph-allocation domination: every product of rank-at-most-two
capacity blocks is coefficientwise bounded below by one product with a
single block per actual graph edge. Nonedges split, repeated edge blocks
merge by genuine rank-two strong positivity, and singletons are absorbed
at incident edges. The number of allocations is bounded by the product
of weak-composition counts. Sent this to root and the creation-cap agent;
that agent implemented the full graph family.

Extended the integer interval closure to all pair inventories and all
graph caps. It still stops short: hard fork lower mass58953 with sole
missing coefficient a743 by132; dense222 lower mass3096 with two deficits
of32. Thus ordinary interval propagation, even with explicit pair
inventory variables and all affine equations, is not complete. Exact
dual combinations show the omitted information consists of coupled
positive row cancellations, not a lack of finite upper bounds.

### Literature audit during this interval

Fresh search on positivity/atomicity found the original Mandel paper,
arXiv:1605.03202, and the published abstract at Cambridge. It explicitly
distinguishes scattering-atlas atomicity from the ordinary cluster atlas;
the distinction is relevant to why full cluster positivity alone cannot
be silently substituted for coefficientwise minimality. No scattering
construction is adopted. Primary URLs:
https://arxiv.org/abs/1605.03202 and
https://www.cambridge.org/core/journals/compositio-mathematica/article/abs/theta-bases-are-atomic/D16A56D61A5BC3347F20BEABC746C2C3 .

A separate fresh 2026 search returned Lusztig arXiv:2609.01321 and Qiyue
Hexagon material already in the root audit. Official arXiv text/PDF fetch
attempts in this child turn were disabled. Local historical audit
`history/package_3/notes/LUSZTIG_2026_LITERAL_DEFINITION_AUDIT.md` was read:
real-positive cones have no additive atoms, and pointwise positivity does
not imply nonnegative canonical coefficients. No new 2026 theorem was
accepted from a mirror or search abstract; no corrected-cone atomicity
claim is used here.

## 2026-11-13 08:27–08:39 UTC

The creation-cap agent found the first genuine failure of the pure graph
cap plus initial pair-lower selector after a rank-four source mutation.
Target B has rows (0,0,-3,-1), (0,0,2,0), (3,-2,0,0), (1,0,0,0), with
g=(8,-7,5,-2) and d=(21,7,9,2). The exact mass selector has mass15151164;
the transported source candidate has mass15151380. The finite graph cone
has no coefficientwise least member at this target.

Implemented lazy independent lower-capacity selection and full
smaller-basis Pieri expansion, so only the lower objects actually needed
by each pointed subtraction are computed. Initially the graph mass
selector failed creation in direction1 with coefficient -9 at root
(2,3,2,2), capacity(3,3,1,0). The transported candidate failed there by-18
and also in creation direction3 by-9. All four lowering directions passed
against that initial selected lower table. These signs are **conditional
candidate-family coherence failures**, not theta inequalities.

Symbolic elimination in the 43-parameter target space gives the apparent
creation constraint a_(8,6,4,2)-a_(5,6,3,2)+33>=0. Its coefficient prefix
uses only15 symbolic roots. The creation-cap agent independently obtained
the same row and tested it. Its integer least point has mass15155092 but
fails further candidate creation and lowering tests. This is not a valid
completion of the target problem.

The causal issue was located in the smaller creator d=(21,6,9,2). Both its
target graph selection and the independently selected source orientation
are exact least members of their own finite graph cones, yet mutation
does not identify them. On returning to the source, the difference is

    18 z^(6,3,2,2) [(1+z1)^2+z1^2 z2].

The bracket is the genuine rank-two LLZ polynomial of capacity
(0,2,1,0). The transported target creator is star-positive at the source
but has exactly one negative rank-two section coordinate: pair(1,2),
outside(0,3)=(6,2), root(3,2), label(-2,3), coefficient-18. Thus there is a
fully justified missing lower constraint, independent of any higher-rank
candidate identification. The creation-cap agent is repairing this
smaller node with that actual transported rank-two row.

After the legitimate repair, that agent reports the apparent target
creation constant changes from33 to51: the old -9/-18 violations disappear
(becoming+9/0). This is an explicit warning against promoting a cached
candidate remainder to a theta constraint. The original and corrected
histories are retained rather than overwriting the evidence.

Finally, individual zero-inventory coverage is insufficient as a proof of
leastness. At an exact positive-mass minimum, every nonzero coefficientwise
positive origin-zero direction H in the carrier must already be detected
by some active lower row, since otherwise F-epsilon H remains feasible
and lowers the mass. This coverage is therefore automatic under the
relevant cone hypotheses. The missing statement concerns mixed signed
H-directions, or equivalently positive generation of all coordinate
functionals by the active rows; it cannot be replaced by a per-column
coverage census.

## 2026-11-13 08:39–08:48 UTC

The second ambiguous creator d=(21,7,9,1) was repaired using actual
neighboring-seed rank-two positivity and graph caps. Its exact least mass
changes10090704→10090920. With both creator repairs, the transported top
candidate passes all eight one-step Pieri probes. The graph mass minimum
fails lowering3 at root(2,3,2,2), value-9.

Exact symbolic elimination gives the corrected lowering row
a_(5,6,3,2)-a_(8,6,4,2)-51, identical to the independently valid
neighboring-seed rank-two row found by the creation-cap agent. It is the
negative of the corrected creation1 row. Direct exact computation then
verified [x3 P1]_q=0 and that the relevant x3-action row has its sole
nonzero entry1 at q itself. Thus this is a real zero-inventory diamond,
not merely an accidental equality of two LP certificates.

Proved the general finite smaller-frame conservation identity b+Mc=a,
with a constructible below the target by commuting lowering before
creation (or using the exchange relation on the diagonal). Proved the
zero-resource forcing rule and fixed the root indexing under which the
initial-variable action matrix has diagonal1. Derivative/marking actions
are not included in that unit-diagonal claim. The positive-resource
exchange theorem remains open.

Root and the creation-cap branch found a smaller complete rank-four
counterexample at d=(4,5,5,6), Cartan product(-8,-5,-5,-2), mass1829,
dimension47. The fresh task is strict full-Pieri recursion with exact
leastness at every lower node, plus the rank of zero-diamond equalities.
The existing mass-selector recursion must not silently choose a lower
point when no least exists. Handoff and resource estimate are in
`HANDOFF.md`.
