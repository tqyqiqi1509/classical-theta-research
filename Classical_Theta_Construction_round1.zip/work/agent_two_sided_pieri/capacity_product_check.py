from capacity_pieri import *


def multiply(F,G,n):
    H={}
    for p,a in F.items():
        for q,b in G.items():
            r=tuple(p[i]+q[i] for i in range(n));H[r]=H.get(r,0)+a*b
    return H


def lower_expand(C,d,F):
    g=C.label(d);remainder=dict(F);terms=[];bad=[]
    points=sorted(product(*(range(a+1) for a in d)),key=lambda p:(sum(p),p))
    for q in points:
        a=remainder.pop(q,0)
        if not a:continue
        if not any(q):raise ArithmeticError('nonzero parent coefficient in lower expansion')
        h=tuple(g[k]+sum(C.B[k][j]*q[j] for j in range(C.n)) for k in range(C.n))
        dh=tuple(acyclic_dimension(C.B,h)[0])
        okay=all(q[k]+dh[k]<=d[k] for k in range(C.n)) and sum(dh)<sum(d)
        if not okay:raise ArithmeticError(('unspanned lower Laurent element',d,q,a,dh))
        H=C.get(dh);t={'root':q,'capacity':dh,'coefficient':a};terms.append(t)
        if a<0:bad.append(t)
        for p,b in H.items():
            if not any(p):continue
            r=tuple(p[k]+q[k] for k in range(C.n))
            remainder[r]=remainder.get(r,0)-a*b
            if not remainder[r]:del remainder[r]
    assert not remainder
    return terms,bad


def check_top(C,d):
    F=C.get(d);out=[];tic=time.time()
    for e in product(*(range(a+1) for a in d)):
        f=tuple(d[i]-e[i] for i in range(C.n))
        if not any(e) or not any(f) or e>f:continue
        P=multiply(C.get(e),C.get(f),C.n)
        for p,a in F.items():
            P[p]=P.get(p,0)-a
            if not P[p]:del P[p]
        terms,bad=lower_expand(C,d,P)
        r={'e':e,'f':f,'terms':terms,'negative_terms':bad}
        out.append(r)
        if bad:print('NEGATIVE',e,f,bad[:3],flush=True)
    return {'d':d,'tested':len(out),'negative_products':sum(bool(x['negative_terms']) for x in out),
            'results':out,'seconds':time.time()-tic}


if __name__=='__main__':
    B=[[0,2,2],[-2,0,2],[-2,-2,0]];d=(7,6,9)
    C=CapacityPieri(B,Path(__file__).parent/'capacity_cache_dense222')
    r=check_top(C,d)
    Path(__file__).with_name('capacity_products_dense222.json').write_text(json.dumps(r,separators=(',',':')))
    print('DONE',r['tested'],r['negative_products'],r['seconds'],flush=True)
