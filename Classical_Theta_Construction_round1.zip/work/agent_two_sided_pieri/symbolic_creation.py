"""Exact symbolic smaller-basis creation rows in build_logic parameters."""
from graph_lower_probe import *
from cap_batch import build_logic,evaluate,parameters,coefficient_references,primitive


def creation_rows(C,B,g,d,source,origin,direction,root_bound=None):
    """Yield (root, capacity, affine row) for P_i-F in smaller candidates.

    root_bound optionally restricts to a coordinatewise downset. Such a
    restriction is exact for all returned coordinates by triangularity.
    source maps coefficient exponents to build_logic parameter rows.
    Every called smaller candidate and its independent selection status is
    saved by GraphCache. No cached candidate is called theta.
    """
    n=len(g);width=len(origin);zero=(0,)*width
    dd=tuple(d[j]-(j==direction) for j in range(n));H=C.get(dd);P=dict(H)
    for p,a in H.items():
        q=tuple(p[j]+(j==direction) for j in range(n));P[q]=P.get(q,0)+a
    points=set(P)|set(source)
    inside=lambda p:root_bound is None or all(p[i]<=root_bound[i] for i in range(n))
    rem={p:tuple(P.get(p,0)*a-b for a,b in zip(origin,source.get(p,zero))) for p in points if inside(p)}
    rem={p:r for p,r in rem.items() if any(r)};rows=[]
    while rem:
        q=min(rem,key=lambda p:(sum(p),p));row=rem.pop(q)
        h=tuple(g[k]+sum(B[k][j]*q[j] for j in range(n)) for k in range(n))
        dh=tuple(acyclic_dimension(B,h)[0])
        if not any(q):raise ArithmeticError('nonzero symbolic leading term')
        if not all(q[k]+dh[k]<=d[k] for k in range(n)) or sum(dh)>=sum(d):
            raise ArithmeticError(('outside smaller Laurent span',q,dh,row))
        rows.append({'root':q,'capacity':dh,'row':[str(a) for a in row]})
        F=C.get(dh)
        for p,a in F.items():
            if not any(p):continue
            s=tuple(q[k]+p[k] for k in range(n))
            if not inside(s):continue
            rr=tuple(b-a*c for b,c in zip(rem.get(s,zero),row))
            if any(rr):rem[s]=rr
            elif s in rem:del rem[s]
    return rows


if __name__=='__main__':
    case=json.loads((WORK/'agent_creation_caps/graph_transport_current_input.json').read_text())
    B,g,d=case['B'],case['g'],case['d'];M,R,S=build_logic(B,g,case['carrier'])[:3]
    origin=R[M['ids'][(0,)*len(g)]];source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    C=GraphCache(B,'graph_target_lower_cache')
    rows=creation_rows(C,B,g,d,source,origin,1,root_bound=(2,3,2,2))
    target=next(r for r in rows if r['root']==(2,3,2,2))
    out={'B':B,'g':g,'d':d,'parameter_dimension':len(origin),'direction':1,
         'root_bound':(2,3,2,2),'target_row':target,'rows':rows,
         'comparison_status':'candidate lower basis; not theta identification'}
    atomic(HERE/'graph_target_creation1_symbolic.json',out)
    print('DONE',len(rows),'target',target,flush=True)
