# Single-step creation suffices; the remaining finite packing problem

2026-11-13. Classical acyclic skew-symmetrizable principal coefficients.
This note adds two general structural lemmas to the root creation theorem.
Neither lemma asserts theta identification of the current computed tables.

## 1. Notation and the order used in induction

Let A=[-B]_+ in a topological order. Write

    g=v-(I-A)d,  v,d>=0,  v_i d_i=0,
    a_i=-e_i+A e_i,
    h_r=g-sum_i r_i a_i,  0<=r<=d.

The standard box of h_r is exactly d-r. Put

    P_r(g)=product_i(1+z_i)^(r_i) F_(h_r).

The creation theorem gives P_r(g)-F_g a nonnegative expansion in shifted
theta polynomials with strictly smaller intrinsic standard boxes. Denote
that smaller positive cone by C_<d(g).

All statements involving the lower basis below assume those lower objects
are the genuine theta objects, or that the required lower positive
multiplication identities have themselves been proved. A numerically
selected lower table does not supply this premise.

## 2. Mixed creation redundancy

**Lemma.** If r_j>0, then

    P_r(g)-P_(e_j)(g) belongs to C_<d(g).

Consequently, once all lower data are established, the single condition

    P_(e_j)(g)-F belongs to C_<d(g)

implies the corresponding mixed-r condition. There are at most n genuinely
new creation inequalities at a parent label; enumerating all mixed r does
not strengthen their complete lower-basis versions.

**Proof.** At the strictly smaller label g-a_j, apply the creation theorem
with vector r-e_j:

    product_i(1+z_i)^(r_i-delta_ij) F_(h_r)
       =F_(g-a_j)+sum_(q>0)c_q z^q F_(g-a_j+Bq).

Multiply the homogeneous identity by x_j'. The left side becomes P_r(g),
and the first term becomes P_(e_j)(g). Every other term is a positive
product x_j' theta_(g-a_j+Bq) multiplied by y^q, hence has a positive
theta expansion. Its original frozen root remains at least q>0. The whole
product has support in [0,d], so every final term satisfies

    q'+d(g+Bq')<=d,  q'>=q>0.

Its intrinsic box is therefore strictly smaller than d. This proves the
claim without assuming positivity of an unknown same-size multiplication.

For r=e_j the difference is zero. The argument also covers repeated powers
at the same vertex and arbitrary nonconstant symmetrizers.

### Why direct rank-two caps remain useful

The redundancy lemma is an inductive statement using established lower
theta products. The root rank-deletion caps with |I|=2 are independently
computable from LLZ and therefore remain useful before a higher-rank lower
basis is known. Their role is to supply rigorous upper information without
passing an unproved candidate identification through an induction.

## 3. Finite coordinates for all origin-one Laurent polynomials in a box

Let M_g=product_i(1+z_i)^(d_i) be the explicit standard product. Define

    Q_g={q in N^n\{0}: q+d(g+Bq)<=d}.

For q in Q_g write H_q=z^q F_(g+Bq). All H_q have smaller intrinsic boxes,
have leading monomial z^q with coefficient1, and belong to the finite
initial-star Laurent space supported in [0,d]. They are linearly
independent by triangularity in coordinatewise order.

The audited finite theta expansion and Newton containment imply that every
origin-zero element of this Laurent space is a finite linear combination
of these H_q. Indeed every theta summand has its shifted Newton polytope
inside [0,d], its leading q is nonnegative, and the box lower-bound lemma
gives the displayed condition. The origin coefficient rules out q=0.

Thus every origin-one element has a unique expression

    F=M_g-sum_(q in Q_g)c_q H_q.                            (1)

This uses the established lower basis to coordinatize the full finite
Laurent space. It does not define theta by its unknown expansion.

## 4. Positivity becomes a packing system

Let R be a linear functional known to be nonnegative on every theta
polynomial relevant here. Examples include an initial coefficient, an
adjacent binomial quotient coefficient, a lower-rank slice coefficient,
or a coefficient after a positive lowering/marking operation and expansion
in established lower theta objects. Then

    R(F)>=0  iff  sum_q R(H_q)c_q <= R(M_g).                (2)

Every matrix entry R(H_q) is nonnegative. For the standard creation
products, write

    M_g-P_(e_i)(g)=sum_q ell_(i,q) H_q.

The numbers ell_(i,q) are nonnegative integers: the lower standard product
contains its lower theta element with leading coefficient1, and
multiplication by x_i' preserves positivity. Then

    P_(e_i)(g)-F in C_<d(g)
       iff c_q>=ell_(i,q) for every q.                     (3)

Hence all single-step upper and lower conditions give the finite system

    c>=ell,   Kc<=b,   K>=0,
    ell_q=max_i ell_(i,q).

The standard-product positivity also gives ell>=0. All original
coefficients, quotient inventories, and lower operations can be included
as additional nonnegative rows of K.

This normal form explains the remaining difficulty precisely: it is a
finite packing and exchange problem. Positivity and finite recursion alone
do not make a general packing polytope possess a greatest c, nor do they
make its image under (1) possess a coefficientwise least F. The actual
Laurent/box matrices would need an additional exchange or common-carrier
theorem. General packing results cannot be substituted for that theorem.

## 5. What generator positivity establishes

For an inactive direction d_i=0, freezing makes multiplication by x_i a
single basis shift. If v_i=0, multiplication by x_i' is a creation step
from d to d+e_i. If v_i>0, use

    x_i x_i'=y_i x^[B[:,i]]_+ + x^[-B[:,i]]_+

and pull out one factor x_i. Thus positivity under lowering by all x_i and
creation by all x_i' gives positivity of the action of the semiring
generated by the initial variables and their one-step mutations.

It does not prove positivity of multiplication by an arbitrary selected
basis element: that basis element can require subtraction when expressed
in the generating variables. This is the precise distinction between
positive generator action and a strongly positive basis.

## 6. Exact interval-propagation test

`capped_interval.py` adds the true rank-two creation caps to the earlier
bounded integer propagation on packet equations. The procedure only raises
integer lower bounds and lowers integer upper bounds; it always terminates
because the standard capacities are finite. If its final lower vector
satisfies all packet equations, that vector is an exact coefficientwise
least certificate. This conditional statement is elementary and proved by
soundness of every interval update.

On the hard carrier d=(8,7,9), both the original packet equations and their
complete affine-space parameter equations stop at lower mass58713, below
the certified least mass59085. Only five coefficient lower bounds remain
deficient: at653,663,743,753,754 the deficits are30,30,132,120,60. Thus the
new caps are essential but do not make elementary interval propagation
complete. Future circuit cancellation remains necessary. This is a
diagnostic of a general algorithmic gap, not a claim that LP proof is
impossible or that the cap-constrained cone lacks a least point there.

