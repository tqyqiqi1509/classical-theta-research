"""Integer interval closure after exposing all rank-two packet inventories.

This is a diagnostic of a possible general finite integer closure rule.
It never identifies cached candidates with theta.
"""
from capped_interval import *
sys.path.insert(0,str(ROOT/'agent_packet_propagation'))
from ranktwo_packets import augment
sys.path.insert(0,str(ROOT/'agent_creation_caps'))
from block_upper_caps import block_upper_caps


def run_pair(B,g,C,F=None,global_rows=True):
    tic=time.time();points=list(map(tuple,C['lattice_points']))
    M=build(B,g,points);rows,rhs=equations(M)
    L,U=standard_bounds(B,g,M);d=acyclic_dimension(B,g)[0]
    cc=caps(B,g,d,points)
    bb,families,_=block_upper_caps(B,d,points,graph=True)
    for p,k in M['ids'].items():U[k]=min(cc[p],bb.get(p,cc[p]))
    for p in C['vertices']:
        k=M['ids'][tuple(p)];L[k]=U[k]=1
    vectors,space=affine_packet_rows(B,g,M)
    N,V,stats=augment(B,g,C,M,vectors)
    for eq in stats['identities']:
        k=len(L);raw={int(j):int(a) for j,a in eq['raw']}
        row={k:1}
        for j,a in raw.items():row[j]=-a
        rows.append(row);rhs.append(0)
        L.append(0)
        U.append(sum(a*(U[j] if a>0 else L[j]) for j,a in raw.items()))
    fixed=0
    for i,v in enumerate(V):
        if not any(v[1:]):
            if v[0].q!=1:raise ArithmeticError(('fixed_nonintegral',i,v[0]))
            L[i]=U[i]=int(v[0]);fixed+=1
    if global_rows:
        extra,erhs,refs=parameter_equations(V,len(points));rows+=extra;rhs+=erhs
    L,U,info=close_intervals(rows,rhs,L,U)
    coeff={p:L[i] for p,i in M['ids'].items() if L[i]}
    out={'B':B,'g':g,'d':d,'points':len(points),'variables':len(L),
         'global_rows':global_rows,'fixed':fixed,'lower_mass':sum(coeff.values()),
         'unfixed':sum(a!=b for a,b in zip(L,U)),'closure':info,
         'block_cap_count':len(families),'pair_coordinates':stats['new_coordinates'],
         'seconds':time.time()-tic}
    if F is not None:
        out.update(candidate_mass=str(sum(F.values())),lower_matches_candidate=coeff==F,
          deficits=[{'p':p,'lower':coeff.get(p,0),'candidate':str(a),'upper':U[M['ids'][p]]}
          for p,a in F.items() if a!=coeff.get(p,0)])
    return out


if __name__=='__main__':
    results=[]
    case=json.load(open(ROOT/'agent_packet_propagation/large_origin_exact_failure_2.json'))
    F={tuple(z['p']):Fraction(z['a']) for z in json.load(open(ROOT/'agent_packet_propagation/pair_completion_fork_8_7_9.json'))['F']}
    for glob in (False,True):
        z=run_pair(case['B'],case['g'],case['carrier'],F,global_rows=glob)
        results.append(z);print('HARD',glob,z['lower_mass'],z.get('lower_matches_candidate'),'deficits',len(z.get('deficits',[])),flush=True)
    r=json.load(open(Path(__file__).parent/'capacity_cache_dense222/d_7_6_9.json'))
    F={tuple(z['p']):z['a'] for z in r['F']}
    for glob in (False,True):
        z=run_pair(r['B'],r['g'],r['carrier'],F,global_rows=glob)
        results.append(z);print('DENSE',glob,z['lower_mass'],z.get('lower_matches_candidate'),'deficits',len(z.get('deficits',[])),flush=True)
    Path(__file__).with_name('pair_interval_results.json').write_text(json.dumps(results,indent=2))
