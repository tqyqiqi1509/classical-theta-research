# A general two-sided Pieri identity and its zero-inventory rule

2026-11-13. Classical acyclic skew-symmetrizable principal coefficients.

This note gives the operator mechanism behind the newly observed
creation/lowering equality. The general identity is proved. The numerical
application uses explicitly recorded smaller candidate polynomials and
independently valid neighboring-seed repairs; it is not a theta
identification of the entire candidate table.

## 1. The common smaller frame

Fix a label g with standard capacity d, and suppose the basis and its
positive initial-variable and one-step-mutated-variable actions have been
established in all strictly smaller total capacities. Let

    P_i=x_i' b_(g-a_i),       a_i=-e_i+A e_i,

where d_i>0. Its label is g. Let H_q be the smaller shifted basis elements
of this degree and box, indexed by q>0. For an unknown pointed F of label
g write

    P_i-F = sum_q c_q H_q.

Choose any active j. In the common degree g+e_j frame, define

    b_r = coefficient_r(x_j F),
    M_(r,q) = coefficient_r(x_j H_q),
    a_r = coefficient_r(x_j P_i).

Every object in this last frame has strictly smaller intrinsic total
capacity than d. The resulting exact identity is

    b + M c = a.                                           (D)

If the proposed two-sided Pieri conditions hold, then b>=0 and c>=0.
The smaller positive action gives M>=0. Its root order is triangular:
M_(r,q)=0 unless r>=q coordinatewise, and M_(q,q)=1. Indeed multiplying by
an initial variable retains the frozen root and its pointed leading
coefficient, while additional frozen roots are nonnegative.

## 2. The right side is constructible entirely below d

For i different from j, commute the scalar factors:

    x_j P_i = x_i' (x_j b_(g-a_i)).

The initial lower input has capacity d-e_i. Since j is active there,
applying x_j decreases total capacity by at least one. Every intermediate
basis term has total capacity at most |d|-2. Multiplication by x_i'
increases total capacity by at most one: if the i-th inactive exponent is
zero it is an ordinary creation; otherwise the exchange relation expresses
it by initial-monomial actions, which never increase capacity. Therefore
all subsequent terms still have total capacity at most |d|-1.

For i=j, use the exchange relation directly:

    x_i x_i' = y_i x^[B[:,i]]_+ + x^[-B[:,i]]_+.

Both terms act on b_(g-a_i), whose capacity is |d|-1, by positive initial
monomials. This again stays strictly below d. Thus a is a known
nonnegative integer inventory from the lower recursion, without an
unknown same-level multiplication.

The same reasoning computes every column of M from smaller initial
variable actions. Consequently (D) is a finite nonnegative integer
incidence system supplied by already constructed lower data.

## 3. Zero-inventory forcing

**Theorem.** If a_r=0, then b_r=0 and c_q=0 for every q with M_(r,q)>0.

This follows immediately from (D): all summands are nonnegative. In the
particularly useful case where row r has a single nonzero entry
M_(r,q)=1, one obtains

    b_r+c_q=0.

Thus the upper creation and lower annihilation inequalities are exact
opposites; together they force one integer linear equality in the
unknown coefficients of F. This is a genuine common-inventory rule, not
an appeal to generic packing-polytope leastness.

For positive a_r the same identity bounds an explicit finite weighted
resource allocation. What is not proved is a general exchange theorem
resolving conflicts between such positive resources. Unitriangularity
alone does not imply a greatest feasible c or a coefficientwise least F.

## 4. Exact rank-four diagnostic

Take the target matrix and label from the rank-four graph-cap failure:

    B=((0,0,-3,-1),(0,0,2,0),(3,-2,0,0),(1,0,0,0)),
    g=(8,-7,5,-2), d=(21,7,9,2).

Use creation i=1 and lowering j=3, with zero-based indices. After the
legitimate smaller-node repairs at capacities (21,6,9,2) and
(21,7,9,1), exact pointed elimination at q=(2,3,2,2) gives

    c_q = a_(8,6,4,2)-a_(5,6,3,2)+51,
    b_q = a_(5,6,3,2)-a_(8,6,4,2)-51.

Independent exact computation of the right side and the relevant action
matrix row gives

    [x_3 P_1]_q=0,
    M_(q,q)=1,
    M_(q,r)=0 for every other root in the relevant creation prefix.

Hence this is precisely the zero-inventory case of the general theorem.
The common equality is

    a_(5,6,3,2)-a_(8,6,4,2)=51.

The corrected lower inequality also agrees exactly with a separately
verified true rank-two section inequality after the source mutation.
That independent derivation certifies the inequality without assuming
all smaller candidate entries are theta. It separates the graph mass
selector (value-9) from the transported candidate (value0). The latter
passes all four lowering and all four creation probes with the two
repaired smaller nodes. This finite test is not a proof of global strong
positivity or theta identification.

The exact row and matrix data are in
`graph_target_lowering3_symbolic.json` and
`pieri_diamond_identity.json`. The earlier uncorrected constant33 and
its spurious negative creation coordinates are retained in the research
log as a warning against treating an arbitrary lower cache as a basis.
