from pathlib import Path
import sys,json,time,math
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agent_interior'))
from packet_bounds import *
from itertools import combinations
from fractions import Fraction

def caps(B,g,d,points):
 n=len(g);A=[[max(-B[i][j],0) for j in range(n)] for i in range(n)]
 bound={p:math.prod(math.comb(d[j],p[j]) for j in range(n)) for p in points}
 for pair in combinations(range(n),2):
  I=pair if B[pair[0]][pair[1]]>=0 else pair[::-1]
  J=[j for j in range(n) if j not in I]
  h=tuple(g[i]-sum(A[i][j]*d[j] for j in J) for i in I)
  F,_=llz_F(B[I[0]][I[1]],-B[I[1]][I[0]],h)
  for p in points:
   u=F.get(tuple(p[i] for i in I),0)*math.prod(math.comb(d[j],p[j]) for j in J)
   bound[p]=min(bound[p],u)
 return bound

def run(B,g,C,F=None,global_rows=False):
 tic=time.time();points=list(map(tuple,C['lattice_points']))
 M=build(B,g,points);rows,rhs=equations(M)
 L,U=standard_bounds(B,g,M);d=acyclic_dimension(B,g)[0]
 cc=caps(B,g,d,points)
 for p,k in M['ids'].items():U[k]=cc[p]
 for p in C['vertices']:
  k=M['ids'][tuple(p)];L[k]=U[k]=1
 fixed=0
 if global_rows:
  vectors,space=affine_packet_rows(B,g,M)
  for i,v in enumerate(vectors):
   if not any(v[1:]):
    if v[0].q!=1:raise ArithmeticError(('fixed_nonintegral',i,v[0]))
    L[i]=U[i]=int(v[0]);fixed+=1
  extra,erhs,refs=parameter_equations(vectors,len(points))
  rows+=extra;rhs+=erhs
 L,U,info=close_intervals(rows,rhs,L,U)
 residual=[{'row':j,'value':sum(c*L[i] for i,c in row.items())-rhs[j]}
           for j,row in enumerate(rows) if sum(c*L[i] for i,c in row.items())!=rhs[j]]
 coeff={p:L[i] for p,i in M['ids'].items() if L[i]}
 out={'B':B,'g':g,'d':d,'points':len(points),'variables':len(M['columns']),
      'global_rows':global_rows,'fixed':fixed,'lower_mass':sum(coeff.values()),
      'lower_feasible':not residual,'residuals':residual[:10],
      'unfixed':sum(a!=b for a,b in zip(L,U)),'closure':info,'seconds':time.time()-tic}
 if F is not None:
  out.update(candidate_mass=str(sum(F.values())),lower_matches_candidate=coeff==F,
    deficits=[{'p':p,'lower':coeff.get(p,0),'candidate':str(a),'upper':U[M['ids'][p]]}
     for p,a in F.items() if a!=coeff.get(p,0)])
 return out

def main():
 out=[]
 cases=json.load(open(ROOT/'agent_acceptance/theta_newton_pruning_results.json'))
 for r in cases:
  if max(r['d'])==0:continue
  for glob in (False,True):
   z=run(r['B'],r['g'],r,global_rows=glob);out.append(z)
   print('CASE',len(out),z['d'],glob,z['lower_mass'],z['lower_feasible'],flush=True)
 case=json.load(open(ROOT/'agent_packet_propagation/large_origin_exact_failure_2.json'))
 F={tuple(z['p']):Fraction(z['a']) for z in json.load(open(ROOT/'agent_packet_propagation/pair_completion_fork_8_7_9.json'))['F']}
 for glob in (False,True):
  z=run(case['B'],case['g'],case['carrier'],F,global_rows=glob);out.append(z)
  print('HARD',glob,z['lower_mass'],z['lower_feasible'],'deficits',len(z['deficits']),flush=True)
 Path(__file__).with_name('capped_interval_results.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
