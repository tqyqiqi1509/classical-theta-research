#!/usr/bin/env python3
"""Diagnostic of one proposed all-allocation common object; no theorem assumed."""
import sys,json,time
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).parent/'agent_source_surgery'))
from common_slot_flows import PairFlows,star_audit

def common(a,b,c,wa,wb):
    aa=[PairFlows(a,t,wa,wa) for t in range(c+1)]
    bb=[PairFlows(b,c-t,wb,wb) for t in range(c+1)]
    out=Counter()
    for vm in range(1<<c):
        ca=Counter(hm.bit_count() for hm in range(1<<a)
          if all(aa[t].compatible(hm,vm&((1<<t)-1)) for t in range(c+1)))
        cb=Counter(hm.bit_count() for hm in range(1<<b)
          if all(bb[t].compatible(hm,vm>>t) for t in range(c+1)))
        for p,x in ca.items():
            for q,y in cb.items():out[p,q,vm.bit_count()]+=x*y
    return dict(out)

start=time.time(); data=[]
for a,b,c,wa,wb in [(2,2,3,2,2),(3,3,4,2,2),(8,7,9,3,2)]:
    F=common(a,b,c,wa,wb)
    B=((0,0,wa),(0,0,wb),(-wa,-wb,0));g=(-a,-b,wa*a+wb*b-c)
    result={'d':[a,b,c],'weights':[wa,wb],'mass':sum(F.values()),'support':len(F),
      'star_audit':star_audit(F,B,g),'F':[[list(p),v] for p,v in sorted(F.items())]}
    data.append(result)
    print({k:v for k,v in result.items() if k!='F'},flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps({'seconds':time.time()-start,'status':'proposed direct common-slot intersection; diagnostic only','data':data},indent=2))
