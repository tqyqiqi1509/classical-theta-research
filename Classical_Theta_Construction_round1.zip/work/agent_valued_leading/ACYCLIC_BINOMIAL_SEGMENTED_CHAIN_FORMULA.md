# Acyclic theta coefficients as finite signed segmented chains

2026-11-13. Independent derivation and audit by the valued-leading branch.
The matrix simplification was proposed by root and verified independently
here. The segmented-chain formulation was also obtained independently by
root. This is a pure finite integer object for every classical acyclic
skew-symmetrizable principal seed.

## 1. Data and finite carrier

Relabel B so B_ij>=0 for i<j, choose an integral positive D with DB
skew-symmetric, and fix g in Z^n. Set A=[-B]_+. Compute, in increasing i,

    d_i=max(-g_i+sum_(j<i)A_ij d_j,0),
    v_i=g_i+d_i-sum_(j<i)A_ij d_j.

Then d,v>=0, d_i v_i=0, and g=v-(I-A)d. Let J=[0,d] cap Z^n.

The finite integer step weight for comparable q<=p in J is

    C_g(p,q)=product_(i=1)^n binom(N_i(p,q), p_i-q_i),
    N_i(p,q)=-g_i-sum_(j<i)B_ij p_j-sum_(j>i)B_ij q_j.   (1)

Generalized binomial coefficients have the integral convention
binom(-r,k)=(-1)^k binom(r+k-1,k), r>0, k>=0. The diagonal C_g(p,p)=1.

For a terminal root p, put m_p=g+Bp and define the finite set

    I_p={p} union {q<=p : m_p^T D(p-q)<0}.                (2)

All data in (1)-(2) are computed from B,D,g and integer lattice points.
There is no mutation word, frame polynomial, wall, theta coefficient,
large real endpoint, or representation in this definition.

## 2. One direct combinatorial definition

For p!=0, take a strict componentwise-increasing lattice chain

    0=s_0<s_1<...<s_N=p,

together with a partition of its N steps into nonempty consecutive blocks.
Let the block endpoints have indices

    0=j_0<j_1<...<j_k=N.

The chain with this partition is admissible if, for every block t and every
index j_(t-1)<=l<j_t,

    (g+B s_(j_t))^T D (s_(j_t)-s_l)<0.                  (3)

Thus each proper earlier vertex of a block lies in the negative half-space
specified by its terminal vertex. Assign the integer weight

    (-1)^(N+k) product_(l=1)^N C_g(s_l,s_(l-1)).         (4)

Let a_p be the sum of these weights over all admissible segmented chains
from 0 to p. Set a_0=1 using the empty chain. There are finitely many such
objects: each strict step increases total root degree, so N<=|p|_1, all
vertices lie in the finite box, and a fixed chain has finitely many step
partitions.

**Theorem.** The resulting polynomial is

    F_g(z)=sum_(p in J) a_p z^p,
    theta_(g,0)=x^g F_g(y_j x^(B e_j)).                  (5)

The signed weights in (4) need not be individually positive. The theorem
identifies their total with the nonnegative integral classical theta
coefficient. It does not assert a cancellation-free matching formula.

### Optional signed objects of weight plus or minus one

Each factor binom(N_i,k_i) in (1) is itself a finite signed choice count.
If N_i>=0, choose a k_i-element subset of N_i colors, with positive sign.
If N_i=-r<0, choose a multiset of size k_i from r colors, with sign
(-1)^k_i. Decorate every step and coordinate by these choices. Multiply
their signs by (-1)^(N+k). Summing these plus-or-minus-one weights gives
exactly (4). This gives finite subset/multiset objects with an explicit
integer half-space constraint, if unweighted binomial symbols are unwanted.

## 3. Equivalent finite chain inverse, and why the restriction is exact

For each p, restrict the matrix C_g to rows and columns I_p. It remains
unitriangular even though I_p need not be downward closed. Define

    w(q,p)=-(C_g[I_p,I_p]^(-1))_(p,q) if q in I_p\{p},
           0 otherwise.

Then the coefficient recurrence is

    a_0=1,       a_p=sum_(q<p) w(q,p) a_q.               (6)

The inverse entry is the usual finite strict-chain sum. Its negative equals
the sum over q=r_0<...<r_l=p with all vertices in I_p of
(-1)^(l+1) product_j C_g(r_j,r_(j-1)). Expanding all edges of a path for
(6) gives precisely the segmented chains (3)-(4): the sum of block lengths
is N and the number of blocks is k, yielding sign (-1)^(N+k).

Here is the exact argument that no intermediate vertex was lost. In the
comparison proof take M>max_i D_i |d|_1 and u=M m_p+1. For every nonzero
increment alpha<=d,

    u^T D alpha<0 iff m_p^T D alpha<0.

Factor the total transport matrix C=A_minus A_plus by the audited sign
factorization, and let T=A_minus^(-1). Its pth row is zero outside I_p.
Also TC=A_plus. For q in I_p\{p}, the (p,q) entry of A_plus is zero, so

    sum_(r in I_p) T_(p,r) C_(r,q)=0;

for q=p this sum is 1. Every r outside I_p disappears because T_(p,r)=0,
not because the restricted set is downward closed. Since C[I_p,I_p] is
unitriangular, the row equations have the unique solution

    T_(p,q)=(C[I_p,I_p]^(-1))_(p,q), q in I_p.

The last-bend comparison already proved for the general theorem gives
(6). Neither u nor the sign factorization has to be evaluated by (1)-(4).

## 4. Derivation of the closed binomial matrix

This derivation identifies (1) with the total transport matrix; the frame
polynomials are used only in the proof. The acyclic sink-order frame has

    H_i=1+z_i product_(j>i)H_j^(A_ji),
    Phi(x_i)=x_i H_i^(-1),      Phi(y_j)=y_j.

Therefore, with r=p-q,

    C_(p,q)=[z^r] product_i H_i^(-(g+Bq)_i).

Extract z_1^(r_1), then z_2^(r_2), and so on. At the ith step the exponent
of H_i is

    -(g+Bq)_i+sum_(j<i) A_ij r_j.

The coefficient is its generalized binomial coefficient at r_i. Since
A_ij=-B_ij for j<i, this exponent is

    -g_i-sum_(j<i)B_ij p_j-sum_(j>i)B_ij q_j,

which proves (1). No assumption D=I was used.

The box J is justified by the ordinary standard product

    S_g=x^v product_i (x_i')^(d_i)
       =x^g product_i(1+z_i)^(d_i).

Every factor is a classical cluster theta function. Its positive theta
expansion has theta_(g,0) with coefficient one, by principal homogeneity
and the origin coefficient. Thus the theta F-polynomial lies in J. This
carrier argument needs no quantum quadratic support inequality.

## 5. Independent exact computations

- `check_acyclic_binomial_matrix.py` compares (1) with an independently
  implemented truncated expansion using the recursive H_i. It checked 240
  randomized acyclic valued matrices, ranks 2-4, symmetrizer entries 1-5,
  arbitrary sampled integer g and comparable p,q. Result: zero failures.
- `halfspace_inverse_wolfram.wl` checks the restricted inverse identity
  against full sign factorization for 150 arbitrary integer unitriangular
  comparable-pair matrices, ranks 2-4, boxes of at most 81 vertices.
  Result: `{150,0,81,35,{}}`, with no warning. This checks the general
  matrix mechanism, not just a selection of cluster examples.
- The exact original receipts are stored alongside these files.

The proof, rather than these finite checks, establishes the arbitrary-rank
and arbitrary-symmetrizer claims. The coefficient-base-change theorem in
`ACYCLIC_GEOMETRIC_COEFFICIENT_BASIS.md` then substitutes
z^p=x^(Bp)f^(Gamma p), giving the same signed objects for arbitrary geometric
coefficients, including the coefficient-free case.
