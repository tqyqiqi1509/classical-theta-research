# Acyclic theta coefficients as a finite signed count of unit-weight objects

2026-11-13. Final independent boundary audit: **PASS**.

Use only the integer data \(B,D,g\), the finite capacity box \(J=[0,d]\), and the strict chains with binary labels of `work/agent_cyclic_generic_bridge/SEGMENTATION_CANCELLATION.md`. No auxiliary transport matrix, matrix inverse, or factorization is part of the following definition. All object rules below are scalar integer sums and comparisons.

For completeness, topologically order the acyclic exchange matrix so that
\(B_{ih}\ge0\) for \(i<h\), choose a positive integral diagonal \(D\)
with \(DB\) skew-symmetric, and compute the finite capacity by the explicit
integer recursion

\[
d_i=\max\left(-g_i+\sum_{h<i}[-B_{ih}]_+d_h,0\right),
\qquad i=1,\ldots,n.
\]

Here \(J=\{p\in\mathbb Z^n:0\le p_i\le d_i\}\), so the construction
requires no supplied polynomial or mutation word.

For \(p\ne0\), choose a strict componentwise increasing chain

\[
0=s_0<s_1<\cdots<s_N=p.
\]

Compute

\[
b_j=\max\left\{k<j:
\sum_{i=1}^n D_i\left(g_i+\sum_{h=1}^nB_{ih}(s_j)_h\right)
\big((s_j)_i-(s_k)_i\big)\ge0\right\},
\]

with the maximum of the empty set taken as \(-1\). Put \(P_{-1}=0\), \(P_0=1\), and \(P_j=P_{b_j}\). Set

\[
\eta(s)=(-1)^N(P_N-P_{N-1})\in\{-1,0,1\}.
\]

Discard chains with \(\eta(s)=0\). For each remaining chain, for every step \(j=1,\ldots,N\) and coordinate \(i=1,\ldots,n\), put

\[
k_{ji}=(s_j)_i-(s_{j-1})_i\ge0,
\qquad
r_{ji}=-g_i-\sum_{h<i}B_{ih}(s_j)_h
                 -\sum_{h>i}B_{ih}(s_{j-1})_h.
\]

Decorate this step and coordinate as follows.

- If \(r_{ji}\ge0\), choose a \(k_{ji}\)-element subset of the labeled set \(\{1,\ldots,r_{ji}\}\). This choice has sign \(+1\).
- If \(r_{ji}=-\ell<0\), choose a multiset of total cardinality \(k_{ji}\) from the \(\ell\) labeled colors \(\{1,\ldots,\ell\}\). This choice has sign \((-1)^{k_{ji}}\).

A complete object is the chain together with all these independent decorations. Its weight is the single sign

\[
\boxed{\eta(s)(-1)^{\sum_{(j,i):\ r_{ji}<0}k_{ji}}\in\{-1,+1\}.}
\]

The signed number of complete objects ending at \(p\) is exactly the theta coefficient \(a_{g,p}\). For \(p=0\), use one empty object of sign \(+1\). For \(p\notin J\), there are no objects.

Writing \(\mathcal O^+_{g,p}\) and \(\mathcal O^-_{g,p}\) for the two
sign classes, the complete output is

\[
\theta_{(g,0)}
=\sum_{p\in J}\bigl(|\mathcal O^+_{g,p}|-|\mathcal O^-_{g,p}|\bigr)
  x^{g+Bp}y^p.
\]

For an arbitrary geometric coefficient matrix \(\Gamma\) in the acyclic
coefficient theorem, replace \(y^p\) by \(f^{\Gamma p}\); the same finite
objects and signs give the integral basis proved there.

**Justification.** In the nonnegative branch the number of decorations is \(\binom{r}{k}\). In the negative branch the number is \(\binom{\ell+k-1}{k}\), and its assigned sign gives

\[
(-1)^k\binom{\ell+k-1}{k}=\binom{-\ell}{k}.
\]

Thus summing the signed decorations of a fixed chain gives exactly its explicit generalized-binomial step weight multiplied by \(\eta(s)\). The already proved cancellation of segmentations gives the theta coefficient after summing chains. The definition itself contains no matrix operation.

**Boundary cases.** When \(k=0\), both branches have precisely one empty decoration with positive sign. In particular \(r=0,k=0\) gives one empty subset. When \(r=0,k>0\), or more generally \(r\ge0,k>r\), there are no subset decorations. The negative branch always has \(\ell\ge1\), so no undefined zero-color multiset convention is needed. A strict chain step may have some zero coordinate increments; those coordinates contribute the unique empty decoration. Zero halfspace pairing is forbidden in a block and is correctly included in the definition of \(b_j\).

All sets are finite: \(N\le |p|_1\), all vertices lie in \(J\), and every decoration has a finite specified color set and finite specified cardinality. The final total is nonnegative by its identification with the classical theta coefficient, but individual objects have either sign. This is a signed unit-weight model, not a claim of a cancellation-free positive matching model.
