# Final substantive audit: integral coefficient specialization

2026-11-13, 10:09 UTC. **Outcome: PASS** for every acyclic classical skew-symmetrizable exchange matrix with arbitrary geometric coefficients over an integral Laurent ring of invertible frozen variables. This note checks the two potentially serious issues: collisions after specialization, and the Sage warning about separation of additions.

## 1. The exact theorem being checked

Write \(R_0=\mathbb Z[y_1^{\pm1},\ldots,y_n^{\pm1}]\), \(R=\mathbb Z[f_1^{\pm1},\ldots,f_m^{\pm1}]\), and let \(\Gamma\) be any integer frozen matrix. Set \(a_i=f^{[\Gamma e_i]_+}\), \(b_i=f^{[-\Gamma e_i]_+}\), and \(\sigma(y_i)=a_i/b_i\). The proposed basis is

\[
\Theta_g^\Gamma=\sigma(\theta_{(g,0)})
=\sum_p a_{g,p}x^{g+Bp}f^{\Gamma p}.
\]

The claim is an \(R\)-basis of the ordinary acyclic cluster algebra, equivalently its upper algebra, without a rank or coprimality restriction on the specialized coefficient matrix. It is not a claim about arbitrary cyclic upper-algebra specialization.

## 2. Tensoring is legitimate even when monomials collide

The BFZ acyclic presentation has all its relations already in the one-step exchange pairs:

\[
A_{\rm prin}=R_0[x_i,u_i]/(x_i u_i-y_iP_i-Q_i),
\]

\[
A_\Gamma=R[x_i,U_i]/(x_iU_i-a_iP_i-b_iQ_i).
\]

After tensoring the first presentation along \(\sigma\), the substitutions \(u_i\mapsto b_i^{-1}U_i\) and \(U_i\mapsto b_i u_i\) are inverse algebra maps. Every \(b_i\) is a unit. Hence

\[
\boxed{A_{\rm prin}\otimes_{R_0,\sigma}R\cong A_\Gamma.}
\]

The fact that tensor products preserve this quotient presentation is right exactness; it does not require flatness. No tensor product of an intersection of Laurent rings appears.

For the principal acyclic seed, the integral full-label theta theorem applies: it is injective-reachable, has full principal rank, and its ordinary and upper algebras agree. Qin's text explicitly uses the classical base ring \(\mathbb Z\); Theorem A.1.5 gives the theta basis. Frozen translations \(\theta_{(g,r)}=y^r\theta_{(g,0)}\) turn this full integral basis into the direct sum

\[
A_{\rm prin}=\bigoplus_{g\in\mathbb Z^n}R_0\theta_{(g,0)}.
\]

Tensor products commute with direct sums and carry a rank-one free summand to a rank-one free summand. Thus

\[
A_\Gamma\cong\bigoplus_{g\in\mathbb Z^n}R(\theta_{(g,0)}\otimes1).
\]

This proves independence and spanning of the displayed family. If a specialized finite relation among the \(\Theta_g^\Gamma\) existed, its inverse image under the presentation isomorphism would be a relation among these displayed free summands, forcing every coefficient to vanish. Laurent monomial collisions are irrelevant to that argument. In particular, one must not replace this reasoning by a claim that a distinguished Laurent coefficient remains one after specialization: that claim can fail.

Equivalently, the principal theta basis and BFZ standard-monomial basis have mutually inverse column-finite change matrices over \(R_0\). Each identity in their product is a finite sum. Applying \(\sigma\) preserves both inverse identities. The specialized standard monomials are the actual standard monomials times frozen units, so the specialized theta family remains a basis. This is an algebraic inverse-matrix argument, not an infinite-triangular convergence argument.

## 3. What the Sage warning actually forbids

The current official Sage documentation for `theta_basis_element` gives a coefficient example in which its theta element equals \((x_1+f)/(x_0f)\), whereas the cluster variable with the corresponding mutable label is \((x_1+f)/x_0\). It warns against applying the cluster-variable separation formula to general theta elements. The difference in that example is exactly one frozen monomial unit.

Our theorem follows the principal normalization \(\Theta_g^\Gamma=\sigma(\theta_g)\). It does **not** divide every theta specialization by a tropical F-polynomial evaluation. Fomin–Zelevinsky's separation theorem is used only for ordinary cluster variables, to identify each specialized principal cluster variable as a frozen unit times the actual cluster variable. Substitution into a positive Laurent expansion in such variables then proves universal Laurent positivity. This use is within the theorem's stated scope.

The optional family

\[
\widehat\Theta_g^\Gamma=f^{-\nu(g)}\Theta_g^\Gamma,
\qquad
\nu_a(g)=\min_{p:a_{g,p}\ne0}(\Gamma p)_a,
\]

is explicitly a frozen-unit rescaling of the basis. For a cluster-monomial label, ordinary separation identifies this rescaled element with that actual cluster monomial. For general labels, we claim only that this is a positive, unit-rescaled basis; we do not claim a general theta separation theorem or an unchanged canonical normalization. Thus the Sage warning is respected, not overridden.

## 4. Remaining scope controls

All statements above use \(R=\mathbb Z[f^{\pm1}]\). The audit does not enlarge the coefficient category to arbitrary rings, where exchange binomials might vanish. Acyclicity supplies the complete finite presentation, and Muller's acyclic \(A=U\) theorem supplies equality with the upper algebra without requiring specialized coprimality. Positivity of structure coefficients survives because \(\sigma\) sends each principal frozen Laurent monomial to a frozen Laurent monomial with coefficient one; collisions add nonnegative integers.

The coefficient-free case is exactly \(\Gamma=0\), \(R=\mathbb Z\), and is covered by the same argument. It needs no separate combinatorial injectivity argument.

## 5. Sources checked

- BFZ, *Cluster algebras III*, Theorems 1.16 and 1.20 and Corollary 1.17: https://arxiv.org/html/math/0305434v3. Their acyclic standard-monomial basis and complete presentation are the essential input. The coprime upper-bound statement is not substituted for these results.
- Qin, *Bases for upper cluster algebras and tropical points*, arXiv:1902.09507v4, classical ground ring in Sections 1–2 and Theorem A.1.5. The local exact text was rechecked during this final audit.
- Fomin–Zelevinsky, *Cluster algebras IV: Coefficients*, Theorem 3.7 and Corollary 6.3: https://arxiv.org/abs/math/0602259. Used only for cluster variables and their monomial products.
- Muller, *A=U for Locally Acyclic Cluster Algebras*: https://sigma-journal.com/2014/094/sigma14-094.pdf.
- Official SageMath documentation, `theta_basis_element` and `theta_basis_F_polynomial`: https://doc.sagemath.org/html/en/reference/algebras/sage/algebras/cluster_algebra.html. Read the actual normalization example and warning, not merely the search snippet. Retrieval references: `turn541view0`, `turn542view2`.

No fatal gap was found in the stated acyclic geometric-coefficient theorem. No 2026 result enters its proof.
