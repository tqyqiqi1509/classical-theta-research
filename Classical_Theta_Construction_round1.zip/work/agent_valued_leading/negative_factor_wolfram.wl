SeedRandom[131126];
cases = Table[
 Module[{r,cap,pts,n,ord,w,C,am,ap,t,less,ds,R,p,q,k,sgn,ok},
  r=RandomInteger[{2,4}]; cap=RandomInteger[{1,2},r];
  pts=SortBy[Tuples[Table[Range[0,cap[[i]]],{i,r}]],{Total[#]&,Identity}];
  n=Length[pts]; w=RandomChoice[{-1,1},r] Table[4^(i-1),{i,r}];
  less[p_,q_]:=And@@Thread[pts[[q]]<=pts[[p]]];
  C=IdentityMatrix[n];
  Do[If[less[p,q],C[[p,q]]=RandomInteger[{-5,5}]],{p,2,n},{q,1,p-1}];
  am=IdentityMatrix[n];ap=IdentityMatrix[n];
  Do[Do[
    If[p>q && less[p,q] && Total[pts[[p]]-pts[[q]]]==k,
      R=C[[p,q]]-Sum[am[[p,j]] ap[[j,q]],{j,q+1,p-1}];
      If[w.(pts[[p]]-pts[[q]])<0,am[[p,q]]=R,ap[[p,q]]=R]
    ],{p,2,n},{q,1,p-1}],{k,1,Total[cap]}];
  t=Inverse[am];
  ok=(am.ap===C)&&(am.t===IdentityMatrix[n])&&
     And@@Flatten[Table[If[p>q&&less[p,q],
       If[w.(pts[[p]]-pts[[q]])<0,ap[[p,q]]===0,am[[p,q]]===0&&t[[p,q]]===0],True],{p,n},{q,n}]];
  {r,n,ok}
 ],{120}];
{Length[cases],Count[cases,{_,_,False}],Counts[cases[[All,1]]],Max[cases[[All,2]]],Select[cases,Not[Last[#]]&]}
