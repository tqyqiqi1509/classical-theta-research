# Independent proof audit: finite signed factorization from a negative frame

2026-11-13, 09:32 UTC. Reviewer: valued-leading-degree branch, independently
of the proposing cyclic-generic branch. Scope: classical principal cluster
algebras with any integral skew-symmetrizer and a supplied negative-frame
mutation word. The review concerns the general mechanism, not special examples.

## Result

The proposed theorem in
`../agent_cyclic_generic_bridge/NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md`
passes this independent proof audit. No quantum positivity, quantum theta
Laurentness, acyclic Hall theorem, Newton VIT theorem, or 2026 manuscript
result is needed. The finite negative frame and standard classical theta
transport/positivity facts suffice. This is a separate route; it does not
retroactively establish every statement in the earlier Hall proof.

The five critical checks are recorded below, with conventions made explicit.

## 1. Total transport, including frozen variables

Let B be an integral exchange matrix, D a positive integral diagonal matrix
with DB skew-symmetric, and z^a=x^(Ba)y^a. A certified terminal C=-P gives
G=-P. After reindexing its variables, the negative frame is

    I_i = x_i^(-1) H_i(z),   H_i(0)=1.

The full leading exponent is (-e_i,0). It is not permissible to retain only
the mutable label and leave a frozen monomial unspecified. Ordinary principal
F/g mutation verifies both the displayed form and the permutation.

The terminal cluster cone is the negative mutable orthant, with the frozen
directions free. GHKK Corollary 3.9 says that a theta function whose label lies
in a cluster cone is its own labeled monomial when expanded at an interior
point of that cone. Thus theta_(-e_i,0)=x_i^(-1) in the negative chamber.
Transport to the initial chamber gives I_i. Since transport is an algebra
automorphism, it gives

    Phi(x_i)=I_i^(-1)=x_i H_i(z)^(-1).

Every normal has zero frozen component, so Phi(y_j)=y_j. In particular
Phi(z_j) is generally NOT z_j. On the fixed principal homogeneous degree g,
using column basis v_q=x^(g+Bq)y^q, the exact entry formula is

    C_pq=[z^(p-q)] product_i H_i(z)^(-(g+Bq)_i),   q<=p.

The Bq term is essential. The formula in the proposed theorem includes it.

## 2. Weighted normals and factor order

A root increment a has mutable displacement Ba. Its normal is Da, up to a
positive scalar. This normalization is consistent with a^T DBa=0; equivalently,
the principal compatible form pairs a based mutable monomial with E a by
-m^T Da. Thus the relevant sign is lambda(a)=u^T Da, not u^T a when D differs
from the identity.

Choose endpoints Q_- in the negative orthant, Q_+ in the positive orthant,
and Q in the cell of a generic u for all roots relevant to the finite box.
A segment Q_- to Q cannot meet a positive-root hyperplane with lambda<0,
because its defining linear function is negative at both endpoints. Its
transport Chi therefore contains only strictly positive-lambda increments.
Likewise the segment Q to Q_+ crosses only lambda<0 hyperplanes, and its
transport Psi contains only strictly negative-lambda increments. Small generic
perturbations can avoid joints without changing these restrictions; only
finitely many roots are relevant at the specified degree.

Every wall transformation and its inverse increase root degree by nonnegative
roots. A composition of increments of one strict lambda sign keeps that sign.
Consistency gives Phi=Psi composed with Chi. With column-vector actions this
is exactly

    C=A_minus A_plus,

where the left factor is Q to initial, and the right factor is negative to Q.
This order has been checked independently. Reversing it would invalidate the
coefficient extraction.

## 3. Finite factorization and truncation

On a downward closed finite box, all operators are unitriangular. Terms
outside the box can never return, under the operators or their inverses.
Hence restriction to the box is compatible with multiplication and inversion.

For q<p, induct on |p-q| and write

    R_pq=C_pq-sum_(q<r<p) (A_minus)_pr (A_plus)_rq.

Both factors in every summand are already known on shorter intervals. Of
the two unknown entries at (p,q), exactly one is permitted by the sign of
lambda(p-q); set it equal to R_pq and the other to zero. This proves existence,
uniqueness and integrality for every unitriangular integer C, not just those
coming from clusters. The actual geometric factors satisfy the same support
conditions, so uniqueness identifies them with the computed factors.

The inverse T=(A_minus)^(-1) is therefore transport from the initial chart
to Q. Its finite strict-chain expansion is integral, with signs allowed.

## 4. Explicit direction and final coefficient extraction

Let K=sum_i d_i for the explicit carrier box and set M=1+(max_i D_i)K.
For the target root p choose u_p=M(g+Bp)+1. For every 0<|a|<=K,

    u_p^T Da=M(g+Bp)^T Da+sum_i D_i a_i.

The second summand lies strictly between 0 and M. Thus the pairing is nonzero
and agrees with the sign of (g+Bp)^T Da whenever that is nonzero.

The backwards final ray Q+t(g+Bp) consequently misses every hyperplane that
could supply a root increment contributing to p. A proposed nonconstant
theta term at full exponent (g+Bp,p) can have no last nontrivial bend. The
unbent term is also excluded for p!=0: its frozen exponent would be p rather
than 0, even when Bp=0 or g+Bp=0. Therefore

    sum_(q<=p) T^(u_p)_pq [z^q]F_g=0,  p!=0.

Since T_pp=1, the claimed triangular recurrence follows. This check covers
the zero mutable final exponent and a nontrivial kernel of B; neither is an
exception. The algorithm itself uses only integer directions, matrix entries,
and signed finite paths. Its correctness proof uses theta transport.

## 5. Finite carrier without a 2026 Newton theorem

Use M_g=product_i x_i^[g_i]_+ I_i^[-g_i]_+. It is a finite product of cluster
theta functions, initially pointed at (g,0). Classical theta multiplication
has nonnegative integral structure coefficients. Principal homogeneity
puts every label in its expansion at (g+Bq,q). Positivity prevents q from
having a negative coordinate, since its own leading monomial would then
appear with that negative frozen exponent in M_g. Only q=0 contributes to
the frozen origin, and its coefficient must be one. Thus theta_g occurs
with coefficient one and is coefficientwise bounded by the explicit product
of the H_i. This gives the finite box d_j=sum_i[-g_i]_+ deg_(z_j)H_i.

The positivity and additive closure statements of GHKK already ensure that
all integer g are allowable theta labels, because both e_i and -e_i belong
to the cluster complex. Qin's injective-reachability theorem then supplies
the full upper-cluster-algebra basis statement. For general negative-frame
inputs, A=U is not asserted. For acyclic inputs the usual equality applies.

## Exact primary-source checks

1. GHKK, arXiv:1411.1394v2, Corollary 3.9, read directly in the current
   public HTML: any cluster chamber sigma, Q in its interior and m in sigma
   gives theta_(Q,m)=z^m. This follows there from Proposition 3.8 and mutation
   compatibility Proposition 3.6. The seed data include skew-symmetrizable
   lattices; this is not a skew-only theorem.
   https://arxiv.org/html/1411.1394v2
   Retrieval refs: turn488view1, turn489view0, turn489view1, turn489view2.
2. Qin, arXiv:1902.09507v4 (2021), Appendix A.1, pages 56-59, read in the
   existing exact local PDF text. It explicitly identifies the t0[1] chamber
   with C-, records theta endpoint transport, states cluster-variable inclusion
   in Theorem A.1.3, and gives the injective-reachable basis theorem A.1.5.
   https://arxiv.org/abs/1902.09507
   Public version history independently checked: turn488view0.
3. The proposed theorem's proof uses no assertion from Li--Pan and no claim
   from the 2026 Qiyue Tang manuscript. The earlier acyclic Hall route remains
   preserved separately as an optional independent research result.

## Review status

General mechanism: PASS. Total substitution: PASS. Factor order: PASS.
Weighted normal: PASS. Finite truncation: PASS. Carrier: PASS. Final extraction:
PASS. Scope condition: explicit negative-frame certificate required. Signed
weights: allowed, with no claim of a cancellation-free positive model.
