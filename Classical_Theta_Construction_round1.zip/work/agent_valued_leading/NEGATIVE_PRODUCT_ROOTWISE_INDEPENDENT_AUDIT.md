# Independent audit of rootwise recovery from a negative product

2026-11-13. General classical skew-symmetrizable principal seeds.
Reviewed file:
`../agent_cyclic_generic_bridge/NEGATIVE_PRODUCT_INTEGER_THETA_THEOREM.md`.

## Result: the general construction passes

Let a finite product of ordinary cluster variables have leading mutable
label h=sum_s a_s g_s with every h_i<0. For any g choose k with g-kh>=0.
The explicit positive product x^(g-kh)P^k supplies a finite carrier for
theta_(g,0), by the already audited positivity and principal-homogeneity
argument. P is used as a product, not identified with any individual theta.

For every positive root alpha, h^T D alpha<0, so one factor g_s has
g_s^T D alpha<0. In its cluster g-cone an interior point with the same
negative pairing is obtained by increasing the positive coefficient of
that column. The formula (5) in the reviewed file is correct: if c<=-1,
b is the sum of the other pairings and N=1+max(0,b), then Nc+b<0.

Ordinary G/F mutation data determine the seed-to-initial transport Phi_s:
Phi_s(x_i)=x_i product_l F_(s,l)^((G_s^(-1))_(l,i)), and frozen variables
are fixed. All G_s are integral unimodular. The inverse matrix S_s therefore
has integer entries on every finite downward-closed root box.

The negative orthant always has no wall in its interior: every wall has
a positive root normal. It consequently defines a formal comparison chart
and a total transport Phi to the positive initial chart, regardless of
whether a cluster seed realizes that orthant. Let C_true be its matrix.

The composition Phi_s^(-1) Phi goes from the negative orthant to an
interior point v of the chosen seed cone. Along a straight segment, only
normal roots beta with v^T D beta>0 can be crossed. Hence every nonzero
increment in this composition has strictly positive pairing with v. For
alpha=p-q chosen with v^T D alpha<0, its (p,q) matrix entry is zero:

    0=(S_s C_true)_(p,q)
     =C_true_(p,q)+sum_(q<=r<p)(S_s)_(p,r) C_true_(r,q).

This is exactly the proposed recurrence. Every remaining unknown has
strictly smaller |r-q|, proving existence, uniqueness, integrality, finite
termination and correctness by induction. Different root-covering seeds
yield the same answer because they satisfy the same identity for C_true.
The subsequent half-space chain extraction is already independently audited.

No negative-orthant theta monomial assertion is used. In particular the
argument never sets P equal to theta_h and never identifies Phi(x_i^-1)
with theta_-e_i when the negative chamber is not a cluster chamber.

## The exact large-cluster-complex equivalence

Fix the coordinate seed and let K be the real cone of finite nonnegative
linear combinations of all cluster g-vectors. The initial e_i belong to K.
The existence of a strictly negative h in K is equivalent to the union of
cluster g-cones not lying in a closed linear half-space through zero.

One careful proof avoids assuming that the infinitely generated K is closed.
If no finite strictly negative combination exists, then for every finite
collection of cluster g-vectors, finite linear separation provides a vector
ell with ell_i>=0, sum_i ell_i=1, and ell(g_s)>=0 on that collection.
These are closed subsets of the compact nonnegative unit simplex. Their
finite intersection property gives one nonzero ell nonnegative on every
cluster g-vector, a containing half-space. The converse is immediate from
ell(e_i)>=0 and ell(h)<0. Because a strictly negative finite combination
uses only finitely many integral columns, rational approximation preserves
strict negativity; clearing denominators yields integer multiplicities.

GHKK arXiv:1411.1394v2 calls this property Definition 8.27 and proves the
full principal Fock--Goncharov conclusion in Proposition 8.28. Both statement
and proof were read directly (retrieval refs turn518view0--2).
https://arxiv.org/html/1411.1394v2

Their definition says the no-half-space property holds for SOME seed.
The displayed negative product is a certificate in the chosen coordinate
seed. If only a different witnessing seed is known, include its mutation
word in the input and perform the construction there, then apply ordinary
coordinate transport. This audit does not need an additional unproved
assertion that every initial seed automatically has such a product.

## Integral upper-basis consequence

GHKK Proposition 8.28 gives the finite full theta basis over Q for the
principal upper algebra. Its integral version follows directly. For
f in the integral upper algebra, take its finite Q-theta expansion. Choose
a remaining full label whose total frozen exponent is minimal. Its leading
monomial can receive no contribution from another remaining theta function:
every nonzero increment raises total frozen exponent, and distinct leading
labels at equal degree are distinct monomials. Thus its rational expansion
coefficient equals an integer coefficient of the initial Laurent expansion
of f. Subtract that integer theta function and continue through the finite
list. Every expansion coefficient is integral. Since the theta functions
themselves are universally integral, this proves an integral full basis.

Frozen translation then groups the full Z-basis into an R0=Z[y^(+/-1)]
basis indexed by mutable labels g. This argument does not import Qin's
injective-reachability-specific theorem into a larger scope.

The principal upper-basis statement does not claim A=U for every large
cluster complex. Arbitrary geometric coefficient specialization remains
fully proved in the separate acyclic presentation theorem, where A=U
also follows from Muller's 2014 result.
