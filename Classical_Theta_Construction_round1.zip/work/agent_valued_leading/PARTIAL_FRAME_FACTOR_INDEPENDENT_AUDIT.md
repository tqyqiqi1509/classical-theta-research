# Independent audit: seed certificates for individual coefficient rows

2026-11-13, 09:44 UTC. Classical, arbitrary skew-symmetrizer. This is an
independent check of the cyclic-generic branch's extension beyond a single
global negative frame.

## Statement checked

Suppose a finite positive product of ordinary cluster variables is supplied
with initial principal leading label (g,0). Its computed F-polynomial gives
a finite downward-closed carrier S for theta_g, by classical theta positivity.
For each nonzero p in S put m_p=g+Bp and

    M_p=1+(max_i D_i)|p|_1,
    u_p=M_p m_p+1.

For every such p, supply an ordinary mutation word ending in a cluster with
g-matrix G and F-polynomials F_1,...,F_n, together with a positive integer
vector a. Set v=G a. The certificate condition is

    u_p^T D alpha<0  ==>  v^T D alpha<0
    for all 0<alpha<=p componentwise.                    (1)

The input word and all of (1) can be checked by finite integer operations.
Given the words, existence of a positive a is also a finite rational linear
feasibility problem: require a_i>=1 and each required negative pairing<=-1.
Strict rational feasibility can be scaled to an integer certificate.

Define a formal leading-unit substitution by

    Phi_t(x_i)=x_i product_j F_j(z)^((G^(-1))_(j,i)),
    Phi_t(y_r)=y_r.                                      (2)

Use its coefficient matrix on the local box [0,p], factor it as A_minus
A_plus in the same multiplicative sense C=A_minus A_plus as in the main
theorem, and use T=(A_minus)^(-1) in the signed coefficient recurrence.
Then the resulting a_p is the actual theta coefficient.

## Critical checks

**Integral inverse.** A cluster g-matrix is unimodular. This follows from
the integral sign-coherent g-matrix mutation, or from tropical duality and
the corresponding unimodular C-matrix mutation. Thus G^(-1) in (2) is
integral and every negative power uses only integer binomial coefficients.

**Full labels.** Each principal cluster variable is
x^(g_j) F_j(z), with F_j(0)=1, so its full initial leading label is (g_j,0).
At an interior point of its cluster cone, theta_(g_j,0) is x^(g_j). The
transport from that cone to the initial chart sends x^(g_j) to the cluster
variable. Expressing e_i=sum_j (G^(-1))_(j,i) g_j proves (2), with no
unaccounted frozen monomial. This is exactly the same cluster-chamber
argument used in the audited global negative-frame case.

**Sufficiency of the one-sided condition.** For a hyperplane whose u_p
pairing is negative, (1) puts both v and u_p strictly on its negative side.
The segment joining them cannot cross it. Hence the seed-cone-to-u_p
transport has only u_p-positive root increments. The segment from u_p to
the initial positive chamber has only u_p-negative root increments.
Coordinate transport composes in the order

    Phi_t=(u_p to initial) composed with (seed t to u_p).

Thus its matrix has the required decomposition C=A_minus A_plus. The
finite integer uniqueness proof identifies A_minus with the actual u_p
to initial transport, so its inverse is the needed comparison map.

**No extra genericity requirement on v.** The point v lies in the interior
of a cluster cone, so no nontrivial wall contains it. It may lie in an
additional hyperplane of the finite containing arrangement that carries no
wall there. In the comparison proof, perturb v inside the cluster cone to
avoid these extra hyperplanes; the strict conditions in (1) survive. Such
a perturbation is not data evaluated by the integer algorithm.

**Local truncation is sufficient.** Every increment contributing to row p
lies componentwise between 0 and p. The interval [0,p] is downward closed
and closed under taking intermediate indices. All larger increments leave
the interval forever. Therefore conditions for 0<alpha<=p, and the local
coefficient matrix on [0,p], suffice. No uniform global height enlargement
is needed for this row.

**Extraction.** The chosen u_p has the same nonzero sign as m_p against
every relevant D alpha, because the positive perturbation is less than M_p.
The backwards ray from the u_p chart in direction m_p therefore meets no
relevant hyperplane. The already audited last-bend argument gives the same
zero equation at every nonzero p and the same finite signed path recurrence.

## Carrier and scope

The carrier is supplied independently by a finite positive product of
cluster variables with leading label g. Additive closure of the classical
theta index set ensures that theta_g exists as a regular theta function;
positive multiplication and the full principal leading exponent give its
coefficient one and bound its support by the product. This argument does
not require a complete negative frame.

The theorem is conditional on the explicit carrier and the finite seed
certificates for every needed row. It does not assert that these certificates
exist for every B and g, and it does not assert termination of an unrestricted
search through mutation words. A complete negative frame automatically
supplies all row certificates, recovering the main theorem.

For a fixed g,p and sign cell of u_p, any two valid seed certificates yield
the same A_minus and the same inverse row: both equal the same comparison
transport. Thus certificate choices affect computation, not the recovered
coefficient or its local inverse row.

## Result

PASS: full-exponent normalization, integral generator formula, sign
condition, factor order, local truncation, and final extraction. This adds
a genuine general certificate mechanism; it makes no unsupported global
existence claim.
