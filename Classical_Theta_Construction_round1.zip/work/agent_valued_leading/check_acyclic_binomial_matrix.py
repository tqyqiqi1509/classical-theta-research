"""Independent exact check: recursive frame series versus closed binomial C."""
from itertools import product
from math import comb, gcd, prod
from random import Random
from pathlib import Path
import json
import time


def choose(n, k):
    if k < 0:
        return 0
    if n >= 0:
        return comb(n, k) if k <= n else 0
    return (-1) ** k * comb(k - n - 1, k)


def mul(a, b, cap):
    out = {}
    for u, x in a.items():
        for v, y in b.items():
            w = tuple(i+j for i,j in zip(u,v))
            if all(i<=j for i,j in zip(w,cap)):
                out[w] = out.get(w,0) + x*y
    return {u:x for u,x in out.items() if x}


def power(a, exponent, cap):
    zero = (0,)*len(cap)
    h = dict(a)
    assert h.pop(zero, 0) == 1
    out = {zero:1}
    term = {zero:1}
    for k in range(1,sum(cap)+1):
        term = mul(term,h,cap)
        if not term:
            break
        coefficient = choose(exponent,k)
        for u,x in term.items():
            out[u] = out.get(u,0)+coefficient*x
    return {u:x for u,x in out.items() if x}


def direct(B,g,q,r):
    n=len(g)
    zero=(0,)*n
    H=[None]*n
    for i in reversed(range(n)):
        temp={zero:1}
        for j in range(i+1,n):
            temp=mul(temp,power(H[j],-B[j][i],r),r)
        H[i]={zero:1}
        for u,c in temp.items():
            v=list(u)
            v[i]+=1
            v=tuple(v)
            if all(a<=b for a,b in zip(v,r)):
                H[i][v]=H[i].get(v,0)+c
    result={zero:1}
    for i in range(n):
        k=g[i]+sum(B[i][j]*q[j] for j in range(n))
        result=mul(result,power(H[i],-k,r),r)
    return result.get(tuple(r),0)


def closed(B,g,q,p):
    return prod(choose(-g[i]-sum(B[i][j]*p[j] for j in range(i))
                       -sum(B[i][j]*q[j] for j in range(i+1,len(g))),p[i]-q[i])
                for i in range(len(g)))


def main():
    rng=Random(20261113)
    cases=[]
    start=time.monotonic()
    for serial in range(240):
        n=rng.randrange(2,5)
        D=[rng.randrange(1,6) for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                e=D[i]*D[j]//gcd(D[i],D[j])*rng.randrange(0,3)
                B[i][j]=e//D[i]
                B[j][i]=-e//D[j]
        g=[rng.randrange(-4,5) for _ in range(n)]
        q=[rng.randrange(0,3) for _ in range(n)]
        r=[rng.randrange(0,3) for _ in range(n)]
        p=[a+b for a,b in zip(q,r)]
        x=direct(B,g,q,r)
        y=closed(B,g,q,p)
        if x!=y:
            cases.append(dict(serial=serial,B=B,D=D,g=g,q=q,p=p,direct=x,closed=y))
    output=dict(seed=20261113,trials=240,rank_range=[2,4],symmetrizer_range=[1,5],
                failures=cases,elapsed_seconds=round(time.monotonic()-start,3),
                method="Exact integer truncated series using recursive H, compared to closed binomial matrix entries")
    Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2))
    print(json.dumps(output))
    assert not cases


if __name__=='__main__':
    main()
