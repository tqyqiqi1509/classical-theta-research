# Independent proof: arbitrary block-constant foldings and negative-chamber carriers

**Date:** 2026-11-13, 10:03 UTC. **Scope:** classical principal coefficients. The core theorem assumes a skew-symmetric cover with a supplied negative cluster frame. An explicitly separated extension replaces that frame by a finite negative-product certificate. Neither statement uses a 2026 result or a Li–Pan conclusion.

This note independently verifies the normalization and the essential carrier identification in `work/agent_cyclic_generic_bridge/FOLDING_CHAIN_EXTENSION.md`. Its output is a finite integer construction of every principal theta function of the folded exchange matrix. An upper-cluster-algebra spanning claim requires an additional basis theorem.

## 1. Core input and normalization

Let \(\widetilde B\) be a skew-symmetric integer matrix. Partition its vertices into nonempty sets \(O_a\), of arbitrary sizes \(r_a\), and require the strong block-constant condition

\[
\widetilde B_{ij}=b_{ab}\qquad(i\in O_a,\ j\in O_b).
\]

Here \(b\) is skew-symmetric; all entries inside an orbit vanish. The product of the symmetric groups of the blocks satisfies the independent-representative condition in Zhou's equation (3.1). This condition is substantially stronger than simultaneous permutation invariance of a quiver.

Use this project's column convention

\[
\widetilde z_i=\widetilde y_i\prod_j\widetilde x_j^{\widetilde B_{ji}}.
\]

Put

\[
\boxed{\bar B_{ab}=r_a b_{ab}},\qquad
L=\operatorname{lcm}_a r_a,\qquad
\boxed{\bar D=\operatorname{diag}(L/r_a)}.
\]

Then \(\bar D\bar B=L b\) is skew-symmetric. Under the monomial map

\[
\sigma(\widetilde x_i)=X_a,\quad
\sigma(\widetilde y_i)=Y_a\quad(i\in O_a),
\]

one has exactly

\[
\sigma(\widetilde z_i)=Z_a,
\qquad Z_a=Y_a\prod_c X_c^{\bar B_{ca}}.
\]

Indeed the exponent of \(X_c\) on the left is \(\sum_{j\in O_c}\widetilde B_{ji}=r_c b_{ca}\). Thus the orbit size scales the **row** in our convention. This computation fixes the convention without relying on a paper's exchange-matrix transpose. If \(P_{ai}=1_{i\in O_a}\), the same statement is the exact matrix identity \(P\widetilde B=\bar B P\).

Zhou's folded mutable character lattice has basis \(f_a=e_a^*/r_a\). His averaging map sends \(e_i^*\) to \(f_a\), so his map \((s^*,q)\) is precisely the integral monomial map \(\sigma\) in these coordinates. There are no fractional powers of the variables \(X_a\). His column-scaled seed matrix uses the dual convention: writing it as \(\epsilon_{ab}=b_{ab}r_b\), the present column-root-monomial convention is \(\bar B=-\epsilon^T\), hence \(\bar B_{ab}=r_a b_{ab}\). Both the root monomial identity and the initial simultaneous orbit exchange verify this conversion: a cover mutation at \(i\in O_a\), after applying \(\sigma\), has exponents \(r_c b_{ca}=\bar B_{ca}\) in the variables \(X_c\).

For an endpoint with folded coordinates \(Q_a\), its invariant cover lift has coordinates \(Q_a/r_a\) at vertices in \(O_a\). For a positive cover charge \(n\), with folded charge \(\bar n=Pn\), its pairing with that lift is

\[
\sum_i n_i\frac{Q_{a(i)}}{r_{a(i)}}
=\frac1L\bar n^T\bar D Q.
\]

Thus signs in the target chain formula are exactly those defined by \(\bar D\), including unequal orbit sizes.

## 2. Negative-orthant monomial lemma, independent proof

**Lemma.** Let \(B\) be any skew-symmetrizable exchange matrix, with positive diagonal \(D\) and \(DB\) skew-symmetric. In its principal positive-root diagram, let the mutable part of a theta label be \(m\le0\) coordinatewise, and let the endpoint \(Q\) have strictly negative mutable coordinates. Then the theta expansion at \(Q\) is the single initial monomial. The negative orthant need not be a cluster chamber.

**Proof.** Suppose an admissible broken line has at least one bend, with successive nonzero positive root increments \(n_1,\ldots,n_k\). Positive multiplicities are included in these vectors. Let \(N_j=n_1+\cdots+n_j\). After the \(j\)-th bend the mutable exponent is \(m+BN_j\), so the velocity is \(-m-BN_j\).

At the first bend, \(n_1^TD\gamma=0\). Immediately afterwards the derivative of this pairing is \(-n_1^TDm\ge0\); the quadratic term vanishes by skew-symmetry. Assume the pairing \(N_{j-1}^TD\gamma\) is nonnegative just before the next bend. At that bend \(n_j^TD\gamma=0\), so \(N_j^TD\gamma\ge0\) there. On the following segment,

\[
\frac{d}{dt}N_j^TD\gamma(t)
=-N_j^TDm-N_j^TDBN_j
=-N_j^TDm\ge0.
\]

By induction the final endpoint satisfies \(N_k^TDQ\ge0\). But \(N_k\) is a nonzero vector with nonnegative coordinates, \(D\) is positive diagonal, and \(Q<0\), so \(N_k^TDQ<0\), a contradiction. Hence no bent line exists. The straight line remains in the negative orthant and contributes precisely its initial monomial. Frozen coordinates do not enter any normal pairing. This also treats labels on the boundary of the nonpositive orthant. \(\square\)

The argument is the negative-sign version of GHKK Proposition 3.8; it is given here to avoid assuming that a negative chamber belongs to the positive cluster fan. GHKK Theorem 3.5 then gives the formal identity

\[
\boxed{\Phi_{-\to+}(x_i^{-1})=\theta_{(-e_i,0)}}
\]

for every principal seed. This identity does **not** assert finiteness. Finiteness will come from the cover. Zhou explicitly uses the same negative-chamber monomial statement and transport identity on printed page 20 before equation (3.2).

## 3. Core folding theorem with a negative-frame cover

Assume a finite ordinary mutation word on the cover produces a negative cluster frame. Compute its ordinary cluster variables, normalized by their initial leading monomials, as

\[
\widetilde I_i=\widetilde x_i^{-1}\widetilde H_i(\widetilde z),
\qquad \widetilde H_i\in\mathbb Z_{\ge0}[\widetilde z],
\quad \widetilde H_i(0)=1.
\]

The negative-frame comparison gives the cover total transport

\[
\widetilde\Phi(\widetilde x_i^{-1})=\widetilde I_i,
\qquad \widetilde\Phi(\widetilde y_i)=\widetilde y_i.
\]

It is rational and birational, because it is the composition of the supplied ordinary cluster mutations and the final monomial coordinate identification. No orbit-adapted condition on that mutation word is required. The *total* transport is invariant under the product of the block permutation groups: the initial diagram and invariant negative and positive endpoints are invariant, and consistency makes the total map independent of the chosen admissible path. This is the content of Zhou Lemma 3.5.

Zhou's quotient construction, Theorem 2.20 and Theorem 3.2, identifies the quotient diagram with the cluster diagram of the folded seed. Proposition 3.4 and equation (3.2) give

\[
\sigma\circ\widetilde\Phi=\bar\Phi\circ\sigma.
\]

All rationality hypotheses of Proposition 3.4 are therefore met in this core theorem. Choose any \(i\in O_a\), and set

\[
H_a(Z)=\widetilde H_i(\widetilde z_j\mapsto Z_{a(j)}).
\]

Equivariance makes the result independent of the representative. The diagram and the lemma in Section 2 yield

\[
\boxed{\bar\theta_{(-e_a,0)}=X_a^{-1}H_a(Z)}.
\]

These are finite positive polynomials obtained by relabeling already computed cover monomials. This proves the essential carrier identification; it does not infer that identification merely from the assertion that the full theta set is finite.

The target total substitution is therefore

\[
\bar\Phi(X_a)=X_aH_a(Z)^{-1},\qquad
\bar\Phi(Y_a)=Y_a.
\]

## 4. Consequence for the finite integer chain construction

For any target label \(g\in\mathbb Z^n\), the finite positive theta product

\[
M_g=X^{[g]_+}\prod_a\bar\theta_{-e_a}^{[-g_a]_+}
=X^g\prod_a H_a(Z)^{[-g_a]_+}
\]

contains \(\bar\theta_g\) with coefficient one in the principal homogeneous expansion. Theta multiplication positivity then bounds every coefficient of \(\bar\theta_g\) by the corresponding coefficient of this finite carrier. Consequently the box

\[
d_b=\sum_a[-g_a]_+\deg_{Z_b}H_a,\qquad J=[0,d]
\]

contains the entire theta support. The input needed by the finite chain formula is the integer unitriangular matrix

\[
C_{pq}=[Z^{p-q}]\prod_a H_a(Z)^{-(g+\bar Bq)_a},\qquad q\le p\in J.
\]

Every entry is obtained by truncated integer binomial multiplication. For each \(p\), use the strict halfspace

\[
I_p=\{p\}\cup\{q\le p:(g+\bar Bp)^T\bar D(p-q)<0\}.
\]

The inverse row of \(C[I_p,I_p]\), or equivalently its finite signed strict-chain expansion, gives the same coefficient recursion proved in `ACYCLIC_BINOMIAL_SEGMENTED_CHAIN_FORMULA.md` and `work/agent_cyclic_generic_bridge/HALFSPACE_CHAIN_FORMULA.md`. The acyclic closed binomial formula for \(C\) is not asserted here; its replacement is the finite polynomial coefficient computation displayed above.

The executable construction uses an integer cover matrix, a finite mutation word, orbit relabeling, finite integer polynomial arithmetic, and finite chains with integer weights. Scattering diagrams and broken lines occur only in the comparison proof.

## 5. Separate enhancement: a negative-product cover suffices

This section is not needed for the core negative-frame theorem. It explains why the rationality hypothesis can also be avoided if the cover's negative generators have already been computed by the negative-product construction.

In the proof of Zhou Proposition 3.4, equation (3.3) is first established as an identity of completed monomial modules for every invariant completed Lie-group element. Rationality is used only afterwards to express the resulting identity as an equality of function-field maps. The following calculation makes the formal statement explicit.

An invariant Lie-algebra basis consists of orbit sums \(\sum_{n'\in\Pi n}z^{n'}\). Acting on a cover monomial of mutable exponent \(m\), and then applying \(\sigma\), its coefficient is

\[
\sum_{n'\in\Pi n}\langle n',m\rangle
=|\Pi n|\sum_a\frac{(Pn)_a(Pm)_a}{r_a}.
\]

The equality follows because the average of \(n'\) has constant coordinate \((Pn)_a/r_a\) on block \(O_a\). The quotient of the orbit sum is \(|\Pi n|z^{Pn}\). The folded action on the mutable basis \(e_a^*/r_a\) has precisely the pairing on the right. Root monomials intertwine by Section 1, and frozen monomials are fixed. Thus the Lie action intertwines. Exponentiation in every finite root-height quotient, followed by the inverse limit, proves the completed-group identity. This argument uses no rational inverse for the total map.

The orbit-sum map preserves total root height, so substitution in completed monomial modules is well-defined. If a finite negative-product certificate on the cover supplies the finite polynomials \(\widetilde H_i\) by the already proved rootwise reconstruction, the formal identity gives exactly the same finite folded \(H_a\). Section 2 then identifies them with the target negative theta generators, and Section 4 applies without change. This is a proved formal enhancement, not an application of Proposition 3.4 with an omitted rationality hypothesis.

## 6. Precise algebra scope and literature review record

The result constructs every principal theta function and shows that all labels occur in the finite theta set for this folded class. It gives the theta basis of the corresponding middle algebra. Equality with the entire upper cluster algebra must be supplied separately. In particular, Zhou Theorem 3.7 concerns the full theta set; it is not by itself an upper-basis theorem. Zhou Theorem 1.1 and its proof in Section 5 give the stronger principal Markov statement. Coefficient-free specialization in this cyclic regime cannot be imported from the acyclic BFZ presentation argument; Zhou Theorem 1.3 expressly distinguishes the coefficient-free Markov upper ring from its theta span.

Primary source reviewed: Yan Zhou, *Cluster Structures and Subfans in Scattering Diagrams*, SIGMA 16 (2020), 013, https://sigma-journal.com/2020/013/sigma20-013.pdf, especially strong condition (3.1), Theorems 2.20 and 3.2, Proposition 3.4 and its equation (3.3), Lemma 3.5, printed-page-20 negative-chamber argument and equation (3.2). The lattice formulas on printed pages 17–18 and the statement on printed page 20 were also inspected as rendered PDF pages, to distinguish overbarred and unbarred notation.

Related primary source: Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, https://arxiv.org/html/1411.1394v2, Theorem 3.5 and Proposition 3.8.

Audit outcomes: **PASS** strong block-constant quotient hypothesis; **PASS** arbitrary-size row normalization and normal pairing; **PASS** negative-orthant monomial lemma; **PASS** rational transport comparison for a negative-frame cover; **PASS** formal Lie-action extension for a negative-product cover; **NOT CLAIMED** upper-algebra spanning for every folded target or arbitrary-coefficient base change in this cyclic regime. No 2026 assertion was used.
