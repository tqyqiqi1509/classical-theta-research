# An acyclic valued quadratic support bound from finite-field Hall counts

**Route status at 2026-11-13 10:05 UTC:** retained as a backup research
derivation, not used by the final finite-chain construction. The elementary
arithmetic Laurent lemma, species Hall count, framed-functor count, sink
argument, and weighted matrix identities received independent checks.
Before citing this route as a complete quantum comparison proof, the
all-valued quantum adjacent-chamber/one-step-cluster identification and
regular specialization of every negative-pairing wall action must be
written with their precise foundational hypotheses. The main classical
chain theorem bypasses these two remaining exposition gates entirely.

2026-11-13. Proposed independent proof for root review. The aim is precisely
the missing classical support inequality needed by the finite integer
reconstruction, not a claim of coefficientwise quantum positivity.

## 1. Statement

Let B be an acyclic skew-symmetrizable integer matrix, ordered so B_ij>=0
for i<j, and let D=diag(D_i) be a positive integral symmetrizer. Put

    A=[-B]_+, C=I-A, U=C^T D,
    g_d=-C d,
    Q_d(p)=(d-p)^T U p.

For the classical principal theta polynomial F_(g_d), the claim is

    [z^p] F_(g_d) != 0  ==>  Q_d(p)>=0.                 (1)

If Q_d(p)=0, its classical coefficient is0 or1. No assumption that the
valued quantum theta coefficients are coefficientwise nonnegative enters
the proof. They may have negative internal coefficients.

The proof below establishes only the acyclic comparison ingredients needed
for (1). It avoids importing the arbitrary-rank positivity theorem of
Qiyue Tang's2026 manuscript. Its framed-Hall idea is borrowed and rederived;
the additional rational-integer-values lemma was supplied independently
by root during this run.

## 2. An elementary arithmetic lemma that closes the Laurent gate

**Lemma.** Suppose f(t) is in Q(t) and f(s) is an integer for an unbounded
sequence of positive integers s at which f is defined. Then f is in Q[t].

Proof. Divide f=P+R/Q with P in Q[t] and deg R<deg Q. Choose a positive
integer L clearing all denominators of P. Then at the prescribed integers,
L(f(s)-P(s)) is an integer tending to0. It is eventually0. Thus R has
infinitely many roots and is0. This does not claim that P has integer
coefficients, which would be false in general. QED.

Consequently, if c(t) is rational and t^(-e)c(t) has integer values on such
a sequence for an integer e, then c(t) is a Laurent polynomial over Q.
This is enough for the implication

    c(t)=c(t^-1), c(t) in Q[t,t^-1], deg_infinity c<0 => c=0.

Bar invariance for a merely rational function would not suffice: for
example1/(t+t^-1) is bar invariant with negative degree at infinity.

## 3. The finite-field species and its rational Hall series

For a prime power q, use vertex fields K_i=F_(q^(D_i)). For i<j put
e_ij=D_i B_ij=D_j A_ji and l_ij=lcm(D_i,D_j). The arrow i->j has the
(K_j,K_i)-bimodule F_(q^l_ij)^(e_ij/l_ij). This is defined because both
D_i and D_j divide e_ij. The resulting acyclic species category is a
finitary hereditary length category. Its Euler form is

    chi(alpha,beta)=sum_i D_i alpha_i beta_i
                    -sum_(i<j) e_ij alpha_i beta_j,
    chi(beta,alpha)-chi(alpha,beta)=alpha^T DB beta.

Write t=sqrt(q), Omega(alpha,beta)=alpha^T DB beta, and use the torus
Z^alpha Z^beta=t^Omega(alpha,beta) Z^(alpha+beta). With the convention
[M]*[N]=sum_E F^E_(M,N)[E], where N is the subobject, Hall integration is

    I([E])=t^chi(dim E,dim E)/|Aut E| Z^(dim E).

Indeed the extension-counting identity is

    sum_E F^E_(M,N)/|Aut E|
       =q^(-chi(M,N))/(|Aut M||Aut N|).

The quadratic exponent in the numerator turns this into precisely the
displayed quantum-torus phase. This calculation needs only the elementary
Hom/Ext counting identity, not a positivity theorem.

For any fixed dimension alpha, the sum over all representations is a
rational function of t: the representation space has q^(sum e_ij alpha_i
alpha_j) points and the vertex group is product_i GL_(alpha_i)(K_i).
All denominators are products of1-t^(-2D_i r), which do not vanish at t>1.

Fix a real stability weight theta and an additive positive rank function.
The unique Harder--Narasimhan filtration gives an ordered factorization of
the total Hall series by slope. Equating a fixed dimension coefficient
computes its semistable series by subtraction of terms with at least two
strictly smaller dimension vectors. This is a finite rational recurrence.
It works identically over every finite field in the displayed species
family. Thus every semistable coefficient is a universal member of Q(t).

At a general point of a wall with primitive positive dimension a, the only
integer dimension vectors of zero stability weight are j a. One may take
the weight irrational within a^perp to enforce this, or use a finite-height
generic perturbation for every calculation. Let C_a be that semistable
subcategory and let

    G_a(z)=sum_(E in C_a) t^chi(E,E)/|Aut E| z^j(E),
    dim E=j(E)a.

The subcategory is abelian and extension closed; its Hall products and
Hom/Ext^1 groups are the inherited ones. Its restricted Euler form is
symmetric because chi(j a,k a)=jk chi(a,a).

## 4. Favorable wall actions have positive highest coefficients and are Laurent

Set delta(a)=gcd_i(D_i a_i). For any positive multiple lambda of delta(a),
we prove

    [z^j] G_a(t^lambda z)/G_a(t^-lambda z)
       is either0 or a Laurent polynomial in Q[t,t^-1]
       with positive highest coefficient.                (2)

Here is a complete framed counting argument. For a simple object S of
C_a, its finite division endomorphism ring is F_(q^epsilon_S). It acts
faithfully on every nonzero vertex space, so

    epsilon_S divides D_i j(S) a_i for every i,
    hence epsilon_S divides delta(a)j(S) and lambda j(S).

In Ind(C_a), take an injective envelope J_S of each simple. Essentiality
and exactness give

    dim_Fq Hom(E,J_S)=epsilon_S [E:S].

The direct sum, over S, of lambda j(S)/epsilon_S copies of the linear dual
Hom(-,J_S)^* therefore defines an exact covariant finite-dimensional
functor F_lambda with dim F_lambda(E)=lambda j(E). For any fixed E only
finitely many summands are nonzero. This construction uses the standard
injective-envelope property of Ind of a small length category; it can also
be confined to its finite-length objects throughout the dimension count.

Let Gen_lambda(E) be the vectors of F_lambda(E) that belong to no proper
subobject image. Exactness preserves intersections. An object over a finite
field has finitely many subobjects, so every vector has a unique minimal
generating subobject. Hence

    q^(lambda j(E))=sum_(U subset E) |Gen_lambda(U)|.

Aut E acts freely on Gen_lambda(E): a fixed vector lies in
F_lambda(ker(g-1)), which forces g=1. Thus |Gen_lambda(E)|/|Aut E| is a
nonnegative integer. Apply Hall integration to the last counting identity:

    G_a(t^lambda z)/G_a(t^-lambda z)
      =sum_E t^(chi(E,E)-lambda j(E))
               |Gen_lambda(E)|/|Aut E| z^j(E).           (3)

For fixed j the power is the common integer
e_j=j^2 chi(a,a)-lambda j. Its coefficient c_j(t) is rational by Section3.
Now restrict the field sizes to squares q=s^2 with s itself a prime power.
Then s^(-e_j)c_j(s) is the nonnegative integer sum of the displayed orbit
counts, for an unbounded sequence of integers s. Section2 implies
c_j(t) in Q[t,t^-1]. If nonzero, it is positive for all sufficiently large
such s, so its highest coefficient is positive. This proves (2).

This proof does not need a polynomial point-count theorem, an identification
with cohomology, or full positivity of quantum coefficients. In particular
it does not infer Laurentness merely from bar invariance or positive
highest degree.

## 5. Why this is the acyclic cluster wall system

The Hall stability diagram is obtained by the positive/zero/negative slope
factorization of the total Hall element. The Harder--Narasimhan identity
proves consistency: between two generic weights the path product is the
ratio of the corresponding positive-slope factors. At every fixed height
there are finitely many dimension vectors and slope chambers; the argument
is a finite Hall identity. This is the content of Bridgeland's general
group-factorization proof, Sections3 and6, and carries over literally to
the finitary species counts because the same HN identity holds.

In the principal exponent coordinates Q, use stability theta=-D Q, so a
wall of dimension a lies in (Da)^T Q=0. Its action is the centered ratio
in (2), with lambda=|a^T D m| on a monomial of mutable exponent m.
Every such lambda is a multiple of delta(a).

The acyclic incoming-wall assertion has an independent direct proof.
Consider a prospective nonvertex charge a at its incoming direction
Q=B a. If the full subquiver on supp(a) has an edge, choose a sink j in
that support having an incoming edge. The full vertex space V_j is a
subrepresentation of every representation of dimension j' a, and

    theta(V_j)=-D_j (B a)_j dim_(K_j)V_j >0.

This violates the convention theta(U)<=0 for semistability. Thus no such
dimension can be semistable at Q=B a. If the support has no edges and has
at least two vertices, every representation is a direct sum of vertex
representations; its semistability locus has codimension at least two and
does not produce a generic wall. Therefore every nonvertex wall is outgoing.

The remaining incoming vertex wall has

    G_(e_i)(z)=Psi_(t^(D_i))(z),

by the elementary GL_j(K_i) count. Rational scattering uniqueness identifies
the integrated Hall diagram with the cluster diagram having these incoming
quantum dilogarithms. No statement that arbitrary genteel quivers have
identical stability and cluster diagrams is used.

**Historical correction.** Bridgeland1603.00416v4 Section11.7 explicitly
retracts the proof of Lemma11.4 (genteel implies equality in general).
Its acyclic Theorem1.5 remains valid by the corrected ordered-path proof.
The stronger sink argument above is specifically acyclic and concerns
semistability, not just the absence of self-stable objects. This avoids the
retracted inference. The field and symmetrizer changes have been displayed
rather than silently importing a complex skew-symmetric theorem.

## 6. Bar, specialization, and positive highest structure coefficients

The initial wall actions commute with bar: bar sends t to t^-1, fixes each
based monomial, reverses products, and sends each Psi to its inverse.
Conjugating all actions by bar gives a rational consistent diagram with
the same incoming data and outgoing supports. Rational uniqueness implies
that every local merged wall action commutes with bar. Hence each selected
coefficient in a favorable action on a based monomial is bar invariant.

By (2), every such coefficient is Laurent over Q and has positive highest
coefficient when nonzero. At each fixed root degree, a theta coefficient is
a finite sum of products of favorable-action coefficients. It is therefore
Laurent over Q, bar invariant, and either0 or positive at infinity.

Laurentness makes specialization at t=1 regular. The specialized incoming
actions are the ordinary classical binomial actions. To check the ray-group
condition explicitly, set A_lambda(z)=G_a(t^lambda z)/G_a(t^-lambda z).
The identity

    A_(lambda+mu)(z)=A_lambda(t^mu z) A_mu(t^-lambda z)

specializes to A_(lambda+mu)=A_lambda A_mu. Thus the specialized action on
a normal coordinate of pairing lambda is the appropriate integer power
of the action at the minimal positive pairing delta(a). It is an ordinary
classical ray automorphism, rather than an arbitrary endomorphism of the
completed torus. Uniqueness of the
consistent completion and finite-height theta sums identify the result with
the classical principal theta series. This assertion uses no quantum
coefficientwise positivity. The classical theta coefficients are integral
and nonnegative by the independently audited classical theorem.

Formal multiplication of theta series has positive highest structure
coefficients. To see this without assuming an unproved algebra basis,
expand a product triangularly in the formal pointed theta family. For a
fixed output label and degree, only finitely many labels matter. Choose a
comparison endpoint close to that output exponent as in the project's
last-bend extraction lemma. The corresponding structure coefficient is a
monomial coefficient of a product of theta series in that chart. All its
nonzero summands are products of positive-highest coefficients and powers
of t. Thus it is0 or positive at infinity. This proves the only positivity
of structure constants used below.

## 7. Standard-product degree comparison proves the classical bound

Use the principal compatible form

    Lambda=[[0,-D],[D,-DB]],
    E_i=(B e_i,e_i), m_i=(-e_i+A e_i,0).

The one-step variable is X^(m_i)+X^(m_i+E_i). Set
M_d=product_(i increasing) (x'_i)^(d_i). Its leading monomial is X^(g_d,0)
with coefficient1. A direct quantum-torus calculation gives its coefficient
at (g_d,0)+E p as

    t^(-R_d(p)) product_i [d_i choose p_i]_(t^(D_i)),
    R_d(p)=sum_(i<j) D_i B_ij(d_i-p_i)p_j.              (4)

Its highest t-degree is

    sum_i D_i p_i(d_i-p_i)-R_d(p)=Q_d(p),              (5)

and its highest coefficient is1.

The formal theta expansion of M_d starts with theta_(g_d) with coefficient1
and has positive-highest remaining structure coefficients by Section6.
At each initially allowed exponent, every nonzero contribution has positive
highest sign. Highest-degree terms therefore cannot cancel. For the theta
coefficient a_p(t), this gives

    deg_infinity a_p(t) <= Q_d(p).

It also forces a_p(t)=0 outside the finite standard box, so finiteness is
obtained without assuming a full valued quantum upper basis. Since a_p(t)
is Laurent and bar invariant, Q<0 implies a_p(t)=0. Specialization gives
(1). If Q=0, a_p(t) is constant; the highest coefficient1 of (4), together
with positive-highest signs, bounds this constant by1. Its classical
integrality makes it0 or1. QED, subject to the explicit root audit requested.

## Sources and adoption boundary

- Qiyue Tang, Hexagon2610.00201v3, Sections2,4.1 and the elementary
  finite-field part of4.2: https://hexagonmath.org/pdf/2610.00201v3.
  The exact-functor/framed-count idea is rederived in Section4 above.
  The paper's general Section5 positivity theorem, all-label quantum basis,
  valued VIT and its Markov results are **not adopted**.
- Tom Bridgeland, Scattering diagrams, Hall algebras and stability conditions,
  arXiv1603.00416v4, Sections3,6 and the2020 erratum Section11.7:
  https://arxiv.org/abs/1603.00416.
  The published2017 PDF omits the subsequent erratum; the v4 text was read.
- Henning Krause, Deriving Auslander's formula, arXiv1409.7051v3,
  Section2: the injective-envelope/Ind-category interface used above.
- Rational scattering existence/uniqueness and endpoint transport are the
  same established inputs already used in the main project's comparison
  proof. They are not data evaluated by its integer reconstruction algorithm.

The final classical algorithm still uses only integer boxes, binomial
equations, exact integer series operations and finite weighted paths.
