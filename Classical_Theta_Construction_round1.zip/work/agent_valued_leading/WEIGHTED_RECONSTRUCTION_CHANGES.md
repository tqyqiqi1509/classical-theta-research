# Exact weighted changes to the finite integer reconstruction

**Route status at 2026-11-13 10:05 UTC:** superseded in the main construction
by the direct total-transport matrix and halfspace-chain formula. The
identities and computations below remain valid; this older reconstruction
is conditional on the backup Hall comparison gates recorded at the start
of `ACYCLIC_VALUED_QUADRATIC_BOUND.md`. No unclosed 2026 positivity claim is
being used in the final classical theorem.

2026-11-13. This is the algebraic extension conditional only on the separately
written acyclic-valued quadratic support theorem, currently under root review.
All classical finite-theta/VIT/freezing inputs are already available in their
skew-symmetrizable scope in the main project.

Let D be a positive integral symmetrizer and topologically order B. Set

    A=[-B]_+, C=I-A, U=C^T D,
    g_d=-C d,
    V=C^(-1)B,
    L=I-V=U^(-T)U,
    T=-L^(-1)=-U^(-1)U^T.

The matrices C^(-1),V,L,T are integral. U and its inverse need not be
unitriangular/integral respectively; U^(-1)=D^(-1)C^(-T) is entrywise
nonnegative, which is the property used. L is unimodular because det L=1.
The exact identities are

    DB=U^T-U,
    L^T U=U^T,
    L^T U L=U.

For d=Na+s and h_r=g_d+B r, the bounded-root interior formulas are

    c_r=d-Vr, v_r=0, sigma(r)=d+Lr,
    Q_d(r)=d^T U r-r^T U r,
    Q_d(d+Lr)=-d^T U r-r^T U r.

For a general actual capacity decomposition h_r=v_r-C c_r and
e=d-r-c_r>=0, the thin-far-corner identity becomes

    U r=-D v_r-U^T e,
    r=-U^(-1)D v_r+T e <= T e.

Thus the signed-cancellation argument and all four explicit constants in
GENERIC_LARGE_LABEL_PREFIX_RIGIDITY.md remain valid with this U,V,L,T.
Every nonzero slope lambda(r)=a^T U r is an integer, so its absolute value
is at least1. The finite genericity condition is weighted:

    lambda(q)=a^T U q=(C a)^T D q=-u^T D q !=0.

Here u=-C a on the active set. The capacity recursion itself is unchanged:
d_i=[-g_i+sum_(j<i) A_ij d_j]_+.

## Adjusted integer reconstruction parameters

Use

    C_B=max_i sum_j (C^(-1))_ij,
    D_max=max_i D_i,
    K=sum_i d_i,
    M=1+max(D_max K,C_B),
    u_p=M(g+Bp)+1.

Then for every positive q with |q|<=K,

    q^T D u_p=M q^T D(g+Bp)+sum_i D_i q_i.

This has the required sign when the first pairing is nonzero, and is
positive when it is zero. Capacity-chamber walls still have nonnegative
path-count normals bounded by C_B, so the same u_p also avoids those walls.

For h in {0,e_i}, the active set of Nu+h is stable for N>C_B. On it

    a=d(u)_I, s_h=-C_I^(-1)h_I,
    d(Nu+h)_I=Na+s_h, (Nu+h)_I=-C_I(Na+s_h).

Take the common N at least the weighted generic-prefix threshold for all h,
and also

    N >= max(C_B+1, 1+D_max K(1+K max|B_ij|)).

Indeed |q^T D(h+Bp)|<=D_max K(1+K max|B_ij|), whereas the weighted integer
pairing q^T D u is nonzero. This verifies the same finite last-bend comparison.

The bounded integer-array search still uses the **classical** binomial
majorant product_i binom(c_i,p_i), ordinary neighbor divisibility, and now
the weighted zero condition Q_c(p)=(c-p)^T U p<0. No quantum coefficient
or finite-field object is an input to the algorithm.

The ratio R_i, substitution exponent g+Bq, fixed frozen variables,
unitriangular inverse T^(u,g), and final finite weighted-path recurrence are
unchanged. The comparison proof's normals are D alpha rather than alpha;
this is exactly why D_max appears in the explicit parameters above.

## Independent arithmetic verification

Wolfram checked1000 randomly generated acyclic skew-symmetrizable matrices
of ranks2--6, with genuinely varying symmetrizers, for all displayed matrix
identities, integrality of L, and the far-corner quadratic identity. The
result was {1000,0,{}}. This is an implementation guard; the algebraic
derivations above are the proof.
