# Acyclic theta reconstruction with arbitrary geometric coefficients

2026-11-13. Classical skew-symmetrizable cluster algebras; frozen variables
are invertible. The theorem below extends the principal-coefficient finite
integer construction to every geometric coefficient matrix, including no
coefficients. It uses a complete acyclic presentation to justify base change.

## 1. Statement and explicit output

Let B be an acyclic skew-symmetrizable n by n integer matrix, and let
Gamma be any m by n integer matrix of frozen coefficients. Put

    R0=Z[y_1^(+/-1),...,y_n^(+/-1)],
    R =Z[f_1^(+/-1),...,f_m^(+/-1)],
    a_i=f^[Gamma e_i]_+,   b_i=f^[-Gamma e_i]_+,
    c_i=a_i/b_i=f^(Gamma e_i).

Let A_Gamma be the ordinary geometric cluster algebra of the extended
matrix (B;Gamma), over R. Its initial one-step exchange is

    x_i X_i'=a_i P_i(x)+b_i Q_i(x),
    P_i=product_j x_j^[B_ji]_+,
    Q_i=product_j x_j^[-B_ji]_+.

For every g in Z^n, compute the principal polynomial

    F_g(z)=sum_p a_(g,p) z^p

by the finite negative-frame signed-path algorithm. Since B is acyclic,
the required negative frame always has an explicit sink-order word; no
word-existence search is needed. Define

    Theta_g^Gamma(x,f)
      =sum_p a_(g,p) x^(g+Bp) f^(Gamma p).                (1)

**Theorem.** The family (Theta_g^Gamma)_(g in Z^n) is an R-basis of
A_Gamma. Each element is a finite Laurent polynomial and is universally
positive in every cluster. Its multiplication structure coefficients are
Laurent polynomials in the frozen variables with nonnegative integral
coefficients. Moreover A_Gamma equals its upper cluster algebra.

This holds without a rank condition on B or (B;Gamma), without a coprimality
condition on the specialized exchanges, and even when Gamma=0. In that case
R=Z and formula (1) is the coefficient-free basis. Roots p producing the
same specialized monomial are simply combined by adding their integer
coefficients; this does not destroy basis independence.

The family in (1) fixes the principal normalization. It contains every
ordinary cluster monomial up to a frozen monomial unit. An optional explicit
normalization in Section 5 makes the cluster monomials themselves members.

## 2. The acyclic presentation makes base change exact

BFZ Theorem 1.16, Corollary 1.17 and Theorem 1.20 imply, respectively,
standard-monomial freeness, the complete relation ideal, and A=the initial
lower bound for an acyclic seed. The last statement does not assume coprimality.
Consequently the principal algebra has presentation

    A_prin = R0[x_1,u_1,...,x_n,u_n] /
             (x_i u_i-y_i P_i-Q_i : 1<=i<=n),            (2)

and the actual coefficient algebra has presentation

    A_Gamma = R[x_1,X_1',...,x_n,X_n'] /
              (x_i X_i'-a_i P_i-b_i Q_i : 1<=i<=n).      (3)

Define sigma:R0->R by sigma(y_i)=a_i/b_i. Since all b_i are frozen
monomial units, the base-changed presentation (2) is isomorphic to (3) by

    x_i -> x_i,             u_i -> b_i^(-1) X_i'.        (4)

Indeed the ith relation in (2) maps to

    b_i^(-1)(x_i X_i'-a_i P_i-b_i Q_i).

The inverse sends X_i' to b_i u_i. Thus there is an actual R-algebra
isomorphism

    A_prin tensor_(R0,sigma) R  ~=  A_Gamma.             (5)

This proof uses the complete finite presentation, so it neither assumes
that tensor products preserve an intersection of Laurent rings nor assumes
that coefficient specialization is flat. A statement about an arbitrary
coefficient specialization of a general upper cluster algebra is unnecessary.
The theorem is restricted to the displayed geometric Laurent rings, where
the exchange binomials are nonzero and the frozen units exist.

## 3. Why the theta basis survives specialization integrally

The established principal classical theta basis is an integral basis on
full exponent labels (g,r) in Z^n direct-sum Z^n. Frozen translation gives

    theta_(g,r)=y^r theta_(g,0).

Grouping this full Z-basis by g proves directly that (theta_(g,0))_g is
an R0-basis of A_prin: a finite R0-relation expands into a finite relation
among distinct full theta labels, and every full label is a frozen translate
of one of these representatives. Here A_prin=U_prin by acyclicity and the
principal full-rank/coprime presentation. Qin's Appendix A.1 explicitly uses
the classical ground ring Z, so no unproved descent from a rational basis
is involved.

Tensoring the free module decomposition gives

    (direct-sum_g R0 theta_(g,0)) tensor_R0 R
       ~= direct-sum_g R (theta_(g,0) tensor 1).

Under (5), theta_(g,0)=x^g F_g(y_j x^(B e_j)) maps exactly to (1).
This proves spanning and linear independence over R, including when
specialization identifies different Laurent exponents. No division by a
specialized coefficient or by a possibly vanishing determinant occurs.

### Relation to the standard-monomial change of basis

BFZ supplies a second R0-basis, consisting of the products

    S_a=product_i x_i^[a_i]_+ u_i^[-a_i]_+,   a in Z^n.

For topological order B_ij>=0 when i<j, put A=[-B]_+. The initial principal
leading mutable label of S_a is

    g(a)=a+A[-a]_+.

The map a->g(a) is bijective: its inverse is obtained recursively from
d_i=max(-g_i+sum_(j<i)A_ij d_j,0), v=g+(I-A)d, then a=v-d.
On the full labels, positive theta multiplication gives a unit-leading
root-triangular change from y^r S_a to the full theta family. The coefficient
at its leading full label is exactly one.

For base change one must use the stronger algebraic fact that both are
actual bases, not only a formal infinite triangular array. Each standard
monomial is a finite theta combination; each theta element is a finite
standard-monomial combination by (2) and BFZ straightening. Their two
change-of-basis matrices are column-finite and are mutual inverses. Every
entry of either matrix product is a finite sum. Applying sigma therefore
preserves both inverse identities. The specialized standard monomials are
the actual standard monomials multiplied by frozen units via (4), hence
are still an R-basis. The specialized theta family is consequently a basis.

This argument also explains why a naive claim that a mutable-label order
survives specialization is not needed: B or (B;Gamma) can have a kernel,
and full root labels can coalesce after forgetting the principal coefficients.

## 4. Positivity survives in every seed and in multiplication

For principal coefficients the multiplication coefficients relative to
(theta_(g,0)) are nonnegative Laurent polynomials in y. The map
y_i->f^(Gamma e_i) sends such a polynomial to a nonnegative Laurent
polynomial in f. Applying the algebra isomorphism (5) proves the claimed
positive multiplication for (1). Multiple monomials that become equal add
their coefficients, with no sign cancellation.

Universal Laurent positivity also survives. Fomin--Zelevinsky IV,
Theorem 3.7, gives for every mutation word and every principal cluster
variable X_(i,t) a frozen monomial unit eta_(i,t) with

    sigma(X_(i,t))=eta_(i,t) X_(i,t)^Gamma.               (6)

Explicitly eta is the F-polynomial evaluated in the tropical coefficient
semifield Trop(f). The theorem's proof is the elementary exchange induction
in Section 3; no positivity conjecture from that paper is being invoked.
Substitute (6) into the positive principal theta Laurent expansion in the
cluster t. Its coefficients and all eta units have positive coefficient one,
so the resulting actual Laurent expansion has nonnegative integral frozen
Laurent coefficients. This works for every t.

## 5. Optional normalization that includes the cluster monomials exactly

For each g and frozen coordinate r define the integer

    nu_r(g)=min_{p:a_(g,p)!=0} (Gamma p)_r.

The support is already known from the finite algorithm, so this is a finite
integer computation. Since p=0 occurs, nu_r(g)<=0. Put

    ThetaHat_g^Gamma = f^(-nu(g)) Theta_g^Gamma.          (7)

This is a frozen-unit rescaling of a basis, so it remains an R-basis.
Its multiplication coefficients remain nonnegative Laurent polynomials;
the structure coefficient at k is multiplied by the unit
f^(-nu(g)-nu(h)+nu(k)). Universal Laurent positivity is also unchanged.

For a cluster label g, the tropical evaluation of its positive F-polynomial
is exactly f^(nu(g)). FZ IV Theorem 3.7/Corollary 6.3 therefore identifies
(7) with the actual cluster monomial. For a single initial mutation,
F_g=1+z_i, nu(g)=-[-Gamma e_i]_+, and (7) multiplies (1) by b_i, giving
the actual X_i' in (3). For coefficient-free algebras Gamma=0, (1) and (7)
coincide.

## 6. Equality A=U and the precise scope

Muller, *A=U for Locally Acyclic Cluster Algebras* (2014), removes the
coprimality condition for acyclic cluster algebras over ZP. His setup
explicitly allows skew-symmetrizable exchange matrices and normalized
coefficients; geometric coefficient Laurent rings are included. The relevant
argument can be summarized completely:

1. If B=0, all mutations commute. For a Laurent monomial exponent alpha,
   use the cluster that mutates exactly the negative coordinates of alpha.
   Membership in its Laurent ring forces the coefficient to be divisible by
   the product of the required exchange factors. This expresses every upper
   element as a standard monomial combination, so A=U even if those factors
   have common divisors.
2. For a nonisolated acyclic seed, choose a source or sink i adjacent to j.
   Its exchange has a frozen-unit term plus a monomial divisible by x_j.
   Rearranging gives 1 in the ideal (x_i,x_j).
3. Freeze i and, separately, j. Both seeds are acyclic of smaller rank.
   By induction their algebras equal their uppers. The standard localization
   sandwich then identifies them with A[x_i^(-1)] and A[x_j^(-1)].
4. These two localizations cover Spec A because (x_i,x_j)=A. Intersecting
   them recovers A; every element of U belongs to each. Thus U is contained
   in A, completing the induction.

Consequently the bases (1) and (7) are bases of both A_Gamma and U_Gamma
in the stated acyclic scope. A mutation-equivalent acyclic seed can be used
instead, followed by the ordinary exchange coordinate change.

For the main theorem on an arbitrary certified negative frame, with no
acyclicity assumption, the established principal result is a theta basis
of U_prin. A negative frame alone is not used here to claim A=U or to
identify U_prin tensor_R0 R with the upper algebra after specialization.
The acyclic presentation (2) is exactly what makes this coefficient extension
conclusive.

## 7. Explicit acyclic frame: no word search and no exact polynomial division

Relabel an acyclic B so B_ij>=0 for i<j and put A=[-B]_+. Mutate vertices
in order n,n-1,...,1. Each vertex is a sink in the sign convention for B.
Its row has only nonpositive off-diagonal entries at that step, so mutation
does not change any other C-column. The terminal C-matrix is -I.

The frame polynomials are computed recursively by

    H_n=1+z_n,
    H_i=1+z_i product_(j>i) H_j^(A_ji),   i=n-1,...,1.   (8)

Each step mutates a previously untouched variable, so its old F-polynomial
is 1. Mutating a sink creates no arrows among the remaining vertices;
therefore the exponents in (8) are exactly the original A_ji. The leading
g-vector is -e_i: the frozen term contributes no mutable leading exponent,
and the unit summand in the exchange gives x_i^(-1).

Formula (8), the matrix sign-factor recurrence, the signed-path recurrence,
and finally (1) or (7) form a finite integer construction for every acyclic
classical skew-symmetrizable cluster algebra with arbitrary geometric
coefficients. This construction has no quantum or geometric representation
theory input in its evaluated data.

## 8. Primary references and precise checks

- BFZ, arXiv:math/0305434v3, Theorem 1.16, Corollary 1.17, Theorem 1.20,
  Corollary 1.21; the statement and proof of Theorem 1.20 were read directly.
  https://arxiv.org/html/math/0305434v3
  Retrieval: turn492view0, turn493view0--3, turn498view0.
  Theorem 1.18 alone has a coprimality hypothesis and is not used to claim
  equality with the specialized upper algebra.
- Qin, arXiv:1902.09507v4, classical ground ring Z in Section 2.1 and
  Appendix A.1.5; full principal theta basis and frozen translates.
  Exact local text was read; public version history: turn488view0.
  https://arxiv.org/abs/1902.09507
- Fomin--Zelevinsky, *Cluster algebras IV: Coefficients*, published Section 3,
  Theorem 3.7 and its exchange-induction proof; Corollary 6.3.
  https://arxiv.org/abs/math/0602259
  Primary published PDF retrieval: turn504view0--2; arXiv v3 history:
  turn503view0. Only the established separation formula is adopted.
- Muller, SIGMA 10 (2014), 094, Sections 2--4, especially Proposition 3,
  Proposition 4 and Corollary 2. The integral coefficient setup and the
  complete localization proof were read directly, not only the abstract.
  https://sigma-journal.com/2014/094/sigma14-094.pdf
  Retrieval: turn499view0, turn500view0; arXiv v4 history: turn499view1.

No 2026 literature assertion or Li--Pan conclusion is a premise here.
