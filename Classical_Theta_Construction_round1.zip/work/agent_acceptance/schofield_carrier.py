#!/usr/bin/env python3
"""Pure integer Schofield recursion and certified finite Newton carriers.

The arithmetic construction uses B,g and integer Euler inequalities. Its
identification with a generic-character polytope is an external theorem.
It is not assumed equal to a theta polytope.
"""
from bipointed_packets import *
from functools import lru_cache

def acyclic_dimension(B,g):
    n=len(g);A=[[max(-B[i][j],0) for j in range(n)] for i in range(n)]
    todo=set(range(n));order=[];d=[0]*n;v=[0]*n
    while todo:
        available=[i for i in sorted(todo) if not any(A[i][j] for j in todo)]
        if not available:raise ValueError('principal matrix is not acyclic')
        for i in available:
            r=g[i]-sum(A[i][j]*d[j] for j in range(n))
            d[i]=max(-r,0);v[i]=max(r,0);order.append(i);todo.remove(i)
    return tuple(d),tuple(v),tuple(order)

class Schofield:
    def __init__(self,B):
        self.B=tuple(map(tuple,B));self.n=len(B);self.checks=0
        self.A=tuple(tuple(max(-B[i][j],0) for j in range(self.n)) for i in range(self.n))
    def euler(self,a,b):
        self.checks+=1
        return sum(a[i]*b[i] for i in range(self.n))-sum(
            self.A[i][j]*a[i]*b[j] for i in range(self.n) for j in range(self.n))
    @lru_cache(None)
    def sub(self,d):
        zero=(0,)*self.n
        if d==zero:return (zero,)
        result=[]
        for e in product(*(range(a+1) for a in d)):
            if e==zero or e==d:
                result.append(e);continue
            diff=tuple(d[i]-e[i] for i in range(self.n))
            if all(self.euler(f,diff)>=0 for f in self.sub(e)):result.append(e)
        return tuple(result)

def rational_feasible(x):
    return [Fraction(float(a)).limit_denominator(1000000) for a in x]

def exact_barycentric(p,vertices):
    n=len(p);A=np.array([list(v)+[1] for v in vertices],dtype=float).T
    b=np.array(list(p)+[1],dtype=float)
    lp=linprog(np.zeros(len(vertices)),A_eq=A,b_eq=b,bounds=(0,None),method='highs')
    if lp.x is None:return None
    active=[i for i,a in enumerate(lp.x) if a>1e-8]
    AA=sp.Matrix.hstack(*(sp.Matrix(list(vertices[i])+[1]) for i in active))
    bb=sp.Matrix(list(p)+[1])
    try:
        sol,params=AA.gauss_jordan_solve(bb)
    except ValueError:return None
    if params.rows:
        subs={s:0 for s in params};sol=sol.subs(subs)
    if AA*sol!=bb or any(a<0 for a in sol):return None
    return [{'i':i,'a':[int(a.p),int(a.q)]} for i,a in zip(active,sol) if a]

def exact_separator(p,vertices):
    # Feasible iff p lies strictly outside conv(vertices); also certifies an
    # exposed vertex when vertices are all other input points.
    A=np.array([[v[i]-p[i] for i in range(len(p))] for v in vertices],dtype=float)
    lp=linprog(np.zeros(len(p)),A_ub=A,b_ub=-np.ones(len(vertices)),bounds=[(None,None)]*len(p),method='highs')
    if lp.x is None:return None
    w=rational_feasible(lp.x)
    if not all(sum(w[i]*(p[i]-v[i]) for i in range(len(p)))>=1 for v in vertices):return None
    return [[a.numerator,a.denominator] for a in w]

def carrier(B,d,cap=30000):
    raw=1
    for a in d:raw*=a+1
    if raw>cap:raise OverflowError('Schofield box cap')
    sc=Schofield(B);S=sc.sub(tuple(d));V=[];witnesses=[]
    if len(S)==1:V=list(S);witnesses=[{'p':S[0],'single_point':True}]
    else:
        for i,p in enumerate(S):
            others=S[:i]+S[i+1:]
            sep=exact_separator(p,others)
            if sep is not None:V.append(p);witnesses.append({'p':p,'normal':sep});continue
            bary=exact_barycentric(p,others)
            if bary is None:raise ArithmeticError('uncertified hull classification')
    points=[];outside=[];inside=[]
    for p in product(*(range(a+1) for a in d)):
        bary=exact_barycentric(p,V)
        if bary is not None:
            points.append(p);inside.append({'p':p,'barycentric':bary})
        else:
            sep=exact_separator(p,V)
            if sep is None:raise ArithmeticError('uncertified lattice containment')
            outside.append({'p':p,'normal':sep})
    return {'d':list(d),'generic_subdimensions':[list(p) for p in S],
            'vertices':[list(p) for p in V],'lattice_points':[list(p) for p in points],
            'vertex_certificates':witnesses,'inside_certificates':inside,
            'outside_certificates':outside,'euler_tests':sc.checks,
            'recursive_domains':sc.sub.cache_info().currsize}

def solve_carrier_packets(B,g,C,seconds=15):
    points=[tuple(p) for p in C['lattice_points'] if in_container(B,g,p)]
    vertices=list(map(tuple,C['vertices']))
    if not all(v in points for v in vertices):raise AssertionError('required vertex outside initial local carrier')
    M=build(B,g,points)
    required=[v for v in vertices if any(v)]
    R=coo_matrix((np.ones(len(required)),(np.arange(len(required)),[M['ids'][v] for v in required])),
                 shape=(len(required),len(M['columns']))).tocsc()
    M['A']=vstack([M['A'],R]).tocsc();M['b']=np.r_[M['b'],np.ones(len(required))]
    lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':seconds})
    out={'points':len(points),'columns':len(M['columns']),'lp_status':int(lp.status)}
    F=exact_primal(M,lp.x)
    if lp.x is not None:out['dual']=finite_dual(M,lp.eqlin.marginals)
    if F is None:
        mi=milp(M['c'],integrality=np.ones(len(M['columns'])),bounds=Bounds(0,np.inf),
            constraints=LinearConstraint(M['A'],M['b'],M['b']),options={'time_limit':seconds})
        out['milp_status']=int(mi.status);F=exact_primal(M,mi.x)
    if F is not None:
        if not all(F.get(v)==1 for v in vertices):raise AssertionError('vertex coefficients')
        out['F']=dump_table(F);out['mass']=sum(F.values())
        dual=out.get('dual',{})
        if dual.get('valid') and Fraction(*dual['value'])==out['mass']:
            cols=dual['zero_slack_columns'];rank=rank_mod_sparse(M['A'],cols)
            out['uniqueness']={'rank':rank,'columns':len(cols),'prime':1000003,'unique':rank==len(cols)}
    return out,F,M

if __name__=='__main__':
    import time
    tic=time.time();root=Path(__file__).resolve().parents[1];out=[]
    for name in ['noncluster_failure_00355.json','rank4_all_mass_minima.json']:
        a=json.loads((root/'agent_mass'/name).read_text());B,g=a['B'],a['g']
        opp=opposite_certificate(B,g,list(range(len(g))))
        C=carrier(B,opp['d']);R,F,M=solve_carrier_packets(B,g,C)
        item={'B':B,'g':g,'opposite':opp,'carrier':C,'packet_result':R};out.append(item)
        print(name,'genericdims',len(C['generic_subdimensions']),'vertices',len(C['vertices']),
              'latticepoints',len(C['lattice_points']),'mass',R.get('mass'),'unique',R.get('uniqueness'),flush=True)
    (Path(__file__).parent/'schofield_packet_repairs.json').write_text(json.dumps(out,indent=2))
    print('seconds',time.time()-tic)
