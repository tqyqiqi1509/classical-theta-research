# Two-sided finite boundary constraints and their exact mutation rule

Date: 2026-11-13. Classical skew-symmetrizable matrices only.
This is a constructive finite boundary mechanism. It does not yet give an
all-seed acceptance theorem or identify the selected elements with theta.

## 1. Laurent membership is already finite

For principal coefficients, the extended matrix E=(B;I) has full column rank.
BFZ, Cluster algebras III, Theorem 1.5, Proposition 1.8 and Corollary 1.9 show
that the upper bound (the intersection of the initial Laurent ring and its
n immediate neighbors) equals the upper cluster algebra U. The proof uses
rank preservation and pairwise coprimality of exchange binomials. Therefore
our initial positive packet equations already imply f belongs to U. They do
not imply universal positivity or compatible pointedness.

Primary source: https://arxiv.org/abs/math/0305434, pp.4--5 and23--25.
The original text and the rank/coprimality proof were directly checked.

## 2. An integer certificate for an opposite word

For an extended exponent v, define the usual tropical mutation

    phi_k(v)_k = -v_k,
    phi_k(v)_i = v_i + [E_ik]_+ v_k - E_ik min(v_k,0), i != k.

Given a finite word w, calculate its matrix E_w and the vectors phi_w(e_i).
Let psi_w be the integer matrix with those vectors as columns. Check

    det(psi_w) = +/-1,
    psi_w E = - E_w P,

where P is a permutation matrix. These are finite exact integer checks.
They certify that the linear leading-degree map reverses dominance order.
No unsupported recognition of a reddening sequence is needed by the code.

For v=(g,0), put eta=psi_w^{-1} phi_w(v). If eta-v=E d with d>=0, then
any f=x^g F(z) in U with F(0)=1 is compatibly pointed at the initial seed and
w **if and only if**

    Supp(F) subset {0<=p<=d},     [z^d]F=1.

The equivalence is the elementary degree/codegree swap: initial monomial
degrees transform linearly by psi_w at their leading terms; order reversal
makes the unique initial minimal degree into the unique target maximal
degree. Invertibility prevents cancellation of distinct extremal terms.
This independently implements Qin's Proposition3.3.12 and3.4.8, rather than
asserting a new theorem of that scope.

Qin's Theorem5.1.2 yields a basis from a full family with these two-chart
properties, but Theorem5.1.3 explicitly treats all-seed pointedness as a
stronger requirement. Thus an opposite word is not an all-seed certificate.
Source: https://arxiv.org/abs/1902.09507v4, Sections3.3--3.4 and5.1.

## 3. A two-sided packet test

Assume a finite polynomial F>=0 has F(0)=1, support in [0,d], and coefficient
1 at d. Set

    h=g+B d,         Fvee(y)=y^d F(y^{-1}).

The same classical exchange polynomials can be described by the opposite
matrix -B (with all extended rows negated). In that description Fvee is the
pointed coefficient factor at the codegree.

Suppose F is in the initial normalized positive packet cone K(B,g). Then
Fvee has positive binomial quotients in all directions automatically:
reversing a positive quotient preserves positivity. Its remaining local
conditions are exactly the reverse degree bounds

    d_k-p_k <= [-h_k]_+ + sum_j [b_kj]_+ (d_j-p_j)
                       for every p in Supp(F) and every k.       (R)

Consequently K(B,g) together with (R), the finite box and the two monic
endpoints is an entirely finite integer packet problem.

## 4. Exact mutation of the paired boundary

Define d' by d'_i=d_i for i!=k and

    d'_k = -d_k + max(
       [g_k]_+ + sum_j [b_kj]_+ d_j,
       [-g_k]_+ + sum_j [-b_kj]_+ d_j).

**One-step theorem.** Under the hypotheses above, (R) for direction k is
equivalent to the statement that the positive normalized mutation F' has
support in [0,d'] and coefficient1 at d'.

Proof. In a fiber with off-k exponent a, write

    P(t)=(1+t)^rminus Q(t),  r=g_k+sum_j b_kj a_j,
    alpha=[-g_k]_+ +sum_j[-b_kj]_+a_j.

The exact target is t^(alpha-rminus)(1+t)^rplus Q(t^-1).
If m is the smallest exponent of P, also the smallest exponent of Q, its
largest target exponent is

    [g_k]_+ +sum_j[b_kj]_+a_j - m.

Bound (R) says precisely that this is at most

    [g_k]_+ +sum_j[b_kj]_+d_j +[-h_k]_+ -d_k = d'_k.

At off-k exponent d_other, reversing P gives the origin fiber of Fvee.
Its constant term is1. Positive division and (R) force this fiber to be
exactly (1+t)^[-h_k]_+. Thus the upper endpoint is attained with coefficient1.
All off-k coordinates remain unchanged. Conversely, the target upper bound
applied to every nonzero fiber is exactly (R). QED.

The matching of labels is an integer identity:

    h'=phi_{-B}(h),  g'=phi_B(g),  h'=g'+B' d'.

For frozen exponents one uses the full extended tropical maps; the same
identity holds. This gives an explicit paired tropical recurrence for the
leading and trailing boundary, independent of a representation model.

The theorem is one-step. It does not prove that the two-sided cone is
preserved under arbitrary mutation; that is the new closure problem.

## 5. Concrete improvement of the existing general construction

For the rank-five skew chain B12=2,B23=B34=B45=1, g=(-2,2,-1,1,1), the
opposite-word computation gives d=(2,2,3,2,1). Intersecting this legitimate
box with the local carrier leaves58 points (the unrestricted local carrier
had163 points). The old mass44 optimum has three terms outside this box.
The finite box/packet optimization has certified minimum46 and is unique:
284 zero-slack columns have rank284 modulo1000003. It equals the candidate
previously found by a two-chart repair.

For the rank-four skew chain B12=4,B23=B34=1 and g=(-1,1,1,1), d=(1,3,2,1).
The finite carrier has15 points, certified minimum25, and59 zero-slack
columns of rank59; it resolves the earlier two equal mass minima.

These examples verify the boundary mechanism; they are not offered as a
replacement for a general closure theorem. Exact outputs are in
`bipointed_repairs.json`, and all computations use `bipointed_packets.py`.
