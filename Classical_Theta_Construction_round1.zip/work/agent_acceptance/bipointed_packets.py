#!/usr/bin/env python3
"""Finite packet constraints with an exactly certified opposite seed.

This is a two-chart criterion, not an all-seed positivity theorem.
All matrices in the opposite-word certificate are exact integer matrices.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import product
from math import comb
from pathlib import Path
import sys, json
import numpy as np
import sympy as sp
from scipy.optimize import linprog, milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix, vstack

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_mass'))
from packet_minimum import build, exact_primal, dump_table
from normalized_fibers import in_container

def mutate_extended(E,k):
    return sp.Matrix(E.rows,E.cols,lambda i,j:
        -E[i,j] if i==k or j==k else E[i,j]+
        max(E[i,k],0)*max(E[k,j],0)-max(-E[i,k],0)*max(-E[k,j],0))

def tropical_step(E,v,k):
    return sp.Matrix([-v[k] if i==k else
        v[i]+max(E[i,k],0)*v[k]-E[i,k]*min(v[k],0)
        for i in range(E.rows)])

def opposite_certificate(B,g,word):
    n=len(g); E0=sp.Matrix(B).col_join(sp.eye(n)); E=E0
    v0=sp.Matrix(list(g)+[0]*n); v=v0
    columns=[sp.eye(2*n)[:,i] for i in range(2*n)]
    for k in word:
        columns=[tropical_step(E,a,k) for a in columns]
        v=tropical_step(E,v,k); E=mutate_extended(E,k)
    psi=sp.Matrix.hstack(*columns)
    det=psi.det()
    if abs(det)!=1:
        return {'valid':False,'reason':'leading_matrix_not_unimodular','det':int(det)}
    # Find a permutation P with psi E0 = - E P.
    Y=psi*E0; permutation=[]
    for j in range(n):
        matches=[i for i in range(n) if Y[:,j]==-E[:,i]]
        if len(matches)!=1:
            return {'valid':False,'reason':'not_order_reversing','column':j}
        permutation.append(matches[0])
    if len(set(permutation))!=n:
        return {'valid':False,'reason':'not_a_permutation'}
    eta=psi.inv()*v; delta=eta-v0; d=delta[n:]
    if any(a.q!=1 or a<0 for a in d) or E0*sp.Matrix(d)!=delta:
        return {'valid':False,'reason':'invalid_support_dimension'}
    return {'valid':True,'word':list(word),'permutation':permutation,
            'psi':[[int(x) for x in row] for row in psi.tolist()],
            'target_extended_B':[[int(x) for x in row] for row in E.tolist()],
            'target_tropical_g':[int(x) for x in v],
            'codegree':[int(x) for x in eta], 'd':[int(x) for x in d]}

def finite_dual(M,dual,max_den=1000000):
    lam=[Fraction(float(a)).limit_denominator(max_den) for a in dual]
    A=M['A'].tocsc(); slacks=[]
    for j in range(A.shape[1]):
        dot=sum((lam[int(i)]*int(round(a)) for i,a in
            zip(A.indices[A.indptr[j]:A.indptr[j+1]],A.data[A.indptr[j]:A.indptr[j+1]])),Fraction(0))
        slack=Fraction(int(M['c'][j]))-dot
        if slack<0:return {'valid':False,'column':j,'slack':str(slack)}
        slacks.append(slack)
    value=sum((Fraction(int(b))*l for b,l in zip(M['b'],lam)),Fraction(0))
    return {'valid':True,'value':[value.numerator,value.denominator],
            'lambda':[[a.numerator,a.denominator] for a in lam],
            'zero_slack_columns':[j for j,a in enumerate(slacks) if not a]}

def rank_mod_sparse(A,cols,prime=1000003):
    A=A.tocsc(); piv={}
    for j in cols:
        v={int(i):int(round(a))%prime for i,a in
           zip(A.indices[A.indptr[j]:A.indptr[j+1]],A.data[A.indptr[j]:A.indptr[j+1]]) if int(round(a))%prime}
        while v:
            r=min(v);a=v[r]
            if r not in piv:
                ia=pow(a,-1,prime);piv[r]={i:z*ia%prime for i,z in v.items()};break
            for i,z in piv[r].items():
                nz=(v.get(i,0)-a*z)%prime
                if nz:v[i]=nz
                else:v.pop(i,None)
    return len(piv)

def dual_label(B,g,d):
    return tuple(g[i]+sum(B[i][j]*d[j] for j in range(len(g))) for i in range(len(g)))

def mutate_support_dimension(B,g,d,k):
    out=list(d)
    out[k]=-d[k]+max(max(g[k],0)+sum(max(B[k][j],0)*d[j] for j in range(len(g))),
                    max(-g[k],0)+sum(max(-B[k][j],0)*d[j] for j in range(len(g))))
    return tuple(out)

def solve_bipointed(B,g,word,cap=25000,seconds=10,both_sides=False):
    cert=opposite_certificate(B,g,word)
    if not cert['valid']:return {'opposite':cert},None,None
    d=tuple(cert['d']); raw=1
    for a in d:raw*=a+1
    if raw>cap:return {'opposite':cert,'resource_cut':'box_points','raw_points':raw},None,None
    negB=[[-a for a in row] for row in B];h=dual_label(B,g,d)
    points=[p for p in product(*(range(a+1) for a in d)) if in_container(B,g,p)
            and (not both_sides or in_container(negB,h,tuple(d[i]-p[i] for i in range(len(g)))))]
    if d not in points:return {'opposite':cert,'no_top_in_local_carrier':True},None,None
    M=build(B,g,points)
    if any(d):
        row=coo_matrix(([1.],([0],[M['ids'][d]])),shape=(1,len(M['columns']))).tocsc()
        M['A']=vstack([M['A'],row]).tocsc();M['b']=np.r_[M['b'],1]
    lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':seconds})
    out={'B':B,'g':list(g),'opposite':cert,'both_sides':both_sides,'points':len(points),'columns':len(M['columns']),
         'lp_status':int(lp.status),'lp_value':None if lp.fun is None else float(lp.fun)}
    F=exact_primal(M,lp.x)
    if lp.x is not None:out['finite_dual']=finite_dual(M,lp.eqlin.marginals)
    if F is None:
        mi=milp(M['c'],integrality=np.ones(len(M['columns'])),bounds=Bounds(0,np.inf),
                constraints=LinearConstraint(M['A'],M['b'],M['b']),options={'time_limit':seconds})
        out['milp_status']=int(mi.status);F=exact_primal(M,mi.x)
    if F is not None:
        if F.get(d)!=1:raise AssertionError('missing monic codegree')
        out['mass']=sum(F.values());out['support']=len(F);out['F']=dump_table(F)
        dual=out.get('finite_dual',{})
        if dual.get('valid') and Fraction(*dual['value'])==out['mass']:
            cols=dual['zero_slack_columns'];rank=rank_mod_sparse(M['A'],cols)
            out['uniqueness']={'rank':rank,'columns':len(cols),'prime':1000003,'unique':rank==len(cols)}
    return out,F,M

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    result=[]
    for name in ['noncluster_failure_00355.json','rank4_all_mass_minima.json']:
        a=json.loads((root/'agent_mass'/name).read_text())
        out,F,M=solve_bipointed(a['B'],a['g'],list(range(len(a['g']))))
        result.append(out)
        print(name,'mass',out.get('mass'),'points',out.get('points'),'unique',out.get('uniqueness'))
    (Path(__file__).parent/'bipointed_repairs.json').write_text(json.dumps(result,indent=2))
