# Acceptance and carrier research log

2026-11-13 05:16 UTC: read mass/dual/cutting-plane and finite-signature handoffs.
The target was a finite global normalized-pointedness acceptance certificate.

05:18--05:24: read Qin1902.09507v4 Sections3.3--3.4,5.1 and BFZ0305434v3
Theorem1.5, Proposition1.8, Corollary1.9, Lemmas3.1--3.2. Confirmed that
opposite-chart pointedness alone is not all-seed pointedness. Confirmed that
principal local Laurent divisibility already gives U-membership. Derived and
implemented an exact integer opposite-word certificate and correct support box.

05:24--05:29: proved the two-sided positive-packet boundary criterion and
explicit paired support-dimension mutation. The corrected box repairs the
earlier rank4 and rank5 local-mass failures, with exact finite dual and rank
certificates. A targeted two-sided-closure test covered96 inputs,76 solved
candidates and5715 transitions; no failure was seen, but292 degree and618
term branches were pruned. This is not an all-path closure conclusion.
Wolfram symbolic FullSimplify did not close the max identity and emitted a
message; a separate exact enumeration of6929 parameter triples returned{0}.
The proof is elementary case separation, not inferred from the enumeration.

05:29--05:36: reviewed primary Fei1911.10513v6 and1909.10151v3, plus
Franzen--Petrella--Webb2506.20568v1. Found an effective integer Schofield
carrier that can connect to the parent's Newton-fingerprint transport lemma.
Read the exact generic-subdimension recursion and Fei's vertex uniqueness
proof. Implemented exact exposed-vertex and convex-combination certificates.
The carrier fixes initial Newton data without knowing generic/theta interior
coefficients. This gives a finite all-seed pointedness certificate for
acyclic skew-symmetric B,g, using generic characters only as a proof reference.

Strong scope corrections retained:
- Do not assume generic F coefficients are positive; generic Grassmannians
  can have negative Euler characteristic.
- Do not assume generic and theta Newton polytopes are equal. A current
  conjecture on equality for pointed bases was found and reported to root.
- Do not replace skew-symmetric Schofield theory by an unaudited weighted
  Euler form for symmetrizable matrices.
- Do not apply the path-algebra recursion to a cyclic cluster quiver with
  unspecified potential relations.

New2026 lead (not adopted): arXiv2607.12458, Euler Characteristics of Generic
Quiver Grassmannians: Semi-Invariants and Localization. Root has been notified
for an independent strong audit.

05:36--05:50: derived the explicit acyclic source-word matrices
psi=[[-I,0],[K,I]], E_w=(B;-K(I-A)), K=(I-[B]_+)^-1, and proved the
componentwise complementarity recurrence for d. Independent exact tests:
84 matrices of ranks1--7,68 with nonconstant symmetrizer,504 labels, no
mismatch. This part genuinely covers skew-symmetrizable acyclic matrices.

Implemented coefficient-free Newton mutation with rational strict-feasibility
or Farkas witnesses. Exact comparison against actual polynomial mutation
passed9 steps/212 branch decisions. A targeted covariance test on the new
Schofield carriers completed112 neighboring comparisons with identical
selected polynomials;9 carrier-size cuts were retained. This is evidence,
not a general covariance proof.

The initial two-sided closure scan had a state-reuse implementation issue:
the second m-value reused the already mutated B, so12 proposed opposite
words correctly failed the certificate. The original result was retained
as `two_sided_closure_results_before_fix.json`. Restoring B for each input
gave96 inputs,84 solved candidates,6425 transitions,344 degree and711 term
cuts, no found failure. The remaining12 unsolved domains are resource caps.

Species/valued searches did not locate a directly applicable Schofield
recursion theorem. Infinite-rank unfoldings were explicitly identified in
the acyclic sign-skew-symmetric literature; they are not a finite carrier
algorithm. No weighted-Euler extension is adopted.

The parent proposed a **conditional** existence bridge using valuative
independence of the finite theta basis: expand the generic reference,
replace negative interior theta coefficients by their absolute values, and
retain the same monic Newton vertices. If the exact valuative-independence
theorem applies as being audited by root, this supplies a globally positive
pointed element with the computed carrier. It is a proof-only existence
argument, not a theta-based construction definition. It does not imply
that the local minimum-mass selector is globally positive.

Primary URLs:
- https://arxiv.org/abs/math/0305434
- https://arxiv.org/abs/1902.09507v4
- https://arxiv.org/abs/1911.10513v6
- https://arxiv.org/abs/1909.10151v3
- https://arxiv.org/abs/2506.20568v1

05:52--06:07: parent completed the CMMM finite-theta valuative-independence
audit. The positive-feasibility argument above is now available under its
stated finite-theta assumptions. A stronger mechanism was then derived:
theta_g is the least Newton carrier of every initially g-pointed U-element,
so finite signed Laurent equations permit exact deletion of every external
vertex. The acyclic complementarity d recurrence supplies a starting box
via the standard product product x_i^v_i (x_i')^d_i. This directly covers
skew-symmetrizable matrices and removes the need for a species Schofield
interface for the Newton construction.

Implemented exact affine-parameter elimination in theta_newton_pruning.py.
The rank5 integration case goes from signed vector dimension44 to final
affine dimension1, with42 nontrivial deletions; final carrier14vertices/
32latticepoints. Rank4 goes from vector dimension16 to affine dimension0,
with15 deletions; final carrier9vertices/15latticepoints. Both carriers
exactly match the independently computed Schofield carriers. The rank4
unique coefficient solution is therefore theta_g under the comparison proof.

Structural validation:24 acyclic inputs ranks2--5,12 nonconstant D,
251 nontrivial eliminations,6821 exact jet checks. Eight reversed deletion
orders agree. Independent Wolfram rank4 calculation returns
{48points,34equations,rank32,nullity16,standard-product residual0}.

Implementation correction: a floating convex-hull proposal included a
redundant boundary point. Exact exposure verification rejected it. The
routine now removes it only with an exact barycentric redundancy witness,
then verifies containment of every input point. A custom sparse carrier
must first be saturated by integer points of its convex hull; this is now
enforced. Default d-box runs were unaffected by the sparse-carrier issue.

Literature refresh in this interval:
- Sherman--Zelevinsky math/0307082v2 Remark5.8 read in the primary PDF:
  arbitrary finite sets of cluster-positivity tests are insufficient without
  a fixed pointed carrier. Their counterexample does not satisfy our fixed
  monic carrier assumptions, so it was not overextended.
- Lee--Li--Zelevinsky1303.5806v1 Theorem1.3 read in the primary PDF: a positive
  element with negative greedy-basis coefficient has two incomparable
  leading imaginary labels. It does not by itself disprove leastness within
  a single fixed pointed class.
- Rupel--Stella2206.04778 located as an explicit finite rank2 dominance-region
  interface; not used as an unaudited positivity theorem.
- New Hexagon2610.00025v3 and2610.00083v2 search results on minimality were
  noted, but no new theorem from these2026 sources was adopted here.

The packet agent subsequently found an actual fixed-carrier initial-star
positive, depth2-negative rank2 example. This is not a minimum-mass failure;
it precisely blocks an overstrong local-positivity implication. Main work
continues on the positive selector, with the all-seed pointedness gap now
resolved by the finite Newton algorithm in the stated acyclic/all-D scope.
