#!/usr/bin/env python3
"""Finite theta Newton carrier by signed Laurent equations and vertex deletion.

The definition uses integer points, rational linear algebra and convex hulls.
Its identification with the theta Newton polytope uses valuative independence
and finite theta expansion, as audited in work/THETA_NEWTON_PRUNING.md.
No theta coefficient or representation-theoretic object is a program input.
"""
from pathlib import Path
import sys, json, time
from collections import defaultdict
from math import comb
import sympy as sp
import numpy as np
from scipy.spatial import ConvexHull

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_acceptance'),str(ROOT/'agent_packet_propagation')]
from schofield_carrier import acyclic_dimension, exact_separator, exact_barycentric
from linear_carrier import divisibility_space
from itertools import product


def qdump(q):
    q=sp.Rational(q)
    return [int(q.p),int(q.q)]


def affine_normalize(F,origin):
    """Normalize coefficient at origin to one; rows=(constant, free part)."""
    r=F.get(origin)
    if r is None or not any(r):
        raise ValueError('no origin-normalized element in this Laurent space')
    pivot=next(i for i,a in enumerate(r) if a)
    other=[i for i in range(len(r)) if i!=pivot]
    return {p:(sp.Rational(v[pivot],r[pivot]),)+tuple(
        sp.Rational(v[i])-sp.Rational(v[pivot]*r[i],r[pivot]) for i in other)
        for p,v in F.items()}


def set_coefficient_zero(rows,point):
    """Exact one-parameter elimination; fail if the coefficient is forced nonzero."""
    r=rows[point]
    free=next((j for j in range(1,len(r)) if r[j]),None)
    if free is None:
        if r[0]:raise ValueError('coefficient is forced nonzero')
        return dict(rows),None
    keep=[j for j in range(len(r)) if j!=free]
    out={p:tuple(sp.cancel(a[j]-a[free]*r[j]/r[free]) for j in keep)
         for p,a in rows.items()}
    if any(out[point]):raise ArithmeticError('elimination failed')
    return out,free


def exact_vertices(points):
    """Floating hull only proposes vertices; every assertion is checked over Q."""
    points=tuple(sorted(set(map(tuple,points))))
    if len(points)==1:
        return list(points),[{'p':list(points[0]),'single_point':True}]
    p0=points[0]
    D=sp.Matrix([[p[i]-p0[i] for i in range(len(p0))] for p in points[1:]])
    coords=list(D.rref()[1])
    if len(coords)==1:
        j=coords[0]
        candidates=sorted(set([min(range(len(points)),key=lambda i:points[i][j]),
                               max(range(len(points)),key=lambda i:points[i][j])]))
    else:
        hull=ConvexHull(np.array([[p[j] for j in coords]for p in points],dtype=float))
        candidates=sorted(map(int,hull.vertices))
    V=[];certs=[]
    for i in candidates:
        p=points[i];others=[a for a in points if a!=p]
        sep=exact_separator(p,others)
        if sep is None:
            if exact_barycentric(p,others) is not None:continue
            raise ArithmeticError('proposed vertex has neither exact exposure nor redundancy')
        V.append(p);certs.append({'p':list(p),'normal':sep})
    vertices=set(V)
    for p in points:
        if p in vertices:continue
        if exact_barycentric(p,V) is None:
            raise ArithmeticError('hull proposal omitted an exact extremal point')
    return V,certs


def verify_affine_space(B,g,rows):
    """Verify every affine coefficient column against all binomial jets exactly."""
    n=len(g); origin=(0,)*n
    if origin not in rows or rows[origin]!=(sp.Integer(1),)+(sp.Integer(0),)*(len(rows[origin])-1):
        raise ArithmeticError('origin normalization failed')
    width=len(rows[origin]);checks=0
    for k in range(n):
        fibers=defaultdict(list)
        for p in rows:fibers[p[:k]+p[k+1:]].append(p)
        for off,points in fibers.items():
            p=off[:k]+(0,)+off[k:]
            r=g[k]+sum(B[k][j]*p[j] for j in range(n))
            power=max(-r,0);degree=max(p[k] for p in points)
            for j in range(min(power,degree+1)):
                values=[sp.Integer(0)]*width
                for p in points:
                    if p[k]<j:continue
                    a=comb(p[k],j)*(-1)**(p[k]-j)
                    values=[x+a*y for x,y in zip(values,rows[p])]
                if any(values):raise ArithmeticError(('jet',k,off,j,values))
                checks+=width
    return checks


def prune(B,g,points=None,cap=5000,reverse_order=False):
    """Return a finite exact theta carrier, conditional only on the stated theorem.

    For acyclic B a known initial pointed product supplies the integer box.
    For other seeds the caller may supply any finite nonnegative support known
    to contain an initial-g-pointed U element. Its convex hull is saturated by
    integer points before forming the affine space. Feasibility alone is checked;
    finite-theta-expansion hypotheses remain the theorem's responsibility.
    """
    tic=time.time();g=tuple(g);n=len(g);origin=(0,)*n
    if points is None:
        d,v,order=acyclic_dimension(B,g)
        size=np.prod([a+1 for a in d],dtype=object)
        if size>cap:raise OverflowError('initial standard-product box cap')
        points=list(product(*(range(a+1) for a in d)))
        initial={'kind':'acyclic_standard_product','d':list(d),'v':list(v),'order':list(order)}
    else:
        supplied=list(map(tuple,points))
        if not supplied:raise ValueError('empty supplied support')
        if origin not in supplied or any(any(a<0 for a in p) for p in supplied):
            raise ValueError('initial support must be nonnegative and contain zero')
        VV,_=exact_vertices(supplied)
        upper=[max(p[i]for p in VV)for i in range(n)]
        raw=1
        for a in upper:raw*=a+1
        if raw>cap:raise OverflowError('supplied convex carrier box cap')
        points=[]
        for p in product(*(range(a+1)for a in upper)):
            if exact_barycentric(p,VV) is not None:points.append(p)
            elif exact_separator(p,VV) is None:
                raise ArithmeticError('uncertified supplied carrier saturation')
        initial={'kind':'supplied_convex_integer_carrier','supplied_points':len(supplied)}
    if origin not in points or any(any(a<0 for a in p) for p in points):
        raise ValueError('initial carrier must be nonnegative and contain zero')
    F,space=divisibility_space(B,g,points)
    rows=affine_normalize(F,origin)
    initial['affine_dimension']=len(rows[origin])-1
    initial['zero_columns']=len(points)-len(rows)
    steps=[];checks=verify_affine_space(B,g,rows)
    while True:
        forced_zero=[p for p,a in rows.items() if not any(a)]
        if forced_zero:
            rows={p:a for p,a in rows.items() if any(a)}
        V,certs=exact_vertices(rows)
        deletable=[p for p in V if p!=origin and any(rows[p][1:])]
        if not deletable:break
        point=sorted(deletable,reverse=reverse_order)[0]
        olddim=len(rows[origin])-1;oldrow=rows[point]
        rows,pivot=set_coefficient_zero(rows,point)
        steps.append({'removed_vertex':list(point),'affine_dimension_before':olddim,
                      'parameter_pivot':pivot,'old_coefficient_row':[qdump(a)for a in oldrow],
                      'exposure':next(a for a in certs if tuple(a['p'])==point),
                      'forced_zero_removed_before':len(forced_zero)})
    checks+=verify_affine_space(B,g,rows)
    fixed_vertices=[]
    for p in V:
        if any(rows[p][1:]):raise ArithmeticError('unpruned variable vertex')
        fixed_vertices.append({'p':list(p),'coefficient':qdump(rows[p][0])})
    if any(rows[p][0]!=1 for p in V):
        raise ArithmeticError('theta-theorem prediction failed: nonmonic forced vertex')
    # Restore every lattice point in the final polytope, even where all current
    # functions have zero coefficient. This is the carrier used by packets.
    d=[max(p[i] for p in V)for i in range(n)]
    box=1
    for a in d:box*=a+1
    if box>cap:raise OverflowError('final carrier box cap')
    inside=[];lattice=[];outside=[]
    for p in product(*(range(a+1)for a in d)):
        bary=exact_barycentric(p,V)
        if bary is not None:
            lattice.append(list(p));inside.append({'p':list(p),'barycentric':bary})
        else:
            sep=exact_separator(p,V)
            if sep is None:raise ArithmeticError('uncertified final lattice point')
            outside.append({'p':list(p),'normal':sep})
    return {'B':B,'g':list(g),'initial':initial,'initial_space':space,
            'deletion_steps':steps,'nontrivial_deletions':len(steps),
            'final_affine_dimension':len(rows[origin])-1,'vertices':[list(p)for p in V],
            'vertex_certificates':certs,'forced_vertex_coefficients':fixed_vertices,
            'lattice_points':lattice,'d':d,'inside_certificates':inside,
            'outside_certificates':outside,'affine_rows':[
                {'p':list(p),'row':[qdump(a)for a in row]}for p,row in sorted(rows.items())],
            'exact_jet_checks':checks,'seconds':time.time()-tic}


def main():
    cases=[]
    for name in ['noncluster_failure_00355.json','rank4_all_mass_minima.json']:
        a=json.loads((ROOT/'agent_mass'/name).read_text());B,g=a['B'],a['g']
        ans=prune(B,g,cap=5000);cases.append(ans)
        print(name,'initial',ans['initial_space'],'deletions',ans['nontrivial_deletions'],
              'vertices',len(ans['vertices']),'lattice',len(ans['lattice_points']),
              'residualdim',ans['final_affine_dimension'],'seconds',ans['seconds'],flush=True)
    (Path(__file__).parent/'theta_newton_pruning_results.json').write_text(json.dumps(cases,indent=2))


if __name__=='__main__':main()
