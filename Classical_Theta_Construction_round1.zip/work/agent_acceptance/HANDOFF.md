# Finite acceptance agent handoff

Updated 2026-11-13 06:11 UTC; checked for handoff completion. Agent `/root/global_pointedness_finite_acceptance`.
Root's six-hour run continues; this is a handoff of one completed mechanism,
not a statement that the full higher-rank positive-basis task is complete.

## Main result to carry forward

The parent's valuative-independence insight and this agent's explicit acyclic
standard-product/dimension recurrence give a finite algorithm for the exact
theta Newton carrier for every acyclic skew-symmetrizable B,g. This avoids
the previously unresolved species Schofield interface. It also gives a finite
certificate for all-seed compatible pointedness of every accepted candidate.

Read first:

1. `work/THETA_NEWTON_PRUNING.md` (parent's precise comparison proof and source audit).
2. `THETA_PRUNING_IMPLEMENTATION.md` (parameter-elimination algorithm, all-D scope,
   finite coefficient/packet upper bounds, exact checks, remaining gap).
3. `theta_newton_pruning.py` (actual implementation).

The key theorem is: finite theta expansion + valuative independence imply
that every initially g-pointed U-element contains theta_g with coefficient1,
and its Newton polytope contains P_theta(g). Start from the acyclic standard
product x^v product(x_i')^d_i with F=product(1+z_i)^d_i and
d_i=[-g_i+sum[-b_ij]_+d_j]_+. In the integer box [0,d], impose only the signed
initial-neighbor Laurent jet equations and a0=1. Delete a vertex whenever its
coefficient can be made zero by exact rational linear algebra. Theta remains
feasible. Every non-theta vertex is deletable, and no theta vertex is. The
algorithm terminates at P_theta(g), independently of deletion order.

Implementation improvement: use affine rows a=c+Wt. A vertex coefficient is
deletable iff W_v is nonzero or it is already forcedzero. Each nontrivial
deletion removes one parameter. Forcedzero coefficients are bulk-discarded.
Thus the nontrivial deletion count equals the drop in affine dimension.

At termination all vertex coefficients are forced1. Any supported integer
candidate satisfying the same jets is in U and has the same monic Newton
fingerprint as theta_g. Root's Newton transport lemma then supplies all-seed
pointedness. This statement does not require universal coefficient positivity.

## Code interfaces

- `theta_newton_pruning.prune(B,g,points=None,cap=5000,reverse_order=False)`.
  Default: acyclic d-box. Output has `vertices`, `lattice_points`, `d`,
  `affine_rows`, exact hull certificates, deletion records and dimensions.
  A supplied sparse support is first saturated by all integer points of its
  convex hull; this is essential for preserving the comparison witness.
- `schofield_carrier.solve_carrier_packets(B,g,C,seconds=15)` accepts the
  returned C without modification. It imposes positive binomial quotients
  and monic vertices and returns exact primal/dual/rank certificates.
- `newton_mutation.mutate_polytope(B,g,vertices,k)` transports Newton data
  without coefficients, with exact rational branch/Farkas certificates.
- Sibling `work/agent_packet_propagation/linear_carrier.py` has
  `divisibility_space` and simultaneous `mutate_rows`; do not duplicate them.

## Exact outcomes

- Rank5 chain B12=2,B23=B34=B45=1,g=(-2,2,-1,1,1): d=(2,2,3,2,1).
  Box216, U-vector dimension44, normalized affine dimension43. After42
  nontrivial deletions:14vertices,32latticepoints, affine dimension1.
  Exactly matches the independently computed Schofield carrier. Its current
  positive-packet minimum is46, unique with finite dual/rank certificate.
- Rank4 chain B12=4,B23=B34=1,g=(-1,1,1,1): box48, U-vector dimension16.
  After15 nontrivial deletions:9vertices,15latticepoints, affine dimension0.
  Its unique rational solution is therefore exactly theta_g under the theorem;
  all15 coefficients are nonnegative integers and total mass25.
- Structured all-D validation:24inputs ranks2--5,12nonconstant symmetrizers,
  251 nontrivial eliminations,6821 independent exact jet checks. Eight reverse
  deletion orders return identical vertices. These24 inputs all have affine
  dimension0; all153 resulting coefficients are nonnegative integers and
  satisfy the explicit standard-product binomial upper bound.
- Independent Wolfram jet matrix rank4 returns{48,34,32,16,0} for
  {points,equations,rank,nullity,standard-product residual}; matches Python.

Primary data: `theta_newton_pruning_results.json`,
`theta_pruning_validation.json`, `theta_pruning_validation_certificates.json`,
`theta_pruning_unique_coefficients_validation.json`,
`WOLFRAM_THETA_JET_CHECK.json`.

Earlier integration results remain useful but are superseded for acceptance:
correct opposite box, two-sided packet theorem, Schofield carrier,
finite-dual coefficient leastness certificates for rank4/5, Newton mutation,
112 neighbor covariance comparisons. Their statements/scopes are in
`BIPOINTED_BOUNDARY_RECURRENCE.md`, `ACYCLIC_NEWTON_ACCEPTANCE.md`,
`NEWTON_MUTATION_ALGORITHM.md`, and `RESEARCH_LOG.md`.

## Explicit finite bounds for the next selector attack

Positive theta multiplication gives M_g=theta_g+sum c_h theta_h,c_h>=0.
Thus theta coefficients are bounded by product_i binom(d_i,p_i). For a local
fiber with r=g_k+sum b_kj a_j and c=[-r]_+, its quotient coefficients are
bounded by

    product_(j!=k) binom(d_j,a_j) * binom(d_k-c,s).

This gives a finite combinatorial integer candidate box using B,g alone.
It does not choose the theta coefficients. The parent has been notified.

## Remaining task and already known obstruction

Sibling packet agent found a genuine initial-star-positive candidate on a
minimal monic carrier with a negative coefficient after two mutations:
rank2 r=3,g=(-7,14), mass491, word(0,1), coefficient at(2,4)=-1. Its exact
artifact is `work/agent_packet_propagation/verified_newton_star_failure.json`.
This is NOT a minimum-mass counterexample. Do not attempt to prove the now
false statement that all positive source-star candidates on the minimal
carrier are universally positive.

The live main gap is a selector for nonvertex coefficients with a proof of
global positivity/greedy or theta identification. Here nonvertex positions
may lie on boundary faces: they need not be in the relative interior. For
example the Kronecker lower monomial at(1,1) lies on a diagonal edge of the
carrier for d=(2,2). Packet agent owns all-seed row-cone
closure and minimum/cut investigations; locality agent owns formal greedy
sharpness and rank2 comparisons; root owns the overall comparison theorem.

Do not silently use generic-basis positivity, theta=generic Newton equality,
weighted Schofield recursion, local-star positivity implying universal
positivity, or coefficientwise greedy leastness without a proof.

## Literature refresh / audits

Exact source interfaces and scopes are logged in RESEARCH_LOG.md. Parent has
audited CMMM2505.09585v2, including its skew-symmetrizable seed scope, and GHKK
A subset mid subset U; BFZ acyclic A=U supplies finite expansions here.
Old Schofield carrier uses ordinary skew quivers only and is now a comparison
tool, not the valued construction.

Sherman--Zelevinsky math/0307082v2 Remark5.8 is an explicit finite-atlas
positivity counterexample without a fixed pointed carrier. LLZ1303.5806v1
Theorem1.3 gives universally positive elements with negative greedy-basis
coefficients and incomparable leading labels. Neither alone resolves the
minimum selector within our fixed pointed class. Primary PDFs/txts are in
references/. Do not include duplicated source PDFs in a compact checkpoint
unless root needs them; code, concise notes and JSON results suffice.
