#!/usr/bin/env python3
"""Stress a specific paired-boundary closure hypothesis, not generic example gathering."""
from bipointed_packets import *
from normalized_fibers import mutate, mutate_matrix
from collections import defaultdict, deque
import random,time

def check(B,g,F,d,depth=3,steps_cap=300,max_degree=200,max_terms=10000):
    q=deque([(B,tuple(g),F,tuple(d),())]);seen=set();stats=defaultdict(int)
    while q:
        BB,gg,FF,dd,w=q.popleft()
        key=(tuple(map(tuple,BB)),gg,tuple(sorted(FF.items())),dd)
        if key in seen:continue
        seen.add(key)
        if len(w)>=depth:continue
        for k in range(len(gg)):
            if w and w[-1]==k:continue
            stats['steps']+=1
            dp=mutate_support_dimension(BB,gg,dd,k)
            if max(dp)>max_degree:
                stats['degree_prunes']+=1;continue
            state,err=mutate(BB,gg,FF,k)
            if err:return dict(stats),{'word':list(w+(k,)),'failure':err}
            BBB,ggg,FFF=state
            bad=[p for p in FFF if any(p[i]>dp[i] for i in range(len(gg)))]
            if bad or FFF.get(dp)!=1:
                return dict(stats),{'word':list(w+(k,)),'failure':'paired_boundary',
                    'expected_d':list(dp),'top_coefficient':FFF.get(dp,0),'outside':bad[:10]}
            if len(FFF)>max_terms:
                stats['term_prunes']+=1;continue
            if stats['steps']>=steps_cap:
                stats['steps_prune']+=1;return dict(stats),None
            q.append((BBB,ggg,FFF,dp,w+(k,)))
    return dict(stats),None

def run():
    rng=random.Random(260113);stats=defaultdict(int);out=[];tic=time.time()
    for n in [2,3,4,5]:
      for valued in [False,True]:
       for r in [2,3]:
        for density in [0.0,0.45,1.0]:
         D=[1,1]+([2,3,1][:n-2] if valued else [1]*(n-2))
         B=[[0]*n for _ in range(n)]
         for i in range(n):
          for j in range(i+1,n):
           w=r if (i,j)==(0,1) else int(j==i+1 or rng.random()<density)
           a=int(sp.ilcm(D[i],D[j]))*w;B[i][j]=a//D[i];B[j][i]=-a//D[j]
         base_B=[row[:] for row in B]
         for m in [1,2]:
          B=[row[:] for row in base_B]
          g=[-m,m]+[rng.choice([-1,0,1]) for _ in range(n-2)]
          word=list(range(n))
          # In half the cases move away from the acyclic chart. The proposed
          # conjugate opposite word is always checked, not assumed valid.
          if density==0.45 and n>=3:
           k=1;g=list(tropical_step(sp.Matrix(B),sp.Matrix(g),k));g=list(map(int,g))
           B=mutate_matrix(B,k);word=[k]+word+[k]
          result,F,M=solve_bipointed(B,g,word,cap=5000,seconds=6,both_sides=True)
          stats['instances']+=1
          if F is None:
           stats['no_solved_candidate']+=1;out.append(result);continue
          stats['candidates']+=1
          cs,fail=check(B,g,F,result['opposite']['d'],depth=4,steps_cap=500)
          for k,a in cs.items():stats[k]+=a
          result['transport_counts']=cs;result['failure']=fail
          if fail:
           stats['failures']+=1
           fn=Path(__file__).parent/('two_sided_failure_%03d.json'%stats['instances'])
           fn.write_text(json.dumps(result,indent=2));print('FAIL',fn,fail,flush=True)
          result.pop('finite_dual',None);result.pop('F',None);out.append(result)
          if stats['instances']%10==0:print(dict(stats),flush=True)
    stats['seconds']=time.time()-tic
    (Path(__file__).parent/'two_sided_closure_results.json').write_text(json.dumps({'stats':dict(stats),'results':out},indent=2))
    print(dict(stats),flush=True)
if __name__=='__main__':run()
