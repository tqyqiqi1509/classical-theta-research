#!/usr/bin/env python3
"""Test the carrier minimum's mutation rule using coefficient-free polytope transport."""
from newton_mutation import *
from normalized_fibers import mutate
import random,time

def lattice_carrier(vertices,cap=3000):
    n=len(vertices[0]);d=[max(p[i]for p in vertices)for i in range(n)]
    if any(min(p[i]for p in vertices)<0 for i in range(n)):raise ValueError('not normalized')
    raw=1
    for a in d:raw*=a+1
    if raw>cap:return None
    points=[]
    for p in product(*(range(a+1)for a in d)):
        if exact_barycentric(p,vertices)is not None:points.append(list(p))
        elif exact_separator(p,vertices)is None:raise ArithmeticError('uncertified point')
    return {'d':d,'vertices':vertices,'lattice_points':points}

def run():
    rng=random.Random(20261113);results=[];stats={'inputs':0,'root_candidates':0,'neighbor_candidates':0,'mass_failures':0,'different_minima':0,'resource_cuts':0};tic=time.time()
    inputs=[]
    for n in [3,4,5]:
      for r in [2,3]:
       for density in [0,0.4,1]:
        for m in [1,2]:
         B=[[0]*n for _ in range(n)]
         for i in range(n):
          for j in range(i+1,n):
           a=r if(i,j)==(0,1)else int(j==i+1 or rng.random()<density)
           B[i][j]=a;B[j][i]=-a
         g=[-m,m]+[rng.choice([-1,0,1])for _ in range(n-2)]
         inputs.append((B,g))
    for B,g in inputs:
        stats['inputs']+=1;d,v,order=acyclic_dimension(B,g)
        try:C=carrier(B,d,cap=800)
        except OverflowError:stats['resource_cuts']+=1;continue
        root,F,M=solve_carrier_packets(B,g,C,seconds=6)
        if F is None:results.append({'B':B,'g':g,'root_failed':root});continue
        stats['root_candidates']+=1;V=C['vertices']
        for k in range(len(g)):
            BB,gg,VV,cert=mutate_polytope(B,g,V,k);CC=lattice_carrier(VV,cap=2500)
            if CC is None:stats['resource_cuts']+=1;continue
            target,H,MM=solve_carrier_packets(BB,gg,CC,seconds=6)
            if H is None:results.append({'B':B,'g':g,'k':k,'target_failed':target});continue
            stats['neighbor_candidates']+=1
            state,err=mutate(B,g,F,k)
            if err:raise AssertionError(err)
            T=state[2];bad=sum(T.values())!=sum(H.values())
            stats['mass_failures']+=bad;stats['different_minima']+=T!=H
            rec={'B':B,'g':g,'d':d,'k':k,'root_mass':sum(F.values()),'transported_mass':sum(T.values()),
                 'target_min_mass':sum(H.values()),'same_polynomial':T==H,'target_unique':target.get('uniqueness')}
            if bad or T!=H:
                rec.update({'root':root,'target':target,'root_vertices':V,'target_vertices':VV})
                fn=Path(__file__).parent/('carrier_covariance_failure_%03d_%d.json'%(stats['inputs'],k))
                fn.write_text(json.dumps(rec,indent=2));print('FAIL',fn,rec['transported_mass'],rec['target_min_mass'],flush=True)
            results.append(rec)
        print(stats,flush=True)
    stats['seconds']=time.time()-tic
    (Path(__file__).parent/'carrier_covariance_results.json').write_text(json.dumps({'stats':stats,'results':results},indent=2))
    print(stats,flush=True)
if __name__=='__main__':run()
