# Coefficient-free mutation of a finite Newton carrier

This procedure calculates the Newton polytope after a classical cluster
mutation without knowing any polynomial coefficients. The input polytope
must be realized by an element Laurent in both charts. The main application
here is the Schofield carrier with its generic-reference existence proof.

Work in all mutable and frozen exponent coordinates. Let E=(B;I), let the
input extended label be v=(g,0), and lift each coefficient-polytope vertex p
to a=v+E p. Mutate direction k. Write E[:,k]=c and let cplus=[c]_+,
cminus=[-c]_+.

On valuation vectors w in the region c.w>0, the exchange numerator has
leading monomial with exponent cplus. On c.w<0 it has exponent cminus.
Let Lplus and Lminus be identity matrices with row k replaced by
cplus^T-e_k^T and cminus^T-e_k^T, respectively. Thus old valuations are
Lsign w. For an old vertex a, its prospective new slope is

    b = Lsign^T a.

Keep b exactly when there exists w satisfying

    (b-b_other).w >0 for every other old vertex,
    sign*c.w >0.

The strict homogeneous system is equivalent to replacing every right side
by1. A feasible system has a rational witness. An infeasible system has a
finite rational Farkas witness lambda>=0 with A^T lambda=0 and sum lambda=1.
The implementation verifies one of these certificates in exact arithmetic;
it does not trust floating infeasibility alone.

The convex hull of the retained slopes is the target Newton polytope.
Indeed the mutation of the support function is the composition with the
piecewise-linear valuation map. On every full-dimensional linearity cone
the gradient is exactly one of the retained b, and every retained b occurs
on such an open cone. Laurentness makes this support function convex, so
these are precisely its distinct vertices.

Finally compute E'=mu_k(E) and v'=phi_k(v). Convert every retained b to a
coefficient exponent q by solving

    b-v'=E' q.

The frozen square block of E' is unimodular; it gives q by integer inversion.
The code also checks the mutable rows and integrality. The resulting vertices
are those of the normalized F-polynomial carrier in the new seed.

This procedure works for arbitrary skew-symmetrizable B whenever the input
carrier has the stated Laurent realization. It is not a method for finding
such a carrier from an arbitrary cyclic label.

Implementation: `newton_mutation.py`. Independent full polynomial transport
of the rank4/rank5 integration examples verified9 mutations,152 realized
vertex/branch pairs,60 Farkas-rejected pairs, and every actual support point.
All target vertex coefficients were1; there were no resource truncations in
this verification. Data: `newton_mutation_validation.json`.

The carrier-covariance experiment then compared independently optimized
packet minima in the initial and every adjacent carrier. It completed36
inputs,30 root candidates and112 neighboring optimizations. The transported
candidate and the independently selected target candidate were equal in
all112 comparisons;9 carrier-size branches were cut. This supports the
selector hypothesis but does not prove covariance. Data:
`carrier_covariance_results.json`.
