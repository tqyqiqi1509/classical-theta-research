#!/usr/bin/env python3
"""Exact Newton-polytope mutation without polynomial coefficients.

Input must be the Newton polytope of a Laurent function that is Laurent after
mutation. All branch reachability decisions carry rational certificates.
"""
from schofield_carrier import *

def strict_feasibility(rows):
    A=np.array(rows,dtype=float);r,m=A.shape
    lp=linprog(np.zeros(m),A_ub=-A,b_ub=-np.ones(r),bounds=[(None,None)]*m,method='highs')
    if lp.x is not None:
        w=rational_feasible(lp.x)
        if all(sum(Fraction(int(a))*b for a,b in zip(row,w))>=1 for row in rows):
            return True,{'w':[[a.numerator,a.denominator] for a in w]}
    # Homogeneous alternative: lambda>=0, A^T lambda=0, sum lambda=1.
    lam=linprog(np.zeros(r),A_eq=np.vstack([A.T,np.ones((1,r))]),b_eq=np.r_[np.zeros(m),1],bounds=(0,None),method='highs')
    if lam.x is None:raise ArithmeticError('neither strict nor Farkas witness found')
    active=[i for i,a in enumerate(lam.x) if a>1e-8]
    AA=sp.Matrix.hstack(*(sp.Matrix(list(rows[i])+[1]) for i in active));bb=sp.Matrix([0]*m+[1])
    z,params=AA.gauss_jordan_solve(bb)
    if params.rows:z=z.subs({a:0 for a in params})
    if AA*z!=bb or any(a<0 for a in z):raise ArithmeticError('invalid Farkas witness')
    return False,{'lambda':[{'i':i,'a':[int(a.p),int(a.q)]} for i,a in zip(active,z) if a]}

def mutate_polytope(B,g,vertices,k):
    n=len(g);E=sp.Matrix(B).col_join(sp.eye(n));v=sp.Matrix(list(g)+[0]*n)
    EE=mutate_extended(E,k);vv=tropical_step(E,v,k)
    full=[v+E*sp.Matrix(p) for p in vertices];all_new=[];certificates=[]
    for sign in [1,-1]:
        # old valuation w_old = L w_new, for the selected exchange monomial.
        L=sp.eye(2*n)
        for j in range(2*n):L[k,j]=max(sign*E[j,k],0)-int(j==k)
        slopes=[L.T*a for a in full]
        for i,a in enumerate(slopes):
            rows=[list(map(int,a-b)) for j,b in enumerate(slopes) if j!=i]
            rows.append([int(sign*E[j,k]) for j in range(2*n)])
            ok,cert=strict_feasibility(rows)
            certificates.append({'vertex':i,'exchange_sign':sign,'realized':ok,'certificate':cert})
            if ok:all_new.append(a)
    C=EE[n:,:];Ci=C.inv();out=set()
    for a in all_new:
        q=Ci*(a-vv)[n:,:]
        if EE*q!=a-vv or any(x.q!=1 for x in q):raise AssertionError('nonintegral pointed exponent')
        out.add(tuple(map(int,q)))
    return [[int(EE[i,j]) for j in range(n)] for i in range(n)],tuple(int(vv[i]) for i in range(n)),sorted(out),certificates

if __name__=='__main__':
    from normalized_fibers import mutate
    import random,time
    root=Path(__file__).resolve().parent;inputs=json.loads((root/'schofield_packet_repairs.json').read_text())
    out=[];stats={'steps':0,'vertex_mismatches':0,'support_mismatches':0,'resource_cuts':0,'strict_branches':0,'farkas_branches':0}
    for inp in inputs:
        B,g,V=inp['B'],inp['g'],list(map(tuple,inp['carrier']['vertices']))
        F={tuple(x['p']):x['a'] for x in inp['packet_result']['F']}
        for k in range(len(g)):
            BB,gg,VV,cert=mutate_polytope(B,g,V,k);state,err=mutate(B,g,F,k)
            if err:raise AssertionError(err)
            assert state[0]==BB and state[1]==gg
            FF=state[2];stats['steps']+=1
            for c in cert:stats['strict_branches' if c['realized'] else 'farkas_branches']+=1
            if any(FF.get(p)!=1 for p in VV):stats['vertex_mismatches']+=1
            for p in FF:
                if exact_barycentric(p,VV) is None:stats['support_mismatches']+=1
            out.append({'B':B,'g':g,'k':k,'target_B':BB,'target_g':gg,'target_vertices':VV,'branches':cert})
    (root/'newton_mutation_validation.json').write_text(json.dumps({'stats':stats,'data':out},indent=2))
    print(stats)
