#!/usr/bin/env python3
"""Structured all-D and order-independence validation for the finite algorithm."""
from theta_newton_pruning import *
import random

def main():
    rng=__import__('random').Random(2026111306);results=[];records=[];tic=time.time()
    for n in range(2,6):
      for valued in [False,True]:
       for rep in range(3):
        D=[1 if not valued else 1+(i%3)for i in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
         for j in range(i+1,n):
          c=1+int(i==0 and j==1 and rep==2) if j==i+1 or rng.random()<0.4 else 0
          B[i][j]=D[j]*c;B[j][i]=-D[i]*c
        d=[1+int((i+rep)%3==0)for i in range(n)]
        if rep==1:d[-1]=0
        A=[[max(-x,0)for x in row]for row in B]
        v=[int(a==0)*rng.choice([0,1,2])for a in d]
        g=[v[i]-d[i]+sum(A[i][j]*d[j]for j in range(n))for i in range(n)]
        ans=prune(B,g,cap=1000);records.append(ans)
        reverse=prune(B,g,cap=1000,reverse_order=True) if rep==0 else None
        same=reverse is None or sorted(ans['vertices'])==sorted(reverse['vertices'])
        if not same:raise AssertionError('deletion-order dependence')
        summary={'B':B,'g':g,'symmetrizer':D,'d':d,'initial_points':ans['initial_space']['points'],
                 'initial_affine_dimension':ans['initial']['affine_dimension'],
                 'nontrivial_deletions':ans['nontrivial_deletions'],
                 'final_affine_dimension':ans['final_affine_dimension'],
                 'vertices':len(ans['vertices']),'lattice_points':len(ans['lattice_points']),
                 'reverse_order_checked':reverse is not None,'same_vertices':same,
                 'exact_jet_checks':ans['exact_jet_checks'],'seconds':ans['seconds']}
        results.append(summary)
        print(n,valued,rep,'dim',summary['initial_affine_dimension'],'to',summary['final_affine_dimension'],
              'V/P',summary['vertices'],summary['lattice_points'],'order',summary['reverse_order_checked'],flush=True)
    out={'stats':{'cases':len(results),'nonconstant_D':sum(len(set(a['symmetrizer']))>1 for a in results),
                  'reverse_order_checks':sum(a['reverse_order_checked']for a in results),
                  'nontrivial_deletions':sum(a['nontrivial_deletions']for a in results),
                  'exact_jet_checks':sum(a['exact_jet_checks']for a in results),'seconds':time.time()-tic},
         'results':results}
    (Path(__file__).parent/'theta_pruning_validation.json').write_text(json.dumps(out,indent=2))
    (Path(__file__).parent/'theta_pruning_validation_certificates.json').write_text(json.dumps(records,indent=2))
    print(out['stats'],flush=True)

if __name__=='__main__':main()
