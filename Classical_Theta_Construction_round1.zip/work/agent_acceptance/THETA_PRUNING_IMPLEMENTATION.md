# Exact finite Newton pruning and the remaining coefficient problem

Date: 2026-11-13, 06:06 UTC. The proof is in `work/THETA_NEWTON_PRUNING.md`.
This file records the finite implementation and its stronger acceptance
consequence. It does not claim the positive coefficient selector is solved.

## 1. Finite algorithm, now including valued acyclic matrices

For any acyclic skew-symmetrizable B and g, put A=[-B]_+. In a topological
order, recursively compute

    d_i=max(0,-g_i+sum_j A_ij d_j),
    v_i=max(0, g_i-sum_j A_ij d_j).

The identity g=v-(I-A)d supplies an explicit initial pointed element

    x^v product_i (x_i')^(d_i) = x^g product_i (1+z_i)^(d_i).

Its F-support is the integer box [0,d]. This identity is valid with arbitrary
symmetrizer; ordinary quiver representations or a weighted Schofield theorem
are unnecessary here.

In this finite box, compute the rational vector space defined by all initial
neighbor Laurent divisibility conditions, using vanishing binomial jets at
t=-1. Normalize a_0=1, obtaining an affine parametrization

    a_p = c_p + sum_j W_pj t_j.

The code uses `linear_carrier.divisibility_space` for the initial exact kernel
and independently checks every resulting column against all original jets.

If v is a vertex of the current possible support, its coefficient can be
made zero precisely when its free row W_v is nonzero, or when the coefficient
is already forced zero. In the nonconstant case choose W_vj != 0 and replace

    t_j = -c_v/W_vj - sum_(l!=j) W_vl/W_vj t_l.

This is exact rational elimination, lowering the affine dimension by one.
Discard all coefficients that become identically zero. They may include
interior points; this is safe because every member of the current space,
including the comparison theta witness, has coefficient zero there.

At termination every remaining vertex coefficient is forced. The comparison
theorem identifies the resulting convex hull with P_theta(g), and every
forced vertex coefficient is exactly 1. Thus there are at most

    dim(L_initial)-dim(L_final)

nontrivial elimination steps, where the dimensions are affine dimensions.
Each of these steps has an exact exposing normal. The final carrier restores
all integer points of the final convex hull, even if every member of the
current space has zero coefficient at some of them.

Floating convex-hull/LP routines only propose rational witnesses. The code
checks each exposing normal, each barycentric inclusion, and each separating
hyperplane using exact arithmetic. An initially proposed hull included a
redundant boundary point; the exact check rejected it. The implementation
now certifies and removes such redundant proposals before verifying inclusion
of every input point. No floating hull classification is accepted by itself.

For an externally supplied sparse support, the code first saturates its
convex hull by all integer points. Mere existence of an initially pointed
U-element in a sparse support would not imply the theta witness occupies
the same sparse support, so this saturation is essential.

## 2. Stronger finite acceptance consequence

Let P_theta(g) be the computed carrier. Every rational polynomial F supported
in its integer points, with a_0=1 and satisfying the initial Laurent jets,
has exactly this Newton polytope and every vertex coefficient 1. Otherwise
the deletion algorithm could shrink the polytope further, or a nonconstant
vertex coefficient could be set to zero.

By the principal full-rank upper-bound theorem it belongs to U. The Newton
fingerprint transport lemma, with theta_g as the proof reference, now makes
it compatibly pointed at g in every seed. This is a finite all-seed
pointedness test in arbitrary acyclic rank, including skew-symmetrizable B.
The defining algorithm itself never computes a theta coefficient, a broken
line, a scattering wall, or a representation variety.

If the final affine dimension is zero, its unique rational solution is
theta_g. In particular its coefficients are integral and nonnegative by the
comparison theorem. This gives a complete coefficient algorithm on exactly
the inputs for which this finite dimension test vanishes. It is not claimed
that it vanishes for every g: the rank5 integration example has dimension 1,
and higher multiples in the Kronecker algebra have genuine interior freedom.

## 3. Explicit finite coefficient bounds

The standard product is a product of cluster theta elements. Positive theta
structure constants and the coefficient-one leading degree imply

    M_g = theta_g + sum_(h!=g) c_h theta_h,     c_h>=0.

Consequently, entirely in terms of d,

    0 <= [z^p] F_theta(g) <= product_i binom(d_i,p_i).

There are also explicit bounds on the local positive-packet quotients. For
direction k and off-k exponent a, put

    r=g_k+sum_(j!=k)b_kj a_j,    c=max(-r,0).

For the standard product, c<=d_k and the quotient is

    product_(j!=k)binom(d_j,a_j) * (1+t)^(d_k-c).

The difference M_g-theta_g is universally positive. For r>=0 the quotient
is simply the source fiber; for r<0 it is read with reversed exponents from
the neighboring positive Laurent expansion. Hence the theta packet variables
are bounded coefficientwise by the displayed binomial quotient. This is a
finite integer search box derived from B,g alone. It does not decide which
of its feasible points is the theta function.

## 4. Exact integration and structural validation

The rank5 earlier local-mass failure has d=(2,2,3,2,1). The initial box has
216 points and its signed U-space has vector dimension 44. Normalization
leaves affine dimension 43; 42 nontrivial deletions leave affine dimension 1.
The final carrier has 14 vertices and 32 lattice points and agrees exactly
with the independently constructed Schofield carrier.

The rank4 integration example has box size 48 and signed vector dimension 16.
Fifteen nontrivial deletions leave affine dimension zero. Its carrier has
9 vertices and 15 lattice points. The unique solution is therefore theta_g;
it is the already computed mass25 polynomial. Again the carrier agrees with
the independently computed Schofield carrier.

A further structural validation used 24 acyclic inputs of ranks2--5,
including12 with nonconstant symmetrizer. It performed251 nontrivial exact
eliminations and6821 independent jet checks. Eight runs were repeated with
the opposite deletion order and returned identical final vertices. These24
controlled inputs had final affine dimension zero. Their purpose is to
check the general arithmetic mechanism and valued conventions, not to claim
generic uniqueness from small inputs.

An independent Wolfram calculation built the rank4 jet matrix directly and
returned {48 points,34 equations,rank32,nullity16,standard-product residual0},
matching the Python calculation.

Code/data:
- `theta_newton_pruning.py`
- `theta_newton_pruning_results.json`
- `validate_theta_pruning.py`
- `theta_pruning_validation.json`
- `theta_pruning_validation_certificates.json`

## 5. Remaining main task

The packet-propagation agent has found a rank2 wild candidate on a monic
minimal carrier that is positive in the initial star but has coefficient -1
after the word(0,1). This is not a minimum-mass counterexample. It prevents
replacing the remaining universal-positivity theorem by source-star positivity.

The unresolved part is to extract the interior coefficients by a finite
combinatorial rule with a proved positivity/selection theorem, or to obtain
a finite acceptance certificate for the universal coefficient-positive cone.
The Newton/pointedness part now has an explicit finite algorithm.
