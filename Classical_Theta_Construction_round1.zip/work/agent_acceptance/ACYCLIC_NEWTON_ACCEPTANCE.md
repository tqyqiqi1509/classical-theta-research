# A finite combinatorial Newton certificate for compatible pointedness

Date: 2026-11-13. Status: detailed derivation; parent's independent verification
of the Newton-transport lemma is part of the main research line.

**06:00 UTC update.** The stronger construction in `work/THETA_NEWTON_PRUNING.md`
and `theta_newton_pruning.py` now computes the theta Newton carrier directly
from signed Laurent equations and an acyclic integer box, including
skew-symmetrizable matrices. The Schofield construction below is retained as
an independently justified comparison carrier; it is no longer needed to
obtain a finite all-seed pointedness certificate in the acyclic case.

## Purpose and exact scope

For every classical **acyclic skew-symmetric** exchange matrix B and label g,
this gives a finite integer procedure to produce a Newton polytope P_g and
its monic-vertex requirements. A candidate satisfying these requirements and
the initial Laurent divisibility equations is compatibly pointed in every
seed. Thus it gives a finite acceptance certificate for the pointedness part
of the main problem on an arbitrary-rank class.

The coefficient construction below uses only integer recurrences, rational
convex hulls, and binomial linear equations. Its correctness proof uses the
known generic-character existence/pointedness theorem. No representation,
Grassmannian, scattering diagram, or theta coefficient is an input to the
algorithm. This dependency is explicit: a completely independent proof of
the generic reference theorem is not claimed.

The result does not prove universal coefficient positivity, theta equality,
positive multiplication, or an arbitrary cyclic/skew-symmetrizable Newton
formula. In particular, P_g is **not asserted to be the theta polytope**.

## 1. Explicit acyclic support dimension, including valued matrices

First this part works for any skew-symmetrizable acyclic B. Relabel vertices
in an order for which A=[-B]_+ is strictly lower triangular and P=[B]_+
strictly upper triangular. Set

    d_i = [-g_i + sum_j A_ij d_j]_+,
    v_i = [ g_i - sum_j A_ij d_j]_+.

This is a finite forward integer recurrence. It gives

    g = v-(I-A)d,       d>=0, v>=0,       d_i v_i=0.

Let K=(I-P)^(-1)=I+P+...+P^(n-1). Along the source word w=(1,...,n), a direct
induction in the extended matrix mutation gives

    E_w = (B; -K(I-A)).

For the full tropical mutation map and the linear map on unit-vector labels,

    phi_w(g,0) = ((I-P)d-v, K v),
    psi_w = [ -I  0 ; K  I ].

Here is the induction behind the label formula. Immediately before vertex i
is mutated, its mutable label is g_i-sum_{j<i}A_ij d_j=v_i-d_i. Its mutation
changes the sign; subsequent source mutations contribute -P_ij d_j. The
current positive c-column at step i is the i-th column of K, so the frozen
label accumulates K v. Applying the same calculation to each coordinate unit
gives psi_w.

Consequently

    psi_w E_0 = -E_w,
    psi_w^(-1) phi_w(g,0) = (g+B d, d).

This proves directly, without a generic-representation dimension assumption,
that the recurrence computes the correct two-end support dimension of
Section2 of BIPOINTED_BOUNDARY_RECURRENCE.md.

For an arbitrary vertex ordering, use the reverse topological order for the
arrows of A. `acyclic_dimension` implements this and rejects a directed cycle.

## 2. Integer Euler recursion for the carrier, in the skew-symmetric case

Use the quiver adjacency A=[-B]_+ and its integer Euler form

    <u,v> = sum_i u_i v_i - sum_ij A_ij u_i v_j.

Define finite sets S(d) recursively:

    0,d belong to S(d).
    For 0<e<d coordinatewise,
    e belongs to S(d) iff <a,d-e> >=0 for every a in S(e).

All recursive calls have smaller total dimension. Hence the procedure halts
using only integer addition, multiplication and comparison. Define

    P_g = conv(S(d(g))).

This is the Schofield subdimension recursion, not a new representation
theorem. Its exact source is Schofield, General representations of quivers
(1992), Theorems3.3/5.4. The complete equivalent criterion is directly given
as Theorem2.6 in Franzen--Petrella--Webb, arXiv:2506.20568v1, pp.3--4.
That paper is2025, not2026; it was read rather than inferred from an abstract.

In `schofield_carrier.py`, convex-hull classifications are separately
certified: each claimed vertex has a rational exposing normal; every lattice
point claimed inside has an exact rational convex combination of vertices;
every point outside has a rational separating hyperplane. Floating LP output
without exact verification is rejected.

## 3. Why this is the Newton fingerprint of a pointed reference

The generic cluster character indexed by g exists for the acyclic principal
coefficient algebra and is compatibly pointed at all seeds. This is the
external generic-character interface used in Qin, arXiv:1902.09507v4,
Section5.2 and its citation of Plamondon's Theorem1.3. Its module-part dimension
is d(g): its F-polynomial has componentwise maximum equal to that dimension
and monic full-dimensional term, and the two-end degree computation above
determines that maximum. For an acyclic quiver, the representation space of
each dimension vector is irreducible, so this is the general representation
of dimension d(g); decoration contributes only the initial monomial factor.

Schofield's criterion identifies S(d) with the dimension vectors occurring
in such a general representation. Fei, arXiv:1909.10151v3, Theorem0.4=4.2,
proves that each vertex corresponds to a unique subrepresentation, hence its
Euler coefficient is1. Therefore the generic F-polynomial has Newton
polytope exactly P_g and every vertex coefficient is1. No positivity of its
other Euler coefficients is required or asserted.

The vertex assertion has a short independent argument. Choose a rational
linear functional uniquely maximized at a vertex dimension e. If two
subrepresentations of dimension e existed, their sum and intersection would
both have maximal value, because weights are additive in the corresponding
short exact sequence. Uniqueness of the maximizing dimension forces both
to have dimension e; thus the two subrepresentations coincide. Its
Grassmannian has one point and Euler characteristic1. All other occurring
dimensions lie in P_g, so Euler cancellation at nonvertices cannot shrink
the Newton polytope.

## 4. Finite acceptance theorem

Let F be an integer polynomial such that

1. Supp(F) subset P_g intersect Z^n;
2. every vertex coefficient of P_g is1;
3. x^g F(y_j x^(B[:,j])) is Laurent in the initial n neighbors.

Then f belongs to U by the BFZ full-rank upper-bound theorem. Its initial
Newton polytope and vertex coefficients equal those of the generic reference.
The parent's Newton-fingerprint transport lemma then implies that f is
compatibly pointed at g in **all** seeds.

The transport argument does not need coefficient positivity: outside finitely
many initial Newton walls and mutation comparison walls, there is a unique
leading monomial. Positive birational mutation transports it with leading
coefficient1. Applying this to f and the reference gives equal support
functions and matching extremal coefficients in every chart. Laurentness,
already known from the finite upper-bound test, turns these into actual
Newton polytopes. Thus the reference's unique pointed monomial transfers to f.

All three acceptance requirements are finite, explicit, and independent of
knowing the reference's interior coefficients.

## 5. Constructive coefficient systems and the unresolved positivity part

Within this finite carrier, ordinary Laurent divisibility is a finite integer
linear system. It has at least one integral solution with the required
vertices, supplied in the proof by the generic character. Therefore one may
find a deterministic integral solution by Smith/Hermite linear algebra, or
by increasing finite L1 enumeration. This already produces an all-seed
pointed element by a combinatorial algorithm.

For the intended greedy construction we instead impose nonnegative
coefficients and nonnegative binomial quotient variables, then minimize
coefficient mass or apply the sharper coefficient recurrence. This is the
finite packet problem implemented in `solve_carrier_packets`. Every
successful exact solution is now known globally pointed. Universal positivity
of that selection is still a separate theorem to prove; local packet
positivity must not be renamed universal positivity.

The existence of the generic reference alone does not establish positivity
of its coefficients. A separate argument is now available: the parent has
audited CMMM, arXiv:2505.09585v2, finite-theta valuative independence. Every
nonzero theta summand of the generic reference has Newton polytope contained
in P_g. A generic exposing weight at a vertex can expose a monomial of only
one theta summand; otherwise a linear combination cancelling that monomial
would contradict valuative independence. Since both the reference and theta
vertices are monic, the coefficient of this summand is +1. Replacing negative
theta expansion coefficients by their absolute values therefore retains
exactly P_g and its monic vertices and gives a universally positive element.
Thus the positive packet system is nonempty under the audited finite-theta
hypotheses. This is an existence proof, not a theta-based algorithm input,
and it does not establish positivity of the minimum-mass selection.

## 6. Exact integration checks

- Rank5 chain B12=2,B23=B34=B45=1, g=(-2,2,-1,1,1): d=(2,2,3,2,1).
  Schofield recursion gives32 subdimensions,14 vertices,32 lattice points.
  The finite positive packet system has exact mass minimum46 and is unique:
  its155 zero-slack columns have rank155 modulo1000003. It equals the earlier
  two-chart repaired candidate.
- Rank4 chain B12=4,B23=B34=1, g=(-1,1,1,1): d=(1,3,2,1).
  The carrier has15 lattice points and9 vertices. Exact mass minimum25 is
  unique, with59 zero-slack columns of rank59.

Data: `schofield_packet_repairs.json`. These examples verify the implementation
of the general mechanism; the acceptance theorem is based on the arguments
and named external inputs above, not on these finite tests.

## 7. Extensions that are and are not justified

With a specified mutation path to an acyclic seed, one may construct in that
seed and transport exactly. This covers mutation-acyclic skew-symmetric
algebras, with ordinary A=U in that class (with the stated frozen localization).
It does not decide whether an arbitrary quiver is mutation-acyclic.

The d-recurrence and two-sided boundary theorem already cover valued acyclic
matrices. The Schofield carrier theorem above has only been justified for
ordinary skew-symmetric quivers. A weighted Euler-form substitution for a
valued quiver would require its own theorem; it is not silently assumed.

For genuinely cyclic cluster algebras, the generic path-algebra subdimension
polytope ignores the Jacobian relations of a potential. Hence applying the
same Euler recursion there does not supply a valid cluster reference and is
not an extension proved here.
