"""Independent integer certificate for the squarefree cycle forest formula.

This checks an algebraically proved sharpness word, not a guessed BFS bound.
"""
from pathlib import Path
from math import prod
from random import Random
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from squarefree_forest_probe import initial_E,mutate_matrix,symmetrizer,forest_coefficients

def cycle_matrix(a):
    n=len(a); B=[[0]*n for _ in a]
    for i in range(n):B[i][(i+1)%n]=a[i];B[i][(i-1)%n]=-a[i]
    return B

def coefficients(a,r):
    n=len(a);N=1<<n;A=[]
    for s in range(N):
        A.append(prod(r[i]+(a[i]if s>>((i-1)%n)&1 else 0)
                      for i in range(n)if s>>i&1))
    A[-1]-=prod(a)+sum(r[i]*prod(a[j]for j in range(n)if j!=i)for i in range(n))
    return A

def apply_word(B,g,A,word):
    n=len(B);N=1<<n;D=symmetrizer(B);E=initial_E(B);F=list(A)
    for k in word:
        c=tuple(E[n+i][k]for i in range(n));alpha=tuple(abs(x)for x in c)
        assert not(any(x>0 for x in c)and any(x<0 for x in c))
        if max(alpha)<=1:
            a=sum(1<<i for i in range(n)if alpha[i]);out=list(F)
            for p in range(N):
                if p&a!=a:continue
                num=sum(c[i]*D[i]*(g[i]+sum(B[i][j]for j in range(n)if p>>j&1))for i in range(n))
                assert num%D[k]==0
                out[p]+=num//D[k]*F[p^a]
            F=out
        E=mutate_matrix(E,k)
    return F

def check(a,r):
    n=len(a);B=cycle_matrix(a);A=coefficients(a,r);word=[0]+list(range(n-1,1,-1))
    F=apply_word(B,[-x for x in r],A,word)
    assert min(A)>=0
    assert F[-1]==0,(a,r,F[-1])
    assert all(F[s]==int(s==0)for s in range(1<<n)if not(s&2)),(a,r,'restriction')
    assert min(F)>=0,(a,r,F)
    if n<=6:assert A==forest_coefficients(B,r,True),(a,r,'forest')
    return {'n':n,'a':a,'r':r,'word':word,'initial_top':A[-1],'transformed_top':F[-1]}

if __name__=='__main__':
    rng=Random(88401);out=[];start=time.time()
    for n in range(3,9):
        for _ in range(60):
            a=[rng.randint(1,9)for _ in range(n)]
            r=[rng.randint(0,7)for _ in range(n)]
            out.append(check(a,r))
    result={'checked':len(out),'max_rank':8,'all_passed':True,'seconds':time.time()-start,
            'cases':out}
    (Path(__file__).parent/'cycle_forest_certificate_results.json').write_text(json.dumps(result,indent=2))
    print({k:v for k,v in result.items()if k!='cases'})
