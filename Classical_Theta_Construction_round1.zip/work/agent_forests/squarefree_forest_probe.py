"""Exact finite-depth probes of direct squarefree forest candidates.

Finite BFS is evidence only.  This file does not assert all-word sufficiency.
"""
from pathlib import Path
from itertools import product
from collections import deque
import sys, json, time

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_division'),str(ROOT/'agent_cutcones')]
from principal_cluster import mutate_matrix
from truncated_atlas import symmetrizer
from exact_laurent_mutation import initial_E

def mul(a,b):
    n=(len(a)-1).bit_length(); out=[0]*(1<<n)
    for s,x in enumerate(a):
        if not x: continue
        rem=((1<<n)-1)^s; t=rem
        while True:
            if b[t]:out[s|t]+=x*b[t]
            if t==0:break
            t=(t-1)&rem
    return tuple(out)

def transform(B,g,H):
    n=len(B);N=1<<n; cols=[]
    for q in range(N):
        p=[0]*N;p[0]=1
        for i in range(n):
            # H_i-1 is divisible by z_i, hence its square vanishes.
            e=g[i]+sum(B[i][j]for j in range(n)if q>>j&1)
            factor=tuple(1 if s==0 else e*H[i][s]for s in range(N))
            p=mul(tuple(p),factor)
        cols.append(tuple(p[s^q]if s&q==q else 0 for s in range(N)))
    return tuple(tuple(cols[q][s]for q in range(N))for s in range(N))

def atlas(B,depth,seed_cap=250000,bit_cap=512):
    n=len(B);N=1<<n;D=symmetrizer(B);unit=(1,)+(0,)*(N-1)
    H0=(unit,)*n; HH=[H0]; hindex={H0:0};words=[()]
    E0=initial_E(B);seen={E0:0};queue=deque([(E0,0,(),-1)]);pruned=0;cache={}
    while queue:
        E,tid,w,last=queue.popleft()
        if len(w)>=depth:continue
        for k in range(n):
            if k==last:continue
            EE=mutate_matrix(E,k)
            if max(abs(v).bit_length()for row in EE for v in row)>bit_cap:
                pruned+=1;continue
            c=tuple(E[n+i][k]for i in range(n));alpha=tuple(abs(v)for v in c)
            if any(v>0 for v in c)and any(v<0 for v in c):raise AssertionError('c sign')
            if max(alpha)>1:ntid=tid
            else:
                key=(tid,c,D[k]);ntid=cache.get(key)
                if ntid is None:
                    a=sum((1<<i)for i in range(n)if alpha[i]);out=[]
                    for h in range(n):
                        vals=list(HH[tid][h])
                        for p in range(N):
                            if p&a!=a:continue
                            num=sum(c[i]*D[i]*(int(i==h)+sum(B[i][j]for j in range(n)if p>>j&1))for i in range(n))
                            assert num%D[k]==0
                            vals[p]+=num//D[k]*HH[tid][h][p^a]
                        out.append(tuple(vals))
                    H=tuple(out);ntid=hindex.get(H)
                    if ntid is None:ntid=len(HH);hindex[H]=ntid;HH.append(H);words.append(w+(k,))
                    cache[key]=ntid
            if EE in seen:
                assert seen[EE]==ntid
                continue
            if len(seen)>=seed_cap:pruned+=1;continue
            seen[EE]=ntid;queue.append((EE,ntid,w+(k,),k))
    return {'depth':depth,'seeds':len(seen),'jets':len(HH),'pruned':pruned},HH,words

def saturate(B,g,HH,words):
    n=len(B);N=1<<n;TT=[transform(B,g,H)for H in HH];A=[0]*N;A[0]=1;witness={}
    for p in sorted(range(1,N),key=lambda p:(p.bit_count(),p)):
        vals=[-sum(row[p][q]*A[q]for q in range(N)if q!=p)for row in TT]
        A[p]=max([0]+vals)
        if A[p]>0:witness[p]=words[vals.index(A[p])]
    return A,witness

def forest_coefficients(B,r,kill_radical=False):
    """Sum directed spanning forests on each induced subset.

    Every non-root chooses a parent i with B[i][j]>0. A directed component
    carries weight r_root, multiplied by edge weights -B[j][i]. Optionally
    delete every component whose indicator is in ker B (non-singleton).
    """
    n=len(B);N=1<<n;out=[0]*N;out[0]=1
    for s in range(1,N):
        vertices=[i for i in range(n)if s>>i&1]
        choices=[[None]+[i for i in vertices if B[i][j]>0]for j in vertices]
        for selected in product(*choices):
            parent=dict(zip(vertices,selected));roots={};good=True;weight=1
            for v in vertices:
                path=set();i=v
                while parent[i] is not None:
                    if i in path:good=False;break
                    path.add(i);i=parent[i]
                if not good:break
                roots[v]=i
            if not good:continue
            for j,p in parent.items():weight*=r[j]if p is None else -B[j][p]
            if kill_radical:
                for root in set(roots.values()):
                    comp=[i for i in vertices if roots[i]==root]
                    if len(comp)>1 and all(sum(B[i][j]for j in comp)==0 for i in range(n)):
                        good=False;break
            if good:out[s]+=weight
    return out

def cumulants(A):
    # distinguished-vertex partition recurrence avoids rational logarithms.
    N=len(A);K=[0]*N
    for s in sorted(range(1,N),key=lambda s:(s.bit_count(),s)):
        v=s&-s;tot=A[s];t=(s-1)&s
        while t:
            if t&v:tot-=K[t]*A[s^t]
            t=(t-1)&s
        K[s]=tot
    return K

def run():
    tests=[]
    for n in (3,4,5):
        for edge in (1,2):
            if n==5 and edge==2:continue
            B=[[0]*n for _ in range(n)]
            for i in range(n):B[i][(i+1)%n]=edge;B[(i+1)%n][i]=-edge
            tests.append((f'cycle{n}_{edge}',B,8 if n<=4 else 6))
    tests.extend([('path3',[[0,2,0],[-2,0,3],[0,-3,0]],7),
                  ('fork3',[[0,2,3],[-2,0,0],[-3,0,0]],7),
                  ('cyclic223',[[0,2,-2],[-2,0,3],[2,-3,0]],10),
                  ('acyclic_complete3',[[0,2,3],[-2,0,4],[-3,-4,0]],7)])
    out=[]
    for name,B,depth in tests:
        meta,HH,words=atlas(B,depth);cases=[]
        for r in ([1]*len(B),list(range(1,len(B)+1))):
            A,w=saturate(B,[-v for v in r],HH,words)
            P=forest_coefficients(B,r,True);K=cumulants(A)
            case={'r':r,'A':A,'K':K,'candidate':P,'differences':[{'support':s,'actual':a,'forest':p,'word':w.get(s)}for s,(a,p)in enumerate(zip(A,P))if a!=p]}
            cases.append(case)
        item={'name':name,'B':B,'atlas':meta,'cases':cases};out.append(item)
        print(name,meta,[(x['r'],len(x['differences']),x['A'][-1],x['candidate'][-1])for x in cases],flush=True)
        (Path(__file__).parent/'squarefree_forest_results.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':run()
