# Integer signed-cycle polarization: what it solves and what it does not

Primary source audited: Travis Mandel, arXiv:1503.06183v5 (2019),
*Scattering diagrams, theta functions, and refined tropical curve counts*.
Read Sections 3.1.1, 3.1.2, 3.2.1, 3.2.3, Theorem 3.9 and Remark 3.10,
and the classical A-principal setup in Section 4.2.2.
https://arxiv.org/html/1503.06183v5

## A useful integral reformulation

Use the classical derivations

    E_p(x^g y^q)=<Dp,g> z^p x^g y^q,
    [E_p,E_q]=(p^TDBq) E_(p+q).

For an elementary binomial factor in primitive root direction alpha, with
delta=gcd(D alpha), its logarithm is

    eps/delta · sum_(m>=1) (-1)^(m+1) E_(m alpha)/m².

Introduce a variable t recording this root multiplicity and polarize
t -> u_1+...+u_k with u_j²=0. For an m-element subset J,

    [u_J] log U
      = eps (-1)^(m+1) (m-1)!
        z^(m alpha) ((D alpha)/delta)·(x ∂_x).                (*)

This is integral: E_(m alpha) itself carries a factor m. In particular, the
apparent m² denominator must not be assessed in the normalized E-basis while
forgetting that factor. For an initial simple direction e_i, (*) is simply

    eps (-1)^(m+1) (m-1)! z_i^m x_i ∂_(x_i).

The factor (m-1)! counts cyclic orders on J. Thus a polarized leaf can be
defined as a same-color cyclically ordered block, with the sign of a
permutation cycle. Monomial derivations with integral exponent and integral
logarithmic direction are closed under brackets and act integrally on Laurent
monomials. Hence the iterated leaf brackets have signed integer weights.

The familiar single-factor cancellation is exact:

    exp(k log(1+t))=(1+t)^k.

After polarization, signed collections of cyclic blocks collapse to injections
of the labels into k slots when k>=0. After forgetting labels, the coefficient
is binomial(k,m). Negative k gives the usual signed multiset count. This is the
appropriate local cycle-to-subset mechanism, not a remaining 1/m² obstruction.

## Two genuine global obstructions remain

1. Mandel's admissible trees still depend on affine incidence data: translated
   initial hyperplanes, realizable edge lengths, and a prescribed generic
   endpoint far away. The binary bracket recursion does not by itself decide
   which trees contribute. Replacing that data by the same linear feasibility
   tests called "graph compatibility" would merely rename tropical disks.
2. Polarizing a coefficient of multidegree p produces (product_i p_i!) times
   that coefficient. Integer leaf weights do not furnish a free label action
   on the contributing trees with fixed generic incidence data. One still
   needs an independent packet cancellation or an explicit integer orbit model
   to recover the unpolarized coefficient. Global integrality from the known
   theta theorem is a comparison result, not such a model.

Mandel's ribbon-tree remark changes brackets into signed associative products;
it leaves both obstructions intact. The audited theorem therefore supplies
motivation and a possible comparison theorem, not an acceptable independent
construction under the current task's rules.

## Productive direction after this audit

The balanced-cycle squarefree theorem in the companion note is a substantive
example of replacing all incidence conditions: its objects are ordinary
colored directed forests with one explicit exclusion rule, and its recurrence
uses only B and g. It works because every proper connected support is acyclic
and the full connected logarithmic block is radical, hence zero.

For general graphs, the next missing datum is a direct integer rule for a
**nonradical connected block**. It must perform the cycle cancellation before
the blocks are assembled into disjoint forests. The unequal 223 triangle is
the smallest retained obstruction to simply using all rooted trees and
deleting radical blocks. An attractor/flow-tree recursion with geometric
admissibility still present would not resolve this requirement.
