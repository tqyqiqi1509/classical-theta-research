# A direct forest formula on balanced cycles of arbitrary rank

Research note, 2026-11-13. Classical principal coefficients throughout.

## Exact scope

This note gives a finite positive integer graph formula for **every squarefree
coefficient** of every initially nonpositive label on an arbitrary-rank
row-balanced directed cycle. It proves equality with the corresponding formal
theta coefficients by a separately identified comparison argument. It also
proves that these coefficients are the successive sharp minima for all actual
original-frozen seed-transport inequalities, once proper squarefree
coefficients have been fixed at their stated values.

It does **not** assert that the squarefree truncation is a full cluster
function, or settle repeated-coordinate coefficients or labels of mixed sign.
The formula does not construct a scattering diagram or a representation space.

## 1. The graph construction

Let n>=3, let a_0,...,a_(n-1) be positive integers, and use cyclic indices. Set

    b_(i,i+1)=a_i,   b_(i,i-1)=-a_i,

with all other entries zero. For n=3 these give the three entries in each row
without overlap. This is skew-symmetrizable: D_i=L/a_i for any common multiple
L of the a_i. When all a_i are equal, B is skew-symmetric. We have B·1=0.

Let g=-r with r_i>=0 integers. Draw the directed cycle i -> i+1. An edge
i -> i+1 has **a_(i+1)** distinguishable colors. A root at vertex i has r_i
distinguishable colors.

For each subset S of vertices, count directed forests covering S, with edges
oriented away from roots, subject to this extra rule:

> No component may contain all n vertices.

The roots and edges have the colors just specified. Each nonroot chooses its
unique possible parent, its predecessor on the cycle. Thus the objects are
finite ordinary colored graphs. Let A_S be their number, and set A_empty=1.

Equivalently, for a proper subset S,

    A_S = product_(i in S) (r_i + a_i·1_(i-1 in S)).                 (1)

For the full set V,

    A_V = sum_(R subset V, |R|>=2)
              product_(i in R) r_i · product_(i notin R) a_i       (2)

        = product_i(r_i+a_i) - product_i a_i
          - sum_i r_i product_(j != i) a_j.

Formula (2) is positive in its subset form. The subtraction form is only an
efficient identity. For n=3 it is exactly the monomer-edge matching expression
previously proved on the all-nonpositive sign cone. For a_i=a and r_i=1,

    A_V=(1+a)^n-a^n-n a^(n-1).

Examples: a=1 gives 4,11,26,57 for n=3,4,5,6; a=2 gives
7,33,131,473.

Write F^sf_(B,-r)=sum_(S subset V) A_S z^S in
Z[z_0,...,z_(n-1)]/(z_i^2). This is the complete definition. It calls no theta
coefficient, wall, endpoint, seed search, or geometric moduli object.

## 2. An acyclic slot-tree lemma

For any acyclic integral skew-symmetrizable B, order its vertices so that
b_ij>0 implies i<j. Put w_ij=-b_ji for each arrow i->j. Define backwards

    P_i = 1 + z_i product_(j:i->j) P_j^(w_ij).                    (3)

This is a finite polynomial recurrence with positive integer coefficients.
It counts rooted trees whose vertex of color i has w_ij distinct optional
child slots of color j. There is no repeated-color path, because the quiver
is acyclic. For r_i>=0, product_i P_i^(r_i) counts such rooted forests with
r_i available root slots of color i.

The ordinary exchange recurrence proves that the reversed topological
mutation sequence gives variables with initial g-vectors -e_i and
F-polynomials P_i. At the step mutating i, every already-mutated outgoing
neighbor j contributes P_j^(-b_ji), the principal c-vector remains e_i, and
the other exchange term is 1. The same induction in the g-vector recurrence
gives -e_i. Hence (3) is an elementary cluster-monomial formula, valid for
arbitrary symmetrizers.

On a squarefree cap every used color occurs once. The slot trees become
directed rooted spanning forests, with edge multiplicity w_ij and root
multiplicity r_i. On a proper induced subgraph of our cycle these are paths,
and independent parent/root choices give (1).

## 3. External comparison lemma: the negative chamber

This section uses theta theory **only to prove equality of the independently
defined graph formula with theta coefficients**.

In the initial principal coordinate lattice, theta functions are indexed by
(g,0). Their mutable asymptotic direction is g. All walls have normals Dp
with p>=0; their mutable monomial shifts are Bp. Thus the open negative
orthant is disjoint from their supports.

For g<=0 and an endpoint Q in this open orthant, the only broken line of
asymptotic direction g is the straight line with monomial x^g. Here is the
precise sign check. Suppose bends add Bp_1,...,Bp_k, p_j>=0, and put
s_k=p_1+...+p_k. After the first bend the line is in the nonnegative halfspace
of Dp_1. Inductively the kth bend point is in {m:<Ds_k,m>>=0}; on its following
segment the derivative pairs with Ds_k as

    <Ds_k, -g-Bs_k> = -<Ds_k,g> >= 0,

using skew-symmetry of DB. The entire final segment remains in this halfspace,
which excludes Q. Therefore a line with a bend cannot end at Q. If an initial
pairing is zero the first segment cannot cross that hyperplane, so boundary
labels g_i=0 cause no exception.

This is GHKK, arXiv:1411.1394v2, Proposition 3.8's proof with both halfspace
inequalities reversed. Zhou, arXiv:1901.04166v3, Section 4, explicitly records
the same reversal for negative chambers (HTML around line 831). GHKK Theorem
3.5 transports the theta function while keeping its **same asymptotic index**+(g,0); only Q changes. Consequently, in the initial positive chart,

    theta_(-r) = product_i theta_(-e_i)^(r_i)                     (4)

as formal principal-coefficient series. This does not require the negative
chamber to belong to the cluster complex, or any finiteness assertion.

The g-vector and endpoint are in the same initial mutable M-space throughout.
No sign reversal of the theta label occurs in (4).

## 4. External comparison: determining each squarefree root polynomial

Write theta_(-e_i)=x_i^(-1) P_i^theta. The normalized chamber transport has
P_i^theta-1 divisible by z_i: every positive root derivation whose direction
has zero i-coordinate fixes x_i, and all other increments retain z_i.

Setting z_j=0 outside S retains exactly terms whose every root degree is
supported on S. The positive grading makes the quotient of the root Lie
algebra the one for the induced principal submatrix B_SS. The compatible
diagram and broken-line comparison commute with this quotient. Thus each
coefficient supported on a proper S is obtained from the acyclic induced
path graph and (3). In particular its root polynomial is a single forward
path beginning at i.

The coefficient at the full squarefree degree 1 is zero. To justify this
without guessing a normalization, recall the elementary bracket identity

    [E_u,E_v]=(u^T D B v)E_(u+v).

No non-axis radical degree p with Bp=0 is produced from initial simple
derivations: every bracket ending in total degree p has factor
u^TDB(p-u)=0, and no initial logarithm contains such a degree. The completed
chamber transport therefore has no radical Hamiltonian generator.

For any normalized unit F, its logarithmic coefficient at radical p is
invariant under such transport. Indeed, a generator E_u reaching that degree
from q=p-u acts on z^q with factor u^TDBq=0; its action on x^g could contribute
only if u=p, which is absent. Initially at the negative endpoint the normalized
unit is 1. Hence [z^1]log P_i^theta=0. Because P_i^theta-1 is divisible by z_i,
all its powers of order >=2 vanish on the squarefree cap, so
[z^1]P_i^theta=0 as well.

We have proved the explicit root formula

    P_i^theta mod(z_j^2)
       = 1 + sum_(ell=1,...,n-1)
          z_i z_(i+1)...z_(i+ell-1)
          product_(h=1,...,ell-1) a_(i+h).                       (5)

Combining (4) and (5) gives exactly the forest construction (1)-(2): disjoint
forward paths with colored roots and edges, and no path covering the whole
cycle. Thus F^sf_(B,-r) is the squarefree truncation of theta_(-r)'s normalized
series. This proves all-word formal coefficient nonnegativity via the usual
positive-theta comparison, with its reliance on that external theorem explicit.

## 5. A finite actual word proves sharpness

Now retain the original-frozen normalized transport T_t^g used in the main
research programme. Assume every proper squarefree A_S has its forest value.
The coefficient of the unknown A_V in every transported top row is 1.

Take the **actual mutation word**

    w=(0,n-1,n-2,...,2),                                         (6)

of length n-1, leaving vertex 1 unmutated. After setting z_1=0, this is precisely
the reversed topological sequence on the path

    2 -> 3 -> ... -> n-1 -> 0.

By the elementary acyclic lemma, it sends the restricted normalized series
of label -r to 1. Hence every nonconstant term of T_w^(-r)F^sf is divisible
by z_1. On the squarefree cap its square is zero. Its full-degree coefficient
therefore equals its full-degree logarithmic coefficient. The latter is zero
by the original-frozen radical invariant, since B·1=0 and the initial forest
series has zero full-degree logarithm by (4)-(5), or directly by the partition
identity for forests with no spanning component.

Consequently the top row for the actual word (6) vanishes at A_V. Any smaller
integer violates that row. Together with the all-word upper bound from Section
4, this proves exact successive minimality at full support. Proper supports
are sharp by their reversed topological words. This is a proof for all words,
not an inference from observed BFS stabilization.

The sharpness proof itself needs only the exchange/tree lemma, the elementary
radical invariant and the graph partition identity. The external theta
comparison is used for the upper bound and identification.

## 6. Exact verification and an important failure

`cycle_forest_certificate.py` verifies the closed graph count independently
against forest enumeration, applies (6) by exact integer binomial mutation,
checks the z_1=0 restriction and verifies the vanished top coefficient. The
360 deterministic random cases cover n=3,...,8, a_i=1,...,9, r_i=0,...,7,
including nontrivial symmetrizers. All passed. The JSON file retains every
case and its witness word.

Earlier unpruned finite BFS probes agreed on C3/C4 with edge weights 1/2 and
C5 with edge weight 1, at both constant and varying labels. Those probes are
supporting checks, not the all-word proof.

The simple rule "keep all rooted forests except radical components" fails
outside the balanced-cycle setting. For

    B=[[0,2,-2],[-2,0,3],[2,-3,0]],

the connected squarefree cubic coefficient is exactly 2r_0+2r_1, whereas all
spanning rooted trees give 6r_0+6r_1+4r_2. This is certified without a BFS-limit
assumption: the actual word (0,2,0,1,2,0) gives g-vectors
(-e_0,-e_2,-e_1). Direct exchange recurrence gives the three full positive
F-polynomials, and their squarefree z_0z_1z_2 coefficients are respectively
2,0,2. Since each root unit is divisible by its own z_i, these are also the
connected logarithmic coefficients. Their cluster-monomial products establish
the claimed formula for every r>=0. Since B·1 is nonzero, the radical deletion
rule removes nothing and genuinely overcounts theta coefficients.

The certificate is `cyclic223_exact_negative_seed.json`; it includes the word,
final C- and g-matrices and the complete F-polynomials. The short reproducible
exchange check is `cyclic223_exact_negative_seed.py`. The initial finite
saturation observations are separately retained in `squarefree_forest_results.json`.
No general forest theorem is claimed from the special cycle result.

## Primary comparison sources read

- Gross--Hacking--Keel--Kontsevich, *Canonical bases for cluster algebras*,
  arXiv:1411.1394v2, Theorem 3.5, Proposition 3.8 and its full proof,
  Corollary 3.9. https://arxiv.org/html/1411.1394v2
- Yan Zhou, *Cluster Structures and Subfans in Scattering Diagrams*,
  arXiv:1901.04166v3 / SIGMA 16 (2020), 013, Section 4's negative-chamber
  proof. https://arxiv.org/html/1901.04166v3

Neither source is being cited for the new graph formula or its short sharpness
word; those are derived above. The formula is a finite construction only on
its explicitly stated squarefree cap.
