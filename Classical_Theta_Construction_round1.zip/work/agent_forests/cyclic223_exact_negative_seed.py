"""Exact exchange certificate against naive radical-only forest deletion."""
from pathlib import Path
import sys,json,sympy as sp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'agent_division'))
from principal_cluster import initial,mutate

B=[[0,2,-2],[-2,0,3],[2,-3,0]]
word=[0,2,0,1,2,0]
z=sp.symbols('z0:3');t=initial(B)
for k in word:t=mutate(B,t,k,z)
assert t[2]==((-1,0,0),(0,0,-1),(0,-1,0))
roots=[]
for i in range(3):
    j=t[2].index(tuple(-int(k==i)for k in range(3)))
    F=sp.Poly(t[1][j],*z)
    assert all(c>=0 and c.is_Integer for c in F.coeffs())
    roots.append([int(F.coeff_monomial(sp.prod(z[k]for k in range(3)if s>>k&1)))for s in range(8)])
assert [F[-1]for F in roots]==[2,2,0]
result={'B':B,'word':word,'C':t[0][3:],'g_vectors':t[2],
        'exact_F_polynomials':[str(F)for F in t[1]],
        'root_squarefree_coefficients':roots,'connected_cubic_root_weights':[2,2,0],
        'naive_forest_root_weights':[6,6,4],'all_checks_passed':True}
(HERE/'cyclic223_exact_negative_seed.json').write_text(json.dumps(result,indent=2))
print({k:result[k]for k in ('word','g_vectors','connected_cubic_root_weights','all_checks_passed')})
