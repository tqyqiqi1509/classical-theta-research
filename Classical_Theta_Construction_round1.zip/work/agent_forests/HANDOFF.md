# Handoff — direct integer forests branch

Owner `/root/direct_integer_forests`; 2026-11-13, approximately 06:13–06:25 UTC.
Root handles persistence; this directory has no separate Library artifact.

## Main result

`BALANCED_CYCLE_SQUAREFREE_FORESTS.md` proves an arbitrary-rank graph formula
for every **squarefree coefficient and every label g<=0** on the row-balanced
directed-cycle family

    b_(i,i+1)=a_i, b_(i,i-1)=-a_i, a_i>0; D_i=L/a_i.

For r=-g, the coefficient at a proper subset S is

    A_S=product_(i in S)(r_i+a_i·1_(i-1 in S)).

At the full set V it is

    A_V=sum_(R subset V, |R|>=2)
              product_(i in R)r_i · product_(i notin R)a_i.

Objects: colored directed rooted forests on the cycle, edge i->j has a_j
colors, root i has r_i colors, and a component may not span the entire cycle.
The construction itself uses no theta, walls, endpoints or representation
spaces. It generalizes the cubic monomer-dimer formula to arbitrary rank and
nontrivial symmetrizers. It is only a cap theorem, not the requested full basis.

## Proof components and their scope

1. **Elementary acyclic slot trees.** In topological order,
   P_i=1+z_i product_(j:i->j) P_j^(-b_ji). Reversed topological mutation gives
   g=-e_i and these F-polynomials. Squarefree coefficients are directed forests.
2. **Audited external comparison:** formal negative-chamber theta functions
   multiply, theta_(-r)=product_i theta_(-e_i)^(r_i). GHKK Thm3.5 keeps the
   asymptotic index fixed when Q moves. Prop3.8's proof with inequalities
   reversed makes theta_(Qnegative,g)=x^g for g<=0. Zhou1901.04166v3 Section4
   explicitly confirms that reversal. No assertion that the negative chamber
   is reachable, or that the formal functions are polynomials in cyclic type.
3. **Support and radical:** proper cycle supports induce acyclic paths; at full
   p=1, Bp=0. The Lie bracket cannot generate non-axis radical degrees. Thus
   the logarithmic coefficient vanishes under chamber transport. A root unit
   minus1 is divisible by its root z_i, so its square vanishes on this cap.
   Each theta_(-e_i) is therefore the sum of proper forward paths beginning i.
   Multiplication proves the graph formula. Known theta positivity supplies
   the explicitly external all-word upper bound.
4. **Independent finite sharpness witness:** actual word (0,n-1,n-2,...,2),
   length n-1. Set z1=0: the word is acyclic negative transport, giving unit1.
   Hence the transported tail is divisiblez1, and squarefree log equals tail.
   The elementary original-frozen radical invariant makes its top coefficient0.
   Thus any smaller top coefficient violates this actual word. Proper supports
   use their reversed topological words. This proves successive all-word
   minimality on the cap; it does not infer it from BFS stabilization.

`cycle_forest_certificate.py` checked 360 deterministic exact cases through
rank8, arbitrary row parameters1..9, labels r_i0..7. It independently compares
graph enumeration and formula, checks the explicit word, the z1=0 restriction,
and top0. All pass; every case is in its JSON output.

## Important failure retained

For B=[[0,2,-2],[-2,0,3],[2,-3,0]], all rooted spanning trees overcount the
squarefree cubic block. The connected coefficient is **exactly** 2r0+2r1,
versus tree sum 6r0+6r1+4r2. This was first detected by finite-depth saturation,
then promoted to an exact certificate: actual word (0,2,0,1,2,0) has g-vectors
(-e0,-e2,-e1). Direct exchange recurrence computes the full F-polynomials and
their cubic coefficients2,0,2. Cluster-monomial products prove the formula
for every r>=0. Thus the nonradical 111 block genuinely falsifies the naive
radical-deletion forest candidate, with no extrapolation from BFS depth.
Exact files: `cyclic223_exact_negative_seed.py` and matching JSON certificate.
Finite exploratory files remain `squarefree_forest_probe.py` and its JSON.

## Mandel audit / denominator insight

`MANDEL_POLARIZATION_AUDIT.md` records the primary paper audit and exact formula:

    m!·E_(m alpha)/(delta m²)
      =(m-1)! z^(m alpha) ((D alpha)/delta)·(x∂x).

Thus nilpotent label polarization turns every multicover leaf into an integer
signed cycle of labels, not a rational weight. All iterated monomial-derivation
brackets remain integral. Single-factor cycle cancellation yields binomial
slot/subset counts. What remains is global unpolarization and, more seriously,
an independent admissibility rule replacing translated hyperplanes and root
endpoints. Mandel's tropical/ribbon theorem does not itself satisfy the user's
construction requirement.

## Next general obstacle

The negative label cone reduces formally to n root series, and disjoint-block
assembly is elementary. The unresolved general combinatorial datum is the
integer coefficient of each **nonradical connected rooted block**. A useful
next branch should attack these weights with graph cuts, cycle cancellations,
or genuine integer recurrences. Do not extend the cycle forest exclusion rule
to arbitrary graphs, and do not treat an attractor/flow-tree formula retaining
geometric admissibility as a new solution.

## Primary URLs opened and checked

- https://arxiv.org/html/1411.1394v2 — GHKK3.5,3.8 full proof,3.9.
- https://arxiv.org/html/1901.04166v3 — negative-chamber proof in Section4.
- https://arxiv.org/html/1503.06183v5 — Mandel3.1.1,3.1.2,3.2.1,3.2.3,3.9,
  ribbon remark3.10 and classical principal A setup4.2.2.

The 2026 search refresh found Reading–Stella2603.23429 and the published
SIGMA2026/109 version of2603.19391 already under root's audit. Neither is an
input to this branch's theorem. An accidental guessed arXiv1805.11596 lookup
was unrelated and is unused. No unsupported result is imported from it.
