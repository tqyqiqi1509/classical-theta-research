from packet_bounds import *
from itertools import product

def hull2(points):
    points=sorted(set(points))
    if len(points)<=1:return points
    def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    lower=[]
    for p in points:
        while len(lower)>=2 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
        lower.append(p)
    upper=[]
    for p in reversed(points):
        while len(upper)>=2 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
        upper.append(p)
    return lower[:-1]+upper[:-1]

def carrier2(F):
    V=hull2(F);d=[max(p[i] for p in V) for i in range(2)]
    if len(V)==1:points=V
    elif len(V)==2:
        a,b=V;dx=b[0]-a[0];dy=b[1]-a[1];gg=math.gcd(dx,dy)
        points=[(a[0]+j*dx//gg,a[1]+j*dy//gg) for j in range(gg+1)]
    else:
        points=[]
        for p in product(*(range(a+1) for a in d)):
            if all((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>=0 for a,b in zip(V,V[1:]+V[:1])):points.append(p)
    return {'vertices':V,'lattice_points':points,'d':d,'source':'known LLZ support; mechanism test only'}

def main():
    tic=time.time();stats={'cases':0,'success':0,'infeasible_lower':0,'wrong_feasible':0};out=[]
    for b,c in [(2,2),(3,3),(4,4),(2,3),(3,2),(1,5)]:
        for a1,a2 in product(range(1,13),repeat=2):
            g=(-a1,c*a1-a2);F=llz_F(b,c,g)[0];C=carrier2(F)
            r=run_case([[0,b],[-c,0]],g,carrier=C,theta=F,seed_forced=True,global_rows=True)
            stats['cases']+=1
            if r['lower_feasible'] and r['theta_equal_lower']:stats['success']+=1
            else:
                stats['infeasible_lower' if not r['lower_feasible'] else 'wrong_feasible']+=1;out.append(r)
                (Path(__file__).parent/'packet_bounds_global_ranktwo_first_failure.json').write_text(json.dumps({'result':r,'carrier':C},indent=2))
                print('FAIL',r,flush=True)
                break
        print(b,c,stats,'seconds',time.time()-tic,flush=True)
        (Path(__file__).parent/'packet_bounds_global_ranktwo_results.json').write_text(json.dumps({'stats':stats,'failures':out,'seconds':time.time()-tic},indent=2))
        if out:break

if __name__=='__main__':main()
