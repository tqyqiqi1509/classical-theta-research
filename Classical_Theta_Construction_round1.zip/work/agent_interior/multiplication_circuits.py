#!/usr/bin/env python3
"""Classify positive circuits in the multiplication face x_i F.

The input coefficient table F is a computed packet candidate, never assumed
to be theta. We restrict the g+e_i packet cone to the support of its full
packet vector; this is exactly the face containing the multiplication image.
"""
from positive_circuits import *

def packet_values(M,F):
    vals=[]
    cache={}
    for key in M['columns']:
        if key[0]=='a':vals.append(F.get(key[1],0))
        else:
            _,k,off,s,d=key;kk=(k,off,d)
            if kk not in cache:cache[kk]=[]
            q=cache[kk]
            while len(q)<=s:
                t=len(q);p=off[:k]+(t,)+off[k:]
                q.append(F.get(p,0)-sum(math.comb(d,j)*q[t-j] for j in range(1,min(d,t)+1)))
            vals.append(q[s])
    return vals

def classify_multiplication(B,g,C,F,i,ray_cap=3000,check_minimal=False):
    gg=list(g);gg[i]+=1;M=build(B,gg,list(map(tuple,C['lattice_points'])))
    R,W,refs,space=integer_parameter_rows(B,gg,M)
    image=packet_values(M,F)
    if any(v<0 for v in image):raise ArithmeticError('multiplication not positive')
    eq=[tuple(-c for c in row) for row,v in zip(W,image) if not v]
    rays,steps=double_description(W+eq,len(R[0]),ray_cap)
    result=[]
    for ray in rays:
        v=[sum(a*b for a,b in zip(row,ray)) for row in R]
        a={p:v[j] for p,j in M['ids'].items() if v[j]}
        q=tuple(min(p[k] for p in a) for k in range(len(g)))
        pointed=q in a
        z={'primitive_parameter':ray,'pointed':pointed,'coordinate_minimum':q,
           'mass':str(sum(a.values())),'F':[{'p':p,'a':str(c)} for p,c in a.items()]}
        if pointed:
            h=tuple(gg[k]+sum(B[k][j]*q[j] for j in range(len(g))) for k in range(len(g)))
            norm={tuple(p[k]-q[k] for k in range(len(g))):c/a[q] for p,c in a.items()}
            z['normalized_label']=h;z['normalized_integral']=all(c.q==1 for c in norm.values())
            z['normalized_mass']=str(sum(norm.values()))
            ds,_,_=acyclic_dimension(B,h);z['d']=ds
            if check_minimal:
                P=prune(B,h,cap=1500)
                z['minimal_carrier']=set(norm).issubset(set(map(tuple,P['lattice_points'])))
        result.append(z)
    return {'B':B,'g':g,'direction':i,'space':space,'image_mass':sum(F.values()),
            'ray_count':len(rays),'all_pointed':all(r['pointed'] for r in result),
            'all_minimal':all(r.get('minimal_carrier',False) for r in result) if check_minimal else None,
            'rays':result,'steps':steps}

def main():
    cases=[]
    x=json.loads((ROOT/'agent_boolean_graph/minimal_shadow_failure.json').read_text())[1]
    cases.append((x['B'],x['g'],{'lattice_points':x['points']},{tuple(a['p']):a['a'] for a in x['min']['F']}))
    x=json.loads((Path(__file__).parent/'packet_bounds_global_ranktwo_first_failure.json').read_text())
    B=x['result']['B'];g=x['result']['g'];F=llz_F(B[0][1],-B[1][0],g)[0]
    cases.append((B,g,x['carrier'],F))
    out=[]
    for B,g,C,F in cases:
        for i in range(len(g)):
            r=classify_multiplication(B,g,C,F,i,check_minimal=True)
            out.append(r)
            (Path(__file__).parent/'multiplication_circuits_results.json').write_text(json.dumps(out,indent=2))
            print({k:v for k,v in r.items() if k not in ['rays','steps']},flush=True)
            print('rays',[(z['pointed'],z.get('minimal_carrier'),z['coordinate_minimum'],z.get('normalized_label'),z.get('normalized_mass')) for z in r['rays']],flush=True)

if __name__=='__main__':main()
