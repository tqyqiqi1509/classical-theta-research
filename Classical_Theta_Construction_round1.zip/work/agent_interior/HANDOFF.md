# Interior coefficients branch: handoff at 07:30 UTC, 2026-11-13

Agent: `/root/interior_coefficients_sharpness`. Parent requested a context
refresh. All work is under `work/agent_interior/`. No Library calls were made;
the parent persists the research workspace. The run continues until 10:12 UTC.

## Read these first

1. `POSITIVE_SLICE_THEOREM.md`: complete general slice comparison, explicit
   acyclic freezing bound, every-seed extension with exact finite-basis scope,
   and the strict box induction lemma.
2. Root's `../ACYCLIC_MARKED_THETA_CALCULUS.md`: general selected/unselected
   marking theorem. Its signs, leaf construction, and strict bound were
   independently checked here.
3. `FINITE_SELECTOR_BASIS.md`: any integral normalized finite-U selector on
   the exact theta Newton carrier already gives an initial-seed basis. It does
   not establish theta equality or seed covariance.
4. `LEX_AND_MARKING_UPDATE.md`: current successful tests and exact failures.
5. `MIDDLE_LEAF_TRANSFER_AND_REDUNDANCY.md`: explicit cross-matrix transfer
   and its positive standard-product decomposition; no new selector results.
6. `TRANSPORTED_PAIR_REPAIR.md`: the exact hard-fork overlap repair. The fresh
   overlap agent has since located the same row one mutation earlier.

## Current next route belongs to the fresh agents

`/root/finite_overlap_completion` and the parent's new theory agent own
source-star surgery. Do not duplicate their implementation. I independently
verified all matrix signs and the essential extension-identification proof:

- For a source `i`, write `b_j=B_ij>=0`, `c_j=-B_ji>=0`, and
  `L(p)=sum_j b_j p_j`. Add `w` with
  `B_iw=-1`, `B_wi=1`, `B_wj=-b_j`, `B_jw=c_j`, and `D_w=D_i`.
- The original extension can be cyclic. Mutation at `w` removes every old
  edge incident to `i`; the resulting full extended quiver is acyclic.
- Choose `lambda=max(0,max_(p in P_g)(L(p)-p_i))`. The function
  `w^lambda theta_g(eta_i w, eta_j w^(-b_j))` is polynomial in the mutable
  variable `w`, and Laurent in the original extended initial star.
- The needed bridge is **principal full-rank BFZ coprime upper-bound mutation
  invariance**, so this initial-star element lies in `U`. Mutation to an
  acyclic seed supplies the full finite theta basis. CMMM VIT confines every
  theta summand to the zero `F_w` face; Qin freezing and old theta linear
  independence then force a single extended theta. Neither mere positivity
  nor mere membership in `U` would establish this identification.
- With `v=z_w'`, direct substitution gives
  `F'=sum_p a_p z^p v^L (1+v)^(lambda+p_i-L)`.
  Its `v^t` slice weights `a_p` by
  `binom(lambda+p_i-L,t-L)` and has old label
  `h_i=g_i+t`, `h_j=g_j+c_j(lambda-t)`.
- The frozen old matrix is `isolated i × B_without_i`, so these slice
  constraints use a genuinely lower-rank theta table. They are not generated
  by the same-B selected/unselected marking calculus.

This route is new and promising; no completeness claim was made here.

## General theorems proved in this branch

### 1. Elementary finite box lemma

For topologically ordered acyclic `B`, put `A=[-B]_+` and
`d_i(h)=max(0,-h_i+sum_(j<i) A_ij d_j(h))`.
If a finite polynomial `G` has nonnegative exponent support in `[0,e]`,
`G(0)!=0`, and `x^h G` satisfies initial-star Laurent divisibility, then
`e>=d(h)` coordinatewise. Positivity of coefficients is not needed.

Proof: successively take the top nonzero coefficient in each coordinate
fiber while later coordinates remain zero. The previously chosen degrees
are at least their `d_j`, so the next required binomial divisor has degree
at least `d_i`. In the exact standard box, origin coefficient one also forces
all prefix vertices `(d_1,...,d_i,0,...,0)` to have coefficient one.

For a pointed shifted component rooted at `q` and supported in `[0,d(g)]`,
this gives `q+d(h)<=d(g)`. Thus `q!=0` strictly lowers `|d|`.
For multiplication by `x_i`, `h=g+e_i+Bq`; when `d_i(g)>0`, even `q=0`
strictly lowers `|d|`. These are actual terminating induction orders.

### 2. Positive lower-rank slices

For `I` mutable and `J` its complement,

`[z_J^s] F_g = sum_(r>=0) c_(s,r) z_I^r`
`              F^[B_II]_(g_I+B_IJ s+B_II r)`, with `c_(s,r)>=0` integral.

The acyclic proof supplies a concrete uniform shift using only finite carrier
`S`, `B`, and `g`: first compute the induced acyclic boxes
`D^I(q)` for `g_I+(Bq)_I`, then choose

`a_j=max(0,max_(q in S)[-g_j-(Bq)_j+sum_(i in I,i<j) A_ji D_i^I(q)])`,
`a_i=0` for `i in I`.

Every potential theta label `g+a+Bq` then has zero standard dimension in
`J`. Strong positive multiplication by `x^a`, finite theta expansion, support
containment, and Qin freezing give the formula.

For an arbitrary seed in the mutation class of this acyclic algebra, the
same conclusion follows by finitely iterating Qin Proposition 6.19. At each
direction in `J`, take the maximum stabilization threshold over the finite
set of potential labels. Previously absent variables stay absent because
`theta_(h+t e_j)` is a coefficient-one summand of `x_j^t theta_h`, hence its
F-support only shrinks. No circular use of slice positivity occurs.

**Scope:** the every-seed proof assumes the ambient algebra has the full
finite theta basis, so every potential label in the finite set is finite.
It is not asserted for an arbitrary algebra merely because one particular
theta function is finite.

Audited primary input: Qin, arXiv:2407.03186v1, Theorem 5.2 (freezing),
Theorem 6.18 (basis context), Proposition 6.19 (eventual disappearance).
The acyclic finite theta/VIT inputs are audited in root
`THETA_NEWTON_PRUNING.md`; no Li--Pan theorem is used.

For `|I|=2`, the lower table is the explicit LLZ integer recurrence, yielding
finite integer compatibility equations. If `B_II=0`, this is simultaneous
positive binomial division, which is strictly stronger than separate positive
quotients.

### 3. Integral selectors are bases

Any integral `S_g=x^g F_g` in the finite-U space, with `F_g(0)=1` and support
inside the exact theta carrier `P_g`, has finite expansion

`S_g=theta_g+sum_(q!=0) c_q y^q theta_(g+Bq)`.

VIT and the box lemma make every correction strictly smaller in `|d|`.
Thus any such family is a frozen-ring basis by finite unitriangular induction.
A finite Boolean/rank-two packet graph of the explicit standard product
provides bounded integral selectors by component enumeration and a fixed
minimum/lex rule. This is an honest initial-seed combinatorial basis, but
universal positivity, covariance, positive multiplication, and theta equality
remain separate gaps.

### 4. Marked-subset calculus

The root theorem, independently checked here, gives

`M_(r,s)F_g = sum_p a_p prod_i binom(p_i,r_i)binom(d_i-p_i,s_i) z^(p-r)`,
`h=g+r+s+B r`,

with a nonnegative theta expansion at label `h`, all summands satisfying
`q+d(h+Bq)<=d-r-s`. The extension uses independent source and sink leaves
with the same symmetrizer entry as their old neighbor. All leaf dimensions
are zero. After their commuting mutations, the full extension is still
acyclic, so the explicit acyclic slice theorem suffices.

The first operators are `D_i=x_i partial_yi` and
`E_i^d=x_i(d_i-y_i partial_yi)`.
Higher mixed markings add no constraints once all first D, E and Pieri maps
are positive on the complete lower table: they are positive compositions;
any ambient capacity above the actual lower box only adds positive Pieri
terms. Division by factorials preserves nonnegativity, and integral basis
expansion supplies integrality.

## What definitely failed

- Initial-star cone mutation closure: previously certified rank-two example
  `B3,g=(-7,14)`, mass491, negative coefficient after word `(1,2)`.
- General initial-star coordinatewise leastness / unique origin ray:
  hard fork `B=[[0,0,3],[0,0,2],[-3,-2,0]]`, `g=(-8,-7,29)`, `d=(8,7,9)`.
  Exact minimal carrier has 252 points, U dimension57. Star rational minimum
  mass59030 is fractional and has a coordinate that another feasible point
  lowers to zero. It fails simultaneous commuting quotient positivity.
- Edgewise leastness: complete rank-three edge3, d=(5,5,5), star minimum134;
  a two-chart positive candidate lowers a coefficient10 to zero.
- Initial all-pair coordinatewise/pointwise leastness: at the mass59085 hard
  candidate, the ray `D47` below is feasible for positive epsilon. It is
  negative at some positive evaluations, so even pointwise leastness fails.
- Pieri plus D plus E does not eliminate `F+D47`.
- Simple local forward maximum, even with all exact preceding U equalities,
  direct rank-two rows, D/E and Pieri, misses 107 positive free coefficients
  in 88 of 504 cases. This is a failure of those *direct rows*, not a proof
  that a full future-elimination lex algorithm fails.
- Initial-star lex minimization fails for every monomial order: see the
  integral mass59813 witness below.
- Naive downward graph confluence fails even for genuine rank-two greedy
  polynomials; the graph agent has the explicit unavoidable terminals.
- Full-box middle-leaf subdivision gives positive smaller standard products,
  so it is redundant in a genuine lower-theta induction. Initial `x_i`-Pieri
  alone is not claimed to imply lower standard-product positivity for an
  arbitrary candidate family.

## Exact hard-fork overlap and lex facts

Let `u,v,w` denote its three F-variables. The complete initial all-pair
tangent cone at the mass59085 candidate `F` is simplicial of dimension56.
Fifty-five primitive rays have nonnegative ordinary coefficients. The sole
bad ray is

`D47=u v w(1+v)[(1+u)^5(1+v)^4-u^5v^4w^2]`.

The integral candidate `H=F+D47` has mass60107 and passes source-star,
source all-pair, recursive Pieri, selected D and complementary E conditions.
Its negative terms as a tangent direction are at `(6,5,3),(6,6,3)`.

After commuting mutations `(0,1)`, two target rank-two coefficient rows are
negative. Both pull back to exactly the tangent functional `t2-t47`.
Packet agent independently found the same functional already after the
single mutation `mu0`, in pair `(1,2)`, outside degree2, root `(3,2)`,
lower label `(-3,5)`.

`D2=u^4v^3w^2(1+u)^2(1+v)^3+u^6v^5w^3(1+v)`.

Both `D2` and `D2+D47` are coefficient-nonnegative. In fact all 55 good
rays and `D2+D47` have nonnegative **all original star and rank-two packet
coordinates**, verified here. The extra row `t2>=t47` therefore repairs
the entire original augmented packet leastness by the explicit decomposition

`H-F=(t2-t47)D2+t47(D2+D47)+sum_(j!=2,47)t_j D_j`.

The independent-chart completion yielded 1013 new distinct rows and exactly
56 repaired rays. This is a fully finite certificate for this carrier, not a
general finite-atlas theorem.

Even before this repair, the original all-pair cone has `F` as unique lex
minimum for **every monomial term order**: all good tangent rays are positive,
and `D47` has the unique componentwise lowest term `uvw` with coefficient1.
Every nonnegative ray combination has positive first nonzero coefficient.

The weaker initial-star cone instead contains

`F+104 u^6v^5w^3[v^2(1+w)^3-1]`, mass59813,

lowering `a_(6,5,3)` from104 to0. Its unique componentwise lowest difference
term is negative, so it is smaller for every monomial order. Six total-degree
tie orders were exactly checked. Another witness lowers `a_(7,4,3)`132 to0.

## Computational implementation map

### Finite circuits and early bounds

- `packet_bounds.py`: bounded integer interval closure with explicit standard
  product bounds, optional exact forced affine coordinates and global RREF
  rows. Finite and order independent, not complete.
- `positive_circuits.py`: exact integer double-description recurrence for all
  positive packet circuits. Main API `enumerate_packet_circuits(B,g,C)`;
  helpers `integer_parameter_rows(B,g,M)`, `double_description(rows,m)`.
  It never assumes a unique origin ray.
- `POSITIVE_CIRCUIT_RECURRENCE.md`: proof of the finite circuit recurrence.
- `PACKET_COMPONENTS.md`: explicit Boolean packet graphs, component and
  bounded embedding lemmas.
- `valued_circuits.py/results.json`: 15 skew-symmetrizable rank3/4 cases
  completed; one resource cutoff was not treated as a counterexample.
- Complete rank-two circuit files show pointedness need not give minimal
  shifted carrier: B3,g(-7,14), root(1,1), normalized label(-4,11), rays mass18
  and33, only the former has minimal carrier.

### Rank-two sections

- `ranktwo_section_positivity.py` exposes `sections(B,g,F)` and
  `greedy_expand(b,c,h,F)`. It performs exact LLZ triangular subtraction.
- Packet agent's `ranktwo_packets.py` transports those rows symbolically on
  the entire U-space. Use that for cone construction, rather than repeating
  scalar sample tests.

### Recursive Pieri candidate family

- `pieri_recursive.py`: `PieriCache(B,path)`, `.get(g)`, `.records[g]`.
  The finite recursion requires all `x_i F_g` expansions to be nonnegative
  combinations of *already fixed smaller-box objects*. Rank<=2 active
  support is exact LLZ. Candidate carrier hulls are certified by finite-U
  forced-vertex pruning, not representation data.
- `pieri_fork_cache/`: 9386 total records at handoff, including 504 higher-rank
  recursive candidates and 8882 rank<=2 base records (one additional base was
  needed by the final transfer check). All504 higher candidates are
  integral, star Laurent/positive, and supported on their exact pruned
  carrier. 484 direct mass-dual certificates were reconstructed; other
  statuses remain explicitly conditional. A false `unique_optimum` flag is
  only failure of one sufficient dual-rank test, not a demonstrated
  nonunique optimum.
- **None of these 504 candidates is silently asserted to be theta.** Each
  record states the conditional ancestor/comparison status. Their agreement
  with stronger independent computations is evidence, not identification.
- `pieri_tradeoff.py` exposes `expand(C,g,F)`. It rejects the fractional star
  and old commuting/all-pair tradeoffs, but `pieri_tangent47.json` shows D47
  survives to epsilon15.

### Marking and sharpness

- `derivative_positive_test.py/results`: 11250 exact rank-two selected
  derivatives, b,c=1..5, denominator coordinates1..15, both directions;
  all greedy expansions nonnegative.
- `derivative_recursive_test.py` exposes
  `basis_expand(C,label,F,bound,require_smaller)` and `check(C,g,F)`.
  `derivative_fork_results.json`: all1512 first derivatives of504 candidates
  nonnegative. Witness data separately preserve the negative old examples.
- `complement_marking_test.py` exposes
  `marked(C,g,F,i,a,b)` and `check_marked(C,g,F,orders=[(a,b)])`.
  All1512 first complementary expansions pass; H=F+D47 also passes.
- `derivative_sharpness.py`: first incomplete direct-row audit, 193 cases/
  294 misses before adding exact U prefix elimination and other rows.
- `triangular_sharpness.py`: final direct audit with exact U prefix
  elimination, pair rows, D, E, Pieri, quotients. 88 cases/107 misses.
  First is `g=(-4,-3,13)`, `d=(4,3,5)`, `a_(2,2,1)=3`.
- `lex_minimum_certificate.py`: exact conic dual identity after eliminating
  previously fixed coefficients; numerical optimizer only proposes a
  rational certificate or witness, both checked exactly. Six tie orders
  certify the small first-miss case, while all six fail for the hard star
  cone by explicit integral witnesses. Data `lex_minimum_results.json`.

### Transport repair and middle leaves

- `commuting_target_pair_rows.py/json`: exact pullback of both two-mutation
  bad rank-two rows to `t2-t47` on the full 56-dimensional tangent space.
- `refined_tangent_packet_positivity.json`: all original augmented packet
  coordinates nonnegative on the repaired ray list.
- `pieri_witness_after_commuting_mutations.json`: exact transported F/H and
  two negative rows.
- `subdivision_transfer.py/results.json`: explicit middle-leaf polynomials
  and positive smaller-basis expansions for the three fork subdivisions.

## Primary literature refresh and exclusions

- Qin arXiv:2407.03186v1 was read at the official arXiv PDF; the exact scope
  and uniform iteration are recorded in `POSITIVE_SLICE_THEOREM.md`.
- Mandel scattering-atlas atomicity must never be relabelled cluster-atlas
  atomicity. No proof here relies on that invalid replacement.
- Bond–Levine least-action requires monotone production; raw packet quotient
  recurrence has mixed signs, so that theorem cannot simply be invoked.
- Müller–Regensburger arXiv:1512.00267v2 supports conformal/circuit reduction,
  not origin-ray uniqueness.
- Li–Pan arXiv:2201.01440v4 was inspected for ideas only. Its several positive
  cones and completions have different scopes; no result is used, and the
  present counterexamples were not declared refutations of that paper.
- At about07:24, broad primary searches revisited perfect bases, frozen
  derivatives, and greedy minimality. Baumann–Kamnitzer–Knutson's Acta2021
  perfectness definition permits signed/complex lower derivative coefficients;
  it cannot establish the new positivity. Author material also emphasizes
  nonuniqueness of biperfect bases. No representation construction was used.
- Recent2026 Hexagon claims surfaced but were not adopted as established
  results. Root's independent leaf/freezing argument supplies marking
  positivity, rather than any unaudited claimed biperfectness theorem.

## Immediate cautions for the next context

Do not restart old leastness or interval scans as if their counterexamples
were unknown. Do not weaken source-star extension identification to positivity
alone. Do not substitute a finite initial pair cone for the infinite actual
cluster atlas without a proof. Keep the exact frozen grading and normalized
label reset throughout transport. Preserve candidate conditionality until a
general selecting mechanism and its theta comparison are proved.
