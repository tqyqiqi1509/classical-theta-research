#!/usr/bin/env python3
"""Exact theta/greedy expansion of acyclic frozen-root derivatives."""
from ranktwo_section_positivity import *
from itertools import product
from pathlib import Path

def derivative(B,g,F,i):
    h=tuple(g[k]+(k==i)+B[k][i] for k in range(len(g)))
    D={}
    for p,a in F.items():
        if p[i]:
            q=tuple(p[k]-(k==i) for k in range(len(g)))
            D[q]=p[i]*a
    return h,D

def main():
    tic=time.time();count=0;bad=[];minbad=None
    for b,c in product(range(1,6),repeat=2):
        B=[[0,b],[-c,0]]
        for a1,a2 in sorted(product(range(1,16),repeat=2),key=lambda p:(sum(p),p)):
            g=(-a1,c*a1-a2);F=llz_F(b,c,g)[0]
            for i in range(2):
                h,D=derivative(B,g,F,i)
                E=greedy_expand(b,c,h,D)
                neg=[a for a in E if Fraction(a['coefficient'])<0]
                count+=1
                if neg:
                    r={'B':B,'g':g,'denominator':(a1,a2),'direction':i,'derivative_label':h,
                       'negatives':neg,'expansion':E,'F':[{'p':p,'a':a} for p,a in F.items()]}
                    bad.append(r)
                    print('FAIL',r['B'],g,i,neg,flush=True)
                    (Path(__file__).parent/'derivative_ranktwo_results.json').write_text(json.dumps({'cases':count,'bad':bad,'seconds':time.time()-tic},indent=2))
                    if len(bad)>=8:return
        print('parameters',b,c,'checked',count,'bad',len(bad),flush=True)
    (Path(__file__).parent/'derivative_ranktwo_results.json').write_text(json.dumps({'cases':count,'bad':bad,'seconds':time.time()-tic},indent=2))
    print('done',count,len(bad),time.time()-tic,flush=True)

if __name__=='__main__':main()
