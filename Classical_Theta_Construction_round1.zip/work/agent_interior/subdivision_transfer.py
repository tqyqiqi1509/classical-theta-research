#!/usr/bin/env python3
"""Explicit middle-leaf transfer from a smaller acyclic exchange matrix.

For disjoint source/sink incidence vectors a,b, mutating a zero-width new
vertex changes B to B+a*b^T-b*a^T. Its M=a.d coefficient slice has character
binom(M-a.p+b.p,b.p) times each source coefficient.
"""
from derivative_recursive_test import *

def transfer(F,a,b,d):
    M=sum(x*y for x,y in zip(a,d));out={}
    for p,value in F.items():
        A=sum(x*y for x,y in zip(a,p));Q=sum(x*y for x,y in zip(b,p))
        if M<A:raise ArithmeticError('source support outside chosen capacity')
        out[p]=value*math.comb(M-A+Q,Q)
    return out

def isolated_F(d):
    return {p:math.prod(math.comb(di,pi) for di,pi in zip(d,p))
            for p in product(*(range(di+1) for di in d))}

def compare(C,g,target,transferred,tag):
    d,_,_=acyclic_dimension(C.B,g)
    H={p:transferred.get(p,0)-target.get(p,0) for p in set(transferred)|set(target)}
    H={p:a for p,a in H.items() if a}
    E=basis_expand(C,g,H,d,sum(d))
    bad=[x for x in E if Fraction(x['coefficient'])<0]
    return {'tag':tag,'mass':sum(transferred.values()),'expansion':E,'negative':bad}

def main():
    B=[[0,0,3],[0,0,2],[-3,-2,0]];g=(-8,-7,29);d=(8,7,9)
    C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache');F=C.get(g)
    witness=json.loads((Path(__file__).parent/'pieri_bad_pointwise_witness.json').read_text())
    H={tuple(t['p']):t['a'] for t in witness['H']};out=[]
    # One common intermediate vertex, versus independent vertices for edges.
    G=transfer(isolated_F(d),(3,2,0),(0,0,1),d)
    for name,T in [('F',F),('F_plus_D47',H)]:out.append(compare(C,g,T,G,'joint_'+name))
    G=transfer(transfer(isolated_F(d),(3,0,0),(0,0,1),d),(0,2,0),(0,0,1),d)
    for name,T in [('F',F),('F_plus_D47',H)]:out.append(compare(C,g,T,G,'separate_'+name))
    # Unit subdivisions of each individual arrow.
    G=isolated_F(d)
    for a in [(1,0,0)]*3+[(0,1,0)]*2:G=transfer(G,a,(0,0,1),d)
    for name,T in [('F',F),('F_plus_D47',H)]:out.append(compare(C,g,T,G,'unit_'+name))
    (Path(__file__).parent/'subdivision_transfer_results.json').write_text(json.dumps(out,indent=2))
    for r in out:print(r['tag'],'mass',r['mass'],'negative',r['negative'][:8],flush=True)

if __name__=='__main__':main()
