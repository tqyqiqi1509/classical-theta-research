#!/usr/bin/env python3
"""Exact rank-two greedy decomposition of every coordinate two-section."""
from packet_bounds import *
from itertools import combinations
from collections import defaultdict
from fractions import Fraction

def greedy_expand(b,c,h,F,cap=20000):
    remainder=dict(F);terms=[]
    for step in range(cap):
        if not remainder:return terms
        q=min(remainder,key=lambda p:(sum(p),p));a=remainder[q]
        label=(h[0]+b*q[1],h[1]-c*q[0])
        G,_=llz_F(b,c,label)
        if G.get((0,0))!=1:raise ArithmeticError('bad greedy origin')
        terms.append({'q':q,'h':label,'coefficient':str(a)})
        for p,value in G.items():
            r=(p[0]+q[0],p[1]+q[1]);remainder[r]=remainder.get(r,0)-a*value
            if not remainder[r]:del remainder[r]
    raise OverflowError('greedy decomposition cap')

def sections(B,g,F):
    n=len(g);out=[]
    for I in combinations(range(n),2):
        outside=tuple(j for j in range(n) if j not in I)
        fibres=defaultdict(dict)
        for p,a in F.items():
            off=tuple(p[j] for j in outside);fibres[off][tuple(p[j] for j in I)]=a
        for off,poly in fibres.items():
            h=tuple(g[i]+sum(B[i][j]*v for j,v in zip(outside,off)) for i in I)
            terms=greedy_expand(B[I[0]][I[1]],-B[I[1]][I[0]],h,poly)
            negatives=[t for t in terms if Fraction(t['coefficient'])<0]
            out.append({'I':I,'off':off,'h':h,'terms':terms,'negatives':negatives})
    return out

def main():
    src=ROOT/'agent_packet_propagation'
    examples=[]
    for filename in ['least_point_sweep_results.json','scaled_edge_results.json']:
        for r in json.loads((src/filename).read_text())['results']:
            examples.append((filename,r['B'],r['g'],r['minimum']['F']))
    r=json.loads((src/'large_origin_exact_failure_2.json').read_text())
    examples.append(('large_counter',r['B'],r['g'],r['F']))
    output=[]
    for tag,B,g,table in examples:
        F={tuple(x['p']):Fraction(x['a']) for x in table};S=sections(B,g,F)
        bad=[s for s in S if s['negatives']]
        r={'source':tag,'B':B,'g':g,'section_count':len(S),'negative_sections':len(bad),'bad':bad}
        output.append(r)
        print(tag,g,len(S),'negative',len(bad),flush=True)
    (Path(__file__).parent/'ranktwo_section_positivity_results.json').write_text(json.dumps(output,indent=2))

if __name__=='__main__':main()
