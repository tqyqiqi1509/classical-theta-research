# Transported pair inequalities repair the fork coefficient tradeoff

Exact certificate, 2026-11-13.

## 1. Source cone and candidate

Take

    B=[[0,0,3],[0,0,2],[-3,-2,0]],
    g=(-8,-7,29).

The exact Newton carrier has 252 lattice points. Let C be the finite
cone of origin-normalized Laurent coefficient tables on that carrier
satisfying all initial-star, commuting-cube, and rank-two greedy-section
positivity conditions.

The packet agent constructed an integral candidate F of mass 59085 and
enumerated the entire tangent cone at F. It is a pointed simplicial cone
of dimension 56, with primitive rays D_0,...,D_55. Every assertion uses
exact rational arithmetic, and each ray has active rank 55.

File: ../agent_packet_propagation/pair_tangent_circuits_results.json.
The ray numbering below is zero-based.

For every H in C, H-F belongs to that tangent cone. Hence

    H-F=sum_(j=0)^55 t_j D_j,  t_j>=0.

This use of the tangent cone is global: inequalities active at F remain
nonnegative on every H-F. It does not assume H is close to F.

## 2. The unique coefficient-negative tangent ray

All rays other than D_47 have coefficientwise nonnegative initial
polynomials. With u=z_1, v=z_2, w=z_3,

    D_47=u v w (1+v)
             ((1+u)^5(1+v)^4-u^5 v^4 w^2).

Its only negative coefficients are -1 at (6,5,3) and (6,6,3).
In particular D_47(1,1,32)=-32768.

The integral function H=F+D_47 has mass 60107 and is feasible for every
source rank-two packet condition. It also satisfies every tested
recursive positive-Pieri constraint against the completely computed
smaller candidates in the d-box (8,7,9). Thus neither those source
conditions nor that Pieri strengthening makes F pointwise least on the
positive torus.

File: pieri_bad_pointwise_witness.json.

## 3. A legitimate transported inequality

Mutate the two commuting source directions, in word (0,1). Both F and H
remain Laurent positive. Permute the target directions by (2,0,1), so

    B_target=[[0,3,2],[-3,0,0],[-2,0,0]],
    g_target=(-9,8,7).

The transported masses are

    mass(F_target)=1426054373,
    mass(H_target)=1426054372.

The latter is smaller by exactly one. This is consistent with the source
positive point above: all target mutable and frozen variables equal to
one correspond to old x_1=x_2=2, x_3=1, hence z=(1,1,32), and the old
prefactor x^g contributes 2^(-15).

However, H_target fails a rank-two greedy-section condition. One such
condition is:

- Pair of target directions (0,1).
- Outside coordinate equal to 1.
- Section label (-7,8).
- Greedy packet root (2,2), whose normalized lower-rank label is (-1,2).

The coefficient of that greedy packet is 0 on F_target and -1 on
H_target. There is a second condition, in pair (0,2), outside coordinate
2, root (2,1), lower label (-1,3), with the same values.

These inequalities are sound theta conditions by the positive-slice
theorem at the target seed. They are not arbitrary optimization cuts.

## 4. Exact evaluation on every tangent ray

Pull either target inequality back to the source tangent space. The
complete exact calculation gives

    ell(D_2)=1,
    ell(D_47)=-1,
    ell(D_j)=0 for all j notin {2,47}.

Thus both target inequalities become the same simple inequality

    t_2>=t_47.

File: commuting_target_pair_rows.json. Its code evaluates the normalized
mutation maps and the LLZ subtraction recurrence exactly on every ray.

The positive ray D_2 has polynomial

    u^4 v^3 w^2 (1+u)^2(1+v)^3
       +u^6 v^5 w^3(1+v).

Consequently D_2+D_47 is coefficientwise nonnegative: the second summand
of D_2 cancels the two negative monomials of D_47, leaving

    u v w(1+u)^5(1+v)^5
       +u^4 v^3 w^2(1+u)^2(1+v)^3.

## 5. A global least-coefficient certificate after one refinement

Let C' be C with either one of the transported inequalities imposed.
The candidate F belongs to C'. For every H in C',

    H-F=(t_2-t_47)D_2+t_47(D_2+D_47)
             +sum_(j notin {2,47}) t_jD_j.

Every scalar and every displayed polynomial is nonnegative. Therefore

    [z^p]H >= [z^p]F for every p.

This proves F is the initial-coefficient least point of the entire
refined finite cone, not just its minimum at z=(1,1,1), and not just a
local minimum. Every strictly positive coefficient objective has the
same unique minimizing coefficient table F.

It does not assert that every quotient coordinate is least, and it does
not identify F with theta without an additional comparison argument.
Theta is feasible in C', so this certificate does imply the rigorous
coefficient lower bound F<=theta_g in the initial seed.

## 6. General finite mechanism isolated by this example

For any finite atlas of coefficient or packet positivity conditions:

1. Compute a candidate F and its exact tangent cone.
2. Enumerate tangent rays by the integer positive-circuit recurrence.
3. If every ray projects to a nonnegative initial coefficient table,
   F is globally coefficientwise least in that finite cone.
4. A new valid active inequality intersects the tangent cone. Integer
   double-description computes the new rays.
5. If this intersection replaces each coefficient-negative ray by
   coefficient-nonnegative combinations, leastness is proved.

Here a single transported rank-two condition replaces D_47 by D_2+D_47.
This is an explicit circuit exchange, closely aligned with packet graph
rematching. The remaining general problem is to prove a finite,
input-determined family of such legitimate transported conditions always
suffices. Searching arbitrarily far through the mutation atlas has no
proved finite stopping bound and is not being presented as a complete
construction.
