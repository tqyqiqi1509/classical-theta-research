#!/usr/bin/env python3
"""Test coefficientwise integer sharpness of finite Pieri/derivative rows."""
from derivative_recursive_test import *

def star_quotients(B,g,F):
    n=len(g);out=[]
    for i in range(n):
        fibers=defaultdict(dict)
        for p,a in F.items():fibers[p[:i]+p[i+1:]][p[i]]=a
        Q={}
        for off,poly in fibers.items():
            p=off[:i]+(0,)+off[i:];D=max(0,-g[i]-sum(B[i][j]*p[j] for j in range(n)));qs=[]
            for s in range(max(poly)+1):
                q=poly.get(s,0)-sum(math.comb(D,j)*qs[s-j] for j in range(1,min(D,s)+1));qs.append(q)
                Q[off[:i]+(s,)+off[i:]]=q
        out.append(Q)
    return out

def sharpness(C,g,F):
    PE=expand(C,g,F);DE=check(C,g,F);d,_,_=acyclic_dimension(C.B,g)
    P={e['direction']:{tuple(t['q']):Fraction(t['coefficient']) for t in e['terms']} for e in PE}
    D={e['direction']:{tuple(t['q']):Fraction(t['coefficient']) for t in e['terms']} for e in DE}
    Q=star_quotients(C.B,g,F);miss=[];stats={'pieri_only_misses':0,'pieri_derivative_misses':0}
    for p,a in F.items():
        if not any(p):continue
        ps=[P[i].get(p,0) for i in P]
        ds=[D[i].get(tuple(p[k]-(i==k) for k in range(C.n)),0)//p[i] for i in D if p[i]]
        qs=[q.get(p,0) for q in Q]
        if min(ps,default=0)>=1:stats['pieri_only_misses']+=1
        if min(ps+ds,default=0)>=1:stats['pieri_derivative_misses']+=1
        if min(ps+ds+qs,default=0)>=1:
            miss.append({'p':p,'a':a,'pieri_slacks':[str(z) for z in ps],
                         'derivative_slack_quotients':[str(z) for z in ds],
                         'quotients':[str(z) for z in qs]})
    return {'g':g,'d':d,'misses':miss,'stats':stats}

def main():
    B=[[0,0,3],[0,0,2],[-3,-2,0]];C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache')
    full=[g for g,r in C.records.items() if r['status']=='recursive_Pieri_candidate'];out=[];tic=time.time()
    for g in sorted(full,key=lambda g:(sum(C.records[g]['d']),g)):
        r=sharpness(C,g,C.get(g));out.append(r)
        if r['misses']:print('MISS',g,r['misses'][:2],flush=True)
    result={'cases':len(full),'misscases':sum(bool(z['misses']) for z in out),
            'misspoints':sum(len(z['misses']) for z in out),'seconds':time.time()-tic,'records':out}
    (Path(__file__).parent/'derivative_sharpness_results.json').write_text(json.dumps(result,indent=2))
    print('SUMMARY',{k:v for k,v in result.items() if k!='records'},flush=True)

if __name__=='__main__':main()
