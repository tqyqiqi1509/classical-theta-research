#!/usr/bin/env python3
"""Monotone interval closure of finite integer Boolean packet equations.

This tests a potential least-action mechanism, without solving an LP. It is
not assumed complete. Initial upper bounds come from the explicit acyclic
standard product. Lower bounds are sound for every bounded integer solution.
"""
from pathlib import Path
import sys,json,time,math
from collections import deque
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_mass'),str(ROOT/'agent_acceptance'),str(ROOT/'agent_division')]
from packet_minimum import build
from theta_newton_pruning import prune
from schofield_carrier import acyclic_dimension
from rank2_saturation_check import llz_F
from linear_carrier import divisibility_space
from theta_newton_pruning import affine_normalize

def ceildiv(a,b):return -((-a)//b)

def equations(M):
    rows=[{} for _ in range(len(M['rows'])+1)]
    for col,key in enumerate(M['columns']):
        if key[0]=='a':
            p=key[1]
            for k in range(len(p)):rows[M['rows'][k,p]][col]=1
            if not any(p):rows[-1][col]=1
        else:
            _,k,off,s,d=key
            for j in range(d+1):
                p=off[:k]+(s+j,)+off[k:]
                rows[M['rows'][k,p]][col]=-math.comb(d,j)
    return rows,[0]*(len(rows)-1)+[1]

def standard_bounds(B,g,M):
    ds,_,_=acyclic_dimension(B,g);upper=[]
    for key in M['columns']:
        if key[0]=='a':
            upper.append(math.prod(math.comb(ds[i],p) for i,p in enumerate(key[1])))
        else:
            _,k,off,s,d=key;p=off[:k]+(0,)+off[k:]
            upper.append(math.comb(ds[k]-d,s)*math.prod(math.comb(ds[i],p[i]) for i in range(len(ds)) if i!=k))
    return [0]*len(upper),upper

def affine_packet_rows(B,g,M):
    F,info=divisibility_space(B,g,M['points'])
    A=affine_normalize(F,(0,)*len(g));width=len(A[(0,)*len(g)])
    zero=(0,)*width;vectors=[];fibres={}
    for key in M['columns']:
        if key[0]=='a':vectors.append(A.get(key[1],zero))
        else:
            _,k,off,s,d=key;cachekey=(k,off,d)
            if cachekey not in fibres:fibres[cachekey]=[]
            qq=fibres[cachekey]
            while len(qq)<=s:
                t=len(qq);p=off[:k]+(t,)+off[k:];v=list(A.get(p,zero))
                for j in range(1,min(d,t)+1):
                    c=math.comb(d,j);v=[x-c*y for x,y in zip(v,qq[t-j])]
                qq.append(tuple(v))
            vectors.append(qq[s])
    return vectors,info

def parameter_equations(vectors,coefficient_count):
    """Exact global rows obtained by choosing actual coefficient parameters."""
    import sympy as sp
    m=len(vectors[0])-1;refs=[]
    for j in range(m):
        options=[i for i,v in enumerate(vectors[:coefficient_count])
                 if not v[0] and v[j+1] and all(not v[k+1] for k in range(m) if k!=j)]
        if not options:raise ArithmeticError(('no actual free coordinate',j))
        refs.append(options[0])
    rows=[];rhs=[]
    for i,v in enumerate(vectors):
        row={i:sp.Integer(1)}
        for j,ref in enumerate(refs):
            if v[j+1]:row[ref]=row.get(ref,0)-v[j+1]/vectors[ref][j+1]
        row={k:a for k,a in row.items() if a}
        if not row:
            if v[0]:raise ArithmeticError('nonzero empty equation')
            continue
        den=sp.ilcm(*[sp.denom(a) for a in list(row.values())+[v[0]]])
        rows.append({k:int(den*a) for k,a in row.items()});rhs.append(int(den*v[0]))
    return rows,rhs,refs

def close_intervals(rows,rhs,lower,upper):
    lower=list(lower);upper=list(upper);touch=[[] for _ in lower]
    for j,row in enumerate(rows):
        for i in row:touch[i].append(j)
    todo=deque(range(len(rows)));queued=set(todo);updates=[];checks=0
    while todo:
        j=todo.popleft();queued.remove(j);row=rows[j];b=rhs[j]
        lo=sum(c*(lower[i] if c>0 else upper[i]) for i,c in row.items())
        hi=sum(c*(upper[i] if c>0 else lower[i]) for i,c in row.items())
        checks+=1
        if not lo<=b<=hi:raise ArithmeticError(('infeasible interval',j,lo,b,hi))
        for i,c in row.items():
            ownlo=c*(lower[i] if c>0 else upper[i]);ownhi=c*(upper[i] if c>0 else lower[i])
            remlo=lo-ownlo;remhi=hi-ownhi
            if c>0:
                nl=max(lower[i],ceildiv(b-remhi,c));nu=min(upper[i],(b-remlo)//c)
            else:
                cc=-c;nl=max(lower[i],ceildiv(remlo-b,cc));nu=min(upper[i],(remhi-b)//cc)
            if nl>nu:raise ArithmeticError(('empty interval',j,i,nl,nu))
            if nl!=lower[i] or nu!=upper[i]:
                updates.append([j,i,lower[i],upper[i],nl,nu]);lower[i]=nl;upper[i]=nu
                for k in touch[i]:
                    if k not in queued:todo.append(k);queued.add(k)
    return lower,upper,{'updates':len(updates),'row_checks':checks}

def run_case(B,g,carrier=None,theta=None,seed_forced=False,global_rows=False):
    tic=time.time()
    C=carrier or prune(B,g,cap=5000)
    M=build(B,g,list(map(tuple,C['lattice_points'])));rows,rhs=equations(M)
    L,U=standard_bounds(B,g,M)
    for p in C['vertices']:
        i=M['ids'][tuple(p)];L[i]=U[i]=1
    fixed=0
    if seed_forced or global_rows:
        vectors,space=affine_packet_rows(B,g,M)
        for i,v in enumerate(vectors):
            if not any(v[1:]):
                if v[0].q!=1:raise ArithmeticError(('fixed nonintegral',i,v[0]))
                L[i]=U[i]=int(v[0]);fixed+=1
        if global_rows:
            extra,erhs,refs=parameter_equations(vectors,len(M['points']))
            rows+=extra;rhs+=erhs
    L,U,info=close_intervals(rows,rhs,L,U)
    residual=[{'row':j,'value':sum(c*L[i] for i,c in row.items())-rhs[j]}
              for j,row in enumerate(rows) if sum(c*L[i] for i,c in row.items())!=rhs[j]]
    coeff={p:L[i] for p,i in M['ids'].items() if L[i]}
    result={'B':B,'g':g,'points':len(M['points']),'variables':len(M['columns']),
            'carrier_affine_dimension':C.get('final_affine_dimension'),
            'seeded_fixed_coordinates':fixed,
            'global_affine_rows':len(extra) if global_rows else 0,
            'lower_feasible':not residual,'lower_mass':sum(coeff.values()),
            'unfixed_variables':sum(a!=b for a,b in zip(L,U)),
            'first_residuals':residual[:8],'closure':info,'seconds':time.time()-tic}
    if theta is not None:
        result['theta_mass']=sum(theta.values())
        result['theta_equal_lower']=coeff==theta
        result['theta_deficits']=[{'p':p,'lower':coeff.get(p,0),'theta':a}
                                  for p,a in theta.items() if coeff.get(p,0)!=a][:12]
    return result

def main():
    out=[]
    for b,d in [(2,3),(2,5),(3,4),(3,7)]:
        B=[[0,b],[-b,0]];g=(-d,(b-1)*d)
        a=run_case(B,g,theta=llz_F(b,b,g)[0]);out.append(a);print(a,flush=True)
    for C in json.loads((ROOT/'agent_acceptance/theta_newton_pruning_results.json').read_text()):
        a=run_case(C['B'],C['g'],carrier=C);out.append(a);print(a,flush=True)
    B=[[0,3,3],[-3,0,3],[-3,-3,0]];g=(-3,6,15)
    a=run_case(B,g);out.append(a);print(a,flush=True)
    (Path(__file__).parent/'packet_bounds_results.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
