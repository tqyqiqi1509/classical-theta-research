#!/usr/bin/env python3
"""Exact lower-basis expansion of selected/unselected Boolean slot markings.

The cache contains explicitly selected lower Pieri candidates; the experiment
does not identify those candidates with theta functions.
"""
from derivative_recursive_test import *

def marked(C,g,F,i,a=0,b=1):
    d,_,_=acyclic_dimension(C.B,g)
    h=tuple(g[k]+(a+b)*(k==i)+a*C.B[k][i] for k in range(C.n))
    G={tuple(p[k]-a*(k==i) for k in range(C.n)):
       value*math.comb(p[i],a)*math.comb(d[i]-p[i],b)
       for p,value in F.items() if p[i]>=a and d[i]-p[i]>=b}
    bound=tuple(d[k]-(a+b)*(k==i) for k in range(C.n))
    return h,G,bound

def check_marked(C,g,F,orders=None):
    d,_,_=acyclic_dimension(C.B,g);out=[]
    for i,di in enumerate(d):
        if not di:continue
        for a,b in (orders or [(0,1)]):
            if a+b>di:continue
            h,G,bound=marked(C,g,F,i,a,b)
            E=basis_expand(C,h,G,bound,sum(d))
            out.append({'direction':i,'selected':a,'unselected':b,'label':h,
                        'terms':E,'negative':[t for t in E if Fraction(t['coefficient'])<0]})
    return out

def main():
    B=[[0,0,3],[0,0,2],[-3,-2,0]]
    C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache')
    full=[g for g,r in C.records.items() if r['status']=='recursive_Pieri_candidate']
    out=[];tic=time.time();badcount=0
    for g in sorted(full,key=lambda g:(sum(C.records[g]['d']),g)):
        E=check_marked(C,g,C.get(g));bad=[z for z in E if z['negative']]
        out.append({'g':g,'negative_directions':len(bad),'bad':bad})
        badcount+=len(bad)
        if bad:print('BAD',g,[(z['direction'],z['negative'][:3]) for z in bad],flush=True)
    result={'cases':len(full),'negative_directions':badcount,'seconds':time.time()-tic,'records':out}
    (Path(__file__).parent/'complement_marking_results.json').write_text(json.dumps(result,indent=2))
    print('CENSUS',{k:v for k,v in result.items() if k!='records'},flush=True)
    g=(-8,-7,29)
    x=json.loads((Path(__file__).parent/'pieri_bad_pointwise_witness.json').read_text())
    H={tuple(t['p']):t['a'] for t in x['H']}
    E=check_marked(C,g,H)
    witness={'g':g,'mass':sum(H.values()),'expansions':E}
    (Path(__file__).parent/'complement_marking_witness.json').write_text(json.dumps(witness,indent=2))
    print('WITNESS',[(z['direction'],z['negative']) for z in E if z['negative']],flush=True)

if __name__=='__main__':main()
