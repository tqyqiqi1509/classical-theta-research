from packet_bounds import *
sys.path.insert(0,str(ROOT/'agent_packet_propagation'))
from minimum_covariance import minimality_certificate

def main():
    tic=time.time();cases=[];out=[];seen=set()
    for name in ['large_carrier_results.json','topology_cones_results.json']:
        cases.extend(json.loads((ROOT/'agent_packet_propagation'/name).read_text())['results'])
    stats={'cases':0,'lower_feasible':0,'lower_infeasible':0,'points':0,'variables':0}
    for ix,c in enumerate(cases):
        B=c['B'];g=c['g'];key=(tuple(map(tuple,B)),tuple(g))
        if key in seen or len(g)<3:continue
        seen.add(key)
        C={'d':c['d'],'vertices':c['vertices'],'lattice_points':c['points']}
        P,cert=minimality_certificate(B,g,C)
        result=run_case(B,g,carrier=P,seed_forced=True);result['minimality_certificate']=cert
        out.append(result);stats['cases']+=1
        stats['lower_feasible' if result['lower_feasible'] else 'lower_infeasible']+=1
        stats['points']+=result['points'];stats['variables']+=result['variables']
        (Path(__file__).parent/'packet_bounds_fixed_sweep_results.json').write_text(json.dumps({'stats':stats,'seconds':time.time()-tic,'results':out},indent=2))
        print(ix,'rank',len(g),'lower mass',result['lower_mass'],'feasible',result['lower_feasible'],stats,flush=True)
        if not result['lower_feasible']:
            (Path(__file__).parent/f'packet_bounds_fixed_failure_{ix}.json').write_text(json.dumps({'result':result,'carrier':P},indent=2))

if __name__=='__main__':main()
