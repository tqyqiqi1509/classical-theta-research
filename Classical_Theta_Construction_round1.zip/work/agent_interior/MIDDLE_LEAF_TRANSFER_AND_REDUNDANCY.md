# Zero-width middle vertices: exact transfer and a redundancy theorem

Research note, 2026-11-13. This is a finite combinatorial identity and an audited
theta comparison. It does not select the desired theta interior coefficients.

## 1. One middle vertex

Let an acyclic skew-symmetric matrix be topologically ordered. Let nonnegative
integer vectors `a,b` have disjoint supports, with every index in `supp(a)`
before every index in `supp(b)`. Insert a mutable vertex `w` with

`B[i,w]=a_i`, `B[w,i]=-a_i`, `B[w,j]=b_j`, `B[j,w]=-b_j`.

For the old standard dimension box `d`, put `M=a.d` and give the new label
the coordinate `g_w=M`. Its standard dimension is zero. Freezing therefore
identifies the extended theta function with

`w^M x^g F_B,g(z_i w^(b_i-a_i))`.

After mutating `w`, the old principal matrix is

`B'=B+a b^T-b a^T`.

It is still acyclic. The full mutated seed may have directed three-cycles;
the comparison consequently uses the general-seed positive-slice theorem
in `POSITIVE_SLICE_THEOREM.md`, not an assertion that the full seed remains
acyclic.

With `v=z_w'`, normalized substitution gives

`F_new=(1+v)^M F_B,g(z_i (v/(1+v))^a_i (1+v)^b_i)`.

Thus the `v^r` slice multiplies the coefficient at `p` by

`binom(M-a.p+b.p, r-a.p)`

and has old label `h_r=g+(M-r)a+r b`. At `r=M`, its origin coefficient is one,
its standard box is still `d`, and the explicit polynomial

`G(z)=sum_p a_p binom(M-a.p+b.p,b.p) z^p`

is a nonnegative sum of `theta_(B',g+Mb)` and shifted theta functions of
strictly smaller standard box. This statement uses strong positivity,
freezing, and the elementary box lemma only in the comparison proof.

## 2. Subdivide all edges from an edgeless old quiver

Start with old matrix zero and insert independent middle vertices whose
rank-one additions sum to the target acyclic matrix. Mutate all middle
vertices and take their simultaneous `r_w=M_w` slice. The source is a cluster
monomial, with `F_0=prod_i(1+z_i)^d_i`, and the resulting explicit polynomial is

`G=sum_p [prod_i binom(d_i,p_i)]`
`       [prod_w binom(M_w-a_w.p+b_w.p,b_w.p)] z^p`.

For an origin-normalized slice to have origin coefficient one, every chosen
`r_w` must be `0` or `M_w`. Choosing `r_w=0` forces all selected incoming old
slots to disappear. Therefore, if all these old directions must remain active,
the only such slice has every `r_w=M_w`, and its support is the full box. This
prevents a general one-slice realization of theta functions with smaller Newton
carrier.

## 3. Positive standard-product decomposition

The whole family of full-box transfer bounds is redundant in an induction
where smaller objects have already been identified with theta, or where
positive expansion of all smaller standard products is separately known.
Positivity of multiplication by initial `x_i` alone is not asserted to imply
this property for an arbitrary candidate basis.

Use Vandermonde in the form

`binom(X+Y,Y)=sum_k binom(X,k)binom(Y,k)`.

For each middle vertex, regard `X` as the number of weighted copies of
unselected incoming slots, and `Y` as the number of weighted copies of selected
outgoing slots. Choose equally many copies on the two sides. Fix orders on
the two copy sets and pair the chosen copies in their orders; no factorial
is introduced. The empty choice contributes the unmodified standard product.

Across all middle vertices, let `l_i` be the number of distinct marked
unselected slots of color `i`, and `r_i` the number of distinct marked selected
slots. Their sets are disjoint. After fixing the marking pattern, the
remaining `n_i=d_i-l_i-r_i` slots are free. The character of the pattern is

`z^r prod_i(1+z_i)^n_i`.

Every marked unselected slot has at least one selected outgoing partner, and
every marked selected slot has at least one unselected incoming partner.
If `U=[B]_+` and `A=[-B]_+`, this gives the capacity inequalities

`l <= U r`, `r <= A l`.

These inequalities remain valid when a middle vertex joins several colors:
the number of chosen copies is bounded by the total available copies on its
opposite side. Summing over middle vertices only enlarges the right-hand side.

For `g=-d+A d+delta`, where `delta>=0` and `delta_i=0` whenever `d_i>0`, the
corresponding Laurent term equals a frozen monomial times the standard product
for `n`, times a mutable cluster monomial of exponent

`v=delta+U r+A l-l-r >= 0`.

Every nonempty marking has `|n|<|d|`. Hence `G-M_g` is a nonnegative integer
sum of frozen and mutable monomials times smaller standard products. When
those products have positive expansion in the selected lower basis and
positive Pieri multiplication is available, `G-F_g>=0` follows from the
standard-product bound `M_g-F_g>=0`. These hypotheses hold for genuine lower
theta objects. The middle-leaf construction supplies an explicit finite
counting identity, but no new interior-selection axiom in that induction.

## 4. Skew-symmetrizable edges

For an old edge with entries `B_ij=b>0`, `B_ji=-c<0`, choose a middle vertex
with `B_iw=b`, `B_wi=-1`, `B_wj=1`, `B_jw=-c`. Its symmetrizer entry is
`D_w=D_i b=D_j c`, so the extension is skew-symmetrizable. Set `g_w=d_i`.
Mutation adds exactly the desired valued edge. Its slice weight is

`binom(d_i-p_i+p_j,p_j)`.

The marked-slot decomposition is the unit-weight one, while the target
capacity inequalities have the larger coefficients `b,c>=1`; the same
standard-product argument applies. Subdividing every valued edge gives the
general skew-symmetrizable version.

## 5. Exact check on the difficult fork

For `B=[[0,0,3],[0,0,2],[-3,-2,0]]`, `g=(-8,-7,29)`, and `d=(8,7,9)`,
`subdivision_transfer.py` checked joint, separate-edge, and unit-arrow middle
vertices. In each case `G-F` and `G-(F+D47)` have nonnegative expansions in the
already fixed smaller Pieri candidates. Their masses are respectively
`5539849465984`, `7474262292933400`, and `20833947854347872570256`.
The candidates are not silently identified with theta functions by this test.
Exact expansions are in `subdivision_transfer_results.json`.
