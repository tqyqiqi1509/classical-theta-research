#!/usr/bin/env python3
"""Certify a supplied polynomial as the lex least point of a finite cone.

Each successful step is an exact nonnegative conic identity, after all earlier
coefficient equalities have been eliminated. Numerical LP only proposes duals
or feasible counterexamples; every reported certificate is checked over Q.
"""
from positive_circuits import *
sys.path.insert(0,str(ROOT/'agent_packet_propagation'))
from linear_carrier import exact_conic
from fractions import Fraction
from itertools import permutations
import sympy as sp
import numpy as np
from scipy.optimize import linprog

def reduce_row(row,pivots):
    c=row[0];v=list(row[1:])
    for j,(old,rhs) in pivots.items():
        if v[j]:
            a=v[j];c+=a*rhs;v=[x-a*y for x,y in zip(v,old)]
    return (c,)+tuple(v)

def check_lex(B,g,points,F,order=None,kind='star'):
    M=build(B,g,points);R,space=affine_packet_rows(B,g,M)
    if kind=='pair':
        from ranktwo_packets import section_rows
        extra,_=section_rows(B,g,{p:R[i] for p,i in M['ids'].items()})
        R+= [row for key,row in extra]
    allR=list(dict.fromkeys(R));nfree=len(R[0])-1
    A={p:R[i] for p,i in M['ids'].items()}
    # Recover the actual affine parameters from all known coefficient values.
    Amat=sp.Matrix([A[p][1:] for p in points]);rhs=sp.Matrix([F.get(p,0)-A[p][0] for p in points])
    fparams,free=Amat.gauss_jordan_solve(rhs)
    if free.rows:raise ArithmeticError('coefficients do not determine parameters')
    values=[row[0]+sum(a*b for a,b in zip(row[1:],fparams)) for row in allR]
    if any(x<0 for x in values):raise ArithmeticError('candidate outside cone')
    active=[r for r,v in zip(allR,values) if not v];pivots={};cert=[];tic=time.time()
    key=order or (lambda p:(sum(p),p))
    for p in sorted(points,key=key):
        target=list(reduce_row(A[p],pivots));target[0]-=F.get(p,0)
        if not any(target):continue
        red=[reduce_row(r,pivots) for r in active]
        nonzero=[(j,r) for j,r in enumerate(red) if any(r)]
        distinct={}
        for j,r in nonzero:distinct.setdefault(r,j)
        rows=list(distinct);weights=exact_conic(tuple(target),rows)
        if weights is None:
            cons=[reduce_row(r,pivots) for r in allR]
            left=[j for j in range(nfree) if j not in pivots]
            lp=linprog([float(target[j+1]) for j in left],
                A_ub=[[-float(r[j+1]) for j in left] for r in cons],
                b_ub=[float(r[0]) for r in cons],bounds=[(None,None)]*len(left),method='highs')
            result={'status':'unresolved_dual','point':p,'candidate_coefficient':F.get(p,0),
                    'numeric_status':int(lp.status),'numeric_improvement':None if lp.fun is None else float(lp.fun+target[0])}
            if lp.x is not None:
                x=[sp.Rational(0)]*nfree
                for j,a in zip(left,lp.x):
                    q=Fraction(float(a)).limit_denominator(1000000);x[j]=sp.Rational(q.numerator,q.denominator)
                for j,(old,b) in reversed(list(pivots.items())):x[j]=b-sum(a*x[k] for k,a in enumerate(old) if k!=j)
                vals=[r[0]+sum(a*b for a,b in zip(r[1:],x)) for r in allR]
                FF={p:sp.cancel(r[0]+sum(a*b for a,b in zip(r[1:],x))) for p,r in A.items()}
                if all(v>=0 for v in vals) and FF[p]<F.get(p,0):
                    result.update({'status':'exact_smaller_witness','coefficient':str(FF[p]),
                                   'F':[{'p':q,'a':str(a)} for q,a in FF.items() if a]})
            return {'B':B,'g':g,'kind':kind,'space':space,'steps':cert,'failure':result,'seconds':time.time()-tic}
        if any(a<0 for j,a in weights):raise ArithmeticError('negative certificate')
        rhsvec=[sum(sp.Rational(a.numerator,a.denominator)*rows[j][k] for j,a in weights) for k in range(nfree+1)]
        if tuple(rhsvec)!=tuple(target):raise ArithmeticError('dual identity failure')
        cert.append({'p':p,'value':F.get(p,0),'dual':[[distinct[rows[j]],str(a)] for j,a in weights]})
        original=reduce_row(A[p],pivots);v=original[1:];j=next(j for j,a in enumerate(v) if a);a=v[j]
        pivots[j]=(tuple(t/a for t in v),(F.get(p,0)-original[0])/a)
    return {'B':B,'g':g,'kind':kind,'space':space,'lex_minimum':True,'steps':cert,
            'active_rows':[[str(a) for a in r] for r in active],'seconds':time.time()-tic}

def main():
    from pieri_recursive import PieriCache
    B=[[0,0,3],[0,0,2],[-3,-2,0]];C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache');out=[]
    for g in [(-4,-3,13),(-8,-7,29)]:
        F=C.get(g);P=list(map(tuple,C.records[g]['carrier']['lattice_points']))
        for perm in permutations(range(3)):
            order=lambda p,perm=perm:(sum(p),tuple(p[i] for i in perm))
            r=check_lex(B,g,P,F,order);r['tie_order']=perm;out.append(r)
            print(g,perm,'lex',r.get('lex_minimum'),r.get('failure'),round(r['seconds'],3),flush=True)
    (Path(__file__).parent/'lex_minimum_results.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
