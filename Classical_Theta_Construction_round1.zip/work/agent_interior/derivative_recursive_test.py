#!/usr/bin/env python3
"""Derivative expansion against the already computed lower Pieri basis."""
from pieri_tradeoff import *
from derivative_positive_test import derivative

def basis_expand(C,label,F,bound,require_smaller=None):
    remainder=dict(F);terms=[]
    for step in range(20000):
        if not remainder:return terms
        q=min(remainder,key=lambda p:(sum(p),p));a=remainder[q]
        h=tuple(label[k]+sum(C.B[k][j]*q[j] for j in range(C.n)) for k in range(C.n))
        dh,_,_=acyclic_dimension(C.B,h)
        if any(q[k]+dh[k]>bound[k] for k in range(C.n)) or (require_smaller is not None and sum(dh)>=require_smaller):
            raise ArithmeticError(('derivative expansion escaped lower box',label,q,h,dh,bound))
        G=C.get(h);terms.append({'q':q,'h':h,'coefficient':str(a)})
        for p,b in G.items():
            r=tuple(p[k]+q[k] for k in range(C.n));remainder[r]=remainder.get(r,0)-a*b
            if not remainder[r]:del remainder[r]
    raise OverflowError('basis expansion step cap')

def check(C,g,F):
    d,_,_=acyclic_dimension(C.B,g);out=[]
    for i in range(C.n):
        if not d[i]:continue
        h,D=derivative(C.B,g,F,i);bound=tuple(a-(j==i) for j,a in enumerate(d))
        E=basis_expand(C,h,D,bound,sum(d));bad=[t for t in E if Fraction(t['coefficient'])<0]
        out.append({'direction':i,'label':h,'terms':E,'negative':bad})
    return out

def main():
    B=[[0,0,3],[0,0,2],[-3,-2,0]];C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache')
    full=[g for g,r in C.records.items() if r['status']=='recursive_Pieri_candidate'];out=[];tic=time.time();badcount=0
    for g in sorted(full,key=lambda g:sum(C.records[g]['d'])):
        E=check(C,g,C.get(g));bad=[e for e in E if e['negative']]
        r={'g':g,'d':C.records[g]['d'],'negative_directions':len(bad),'bad':bad}
        out.append(r);badcount+=len(bad)
        if bad:print('BAD',g,[(z['direction'],z['negative'][:3]) for z in bad],flush=True)
    records={'cases':len(full),'derivatives':sum(len([d for d in C.records[g]['d'] if d]) for g in full),
             'negative_directions':badcount,'seconds':time.time()-tic,'records':out}
    (Path(__file__).parent/'derivative_fork_results.json').write_text(json.dumps(records,indent=2))
    print('census',len(full),'bad',badcount,'seconds',time.time()-tic,flush=True)
    witnesses=[];g=(-8,-7,29)
    for source in ['large_origin_exact_failure_2.json','commuting_completion_fork_8_7_9.json','pair_completion_fork_8_7_9.json']:
        x=json.loads((ROOT/'agent_packet_propagation'/source).read_text());P=sorted(map(tuple,x['carrier']['lattice_points']))
        tests=[('minimum',{tuple(a['p']):Fraction(a['a']) for a in x['F']})]
        for j,z in enumerate(x['failures']):
            tests.append(('tradeoff_'+str(j),{p:Fraction(*z['smaller_point'][k]) for k,p in enumerate(P) if z['smaller_point'][k][0]}))
        for name,F in tests:
            E=check(C,g,F);bad=[e for e in E if e['negative']]
            witnesses.append({'source':source,'kind':name,'expansions':E})
            print('witness',source,name,[(z['direction'],z['negative'][:2]) for z in bad],flush=True)
    x=json.loads((Path(__file__).parent/'pieri_bad_pointwise_witness.json').read_text());F={tuple(a['p']):a['a'] for a in x['H']}
    E=check(C,g,F);witnesses.append({'source':'F_plus_D47','expansions':E})
    print('witness F_plus_D47',[(z['direction'],z['negative']) for z in E if z['negative']],flush=True)
    (Path(__file__).parent/'derivative_witness_results.json').write_text(json.dumps(witnesses,indent=2))

if __name__=='__main__':main()
