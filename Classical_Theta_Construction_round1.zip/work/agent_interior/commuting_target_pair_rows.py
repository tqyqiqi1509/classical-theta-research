#!/usr/bin/env python3
"""Pull two newly detected pair inequalities to the 56-ray source tangent cone."""
from ranktwo_section_positivity import *
from normalized_fibers import mutate

def target_table(B,g,F):
    for k in (0,1):
        state,error=mutate(B,g,F,k,require_positive=False)
        if error:raise ArithmeticError(error)
        B,g,F=state
    perm=(2,0,1)
    return [[B[i][j] for j in perm] for i in perm],tuple(g[i] for i in perm),{
        tuple(p[i] for i in perm):a for p,a in F.items()}

def pair_coordinate(B,g,F,I,off,q):
    J=[j for j in range(len(g)) if j not in I]
    H={tuple(p[i] for i in I):a for p,a in F.items() if tuple(p[j] for j in J)==tuple(off)}
    h=tuple(g[i]+sum(B[i][j]*a for j,a in zip(J,off)) for i in I)
    expansion=greedy_expand(B[I[0]][I[1]],-B[I[1]][I[0]],h,H)
    return next((Fraction(z['coefficient']) for z in expansion if tuple(z['q'])==tuple(q)),Fraction(0))

def main():
    source=json.loads((ROOT/'agent_packet_propagation/pair_tangent_circuits_results.json').read_text())
    witness=json.loads((Path(__file__).parent/'pieri_witness_after_commuting_mutations.json').read_text())
    tests=[]
    for section in witness['H']['negative_sections']:
        for term in section['negatives']:
            tests.append({'I':section['I'],'off':section['off'],'q':term['q'],'h':term['h']})
    rows=[[] for _ in tests]
    for ray in source['rays']:
        D={tuple(z['p']):z['a'] for z in ray['coefficient_polynomial']}
        B,g,F=target_table(source['B'],source['g'],D)
        for row,test in zip(rows,tests):row.append(str(pair_coordinate(B,g,F,test['I'],test['off'],test['q'])))
    out={'tests':tests,'values_on_tangent_rays':rows,'ray_indices':[z['ray_index'] for z in source['rays']]}
    (Path(__file__).parent/'commuting_target_pair_rows.json').write_text(json.dumps(out,indent=2))
    for t,row in zip(tests,rows):
        print(t,'nonzero',[(i,v) for i,v in enumerate(row) if Fraction(v)],flush=True)

if __name__=='__main__':main()
