# Lexicographic and marking tests, 07:15–07:35 UTC

## Mixed marking

For `a` selected and `b` unselected slots of color `i`, the finite operator is

`a_p -> binom(p_i,a) binom(d_i-p_i,b) a_p`,

with exponent reset `p -> p-a e_i`, label
`h=g+(a+b)e_i+a B[:,i]`, and ambient box `d-(a+b)e_i`.
The source/sink-leaf comparison supplies theta positivity. The principal-leaf
extension avoids needing a new theorem for arbitrary geometric coefficients.

All 504 cached higher-rank Pieri candidates pass all 1512 first selected and
all 1512 first unselected expansions. The explicit bad transport witness
`F+D47` passes both. Higher mixed markings are positive compositions of these
operators and Pieri multiplication; a smaller actual dimension than the
ambient capacity merely contributes additional nonnegative Pieri terms.
Therefore higher orders cannot repair this witness in this cached family.

## Forward local sharpness is still incomplete

`triangular_sharpness.py` fixes every earlier coefficient and performs exact
affine elimination in the full finite Laurent space. It then checks all
available direct lower bounds: one-color quotients, rank-two greedy sections,
Pieri, selected marking, and unselected marking. Among 504 cases, 88 cases
contain 107 positive, affine-unforced coefficients with no sharp direct bound.

The first case is `g=(-4,-3,13)`, `d=(4,3,5)`, `p=(2,2,1)`, where `a_p=3`
and all the direct normalized slacks equal 3. This is not a counterexample to
global lex minimization: a later nonnegative coordinate, after finite Laurent
elimination, supplies the missing bound. Six total-degree tie orders have
exact lex-minimality certificates for this case.

## Initial-star lex minimization fails

For the hard fork, let `F` be the mass-59085 candidate. The integral polynomial

`H=F+104 u^6 v^5 w^3 [v^2(1+w)^3-1]`

is initial-star positive on the same exact carrier, has mass 59813, and lowers
`a_(6,5,3)` from 104 to zero while preserving all preceding coefficients in the
usual total-degree lex order. Its difference has a unique componentwise lowest
monomial with negative coefficient. Hence it is lexicographically smaller for
every monomial term order, not merely for one tie convention. This witness
fails the stronger rank-two-section constraints.

`lex_minimum_certificate.py` produces exact nonnegative dual identities for
each successful prefix step and rationally verifies each smaller witness.
Six tie orders were checked in `lex_minimum_results.json`.

## Full initial-pair cone has order-independent lex minimum in the hard case

The already completed exact tangent enumeration of the initial all-pair cone
at `F` has 56 rays. Fifty-five have nonnegative ordinary coefficients. The
remaining ray is

`D47=u v w(1+v)[(1+u)^5(1+v)^4-u^5v^4w^2]`.

Its unique componentwise lowest term is `u v w` with positive coefficient.
Thus every tangent ray has positive first coefficient for every monomial term
order. A nonnegative linear combination has the same property at its first
nonzero coefficient. This proves, for this complete finite cone, that `F` is
the unique lex minimum for every monomial term order. It does not prove
coefficientwise leastness or a general theta comparison.

## Literature refresh

Primary searches at approximately 07:24 UTC revisited perfect/biperfect bases,
frozen differentiation, and greedy minimality. The authoritative Acta paper
by Baumann–Kamnitzer–Knutson (2021), DOI 10.4310/ACTA.2021.v227.n1.a1,
defines perfectness with lower derivative coefficients allowed to be arbitrary
complex numbers; it cannot supply the new positivity statement. The author
PDF `https://www.math.unistra.fr/~baumann/mvstable.pdf` also explicitly discusses
nonuniqueness of biperfect bases. No representation construction is imported.
Recent 2026 Hexagon claims surfaced in search and were not used as established
theorems. The independent leaf/freezing proof is the only asserted derivative
positivity justification here.
