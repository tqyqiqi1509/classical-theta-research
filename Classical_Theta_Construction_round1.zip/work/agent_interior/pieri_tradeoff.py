#!/usr/bin/env python3
"""Exact positive-Pieri expansion of supplied candidates against cached lower objects."""
from pieri_recursive import *

def expand(C,g,F):
    d,_,_=acyclic_dimension(C.B,g);points=sorted(product(*(range(a+1) for a in d)),key=lambda p:(sum(p),p))
    out=[]
    for i,di in enumerate(d):
        if not di:continue
        remainder=dict(F);terms=[];bad=[]
        for q in points:
            a=remainder.pop(q,0)
            if not a:continue
            h=tuple(g[k]+(k==i)+sum(C.B[k][j]*q[j] for j in range(C.n)) for k in range(C.n))
            dh,_,_=acyclic_dimension(C.B,h)
            admissible=all(q[k]+dh[k]<=d[k] for k in range(C.n)) and sum(dh)<sum(d)
            term={'q':q,'h':h,'coefficient':str(a),'admissible':admissible};terms.append(term)
            if a<0 or not admissible:bad.append(term)
            if admissible:
                H=C.get(h)
                for p,b in H.items():
                    if not any(p):continue
                    r=tuple(p[k]+q[k] for k in range(C.n))
                    remainder[r]=remainder.get(r,0)-a*b
                    if not remainder[r]:del remainder[r]
        if remainder:raise ArithmeticError('Pieri expansion escaped the box')
        out.append({'direction':i,'terms':terms,'bad':bad})
    return out

def main():
    B=[[0,0,3],[0,0,2],[-3,-2,0]];g=(-8,-7,29)
    C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache');out=[]
    sources=['large_origin_exact_failure_2.json','commuting_completion_fork_8_7_9.json',
             'pair_completion_fork_8_7_9.json']
    for source in sources:
        x=json.loads((ROOT/'agent_packet_propagation'/source).read_text())
        points=sorted(map(tuple,x['carrier']['lattice_points']))
        tests=[('minimum',{tuple(z['p']):Fraction(z['a']) for z in x['F']})]
        for j,z in enumerate(x['failures']):
            tests.append(('tradeoff_'+str(j),{p:Fraction(*z['smaller_point'][k]) for k,p in enumerate(points) if z['smaller_point'][k][0]}))
        for kind,F in tests:
            expansions=expand(C,g,F)
            r={'source':source,'kind':kind,'mass':str(sum(F.values())),'expansions':expansions,
               'all_positive':all(not z['bad'] for z in expansions)}
            out.append(r)
            print(source,kind,'mass',sum(F.values()),'positive',r['all_positive'],
                  'bad',[(z['direction'],len(z['bad']),z['bad'][:2]) for z in expansions if z['bad']],flush=True)
    (Path(__file__).parent/'pieri_tradeoff_results.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
