# Positive lower-rank slices of acyclic theta functions

Research lemma, 2026-11-13. The construction below is finite and uses only
integer matrices, lower-rank coefficient tables, and compatibility
equations. Its comparison with theta uses strong theta multiplication
positivity, the audited finite theta basis/Newton containment statement,
and the freezing identity. No broken-line enumeration or representation
object is an input to the construction.

## 1. Notation and the elementary box lemma

Topologically order an acyclic integer exchange matrix B so that b_ij>=0
for i<j. Put A_ij=[-b_ij]_+, so A is strictly lower triangular. For h define

    d_i(h)=max(0,-h_i+sum_(j<i) A_ij d_j(h)).

The explicit standard product gives theta_h an F-polynomial supported in
[0,d(h)]. This bound and its scope are established in
THETA_NEWTON_PRUNING.md.

There is also an elementary converse for finite Laurent-divisible
polynomials. If G(0) != 0, supp(G) is nonnegative and contained in [0,e],
and x^h G satisfies every initial-star Laurent divisibility condition,
then e>=d(h) coordinatewise.

To prove this, start with the fibre in direction 1 with all other
coordinates zero. Its constant coefficient is nonzero, and divisibility
by (1+t)^[-h_1]_+ implies that its degree r_1 is at least d_1(h). Select
its top nonzero coefficient. Next take the direction-2 fibre through that
coefficient, with coordinates later than 2 zero. Its required divisor
degree is

    max(0,-h_2+A_21 r_1) >= d_2(h).

Select its top nonzero coefficient and continue. At step i the previously
selected coordinates r_j are at least d_j(h), hence the required degree
is at least d_i(h). The final selected support point r satisfies r>=d(h).
No positivity is required for this argument.

In particular, if the support lies in the standard box [0,d(h)] and
the origin coefficient is one, every prefix point

    (d_1(h),...,d_i(h),0,...,0)

has coefficient one: each successive fibre has required divisor degree
equal to its entire available degree, so its quotient is a constant.

## 2. Statement of slice positivity

Let I be a subset of mutable directions, J its complement. Write

    theta_g=x^g F_g(z),  z_j=y_j x^(B[:,j]).

For s in N^J, define the coefficient slice

    F_(g;J=s)(z_I) = [z_J^s] F_g(z).

Set

    h_I(s)=g_I+B_(I,J)s.

Then there are finitely many nonnegative integers c_(s,r) such that

    F_(g;J=s)(z_I)
      = sum_(r in N^I) c_(s,r) z_I^r
          F^[B_II]_(h_I(s)+B_II r)(z_I).

Here F^[B_II]_u denotes the principal F-polynomial of the lower-rank theta
function for the induced acyclic matrix B_II, with the usual geometric
coefficient extension for the frozen outside variables.

Thus every coordinate slice has a nonnegative lower-rank theta expansion.
The assertion is stronger than Laurent positivity in the frozen
subalgebra. In rank two of wild type those two conditions must not be
conflated, because universally positive elements need not have nonnegative
greedy-basis expansions.

## 3. A finite explicit freezing shift

Let S be any finite known carrier of F_g, for example the exact pruned
Newton carrier or the explicit standard box. For each q in S, compute the
lower-rank box D^I(q) in topological order on I:

    D_i^I(q)
      = max(0,-g_i-(Bq)_i
                 +sum_(l in I, l<i) A_il D_l^I(q)),   i in I.

Choose a_i=0 for i in I and, for j in J, choose

    a_j=max(0, max_(q in S) [
                 -g_j-(Bq)_j
                 +sum_(i in I, i<j) A_ji D_i^I(q)]).

Every number in this prescription is an explicit integer obtained from
B,g and finite S. By induction on the topological order, for every q in S
the full box vector for

    u(q)=g+a+Bq

has d_j(u(q))=0 for j in J, and d_i(u(q))=D_i^I(q) for i in I.
Consequently every theta_(u(q)) has F-polynomial independent of z_J.

No uniform asymptotic theorem is needed to produce this bound. It follows
directly from the already established acyclic standard-product box.

## 4. Comparison proof

Multiply theta_g by the initial cluster monomial x^a. Strong positivity
and the finite theta basis give a finite nonnegative theta expansion.

Homogeneity and principal pointedness write it as

    x^a theta_g
      = sum_q c_q y^q theta_(g+a+Bq),   c_q in N.

Every leading exponent q belongs to S. One way to see this is the audited
Newton containment theorem: each theta summand's full Newton polytope is
contained in that of x^a theta_g, so its leading exponent has frozen
coordinate q in Newt(F_g). Alternatively, once all theta summands and
coefficients are positive in the initial seed, support containment is
immediate; the finite theta-basis assertion identifies the summands.

The shift from Section 3 makes each theta summand independent of z_J.
Applying the freezing identity identifies it with the lower-rank theta
function indexed by its I coordinates. Cancelling x^(g+a) now gives

    F_g(z)=sum_q c_q z^q
               F^[B_II]_(g_I+(Bq)_I)(z_I).

Taking coefficient z_J^s gives the stated formula.

The freezing identity used here has exact audited scope:
Fan Qin, Applications of the freezing operators on cluster algebras,
arXiv:2407.03186v1, Theorem 5.2, says that the operation which deletes
all terms with positive exponents in frozen F-directions sends a theta
function to the theta function of the frozen seed. Since our summand
already has no such terms, that operation changes nothing. Theorem 6.18
provides the corresponding basis statement for injective-reachable seeds.
We use the classical statement, which covers skew-symmetrizable B.
The induced principal-coefficient version is the standard monomial
coefficient extension; the outside mutable variables remain frozen.

The proof is valid for every skew-symmetrizable acyclic B. The
symmetrizer does not enter the integer shift formula. It also establishes
all subsets I simultaneously, with a separate finite shift if desired.

## 4A. Extension to every seed in the same acyclic cluster algebra

The slice conclusion holds at every seed of an algebra possessing the
full finite theta basis used here, even when that seed's exchange matrix
is cyclic. The elementary acyclic bound in Section 3 is then replaced
by the following audited stabilization comparison theorem:

Qin, arXiv:2407.03186v1, Proposition 6.19: for a Laurent-polynomial theta
function theta_h and a mutable direction j, theta_(h+t e_j) has no
z_j in its F-polynomial for all sufficiently large integers t.

Here is the full finite uniform-shift argument. Fix the finite set S of
possible leading roots q in the theta expansion of x^a theta_g, namely
the lattice points of Newt(F_g). This set is independent of a, because
multiplication by x^a does not change the F-polynomial, and positive
summands cannot have support outside it. List J={j_1,...,j_m}.

Start with a=0. At stage r, apply Proposition 6.19 to each of the finitely
many labels h_q=g+a+Bq, q in S, and direction j_r. All these theta
functions are Laurent polynomials because the ambient algebra has the
full finite theta basis. Choose one integer t at least all their finitely
many thresholds, and replace a by a+t e_(j_r).

Previously removed F-variables remain absent. Indeed strong positivity
and pointedness make theta_(h+t e_j) a coefficient-one summand of
x_j^t theta_h, so its F-support is contained in the F-support of theta_h.
Thus at each stage every label g+a+Bq simultaneously lacks all the
directions already processed. After exactly |J| stages all summands lack
z_J. The freezing identity and coefficient extraction now give exactly
the formula in Section 2.

There is no circular use of the desired slice positivity: the only
inputs are strong theta multiplication positivity, finite theta
expansions, the stated stabilization theorem, and freezing. The choice
of shifts is finite but this general-seed proof does not supply the
elementary explicit threshold of Section 3. The actual rank-two packet
construction does not use those shifts or theta data at all; it uses
only B,g,S and the LLZ integer recurrence.

The scope is deliberately the full finite theta-basis setting, including
every seed of the acyclic algebra in this run. The weaker assumption
that one individual theta_g is finite in an arbitrary cluster algebra
is not asserted sufficient for the uniform potential-label argument.

## 5. Genuine finite rank-two compatibility equations

For |I|=2 the lower-rank theta tables are the classical LLZ greedy tables,
which have an independent compatible-pair construction and explicit
integer recurrence. Therefore this lemma gives a new finite family of
necessary, combinatorial theta conditions in every acyclic rank.

Fix a finite carrier S and one slice J=s. Order its lattice points by a
linear extension of coordinatewise order. Let A_p be the unknown slice
coefficient. Define recursively

    beta_r = A_r
       - sum_(q<r) beta_q
           [z_I^(r-q)] F^[B_II]_(h_I(s)+B_II q).

The sum is finite and all weights are explicit LLZ nonnegative integers.
Requiring every beta_r>=0 is precisely requiring a nonnegative greedy
expansion. If a candidate packet would have support outside the prescribed
slice carrier, its coefficient beta_q must be zero. These are finite
integer linear equalities and inequalities in the initial A_p.

This condition includes the original one-direction packets. If the two
directions commute, B_II=0, it becomes simultaneous division by

    (1+z_i)^[-h_i(s)]_+ (1+z_j)^[-h_j(s)]_+,

with nonnegative common quotient. Separate quotient positivity is weaker.

### Finite graph interpretation

A unit beta_q is a rank-two packet whose vertices are the compatible
pairs counted by the lower-rank LLZ polynomial, shifted by q. For each
pair-colour I and outside slice s, match vertices of these packets to
the common coefficient vertices of weight p. Equal weight multiplicities
are exactly the displayed compatibility equations.

This is a finite coloured packet graph using explicit lattice paths and
compatible pairs. Every union of connected components satisfies every
rank-two slice condition. The construction does not enumerate scattering
walls. A distinguished origin component can be minimized or analyzed by
positive circuits, exactly as for the earlier Boolean packet graphs.

The theorem proves theta is feasible in this stronger finite
compatibility system. It does not prove that its least integral origin
component is unique, seed independent, or equal to theta.

## 6. Independent exact checks and obstruction removed

The recurrence was implemented in ranktwo_section_positivity.py. Across
57 earlier rank-three through rank-five candidate tables, all 4791
coordinate two-sections had nonnegative greedy expansions. These are
mechanism checks, not a replacement for the comparison proof.

For the independently certified fractional star minimum

    B=[[0,0,3],[0,0,2],[-3,-2,0]],
    g=(-8,-7,29), d=(8,7,9),

there are 27 two-sections. Exactly one has a negative greedy coefficient:
I={1,2}, s_3=2, h_I=(-2,-3), at root r=(4,3) the coefficient is -15/2.
This is exactly the negative common quotient seen after the two commuting
mutations. Thus the new compatibility equations exclude the mass-59030
fractional star extreme ray by a finite integer recurrence.

Data: ranktwo_section_positivity_results.json. The packet agent is testing
the full strengthened cone; no universal completeness assertion is made.

## 7. Pieri order and its remaining gap

For multiplication by x_i, any pointed component with root q has label

    h=g+e_i+Bq.

If its support is contained in [0,d(g)], the box lemma gives

    q+d(h)<=d(g).

Thus q!=0 implies |d(h)|<|d(g)|. For q=0 the same strict inequality holds
when d_i(g)>0, because increasing g_i by one reduces d_i by one and cannot
increase any later d_j. This gives a genuine finite well-founded order
for a recursive positive Pieri construction.

However, arbitrary positive circuits in the enlarged multiplication cone
can have nonminimal Newton carriers. Already B3,g=(-7,14) has two
origin-zero rays with the same root q=(1,1): normalized label (-4,11),
one of mass18 on the minimal carrier and another of mass33 on a larger
carrier. Therefore pointedness of components alone is insufficient.
A Pieri construction must require its smaller components to be the
already fixed lower objects, or prove minimality of their carriers.

The slice theorem supplies sound higher-rank constraints independently
of that unresolved Pieri selection problem.
