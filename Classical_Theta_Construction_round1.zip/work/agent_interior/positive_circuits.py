#!/usr/bin/env python3
"""Exact integer double-description of the finite binomial packet cone.

No optimizer or theta coefficients are inputs. An execution can report several
origin-positive circuits: uniqueness is tested, never assumed.
"""
from packet_bounds import *
from functools import reduce

def primitive(v):
    g=math.gcd(*v)
    return tuple(a//g for a in v) if g else tuple(v)

def integer_parameter_rows(B,g,M):
    import sympy as sp
    V,space=affine_packet_rows(B,g,M)
    # Choose a basis of coordinate functionals, beginning with the origin.
    # Unlike the fast interval routine this does not require the initially
    # returned nullspace parameters to be individual coefficient coordinates.
    origin=M['ids'][(0,)*len(g)]
    candidates=[origin]+[i for i in range(len(M['points'])) if i!=origin]
    pivots=sp.Matrix([V[i] for i in candidates]).T.rref()[1]
    refs=[candidates[j] for j in pivots]
    if not refs or refs[0]!=origin or len(refs)!=len(V[0]):
        raise ArithmeticError('coefficient coordinates failed to span Laurent space')
    change=sp.Matrix([V[i] for i in refs]).inv()
    true_rows=[tuple(sp.Matrix([v])*change) for v in V]
    W=[]
    for r in true_rows:
        den=sp.ilcm(*[sp.denom(a) for a in r]) if len(r)>1 else sp.denom(r[0])
        W.append(primitive([int(den*a) for a in r]))
    return true_rows,W,refs,space

def double_description(rows,dimension,ray_cap=200000):
    """Incremental cone intersection, with exact combinatorial adjacency.

    Start with coordinate orthant. Rows are homogeneous halfspaces >=0.
    Active-set masks include the coordinate halfspaces. For a pair of old
    extreme rays, their common active equalities define their smallest face;
    they are adjacent exactly if that face has no third extreme ray.
    """
    allmask=(1<<dimension)-1
    rays=[(tuple(int(i==j) for j in range(dimension)),allmask^(1<<i)) for i in range(dimension)]
    rows=list(dict.fromkeys(tuple(r) for r in rows if any(a<0 for a in r)))
    records=[]
    for step,row in enumerate(rows):
        values=[sum(a*b for a,b in zip(row,v)) for v,mask in rays]
        pos=[i for i,a in enumerate(values) if a>0];neg=[i for i,a in enumerate(values) if a<0]
        zeros=[i for i,a in enumerate(values) if not a];newbit=1<<(dimension+step)
        if not neg:
            rays=[(v,mask|newbit if values[i]==0 else mask) for i,(v,mask) in enumerate(rays)]
            continue
        keep={rays[i][0]:(rays[i][1]|newbit if values[i]==0 else rays[i][1]) for i in pos+zeros}
        pairs=0;adjacent=0
        for i in pos:
            u,um=rays[i]
            for j in neg:
                pairs+=1;v,vm=rays[j];common=um&vm
                if any(k!=i and k!=j and (mask&common)==common for k,(w,mask) in enumerate(rays)):continue
                adjacent+=1
                w=primitive([values[i]*b-values[j]*a for a,b in zip(u,v)])
                mask=common|newbit
                if w in keep:
                    if keep[w]!=mask:raise ArithmeticError('duplicate ray active masks disagree')
                else:keep[w]=mask
        rays=list(keep.items())
        records.append({'row_index':step,'positive':len(pos),'negative':len(neg),'zero':len(zeros),
                        'pairs':pairs,'adjacent_pairs':adjacent,'rays_after':len(rays)})
        if len(rays)>ray_cap:raise OverflowError(('ray cap',step,len(rays)))
    vectors=[v for v,mask in rays]
    if any(any(sum(a*b for a,b in zip(row,v))<0 for row in rows) for v in vectors):raise ArithmeticError('final infeasible ray')
    return vectors,records

def enumerate_packet_circuits(B,g,C,ray_cap=200000,retain_rays=True):
    import sympy as sp
    tic=time.time();M=build(B,g,list(map(tuple,C['lattice_points'])));true_rows,W,refs,space=integer_parameter_rows(B,g,M)
    dimension=len(W[0]);rays,steps=double_description(W,dimension,ray_cap)
    # Recover actual a/q values using the rational, not independently scaled,
    # coordinate forms. The first parameter is the origin coefficient.
    origin=[];all_values=[]
    for ray in rays:
        vals=[sum(a*b for a,b in zip(row,ray)) for row in true_rows]
        if any(a<0 for a in vals):raise ArithmeticError('negative full packet coordinate')
        active=[row for row,val in zip(W,vals) if val==0]
        if sp.Matrix(active).rank()!=dimension-1:raise ArithmeticError('unverified extremality')
        if ray[0]>0:
            f=[a/ray[0] for a in vals]
            origin.append({'parameter_ray':ray,'mass':str(sum(f[:len(M['points'])])),
                           'integral':all(a.q==1 for a in f),
                           'F':[{'p':p,'a':str(f[i])} for p,i in M['ids'].items() if f[i]]})
        if retain_rays:all_values.append({'parameter_ray':ray,'origin':ray[0],
                                         'support':[i for i,a in enumerate(vals) if a]})
    return {'B':B,'g':g,'points':len(M['points']),'packet_coordinates':len(M['columns']),
            'space':space,'cone_dimension_parameter_count':dimension,'extreme_rays':len(rays),
            'parameter_coefficient_points':[M['points'][i] for i in refs],
            'origin_positive_rays':origin,'unique_origin_ray':len(origin)==1,
            'steps':steps,'rays':all_values,'seconds':time.time()-tic}

def main():
    x=json.loads((Path(__file__).parent/'packet_bounds_global_ranktwo_first_failure.json').read_text())
    r=enumerate_packet_circuits(x['result']['B'],x['result']['g'],x['carrier'])
    (Path(__file__).parent/'positive_circuits_ranktwo_7_8.json').write_text(json.dumps(r,indent=2))
    print({k:v for k,v in r.items() if k not in ['steps','rays','origin_positive_rays']},flush=True)
    print('origin rays',[(a['mass'],a['integral'],a['parameter_ray']) for a in r['origin_positive_rays']],flush=True)

if __name__=='__main__':main()
