#!/usr/bin/env python3
"""Audit a finite forward greedy rule, retaining exact U-space constraints.

At each coefficient, all earlier coefficients have their candidate values.
An affine forced value is recorded separately from a positivity lower bound.
No claim is made that a locally feasible lower value extends to a full point.
"""
from derivative_sharpness import *
from complement_marking_test import check_marked
from ranktwo_section_positivity import sections

def forced_coordinates(C,g,F,points,order=None):
    rows,info=divisibility_space(C.B,g,points)
    rows=affine_normalize(rows,(0,)*C.n)
    width=len(next(iter(rows.values())));zero=(0,)*width
    pivots={};out={}
    key=order or (lambda p:(sum(p),p))
    for p in sorted(points,key=key):
        v=list(rows.get(p,zero));const=v.pop(0)
        for j,(old,rhs) in pivots.items():
            if v[j]:
                c=v[j];const+=c*rhs
                v=[x-c*y for x,y in zip(v,old)]
        free=next((j for j,x in enumerate(v) if x),None)
        if free is None:
            if const!=F.get(p,0):raise ArithmeticError(('forced mismatch',p,const,F.get(p,0)))
            out[p]={'forced':True,'value':str(const)}
        else:
            c=v[free];pivots[free]=(tuple(x/c for x in v),(F.get(p,0)-const)/c)
            out[p]={'forced':False,'pivot':free}
    if len(pivots)!=width-1:raise ArithmeticError(('missing parameter',len(pivots),width))
    return out,info

def sharpness_with_space(C,g,F,points=None,order=None):
    points=points or list(map(tuple,C.records[g]['carrier']['lattice_points']))
    forced,info=forced_coordinates(C,g,F,points,order)
    PE=expand(C,g,F);DE=check(C,g,F);EE=check_marked(C,g,F)
    d,_,_=acyclic_dimension(C.B,g)
    P={e['direction']:{tuple(t['q']):Fraction(t['coefficient']) for t in e['terms']} for e in PE}
    D={e['direction']:{tuple(t['q']):Fraction(t['coefficient']) for t in e['terms']} for e in DE}
    E={e['direction']:{tuple(t['q']):Fraction(t['coefficient']) for t in e['terms']} for e in EE}
    Q=star_quotients(C.B,g,F);pair=defaultdict(list)
    for sec in sections(C.B,g,F):
        I=sec['I'];outside=tuple(j for j in range(C.n) if j not in I)
        terms={tuple(t['q']):Fraction(t['coefficient']) for t in sec['terms']}
        for p in points:
            if tuple(p[j] for j in outside)==tuple(sec['off']):
                pair[p].append(terms.get(tuple(p[j] for j in I),0))
    miss=[];free_positive=0;free_sharp=0
    for p in sorted(points,key=order or (lambda p:(sum(p),p))):
        a=F.get(p,0)
        if not a or forced[p]['forced']:continue
        free_positive+=1
        ps=[P[i].get(p,0) for i in P]
        ds=[D[i].get(tuple(p[k]-(i==k) for k in range(C.n)),0)//p[i] for i in D if p[i]]
        es=[E[i].get(p,0)//(d[i]-p[i]) for i in E if d[i]>p[i]]
        qs=[q.get(p,0) for q in Q];rs=pair[p]
        if min(ps+ds+es+qs+rs,default=0)>=1:
            miss.append({'p':p,'a':a,'pieri_slacks':[str(z) for z in ps],
                         'selected_slack_quotients':[str(z) for z in ds],
                         'unselected_slack_quotients':[str(z) for z in es],
                         'quotients':[str(z) for z in qs],
                         'ranktwo_slacks':[str(z) for z in rs]})
        else:free_sharp+=1
    return {'g':g,'space':info,'free_positive':free_positive,'free_sharp':free_sharp,'misses':miss}

def main():
    B=[[0,0,3],[0,0,2],[-3,-2,0]];C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache')
    full=[g for g,r in C.records.items() if r['status']=='recursive_Pieri_candidate']
    out=[];tic=time.time()
    for num,g in enumerate(sorted(full,key=lambda g:(sum(C.records[g]['d']),g))):
        r=sharpness_with_space(C,g,C.get(g));out.append(r)
        if r['misses']:print('MISS',g,r['misses'][:2],flush=True)
        if num%50==0:print('PROGRESS',num,round(time.time()-tic,2),flush=True)
    result={'cases':len(full),'misscases':sum(bool(z['misses']) for z in out),
            'misspoints':sum(len(z['misses']) for z in out),'seconds':time.time()-tic,'records':out}
    (Path(__file__).parent/'triangular_sharpness_results.json').write_text(json.dumps(result,indent=2))
    print('SUMMARY',{k:v for k,v in result.items() if k!='records'},flush=True)

if __name__=='__main__':main()
