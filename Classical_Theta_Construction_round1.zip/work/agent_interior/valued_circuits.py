#!/usr/bin/env python3
"""Valued acyclic mechanism checks using exact Newton pruning and integer rays."""
from positive_circuits import *
from itertools import product
import signal

def time_alarm(signum,frame):raise TimeoutError('per-case time limit')
signal.signal(signal.SIGALRM,time_alarm)

def valued_matrix(sym,edges):
    n=len(sym);B=[[0]*n for _ in range(n)]
    for i,j,c in edges:
        common=math.lcm(sym[i],sym[j])*c
        B[i][j]=common//sym[i];B[j][i]=-common//sym[j]
    return B

def main():
    cases=[]
    for sym,edges in [
      ((1,2,3),[(0,1,1),(1,2,1)]),
      ((1,2,3),[(0,1,1),(0,2,1)]),
      ((1,2,3),[(0,1,1),(0,2,1),(1,2,1)]),
      ((1,1,2),[(0,1,2),(0,2,1),(1,2,1)]),
      ((1,2,4),[(0,1,1),(0,2,1),(1,2,1)]),
      ((2,3,6),[(0,1,1),(0,2,1),(1,2,1)]),
      ((1,2,1,2),[(0,1,1),(1,2,1),(2,3,1)]),
      ((1,2,3,6),[(0,1,1),(0,2,1),(1,3,1),(2,3,1)]),
    ]:
      for dval in [2,3]:
        n=len(sym);d=(dval,)*n;B=valued_matrix(sym,edges)
        g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n))
        cases.append((sym,B,g,d))
    out=[];path=Path(__file__).parent/'valued_circuits_results.json'
    for sym,B,g,d in cases:
        tic=time.time();signal.alarm(45)
        try:
            C=prune(B,g,cap=400)
            r=enumerate_packet_circuits(B,g,C,ray_cap=3000,retain_rays=False)
            r.update({'symmetrizer':sym,'d':d,'carrier':C,'status':'complete'})
        except (TimeoutError,OverflowError) as e:
            r={'B':B,'g':g,'d':d,'symmetrizer':sym,'status':'resource cutoff','reason':str(e)}
        finally:signal.alarm(0)
        r['total_seconds']=time.time()-tic;out.append(r)
        path.write_text(json.dumps(out,indent=2))
        print({k:v for k,v in r.items() if k in ['B','g','d','status','points','space','extreme_rays','unique_origin_ray','total_seconds']},flush=True)
        if 'origin_positive_rays' in r:print('origin',[(x['mass'],x['integral']) for x in r['origin_positive_rays']],flush=True)

if __name__=='__main__':main()
