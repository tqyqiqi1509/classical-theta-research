from packet_bounds import *
from itertools import combinations_with_replacement
sys.path.insert(0,str(ROOT/'agent_packet_propagation'))
from minimum_covariance import minimality_certificate

def main():
    tic=time.time();out=[]
    for n,m,d in [(3,3,5),(3,3,6),(3,3,7),(3,3,8),(4,2,4),(4,3,4),(4,3,5)]:
        B=[[m if i<j else -m if i>j else 0 for j in range(n)] for i in range(n)]
        g=tuple((m*i-1)*d for i in range(n))
        C={'d':[d]*n,'vertices':[tuple([d]*j+[0]*(n-j)) for j in range(n+1)],
           'lattice_points':[tuple(reversed(p)) for p in combinations_with_replacement(range(d+1),n)]}
        P,cert=minimality_certificate(B,g,C)
        r=run_case(B,g,carrier=P,seed_forced=True,global_rows=True);r['minimality_certificate']=cert
        out.append(r);print(r,flush=True)
        (Path(__file__).parent/'packet_bounds_scaled_results.json').write_text(json.dumps({'results':out,'seconds':time.time()-tic},indent=2))
        if not r['lower_feasible']:
            (Path(__file__).parent/f'packet_bounds_scaled_failure_{n}_{m}_{d}.json').write_text(json.dumps({'result':r,'carrier':P},indent=2))

if __name__=='__main__':main()
