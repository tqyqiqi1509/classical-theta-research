# Finite coloured packet components and the interior selection gap

Research note, 2026-11-13. All graph constructions below are elementary finite
constructions from integer coefficient tables. Theta functions enter only the
comparison and ambient-bound argument in Section 4. No independence of the
matching choices is claimed.

## 1. Packet space on a finite carrier

Fix B, g, and a finite nonnegative lattice carrier S. For each direction k and
each fixed off-k exponent u, put

    d(k,u) = max(0, -g_k - sum_(j != k) b_kj u_j).

A nonnegative integral table a=(a_p) is star-positive if its fibre polynomial
is (1+t)^d Q_(k,u)(t), where every Q has nonnegative integer coefficients.
The quotient is unique. Its coefficients are integers whenever a is integral,
because the divisor is monic (and also has constant term one).

Let v(a) collect a and all these quotient coefficients. Then star positivity
is exactly v(a)>=0. The map a -> v(a) is integral linear on the Laurent
divisibility space. All its coordinates have finite support determined by S.

## 2. Exact finite graph realization

For each p take a_p distinguishable vertices of weight p. For each direction
k, each fibre u, each r, and each of the q_(k,u,r) units of the quotient, make
a packet with slots indexed by subsets J of [d(k,u)]. The slot indexed by J
has weight (u,r+|J|). Thus it has binom(d,j) slots at height r+j.

For each weight p and colour k, match the slots of weight p bijectively to the
a_p vertices of that weight. The packet equations say exactly that the two
sets have equal cardinality. Connect every two vertices belonging to one
packet. Equivalently, regard packets as coloured hyperedges.

**Component theorem.** The weight generating function of any union of
connected components is star-positive. If a_0=1, the component of the unique
vertex of weight 0 is pointed and every other component has zero constant
term.

**Proof.** A component contains either all or none of each coloured packet.
Its k-fibre is consequently a nonnegative integral sum of
t^r(1+t)^d. This works simultaneously for every k. The assertions about the
constant term follow from uniqueness of the origin vertex. QED.

This is an actual multicolour compatibility certificate: the same vertex
set serves all directional packet partitions. It is not a proof that any
particular canonical choice of matchings gives a theta function.

## 3. Bounded summands are exactly packet subgraphs

Let M be an explicit star-positive integral table with M_0=1. A table F is
realizable as a union of components containing the origin in some packet
graph for M if and only if

    v(F)>=0 and v(M-F)>=0, F_0=1.

For necessity, use the component theorem for the union and its complement.
For sufficiency, build separate packet graphs for F and M-F, then take their
disjoint union and label the copies as vertices/slots of M. This graph may
have additional components inside F. Consequently a minimum-mass such F
is necessarily realizable as a single origin component.

This gives a finite combinatorial optimization problem: enumerate the finite
packet matchings of M, compute the origin component, and minimize its number
of vertices (or any strictly positive weight depending only on p). It uses
finite graphs and integer counting only. Its identification with theta
requires the missing selection theorem below.

## 4. A finite explicit ambient bound in every acyclic rank

Use the standard product from THETA_NEWTON_PRUNING.md:

    M_g = x^g product_i (1+z_i)^d_i.

Its coefficient table is the product of binomial coefficients. In each
k-fibre, the required exponent d(k,u) is at most d_k, so the quotient table
is an explicit nonnegative product of binomial coefficients as well.

For the comparison only, theta strong positivity gives

    M_g = theta_g + sum_(q != 0) c_q y^q theta_(g+Bq), c_q>=0.

The coefficient at theta_g is one by pointedness and injectivity of the
principal exchange map. Thus M_g-theta_g is universally positive, giving

    0 <= v(theta_g) <= v(M_g).

This bounds both all initial theta coefficients and every initial-star
quotient coefficient by explicit integers. In particular theta_g is a
permitted component union of at least one graph of the known M_g. The
comparison uses the audited finite theta basis and positive multiplication;
the finite graph enumeration itself has no theta data as input.

The exact pruned Newton carrier P_g may be imposed by forbidding the origin
component from meeting weights outside P_g. Existence is guaranteed by the
theta comparison. This removes all outer support choices but not yet the
interior coefficient ambiguity.

## 5. The precise least-point/confluence condition

Let K(P_g) be the finite real cone of packet-positive tables supported in
P_g, and K_0 its face a_0=0. A normalized packet-coordinate least point F
exists exactly when

    K(P_g) cap {a_0=1} = F + K_0.

Equivalently, K(P_g) has exactly one extremal ray on which a_0 is positive.
Indeed, a nonnegative-coordinate cone is pointed and finitely generated;
decomposing into extremal rays proves the equivalence. In that case every
strictly positive objective on packet coordinates has the same normalized
minimizer F. Integrality of F does not follow from this cone statement alone.

The graph version asks for a matching-independent least character of the
origin component, under allowed packet rematchings. Ordinary coordinatewise
intersection cannot be invoked: even univariate positive divisibility by
1+t is not closed under coefficientwise minimum. A new uncrossing argument
using B and the exact Newton boundary is needed.

Update: the proposed general least point for these one-colour packets is
false. The exact rank-three fork counterexample documented in
POSITIVE_CIRCUIT_RECURRENCE.md has a fractional optimum and a strict
coordinate tradeoff on the exact minimal carrier. The component theorem
and finite graph realization above are unaffected. POSITIVE_SLICE_THEOREM.md
gives a proved stronger family of compatible-pair packets from lower-rank
theta positivity; its completeness is a separate question.

## 6. Why an ordinary abelian network theorem is not yet applicable

At a coefficient p, write the already determined part of the k-convolution
as R_k. The naive local completion would choose

    a_p=max_k R_k, q_(k,p)=max_l R_l-R_k.

The residual q_(k,p) decreases when R_k increases while another R_l stays
larger. Thus these residual coordinates are not a nondecreasing production
map. Bond--Levine's monotone integer-programming least-action theorem cannot
be applied to this formula without a different state representation.
Moreover, the packet agent's rank-two example has a genuine greedy point
with both directional quotient coordinates positive at p=(3,1), so local
zero slack at each p is not the required global boundary mechanism.

## 7. Other routes checked

The candidate condition 'theta_g vanishes at every admissible lower theta
start q' is false. Exact LLZ computation for B=[[0,3],[-3,0]], g=(-4,7),
q=(2,1) gives h=g+Bq=(-1,1), theta_g[q]=3, and
q+Newt(theta_h) contained in Newt(theta_g). The shifted lower theta does
extend to a zero of theta_g, at (3,3), so this does not contradict the root's
failure to find a coefficientwise dominated shifted theta.

Files: admissible_leading_test.json and imaginary_leading_test.json.

## Primary literature audited for this route

- Bond--Levine, *Abelian networks I. Foundations and examples*,
  arXiv:1309.3445v3: definitions of abelian processors and networks and the
  monotone integer-programming least-action mechanism. A nondecreasing
  production map and local commutativity are actual hypotheses.
- Bond--Levine, *Abelian networks II. Halting on all inputs*,
  arXiv:1409.0169v2: nonnegative rational production matrix and spectral
  criterion; no claim that our signed packet recurrence satisfies it.
- Mandel, *Theta bases are atomic*, arXiv:1605.03202v2: Theorem 1 concerns
  the scattering atlas. The paragraph following it explicitly leaves
  cluster-atlas indecomposability open in general. No cluster-atlas atomic
  theorem is imported here.
- Mandel, *Tropical theta functions and log Calabi--Yau surfaces*,
  arXiv:1407.5901v2: the introduction and Section 6 distinguish ordinary
  trace from the generally false full orthogonality claim for ratios of
  theta functions. The useful trace extraction hypotheses are cluster
  complex membership or exposed tropical support; they do not settle our
  arbitrary interior labels.

