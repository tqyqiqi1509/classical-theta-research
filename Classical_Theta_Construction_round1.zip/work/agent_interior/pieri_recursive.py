#!/usr/bin/env python3
"""Finite recursive positive-Pieri candidate construction.

No theta coefficients enter: rank<=2 uses LLZ; higher rank uses already
selected strictly smaller d-box candidates. A candidate is never labelled
theta merely because the LP selected it. Exact optimality and ambiguity
flags are retained, and conditional ancestor choices propagate.
"""
from packet_bounds import *
from fractions import Fraction
from itertools import product
from functools import lru_cache
from collections import defaultdict
import numpy as np
import sympy as sp
from scipy.optimize import linprog,milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix,vstack
from scipy.spatial import ConvexHull
from theta_newton_pruning import exact_vertices,verify_affine_space
from normalized_fibers import all_neighbors

def addrow(a,b,c):
    out=dict(a)
    for i,v in b.items():
        out[i]=out.get(i,0)+c*v
        if not out[i]:del out[i]
    return out

def sparse(rows,N):
    rr=[];cc=[];vv=[]
    for j,row in enumerate(rows):
        for i,c in row.items():
            if abs(c)>=2**53:raise OverflowError('Pieri integer row beyond exact binary64 range')
            rr.append(j);cc.append(i);vv.append(c)
    return coo_matrix((np.array(vv,float),(rr,cc)),shape=(len(rows),N)).tocsc()

def rank_mod(rows,N,prime=1000003):
    pivots={}
    for row in rows:
        v={j:int(a)%prime for j,a in row.items() if int(a)%prime}
        while v:
            j=min(v);a=v[j]
            if j not in pivots:
                inv=pow(a,-1,prime);pivots[j]={k:b*inv%prime for k,b in v.items()};break
            for k,b in pivots[j].items():
                c=(v.get(k,0)-a*b)%prime
                if c:v[k]=c
                elif k in v:del v[k]
        if len(pivots)==N:return N
    return len(pivots)

def rational_vector(x,maxden=1000000):
    rounded=[Fraction(round(float(a))) for a in x]
    if max((abs(float(a)-float(b)) for a,b in zip(x,rounded)),default=0)<1e-7:return rounded
    return [Fraction(float(a)).limit_denominator(maxden) for a in x]

def verify_solution(eq,ineq,z):
    if any(a<0 for a in z):return False
    if any(sum(c*z[j] for j,c in row.items())!=b for row,b in eq):return False
    if any(sum(c*z[j] for j,c in row.items())<0 for row in ineq):return False
    return True

def certify_dual(eq,ineq,lp,z):
    if lp.eqlin.marginals is None:return {'valid':False}
    le=rational_vector(lp.eqlin.marginals);mu=rational_vector(lp.ineqlin.marginals)
    if any(a>0 for a in mu):return {'valid':False,'reason':'positive inequality dual'}
    slack=[Fraction(1) for a in z]
    for (row,b),v in zip(eq,le):
        for j,c in row.items():slack[j]-=c*v
    for row,v in zip(ineq,mu):
        for j,c in row.items():slack[j]+=c*v # LP inequality is -row<=0
    value=sum(Fraction(b)*v for (row,b),v in zip(eq,le))
    if any(a<0 for a in slack) or value!=sum(z):
        return {'valid':False,'reason':'dual residual','value':str(value),'primal':str(sum(z))}
    face=[row for row,b in eq]+[row for row,v in zip(ineq,mu) if v]
    face +=[{j:1} for j,v in enumerate(slack) if v]
    rank=rank_mod(face,len(z))
    return {'valid':True,'value':str(value),'unique_optimum':rank==len(z),
            'optimal_face_rank_mod_prime':rank,'variables':len(z),'prime':1000003,
            'equality_dual':[[j,str(v)] for j,v in enumerate(le) if v],
            'inequality_dual':[[j,str(v)] for j,v in enumerate(mu) if v]}

def solve_coefficients(points,ineq,zero_rows,allowed=None,time_limit=30):
    ids={p:i for i,p in enumerate(points)};N=len(points)
    eq=[({ids[(0,)*len(points[0])]:1},1)]+[(row,0) for row in zero_rows]
    if allowed is not None:eq +=[({i:1},0) for p,i in ids.items() if p not in allowed]
    E=sparse([r for r,b in eq],N);b=np.array([b for r,b in eq],float);I=sparse(ineq,N)
    lp=linprog(np.ones(N),A_eq=E,b_eq=b,A_ub=-I,b_ub=np.zeros(len(ineq)),
               bounds=(0,None),method='highs',options={'time_limit':time_limit})
    if lp.x is None:return None,{'status':'infeasible_or_resource','lp_status':int(lp.status),'message':lp.message}
    z=rational_vector(lp.x)
    if not verify_solution(eq,ineq,z):
        z=rational_vector(lp.x,100000000)
        if not verify_solution(eq,ineq,z):return None,{'status':'unverified_primal','lp_status':int(lp.status)}
    cert=certify_dual(eq,ineq,lp,z)
    info={'status':'rational_optimum','rational_mass':str(sum(z)),
          'rational_integral':all(a.denominator==1 for a in z),'dual':cert}
    if not all(a.denominator==1 for a in z):
        mi=milp(np.ones(N),integrality=np.ones(N),bounds=Bounds(0,np.inf),
                constraints=[LinearConstraint(E,b,b),LinearConstraint(I,0,np.inf)],
                options={'time_limit':time_limit})
        info['milp_status']=int(mi.status)
        if mi.x is None:return None,dict(info,status='no_integral_choice')
        zi=[Fraction(round(float(a))) for a in mi.x]
        if not verify_solution(eq,ineq,zi):return None,dict(info,status='unverified_integer_choice')
        info['integer_mass']=str(sum(zi));info['integer_optimal']=bool(mi.status==0)
        z=zi;info['status']='integral_choice_after_fractional_optimum'
    else:info['status']='integral_optimum'
    return {p:int(z[j]) for p,j in ids.items() if z[j]},info

def hull_carrier(B,g,d,F):
    """Candidate hull from F, certified by exact Laurent vertex rows.

    Proposed integer facet inequalities are checked on every support point.
    They may give a larger carrier without invalidating the proof: F is still
    feasible there, and forced nonzero coefficients at every exact vertex
    then certify that carrier by the Newton-pruning theorem.
    """
    pts=sorted(F);n=len(g);arr=np.array(pts,dtype=float)
    hull=ConvexHull(arr);facets=set()
    for simplex in hull.simplices:
        vv=[pts[j] for j in simplex];base=vv[0]
        D=sp.Matrix([[p[k]-base[k] for k in range(n)] for p in vv[1:]])
        ns=D.nullspace()
        if len(ns)!=1:raise ArithmeticError('degenerate proposed facet')
        v=ns[0];den=sp.ilcm(*[a.q for a in v]);normal=[int(a*den) for a in v]
        gg=math.gcd(*normal);normal=[a//gg for a in normal]
        c=sum(a*b for a,b in zip(normal,base))
        values=[sum(a*b for a,b in zip(normal,p))-c for p in pts]
        if max(values)>0 and min(values)<0:raise ArithmeticError('invalid hull facet')
        if max(values)>0:normal=[-a for a in normal];c=-c
        facets.add((tuple(normal),c))
    S=[p for p in product(*(range(a+1) for a in d))
       if all(sum(a*b for a,b in zip(normal,p))<=c for normal,c in facets)]
    V,certs=exact_vertices(S)
    rows,space=divisibility_space(B,g,S);aff=affine_normalize(rows,(0,)*n)
    forced=all(p in aff and not any(aff[p][1:]) and aff[p][0]==1 for p in V)
    if forced:
        verify_affine_space(B,g,aff)
        return {'lattice_points':[list(p) for p in S],'vertices':[list(p) for p in V],
                'final_affine_dimension':space['dimension']-1,'space':space,
                'certification':'feasible_F_and_exact_forced_vertices','vertex_certificates':certs,
                'facets':[{'normal':a,'bound':b} for a,b in sorted(facets)]}
    C=prune(B,g,points=pts,cap=5000)
    C['certification']='full_vertex_pruning_from_finite_Pieri_candidate'
    return C

class PieriCache:
    def __init__(self,B,directory):
        self.B=tuple(map(tuple,B));self.n=len(B);self.directory=Path(directory)
        self.directory.mkdir(parents=True,exist_ok=True);self.cache={};self.records={}
        self.active=set();self.start=time.time();self.full_count=0
        for file in self.directory.glob('g_*.json'):
            x=json.loads(file.read_text());g=tuple(x['g'])
            if x.get('F') is not None:
                self.cache[g]={tuple(a['p']):int(a['a']) for a in x['F']};self.records[g]=x
    def filename(self,g):return self.directory/('g_'+'_'.join(str(x).replace('-','m') for x in g)+'.json')
    def store(self,g,F,record):
        record['F']=[{'p':p,'a':a} for p,a in sorted(F.items())];record['g']=g;record['B']=self.B
        self.cache[g]=F;self.records[g]=record
        self.filename(g).write_text(json.dumps(record,indent=2))
        return F
    def get(self,g):
        g=tuple(g)
        if g in self.cache:return self.cache[g]
        if g in self.active:raise ArithmeticError('Pieri recursion cycle')
        self.active.add(g);tic=time.time();d,_,_=acyclic_dimension(self.B,g)
        active=[i for i,a in enumerate(d) if a]
        if len(active)<=2:
            if not active:F={(0,)*self.n:1}
            elif len(active)==1:
                i=active[0];F={tuple(s if j==i else 0 for j in range(self.n)):math.comb(d[i],s) for s in range(d[i]+1)}
            else:
                i,j=active;H,_=llz_F(self.B[i][j],-self.B[j][i],(g[i],g[j]))
                F={tuple(p[active.index(k)] if k in active else 0 for k in range(self.n)):a for p,a in H.items()}
            self.active.remove(g)
            return self.store(g,F,{'status':'exact_lower_rank_base','d':d,'mass':sum(F.values()),
                                  'conditional_ancestor':False,'seconds':time.time()-tic})
        points=sorted(product(*(range(a+1) for a in d)),key=lambda p:(sum(p),p))
        ids={p:j for j,p in enumerate(points)};ineq=[];zero=[];dependencies=set();groups=[]
        for i in active:
            remainder={p:{ids[p]:1} for p in points};count=0;allowedq=[]
            for q in points:
                row=remainder.pop(q,{})
                h=tuple(g[k]+(k==i)+sum(self.B[k][j]*q[j] for j in range(self.n)) for k in range(self.n))
                dh,_,_=acyclic_dimension(self.B,h)
                admissible=all(q[k]+dh[k]<=d[k] for k in range(self.n)) and sum(dh)<sum(d)
                if admissible:
                    H=self.get(h);dependencies.add(h);allowedq.append((q,h));count+=1
                    if row:ineq.append(row)
                    for p,a in H.items():
                        if not any(p):continue
                        r=tuple(q[k]+p[k] for k in range(self.n))
                        if r not in ids:raise ArithmeticError('lower candidate escaped parent box')
                        remainder[r]=addrow(remainder.get(r,{}),row,-a)
                elif row:zero.append(row)
            if remainder:raise ArithmeticError('unprocessed Pieri remainder')
            groups.append({'direction':i,'allowed_roots':count})
        F,solve=solve_coefficients(points,ineq,zero)
        if F is None:
            record={'B':self.B,'g':g,'d':d,'status':'construction_failed','solve':solve,
                    'dependencies':[list(h) for h in sorted(dependencies)]}
            self.filename(g).write_text(json.dumps(record,indent=2));raise RuntimeError(record)
        ok,error=all_neighbors(self.B,g,F)
        if not ok:raise ArithmeticError(('Pieri output not star-positive',g,error))
        C=hull_carrier(self.B,g,d,F);P=set(map(tuple,C['lattice_points']))
        if any(p not in P for p in F):
            F,solve2=solve_coefficients(points,ineq,zero,allowed=P)
            if F is None:raise ArithmeticError(('Pieri infeasible on exact Newton carrier',g,solve2))
            solve['exact_carrier_resolve']=solve2
        inherited=any(self.records[h].get('conditional_ancestor') or
                      self.records[h]['status']!='exact_lower_rank_base' for h in dependencies)
        record={'status':'recursive_Pieri_candidate','d':d,'mass':sum(F.values()),
                'points':len(P),'box_points':len(points),'inequalities':len(ineq),'zero_equations':len(zero),
                'groups':groups,'solve':solve,'carrier':C,
                'dependencies':[list(h) for h in sorted(dependencies)],
                'conditional_ancestor':inherited,
                'comparison_status':'not identified with theta','seconds':time.time()-tic}
        self.active.remove(g);self.full_count+=1;self.store(g,F,record)
        print('Pieri',d,'g',g,'mass',sum(F.values()),'P',len(P),
              'LP',solve['status'],'unique',solve.get('dual',{}).get('unique_optimum'),
              'seconds',round(time.time()-tic,3),'full_cache',self.full_count,flush=True)
        return F

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--d',nargs=3,type=int,default=[4,4,5])
    args=parser.parse_args();d=tuple(args.d);B=[[0,0,3],[0,0,2],[-3,-2,0]]
    g=(-d[0],-d[1],3*d[0]+2*d[1]-d[2]);C=PieriCache(B,Path(__file__).parent/'pieri_fork_cache')
    F=C.get(g);r=C.records[g]
    print('TARGET',g,d,'mass',sum(F.values()),'records',len(C.records),'seconds',time.time()-C.start,flush=True)

if __name__=='__main__':main()
