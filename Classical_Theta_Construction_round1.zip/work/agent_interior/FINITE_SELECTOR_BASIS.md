# Finite integral selectors already give an initial-seed basis

Research lemma, 2026-11-13. This result separates the basis property from
the substantially harder positivity and seed-covariance questions.

Fix an acyclic principal-coefficient cluster algebra under the same
finite theta-basis and Newton-containment hypotheses audited in
THETA_NEWTON_PRUNING.md. Work over the chosen frozen coefficient ring R
for which that theta-basis statement holds.

For each g, choose any integral Laurent element

    S_g=x^g F_g(z),  F_g(0)=1,

whose F-polynomial is supported in the exact theta Newton carrier P_g.
No positivity assumption is needed for the basis assertion.

**Theorem.** The elements S_g form an R-basis. The change of basis to the
theta basis is finite unitriangular for the integer complexity |d(g)|.

**Proof.** The finite theta expansion and Newton containment give

    S_g=theta_g+sum_(q!=0) c_(g,q) y^q theta_(g+Bq),

where q>=0, c_(g,q) are integers, and

    q+Newt(F_(g+Bq)) subset P_g subset [0,d(g)].

The leading coefficient of theta_g is one and it is the only summand
which can contribute to the original leading exponent, so its coefficient
is one. The box lemma in POSITIVE_SLICE_THEOREM.md implies

    q+d(g+Bq)<=d(g).

For q!=0 this gives |d(g+Bq)|<|d(g)|. Thus the correction terms have
strictly smaller nonnegative integer complexity. Induction on |d(g)|
expresses each theta_g in the R-span of the S_h. The same triangular
argument applied to a finite relation proves linear independence. QED.

For |d|=0 there is no correction and S_g is the corresponding initial
cluster monomial. Every induction step is finite.

## A finite graph selector to which the theorem applies

The standard product M_g gives explicit integral coefficient bounds. Its
Boolean packet coordinates are products of binomial coefficients. Its
rank-two compatible-pair packet coordinates are computed by the explicit
LLZ subtraction recurrence.

Strong theta multiplication positivity gives M_g-theta_g theta-positive.
The positive slice theorem then gives nonnegative lower-rank packet
coordinates for both theta_g and M_g-theta_g. Consequently theta_g is the
character of an origin-containing component union in at least one finite
packet graph of the explicitly known M_g.

Restrict origin components to weights in P_g. Enumerate the finite packet
matchings, and select a component character by minimum mass and a fixed
lexicographic tie rule. This is a completely finite integer graph
selection from B,g and the finite Newton-pruning output. Its existence
uses the theta comparison; no theta coefficient table is an input.

Any such selected character is integral, pointed, supported in P_g,
and Laurent by its packet equations. Therefore it gives an R-basis by
the theorem above. The one-colour graph version supplies initial-star
positivity; the rank-two compatible-pair version supplies nonnegative
rank-two greedy expansions in every coordinate two-section.

This is an initial-seed construction. The theorem does not establish
universal Laurent positivity, independence of the initial seed, positive
structure constants, or equality with theta. Those are exactly the
additional properties needed to identify a full higher-rank greedy or
theta construction.
