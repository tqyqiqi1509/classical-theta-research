# Finite signed integer paths for classical theta functions from a negative frame

2026-11-13, 09:32 UTC; updated09:36. The general construction has passed
independent root and valued-branch proof audits. The Pieri branch is carrying
out an independent implementation and rank-two comparison. This theorem applies to **classical
skew-symmetrizable principal seeds with a supplied finite negative-frame
certificate**. In particular it is not restricted to mutation-acyclic seeds.
It does not claim that every exchange matrix possesses such a certificate.

The construction below uses only ordinary cluster exchange, finitely many
integer power-series coefficients, and two finite unitriangular matrix
recursions. It does not construct a scattering diagram, compute a wall function,
enumerate broken lines, or use a theta coefficient as input. Those objects enter
only the comparison proof identifying the independently specified integers.
The output has signed integer path weights; cancellation-free counting is not
claimed.

## 1. Input and the finite negative frame

Input an n by n skew-symmetrizable integer exchange matrix B, an integral
positive diagonal symmetrizer D with DB skew-symmetric, a target g in Z^n,
and a finite mutation word w giving a negative frame. Work with principal
coefficients, E=(B;I), and write

    z_j = y_j product_i x_i^(B_ij).

The certificate is verified by ordinary extended-matrix and F/g mutation.
After a permutation, the terminal cluster variables I_i have expansions

    I_i = x_i^(-1) H_i(z),       H_i in N[z], H_i(0)=1.       (1)

Thus the full leading exponent is (-e_i,0), not merely a mutable degree
with an unspecified frozen factor. A terminal C=-P certificate supplies this
frame by tropical duality and the integrality/permutation argument already
proved in the main project. Alternatively the algorithm can verify the
leading g-vectors directly. All H_i are computed by the finite ordinary
exchange recurrences along w. No theta computation is involved.

The negative frame is a single cluster, not n unrelated variables with
negative g-vectors. The permutation of its columns is retained explicitly.

## 2. An explicit finite carrier

Let a_i=[-g_i]_+ and v_i=[g_i]_+. Form the ordinary positive product

    M_g = x^v product_i I_i^a_i = x^g product_i H_i(z)^a_i.

Set

    d_j = sum_i a_i deg_(z_j) H_i,
    Dbox = {p in Z^n : 0<=p<=d},
    K = sum_j d_j.

If K=0, output F_g=1. Otherwise the subsequent algorithm uses only this
finite downward-closed box. The comparison proof establishes that theta_g
is in M_g with coefficient1 and a positive remainder, hence that its
F-polynomial is contained in Dbox. There is no Newton-polytope oracle or
unknown support bound in the construction.

## 3. The integer matrix determined by the frame

Define a leading-unit formal substitution, truncated to the box as needed,

    Phi(x_i)=I_i^(-1)=x_i H_i(z)^(-1),       Phi(y_j)=y_j.

Negative powers are computed by the finite integer binomial rule

    (1+H)^m = sum_(r=0)^K binom(m,r) H^r   modulo degree>K,

where H has zero constant term and m is any integer. In particular every
coefficient of every series used here is an integer. The induced formula is

    Phi(x^g z^q)
      =x^g z^q product_i H_i(z)^(-(g+Bq)_i).              (2)

Define a square integer matrix C on Dbox by

    C_(p,q) = [z^(p-q)] product_i H_i(z)^(-(g+Bq)_i)
                      if q<=p componentwise,
              0       otherwise.                        (3)

It is unitriangular when the indices are ordered by total root degree.
This matrix is specified directly by the finite exchange data (1).

## 4. A finite integer sign factorization

Choose an integer vector u such that

    u^T D alpha !=0
    for every nonzero alpha>=0 with |alpha|_1<=K.         (4)

Put lambda(alpha)=u^T D alpha. There is a unique factorization

    C = A_minus A_plus                                  (5)

into unitriangular integer matrices supported on componentwise-increasing
indices, where their off-diagonal entries satisfy

    (A_minus)_(p,q)=0 if lambda(p-q)>0,
    (A_plus)_(p,q)=0  if lambda(p-q)<0.                   (6)

Here is the complete recurrence. Set both diagonals to1. For every pair
q<p, in **increasing degree |p-q|_1**, compute

    R_(p,q) = C_(p,q)
        - sum_(q<r<p) (A_minus)_(p,r) (A_plus)_(r,q).     (7)

If lambda(p-q)<0, set (A_minus)_(p,q)=R_(p,q) and the
corresponding A_plus entry to0. If lambda(p-q)>0 do the reverse.
Both intervals in every summand of (7) are strictly shorter than p-q,
so all entries are already known. This proves existence, integrality,
uniqueness, and termination without division.

The two support conditions define subgroups of the finite unitriangular
matrix group: a sum of negative lambda increments remains negative, and
likewise for positive increments. This also follows directly from the
finite geometric-series formula for an inverse.

Let T^u=(A_minus)^(-1). Its entries are computed by

    T^u_(q,q)=1,
    T^u_(p,q)=-sum_(q<=r<p) (A_minus)_(p,r) T^u_(r,q).   (8)

This is another finite integer recurrence. It is also the signed sum over
strict chains from q to p of products of A_minus entries.

## 5. Explicit directions and the final path recurrence

Let Dmax=max_i D_i and choose the single integer

    M=1+Dmax K.

For each p in Dbox put

    m_p=g+Bp,
    u_p=M m_p+(1,...,1).                                (9)

For any alpha>=0 with 0<|alpha|<=K,

    u_p^T D alpha = M m_p^T D alpha + sum_i D_i alpha_i.

The second term is between1 and Dmax K. Hence (4) holds. If
m_p^T D alpha is nonzero, the two pairings have the same sign; if it
is zero, the u_p pairing is positive. No wall locations or chamber
searches enter this choice.

Set a_0=1. For p!=0, in increasing total degree, compute the factorization
(5)-(7) for u_p and the row of (8), then put

    a_p = -sum_(q<p) T^(u_p)_(p,q) a_q.                (10)

All inequalities q<p in this note mean q<=p componentwise and q!=p.
Output

    F_g(z)=sum_(p in Dbox) a_p z^p.

Equivalently, make a finite directed graph with vertex set Dbox and an
edge q->p of integer weight

    w(q->p) = -T^(u_p)_(p,q)   for each q<p.

Then a_p is the sum over all directed paths 0->p of the products of their
edge weights; the empty path at0 has weight1. This is the finite integer
weighted combinatorial object. The graph has no directed cycles since
root degree strictly increases.

## 6. Comparison: the total substitution is known from the negative frame

Only this and the following sections use theta theory. They do not change
or supplement the algorithm's input.

In principal cluster theta notation use full monomial exponents (m,r),
meaning x^m y^r. The increments are E alpha=(B alpha,alpha), alpha>=0.
The standard symmetrizable normalization puts a wall with charge alpha
in the hyperplane

    alpha^T D m=0.

Initial walls have alpha=e_i and hence the usual coordinate hyperplanes.
The normalization factor in the initial wall action changes with D_i,
but the displayed hyperplane and all sign arguments are unaffected.

The terminal g-cone of the negative frame is the full negative mutable
orthant, because its g-matrix is -P. In that cluster chamber the theta
functions I_i=theta_(-e_i,0) are the monomials x_i^(-1). Consequently the
coordinate transport from the negative chamber to the initial positive
chamber sends x_i^(-1) to I_i. It sends x_i to I_i^(-1).

Every frozen monomial y_j has zero pairing with all wall normals, and is
fixed by every coordinate transport. Thus this total transport is exactly
Phi, on all generators, with no extra frozen factor and no unknown scalar.
This proves the asserted identification of (2) with the total transport.

## 7. Why a two-factor matrix recursion gives the required transport

Fix the generic direction u of (4), and a generic point Q in its cell for
the finite arrangement of all positive normals D alpha with |alpha|<=K.
Take points Q_minus in the negative orthant and Q_plus in the positive
orthant. At finite degree there are only finitely many relevant walls.
Paths can be chosen arbitrarily close to the straight segments, avoiding
joints, while retaining all endpoint sign restrictions below.

Along the segment from Q_minus to Q, a hyperplane with
lambda(alpha)<0 cannot be met: its values at both endpoints are negative.
Every possible crossing therefore has lambda(alpha)>0. The transport
Chi from the negative chamber to Q has only positive-lambda root increments.
Its inverse also has this support property.

Along the segment from Q to Q_plus, a hyperplane with
lambda(alpha)>0 cannot be met. Thus the transport Psi from Q to the
initial chamber has only negative-lambda root increments, and so does
its inverse. Every nontrivial monomial of a wall action is a positive
multiple of the wall's charge. Sums of charges of one strict lambda sign
keep that sign, so the support assertion holds for the complete products,
not only individual crossings.

Consistency and composition of coordinate transports give

    Phi = Psi composed with Chi.

We use column-vector matrix actions, so on the fixed homogeneous degree g
this equality reads C=A_Psi A_Chi, in that order. The two matrices obey
exactly (6). Uniqueness of the elementary factorization (5)-(7) gives

    A_Psi = A_minus,          A_Chi=A_plus.              (11)

Thus the explicitly computed inverse T^u is the coefficient matrix of
transport from initial coordinates to Q coordinates. The construction
never enumerates the crossings or their wall functions: (11) is proved by
uniqueness after the two integer matrices have already been defined.

The box truncation is legitimate. Every transport adds nonnegative root
increments. Terms that leave a downward-closed box cannot return, under
any factor or its inverse. Hence all products and inverse rows computed
inside Dbox equal the corresponding restrictions of the complete maps.

## 8. The final-exponent argument and identification with theta

For target p, take Q as in Section7 with u=u_p. Consider the possible final
full exponent (g+Bp,p) in the Q-expansion of theta_(g,0). A wall capable of
contributing to this exponent has a primitive positive charge alpha, with
a nontrivial increment k alpha for an integer k>=1. Since all increments
are nonnegative and their total is p, |alpha|<=|p|<=K.

The backwards ray of a proposed final segment has mutable part

    Q_mut+t(g+Bp),       t>=0.

For every relevant alpha, the sign rule (9) makes
alpha^T D Q_mut and alpha^T D(g+Bp) equal whenever the latter is nonzero.
If the latter is zero, the former is still nonzero. Therefore the backwards
ray cannot meet any relevant hyperplane. There can be no last nontrivial
bend producing this final exponent.

The only possible contribution is the unbent monomial. If p!=0, its full
frozen exponent differs from the initial exponent (g,0), even in the case
Bp=0. Thus that contribution is absent. For p=0 the coefficient is1.
It follows that the genuine theta coefficients satisfy

    sum_(q<=p) T^(u_p)_(p,q) [z^q]F_g = 0  (p!=0),
    [z^0]F_g=1.

The diagonal of T is1, so this is precisely recurrence (10). Induction
on total degree proves that its output equals the theta polynomial on Dbox.
The carrier argument in Section2 proves that no coefficient was omitted.

## 9. Carrier proof and basis scope

Classical cluster theta functions have positive Laurent coefficients and
positive multiplication for skew-symmetrizable seeds. The factors x_i
and I_i of M_g are cluster theta functions. Their product is initially
pointed at full exponent (g,0), with leading coefficient1. Principal
homogeneity makes every label in its theta expansion have the form
(g+Bq,q), with q initially allowed in Z^n. In its positive
theta expansion, every occurring frozen translate has nonnegative frozen
shift: otherwise that translate's own leading monomial would have a
negative frozen exponent in M_g, with no possible cancellation.

Only the unshifted theta_(g,0) can contribute to the origin frozen exponent,
so its coefficient is exactly1. Thus theta_(g,0) is coefficientwise bounded
by M_g. This also proves finiteness directly from positivity; an infinite
positive summand cannot occur inside a finite polynomial. The degrees d_j
in Section2 therefore bound its support.

The supplied negative frame is the injective-reachability condition. The
previously audited full-basis theorem for classical skew-symmetrizable
injective-reachable principal seeds identifies the resulting family with
the theta basis of the upper cluster algebra. In acyclic cases the cluster
and upper cluster algebras agree. For a general input this distinction must
be retained: the construction is not a claim that A=U in every such class.

## 10. What is and is not established

- This supplies the same explicit signed-integer path construction for
  every rank and every skew-symmetrizer admitting the supplied finite frame.
- It uses no large-label search, quantum positivity, Lefschetz theorem,
  Li--Pan conclusion, or unaudited2026 leading-degree assertion.
- The new general step is the unique finite matrix sign factorization.
  It consumes ordinary exchange polynomials, not hidden wall data.
- The proof identifying the output with theta uses the established theta
  coordinate-transport formalism and the elementary final-segment argument.
  An entirely elementary comparison proof is not claimed.
- The integer path weights may be negative, and no efficiency bound beyond
  finite termination is claimed. Shared matrix calculations and smaller
  downward-closed carriers are practical optimizations.
- Seeds with no finite negative frame remain outside this theorem. No
  existence certificate is invented or inferred from a bounded search.

## Primary comparison sources

- GHKK, Canonical bases for cluster algebras, arXiv:1411.1394v2:
  classical principal theta positivity, cluster monomial inclusion,
  compatible coordinate transports and their composition. In particular
  Propositions3.6,3.8 and Corollary3.9 give the cluster-chamber monomial
  identification used for the negative frame.
- Qin, Bases for upper cluster algebras and tropical points,
  arXiv:1902.09507v4, AppendixA.1: finite full theta basis in the classical
  skew-symmetrizable injective-reachable setting.
- The negative-frame normalization and matrix certificate are independently
  verified by ordinary F/g mutation; see the implementation and the main
  project's negative-frame proof.

No statement from Li--Pan is a premise of this construction.
