# Finite half-space chain formula for classical theta coefficients

2026-11-13 09:52 UTC. Root proposed the elimination of the sign factorization;
this branch independently checked the row-support proof below. This is the
most direct form of the construction. In the acyclic case all data are given
by B,D,g and elementary integer formulas. There is no matrix factorization,
choice of generic direction, wall, or broken line in the algorithm.

## 1. The complete acyclic input formulas

Let B be any acyclic skew-symmetrizable exchange matrix. Relabel its vertices
so that A=[-B]_+ is strictly lower triangular. Let D be any positive integral
diagonal symmetrizer, and let g in Z^n be the desired initial label.

Compute the finite carrier bound in increasing i:

    d_i=max(0, sum_(j<i) A_(i,j)d_j - g_i).              (1)

Let J=[0,d] cap Z^n. For q<=p in J define

    C[p,q]=product_(i=1)^n
       binom(-g_i-sum_(j<i)B_(i,j)p_j-sum_(j>i)B_(i,j)q_j,
             p_i-q_i).                                 (2)

Set C[p,q]=0 when q is not componentwise at most p. The diagonal is1.
All binomial coefficients in(2) are integer binomial coefficients with
possibly negative upper arguments. In particular,

    binom(-l,k)=(-1)^k binom(l+k-1,k),    l>0.

No ordinary exchange computation is necessary after B,D,g are supplied.
The carrier and binomial-total-matrix proofs are in
ACYCLIC_LOCAL_BINOMIAL_COROLLARY.md.

## 2. The allowed chains

For every p in J put m_p=g+Bp and define the finite set

    I_p={p} union {q in J:q<p and m_p^T D(p-q)<0}.       (3)

The inequality is strict. A zero pairing is excluded. It is an explicit
integer sign test determined only by the target p and B,D,g.

For q<p define the integer edge weight w(q,p) to be0 if q is not in I_p.
If q is in I_p, let

    w(q,p)= sum_(ell>=1)
      sum_(q=q_0<q_1<...<q_ell=p; every q_j in I_p)
       (-1)^(ell+1) product_(j=1)^ell C[q_j,q_(j-1)].   (4)

Every ordering is componentwise. The strict chains in(4) have length at
most |p-q|_1, so all sums are finite. The set I_p need not be downward
closed; its definition in(3) is the entire chain restriction.

Build the directed graph with vertices J and an edge q->p of weight w(q,p)
for q<p. Define

    a_0=1,
    a_p=sum_(q<p) w(q,p)a_q.                            (5)

Equivalently, a_p is the signed integer weighted sum over graph paths from
0 to p; the empty path at0 has weight1. Equations(1)--(5) are the complete
finite combinatorial construction.

Then, in principal coefficients,

    theta_(g,0)=x^g sum_(p in J) a_p z^p,
    z_i=y_i x^(B e_i).                                 (6)

Thus the arbitrary-rank classical acyclic theta coefficients are finite
sums of products of binomial integers, indexed by finite chains and paths.
The comparison theorem proves a_p>=0. Individual chain and edge weights
are allowed to have either sign.

## 3. Efficient recurrence for the same chain weights

Enumerating all chains is unnecessary. Form the finite unitriangular
submatrix C_p=C[I_p,I_p]. The finite geometric-series formula gives

    w(q,p)=-(C_p^(-1))[p,q]    (q in I_p, q!=p).         (7)

The row can be computed from q near p downward by

    r_p=1,
    r_q=-sum_(q<s<=p, s in I_p) r_s C[s,q],
    w(q,p)=-r_q.                                       (8)

Only comparable s appear. This recurrence involves finite integer addition
and multiplication and gives exactly the explicit chain sum(4).
Formula(4), rather than a black-box inversion, specifies the combinatorial
objects; formula(8) is a direct dynamic program for those same objects.

## 4. Proof of the half-space restriction

This section is a comparison proof, not an extra algorithmic input.
Let K=sum_i d_i, M=1+(max_i D_i)K, and

    u=M m_p+(1,...,1),       lambda(alpha)=u^T D alpha.

For every nonzero positive difference alpha within J,

    lambda(alpha)<0  iff  m_p^T D alpha<0.              (9)

Indeed the second summand sum_i D_i alpha_i lies between1 and M-1,
while a nonzero first integer pairing has magnitude at least M.
In particular zero m_p pairing gives positive lambda, exactly explaining
the strict sign in(3).

For the proof only, use the unique finite sign factorization

    C=A_minus A_plus,

with negative/positive lambda supports. Let T=A_minus^(-1). Then

    T C=A_plus,
    T[p,q]=0 whenever q!=p and lambda(p-q)>0.

The p-th row of T is therefore supported on I_p. For q in I_p other
than p, the negative sign forces A_plus[p,q]=0, so

    sum_(r in I_p) T[p,r] C[r,q]=0,

while the diagonal equation gives1. Hence the row is the p-th row of
C[I_p,I_p]^(-1), proving(7). Expanding the finite inverse as
I-N+N^2-... proves(4), with the sign(-1)^(ell+1).

This argument does not require I_p to be downward closed. It uses an
exact row-support statement and a square unitriangular row equation.
There is therefore no hidden truncation assumption on the half-space set.

The previously proved last-exponent argument says that the theta
coefficients satisfy

    a_p=-sum_(q<p) T[p,q]a_q.

Using(7) gives(5). The carrier proof confines all coefficients to J, so
(6) is the complete theta polynomial and not just a finite prefix.

## 5. The same chains apply to general large-complex certificates

For a general, possibly genuinely mutation-cyclic classical seed, supply a
finite positive product of cluster variables with strictly negative initial
leading degree h. Obtain J and C by the explicit finite negative-product
construction in NEGATIVE_PRODUCT_INTEGER_THETA_THEOREM.md. Then equations
(3)--(8) apply without alteration and give the complete theta polynomial.

Thus the sign-factorization and generic directions are eliminated from the
actual algorithm in both the acyclic and the general certificate case.
They remain only convenient tools in the correctness proof. The general
case computes C from ordinary exchanges; the acyclic case has the closed
binomial expression(2).

## 6. Precise status

The formulas are classical and valid for all integral positive diagonal
symmetrizers D. They do not invoke Li--Pan conclusions, quantum bases,
2026 vanishing results, or any uncomputed theta coefficient. Their abstract
factorization proof has the Kontsevich--Soibelman/Bridgeland precedent;
no originality claim is made for that abstract lemma. Literature priority
for the complete finite half-space chain construction remains to be checked.
No cancellation-free positive counting rule or polynomial runtime bound
is asserted.

### Final literature clarification,10:10

The chain-inverse step has an exact established noncommutative slice-
inversion precedent: Mozgovoy--Reineke2014, Section8, Theorem8.3(2).
Using a finite matrix coefficient ring encodes our endpoint-dependent C
entries, and its slope-partial-sum condition gives precisely I_p. See
FRAMED_HN_INTERFACE.md Section5 for the complete dictionary. The inversion
identity itself is not a new theorem. The explicit classical carrier,
ordinary-exchange total-matrix recovery, closed acyclic binomial input,
final-exponent extraction, and certified folding application are the
specific combined construction supplied here; priority of that whole
combination remains unestablished.
