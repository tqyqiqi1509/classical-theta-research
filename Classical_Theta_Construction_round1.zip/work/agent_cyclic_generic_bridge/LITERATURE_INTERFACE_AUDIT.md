# Literature interfaces checked during the cyclic bridge branch

2026-11-13. Primary-source review log; no claim of exhaustive priority search.
The dates below are publication or preprint dates, not search timestamps.

## 1. GHKK, Canonical bases for cluster algebras (arXiv1411.1394v2)

Primary: https://arxiv.org/html/1411.1394v2

Read: Definition8.27, Proposition8.28, Lemma8.29, Corollary8.30, and their
proofs. Definition8.27 says the cluster complex escapes every half-space
for **some seed**. Proposition8.28 proves EGM and the full Fock--Goncharov
conjecture for the principal variety under that hypothesis. It does not
claim ordinary A=upper A in all these cases. Our finite negative-product
certificate is equivalent to the no-half-space property in the chosen
coordinates. The finite-certificate proof was independently reviewed; no
invariance of that coordinatewise property is silently assumed.

Use: establishes the ambient principal theta-basis scope for the general
negative-product construction. The construction itself gives finite
integer recurrences from ordinary mutation certificates.

## 2. Bridgeland, Scattering diagrams, Hall algebras and stability conditions

Publication: Algebraic Geometry4(5),2017,523--561.
Primary: https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf

Read: Section3.1--3.4, especially equation(3.2), Lemmas3.1--3.2.
The unique positive/zero/negative graded group factorization and recovery
of chamber transport from a total group element are explicitly present.
Bridgeland credits these reconstruction ideas to Kontsevich--Soibelman.

Use: genuine predecessor of the abstract factorization step. We must not
advertise our elementary sign-factorization lemma as a novel theorem.
What is separately provided here is a finite integer construction combining
ordinary exchange input, rootwise reconstruction from several seeds,
explicit positive carriers, final-exponent coefficient extraction, and the
half-space chain formula. The prior literature priority of that entire
combination remains unestablished.

## 3. Reineke, Poisson automorphisms and quiver moduli

arXiv0804.3214v2,2009; subsequent journal publication.
Primary: https://arxiv.org/pdf/0804.3214

Read: Theorem2.1; Definition4.1; Lemma4.3 and the surrounding recursion.
The paper treats acyclic quivers and factors an elementary total Poisson
automorphism by slope, relating factors to framed quiver-moduli Euler
characteristics. Definition4.1 gives an explicit Harder--Narasimhan
recursion, and the following remark gives a signed decomposition formula.
The intermediate series lie over rational functions in a quantum parameter.

Use: predecessor and possible conceptual source for the factorization
structure, not an input oracle for this classical integer algorithm. The
current acyclic formula has no representation or quantum computation as
input. No unsupported claim that all our combinatorics is new is made.

## 4. Weng, F-Polynomials of Donaldson--Thomas Transformations

arXiv2303.03466v1,2023.
Primary: https://arxiv.org/pdf/2303.03466

Read: Theorem1.1; Definition2.3; Theorem5.2 and its proof; Definition6.5,
Theorem6.6 and the first proof reduction; Example1.3; cited Zhou reference.
Theorem5.2 gives DT F-polynomials of acyclic quivers by ideals in an
ascendant-tree poset. For surfaces, the theorem applies to specified
**admissible arcs**, with explicit restrictions in Definition6.5; it must
not be shortened to an assertion for every arbitrary surface arc. The
introduction's table points to6.4, while the actual poset formula is6.6;
this is a numbering issue rather than a counterexample to the result.
Example1.3 describes folding the four-punctured-sphere DT polynomials to
the Markov quiver and cites Zhou2020.

Use: a direct finite-poset input source for certain negative-frame
polynomials. Our proved construction does not rely on Weng's conclusions:
its input polynomials were independently computed by ordinary exact
exchanges. Example1.3 prompted the general folding extension; its critical
comparison gate was then checked in Zhou's primary text rather than
accepted from this example alone.

## 5. Zhou, Cluster Structures and Subfans in Scattering Diagrams

SIGMA16(2020),013,35pp; arXiv1901.04166.
Primary: https://sigma-journal.com/2020/013/sigma20-013.pdf

Read: Section3.1 condition(3.1); Section3.3 lattice map(s*,q),
Proposition3.4, Lemma3.5, Proposition3.6, equation(3.2), Theorem3.7;
Theorem1.1 and the relevant formulation of Theorem5.1.

The folding condition is strong: the skew pairing is independent under
changing the two orbit representatives separately. Merely having a quiver
automorphism is insufficient. Proposition3.4 requires an invariant rational
automorphism before claiming rational descent. A cover negative cluster
frame supplies that hypothesis. Printed page20 explicitly identifies a
negative-chamber theta monomial with its total negative-to-positive
transport; that equality, followed by equation(3.2), is the carrier gate
for the folded integer-chain extension. Finiteness of the theta set alone
would not justify replacing an arbitrary transported monomial by theta.

Theorem3.7 transfers the full theta set from cover to fold. It is not, by
itself, an equality between the full theta span and the upper algebra for
every fold. Theorem5.1 supplies the full principal Markov conclusion.
The coefficient-free Markov conclusion is different: Theorem1.3 explicitly
states a strict containment of the theta span in the upper ring. That
specialization must therefore not be advertised as an upper basis without
additional hypotheses.

Use: general folding construction beyond negative products in the target,
with a separately checked lattice normalization and independent proof audit.

## 6. Searches not promoted to proof input

Searches also returned recent articles on tight gradings, quiver moduli,
and affine theta functions, including2026 metadata. No2026 claim from
those search snippets was used. The earlier quantum/vanishing routes and
Q-support estimates were not needed by the present classical construction.
No Li--Pan statement is used. The bounded-prefix separating-seed and
multi-seed ideas were developed into the negative-product theorem instead
of being left as a search-termination assertion.

## 09:58 refresh

A stronger search over recent theta/greedy/acyclic combinatorial algorithms
returned Reading--Stella, "Theta functions in acyclic affine type",
arXiv2603.23429, submitted2026-03-24. Only its abstract and metadata were
read in this branch; no theorem from it is used. Its stated scope concerns
the imaginary wall of acyclic affine type, not an arbitrary-rank binomial
formula of the form proved here. This abstract-level distinction is not a
priority conclusion, and the paper requires full audit before mathematical
use. Sage's official current theta-F-polynomial documentation reports a
rank-two LLZ implementation and warns that theta elements do not satisfy a
general separation-of-additions formula. Accordingly this branch's basis
and coefficient statements remain principal, except where a separate
specialization theorem is cited.

## 10:10 final primary-source addition

Mozgovoy--Reineke, JEP1(2014),117--146, Section8, primary
https://www.numdam.org/article/JEP_2014__1__117_0.pdf:
Equation(8.2) and Theorems8.2--8.3 were read directly after root flagged
them. Theorem8.3(2) exactly specializes to our restricted inverse-chain
formula over a finite matrix coefficient ring, with slope
mu(alpha)=-(g+Bp)^TDalpha/|alpha|. Matrix units encode the endpoint-dependent
C entries and enforce composability. Hence ordinary slice inversion and
its admissible-chain expansion have explicit published precedent; their
novelty is not claimed. This is mathematically useful for organizing the
remaining cross-chain problem, but it does not supply a positive packet
model. The full dictionary and precise remaining gate are recorded in
FRAMED_HN_INTERFACE.md Section5.
