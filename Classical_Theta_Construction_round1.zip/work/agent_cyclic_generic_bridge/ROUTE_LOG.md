# Cyclic bridge route and source log

2026-11-13, 09:32 UTC.

## Active research route

- Read the preceding acyclic Q/prefix/ratio construction and the negative-frame graded cap proof in full.
- A generic near-origin grade bound was found for all negative-frame seeds, but did not by itself give a far-corner cancellation argument. This route was not promoted to a complete prefix theorem.
- Investigated opposite codegrees, common dominance, and quantum standard products. Qin1902.09507v4 Sections3-6 and Rupel--Stella2023 dominance regions were opened. Compatibly pointed bases can deform, so bipointedness alone is not a uniqueness premise.
- The decisive replacement is direct finite sign factorization of the total negative-frame substitution. It removes the generic-prefix problem altogether. This is an integer matrix calculation from ordinary cluster polynomials; no individual wall is computed.
- Complete construction and comparison proof are in NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md. Root and the valued audit branch independently checked the normalization, factor order, frozen variables, and signed support argument. The Pieri branch is implementing independent LLZ and higher-rank validations.

## A necessary scope/implementation guard, not the proof's scope

An oriented tetrahedron triangulates the sphere with four punctures. Its six-edge exchange matrix was constructed directly from the four oriented triangles. A17-step green word was found and its terminal C=-P verified by integer mutation.

To certify that this test exercises genuinely new scope, the entire labeled mutation class was enumerated:270 matrices,1620 directed mutation edges, all entries bounded by2, queue exhausted, no acyclic matrix. Thus this input is demonstrably not mutation-acyclic, independently of surface classification. Files four_punctured_sphere_frame.json and four_punctured_sphere_mutation_class.json record the complete input and checks. No negative result from a bounded search is being mistaken for mutation-cyclicity.

Primary source Mills1606.03799 / Adv.Math.319(2017),182-210 was located for broad scope: maximal green sequences for finite mutation types except the stated once-punctured-closed and X7 exclusions. The present finite certificate does not depend on that theorem. URL https://arxiv.org/abs/1606.03799 .

The general construction applies to every supplied negative frame; it does not infer that every B has one. It identifies theta in the upper algebra. Ordinary A=U remains a separate condition.

## 09:43--09:59: second general mechanism and its simplifications

Primary literature reread identified the exact KS/Bridgeland precedent for
sign factorization, and Reineke's earlier slope recursion. Novelty of the
abstract factorization was explicitly disclaimed. Weng's finite-poset DT
input was read with its admissible-arc qualifications.

A finite separating seed for each extraction direction was proved enough.
This was then genuinely strengthened: rootwise recovery of the total
matrix can use a different seed for every positive increment. The formula
C[p,q]=-sum S_t[p,r]C[r,q] was independently audited and implemented.
Root recognized that any strictly negative positive product of cluster
variables automatically covers every positive root; this yielded the full
negative-product theorem, equivalent to a large-complex certificate in the
chosen seed coordinates. Valued independent audit passed. Pieri checked
all216 comparable matrix entries on a valued rank3 example and all729 on
the cyclic rank6 box against an independently computed total map.

The acyclic case collapsed to a direct B-only construction. One-step
variables give the capacity d_i=[sum_{j<i}[-B_ij]_+d_j-g_i]_+; maximal
support coordinates give a local binomial total-map recurrence. Root then
derived the closed product of binomial coefficients, independently checked
here. Finally root eliminated sign LU and generic directions from the
actual algorithm: each inverse row is the inverse of a finite submatrix
selected by (g+Bp)^T D(p-q)<0. The result is the explicit finite half-space
chain/path formula. Both this branch and valued branch independently
verified the row-support proof; Pieri implemented the formula and matched
whole K4, valued rank2, and cyclic rank6 outputs.

The next main interface is folding. Zhou2020's primary quotient theorem was
read, including the actual negative-theta transport equality on page20.
A uniform block-constant cover with a verified negative cluster frame gives
finite target negative theta polynomials by monomial relabeling; these
supply the same carrier and half-space-chain construction even if the
target has no negative cluster frame or negative product. The exact
lattice normalization and carrier gate were sent for independent audit;
UNIFORM_FOLDING_CHAIN_EXTENSION.md retains that status until received.

## 10:00--10:03: folding normalization and local cancellation

The folding carrier gate passed independent valued and root checks. A
negative-orthant theta monomial lemma was also proved directly, removing
any dependence on an unsupported unreachable-cluster claim. Arbitrary
orbit sizes obey Bbar[a,b]=r_a b[a,b], Dbar[a]=lcm(r)/r_a; this was derived
from both the principal monomial map and simultaneous initial orbit
exchange. An independent A3-to-valued-B2 exact-exchange computation checked
the full folded H-polynomials and every representative equality.

Zhou's formal equation(3.3), proved by invariant Lie operators before any
rationality conclusion, also lets the cover be supplied by a negative
product rather than a common negative cluster. The general proof is in
FOLDING_CHAIN_EXTENSION.md, with the stronger case in Section7. No blanket
upper-basis conclusion is made for every fold. The Markov target gives a
strict increase in certified scope: all its ordinary cluster g-vectors
have total degree1, so it has no strictly negative product certificate,
but the verified four-punctured-sphere cover supplies the folded input.
Pieri's full folded-chain computation for g=(-1,-1,1) used31 carrier terms,
returned16 theta terms of mass27, and passed exact neighboring Laurent
checks.

Root's new general cancellation was independently checked and written in
SEGMENTATION_CANCELLATION.md. For every fixed flattened chain, all allowed
segmentations cancel to a coefficient in{-1,0,1}, given by deterministic
binary labels P_j=P_(b_j). This removes the nested segmentation layer
without claiming positivity of each remaining chain.

10:03 final cross-read: GENERAL_BLOCK_CONSTANT_FOLDING.md in the valued branch was read in full; all core and formal-enhancement steps passed. The current authoritative folding statement is FOLDING_CHAIN_EXTENSION.md.

## 10:07--10:09: final substantive sign-cancellation interface

Reread Reineke0804.3214v2 primary Section4.1 and its explicit inversion.
Proved an exact arbitrary-rank index-and-sign bijection from each allowed
half-space inner chain to an HN admissible decomposition with one terminal
framing unit. Also proved that every endpoint pairing is the restriction
of one fixed framed alternating form Omega on (1,p). These are written in
FRAMED_HN_INTERFACE.md. They connect the present combinatorial recurrence
to a concrete established inversion; they do not constitute a completed
positive construction. The remaining precise gate is a weight-preserving
framed packet/flag realization of the endpoint-dependent binomial C
entries and a cross-chain refinement cancellation. That gate was not
silently replaced by geometric positivity or a new conjecture called a
solution.

10:10 correction/refinement after root's additional primary discovery:
Mozgovoy--Reineke2014 Section8 was read directly. Its noncommutative slice
inverse contains the exact matrix-valued chain inversion used here. The
finite matrix coefficient ring handles the C endpoint dependence, so the
formal signed-weight dictionary is complete. Remaining work is specifically
positive packet/flag realization and cross-chain cancellation. Standard
slice inversion is explicitly credited, not advertised as a new theorem.
