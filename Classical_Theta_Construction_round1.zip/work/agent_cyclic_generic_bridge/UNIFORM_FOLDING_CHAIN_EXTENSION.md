# Uniform foldings of negative-frame covers

Historical intermediate version. The fully audited arbitrary-orbit-size theorem, including negative-product covers, is FOLDING_CHAIN_EXTENSION.md.

2026-11-13 09:57 UTC. Proposed extension of the proved integer-chain
construction. The parent and valued branch are independently auditing the
literature interface in this note. The key comparison input is Yan Zhou,
SIGMA16(2020),013, Section3.3, especially Proposition3.4, Lemma3.5, and
Equation(3.2) on printed page20. No 2026 result is used.

Primary source: https://sigma-journal.com/2020/013/sigma20-013.pdf
arXiv: https://arxiv.org/abs/1901.04166

## 1. An entirely finite combinatorial input class

Supply a skew-symmetric integer cover exchange matrix Btilde, together
with a partition of its vertices into orbits O_1,...,O_n, all of the same
size r. Require the strong block-constant condition

    Btilde[i,j]=b[a,b]  for every i in O_a,j in O_b,       (1)

where b is skew-symmetric. In particular all entries inside an orbit
are0. This is stronger than merely having a quiver automorphism. The
product of symmetric groups on the orbits satisfies precisely Zhou's
independent-representative pairing condition(3.1).

Define the folded exchange matrix

    Bbar[a,b]=r b[a,b].                                 (2)

It is skew-symmetric. Supply and verify an ordinary finite negative-frame
mutation word for Btilde, and compute its negative-frame polynomials

    Itilde_i=xtilde_i^(-1) Htilde_i(ztilde),
    ztilde_i=ytilde_i product_j xtilde_j^(Btilde[j,i]).    (3)

These computations are ordinary finite cluster exchanges on the cover.
No negative frame is required to exist for Bbar.

## 2. Fold the finite polynomials by relabeling

Let sigma be the monomial map

    sigma(xtilde_i)=X_a,   sigma(ytilde_i)=Y_a
    for i in O_a.

Then(1)--(2) give

    sigma(ztilde_i)=Z_a,
    Z_a=Y_a product_b X_b^(Bbar[b,a]).                   (4)

Choose a representative i in O_a and define

    Hbar_a(Z)=Htilde_i(ztilde_j -> Z_orbit(j)),
    Ibar_a=X_a^(-1) Hbar_a(Z).                          (5)

This is a finite relabeling of integer monomials, combining equal exponents
by addition. It introduces no denominators or fractional coefficients.
Orbit equivariance of the total map implies independence of the chosen
representative; the supplied data can also verify this polynomial equality
explicitly for all representatives.

## 3. The exact comparison statement and the carrier gate

The input needed from Zhou is not just that all theta functions are finite.
One needs the following two assertions from Section3.3.

First, its principal quotient lattice map(s*,q) sends each cover mutable
basis monomial to the folded mutable basis monomial. Here s*(e_i*) is
(e_a*)/r, which is an integral basis vector of the folded M-circ lattice.
The frozen map sends e_i to e_a. Consequently its monomial map is exactly
sigma in(4), using the standard folded mutable coordinates. Uniform orbit
size makes the folded exchange matrix the skew matrix(2), and multiplying
the symmetrizer by a common scalar does not change any sign test in the
chain formula.

Second, Proposition3.4 and Lemma3.5 identify the descended total negative
to positive transport with the folded cluster total transport. The source
map is rational because it comes from a supplied negative cluster frame.
The proposition is therefore applied with all its rationality hypotheses.
Equation(3.2) says precisely that this transport commutes with sigma.

Printed page20 then explicitly takes a negative-chamber label(m,0) and a
point Q0 in the negative chamber and writes

    theta_(m,0),Q0 = z^(m,0),
    theta_(m,0),Q = p_(-,+)(z^(m,0)).                   (6)

The second equality is attributed there to GHKK Theorem3.5. Thus it is
(6), followed by the commuting diagram(3.2), that identifies

    Ibar_a=theta_(-e_a,0),                              (7)

and not an inference from the mere finiteness of theta functions.
Equation(7) is the essential carrier gate. It must be retained explicitly
when presenting this extension. The valued branch independently checked
Zhou's printed argument and also gave a direct negative-orthant version
of the GHKK Proposition3.8 bend argument: accumulated positive bend charges
have nonnegative pairing with the path after its first bend, whereas their
pairing with a strictly negative endpoint is negative. This rules out any
bent contribution for a nonpositive initial label in that chamber. Thus
(6) does not rest merely on an unverified chamber-identification assertion.

The same diagram gives the folded total substitution

    Phibar(X_a)=Ibar_a^(-1)=X_a Hbar_a(Z)^(-1),
    Phibar(Y_a)=Y_a.                                   (8)

The source negative-frame computation and the finite relabeling in(5)
therefore supply the folded total substitution without constructing a
folded wall or broken line.

## 4. Apply the same finite chain algorithm

For any folded label g, form the finite positive theta product

    M_g=X^[g]_+ product_a Ibar_a^[-g_a]_+
       =X^g product_a Hbar_a(Z)^[-g_a]_+.

Using(7), theta positivity and the same principal-homogeneity argument as
in the negative-frame theorem imply that this carrier contains theta_g
coefficientwise. This is allowed to be a product of the known theta
functions(7), even though they may not be ordinary cluster variables.
The finite polynomials in(5) are computed solely on the cover; they are
not unknown folded theta functions used as coefficient oracles.

Set

    d_b=sum_a [-g_a]_+ deg_(Z_b)Hbar_a,
    J=[0,d],
    C[p,q]=[Z^(p-q)] product_a Hbar_a(Z)^(-(g+Bbar q)_a).

Every coefficient is computed by finite integer binomial recurrences.
Use I_p and the chain weights in HALFSPACE_CHAIN_FORMULA.md, with B=Bbar
and D=I. The resulting finite signed path sum is the complete classical
principal theta function of the folded seed.

## 5. A genuinely new input regime

This certificate class is not restricted to targets having a negative
cluster frame or a strictly negative product of their ordinary cluster
variables. The standard four-punctured-sphere cover supplied in this
project has orbits

    O_0={0,5}, O_1={1,4}, O_2={2,3}

and block-constant exchange entries. Its folded matrix is

    [[0,-2,2],[2,0,-2],[-2,2,0]],

the Markov exchange matrix. The explicit17-step negative word on the cover
has already been independently verified. The three folded H_a each have
7 monomials and coefficient sum9, and their equality for both choices of
orbit representative has been checked exactly; see
folded_markov_negative_polynomials.json.

The target really has no negative-product certificate: give each initial
X_i degree1 and each frozen Y_i degree0. Every Markov mutation replaces one
variable by a ratio whose numerator has degree2 and denominator degree1,
so all ordinary cluster variables have degree1. Since every initial Z_i
has degree0, every cluster g-vector has coordinate sum1. A positive product
of these vectors has positive coordinate sum and cannot have all its
coordinates negative. Thus the folding input class adds cases excluded
from the negative-product hypothesis by an elementary grading argument.

Zhou's paper proves the full
Fock--Goncharov theorem for the principal Markov variety (Theorem1.1,
refined in Theorem5.1/Corollary5.2), despite its separate negative and
positive cluster fans.

The current extension is a uniform-folding mechanism, not a formula
invented solely for this example. The example demonstrates that its input
regime goes beyond the negative-product certificate class.

## 6. Limits that must not be silently removed

The block-constant condition(1) is essential in the cited quotient theorem.
An arbitrary quiver automorphism is insufficient. This historical uniform
version preceded the arbitrary-size normalization audit. That audit has
now passed: the current theorem FOLDING_CHAIN_EXTENSION.md includes
nonuniform orbit sizes with Bbar[a,b]=r_a b[a,b] and Dbar[a]=lcm(r)/r_a.
Use that theorem for all current scope statements.

This note proves a finite algorithm for all principal theta functions in
the stated folded class once the cited comparison gate is accepted. A
claim that these span the whole upper cluster algebra requires its own
basis theorem. Zhou gives that theorem for the principal Markov example;
Theorem3.7 alone gives the full theta set and must not be misquoted as an
upper-basis theorem in every folded case. Coefficient-free specialization
also requires its own statement: Zhou's Theorem1.3 explicitly distinguishes
the coefficient-free Markov upper ring from the full theta span.
