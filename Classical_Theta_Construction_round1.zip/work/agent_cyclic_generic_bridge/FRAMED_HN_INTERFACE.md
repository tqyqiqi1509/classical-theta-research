# Exact framed-HN interface for the remaining signed chains

2026-11-13 10:09 UTC. Final substantive route exploration. The statements
in Sections1--2 are elementary proved identities for all ranks. They do
not claim a positive model or a completed cancellation between different
chains.

## 1. All endpoint inequalities come from one framed skew form

Write

    h(p,q)=(g+Bp)^T D(p-q).

Using B^T D=-DB gives

    h(p,q)=g^T D(p-q)+p^T DBq.

On the enlarged lattice Z^(1+n), set

    Omega = [[0, -g^T D], [Dg, DB]],
    p_hat=(1,p).

Then Omega is an integral skew-symmetric matrix and

    h(p,q)=p_hat^T Omega q_hat.                         (1)

Thus the changing endpoint half-spaces in the chain formula are encoded
by a single fixed alternating pairing on a lattice with one framing
coordinate. The last-bad-index binary rule can be written entirely using
(1). This creates a concrete framed-quiver interface; it is not just a
change of notation for an unspecified stability condition.

## 2. Exact match with the index set of framed HN inversion

Fix p,q with q<p and h(p,q)<0, and let alpha=p-q. Define the integer
functional theta(beta)=(g+Bp)^T D beta. An inner allowed chain

    q=q_0<q_1<...<q_l=p

has theta(p-q_j)<0 for every j<l. Reverse its nonzero increments:

    beta_j=q_(l-j+1)-q_(l-j),       j=1,...,l.

Then beta_1+...+beta_k=p-q_(l-k), so chain admissibility is exactly

    theta(beta_1+...+beta_k)<0,       1<=k<=l.           (2)

Add a unit framing coordinate epsilon=(0,1), and give the augmented
lattice the stability

    Theta_tilde(beta,c)=-theta(beta)+c theta(alpha).

The total dimension d=(alpha,1) has Theta_tilde(d)=0. Choose the positive
rank function rank(beta,c)=|beta|_1+c. Then its slope mu(d)=0. The ordered
decomposition

    ((beta_1,0),...,(beta_l,0),epsilon)

has every proper partial sum of strictly positive slope if and only if
(2) holds. Conversely every such decomposition with final part epsilon
and all earlier parts unframed gives a unique allowed chain. This is an
exact bijection. The signed decomposition factor(-1)^(s-1) with s=l+1
is(-1)^l, precisely the sign in the restricted inverse row T[p,q].
The edge weight w=-T has the extra overall minus sign already specified
in HALFSPACE_CHAIN_FORMULA.md.

## 3. Primary interface inspected

Markus Reineke, Poisson automorphisms and quiver moduli,
arXiv0804.3214v2, primary https://arxiv.org/pdf/0804.3214,
Section4.1, Definition4.1 and the explicit formula immediately following
it on printed page6, was reread during this final round. That explicit
inversion is indexed by ordered positive decompositions whose proper
partial sums have slope strictly greater than the total slope, with an
alternating sign. Section2 and Lemma4.3 connect the recursion to a slope
factorization. Sections1--2 above give the precise matching subfamily
with a terminal framing unit, including the sign convention.

Usefulness: this is a genuine all-rank interface between our chain
restriction and an established HN inversion, and(1) gives a fixed framed
skew form governing every endpoint. It suggests looking for a single
framed flag model whose elimination produces our binomial matrix entries.
It does not replace the integer-chain construction by representation
geometry.

## 4. Exact missing step; no promotion to a positive formula

The identified index set and sign are not enough to import Reineke's
positivity conclusions. His displayed summands include Euler-form powers
and rational finite-field factors; our C[p,q] is an explicit integer
binomial product with exponents depending on both endpoints. A proof that
these weights arise from compatible finite flag packets, with refinement
maps preserving their weights, has not been supplied. Nor has a
weight-preserving sign-reversing involution between distinct flattened
chains been constructed.

This is now a specific algebraic interface to attack: establish a framed
packet/flag multiplication identity for C and show that its unstable
filtrations admit the required refinement cancellation. Merely invoking
HN existence or a geometric Euler characteristic would not meet the pure
combinatorial goal. The proved binary-label cancellation remains valid;
this last round does not claim to have removed its remaining signs.

Outcome: **useful and proved** framed skew-form identity and admissible-
decomposition bijection; **not completed** cross-chain weight-preserving
cancellation. No2026 result or special-case computation is used in this
interface.

## 5. Sharper primary interface: exact noncommutative matrix specialization

10:10 update prompted by root's fresh primary-source discovery. Sergey
Mozgovoy and Markus Reineke, Moduli spaces of stable pairs and non-abelian
zeta functions of curves via wall-crossing, JEP1(2014),117--146,
https://www.numdam.org/article/JEP_2014__1__117_0.pdf,
Section8, equation(8.2), Theorems8.2--8.3 and their decomposition proofs
were read directly. Their arbitrary coefficient-ring slice inversion gives
a more direct algebraic interface than the framing trick of Section2.
The inversion itself must therefore be credited as established machinery.

Here is the exact dictionary, including all of our endpoint-dependent
weights. Fix the finite box J and the integer matrix C. Use the finite
matrix coefficient ring R=Mat_J(Z). For every nonzero positive alpha set

    b_alpha=sum_(q,q+alpha in J)
                  C[q+alpha,q] E_(q+alpha,q).

Then b=I+sum b_alpha y^alpha records the entire matrix C with root degree.
For the selected target p, use

    mu(alpha)=-(g+Bp)^T D alpha/|alpha|_1,    tau=0.

The left factor of C is the positive-mu factor. Theorem8.3(2) gives its
inverse by ordered products with positive-mu partial sums. Matrix-unit
multiplication kills every product except a composable chain. Reading
its increments from left to right reverses the geometric chain, so those
partial sums are precisely p-q_j. Their positive-mu condition is

    (g+Bp)^T D(p-q_j)<0,

the definition of I_p. The coefficient of each surviving product is
exactly product C[q_j,q_(j-1)], with sign(-1)^(number of steps).
Thus the restricted inverse-chain expression is an exact finite matrix
specialization of the known noncommutative slice-inversion formula.
No unknown Euler-characteristic identity is required for this algebraic
matching; endpoint dependence is handled by the matrix coefficient ring.
The finite positive-root grading makes every product finite after the box
truncation.

This sharpens Section4: the missing bridge is **not** the formal HN
inversion or its signed weights, which now match exactly. The unresolved
step is a positive finite packet/flag realization of these matrix entries
and a weight-preserving cancellation between distinct flattened chains.
The arbitrary-ring theorem supplies an inversion identity, not positivity
of our individual surviving objects. The present appendix therefore records
both a useful exact interface and a limitation on novelty: standard slice
inversion is not claimed as a new theorem in this project.
