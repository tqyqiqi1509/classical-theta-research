# Cancelling all segmentations of a fixed chain

2026-11-13 10:00 UTC. Root proposed the mechanism and this branch checked
its signs and boundary cases independently. This is a general algebraic
cancellation valid for the half-space chain formula, including the acyclic,
negative-product, and certified folding settings.

## 1. Flatten the paths of chains

In HALFSPACE_CHAIN_FORMULA.md, an outer graph path is a concatenation of
strict inner chains. Fix one flattened strict chain

    s_0=0<s_1<...<s_N=p.

Its contribution is the product

    W(s)=product_(j=1)^N C[s_j,s_(j-1)]                  (1)

times the signed sum over all admissible ways to put cuts between these
steps. A block from index i to j is admissible exactly when

    (g+B s_j)^T D(s_j-s_k)<0   for every i<=k<j.        (2)

A block of length j-i has sign(-1)^(j-i+1). Consequently a segmentation
of the N-step chain into t blocks has total sign(-1)^(N+t).
The weight(1) is independent of the placement of the cuts.

## 2. A deterministic binary-label rule

For j>=1 define the last forbidden starting position

    b_j=max{k<j:(g+B s_j)^T D(s_j-s_k)>=0},             (3)

with b_j=-1 if the set is empty. Then(2) is equivalent to i>b_j.
Notice that equality in the pairing is forbidden, consistently with the
strict inequality in the original chain formula.

Attach labels P_-1=0 and P_0=1. Then, successively, set

    P_j=P_(b_j),          j=1,...,N.                    (4)

Because -1<=b_j<j, every label is already defined and belongs to{0,1}.
Set

    eta(s)=(-1)^N (P_N-P_(N-1)).                       (5)

Thus eta(s) belongs to{-1,0,1}. The entire contribution of every admissible
segmentation of the fixed chain s is exactly eta(s)W(s).

## 3. Proof of the cancellation

Let epsilon_j be the sum of(-1)^(number of blocks) over all admissible
segmentations of the prefix s_0,...,s_j. The empty prefix gives epsilon_0=1.
The last block can start at any i in{b_j+1,...,j-1}; adding it changes the
sign. Therefore

    epsilon_j=-sum_(i=b_j+1)^(j-1) epsilon_i.           (6)

Write P_j=sum_(i=0)^j epsilon_i and P_-1=0. Equation(6) becomes

    P_j=P_(j-1)-[P_(j-1)-P_(b_j)]=P_(b_j),

which is exactly(4). Hence epsilon_N=P_N-P_(N-1). Multiplying the
segmentation sign by the fixed factor(-1)^N yields(5).

The recursion also covers j=1, b_j=j-1 (no admissible final block), and
b_j=-1 (all earlier cut positions admissible). No exceptional convention
for zero pairings or empty sums is missing.

## 4. The resulting single-chain formula

The full theta coefficient can therefore be written directly as

    a_0=1,
    a_p=sum_(0=s_0<...<s_N=p)
             eta(s) product_(j=1)^N C[s_j,s_(j-1)]      (7)

for p!=0, where eta is the binary-label rule(3)--(5).
There are finitely many chains in the finite carrier box. The nested path
and chain description is no longer needed for the definition of a_p.

In the acyclic case substitute the explicit binomial formula for C. Then
(7) uses only B,D,g, a finite box, strict integer chains, integer binomial
weights, and binary labels. In the general certificate cases the same
formula uses C obtained from the finite ordinary-exchange computation.

## 5. What has and has not been cancelled

This is a proved, general cancellation of every segmentation multiplicity:
the signed number of admissible segmentations is always0,+1,or-1. It is a
substantive simplification of the combinatorial objects, independent of
special quiver examples. It does not yet prove all remaining chain weights
are nonnegative, and it does not supply a sign-reversing involution between
distinct flattened chains. Those would be further steps toward a positive
matching or compatible-pair model and are not claimed here.
