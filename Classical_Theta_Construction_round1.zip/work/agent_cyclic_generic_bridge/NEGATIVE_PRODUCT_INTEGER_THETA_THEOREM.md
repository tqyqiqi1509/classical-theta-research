# A finite negative product replaces a negative cluster frame

2026-11-13 09:48 UTC. Generalization of the negative-frame theorem.
The algebraic mechanism below was independently recognized by root and this
branch. All algorithms are classical and apply to skew-symmetrizable principal
seeds. This note supplies the general construction and its proof; identifying
its full family with a named literature class, and any upper-basis conclusion,
requires the separately cited hypotheses of the relevant basis theorem.

## 1. Finite input certificate

Let B be an integer skew-symmetrizable n by n exchange matrix and D a positive
integral diagonal symmetrizer. Supply finitely many ordinary cluster variables
X_s, together with finite mutation words computing each one and positive
integer multiplicities a_s, such that their initial g-vectors satisfy

    h = sum_s a_s g_s,             h_i<0 for every i.          (1)

The variables need not belong to a single cluster. Write

    X_s=x^(g_s) F_s(z),            z_j=y_j x^(B e_j),
    P=product_s X_s^(a_s)=x^h H(z),
    H=product_s F_s^(a_s).

All input assertions are verified by ordinary matrix, F-polynomial, and
g-vector mutation. F_s has constant term1 and nonnegative integer
coefficients. The supplied mutation words are the complete source of
coefficient data. In particular, (1) does not require a C=-P seed or a
Donaldson-Thomas cluster transformation.

## 2. Uniform finite carrier for every target

For g in Z^n, set

    k = max_i ceil( max(0,-g_i) / (-h_i) ).                    (2)

Then g-kh is componentwise nonnegative, and

    M_g = x^(g-kh) P^k = x^g H(z)^k                           (3)

is an explicitly known positive product of ordinary cluster variables.
Its initial leading full exponent is (g,0), with leading coefficient1.
The same homogeneity and theta-positivity argument as in Section9 of the
negative-frame theorem puts theta_(g,0) inside this carrier, coefficientwise.
Thus the explicit finite box

    d_i=k deg_(z_i) H,       J=[0,d] cap Z^n                  (4)

contains its complete F-polynomial. If k=0 or H^k=1, the output is1.
No degree estimate from an uncomputed theta element is used.

For clarity, this carrier argument only uses the standard classical theta
multiplication and positivity comparison. All the factors X_s and x_i are
cluster monomials and therefore theta elements. Principal homogeneity says
that any theta label occurring in their product is (g+Bq,q). Positivity,
and the absence of negative frozen exponents in (3), force q>=0. Its sole
constant term forces theta_(g,0) to occur once. Each of its nonnegative
coefficients is consequently bounded by the coefficient of (3).

## 3. Explicit root-covering seed certificates

For every nonzero alpha>=0 with alpha<=d, (1) gives

    h^T D alpha = sum_s a_s (g_s^T D alpha)<0.

Choose any s for which c=g_s^T D alpha<0. Use the supplied seed containing
X_s; denote its entire g-matrix by G_s, its relevant column by j, and its
ordinary F-polynomials by F_(s,l), 1<=l<=n.

A fully explicit point in the interior of that seed's g-cone, with negative
pairing against alpha, is obtained as follows:

    b=sum_(l!=j) (G_s[:,l])^T D alpha,
    N=1+max(0,b),
    v_alpha=N G_s[:,j] + sum_(l!=j) G_s[:,l].              (5)

Every cone coefficient is positive. Since c is an integer at most-1,

    v_alpha^T D alpha = N c+b <= -N+b <0.

No linear-programming oracle, cluster-fan search, or wall search is needed.
The same seed may serve many roots. The pairing need only be negative on
this single root; no simultaneous separation of other roots is imposed.
A small generic perturbation within the cluster cone preserves this strict
inequality whenever the comparison proof requires generic endpoints.

## 4. Known transports from the supplied ordinary seeds

For every seed s used in Section3, its g-matrix G_s is unimodular. Define

    R_(s,i)(z)=product_l F_(s,l)(z)^((G_s^(-1))_(l,i)),
    Phi_s(x_i)=x_i R_(s,i)(z),        Phi_s(y_j)=y_j.      (6)

These are explicit integer leading-unit series. Their coefficients on J
are obtained by the finite integer binomial recurrences of the original
construction. On fixed homogeneous degree g, define the integer matrix

    C_s[p,q]=[z^(p-q)] product_i R_(s,i)(z)^((g+Bq)_i),   (7)

for q<=p, and zero otherwise. Put S_s=C_s^(-1), computed by the finite
unitriangular integer inverse recurrence.

The comparison theorem for cluster chambers identifies Phi_s with the
transport from this seed's chamber to the initial positive chamber:
indeed Phi_s(x^(G_s[:,l]))=x^(G_s[:,l]) F_(s,l)=X_(s,l).
Unimodularity and the fixed frozen monomials determine all generators.
No negative chamber is assumed to be a cluster chamber here.

## 5. Recover the total finite matrix, one root at a time

Define C[p,p]=1. For every q<p in increasing interval degree |p-q|_1,
choose s as in Section3 for alpha=p-q and set

    C[p,q] = - sum_(q<=r<p) S_s[p,r] C[r,q].             (8)

Every C entry on the right has strictly smaller interval degree. Thus
(8) is a terminating finite integer recurrence. Its input consists only
of the ordinary cluster mutation data supplied in Section1. One may choose
a different covering seed for every alpha or even every pair(p,q).

### Proof that the recovered C is correct

For comparison only, let Phi be the formal total coordinate transport from
the negative mutable orthant to the initial positive chamber. This formal
map exists regardless of whether the negative chamber is reachable by
cluster mutations. Let its finite degree-g matrix be C_true.

Choose a generic point v in the seed chamber of s with v^T D alpha<0.
Composition gives

    Phi_s^(-1) composed with Phi = transport(negative orthant -> v).

The straight segment from the negative orthant to v can cross only charge
hyperplanes beta for which v^T D beta>0. Every nontrivial monomial of its
coordinate transport therefore has an increment whose pairing with v is
strictly positive: sums of such charges retain that sign. The same holds
for a sufficiently small generic path perturbation at the finite degree
under consideration.

Since v^T D(p-q)<0, this implies

    (S_s C_true)[p,q]=0.

Expanding this matrix entry gives precisely (8). The induction on interval
degree now proves C=C_true on J. It also proves that all valid choices of
covering seeds yield exactly the same C. The comparison uses the formal
transport only to prove equality; the algorithm computes (8) directly and
never requests that formal map as an input.

Downward closure is sufficient for every truncation here: every map and
inverse adds a nonnegative root. No term outside J can return to J.

## 6. Finish with the signed integer graph

Having obtained C by (8), apply Sections4--5 of
NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md without alteration:

* M=1+(max_i D_i) sum_i d_i;
* for each p, u_p=M(g+Bp)+(1,...,1);
* lambda_p(alpha)=u_p^T D alpha;
* split C=A_minus A_plus by the finite integer residual recurrence,
  ordered by interval degree;
* set T^(u_p)=A_minus^(-1);
* set a_0=1 and a_p=-sum_(q<p) T^(u_p)[p,q] a_q.

The directed graph has vertices J, edges q->p for q<p, and integer weight
-T^(u_p)[p,q]. Its path sum from0 to p is a_p. The same last-exponent
comparison identifies sum a_p z^p with the complete classical F-polynomial
of theta_(g,0). No wall, broken line, moduli space, or theta coefficient is
constructed or queried by this finite graph algorithm.

## 7. Generality and relation to a large cluster complex

A negative cluster frame is a special case: take its n variables and
multiplicity1, obtaining h=(-1,...,-1). The present certificate permits
arbitrary finitely many cluster variables from different seeds.

Fix the current seed coordinates. Suppose their union of cluster g-cones
is not contained in any closed linear half-space through0. Let K be the
convex cone generated by all their g-vectors. If K missed the open negative
orthant, a separating functional would be nonnegative on K and nonpositive
on that open orthant. Since K contains all initial e_i, this would be a
nonzero functional nonnegative on every cluster g-vector, contradicting the
no-half-space condition. Thus K meets the open negative orthant. The point
in that intersection is, by the definition of a generated cone, a finite
nonnegative real combination of cluster g-vectors. The inequalities are
strict, so its coefficients can be approximated by nonnegative rational
coefficients while preserving the negative result (discarding zero
coefficients). Clearing denominators yields (1).

Conversely, (1), together with the initial g-vectors e_i, implies that the
positive cone of all cluster g-vectors is R^n: for each i,

    -e_i = h + (-e_i-h),

and the second summand is a nonnegative integral combination of the e_j.
Hence a nonzero functional cannot be nonnegative on the entire cluster
complex. In this precise sense, the finite negative-product certificate is
equivalent to the no-containing-half-space condition in the current seed
coordinates. GHKK arXiv1411.1394v2 Definition8.27 calls a cluster complex
large when this condition holds for some seed. If only that existential
large-complex statement is given, include the seed where it holds, together
with its mutation word, in the certificate and perform this construction
in those coordinates. No unproved assertion that every initial coordinate
identification has the same half-space property is needed. GHKK
Proposition8.28 supplies the full Fock--Goncharov theorem for the principal
cluster variety under this condition; it does not by itself assert A=U.

A word enumeration can find this finite certificate whenever that condition
is known to hold: enumerate finitely many reachable variables, solve the
finite rational linear feasibility problem for a strictly negative sum,
and clear denominators. This is an existence/termination statement under
the stated large-complex assumption; it is not a claim that every exchange
matrix satisfies it. Once a certificate is supplied, all subsequent steps
above have explicit finite bounds and integer recurrences.

## 8. Novelty and proof-interface boundary

The abstract sign factorization has the Kontsevich--Soibelman/Bridgeland
precedent; see Bridgeland2017 Section3.2, equation(3.2), and Lemmas3.1--3.2.
It is not claimed as a new group-theoretic factorization lemma. The present
result is the explicit finite integer construction obtained by combining
ordinary mutation certificates, the rootwise reconstruction (8), finite
positive carriers, and the target-dependent last-exponent recurrence.
Literature priority for that complete combination has not been established.
The construction uses signed integer weights; cancellation-free positive
objects and efficient complexity bounds are not asserted.
