# Direct binomial graph construction for every classical acyclic seed

2026-11-13 09:50 UTC. Root proposed the local-seed total-matrix recurrence;
this branch independently checked its normalization and supplied the direct
B-only carrier below. This is a specialization of the negative-product theorem.
It requires no negative word, frame F-polynomial, quantum input, or external
coefficient oracle.

## Input and topological order

Let B be an acyclic skew-symmetrizable integer exchange matrix. Relabel its
vertices topologically so that

    A=[-B]_+

is strictly lower triangular. Let D be any positive integral diagonal
symmetrizer, DB skew-symmetric, and let g be the desired initial label.

The one-step cluster mutation at i gives the ordinary cluster variable

    X_i'=x^(b_i)(1+z_i),
    b_i=-e_i+sum_(j>i) A_(j,i)e_j,
    z_i=y_i x^(B e_i).                                  (1)

These n variables need not lie in a common cluster, which is precisely why
the negative-product theorem is useful.

## 1. Compute the carrier box directly from B and g

In increasing vertex order set

    a_i=max(0, sum_(j<i) A_(i,j)a_j - g_i).              (2)

Put h=(A-I)a. Then h_i<=g_i for every i, and

    M_g=x^(g-h) product_i (X_i')^(a_i)
       =x^g product_i(1+z_i)^(a_i)                     (3)

is a positive product of ordinary cluster variables with leading degree g.
Consequently the complete theta F-polynomial is supported in

    J={p in Z^n:0<=p_i<=a_i}.                           (4)

The a_i are integers obtained by n additions and positive-part operations.
No mutation sequence or F-polynomial calculation is needed for this bound.
If every a_i=0, the answer is1.

## 2. The total finite matrix has a closed binomial formula

For q<=p, set

    C[p,q] = product_(i=1)^n
        binom(-g_i-sum_(j<i) B_(i,j)p_j-sum_(j>i) B_(i,j)q_j,
              p_i-q_i).                                (5a)

Set C[p,q]=0 if q is not componentwise at most p. Formula(5a), together
with the carrier(2), makes the entire construction a finite B,D,g formula.
It avoids even the ordinary cluster mutation computation of input series.
The following recurrence and its proof verify this closed expression.

### A recursive form and its proof

Set C[q,q]=1 and C[p,q]=0 if q is not componentwise at most p. For q<p,
let

    delta=p-q,
    i=max{j:delta_j>0}.

In increasing interval degree |delta|_1, define

    C[p,q]= -sum_(k=1)^(delta_i)
                 binom((g+Bp)_i,k) C[p-k e_i,q].        (5)

The upper argument is any integer; use

    binom(m,k)=m(m-1)...(m-k+1)/k!

or the equivalent integer rule

    binom(-l,k)=(-1)^k binom(l+k-1,k),   l>0.

Thus (5) consists entirely of finite integer operations. The binomial integer
may also be represented as a signed count of k-subsets or k-multisets.

### Verification of (5)

The one-step seed at i has g-column b_i in (1). Since i is the largest
nonzero coordinate of delta,

    b_i^T D delta=-D_i delta_i<0.                       (6)

The other terms in b_i are supported at j>i, where delta_j=0. A point in
the interior of that one-step cluster cone can be chosen arbitrarily close
to the b_i ray and still has negative pairing with delta.

The normalized transport from that cluster chamber to the initial chamber
is the explicit ordinary substitution

    Phi_i(x_i)=x_i/(1+z_i),
    Phi_i(x_j)=x_j (j!=i),       Phi_i(y_j)=y_j.

Because B_ii=0, Phi_i fixes z_i. Its inverse sends x_i to x_i(1+z_i).
Therefore the matrix S_i of Phi_i^(-1) on homogeneous degree g has entries

    S_i[p,r]=binom((g+Br)_i,k)

when p-r=k e_i, k>=0, and zero otherwise. Since B_ii=0,
(g+Br)_i=(g+Bp)_i for these indices. Substituting this expression into the
rootwise reconstruction formula

    C[p,q]=-sum_(q<=r<p) S_i[p,r] C[r,q]

gives exactly (5). All hypotheses of that general reconstruction follow
from (6), so C is the correct total transport matrix on J.

To derive(5a), hold all coordinates except the largest active i fixed.
The exponent m_i=(g+Bp)_i is unchanged as p_i decreases. Equation(5) is
exactly convolution by the nonconstant coefficients of(1+t)^(m_i);
its inverse contributes binom(-m_i,p_i-q_i). After eliminating the i-th
coordinate, it equals q_i. Proceeding downward in i, higher coordinates
have already become q_j, while lower coordinates are still p_j. Thus

    m_i=g_i+sum_(j<i) B_(i,j)p_j+sum_(j>i) B_(i,j)q_j,

and multiplication of the independent elimination factors gives(5a).
This is a finite elementary binomial convolution argument.

## 3. Finish with three explicit finite integer recurrences

Let K=sum_i a_i and M=1+(max_i D_i)K. For every target vertex p define

    u_p=M(g+Bp)+(1,...,1),
    lambda_p(delta)=u_p^T D delta.

For this direction factor C=A_minus A_plus. Both factors have diagonal1.
For q<r in increasing |r-q|, calculate

    R[r,q]=C[r,q]-sum_(q<s<r) A_minus[r,s] A_plus[s,q].

Assign R[r,q] to A_minus[r,q] if lambda_p(r-q)<0, and to A_plus[r,q]
if lambda_p(r-q)>0; assign the other entry0. There are no zero signs for
nonzero differences in J. Invert A_minus by

    T[q,q]=1,
    T[r,q]=-sum_(q<=s<r) A_minus[r,s]T[s,q].

This T depends on p through u_p. Finally put

    f_0=1,
    f_p=-sum_(q<p) T^(u_p)[p,q]f_q.                     (7)

The graph vertices are J and its edge q->p has integer weight
-T^(u_p)[p,q]. Then f_p is the finite path sum from0 to p, and

    theta_(g,0)=x^g sum_(p in J) f_p z^p.

This is a direct formula from B,D,g using only integer arithmetic, binomial
coefficients, sign tests, and paths in a finite directed acyclic graph.
The established comparison proof proves f_p>=0; individual graph edges
may have negative weights. No cancellation-free interpretation is asserted.

## 4. Relation to the uniform negative-product certificate

A single certificate independent of g is also explicit. Set

    c_i=1+sum_(j<i) A_(i,j)c_j.

Then (A-I)c=(-1,...,-1), so product_i (X_i')^(c_i) has strictly negative
leading degree. This verifies the general large-cluster-complex condition
without constructing a negative cluster frame. Formula(2) is the smaller
target-dependent carrier and should be used in computation.
