import json,time,sys
from collections import deque
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_negative_frame'))
from negative_frame import mutate_matrix
case=json.loads(Path(__file__).with_name('four_punctured_sphere_frame.json').read_text());B=case['B'];n=len(B)
def enc(B):return bytes(x+4 for row in B for x in row)
def dec(s):return [[s[n*i+j]-4 for j in range(n)] for i in range(n)]
def acyclic(B):
 ind=[sum(B[j][i]>0 for j in range(n)) for i in range(n)];todo=[i for i in range(n) if not ind[i]];cnt=0
 while todo:
  i=todo.pop();cnt+=1
  for j in range(n):
   if B[i][j]>0:
    ind[j]-=1
    if ind[j]==0:todo.append(j)
 return cnt==n
q=deque([enc(B)]);seen={enc(B)};edges=0;tic=time.time();bound=200000
while q:
 s=q.popleft();b=dec(s)
 if acyclic(b):print('ACYCLIC_FOUND');sys.exit(1)
 for k in range(n):
  nxt=mutate_matrix(b,k);edges+=1
  assert max(abs(x) for row in nxt for x in row)<=2
  ss=enc(nxt)
  if ss not in seen:seen.add(ss);q.append(ss)
 if len(seen)>bound:print('RESOURCE_BOUND',len(seen),len(q));sys.exit(2)
out={'input':B,'all_labeled_mutation_states':len(seen),'directed_mutation_edges':edges,'queue_exhausted':True,'acyclic_states':0,'max_absolute_entry_bound':2,'seconds':time.time()-tic}
Path(__file__).with_name('four_punctured_sphere_mutation_class.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
