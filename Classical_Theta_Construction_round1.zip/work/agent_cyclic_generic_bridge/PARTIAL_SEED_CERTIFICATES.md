# A finite-degree replacement for a global negative frame

2026-11-13 09:42 UTC. This is a proved extension of the coefficient-extraction
mechanism with an explicitly checkable input certificate. It is not a claim
that the certificate exists for every seed and every target.

## 1. Prefix version needs no unknown carrier

Fix a finite downward-closed set J of nonnegative roots, for example
J=[0,p] for a requested coefficient p or J={q:|q|<=K}. The last-segment
comparison and the finite matrix recursions apply to this set directly.
They compute the corresponding prefix of the formal theta function;
no assertion of global finiteness is needed for that statement.

For a complete polynomial, an independent finite carrier is still needed.
A supplied positive product of cluster variables whose initial leading
mutable degree is g gives such a carrier by the same positive-expansion
argument as in the negative-frame theorem. The negative frame gives this
carrier uniformly for all g.

## 2. A separating seed is enough for one direction

For the direction u associated to a target coefficient, list all nonzero
alpha>=0 of degree at most K and put lambda(alpha)=u^T D alpha.
Assume lambda never vanishes. Supply any finite cluster mutation word
ending at a seed t. Compute its ordinary F-polynomials F_j and g-matrix G.

The certificate consists of a positive rational (or, after scaling, integer)
vector a such that v=G a satisfies

    v^T D alpha<0 whenever lambda(alpha)<0.              (1)

This is a finite list of rational linear inequalities. A strictly positive
a places v in the interior of the known cluster chamber of t. There is
no requirement on v for alpha with lambda(alpha)>0. A generic small
perturbation inside the chamber preserves every inequality in (1).

Because G is unimodular, define explicit leading-unit integer series

    R_i=product_j F_j^((G^(-1))_(j,i)),
    Phi_t(x_i)=x_i R_i,             Phi_t(y_j)=y_j.       (2)

The cluster monomial theorem identifies (2) with transport from chamber t
to the initial chamber: it takes x^(g_j) to the j-th cluster variable.
All powers in (2) are integer powers and are computed by finite binomial
recurrences on J.

## 3. The same sign factorization recovers the desired factor

For a generic Q near u, the segment from v to Q cannot cross a hyperplane
with lambda(alpha)<0, because (1) makes its value negative at both ends.
Thus transport from t to Q has only positive-lambda root increments.
Transport from Q to the initial positive chamber has only negative-lambda
increments. Their product is Phi_t.

Consequently, the finite matrix of Phi_t factors as A_minus A_plus with
the very same sign supports as in the main theorem. The integer residual
recurrence uniquely computes A_minus. Its inverse is the desired extractor
for u. No additional wall information is required.

One may use a different seed t and a different finite certificate (1) for
each target coefficient. Any valid choice gives the same extracted theta
coefficient. A single global negative frame supplies all these certificates
simultaneously by taking v in the negative orthant.

## 4. What this adds

This theorem strictly weakens the *input condition* required by the matrix
algorithm: a particular finite prefix can be certified without a global
C=-P word. The certificate is ordinary mutation data and finite linear
inequalities. The algorithm can enumerate words and test those inequalities,
but **no universal termination theorem for that enumeration is asserted**.

The unresolved general question is whether the required separating seeds
exist, or can be replaced by another finite ordinary-exchange construction,
for every finite theta element in classes without a negative frame. A proof
of that assertion is not supplied here. The formal total transport should
not be silently treated as known merely because it exists abstractly.

This route continues the same general coefficient mechanism; it does not
replace the principal problem by a collection of special-case formulas.
