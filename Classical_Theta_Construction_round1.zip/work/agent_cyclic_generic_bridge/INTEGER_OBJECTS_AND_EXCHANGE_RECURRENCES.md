# The finite integer objects, including computation of the input frame

This appendix expands every operation in
NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md into finite integer recurrences.
It supplies no additional oracle or geometric data. All graph/packet weights
below may have either sign.

## 1. Ordinary exchange itself is a finite integer recurrence

Track the principal extended exchange matrix E_t=(B_t;C_t), F-polynomials
F_1,...,F_n with F_i(0)=1, and initial-coordinate g-columns g_i. Initially
E=(B;I), F_i=1 and g_i=e_i. At a mutation k form

    N_k(z)=z^[C_t[:,k]]_+ product_j F_j(z)^[B_t[j,k]]_+
           +z^[-C_t[:,k]]_+ product_j F_j(z)^[-B_t[j,k]]_+.

The new polynomial satisfies

    F_k F'_k=N_k.

Let e_i=deg_(z_i)N_k-deg_(z_i)F_k. Ordinary F-polynomial Laurentness says
F'_k is a polynomial. Degree additivity in an integral polynomial ring
therefore gives its complete finite box 0<=p<=e. Its coefficients are
computed by the integer triangular recurrence

    F'_k[p]=N_k[p]-sum_(0<r<=p) F_k[r] F'_k[p-r].         (A)

Only smaller root degrees occur on the right. The initial constant is1.
The complete product identity F_k F'_k=N_k can be checked afterwards;
it is not enough to verify a truncated remainder. This is an alternative
to a black-box polynomial-division routine, using only addition and
multiplication of integers. The g-column recurrence is

    g'_k=-g_k+sum_j [B_t[j,k]]_+ g_j-B [C_t[:,k]]_+,

with the other columns unchanged. Matrix mutation is its usual explicit
integer formula. At the end of the supplied word the algorithm verifies
the permutation of negative unit g-columns and records the H_i=F_i.

Equation(A) can itself be unrolled as a finite signed sum over chains of
nonzero root packets. Thus even the frame polynomials needed by the main
construction are given by finite integer recurrences.

## 2. Entries of the total-substitution matrix are packet sums

Write H_i=1+V_i, where V_i has no constant term. For any integer m,

    H_i^m = sum_(r=0)^K binom(m,r) V_i^r  mod degree>K.

For m>=0 this is an ordinary finite choice of slots. For m=-ell<0,

    binom(-ell,r)=(-1)^r binom(ell+r-1,r).

The nonnegative number binom(ell+r-1,r) counts weak distributions of r
ordered packet positions among ell compartments. Each monomial of V_i
is a packet carrying its root vector and positive integer weight from H_i.
Choose r packets, multiply their weights and the displayed integer sign,
and retain choices with the required total root vector. Products over i
then give precisely C_(p,q) of the main theorem. No coefficient of theta
is used to define a packet or its weight.

## 3. Sign factorization is a recursive finite graph operation

The index set is the finite root box. For each interval q<p, compute the
residual

    R_(p,q)=C_(p,q)-sum_(q<r<p) A_minus(p,r) A_plus(r,q).

This removes all two-stage paths whose first interval has positive lambda
and whose second interval has negative lambda (matrix composition uses
column-vector actions). Place the residual on the negative or positive
side according to the sign of lambda(p-q). Every recursive subinterval
has smaller total degree, so this describes a finite family of decorated
binary trees if fully expanded. Each internal subtraction changes its
sign. The sign depends only on an explicitly computed integer dot product.

This is not an instruction to look for a wall at the root p-q. Every
interval is processed, including intervals corresponding to no wall.
It is a factorization of one finite integer matrix, and zero residuals
simply contribute weight0.

## 4. Inverse chains and final paths

The inverse T=(A_minus)^(-1) is the finite geometric series

    T=I-(A_minus-I)+(A_minus-I)^2-... .

Its entry from q to p is the signed sum over strict interval chains from
q to p, with products of A_minus weights. There are at most |p-q| nontrivial
steps, because each raises root degree.

For each target p choose its explicit u_p and hence its T^(u_p). Make a
single final DAG whose edge q->p has integer weight -T^(u_p)_(p,q).
The target coefficient is the sum of products of edge weights over all
paths from0 to p. Grouping paths by their last edge proves the recurrence.

Thus the final objects can be described at any of three equivalent levels:
finite integer matrices, recursively decorated packet chains, or paths in
a finite integer-weighted DAG. None takes an already constructed theta
function, scattering diagram, wall factor, or representation as input.

## Exact claim

The construction is finite and integer-valued before the comparison theorem
is invoked. The comparison theorem proves its output is the classical theta
polynomial, which in particular proves the final signed sum is nonnegative.
It does not provide a local sign-reversing involution, a polynomial runtime
bound, or a positive-cardinality perfect-matching model. Those stronger
properties are separate questions.
