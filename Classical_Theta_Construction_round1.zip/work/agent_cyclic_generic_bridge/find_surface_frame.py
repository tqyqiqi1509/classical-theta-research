import sys,random,json,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_negative_frame'))
from negative_frame import mutate_matrix,principal_extension,negative_permutation
n=6;edges=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)];B=[[0]*n for _ in range(n)]
for face in [(0,1,2),(0,3,1),(0,2,3),(1,3,2)]:
 ids=[edges.index(tuple(sorted((face[i],face[(i+1)%3])))) for i in range(3)]
 for i in range(3):a,b=ids[i],ids[(i+1)%3];B[a][b]+=1;B[b][a]-=1
rng=random.Random(20261113);tic=time.time();best=0
for trial in range(30000):
 E=principal_extension(B);word=[]
 for step in range(40):
  green=[k for k in range(n) if all(E[n+i][k]>=0 for i in range(n))]
  if not green:
   try:P=negative_permutation(E[n:])
   except Exception:break
   out={'surface':'oriented tetrahedron triangulation of sphere with four punctures','edges':edges,'B':B,'word':word,'permutation':P,'terminal_C':E[n:],'trials':trial+1,'seconds':time.time()-tic}
   Path(__file__).with_name('four_punctured_sphere_frame.json').write_text(json.dumps(out,indent=2));print(json.dumps(out));sys.exit()
  # prefer smaller total positive column and avoid large degree drift
  costs=[sum(E[n+i][k] for i in range(n)) for k in green]
  weights=[1/(c**rng.choice([0,1,2])) for c in costs]
  k=rng.choices(green,weights=weights)[0];word.append(k);E=mutate_matrix(E,k)
  if max(abs(x) for row in E for x in row)>1000:break
print({'no_frame_found':True,'B':B,'seconds':time.time()-tic})
