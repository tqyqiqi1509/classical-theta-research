# Arbitrary-size block foldings of negative-frame covers

2026-11-13 10:00 UTC. Extension of the proved integer-chain construction.
The negative-chamber carrier gate and arbitrary-size lattice normalization
have passed independent root and valued-branch audits. This branch also
checked the monomial map and the initial ordinary exchange normalization. The key comparison input is Yan Zhou,
SIGMA16(2020),013, Section3.3, especially Proposition3.4, Lemma3.5, and
Equation(3.2) on printed page20. No 2026 result is used.

Primary source: https://sigma-journal.com/2020/013/sigma20-013.pdf
arXiv: https://arxiv.org/abs/1901.04166

## 1. An entirely finite combinatorial input class

Supply a skew-symmetric integer cover exchange matrix Btilde, together
with a partition of its vertices into orbits O_1,...,O_n of arbitrary
positive sizes r_1,...,r_n. Require the strong block-constant condition

    Btilde[i,j]=b[a,b]  for every i in O_a,j in O_b,       (1)

where b is skew-symmetric. In particular all entries inside an orbit
are0. This is stronger than merely having a quiver automorphism. The
product of symmetric groups on the orbits satisfies precisely Zhou's
independent-representative pairing condition(3.1).

Define the folded exchange matrix

    Bbar[a,b]=r_a b[a,b],
    L=lcm(r_1,...,r_n),       Dbar=diag(L/r_a).          (2)

Then Dbar Bbar=L b is skew-symmetric, so Bbar is an ordinary integral
skew-symmetrizable exchange matrix. Equal orbit sizes recover the
skew-symmetric case. The orbit sizes scale the **rows**, not the columns,
in this project's convention z_j=y_j x^(B e_j). Supply and verify an ordinary finite negative-frame
mutation word for Btilde, and compute its negative-frame polynomials

    Itilde_i=xtilde_i^(-1) Htilde_i(ztilde),
    ztilde_i=ytilde_i product_j xtilde_j^(Btilde[j,i]).    (3)

These computations are ordinary finite cluster exchanges on the cover.
No negative frame is required to exist for Bbar.

## 2. Fold the finite polynomials by relabeling

Let sigma be the monomial map

    sigma(xtilde_i)=X_a,   sigma(ytilde_i)=Y_a
    for i in O_a.

Then(1)--(2) give

    sigma(ztilde_i)=Z_a,
    Z_a=Y_a product_b X_b^(Bbar[b,a]).                   (4)

Choose a representative i in O_a and define

    Hbar_a(Z)=Htilde_i(ztilde_j -> Z_orbit(j)),
    Ibar_a=X_a^(-1) Hbar_a(Z).                          (5)

This is a finite relabeling of integer monomials, combining equal exponents
by addition. It introduces no denominators or fractional coefficients.
Orbit equivariance of the total map implies independence of the chosen
representative; the supplied data can also verify this polynomial equality
explicitly for all representatives.

## 3. The exact comparison statement and the carrier gate

The input needed from Zhou is not just that all theta functions are finite.
One needs the following two assertions from Section3.3.

First, its principal quotient lattice map(s*,q) sends each cover mutable
basis monomial to the folded mutable basis monomial. Here s*(e_i*) is
(e_a*)/r_a, which is an integral basis vector of the folded M-circ lattice.
The frozen map sends e_i to e_a. Consequently its monomial map is exactly
sigma in(4), using the standard folded mutable coordinates. Expressing
the descended p-star map in this basis yields exactly the row-scaled
exchange matrix(2). The symmetrizer Dbar in(2) is its integral
normalization. This can also be checked without lattice notation:
simultaneously mutating all cover vertices in O_a is permitted because
there are no internal arrows. Under sigma every such ordinary exchange
has exponent sum_(j in O_b)Btilde[j,i]=r_b b[b,a] on X_b, precisely
Bbar[b,a]. Thus both the root monomials and the initial exchange relation
calibrate the same row convention. This initial check does not assume
that an entire negative-frame word is orbit-adapted; no such condition is
required by the invariant-total-map comparison theorem.

Second, Proposition3.4 and Lemma3.5 identify the descended total negative
to positive transport with the folded cluster total transport. The source
map is rational because it comes from a supplied negative cluster frame.
The proposition is therefore applied with all its rationality hypotheses.
Equation(3.2) says precisely that this transport commutes with sigma.

Printed page20 then explicitly takes a negative-chamber label(m,0) and a
point Q0 in the negative chamber and writes

    theta_(m,0),Q0 = z^(m,0),
    theta_(m,0),Q = p_(-,+)(z^(m,0)).                   (6)

The second equality is attributed there to GHKK Theorem3.5. Thus it is
(6), followed by the commuting diagram(3.2), that identifies

    Ibar_a=theta_(-e_a,0),                              (7)

and not an inference from the mere finiteness of theta functions.
Equation(7) is the essential carrier gate. It must be retained explicitly
when presenting this extension. The valued branch independently checked
Zhou's printed argument and also gave a direct negative-orthant version
of the GHKK Proposition3.8 bend argument: accumulated positive bend charges
have nonnegative pairing with the path after its first bend, whereas their
pairing with a strictly negative endpoint is negative. This rules out any
bent contribution for a nonpositive initial label in that chamber. Thus
(6) does not rest merely on an unverified chamber-identification assertion.

The same diagram gives the folded total substitution

    Phibar(X_a)=Ibar_a^(-1)=X_a Hbar_a(Z)^(-1),
    Phibar(Y_a)=Y_a.                                   (8)

The source negative-frame computation and the finite relabeling in(5)
therefore supply the folded total substitution without constructing a
folded wall or broken line.

## 4. Apply the same finite chain algorithm

For any folded label g, form the finite positive theta product

    M_g=X^[g]_+ product_a Ibar_a^[-g_a]_+
       =X^g product_a Hbar_a(Z)^[-g_a]_+.

Using(7), theta positivity and the same principal-homogeneity argument as
in the negative-frame theorem imply that this carrier contains theta_g
coefficientwise. This is allowed to be a product of the known theta
functions(7), even though they may not be ordinary cluster variables.
The finite polynomials in(5) are computed solely on the cover; they are
not unknown folded theta functions used as coefficient oracles.

Set

    d_b=sum_a [-g_a]_+ deg_(Z_b)Hbar_a,
    J=[0,d],
    C[p,q]=[Z^(p-q)] product_a Hbar_a(Z)^(-(g+Bbar q)_a).

Every coefficient is computed by finite integer binomial recurrences.
Use I_p and the chain weights in HALFSPACE_CHAIN_FORMULA.md, with B=Bbar
and D=Dbar. The resulting finite signed path sum is the complete classical
principal theta function of the folded seed.

## 5. A genuinely new input regime

This certificate class is not restricted to targets having a negative
cluster frame or a strictly negative product of their ordinary cluster
variables. The standard four-punctured-sphere cover supplied in this
project has orbits

    O_0={0,5}, O_1={1,4}, O_2={2,3}

and block-constant exchange entries. Its folded matrix is

    [[0,-2,2],[2,0,-2],[-2,2,0]],

the Markov exchange matrix. The explicit17-step negative word on the cover
has already been independently verified. The three folded H_a each have
7 monomials and coefficient sum9, and their equality for both choices of
orbit representative has been checked exactly; see
folded_markov_negative_polynomials.json.

The target really has no negative-product certificate: give each initial
X_i degree1 and each frozen Y_i degree0. Every Markov mutation replaces one
variable by a ratio whose numerator has degree2 and denominator degree1,
so all ordinary cluster variables have degree1. Since every initial Z_i
has degree0, every cluster g-vector has coordinate sum1. A positive product
of these vectors has positive coordinate sum and cannot have all its
coordinates negative. Thus the folding input class adds cases excluded
from the negative-product hypothesis by an elementary grading argument.

Zhou's paper proves the full
Fock--Goncharov theorem for the principal Markov variety (Theorem1.1,
refined in Theorem5.1/Corollary5.2), despite its separate negative and
positive cluster fans.

The current extension is a block-folding mechanism with arbitrary orbit
sizes, not a formula invented solely for this example. The example demonstrates that its input
regime goes beyond the negative-product certificate class.

## 6. Limits that must not be silently removed

The block-constant condition(1) is essential in the cited quotient theorem.
An arbitrary quiver automorphism is insufficient. The precise row-scaling
and Dbar in(2) are part of the certificate and cannot be replaced by an
unchecked folding convention. The core theorem in Sections1--6 requires a supplied finite negative
cluster frame, which makes the rationality hypothesis of Zhou's
Proposition3.4 automatic. Section7 separately proves the stronger
negative-product-cover case using the formal intertwining identity; it
does not replace the rationality hypothesis by an unsupported inference
from cover theta finiteness.

This note proves a finite algorithm for all principal theta functions in
the stated folded class once the cited comparison gate is accepted. A
claim that these span the whole upper cluster algebra requires its own
basis theorem. Zhou gives that theorem for the principal Markov example;
Theorem3.7 alone gives the full theta set and must not be misquoted as an
upper-basis theorem in every folded case. Coefficient-free specialization
also requires its own statement: Zhou's Theorem1.3 explicitly distinguishes
the coefficient-free Markov upper ring from the full theta span.

## 7. Independently audited enhancement: a negative-product cover suffices

The cover hypothesis can be weakened from a common negative cluster frame
to a finite negative-product certificate as in
NEGATIVE_PRODUCT_INTEGER_THETA_THEOREM.md. This enhancement uses the formal
intertwining identity proved inside Zhou's Proposition3.4, equation(3.3),
rather than its stronger rational-function-field conclusion. The valued
branch independently read that proof and confirmed this distinction.

First use the cover's finite integer algorithm to compute the finitely many
cover functions theta_(-e_i,0). They are finite positive polynomials with
known leading monomials. The negative-orthant monomial lemma identifies
them with the cover total map applied to xtilde_i^(-1). Hence no rationality
of the inverse total map needs to be asserted.

Here is the formal identity directly. Let O(n) be an orbit of a positive
cover charge n. The invariant Lie operator formed by summing over O(n)
acts on a cover monomial of mutable exponent m by

    sum_(n' in O(n)) ztilde^(n') (n' dot m).

After sigma, this becomes

    |O(n)| Z^(q n) sum_a (q n)_a (sigma m)_a/r_a.        (9)

Indeed orbit symmetry makes the average n'_i over i in O_a equal to
(q n)_a/r_a. The right side is exactly the action of the quotient Lie
operator in the folded M-circ basis f_a/r_a. The equality holds on all
monomials; it therefore holds for products and exponentials after positive
root completion. The map q preserves total nonnegative root degree, so
sigma is continuous for this completion. This is the formal equation(3.3).
Rationality is needed only for the additional birational conclusion at the
end of the cited proposition, which is not used here.

The invariant total element thus descends formally, and its values on the
negative mutable generators are the finite polynomials obtained by sigma
from the already computed cover theta functions. The negative-orthant
monomial lemma identifies them with the folded theta_(-e_a,0). Sections4--6
then apply unchanged. Every algorithmic operation is a finite cover graph
computation, monomial relabeling, or a folded finite integer chain.

Consequently arbitrary-size block-constant foldings of skew-symmetric
covers with supplied negative-product certificates are included. This is
an independently justified extension, not an inference that rationality
follows merely from finiteness of all theta functions. A claim of a full
upper basis still requires the separate hypothesis discussed in Section6.
