# Third independent audit of the finite integer reconstruction

Auditor branch: positive_inventory_exchange. 2026-11-13, 09:13 UTC.

## Conclusion and scope

I independently checked the algebraic and finite-combinatorial argument in
../agent_asymptotic_detector/GENERIC_LARGE_LABEL_PREFIX_RIGIDITY.md and
../agent_asymptotic_detector/FINITE_INTEGER_THETA_RECONSTRUCTION.md.
**No fatal gap was found in the proposed reconstruction, under its explicitly
listed comparison inputs.** The ratio direction, inversion direction,
generic-direction construction, inactive-capacity reduction, and last-bend
coefficient extraction are consistent.

This is an arbitrary-rank construction for **acyclic, skew-symmetric,
classical cluster algebras with principal coefficients**, and hence for an
input supplied with mutation transport to such a seed. It is a finite
**signed integer** construction. It is not currently a cancellation-free
nonnegative matching formula, an unconditional all-skew-symmetrizable theorem,
or a construction for genuinely mutation-cyclic classes.

This audit checks the new argument independently. It does not claim to repeat
the full primary-source audit of every earlier input: finite theta expansion,
valuative independence, the full-rank acyclic upper-bound theorem, and the
project's capacity/freezing statements remain the explicit inputs audited
elsewhere by the team. Their precise roles are separated below.

## 1. Generic-prefix rigidity

1. The matrices have the stated orientations. With U=I-A^T and
   B=U^T-U, set V=U^(-T)B and L=U^(-T)U=I-V. Then
   L^T U=U^T and L^T U L=U, by direct multiplication.

2. For a bounded root r, g+B r=-U^T(d-Vr), so the canonical capacity is
   c_r=d-Vr once all its entries are positive. Its far root-coordinate
   corner is r+c_r=d+Lr.

3. The quadratic evaluations are correct:

       Q_d(r)=d^T U r-r^T U r,
       Q_d(d+Lr)=-d^T U r-r^T U r.

4. Valuative independence is used only to put each signed theta summand's
   Newton polytope inside the **box** supporting the difference. It is not
   applied to the nonconvex region Q>=0. This avoids the earlier potential
   convexity error.

5. If a summand's far corner is d-e, its capacity decomposition gives
   U r=-v-U^T e and r=-U^(-1)v-U^(-1)U^T e. Since U^(-1)>=0 and v>=0,
   this bounds r by T e, T=-U^(-1)U^T. Therefore every summand that could
   contribute near a fixed-root far corner has a uniformly bounded root.
   The bound is independent of the unknown number of signed summands.

6. The negative-slope near-root induction is triangular: every contributor
   r<=q other than q either already vanishes or has lambda(q-r)<0, so its
   relevant coefficient vanishes by Q. No unknown sign is assumed.

7. For a positive-slope correction, maximizing lambda among the bounded
   near-far contributors and then choosing a componentwise maximal far
   corner handles all equal-lambda ties. For a smaller-lambda contributor,
   t=L(r-r_*)>=0 has

       Q_(c_r)(c_r-t)=N(lambda(r)-lambda(r_*))+O(1)<0.

   I checked the sign using L^T U=U^T. The remaining summand is its
   nonzero coefficient times the far-corner coefficient one, giving the
   claimed contradiction.

8. The displayed generous N_0 bounds the finitely many capacity and
   quadratic constant terms. Positive integral a has a_i>=1, and every
   nonzero lambda is an integer of absolute value at least one. Thus the
   threshold is uniform even though the coefficients of the candidate
   Laurent element may have either sign.

## 2. Capacity chambers and the large finite system

9. On a fixed active set, every chamber test has normal

       q_i=e_i+sum_(j<i, active j) A_ij q_j.

   These are nonzero nonnegative integer path-count vectors. Removing the
   active-set restriction only adds paths, so q_i is componentwise bounded
   by row i of U^(-T). The stated C_B bounds their l1 norms.

10. For M=1+max(K,C_B), u=M m+ones is strict for all relevant normals.
    Indeed q^T u=M q^T m+|q|. If q^T m is nonzero, M>|q| preserves its
    sign; if it is zero, q^T u=|q|>0. This handles targets on chamber walls
    without assuming generic target labels.

11. N>C_B preserves the active set of Nu+h for h=0,e_i. Inside this set,
    the induced active matrix gives the exact shift
    s_h=-U_I^(-T)h_I. If e_i is inactive, h_I=0 and the active capacity
    is unchanged. The outside variables are frozen units, and the active
    monomials are exactly the original z_i restricted to i in I.

12. The large-array search is truly finite: a finite box, finite integral
    coefficient bounds, origin one, Q zeros, and integer divisibility
    equations. The equation

       sum_(t>=r) (-1)^(t-r) binom(t,r) A_t=0

    is the r-th divided derivative at -1, so the displayed equations are
    equivalent to the required power of (1+Z) dividing the slice.
    True theta gives existence. Prefix rigidity and acyclic upper-bound
    equality give equality of every feasible prefix. No actual theta
    coefficient is queried in the construction.

    Exact rational elimination is a practical implementation of the same
    uniquely determined prefix. If integer-only arithmetic is desired,
    one can either keep the bounded-array definition or use a deterministic
    nonzero minor and Cramer's rule: the numerator and denominator are
    signed finite permutation sums, and division is exact for a uniquely
    determined prefix coordinate because an integral theta solution exists.
    Fraction-free Bareiss elimination realizes these operations.

## 3. Ratio and substitution direction

13. All large probes use the same N. Through degree K, the comparison
    endpoint u sees theta_(Nu+h) as the monomial x^(Nu+h). Therefore

       iota_u(theta_(Nu+e_i)/theta_(Nu))=x_i,

    while the initial expression is x_i R_i. Thus psi(x_i)=x_i R_i is
    transport **from the u chart to the initial chart**, and tau=psi^(-1)
    is transport in the reverse direction. The proposed C and T=C^(-1)
    have this correct order; using C instead of T in the final recurrence
    would be incorrect.

14. Frozen y_j is fixed because every wall normal has zero frozen
    component. Therefore

       psi(z_j)=z_j product_i R_i^(B_ij),
       psi(x^g z^q)=x^g z^q product_i R_i^(g_i+(Bq)_i).

    There is no omitted transpose, sign, or frozen factor in the matrix
    entry C_(p,q).

15. The substitutions are leading-unit and increase root degree. Their
    inverses have the same filtration property. The target box is
    componentwise downward closed: an occupancy that leaves it cannot
    return by adding nonnegative roots. Hence restriction to the box and
    unitriangular matrix inversion do not discard a later contribution.

16. As an independent sign check, in rank one B=0 and g=-d<0, the ratio
    is R=(1+y)^(-1), so psi(x)=x/(1+y), tau(x)=x(1+y). The proposed
    recurrence recovers F=(1+y)^d. This is only a normalization check;
    no rank-one argument is substituted for the general proof.

## 4. The last-bend argument and a clarification to insert

17. The final-ray argument is correct, including zero mutable exponent.
    If the terminal mutable exponent is m, a final segment traced backward
    has mutable part Q+t m, t>=0. If q^T m is zero or has the same sign as
    q^T Q, this ray cannot meet q^T x=0. Equivalently, a last bend would
    force q^T Q=-t q^T m for some t>0, contradicting those signs.

18. The explicit large-probe bound is sufficient. For |q|,|r|<=K and
    h=0,e_i,

       |q^T(h+B r)|<=K(1+K max|B_ij|).

    Since |q^T u|>=1, the chosen N makes every possible exponent
    Nu+h+B r lie in u's same finite-normal sign cell. Higher-degree
    terms cannot influence the retained jet.

19. For the target occupancy p, u_p uses m=g+Bp. The last-bend lemma
    annihilates the x^g z^p coefficient of theta_g in that chart whenever
    p!=0. Even if Bp=0, the full exponent (g+Bp,p) differs from (g,0),
    so it cannot be the unbent term. This frozen-exponent distinction is
    essential and is correctly included in the draft.

20. **Recommended clarification:** take each wall's normal alpha to be
    primitive. A nontrivial contribution from that wall increases the
    root exponent by k alpha for an integer k>=1. Therefore a bend
    contributing to total root degree<=K necessarily has |alpha|<=K.
    This explicitly justifies why the finite arrangement of *all* positive
    normals of degree<=K contains every relevant wall. It does not require
    computing which of those hyperplanes actually carry walls.

## 5. A direct finite weighted graph interpretation

For the target box D=[0,d], order vertices by total root degree. For each
strict componentwise pair q<p define an integer directed edge weight

    w(p,q)=-T^(u_p,g)_(p,q).

The final recurrence becomes

    a_0=1,             a_p=sum_(q<p) w(p,q) a_q.

Hence a_p is the sum, over all directed paths from0 to p, of the products
of their integer edge weights. The graph is finite and acyclic. Its edge
weights themselves are finite signed chain sums from the inverse of C,
whose entries come from the displayed integer binomial substitutions.

This gives the requested type of explicit integer-weighted finite
combinatorial object, with the qualification that weights can be negative.
The equality with theta proves final nonnegativity; it does not supply a
cancellation-free object count. No wall, broken line, representation, or
theta value occurs as an input to the graph or its weights.

## Remaining boundaries

- The large-jet step may be computationally enormous. Finite termination is
  proved; polynomial-time complexity or practical efficiency is not.
- The geometric comparison in the correctness proof is stated openly.
  The algorithm itself is independently specified by integer data.
- Cyclic skew inputs and all-D inputs require new comparison or rigidity
  arguments; formal symmetrizer algebra alone does not provide them.
- A positive matching/independent-set model without signed cancellation is
  a further problem, not a consequence silently included in this theorem.
