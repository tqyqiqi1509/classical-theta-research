"""Charged graph-allocation upper caps, using genuine rank-two support only.

The finite integer construction is independent of theta computation. Its
comparison theorem currently uses the skew-symmetric positive quantum lift.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_creation_caps'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_packet_propagation'))
from block_upper_caps import block_polynomial, graph_partitions, two_pair_partitions
from charged_caps import charged_standard, convolution, topological_order

def capacity_label(B,e):
    return tuple(-e[i]+sum(max(-B[i][j],0)*e[j] for j in range(len(e))) for i in range(len(e)))

def phase(B,e,p,f,q,D=None):
    n=len(e);D=D or (1,)*n
    ge=capacity_label(B,e);gf=capacity_label(B,f)
    return (-sum(ge[i]*D[i]*q[i] for i in range(n))
            +sum(p[i]*D[i]*gf[i] for i in range(n))
            +sum(p[i]*D[i]*B[i][j]*q[j] for i in range(n) for j in range(n)))

def symmetric_envelope(m):
    return {k:min(v,m.get(-k,0)) for k,v in m.items() if min(v,m.get(-k,0))}

def lefschetz_budget_envelope(u,a,exact_budget_limit=1000):
    """Maximal individual charge counts among integral Lefschetz inventories.

    Uses only the known classical total a and finite upper inventory u. The
    justification for a true theta block uses DM Theorem 1.5 (acyclic only).
    A length-(k+1) chain is needed for every occurrence at absolute charge k.
    For large a the inexpensive chain-cost upper bound remains valid.
    """
    parity=next(iter(u))%2
    assert all(k%2==parity for k in u)
    w={k:min(v,a//(abs(k)+1)) for k,v in u.items()}
    w={k:v for k,v in w.items() if v}
    if a>exact_budget_limit:return w
    positive=tuple(range(parity,max(abs(k) for k in w)+1,2))
    caps=tuple(w.get(k,0) for k in positive)
    @lru_cache(None)
    def feasible(r,count,budget):
        if r<0:return budget==0
        length=positive[r]+1
        limit=min(caps[r]-count,budget//length)
        for nr in range(limit+1):
            if feasible(r-1,count+nr,budget-length*nr):return True
        return False
    assert feasible(len(caps)-1,0,a),(u,a,'no Lefschetz inventory')
    maximum=[0]*len(caps);seen=set()
    def collect(r,count,budget):
        if r<0 or (r,count,budget) in seen:return
        seen.add((r,count,budget));length=positive[r]+1
        for nr in range(min(caps[r]-count,budget//length)+1):
            if feasible(r-1,count+nr,budget-length*nr):
                maximum[r]=max(maximum[r],count+nr)
                collect(r-1,count+nr,budget-length*nr)
    collect(len(caps)-1,0,a)
    out={}
    for k,v in zip(positive,maximum):
        if v:out[k]=v;out[-k]=v
    return out

@lru_cache(None)
def block_envelope(B,e,D=None,integer_budget=True,lefschetz=True):
    """Safe graded majorant; all inputs are finite integer rank-two objects.

    Classical LLZ coefficients constrain support and total charge budget.
    The returned coefficients are independent upper bounds, so their sum may
    exceed the classical LLZ coefficient. This is intentional and necessary.
    """
    n=len(e);D=D or (1,)*n
    F=block_polynomial(B,e);out={}
    for p,a in F.items():
        m,_=charged_standard(B,e,p,D)
        u=symmetric_envelope(m)
        if integer_budget:
            for k in list(u):
                if k:u[k]=min(u[k],a//2)
                else:
                    u[k]=min(u[k],a)
                    u[k]-=(u[k]-a)%2
                if not u[k]:del u[k]
            assert all(v>0 for v in u.values()),(e,p,a,u)
        if lefschetz:u=lefschetz_budget_envelope(u,a)
        assert sum(u.values())>=a,(e,p,a,u)
        out[p]=u
    return out

def graded_product(B,blocks,target=None,D=None,integer_budget=True,lefschetz=True):
    """Multiply the block majorants with exact quantum-torus integer phase.

    If target is given, occupancy states exceeding it are discarded; this is
    safe because all occupancies are nonnegative and we only need its row.
    """
    B=tuple(map(tuple,B));n=len(B);D=tuple(D or (1,)*n)
    z=(0,)*n;curr={z:{0:1}};e=z
    for ff in blocks:
        f=tuple(ff);G=block_envelope(B,f,D,integer_budget,lefschetz)
        new={}
        for p,fp in curr.items():
            for q,gq in G.items():
                r=tuple(a+b for a,b in zip(p,q))
                if target is not None and any(a>b for a,b in zip(r,target)):continue
                shift=phase(B,e,p,f,q,D)
                row=new.setdefault(r,Counter())
                for k,a in fp.items():
                    for l,b in gq.items():row[k+l+shift]+=a*b
        curr={p:dict(row) for p,row in new.items()}
        e=tuple(a+b for a,b in zip(e,f))
    return curr

def graph_cap_at(B,d,p,max_allocations=200000,integer_budget=True,all_orders=False,lefschetz=True):
    """Finite minimum over edge allocations (and optionally factor orders).

    Factor order is relevant before bar-overlap. All orders are valid upper
    products; using only the canonical sorted order is still a valid cap.
    """
    from itertools import permutations
    B=tuple(map(tuple,B));d=tuple(d);p=tuple(p)
    raw,_=charged_standard(B,d,p);best=sum(symmetric_envelope(raw).values())
    witness={'type':'standard','cap':best};count=0
    if not best:return best,witness,count
    for blocks in graph_partitions(B,d,max_allocations):
        orders=permutations(blocks) if all_orders else (blocks,)
        for ordered in orders:
            row=graded_product(B,ordered,p,integer_budget=integer_budget,lefschetz=lefschetz).get(p,{})
            cap=sum(symmetric_envelope(row).values());count+=1
            if cap<best:
                best=cap;witness={'type':'graph','blocks':ordered,'cap':best,'graded_row':sorted(row.items())}
            if not best:return best,witness,count
    return best,witness,count

if __name__=='__main__':
    import json,time
    B=tuple(tuple((j>i)-(j<i) for j in range(4)) for i in range(4))
    d=(0,2,2,2);p=(0,1,1,1);tic=time.time()
    answer=graph_cap_at(B,d,p,all_orders=True)
    out={'B':B,'d':d,'p':p,'cap':answer[0],'witness':answer[1],'products':answer[2],'seconds':time.time()-tic}
    Path(__file__).with_name('charged_graph_cycle_inventory.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out))
