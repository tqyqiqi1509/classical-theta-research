import sys,json
from pathlib import Path
from collections import defaultdict,Counter
from itertools import product
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_source_surgery'))
from common_slot_flows import PairFlows

out=[]
for a,b,w in product(range(1,7),range(1,7),range(1,4)):
    P=PairFlows(a,b,w,w);poly=defaultdict(Counter)
    for hm,vm in product(range(1<<a),range(1<<b)):
        if not P.compatible(hm,vm):continue
        p,q=hm.bit_count(),vm.bit_count()
        charge=sum(a-1-2*t for t in range(a) if hm>>t&1)+sum(b-1-2*t for t in range(b) if vm>>t&1)-w*(a-p)*q
        poly[p,q][charge]+=1
    bad=[{'p':p,'layers':sorted(c.items())} for p,c in poly.items() if any(c[-k]!=v for k,v in list(c.items()))]
    if bad:
        out.append({'d':[a,b],'w':w,'bad':bad[:3]})
        if len(out)>=5:break
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'reject standard-slot inherited charge unless no failures','failures':out},indent=2))
print(out)
