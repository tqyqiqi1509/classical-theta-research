from pathlib import Path
import sys,json,time
HERE=Path(__file__).resolve().parent;WORK=HERE.parent
sys.path[:0]=[str(WORK/'agent_creation_caps'),str(HERE)]
from cap_batch import run_case,atomic
from charged_caps import charged_caps
p=WORK/'agent_creation_caps/fundamental_input_6.json';case=json.loads(p.read_text())
U=charged_caps(case['B'],case['d'],case['carrier']['lattice_points'])
for z in case['precomputed_graph_caps']:z['a']=min(z['a'],U[tuple(z['p'])])
case['construction']='graph caps intersected with proved symmetric-charge matching cap'
print('start',flush=True)
r=run_case(case,mode='graph_pair')
atomic(HERE/'charged_k4_lp_result.json',r)
print({k:r.get(k) for k in ['status','mass','integral','a_least_proved','constraint_rows','seconds']},flush=True)
if r.get('coordinate_failure'):print({k:v for k,v in r['coordinate_failure'].items() if k!='other_F'},flush=True)
