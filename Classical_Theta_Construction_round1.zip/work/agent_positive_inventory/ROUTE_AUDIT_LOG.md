# Route and primary-literature audit log

## 08:49--09:13 UTC, 2026-11-13

- Read the two-sided Pieri, capacity-product, and creation-cap handoffs before
  beginning. Did not reuse the invalid neighbor-row constant33 or the false
  fundamental-region shortcut.
- Constructed the charged Boolean-slot DP. Verified phase/normalization with
  the parent and asymptotic branch. Scope of comparison: classical skew case,
  acyclic seed; all-D remains formal algebra only.
- Computed the K4 standard charged cap;43 additional zeros; exact least1829
  in the amended graph/pair cone. Theta identification is explicitly pending.
- Direct inherited charge on compatible pairs failed already at(1,3), weight2.
  Kept the counterexample as a guard against a false graph interpretation.
- Implemented graded rank-two graph-product majorants, all exact integer data.
  The240 ordered allocations at the first true periodic freedom still give1.
  The direction is retained as an upper-resource tool, not promoted to a selector.
- Reviewed literature interfaces: Bergman diamond confluence is not applicable
  merely because matrices M are triangular. Actual terminating reductions and
  critical-pair resolution must be supplied. The author's errata page was read:
  https://math.berkeley.edu/~gbergman/papers/updates/diamond.html . No theorem
  conclusion is invoked in the construction.
- Lê--Thurston--Yu1908.05775: read §§2.5,4,5. Useful: transverse independent
  output detector; lowest quantum-charge detector. Not transferable without
  no-collision proof. Corrected loose initial wording about band positivity;
  their broad negative-Euler-characteristic band statement was conjectural.
- Davison--Mandel1910.12915 / Inventiones2021: inspected primary published PDF
  https://d-nb.info/1243743123/34 . Theorem1.5 and §4.9 prove Lefschetz type for
  acyclic seeds. General cyclic Lefschetz remains conjectural there; pL is
  available generally. Added only the audited acyclic chain-budget bound.
-2026 search hit arXiv2611.00991, *Quantum Generalized Cluster Algebras from
  Scattering Diagrams: Positivity and Mutation*. Not used: outside the present
  classical ordinary-cluster scope, and no independent full proof audit done.
  Its search listing is retained as a lead only, not positive evidence.

No Li--Pan conclusion is used. No new special family is claimed as a general
solution. The actual unresolved target remains a canonical coherent minimal
positive inventory or an independently proved finite recurrence selecting it.

## Main-route update, 09:13 UTC

The generic-prefix and ratio-transport construction supplied a different
general mechanism. This branch independently audited both proof drafts;
details are in INDEPENDENT_RECONSTRUCTION_AUDIT.md. No fatal gap was found
under the stated comparison inputs. The finite signed integer recurrence
now provides the acyclic skew theta construction, conditional only on those
published/project theorems explicitly identified in the draft, rather than
on an unproved confluence or positive-inventory selector. A cancellation-free
matching formula and the all-D/cyclic extensions remain separate goals.

The exact Lefschetz-chain budget check completed:486 rank-two blocks,
6188 nonzero coefficients,239 strict refinements removing2318 graded slots.
See ranktwo_lefschetz_budget_audit.json. No additional two-edge refinement
was found for the five residual K4 parameters; charged_twoedge_k4.json records
324 ordered products per parameter.
