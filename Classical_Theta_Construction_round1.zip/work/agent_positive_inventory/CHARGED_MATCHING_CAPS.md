# Charged matching inventories and a graded graph refinement

Research branch: positive_inventory_exchange. 2026-11-13, starting 08:49 UTC.

## 1. The proved integer upper inventory

Let B be skew-symmetric and acyclic, ordered so B_ij>=0 for i<j. Write
A=[-B]_+, g_d=-d+Ad. At vertex i, put d_i labelled Boolean slots t=0,...,d_i-1.
For occupancy p_i, choose p_i slots. Give slot t the integer charge
d_i-1-2t. For the complete selection, subtract

    R_d(p)=sum_(i<j) B_ij(d_i-p_i)p_j.

Let m_(d,p,k) count selections of total charge k. Define

    U_d(p)=sum_k min(m_(d,p,k),m_(d,p,-k)).

This is the cardinality of a maximum symmetric inventory: keep every charge-zero
selection, and for each k>0 match as many charge-k selections as possible with
charge-minus-k selections. The bipartite matching graph between the two charge
classes is complete. Thus no matching oracle, theta coefficient, geometric
object, or scattering construction is required to compute U.

**Comparison theorem, skew-symmetric case.** The classical coefficient a_d(p)
of theta_(g_d) satisfies 0<=a_d(p)<=U_d(p).

The proof uses the positive quantum lift as an external comparison theorem,
not as the definition or an input oracle of the integer construction. In the
principal normalized torus use

    E=(B;I), Lambda=[[0,-I],[I,-B]], m_i=(-e_i+A e_i,0).

The ordered product M_d=product_i (x_i')^(d_i) has leading coefficient one,
since Lambda(m_i,m_j)=0. Its normalized coefficient at (g_d,0)+Ep is exactly

    v^(-R_d(p)) product_i [d_i choose p_i]_v.

The Boolean charge inventory is the elementary subset expansion of this
polynomial. Positive multiplication contains theta_(g_d) with coefficient one;
positivity and bar invariance of theta therefore bound its charge-k coefficient
by both m_(d,p,k) and m_(d,p,-k). Specialize v=1.

The full normalization proof and external theorem audit are in
../agent_asymptotic_detector/CLASSICAL_QUADRATIC_CAP_FROM_POSITIVE_LIFT.md.

If S=sum_i p_i(d_i-p_i) and Q=S-R, then Q<0 forces a_d(p)=0, while Q=0 gives
a_d(p)<=1. There is also a useful integer restriction: every charge has parity
Q, so **Q odd forces a_d(p) even**. Neither the bound nor parity is sufficient
to select the coefficient.

## 2. Exact integer dynamic programming

For each vertex, define G_(j,r,k) as the number of ways to choose r of its first
j slots with charge k. Start G_(0,0,0)=1 and use

    G_(j+1,r,k)=G_(j,r,k)+G_(j,r-1,k-(d_i-1-2j)).

Convolve the resulting charge lists over vertices, shift by -R, then take the
opposite-charge minimum. All coefficients and operations are nonnegative
integers. The implementation is charged_caps.py. Its scalar API is

    charged_cap(B,d,p,D=None)

and charged_caps(B,d,points=None,D=None,metadata=False) computes a finite family.
It accepts a nontrivial integral symmetrizer as an algebraic DP, with charge
D_i(d_i-1-2t) and interaction D_i B_ij. **The theta comparison has only been
audited for skew-symmetric B; accepting D in code does not prove all-D positivity.**

The function charged_standard skips its full polynomial when Q<0 because its
only intended consumers take the symmetric envelope. It should not be used as
a full raw standard-product coefficient oracle at such points.

## 3. Refined finite graph upper products

Partition d into blocks e supported on at most two vertices. The classical
F-polynomial of each block is computed by the genuine rank-two greedy recurrence.
Let a_e(p) be that known nonnegative integer. Start with the block's symmetric
charge envelope, set it to zero outside this exact classical support, and use
its classical total to bound individual graded coefficients:

    charge k!=0: c_k <= floor(a_e(p)/2),
    charge 0: c_0 <= a_e(p), with c_0 congruent a_e(p) modulo2.

These are independent componentwise upper bounds. Their sum need not equal the
known total a_e(p). Artificially reducing their sum to a_e(p) without tracking
all possible graded inventories would invalidate the upper bound.

The acyclic Lefschetz theorem gives a further safe integer refinement. A
Lefschetz chain reaching charge k contains at least |k|+1 objects. Hence

    c_k <= floor(a_e(p)/(|k|+1)).

The implementation goes further for moderate a: enumerate all nonnegative
integer chain multiplicities n_r, where a chain of highest charge r has length
r+1, subject to the known total and the previous charge caps. A finite knapsack
DP returns the largest feasible coefficient at each charge. For large totals
it uses only the inexpensive chain-cost bound. This is justified by
Davison--Mandel Theorem1.5 for acyclic seeds. The theorem is not assumed for
general cyclic seeds.

Now multiply these graded block majorants in any chosen block order. For
capacity e, occupancy p followed by capacity f, occupancy q, the exact phase is

    beta(e,p;f,q)= -g_e^T q + p^T g_f + p^T B q.

Indeed this equals Lambda((g_e,0)+Ep,(g_f,0)+Eq). The leading phase is zero,
because the leading exponents have no frozen components. Multiply charge
histograms with this integer shift. On the resulting total coefficient take
the symmetric envelope once more. This again bounds theta_(g_d), because the
product of the genuine block theta functions contains it with leading
structure coefficient one, and all coefficients are positive.

This construction remains a finite graph calculation. Edge allocations give
one block per edge; the entire family or any selected subfamily produces valid
caps. The code does not assume quantum theta equals quantum greedy. Only the
classical rank-two specialization is used to obtain support and total budgets.

Implementation: charged_graph_caps.py, with block_envelope, graded_product,
graph_cap_at. All orderings are valid; reverse order has the same final symmetric
cap, while other orders can in principle give additional bounds.

## 4. Main computations and what they establish

For the complete acyclic four-vertex unit-arrow matrix and d=(4,5,5,6), the old
graph carrier has173 points. The new standard charge bound deletes43 points.
The exact Laurent solution space dimension drops from47 to6. Intersecting the
old graph/pair cone with the new caps gives a coefficientwise least integral
point of mass1829, proved by exact rational dual certificates. This repairs the
old cone's failure to possess a coefficientwise least point.

Files: charged_k4_caps.json, charged_k4_lp_result.json. The latter is generated
by charged_lp.py. The Gaussian DP was checked for d<=12 and scales1,2,3:273
occupancy layers, checking binomial total, symmetry, and endpoint degree.

The refined graph budget was checked against486 rank-two blocks (arrow weight
1 through6, each capacity0 through8),6188 nonzero classical coefficients. The
known totals admit the required graded envelopes. These finite checks support
the implementation; the comparison is proved algebraically above.

**This does not identify the1829 point as theta.** The cap cone still contains
larger elements. A least candidate must still be shown to extend coherently or
to have nonnegative transition from theta before theta equality follows.

## 5. The surviving periodic resource and the actual next gap

The strict lower-Pieri branch identified all139 earlier layers, but at
d=(0,2,2,2) found a one-parameter genuine-lower system

    F=F_0+t z^(0,1,1,1), 0<=t<=1.

Its Q at the free occupancy is0. Every lower/creation condition, all graph caps,
and all13 proper capacity splits allow both integer values. The graded graph
refinement, including all240 ordered edge-allocation products and the exact
Lefschetz budget, still has cap1. See charged_graph_cycle_inventory.json.

This is precisely the surviving periodic inventory that needs a general
minimality/extension mechanism. In the corresponding one-variable loop
sector, the alternatives resemble z^2-2 and z^2-1. Positive basis conditions
alone should not be assumed to make all such alternatives disappear.

The finite charged inventory is therefore a genuine new upper resource system,
not yet the desired complete positive object model. Its role is to expose and
sharply constrain the remaining exchange problem.

## 6. A tested charge assignment that must not be reused

Assigning the standard Boolean-slot charges directly to the existing rank-two
compatible-pair subset is incorrect. At arrow weight2 and capacities(1,3), the
compatible-pair subset at occupancy(0,1) consists of one state with inherited
charge-2; a positive bar-invariant quantum coefficient of classical total1
would have to have charge0. The support/counterexample computation is in
slot_charge_pair_diagnostic.py and its JSON. This only rejects that inherited
charge labelling; it does not reject compatible pairs, the charge cap, or a
possible rematching construction.

## 7. Audited literature interface: transverse detectors

Lê--Thurston--Yu, *Lower and Upper Bounds for Positive Bases of Skein Algebras*,
arXiv:1908.05775; accepted2020, published IMRN2021. Primary author PDF:
https://letu.math.gatech.edu/Papers/positive%20basis%20of%20skein%20algebra_new.pdf

Their lower-bound proof uses a transverse probe b for which T_n(a)b contains
distinct extremal outputs b_n and b_-n, while T_i(a)b contributes to the distinct
outputs b_i and b_-i. Peripheral-sector terms cannot collide with these. Thus,
writing a proposed positive basis P_n=T_n+sum_i delta_i T_i, positivity of the
probe product separately detects delta_i>=0. This mechanism, not the surface
conclusion itself, is useful here: an isolated output could force nonnegative
transition to a minimal basis.

Their quantum upper-bound proof isolates the lowest charge of a family of
products. This is a finer detector than total support or mass. Neither proof
automatically transfers to arbitrary quivers; one must prove distinct output
and no-collision statements for the proposed probes.

The parent asymptotic branch's two-corner Euler identities are the current
candidate replacement for those transverse outputs. The remaining issue is
isolating a signed lower deformation from every other far-corner contributor.

The author's PDF explicitly presents band positivity for all surfaces of
negative Euler characteristic as a conjecture at that time. No claim that
their general band positivity was already proved is used here. Search-engine
publication timestamps that labelled this older PDF as2025 were discarded.
