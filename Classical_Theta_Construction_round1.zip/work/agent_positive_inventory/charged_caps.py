"""Finite integer charged-slot matching caps for classical theta comparisons.

The DP itself handles integral symmetrizers. Its theta comparison is currently
certified here only in the skew-symmetric case via positive quantum theta.
No theta coefficients are inputs.
"""
from collections import Counter
from functools import lru_cache
from itertools import product
from math import comb

@lru_cache(None)
def gaussian_layers(d, scale=1):
    """Tuple by occupancy p of ((charge,count),...) for labeled d Boolean slots."""
    if d<0 or scale<1: raise ValueError((d,scale))
    table=[Counter() for _ in range(d+1)];table[0][0]=1
    for t in range(d):
        wt=scale*(d-1-2*t)
        for p in range(t+1,0,-1):
            for k,m in table[p-1].items():table[p][k+wt]+=m
    return tuple(tuple(sorted(z.items())) for z in table)

def convolution(a,b):
    z=Counter()
    for k,x in a.items():
        for l,y in b.items():z[k+l]+=x*y
    return dict(z)

def topological_order(B):
    n=len(B);remain=set(range(n));order=[]
    while remain:
        sources=[i for i in remain if all(B[i][j]>=0 for j in remain)]
        if not sources:raise ValueError('acyclic input required')
        order.extend(sorted(sources));remain.difference_update(sources)
    return order

def charged_standard(B,d,p,D=None):
    n=len(B);d=tuple(d);p=tuple(p);D=tuple(D or (1,)*n)
    if len(d)!=n or len(p)!=n or len(D)!=n:raise ValueError('dimension')
    if any(not(0<=p[i]<=d[i]) for i in range(n)):return {},{'S':0,'R':0,'Q':-1}
    order=topological_order(B)
    if any(D[i]*B[i][j]!=-D[j]*B[j][i] for i in range(n) for j in range(n)):
        raise ValueError('D B must be skew-symmetric')
    R=sum(D[i]*B[i][j]*(d[i]-p[i])*p[j]
          for ii,i in enumerate(order) for j in order[ii+1:])
    S=sum(D[i]*p[i]*(d[i]-p[i]) for i in range(n))
    # No symmetric charge survives when the maximal standard charge is negative.
    if S<R:return {},{'S':S,'R':R,'Q':S-R}
    coeff={0:1}
    for i in range(n):coeff=convolution(coeff,dict(gaussian_layers(d[i],D[i])[p[i]]))
    return {k-R:v for k,v in coeff.items()},{'S':S,'R':R,'Q':S-R}

def charged_cap(B,d,p,D=None):
    m,meta=charged_standard(B,d,p,D)
    return sum(min(v,m.get(-k,0)) for k,v in m.items())

def charged_caps(B,d,points=None,D=None,metadata=False):
    if points is None:points=product(*(range(q+1) for q in d))
    caps={};metas={}
    for pp in points:
        p=tuple(pp);m,meta=charged_standard(B,d,p,D)
        caps[p]=sum(min(v,m.get(-k,0)) for k,v in m.items())
        if metadata:metas[p]=meta
    return (caps,metas) if metadata else caps

if __name__=='__main__':
    import json,time
    from pathlib import Path
    tic=time.time()
    count=0
    for d in range(13):
        for scale in range(1,4):
            for p,layers in enumerate(gaussian_layers(d,scale)):
                z=dict(layers)
                assert sum(z.values())==comb(d,p)
                assert all(z.get(-k)==v for k,v in z.items())
                assert max(z)==scale*p*(d-p)
                count+=1
    path=Path(__file__).resolve().parents[1]/'agent_creation_caps/fundamental_input_6.json'
    inp=json.loads(path.read_text());B=inp['B'];d=inp['carrier']['d'];pts=inp['carrier']['lattice_points']
    caps,meta=charged_caps(B,d,pts,metadata=True)
    result={'layer_checks':count,'B':B,'d':d,'point_count':len(pts),
      'zero_caps':[p for p,v in caps.items() if not v],
      'caps':[{'p':p,'cap':v,**meta[p]} for p,v in caps.items()],
      'seconds':time.time()-tic,'scope':'skew theta comparison; pure integer DP; no higher theta inputs'}
    Path(__file__).with_name('charged_k4_caps.json').write_text(json.dumps(result,indent=2))
    print({k:v for k,v in result.items() if k not in ('caps','zero_caps')})
    print('zeros',len(result['zero_caps']),'cap3221',caps.get((3,2,2,1)))
