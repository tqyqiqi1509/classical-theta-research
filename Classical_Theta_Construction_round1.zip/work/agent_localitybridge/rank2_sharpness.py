"""Check the exact all-seed zero-coefficient criterion for true LLZ elements.

This is not a coefficientwise-minimality argument. Starting with the genuine
denominator-coordinate LLZ recursion, it seeks an actual cluster chart with
zero coefficient at each nonzero original principal-coefficient exponent.
The rank-two alternating rays are followed beyond the last possible active
root; the stopping certificate is the standard two-step root recurrence.
"""
import sys, math, json, time
from itertools import product
from pathlib import Path
sys.path.insert(0, '/workspace/scratch/184561e83b72/work/agent_division')
from principal_cluster import mutate_matrix
from rank2_saturation_check import llz_F
from truncated_atlas import symmetrizer

def binom(a,j):
    if j==0:return 1
    if a>=0:return math.comb(a,j) if j<=a else 0
    return (-1)**j*math.comb(-a+j-1,j)

def series_step(B,D,g,E,A,k,ee,index):
    c=tuple(E[2+i][k] for i in range(2));root=tuple(abs(x) for x in c)
    out=[]
    for p in ee:
        base=sum(c[i]*D[i]*(g[i]+sum(B[i][j]*p[j] for j in range(2))) for i in range(2))
        assert base%D[k]==0;a=base//D[k]
        upper=min(p[j]//root[j] for j in range(2) if root[j])
        out.append(sum(binom(a,r)*A[index[tuple(p[j]-r*root[j] for j in range(2))]] for r in range(upper+1)))
    return mutate_matrix(E,k),tuple(out),root

def outside(v,cap):return any(v[i]>cap[i] for i in range(2))

def case(b,c,a1,a2):
    B=((0,b),(-c,0));D=symmetrizer(B);g=(-a1,c*max(a1,0)-a2)
    F,cap=llz_F(b,c,g)
    ee=tuple(product(range(cap[0]+1),range(cap[1]+1)));index={p:i for i,p in enumerate(ee)}
    A0=tuple(F.get(p,0) for p in ee)
    witnesses={p:() for p in ee if p!=(0,0) and not F.get(p,0)}
    E0=B+((1,0),(0,1));depths=[];stops=[];tail_values=[];mincoef=0;maxcoef=max(A0)
    for first in (0,1):
        E=E0;A=A0;w=[];roots=[];seen={E};stop=None
        for d in range(1,10000):
            k=(first+d-1)%2
            E,A,root=series_step(B,D,g,E,A,k,ee,index);roots.append(root);w.append(k)
            mincoef=min(mincoef,min(A));maxcoef=max(maxcoef,max(A))
            for p,v in zip(ee,A):
                if p!=(0,0) and v==0 and p not in witnesses:witnesses[p]=tuple(w)
            if E in seen:
                stop={'kind':'seed_repeat','depth':d};break
            seen.add(E)
            # For bc>=4, after the sign transient, each parity of positive
            # root vectors obeys r[j+2]=(bc-2)r[j]-r[j-2]. We explicitly
            # verify two recurrence instances plus monotonicity on both
            # parities before invoking it as the infinite-ray tail formula.
            if b*c>=4 and d>=10:
                tr=b*c-2
                checks=all(all(roots[j][i]==tr*roots[j-2][i]-roots[j-4][i] for i in range(2)) for j in (d-2,d-1))
                growing=all(all(roots[j][i]>=roots[j-2][i] for i in range(2)) for j in (d-2,d-1))
                if checks and growing and outside(roots[-1],cap) and outside(roots[-2],cap):
                    stop={'kind':'monotone_root_tail','depth':d,'trace':tr,'last_roots':roots[-4:]};break
        assert stop is not None,'unexpected 10000-step cutoff'
        depths.append(len(w));stops.append(stop);tail_values.append(A)
    missing=[p for p in ee if p!=(0,0) and p not in witnesses]
    positive_count=sum(v>0 for p,v in F.items() if p!=(0,0))
    max_witness=max((len(w) for p,w in witnesses.items() if F.get(p,0)>0),default=0)
    result={'b':b,'c':c,'a':[a1,a2],'g':g,'cap':cap,'positive_nonconstant_coefficients':positive_count,'missing_sharpness':missing,'min_transported_coefficient':mincoef,'max_transported_coefficient':maxcoef,'max_witness_length':max_witness,'ray_depths':depths,'tail_certificates':stops}
    if b*c>=4:
        result['both_tail_positive']=[p for p in ee if p!=(0,0) and F.get(p,0)>0 and tail_values[0][index[p]]>0 and tail_values[1][index[p]]>0]
    if missing:result['F']=[[p,v] for p,v in sorted(F.items())]
    # Retain long witnesses, which can expose the mechanism most effectively.
    if max_witness>3:result['long_witnesses']=[{'p':p,'word':w,'value':F.get(p,0)} for p,w in witnesses.items() if len(w)==max_witness]
    return result

if __name__=='__main__':
    start=time.time();results=[]
    dest=Path('/workspace/scratch/184561e83b72/work/agent_localitybridge/rank2_sharpness_results.json')
    for b,c in product(range(1,7),repeat=2):
      for a1,a2 in product(range(1,13),repeat=2):
        r=case(b,c,a1,a2);results.append(r)
      data={'seconds':time.time()-start,'cases':len(results),'missing_cases':sum(bool(r['missing_sharpness']) for r in results),'negative_cases':sum(r['min_transported_coefficient']<0 for r in results),'positive_coefficients_checked':sum(r['positive_nonconstant_coefficients'] for r in results),'max_witness_length':max(r['max_witness_length'] for r in results),'results':results}
      dest.write_text(json.dumps(data,indent=2))
      print(b,c,'cases',len(results),'missing',data['missing_cases'],'negative',data['negative_cases'],'maxword',data['max_witness_length'],'seconds',round(time.time()-start,2),flush=True)
