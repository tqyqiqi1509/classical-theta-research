# Exact seed reset and an asymptotic interface for the general construction

Date: 2026-11-13. The reset formula and degree-two stabilization below are proved algebraically. Higher-order stabilization is a research direction, not a theorem.

## 1. Exact finite-fiber reset

Write f=x^g F(z) at initial principal coefficients. Mutate the initial seed at k, with B'=mu_k(B), and reset the coefficient variables to independent principal variables at that seed. The coefficient identification is

    y'_k=y_k^{-1},   y'_j=y_j y_k^{[b_kj]_+}  (j!=k).

Cluster variables at later seeds are also rescaled by frozen monomials; merely substituting the above y variables in every old normalized transport is therefore not a valid covariance argument.

For a fixed exponent vector p_hatk on all variables other than z_k, write the old fiber as P(t)=sum_r A_(p_hatk,r) t^r. If the exact reset is polynomial and pointed, the new fiber is

    P'(t)=t^L (1+t)^R P(t^{-1}),
    L=[-g_k]_+ + sum_{j!=k}[-b_kj]_+ p_j,
    R=g_k + sum_{j!=k} b_kj p_j.                         (M)

The new mutable label is

    g'_k=-g_k,
    g'_i=g_i+[b_ik]_+ g_k       if g_k>=0,
    g'_i=g_i+[-b_ik]_+ g_k      if g_k<=0, i!=k.

The removed frozen prefactor is (y'_k)^(-[g_k]_+). To derive (M), substitute the exchange relation into each monomial, express old y as monomials in y', factor the exchange binomial as a frozen monomial times (1+z'_k), and group by p_hatk. The exponent of (1+z'_k) is independent of r because b_kk=0.

The implementation `reset_one` in `candidate_sharpness.py` does not assume (M): it first performs exact sparse Laurent binomial division, converts y-exponents, and extracts the pointed constant monomial. It checks the expected label and frozen prefactor. This independent route is useful for detecting a sign or convention error in (M).

A finite original-y jet cannot in general be reset by (M), since t inversion can bring arbitrarily high old fiber terms into low new degrees. A genuine finite-fiber bound or exact finite candidate is needed.

## 2. General eventual polynomiality, proved

**Theorem.** Fix B, h in Z^n and a coefficient exponent p. There are N_0 and a rational polynomial P_p(N), of degree at most |p|_1, such that

    [z^p]G_(Nh)^B=P_p(N)  for every integer N>=N_0.

For p!=0, P_p(0)=0. For each fixed p, one actual seed can be chosen that witnesses coefficient sharpness for every sufficiently large N. The theorem holds without genericity of h.

**Proof.** For every actual transport, its row entry from q to p is a polynomial in g over Q of degree at most |p-q|_1. In each signed-c binomial generator, taking j copies of a positive direction alpha contributes degree at most j in g and raises total coefficient degree by j|alpha|_1>=j. Composition preserves the claimed bound. Finite signatures give only finitely many distinct operator rows, uniformly for all g.

Induct on |p|. Once all proper predecessor coefficients have their eventual polynomials, every cut for p is a rational polynomial in N of degree at most |p|. There are finitely many cuts. The sign of each pairwise polynomial difference is fixed for all sufficiently large positive N, unless the difference is identically zero. Thus their maximum is eventually one fixed polynomial. It is integer-valued at all sufficiently large integers because the actual coefficients are integers. The same maximizing actual seed is a sharpness witness throughout that tail.

For the vanishing at N=0, use induction again. All nonconstant predecessor polynomials vanish there. The only surviving potential cut term is the transport entry from q=0, evaluated at g=0. This is zero at p!=0 because every transport fixes the element 1. Hence every eventual cut polynomial vanishes at N=0, and so does the maximizing one. ∎

The coefficient [z^p]log G_(Nh) is therefore eventually a rational polynomial of degree at most |p| and with zero constant term. Dividing it by N leaves an eventual polynomial of degree at most |p|-1. The substantive missing step is the cancellation of every remaining positive power of N. This theorem establishes existence of an eventual branch, not an effective general threshold: exact enumeration of all actual rows is still an unresolved part of the finite algorithm.

The same argument applies along Nh+a for a fixed offset a, but the assertion P_p(0)=0 then need not hold. A finite set of offsets admits a common eventual threshold by taking the maximum of their individual thresholds.

## 3. Eventual logarithmic linearity in degree two

Let G_g^B be the all-seed formal greedy series from `FORMAL_GREEDY_SHARPNESS.md`. Fix an integral h and write r_i=[-h_i]_+, s_i=[h_i]_+. The already proved second-order formula gives, for b_ij=a>0, b_ji=-b<0,

    [z_i z_j] G_(Nh) = N^2 r_i r_j
                         + [b N r_i - N s_j min(N r_i,a)]_+.

For N>=max_{i,j}|b_ij|, every nonzero integral r_i satisfies N r_i>=a, so

    [z_i z_j] log G_(Nh) = N [b r_i-a s_j]_+.

Also [z_i]log G_(Nh)=N r_i and [z_i^2]log G_(Nh)=-N r_i/2. Consequently

    (1/N) log G_(Nh) modulo degree >2

is exactly independent of N once the displayed uniform bound holds. On each chamber cut out by h_i=0 and b h_i+a h_j=0, these stabilized coefficients are linear functions of h.

This is a proven low-order form of an asymptotic mechanism that could address labels outside cluster cones. The proposed higher-order question is: for every fixed degree K and a direction h avoiding the relevant rational hyperplanes, does log G_(Nh)/N become exactly constant for all sufficiently large N? If so, can the resulting chamberwise linear functions define integer formal coordinate maps whose compatibility is forced by the positive multiplication of the family G?

The proposal does not define a scattering diagram or use theta functions as its input. At present, its higher-order stabilization, integrality as automorphisms, consistency, and relation to finite Laurent support are all open steps.

## 4. Why a finite-degree saturation result does not already prove logarithmic linearity

Finite signatures show only that a coefficient is the maximum of finitely many integral polynomial expressions after its predecessors are fixed. They do not by themselves force the logarithm's nonlinear powers of N to cancel. The second-order cancellation is explicit. The all-order question needs a new mechanism, potentially using the family's structure constants or exact endpoint certificates.

Qiyue Tang's Hexagon 2610.00025v3 uses a related finite-rigidity strategy in a quantum setting: growing labels force bounded lower corrections to vanish by a quantum degree capacity and bar invariance, then positive structure constants extract otherwise inaccessible coefficients. The exact argument cannot be specialized to arbitrary classical positive families merely by setting v=1, because its vanishing bound uses information lost under that specialization. It is recorded as an idea for adaptation, not as an adopted result.
