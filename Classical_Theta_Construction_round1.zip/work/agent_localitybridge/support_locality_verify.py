"""Independent exact support-locality check.

An ambient mutation word is transported directly in the original principal
coefficient variables. Separately, reduced seeds are enumerated until the
strict g-cone criterion finds the frozen product's chart. The two entire
restricted transport jets (all coordinate generators) are then compared.
No clustering of ambient signatures is used. Search cutoffs are explicit.
"""
import sys, math, json, random, time
from itertools import product, combinations
from collections import deque
from pathlib import Path
sys.path.insert(0, '/workspace/scratch/184561e83b72/work/agent_division')
from principal_cluster import mutate_matrix
from truncated_atlas import symmetrizer

def binom(a,j):
    if j==0:return 1
    if a>=0:return math.comb(a,j) if j<=a else 0
    return (-1)**j*math.comb(-a+j-1,j)

class Transport:
    def __init__(self,B,I,N):
        self.B=tuple(map(tuple,B));self.n=len(B);self.I=tuple(I);self.N=N
        self.D=symmetrizer(B);self.k=len(I)
        self.ee=sorted((p for p in product(range(N+1),repeat=self.k) if sum(p)<=N),key=lambda p:(sum(p),p))
        self.index={p:i for i,p in enumerate(self.ee)}
        self.zero=tuple(0 for _ in I)
    def start(self):
        n=self.n
        E=self.B+tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
        G=tuple(tuple(int(i==j) for i in range(n)) for j in range(n))
        H=tuple(tuple(int(p==self.zero) for p in self.ee) for i in self.I)
        return E,G,H
    def step(self,S,k):
        E,G,H=S;n=self.n;I=self.I;B=self.B;D=self.D
        c=tuple(E[n+i][k] for i in range(n));a=tuple(abs(c[i]) for i in I)
        assert all(t>=0 for t in c) or all(t<=0 for t in c)
        eps=1 if any(t>0 for t in c) else -1
        gg=tuple(-G[k][r]+sum(max(-eps*E[i][k],0)*G[i][r] for i in range(n)) for r in range(n))
        GG=list(G);GG[k]=gg;GG=tuple(GG)
        EE=mutate_matrix(E,k)
        if any(c[i] for i in range(n) if i not in I) or sum(a)>self.N:
            return EE,GG,H
        HH=[]
        for ri,i in enumerate(I):
            hh=[]
            for p in self.ee:
                base=sum(c[r]*D[r]*(int(r==i)+sum(B[r][s]*p[sj] for sj,s in enumerate(I))) for r in I)
                assert base%D[k]==0
                exponent=base//D[k]
                upper=min((p[j]//a[j] for j in range(len(I)) if a[j]),default=0)
                value=sum(binom(exponent,z)*H[ri][self.index[tuple(p[j]-z*a[j] for j in range(len(I)))]] for z in range(upper+1))
                hh.append(value)
            HH.append(tuple(hh))
        return EE,GG,tuple(HH)
    def cone_coordinates(self,S,h):
        E,G,H=S;n=self.n;D=self.D
        out=[]
        for k in range(n):
            v=sum(E[n+i][k]*D[i]*h[i] for i in range(n))
            assert v%D[k]==0
            out.append(v//D[k])
        return tuple(out)

def reduced_search(B,h,N,depth=18,state_cap=120000,bit_cap=1000):
    n=len(B);tr=Transport(B,range(n),N);S0=tr.start()
    q=deque([(S0,(),-1)]);seen={S0[0]};cuts={'depth':0,'state':0,'bits':0}
    while q:
        S,w,last=q.popleft()
        coords=tr.cone_coordinates(S,h)
        if min(coords)>0:return S,w,coords,len(seen),cuts
        if len(w)>=depth:cuts['depth']+=1;continue
        for k in range(n):
            if k==last:continue
            SS=tr.step(S,k)
            if SS[0] in seen:continue
            if max(abs(a).bit_length() for row in SS[0] for a in row)>bit_cap:cuts['bits']+=1;continue
            if len(seen)>=state_cap:cuts['state']+=1;continue
            seen.add(SS[0]);q.append((SS,w+(k,),k))
    return None,None,None,len(seen),cuts

def run_case(B,I,w,N=4):
    tr=Transport(B,I,N);S=tr.start()
    for k in w:S=tr.step(S,k)
    h=tuple(sum(S[1][j][i] for j in range(len(B))) for i in I)
    BB=[[B[i][j] for j in I] for i in I]
    SS,ww,coords,count,cuts=reduced_search(BB,h,N)
    result={'B':B,'D':tr.D,'I':I,'ambient_word':w,'target_h_I':h,'reduced_word':ww,'cone_coordinates':coords,'degree':N,'reduced_states':count,'search_cuts':cuts}
    if SS is None:result['status']='search_cutoff';return result
    assert S[2]==SS[2],('LOCALITY MISMATCH',result,S[2],SS[2])
    result['status']='verified';result['generator_coefficients_compared']=len(I)*len(tr.ee)
    result['max_jet_coefficient']=max(max(row) for row in S[2]);return result

if __name__=='__main__':
    rng=random.Random(202611130511);start=time.time();results=[]
    path=Path('/workspace/scratch/184561e83b72/work/agent_localitybridge/support_locality_results.json')
    for n in (3,4,5,6):
      for z in range(30):
        D=[1]*n if z<15 else [rng.randint(1,4) for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
          for j in range(i+1,n):
            v=rng.choice([-2,-1,0,1,2]);B[i][j]=D[j]*v;B[j][i]=-D[i]*v
        w=[]
        for _ in range(rng.randint(4,15)):
            k=rng.choice([k for k in range(n) if not w or k!=w[-1]]);w.append(k)
        I=sorted(rng.sample(range(n),2 if n==3 or z%3 else 3))
        r=run_case(B,I,w);results.append(r)
        data={'seconds':time.time()-start,'cases':len(results),'verified':sum(r['status']=='verified' for r in results),'compared_coefficients':sum(r.get('generator_coefficients_compared',0) for r in results),'results':results}
        path.write_text(json.dumps(data,indent=2))
        print(n,z,r['status'],'ambient',len(w),'reduced',len(r['reduced_word']) if r['reduced_word'] is not None else None,'states',r['reduced_states'],'seconds',round(time.time()-start,2),flush=True)
