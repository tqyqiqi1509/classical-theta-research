# Handoff: locality, sharpness, reset, and large-label interface

Completed wave: 2026-11-13 approximately 05:05–05:35 UTC.

## Main results available to root

1. `SUPPORT_LOCALIZATION_AUDIT.md`: independent check of root's product-freezing support-localization proof. No substantive gap found. Qin 2407.03186 Theorem 5.11 classical hypotheses checked; it covers skew-symmetrizable principal coefficients without reddening. Multiplicativity is used only for the compatible pointed product, as allowed by Lemma 4.3(3). Existing scattering dependency remains explicit.

2. A stronger integer stopping test for the reduced chart: h=G_t 1 satisfies (G_s^{-1}h)_I>0. Every mutable E-row is nonnegative because a globally Laurent monomial cannot have a negative mutable exponent; each row is nonzero by invertibility. Thus the row sums are strictly positive. Enumerating I-only g-cones finds the common chart; use cluster-monomial g-vector injectivity or a final exact F identity certificate to identify it.

3. `FORMAL_GREEDY_SHARPNESS.md`: the all-seed formal greedy recursion is well-defined by finite signatures. It is characterized by positivity plus an actual zero coefficient witness at every nonzero p. This gives a general all-order recovery theorem for every cluster monomial, since its own seed makes the entire nonconstant series zero.

4. Under support locality, the formal greedy family commutes with coordinate freezing. It factors over disconnected exchange components. Therefore log G has no coefficient with disconnected induced support. This is a combinatorial locality property, not a positivity assertion about the logarithm.

5. `RESET_AND_ASYMPTOTIC_INTERFACE.md`: exact finite-fiber principal reset. At mutation k, fixed p_hatk fiber P(t) becomes

       t^([-gk]_+ + sum[-b_kj]_+ p_j)
       (1+t)^(gk + sum b_kj p_j) P(t^-1).

   The usual tropical g reset and the frozen prefactor y'_k^(-[gk]_+) are included. The independent implementation obtains these by exact Laurent binomial division, rather than assuming this formula. One cannot reset a finite jet without a bound on the complete old t-fiber.

6. General eventual polynomiality, as proposed by root and written with proof: for each fixed B,h,p, A_p(Nh) is eventually a rational polynomial of degree <=|p|. There is a fixed actual sharpness-witness seed for that p throughout the tail. The argument needs no genericity of h. An additional deduction is P_p(0)=0 for p!=0, using induction and T(1)=1. Hence [z^p]log G_(Nh)/N is eventually a polynomial of degree <=|p|-1. Degree-two formulas force it to be constant already for N>=max|b_ij|. The all-order cancellation of positive powers of N is the next major open step.

7. Independent check of root's radical-degree rigidity proof passed: Bp=0 annihilates the top BCH bracket, while a direct elementary contribution would require an isolated c-direction. This is a logarithmic statement, not vanishing of ordinary transport coefficients.

## Computation completed

- `support_locality_verify.py` / `support_locality_results.json`: 120 inputs, ranks 3–6, 57 nonconstant symmetrizers, supports size 2 or 3, degree 4. All 5,850 exact generator coefficients match the independently found reduced chart. No search cutoff. Max reduced word length 7.
- `rank2_sharpness.py` / `rank2_sharpness_results.json`: b,c=1..6 and denominator labels a1,a2=1..12, 5,184 true LLZ-recursion inputs. All 135,611 positive nonconstant coefficients have actual zero witnesses. Max witness word length 12. Each alternating ray stops on an exact seed repetition or a monotone root-tail certificate. This certifies those finitely many inputs; the all-parameter LLZ sharpness theorem is not yet proved.
- Rejected shortcut: retain only the two stabilized rank-two ray transports. It fails in 3,599 tested inputs; intermediate seeds matter. Example b=1,c=4,a=(1,2), p=(1,2).
- `candidate_sharpness.py` / `affine_candidate_sharpness_results.json`: 960 independently generated affine-cycle Chebyshev candidates and one-step principal resets, ranks 3–6, degree<=4. 12,249 positive coefficients witnessed. These low-degree tests in rank>=5 have proper support, so they do not by themselves probe the full higher-rank core.
- `full_carrier_sharpness.py` / `full_carrier_sharpness_results.json`: repaired that limitation by testing the entire finite initial carrier in 150 cases, ranks 3–5, two orientations per rank, multiples 1..5 and every one-step initial reset. All 12,596 positive nonconstant coefficients have actual witnesses, max word length 3, no cutoff. Largest coefficient box has 7,776 positions. The generator is an independent order-ideal/Chebyshev model. Its identification with theta and its universal positivity need an external established affine/surface bridge; this wave did not complete that strong audit, so treat it as a diagnostic and a conditional identification certificate, not an unconditional new theta theorem.
- Actual Wolfram kernel computation in `wolfram_rank2_tail.wl` confirms monodromy trace bc-2, determinant 1, the Cayley–Hamilton two-step root recurrence, and the monotone-tail inequality. The preliminary WolframContext call errored internally; the language evaluator succeeded. Root already has other successful Wolfram usage as well.

All processes have completed; logs and exact witnesses are retained. Large JSON is highly repetitive and compresses well in the stage ZIP. No need to reproduce raw rows in a prose report.

## Precise remaining gaps

- Exact finite row enumeration: finite-signature cardinality bounds do not automatically decide which abstract rows are realized by actual seeds.
- Non-CM sharpness: no proof yet that every finite theta function satisfies the actual-cluster zero criterion. Rank-two LLZ evidence is broad but finite.
- Reset covariance: no general proof that sharpness survives the reciprocal fiber operation. Actual rescaled chart variables matter; substitution of original y exponents alone gives a false argument even for a rank-one cluster variable.
- Finite Laurent support: formal positivity and the formal recursion do not yet bound the carrier for a general g. This is not supplied by recent pointed-basis theorems.
- Asymptotic linearity: eventual polynomiality is now proved; logarithmic degree collapse beyond degree 2 is open. This seems a concrete next task for a fresh agent, especially together with root's squarefree structure-constant positivity experiments.

## Literature audited or screened

- Qin 2407.03186: exact freezing interface checked, classical scope correct; existing scattering proof dependency declared.
- Reading–Stella 2603.19391v4, *Mutation of Theta Functions*, SIGMA 22 (2026),109, published 2026-11-08. Primary arXiv and journal metadata agree. Sections 2.6,3.3,5.3–5.5 checked. Thm5.14 presupposes membership in the theta-generated small canonical algebra, so it cannot provide our membership or finite-support proof. Its dominance-coordinate formulas are useful possible constraints. Entire paper not independently reproved.
- Cheung–Magee–Mandel–Muller 2505.09585v2 (2026-05-21), *Valuative independence and cluster theta reciprocity*. Primary text Sections3.4–3.9 inspected. Unit Newton vertex coefficients come from unique taut extremal broken lines. This does not imply interior coefficient sharpness; do not substitute one for the other. Their Li–Pan citation is not adopted.
- Reading–Stella 2603.23429v1, *Theta functions in acyclic affine type*. Imaginary-ray recurrence and compatible-root product formula inspected as a candidate generator; full proof still unaudited for use.
- Qiyue Tang Hexagon2611.00190v2, modified-quantum-group positivity. Statements and Demazure quotient/transition/adjunction interfaces inspected. Transferable idea: coherent finite-stage label identification. No main positivity result is used.
- Qiyue Tang Hexagon2610.00025v3, *Minimality of the Rank-Two Quantum Greedy Basis*. Read through Lemma3.1 and the finite-rigidity mechanism. Growing labels annihilate bounded corrections using two opposite degree capacities, then multiplication extracts coefficients. The crucial bar-invariance/v-degree bound is lost on setting v=1, so this does not establish the analogous assertion for arbitrary classical positive families. Suggested adaptation: replace degree capacity by our actual endpoint/cut certificates.
- Fei2510.01615v4 (2026-11-03), orthogonal projections: primary metadata checked; detailed projection/facet theorem not yet cleared.
- LLZ1208.2391v3, especially Prop1.5, Prop1.6, Prop4.1, read in their actual denominator coordinates. Neither alternating lower-bound induction nor indecomposability alone proves coefficientwise leastness. Rank-two all-seed sharpness is the right separate claim tested here.

Relevant web references for root to independently reopen if citing: Qin PDF https://arxiv.org/pdf/2407.03186 ; Reading–Stella https://arxiv.org/html/2603.19391v4 ; VIT https://arxiv.org/html/2505.09585v2 ; affine theta https://arxiv.org/html/2603.23429v1 ; LLZ https://arxiv.org/pdf/1208.2391 ; Qiyue minimality https://hexagonmath.org/pdf/2610.00025v3 .
