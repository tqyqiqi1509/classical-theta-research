# An all-order formal greedy mechanism and exact sharpness criterion

Date: 2026-11-13. Status: proved from the team's finite-signature transport theorem. These are formal-series statements; no finite Laurent-support or theta-identification claim is included without an additional hypothesis.

## 1. Definition by actual cluster transports

Fix a classical skew-symmetrizable exchange matrix B, initial principal coefficients, z_i=y_i x^{B[:,i]}, and g in Z^n. Let T_t run over the normalized inverse transports of actual cluster seeds. On the homogeneous formal module x^g Z[[z]], write

    [z^p] x^{-g} T_t(x^g F) = A_p + L_{t,g,p}(A_{q}: 0<=q<p).

Here `<` means coordinatewise at most and not equal. Triangularity follows from the explicit signed-c binomial generators. Each L is an integral linear form involving finitely many proper predecessors of p. The finite-signature theorem says that for fixed p there are only finitely many actual such rows, although a terminating algorithm listing exactly those rows has not yet been supplied in full generality.

Set A_0=1 and recursively define

    A_p = max_t {-L_{t,g,p}(A_q:0<=q<p)}  for p!=0.       (G)

The initial seed contributes zero, so A_p>=0. Every maximum is a finite attained integer. Any linear extension of the coordinatewise order gives the same result, because only proper predecessors occur. Denote the resulting formal series by G_g^B(z).

This is a well-defined canonical formal construction from actual integer cluster transports. It is not yet a finite combinatorial algorithm in the sense requested for the final basis: exact enumeration of the actual rows, finite Laurent support, and seed covariance require further proof. The distinction is essential.

## 2. Universal formal positivity and coefficient sharpness

The defining inequality immediately gives

    x^{-g} T_t(x^g G_g^B) in Z_{>=0}[[z]]

for every actual seed t. Moreover, for every nonzero p there exists an actual seed t=t(p) such that

    [z^p] x^{-g} T_t(x^g G_g^B)=0.                       (S)

This follows because the maximum in (G) is attained. When A_p=0, the initial seed itself can serve if it attains the bound; in all cases some actual row attains it.

**Sharpness characterization.** Suppose F(0)=1 and F has nonnegative integral coefficients after every actual normalized transport. Then F=G_g^B if and only if F satisfies (S) at every nonzero p.

**Proof.** The forward direction was just proved. For the reverse direction, induct on total degree. Suppose the coefficients agree at every proper predecessor of p. Positivity of F bounds F_p below by the maximum in (G). A seed witnessing (S) gives F_p=-L_t, which is at most that maximum. Hence equality. This also shows precisely why mere formal positivity does not identify the candidate. ∎

## 3. All-order recovery of cluster monomials

**Theorem.** If g is the g-vector of a localized cluster monomial f=X(t)^a, where mutable exponents a are nonnegative and original frozen exponents are zero, then

    f=x^g G_g^B(z).

**Proof.** The principal-coefficient expansion of f has constant coefficient one, and cluster positivity gives nonnegative coefficients in every cluster. Its normalized original-frozen transport is therefore nonnegative. In its own seed,

    T_t(f)=x^{G_t a}=x^g.

Thus the same seed t witnesses (S) simultaneously for every nonzero p. Apply the sharpness characterization. ∎

This is a general extension mechanism, not a finite check on special examples: the construction recovers every cluster monomial, in every rank, at every coefficient degree. It also proves finite support for all cluster-monomial labels. It does not infer finite support for other labels.

## 4. Restriction to supports

Assume the support-localization theorem of `../ALGEBRAIC_SUPPORT_LOCALIZATION.md`, with its openly stated Qin freezing input. For every I subset of mutable indices,

    G_g^B(z)|_{z_j=0,j outside I}=G_{g_I}^{B_I}(z_I).    (R)

Indeed, the exact set of restricted actual transport rows is the actual transport set for B_I, and every proper predecessor of p supported in I is also supported in I. Induction in (G) proves (R).

The operation uses only integer data. The present general proof of equality of actual row sets still has the external freezing dependency; this is not obscured.

## 5. Products and disconnected exchange matrices

Let f=x^g F and h=x^h H be formal universally positive elements. A product transport has nonnegative coefficients, so

    [z^p] x^{-(g+h)} T_t(fh)=0

if and only if p is absent from the Minkowski sum of the coefficient supports of x^{-g}T_t(f) and x^{-h}T_t(h). Consequently, if for every nonzero p there is an actual seed excluding p from that sum, then the product is exactly x^{g+h}G_{g+h}^B by (S). This gives a concrete sufficient criterion for multiplicative compatibility without invoking theta functions.

In particular, if B is block diagonal on components I_1,...,I_r, then

    G_g^B(z)=product_a G_{g_{I_a}}^{B_{I_a}}(z_{I_a}).   (D)

The transport set is the direct product of component transport sets. The product on the right is positive. For a nonzero p, choose a component with p restricted to that component nonzero and choose a sharpness-witness seed for that component. The coefficient at p in the product is the product of component coefficients, so it vanishes. Apply (S).

Combining (R) and (D), the formal logarithm log G_g^B has zero coefficient at every p whose induced support graph B[supp(p)] is disconnected. This is a connected-support property of the logarithmic coefficients, obtained from formal positivity and sharpness rather than from scattering or geometric representation theory. The logarithm can have rational or signed coefficients; it is not yet a positive combinatorial model.

## 6. The theta bridge is a precise open condition

For a proposed finite theta/greedy candidate f_g, the sufficient and necessary condition for agreement with this formal greedy construction is (S), in addition to actual-cluster formal positivity. Newton-polytope vertices of coefficient one, pointedness, and valuative independence do not on their own establish the zero coefficient condition at interior p.

Even rank two requires care: LLZ Proposition 1.5 is formulated in denominator-pointed coordinates, and its inequalities are alternating. It does not imply that a greedy coefficient is coefficientwise no greater than every other positive pointed element merely by naive induction. The needed claim is equality of the correct principal-g all-seed recurrence, which is a separate statement.

Useful next attack: obtain sharpness for a non-cluster-monomial candidate from a finite family of exact Laurent divisions or from a support-avoidance rule. Then the above theorem gives identification without a separate coefficient comparison. Alternatively, a failure of (S) would identify exactly where the all-seed greedy construction differs and force a change of selection mechanism.
