from candidate_sharpness import *

start=time.time();results=[]
target=Path('/workspace/scratch/184561e83b72/work/agent_localitybridge/full_carrier_sharpness_results.json')
for n in (3,4,5):
 for bits in [(1,)*(n-1)+(0,),tuple(i%2 for i in range(n))]:
  B=cycle_matrix(n,bits)
  for multiple in range(1,6):
   g,F=affine_cycle(B,multiple)
   for mutation in [None]+list(range(n)):
    if mutation is None:BB,gg,FF=B,g,F
    else:
     reset=reset_one(B,g,F,mutation);assert reset['status']=='pointed',reset
     BB,gg,FF=reset['B'],reset['g'],reset['F']
    r=sharp_witnesses(BB,gg,FF,None,12,30000)
    r.update({'rank':n,'cycle_orientation':bits,'multiple':multiple,'initial_mutation':mutation,'B':BB,'g':gg,'candidate_terms':len(FF)})
    results.append(r)
    if r['status']!='witnessed':r['F']=[[p,c] for p,c in sorted(FF.items())]
    data={'cases':len(results),'seconds':time.time()-start,'witnessed':sum(r['status']=='witnessed' for r in results),'negative':sum(r['status']=='negative' for r in results),'cutoff':sum(r['status']=='cutoff' for r in results),'results':results}
    target.write_text(json.dumps(data,indent=2))
    print(n,bits,multiple,mutation,r['status'],'states',r['states'],'coeff',r['coefficients_per_chart'],'seconds',round(time.time()-start,2),flush=True)
