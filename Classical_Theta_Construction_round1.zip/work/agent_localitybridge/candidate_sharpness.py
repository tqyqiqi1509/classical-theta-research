"""Finite candidate zero witnesses, with exact principal-coefficient reset.

Candidates are generated independently of the all-seed greedy recursion.
Finite affine-cycle candidates are used as a diagnostic of the general
sharpness/covariance mechanism, not as a replacement target theorem.
"""
import sys,math,json,time,random
from collections import defaultdict,deque
from itertools import product
from pathlib import Path
sys.path.insert(0,'/workspace/scratch/184561e83b72/work/agent_division')
from principal_cluster import mutate_matrix
from truncated_atlas import symmetrizer
from exact_laurent_mutation import initial_E,from_F,mutate_laurent

def binom(a,j):
    if j==0:return 1
    if a>=0:return math.comb(a,j) if j<=a else 0
    return (-1)**j*math.comb(-a+j-1,j)

def mul(F,H):
    out=defaultdict(int)
    for a,c in F.items():
        for b,d in H.items():out[tuple(x+y for x,y in zip(a,b))]+=c*d
    return {p:c for p,c in out.items() if c}

def affine_cycle(B,k):
    n=len(B);zero=(0,)*n
    g=tuple(-1+sum(max(-B[i][j],0) for j in range(n)) for i in range(n))
    F={p:1 for p in product((0,1),repeat=n) if all(not(B[i][j]>0 and p[j]>p[i]) for i in range(n) for j in range(n))}
    prev={zero:2};curr=F
    if k==0:return tuple(0 for _ in g),prev
    for j in range(2,k+1):
        nex=mul(curr,F)
        for p,c in prev.items():
            q=tuple(x+1 for x in p);nex[q]=nex.get(q,0)-c
            if not nex[q]:del nex[q]
        prev,curr=curr,nex
    assert min(curr.values())>0
    return tuple(k*x for x in g),curr

def reset_one(B,g,F,k):
    n=len(B);E,ff=mutate_laurent(initial_E(B),from_F(B,g,F),k);BB=tuple(row for row in E[:n])
    converted=[]
    for e,c in ff.items():
        pp=list(e[n:]);pp[k]=-e[n+k]+sum(max(B[k][j],0)*e[n+j] for j in range(n))
        converted.append((e[:n],tuple(pp),c))
    q0=tuple(min(q[j] for m,q,c in converted) for j in range(n))
    leading=[(m,c) for m,q,c in converted if q==q0]
    if len(leading)!=1 or leading[0][1]!=1:return {'status':'not_pointed','q0':q0,'leading':leading}
    gg=leading[0][0];FF={}
    for m,q,c in converted:
        p=tuple(q[j]-q0[j] for j in range(n))
        assert m==tuple(gg[i]+sum(BB[i][j]*p[j] for j in range(n)) for i in range(n))
        FF[p]=c
    expectedg=tuple(-g[i] if i==k else g[i]+(max(B[i][k],0) if g[k]>=0 else max(-B[i][k],0))*g[k] for i in range(n))
    assert gg==expectedg,(B,g,k,gg,expectedg)
    assert q0==tuple(-max(g[k],0) if j==k else 0 for j in range(n)),(B,g,k,q0)
    return {'status':'pointed','B':BB,'g':gg,'F':FF,'frozen_prefactor':q0}

def sharp_witnesses(B,g,F,N=4,depth=8,state_cap=15000):
    n=len(B);D=symmetrizer(B)
    cap=tuple(max(p[i] for p in F) for i in range(n)) if N is None else (N,)*n
    ee=sorted((p for p in product(*(range(a+1) for a in cap)) if N is None or sum(p)<=N),key=lambda p:(sum(p),p));index={p:i for i,p in enumerate(ee)}
    A0=tuple(F.get(p,0) for p in ee);need={p for p,c in F.items() if any(p) and (N is None or sum(p)<=N) and c>0};found={}
    E0=initial_E(B);queue=deque([(E0,A0,(),-1)]);seen={E0};negative=None;transitions=0
    while queue and need:
        E,A,w,last=queue.popleft()
        for p in list(need):
            if A[index[p]]==0:found[p]=w;need.remove(p)
        if min(A)<0:
            negative={'word':w,'coefficients':[(p,a) for p,a in zip(ee,A) if a<0]};break
        if len(w)>=depth:continue
        for k in range(n):
            if k==last:continue
            EE=mutate_matrix(E,k)
            if EE in seen:continue
            if len(seen)>=state_cap:continue
            c=tuple(E[n+i][k] for i in range(n));root=tuple(abs(x) for x in c)
            if any(root[i]>cap[i] for i in range(n)) or (N is not None and sum(root)>N):AA=A
            else:
                aa=[]
                for p in ee:
                    base=sum(c[i]*D[i]*(g[i]+sum(B[i][j]*p[j] for j in range(n))) for i in range(n));assert base%D[k]==0
                    a=base//D[k];lim=min(p[j]//root[j] for j in range(n) if root[j])
                    aa.append(sum(binom(a,r)*A[index[tuple(p[j]-r*root[j] for j in range(n))]] for r in range(lim+1)))
                AA=tuple(aa)
            seen.add(EE);queue.append((EE,AA,w+(k,),k));transitions+=1
    return {'status':'negative' if negative else 'witnessed' if not need else 'cutoff','states':len(seen),'transitions':transitions,'degree':N,'box':cap,'coefficients_per_chart':len(ee),'depth_limit':depth,'state_limit':state_cap,'unwitnessed':sorted(need),'negative':negative,'witnesses':[{'p':p,'word':w} for p,w in sorted(found.items())]}

def cycle_matrix(n,bits):
    B=[[0]*n for _ in range(n)]
    for i in range(n):
        j=(i+1)%n;v=1 if bits[i] else -1;B[i][j]=v;B[j][i]=-v
    return B

if __name__=='__main__':
    start=time.time();results=[];rng=random.Random(202611130528)
    target=Path('/workspace/scratch/184561e83b72/work/agent_localitybridge/affine_candidate_sharpness_results.json')
    for n in range(3,7):
      patterns=[p for p in product((0,1),repeat=n) if 0<sum(p)<n]
      if len(patterns)>12:patterns=rng.sample(patterns,12)
      for bits in patterns:
       B=cycle_matrix(n,bits)
       for k in range(1,5):
        g,F=affine_cycle(B,k)
        for initial_mutation in [None]+list(range(n)):
            if initial_mutation is None:BB,gg,FF=B,g,F
            else:
                reset=reset_one(B,g,F,initial_mutation)
                assert reset['status']=='pointed',reset
                BB,gg,FF=reset['B'],reset['g'],reset['F']
            r=sharp_witnesses(BB,gg,FF,4,8,20000)
            r.update({'rank':n,'cycle_orientation':bits,'multiple':k,'initial_mutation':initial_mutation,'B':BB,'g':gg,'candidate_terms':len(FF)})
            results.append(r)
            if r['status']!='witnessed':r['F']=[[p,c] for p,c in sorted(FF.items())]
        data={'cases':len(results),'seconds':time.time()-start,'witnessed':sum(r['status']=='witnessed' for r in results),'negative':sum(r['status']=='negative' for r in results),'cutoff':sum(r['status']=='cutoff' for r in results),'results':results}
        target.write_text(json.dumps(data,indent=2))
        print(n,bits,k,'cases',len(results),'witnessed',data['witnessed'],'negative',data['negative'],'cutoff',data['cutoff'],'seconds',round(time.time()-start,2),flush=True)
