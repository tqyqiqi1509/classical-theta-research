mb={{b,-1},{1,0}};
mc={{c,-1},{1,0}};
mon=mc.mb;
{
  Simplify[Tr[mon]],
  Simplify[Det[mon]],
  Simplify[mon.mon-(b c-2)mon+IdentityMatrix[2]],
  Resolve[ForAll[{u,v,t},Implies[t>=2&&u>=v&&v>=0,t*u-v>=u]],Reals]
}

(* Actual Wolfram Language Evaluator output on 2026-11-13:
   {-2 + b*c, 1, {{0, 0}, {0, 0}}, True}
   This verifies the two-step recurrence and monotone-tail arithmetic.
   It does not prove the LLZ all-parameter sharpness conjecture.
   WolframContext was attempted first and returned an internal error;
   the actual language-kernel computation succeeded.
*)
