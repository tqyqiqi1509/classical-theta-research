# Positive-division subtask handoff

Time: started 2026-11-13 04:13 UTC; handoff prepared 04:38 UTC. This is a research handoff to another agent, not the user-facing final package.

## What is established

1. **Finite dimer/Boolean-cube criterion for positive binomial division.** A nonnegative coefficient sequence is divisible positively by `(1+t)^m` iff m successive deterministic adjacent-level dimer partitions succeed. Complete elementary proof is in `positive_division_notes.md` Sections 1--2. This applies on lattice cosets to arbitrary-rank cluster exchange binomials. It gives local certificates only; multicolor compatibility is not established.

2. **A general explicit two-step positivity cut.** For `b_kl=a>0`, `b_lk=-d<0`, `q_k=q_l=0`, and `r_i=g_i+sum_j b_ij q_j`, the coefficient after mutations k,l at original frozen degree `q+a e_k+e_l` equals

   `sum_{j=0}^a binom(r_k+a,a-j) A_{q+j e_k+e_l}+(r_l+d*r_k)A_q`.

   This is an exact integer identity and a necessary positivity inequality. It works in arbitrary rank and with arbitrary symmetrizer. Proof: only two families of binomial-choice histories can reach that frozen degree. See Section 4 and `two_step_cut_check.py`.

3. **Exact failure of the naive directional-max recurrence.** For the cyclic A3 matrix `[[0,1,-1],[-1,0,1],[1,-1,0]]` at g=(-1,-1,-1), the candidate gives A111=2. A cluster monomial reached by (1,2,3,1) has F-polynomial

   `(1+y1+y1*y2)(1+y2+y2*y3)(1+y3+y1*y3)`,

   whose A111 is 4. The two-step cut at (1,2),q=e3 is `A111-A011-2*A001>=0`, forcing A111>=4 once the lower coefficients are fixed. No inference from a finite truncation to infinite divergence is made.

   The polytope agent's finite one-step-positive 43-term tables with A111=2,3 acquire respectively -2,-1 at `x1'^{-1}x2''^2 x3^{-1} y1*y2*y3` after (1,2). **These are not counterexamples to Li--Pan's complete construction:** they fail stronger coefficient-reset pointedness/degree constraints. The polytope agent is separately researching those constraints.

4. **Exact bounded-degree mutation operator.** Fix original frozen y, an initial homogeneous degree g, B, and symmetrizer D. For c=C_t[:,k], alpha=abs(c), the homogeneous scalar coefficient transform is

   `A'_p=sum_{j>=0} binom(c^T D(g+Bp)/d_k,j) A_{p-j*alpha}`.

   The upper binomial index is independent of j. The mutation becomes the identity on coefficient tables of total degree <=N whenever |c|_1>N. The mutable monomial changes are already absorbed by the homogeneous exponent `G_t^{-1}(g+Bp)`.

   Mechanism agent's improvement: `d_k=gcd_i(|c_i|d_i)`, since the corresponding row of G^{-1} is primitive integral. Thus the active letter depends only on signed c and initial B,D,g, not on its current label.

   Deleting an inactive letter from the **operator product** is valid. Deleting its descendants from the **seed search** is not justified.

5. **Finite normal form in total degree one.** Using global c-sign coherence and tropical duality, G rows are sign-coherent. The i-th row can change sign exactly when c=+e_i or -e_i is mutated. These signs alternate, starting with +e_i. Hence the net simple-root count is 0 or 1, and there are at most 2^n degree-one operators; the saturated first coefficient is [-g_i]_+.

   Dependency alert: global c-sign coherence is an external standard theorem; no independent purely combinatorial proof of it was supplied. Opposite-initial-seed duality is algebraic given that input. Each finite computed word is instead checked directly for c-column sign coherence.

## What remains genuinely open here

- Find a **purely algebraic/combinatorial projection or word-collection theorem** at degree two, especially for active columns supported on I={i,j}. Setting all other frozen variables to zero makes outside-support steps act trivially, but those steps may change the later active word.
- A finite alphabet or a nilpotent collection basis does not bound integer powers/commutator coefficients.
- Even finiteness of the set of possible operators does not give a computable completion/stopping certificate for the reachable subset. At degree one, a reachable operator with all simple-root net counts 1 is equivalent to a reddening seed (G=-permutation). A reachability-preserving effective finite quotient would therefore also supply a general route to deciding existence of reddening sequences.
- No arbitrary-rank theta characterization, finite Laurent support theorem, ordinary-A membership theorem, or basis/multiplication theorem has been obtained.

## Main code APIs

- `binomial_matching.py`: `divide_positive(f,m)`, exact nonnegative dimer algorithm; independent oracle `exact_quotient`.
- `seed_greedy.py`: `recurrence(B,g,degree)`; the **rejected** naive directional-max candidate, useful as a diagnostic only.
- `principal_cluster.py`: exact principal coefficient seed/F/g mutation, used for the A3 cluster monomial comparison.
- `exact_laurent_mutation.py`: sparse Laurent-polynomial exact mutation, signed or unsigned; `search_negative` searches the first negative chart.
- `positive_cuts.py`: `coefficient_cut(B,g,path,target)` gives an exact integer linear form in initial A_e for one output coefficient, using finite frozen-degree power-series expansion. No theta input.
- `truncated_atlas.py`: box-truncated coefficient operators and tentative all-word saturation.
- `atlas_bfs_study.py`: `atlas_total(B,g,degree,maxdepth,seed_cap=200000,bit_cap=16384)` returns `(result,exponents,transforms)` for total-degree truncation. It stores full integer B,C and never prunes merely inactive steps. It interns operators, independently checks each duplicate extended-matrix visit, checks all traversed c-columns for sign coherence, and records any resource cutoff.

## Computation evidence (not proofs)

- Dimer criterion: 65,535 input polynomials; 262,059 divisor checks; 2,087 successful positive quotients; zero mismatch with independent exact division.
- General two-step formula: 183 random symmetrizable matrices of rank 2--5 with diverse g,q; zero discrepancy with direct truncated substitution.
- Rank-two tentative all-word saturation: 225 small plus 42 larger LLZ greedy comparisons, including wild parameters; no mismatch at the tested coefficient boxes and word bounds. This is a benchmark, not a proof of a new all-rank rule.
- Degree 2 and degree 3 BFS: 44 matrices each (32 connected rank-three matrices with nonzero edge magnitudes <=2 and 12 rank-four matrices, including nontrivial symmetrizers); 299,501 states in each run.
- Verified degree-three broad run: 11,470 duplicate extended-matrix operator checks and 310,927 c-column sign checks, all passed.
- Extended degree-three rank-four run: 12 matrices to word length 12; **3,769,009 states**, 70,076 duplicate operator checks, 3,839,073 sign checks, zero resource pruning. There were 28--162 distinct truncated operators per matrix. Some new types first appeared at depths 9--10, so a plateau at depth 8 was not sufficient.
- Active words can have nonadjacent repeated absolute roots. Example `(e1,e2,e2+e3,-e1)` occurs among first-seen representatives; free cancellation is insufficient.

All numerical detail is in the JSON files in this directory. The notes contain exact proof statements and source-scope cautions.

## Source interfaces passed to other agents

- Nakanishi--Zelevinsky arXiv:1101.3736v3: Theorem 1.2, Proposition 1.3, (2.7)--(2.9), read directly. Original theorem is conditional on c-sign coherence; use correctly.
- LLZ arXiv:1208.2391v3: Proposition 1.5 and Lemma 2.1/proofs checked. Adjacent positive-division inequalities are useful; they do not establish general universal positivity.
- Sherman--Zelevinsky arXiv:math/0307082, Remark 5.8: no fixed finite chart set characterizes unrestricted positive Laurentness even in rank two affine. This does not refute a coefficientwise bounded-degree statement for fixed g.
- Lin--Musiker--Nakanishi arXiv:2112.11839 / IMRN2024: the mechanism agent is reading the pure algebraic finite-word generalized-binomial formula; do not promote it to a finite-state theorem over all words.
- Gupta arXiv:1812.01910: the mechanism agent reports a no-repeated-positive-c-vector lemma for all-green sequences; its stability theorem has extra periodic hypotheses.
- Qin arXiv:2407.03186 freezing theorem uses scattering in its proof (author's Remark1.2); not an independent pure-combinatorial closure here.
- Cao--Gyoda--Yurikusa arXiv:2106.11668: mechanism agent studying Bongartz projection as a possible replacement.
- Qiu--Tang arXiv:2611.09155v1, Nov6 2026: primary full text opened; Assumption1.1 requires green-to-red throughout. Not used as a theorem. Section5 acyclicity gives a strict partial order, not a demonstrated well-founded finite-word bound; mechanism agent checked this distinction.

## Suggested next task after context refresh

Prove or refute a degree-two support restriction lemma using only mutation recurrences, enough g-pairs/Bongartz completion if independently justified, and integer word operations. Specifically: does the signed active subword with c supported on I={i,j}, after discarding |c|_1>2, have a bounded normal form equal to one realized in the rank-two principal submatrix B_I? State carefully whether it is equality of true reachable words, equality only of truncated operators, or merely an over-approximation of operators; the distinction affects positivity and termination.

## Final degree-two experiment, 04:41 UTC

The initially proposed one-step expression

`max(0,[-g_i-b_ij]_+[-g_j]_+,[-g_j-b_ji]_+[-g_i]_+)`

is **false** for the desired coefficient. For example use `B=[[0,1,-2],[-1,0,-2],[2,2,0]]`, g=(-3,2,3). The local rule gives A110=0, with A000=1,A100=3,A010=0. The actual two-step path (1,2) gives the coefficient cut

`A110-2*A010-A000>=0`,

at mutated monomial `(x1')^1*(x2'')^1*x3^7*y1*y2`, requiring A110>=1. This is already a rank-two A2 effect: the true rank-two greedy F-polynomial is `(1+y1)^2*(1+y1+y1*y2)`. Thus the principal-g directional-max candidate is not even the original LLZ recursion in a different notation: LLZ uses a denominator-pointed quadrant, and reversing one coordinate requires upper-bound/normalization information. Do not misstate this diagnostic as a new failure of the actual LLZ rank-two construction.

The correct tested replacement is: for each pair i,j, compute the genuine rank-two LLZ greedy F-polynomial for B_{ij},B_{ji} and g_i,g_j; take its coefficient at y_i*y_j. For disconnected pairs take `[-g_i]_+[-g_j]_+`. Together with the univariate coefficients this defines a **rank-two envelope in total degree two**.

Across 44 exchange matrices (ranks 3 and 4, skew-symmetric and skew-symmetrizable), eight g-vectors per matrix, and **1,752,872 actual seed states**, the all-path saturation through the tested word bounds matched this rank-two envelope in all **352** cases. There were 35 counterexamples to the naive one-step formula but **zero** to the genuine rank-two envelope. This is the best current positive lead. A proof should show that every full-rank path's degree-two positivity constraint is bounded by a genuine rank-two constraint, without requiring equality of the full reachable operator sets.

Files: `degree2_worst_constraints.py` (the intentionally tested-and-rejected one-step formula), `degree2_worst_constraints_results.json` (all 352 full-rank experiments), `degree2_rank2_envelope_results.json` (comparison with actual LLZ rank-two coefficients). The latter was computed from saved full-rank results; no additional seed sampling was used.
