"""Exact finite combinatorial positive division by powers of a binomial.
The recurrence returns dimer multiplicities, with independent exact convolution checks.
"""
from math import comb
from itertools import product
from dataclasses import dataclass
import json

@dataclass
class DivisionResult:
    success: bool
    quotient: list[int] | None
    layers: list[list[int]]
    obstruction: dict | None

def trim(a):
    a=list(a)
    while a and a[-1]==0:a.pop()
    return a

def convolve(a,b):
    if not a or not b:return []
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
      for j,y in enumerate(b):c[i+j]+=x*y
    return trim(c)

def divide_positive(f,m):
    """Process m successive dimer partitions, never using negative token counts.
    Empty f represents zero. The exact degree boundary is included.
    """
    if m<0 or any(int(a)!=a or a<0 for a in f):raise ValueError('Require nonnegative integral coefficients and m>=0')
    cur=trim(f);layers=[]
    for s in range(m):
      if not cur:layers.append([]);continue
      prev=0; q=[]
      for j,a in enumerate(cur):
        if a<prev:
          return DivisionResult(False,None,layers,{'layer':s+1,'level':j,'available':a,'required':prev,'type':'insufficient_tokens'})
        outgoing=a-prev
        q.append(outgoing);prev=outgoing
      if prev:
        return DivisionResult(False,None,layers,{'layer':s+1,'level':len(cur),'available':0,'required':prev,'type':'unmatched_terminal_tokens'})
      cur=trim(q[:-1]);layers.append(cur)
    return DivisionResult(True,cur,layers,None)

def exact_quotient(f,m):
    """Independent signed long division over Z[t], including remainder."""
    f=trim(f);kernel=[comb(m,j)for j in range(m+1)]
    if not f:return [],[]
    if len(f)<=m:return [],f
    work=f[:]; q=[0]*(len(f)-m)
    for j in range(len(f)-m-1,-1,-1):
      q[j]=work[j+m]
      for k,c in enumerate(kernel):work[j+k]-=q[j]*c
    return trim(q),trim(work)

def exhaustive(max_degree=8,max_coeff=3,max_power=4):
    counts={'inputs':0,'cases':0,'successes':0,'failures':0,'mismatches':[]}
    for degree in range(max_degree+1):
      for pref in product(range(max_coeff+1),repeat=degree):
        for leading in range(1,max_coeff+1):
          f=list(pref)+( [leading] )
          counts['inputs']+=1
          for m in range(1,min(max_power,degree+1)+1):
            counts['cases']+=1
            out=divide_positive(f,m);q,r=exact_quotient(f,m)
            expected=not r and all(a>=0 for a in q)
            if out.success!=expected or out.success and out.quotient!=q:
              counts['mismatches'].append([f,m,out.__dict__,q,r])
            counts['successes' if out.success else 'failures']+=1
    return counts

if __name__=='__main__':
    r=exhaustive(7,3,4)
    print(json.dumps(r,indent=2))
    with open('/workspace/scratch/184561e83b72/work/agent_division/binomial_matching_results.json','w') as f:json.dump(r,f,indent=2)
