import sympy as sp
from collections import deque
from itertools import product

def mutate_matrix(E,k):
    n=len(E[0]);m=len(E)
    return tuple(tuple(-E[i][j] if i==k or j==k else E[i][j]+max(E[i][k],0)*max(E[k][j],0)-max(-E[i][k],0)*max(-E[k][j],0) for j in range(n))for i in range(m))

def initial(B):
    n=len(B);E=tuple(tuple(row) for row in B)+tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
    return (E,tuple(sp.Integer(1) for i in range(n)),tuple(tuple(int(i==j) for j in range(n)) for i in range(n)),())

def mutate(B,seed,k,ys):
    E,Fs,gs,path=seed;n=len(B)
    P=sp.prod(Fs[i]**max(E[i][k],0) for i in range(n))*sp.prod(ys[j]**max(E[n+j][k],0) for j in range(n))
    N=sp.prod(Fs[i]**max(-E[i][k],0) for i in range(n))*sp.prod(ys[j]**max(-E[n+j][k],0) for j in range(n))
    nf=sp.cancel((P+N)/Fs[k]);nf=sp.Poly(nf,*ys).as_expr()
    ng=tuple(-gs[k][r]+sum(max(E[i][k],0)*gs[i][r] for i in range(n))-sum(B[r][j]*max(E[n+j][k],0) for j in range(n)) for r in range(n))
    fs=list(Fs);fs[k]=nf;gg=list(gs);gg[k]=ng
    return mutate_matrix(E,k),tuple(fs),tuple(gg),path+(k,)

def enumerate_seeds(B,maxdepth=8):
    n=len(B);ys=sp.symbols('y1:'+str(n+1));s0=initial(B)
    q=deque([s0]); seen={s0[:3]};out=[]
    while q:
      s=q.popleft();out.append(s)
      if len(s[3])>=maxdepth:continue
      for k in range(n):
        if s[3] and s[3][-1]==k:continue
        ns=mutate(B,s,k,ys)
        if ns[:3] not in seen: seen.add(ns[:3]);q.append(ns)
    return ys,out

if __name__=='__main__':
    B=[[0,1,-1],[-1,0,1],[1,-1,0]]
    ys,seeds=enumerate_seeds(B,8)
    print('seeds',len(seeds),'variables',len(set((g,F)for E,Fs,gs,p in seeds for g,F in zip(gs,Fs))))
    for target in [(-1,-1,-1),(-1,-1,0),(-2,-2,-2)]:
      for E,Fs,gs,p in seeds:
        A=sp.Matrix.hstack(*map(sp.Matrix,gs));c=A.inv()*sp.Matrix(target)
        if all(x>=0 and x.q==1 for x in c):
          F=sp.expand(sp.prod(fi**int(ci) for fi,ci in zip(Fs,c)))
          print('target',target,'path',p,'powers',tuple(c),'gs',gs,'F',F)
          break
