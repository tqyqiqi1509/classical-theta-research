from atlas_bfs_study import atlas_total
from truncated_atlas import saturated_greedy
from math import comb
import random,json,time

def predicted(B,g):
 n=len(B);zero=(0,)*n;c={zero:1};a=[max(-x,0)for x in g]
 for i in range(n):
  e=[0]*n;e[i]=1
  if a[i]:c[tuple(e)]=a[i]
  e[i]=2
  v=comb(a[i],2)
  if v:c[tuple(e)]=v
 for i in range(n):
  for j in range(i+1,n):
   e=[0]*n;e[i]=e[j]=1
   v=max(0,max(-g[i]-B[i][j],0)*a[j],max(-g[j]-B[j][i],0)*a[i])
   if v:c[tuple(e)]=v
 return c

def run():
 rng=random.Random(202611130440);old=json.load(open('/workspace/scratch/184561e83b72/work/agent_division/atlas_bfs_degree3.json'))
 results=[];start=time.time()
 for z in old['results']:
  B=z['B'];n=len(B)
  gs=[tuple(rng.randint(-3,3)for _ in range(n))for _ in range(6)]+[tuple(-1 for _ in range(n)),tuple(-2 for _ in range(n))]
  for g in gs:
   r,ee,Ts=atlas_total(B,g,2,10 if n==3 else 9,seed_cap=200000)
   got=saturated_greedy(ee,Ts);exp=predicted(B,g)
   mm=[(p,exp.get(p,0),got.get(p,0))for p in ee if exp.get(p,0)!=got.get(p,0)]
   results.append({'name':z['name'],'B':B,'g':g,'states':r['seed_count'],'T':len(Ts),'mismatches':mm})
   if mm:print('COUNTEREXAMPLE',results[-1],flush=True)
  print('done',z['name'],'cases',len(results),flush=True)
 out={'cases':len(results),'total_states':sum(z['states']for z in results),'mismatch_cases':sum(bool(z['mismatches'])for z in results),'seconds':time.time()-start,'results':results}
 json.dump(out,open('/workspace/scratch/184561e83b72/work/agent_division/degree2_worst_constraints_results.json','w'),indent=2)
 print({k:v for k,v in out.items()if k!='results'},flush=True)
if __name__=='__main__':run()
