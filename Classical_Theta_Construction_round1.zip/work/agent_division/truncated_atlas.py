"""Enumerate exact low-frozen-degree coefficient transforms along mutation words.
Research instrument. A finite word bound is not asserted to characterize all seeds.
"""
from itertools import product
from collections import deque
from fractions import Fraction
from math import gcd
from functools import reduce
import json,time
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E
from positive_cuts import generalized_binomial

def symmetrizer(B):
    n=len(B);D=[None]*n
    for root in range(n):
      if D[root] is not None:continue
      D[root]=Fraction(1);todo=[root]
      while todo:
        i=todo.pop()
        for j in range(n):
          if not B[i][j]:continue
          v=-D[i]*Fraction(B[i][j],B[j][i])
          if D[j] is None:D[j]=v;todo.append(j)
          elif D[j]!=v:raise ValueError('not symmetrizable')
    den=1
    for d in D:den=den*d.denominator//gcd(den,d.denominator)
    ints=[int(d*den)for d in D];z=reduce(gcd,ints)
    return [d//z for d in ints]

def exponents(cap):return sorted(product(*(range(c+1)for c in cap)),key=lambda p:(sum(p),p))
def identity(N):return tuple(tuple(int(i==j)for j in range(N))for i in range(N))

def update_transform(B,D,g,E,T,k,exps,index):
    n=len(B);c=tuple(E[n+i][k]for i in range(n));v=tuple(abs(x)for x in c)
    if any(x>0 for x in c)and any(x<0 for x in c):raise ArithmeticError('c sign')
    if not any(v):raise ArithmeticError('zero c')
    rows=[]
    for p in exps:
      lim=min(p[i]//v[i] for i in range(n) if v[i])
      if not lim:rows.append(T[index[p]]);continue
      num=sum(c[i]*D[i]*(g[i]+sum(B[i][j]*p[j]for j in range(n)))for i in range(n))
      assert num%D[k]==0
      r=num//D[k];row=list(T[index[p]])
      for j in range(1,lim+1):
        z=generalized_binomial(r,j)
        if not z:continue
        q=tuple(p[i]-j*v[i]for i in range(n));rr=T[index[q]]
        for h,a in enumerate(rr):row[h]+=z*a
      rows.append(tuple(row))
    return tuple(rows)

def atlas(B,g,cap,maxdepth):
    n=len(B);D=symmetrizer(B);exps=exponents(cap);index={e:i for i,e in enumerate(exps)};I=identity(len(exps));E=initial_E(B)
    q=deque([(E,I,(),-1)]);seenE={E};Ts={I:()};levels={};maxabs=0
    while q:
      E,T,p,last=q.popleft();lev=len(p)
      st=levels.setdefault(lev,{'seeds':0,'new_transforms':0});st['seeds']+=1
      if T not in Ts:Ts[T]=p;st['new_transforms']+=1
      if lev==maxdepth:continue
      for k in range(n):
        if k==last:continue
        EE=mutate_matrix(E,k)
        if EE in seenE:continue
        seenE.add(EE)
        TT=update_transform(B,D,g,E,T,k,exps,index)
        q.append((EE,TT,p+(k,),k))
    return exps,Ts,levels

def saturated_greedy(exps,Ts):
    vals=[1]+[0]*(len(exps)-1)
    for i in range(1,len(exps)):
      vals[i]=max(0,max(-sum(T[i][j]*vals[j]for j in range(i))for T in Ts))
    return {p:a for p,a in zip(exps,vals)if a}

if __name__=='__main__':
    examples=[('A3cyc',[[0,1,-1],[-1,0,1],[1,-1,0]],(-1,-1,-1),(2,2,2),9),('Markov',[[0,2,-2],[-2,0,2],[2,-2,0]],(-1,-1,-1),(2,2,2),12),('rank2_33',[[0,3],[-3,0]],(-3,5),(5,5),18)]
    result={}
    for name,B,g,cap,depth in examples:
      start=time.time();exps,Ts,levels=atlas(B,g,cap,depth);c=saturated_greedy(exps,Ts)
      res={'B':B,'g':g,'cap':cap,'word_length':depth,'seeds':sum(x['seeds']for x in levels.values()),'transforms':len(Ts),'levels':levels,'greedy':[[p,a]for p,a in c.items()],'seconds':time.time()-start}
      result[name]=res;print(name,{k:v for k,v in res.items()if k not in ['greedy','levels']},'levels',levels,flush=True)
    json.dump(result,open('/workspace/scratch/184561e83b72/work/agent_division/truncated_atlas_results.json','w'),indent=2)
