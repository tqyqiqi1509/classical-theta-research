from math import comb
from itertools import product
from truncated_atlas import atlas,saturated_greedy
import json,time

def llz_F(b,c,g):
 a1=-g[0];a2=c*max(a1,0)-g[1];m1=max(a1,0);m2=max(a2,0);co={(0,0):1}
 for d in range(1,m1+m2+1):
  for p in range(max(0,d-m1),min(m2,d)+1):
   q=d-p;value=0
   if a2-c*q>0:
    z=sum((-1)**(k-1)*comb(a2-c*q+k-1,k)*co.get((p-k,q),0)for k in range(1,p+1));value=max(value,z)
   if a1-b*p>0:
    z=sum((-1)**(k-1)*comb(a1-b*p+k-1,k)*co.get((p,q-k),0)for k in range(1,q+1));value=max(value,z)
   if value:co[p,q]=value
 return {(m1-q,p):v for (p,q),v in co.items()},(m1,m2)

def run():
 records=[];start=time.time()
 for b,c in product(range(1,4),repeat=2):
  B=[[0,b],[-c,0]]
  for g in product(range(-2,3),repeat=2):
   expected,bound=llz_F(b,c,g);cap=tuple(x+1 for x in bound)
   exps,Ts,levels=atlas(B,g,cap,14);got=saturated_greedy(exps,Ts)
   mismatches=[(e,expected.get(e,0),got.get(e,0))for e in exps if expected.get(e,0)!=got.get(e,0)]
   r={'b':b,'c':c,'g':g,'cap':cap,'transforms':len(Ts),'mismatches':mismatches}
   records.append(r)
  print('parameters',b,c,'cumulative',len(records),'mismatchcases',sum(bool(r['mismatches'])for r in records),flush=True)
 data={'cases':len(records),'mismatchcases':sum(bool(r['mismatches'])for r in records),'depth':14,'seconds':time.time()-start,'records':records}
 json.dump(data,open('/workspace/scratch/184561e83b72/work/agent_division/rank2_saturation_results.json','w'),indent=2)
 print({k:v for k,v in data.items()if k!='records'})
if __name__=='__main__':run()
