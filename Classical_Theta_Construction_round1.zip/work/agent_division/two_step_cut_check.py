from positive_cuts import *
import random,json

def predicted(B,g,k,l,q):
  a=B[k][l];d=-B[l][k]
  rk=g[k]+sum(B[k][i]*q[i]for i in range(len(B)))
  rl=g[l]+sum(B[l][i]*q[i]for i in range(len(B)))
  out={}
  for j in range(a+1):
    e=list(q);e[k]+=j;e[l]+=1;c=generalized_binomial(rk+a,a-j)
    if c:out[tuple(e)]=c
  c=rl+d*rk
  if c:out[tuple(q)]=c
  return out

def run(N=200):
  rng=random.Random(20261113);checks=[]
  for z in range(N):
    n=rng.randint(2,5);D=[rng.randint(1,3)for _ in range(n)];B=[[0]*n for _ in range(n)]
    # B_ij=D_j*C_ij makes D_i B_ij skew-symmetric.
    for i in range(n):
      for j in range(i+1,n):
        c=rng.randint(-1,1);B[i][j]=D[j]*c;B[j][i]=-D[i]*c
    pairs=[(i,j)for i in range(n)for j in range(n)if B[i][j]>0]
    if not pairs:continue
    k,l=rng.choice(pairs);g=tuple(rng.randint(-3,3)for _ in range(n));q=[rng.randint(0,1)for _ in range(n)];q[k]=q[l]=0;q=tuple(q)
    p=list(q);p[k]+=B[k][l];p[l]+=1;p=tuple(p)
    _,out=transform_series(B,g,{p:1},(k,l),p)
    assert len(out)==1 and next(iter(out.values()))==1
    target=next(iter(out));actual=coefficient_cut(B,g,(k,l),target);pred=predicted(B,g,k,l,q)
    if actual!=pred:raise AssertionError((B,g,k,l,q,actual,pred))
    checks.append({'rank':n,'symmetrizer':D,'B':B,'g':g,'path':[k,l],'q':q,'target':target,'cut':[[e,c]for e,c in actual.items()]})
  result={'checked':len(checks),'mismatches':0,'formula':'sum_{j=0}^a binom(r_k(q)+a,a-j)c[q+j e_k+e_l]+(r_l(q)+d r_k(q))c[q] >=0','cases':checks}
  json.dump(result,open('/workspace/scratch/184561e83b72/work/agent_division/two_step_cut_results.json','w'),indent=2)
  print('two-step exact formula checks',len(checks),'mismatches',0)
if __name__=='__main__':run()
