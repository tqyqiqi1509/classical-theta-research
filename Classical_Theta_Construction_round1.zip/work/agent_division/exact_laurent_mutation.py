"""Sparse exact mutation in a geometric-type cluster chart.
No scattering input. Includes orbitwise Laurent division by exchange binomials.
"""
from collections import defaultdict, deque
from math import comb
from itertools import product
import json
from principal_cluster import mutate_matrix
from binomial_matching import exact_quotient

def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(a,k):return tuple(k*x for x in a)
def sub(a,b):return tuple(x-y for x,y in zip(a,b))

def divide_binomial(poly,u,v,m):
    """Exact Laurent division by (z^u+z^v)^m, signed quotient allowed."""
    delta=sub(u,v);N=len(u)
    pivot=next((i for i,d in enumerate(delta) if d),None)
    if pivot is None:
      out={};den=2**m
      for a,c in poly.items():
        if c%den:raise ArithmeticError(('nonintegral',a,c,den))
        if c:out[sub(a,scale(v,m))]=c//den
      return out
    fibers=defaultdict(dict)
    for a,c in poly.items():
      j=a[pivot]//delta[pivot]
      base=sub(a,scale(delta,j)); fibers[base][j]=c
    out={}
    for base,vals in fibers.items():
      low=min(vals);high=max(vals)
      p=[vals.get(j,0)for j in range(low,high+1)]
      q,r=exact_quotient(p,m)
      if r:raise ArithmeticError(('nonlaurent',m,base,low,p,r))
      start=sub(add(base,scale(delta,low)),scale(v,m))
      for j,c in enumerate(q):
        if c:out[add(start,scale(delta,j))]=c
    return out

def multiply_binomial(poly,u,v,m):
    out=defaultdict(int)
    for a,c in poly.items():
      for j in range(m+1):out[add(a,add(scale(u,j),scale(v,m-j)))]+=c*comb(m,j)
    return {a:c for a,c in out.items()if c}

def mutate_laurent(E,poly,k):
    N=len(E);n=len(E[0]);u=tuple(max(E[i][k],0)for i in range(N));v=tuple(max(-E[i][k],0)for i in range(N))
    slices=defaultdict(dict)
    for a,c in poly.items():
      r=a[k];aa=list(a);aa[k]=0;slices[r][tuple(aa)]=c
    out=defaultdict(int)
    for r,p in slices.items():
      q=multiply_binomial(p,u,v,r) if r>=0 else divide_binomial(p,u,v,-r)
      for a,c in q.items():
        aa=list(a);aa[k]=-r;out[tuple(aa)]+=c
    return mutate_matrix(E,k),{a:c for a,c in out.items()if c}

def from_F(B,g,coef):
    n=len(B);out={}
    for p,c in coef.items():
      a=tuple(g[i]+sum(B[i][j]*p[j]for j in range(n))for i in range(n))+tuple(p)
      out[a]=c
    return out

def initial_E(B):
    n=len(B);return tuple(map(tuple,B))+tuple(tuple(int(i==j)for j in range(n))for i in range(n))

def search_negative(B,g,coef,depth=5):
    E=initial_E(B);f=from_F(B,g,coef);q=deque([(E,f,())]);seen=set();counts=defaultdict(int)
    while q:
      E,f,path=q.popleft();counts[len(path)]+=1
      neg=[(a,c)for a,c in f.items()if c<0]
      if neg:return {'path':path,'negative':neg,'terms':len(f),'counts':dict(counts),'E':E,'polynomial':f}
      if len(path)==depth:continue
      for k in range(len(B)):
        if path and path[-1]==k:continue
        Ee,ff=mutate_laurent(E,f,k);key=(Ee,tuple(sorted(ff.items())))
        if key not in seen:seen.add(key);q.append((Ee,ff,path+(k,)))
    return {'path':None,'counts':dict(counts)}
