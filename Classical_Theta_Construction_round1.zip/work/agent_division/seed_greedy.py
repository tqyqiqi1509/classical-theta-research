"""Exact principal-coefficient adjacent-seed positive-division recursion.
Candidate only; no assertion of mutation invariance or theta equality.
"""
from math import comb
from itertools import product
from collections import defaultdict
import json, time

def weak_compositions(k,n):
    if n==1:
        yield (k,); return
    for a in range(k+1):
        for tail in weak_compositions(k-a,n-1): yield (a,)+tail

def recurrence(B,g,degree):
    n=len(g); zero=(0,)*n; co={zero:1}; stats=[]
    for d in range(1,degree+1):
        layer=[]
        for e in weak_compositions(d,n):
            lower=0
            for i in range(n):
                m=max(0,-g[i]-sum(B[i][j]*e[j] for j in range(n)))
                if m==0: continue
                value=0
                for k in range(1,e[i]+1):
                    prev=list(e); prev[i]-=k
                    value+=(-1)**(k-1)*comb(m+k-1,k)*co.get(tuple(prev),0)
                lower=max(lower,value)
            if lower: co[e]=lower; layer.append((e,lower))
        stats.append({'degree':d,'nonzero':len(layer),'mass':sum(c for e,c in layer),'max':max((c for e,c in layer),default=0)})
    return co,stats

def sparse_serial(co): return [[list(e),c] for e,c in sorted(co.items(),key=lambda t:(sum(t[0]),t[0]))]

def main():
    Bs={
      'A2':[[0,1],[-1,0]],
      'rank2_23':[[0,2],[-3,0]],
      'A3_path':[[0,1,0],[-1,0,1],[0,-1,0]],
      'A3_cycle':[[0,1,-1],[-1,0,1],[1,-1,0]],
      'Markov':[[0,2,-2],[-2,0,2],[2,-2,0]],
      'cycle_123':[[0,1,-3],[-1,0,2],[3,-2,0]],
      'acyclic_222':[[0,2,2],[-2,0,2],[-2,-2,0]],
      'skewsymmetrizable_cycle':[[0,2,-2],[-1,0,1],[2,-2,0]],
    }
    out={}
    for name,B in Bs.items():
      n=len(B); entries=[]
      for g in product(range(-2,2),repeat=n):
        co,st=recurrence(B,g,15)
        entries.append({'g':g,'size':len(co),'last':st[-1],'active_degrees':[s['degree'] for s in st if s['nonzero']]})
      out[name]=entries
      print(name,'count',len(entries),'live_at_15',sum(x['last']['nonzero']>0 for x in entries),'maxsize',max(x['size'] for x in entries),flush=True)
    with open('/workspace/scratch/184561e83b72/work/agent_division/recurrence_grid.json','w') as f:json.dump(out,f,indent=2)
if __name__=='__main__':main()
