"""Exact truncated mutation-atlas BFS. No unproved pruning of inactive steps.
Records any resource cutoffs explicitly; observed stabilization is not a proof.
"""
from itertools import product
from collections import deque
import random,time,json,argparse
from truncated_atlas import symmetrizer,identity,update_transform
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E

def total_exponents(n,degree):
    return sorted((p for p in product(range(degree+1),repeat=n)if sum(p)<=degree),key=lambda p:(sum(p),p))

def atlas_total(B,g,degree,maxdepth,seed_cap=200000,bit_cap=16384):
    n=len(B);D=symmetrizer(B);ee=total_exponents(n,degree);idx={p:i for i,p in enumerate(ee)}
    I=identity(len(ee));E0=initial_E(B)
    # Intern every truncated transform once; queue entries hold integer IDs.
    transforms=[I];transform_index={I:0};representatives=[()];cache={}
    q=deque([(E0,0,(),-1)]);seen={E0:0};levels={};pruned_bits=0;pruned_limit=0;duplicate_checks=0;sign_checks=0
    active_roots=set();maxbit=0;edges=0;inactive=0
    while q:
        E,tid,path,last=q.popleft();lev=len(path)
        st=levels.setdefault(lev,{'seeds':0,'new_transforms':0,'active_edges':0,'inactive_edges':0})
        st['seeds']+=1
        if lev>=maxdepth:continue
        for k in range(n):
            if k==last:continue
            EE=mutate_matrix(E,k)
            bit=max(abs(v).bit_length()for row in EE for v in row);maxbit=max(maxbit,bit)
            if bit>bit_cap:pruned_bits+=1;continue
            c=tuple(E[n+i][k]for i in range(n));sign_checks+=1
            if any(v>0 for v in c) and any(v<0 for v in c):raise AssertionError(('sign incoherence',E,k))
            active=sum(abs(v)for v in c)<=degree
            if active:
                active_roots.add((c,D[k]));st['active_edges']+=1
                key=(tid,c,D[k])
                if key in cache:ntid=cache[key]
                else:
                    TT=update_transform(B,D,g,E,transforms[tid],k,ee,idx)
                    ntid=transform_index.get(TT)
                    if ntid is None:
                        ntid=len(transforms);transform_index[TT]=ntid;transforms.append(TT);representatives.append(path+(k,))
                        levels.setdefault(lev+1,{'seeds':0,'new_transforms':0,'active_edges':0,'inactive_edges':0})['new_transforms']+=1
                    cache[key]=ntid
            else:inactive+=1;st['inactive_edges']+=1;ntid=tid
            if EE in seen:
                duplicate_checks+=1
                if seen[EE]!=ntid:raise AssertionError(('same extended matrix, different truncated operator',EE,seen[EE],ntid,path+(k,)))
                continue
            if len(seen)>=seed_cap:pruned_limit+=1;continue
            seen[EE]=ntid;edges+=1
            q.append((EE,ntid,path+(k,),k))
    last_new=max((lev for lev,st in levels.items()if st['new_transforms']),default=0)
    result={'rank':n,'B':B,'g':g,'symmetrizer':D,'degree':degree,'word_length_bound':maxdepth,'seed_count':len(seen),'transforms':len(transforms),'active_roots':len(active_roots),'last_new_transform_depth':last_new,'levels':levels,'inactive_edges':inactive,'edges':edges,'pruned_bit_limit':pruned_bits,'pruned_seed_limit':pruned_limit,'max_entry_bits':maxbit,'transform_representatives':representatives,'duplicate_operator_checks':duplicate_checks,'sign_coherence_checks':sign_checks}
    return result,ee,transforms

def study(degree=3,max_rank3_depth=12,max_rank4_depth=8):
    rng=random.Random(202611130435);samples=[]
    # All connected skew-symmetric rank-three matrices with positive nonzero
    # edge magnitudes 1 or 2, modulo reversal and a fixed first edge sign.
    for a,b,c in product([1,2],[-2,-1,1,2],[-2,-1,1,2]):
        B=[[0,a,b],[-a,0,c],[-b,-c,0]];samples.append(('skew_rank3_'+str((a,b,c)),B))
    # Additional higher-rank and skew-symmetrizable data, retaining D explicitly.
    for z in range(12):
        n=4;D=[1]*n if z<6 else [rng.randint(1,3)for _ in range(n)];B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                a=rng.choice([-1,0,1]);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
        samples.append(('rank4_'+str(z),B))
    out=[];start=time.time()
    for name,B in samples:
        n=len(B);g=[-1]*n;dep=max_rank3_depth if n==3 else max_rank4_depth
        t=time.time();res,_,_=atlas_total(B,g,degree,dep);res['name']=name;res['seconds']=time.time()-t;out.append(res)
        print(name,'seeds',res['seed_count'],'T',res['transforms'],'lastnew',res['last_new_transform_depth'],'cut',res['pruned_seed_limit'],res['pruned_bit_limit'],'sec',round(res['seconds'],3),flush=True)
    data={'degree':degree,'cases':len(out),'total_seeds':sum(x['seed_count']for x in out),'seconds':time.time()-start,'results':out}
    fn='/workspace/scratch/184561e83b72/work/agent_division/atlas_bfs_degree'+str(degree)+'.json';json.dump(data,open(fn,'w'),indent=2)
    print('SAVED',fn,'total_seeds',data['total_seeds'],'seconds',data['seconds'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--degree',type=int,default=3);p.add_argument('--rank3-depth',type=int,default=12);p.add_argument('--rank4-depth',type=int,default=8);a=p.parse_args();study(a.degree,a.rank3_depth,a.rank4_depth)
