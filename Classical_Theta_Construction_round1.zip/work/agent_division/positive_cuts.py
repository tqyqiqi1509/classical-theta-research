"""Finite coefficient cuts from principal-coefficient mutations.
For any chosen frozen-degree box this computes exact linear inequalities
necessary for Laurent positivity, without knowing a candidate theta function.
"""
from math import comb
from collections import defaultdict
from exact_laurent_mutation import initial_E,from_F
from principal_cluster import mutate_matrix

def generalized_binomial(r,j):
    if r>=0:return comb(r,j) if j<=r else 0
    return (-1)**j*comb(-r+j-1,j)

def series_mutate(E,poly,k,frozen_cap):
    n=len(E[0]);N=len(E);u=tuple(max(E[i][k],0)for i in range(N));v=tuple(max(-E[i][k],0)for i in range(N))
    if all(x==0 for x in u[n:]):L,R=u,v
    elif all(x==0 for x in v[n:]):L,R=v,u
    else:raise ArithmeticError('No coefficient-free exchange summand at this step')
    delta=tuple(a-b for a,b in zip(R,L));cy=delta[n:]
    if not any(cy):raise ArithmeticError('Zero coefficient column: use a different expansion')
    out=defaultdict(int)
    for a,c in poly.items():
      r=a[k]
      lim=min((frozen_cap[h]-a[n+h])//cy[h]for h in range(len(cy))if cy[h])
      if r>=0:lim=min(lim,r)
      for j in range(lim+1):
        s=generalized_binomial(r,j)
        if not s:continue
        aa=[a[h]+r*L[h]+j*delta[h]for h in range(N)];aa[k]=-r
        if any(aa[n+h]<0 or aa[n+h]>frozen_cap[h] for h in range(len(cy))):continue
        out[tuple(aa)]+=c*s
    return mutate_matrix(E,k),{a:c for a,c in out.items()if c}

def transform_series(B,g,coef,path,cap):
    E=initial_E(B);f=from_F(B,g,{e:c for e,c in coef.items()if all(e[j]<=cap[j]for j in range(len(cap)))})
    for k in path:E,f=series_mutate(E,f,k,cap)
    return E,f

def coefficient_cut(B,g,path,target):
    """Return integer map e->weight with coef_target=sum_e weight*initial_a[e]."""
    from itertools import product
    n=len(B);cap=target[n:];cut={}
    for e in product(*(range(c+1)for c in cap)):
      E,f=transform_series(B,g,{e:1},path,cap)
      c=f.get(target,0)
      if c:cut[e]=c
    return cut

if __name__=='__main__':
    B=[[0,1,-1],[-1,0,1],[1,-1,0]]
    print(coefficient_cut(B,(-1,-1,-1),(0,1),(-1,2,-1,1,1,1)))
