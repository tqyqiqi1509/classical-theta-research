# Positive division, coefficient cuts, and finite-degree mutation operators

Research notes, started 2026-11-13 04:13 UTC. These notes do **not** assert a higher-rank greedy basis theorem or identify a new family with theta functions. The results below are elementary algebraic/combinatorial identities intended to supply the missing positive-division mechanism. No conclusion from Li--Pan is used.

## 1. Exact positive binomial division is a finite dimer problem

Let `f(t)=sum_{j=0}^N f_j t^j` with `f_j` nonnegative integers. Write `f_j` as a row of that many distinct tokens at level j. A dimer consists of one token at level j and one token at level j+1, and contributes `t^j(1+t)`.

**Proposition 1.** There is a partition of all tokens into such dimers if and only if `f=(1+t)q` for a polynomial q with nonnegative integer coefficients. Its dimer multiplicities are uniquely determined by

`q_{-1}=0`, `q_j=f_j-q_{j-1}` for `0<=j<=N`, with `q_N=0`.

**Proof.** Each token at level j either ends a dimer starting at j-1 or begins a dimer starting at j. Thus `f_j=q_{j-1}+q_j`. This determines q recursively. If all q_j are nonnegative and q_N=0, pair the incoming `q_{j-1}` tokens at level j with any fixed first `q_{j-1}` tokens, and use the remaining q_j tokens as starts for level j+1. Conversely a partition gives these equations and nonnegative q. A deterministic order on the tokens makes this an explicit algorithm. The condition at the top level cannot be omitted.

**Corollary 2.** For m>=0, `f=(1+t)^m q` with `q>=0` integral if and only if m successive dimer divisions succeed. This is equivalently a partition of the weighted token multiset into m-dimensional Boolean cubes whose generating functions are `t^a(1+t)^m`.

**Proof.** If the final quotient is nonnegative, all intermediate quotients `(1+t)^{m-s}q` are nonnegative. Conversely compose the m dimer partitions: each final token has 2^m leaves with multiplicities binomial(m,j) at level a+j. All steps and leaves are finite.

This does not solve compatibility between *different* mutable colors. It supplies a necessary and sufficient local certificate, not the promised global object construction.

`binomial_matching.py` implements this. Exhaustive comparison with independent signed exact polynomial division used 65,535 input polynomials, coefficients in {0,1,2,3}, degree <=7, divisors `(1+t)^m` with 1<=m<=min(4,degree+1): 262,059 cases, 2,087 successes, no discrepancy.

## 2. Arbitrary-rank positive mutation reduces to these fibers

For geometric coefficients, write the exchange relation as `x_k x'_k=M_++M_-`, with both monomials independent of x_k. Split a Laurent polynomial into its x_k slices, `f=sum_r x_k^r f_r`. Mutation changes that slice to `x_k'^{-r}(M_++M_-)^r f_r`.

For r>=0 there is a direct expansion by r binary choices. For r=-m<0, positivity of the mutated slice is precisely positive divisibility of f_r by `(M_++M_-)^m`. Partition the exponent lattice of the other variables into cosets of `Z(delta)`, where delta=exponent(M_+)-exponent(M_-). On each coset remove a monomial factor and put `t=z^delta`; the divisor becomes `(1+t)^m`. Proposition 1 and Corollary 2 apply. This works without any restriction on rank or on a symmetrizer. A nonprimitive delta simply means more lattice cosets. If delta=0, the exchange factor is twice a monomial and integer divisibility by 2^m must also be checked.

`exact_laurent_mutation.py` implements the exact signed quotient as an independent oracle. It explicitly rejects a nonzero remainder or a nonintegral quotient.

## 3. Principal coefficient tables and the one-step constraints

Fix an n by n exchange matrix B, independent frozen variables y_1,...,y_n, and `hat y_i=y_i x^{B[:,i]}`. For an integer vector g, consider

`f=x^g F(hat y)`, `F(y)=sum_{p>=0} a_p y^p`, `a_0=1`.

Fix direction k and a vector q with q_k=0. Let

`r_k(q)=g_k+sum_j b_kj q_j`, `m_k(q)=max(-r_k(q),0)`.

Since b_kk=0, r_k is constant along this k-fiber. Positivity in the initial chart and its k-neighbor is equivalent, fiber by fiber, to

`sum_{j>=0} a_{q+j e_k} t^j=(1+t)^{m_k(q)}Q_{k,q}(t)`, `Q_{k,q}(t)>=0`,

with finite Q when F is finite. The formal quotient coefficients are

`[t^s]Q=sum_{j=0}^s (-1)^j binom(m+j-1,j) a_{q+(s-j)e_k}` for m>0.

Thus choosing a_p as the maximum of the directional lower bounds is a natural *candidate* recurrence. It is not a proof of finite support, global positivity, pointedness after normalization at other seeds, or a basis theorem.

## 4. A general two-step cut, with no finite-type assumption

Let `b_kl=a>0`, `b_lk=-d<0`, and `q_k=q_l=0`. Write `r_i=r_i(q)`. Apply mutations k and then l while keeping the original frozen variables y fixed. The second exchanged c-vector is `e_l+a e_k`.

**Proposition 3.** In the formal frozen-variable expansion after these two mutations, the coefficient of frozen degree `p=q+a e_k+e_l` is

`sum_{j=0}^a binom(r_k+a,a-j) a_{q+j e_k+e_l} + (r_l+d r_k)a_q`.  (4.1)

The mutable monomial multiplying this coefficient is uniquely specified by homogeneity. The binomial coefficient has its ordinary integer extension to negative upper index. Universal Laurent positivity implies that (4.1) is nonnegative.

**Proof.** The first mutation has a coefficient-free exchange summand, and its other summand has frozen degree e_k. The second has a coefficient-free summand and its other summand has frozen degree `a e_k+e_l`. To arrive at p, a term already having frozen l-degree 1 must start at `q+j e_k+e_l` for 0<=j<=a, use a-j nonconstant summands in the first binomial expansion, and no nonconstant summand in the second. Its x_k exponent before the first mutation is r_k+a, giving the first sum. A term with frozen l-degree 0 can only start at q, use no nonconstant summand in the first expansion, and exactly one in the second. Substitution of the coefficient-free first exchange monomial changes its x_l exponent from r_l to `r_l+d r_k`; this yields the last term. No other initial frozen degree can contribute. Homogeneity ensures all contributions multiply the same mutable monomial. This is an exact coefficient identity, independent of positivity.

183 randomly chosen skew-symmetrizable matrices of ranks 2--5, symmetrizers with entries in {1,2,3}, integer g and q were checked independently using `positive_cuts.py`; no discrepancy. This check is not the proof.

## 5. The cyclic A3 diagnostic

Take

`B=[[0,1,-1],[-1,0,1],[1,-1,0]]`, `g=(-1,-1,-1)`.

The mutation sequence (1,2,3,1), indexed here from 1, has final g-vectors `(0,-1,0),(-1,0,0),(0,0,-1)` and F-polynomials

`1+y2+y2*y3`, `1+y1+y1*y2`, `1+y3+y1*y3`.

Their product is a cluster monomial with g=(-1,-1,-1), so its F-polynomial is

`F0=(1+y1+y1*y2)(1+y2+y2*y3)(1+y3+y1*y3)`.

In particular `[y1*y2*y3]F0=4`. The direct one-step-max candidate gives a_001=1, a_011=2, a_111=2. Proposition 3 with k=1,l=2,q=e_3 says instead

`a_111-a_011-2*a_001>=0`, hence `a_111>=4`.

The candidate therefore does not produce the required cluster monomial, without any need to infer infinite support from a finite truncation. Continued nonzero terms in the degree-15 experiment are not claimed to prove divergence.

The polytope agent separately found finite tables satisfying all one-step *Laurent positivity* conditions with a_111=2 or 3. `exact_laurent_mutation.py` shows each acquires a negative coefficient after (1,2): the term is

`x1'^{-1} x2''^2 x3^{-1} y1 y2 y3`,

with coefficient -2 or -1, respectively. These examples **do not** satisfy all principal-coefficient renormalized pointedness/degree constraints. They must not be cited as counterexamples to Li--Pan's complete construction or to any theorem with those stronger hypotheses.

The Wolfram Language evaluator independently returned `[y1*y2*y3]F0=4`. Exact input was the product displayed above; no numerical approximation was used.

## 6. Single-step operators in bounded frozen degree

Let C_t and G_t be principal c- and g-matrices. Fix an initial homogeneous degree g. At any seed, a homogeneous formal expression with nonnegative initial frozen degrees has the form

`f_t=sum_p A_{t,p} x_t^{G_t^{-1}(g+Bp)} y^p`.

For a mutation k, write c=C_t[:,k], epsilon=its sign, alpha=epsilon*c>=0. In a computed sign-coherent path the exchange binomial has one coefficient-free summand and one with frozen degree alpha. The standard elementary matrix identities are

`G_t B_t=B C_t`, `G_t^{-1}=D^{-1} C_t^T D`,

where DB is skew-symmetric. The latter follows algebraically from sign-coherent C/G recurrences; see Nakanishi--Zelevinsky (2012), Theorem 1.2 and identities (2.7)--(2.9). We use the formulas with the convention b_ij above.

**Proposition 4.** The exact coefficient transform is

`A_{t',p}=sum_{j>=0} binom(lambda_c(p),j) A_{t,p-j*alpha}`,

`lambda_c(p)=c^T D(g+Bp)/D_kk`.

The sum is finite for each p>=0. The upper index is independent of j because `(G_t^{-1} B c)_k=(B_t)_{kk}=0`.

**Proof.** Apply the binomial theorem to the current x_k exponent of each term and use the unique mutable exponent determined by homogeneity. The nonconstant summand increments the frozen degree by alpha, so only the stated terms can contribute. Substitute tropical duality to express the x_k exponent; its pairing with alpha is zero by the first matrix identity. All expressions are integral because they are current mutable exponents.

In the skew-symmetric case, lambda is simply `epsilon*alpha dot (g+Bp)`. The operator depends only on the bounded c-vector, its sign, the label's root length D_kk, and the initial data B,g. It does not require the other potentially huge current matrix entries. With respect to total frozen degree it is a unipotent triangular integer matrix.

On a total-degree cutoff N, a step with `sum_i |c_i|>N` is exactly the identity on the coefficient table (its mutable monomial change has already been absorbed into the homogeneous normalization). This statement permits dropping that step from the *operator product*, but not pruning its seed descendants: an inactive step can change which active c-vector becomes reachable next.

The inverse is the operator for -c with the same root length. One may equivalently write the action on a generating series F as

`(1+y^alpha)^lambda_c(0) F(y_i*(1+y^alpha)^lambda_i)`,

where `lambda_i=c^T D B[:,i]/D_kk`. This identity is an algebraic operator formula, not a substitute definition of theta functions.

## 7. The next construction question

The foregoing gives an exact finite integer transform for every chosen mutation word and cutoff. For each nonzero p, all chart positivity inequalities have the form `A_p+L_{word,p}(A_{<p})>=0`. The tentative saturation rule is

`A_0=1`, `A_p=max(0,sup_word(-L_{word,p}(A_{<p})))`.

If this exists, and the sup is attained, it is intrinsically characterized by nonnegative coefficients in every chart plus at least one zero coefficient in some chart at every nonzero frozen degree. It recovers any cluster monomial: in the chart containing that monomial every nonzero frozen-degree coefficient vanishes, and induction on degree forces equality with its known expansion.

This is not yet a finite algorithm or a basis construction. Missing points include: a purely integer finite-state normal form for all active c-vector words; boundedness/attainment of the sup; finite Laurent support; identification with theta or an independent basis and multiplication theorem. A finite list of possible active roots is not enough: repeated words can in general generate unbounded integer powers and commutators.

Current implementation: `truncated_atlas.py` (box cutoff), `atlas_bfs_study.py` (total-degree cutoff), `positive_cuts.py` (individual exact linear certificate). The BFS never prunes a branch merely because its next step is inactive. Any resource pruning is explicitly recorded.

## 8. Source and route log

- Lee--Li--Zelevinsky, *Greedy elements in rank 2 cluster algebras*, arXiv:1208.2391v3, read Proposition 1.5, Lemma 2.1 and their proofs. Useful: binomial coefficient inequalities from adjacent positive Laurent expansions. It does not prove higher-rank positive division or all-seed positivity from one-step positivity.
- Sherman--Zelevinsky, *Positivity and canonical bases in rank 2 cluster algebras of finite and affine types*, arXiv:math/0307082, Remark 5.8 located; LLZ quotes it explicitly. A finite set of charts does not characterize unrestricted universal positivity even for A(2,2). This does not by itself refute finite-degree bounds for a fixed g and coefficient support.
- Berenstein--Fomin--Zelevinsky, *Cluster algebras III*, arXiv:math/0305434v3, definition of upper bound and mutation invariance scope checked. Laurent membership and positivity are different statements; upper-bound equality supplies no positive-quotient theorem.
- Nakanishi--Zelevinsky, *On tropical dualities in cluster algebras*, arXiv:1101.3736v3, Theorem 1.2, Proposition 1.3 and (2.7)--(2.9) read. Useful elementary matrix recurrence proof conditional in the original paper on sign coherence. The code verifies sign coherence on every computed step; the general classical sign-coherence theorem is separate background.
- 2026 higher-rank greedy/positive-division searches: no verified new general independent construction located in this route. Li--Pan search results were treated as claims and passed to the independent polytope agent, not as input theorems.
- Direct directional max recurrence: rejected as a global construction by the exact A3 cluster-monomial comparison. Its fiber inequalities remain useful.
- Boolean/dimer fibers: complete local result; compatibility between colors unresolved.
- All-word saturation and bounded active c-vectors: ongoing positive route, not declared solved.

### 04:33 UTC route review (about 20 minutes after this subtask began)

The one-step max route is decisively insufficient. The constructive route is now the exact finite-degree mutation operator together with active-word collection. A broad BFS at total degree 3 covered 299,501 states across 44 matrices; 11,470 repeated extended-matrix visits were independently checked to have the same truncated operator, and all 310,927 traversed c-columns were checked for sign coherence. This strengthens the computation but does not prove a finite-state theorem. No branch was deleted merely for being inactive.

The separate rank-four extension covered exactly 3,769,009 states to word length 12 (12 matrices). At degree 3 it saw 28--162 operator types per matrix; four examples first acquired additional types at depths 9--10. Thus a short plateau is not a stopping certificate. The extended run predates the repeated-E consistency check; its basic operator formula is the same.

A useful correction from the mechanism agent: the apparent root-length label in Proposition 4 is determined by c. Since the row `(c_i D_ii / D_kk)_i` of G^{-1} is integral and primitive, `D_kk=gcd_i(|c_i|D_ii)`. Hence the operator alphabet is indexed by signed c alone.

Repeated absolute roots cannot simply be erased from active words. For example, a shortest first-seen representative in rank four has active word `(e1,e2,e2+e3,-e1)`. Nonadjacent cancellation would discard a nontrivial commutator. A degree filtration/collection rule is needed.

## 9. A genuine finite normal form in total frozen degree one

Assume the ordinary sign-coherence and tropical-duality identities for the principal pattern. In total degree <=1, the only active columns are c=+e_i or c=-e_i. The i-th row of G is sign-coherent. Along a mutation in column k, only the k-th entry of that row changes. Consequently its sign can change only if all other entries in that row vanish. As G is unimodular, the remaining entry is +1 or -1. Tropical duality then forces c_k=+e_i or -e_i, respectively; conversely these columns force exactly this situation and the mutation reverses the row sign. The signs +e_i and -e_i therefore alternate whenever that root is active, starting with +e_i. Its net signed count is 0 or 1.

The degree-one operators commute modulo degree >=2. Thus every mutation word has, in degree <=1, a normal form consisting of at most one occurrence of each positive simple root. There are at most 2^n operator types, and the all-chart saturation coefficient is exactly `a_{e_i}=max(0,-g_i)`.

This proves the base case for a possible induction on truncation degree. The argument does not extend verbatim to nonsimple roots: a hyperplane with normal e_i+e_j can pass through the interior of another cluster cone, so its sign need not be encoded by one sign-coherent G-row.

## 10. Fresh-source check, 04:33--04:35 UTC

A search identified Qiu--Tang, *X-evolution flows/foliations for cluster algebras: partial Bongartz (co-)completions and acyclicity*, arXiv:2611.09155v1 (6 November 2026). The primary PDF and HTML were opened. Crucial hypothesis: Assumption 1.1 requires a green-to-red sequence throughout the paper. The abstract alone hides this scope. Section 5's x-order could be useful as a source of a potential function, but no theorem from this paper is used in the present notes: the proof has not received the requested full adversarial audit and the hypothesis does not cover arbitrary B. Its existence is a research lead only.

The mechanism agent located Lin--Musiker--Nakanishi, *Two Formulas for F-Polynomials*, arXiv:2112.11839 (IMRN 2024), as an earlier algebraic source for generalized-binomial formulas along a fixed finite word. The finite-word formula must not be promoted to a theorem that all words admit finitely many truncated normal forms. The source is being read by that agent.

### Dependency correction and final BFS cross-check

The degree-one normal form uses **global c-sign coherence as an external standard theorem**. The g-row sign-coherence follows from Nakanishi--Zelevinsky's opposite-initial-seed duality `G^T=C_{t0}^{B_t^T;t}`. Their matrix recurrence proof is algebraic given c-sign coherence; these notes do not independently prove general c-sign coherence by pure combinatorics. Similarly, the statement that saturation recovers cluster monomials uses their known universal Laurent positivity. These dependencies must not be hidden if these notes are later used in a proof claiming to be wholly combinatorial. The exact finite-word coefficient identities, by contrast, can be verified on each computed word without appealing to a global theorem: every c-column is checked directly.

The full rank-four BFS was repeated with consistency verification at duplicate extended matrices and sign verification at every traversed column. Results are unchanged: exactly 3,769,009 states, no resource pruning, no operator inconsistency, no sign-coherence failure. The JSON result includes the precise duplicate and sign-check counts.

## 11. Correction to the principal-direction max interpretation

The principal-g fiber maximum in Section 3 is a natural local constraint, but is not literally LLZ's original rank-two recursion. In the LLZ denominator-pointed expansion one coordinate is reversed when converting to a principal g-normalized F-polynomial, so the finite top boundary matters. An exact rank-two A2 diagnostic already shows the difference: B=[[0,1],[-1,0]], g=(-3,2), and F=(1+y1)^2(1+y1+y1*y2). Local principal-direction minimization gives coefficient a11=0, while the correct coefficient is 1, and the two-step cut a11-2a01-a00>=0 forces that value. The A3 test remains valid, but must not be described as a counterexample to the genuine rank-two LLZ construction.

At total degree two the genuine rank-two envelope (using LLZ, not the local simplified formula) matched all tested full-rank saturation constraints: 352 data sets, 44 matrices with eight g-vectors each, 1,752,872 seed states, zero mismatch. This is an experimentally supported construction mechanism, not a general theorem. The target proof is that the worst degree-two constraints are attained in a rank-two subpattern, even if the entire full-rank active-word image has more operators.
