#!/usr/bin/env python3
"""Compare finite slot graphs with independently reconstructed least packets."""
from boolean_slots import *
from fractions import Fraction
import argparse

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--max-D',type=int,default=12)
    ap.add_argument('--seconds',type=float,default=20);ap.add_argument('--count',type=int,default=100)
    ap.add_argument('--min-D',type=int,default=0);ap.add_argument('--outfile',default='slot_sweep_results.json')
    ap.add_argument('--local',action='store_true')
    args=ap.parse_args();folder=Path(__file__).parent;tic=time.time();out=[]
    src=json.loads((ROOT/'agent_packet_propagation'/'mandatory_support_results.json').read_text())
    cases=src['results'];stats=defaultdict(int)
    for ci,c in enumerate(cases[:args.count]):
        B=c['B'];g=c['g'];d=c.get('d')
        if d is None:d=acyclic_dimension(B,g)[0]
        if sum(d)>args.max_D or sum(d)<args.min_D:stats['dimension_skips']+=1;continue
        P=c.get('F')
        if P is None:raise KeyError(('no polynomial',ci,c.keys()))
        if isinstance(P,list) and P and isinstance(P[0],dict):
            F={tuple(z['p']):int(z['a'])for z in P}
        else:F={tuple(p):int(Fraction(*a))if isinstance(a,list)else int(a)for p,a in P}
        G=SlotSystem(B,g,d)
        _,old,C=G.fixed_rule('last')
        search,members,active=G.solve(F=F,seconds=args.seconds,local=args.local)
        rec={'i':ci,'B':B,'g':g,'d':d,'F':dump_table(F),'last_mass':len(old),'least_mass':sum(F.values()),
             'fixed_rule_equals':C==F,'search':search}
        stats['attempted']+=1;stats['fixed_rule_equal']+=int(C==F)
        if members is not None:
            stats['realizations']+=1
            stats['connected']+=int(search['verified']['connected'])
            rec['members']=sorted(members)
            rec['active']=[[k,off,a] for(k,off),a in sorted(active.items())]
        else:stats['infeasible'if search['status']==2 else 'resource_cut']+=1
        out.append(rec)
        (folder/args.outfile).write_text(json.dumps({'stats':dict(stats),'seconds':time.time()-tic,'results':out},indent=2))
        print(ci,'rank',len(g),'d',d,'last',len(old),'least',sum(F.values()),'search',search['status'],search['seconds'],dict(stats),flush=True)
    print('DONE',dict(stats),'seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
