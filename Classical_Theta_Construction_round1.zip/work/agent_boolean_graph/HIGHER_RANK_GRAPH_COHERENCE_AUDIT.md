# What higher-rank graph coherence does and does not supply

Primary-source audit, 2026-11-13, for the finite packet graph project.

## The applicable general theorem

Fowler and Sims, *Product systems over right-angled Artin semigroups*,
Theorems 2.1 and 2.2, give a construction from pair interchange maps
which are inverse in opposite orders and satisfy the three-generator
hexagon equation. The construction is unique up to the indicated
isomorphism. The graph specialization appears in their Remark 2.3.

Primary PDF: https://www.aidansims.com/papers/FS1999.pdf

Hazlewood, Raeburn, Sims and Webster give an explicit graph version:
a complete collection of commuting squares satisfying the three-color
associativity condition determines a higher-rank graph, uniquely up
to a square-preserving skeleton isomorphism. See Section 3, equation (3.2),
Theorems 4.4 and 4.5, Lemma 4.6 and Proposition 4.7.

Primary PDF: https://arxiv.org/pdf/1110.2269

The combinatorial content used here is only this factorization theorem;
none of the associated operator-algebra results is needed.

## The finite critical-pair proof in our language

Suppose elementary operations have colors, and for every two distinct
colors i,j we have a specified bijection between ALL composable paths
ij and ji, preserving both endpoints. Opposite-order bijections must
be inverse. Sort color words using these bijections.

The number of inversions decreases at every sorting step. Disjoint
swaps commute. The only overlapping ambiguities involve a strictly
descending triple of different colors. Equality of its two three-swap
routes is exactly the cubic/hexagon condition. It follows that sorting
has a unique normal form and the resulting composition is associative.
No genuinely new four-color ambiguity appears.

This elementary rewriting proof explains why a concrete three-color
transport lemma, once properly formulated and verified, can give an
all-rank coherence theorem. The statement assumes COMPLETE specified
bijections, not merely equality of numbers, equality of characters, or
separate existence of arbitrary pair matchings.

## Why it cannot be imposed on the original bit edges

The smallest adjacent-color greedy graph already violates completeness.
For

    B=[[0,1],[-1,0]], d=(1,1), g=(-1,0),

its Boolean graph has vertices 00,10,11 and edges

    00 --color0-- 10 --color1-- 11.

There is a path of colors 01 from 00 to11, but no path of colors 10
with those endpoints. Thus there is no complete commuting-square
bijection even in this rank-two finite-type example. Demanding a
higher-rank-graph skeleton structure on all original packet edges
would exclude an actual greedy/theta element.

The literal commuting-square condition remains correct for NONADJACENT
exchange colors. Adjacent colors require their rank-two greedy models,
not commutative squares of individual active-bit edges.

## A valid application: the marked deletion operations

The selected/unselected marking construction in
MARKED_DIVIDED_POWER_FUNCTOR.md gives a different colored operation
graph. Its colors can be refined to the individual original slots.
Two deletions interchange by remembering which original slots were
marked and their selected/unselected types. Both orders end at the
same restricted graph because the prefix rule depends only on the
UNION of the marks. Three deletions therefore satisfy the cubic
condition literally. Repeated marks of the same quiver color have
the divided-power multiplicities stated in that note.

This operation diagram is coherent in all ranks. The theorem does
not establish that its components are canonical theta objects.

## What would still be needed for mutation

The packet replacement and whole-packet reconnection operation in
CUBICAL_COHERENCE_AND_MUTATION.md is not yet a system of complete
commuting operation bijections. Mutation changes the exchange matrix;
adjacent mutations do not simply commute. Therefore the cited theorem
cannot be applied to mutation words without specifying the appropriate
objects, domains and actual path interchange maps.

A genuine use would provide explicit pair transport maps, prove their
compatibility with marked restrictions, and then identify and prove
the correct three-operation critical-pair relations. It would be
incorrect to infer these maps from rank-two character positivity or
to call the unproved three-color transport axiom a theorem.
