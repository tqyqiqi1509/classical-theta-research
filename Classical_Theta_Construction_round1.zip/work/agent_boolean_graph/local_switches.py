#!/usr/bin/env python3
"""Local active-coordinate flips on the exact cube, with strict component descent."""
from boolean_slots import *
from itertools import combinations

def descend(G,active,cap=1000,subset_only=True):
    current=G.component(active);steps=[];inspected=0
    for step in range(cap):
        options=[]
        touched={(k,v&~G.masks[k])for v in current for k in range(G.n)}
        for k,off in sorted(touched):
            old=active[k,off];mask=G.masks[k]
            inside=[1<<(G.offsets[k]+i)for i in range(G.d[k])if old&(1<<(G.offsets[k]+i))]
            outside=[1<<(G.offsets[k]+i)for i in range(G.d[k])if not old&(1<<(G.offsets[k]+i))]
            for a in inside:
                for b in outside:
                    active[k,off]=old^a^b
                    C=G.component(active);inspected+=1
                    if len(C)<len(current) and (not subset_only or C<=current):
                        options.append((len(C),k,off,a,b,C))
            active[k,off]=old
        if not options:break
        options.sort(key=lambda z:z[:5]);size,k,off,a,b,C=options[0]
        active[k,off]^=a^b
        steps.append({'before':len(current),'after':size,'k':k,'off':off,'old_bit':a,'new_bit':b,
                      'removed':sorted(current-C),'added':sorted(C-current)})
        current=C
    return {'mass':len(current),'steps':steps,'inspected':inspected,'F':dump_table(G.character(current))},active

def plateau_search(G,active,target_mass,cap=100000):
    """Explore switches keeping the entire current member set invariant.

    State space finite; no finite cutoff is interpreted as an impossibility.
    We permit only switches in touched fibers and retain no enlargement.
    """
    initial=G.component(active);fibers=sorted({(k,v&~G.masks[k])for v in initial for k in range(G.n)})
    keys=[f for f in fibers if 0<active[f].bit_count()<G.d[f[0]]]
    start=tuple(active[f]for f in keys);seen={start};todo=deque([(start,[])])
    while todo:
        state,word=todo.popleft()
        for f,a in zip(keys,state):active[f]=a
        current=G.component(active)
        if len(current)<=target_mass:return {'found':True,'states':len(seen),'word':word,'mass':len(current)},active
        touched={(k,v&~G.masks[k])for v in current for k in range(G.n)}
        for j,(k,off) in enumerate(keys):
            if(k,off)not in touched:continue
            old=active[k,off]
            inside=[1<<(G.offsets[k]+i)for i in range(G.d[k])if old&(1<<(G.offsets[k]+i))]
            outside=[1<<(G.offsets[k]+i)for i in range(G.d[k])if not old&(1<<(G.offsets[k]+i))]
            for a in inside:
                for b in outside:
                    value=old^a^b;new=state[:j]+(value,)+state[j+1:]
                    if new in seen:continue
                    active[k,off]=value;C=G.component(active)
                    if C<=initial:
                        seen.add(new);todo.append((new,word+[[k,off,a,b,len(C)]]))
                        if len(C)<=target_mass:return {'found':True,'states':len(seen),'word':word+[[k,off,a,b,len(C)]],'mass':len(C)},active
                        if len(seen)>=cap:return {'found':False,'cut':'states','states':len(seen)},None
            active[k,off]=old
    return {'found':False,'exhausted':True,'states':len(seen)},None

def main():
    cases=[([[0,2,1],[-2,0,0],[-1,0,0]],(-4,6,2),58),([[0,0,1],[0,0,2],[-1,-2,0]],(-3,-2,3),98)]
    out=[]
    for B,g,mass in cases:
        G=SlotSystem(B,g);act,C,F=G.shadow_rule();r,act2=descend(G,dict(act));p,NoneVal=({},None)
        if r['mass']!=mass:p,act3=plateau_search(G,dict(act),mass,cap=20000)
        out.append({'B':B,'g':g,'d':G.d,'initial_mass':len(C),'target_mass':mass,'strict_descent':r,'plateau':p})
        print('CASE',B,g,'strict',r['mass'],'steps',len(r['steps']),'plateau',p,flush=True)
    (Path(__file__).parent/'local_switches_results.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
