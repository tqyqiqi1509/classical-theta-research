#!/usr/bin/env python3
"""Exact local color splitting and component inspection on a sparse graph."""
from local_closed_switch import *

def all_components(G,choices):
    todo=set(G.members);out=[]
    while todo:
        start=min(todo);C=G.component(choices,start)
        if not C<=todo:raise ArithmeticError('overlapping components')
        todo-=C;out.append(C)
    return out

def main():
    folder=Path(__file__).parent;R=json.loads((folder/'large_degree_exchange_results.json').read_text());B,g,d=R['B'],R['g'],R['d']
    G=ClosedLocalGraph(B,g,d,set(R['members']));lookup={(k,off):a for k,off,a in R['local_active']};base=[lookup[z['key']]for z in G.groups]
    out={'B':B,'g':g,'d':d,'mass':len(G.members),'colors':[]}
    for k in range(len(g)):
        choices=[(a&(a-1))if z['key'][0]==k and a else a for z,a in zip(G.groups,base)]
        data=[]
        for C in all_components(G,choices):
            F=G.character(C);root=tuple(min(p[i]for p in F)for i in range(G.n));mult=F.get(root,0)
            rec={'mass':len(C),'root':root,'root_multiplicity':mult,'pointed':mult==1}
            if mult==1:
                h=tuple(g[i]+int(i==k)+sum(B[i][j]*root[j]for j in range(G.n))for i in range(G.n))
                T={tuple(p[i]-root[i]for i in range(G.n)):a for p,a in F.items()};dh,_,_=acyclic_dimension(B,h)
                width=tuple(max(p[i]for p in T)for i in range(G.n))
                rec.update({'h':h,'standard_d':dh,'widths':width,'within_standard_box':all(a<=b for a,b in zip(width,dh)),'F':dump_table(T)})
            else:rec['F_unshifted']=dump_table(F)
            data.append(rec)
        out['colors'].append({'k':k,'components':data})
        print('COLOR',k,[(a['mass'],a['root'],a['pointed'],a.get('within_standard_box'))for a in data],flush=True)
    (folder/'large_pieri_split_results.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
