#!/usr/bin/env python3
"""Find a local active-slot subgraph with prescribed counts inside a known graph.

Only vertices in degrees whose counts change are binary variables. Directions
that would move any mandatory retained state outside the ambient member set
are eliminated before MILP. Every output is checked by exact bit operations.
"""
from local_closed_switch import *

def realize(B,g,d,C,F,seconds=60):
    tic=time.time();G=ClosedLocalGraph(B,g,d,C,check_closed=False);H=G.character(C);F={tuple(p):int(a)for p,a in F.items()if a}
    if any(F.get(p,0)>a for p,a in H.items())or any(p not in H for p in F):raise ValueError('target not coefficientwise below ambient')
    by_degree=defaultdict(list)
    for v,p in G.degrees.items():by_degree[p].append(v)
    var_h={};fixed={};count=0
    for p,vs in by_degree.items():
        a=F.get(p,0)
        if a==0:
            for v in vs:fixed[v]=0
        elif a==len(vs):
            for v in vs:fixed[v]=1
        else:
            for v in vs:var_h[v]=count;count+=1
    grouped=defaultdict(list)
    for v in C:
        for gid in G.vertex_groups[v]:grouped[gid].append(v)
    activation={};fixed_a={};potential={}
    for gid,group in enumerate(G.groups):
        k,_=group['key'];c=group['c']
        if c==0:fixed_a[gid]=0;continue
        fixed_ones=[v for v in grouped[gid]if fixed.get(v)==1]
        bits=[1<<(G.offsets[k]+i)for i in range(d[k])]
        allowed=[bit for bit in bits if all((v^bit)in C and fixed.get(v^bit,1)!=0 for v in fixed_ones)]
        if len(allowed)<c:return {'status':'fixed states contradict locality','group':group['key'],'c':c,'allowed':len(allowed)},None,None
        if len(allowed)==c:fixed_a[gid]=sum(allowed)
        else:
            activation[gid]={}
            for bit in allowed:activation[gid][bit]=count;count+=1
            potential[gid]=allowed
    rr=[];cc=[];vv=[];lo=[];hi=[]
    def row(terms,L,U):
        vals=defaultdict(int);const=0
        for key,a in terms:
            if isinstance(key,tuple)and key[0]=='v':
                v=key[1]
                if v in var_h:vals[var_h[v]]+=a
                else:const+=a*fixed.get(v,0)
            else:vals[key]+=a
        vals={k:a for k,a in vals.items()if a}
        L-=const;U-=const
        if not vals:
            if not L<=0<=U:raise ArithmeticError(('contradictory fixed row',L,U))
            return
        r=len(lo)
        for k,a in vals.items():rr.append(r);cc.append(k);vv.append(a)
        lo.append(L);hi.append(U)
    for p,vs in by_degree.items():
        if vs[0]in var_h:row([(('v',v),1)for v in vs],F.get(p,0),F.get(p,0))
    for gid,ai in activation.items():
        c=G.groups[gid]['c'];row([(col,1)for col in ai.values()],c,c)
    for gid,group in enumerate(G.groups):
        k,_=group['key']
        if gid in fixed_a:
            am=fixed_a[gid];bits=[]
            while am:bit=am&-am;am-=bit;bits.append((bit,None))
        else:bits=list(activation[gid].items())
        for bit,a in bits:
            for v in grouped[gid]:
                w=v^bit
                if w in C and v>w:continue
                if a is None:row([(('v',v),1),(('v',w),-1)],0,0)
                else:
                    row([(('v',v),1),(('v',w),-1),(a,1)],-np.inf,1)
                    row([(('v',w),1),(('v',v),-1),(a,1)],-np.inf,1)
    A=coo_matrix((np.array(vv,float),(rr,cc)),shape=(len(lo),count)).tocsc()
    report={'variables':count,'vertex_variables':len(var_h),'activation_groups':len(activation),'rows':len(lo),'build_seconds':time.time()-tic}
    print('MODEL',report,flush=True)
    result=milp(np.zeros(count),integrality=np.ones(count),bounds=Bounds(0,1),constraints=LinearConstraint(A,lo,hi),options={'time_limit':seconds,'mip_rel_gap':0})
    report.update({'status':int(result.status),'message':result.message,'seconds':time.time()-tic,'nodes':getattr(result,'mip_node_count',None)})
    if result.x is None:return report,None,None
    z=[int(round(a))for a in result.x]
    if any(abs(a-b)>1e-6 for a,b in zip(z,result.x)):raise ArithmeticError('nonintegral solution')
    members={v for v in C if fixed.get(v,z[var_h[v]] if v in var_h else 0)}
    choices=[]
    for gid in range(len(G.groups)):
        if gid in fixed_a:choices.append(fixed_a[gid])
        else:choices.append(sum(bit*z[col]for bit,col in activation[gid].items()))
    for gid,group in enumerate(G.groups):
        if choices[gid].bit_count()!=group['c']:raise ArithmeticError('wrong cube dimension')
    for v in members:
        for gid in G.vertex_groups[v]:
            am=choices[gid]
            while am:
                bit=am&-am;am-=bit
                if(v^bit)not in members:raise ArithmeticError('output not closed')
    if G.character(members)!=F:raise ArithmeticError('wrong coefficient counts')
    comp=G.component(choices)
    if not comp<=members:raise ArithmeticError('origin component exits members')
    report['verified']={'mass':len(members),'origin_mass':len(comp),'connected':comp==members,'local':True}
    return report,members,G.actual_active(choices)

def main():
    folder=Path(__file__).parent;R=json.loads((ROOT/'agent_packet_propagation'/'pair_completion_fork_8_7_9.json').read_text())
    B=R['B'];g=R['g'];d=R['d'];F={tuple(z['p']):int(Fraction(z['a']))for z in R['F']}
    H,meta=sparse_shadow(B,g,cap=300000);C=set(meta['states'])
    report,members,active=realize(B,g,d,C,F,seconds=90)
    out={'B':B,'g':g,'d':d,'report':report,'F':dump_table(F)}
    if members is not None:out['members']=sorted(members);out['local_active']=active;out['removed']=sorted(C-members)
    (folder/'large_local_exact_embedding.json').write_text(json.dumps(out,indent=2));print('RESULT',report,flush=True)

if __name__=='__main__':main()
