#!/usr/bin/env python3
"""Inspect exact rank-two branching after all single-slot restrictions."""
from marked_restriction import *
from pair_coherence import inspect

def main():
    folder=Path(__file__).parent;src=json.loads((folder/'slot_local_results.json').read_text())
    out=[];totals=defaultdict(int);tic=time.time()
    for R in src['results']:
        G=SlotSystem(R['B'],R['g'],R['d']);members=set(R['members'])
        active={(k,off):a for k,off,a in R['active']}
        rec={'i':R['i'],'B':G.B,'g':G.g,'d':G.d,'marks':[]}
        for i in range(G.n):
            for bit in bits(G.masks[i]):
                for selected in [True,False]:
                    S=[0]*G.n;U=[0]*G.n
                    (S if selected else U)[i]=bit
                    H=FixedMarkGraph(G,members,active,S,U);H.verify()
                    if not H.members:continue
                    stats,bad=inspect(H,H.members,H.active)
                    negative=[x for x in bad if x['negatives']]
                    totals['restrictions']+=1
                    for k,v in stats.items():totals[k]+=v
                    rec['marks'].append({'color':i,'bit':bit,'selected':selected,'mass':len(H.members),
                                         'stats':stats,'negative_components':negative})
                    if negative:
                        out.append(rec)
                        (folder/'marked_highrank_sections_results.json').write_text(json.dumps({'totals':dict(totals),'results':out},indent=2))
                        print('NEGATIVE',R['i'],i,bit,selected,negative,flush=True);return
        out.append(rec)
        (folder/'marked_highrank_sections_results.json').write_text(json.dumps({'totals':dict(totals),'results':out},indent=2))
        print('CASE',R['i'],dict(totals),'elapsed',round(time.time()-tic,2),flush=True)
    print('DONE',dict(totals),flush=True)

if __name__=='__main__':main()
