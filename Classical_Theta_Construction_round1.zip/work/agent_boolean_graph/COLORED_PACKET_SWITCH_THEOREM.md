# Finite Boolean packet graphs and component switches

Research note, 2026-11-13. Classical principal coefficients only.
The graph construction below never enumerates walls, broken lines, or
representation varieties. The comparison with a theta Newton polytope is
explicitly external. The coefficient identification remains a separate gap.

**Later correction.** The general least-packet-vector hypothesis used in
the conditional confluence statement below has now been disproved on
an exact rank-three Newton carrier. The switching and realization
theorems remain valid, but that hypothesis cannot be used as a general
coefficient theorem. See CUBICAL_COHERENCE_AND_MUTATION.md and the
current HANDOFF.md for the precise counterexample and stronger routes.

## 1. A finite graph universe from the exchange matrix

Let B be acyclic, topologically ordered, and let g be integral. Set

    A=[-B]_+,   d_i=max(0,-g_i+sum_j A_ij d_j),
    v=g+(I-A)d.

Thus d,v>=0 and d_i v_i=0. Write Q for the Boolean cube having d_i distinct
slots of color i. Its states are subsets of the slots. A state's degree p
records its selected-slot counts. Let Q_p denote the degree-p fiber, so

    N_p=|Q_p|=product_i binom(d_i,p_i).

For color k and off-k degree t, define

    c_k(t)=[-g_k-sum_j b_kj p_j]_+.

This is at most d_k. Indeed

    c_k(t)=[d_k-v_k
             -sum_(b_kj>0) b_kj p_j
             -sum_(b_kj<0) (-b_kj)(d_j-p_j)]_+.

For each fixed off-k BIT configuration, choose the last c_k(t) slots of color
k as active. Toggling them partitions Q into disjoint Boolean c_k(t)-cubes.
Call these the canonical k-packets. A packet with s selected inactive slots
has degree character z^t z_k^s(1+z_k)^c. The number of canonical packets of
type (k,t,s) is

    Q_(k,t,s)=product_(j!=k) binom(d_j,t_j) * binom(d_k-c_k(t),s).

This gives a finite explicit packet inventory for every color.

### Allowed relabelings

For every pair (k,p), independently choose a permutation of Q_p and apply it
to the vertices of the canonical k-packets. The packet's cube edges are
transported with its vertices. Retain all colors simultaneously. Every such
graph has the same finite vertex set Q and the same packet inventory.

These relabelings preserve degree, not necessarily the individual bits of
the other colors. This is a deliberate enlargement of the stricter
active-coordinate graph model. The strict model is the special case where
every packet remains a coordinate subcube in a fixed off-bit fiber.

Every connected component C is a union of whole packets of each color.
Consequently its degree character

    F_C(z)=sum_(u in C) z^deg(u)

has nonnegative integer binomial quotients in every initial-star direction.
The component containing the unique degree-zero vertex has constant term 1.
The corresponding x^g F_C therefore belongs to the upper cluster algebra by
the principal-coefficient upper-bound theorem. This is Laurent membership
and positivity in the initial star, not an all-seed positivity claim.

## 2. Exact realization theorem

Write an integral packet vector as

    w=(a_p,q_(k,t,s)),

where all entries are nonnegative and, for each k and p,

    a_p=sum_s binom(c_k(t),p_k-s) q_(k,t,s).

Let W=(N_p,Q_(k,t,s)) be the full-cube packet vector.

**Theorem 1.** Every integral packet vector 0<=w<=W is realized by a subset
C of Q which is a union of connected components in some allowed relabeling.

**Proof.** First choose any a_p vertices in each Q_p and call their union C.
For each color k and packet type (k,t,s), choose any q_(k,t,s) canonical
packets. The convolution equations say that the union of their degree-p
vertices has cardinality a_p. Choose a bijection from this set to C intersect
Q_p, and extend it to a permutation of all Q_p. Do this independently for
each k and p. Every chosen k-packet now lies inside C and every unchosen
k-packet outside C. Thus C is closed under every colored edge. QED.

No theta coefficient enters this theorem. It is a finite integer matching
statement. Once the packet subcounts have been chosen, the requisite Hall
conditions reduce to equality of the two cardinalities in each degree fiber;
the allowed matching graph is complete bipartite.

The hard selection problem is precisely choosing balanced packet subcounts.
Invoking Hall after those subcounts are known does not solve that problem.

## 3. Internal switching and finite descent

Let C be one connected component of an allowed graph, with integral packet
vector u and a_0=1. A **switch** swaps two degree-equal vertices in the
incidences of one color, carrying that color's packet edges with the swap.
Restrict all switches to vertices of C. Each switch preserves all packet
types and leaves C closed under every colored edge.

**Theorem 2.** There is a finite sequence of switches, keeping the origin
component equal to C until its first strict split, if and only if u has a
proper integral balanced subvector w<=u with w_0=1.

**Proof.** A strict split gives such a subvector by taking the origin
component. Conversely apply Theorem 1 within C: select the prescribed number
of its existing k-packets of every type and degree-preservingly relabel them
to a common chosen subset with coefficient counts a_p(w). All permutations
are internal to C and factor into transpositions of degree-equal vertices.
Their final graph disconnects C. Follow this finite switch sequence only as
far as its first disconnection. Before that step the whole graph on C is
connected, hence the origin component is exactly C. The first disconnection
strictly decreases it. QED.

This proof does **not** claim that a preselected full switch path is
monotone after its first split. The algorithm stops at that first split,
discards the other components, and starts a new search on the surviving
origin component.

### A target-free exact graph algorithm

1. On the current component C enumerate its finite switch configuration
   graph in a fixed lexicographic breadth-first order.
2. Continue through configurations for which the origin component is C.
3. On the first strict split, retain the origin component and restart.
4. If the finite configuration graph is exhausted without a split, stop.

The number of strict decreases is at most |C|-1. Each plateau search is
finite, bounded very crudely by product_p (a_p!)^n.

The algorithm returns an integral packet vector with origin coefficient 1
which has no nonzero integral zero-origin packet summand. It is an
indecomposable integral packet object in this precise sense.

**Conditional confluence.** If the normalized feasible packet set in the
chosen carrier has an integral coordinatewise least vector L, and the
starting component is in that carrier, then every possible descent ends at
L. Every intermediate u dominates L, so if u!=L the difference u-L is an
integral nonnegative balanced vector and Theorem 2 gives a further split.

This is a conditional theorem, not a proof that such an L always exists,
is integral, is mutation covariant, or equals theta_g.

## 4. What can be identified generally with existing theta results

The full-cube polynomial is the standard product

    M_g=x^g product_i(1+z_i)^d_i
       =product_i x_i^v_i (x_i')^d_i.

It is a product of cluster variables. Existing theta positivity and positive
multiplication imply that its finite theta expansion has nonnegative
coefficients. Pointedness and the injectivity of the principal coefficient
embedding show that theta_g occurs with coefficient 1. Therefore both
theta_g and M_g-theta_g have nonnegative Laurent coefficients in the initial
star. Equivalently, the integral theta packet vector lies between 0 and W.

By Theorem 1, a subset representing theta_g is a union of components in
one of the finite allowed graphs. Its origin component C has support inside
Newt(theta_g). Root's independently established smallest-Newton-carrier
proposition applies to x^g F_C and gives the opposite containment. Hence

    Newt(F_C)=Newt(theta_g).

Moreover, every origin component in every allowed graph contains this
Newton polytope. Thus:

**Corollary.** Among the origin-component degree polytopes of this completely
finite, explicitly specified graph family, there is a unique least polytope,
and it is the theta Newton polytope.

This gives a graph-only finite version of the Newton-pruning result. It is
much less efficient than the exact linear vertex-deletion algorithm. Its
comparison uses positive theta multiplication and the valuative-independence
bridge; its actual finite enumeration uses only B,g, slots and permutations.

It does **not** follow that a least-cardinality origin component with this
polytope is theta_g. The missing coefficient theorem is unchanged: one must
prove that the relevant graph descent selects a mutation-covariant object
and identify it with theta_g. Initial-star indecomposability alone has not
been promoted to all-seed indecomposability or theta atomicity.

## 5. Exact strict-slot examples and a necessary plateau

All statements in this section were checked with Python integer arithmetic.

For B=[[0,2],[-2,0]], g=(-3,3), d=(3,3), choosing the last c active slots
produces mass24, whereas the rank-two greedy polynomial has mass18. The
extra coefficients are 2 at each of (1,1),(2,1),(2,2). A matching between
missing color-1 slots and singleton color-2 slots repairs the graph.

The cyclic parking shadow rule puts color-i slots at a/d_i on a circle.
A selected neighbor with b_ij>0 occupies nearest free i-slots preceding it;
an unselected neighbor with b_ij<0 occupies following i-slots. Each demands
|b_ij| slots. Remaining slots are active. In rank two this is the usual
shadow-complement mechanism. In higher rank it is only a tested candidate.

### Fork B: an interior packet component

    B=[[0,2,1],[-2,0,0],[-1,0,0]],
    g=(-4,6,2), d=(4,2,2).

The cyclic shadow graph has mass64; the exact packet least vector has
mass58. The difference is

    2 z_1^2 z_2 z_3 (1+z_1+z_1 z_3).

Every excess exponent lies inside the Newton-minimal carrier. The homogeneous
packet cone has two rays, with the non-origin primitive ray equal to the
three-vertex path shown in parentheses (verified independently by the
interior agent).

The mass64 graph has no single active-coordinate swap which strictly
shrinks its origin component. Nevertheless these four strict-slot swaps
give masses64,64,61,58, while keeping every origin component inside the
original vertex set:

    (color0, offbits80, activebit4 -> bit8),
    (color0, offbits160, activebit1 -> bit2),
    (color2, offbits27, activebit64 -> bit128),
    (color2, offbits46, activebit128 -> bit64).

These are bit MASKS with zero-based colors. The first two moves are neutral;
the latter two detach one three-state path each. A strict improving-move
algorithm would stop incorrectly.

### Fork A: excess outside the canonical Newton carrier

    B=[[0,0,1],[0,0,2],[-1,-2,0]],
    g=(-3,-2,3), d=(3,2,4).

The shadow graph has mass104; the exact packet least vector has mass98.
Its excess coefficients are

    a_(0,1,1)=1, a_(1,1,1)=2, a_(1,1,2)=1,
    a_(2,1,1)=1, a_(2,1,2)=1.

The exponents (0,1,1) and (1,1,2) lie outside the exact Newton carrier,
so the naive shadow rule is ruled out independently of any coefficient
selector conjecture. Again no strict single-swap descent exists at the
original graph, but two active-coordinate swaps give104,98:

    (color0, offbits48, activebit2 -> bit4),
    (color2, offbits21, activebit32 -> bit256).

Thus multiple-neighbor interactions already obstruct fixed cyclic parking
on a rank-three fork; mixed incoming/outgoing directions are not necessary.

## 6. Exact files

- boolean_slots.py: ambient cubes, integer verification, embedding discovery.
- sparse_shadow.py: lazy graph exploration, with no exponential ambient list.
- local_switches.py: strict descent and neutral-plateau searches.
- small_demo.json: affine rank-two fixed-slot counterexample and repair.
- slot_sweep_results.json:55/55 prescribed least vectors realized, ranks3–5,
  total slots at most12; all origin components connected.
- slot_large_results.json:11 further realizations,2 time cuts, no infeasibility.
- shadow_sweep_results.json:balanced cyclic shadows match57/60 cases;
  three fixed-rule failures retained.
- minimal_shadow_failure.json:two reduced rank-three fork failures, exact
  packet optimum duals, and Newton carriers.
- local_switches_results.json:complete switch words and removed states.

## Primary literature used for the limited comparison

- Lee–Li–Zelevinsky, Greedy elements in rank2 cluster algebras,
  arXiv:1208.2391v3, Definitions3.6–3.7 and the proof of Lemma3.4:
  https://arxiv.org/pdf/1208.2391 . This supplies the rank-two shadow
  interpretation only, not a higher-rank theorem.
- Lee–Li–Mills, A combinatorial formula for certain elements of upper cluster
  algebras, SIGMA11(2015)049, Definition3.1, Lemmas3.3/3.5 and Theorems1.1/1.2:
  https://sigma-journal.com/2015/049/sigma15-049.pdf . Their GCC construction
  is a comparison object; no identification with this graph or with theta
  is asserted.
- BFZ, GHKK and CMMM inputs are exactly the external inputs recorded in
  work/THETA_NEWTON_PRUNING.md. No Li–Pan conclusion is used.
