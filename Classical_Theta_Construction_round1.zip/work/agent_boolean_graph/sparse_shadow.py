#!/usr/bin/env python3
"""Lazy exploration of cyclic shadow graphs; no ambient cube enumeration."""
from boolean_slots import *
from functools import lru_cache

def sparse_shadow(B,g,phases='incoming_first',reverse_ties=False,site_order='forward',shifts=None,cap=1000000):
    d,v,topo=acyclic_dimension(B,g);n=len(g);D=sum(d);offsets=[];s=0
    for a in d:offsets.append(s);s+=a
    masks=[((1<<a)-1)<<s for a,s in zip(d,offsets)]
    if shifts is None:shifts=[Fraction(0)]*n
    word=sorted((((Fraction(a+1,dk)+shifts[k])%1),-k if reverse_ties else k,k,a)
                for k,dk in enumerate(d) for a in range(dk))
    pos={(k,a):t for t,(_,__,k,a) in enumerate(word)}
    order=[(k,a)for _,__,k,a in word]
    priorities={(k,j,a,direction):tuple(sorted(range(d[k]),key=lambda u:((pos[k,u]-pos[j,a])*direction)%D))
                for k in range(n)for j,a in order if k!=j for direction in [-1,1]}
    @lru_cache(None)
    def degree(v):return tuple(((v&m)>>s).bit_count()for m,s in zip(masks,offsets))
    @lru_cache(None)
    def activate(k,off):
        dk=d[k];p=degree(off);c=max(0,-g[k]-sum(B[k][j]*p[j]for j in range(n)))
        if c>dk:raise AssertionError('packet too large')
        if c==0:return 0
        if c==dk:return masks[k]
        demands=[]
        for j,a in order:
            if j==k or not B[k][j]:continue
            bit=bool(off&(1<<(offsets[j]+a)));b=B[k][j]
            if(b>0 and bit)or(b<0 and not bit):
                direction=-1 if b>0 else 1;group=0 if((b<0)==(phases=='incoming_first'))else 1
                if phases=='interleaved':group=0
                site=pos[j,a]
                demands.append((group,site if site_order=='forward'else -site,j,a,abs(b),direction))
        demands.sort();free=set(range(dk))
        for _,__,j,a,count,direction in demands:
            for u in priorities[k,j,a,direction]:
                if u in free:
                    free.remove(u);count-=1
                    if count==0:break
        if len(free)!=c:raise AssertionError(('bad shadow size',k,off,c,len(free)))
        return sum(1<<(offsets[k]+u)for u in free)
    seen={0};todo=[0];F=defaultdict(int)
    while todo:
        v=todo.pop();F[degree(v)]+=1
        for k in range(n):
            am=activate(k,v&~masks[k])
            while am:
                bit=am&-am;am-=bit;w=v^bit
                if w not in seen:
                    seen.add(w);todo.append(w)
                    if len(seen)>cap:return None,{'cut':'component_size','size':len(seen)}
    return dict(F),{'members':len(seen),'fibers':activate.cache_info().currsize,'d':d,'word':order,'states':sorted(seen)}

def main():
    folder=Path(__file__).parent;src=json.loads((ROOT/'agent_packet_propagation'/'mandatory_support_results.json').read_text())
    out=[]
    for i in [41,43,46]:
        c=src['results'][i];B,g=c['B'],c['g'];F={tuple(p):int(Fraction(*a))for p,a in c['F']}
        H,meta=sparse_shadow(B,g)
        difference={p:H.get(p,0)-F.get(p,0)for p in H.keys()|F.keys()if H.get(p,0)!=F.get(p,0)}
        rec={'i':i,'B':B,'g':g,'d':meta['d'],'least_mass':sum(F.values()),'shadow_mass':sum(H.values()),
             'difference':dump_table(difference),'least':dump_table(F),'shadow':dump_table(H)}
        out.append(rec);print(json.dumps({k:v for k,v in rec.items()if k not in ['least','shadow']}),flush=True)
    for n,m in [(3,5),(4,4),(4,5),(3,6),(3,7)]:
        B=[[0 if i==j else 3*(1 if i<j else -1)for j in range(n)]for i in range(n)]
        g=tuple(-m+3*m*i for i in range(n));H,meta=sparse_shadow(B,g)
        print('complete',n,m,'mass',sum(H.values()),'terms',len(H),'fibers',meta['fibers'],flush=True)
        rec={'B':B,'g':g,'d':meta['d'],'shadow_mass':sum(H.values()),'shadow':dump_table(H)}
        out.append(rec)
    (folder/'shadow_failures_and_stress.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
