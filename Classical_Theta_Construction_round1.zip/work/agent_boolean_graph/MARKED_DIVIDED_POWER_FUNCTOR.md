# Marked Boolean packets form a commuting divided-power functor

Research lemma, 2026-11-13. This is a general finite graph statement. It
does not assume theta coefficients and does not identify an arbitrary
packet component with a theta element.

## 1. Input and notation

Let B be an exchange matrix and g an integer label. Give color i a finite
totally ordered slot set E_i of size d_i. A vertex u is a selected subset
of the disjoint union of the E_i, with degree p_i=|u intersect E_i|.
At each fixed configuration outside E_i choose an active set A_i(u)
inside E_i, independent of the i-bits, of size

    c_i(u)=[-g_i-sum_j b_ij p_j]_+.

Edges toggle active bits. Let C be any finite union of components and
let F(z)=sum_(u in C) z^p. All assertions below work for such a union,
without a pointedness or connectedness assumption.

## 2. The operator and its exact label

For principal variables z_i=y_i x^(B[:,i]), define

    D_i=x_i partial/partial y_i,
    D_i^[r]=D_i^r/r!.

The variables x are held fixed in this derivative. Direct differentiation
gives

    D_i^[r](x^g F(z))
      =x^(g+r(e_i+B[:,i]))
         sum_p binom(p_i,r) a_p z^(p-r e_i).

In particular the B-column has a PLUS sign. The coefficient multiplier
counts choices of r selected i-slots.

For a vector r>=0, let R=(R_i) be a tuple of marked subsets with
R_i contained in u intersect E_i and |R_i|=r_i. The marked graph vertices
are all pairs (u,R). Delete the marked slots from the degree:

    p'=p-r,   h=g+r+B r.

The character of the complete marked vertex set is exactly the divided
derivative product_(i) D_i^[r_i](x^g F). The number of remaining slots
of color i is d_i-r_i, so every nonzero derivative strictly reduces the
total ambient slot count.

## 3. The canonical repaired packet graph

Fix the marker tuple R throughout every edge. At (u,R) define

    A_i^R(u)=the first [c_i(u)-r_i]_+ slots of A_i(u) minus R_i.

There are enough slots: at most r_i active slots were marked, hence
|A_i minus R_i| >= c_i-r_i whenever the latter is positive.
Keep exactly the toggles in A_i^R. All these edges remain in C, and they
preserve the requirement that every marked slot be selected.

The required new packet dimension follows from a cancellation:

    h_i+sum_j b_ij p'_j
      =g_i+r_i+sum_j b_ij p_j.

Consequently

    [-h_i-sum_j b_ij p'_j]_+
      =[c_i(u)-r_i]_+.

The new active set is independent of the unmarked i-bits, because the
old active set and R are fixed on that fiber. Thus the marked graph is
again a strict Boolean packet graph, now with label h and slot box d-r.
Every one of its components has nonnegative one-color binomial quotients.

For a single color i one can see the construction packet by packet.
An old i-packet has c active directions and s selected inactive slots.
If R contains a active markers and r-a inactive markers, its marked
restriction is a (c-a)-cube at base degree s-r+a. The desired new cube
dimension is [c-r]_+. Freeze all but the first [c-r]_+ of its unmarked
active directions. This partitions the restricted cube into legitimate
new packets with no subtraction and no extra vertices.

## 4. Same-color composition

For an ordered finite set A of size c write first_m(A) for its first m
elements, where m is truncated below at zero. If R and S are disjoint
marker sets of respective total sizes r and s, then

    first_[c-r-s]_+( first_[c-r]_+(A minus R) minus S )
       = first_[c-r-s]_+(A minus (R union S)).

To verify this, assume c-r-s>0. Removing S deletes at most s elements
from the first c-r surviving elements. Therefore that prefix still
contains every element needed for the first c-r-s survivors. The case
c-r-s<=0 is immediate. Markers outside A cause no difficulty.

Thus successive marked restrictions have EXACTLY the same remaining
active directions as a single restriction by the union of the marks.
For a fixed total marker set T of size r+s there are binom(r+s,r)
ways to designate which r marks were made first. Forgetting this
designation yields a graph isomorphism, with the indicated multiplicity:

    D_i^[r] D_i^[s] G
       is binom(r+s,r) disjoint copies of D_i^[r+s] G.

This is the divided-power identity at the level of finite graphs, not
only at the level of their polynomial characters.

## 5. Different colors commute

Marking color i trims only A_i; it leaves all other colors' active sets
unchanged. Marking color j subsequently trims only A_j. The full original
state u can always be recovered by restoring the fixed marker tuple.
Hence restrictions in distinct colors commute literally after the
obvious identification of their marker tags. Their label changes add:

    g -> g+r(e_i+B[:,i])+s(e_j+B[:,j]).

This assertion does not require b_ij=0. The operators D_i commute as
ordinary partial derivatives, and the graph construction respects that
commutation.

## 6. Multiplication cuts fit the same construction

Multiplying by x_i changes g to g+e_i and lowers the required i-cube
dimension from c_i to [c_i-1]_+. It is therefore represented by deleting
the last active i-direction of every positive-dimensional packet.

For simultaneous multiplication by x^a and marking r, retain

    first_[c_i-a_i-r_i]_+(A_i minus R_i)

in color i, and use label h=g+a+r+B r. The same prefix argument proves
that all multiplication cuts and all marked restrictions commute, with
the same divided-power multiplicities for repeated marks of one color.

These are canonical once the original slot orders are specified. They
are natural under restriction to a union of components and under fixing
outside bit data, because the formulas use only the original active
set and the fixed marks on the fiber in question.

## 7. The remaining coefficient problem

The construction proves a useful positive closure of the finite packet
graph category. It does NOT prove that a connected component of a
derived graph is pointed, has coefficient one at a least monomial, or
has the character of a lower theta element. Those are stronger selection
properties, precisely where the root's positive derivative/slice theorem
could supply an induction interface.

A proposed canonical class may require that these marked restrictions
admit compatible decompositions into already constructed smaller
objects. The general lemma supplies the exact vertices, dimensions,
weights, and commuting maps for that requirement. It does not assume
that the unknown coefficient table has already been supplied.

## 8. Unselected markers and the full mixed construction

The root's sink-leaf argument suggests the complementary operation.
It has an equally direct graph realization. In each color choose

    S_i subset of u intersect E_i,   |S_i|=r_i,
    U_i subset of E_i minus u,      |U_i|=q_i.

Delete both the selected markers S_i and the unselected markers U_i.
Use the shifted data

    p'=p-r,   h=g+(r+q)+B r,   d'=d-r-q,

and retain the active directions

    first_[c_i-r_i-q_i]_+(A_i minus (S_i union U_i)).

The same count proves enough unmarked active slots remain. The same
cancellation proves the required packet dimension is [c_i-r_i-q_i]_+.
The total marked graph has polynomial character

    sum_p a_p product_i binom(p_i,r_i) binom(d_i-p_i,q_i) z^(p-r).

With only unselected markers in color i, the operation on x^g F is

    x_i^q binom(d_i-y_i partial_y_i,q)(x^g F).

Here the binomial is the falling-factorial polynomial in the Euler
operator. With one selected marker the operation is D_i as above.
When operations are composed, the ambient d is updated after every
deletion. This is essential: the one-slot relation is

    D_i [x_i(d_i-y_i partial_y_i)]
       = [x_i(d_i-1-y_i partial_y_i)] D_i.

For arbitrary mixed markers, the prefix lemma from Section 4 applies
to the UNION of all marker sets, independent of whether the markers
are selected or unselected. Consequently all different-color and
different-type deletions commute at graph level. Repeated selected
markings of sizes r,s give multiplicity binom(r+s,r); repeated
unselected markings of sizes q,t give multiplicity binom(q+t,q).
There is no extra multiplicity for commuting a selected with an
unselected marking: their types already distinguish the two sets.

## 9. Full marking is an exact slice, not an approximation

If r_i+q_i=d_i, then

    binom(p_i,r_i) binom(d_i-p_i,q_i)

is 1 when p_i=r_i and 0 otherwise. Full marking of color i therefore
extracts its exact degree-r_i slice, deletes all its slots, and gives
base label g+d_i e_i+r_i B[:,i]. There is exactly one marker assignment
for every surviving original vertex: all selected slots are marked S
and all unselected slots are marked U.

Thus the same finite construction interpolates between derivatives,
complementary derivatives, multiplication cuts, and full coordinate
slices. Its diagrams commute by literal unions of fixed marker sets.
This yields a concrete source of all-rank cubical coherence. It still
does not by itself supply compatible theta-component decompositions.

## 10. Complement duality and the opposite distinguished vertex

Complement all slots, u* = E minus u. Replace the label data by

    B*=-B,   g*=g+B d,   d*=d.

Set A_i*(u*)=A_i(u). Since p*=d-p,

    g*+B* p* = g+B p.

All packet dimensions and edges are preserved. This is an involution.
For an acyclic standard box, write A=[-B]_+, P=[B]_+ and
g=-d+A d+v with v,d>=0 and v_i d_i=0. Then
g*=-d+P d+v. The opposite orientation has lower-triangular matrix P
when its topological order is reversed, so it has the same standard
box d and the same residual monomial vector v.

Every origin component in an acyclic standard Boolean box contains
the fully selected vertex d. Starting at the empty vertex, fill the
colors in topological order. At the stage for i, all incoming colors
are full and all outgoing colors are empty. If d_i>0 then v_i=0,
so c_i=d_i and every i-slot may be toggled. Thus the whole path lies
in the origin component. Both endpoints have coefficient one because
there is only one empty and one fully selected Boolean state.

Complement duality consequently sends an origin component to an
origin component for the opposite exchange matrix. At the polynomial
level its character is z^d F(z^-1). The purely algebraic analogue is
that any origin-normalized table supported in the standard box and
divisible by the required fiber binomials has a_d=a_0=1: along the
same topological sequence each relevant fiber has full required
binomial degree d_i, so its two endpoint coefficients agree.

Selected marking in the complemented graph is exactly unselected
marking in the original graph. After q selected deletions in color i,
the complemented label is g*+q(e_i-B[:,i]). Complementing back in
the reduced box d-q e_i gives g+q e_i, the unselected-marking label.
This conjugation gives a direct graph explanation of the two types.

## 11. Preservation of independent-color squares

Suppose b_ij=0 and the original graph satisfies the literal active-square
axiom A_i(u xor e)=A_i(u) for e in A_j(u), and conversely. Every new
j-direction after marking or multiplication is an old j-direction.
Along it the old A_i is unchanged; the marker set, slot order and
truncation count are fixed. Hence the new A_i is unchanged as well.
The marked restriction therefore preserves every independent-color
cube axiom. No assumption of neighbor-only active-set dependence is
needed.

## 12. Exact computational audit and the unproved strengthening

Code: marked_restriction.py, marked_ranktwo_stress.py,
marked_highrank_sections.py. The checks use integer bits and exact
rational LLZ comparisons; no numerical optimizer enters these cuts.

- Exhaustive prefix composition verification covered 55,987 cases,
  including markers outside the original active set.
- The rank-two stress used 250 inputs with b,c<=5 and total slots<=14,
  and 1,919 selected/unselected/mixed operations. Among 82,585 resulting
  connected components, 79,885 were individual greedy polynomials and
  the other 2,700 had nonnegative integral greedy expansions.
- On the 55 stored local rank-three through rank-five realizations,
  all 1,054 nonempty single-slot restrictions were checked. Their
  99,350 two-color components consisted of 99,312 individual greedies
  and 38 positive sums of greedies. No negative expansion occurred.

These data do not prove a general marked branching theorem for the
canonical class. Even the hard rank-two d=(7,8) graph produces some
components that are positive sums rather than individual greedies;
coherent rematching would still be needed to obtain canonical objects.
The original higher-rank input coefficient tables were supplied to
construct their realizations, so these experiments are not independent
coefficient formulas.
