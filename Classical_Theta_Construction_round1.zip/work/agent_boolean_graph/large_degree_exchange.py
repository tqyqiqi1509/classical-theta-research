#!/usr/bin/env python3
"""Allow all degree-equal Boolean exchanges in the three excess degrees."""
from sparse_subgraph_embedding import *
from itertools import combinations

def main():
    folder=Path(__file__).parent;R=json.loads((ROOT/'agent_packet_propagation'/'pair_completion_fork_8_7_9.json').read_text())
    B=R['B'];g=R['g'];d=R['d'];F={tuple(z['p']):int(Fraction(z['a']))for z in R['F']}
    H,meta=sparse_shadow(B,g,cap=300000);old=set(meta['states']);C=set(old)
    changed=[p for p in H.keys()|F.keys()if H.get(p,0)!=F.get(p,0)]
    offset=[0,d[0],d[0]+d[1]]
    for p in changed:
        pools=[[sum(1<<(offset[i]+j)for j in S)for S in combinations(range(d[i]),p[i])]for i in range(3)]
        C.update(a|b|c for a,b,c in product(*pools))
    print('expanded states',len(C),'old',len(old),'variable degrees',changed,flush=True)
    report,members,active=realize(B,g,d,C,F,seconds=60)
    out={'B':B,'g':g,'d':d,'report':report,'F':dump_table(F),'ambient_size':len(C)}
    if members is not None:out['members']=sorted(members);out['local_active']=active;out['removed']=sorted(old-members);out['added']=sorted(members-old)
    (folder/'large_degree_exchange_results.json').write_text(json.dumps(out,indent=2));print('RESULT',report,flush=True)

if __name__=='__main__':main()
