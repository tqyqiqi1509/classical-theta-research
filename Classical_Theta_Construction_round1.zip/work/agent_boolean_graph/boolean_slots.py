#!/usr/bin/env python3
"""Finite colored Boolean slot graphs and exact checked embedding searches.

A state has d_i labeled bits of each color i. For each i and each fixed
configuration of all other colors, choose c_i=max(0,-g_i-(B p)_i) active
bits. Their toggles are edges. Every connected component has positive
binomial quotients in the initial star. No claim of all-seed positivity.

MILP is only a discovery tool: all returned membership/activation bits,
fiber conditions, prescribed counts and origin connected component are
independently rechecked with Python integers.
"""
from __future__ import annotations
from collections import defaultdict, deque
from itertools import product
from pathlib import Path
import math, json, sys, time
from fractions import Fraction
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_acceptance'),str(ROOT/'agent_packet_propagation'),str(ROOT/'agent_mass')]
from schofield_carrier import acyclic_dimension, solve_carrier_packets
from theta_newton_pruning import prune
from packet_minimum import dump_table


class SlotSystem:
    def __init__(self,B,g,d=None):
        self.B=tuple(map(tuple,B));self.g=tuple(g);self.n=len(g)
        if d is None:d,_,_=acyclic_dimension(B,g)
        self.d=tuple(d);self.D=sum(d);self.N=1<<self.D
        self.offsets=[];s=0
        for a in d:self.offsets.append(s);s+=a
        self.masks=tuple(((1<<a)-1)<<s for a,s in zip(d,self.offsets))
        self.neighbor_masks=tuple(sum(self.masks[j]for j in range(self.n)if B[k][j])for k in range(self.n))
        self.degrees=[tuple(((v&m)>>s).bit_count() for m,s in zip(self.masks,self.offsets)) for v in range(self.N)]
        self.by_degree=defaultdict(list)
        for v,p in enumerate(self.degrees):self.by_degree[p].append(v)
        self.fibers=[]
        for k,(dk,offset,mask) in enumerate(zip(d,self.offsets,self.masks)):
            for off in range(self.N):
                if off&mask:continue
                p=self.degrees[off]
                c=max(0,-g[k]-sum(B[k][j]*p[j] for j in range(self.n)))
                if c>dk:raise ValueError(('packet larger than slots',k,off,c,dk))
                self.fibers.append((k,off,c))

    def component(self,active,start=0):
        seen={start};todo=[start]
        while todo:
            v=todo.pop()
            for k,mask in enumerate(self.masks):
                off=v&~mask
                am=active[k,off]
                while am:
                    bit=am&-am;am-=bit;w=v^bit
                    if w not in seen:seen.add(w);todo.append(w)
        return seen

    def character(self,members):
        F=defaultdict(int)
        for v in members:F[self.degrees[v]]+=1
        return dict(F)

    def fixed_rule(self,rule='last'):
        active={}
        for k,off,c in self.fibers:
            if rule=='first':local=(1<<c)-1
            elif rule=='last':local=((1<<c)-1)<<(self.d[k]-c)
            else:raise ValueError(rule)
            active[k,off]=local<<self.offsets[k]
        members=self.component(active)
        return active,members,self.character(members)

    def shadow_rule(self,phases='incoming_first',reverse_ties=False,site_order='forward',shifts=None):
        """Cyclic nearest-free-slot parking, a direct higher-rank shadow guess.

        A selected outgoing neighbor consumes b_ij preceding i-slots;
        an unselected incoming neighbor consumes -b_ij following i-slots.
        In rank two these are precisely the usual cyclic shadow matchings
        for a maximal Dyck path, with the horizontal membership complemented.
        Mixed directions in higher rank require a chosen order; no confluence
        or canonical-basis claim is built into this experimental definition.
        """
        if shifts is None:shifts=[Fraction(0)]*self.n
        word=sorted(( ((Fraction(a+1,dk)+shifts[k])%1),-k if reverse_ties else k,k,a)
                    for k,dk in enumerate(self.d) for a in range(dk))
        pos={(k,a):t for t,(_,__,k,a) in enumerate(word)}
        order=[(k,a)for _,__,k,a in word]
        active={}
        for k,off,c in self.fibers:
            dk=self.d[k]
            if c==0:active[k,off]=0;continue
            if c==dk:active[k,off]=self.masks[k];continue
            demands=[]
            for j,a in order:
                if j==k or not self.B[k][j]:continue
                bit=bool(off&(1<<(self.offsets[j]+a)))
                b=self.B[k][j]
                if (b>0 and bit)or(b<0 and not bit):
                    direction=-1 if b>0 else 1
                    group=0 if ((b<0)==(phases=='incoming_first'))else 1
                    if phases=='interleaved':group=0
                    site=pos[j,a]
                    demands.append((group,site if site_order=='forward'else -site,j,a,abs(b),direction))
            demands.sort()
            free=set(range(dk))
            for group,site,j,a,count,direction in demands:
                start=pos[j,a]
                priorities=sorted(free,key=lambda u:((pos[k,u]-start)*direction)%self.D)
                for u in priorities[:count]:free.remove(u)
            if len(free)!=c:raise AssertionError(('bad shadow size',k,off,c,len(free)))
            active[k,off]=sum(1<<(self.offsets[k]+u)for u in free)
        members=self.component(active)
        return active,members,self.character(members)

    def verify(self,members,active,F=None,allowed=None,local=False):
        if 0 not in members:raise AssertionError('origin missing')
        for k,off,c in self.fibers:
            a=active[k,off]
            if a&~self.masks[k] or a.bit_count()!=c:raise AssertionError(('bad activation',k,off,c,a))
            for local in range(1<<self.d[k]):
                v=off|(local<<self.offsets[k]);bits=a
                while bits:
                    bit=bits&-bits;bits-=bit
                    if (v in members)!=((v^bit) in members):
                        raise AssertionError(('membership not invariant',k,off,v,bit))
        if local:
            lookup={}
            for (k,off),am in active.items():
                key=k,off&self.neighbor_masks[k]
                if key in lookup and lookup[key]!=am:raise AssertionError(('nonlocal activation',key))
                lookup[key]=am
        actual=self.character(members)
        if F is not None and actual!={p:a for p,a in F.items() if a}:raise AssertionError('degree marginal mismatch')
        if allowed is not None and not set(actual)<=set(allowed):raise AssertionError('support outside carrier')
        comp=self.component(active)
        if not comp<=members:raise AssertionError('origin component outside members')
        return {'members':len(members),'origin_component':len(comp),'connected':comp==members,
                'F':dump_table(actual),'component_F':dump_table(self.character(comp))}

    def solve(self,F=None,allowed=None,seconds=30,objective=True,local=False):
        """Realize F, or find a minimum invariant member set in allowed degrees."""
        tic=time.time();var_count=self.N;amap={};forced={};active={};groups={}
        for k,off,c in self.fibers:
            if c==0:active[k,off]=0
            elif c==self.d[k]:active[k,off]=self.masks[k]
            else:
                key=(k,off&self.neighbor_masks[k])if local else(k,off)
                if key not in groups:
                    groups[key]=list(range(var_count,var_count+self.d[k]));var_count+=self.d[k]
                amap[k,off]=groups[key]
        low=np.zeros(var_count);high=np.ones(var_count)
        low[0]=high[0]=1
        if allowed is not None:
            allowed=set(map(tuple,allowed))
            for v,p in enumerate(self.degrees):
                if p not in allowed:high[v]=0
        if F is not None:
            F={tuple(p):a for p,a in F.items() if a}
            for p,vs in self.by_degree.items():
                a=F.get(p,0)
                if not 0<=a<=len(vs):return {'status':'impossible_marginal','p':p,'value':a,'capacity':len(vs)},None,None
                if a==0:high[vs]=0
                elif a==len(vs):low[vs]=1
        if any(low>high):return {'status':'inconsistent_bounds'},None,None
        rr=[];cc=[];vv=[];rlow=[];rhigh=[]
        def row(terms,lo,hi):
            r=len(rlow)
            for col,a in terms:rr.append(r);cc.append(col);vv.append(a)
            rlow.append(lo);rhigh.append(hi)
        if F is not None:
            for p,vs in self.by_degree.items():
                a=F.get(p,0)
                if 0<a<len(vs):row([(v,1) for v in vs],a,a)
        used_activation_rows=set()
        for k,off,c in self.fibers:
            if c==0:continue
            dk=self.d[k];offset=self.offsets[k]
            if (k,off) in amap:
                ai=amap[k,off]
                if tuple(ai)not in used_activation_rows:
                    row([(a,1) for a in ai],c,c);used_activation_rows.add(tuple(ai))
            else:ai=None
            for i in range(dk):
                bit=1<<(offset+i)
                for local in range(1<<dk):
                    if local&(1<<i):continue
                    v=off|(local<<offset);w=v|bit
                    if ai is None:
                        row([(v,1),(w,-1)],0,0)
                    else:
                        row([(v,1),(w,-1),(ai[i],1)],-np.inf,1)
                        row([(w,1),(v,-1),(ai[i],1)],-np.inf,1)
        A=coo_matrix((np.array(vv,float),(rr,cc)),shape=(len(rlow),var_count)).tocsc()
        obj=np.zeros(var_count)
        if objective:obj[:self.N]=1
        res=milp(obj,integrality=np.ones(var_count),bounds=Bounds(low,high),
                 constraints=LinearConstraint(A,np.array(rlow),np.array(rhigh)),
                 options={'time_limit':seconds,'mip_rel_gap':0})
        report={'status':int(res.status),'message':res.message,'variables':var_count,'rows':len(rlow),'cube':self.N,
                'seconds':time.time()-tic,'objective':None if res.fun is None else float(res.fun),
                'bound':None if getattr(res,'mip_dual_bound',None)is None else float(res.mip_dual_bound),
                'nodes':getattr(res,'mip_node_count',None),'local_activation':local}
        if res.x is None:return report,None,None
        z=[int(round(a)) for a in res.x]
        if any(abs(a-b)>1e-6 for a,b in zip(z,res.x)):raise ArithmeticError('nonintegral solver answer')
        members={v for v in range(self.N) if z[v]}
        for (k,off),ai in amap.items():
            active[k,off]=sum(z[a]<<(self.offsets[k]+i) for i,a in enumerate(ai))
        report['verified']=self.verify(members,active,F,allowed,local)
        return report,members,active

def small_demo():
    B=[[0,2],[-2,0]];g=(-3,3);G=SlotSystem(B,g)
    active,members,F=G.fixed_rule()
    C=prune(B,g,cap=1000)
    rep,H,M=solve_carrier_packets(B,g,C)
    search,good,act=G.solve(F=H,seconds=30)
    out={'B':B,'g':g,'d':G.d,'last_rule':dump_table(F),'packet_min':rep,'embedding':search}
    if act is not None:out['active']=[{'k':k,'off':off,'active':a}for(k,off),a in sorted(act.items())]
    folder=Path(__file__).parent
    (folder/'small_demo.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))

if __name__=='__main__':small_demo()
