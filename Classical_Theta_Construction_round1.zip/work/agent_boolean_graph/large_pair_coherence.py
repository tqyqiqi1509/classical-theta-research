#!/usr/bin/env python3
from pair_coherence import *
from types import SimpleNamespace

class Degrees:
    def __init__(self,masks,offsets):self.masks=masks;self.offsets=offsets
    def __getitem__(self,v):return tuple(((v&m)>>s).bit_count()for m,s in zip(self.masks,self.offsets))

class LocalActivation:
    def __init__(self,lookup,masks):self.lookup=lookup;self.masks=masks
    def __getitem__(self,key):
        k,off=key;return self.lookup[k,off&self.masks[k]]

def main():
    folder=Path(__file__).parent;r=json.loads((folder/'large_degree_exchange_results.json').read_text())
    B=r['B'];g=r['g'];d=r['d'];n=len(g);offsets=[];s=0
    for a in d:offsets.append(s);s+=a
    masks=[((1<<a)-1)<<s for a,s in zip(d,offsets)]
    neighbors=[sum(masks[j]for j in range(n)if B[k][j])for k in range(n)]
    G=SimpleNamespace(n=n,B=B,g=g,d=d,masks=masks,degrees=Degrees(masks,offsets))
    lookup={(k,off):a for k,off,a in r['local_active']};active=LocalActivation(lookup,neighbors)
    stats,bad=inspect(G,set(r['members']),active)
    out={'B':B,'g':g,'d':d,'stats':stats,'bad':bad,'removed_count':len(r['removed']),'added_count':len(r['added'])}
    (folder/'large_pair_coherence_results.json').write_text(json.dumps(out,indent=2))
    print('RESULT',stats,'removed',len(r['removed']),'added',len(r['added']),flush=True)
    print('first nongreedy',next((z for z in bad if not z['greedy_equal']),None),flush=True)

if __name__=='__main__':main()
