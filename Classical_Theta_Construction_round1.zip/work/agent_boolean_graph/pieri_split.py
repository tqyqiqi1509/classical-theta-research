#!/usr/bin/env python3
"""Color-cube splitting under multiplication by an initial variable.

The graph action itself is exact: decrease the selected color's positive
packet dimensions by one by deleting one bit direction from each cube.
Rootedness and comparison with smaller packet minima are investigated only.
"""
from boolean_slots import *
import random

def extract_packets(G,members,active):
    packets=[]
    for k,off,c in G.fibers:
        am=active[k,off];inactive=G.masks[k]^am
        own=[v&G.masks[k] for v in members if(v&~G.masks[k])==off]
        if not own:continue
        bases=sorted({v&inactive for v in own})
        bits=[1<<(G.offsets[k]+i)for i in range(G.d[k])if am&(1<<(G.offsets[k]+i))]
        for base in bases:
            vs=[off|base|sum(bit for j,bit in enumerate(bits)if mask&(1<<j))for mask in range(1<<c)]
            if not set(vs)<=members:raise AssertionError('incomplete packet')
            packets.append({'k':k,'off':off,'base':base,'c':c,'bits':bits,'vertices':vs})
    return packets

def components(members,packets):
    parent={v:v for v in members}
    def root(v):
        while parent[v]!=v:
            parent[v]=parent[parent[v]];v=parent[v]
        return v
    for packet in packets:
        vs=packet['vertices']
        a=root(vs[0])
        for v in vs[1:]:
            b=root(v)
            if a!=b:parent[b]=a
    out=defaultdict(set)
    for v in members:out[root(v)].add(v)
    return sorted(out.values(),key=lambda s:min(s))

def split_packets(packets,k,choices=None):
    out=[];choices={}if choices is None else choices
    for i,p in enumerate(packets):
        if p['k']!=k or p['c']==0:out.append(p);continue
        j=choices.get(i,0)
        for epsilon in [0,1]:
            vs=[v for mask,v in enumerate(p['vertices'])if((mask>>j)&1)==epsilon]
            out.append({**p,'c':p['c']-1,'vertices':vs})
    return out

def root_data(G,C,gnew):
    F=G.character(C);pmin=tuple(min(p[i]for p in F)for i in range(G.n))
    multiplicity=F.get(pmin,0);rooted=multiplicity==1
    out={'mass':len(C),'coordinate_minimum':pmin,'minimum_multiplicity':multiplicity,'rooted':rooted}
    if rooted:
        h=tuple(gnew[i]+sum(G.B[i][j]*pmin[j]for j in range(G.n))for i in range(G.n))
        out['h']=h;out['F']=dump_table({tuple(p[i]-pmin[i]for i in range(G.n)):a for p,a in F.items()})
        out['width']=sum(max(p[i]for p in F)-pmin[i]for i in range(G.n))
    else:out['F_unshifted']=dump_table(F)
    return out

def evaluate_split(G,members,packets,k,choices=None):
    gnew=tuple(g+int(i==k)for i,g in enumerate(G.g))
    pp=split_packets(packets,k,choices);cc=components(members,pp)
    data=[root_data(G,C,gnew)for C in cc]
    return {'k':k,'components':data,'all_rooted':all(c['rooted']for c in data),
            'bad_components':sum(not c['rooted']for c in data),'number_components':len(cc)},cc,pp

def main():
    folder=Path(__file__).parent;src=json.loads((folder/'slot_sweep_results.json').read_text());out=[];stats=defaultdict(int)
    rng=random.Random(98712)
    for rec in src['results']:
        G=SlotSystem(rec['B'],rec['g'],rec['d']);members=set(rec['members']);active={(k,off):a for k,off,a in rec['active']}
        packets=extract_packets(G,members,active);case={'i':rec['i'],'B':rec['B'],'g':rec['g'],'d':rec['d'],'colors':[]}
        for k in range(G.n):
            default,cc,pp=evaluate_split(G,members,packets,k);best=default;bestchoices=None
            if not default['all_rooted']:
                for trial in range(40):
                    choices={j:rng.randrange(p['c'])for j,p in enumerate(packets)if p['k']==k and p['c']>0}
                    rr,cc,pp=evaluate_split(G,members,packets,k,choices)
                    if rr['bad_components']<best['bad_components']:best=rr;bestchoices=choices
                    if best['all_rooted']:break
            stats['colors']+=1;stats['default_rooted']+=int(default['all_rooted']);stats['some_rooted']+=int(best['all_rooted'])
            case['colors'].append({'k':k,'default_rooted':default['all_rooted'],'best':best,'choices':bestchoices})
        out.append(case)
        (folder/'pieri_split_results.json').write_text(json.dumps({'stats':dict(stats),'results':out},indent=2))
        print(rec['i'],'rank',G.n,'mass',len(members),'rooted',[x['best']['all_rooted']for x in case['colors']],dict(stats),flush=True)
    print('DONE',dict(stats),flush=True)

if __name__=='__main__':main()
