#!/usr/bin/env python3
"""Search coherent local active choices maximizing two-color components.

The member set and polynomial stay fixed. Every changed activation remains
local and every toggle preserves that set. Numerical optimization is used
only to propose a graph; final component characters are checked exactly.
"""
from local_closed_switch import *
from scipy.sparse.csgraph import connected_components
import itertools

class PairScore:
    def __init__(self,G):
        self.G=G;self.states=sorted(G.members);self.ids={v:i for i,v in enumerate(self.states)}
        self.N=len(self.states);bygroup=defaultdict(list)
        for v in self.states:
            for gid in G.vertex_groups[v]:bygroup[gid].append(v)
        fixed={k:[[],[]]for k in range(G.n)};self.variable={}
        for gid,z in enumerate(G.groups):
            k,_=z['key'];c=z['c']
            if not c:continue
            isvariable=len(z['allowed'])>c
            for bit in z['allowed']:
                pairs=[(self.ids[v],self.ids[v^bit])for v in bygroup[gid]if not(v&bit)]
                a=np.array(pairs,dtype=np.int32).T
                if isvariable:self.variable[gid,bit]=(a[0],a[1])
                else:fixed[k][0].append(a[0]);fixed[k][1].append(a[1])
        self.fixed={k:(np.concatenate(a[0])if a[0]else np.array([],np.int32),np.concatenate(a[1])if a[1]else np.array([],np.int32))for k,a in fixed.items()}
        self.pairs=list(itertools.combinations(range(G.n),2));self.pairfixed={}
        for I in self.pairs:
            self.pairfixed[I]=tuple(np.concatenate([self.fixed[k][j]for k in I])for j in range(2))
        self.varbycolor={k:[i for i in G.variable if G.groups[i]['key'][0]==k]for k in range(G.n)}
    def score(self,choices):
        arrays={}
        for k in range(self.G.n):
            a=[[],[]]
            for gid in self.varbycolor[k]:
                mask=choices[gid]
                while mask:
                    bit=mask&-mask;mask-=bit;u,v=self.variable[gid,bit];a[0].append(u);a[1].append(v)
            arrays[k]=tuple(np.concatenate(t)if t else np.array([],np.int32)for t in a)
        scores=[]
        for I in self.pairs:
            u=np.concatenate([self.pairfixed[I][0]]+[arrays[k][0]for k in I]);v=np.concatenate([self.pairfixed[I][1]]+[arrays[k][1]for k in I])
            A=coo_matrix((np.ones(len(u),np.int8),(u,v)),shape=(self.N,self.N)).tocsr()
            scores.append(int(connected_components(A,directed=False,return_labels=False)))
        return sum(scores),scores

def main():
    folder=Path(__file__).parent;R=json.loads((folder/'large_degree_exchange_results.json').read_text());B,g,d=R['B'],R['g'],R['d']
    G=ClosedLocalGraph(B,g,d,set(R['members']));lookup={(k,off):a for k,off,a in R['local_active']}
    choices=[lookup[z['key']]for z in G.groups]
    tic=time.time();S=PairScore(G);score,parts=S.score(choices)
    A=json.loads((folder/'large_pair_coherence_results.json').read_text())
    target=A['stats']['greedy_components']+sum(sum(int(Fraction(t['coefficient']))for t in x['greedy_expansion'])for x in A['bad']if not x['greedy_equal'])
    print('INIT','states',len(G.members),'variables',len(G.variable),'score',score,parts,'target',target,'buildseconds',time.time()-tic,flush=True)
    rng=random.Random(42371);best=score;history=[];evals=0;out={'B':B,'g':g,'d':d,'target':target,'initial_score':score}
    for roundno in range(10):
        ids=list(G.variable);rng.shuffle(ids);improvements=0
        for gid in ids:
            z=G.groups[gid];old=choices[gid];inside=[b for b in z['allowed']if old&b];outside=[b for b in z['allowed']if not old&b]
            candidates=[]
            for a in inside:
                for b in outside:
                    choices[gid]=old^a^b;new,parts=S.score(choices);evals+=1
                    if new>=score:candidates.append((new,a,b,parts))
            choices[gid]=old
            if candidates:
                candidates.sort(reverse=True);new,a,b,parts=candidates[0]
                if new>score or rng.random()<0.04:
                    choices[gid]=old^a^b;score=new
                    if score>best:
                        improvements+=1;best=score;history.append({'round':roundno,'evals':evals,'score':score,'parts':parts,'group':z['key']})
                        print('BEST',history[-1],'seconds',time.time()-tic,flush=True)
                        out.update({'score':score,'parts':parts,'history':history,'local_active':G.actual_active(choices),'seconds':time.time()-tic,'evals':evals})
                        (folder/'large_pair_split_search.json').write_text(json.dumps(out,indent=2))
            if score>=target:break
        print('ROUND',roundno,'score',score,'improvements',improvements,'evals',evals,'seconds',time.time()-tic,flush=True)
        if score>=target:break
    print('DONE',score,'target',target,'seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
