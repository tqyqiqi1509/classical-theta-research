#!/usr/bin/env python3
"""Test cyclic parking shadow rules without using target coefficients."""
from boolean_slots import *
from fractions import Fraction

def main():
    folder=Path(__file__).parent;tic=time.time()
    src=json.loads((ROOT/'agent_packet_propagation'/'mandatory_support_results.json').read_text())
    rules=list(product(['incoming_first','outgoing_first','interleaved'],[False,True],['forward','backward']))
    totals={str(rule):defaultdict(int)for rule in rules};out=[]
    for ci,c in enumerate(src['results']):
        B=c['B'];g=c['g'];d=acyclic_dimension(B,g)[0]
        if sum(d)>14:continue
        F={tuple(p):int(Fraction(*a))for p,a in c['F']};G=SlotSystem(B,g,d)
        rec={'i':ci,'B':B,'g':g,'d':d,'least_mass':sum(F.values()),'rules':[]}
        for rule in rules:
            act,mem,H=G.shadow_rule(*rule)
            eq=H==F;total=totals[str(rule)];total['cases']+=1;total['equals']+=int(eq)
            total['excess_mass']+=len(mem)-sum(F.values())
            rec['rules'].append({'rule':rule,'mass':len(mem),'equals':eq})
        out.append(rec)
        print(ci,'rank',len(g),'d',d,'mass',sum(F.values()),'matches',[r['rule']for r in rec['rules']if r['equals']],flush=True)
        (folder/'shadow_sweep_results.json').write_text(json.dumps({'seconds':time.time()-tic,'totals':{k:dict(v)for k,v in totals.items()},'results':out},indent=2))
    print({k:dict(v)for k,v in totals.items()},flush=True)

if __name__=='__main__':main()
