#!/usr/bin/env python3
"""Look for a negative greedy component after canonical marked cuts."""
from marked_restriction import *
sys.path.insert(0,str(ROOT/'agent_interior'))
from ranktwo_section_positivity import greedy_expand
import random

def main():
    rng=random.Random(20261113);out=[];totals=defaultdict(int);tic=time.time()
    folder=Path(__file__).parent
    for index in range(250):
        b=rng.randint(1,5);c=rng.randint(1,5)
        d0=rng.randint(1,8);d1=rng.randint(1,min(8,14-d0))
        G=SlotSystem([[0,b],[-c,0]],[-d0,c*d0-d1]);active,members,F=G.shadow_rule()
        if sum(F.values())>6000:continue
        rec={'index':index,'B':G.B,'g':G.g,'d':G.d,'mass':len(members),'operations':[]}
        for r,q in [((1,0),(0,0)),((0,1),(0,0)),((0,0),(1,0)),((0,0),(0,1)),
                    ((1,0),(1,0)),((0,1),(0,1)),((1,0),(0,1)),((0,1),(1,0))]:
            if any(r[i]+q[i]>G.d[i]for i in range(2)):continue
            graphs,P=verify_aggregate(G,members,active,r,q);bad=[];good=0;nongreedy=0
            for H in graphs:
                ng,records=ranktwo_component_report(H);good+=ng;nongreedy+=len(records)
                for R in records:
                    E=greedy_expand(b,c,R['h'],{tuple(x['p']):Fraction(x['a'])for x in R['F']})
                    negative=[x for x in E if Fraction(x['coefficient'])<0]
                    if negative:bad.append(dict(R,expansion=E,negative=negative))
            totals['operations']+=1;totals['greedy_components']+=good
            totals['nongreedy_components']+=nongreedy;totals['negative_components']+=len(bad)
            rec['operations'].append({'r':r,'q':q,'greedy':good,'nongreedy':nongreedy,'negative':bad})
            if bad:
                out.append(rec);totals['cases']+=1
                (folder/'marked_ranktwo_stress_results.json').write_text(json.dumps({'totals':dict(totals),'results':out},indent=2))
                print('FAIL',rec['B'],rec['d'],r,q,'bad',len(bad),flush=True);return
        out.append(rec);totals['cases']+=1
        (folder/'marked_ranktwo_stress_results.json').write_text(json.dumps({'totals':dict(totals),'results':out},indent=2))
        if index%10==0:print('AT',index,dict(totals),'elapsed',round(time.time()-tic,2),flush=True)
    print('DONE',dict(totals),'elapsed',time.time()-tic,flush=True)

if __name__=='__main__':main()
