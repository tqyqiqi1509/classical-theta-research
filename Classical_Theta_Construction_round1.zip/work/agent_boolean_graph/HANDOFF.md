# Boolean packet graph handoff

Completed by `/root/boolean_packet_graph`, 2026-11-13 around 07:24 UTC.
The user requested work until 10:12 UTC; the parent requested this agent
to finish its handoff now so a fresh agent can continue. No computation
is still running. All files below are in this directory unless a path
is supplied. These are shared research files; root handles the final
user-facing deliverable and persistence.

## 1. Current main result: coherent selected/unselected deletion

Read **MARKED_DIVIDED_POWER_FUNCTOR.md** first. This is the strongest
new GENERAL graph lemma of this branch. It does not use theta as input.

An input graph has d_i ordered Boolean slots in color i. At vertex u
with degree p, its active i-slots form a set A_i depending only on
other-color bits, of cardinality

    c_i=[-g_i-sum_j b_ij p_j]_+.

Toggle these active bits. Every component is a union of monochromatic
cubes, hence its polynomial is positive in the initial cluster and
its n neighbors.

For every color choose r_i SELECTED markers S_i and q_i UNSELECTED
markers U_i. A marked vertex is (u,S,U). Keep the marker identities
fixed on each edge and delete those slots. The resulting data are

    p'=p-r,   h=g+(r+q)+B r,   d'=d-r-q.

Keep the first [c_i-r_i-q_i]_+ slots of A_i minus (S_i union U_i).
There are enough directions, and the required new packet dimension
is exactly [c_i-r_i-q_i]_+. No vertices are added and no cancellation
occurs. The complete marked graph has character

    sum_p a_p product_i binom(p_i,r_i) binom(d_i-p_i,q_i) z^(p-r).

Selected marking implements D_i^[r]=(x_i partial_y_i)^r/r! with
label shift **+r(e_i+B[:,i])**. Unselected marking implements
x_i^q binom(d_i-y_i partial_y_i,q) with label shift +q e_i.

The prefix rule makes all these operations coherent:

- Distinct colors commute exactly, including adjacent exchange colors.
- Selected and unselected deletions commute with the updated slot count.
- Repeated same-type marking has the appropriate divided-power
  binomial multiplicity.
- Multiplication by x_i is a compatible cut: delete the last active
  direction in each positive-dimensional i-cube.
- If r_i+q_i=d_i the operation is the exact degree-r_i slice, with
  multiplicity one.
- Literal commuting-square axioms for nonadjacent colors are preserved.

The key identity is that the first [c-r-s]_+ survivors after two sets
of deletions equal the first [c-r-s]_+ survivors after their union.
This is an exact finite graph identity, not merely a polynomial one.

### Complement duality

Complement all slots and change (B,g,d) to (-B,g+B d,d). Packet
dimensions and edges are unchanged. The acyclic standard box d is
unchanged, with the opposite topological order. Every origin component
contains the fully selected vertex: fill the colors in topological
order, when the entire current color is active. Thus complement sends
origin component to origin component. Its character is z^d F(z^-1).
Selected deletion under this duality becomes unselected deletion.

### Exact audit

Code and output:

- `marked_restriction.py`, `marked_restriction_results.json`:
  55,987 exhaustive prefix-composition checks and five rank-two inputs.
- `marked_ranktwo_stress.py`, `marked_ranktwo_stress_results.json`:
  250 rank-two inputs, b,c<=5, total slots<=14; 1,919 selected,
  unselected and mixed operations; 82,585 resulting components.
  Of these, 79,885 are individual greedies and 2,700 are positive
  sums of greedies. No negative greedy expansion.
- `marked_highrank_sections.py`, `marked_highrank_sections_results.json`:
  all 1,054 nonempty single-slot restrictions of the 55 stored local
  rank-three through rank-five realizations. Among 99,350 two-color
  components, 99,312 are individual greedies; the remaining 38 have
  positive greedy expansions. No negative expansion.
- `marked_greedy_expansions.json` audits the non-single-greedy
  components from the initial five cases.

These are exact integer/rational checks without optimization. The
higher-rank input graphs were previously built from prescribed
coefficient tables, so these data are not an independent coefficient
construction. A cut component can be a SUM of canonical objects;
coherent rematching is still needed. The derivative functor does not
prove every cut component is a smaller theta object.

## 2. Explicit mutation interface and its exact missing theorem

Read **CUBICAL_COHERENCE_AND_MUTATION.md**.

For a k-packet with off-k degree p, base k-degree s, put

    r=g_k+sum_j b_kj p_j,
    c=[-r]_+,
    alpha=[-g_k]_+ + sum_j[-b_kj]_+ p_j.

Mutation replaces its Boolean c-cube by a Boolean [r]_+-cube at base
alpha-c-s. Negative r contracts a cube to one vertex; positive r
expands a singleton. This is the exact normalized fiber mutation.
Nonnegative new degrees require the one-step normalized carrier;
otherwise weights can be Laurent. Do not silently claim positivity
of reset exponents for every arbitrary pointed U-element.

If every old (k,j)-component has a rank-two greedy packet model, its
mutated rank-two model can be attached to the replacement k-packets.
Match WHOLE k'-packets of the same type (off-degree,base,dimension),
then identify their internal cube bits and carry the new j-edges.
The packet inventories agree because binomial quotient coefficients
of the transformed rank-two polynomial are unique.

The remaining gap is precise: transports through (k,j) and (k,l)
may combine into a new (j,l)-component which is not greedy. A canonical
transport natural under restriction, together with a genuine
three-color compatibility theorem, could give preservation in all
ranks. Existence of separate arbitrary matchings for each pair or
triple is insufficient. Neither this transport theorem nor a theta
identification has been proved.

The marked deletion functor provides a concrete coherent restriction
system to which such a transport could be required to be compatible.
It does not automatically construct the missing transport.

## 3. Literature coherence theorem: applicable scope and obstruction

Read **HIGHER_RANK_GRAPH_COHERENCE_AUDIT.md**.

Primary sources checked directly:

- Fowler--Sims, *Product systems over right-angled Artin semigroups*,
  Theorems 2.1/2.2, Remark 2.3,
  https://www.aidansims.com/papers/FS1999.pdf.
- Hazlewood--Raeburn--Sims--Webster, arXiv:1110.2269, Section 3
  equation (3.2), Theorems 4.4/4.5,
  https://arxiv.org/pdf/1110.2269.

Complete deterministic two-color path interchanges plus three-color
cubic coherence give unique all-rank factorization. Sorting colors
has no new four-color critical ambiguity. But this theorem cannot
be imposed on original active bit edges: the A2 greedy graph
B12=1,d=(1,1),g=(-1,0) is the three-vertex path 00--0--10--1--11.
It has an 01 path and no 10 path with the same endpoints.

The theorem applies naturally to our SLOT DELETION OPERATIONS, which
commute by unions of marks. Mutation operations have changing matrices
and adjacent mutations do not commute. Their required interchange
maps have not been supplied. Do not treat the literature theorem as
proving this missing input.

Relevant web references available to root after opening these URLs:
turn313view0 / turn314view0 / turn315view0 for HRSW,
turn313view1 / turn314view2 / turn315view1 for Fowler--Sims.

## 4. Earlier general graph theorems that remain valid

Read **COLORED_PACKET_SWITCH_THEOREM.md**.

Start with the full standard Boolean cube. Permit degree-preserving
vertex permutations separately for each color, carrying its cube
partition. Such relabelings need not preserve actual outside BITS.

Any integral balanced packet vector bounded by the full cube's
coefficient and quotient inventories can be realized as a union of
components of some such graph: select the packet copies color by
color, then use weightwise bijections to a common vertex subset.

A connected origin component has a proper integral origin-one balanced
subobject iff a finite sequence of equal-degree, single-color incidence
transpositions can first split it. Before the FIRST split the origin
component stays the whole component. After that split, discard other
components and restart; following an entire old permutation path
need not keep subsequent components decreasing.

Thus finite plateau search plus first split gives an integral
indecomposable object. General confluence is NOT proved. The old
conditional confluence theorem assumes a coordinatewise least packet
vector. The full nonnegative packet cone is now known to lack such a
least point in general. Do not infer a general integer graph selector
from that failed rational-cone hypothesis.

The same realization theorem plus root's external theta/Newton tools
gives a graph-only finite family whose least origin-component NEWTON
POLYTOPE is exactly P_theta. This is a Newton theorem, not a
coefficient theorem; root's linear pruning is much more efficient.

## 5. Strict graph rules, successful embeddings, and known failures

`boolean_slots.py` defines `SlotSystem` and exact verification. The
`local=True` option forces A_i to depend only on neighbor BITS. This
is sufficient but stronger than necessary for commuting squares.

The exact nonedge axiom is A_i(u xor e)=A_i(u) for active j-bits e,
and conversely. Dependence on INACTIVE nonneighbor bits is allowed.
Do not enforce neighbor-only locality as if it were intrinsic.

### Cyclic shadow guess

`shadow_rule` / `sparse_shadow` put all color slots in cyclic rational
position order. Selected outgoing neighbors consume preceding slots;
unselected incoming neighbors consume following slots. Free slots
are active. The rule has the right active cardinality and strong
locality, but its higher-rank origin polynomial is NOT always theta.

- Exact rank-two comparison: 493 tested cases match LLZ, 7 resource
  cuts, b,c<=6 and d_i<=12 (`ranktwo_shadow_audit.json`).
- Higher-rank sample: 57 of 60 match prescribed least candidates.
- Complete rank-three upper3,d5 gives mass134; complete rank-four
  upper3,d4/d5 gives masses73/185. These passed coefficient checks.

### Minimal fork failures

Fork A: B=[[0,0,1],[0,0,2],[-1,-2,0]], g=(-3,-2,3),d=(3,2,4).
Shadow mass104 versus candidate98; excess includes degrees011 and112
OUTSIDE exact P_theta, so this is a rigorous theta failure regardless
of coefficient selection.

Fork B: B=[[0,2,1],[-2,0,0],[-1,0,0]],g=(-4,6,2),d=(4,2,2).
Shadow64 versus exact least58; difference is
2 z^(2,1,1)(1+z0+z0 z2), entirely inside P. Interior proved U_P
dimension2 and exactly the corresponding two packet rays.

Both can be repaired by coherent local active-set changes while only
deleting old states. Neither admits a single immediate strict
decreasing bit swap. Neutral plateaus are needed. Files:
`minimal_shadow_failure.json`, `local_switches_results.json`,
`fork_local_subembedding.json`, `fork_coherent_switch_groups.json`.

### Prescribed embeddings

55 targets with total slots<=12 all have exact connected neighbor-local
strict slot realizations. Eleven of the remaining thirteen larger
targets were realized, with two time cuts. No proved infeasibility.
`slot_local_results.json`, `slot_sweep_results.json`, `slot_large_results.json`.

The original 55 local realizations have 8,075 two-color components:
8,073 single greedies and two positive sums, no negative expansion.
`pair_coherence_results.json`.

## 6. The large fork, graph lifting, and why local conditions alone fail

Hard input: B=[[0,0,3],[0,0,2],[-3,-2,0]], d=(8,7,9),g=(-8,-7,29).
Exact P has252 lattice points, U dimension57.

- Initial-star rational minimum mass59030 has a332=15/4; another
  feasible normalized vector has a332=0. This disproves leastness in
  the full star cone. It fails two COMMUTING mutations (0,1), with a
  coefficient -15/2. Packet agent owns exact certificates.
- Independent-set cube completion and all initial rank-two greedy
  slice inequalities give integral mass minimum59085, still with
  coefficient tradeoffs. All three one-step neighbors pass pair tests.
- The natural local shadow graph has mass59103. Its difference from
  the59085 candidate is 6 z^(6,5,3)(1+z1+z1 z2).

The59085 candidate HAS an exact connected neighbor-local slot graph.
To realize it, enlarge the old shadow member set only at degrees653,
663,664. The final graph removes44 old states and adds26 new states,
net -18. All counts, bit closures, active sizes and connectivity were
verified exactly. `large_degree_exchange_results.json` is the complete
graph; `large_degree_exchange.py` reproduces discovery/verification.

Its4,590 pair components comprise4,521 individual greedies and69
positive sums; none has a negative expansion. A local fixed-member
switch search increased the count to4,679, below the4,808 greedy
blocks predicted by splitting all positive sums. This failure is
NOT an impossibility certificate, and stronger neighbor-only locality
may be unnecessarily restrictive.

Default Pieri cuts of this graph are all pointed, but one color2-cut
component has mass4,796 and normalized label(-5,-5,19), whose standard
box is(5,5,6), while that component has widths(5,6,8). Pointedness alone
does not make it an already canonical smaller object.

The parent/interior subsequently found an integral direction D47
passing source pair and recursive Pieri constraints, but failing a
target pair constraint after commuting mutations. See
`../agent_interior/TRANSPORTED_PAIR_REPAIR.md`: one transported cut
forces t2>=t47 and makes59085 coefficientwise least in the refined
finite cone. This is a real overlap constraint, not a proof of a
general finite atlas bound or theta equality.

## 7. Do not revive the incorrect downward-crystal argument

Degree-downward edge orientation cannot have a unique terminal even
for true rank-two greedies. For B12=3,g=(-7,13), d=(7,8),
a_(2,1)=3, a_(1,1)=0 and c(2,1)=(4,0). Every vertex at(2,1) is
necessarily downward terminal in EVERY packet realization. The
natural graph has27 terminal states despite correct greedy mass823.

With source edges oriented upward and sink edges downward, the
natural rank-two graph empirically has one terminal (d0,0), but
these signs cannot be assigned consistently to every adjacent pair
of a general nonbipartite acyclic quiver. No general conclusion.

An additional simple warning is `nonpointed_packet_component.json`:
an arbitrary strict-slot graph on B=[[0,0,2],[0,0,2],[-2,-2,0]],d=(3,3,3)
has an8-vertex non-origin component whose coordinatewise minimum
(0,1,1) is absent. This graph was not required to satisfy independent
color squares; it only illustrates why arbitrary packet components
are not automatically pointed. Do not use it as a counterexample to
the stronger coherent class.

## 8. Best continuation targets

The parent plans a fresh branch on intermediate zero-width vertex
subdivision. The marked functor gives explicit graph restrictions
with which such a construction can be compared.

For graph mutation, the essential next theorem is a concrete
rank-two packet transport compatible with these restrictions and
with all three-color overlaps. Pair character equality is insufficient.
An alternative is to prove simultaneous coherent rematching of the
derived graphs into smaller canonical objects, using the parent's
positive derivative and complementary-derivative theta theorems.

Do not spend the remaining task merely tuning parking-order variants,
optimizing the4,679 pair-component count, or redoing squarefree/forest
cases. Root already has those branches. Preserve the distinction
between exact graph lemmas, finite evidence, and the unresolved
general coefficient/mutation acceptance theorem.

No quantum construction, Li--Pan conclusion, or relabeling of
scattering diagrams/broken lines is used in this branch.
