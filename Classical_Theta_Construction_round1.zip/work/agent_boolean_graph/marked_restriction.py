#!/usr/bin/env python3
"""Exact selected/unselected deletion functor for finite Boolean packets.

All checks use integer bit operations. No coefficient optimizer is used.
The graph construction is general; greedy component comparisons are an
optional finite investigation, not part of the definition.
"""
from boolean_slots import *
from itertools import combinations, product
from functools import lru_cache


def first_bits(a, count):
    out=0
    for _ in range(max(0,count)):
        if not a:raise ArithmeticError('not enough surviving active directions')
        bit=a&-a;out|=bit;a-=bit
    return out


def bits(a):
    out=[]
    while a:
        bit=a&-a;out.append(bit);a-=bit
    return out


class ShiftedDegrees:
    def __init__(self, source, r):self.source=source;self.r=tuple(r)
    def __getitem__(self, v):return tuple(p-r for p,r in zip(self.source[v],self.r))


class MarkedActivation:
    def __init__(self, G):self.G=G
    def __getitem__(self, key):
        k,off=key;G=self.G;a=G.original_active[k,off]
        return first_bits(a&~G.removed[k], a.bit_count()-G.r[k]-G.q[k]-G.cut[k])


class FixedMarkGraph:
    """One fixed tuple of selected/unselected marker identities."""
    def __init__(self, G, members, active, selected=None, unselected=None, cut=None):
        self.original=G;self.original_active=active
        self.n=G.n;self.B=G.B;self.masks=G.masks
        self.selected=tuple(selected or [0]*G.n)
        self.unselected=tuple(unselected or [0]*G.n)
        self.cut=tuple(cut or [0]*G.n)
        self.removed=tuple(s|u for s,u in zip(self.selected,self.unselected))
        for k in range(G.n):
            if (self.selected[k]&self.unselected[k]) or self.removed[k]&~G.masks[k]:
                raise ValueError('invalid markers')
        self.r=tuple(s.bit_count()for s in self.selected)
        self.q=tuple(u.bit_count()for u in self.unselected)
        self.d=tuple(d-r-q for d,r,q in zip(G.d,self.r,self.q))
        self.g=tuple(G.g[k]+self.r[k]+self.q[k]+self.cut[k]
                     +sum(G.B[k][j]*self.r[j]for j in range(G.n))for k in range(G.n))
        sm=sum(self.selected);um=sum(self.unselected)
        self.members={v for v in members if v&sm==sm and not(v&um)}
        self.degrees=ShiftedDegrees(G.degrees,self.r)
        self.active=MarkedActivation(self)

    def components(self):
        unseen=set(self.members);out=[]
        while unseen:
            start=min(unseen);unseen.remove(start);todo=[start];C={start}
            while todo:
                v=todo.pop()
                for k in range(self.n):
                    for bit in bits(self.active[k,v&~self.masks[k]]):
                        w=v^bit
                        if w not in self.members:raise ArithmeticError('restricted edge exits vertices')
                        if w in unseen:unseen.remove(w);C.add(w);todo.append(w)
            out.append(C)
        return out

    def character(self, members=None):
        out=defaultdict(int)
        for v in self.members if members is None else members:out[self.degrees[v]]+=1
        return dict(out)

    def verify(self):
        for v in self.members:
            p=self.degrees[v]
            if not all(0<=p[i]<=self.d[i]for i in range(self.n)):
                raise ArithmeticError('degree outside deleted-slot box')
            for k in range(self.n):
                a=self.active[k,v&~self.masks[k]]
                c=max(0,-self.g[k]-sum(self.B[k][j]*p[j]for j in range(self.n)))
                if a.bit_count()!=c or a&self.removed[k]:raise ArithmeticError('invalid new packet')
                for bit in bits(a):
                    if v^bit not in self.members:raise ArithmeticError('membership not closed')
        return True


def marker_tuples(G, r, q):
    choices=[]
    for mask,ri,qi in zip(G.masks,r,q):
        options=[]
        for selected in combinations(bits(mask),ri):
            s=sum(selected)
            for unselected in combinations(bits(mask&~s),qi):options.append((s,sum(unselected)))
        choices.append(options)
    for choice in product(*choices):yield tuple(x[0]for x in choice),tuple(x[1]for x in choice)


def verify_aggregate(G,members,active,r,q):
    actual=defaultdict(int);graphs=[]
    for s,u in marker_tuples(G,r,q):
        H=FixedMarkGraph(G,members,active,s,u);H.verify()
        for p,a in H.character().items():actual[p]+=a
        if H.members:graphs.append(H)
    expected={}
    for p,a in G.character(members).items():
        count=a
        for k in range(G.n):
            count*=math.comb(p[k],r[k])if p[k]>=r[k]else 0
            count*=math.comb(G.d[k]-p[k],q[k])if G.d[k]-p[k]>=q[k]else 0
        if count:expected[tuple(p[k]-r[k]for k in range(G.n))]=count
    if dict(actual)!=expected:raise ArithmeticError('marked coefficient identity failed')
    return graphs,expected


def verify_compositions(max_slots=7):
    """Exhaustive prefix identity, including inactive marker locations."""
    count=0
    for d in range(max_slots+1):
        full=(1<<d)-1
        for a in range(1<<d):
            c=a.bit_count()
            # Each slot is unmarked, marked first, or marked second.
            for word in product(range(3),repeat=d):
                r=sum((1<<j)for j,x in enumerate(word)if x==1)
                s=sum((1<<j)for j,x in enumerate(word)if x==2)
                nr=r.bit_count();ns=s.bit_count()
                initial=first_bits(a&~r,c-nr)
                sequential=first_bits(initial&~s,initial.bit_count()-ns)
                direct=first_bits(a&~(r|s),c-nr-ns)
                if sequential!=direct:raise ArithmeticError('composition failure')
                count+=1
    return count


@lru_cache(None)
def ranktwo_greedy(b,c,h):
    sys.path.insert(0,str(ROOT/'agent_division'))
    from rank2_saturation_check import llz_F
    return llz_F(b,c,h)[0]


def ranktwo_component_report(H):
    out=[];good=0
    for C in H.components():
        F=H.character(C)
        root=tuple(min(p[j]for p in F)for j in range(2))
        h=tuple(H.g[i]+sum(H.B[i][j]*root[j]for j in range(2))for i in range(2))
        norm={tuple(p[j]-root[j]for j in range(2)):a for p,a in F.items()}
        expected=ranktwo_greedy(H.B[0][1],-H.B[1][0],h)
        equal=norm==expected;good+=int(equal)
        if not equal:
            out.append({'selected':H.selected,'unselected':H.unselected,'g':H.g,
                        'root':root,'h':h,'mass':len(C),'F':dump_table(norm)})
    return good,out


def main():
    folder=Path(__file__).parent
    report={'prefix_compositions_checked':verify_compositions(6),'ranktwo':[]}
    for b,c,d0,d1 in [(1,1,2,2),(2,2,3,3),(3,2,3,3),(3,3,7,8),(1,5,5,4)]:
        G=SlotSystem([[0,b],[-c,0]],[-d0,c*d0-d1]);active,members,F=G.shadow_rule()
        rec={'B':G.B,'g':G.g,'d':G.d,'mass':len(members),'operations':[]}
        operations=[((1,0),(0,0)),((0,1),(0,0)),((0,0),(1,0)),((0,0),(0,1)),
                    ((1,0),(1,0)),((0,1),(0,1)),((1,0),(0,1)),((0,1),(1,0))]
        for r,q in operations:
            graphs,P=verify_aggregate(G,members,active,r,q);good=0;bad=[]
            for H in graphs:
                a,z=ranktwo_component_report(H);good+=a;bad.extend(z)
            row={'r':r,'q':q,'mass':sum(P.values()),'nonempty_tags':len(graphs),
                 'greedy_components':good,'nongreedy_components':len(bad),'failures':bad}
            rec['operations'].append(row)
            print('MARK',b,c,(d0,d1),r,q,'mass',sum(P.values()),'good',good,'bad',len(bad),flush=True)
        report['ranktwo'].append(rec)
        (folder/'marked_restriction_results.json').write_text(json.dumps(report,indent=2))
    print('DONE',report['prefix_compositions_checked'],flush=True)


if __name__=='__main__':main()
