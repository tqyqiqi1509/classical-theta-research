# Cubical coherence and a concrete mutation interface

Research continuation, 2026-11-13, approximately07:07UTC.

## 1. The previous confluence hypothesis is false

The switching theorem in COLORED_PACKET_SWITCH_THEOREM.md remains valid.
Its confluence conclusion was explicitly conditional on an integral least
packet vector. That hypothesis cannot hold generally. The packet agent found
an exact rank-three fork counterexample:

    B=[[0,0,3],[0,0,2],[-3,-2,0]],
    d=(8,7,9), g=(-8,-7,29).

The initial-star rational minimum has mass59030 and a fractional coefficient
a_(3,3,2)=15/4; another feasible normalized vector has that coefficient0.
Thus there is no coordinatewise least initial-star point on the exact theta
Newton carrier. The missing constraint first appears in two COMMUTING
directions. Completing the common independent-color quotient repairs that
particular failure, but neither that completion nor all initial rank-two
greedy slice inequalities restore general coordinatewise leastness.

The source certificates belong to the packet agent; this note does not
substitute solver evidence for those exact certificates.

## 2. A genuine graph axiom for commuting colors

In a strict Boolean-slot graph, let A_i(u) be the active i-slot set at u.
It is independent of u's own i-bits. If b_ij=0, require

    A_i(u xor e)=A_i(u) for every e in A_j(u),
    A_j(u xor f)=A_j(u) for every f in A_i(u).

These are literal commuting-square conditions. Each active i-flip and each
active j-flip can be performed in either order, with the same result. For an
independent set I of colors, the active sets remain fixed throughout its
orbit. Every I-orbit is therefore the product of Boolean cubes of dimensions

    c_i=[-g_i-sum_j b_ij p_j]_+, i in I.

Its character is z^s product_(i in I)(1+z_i)^c_i. Every full connected
component is a union of I-orbits, proving positivity of every simultaneous
independent-set binomial quotient.

### A useful sufficient condition, not the exact condition

It suffices to require that A_i depend only on the bits at quiver neighbors
of i. This is the `local=True` condition in boolean_slots.py. It is stronger
than commuting squares: A_i may legitimately depend on j's INACTIVE bits,
because active j-flips do not change them.

This distinction matters on the hard fork. At sink degree3,

    c_0=0, c_1=1.

There is no active color0 move. Thus A_1 may depend arbitrarily on the
color0 bits at this level without violating the commuting-square axiom.
Neighbor-only dependence would forbid this legitimate freedom.

All55 tested rank3–5 least polynomials with total standard slots<=12 have
exact connected realizations satisfying the stronger neighbor-only condition.
This is evidence about that finite sample, not a general lifting theorem.

## 3. Rank-two regularity is a second, stronger interface

At fixed bits outside colors i,j, inspect connected components using only
i- and j-edges. A natural stronger condition is that each such component
have the character of one shifted rank-two LLZ greedy polynomial.

For b_ij=0 this reduces to the product-cube condition. For adjacent colors
it incorporates the genuine rank-two compatible-pair combinatorics.

The arithmetic consequence is immediate: after aggregating fixed outside
bit configurations with the same outside degree, every two-variable slice
is a nonnegative integral sum of rank-two greedy polynomials. The converse
does not follow: arithmetic branching does not supply simultaneous
partitions of the same vertices and the same one-color packets.

Exact sample inspection found8073 individual greedy components among8075
two-color components in55 local realizations. The remaining two were
positive sums of two greedies; there were no negative greedy expansions.
The actual Boolean graph is therefore quite close to the stronger axiom
in these examples, but this is not a proof that it can always be achieved.

## 4. Why degree-downward confluence cannot be the proof

Orient an active bit edge downward if it decreases its degree coordinate.
If every two-color component had a unique terminal vertex for this
orientation, Newman's lemma would indeed prove global confluence and a
unique coefficient-one coordinatewise least root. The local-confluence
proof is elementary: two competing descents lie in one one- or two-color
component and would reduce to that component's unique terminal vertex.

But the hypothesis is impossible even for genuine rank-two greedy functions.
For B12=3 and g=(-7,13), the greedy polynomial has

    a_(2,1)=3, a_(1,1)=0, and c(2,1)=(4,0).

Every vertex of degree(2,1) is necessarily a downward terminal in EVERY
packet realization: a color0 descent would enter the absent degree(1,1),
while color1 has a zero-dimensional packet. These terminals coexist with
the origin. An even smaller example is d=(4,3),g=(-4,9), where
a_(3,1)=3, a_(2,1)=0 and c(3,1)=(1,0).

The natural rank-two shadow graph for d=(7,8) has27 terminals while its
character is exactly the mass823 greedy polynomial. The larger sample had
120 multi-terminal two-color components,118 of which were individual
greedies. This is structural, not an implementation defect.

A macro-move from a two-color component to its coordinatewise least root
can decrease degree despite an edge path that first goes up. Confluence
of overlapping macro-moves would require new three-color critical-pair
information; it does not follow from Newman's lemma alone.

## 5. Explicit mutation of one-color packets

Here is the finite graph operation that exactly matches one exchange
substitution, before attempting to glue the other colors.

Fix k. A k-packet has fixed off-k degree p, base k-degree s, and dimension

    r=g_k+sum_j b_kj p_j,  c=[-r]_+.

Set

    alpha=[-g_k]_+ + sum_j[-b_kj]_+ p_j,
    c'=[r]_+,  s'=alpha-c-s.

Replace this entire Boolean c-cube by a Boolean c'-cube whose k-degrees are
s',...,s'+c', retaining all other degree coordinates. Thus a negative-r
cube collapses to one vertex, while a positive-r singleton expands to a
cube. The resulting vertex character is exactly the normalized mutated
polynomial, since fiberwise

    (1+t)^c * sum_s q_s t^s
      maps to sum_s q_s t^(alpha-c-s) (1+t)^[r]_+.

The new exchange matrix and label are

    B'=mu_k B,
    g'_k=-g_k,
    g'_i=g_i+[b_ik]_+ g_k-b_ik min(g_k,0), i!=k.

The required new k-packet dimension is correct because r'_k=-r.
If the input lies in the normalized one-step carrier, every s' is
nonnegative. Otherwise the same operation gives finite Laurent weights;
one should not silently claim nonnegative reset exponents.

This operation uses only finite cubes, their base degrees, and integer
arithmetic. It is not a wall-crossing or broken-line construction.

## 6. Reconnecting another color through rank two

Suppose every old(k,j)-component is supplied with a rank-two greedy model
and its one-color cube partitions. The rank-two mutation theorem identifies
its transformed character with one shifted greedy polynomial in the new
rank-two seed. The LLZ remote-shadow bijection gives the relevant finite
quotient correspondence; this is a rank-two combinatorial input.

To glue such a transformed model to the already replaced k-packets:

1. Group its k'-packets by fixed off-k' degree, base degree and dimension.
2. Group the replacement packets belonging to the old(k,j)-component by
   the same data.
3. Match packets of the same type, then identify their internal cube bits.
4. Carry the new j-packet edges across these packet-preserving bijections.

The packet counts agree: they are uniquely determined by division by the
appropriate binomial in the common transformed character. Thus this is an
ordinary finite matching problem. Crucially, matching WHOLE k'-packets
preserves the one k'-partition already shared by all colors; arbitrary
vertexwise matching would not do so.

Doing this separately for all j!=k gives a finite graph whose k,j sectors
have the prescribed mutated rank-two models. In particular it supplies the
new one-color binomial partitions and initial-star positivity in the new
seed, conditional only on the stated rank-two packet models/transports.

## 7. The precise higher-rank gap: compatible three-color reconnection

The previous step says nothing yet about a pair(j,l) with j,l!=k. Its new
edges come from TWO separate reconnections, via(k,j) and(k,l). They may
combine into a non-greedy pair component. This is exactly where a
three-color compatibility theorem is needed.

A useful general target is a canonical rank-two packet transport, natural
under restriction to fixed outside data, satisfying the following lemma:

> In every three-color graph belonging to the proposed class, simultaneous
> packet-preserving transport through color k makes the remaining(j,l)
> components into the prescribed new rank-two greedy models.

If a deterministic transport has this restriction property, a proof of
that three-color lemma proves preservation of pair regularity in every
rank: each potentially problematic new pair is contained in a triple
with k. Involutivity and root/label compatibility must also be proved.

Merely knowing that some reconnection works separately for each triple is
not enough: choices shared by different triples may conflict. Nor is
initial arithmetic pair positivity enough; the root/packet agents have an
exact example positive in initial pair and Pieri tests which acquires
negative rank-two expansion coefficients after two commuting mutations.

This is now a precise finite graph compatibility problem. A theorem about
this transport would provide a mutation acceptance mechanism. At present
no such theorem has been proved, and pair-character agreement is not
being treated as a substitute for it.

## 8. Large exact lifting result and its limits

The hard fork's natural local cyclic-shadow component has mass59103. The
all-pair arithmetic minimum found by the packet agent has mass59085. Their
difference is exactly

    6 z_0^6 z_1^5 z_2^3 (1+z_1+z_1 z_2).

The shifted label of the three-vertex factor is h=(1,-1,1), with standard
d=(0,1,1). Both the shadow polynomial and the difference have nonnegative
rank-two greedy slice expansions.

The mass59085 polynomial DOES have a connected local Boolean-slot
realization. It was found by permitting weight-preserving state exchanges
only at degrees(6,5,3),(6,6,3),(6,6,4). The ambient candidate state set grew
from59103 to149338 states; after removing forced states the binary model had
67089 variables. It solved in4seconds, and every output bit, activation
cardinality, closure condition, degree count and connectivity assertion was
independently checked with integer operations. The final graph removes44
old states and inserts26 new states, reducing mass by18.

Its4590 two-color components comprise4521 individual greedies and69 positive
sums of greedies, with no negative expansions. Thus it satisfies arithmetic
pair positivity even separately at every fixed outside BIT configuration.
It has not yet been made fully pair-regular. Local switches preserving this
member set increased the total two-color component count to4679; the count
predicted by completely separating its positive greedy blocks is4808.
The search's failure to reach that number is not an impossibility proof.

For this graph, default single-bit Pieri cuts yield pointed components in
all three colors. One color2-cut component, mass4796 with root(3,1,1),
normalizes to h=(-5,-5,19) but has widths(5,6,8), exceeding its standard
bound d(h)=(5,5,6). Thus pointedness alone does not imply that a component
is already a smaller canonical object; further coherent splitting is
necessary even in this explicit positive example.

## Main exact artifacts

- slot_local_results.json:55 connected local realizations.
- pair_coherence_results.json:8075 pair components and terminal audit.
- ranktwo_shadow_audit.json:493 exact randomized rank-two comparisons,
  b,c<=6,d_i<=12, all matching LLZ;7 resource cuts.
- large_degree_exchange_results.json:exact59085 local graph and state exchange.
- large_pair_coherence_results.json:4590 pair-component inspections.
- large_pieri_split_results.json:all local color cuts and normalized components.
- sparse_subgraph_embedding.py / large_degree_exchange.py:reproducible exact
  graph lifting searches and integer verification.

All comparisons use classical LLZ rank-two formulas. No quantum conclusion,
Li–Pan conclusion, or scattering/broken-line relabeling is used in the
construction.
