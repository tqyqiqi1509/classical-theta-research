#!/usr/bin/env python3
"""Switch only among local directions that keep a fixed finite member set closed.

For each color k and fixed NEIGHBOR bit pattern, a bit is available if its
toggle preserves the whole current member set. Any c-subset of available
bits defines a local activation rule on that group. This reduces a plateau
search to a finite Cartesian product and cannot add a vertex outside C.
"""
from sparse_shadow import *
import random

class ClosedLocalGraph:
    def __init__(self,B,g,d,members,check_closed=True):
        self.B=B;self.g=g;self.d=tuple(d);self.n=len(g);self.D=sum(d)
        self.offsets=[];s=0
        for a in d:self.offsets.append(s);s+=a
        self.masks=tuple(((1<<a)-1)<<s for a,s in zip(d,self.offsets))
        self.neighbor_masks=tuple(sum(self.masks[j]for j in range(self.n)if B[k][j])for k in range(self.n))
        self.members=set(members);self.degrees={v:tuple(((v&m)>>s).bit_count()for m,s in zip(self.masks,self.offsets))for v in members}
        groups=defaultdict(list)
        for v in members:
            for k in range(self.n):groups[k,v&self.neighbor_masks[k]].append(v)
        self.groups=[];self.gids={}
        for key,vs in sorted(groups.items()):
            k,off=key;p=self.degrees[vs[0]];c=max(0,-g[k]-sum(B[k][j]*p[j]for j in range(self.n)))
            allowed=[]
            if c:
                for i in range(d[k]):
                    bit=1<<(self.offsets[k]+i)
                    if not check_closed or all((v^bit)in self.members for v in vs):allowed.append(bit)
            if check_closed and len(allowed)<c:raise ArithmeticError(('no local rule preserving set',key,c,len(allowed)))
            self.gids[key]=len(self.groups)
            self.groups.append({'key':key,'c':c,'allowed':tuple(allowed),'size':len(vs)})
        self.vertex_groups={v:tuple(self.gids[k,v&self.neighbor_masks[k]]for k in range(self.n))for v in members}
        self.variable=[i for i,z in enumerate(self.groups)if 0<z['c']<len(z['allowed'])]

    def choices(self,rng=None,mode='first'):
        out=[]
        for z in self.groups:
            c=z['c'];bits=z['allowed']
            if rng is not None:bits=rng.sample(bits,c)
            elif mode=='last':bits=bits[-c:]if c else()
            else:bits=bits[:c]
            out.append(sum(bits))
        return out

    def component(self,choices,start=0):
        seen={start};todo=[start]
        while todo:
            v=todo.pop()
            for gid in self.vertex_groups[v]:
                mask=choices[gid]
                while mask:
                    bit=mask&-mask;mask-=bit;w=v^bit
                    if w not in seen:seen.add(w);todo.append(w)
        return seen

    def character(self,C):
        F=defaultdict(int)
        for v in C:F[self.degrees[v]]+=1
        return dict(F)

    def actual_active(self,choices):
        """A compact local-activation lookup for all groups touching the members."""
        return [(z['key'][0],z['key'][1],a)for z,a in zip(self.groups,choices)]

def main():
    folder=Path(__file__).parent;B=[[0,0,3],[0,0,2],[-3,-2,0]];g=(-8,-7,29)
    F,meta=sparse_shadow(B,g,cap=300000);C=set(meta['states']);tic=time.time()
    G=ClosedLocalGraph(B,g,meta['d'],C)
    print('groups',len(G.groups),'variable',len(G.variable),'buildseconds',time.time()-tic,flush=True)
    rng=random.Random(227891);best=len(C)+1;out={'B':B,'g':g,'d':meta['d'],'initial_mass':len(C),'groups':len(G.groups),'variable_groups':len(G.variable),'trials':[]}
    for trial in range(400):
        choices=G.choices(None,'first'if trial==0 else'last')if trial<2 else G.choices(rng)
        comp=G.component(choices);mass=len(comp)
        if mass<best:
            best=mass;out['trials'].append({'trial':trial,'mass':mass});print('trial',trial,'newbest',mass,'seconds',time.time()-tic,flush=True)
            out['mass']=mass;out['F']=dump_table(G.character(comp));out['members']=sorted(comp);out['local_active']=G.actual_active(choices)
            out['choices']=[{'key':G.groups[i]['key'],'mask':choices[i],'c':G.groups[i]['c'],'allowed':G.groups[i]['allowed']}for i in G.variable]
            (folder/'large_local_detachment.json').write_text(json.dumps(out,indent=2))
            if mass<len(G.members):
                G=ClosedLocalGraph(B,g,meta['d'],comp)
                print('restrict','mass',mass,'variablegroups',len(G.variable),flush=True)
        if best<=59085:break
    print('DONE','best',best,'seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
