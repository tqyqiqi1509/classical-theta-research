#!/usr/bin/env python3
"""Test finite rank-two regularity of an existing local Boolean graph."""
from boolean_slots import *
sys.path.insert(0,str(ROOT/'agent_division'))
sys.path.insert(0,str(ROOT/'agent_interior'))
from rank2_saturation_check import llz_F
from ranktwo_section_positivity import greedy_expand
from itertools import combinations
from functools import lru_cache

@lru_cache(None)
def greedy(b,c,h):return llz_F(b,c,h)[0]

def pair_components(G,members,active,I):
    seen=set();out=[]
    for start in sorted(members):
        if start in seen:continue
        C={start};seen.add(start);todo=[start]
        while todo:
            v=todo.pop()
            for k in I:
                am=active[k,v&~G.masks[k]]
                while am:
                    bit=am&-am;am-=bit;w=v^bit
                    if w not in members:raise AssertionError('pair edge exits members')
                    if w not in seen:seen.add(w);C.add(w);todo.append(w)
        out.append(C)
    return out

def inspect(G,members,active):
    results=[];stats=defaultdict(int)
    for I in combinations(range(G.n),2):
        outside=[j for j in range(G.n)if j not in I]
        b=G.B[I[0]][I[1]];c=-G.B[I[1]][I[0]]
        if b<0:raise ValueError('requires topological vertex order')
        for C in pair_components(G,members,active,I):
            offbits=next(iter(C))&~(G.masks[I[0]]|G.masks[I[1]])
            offp=G.degrees[offbits]
            hbar=tuple(G.g[k]+sum(G.B[k][j]*offp[j]for j in outside)for k in I)
            F=defaultdict(int)
            for v in C:F[tuple(G.degrees[v][k]for k in I)]+=1
            root=tuple(min(p[j]for p in F)for j in range(2));mult=F.get(root,0)
            h=(hbar[0]+b*root[1],hbar[1]-c*root[0])
            shifted={tuple(p[j]-root[j]for j in range(2)):a for p,a in F.items()}
            expected=greedy(b,c,h)
            equal=shifted==expected
            stats['components']+=1;stats['greedy_components']+=int(equal)
            terminals=[v for v in C if not any(active[k,v&~G.masks[k]]&v for k in I)]
            diamond=len(terminals)==1
            stats['unique_downward_terminal']+=int(diamond)
            if not equal or not diamond:
                exp=greedy_expand(b,c,hbar,F)
                bad=[t for t in exp if Fraction(t['coefficient'])<0]
                stats['nongreedy_components']+=int(not equal);stats['negative_expansions']+=int(bool(bad))
                stats['multiple_terminals']+=int(not diamond)
                results.append({'I':I,'offbits':offbits,'offdegree':offp,'root':root,'root_multiplicity':mult,
                                'h':h,'mass':len(C),'F':dump_table(F),'greedy_expansion':exp,'negatives':bad,
                                'greedy_equal':equal,'downward_terminals':terminals})
    return dict(stats),results

def main():
    folder=Path(__file__).parent;src=json.loads((folder/'slot_local_results.json').read_text());out=[];total=defaultdict(int)
    for r in src['results']:
        G=SlotSystem(r['B'],r['g'],r['d']);members=set(r['members']);active={(k,off):a for k,off,a in r['active']}
        stats,bad=inspect(G,members,active)
        for k,a in stats.items():total[k]+=a
        out.append({'i':r['i'],'B':r['B'],'g':r['g'],'stats':stats,'bad':bad})
        print(r['i'],stats,flush=True)
        (folder/'pair_coherence_results.json').write_text(json.dumps({'totals':dict(total),'results':out},indent=2))
    print('DONE',dict(total),flush=True)

if __name__=='__main__':main()
