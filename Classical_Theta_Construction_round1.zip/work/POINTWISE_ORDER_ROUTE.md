# Pointwise order as a possible replacement for coefficientwise leastness

2026-11-13 06:53 UTC. Active mechanism, not a proved theta characterization.

The exact minimal-Newton star cone can have no coefficientwise least normalized point. Even the stronger all-rank-two-slice cone has a coordinate tradeoff on the fork B=[[0,0,3],[0,0,2],[-3,-2,0]], g=(-8,-7,29). This does not logically rule out a pointwise least function on the positive real torus. A monomial evaluation objective has weights z^p, a much smaller family than arbitrary nonnegative coefficient objectives.

For the exact all-pair mass-minimum F of mass59085 and the certified alternative H reducing a_(6,5,3) from104 to21, direct arithmetic gives

D=H-F=R+u^6 v^3 w(83/4-2v^2w^2)^2+(45/2)u^6v^5w^2(1-vw)^2,

where all51 coefficients of R are positive. Thus this particular coefficient tradeoff is pointwise above F for every positive u,v,w. Its mass excess is85358. An independent Wolfram evaluation returned {True,26/3,51,85358}: exact identity, smallest nonzero R coefficient, number of R terms, and mass excess.

Files: POINTWISE_TRADEOFF_CERTIFICATE.json, pointwise_difference.json, WOLFRAM_POINTWISE_SOS_CHECK.json. This certificate concerns one witness only; it does not prove that F is pointwise least over the full cone. The packet agent is testing exact rational monomial-evaluation objectives.

General interface: if a candidate is least at every positive point and the feasible families are transported into each other, its function is mutation independent because cluster changes biject the positive tori. Neither hypothesis follows from local slice positivity. One could certify individual tangent differences by nonnegative monomial-weighted squares or nonnegative circuit polynomials, using weighted AM-GM. Such pointwise positivity is weaker than Laurent coefficient positivity and must never be substituted for it.

Primary literature inspected: Iliman--de Wolff, arXiv:1402.0462v3, Introduction, Sections2.3 and3, on circuit numbers and AM-GM/SOS certificates. Its nonnegative-polynomial theorem has no cluster-basis conclusion. The displayed certificate is independently verified and does not depend on that paper.

## 06:58 correction: global pointwise leastness fails

The packet agent completed exact double-description of the tangent cone at F: dimension56,460 active coordinates,99 distinct inequality rows,56 extreme rays, all independently rank-verified. Root found55 rays coefficientwise nonnegative. The remaining ray factors exactly as

    D=u v w(1+v)[(1+u)^5(1+v)^4-u^5 v^4 w^2].

At(u,v,w)=(1,1,32) this is negative. Because D is a tangent-cone ray, F+epsilon D is feasible for sufficiently small positive epsilon. Therefore F is NOT pointwise least over the all-pair feasible cone. The64 exact evaluation certificates remain correct at their tested points; they did not establish a global property. The earlier SOS certificate for one different witness remains correct as well.

This isolates a single exceptional direction in a simplicial tangent cone, providing a sharply specified target for the positive-Pieri and mutation constraints. The general AM-GM certificate tool remains useful for exact analysis of directions, but this branch no longer proposes global pointwise leastness of the present cone.
