# A finite marked-subset calculus for acyclic classical theta functions

2026-11-13, root derivation, independently checked by the interior and Boolean graph branches. This is a new general mechanism in the active research; it is not a claim that the final greedy selector is already proved.

## Conventions and audited inputs

Let B be an acyclic skew-symmetrizable integer exchange matrix. Order its vertices so B_ij >= 0 for i<j. Work with principal coefficients, z_j=y_j x^(B e_j), and theta_g=x^g F_g(z), with initial frozen label zero. Write A=[-B]_+ and define

    d_i(g) = max(0, -g_i + sum_{j<i} A_ij d_j(g)).

The standard product x^v product_i(x_i')^d_i, v=g+(I-A)d, proves supp(F_g) subset [0,d]. This uses the audited finite theta basis and positive multiplication for acyclic principal coefficients. The other input is the positive-slice theorem proved in `agent_interior/POSITIVE_SLICE_THEOREM.md`: a fixed outside-degree slice is a nonnegative integer sum of shifted theta F-polynomials for the remaining principal submatrix. The proof below needs this theorem only in an acyclic extended seed.

## The marked-subset theorem

For r,s in N^n with r+s<=d coordinatewise, define

    M_(r,s) F_g
      = sum_{p>=r} a_p product_i binom(p_i,r_i) binom(d_i-p_i,s_i) z^(p-r),
    h = g+r+s+B r.

Then

    x^h M_(r,s) F_g = sum_q c_q y^q theta_(h+Bq),   c_q in N.

The sum is finite. Every occurring q satisfies

    q+d(h+Bq) <= d-r-s.

In particular, if |r+s|>0 every summand has a strictly smaller total standard box than g. Thus these are finite inequalities using only previously determined smaller-box coefficient tables.

### Proof by independent source and sink leaves

Add two mutable leaves u_i,v_i at every original vertex i. Their only mutable incidences are

    B_(u_i,i)=1, B_(i,u_i)=-1,
    B_(v_i,i)=-1, B_(i,v_i)=1.

Use principal coefficients for the enlarged seed. Append the original symmetrizing integer D_i to both leaves. This gives an integral skew-symmetrizable acyclic extension. Put label zero on u_i and label d_i on v_i. In the order (all u_i, old vertices, all v_i), the standard-box recursion gives degree zero at every leaf and the old degree vector d on the old vertices. Freezing therefore identifies its theta function with

    product_i v_i^d_i * x^g * F_g(eta_i u_i/v_i * x^(B e_i)).

All leaves are pairwise nonadjacent. Mutate all of them; the principal matrix on the old vertices stays B, and the new full seed is still acyclic. A direct exchange calculation gives the normalized F-polynomial

    product_i (1+V_i)^d_i *
       F_g(z_i (1+U_i) V_i/(1+V_i) : i=1,...,n).

Here U_i,V_i are the new leaf coefficient monomials. The old part of the new leading label is g+d. The new source-leaf column has old part +e_i, and the new sink-leaf column has old part -e_i.

Extract the outside degree U^r V^(d-s). The binomial theorem gives

    sum_p a_p product_i binom(p_i,r_i) binom(d_i-p_i,s_i) z^p.

The positive-slice theorem gives a nonnegative shifted theta expansion with old base label g+r+s. Every nonzero monomial has p>=r, so positivity forces every summand root to be >=r. Factor z^r and replace the root by q+r. This gives precisely h=g+r+s+B r and the displayed nonnegative expansion.

Its ordinary coefficient support is contained in [0,d-r-s]. Because the expansion is positive, every individual pointed summand is also supported there. Applying the elementary box lower-bound lemma to that summand proves q+d(h+Bq)<=d-r-s. This also proves the stated strict well-foundedness. No representation-theoretic object or scattering datum is part of the marked-subset operation.

## First-order operations and the genuinely joint inequality

Selected marking gives D_i=x_i partial/partial y_i:

    D_i theta_g = x^(g+e_i+B e_i) partial_i F_g,

where the polynomial derivative is interpreted as sum_p (p_i+1)a_(p+e_i) z^p. Divided powers D_i^r/r! have integer positive theta expansions.

Unselected marking gives

    E_i^d theta_g = x_i (d_i-y_i partial/partial y_i) theta_g
                 = d_i x_i theta_g - y_i D_i theta_g,

and this too has a nonnegative integer theta expansion. Thus positivity of multiplication by x_i and positivity of D_i are not the whole condition: their particular difference above is also positive.

For mixed marking in one color the coefficients are binom(p_i,a)binom(d_i-p_i,b), the new label is g+(a+b)e_i+aB e_i, and the box loses a+b slots of that color. Marking every slot extracts an exact coordinate fiber. The whole collection interpolates between ordinary derivatives, complementary derivatives, and lower-rank slices.

## Finite graph realization

Begin with a bounded colored packet graph whose degree-p vertices are labelled configurations of d_i Boolean slots of color i. Mark r_i selected and s_i unselected slots, retain the marking as part of the vertex label, and delete those slots. The multiplicity of a vertex is exactly the binomial product above.

For a monochromatic Boolean packet with active set C and forced dimension c, retain the first max(0,c-r_i-s_i) unmarked active slots in a fixed slot order and erase the other edges. There are enough unmarked active slots. Other-color packet rules are transported with the fixed markings. This yields the correct new packet dimension and box. The Boolean graph branch proved that successive markings commute: the retained-prefix identity ensures that deleting markings in either order gives the same final active set. Repeated markings of the same selected/unselected type have the usual binomial multiplicity. See its detailed graph proof for boundary cases.

This graph operation is independent of theta coefficients. The theorem above establishes its positive-theta comparison on genuine theta characters. A canonical graph decomposition into lower characters is a further problem, not supplied merely by equality of their generating polynomials.

## What is and is not established

- Established: the positive marked-subset formula in every acyclic classical skew-symmetrizable rank; explicit finite strict size reduction; a graph operation for the same integer weights.
- Established computationally: 11,250 exact rank-two first-derivative expansions, including all b,c in 1..5 and denominator coordinates <=15, are nonnegative. These verify implementation, not the theorem by enumeration.
- Higher-rank candidate tests use recursively chosen candidate tables; they are labelled as conditional comparisons until those tables are identified with theta.
- Not established: that these inequalities uniquely determine F_g, that a forward maximum recurrence is always feasible, or that the resulting candidate is mutation invariant. The hard direction F+D_47 already survives the selected-derivative conditions and Pieri positivity, so those two conditions alone are insufficient for coefficientwise leastness.
- No Li--Pan conclusion is used.
