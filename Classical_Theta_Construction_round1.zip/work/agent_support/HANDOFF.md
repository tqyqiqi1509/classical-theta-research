# Second-wave support-locality handoff

Prepared 2026-11-13 around 04:52 UTC. This subtask is complete; the parent's six-hour research task continues.

## Main proved result

`SECOND_ORDER_FINITE_CRITERION.md` gives a complete arbitrary-rank theorem for classical skew-symmetrizable B:

> For any homogeneous formal coefficient table in the original principal frozen variables, nonnegative coefficients in every seed through total frozen degree two are equivalent to the same test in seeds at word length at most three.

A smaller explicit word list consists of the empty word, every one-letter word, `(j,i),(j,i,j)` for each oriented pair `b_ij>0`, and `(i,j)` for each disconnected pair. Words are applied left to right.

This is stronger than the earlier numerical rank-two-envelope observation. It is a coefficient-row convex-domination result, not equality of full reachable operator sets and not a decision procedure for reddening.

## Key proof

On a pair with B_ij=a>0,B_ji=-b<0, retain only `(00,10,01,11)`. Inactive letters act identically. Active letters are ±ei,±ej,±(ei+ej). The last are central at this cutoff. Every full-rank word has

```
A'11 = A11 + u(gi+a)A01 + v(gj-b)A10
       + [uv gi(gj-b) + tau(b gi+a gj)] A00.
```

Here u,v are integer signed simple-letter counts, tau rational, and all three are independent of g. Positivity of the four known cluster variables xi,xj,xi',xj' gives u,v in {0,1}; positivity of xi at mixed degree gives tau>=uv and xj' gives tau<=u. Thus only `(u,v)=(1,0)` has freedom, and 0<=tau<=1. Its row is a convex combination of two rank-two rows. Five endpoints are realized by `empty,j,i,ji,jij`.

For a=b=0 do not assume c-support connected: allow a general central linear term P gi+Q gj; positivity of xi,xi' gives P=0 and xj,xj' gives Q=0. Pure squared degrees are controlled by one simple letter. This completes the general theorem.

The algorithm and proof do not define scattering diagrams, broken lines, representations, or theta functions. Standard c-sign coherence, tropical duality and cluster Laurent positivity are external correctness inputs. Their known geometric proofs were not redone or concealed.

## Explicit coefficientwise least positive second jet

With A0=1, set ri=[-gi]+. Then Ai=ri and Aii=binom(ri,2). For B_ij=a>0,B_ji=-b<0,

```
Aij = r [-gj]+ + [b*r - [gj]+ min(r,a)]+,   r=[-gi]+.
```

It is coordinatewise least even among jets with larger first-order coefficients; a short three-case inequality proof is included. For a=b=0 it becomes ri*rj.

Section 8 proves, rather than merely tests, agreement with the true LLZ rank-two greedy coefficient. In LLZ coordinates this is c(1,r-1), with denominator label (r,br-gj). Proposition1.6 determines the degree of Q(t)=(1+t)^-(r-a)sum c(1,q)t^q. For r>a and gj=s>=0, its top coefficient is [br-as]+; the other regimes are immediate from the original maximum recurrence. This avoids the incorrect principal-direction one-step-max identification.

`second_order.py` provides the finite word set, least coefficient table and a finite nonnegative rectangle-tail object count for each mixed coefficient. It explicitly disclaims computing a full basis element.

## Verification

`verify_second_order.py` uses actual extended Laurent exponent substitutions from the previous agent as an independent mutation oracle, rather than using the proved four-dimensional formula as its oracle.

- 144 random skew-symmetrizable matrix families, ranks2--7, symmetrizers1--5.
- 1152 actual pair words and 3456 arbitrary signed table/label identity checks.
- 1152 pure-direction checks.
- 28224 closed-form versus five-cut-maximum checks.
- 112896 checks that increasing first coefficients cannot lower below the proposed least mixed coefficient.
- 3025 comparisons with the original LLZ denominator recursion.
- Zero mismatch. 16 requested random words hit a 2048-bit matrix cutoff and were shortened; this is explicitly recorded rather than counted as complete requested words.

Root independently checked 11025 additional parameter combinations using Wolfram.

Output `second_order_verification.json` is small enough for the parent's checkpoint.

## Sources directly inspected

- NZ arXiv1101.3736v3, Theorem1.2 and sign-coherence assumption: `https://arxiv.org/pdf/1101.3736`.
- GHKK author's manuscript `https://paulhacking.github.io/canonicalbases.pdf`: Corollary0.3 (PDFp5) Laurent positivity, Corollary5.5 (PDFp55) c-sign coherence; both opened and found in primary full text.
- LLZ arXiv1208.2391v3, Definition1.3 and Proposition1.6 (PDFpp3--4), directly inspected for the exact recurrence and branch inequalities.
- Qin freezing is a useful optional comparison but NOT used in this proof.

Root must independently open child web sources before using their retrieval references in final citations. References available: `turn99view1` (GHKKc), `turn99view2` (GHKKpositive), `turn97view2` (LLZ branch), `turn95view0` (NZ).

## Exact next question for a fresh context

At total degree D=3, do all infinite-atlas positivity rows lie in the nonnegative cone of rows from finitely many short words (perhaps length5 or7)? The previous degree3 BFS has new operators at depth9--10, but a new operator need not give a new row inequality.

Use `atlas_total` to get operator matrices and word representatives. For each target p, retain only initial q<=p and test whether each long-word row lies in the nonnegative cone generated by short-word rows, using LP/Farkas certificates. If it fails, extract an exact rational/integer coefficient jet, not just a numerical-new-T claim. Whole-operator convexity is unnecessary; coefficient-row domination is enough.

The mechanism to generalize is central lowest-degree derivations bounded by known positive cluster functions. Degree3 has several overlapping central directions; no proof of their joint extremal realization is included here.
