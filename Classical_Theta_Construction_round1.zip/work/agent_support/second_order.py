"""Finite combinatorial second-order saturation for classical cluster algebras.

The input B must be an integral skew-symmetrizable matrix. This module computes
the coefficientwise least normalized jet positive in every original-frozen
cluster chart through degree two. It does NOT compute a complete basis element.
"""
from math import comb


def second_order_test_words(B):
    """A finite word set sufficient for all degree <=2 positivity cuts.

    Word entries are zero-based indices, applied left to right.
    """
    n = len(B)
    words = {()}
    words.update((i,) for i in range(n))
    for i in range(n):
        for j in range(i + 1, n):
            if B[i][j] > 0:
                source, target = i, j
            elif B[i][j] < 0:
                source, target = j, i
            else:
                words.add((i, j))
                continue
            words.add((target, source))
            words.add((target, source, target))
    return sorted(words, key=lambda w: (len(w), w))


def mixed_coefficient(a, b, gi, gj):
    """Assumes B_ij=a>0, B_ji=-b<0; allows a=b=0 as well."""
    r = max(-gi, 0)
    return r * max(-gj, 0) + max(b*r - max(gj, 0)*min(r, a), 0)


def second_order_minimal_jet(B, g):
    n = len(B)
    if len(g) != n or any(len(row) != n for row in B):
        raise ValueError("B must be square and g have matching length")
    out = {(0,) * n: 1}
    for i, gi in enumerate(g):
        r = max(-gi, 0)
        for power, value in ((1, r), (2, comb(r, 2))):
            if value:
                p = [0] * n
                p[i] = power
                out[tuple(p)] = value
    for i in range(n):
        for j in range(i + 1, n):
            if B[i][j] >= 0:
                a, b, gi, gj = B[i][j], -B[j][i], g[i], g[j]
            else:
                a, b, gi, gj = B[j][i], -B[i][j], g[j], g[i]
            value = mixed_coefficient(a, b, gi, gj)
            if value:
                p = [0] * n
                p[i] = p[j] = 1
                out[tuple(p)] = value
    return out


def mixed_objects(a, b, gi, gj):
    """Finite nonnegative objects counted by the mixed coefficient.

    Type 0 is an r by [-gj]+ rectangle. Type 1 is the tail of an r by b
    rectangle after deleting its first [gj]+ min(r,a) linearly ordered cells.
    """
    r, q, s = max(-gi, 0), max(-gj, 0), max(gj, 0)
    for u in range(1, r + 1):
        for v in range(1, q + 1):
            yield (0, u, v)
    cut = s * min(r, a)
    for u in range(1, r + 1):
        for v in range(1, b + 1):
            if b * (u - 1) + v > cut:
                yield (1, u, v)
