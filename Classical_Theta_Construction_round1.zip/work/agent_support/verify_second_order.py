"""Independent checks of the arbitrary-rank second-order criterion.

The mutation oracle substitutes actual extended Laurent exponents, rather than
the four-coordinate normal form proved in the accompanying note.
"""
from pathlib import Path
import sys, random, json, time
from fractions import Fraction
from math import gcd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "agent_division"))
from positive_cuts import transform_series
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E
from rank2_saturation_check import llz_F


def degree(n, i=None, j=None):
    p = [0] * n
    if i is not None:
        p[i] += 1
    if j is not None:
        p[j] += 1
    return tuple(p)


def coefficients(B, g, coef, word, cap):
    _, f = transform_series(B, g, coef, word, cap)
    n = len(B)
    out = {}
    for monomial, value in f.items():
        p = monomial[n:]
        if p in out:
            raise AssertionError("Homogeneity should give a unique mutable exponent")
        out[p] = value
    return out


def choose_B(rng, n):
    D = [rng.randint(1, 5) for _ in range(n)]
    B = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            w = rng.randint(-2, 2)
            q = gcd(D[i], D[j])
            B[i][j] = D[j] // q * w
            B[j][i] = -D[i] // q * w
    return B, D


def bounded_word(B, rng, length, bit_limit=2048):
    E = initial_E(B)
    word = []
    for _ in range(length):
        k = rng.randrange(len(B))
        E = mutate_matrix(E, k)
        if max(abs(x).bit_length() for row in E for x in row) > bit_limit:
            return tuple(word), True
        word.append(k)
    return tuple(word), False


def check_pair(B, i, j, word, rng):
    n = len(B)
    if B[i][j] < 0:
        i, j = j, i
    a, b = B[i][j], -B[j][i]
    z, ei, ej, eij = degree(n), degree(n, i), degree(n, j), degree(n, i, j)
    cap = eij
    Hi = coefficients(B, ei, {z: 1}, word, cap)
    Hj = coefficients(B, ej, {z: 1}, word, cap)
    u, v = Hi.get(ei, 0), Hj.get(ej, 0)
    assert u in (0, 1) and v in (0, 1)
    if a:
        tau = Fraction(Hi.get(eij, 0) + u*v*b, b)
        assert u*v <= tau <= u
        assert Hj.get(eij, 0) == tau*a
    else:
        assert b == 0 and Hi.get(eij, 0) == Hj.get(eij, 0) == 0
        tau = Fraction(0)

    # General signed integer tables and labels test the linear identity,
    # not merely positivity of known examples.
    for _ in range(3):
        g = tuple(rng.randint(-5, 5) for _ in range(n))
        A00, A10, A01, A11 = (rng.randint(-4, 4) for _ in range(4))
        actual = coefficients(B, g, {z:A00,ei:A10,ej:A01,eij:A11}, word, cap)
        expected = {
            z:A00,
            ei:A10+u*g[i]*A00,
            ej:A01+v*g[j]*A00,
            eij:A11+u*(g[i]+a)*A01+v*(g[j]-b)*A10
              +(u*v*g[i]*(g[j]-b)+tau*(b*g[i]+a*g[j]))*A00,
        }
        assert all(actual.get(p,0) == value for p,value in expected.items()), (B,g,word,i,j,actual,expected)
    return (u,v,str(tau)), bool(a)


def check_axis(B, i, word, rng):
    n=len(B)
    z, ei, eii=degree(n),degree(n,i),degree(n,i,i)
    H=coefficients(B,ei,{z:1},word,eii)
    u=H.get(ei,0)
    assert u in (0,1)
    g=tuple(rng.randint(-5,5) for _ in range(n))
    a0,a1,a2=[rng.randint(-4,4) for _ in range(3)]
    T=coefficients(B,g,{z:a0,ei:a1,eii:a2},word,eii)
    assert T.get(eii,0)==a2+u*(g[i]*a1+g[i]*(g[i]-1)//2*a0)


def closed(a,b,gi,gj):
    r=max(-gi,0)
    return r*max(-gj,0)+max(b*r-max(gj,0)*min(r,a),0)


def five_cuts(a,b,gi,gj,Ai=None,Aj=None):
    Ai=max(-gi,0) if Ai is None else Ai
    Aj=max(-gj,0) if Aj is None else Aj
    return max(0,
        -(gj-b)*Ai,
        -(gi+a)*Aj,
        -(gi+a)*(Aj+gj)-(gj-b)*Ai,
        -(gi+a)*Aj-b*gi-a*gj)


def run():
    start=time.time();rng=random.Random(202611130450)
    cases=[];word_cutoffs=0;pair_tests=axis_tests=0
    for n in range(2,8):
        for family in range(24):
            B,D=choose_B(rng,n)
            observed=set();edges=nonedges=0
            for _ in range(8):
                word,cut=bounded_word(B,rng,rng.randint(8,28))
                word_cutoffs+=cut
                i,j=rng.sample(range(n),2)
                sig,edge=check_pair(B,i,j,word,rng)
                observed.add(sig);edges+=edge;nonedges+=not edge;pair_tests+=1
                check_axis(B,i,word,rng);axis_tests+=1
            cases.append(dict(n=n,B=B,D=D,signatures=sorted(observed),edges=edges,nonedges=nonedges))

    closed_checks=0;least_checks=0
    for a in range(1,9):
        for b in range(1,9):
            for gi in range(-10,11):
                for gj in range(-10,11):
                    x=closed(a,b,gi,gj)
                    assert x==five_cuts(a,b,gi,gj)
                    closed_checks+=1
                    for delta_i,delta_j in [(1,0),(0,1),(2,3),(3,2)]:
                        assert five_cuts(a,b,gi,gj,max(-gi,0)+delta_i,max(-gj,0)+delta_j)>=x
                        least_checks+=1

    # Independent original LLZ denominator-pointed recurrence, converted to F.
    llz_checks=0
    for a in range(1,6):
        for b in range(1,6):
            for gi in range(-5,6):
                for gj in range(-5,6):
                    F,_=llz_F(a,b,(gi,gj))
                    assert F.get((1,1),0)==closed(a,b,gi,gj),(a,b,gi,gj,F)
                    llz_checks+=1

    out=dict(matrix_families=len(cases),random_pair_words=pair_tests,
        general_signed_table_identity_checks=pair_tests*3,
        axis_checks=axis_tests,word_bit_cutoffs=word_cutoffs,
        closed_formula_checks=closed_checks,leastness_checks=least_checks,
        independent_LLZ_checks=llz_checks,seconds=time.time()-start,
        mismatches=0,cases=cases)
    Path(__file__).with_name("second_order_verification.json").write_text(json.dumps(out,indent=2))
    print({k:v for k,v in out.items() if k!='cases'})

if __name__=='__main__':run()
