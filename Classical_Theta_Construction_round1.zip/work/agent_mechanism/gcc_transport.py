"""Exact Laurent transport and globally compatible binary-configuration probe.

No scattering or geometric input. Column-convention exchange matrices.
The GCC family is Lee--Li--Mills 2015, Definition 3.1 (not claimed new).
"""
from collections import defaultdict
from math import comb
from itertools import product
import json, random, time

def madd(d,k,v):
    if v:
        d[k] += v
        if d[k] == 0: del d[k]

def mutate_matrix(B,k):
    m,n=len(B),len(B[0])
    return [[-B[i][j] if i==k or j==k else B[i][j]+max(B[i][k],0)*max(B[k][j],0)-max(-B[i][k],0)*max(-B[k][j],0) for j in range(n)] for i in range(m)]

def div_binom(poly,u,v,q):
    """Divide a Laurent polynomial exactly by (x^u+x^v)^q."""
    m=len(u)
    d=tuple(u[i]-v[i] for i in range(m))
    if not any(d):
        div=2**q
        if any(c%div for c in poly.values()): raise ArithmeticError('nonintegral scalar division')
        return {tuple(e[i]-q*v[i] for i in range(m)):c//div for e,c in poly.items()}
    pivot=next(i for i,z in enumerate(d) if z)
    if d[pivot]<0: u,v=v,u;d=tuple(-z for z in d)
    chains=defaultdict(dict)
    for e,c in poly.items():
        ep=tuple(e[i]-q*v[i] for i in range(m))
        t=ep[pivot]//d[pivot]
        key=tuple(ep[i]-t*d[i] for i in range(m))
        chains[key][t]=c
    out=defaultdict(int)
    for key,co in chains.items():
        lo,hi=min(co),max(co)
        vals={}
        for t in range(lo,hi+1):
            ct=co.get(t,0)-sum(comb(q,j)*vals.get(t-j,0) for j in range(1,q+1))
            if ct: vals[t]=ct
        if any(t>hi-q for t in vals):
            raise ArithmeticError('non-Laurent image: binomial remainder')
        for t,c in vals.items():
            e=tuple(key[i]+t*d[i] for i in range(m))
            madd(out,e,c)
    return dict(out)

def transport(f,B,k,term_limit=50000):
    m=len(B)
    if any(abs(e[k])>80 for e in f): raise OverflowError('degree limit')
    u=tuple(max(B[i][k],0) for i in range(m))
    v=tuple(max(-B[i][k],0) for i in range(m))
    slices=defaultdict(dict)
    for e,c in f.items():
        r=e[k]; e0=list(e); e0[k]=0
        slices[r][tuple(e0)]=c
    out=defaultdict(int)
    for r,S in slices.items():
        if r>=0:
            for e,c in S.items():
                for j in range(r+1):
                    t=tuple(e[i]+j*u[i]+(r-j)*v[i]-(r if i==k else 0) for i in range(m))
                    madd(out,t,c*comb(r,j))
        else:
            Q=div_binom(S,u,v,-r)
            for e,c in Q.items():
                t=list(e);t[k]=-r
                madd(out,tuple(t),c)
        if len(out)>term_limit: raise OverflowError('term limit')
    return dict(out)

def gcc(B,a):
    m,n=len(B),len(a)
    out=defaultdict(int)
    for s in product(*[range(a[i]+1) for i in range(n)]):
        if any(B[i][j]>0 and s[i] and a[j]-s[j] for i in range(n) for j in range(n)):
            continue
        e=tuple(-(a[i] if i<n else 0)+sum((a[j]-s[j])*max(B[i][j],0)+s[j]*max(-B[i][j],0) for j in range(n)) for i in range(m))
        madd(out,e,1)
    return dict(out)

def probe(seed=821726, trials=500,depth=12,principal=True):
    rng=random.Random(seed);started=time.time(); checks=0;aborted=0
    for trial in range(trials):
        n=rng.choice([3,4,5])
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                B[i][j]=rng.choice([0,0,1,1,2]);B[j][i]=-B[i][j]
        if principal: B.extend([[int(i==j) for j in range(n)] for i in range(n)])
        a=[rng.choice([0,1,1]) for _ in range(n)]
        if not any(a):continue
        original=B
        f=gcc(B,a);seq=[];prev=-1
        for step in range(depth):
            k=rng.choice([i for i in range(n) if i!=prev]);prev=k;seq.append(k)
            try: f=transport(f,B,k,10000)
            except OverflowError:aborted+=1;break
            checks+=1;B=mutate_matrix(B,k)
            neg=[(e,c) for e,c in f.items() if c<0]
            if neg:
                return dict(status='negative',seed=seed,trial=trial,checks=checks,B=original,a=a,sequence=[k+1 for k in seq],negative=[(list(e),c) for e,c in neg[:20]],terms=len(f),duration=time.time()-started,aborted=aborted)
            if len(f)>2000:aborted+=1;break
    return dict(status='no_negative_in_bounded_probe',seed=seed,trials=trials,checks=checks,duration=time.time()-started,aborted=aborted)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--trials',type=int,default=500);p.add_argument('--depth',type=int,default=12);p.add_argument('--seed',type=int,default=821726);p.add_argument('--no-principal',action='store_true');p.add_argument('--output',default='gcc_probe.json');args=p.parse_args()
    result=probe(args.seed,args.trials,args.depth,not args.no_principal)
    with open(args.output,'w') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))
