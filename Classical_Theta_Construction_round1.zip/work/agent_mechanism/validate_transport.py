"""Independent checks for the exact Laurent mutation engine."""
from collections import defaultdict
from itertools import product
from math import comb
import json, random
from gcc_transport import div_binom, mutate_matrix, transport, gcc

rng=random.Random(13110428)

def mul(f,h):
    z=defaultdict(int)
    for a,c in f.items():
        for b,d in h.items():z[tuple(u+v for u,v in zip(a,b))]+=c*d
    return {a:c for a,c in z.items() if c}

division=0
for _ in range(300):
    n=rng.randrange(2,7);q=rng.randrange(1,6)
    u=tuple(rng.randrange(3) for _ in range(n));v=tuple(rng.randrange(3) for _ in range(n))
    f={tuple(rng.randrange(-4,5) for _ in range(n)):rng.choice([-3,-2,-1,1,2,3]) for _ in range(12)}
    p=defaultdict(int)
    for j in range(q+1):p[tuple(j*u[i]+(q-j)*v[i] for i in range(n))]+=comb(q,j)
    assert div_binom(mul(f,p),u,v,q)==f
    division+=1

involutions=0
adjacency=0
for _ in range(150):
    n=rng.randrange(2,6)
    B=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1,n):B[i][j]=rng.randrange(-2,3);B[j][i]=-B[i][j]
    B += [[int(i==j) for j in range(n)] for i in range(n)]
    a=[rng.randrange(2) for _ in range(n)];f=gcc(B,a)
    for k in range(n):
        BB=mutate_matrix(B,k)
        assert mutate_matrix(BB,k)==B
        ff=transport(f,B,k)
        assert min(ff.values())>0
        assert transport(ff,BB,k)==f
        involutions+=1;adjacency+=1

# Direct symbolic substitution is an implementation-independent small check.
import sympy as sp
symbolic=0
for n in [2,3]:
    B=[[0]*n for _ in range(n)]
    for i in range(n-1):B[i][i+1]=1;B[i+1][i]=-1
    B += [[int(i==j) for j in range(n)] for i in range(n)]
    z=sp.symbols('z:'+str(2*n))
    for a in product([0,1],repeat=n):
        f=gcc(B,a)
        for k in range(n):
            def expr(t):return sum(c*sp.prod(z[i]**e[i] for i in range(2*n)) for e,c in t.items())
            P=sp.prod(z[i]**max(B[i][k],0) for i in range(2*n))+sp.prod(z[i]**max(-B[i][k],0) for i in range(2*n))
            assert sp.cancel(expr(f).subs(z[k],P/z[k])-expr(transport(f,B,k)))==0
            symbolic+=1

result={'status':'all_passed','seed':13110428,'random_signed_binomial_quotient_checks':division,'mutation_involution_checks':involutions,'arbitrary_orientation_binary_adjacent_positivity_checks':adjacency,'independent_symbolic_substitution_checks':symbolic}
with open(__file__.replace('validate_transport.py','transport_validation.json'),'w') as f:json.dump(result,f,indent=2)
print(json.dumps(result))
