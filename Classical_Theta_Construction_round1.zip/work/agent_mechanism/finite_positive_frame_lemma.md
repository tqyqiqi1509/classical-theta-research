# Positive frame bounds for truncated cluster transports

Status: a proved conditional, general-rank mechanism. It does **not** prove the requested higher-rank greedy/theta construction. The hypotheses can be certified by finite integer mutation calculations whenever an appropriate product of cluster variables is found. No scattering object enters either the statement or the coefficient algorithm.

## 1. Setup

Let B be a skew-symmetrizable integer exchange matrix and use principal coefficients at the initial seed. Write x=(x_1,...,x_n), y=(y_1,...,y_n), and z_j=y_j x^{B[:,j]}. All coefficient indices below are in N^n. Let K be any finite down-set of coefficient indices, for example a box 0<=p<=cap. Fix an actual seed t and its G-matrix.

For every initial cluster variable, its normalized Laurent expansion at t has the form

\[
x_i=x_t^{G_t^{-1}e_i}H_{i,t}(z_t),\qquad
z_{t,j}=y_jx_t^{G_t^{-1}B[:,j]}.
\]

Standard principal-coefficient separation, Laurent positivity, and constant-term normalization give H_{i,t}(0)=1 and nonnegative integer coefficients. These H_i are exactly the first columns of the division agent's transports T_t^{e_i}.

For a normalized pointed expression x^g F(z), multiplication and substitution give

\[
T_t^g(F)(z)=H_t(z)^g\,
F\left(z_j\prod_i H_{i,t}(z)^{B_{ij}}\right).
\tag{1}
\]

The variable z here is a formal placeholder for z_t. Negative powers of the units H_i are expanded formally. Each coefficient is a finite integer calculation.

## 2. Positive frame hypothesis

Assume we are given one fixed universally positive pointed expression

\[
f=x^{-r}F(z),\qquad r_i>0,\quad F(0)=1.
\tag{2}
\]

It is enough to know the coefficients of F at indices in K. In the easiest certifiable situation f is a product of cluster variables, each supplied by a finite mutation word, and its leading g-vector is strictly negative in every coordinate. Its F-polynomial and r are then calculated by ordinary integer cluster recurrences.

A reddening sequence is a sufficient source: its terminal G-matrix is a negative permutation matrix, so the product of terminal cluster variables has g=(-1,...,-1). More generally, the chosen cluster variables need not belong to the same cluster. A nonnegative integer combination of their g-vectors lying in the strictly negative orthant gives a certificate of (2).

## 3. The coefficient-bound theorem

**Theorem.** Under (2), for every finite down-set K there are explicitly recursively computable nonnegative integers M_{i,p}, depending only on B,r,F|_K, such that

\[
0\leq [z^p]H_{i,t}\leq M_{i,p}
\]

for every actual seed t, i, and p in K. Consequently, for each fixed g, the restrictions T_t^g mod K form a finite set of integer linear operators.

**Proof.** Let A_t=T_t^{-r}(F). Universal positivity says A_t has nonnegative coefficients and constant term 1. Applying (1) to x^r f=F(z) gives

\[
\left(\prod_i H_{i,t}^{r_i}\right) A_t
= F\left(z_j\prod_i H_{i,t}^{B_{ij}}\right).
\tag{3}
\]

The coefficient of z^p on the left is at least r_i[z^p]H_{i,t}: choose the z^p term from one of the r_i copies of H_i and constant terms from all other factors. Every other contribution is nonnegative.

On the right, the constant monomial of F contributes only the constant 1. Every other term has the shape

\[
a_m z^m\prod_i H_{i,t}^{(Bm)_i},\qquad m>0.
\]

Its z^p coefficient depends only on H_i coefficients of total degree at most |p-m|<|p|. Induction on |p| therefore gives a finite computable upper bound A_p on the absolute value of the right coefficient. Then set M_{i,p}=floor(A_p/r_i). Starting from H_i(0)=1 completes the induction. Formula (1) proves the operator claim, since a finite collection of bounded integer jets admits only finitely many substitutions and multiplications. QED.

## 4. An explicit integer majorant

Assume bounds of lower total degree have been computed. Put

\[
K_i(z)=\sum_{0<|q|<|p|} M_{i,q}z^q,
\]

retaining only q<=p. For an integer a, use

\[
P_a(K)=\begin{cases}
(1+K)^a,&a\geq0,\\
(1-K)^a=\sum_{j\geq0}\binom{-a+j-1}{j}K^j,&a<0.
\end{cases}
\]

This coefficientwise majorizes the absolute coefficients of H_i^a at the needed lower degrees. An explicit valid choice is

\[
A_p=\sum_{0<m\leq p} a_m
[z^{p-m}]\prod_i P_{(Bm)_i}(K_i).
\tag{4}
\]

All sums and powers in (4) truncate at p, so this is a finite integer algorithm. The accompanying `positive_frame_bounds.py` implements exactly (4). It uses no root enumeration or scattering data.

## 5. Scope and remaining gap

This controls arbitrary mutation words and includes mixed red/green repetitions; it does not use a no-repeat assertion. It proves actual finiteness of the truncated transports under the positive-frame hypothesis, rather than merely finiteness of an alphabet of generators.

It does **not** give a stopping criterion for enumerating all actual transports from seeds. A finite bound on possible operators does not by itself tell when all realizable ones have been found. Generating all integer operators within the bounds is a finite over-approximation, but its extra operators may impose invalid positivity constraints. This reachability/normal-form gap must remain explicit.

The existence of a positive frame for every exchange matrix has not been proved here. Reddening is sufficient but is not available for all exchange matrices. A family of positive functions whose leading vectors have a positive combination strictly inside the negative orthant is another sufficient certificate. Using an unknown theta function itself as the frame would be circular for the intended construction.

## 6. Computational verification

The generic integer majorant was compared with the exact transport engine on 1,800 random word states (600 each in ranks 2,3,4), total box cap=(1,...,1), with negative frames computed from sink reddening words. All coefficient nonnegativity and bound assertions passed. This checks the implementation and conventions, not the general theorem. Maximum bounds in the three inputs were 4,74,14600. The rank-4 frame had 270 monomials.

The first attempt to serialize the successful validation encountered a SymPy Integer JSON type error after all assertions passed. The numeric result was then saved using ordinary Python integers; no mathematical check failed.

