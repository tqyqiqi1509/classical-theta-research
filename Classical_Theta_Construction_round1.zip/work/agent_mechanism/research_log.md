# General combinatorial mechanism: live research log

Start: 2026-11-13, approximately 04:12 UTC. Scope: classical cluster algebras; skew-symmetric first, then skew-symmetrizable. This is an intermediate research record, not a claim that the general problem has been solved.

## 1. Lee–Li–Mills binary configurations as a concrete starting mechanism

Primary source: Kyungyong Lee, Li Li, Matthew R. Mills, *A Combinatorial Formula for Certain Elements of Upper Cluster Algebras*, SIGMA 11 (2015), 049, arXiv:1409.8177; https://www.imath.kiev.ua/~sigma/2015/049/ . Full text inspected, especially Theorems 1.1–1.2, Definition 3.1, Lemma 3.3, Lemma 3.5 and its proof.

For a tall extended exchange matrix B (column convention) and a binary denominator vector a, let s_i be a bit whenever a_i=1 and zero otherwise. Forbid s_i=1 and a_j-s_j=1 whenever b_ij>0. The weight of s is

    x^(-a) product_j (M_j^+)^(a_j-s_j) (M_j^-)^(s_j),
    M_j^+ = product_i x_i^[b_ij]_+,  M_j^- = product_i x_i^[-b_ij]_+.

This model already exists in the cited paper. The relevant constructive feature is the exchange-binomial pairing: in the fiber with exponent of x_k equal to -1, the adjacent bits are forced so that s_k is free. Flipping s_k pairs weights whose sum has the factor M_k^+ + M_k^-. Thus transport to an adjacent seed is positive. Arbitrary a are built by level-set products of binary configurations.

What the paper proves: U membership for arbitrary geometric-type seed; a basis if the initial seed is acyclic. What it does not establish as its general result: mutation-invariant family, universal positivity of this family, arbitrary cyclic-seed basis, or equality with higher-rank theta functions. The cyclic 3-vertex example explicitly destroys linear independence. For a=(1,1,1), all three arrows in a directed cycle force all bits equal, leaving only two configurations. Pairwise rank-two-compatible substitutes cannot repair this thin case, because their binary constraint is the same forbidden (1,0) pair.

**Route status:** productive local mechanism, no global closure. The next genuine gap is a multicolored compatibility condition making all exchange-binomial packet decompositions transport consistently; replacing this gap by “choose all globally compatible packet decompositions” would be a tautology.

### Exact computational probe

`gcc_transport.py` implements the displayed binary model and exact sparse Laurent mutation. Negative exponents are handled by integer deconvolution of powers of a binomial on each exponent-lattice coset; no symbolic positivity or scattering oracle is used.

First probe (before an exponent cutoff): random acyclic rank 3–5 matrices with edge weights 1 or 2, principal coefficients, 500 initial binary configurations, non-backtracking paths of length at most 12. Actual completed mutation checks: 4,653. No negative coefficient detected. 270 trajectories were cut for size. Measured runtime approximately 37.82 seconds. This output was observed, but the original JSON was overwritten by the second probe.

Second probe (retained JSON `gcc_probe_principal.json`): same seed 821726, 500 trials, depth at most 8, additional exponent cutoff 80. Actual completed checks 3,511; 175 cut trajectories; runtime approximately 7.02 seconds; no negative coefficient detected. These are bounded probes, not proofs. They concern seed-specific LLM functions, not a new proposed canonical basis. Independent transport identity validation is still to be added before drawing stronger computational conclusions.

## 2. Reading–Stella 2026: useful algebraic interface, carefully delimited

Primary source: Nathan Reading, Salvatore Stella, *Mutation of Theta Functions*, SIGMA 22 (2026), 109, 38 pp.; published 8 November 2026. https://sigma-journal.com/2026/109/ and https://sigma-journal.com/2026/109/sigma26-109.pdf . Bibliography/version details and relevant definitions/theorems inspected against the journal PDF. This is a 2026 source subject to heightened audit.

Relevant portions: §3.3, Theorem 3.9, §5.3–5.4, Theorems 5.6 and 5.14, Example 5.9. The paper uses a wide matrix and row vectors, unlike our code.

Important hypotheses and distinctions:

1. Signed-nondegenerating coefficients are assumed in the global mutation and pointedness results; principal coefficients at some seed suffice.
2. The ambient algebra in Theorem 5.14 is the **small canonical algebra** `can(Btilde)`. One cannot replace it by ordinary A or upper U without another theorem.
3. Its definition of reduced “basis” allows a specified convergent infinite expansion. Remark 3.4 expressly warns against silently identifying it with usual completed-space/Schauder notions. Hamel statements require additional hypotheses.
4. Theorem 5.6 gives all globally pointed elements as theta_m plus freely chosen correction coefficients c_n on a set N_m. It therefore does not assert uniqueness from pointedness.
5. N_m is an intersection over every mutation sequence. Its definition is an algebraic interface but is not a finite combinatorial construction or an algorithm whose termination follows from the theorem.
6. Even if a positive pointed minimum exists, this theorem alone does not show it is theta_m. Scattering-atlas atomicity is a different condition from cluster-atlas positivity.

### Independently verified error in Example 5.9

The journal PDF p.32 (zero-based page 31), including the rendered page, was checked. For the Markov matrix with m=[1,1,1], the printed calculation is

    nu_1(n) = [-n1+2n3+1,n2,n3] if n2>n3,
              [-n1+2n2,  n2,n3] if n2<=n3.

For nonnegative integral n this implies

    n1 <= min(2 n2, 2 n3 + 1),

whereas the article prints `max` in both the prose and the displayed set. For n=(1,0,0), its printed max condition is true, but nu_1(n)=(-1,0,0) violates nonnegativity. This is not an OCR artifact. The strict-containment conclusion of the example still holds with the corrected formula; this local error alone does not refute the main theorem. Any use of N_m in computation must be reconstructed from the definitions, not this erroneous display.

**Route status:** audited as a conditional comparison theorem and a potential way to bound deformations. Not a proof of the requested construction.

## 3. Cluster-positive versus scattering-positive: do not conflate them

Primary source: Ben Davison, Travis Mandel, *Strong positivity for quantum theta bases of quantum cluster algebras*, Inventiones (2021), DOI 10.1007/s00222-021-01061-1; full PDF https://d-nb.info/1243743123/34 . Relevant §1.4 (p.9) inspected. Although quantum, the methodological distinction is relevant to the classical limit.

The paper explicitly describes characterizations relying only on cluster structure as a research direction. Its discussed minimum concerns an entire pointed strongly positive basis, including global monomials. This is much stronger than selecting a single universally positive pointed element. Atomicity relative to the scattering atlas does not prove atomicity or coefficientwise minimality from the cluster atlas alone.

Primary source: K. Lee, L. Li, A. Zelevinsky, *Positivity and tameness in rank 2 cluster algebras*, J. Algebraic Combin. 40 (2014), 823–840; arXiv:1303.5806, https://arxiv.org/pdf/1303.5806 . Definitions and Theorems 1.2–1.3 inspected. In wild rank two, all indecomposable cluster-positive elements do not form a basis; explicit positive elements have negative greedy-basis coefficients. This does not, without a separate pointedness check, refute a fixed-global-g minimum principle.

The standard example for min(b,c)>1 is

    p = G[bc-b+1,c+1] + G[b+1,bc-c+1] - G[1,1].

For b=c=3, in the convention of Rupel–Stella below, its candidate initial leading g is (17,-7), while the other positive summand has g=(5,-4). The first inequality for the global dominance region fails: alpha*(-12)+3<0 for alpha=(3-sqrt(5))/2. Thus the example is not directly a globally pointed deformation at g=(17,-7). A claim that it disproves the fixed-global-g principle would be unjustified.

Primary source: Dylan Rupel, Salvatore Stella, *Dominance Regions for Rank Two Cluster Algebras*, Ann. Comb. 27 (2023), 873–894; arXiv:2206.04778, https://arxiv.org/pdf/2206.04778 . Intro/Theorems 1.1–1.6 and support discussion §6 inspected. The dominance polygon bounds the possible g-indices of pointed deformations. The paper gives maximal support, not a general theta-minimum theorem.

**Route status:** currently open in this investigation. Need either an actual globally pointed positive counterexample or a proof of a minimum selection principle, plus finiteness and arbitrary-rank extension. No such theorem has been established here.
## 4. Mutation-word normal form: routes examined after the first survey

### 4.1. All-green words: a real bound, with a precise limitation

Gupta, *A formula for F-Polynomials in terms of C-Vectors and Stabilization of F-Polynomials*, arXiv:1812.01910v2, https://arxiv.org/pdf/1812.01910 . Lemma 6.2 is on PDF page 19 (zero-based P18). The mutated positive c-root monomials in an all-green word are distinct. Therefore the active word at a fixed box cap has length at most product_i(cap_i+1)-1. The proof uses fundamental monomials and F-polynomial positivity; I checked the proof, not only the statement. The general mixed-red/green statements in §5 are Conjectures 5.7, 5.8, 5.10. The stabilization theorem additionally assumes a periodic green word. Outcome: useful general mechanism for oriented words; does not establish arbitrary-word reduction.

Lin–Musiker–Nakanishi, *Two Formulas for F-Polynomials*, arXiv:2112.11839, https://arxiv.org/pdf/2112.11839 . Theorem 3.1 gives the product formula; its first proof in §4 (PDF pages 10–12) uses F-mutation directly. Theorem 6.2 (PDF page 15) is an explicit generalized-binomial sum. This is genuinely integer algebra for a supplied finite mutation word. Generalized binomials can be signed, and the formulas give no all-word bound. Outcome: verified interface for exact transport, not a manifestly positive higher-rank basis formula.

### 4.2. Root length is determined by the c-vector

This was derived independently and sent to the division agent. For symmetrizer D and an actual column c=C_t[:,k], tropical duality gives row k of G_t^{-1} as (c_i D_ii/D_kk)_i. It is an integer primitive row of a unimodular matrix. Hence

\[
D_{kk}=\gcd_i(|c_i|D_{ii}).
\]

Thus the signed transport generator is determined by B,D,c alone; an extra root-length label is unnecessary. This works for skew-symmetrizable B, not only skew-symmetric B.

### 4.3. Finite alphabet does not imply finite transport set

The coefficient filtration makes the transport group nilpotent modulo a finite cap. Its integral unipotent coordinates can nevertheless be unbounded. Hall collection only gives finitely many coordinate slots, not bounds on their values. Division-agent computations found many shortest representatives with nonadjacent repeated absolute roots, including active word (e1,e2,e2+e3,-e1) along mutation word (0,1,2,0). Therefore deleting repeated roots, or using only free cancellation, is invalid.

Kim–Yamazaki, *Comments on Exchange Graphs in Cluster Algebras*, https://arxiv.org/abs/1612.00145 , reports counterexamples to naïve generation of exchange loops by rank-two loops. Only the abstract was inspected. Outcome: do not invoke a universal square/pentagon word reduction without a separate theorem; the exact stronger statements in the paper are not yet audited.

### 4.4. A closed conditional mechanism: positive negative-g frame bounds

The complete proof and explicit integer recurrence are in `finite_positive_frame_lemma.md`; implementation is `positive_frame_bounds.py`.

Given a universally positive pointed f=x^{-r}F(hat y) with every r_i>0 and F(0)=1, normalized initial-variable expansions x_i -> x_i H_i satisfy

\[
H^r T(f)=F(z_jH^{B[:,j]}).
\]

The left side is nonnegative and its p coefficient dominates r_i[H_i]_p. The right side at degree p depends only on strictly lower-degree H coefficients. Absolute generalized-binomial majorants give explicit recursive integer bounds on every H coefficient, uniformly over **all** mutation words. Thus all truncated transports form a finite set. A reddening sequence supplies such a frame by taking the product of terminal cluster variables. More generally a product of arbitrary known cluster variables with strictly negative leading g-vector suffices. The proof uses only Laurent positivity, separation, and integer substitutions.

Outcome: proved conditional theorem, addressing mixed red/green repetitions without a no-repeat claim. It does not prove a finite-time complete atlas enumeration or an arbitrary-B negative-frame existence theorem. Taking an unknown theta function for f would make the intended construction circular. Generic code validation checked 1,800 word states with no failed mathematical assertions.

## 5. Freezing and Bongartz: retain the algorithmic interface, distinguish proof dependencies

Qin, *Applications of freezing operators on cluster algebras*, arXiv:2407.03186, https://arxiv.org/pdf/2407.03186 . Theorem 1.1/5.11 sends localized cluster monomials to localized cluster monomials under y_j=0 for frozen directions; Remark 1.2 is on PDF page 2 and explicitly states that the proof heavily relies on classical scattering. The operation itself is a finite coefficient deletion. The parent clarified that a purely integer construction may cite an independently audited structural theorem even if its historical proof uses scattering; the forbidden step is defining the new algorithm by scattering data or simply renaming its computation. Accordingly this interface remains active. A wholly combinatorial proof of freezing projection has not been supplied here.

Cao–Gyoda–Yurikusa, *Bongartz completion via c-vectors*, arXiv:2106.11668, https://arxiv.org/pdf/2106.11668 . Theorem 4.15 uses enough g-pairs (Theorem 3.20). The projected-cone condition gives a conceptual way to send arbitrary seeds to a frozen face. Cao–Fang Li, arXiv:1803.05281, provides the enough-g-pairs input through Muller/scattering. Neither statement currently supplies an explicit finite integer projection word in this work. Outcome: useful external correctness interface, constructive stopping rule still missing; do not turn the dependency warning into an automatic rejection of the route.

## 6. Strong review of additional 2026 literature

### 6.1. Qiyue Tang, Hexagon2610.00025v3

Primary sources: https://hexagonmath.org/2610.00025v3 and https://hexagonmath.org/pdf/2610.00025v3 . Inspected the classical-transfer portions; no main quantum result is used as an input. Lemmas 2.1–2.2 contain useful denominator-clearing positivity and common binomial-divisor observations. Lemma 3.1 is on PDF pages 5–6 and uses a quantum degree-capacity inequality and bar symmetry. Those constraints disappear upon specialization v=1, so the finite-rigidity conclusion cannot simply be transferred to the classical case. Sections 4 onward explicitly use scattering realization. Outcome: two elementary algebraic ideas retained, main rigidity/theorem not imported.

### 6.2. Burcroff–Neville, *Eventual sign coherence*

https://arxiv.org/pdf/2605.12865 , May 13, 2026; author homepage also lists the paper. Checked the proof architecture and principal growth lemmas. The arbitrary-initial-frozen-C statement is probability-one behavior of random mutation, not a claim about every word. Fork arguments give growth on directed branches, but growth of total arrow count alone does not prove each frozen c-column stays outside a given cap. Outcome: potentially useful branch-pruning inspiration; no unconditional coefficient-truncation termination input accepted.

### 6.3. Ervin–Neville, *Mutation Cycles from Reddening Sequences*

https://arxiv.org/pdf/2504.06573 ; published September 2026, DOI 10.1007/s00026-026-00849-3. Inspected the introductory structural claims. The paper constructs cycles through triangular extensions and reddening words; it does not make the forkless part uniformly finite or decide arbitrary mutation equivalence. Outcome: not used as a finite-atlas theorem.

### 6.4. Qiu–Liheng Tang, *X-evolution flows/foliations...*

https://arxiv.org/html/2611.09155v1 , November 6, 2026. Inspected Assumption 1.1 and §5 proofs. **Assumption 1.1 requires a green-to-red sequence throughout the paper.** The dominant-set x-order in Definitions 5.3–5.4 is a partial order on partial clusters; Theorem 5.7 gives strict changes at flow crossings; Theorem 5.8 excludes cyclic leaves. This is not a well-founded numerical potential for arbitrary mutation words: the sets involved may be infinite, and no uniform descending-chain bound is proved. Outcome: the proof as read gives a useful oriented monotonicity idea, not the needed all-word finite normal form. No detected error is asserted in those results.

## 7. Support/division uniqueness and positivity distinctions

Lee–Li–Rupel–Zelevinsky, https://arxiv.org/pdf/1405.2311 , classical Theorem 4 on PDF page 2: a prescribed rank-two greedy support region together with two families of binomial divisibilities uniquely determines the greedy element. The support is an essential input; arbitrary finite carriers do not inherit the conclusion. This is a genuine finite linear-algebra interface for the parent's minimal-Newton-carrier route.

The original LLZ greedy paper https://arxiv.org/pdf/1208.2391 states on PDF page 2 that testing positivity in any fixed finite cluster collection does not suffice in general, even in an affine rank-two example (citing Sherman–Zelevinsky Remark 5.8). The alternating-binomial greedy recurrence is not monotone in all previous coefficients. Consequently, neither a trivial monotone iteration argument nor a finite-neighbor universal-positivity claim has been accepted.

The division agent's later degree-two computation is promising: 44 exchange matrices times 8 g-vectors, 1,752,872 actual seed states, zero discrepancies between all-path saturation of a_{ei+ej} and the corresponding rank-two LLZ F coefficient. This is computational evidence from that agent, not an independently established theorem. A naive local max formula already fails in rank two. The useful next target is a proof of support-two reduction through freezing or a finite projection mechanism.
