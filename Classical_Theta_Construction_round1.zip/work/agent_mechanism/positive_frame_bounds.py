"""Pure integer coefficient bounds from one negative positive frame.

Hypothesis, not decided by this program: x^(-r) F(hat y) is universally
positive, r_i > 0, F(0) = 1.  Then every normalized Laurent expansion of
an initial variable has coefficients bounded by the returned table.
The program does not claim to enumerate the complete truncated atlas.
"""
from itertools import product
from math import comb


def mul(a, b, cap):
    out = {}
    for p, v in a.items():
        for q, w in b.items():
            s = tuple(x+y for x, y in zip(p, q))
            if all(x <= c for x, c in zip(s, cap)):
                out[s] = out.get(s, 0) + v*w
    return {p: v for p, v in out.items() if v}


def absolute_power(K, exponent, cap):
    """Majorant of (1+H)^exponent when |coeff H| <= coeff K."""
    zero = (0,)*len(cap)
    out, power = {zero: 1}, {zero: 1}
    maxj = min(sum(cap), exponent) if exponent >= 0 else sum(cap)
    for j in range(1, maxj+1):
        power = mul(power, K, cap)
        if not power:
            break
        coefficient = comb(exponent, j) if exponent >= 0 else comb(-exponent+j-1, j)
        for p, a in power.items():
            out[p] = out.get(p, 0)+coefficient*a
    return out


def frame_bounds(B, r, F, cap):
    n = len(B)
    assert len(r) == len(cap) == n and all(a > 0 for a in r)
    zero = (0,)*n
    assert F.get(zero) == 1 and all(a >= 0 for a in F.values())
    exps = sorted(product(*(range(c+1) for c in cap)), key=lambda p: (sum(p), p))
    bounds = [{zero: 1} for _ in range(n)]
    for p in exps[1:]:
        degree = sum(p)
        Ks = [{q: a for q, a in tab.items() if 0 < sum(q) < degree
               and all(x <= y for x, y in zip(q, p))} for tab in bounds]
        total = 0
        for m, coefficient in F.items():
            if m == zero or any(x > y for x, y in zip(m, p)):
                continue
            target = tuple(x-y for x, y in zip(p, m))
            powers = [sum(B[i][j]*m[j] for j in range(n)) for i in range(n)]
            majorant = {zero: 1}
            for K, exponent in zip(Ks, powers):
                majorant = mul(majorant, absolute_power(K, exponent, target), target)
            total += coefficient*majorant.get(target, 0)
        for i in range(n):
            bounds[i][p] = total//r[i]
    return bounds

