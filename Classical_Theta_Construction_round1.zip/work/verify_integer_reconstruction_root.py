#!/usr/bin/env python3
"""Independent exact audit of the stored K4 reconstruction certificate.

No implementation helper from the generating branch is imported. We rebuild
full cluster F-polynomials with SymPy, verify rational ratio jets, reconstruct
the inverse row backwards, and check the full finite linear system has rank.
"""
from pathlib import Path
from itertools import product
from collections import defaultdict
from math import comb
import json,time
import sympy as sp

BASE=Path(__file__).resolve().parent
data=json.loads((BASE/'agent_pieri_diamond/integer_ratio_k4.json').read_text())
B=sp.Matrix(data['B']);g=sp.Matrix(data['g']);n=B.rows
z=sp.symbols('z0:'+str(n));zero=(0,)*n
Ftarget={tuple(x['p']):int(x['a']) for x in data['F']}

def points(box):
    return sorted(product(*(range(x+1) for x in box)),key=lambda p:(sum(p),p))

def inside(p,box):return all(0<=a<=b for a,b in zip(p,box))

def conv(P,Q,box):
    out=defaultdict(int)
    for p,a in P.items():
        for q,b in Q.items():
            r=tuple(x+y for x,y in zip(p,q))
            if inside(r,box):out[r]+=a*b
    return {p:a for p,a in out.items() if a}

def binomial_power(P,k,box):
    assert P.get(zero)==1
    H={p:a for p,a in P.items() if p!=zero};out={zero:1};term={zero:1}
    for j in range(1,sum(box)+1):
        term=conv(term,H,box)
        if not term:break
        c=int(sp.binomial(k,j))
        for p,a in term.items():out[p]=out.get(p,0)+c*a
    return {p:a for p,a in out.items() if a}

def actual_cluster(word):
    E=B.col_join(sp.eye(n));G=sp.eye(n);F=[sp.Poly(1,*z) for _ in range(n)]
    for k in word:
        terms=[]
        for sign in (1,-1):
            P=sp.Poly(sp.prod(z[i]**max(sign*E[n+i,k],0) for i in range(n)),*z)
            for j in range(n):P*=F[j]**max(sign*E[j,k],0)
            terms.append(P)
        new,rem=sp.div(terms[0]+terms[1],F[k]);assert rem.is_zero
        gg=-G[:,k]+sum((max(E[j,k],0)*G[:,j] for j in range(n)),sp.zeros(n,1))
        gg-=B*sp.Matrix([max(E[n+j,k],0) for j in range(n)])
        E2=E.copy()
        for i in range(2*n):
            for j in range(n):
                E2[i,j]=-E[i,j] if i==k or j==k else E[i,j]+max(E[i,k],0)*max(E[k,j],0)-max(-E[i,k],0)*max(-E[k,j],0)
        E=E2;G[:,k]=gg;F[k]=new
    return E,G,F

tic=time.time();d=[]
for i in range(n):d.append(max(0,-g[i]+sum(max(-B[i,j],0)*d[j] for j in range(i))))
S=[p for p in points(d) if sum(p[i]*(d[i]-p[i]) for i in range(n))-sum(B[i,j]*(d[i]-p[i])*p[j] for i in range(n) for j in range(i+1,n))>=0]
ids={p:i for i,p in enumerate(S)};equations=[];rhs=[]
for k in range(n):
    fibers=defaultdict(list)
    for p in S:fibers[p[:k]+p[k+1:]].append(p)
    for fiber in fibers.values():
        p=fiber[0];power=max(0,-g[k]-sum(B[k,j]*p[j] for j in range(n)))
        for j in range(min(power,max(p[k] for p in fiber)+1)):
            row=[0]*len(S)
            for p in fiber:
                if p[k]>=j:row[ids[p]]=(-1)**(p[k]-j)*comb(p[k],j)
            if any(row):equations.append(row);rhs.append(0)
initial_rank=sp.Matrix(equations).rank()
row=[0]*len(S);row[ids[zero]]=1;equations.append(row);rhs.append(1)
records=[]
for step in data['steps']:
    p=tuple(step['p']);cert=step['ratio_certificate'];chart=cert['cluster_certificate']
    E,G,F=actual_cluster(chart['word']);Gi=G.inv()
    assert E[:n,:]==sp.Matrix(chart['B']) and E[n:,:]==sp.Matrix(chart['C'])
    assert Gi==sp.Matrix(chart['G_inverse'])
    u=sp.Matrix(cert['u']);N=cert['N'];alpha=Gi*u
    ui=list(map(int,u));bi=[[int(B[i,j]) for j in range(n)] for i in range(n)]
    assert min(alpha)>0
    assert all(min(N*alpha+Gi[:,i])>=0 for i in range(n))
    m=g+B*sp.Matrix(p);mi=list(map(int,m));K=sum(p)
    for q in product(*(range(K+1) for _ in range(n))):
        if not 0<sum(q)<=K:continue
        qu=sum(a*b for a,b in zip(q,ui));qm=sum(a*b for a,b in zip(q,mi));assert qu!=0 and qu*qm>=0
        sg=1 if qu>0 else -1
        min_offset=min(0,*[sg*x for x in q])
        min_bend=K*min(0,*[sg*sum(q[i]*bi[i][j] for i in range(n)) for j in range(n)])
        assert N*abs(qu)+min_offset+min_bend>0
    ratios=[{tuple(x['p']):int(x['a']) for x in R} for R in step['R']]
    for i,R in enumerate(ratios):
        num=sp.Poly(1,*z);den=sp.Poly(1,*z)
        for j in range(n):
            a=int(Gi[j,i])
            if a>0:num*=F[j]**a
            if a<0:den*=F[j]**(-a)
        Rp=sp.Poly.from_dict(R,z);residue=num-Rp*den
        assert all(not inside(q,p) for q,a in residue.terms() if a)
    P=points(p);pos={q:i for i,q in enumerate(P)};cols=[]
    for q in P:
        h=g+B*sp.Matrix(q);box=tuple(a-b for a,b in zip(p,q));col={zero:1}
        for i in range(n):col=conv(col,binomial_power(ratios[i],int(h[i]),box),box)
        cols.append({tuple(a+b for a,b in zip(q,r)):a for r,a in col.items()})
    weights={p:1}
    for q in reversed(P[:-1]):
        weights[q]=-sum(weights[r]*a for r,a in cols[pos[q]].items() if r!=q)
    assert sum(weights[q]*Ftarget.get(q,0) for q in P)==0
    eq=[weights.get(q,0) for q in S];equations.append(eq);rhs.append(0)
    print('ROOT VERIFIED',p,flush=True)
    records.append({'p':p,'word':chart['word'],'verified_ratio_jets':n,'inverse_row_zero':True,'ray_inequalities':True})
A=sp.Matrix(equations);target=sp.Matrix([Ftarget.get(p,0) for p in S])
assert A*target==sp.Matrix(rhs)
assert A.rank()==len(S)
out={'status':'independent_exact_certificate_pass','carrier_points':len(S),'initial_rank':initial_rank,'final_rank':A.rank(),'mass':sum(Ftarget.values()),'nonzero_coefficients':len(Ftarget),'records':records,'seconds':time.time()-tic}
(BASE/'ROOT_K4_RECONSTRUCTION_CERTIFICATE.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
