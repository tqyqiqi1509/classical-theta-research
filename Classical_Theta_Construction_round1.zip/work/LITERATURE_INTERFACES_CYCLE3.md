# Third-cycle primary-source interfaces

Checked 2026-11-13, during the active six-hour classical research run. Only specifically inspected statements below are assessed; an abstract or AI-review badge is never treated as proof.

## Cao–Fujita–Murakami, partial F-invariants

Primary source: <https://arxiv.org/abs/2609.08781>, v1, submitted 8 September 2026, 82 pages. Local PDF/text: `references/Cao_Fujita_Murakami_partial_F_2609.08781.*`.

Read the definitions in §2.4 and the full elementary argument in §3.1 (Lemmas 3.1–3.3, Theorem 3.4). These statements concern full-rank classical cluster algebras and good elements, where goodness already includes compatible pointedness at every seed and universal positivity. They are not an existence or finite acceptance criterion for our candidates.

The useful identity is the one-step tropical cocycle. With D=diag(d_i), tropical labels g,h, and normalized positive F-polynomials, write I_t(g,h)=Trop(F_g^t)(D h^t). Then

\[
I_{t'}(g,h)-I_t(g,h)
=d_k\bigl([-g_k^{t'}]_+[-h_k^t]_+-[-g_k^t]_+[-h_k^{t'}]_+\bigr).
\]

The proof is directly checkable: the monomial normalization identity gives the binomial F-reset identity; D h transforms by the Y-pattern tropical mutation; applying the max-plus evaluation gives the formula. Symmetrization cancels the increment. No geometric representation input is needed for this part. The later categorical identifications in §§4–6 were not adopted or fully audited.

**Independent extension being used as a route, not quoted as the paper's theorem.** Define F^t by rational positive Y-resets from any initial positive polynomial and an abstract tropical label. The same algebraic and tropical calculation remains valid before global polynomiality is known, with tropical rational functions in place of support polynomials. Thus the cocycle by itself cannot certify goodness: it also holds for candidates that fail normalized polynomiality. It can still compute exact candidate tropical boundary data without expanding coefficients in every chart. This distinction prevents a circular argument.

Related primary sources: Cao, <https://arxiv.org/abs/2306.11438>, v4, 6 October 2025; Definition 3.6, §3.2 and Theorem 4.10 inspected. The latest <https://arxiv.org/abs/2503.06605> is **withdrawn on 9 September 2026 because its results were incorporated into 2609.08781**. This is not recorded as a mathematical error. The historical v1 is available and its cluster-monomial-only §3.1 agrees with the later mechanism.

Assessment: useful tropical transport interface; no error found in the specifically inspected elementary proof; insufficient for the missing global acceptance theorem. Do not cite the withdrawn item as an independent current result.

## Burcroff–Lee–Mou, tight gradings and leafy trees

Primary source: <https://arxiv.org/abs/2611.10154>, v1, submitted 6 November 2026, 13 pages. Read the definitions and statements across §§2–4, including the final disclosure: this is an extended abstract and proofs of the main bijections are deferred to a later full version. Therefore the stated bijections have not passed a full proof audit here and are not theorem inputs to our construction.

The potentially useful independent combinatorial idea is the subtree balance condition. An m-leafy tree is a finite ordered rooted tree in which every full subtree has strictly more leaves than m times its internal vertices. This suggests turning binomial packet deficits into recursively constrained finite trees. The rank-two central-wall application in the source is not a higher-rank basis construction.

One recursion can be independently derived immediately, without invoking their bijections or scattering. Let T be the generating function of such trees, G=1/(1-T) that of ordered forests, t count internal vertices, and u record the balance leaves minus m times internal vertices. A leaf contributes u. An internal root consumes m units of balance, so its children must form a forest of balance greater than m. Therefore

\[
T=u+t u^{-m}\left(G-\sum_{j=0}^{m}G_j u^j\right),\qquad G_j=[u^j]G,
\]

which yields their displayed quadratic equation

\[
tG^2-\left(u^m(1-u)+t\sum_{j=0}^{m}G_j u^j\right)G+u^m=0.
\]

This recurrence is purely combinatorial, has a direct finite-object interpretation coefficient by coefficient, and has been independently justified above. Transferring its balance condition to multitype cluster packets still requires a specific correspondence; merely naming a wall tree a packet tree would not satisfy the user's goal.

Assessment: useful new combinatorial interface; exact elementary recursion checked; main bijections unaudited because full proofs are absent in this version; no assertion that they are false.
