# Finite Newton pruning from Laurent divisibility

Research note, 2026-11-13, 05:55 UTC. This is a general finite algorithm for a Newton polytope, **not yet an algorithm for the interior coefficients of a theta function**. No Li–Pan theorem is used. The algorithm below uses exchange matrices, integer lattice points and linear equations. Existing theta results enter only its comparison proof and are explicitly identified.

## 1. Setup and external inputs

Work with classical principal coefficients, extended exchange matrix E=(B;I), z_j=y_j x^{B[:,j]}. A homogeneous initially g-pointed Laurent polynomial is x^g F(z), with F in Q[z_1,...,z_n] and F(0)=1.

For the comparison argument assume:

1. The elements of the upper cluster algebra under consideration have finite theta expansions. It suffices that U=mid. In the acyclic case BFZ gives A=U and GHKK gives A contained in mid contained in U, so this follows without an extra conjecture.
2. Theta functions are initially pointed, with nonnegative frozen shifts, and have positive Laurent coefficients.
3. Finite theta expansions satisfy valuative independence for all toric weights. This is CMMM, arXiv:2505.09585v2, Theorems 3.7–3.8. The root agent directly read Sections 2.5, 3.1–3.5 and 3.8, including the local rational-bend deformation and uniqueness of a minimizing taut line. For finite Laurent expansions there are no convergence or finite-infimum issues in the use below. The proof depends on the established positive cluster scattering construction; the proposed algorithm does not construct or enumerate it.

The full-rank principal exchange matrix also makes BFZ's upper bound mutation invariant: membership in U is tested in the initial seed and its n neighbors. This is ordinary Laurent membership, not a claim that positivity can be tested in these seeds.

## 2. Theta is the smallest Newton carrier

**Proposition.** If f=x^g F(z) is initially g-pointed and has a finite theta expansion, then its expansion contains theta_g with coefficient 1 and Newt(theta_g) is contained in Newt(f), retaining the original frozen exponents.

**Proof.** Valuative independence implies that the Newton polytope of every nonzero theta summand is contained in Newt(f): otherwise a separating toric weight would give a strictly smaller valuation on that summand. Regard any frozen monomial multiplying a theta function as part of its full lattice index. Every summand therefore has leading exponent of the form (g,0)+E q, q>=0. If the monomial (g,0) occurs in this summand, pointedness gives (g,0)=(g,0)+E(q+r) with r>=0. The principal E is injective, so q=r=0. Thus only theta_g contributes to the coefficient at (g,0), and it contributes 1 times its expansion coefficient. Since f has that coefficient 1, the theta_g coefficient is 1. The containment follows from the first observation. QED.

No equality between generic-basis and theta Newton polytopes has been assumed. Qin's arXiv:2508.12761v2, Remark 2.20, explicitly presents such equality as a conjectural interface for other pointed bases.

## 3. A finite, purely integer starting carrier in every acyclic rank

Topologically order an acyclic B so A=[-B]_+ is strictly lower triangular. Compute recursively

    d_i=max(0,-g_i+sum_j A_ij d_j),
    v=g+(I-A)d.

Then v,d>=0 and v_i d_i=0. These are finite integer recursions. The standard product

    M_g = product_i x_i^{v_i} (x_i')^{d_i}
        = x^g product_i (1+z_i)^{d_i}

belongs to A and is initially g-pointed. Thus the integer box 0<=p<=d is an explicit starting carrier containing Newt(theta_g). This avoids computing a generic quiver character or assuming that its polytope is the theta polytope.

An alternative in any verified injective-reachable setting is a product of initial variables and variables with mutable g-vectors -e_i. It is unnecessary for the acyclic version above.

## 4. Linear membership equations

Let S be the lattice points of a finite polytope in N^n containing 0. Write F=sum_{p in S} a_p z^p, a_0=1. For each k and each fixed off-k exponent q, let

    P_q(t)=sum_{m:(q,m) in S} a_(q,m) t^m,
    r=g_k+sum_{j!=k} b_kj q_j,
    a=max(0,-r).

Laurent membership in the k-adjacent seed is exactly (1+t)^a dividing P_q(t). This is the finite integer linear system

    sum_{m>=j} (-1)^(m-j) binom(m,j) a_(q,m)=0,
    0<=j<a.

The equivalence follows by the actual exchange substitution; these are divided derivatives at t=-1. There are only finitely many fibers. Together with a_0=1 they define an affine rational space L(S). By the principal upper-bound theorem, these are exactly the initially pointed U-elements supported in S.

## 5. Vertex-deletion algorithm

Start S=([0,d] intersect Z^n). Repeat:

1. Compute the vertices of conv(S).
2. For each vertex v other than 0, test the consistency of L(S) together with a_v=0 by exact rational row reduction (equivalently integer elimination).
3. If a test succeeds, replace S by S minus {v} and repeat. If none succeeds, stop.

The remaining S is always the set of integer points of conv(S): deleting a vertex cannot remove any other lattice point. A theta_g witness remains in L(S) throughout, by the proposition. If a current vertex is outside Newt(theta_g), theta_g itself proves that it is deletable. A vertex belonging to Newt(theta_g) cannot be deleted, because every element of L(S) must contain that polytope. Consequently the process terminates after at most |[0,d] intersect Z^n|-1 deletions and returns exactly Newt(theta_g). Its result is independent of deletion order.

This is a genuine finite algorithm. Its initial box, equations and linear-algebra operations are specified from B and g. It does not ask an oracle for theta coefficients, broken lines, representation varieties or an infinite set of seeds.

## 6. What remains after pruning

At termination each vertex coefficient is constant over L(S), since otherwise an affine rational combination would make it zero. CMMM Theorem 3.15 implies that this constant is 1. Nonzero differences between members of L(S) are supported away from its vertices.

Such interior differences can exist. The polytope computation therefore does not establish a unique polynomial. In particular, a claim that a one-chart minimum-mass point, or the positive cone of the initial star, must be universally positive still needs a separate theorem. That is the next mechanism being investigated.

## 7. Related positive feasibility observation

If a finite-theta element f has monic Newton vertices, replace every theta expansion coefficient by its absolute value. Valuative independence keeps every summand inside Newt(f), and generic toric weights show that each exposed vertex comes from a unique summand. Monicity of theta vertices makes the coefficient of that summand +1. Therefore the absolute-value expansion is universally positive and has exactly the same polytope and the same vertex coefficients.

This proves existence of positive feasible points under the stated finite-theta hypotheses. It is not the definition or implementation of the finite pruning algorithm, and it does not authorize using theta coefficients to compute a proposed combinatorial basis.

## Primary references and audit scope

- BFZ, *Cluster algebras III: Upper bounds and double Bruhat cells*, arXiv:math/0305434: full-rank upper-bound invariance and acyclic A=U. Relevant statements and proof were read by the acceptance agent.
- GHKK, *Canonical bases for cluster algebras*, arXiv:1411.1394v2: Theorem 0.3 and Section 7 give A subset mid subset U; Proposition 0.14 and Section 8.4 give broader full-basis criteria. Root read the exact statements and the relevant principal-coefficient scope.
- Cheung–Magee–Mandel–Muller, *Valuative independence and cluster theta reciprocity*, arXiv:2505.09585v2, updated 2026-05-21: Sections 3.2–3.5 and 3.8 audited as above. No result about cluster-atlas atomicity is inferred.
- Qin, *An introduction to representation-theoretic canonical bases of cluster algebras*, arXiv:2508.12761v2: Remark 2.20 read; equality of Newton polytopes for arbitrary other pointed bases is not treated as a theorem.

Independent agent implementation and further checks are in work/agent_acceptance. This note records the proof and its exact boundary before numerical results are available.
