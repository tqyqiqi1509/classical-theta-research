"""Test the first three-support product coefficient of the formal greedy family.

Exact integer arithmetic. Finite sampled atlases are not claimed complete unless
an independent all-path certificate is supplied. The label scan probes a general
family-level property, not just isolated theta functions.
"""
import sys, json, time, random
from pathlib import Path
from functools import lru_cache
from itertools import product
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'agent_cutcones'))
sys.path.insert(0,str(ROOT/'agent_support'))
from universal_atlas import universal_atlas
from second_order import mixed_coefficient

MASKS=tuple(tuple((s>>i)&1 for i in range(3)) for s in range(8))

def logs(H):
    ans=[]
    for h in H:
        a=list(h)
        for s in (3,5,6):
            i,j=[1<<k for k in range(3) if s>>k&1]
            a[s]=h[s]-h[i]*h[j]
        a[7]=h[7]-h[1]*h[6]-h[2]*h[5]-h[4]*h[3]+2*h[1]*h[2]*h[4]
        ans.append(tuple(a))
    return tuple(ans)

def coefficient(L,g,s):
    def ell(q):return sum(g[i]*L[i][q] for i in range(3))
    if s in (1,2,4):return ell(s)
    if s in (3,5,6):
        i,j=[1<<k for k in range(3) if s>>k&1]
        return ell(s)+ell(i)*ell(j)
    return ell(7)+ell(1)*ell(6)+ell(2)*ell(5)+ell(4)*ell(3)+ell(1)*ell(2)*ell(4)

class SquarefreeGreedy:
    def __init__(self,B,depth=12):
        self.B=B
        self.meta,ee,HH,words=universal_atlas(B,3,depth,seed_cap=100000,bit_cap=4096)
        idx={p:i for i,p in enumerate(ee)}
        data={}
        for H,w in zip(HH,words):
            hh=tuple(tuple(h[idx[p]] for p in MASKS) for h in H)
            data.setdefault(hh,w)
        self.L=[logs(h) for h in data]
        self.words=list(data.values())
        self.shifts=[tuple(sum(B[i][j]*p[j] for j in range(3)) for i in range(3)) for p in MASKS]
        self.coefficient_calls=0

    @lru_cache(maxsize=None)
    def lower(self,g):
        f=[0]*8;f[0]=1
        for i in range(3):f[1<<i]=max(-g[i],0)
        for i in range(3):
            for j in range(i+1,3):
                if self.B[i][j]>=0:
                    v=mixed_coefficient(self.B[i][j],-self.B[j][i],g[i],g[j])
                else:v=mixed_coefficient(self.B[j][i],-self.B[i][j],g[j],g[i])
                f[(1<<i)+(1<<j)]=v
        return tuple(f)

    @lru_cache(maxsize=None)
    def greedy(self,g):
        f=list(self.lower(g));best=0;winner=0
        gg=[tuple(g[i]+self.shifts[q][i] for i in range(3)) for q in range(8)]
        for z,L in enumerate(self.L):
            v=-sum(f[q]*coefficient(L,gg[q],7^q) for q in range(7) if f[q])
            if v>best:best=v;winner=z
        f[7]=best;self.coefficient_calls+=1
        return tuple(f),winner

    def multiply(self,g,h):
        f,_=self.greedy(g);ff,_=self.greedy(h)
        k=tuple(a+b for a,b in zip(g,h));fk,_=self.greedy(k)
        c=[0]*8;c[0]=1
        for p in (1,2,4,3,5,6,7):
            value=sum(f[q]*ff[p^q] for q in range(8) if q&p==q)-fk[p]
            for q in range(1,7):
                if q!=p and q&p==q and c[q]:
                    kk=tuple(k[i]+self.shifts[q][i] for i in range(3))
                    value-=c[q]*self.lower(kk)[p^q]
            c[p]=value
        return c

def scan():
    samples=[
      ('acyclic_chain',[[0,1,0],[-1,0,1],[0,-1,0]]),
      ('acyclic_triangle',[[0,1,1],[-1,0,1],[-1,-1,0]]),
      ('acyclic_234',[[0,2,3],[-2,0,4],[-3,-4,0]]),
      ('cyclic_A3',[[0,1,-1],[-1,0,1],[1,-1,0]]),
      ('cyclic_222',[[0,2,-2],[-2,0,2],[2,-2,0]]),
      ('cyclic_223',[[0,2,-2],[-2,0,3],[2,-3,0]]),
      ('cyclic_333',[[0,3,-3],[-3,0,3],[3,-3,0]]),
      ('valued_123',[[0,2,-3],[-1,0,3],[1,-2,0]]),
    ]
    out=[];rng=random.Random(202611130527)
    target=ROOT/'structure_constants_squarefree_results.json'
    for name,B in samples:
        start=time.time();A=SquarefreeGreedy(B)
        labels=list(product(range(-4,5),repeat=3))
        pairs=[(rng.choice(labels),rng.choice(labels)) for _ in range(150000)]
        negative=[];mins=[0]*8
        for g,h in pairs:
            c=A.multiply(g,h)
            mins=[min(a,b) for a,b in zip(mins,c)]
            if any(v<0 for v in c):
                f,w=A.greedy(g);fh,wh=A.greedy(h);k=tuple(a+b for a,b in zip(g,h));fk,wk=A.greedy(k)
                negative.append({'g':g,'h':h,'c':c,'F_g':f,'F_h':fh,'F_sum':fk,
                                 'top_witness_words':[A.words[j] for j in (w,wh,wk)]})
                if len(negative)>=10:break
        result={'name':name,'B':B,'atlas':A.meta,'squarefree_jets':len(A.L),
                'trials':len(pairs) if not negative else pairs.index((g,h))+1,
                'labels_computed':A.coefficient_calls,'negative':negative,
                'minima':mins,'seconds':time.time()-start,
                'scope':'sampled atlas; independent all-path certificate required'}
        out.append(result)
        target.write_text(json.dumps({'completed':False,'results':out},indent=2))
        print(name,'trials',result['trials'],'labels',A.coefficient_calls,'negative',len(negative),
              'seconds',round(result['seconds'],2),flush=True)
    target.write_text(json.dumps({'completed':True,'results':out},indent=2))

if __name__=='__main__':scan()
