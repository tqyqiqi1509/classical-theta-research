# Integer graded inventories from a finite negative frame

2026-11-13. This is a general coefficient upper bound, not a complete basis
selector. Its proved comparison scope is classical **skew-symmetric** principal
seeds with a supplied finite mutation word whose terminal C-matrix is -P.
The construction contains no theta coefficients, broken lines, or geometric
objects. Quantum positivity is used explicitly in the comparison proof.

## Input and finite integer construction

Let B be an n by n skew-symmetric integer matrix. Supply a mutation word w
and verify by ordinary extended-matrix mutation that C(w)=-P. The independent
negative-frame proof in ../agent_negative_frame establishes G(w)=-P and labels
the terminal cluster variables I_i by g(I_i)=-e_i. The permutation is part
of the certificate, not assumed to be the identity.

Use the integral skew form

    Lambda = [[0,-I],[I,-B]]

on Z^(2n). A graded inventory is a finite integer multiplicity function
N(u,k), where u is a full Laurent exponent and k is an integer charge.
Convolution is the explicit rule

    (u,k)*(v,l) = (u+v,k+l+Lambda(u,v)).                 (1)

Start with the 2n singletons (e_i,0). Along w, compute the ordinary classical
F-polynomials and g-vectors by their finite exchange recurrences. Independently
compute the graded inventories using the same exchange mutations, with (1).

For clarity, the exact division implemented in graded_frame.py is as follows.
Let Lambda_cur be the form in the current cluster and let
a^+_i=[Btilde_ik]_+, a^-_i=[-Btilde_ik]_+. The inventory for the normalized
current monomial M_cur(a) is the ordered convolution of the current variables,
shifted in charge by -sum_(i<j) a_i a_j Lambda_cur,ij. The equation to solve is

    X_k * X'_k = sum_(epsilon=+,-)
      t^(sum_i Lambda_cur,ki a^epsilon_i) M_cur(a^epsilon).     (2)

Order the known classical F-support of X'_k by total frozen degree and then
lexicographically. Its leading Laurent monomial has coefficient1. At each
support point, read the still-unremoved numerator at the sum of that point
and the leading exponent of X_k, correct its charge by Lambda(lead,u), and
subtract its convolution with X_k. Every other term of X_k has strictly
positive frozen degree, so this is a finite triangular integer division.
The complete remainder must vanish. This last check certifies the actual
exchange identity, not just a truncation of it.

The ordinary classical support is a finite scheduling device. It is computed
by exact polynomial division at each mutation; it is not a basis oracle.
Positivity and specialization of quantum cluster variables show that this
support contains precisely the nonzero graded fibers. The implementation
checks positive multiplicities, charge reversal symmetry, origin coefficient1,
the full exchange remainder, and specialization at every step.

For a target label g, form in a fixed order

    M_g = product_i x_i^[g_i]_+ product_i I_i^[-g_i]_+.

All leading exponents have only mutable coordinates, so their pairings under
Lambda are0. Thus the leading inventory of M_g at (g,0) is exactly one object
of charge0. Write the inventory at (g+Bp,p) as m_(g,p,k). Define the finite cap

    C_g(p) = sum_(k in Z) min(m_(g,p,k),m_(g,p,-k)).       (3)

This is the number of objects retained by pairing opposite-charge classes,
with charge0 retained once. Construction (1)-(3) uses only integer arrays,
matrix mutation, finite convolution, and exact integer subtraction/division.

## Comparison theorem

For every classical theta coefficient a_(g,p),

    0 <= a_(g,p) <= C_g(p).                              (4)

Proof. Use the skew-symmetric quantum theta positivity, positive multiplication,
bar invariance, and classical specialization theorem of Davison--Mandel.
The factors x_i and I_i are quantum cluster variables, hence theta elements.
Their product has a positive theta expansion. Homogeneity writes its terms
as coefficient polynomials times frozen translates of theta_(g+Bq).

No occurring translate can have a negative frozen coordinate q_i: its own
leading Laurent monomial would have that negative frozen coordinate and a
positive coefficient, whereas M_g has none. Therefore q>=0. The coefficient
of the monomial (g,0) is1, and only q=0 can contribute there. The coefficient
of the unshifted theta_g is consequently exactly1. This argument also forces
theta_g to be finite whenever needed: a positive summand of the finite M_g
cannot have an infinite Laurent support or infinite positive multiplicities.

Let a_(g,p,k) be the normalized quantum coefficient of this summand. Positive
multiplication and positive theta Laurent expansions give

    0 <= a_(g,p,k) <= m_(g,p,k).

Bar invariance gives a_(g,p,k)=a_(g,p,-k), so it is bounded by the minimum
of the two opposite inventories. Sum over k and specialize to the classical
parameter1 to obtain (4).

This proof establishes an upper inventory. It does not assert that every
opposite-charge matching survives, nor that the cap itself is Laurent.

## Relation to the acyclic Boolean formula

For a topologically ordered acyclic seed, the one-step variables have two
inventory points. Their powers give Gaussian subset statistics. With canonical
capacity d and p selected slots, the total charge inventory is

    t^(-R_d(p)) product_i [d_i choose p_i]_t,
    R_d(p)=sum_(i<j) B_ij(d_i-p_i)p_j.

Its maximum charge is Q_d(p)=sum_i p_i(d_i-p_i)-R_d(p). Thus Q<0 forces
the cap0, and Q=0 forces the cap at most1. This is the previous quadratic
support theorem. The negative-frame construction supplies a finite analogue
when the initial matrix contains oriented cycles.

## Symmetrizable boundary and implementation checks

All displayed integer arithmetic extends with Lambda=[[0,-D],[D,-DB]].
The current comparison proof invokes only the audited skew-symmetric
Davison--Mandel theorem. A nontrivial symmetrizer therefore remains a formal
arithmetic implementation guard, not an unconditional instance of (4).

The four recorded cases in graded_frame_checks.json include three cyclic
skew seeds and one genuinely valued seed. Complete graded exchange division
and insertion of a red backtrack agree in every case. In the three skew
guards, the resulting cap equals the independently certified classical
theta polynomial, whose Newton carrier has a unique normalized Laurent
solution. This coincidence is not promoted to a general sharpness claim.
The valued guard has cap mass11 and true classical mass10; it illustrates
both non-sharpness and the need to preserve the separate proof scope.

## Sources

- Davison--Mandel, Strong positivity for quantum theta bases of quantum
  cluster algebras, arXiv:1910.12915v3, Inventiones226 (2021),725-843:
  https://arxiv.org/abs/1910.12915
- The finite classical negative-frame and Newton-comparison ingredients
  have their separately audited sources in
  ../agent_negative_frame/INJECTIVE_REACHABLE_NEWTON_AND_MARKING.md.

No Li--Pan conclusion or unaudited2026 theorem is used here.
