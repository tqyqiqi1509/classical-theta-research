#!/usr/bin/env python3
"""Finite graded-slot upper inventory from a supplied negative-frame word.

Arithmetic works for integral compatible forms. Theta comparison in this
project is proved only for skew-symmetric principal seeds. No quantum theta
coefficient is queried; only cluster-variable exchange and exact division.
"""
from pathlib import Path
from collections import Counter
import sys,json,time
import sympy as sp
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_negative_frame'))
from negative_frame import symmetrizer,principal_extension,mutate_matrix,negative_permutation


def add(P,Q,sign=1):
    R=dict(P)
    for key,c in Q.items():
        R[key]=R.get(key,0)+sign*c
        if not R[key]:del R[key]
    return R


def shift(P,s):return {(u,k+s):c for (u,k),c in P.items()}


def pairing(L,u,v):
    return sum(u[i]*L[i][j]*v[j] for i in range(len(u)) if u[i]
               for j in range(len(v)) if v[j])


def multiply(P,Q,L):
    R=Counter()
    for (u,k),a in P.items():
        for (v,l),b in Q.items():
            R[tuple(x+y for x,y in zip(u,v)),k+l+pairing(L,u,v)]+=a*b
    return {key:c for key,c in R.items() if c}


def power(P,k,L):
    R={(tuple(0 for _ in L),0):1}
    while k:
        if k&1:R=multiply(R,P,L)
        k//=2
        if k:P=multiply(P,P,L)
    return R


def toric_monomial(X,a,Lcurrent,Linitial):
    assert min(a)>=0
    R={(tuple(0 for _ in Linitial),0):1}
    for P,k in zip(X,a):
        if k:R=multiply(R,power(P,k,Linitial),Linitial)
    correction=-sum(a[i]*a[j]*Lcurrent[i][j]
                    for i in range(len(a)) for j in range(i+1,len(a)))
    return shift(R,correction)


def mutate_lambda(L,E,k):
    m=len(L);T=sp.eye(m)
    T[k,k]=-1
    for i in range(m):
        if i!=k:T[i,k]=max(-E[i][k],0)
    return [[int(x) for x in row] for row in (T.T*sp.Matrix(L)*T).tolist()]


def graded_frame(B,word,term_cap=250000):
    n=len(B);m=2*n;D=symmetrizer(B);E=principal_extension(B)
    L=[[0]*m for _ in range(m)]
    for i in range(n):
        L[i][n+i]=-D[i];L[n+i][i]=D[i]
        for j in range(n):L[n+i][n+j]=-D[i]*B[i][j]
    Lcur=[row[:] for row in L]
    X=[{(tuple(int(i==j) for i in range(m)),0):1} for j in range(m)]
    z=sp.symbols('z0:'+str(n));F=[sp.Poly(1,*z,domain=sp.ZZ) for _ in range(n)]
    G=[tuple(int(i==j) for i in range(n)) for j in range(n)]
    steps=[]
    for step,k in enumerate(word):
        cv=[E[n+i][k] for i in range(n)]
        plus=sp.Poly(sp.prod(z[i]**max(cv[i],0) for i in range(n)),*z,domain=sp.ZZ)
        minus=sp.Poly(sp.prod(z[i]**max(-cv[i],0) for i in range(n)),*z,domain=sp.ZZ)
        for j in range(n):
            plus*=F[j]**max(E[j][k],0);minus*=F[j]**max(-E[j][k],0)
        Fnew,rem=sp.div(plus+minus,F[k],domain=sp.ZZ)
        assert rem.is_zero
        gnew=tuple(-G[k][i]+sum(max(E[j][k],0)*G[j][i] for j in range(n))
          -sum(B[i][j]*max(cv[j],0) for j in range(n)) for i in range(n))
        numerator={}
        for sg in (1,-1):
            a=[max(sg*E[i][k],0) for i in range(m)]
            P=toric_monomial(X,a,Lcur,L)
            P=shift(P,sum(Lcur[k][i]*a[i] for i in range(m)))
            numerator=add(numerator,P)
        remainder=dict(numerator);Q={};lead=G[k]+(0,)*n
        for p,expected in sorted(Fnew.terms(),key=lambda pc:(sum(pc[0]),pc[0])):
            u=tuple(gnew[i]+sum(B[i][j]*p[j] for j in range(n)) for i in range(n))+tuple(p)
            target=tuple(a+b for a,b in zip(lead,u))
            phase=pairing(L,lead,u)
            part={(u,c-phase):a for (exp,c),a in remainder.items() if exp==target}
            assert sum(part.values())==int(expected),(step,k,p,'specialization')
            assert all(a>0 for a in part.values()),(step,k,p,'nonpositive coefficient')
            assert all(part.get((u,-c))==a for (uu,c),a in part.items()),(step,k,p,'bar')
            Q=add(Q,part);remainder=add(remainder,multiply(X[k],part,L),-1)
        assert not remainder,(step,k,'exact division remainder',list(remainder.items())[:3])
        assert len(Q)<=term_cap
        assert Q.get((gnew+(0,)*n,0))==1
        Lnext=mutate_lambda(Lcur,E,k)
        X[k]=Q;F[k]=Fnew;G[k]=gnew;E=mutate_matrix(E,k);Lcur=Lnext
        steps.append({'step':step,'k':k,'classical_support':len(Fnew.terms()),'graded_terms':len(Q)})
    perm=negative_permutation(E[n:]);inverse=[perm.index(i) for i in range(n)]
    assert all(G[inverse[i]]==tuple(-int(i==j) for j in range(n)) for i in range(n))
    return {'B':B,'D':D,'word':word,'permutation':perm,'L':L,'frame':[X[j] for j in inverse],
            'initial':X[n:],'steps':steps}


def inventory(B,word,g):
    state=graded_frame(B,word);n=len(B);L=state['L'];M={(tuple(0 for _ in L),0):1}
    for i,a in enumerate(g):
        if a>0:
            P={(tuple(int(i==j) for j in range(2*n)),0):1}
            M=multiply(M,power(P,a,L),L)
    for i,a in enumerate(g):
        if a<0:M=multiply(M,power(state['frame'][i],-a,L),L)
    byp={}
    for (u,k),a in M.items():
        p=u[n:]
        assert u[:n]==tuple(g[i]+sum(B[i][j]*p[j] for j in range(n)) for i in range(n))
        byp.setdefault(p,{})[k]=a
    caps={p:sum(min(v,cs.get(-k,0)) for k,v in cs.items()) for p,cs in byp.items()}
    return state,caps,byp


def main():
    from implementation_checks import CASES
    results=[];tic=time.time()
    for case in CASES:
        state,caps,byp=inventory(case['B'],case['word'],case['g'])
        scope='unconditional skew comparison' if len(set(state['D']))==1 else 'formal valued arithmetic guard only'
        record={'input':case,'D':state['D'],'scope':scope,'steps':state['steps'],
            'standard_mass':sum(sum(v.values()) for v in byp.values()),'cap_mass':sum(caps.values()),
            'caps':[{'p':p,'cap':caps[p],'charges':sorted(cs.items())} for p,cs in sorted(byp.items())]}
        # Add a red backtrack and check the entire graded frame, not just v=1.
        other=graded_frame(case['B'],[0,0]+case['word'])
        assert other['frame']==state['frame']
        record['red_backtrack_exact_graded_agreement']=True
        results.append(record)
        print({k:v for k,v in record.items() if k not in ('caps','steps')},flush=True)
    Path(__file__).with_name('graded_frame_checks.json').write_text(json.dumps({'results':results,'seconds':time.time()-tic},indent=2))

if __name__=='__main__':main()
