# Common capacity-slot intersection: rejected direct gluing rule

2026-11-13, active research. This note records one new general-object test,
not a substitute for the main coefficient construction.

For a source-source-sink fork, put ordered Boolean slots at each vertex.
For every split t of the sink capacity between its two incident edges,
assign the first t sink slots to the first edge and the remaining slots
to the second. Require each edge restriction to be a genuine rank-two
Dyck compatible pair, simultaneously for every allocation.

This yields a finite direct common object that injects into all allocation
products, so its coefficients respect all those upper bounds. However,
the embeddings are fixed slot restrictions and need not respect Laurent
packet identities. Exact implementation in common_capacity_slot_intersection.py
shows failure already at widths(2,2,3), weights(2,2): its sink fiber over
source counts(1,2) is the constant2 but requires divisibility by(1+z_sink).
Thus it is not an upper-cluster element. At the prior hard widths(8,7,9),
the mass is35311 and it fails34 one-color fibers. No further parameter
sweep of this rule is warranted.

The implication for the general construction is specific: coefficient
majorants do not identify a common set of slot representatives. The
allocation changes need weight-preserving rematching compatible with all
one-color packets. Simply taking intersections of the same bitstrings is
incorrect. The graph majorant theorem itself is unaffected.
