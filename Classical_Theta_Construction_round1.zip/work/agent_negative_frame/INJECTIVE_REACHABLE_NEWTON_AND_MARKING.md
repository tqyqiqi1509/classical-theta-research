# Finite Newton pruning and marked calculus from a negative frame

Research derivation and independent scope check, 2026-11-13. Classical cluster algebras only. All statements below allow an arbitrary integral skew-symmetrizable exchange matrix, including directed cycles, provided a finite negative-frame certificate is supplied. No Li–Pan conclusion is used.

The new concrete outputs are a finite Newton algorithm, an exact simultaneous freezing threshold, and a strictly decreasing marked-subset calculus. They do not yet identify the interior coefficients of every theta function by a canonical counting rule.

## 1. Conventions and exact external inputs

Let (B\in\mathbb Z^{n\times n}) be skew-symmetrizable, with (DB) skew-symmetric for a positive integral diagonal (D). Work with classical principal coefficients, extended matrix (E=(B;I_n)), and

\[
z_i=y_i x^{B e_i},\qquad
\theta_g=x^gF_g(z),\qquad F_g(0)=1.
\]

The frozen variables are invertible. A principal coefficient statement is retained before any coefficient specialization: projected or specialized Newton polytopes need separate care.

The input includes a finite mutation word (\mathbf k) whose exact principal (C)-matrix at the end is (-P), with (P) a permutation matrix. No assumption that every step is green is made.

The comparison proof uses these individually scoped results:

1. **Negative frame and finite theta basis.** Qin, *Bases for upper cluster algebras and tropical points*, arXiv:1902.09507v4, Proposition 2.3.3 and Theorem A.1.5. The paper's seed convention is skew-symmetrizable. In the classical case, injective reachability gives finite pointed theta functions for every lattice label and a basis of the upper cluster algebra (U). Full rank is automatic for principal coefficients.
2. **Initial-star upper bound.** BFZ, arXiv:math/0305434v3, Theorem 1.5, Proposition 1.8 and Corollary 1.9: full column rank makes the upper bound invariant, so the initial chart and its (n) neighbors test membership in (U). This does not require acyclicity. The separate statement (A=U) is not used.
3. **Newton containment and monic vertices.** Cheung–Magee–Mandel–Muller, arXiv:2505.09585v2, Theorems 3.8 and 3.15, together with the positivity statement for skew-symmetrizable seed data in Theorem 4.11. Only finite theta expansions and finite Newton polytopes enter here. The 2026 version and its proof dependencies are recorded in `LITERATURE_SCOPE_AUDIT.json` and the root audit.
4. **Positivity and freezing.** Ordinary theta multiplication has nonnegative integral structure constants. Freezing sends a theta function to the theta function of the frozen seed, and frozen monomials factor out. The precise freezing statement is Qin, arXiv:2407.03186v1, Theorem 5.2. The classical scope of Section 6.4 is skew-symmetrizable. Proposition 6.19 is a useful independent comparison, but the explicit stabilization proof below does not use it.

Version correction: Qin A.1.5 cites GHKK's published Proposition 8.25. In arXiv:1411.1394v2, the large-cluster-complex/full-basis statement is **Proposition 8.28**; its Corollary 8.25 is only a finite-generation statement. These numberings must not be mixed.

## 2. The negative-frame carrier is entirely finite

Write (C_t) for the principal (C)-matrix and (G_t) for the mutable (g)-matrix along the supplied word. Tropical duality gives

\[
G_t^{\mathsf T}D C_t=D.
\]

At (C_t=-P), this says (G_t=-D^{-1}PD). Each nonzero entry has absolute value (D_j/D_{P(j)}), a positive integer. Around every permutation cycle their product is one, so each is one. Consequently (P) preserves (D) and (G_t=-P). Reindex the terminal cluster variables as (I_i), so their initial mutable labels are (-e_i).

Their (F)-polynomials are computed by the ordinary recurrence. If (c_k) is the current (k)-th (C)-column and (B_t=(b_{ij})), then

\[
F'_k=
\frac{z^{[c_k]_+}\prod_jF_j^{[b_{jk}]_+}
      +z^{[-c_k]_+}\prod_jF_j^{[-b_{jk}]_+}}{F_k},
\qquad F'_j=F_j\ (j\ne k).
\]

Here (z) is merely the formal (F)-polynomial variable; the eventual evaluation is (z_i=y_i x^{Be_i}). Start with all (F_i=1). Exact polynomial division verifies the recurrence at every step. The implementation also computes (g)-vectors independently and checks (G=-P), constant coefficient one, and positive integral coefficients.

For any (g\in\mathbb Z^n), set

\[
M_g=\prod_i x_i^{[g_i]_+}\prod_i I_i^{[-g_i]_+}
    =x^g\prod_iF_{I_i}(z)^{[-g_i]_+}.
\]

This is a finite positive (g)-pointed element of (A\subseteq U). Its carrier is explicit and needs no theta coefficients. Define the nonnegative integer matrix

\[
N_{ij}=\deg_{z_i}F_{I_j},\qquad e(g)=N[-g]_+.
\]

Then the full integer box (0\le p\le e(g)) is always a valid initial carrier. The convex hull of the actual computed product support is usually smaller and is the carrier used by the implementation.

This also shows that a supplied word is a computational certificate rather than a hidden theta oracle: all operations before pruning are finite matrix mutation, integer powers, polynomial multiplication and exact division.

## 3. The Newton algorithm extends unchanged

The root Newton-containment argument applies to every initially (g)-pointed (f\in U\otimes\mathbb Q). Its finite theta expansion contains \(\theta_g\) with coefficient one, and

\[
\operatorname{Newt}(F_g)\subseteq\operatorname{Newt}(F_f).
\]

For completeness, valuative independence puts the Newton polytope of every nonzero theta summand inside that of (f). Every leading exponent is therefore ((g,0)+Eq) with (q\ge0). Since (E) is injective and every theta is pointed, only (q=0) can contribute to the monomial ((g,0)); its coefficient is one.

On a finite integer carrier, membership in the (k)-neighbor is equivalent to divisibility of each off-(k) fiber by

\[
(1+t)^{[-g_k-\sum_{j\ne k}b_{kj}q_j]_+}.
\]

Divided derivatives at (t=-1) give finite integer linear equations. Normalize the origin coefficient to one. Delete a nonzero vertex whenever its coefficient can consistently be set to zero. The theta witness survives each deletion. An outer vertex is deletable; a vertex of the theta Newton polytope is not. Hence the process terminates at exactly

\[
P_g=\operatorname{Newt}(F_g).
\]

This result is independent of deletion order and of the chosen negative-frame word or initial carrier. The vertex coefficients are one. Interior parameters can remain; the theorem makes no uniqueness claim for them.

Define the **intrinsic Newton box**

\[
\delta_i(g)=\max_{p\in P_g}p_i.
\]

It is now computable for any input covered by the negative-frame certificate. It is different from both the negative-frame carrier box (e(g)) and the acyclic standard box. The later strict recursion uses \(\delta\), not a substituted acyclic formula.

## 4. Exact simultaneous freezing threshold

This is an additional general consequence of the same mechanism. It provides a finite explicit replacement for nonconstructive stabilization thresholds.

Fix (J\subseteq\{1,\ldots,n\}), put (I=J^c), and define the coordinate zero face

\[
P_h^J=P_h\cap\{p_j=0\text{ for all }j\in J\}.
\]

Because (F_h\) has nonnegative degrees and constant coefficient one, this is exactly the Newton polytope of \(F_h|_{z_J=0}\). It is nonempty. Its vertices are precisely those vertices of (P_h) lying in that coordinate face. Define

\[
T_j(h;J)=\max\left(0,-h_j-
       \min_{p\in P_h^J}\sum_{i\in I}b_{ji}p_i\right)
       \quad(j\in J),\qquad T_i=0\quad(i\in I).
\]

All minima are over a finite explicitly known vertex set, so (T\) is integral and computable without interior theta coefficients.

**Exact freezing theorem.** For every (a\in\mathbb N^n) supported on (J), the following are equivalent:

1. (F_{h+a}) contains no variable (z_j\) with (j\in J).
2. (a_j\ge T_j(h;J)) for every (j\in J).

When these conditions hold,

\[
\theta_{h+a}=x^a\,\mathfrak f_J(\theta_h)
             =x^{h+a}F_h(z)|_{z_J=0}.
\]

**Proof of sufficiency.** Let the rightmost expression be (H). For a mutation direction (i\in I), its Laurent divisibility equations are exactly the equations of the original \(\theta_h\) on fibers with outside (J)-degree zero. The shift (a\) does not change the (i)-th leading exponent. Thus all these equations are inherited.

For (j\in J), every fiber of (F_H) is constant in (z_j). Its mutable (x_j)-exponent is

\[
h_j+a_j+\sum_{i\in I}b_{ji}p_i.
\]

The threshold makes it nonnegative for every support exponent. Therefore (H) is Laurent in the (j)-neighbor as well. BFZ gives (H\in U). Newton minimality puts (P_{h+a}) inside the zero-(J) face supporting (H), so (F_{h+a}) has no (z_J). Freezing and factorization in the newly frozen directions then identify this theta function with (H).

**Proof of necessity.** If (F_{h+a}) has no (z_J), freezing changes nothing and frozen factorization forces \(\theta_{h+a}=H\). Its Laurent property in a (j\)-neighbor requires every constant (z_j)-fiber to have nonnegative (x_j)-exponent. Taking the minimum over the zero face gives (a_j\ge T_j\). There is no possible cancellation between these distinct off-(j) fibers. QED.

Thus the simultaneous stabilization region is an explicitly determined integral orthant, rather than only an eventual-existence assertion. This uses no acyclicity and no formula for interior theta coefficients.

### A cheaper sufficient threshold

If only a carrier box (0\le p\le b(h)) is known, it suffices to choose

\[
a_j\ge\left[-h_j+\sum_{i\in I}[-b_{ji}]_+b_i(h)\right]_+
\quad(j\in J),\qquad a_I=0.
\]

One may take (b(h)=e(h)=N[-h]_+\). This version needs one negative-frame computation and integer arithmetic only.

## 5. Positive slices with an explicit finite shift

Take any finite integer carrier (S\supseteq P_g\cap\mathbb Z^n); the box (e(g)) suffices. For every (q\in S), put (h_q=g+Bq). The preceding carrier formula gives (e(h_q)). Define (a_I=0) and

\[
a_j=\max_{q\in S}\left[
  -(h_q)_j+\sum_{i\in I}[-b_{ji}]_+e_i(h_q)
  \right]_+\quad(j\in J).
\]

This is a finite explicit integer prescription. The exact thresholds (T(h_q;J)) can replace it if smaller shifts are desired.

Strong multiplication positivity expands

\[
x^a\theta_g=\sum_q c_q y^q\theta_{g+a+Bq},\qquad c_q\in\mathbb N.
\]

The expansion is finite, and positivity/pointedness puts all roots (q) in (S). The common shift just constructed makes every summand independent of (z_J). Freeze and cancel the monomial (x^{g+a}); then extract a fixed degree (z_J^s). The result is

\[
[z_J^s]F_g=
\sum_{r\in\mathbb N^I}c_{s,r}z_I^r
F^{B_{II}}_{g_I+B_{IJ}s+B_{II}r}(z_I),\qquad c_{s,r}\in\mathbb N.
\]

This is the same positive-slice conclusion as in the acyclic proof, now with an explicit general finite shift. The construction of that shift does not use Qin Proposition 6.19, a limit, or a choice of broken lines.

## 6. Source and sink leaves preserve the certificate

Here is the elementary matrix argument needed for the marked construction; the general triangular-extension theorem is unnecessary.

Attach a leaf (w) at vertex (i), with (b_{wi}=1,b_{iw}=-1\), and give it symmetrizer entry (D_i). In block notation its initial row on the old vertices is (r\ge0\). Along an old mutation word, the old principal part evolves as before. If (C\) is the old principal (C)-matrix, the leaf row is

\[
b_{w,\mathrm{old}}=rC.
\]

Inductively this follows because sign-coherent columns of (C) allow the nonnegative linear combination (rC) to use the same mutation branch. Skew symmetrizability makes the old-to-leaf column have the opposite sign. Therefore the old frozen rows retain zero in the new column. The new frozen row retains zero in all old columns. The extended (C)-matrix is block diagonal \(\operatorname{diag}(C,1)\) throughout the old word.

At the old endpoint (C=-P), the leaf row is (-rP\le0\). Mutating (w) once changes the extended (C)-matrix to \(-\operatorname{diag}(P,1)\). Thus an old word followed by (w) is a certificate for a source leaf.

For a sink leaf, (b_{w,\mathrm{old}}=-r\le0\). Mutate (w) first. Its row becomes (r\), while the extended (C)-matrix becomes \(\operatorname{diag}(I,-1)\). Applying the old word now gives \(-\operatorname{diag}(P,1)\), by the same induction. Thus (w) followed by the old word is a certificate for a sink leaf.

Iterate these operations. With all source leaves (u_i\) and sink leaves (v_i\), one certificate is: all sink leaves first, the old word, all source leaves last. Each block consists of pairwise commuting mutations. Mutating all leaves swaps the two signs and leaves the old principal matrix (B) unchanged; the swapped extension has an equally explicit certificate.

The argument permits red steps in the old word and works with any integral symmetrizer. It does not invoke a Li–Pan result.

## 7. Embedding the old theta as one extended theta

Let (d\ge\delta(g)) coordinatewise. Add the two leaves at every old vertex as in Section 6, with principal coefficients for the enlarged seed. The old-to-leaf entries are

\[
b_{u_i,i}=1,\ b_{i,u_i}=-1,\qquad
b_{v_i,i}=-1,\ b_{i,v_i}=1.
\]

Give the old directions label (g), source leaves label zero, and sink leaves label (d). Consider

\[
\widetilde f=\prod_i v_i^{d_i}\,x^g
F_g\bigl(\eta_i u_i v_i^{-1}x^{Be_i}\bigr).
\]

Every monomial has source exponent (p_i\ge0\) and sink exponent (d_i-p_i\ge0\). Hence it is Laurent after either leaf mutation. At an old neighbor, Laurent membership follows by substituting (y_i\mapsto\eta_i u_i/v_i\) in the old theta expression; the extended old exchange variable differs from the substituted one by the invertible factor (v_i\). BFZ therefore gives \(\widetilde f\in U_{\mathrm{extended}}\).

The leaf extension has a finite theta basis by its explicit negative-frame certificate. In the finite theta expansion of \(\widetilde f\), valuative independence confines every summand to its Newton polytope. The latter has degree zero in all **leaf principal coefficient** directions. Consequently every summand has zero leading shift and zero (F\)-degree in those directions. Freezing all leaves leaves every summand unchanged and sends it to its theta function in the frozen seed.

The frozen image of \(\widetilde f\) is precisely the original theta under monomial coefficient extension and a frozen monomial factor. Distinct full lattice labels remain distinct after freezing, because the initial exponent lattice is unchanged. Theta linear independence in the frozen seed forces the expansion to have exactly that one summand, with coefficient one. Thus \(\widetilde f\) is the single extended theta with the stated label.

This step does not assume that the enlarged matrix is acyclic. It is also consistent with the independently audited extension criterion CMMM Theorem 4.12, although the argument above spells out the ingredients needed here.

## 8. General marked-subset theorem and strict intrinsic descent

Write (F_g=\sum_pa_pz^p\). For (r,s\in\mathbb N^n\) with (r+s\le d\), define

\[
\mathcal M^{d}_{r,s}F_g
 =\sum_{p\ge r}a_p
   \prod_i\binom{p_i}{r_i}\binom{d_i-p_i}{s_i}\,z^{p-r},
\qquad h=g+r+s+Br.
\]

**Marked-subset theorem.** In every classical skew-symmetrizable seed supplied with a negative-frame certificate,

\[
x^h\mathcal M^{d}_{r,s}F_g
  =\sum_qc_qy^q\theta_{h+Bq},\qquad c_q\in\mathbb N,
\]

with a finite sum. Every occurring (q) satisfies

\[
q+\delta(h+Bq)\le d-r-s.
\]

In particular, choose (d=\delta(g)\). If \(|r+s|>0\), every summand has strictly smaller intrinsic box total \(|\delta(h+Bq)|<|\delta(g)|\).

**Proof.** Mutate all leaves in Section 7. Ordinary exchange substitution gives the normalized (F\)-polynomial

\[
\prod_i(1+V_i)^{d_i}
F_g\left(z_i\frac{(1+U_i)V_i}{1+V_i}\right).
\]

The old part of the new leading label is (g+d\); the new source columns have old part (+e_i\), and sink columns old part (-e_i\). Extract leaf degree (U^rV^{d-s}\). Its ordinary coefficients are

\[
\sum_pa_p\prod_i\binom{p_i}{r_i}\binom{d_i-p_i}{s_i}z^p.
\]

Apply the general positive-slice theorem of Section 5 in the leaf-mutated seed, which has its own negative-frame certificate. The old leading label for this slice is (g+r+s\). All its monomials have (p\ge r\); positivity forces each summand's root to be at least (r\). Factor (z^r\), giving (h=g+r+s+Br\) and the claimed positive theta expansion.

The resulting polynomial is supported in (0\le p\le d-r-s\). Since every theta summand and expansion coefficient is nonnegative, each shifted summand lies in that box. Taking its coordinate maxima gives (q+\delta(h+Bq)\le d-r-s\). QED.

The recursion has a concrete base: \(\delta(g)=0\) if and only if \(g\ge0\). One direction is the initial cluster-monomial formula. In the other direction, \(F_g=1\); initial-star Laurent divisibility at the origin forces each (g_i\ge0\).

The combinatorial marking weights are unchanged: choose (r_i\) selected and (s_i\) unselected objects from (d_i\) labeled Boolean slots, retain their labels, and remove the marked slots. The multiplicity is the displayed binomial product. The theorem supplies a positive theta comparison and a finite strictly smaller domain for recursive coefficients. It does not by itself select a canonical decomposition of the finite objects.

## 9. What is deliberately not inferred

The acyclic creation-cap theorem uses its own standard-box recursion and exact capacity-removal identity. Those ingredients are absent here; replacing them by \(e(g)\) or \(\delta(g)\) without proof is invalid. The present extension does not claim general creation caps.

The complete higher-rank greedy selector remains open: Newton pruning fixes the polytope and exposed coefficients, while marked positivity supplies strong lower-character constraints. Neither statement proves uniqueness of all interior coefficients or the desired canonical graph/compatible-pair model.

The input promise is injective reachability certified by a finite word. The argument does not claim that every skew-symmetrizable matrix has such a word, nor does it silently extend a principal-coefficient basis conclusion to arbitrary specializations.

## 10. Implementation and finite checks

`negative_frame.py` implements certificate verification, exact (F\)- and (g\)-recurrences, carrier production, composition with the existing exact pruning algorithm, source/sink extensions, the coarse common shift, and the exact threshold from Newton vertices. Resource caps raise explicit exceptions; they are implementation limits, not mathematical exceptions.

`implementation_checks.py` uses four cyclic input matrices to check indexing and arithmetic, including a nontrivial endpoint permutation, (D=(2,1,1)\), an infinite-type weighted-path mutation, and a cyclic (2,2,3\) matrix. It compares an independently written (F/g\) recurrence, inserts a red backtrack, compares opposite vertex-deletion orders, and verifies the enlarged and leaf-mutated rank-nine negative-frame words.

`freezing_threshold_checks.py` compares exact threshold predictions with newly computed Newton polytopes at the threshold and one step below it; in these four implementation cases the coefficient space is zero dimensional, so it also checks the full frozen-polynomial identity exactly. These calculations guard the implementation and do not substitute for the general proofs above.
