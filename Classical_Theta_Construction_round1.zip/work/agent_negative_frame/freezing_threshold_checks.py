#!/usr/bin/env python3
"""Check exact freezing thresholds against independently repeated pruning."""
from pathlib import Path
import json

from negative_frame import (certified_newton, exact_freezing_threshold,
                            simultaneous_slice_shift)
from implementation_checks import CASES

HERE = Path(__file__).resolve().parent


def table(pruning):
    assert pruning["final_affine_dimension"] == 0
    return {tuple(r["p"]): r["row"][0] for r in pruning["affine_rows"]
            if r["row"][0][0]}


def main():
    all_results = []
    for case, J in zip(CASES, ([2], [0], [2], [0])):
        B, word, h = case["B"], case["word"], case["g"]
        initial = json.loads((HERE/(case["name"]+".json")).read_text())["result"]["pruning"]
        threshold = exact_freezing_threshold(B, h, J, initial["vertices"])
        a = threshold["threshold"]
        target = [h[i]+a[i] for i in range(len(h))]
        after = certified_newton(B, word, target, cap=1500)["pruning"]
        assert all(after["d"][j] == 0 for j in J)
        frozen_table = {p:c for p,c in table(initial).items() if all(p[j] == 0 for j in J)}
        assert table(after) == frozen_table
        boundary = []
        for j in J:
            if not a[j]:
                continue
            below = list(target)
            below[j] -= 1
            below_result = certified_newton(B, word, below, cap=1500)["pruning"]
            assert any(below_result["d"][k] for k in J)
            boundary.append({"label": below, "box": below_result["d"]})
        common = simultaneous_slice_shift(B, word, h, J, cap=1500)
        common.pop("negative_frame_certificate")
        result = {"name": case["name"], "h": h, "threshold": threshold,
                  "shifted_label": target, "shifted_box": after["d"],
                  "frozen_F_equals_shifted_F_exactly": True,
                  "one_below_threshold": boundary,
                  "simultaneous_slice_shift_from_frame": common}
        all_results.append(result)
        print(json.dumps({"name": case["name"], "J": J, "T": a,
                          "identity": True, "below_checked": len(boundary)}), flush=True)
    (HERE/"freezing_threshold_checks.json").write_text(json.dumps(all_results, indent=2)+"\n")


if __name__ == "__main__":
    main()
