#!/usr/bin/env python3
"""Certified finite Newton input for injective-reachable classical seeds.

Input is an integer skew-symmetrizable B, a zero-based mutation word whose
principal C-matrix ends at -P, and an optional integral label g.  Only ordinary
matrix mutation, the F-polynomial recurrence and exact polynomial division
are used to produce the pointed carrier.  Identification of the pruned
polytope with the theta Newton polytope uses the separately stated theorem.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
from functools import reduce
from itertools import product
from math import gcd, lcm
from pathlib import Path
import json
import sys
import time

import sympy as sp


def symmetrizer(B):
    """Find a primitive positive integral symmetrizer on each component."""
    n = len(B)
    if not n or any(len(row) != n for row in B):
        raise ValueError("B must be a nonempty square matrix")
    if any(type(a) is not int for row in B for a in row):
        raise ValueError("B must have integer entries")
    if any(B[i][i] for i in range(n)):
        raise ValueError("B must have zero diagonal")
    if any((B[i][j] == 0) != (B[j][i] == 0) or B[i][j]*B[j][i] > 0
           for i in range(n) for j in range(n)):
        raise ValueError("opposite entries must have opposite signs")
    d = [None]*n
    for root in range(n):
        if d[root] is not None:
            continue
        d[root] = Fraction(1)
        component = [root]
        for i in component:
            for j in range(n):
                if not B[i][j]:
                    continue
                dj = -d[i]*Fraction(B[i][j], B[j][i])
                if d[j] is None:
                    d[j] = dj
                    component.append(j)
                elif d[j] != dj:
                    raise ValueError("B is not skew-symmetrizable")
        denominator = lcm(*(d[i].denominator for i in component))
        integer_values = [int(d[i]*denominator) for i in component]
        divisor = reduce(gcd, integer_values)
        for i, value in zip(component, integer_values):
            d[i] = value//divisor
    assert all(d[i]*B[i][j] == -d[j]*B[j][i]
               for i in range(n) for j in range(n))
    return d


def mutate_matrix(E, k):
    n = len(E[0])
    return [[-E[i][j] if i == k or j == k else
             E[i][j] + max(E[i][k], 0)*max(E[k][j], 0)
             - max(-E[i][k], 0)*max(-E[k][j], 0)
             for j in range(n)] for i in range(len(E))]


def principal_extension(B):
    n = len(B)
    return [list(row) for row in B] + [
        [int(i == j) for j in range(n)] for i in range(n)]


def negative_permutation(C):
    n = len(C)
    permutation = []
    for j in range(n):
        column = [C[i][j] for i in range(n)]
        if column.count(-1) != 1 or any(a not in (0, -1) for a in column):
            raise ValueError("terminal C is not a negative permutation matrix")
        permutation.append(column.index(-1))
    if len(set(permutation)) != n:
        raise ValueError("terminal C does not encode a permutation")
    return permutation


def certify_c_word(B, word):
    """Fast exact C-certificate, also suitable for many attached leaves."""
    d = symmetrizer(B)
    n = len(B)
    E = principal_extension(B)
    steps = []
    for k in word:
        if type(k) is not int or not 0 <= k < n:
            raise ValueError("word entries must be zero-based mutable indices")
        c = [E[n+i][k] for i in range(n)]
        if not any(c) or not (all(a >= 0 for a in c) or all(a <= 0 for a in c)):
            raise ArithmeticError("sign-coherence check failed")
        steps.append({"vertex": k, "c_vector": c, "green": all(a >= 0 for a in c)})
        E = mutate_matrix(E, k)
    C = E[n:]
    permutation = negative_permutation(C)
    if any(d[j] != d[permutation[j]] for j in range(n)):
        raise ArithmeticError("negative permutation failed symmetrizer preservation")
    return {"B": B, "word": list(word), "D": d, "terminal_C": C,
            "terminal_B": E[:n], "permutation": permutation, "steps": steps}


def polynomial_table(poly):
    return [{"p": list(p), "coefficient": int(c)}
            for p, c in sorted(poly.terms())]


def certify_negative_frame(B, word, max_terms=200000):
    """Verify C=-P and compute all negative-frame F-polynomials exactly."""
    start = time.time()
    certificate = certify_c_word(B, word)
    n = len(B)
    z = sp.symbols("z0:"+str(n))
    E = principal_extension(B)
    F = [sp.Poly(1, *z, domain=sp.ZZ) for _ in range(n)]
    G = [[int(i == j) for i in range(n)] for j in range(n)]  # columns
    steps = []
    for k in word:
        c = [E[n+i][k] for i in range(n)]
        plus = sp.Poly(sp.prod(z[i]**max(c[i], 0) for i in range(n)), *z, domain=sp.ZZ)
        minus = sp.Poly(sp.prod(z[i]**max(-c[i], 0) for i in range(n)), *z, domain=sp.ZZ)
        for j in range(n):
            plus *= F[j]**max(E[j][k], 0)
            minus *= F[j]**max(-E[j][k], 0)
        new_F, remainder = sp.div(plus+minus, F[k], domain=sp.ZZ)
        if not remainder.is_zero:
            raise ArithmeticError("F mutation did not divide exactly in Z[z]")
        if len(new_F.terms()) > max_terms:
            raise OverflowError("F-polynomial term resource cap")
        if new_F.coeff_monomial((0,)*n) != 1:
            raise ArithmeticError("F mutation lost its constant term one")
        if any(c <= 0 or not c.is_Integer for c in new_F.coeffs()):
            raise ArithmeticError("F mutation positivity check failed")
        new_g = [-G[k][i] + sum(max(E[j][k], 0)*G[j][i] for j in range(n))
                 - sum(B[i][j]*max(c[j], 0) for j in range(n)) for i in range(n)]
        F[k], G[k] = new_F, new_g
        E = mutate_matrix(E, k)
        steps.append({"vertex": k, "new_g_vector": new_g,
                      "new_F_terms": len(new_F.terms()),
                      "new_F_total_degree": int(new_F.total_degree())})
    permutation = certificate["permutation"]
    expected_G = [[-int(i == permutation[j]) for i in range(n)] for j in range(n)]
    if G != expected_G:
        raise ArithmeticError("direct g recurrence does not give G=-P")
    inverse = [permutation.index(i) for i in range(n)]
    frame_F = [F[j] for j in inverse]
    certificate.update({"terminal_G_columns": G, "F_mutation_steps": steps,
                        "negative_frame_variables": [
                            {"initial_label": [-int(i == j) for j in range(n)],
                             "terminal_cluster_position": inverse[i],
                             "F": polynomial_table(frame_F[i])} for i in range(n)],
                        "seconds": time.time()-start})
    return certificate, frame_F


def pointed_carrier(B, word, g, max_terms=200000):
    """M_g=x^[g]+ product I_i^[-g_i]+, as a finite positive F-table."""
    if len(g) != len(B) or any(type(a) is not int for a in g):
        raise ValueError("g must be an integral vector of the correct rank")
    certificate, frame_F = certify_negative_frame(B, word, max_terms=max_terms)
    z = frame_F[0].gens
    F = sp.Poly(1, *z, domain=sp.ZZ)
    for i, a in enumerate(g):
        if a < 0:
            F *= frame_F[i]**(-a)
            if len(F.terms()) > max_terms:
                raise OverflowError("pointed carrier term resource cap")
    certificate["carrier"] = {
        "g": list(g), "initial_variable_powers": [max(a, 0) for a in g],
        "negative_frame_powers": [max(-a, 0) for a in g],
        "F": polynomial_table(F), "terms": len(F.terms()),
        "mass": int(sum(F.coeffs())),
        "box": [int(F.degree(z[i])) for i in range(len(g))]}
    return certificate, F


def certified_newton(B, word, g, cap=5000, reverse_order=False):
    """Compose the certified finite carrier with exact Newton pruning."""
    certificate, F = pointed_carrier(B, word, g)
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"agent_acceptance"))
    from theta_newton_pruning import prune
    result = prune(B, g, points=[p for p, c in F.terms()], cap=cap,
                   reverse_order=reverse_order)
    return {"certificate": certificate, "pruning": result}


def frame_degree_matrix(frame_F):
    """N_ij=degree in z_i of the negative-frame variable I_j's F-polynomial."""
    n = len(frame_F)
    return [[int(frame_F[j].degree(frame_F[j].gens[i])) for j in range(n)]
            for i in range(n)]


def frame_box(N, h):
    return [sum(N[i][j]*max(-h[j], 0) for j in range(len(h)))
            for i in range(len(h))]


def freezing_shift(B, h, J, box):
    """An explicit shift extending the frozen theta_h back to a full theta.

    `box` must be any certified coordinate bound on supp(F_h).  The proof uses
    only initial-star divisibility, BFZ, Newton minimality and freezing.
    """
    n = len(h)
    J = set(J)
    if not J.issubset(range(n)) or len(box) != n or any(a < 0 for a in box):
        raise ValueError("invalid frozen subset or support box")
    I = set(range(n))-J
    return [max(0, -h[j]+sum(max(-B[j][i], 0)*box[i] for i in I))
            if j in J else 0 for j in range(n)]


def exact_freezing_threshold(B, h, J, theta_vertices):
    """Exact threshold from the zero-J face of the theta Newton polytope.

    For a>=0 supported on J, F_(h+a) lacks all variables z_J iff a>=T.
    The input vertices must be the output of the certified pruning theorem.
    """
    n = len(h)
    J = set(J)
    if not J.issubset(range(n)):
        raise ValueError("invalid frozen subset")
    face = [tuple(p) for p in theta_vertices if all(p[j] == 0 for j in J)]
    if not face:
        raise ValueError("theta Newton polytope must contain the origin")
    I = set(range(n))-J
    T = [0]*n
    witnesses = [None]*n
    for j in J:
        p = min(face, key=lambda q: sum(B[j][i]*q[i] for i in I))
        T[j] = max(0, -h[j]-sum(B[j][i]*p[i] for i in I))
        witnesses[j] = list(p)
    return {"J": sorted(J), "threshold": T, "zero_face_vertices": [list(p) for p in face],
            "minimizing_vertices": witnesses}


def simultaneous_slice_shift(B, word, g, J, points=None, cap=200000):
    """Finite integer common shift for every potential slice-expansion root.

    A caller may supply a certified finite root carrier.  Otherwise, the entire
    negative-frame box is used, so no theta coefficients or Newton oracle enter.
    """
    certificate, frame_F = certify_negative_frame(B, word)
    N = frame_degree_matrix(frame_F)
    e = frame_box(N, g)
    if points is None:
        count = 1
        for a in e:
            count *= a+1
        if count > cap:
            raise OverflowError("slice root-box resource cap")
        points = list(product(*(range(a+1) for a in e)))
    else:
        points = list(map(tuple, points))
    a = [0]*len(g)
    witnesses = [None]*len(g)
    for q in points:
        h = [g[i]+sum(B[i][j]*q[j] for j in range(len(g)))
             for i in range(len(g))]
        lower_box = frame_box(N, h)
        candidate = freezing_shift(B, h, J, lower_box)
        for j, value in enumerate(candidate):
            if value > a[j]:
                a[j] = value
                witnesses[j] = {"q": list(q), "h_q": h, "carrier_box": lower_box}
    return {"B": B, "g": list(g), "J": sorted(J), "frame_degree_matrix": N,
            "initial_root_box": e, "root_count": len(points),
            "shift": a, "maximizing_witnesses": witnesses,
            "negative_frame_certificate": certificate}


def attach_leaf(B, word, vertex, source=True):
    """Attach one unvalued leaf with the old attachment's symmetrizer entry."""
    n = len(B)
    if not 0 <= vertex < n:
        raise ValueError("invalid attachment vertex")
    enlarged = [list(row)+[0] for row in B] + [[0]*(n+1)]
    sign = 1 if source else -1
    enlarged[n][vertex] = sign
    enlarged[vertex][n] = -sign
    new_word = list(word)+[n] if source else [n]+list(word)
    return enlarged, new_word


def marked_leaf_extension(B, word):
    """Attach a source and sink leaf at every old vertex and certify C=-P."""
    n = len(B)
    enlarged, new_word = [list(row) for row in B], list(word)
    source_indices, sink_indices = [], []
    for i in range(n):
        source_indices.append(len(enlarged))
        enlarged, new_word = attach_leaf(enlarged, new_word, i, source=True)
    for i in range(n):
        sink_indices.append(len(enlarged))
        enlarged, new_word = attach_leaf(enlarged, new_word, i, source=False)
    certificate = certify_c_word(enlarged, new_word)
    certificate.update({"source_leaves": source_indices, "sink_leaves": sink_indices})
    return certificate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="JSON with B, word, and optionally g")
    parser.add_argument("--output", required=True)
    parser.add_argument("--prune", action="store_true")
    parser.add_argument("--cap", type=int, default=5000)
    args = parser.parse_args()
    data = json.loads(Path(args.input).read_text())
    B, word = data["B"], data["word"]
    if args.prune:
        result = certified_newton(B, word, data["g"], cap=args.cap)
    elif "g" in data:
        result, _ = pointed_carrier(B, word, data["g"])
    else:
        result, _ = certify_negative_frame(B, word)
    Path(args.output).write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"output": args.output, "rank": len(B), "word_length": len(word),
                      "pruned": args.prune}))


if __name__ == "__main__":
    main()
