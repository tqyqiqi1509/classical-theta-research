# Negative-frame extension handoff

2026-11-13, 08:35 UTC。此分支工作完成，主目标的内部系数选择仍未解决。

## 已得到的一般结论

1. **含环推广成立。** 输入任意经典斜对称化整数矩阵 (B) 和一个有限 word，精确验证终点 (C=-P)。普通 (F) 递推得到负 frame 变量 (I_i)，初始 (g(I_i)=-e_i)。(M_g=x^{[g]_+}\prod I_i^{[-g_i]_+}) 给出有限正载体，喂入已有 Newton pruning，返回精确 (P_g=\operatorname{Newt}F_g)。不要求无环，也不要求 (A=U)。
2. **精确冻结阈值。** 令 (J\) 为被冻方向，(I=J^c\)，(P_h^J=P_h\cap\{p_J=0\}\)。定义
   \[
   T_j=\max\{0,-h_j-\min_{p\in P_h^J}B_{jI}p_I\},\ j\in J;\quad T_I=0.
   \]
   对 (a\ge0\)、(\operatorname{supp}a\subset J\)，(F_{h+a}\) 不含 (z_J\) **当且仅当** (a\ge T\)。此时 \(\theta_{h+a}=x^a\mathfrak f_J(\theta_h)\)。阈值只需 Newton 零面顶点，不需内部系数。核心证明：冻结多项式在 (I\)-邻点继承除法；在 (J\)-邻点 Laurent 恰当于所有 (x_j\) 指数非负；BFZ+Newton 最小性+freezing 完成充分性，反向由 freezing factorization 和单纤维必要性完成。
3. **一般 positive-slice 现在有显式同时位移。** (N_{ij}=\deg_i F_{I_j}\)，(e(h)=N[-h]_+\)。对有限根载体 (S\)、(h_q=g+Bq\)，取
   \[
   a_j=\max_{q\in S}\big[-(h_q)_j+\sum_{i\in I}[-b_{ji}]_+e_i(h_q)\big]_+,
   \quad a_I=0.
   \]
   它一次性使所有潜在 summands 无 (z_J\)。不再需要 Qin 6.19 的非构造稳定化阈值。
4. **源/汇叶推广成立。** elementary row (rC\) 归纳：source append leaf，sink prepend leaf。旧 word 允许 red steps。两种叶方向均给显式证书。旧 (F\) 嵌入扩大种子由 BFZ 得 (U\) 成员；VIT 强制 leaf principal (F\)-degree 零；freezing 独立性识别一个 extended theta。
5. **一般 marked positivity 与严格下降成立。** 选实际 intrinsic box (d=\delta(g)\)。相同 binomial marks 给非负整数 theta 展开，且所有项满足 (q+\delta(h+Bq)\le\delta(g)-r-s\)。非空 mark 严格降低盒总量。(\delta(g)=0\iff g\ge0\) 给递归基例。

## 必须保留的边界

- 非无环 creation caps **尚未证明**；不可把 acyclic standard box 换成 intrinsic box 就声称成立。
- Newton 和 marked constraints 仍未被证明唯一确定内部系数；没有完成高秩 greedy/theta 纯组合计数模型。
- 保持 principal-coefficient Newton 空间；未声称任意系数特殊化保持同样 Newton 结论。
- 有限 negative-frame word 是输入证书；未声称每个 skew-symmetrizable 矩阵都具有该证书。

## 文件

- 完整证明：`INJECTIVE_REACHABLE_NEWTON_AND_MARKING.md`，请优先独立审第4节精确阈值。
- 实现：`negative_frame.py`。
- 数值/符号检查：`implementation_checks.py`、`implementation_checks.json` 及4个单例完整 JSON。
- 阈值边界验证：`freezing_threshold_checks.py`、`freezing_threshold_checks.json`。
- 文献审核：`LITERATURE_SCOPE_AUDIT.json`，5条。
- 探索记录：`ROUTE_RECORD.json`，9条。

## 检查结果摘要

四个含环输入（含非平凡最终 permutation、(D=(2,1,1)\)、无限型 weighted-path mutation、cyclic 223）全部通过独立 (F/g\) 递推对照、red backtrack、相反删点顺序、rank-9 叶扩展及叶翻转后的证书验证。四个冻结输入均在 (T\) 处得到完整系数恒等式，在 (T-e_j\) 处仍含被冻结变量。这些仅作实现检查，证明为一般论证。

## 引文修正

Qin1902.09507v4 A.1.5 引的是 GHKK 发表版 Proposition8.25。arXiv1411.1394v2 的同类 full-basis/large-cluster-complex 结论是 **Proposition8.28**；其 Corollary8.25 只是有限生成。主文最好直接引 Qin A.1.5，避免混号。
