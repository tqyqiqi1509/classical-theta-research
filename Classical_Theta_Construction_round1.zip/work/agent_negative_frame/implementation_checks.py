#!/usr/bin/env python3
"""Implementation checks of the general negative-frame pipeline.

These are guards against permutation, valuation, red-step, and leaf-extension
implementation errors; they are not evidence for a theorem beyond its proof.
"""
from pathlib import Path
import json
import sys
import time
import sympy as sp

from negative_frame import (certify_c_word, certify_negative_frame,
                            certified_newton, marked_leaf_extension,
                            mutate_matrix, principal_extension)

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent/"agent_division"))
from principal_cluster import initial as independent_initial
from principal_cluster import mutate as independent_mutate


CASES = [
    {"name": "skew_cycle_permuted_frame", "B": [[0,1,-1],[-1,0,1],[1,-1,0]],
     "word": [1,2,0,1], "g": [1,-1,-1]},
    {"name": "valued_cycle", "B": [[0,-1,1],[2,0,-1],[-2,1,0]],
     "word": [1,2,1,0,1], "g": [-1,1,-1]},
    {"name": "infinite_type_cycle", "B": [[0,-2,4],[2,0,-2],[-4,2,0]],
     "word": [1,2,1,0,1], "g": [-1,2,2]},
    {"name": "cyclic_223", "B": [[0,2,-2],[-2,0,3],[2,-3,0]],
     "word": [0,2,0,1,2,0], "g": [1,1,-1]}
]


def main():
    start = time.time()
    results = []
    for case in CASES:
        name, B, word, g = (case[k] for k in ("name", "B", "word", "g"))
        n = len(B)
        certificate, Fs = certify_negative_frame(B, word)
        # A separately written g/F recurrence from an earlier branch must agree.
        z = Fs[0].gens
        state = independent_initial(B)
        for k in word:
            state = independent_mutate(B, state, k, z)
        p = certificate["permutation"]
        assert tuple(map(tuple, certificate["terminal_C"])) == state[0][n:]
        assert tuple(map(tuple, certificate["terminal_G_columns"])) == state[2]
        assert all(sp.Poly(state[1][p.index(i)], *z) == Fs[i] for i in range(n))
        # A red backtrack is legal in a reddening certificate.
        red_certificate, red_Fs = certify_negative_frame(B, [0,0]+word)
        assert red_Fs == Fs
        assert any(not step["green"] for step in red_certificate["steps"])
        # Both the initial leaf seed and the leaf-mutated seed have certificates.
        extension = marked_leaf_extension(B, word)
        leaf_word = extension["source_leaves"] + extension["sink_leaves"]
        E = principal_extension(extension["B"])
        for k in leaf_word:
            E = mutate_matrix(E, k)
        enlarged_rank = len(extension["B"])
        leaf_mutated_B = E[:enlarged_rank]
        assert [row[:n] for row in leaf_mutated_B[:n]] == B
        # General mutation invariance is not needed here: the leaves have swapped
        # signs, and the constructive source/sink word can be rebuilt directly.
        opposite_extension = [list(row) for row in B]
        opposite_word = list(word)
        from negative_frame import attach_leaf
        for i in range(n):
            opposite_extension, opposite_word = attach_leaf(
                opposite_extension, opposite_word, i, source=False)
        for i in range(n):
            opposite_extension, opposite_word = attach_leaf(
                opposite_extension, opposite_word, i, source=True)
        assert opposite_extension == leaf_mutated_B
        opposite_certificate = certify_c_word(opposite_extension, opposite_word)
        result = certified_newton(B, word, g, cap=1500)
        reverse = certified_newton(B, word, g, cap=1500, reverse_order=True)
        assert result["pruning"]["vertices"] == reverse["pruning"]["vertices"]
        assert result["pruning"]["lattice_points"] == reverse["pruning"]["lattice_points"]
        out = {"input": case, "result": result,
               "marked_leaf_extension": extension,
               "leaf_mutated_certificate": opposite_certificate,
               "independent_F_and_g_recurrence_agrees": True,
               "red_backtrack_agrees": True,
               "reverse_pruning_order_agrees": True}
        (HERE/(name+".json")).write_text(json.dumps(out, indent=2)+"\n")
        short = {"name": name, "D": certificate["D"],
                 "permutation": p, "frame_F_term_counts": [len(F.terms()) for F in Fs],
                 "carrier_terms": result["certificate"]["carrier"]["terms"],
                 "carrier_box": result["certificate"]["carrier"]["box"],
                 "theta_intrinsic_box": result["pruning"]["d"],
                 "theta_Newton_lattice_points": len(result["pruning"]["lattice_points"]),
                 "theta_Newton_vertices": len(result["pruning"]["vertices"]),
                 "residual_coefficient_dimension": result["pruning"]["final_affine_dimension"],
                 "pruning_deletions": result["pruning"]["nontrivial_deletions"],
                 "exact_jet_checks": result["pruning"]["exact_jet_checks"],
                 "reverse_order_agrees": True, "leaf_extension_rank": enlarged_rank}
        results.append(short)
        print(json.dumps(short), flush=True)
    summary = {"scope": "implementation checks only", "cases": results,
               "seconds": time.time()-start}
    (HERE/"implementation_checks.json").write_text(json.dumps(summary, indent=2)+"\n")


if __name__ == "__main__":
    main()
