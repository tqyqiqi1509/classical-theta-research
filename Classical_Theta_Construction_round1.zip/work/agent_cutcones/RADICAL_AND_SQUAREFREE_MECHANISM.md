# Radical-degree vanishing and squarefree coefficient mechanisms

Classical setting throughout. These statements concern normalized formal
transport in the **original principal frozen variables**. They do not imply
Laurent admissibility or normalized pointedness after resetting coefficients.

## 1. Conventions

Let B be an integral skew-symmetrizable n by n exchange matrix and let
D=diag(d_i)>0 satisfy DB=-B^T D. Put z_j=y_j x^{B_{*j}}. For p in N^n\{0},
write

\[
 E_p(x^g y^q)=\langle Dp,g\rangle z^p x^g y^q.
\]

The bracket is

\[
 [E_a,E_b]=(a^TDBb)E_{a+b}.
\]

The actual normalized transport T_t is an automorphism congruent to the identity
in positive frozen degree. It is a product of root-binomial factors indexed by
signed c-vectors. At every finite cutoff its logarithm is a finite BCH Lie
polynomial. A root factor with alpha=|c| has logarithm supported on E_{m alpha},
m>=1. Its scalar coefficients are irrelevant to the vanishing argument below.

We use the standard tropical identities, also checked directly by the mutation
recurrences in the code:

\[
 C_t^T D B C_t=D B_t,\qquad G_t^T D C_t=D.
\]

## 2. General radical-degree vanishing theorem

**Theorem.** If p is a nonzero nonnegative vector with Bp=0, and p is not a
positive multiple of an initially isolated vertex, then the E_p coefficient
of log T_t is zero for every actual seed t. In particular this holds for every
non-axis radical degree p.

**Proof.** First, a c-vector cannot be a radical vector in a nontrivial connected
component. Indeed, if c=C_t e_k and Bc=0, then

\[
 D B_t e_k=C_t^T D B C_t e_k=0.
\]

Thus vertex k is isolated in B_t. Mutation cannot merge two connected components:
if all exchange entries across a partition vanish, every mutation preserves
those zero entries. Reversibility then says it cannot split a connected
component either. Consequently k belongs to an initially isolated component.
On such a component its c-vector is +/-e_i. Therefore no one-letter logarithm
of an actual root factor contributes E_p under the stated hypothesis.

Second, every Lie monomial with at least two letters and total degree p ends
with a bracket between homogeneous degrees a,b>0 with a+b=p. Its coefficient
contains

\[
 a^TDBb=a^TDB(p-a)=a^TDBp-a^TDBa=0.
\]

All BCH contributions in degree p therefore vanish. This proves the result at
every finite cutoff and hence formally. No scattering diagram or geometric
representation argument is involved. □

**Consequence for finite coefficient recurrence.** Suppose two normalized
transports have identical proper-coordinate jets below p. The lowest-difference
lemma gives their difference in degree p as lambda E_p. If Bp=0 and the
hypothesis of the theorem holds, both logarithmic E_p coefficients vanish, so
lambda=0. Thus the next coefficient is uniquely determined by the proper jets.
The conclusion removes a parameter; it does **not** assert that every compatible
list of lower jets comes from an actual seed.

This distinction matters: in the balanced cyclic rank-three example below,
four formally compatible degree-two states are not actual. Radical vanishing
alone does not eliminate them.

## 3. Divisibility of variable images and multiaffine squarefree rows

Write T(x_i)=x_i H_i(z). For every actual positive-root formal transport,

\[
 H_i-1\in z_i\,\mathbb Z[[z_1,\ldots,z_n]].
\]

To see this, a generator of degree alpha with alpha_i=0 fixes x_i. A generator
with alpha_i>0 changes x_i only by multiples of z_i. If a series has already
acquired a factor z_i, applying a positive-degree generator preserves that
factor. This proves the assertion inductively along the root factors.

On a squarefree coordinate cap, z_j^2=0 for the active coordinates. Therefore
(H_i-1)^2=0 and, for every integer g_i (positive or negative),

\[
 H_i^{g_i}=1+g_i(H_i-1).
\]

Hence every squarefree transport row is a multiaffine polynomial in the shifted
label g+Bq. More explicitly,

\[
 T^g(z^q)=z^q\prod_i\left(1+(g_i+(Bq)_i)(H_i-1)\right)
 \quad\text{on the squarefree cap.}
\]

Coefficients can thus be computed by finite collections of disjoint blocks,
each block assigned a distinguished root i that lies in it. The weight of a
block is the corresponding H_i coefficient times g_i+(Bq)_i. This is a direct
finite combinatorial expansion of the transport; positivity or minimization of
its signed rows remains a separate problem.

### 3.1 A stronger coefficient-level radical vanishing

**Theorem.** Let p be a non-axis, nonzero, squarefree vector with Bp=0. Then

\[
 [z^p]H_{i,t}=0
\]

for every i and every actual seed t. More generally the same conclusion holds
for an individual i whenever p_i<=1 and p is not a multiple of an isolated
axis.

**Direct proof from the binomial rule.** The case p_i=0 follows from
H_i-1 divisible by z_i. If p_i=1, the mutation exponent in the update of the
coefficient at p is c_i d_i/d_k, since Bp=0. If c_i=0 there is no update. If
c_i is nonzero, any possible term at p-j|c| has exhausted the only i-coordinate;
divisibility forces that H_i coefficient to vanish unless p-j|c|=0. In that
exceptional case the c-vector is radical, which Section 2 rules out outside an
isolated axis. Thus the coefficient, initially zero, stays zero at every step. □

This identity is stronger than log-degree vanishing on the squarefree cap. It
sets the top vector of all universal variable images to zero directly. A finite
compatible list of proper jets therefore determines every radical squarefree
row by the block expansion above, without solving a new endpoint parameter.

## 4. A universal squarefree rank-three classification usable for all labels

Take

\[
 B_r=r\begin{pmatrix}0&1&-1\\-1&0&1\\1&-1&0\end{pmatrix},\qquad r\ge1.
\]

For p=(1,1,1), B_r p=0, so Section 2 applies. The established degree-two normal
form is specified by u=(u_0,u_1,u_2) in {0,1}^3 and
tau=(tau_01,tau_12,tau_20), with

\[
 u_i u_j\le\tau_{ij}\le u_i
\]

on the directed edges 0->1->2->0. Actual tau values are 0 or 1, by the
two-endpoint lemma. There are fourteen such lower states. For each lower state,
the cap111 top transport is unique by radical vanishing.

### 4.1 The ten states always realized

The following words realize ten states for r>=2. Words are applied from left
to right and indices are zero based.

| u | tau | word |
|---|---|---|
| 000 | 000 | empty |
| 100 | 000 | 0 |
| 010 | 000 | 1 |
| 001 | 000 | 2 |
| 110 | 100 | 10 |
| 011 | 010 | 21 |
| 101 | 001 | 02 |
| 100 | 100 | 101 |
| 010 | 010 | 212 |
| 001 | 001 | 020 |

These identities follow by three direct applications of the integer binomial
mutation rule; they are symbolic in r>=2. All these words use only two vertex
directions, so H_i(111)=0 for all three variable images.

### 4.2 Why the other four states are impossible when r>=2

We give an elementary global positive grading solely to decide lower-state
admissibility. It is no longer needed to bound the top parameter.

For a cyclic weighted rank-three quiver with edge magnitudes a,b,c>=2, set
C=a^2+b^2+c^2-abc. Replacing one edge c by ab-c preserves C. If C<=4, the new
edge cannot be <2: for t<2,

\[
 a^2+b^2+t^2-abt> a^2+b^2+4-2ab=(a-b)^2+4\ge4.
\]

Thus every mutation remains cyclic with all weighted edges at least two.
For B_r, C=3r^2-r^3<=4 for every integer r>=2.

Give the three initial mutable variables ordinary degree one and all initial
principal coefficients degree zero. The initial exchange relations are
homogeneous because B_r^T(1,1,1)^T=0. At any cyclic seed the positive kernel
covector is proportional to the vector of opposite edge magnitudes. Under a
mutation its changed degree is exactly the corresponding positive difference
ab-c (times the fixed positive proportionality factor). It follows inductively
that every cluster variable has strictly positive degree. Equivalently,

\[
 (1,1,1)G_t\text{ has all entries strictly positive.}
\]

Now u_i=1 forces row i of G_t to be nonpositive, by endpoint positivity in
degree e_i. If u_i=1,u_j=0,tau_ij=1, comparison with the one-letter seed i in
degree e_i+e_j forces the sum of rows i,j of G_t to be nonpositive.

The four remaining lower states are

\[
 (u,\tau)=(110,110),(011,011),(101,101),(111,111).
\]

For the first, row 0 is nonpositive and rows 1+2 have nonpositive sum. Thus the
sum of all rows is nonpositive, contradicting the strictly positive grading.
The next two cases are cyclic rotations. For the fourth, all three rows are
nonpositive. All four are impossible.

Consequently, **for every r>=2 and every integer label g**, every actual
cap111 positivity row is one of the rows of the ten displayed words. In
particular length three suffices. This is an all-word theorem, not a claim
deduced from the finite scans. It may be embedded in larger rank only after
using the separately proved support-localization theorem.

### 4.3 The r=1 cycle

All fourteen lower states occur. The four additional states are realized by
the words 102, 201, 012, and 0120 respectively (in the order above). The last
state needs four letters for the universal transport list. The radical
vanishing theorem again makes each top extension unique. Thus all labels g
have a universal cap111 criterion using words through four.

There is no claim here that four is needed after fixing the *minimal* proper
prefix. That weaker saturation question has separate evidence below.

## 5. Exact finite CM-interval certificate (arbitrary B and label)

Fix a cap with top p and a finite exhaustive list of possible proper jets L.
Choose a formal base T_L for each; every actual extension has top T_L+lambda E_p.
For every actual known cluster function f=x^h F(z), its top coefficient after
transport is

\[
 b_f(L)+\lambda\langle Dp,h\rangle F(0).
\]

With the conventional normalized cluster variables F(0)=1, positivity gives
an exact rational interval for lambda. Proper negative coefficients exclude
L. Empty intervals exclude L. Any independent radical identity may intersect
this interval with a singleton.

For a fixed test label g with a0>=0, the adverse endpoint is the lower endpoint
if <Dp,g>>0 and the upper endpoint if <Dp,g><0. When this endpoint is finite,
an exact nonnegative linear combination expressing its row in the cone of
selected actual short-word coefficient rows proves the required inequality for
every actual extension of L. A zero slope needs no bound. If all L are handled,
this is an all-word finite positivity certificate.

No converse or automatic termination is asserted. In a positive polar direction,
all cluster g-vectors may have the same pairing sign, so even infinitely many
CM inequalities may leave an adverse endpoint unbounded. The method should
therefore be combined with genuine seed admissibility information or with
identities such as Section 2, rather than treating a numerical failure as a
mathematical counterexample.

Implementation: `cm_interval_certificates.py`; exact reconstruction and checks:
`jet_cut_cones.py`. The cap111 exhaustive lower list comes from the proved
first/second-order binary normal forms. The method is general beyond rank three
once an exhaustive proper-jet list is supplied.
