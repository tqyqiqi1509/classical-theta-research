"""All-path certificates for squarefree third-order coefficient transports.

The finite set of candidate proper jets is obtained from the proved first/second
order binary normal forms. Comparison to actual short seeds gives forced signs of
their G-cones. Exact conic combinations or mixed-sign representatives then certify
that a first actual endpoint is unique; two actual endpoints are exhaustive by
the endpoint-positivity two-value lemma. No BFS plateau is used as a certificate.
"""
import sys,json,itertools,time
from pathlib import Path
import sympy as sp
import numpy as np
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parent/'agent_division'))
from universal_atlas import JetRing
from truncated_atlas import symmetrizer,exponents,identity,update_transform
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E
from positive_cuts import generalized_binomial
from jet_cut_cones import exact_nonnegative_combination

def root_step(B,H,ee,alpha,weight):
    idx={p:i for i,p in enumerate(ee)};n=len(B);out=[]
    for h in range(n):
        v=list(H[h])
        for ip,p in enumerate(ee):
            lim=min(p[i]//alpha[i]for i in range(n)if alpha[i])
            r=weight[h]+sum(weight[i]*B[i][j]*p[j]for i in range(n)for j in range(n))
            for k in range(1,lim+1):
                q=tuple(p[i]-k*alpha[i]for i in range(n))
                v[ip]+=generalized_binomial(r,k)*H[h][idx[q]]
        out.append(tuple(v))
    return tuple(out)

def binary_bases(B):
    n=len(B);assert n==3
    ee=exponents((1,1,1));unit=(1,)+(0,)*(len(ee)-1)
    pairs=[(i,j)for i in range(n)for j in range(n)if B[i][j]>0]
    out=[]
    for u in itertools.product((0,1),repeat=n):
        choices=[range(u[i]*u[j],u[i]+1)for i,j in pairs]
        for taus in itertools.product(*choices):
            H=(unit,)*n
            for i in range(n):
                if u[i]:
                    e=tuple(int(j==i)for j in range(n));H=root_step(B,H,ee,e,e)
            for (i,j),tau in zip(pairs,taus):
                # Canonical simple letters were applied in increasing order.
                baseline=u[i]*u[j]*int(j<i)
                delta=tau-baseline
                if delta:
                    alpha=tuple(int(k in(i,j))for k in range(n))
                    w=tuple(delta*(-B[j][i]if k==i else B[i][j]if k==j else 0)for k in range(n))
                    H=root_step(B,H,ee,alpha,w)
            out.append({'u':u,'taus':list(zip(pairs,taus)),'H':H})
    return ee,out

def short_seeds(B,depth):
    n=len(B);D=symmetrizer(B);ee=exponents((1,1,1));idx={p:i for i,p in enumerate(ee)}
    H0=((1,)+(0,)*(len(ee)-1),)*n;E0=initial_E(B)
    nodes=[(E0,H0,(),-1)];seen={E0};out=[]
    for E,H,w,last in nodes:
        C=sp.Matrix(E[n:]);G=sp.diag(*D).inv()*C.T.inv()*sp.diag(*D)
        assert all(v.q==1 for v in G)
        out.append({'E':E,'H':H,'word':w,'G':tuple(tuple(int(G[i,j])for j in range(n))for i in range(n))})
        if len(w)>=depth:continue
        for k in range(n):
            if k==last:continue
            EE=mutate_matrix(E,k)
            if EE in seen:continue
            seen.add(EE)
            c=tuple(E[n+i][k]for i in range(n));alpha=tuple(abs(v)for v in c)
            weight=tuple(c[i]*D[i]//D[k]for i in range(n))
            assert all(c[i]*D[i]%D[k]==0 for i in range(n))
            HH=root_step(B,H,ee,alpha,weight)
            nodes.append((EE,HH,w+(k,),k))
    return ee,out

def proper_key(H):return tuple(tuple(h[:-1])for h in H)

def strict_cone_certificate(normals):
    if not normals:return None
    R=np.asarray(normals,dtype=float)
    res=linprog(np.zeros(R.shape[1]),A_ub=-R,b_ub=-np.ones(len(R)),bounds=[(None,None)]*R.shape[1],method='highs')
    if res.success:return None
    dep=linprog(np.zeros(len(normals)),A_eq=np.vstack((R.T,np.ones(len(R)))),
                b_eq=[0]*R.shape[1]+[1],bounds=(0,None),method='highs')
    if not dep.success:return {'kind':'unverified_lp'}
    ids=[i for i,v in enumerate(dep.x)if v>1e-8]
    M=sp.Matrix([list(normals[i])+[1]for i in ids]).T
    sol,pars=M.gauss_jordan_solve(sp.Matrix([0]*R.shape[1]+[1]));sol=sol.subs({v:0 for v in pars})
    if any(v<0 for v in sol)or M*sol!=sp.Matrix([0]*R.shape[1]+[1]):return {'kind':'unverified_lp'}
    return {'kind':'rank_exclusion','dependence':[[normals[i],str(v)]for i,v in zip(ids,sol)if v]}

def compare_prefix(B,D,ee,H,S):
    """Necessary normals on an unknown actual G having proper jet H."""
    out=[];bad=[];n=len(B)
    for iq,q in enumerate(ee[:-1]):
        if not any(q):continue
        vv=[H[i][iq]-S['H'][i][iq]for i in range(n)]
        if not any(vv):continue
        lower=[j for j,r in enumerate(ee)if r!=q and all(a<=b for a,b in zip(r,q))]
        if any(H[i][j]!=S['H'][i][j]for i in range(n)for j in lower):continue
        dq=[D[i]*q[i]for i in range(n)];h=next(i for i in range(n)if dq[i]);lam=sp.Rational(vv[h],dq[h])
        if any(vv[i]!=lam*dq[i]for i in range(n)):
            bad.append({'q':q,'difference':vv,'reason':'non-Hamiltonian minimal difference'});continue
        pair=[sum(dq[i]*S['G'][i][j]for i in range(n))for j in range(n)]
        if any(lam*x<0 for x in pair):
            bad.append({'q':q,'lambda':str(lam),'known_word':S['word'],'pairings':pair,'reason':'known endpoint positivity'});continue
        sign=1 if lam>0 else -1
        out.append(tuple(-sign*x for x in dq))
    return out,bad

def positive_kernel_certificate(B):
    """A directly checked global positive grading for rank-three cyclic B.

    If weighted edges a,b,c >= 2 and a^2+b^2+c^2-abc <= 4, every
    mutation remains cyclic: replacing c by ab-c cannot make it <2, since
    a^2+b^2+t^2-abt > 4 for t<2 and a,b>=2.  The positive kernel grading
    therefore stays positive under each exchange recurrence.  This returns
    a primitive integer covector v with G_t^T v > 0 for every seed.
    """
    if len(B)!=3:return None
    cyc=[B[0][1],B[1][2],B[2][0]]
    if not(all(v>0 for v in cyc)or all(v<0 for v in cyc)):return None
    edge=[-B[0][1]*B[1][0],-B[1][2]*B[2][1],-B[2][0]*B[0][2]]
    mc=sum(edge)-abs(cyc[0]*cyc[1]*cyc[2])
    if min(edge)<4 or mc>4:return None
    v=sp.Matrix(B).T.nullspace()[0]
    if all(a<0 for a in v):v=-v
    assert all(a>0 for a in v)
    den=sp.ilcm(*[a.q for a in v]);v=[int(a*den)for a in v]
    gcd=sp.igcd(*v);v=tuple(a//gcd for a in v)
    return {'normal':v,'weighted_edge_squares':edge,'Markov_constant':mc}

def certify(B,depth=4,use_positive_kernel=False):
    n=3;D=symmetrizer(B);ee,bases=binary_bases(B);_,seeds=short_seeds(B,depth)
    groups={}
    for s in seeds:groups.setdefault(proper_key(s['H']),[]).append(s)
    kernel=positive_kernel_certificate(B)if use_positive_kernel else None
    result={'B':B,'D':D,'depth':depth,'short_seeds':len(seeds),'lower_candidates':len(bases),'states':[],
            'positive_kernel':kernel,
            'complete':True,'unresolved':0}
    for bas in bases:
        H=bas['H'];key=proper_key(H);reps=groups.get(key,[]);normals=[kernel['normal']]if kernel else [];bad=[]
        for s in seeds:
            ns,bs=compare_prefix(B,D,ee,H,s);normals+=ns;bad+=bs
        normals=sorted(set(normals));state={'u':bas['u'],'taus':bas['taus'],'normal_count':len(normals)}
        if bad:
            state['certificate']={'kind':'excluded','witness':bad[0]};result['states'].append(state);continue
        rankcert=strict_cone_certificate(normals)
        if rankcert and rankcert['kind']=='rank_exclusion':
            state['certificate']=rankcert;result['states'].append(state);continue
        distinct={tuple(h[-1]for h in s['H']):s for s in reps}
        assert len(distinct)<=2,('two-value contradiction',B,state,distinct)
        if len(distinct)==2:
            state['certificate']={'kind':'two_endpoints','words':[s['word']for s in distinct.values()],
                                  'endpoint_coefficients':list(distinct)}
        elif len(distinct)==1:
            s=next(iter(distinct.values()));pair=[sum(D[i]*s['G'][i][j]for i in range(n))for j in range(n)]
            if min(pair)<0<max(pair):
                state['certificate']={'kind':'mixed_endpoint','word':s['word'],'pairings':pair}
            else:
                signs=[1,-1];cert=None
                for sign in signs:
                    target=tuple(sign*d for d in D)
                    ans=exact_nonnegative_combination(normals,target)if normals else {'kind':'unverified_lp'}
                    if ans['kind']=='direct':
                        cert={'kind':'fixed_sign','sign':sign,'combination':[[normals[ans['index']],'1']]};break
                    if ans['kind']=='farkas':
                        cert={'kind':'fixed_sign','sign':sign,'combination':[[normals[i],v]for i,v in ans['weights']]};break
                if cert:
                    assert all(cert['sign']*x>=0 for x in pair)
                    cert['word']=s['word'];cert['pairings']=pair;state['certificate']=cert
                else:state['certificate']={'kind':'unresolved','word':s['word'],'pairings':pair,'normals':normals}
        else:state['certificate']={'kind':'unresolved_no_representative','normals':normals}
        if state['certificate']['kind'].startswith('unresolved'):
            result['complete']=False;result['unresolved']+=1
        result['states'].append(state)
    return result

if __name__=='__main__':
    out=[];start=time.time()
    for a,b,c in itertools.product(range(0,4),repeat=3):
        for orient in [1,-1]:
            B=[[0,a,orient*b],[-a,0,c],[-orient*b,-c,0]]
            r=certify(B,4);out.append(r)
            print((a,b,c,orient),'complete',r['complete'],'unresolved',r['unresolved'],flush=True)
            json.dump({'results':out,'seconds':time.time()-start,'completed':False},open(HERE/'third_endpoint_certificates.json','w'),indent=2)
    json.dump({'results':out,'seconds':time.time()-start,'completed':True},open(HERE/'third_endpoint_certificates.json','w'),indent=2)
