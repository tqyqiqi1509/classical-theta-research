# Higher-degree coefficient cuts — live research log

Owner: `/root/higher_degree_cut_cones`. Start: 2026-11-13 04:55 UTC.
This directory studies **classical, original-frozen formal coefficient jets**.
None of its positivity conclusions alone proves ordinary Laurent admissibility,
seedwise normalized pointedness, a greedy basis, or identification with theta.

## 04:55–05:05 — exact cone comparison and degree four

Read the degree-two all-word proof, universal binomial mutation recurrence, and
the finite-signature proof. Implemented exact Farkas reconstruction over QQ;
floating-point linear programming only proposes a certificate. Implemented a
universal atlas using the images of all initial variables, avoiding accidental
operator collisions at one exceptional label g. Independently compared the
universal reconstruction with the previous full matrix implementation.

Degree-three initial scan: 52 matrices (32 rank-three small-edge orientation
cases, 12 rank-four cases, 8 rank-five cases), two labels each, ranks 3/4/5,
depths 12/10/8. 1,939,236 seed states were traversed in these 104 runs. No seed
or bit pruning occurred. Per bound, 9,007 distinct target-degree-three rows were
tested. Bound 3: 7 exact separators, all squarefree three-support; bound 4:
none; bound 5: none; bound 7: all rows direct. **This is a restricted finite
scan, not a universal short-four theorem.** A later larger-edge example below
refutes the universal extrapolation.

Degree-four scan: 64 matrices, two labels each, 1,733,750 universal seed states
(not double counted for labels), depths 13/10/8, no pruning. Per bound, 30,546
degree-four cuts. Short bounds 4/5/6/7 have respectively 21/8/0/0 exact
separators. This concerns arbitrary positive prefixes, a stronger question than
the saturated minimal-prefix construction needs.

## 05:05–05:13 — a finite all-word endpoint certificate

For a fixed coordinate downset with top p, fixing every proper transport jet
leaves one parameter lambda, acting by lambda times E_p. Positivity of seed
variables at two actual endpoints proves there are **at most two actual values**
of lambda. Three values would force every column of the middle invertible G to
pair both nonnegatively and nonpositively with Dp.

At cap (1,1,1), enumerate the proved binary first/second-order normal forms.
Compare minimal differing proper coefficients with actual short seeds. Their
positive cluster variables force linear sign constraints on every column of a
prospective G. Exact positive dependence excludes cones of deficient span;
exact conic implication of +/-Dp certifies a fixed sign. A mixed-sign actual
representative is unique; two distinct actual representatives are exhaustive.
This is a general finite **verification mechanism**, not an unproved stopping
rule. With words through four, 35/128 edge-0..3 rank-three matrices are fully
certified by this first method; 245 lower states remain unresolved. See
`third_order_endpoint_certificate.py` and its JSON certificates.

## 05:13–05:16 — literature / route refresh (first 20-minute checkpoint)

Queries covered rank-three Markov invariants, recent g-vector bounds, finite
theta/greedy truncations, and tight gradings. Primary sources opened:

1. Ryota Akagi, arXiv:2411.07083v2, *Cluster-cyclic condition of
   skew-symmetrizable matrices of rank 3 via the Markov constant*.
   Primary HTML: https://arxiv.org/html/2411.07083v2 . Version header is
   29 July 2025; original submission is 11 November 2024. Theorem 1.2 states
   cyclicity is preserved precisely when C<=4 and the three weighted edge
   squares are at least 4. We independently proved the **sufficiency** needed
   here directly: if a,b,c>=2 and C=a^2+b^2+c^2-abc<=4, replacing c by ab-c
   cannot make it <2, since f(t)=a^2+b^2+t^2-abt>4 for t<2. Status: useful;
   no reliance on the unreviewed converse or later classification.

2. Ryota Akagi and Zhichao Chen, arXiv:2603.16326v2, *Geometric structures of
   G-fans associated with rank 3 cluster-cyclic exchange matrices*.
   https://arxiv.org/abs/2603.16326 . Original 17 March 2026; v2 8 June 2026.
   Official record explicitly says Example 9.4 was corrected. Abstract gives
   global/local bounds and monotonicity. Status: promising interface only;
   no theorem used before strong review.

3. Amanda Burcroff, Kyungyong Lee, Lang Mou, arXiv:2611.10154v1, *Bijecting
   m-Tamari intervals, trees, and tight gradings*, 6 November 2026.
   https://arxiv.org/html/2611.10154v1 . Opened primary text, definitions and
   scope: m-leafy trees require every full rooted subtree to have more than
   m times as many leaves as internal vertices; the result concerns central
   rank-two tight gradings / m-Tamari intervals. It is an extended abstract.
   Status: useful new combinatorial interface, sent to root for independent
   strong review. No theorem used here; no higher-rank conclusion inferred.

Search also returned 2026 Hexagon quantum papers and a Zenodo finite-type
cluster-mirror claim. They were not used: the current task is classical and
the relevant all-rank correctness gap is not addressed by their snippets.

Route decision: stop inferring short-word bounds from stabilization. Use
positive cluster functions to bound the one remaining parameter and derive
exact all-word certificates; separately compare **minimal proper prefixes**.

## 05:16–05:20 — positive-function intervals and a necessary correction

`cm_interval_certificates.py` computes finite jets of actual cluster variables
by inverting their unitriangular transport matrices. It checks all coefficients
are nonnegative. For each binary lower state, every actual extension has top
H_base[p]+lambda Dp. Each known cluster function x^h F gives the exact inequality
b+lambda <Dp,h> >= 0. The adverse endpoint for a candidate label is tested by
an exact Farkas combination of short-word rows. Success for every lower state
is an **all-word implication**, even if some lower states are unrealizable.

For all 128 skew rank-three matrices with edge magnitudes 0..3 and the label
g=(-1,-1,-1), short-four cluster functions certify short-four sufficiency for
120 matrices. These are genuine finite certificates, not finite-depth tests.
The eight unresolved cyclic matrices led to a concrete correction:

B = [[0,2,-2],[-2,0,3],[2,-3,0]], g=(-1,-1,-1), p=(1,1,1).
An actual word (0,2,0,1,2,0) gives a cut not in the cone of all words through
length five. Its row, in order 000,001,010,100,011,101,110,111, is

    (2,-2,-2,0,-1,0,-2,1).

Another actual word (0,2,0,1,2,0,2,1) gives

    (-6,-2,0,0,-1,0,0,1),

with normalized separator (1,4,1,1,4,12,3,12), value -6. Every short-five
row is nonnegative on it. Thus even a0=1 does not salvage a universal short
four/five criterion for arbitrary prefixes. Exact files:
`degree3_223_deep_cones.json`. The depth-16 exploratory atlas has 140,854
states and **278 bit-pruned branches** at a 2,048-bit cap; all displayed
counterexamples and all short-five rows are exact and occur before pruning.
No all-seed completeness is inferred from that atlas. Three permutations have
the same behavior. Tested short-six rows dominate all observed long rows.

For a cyclic rank-three matrix with weighted edges>=2 and C<=4, the primitive
positive covector v in ker(B^T) stays strictly positive on every cluster
g-vector. The above elementary invariant proof plus the homogeneous exchange
degree recurrence establishes this directly. Adding v to the sign cone closes
all cap111 transport states for balanced cyclic (r,r,r), r>=2. Nonbalanced
cases remain unresolved. Ambient-rank use requires the separately reviewed
support-localization lemma; the global grading is not asserted for arbitrary
ambient mutations without that reduction.

Crucially, CM positivity alone cannot always make the interval finite: for
balanced mutation-cyclic rank three and p=(1,1,1), all cluster g-vectors pair
positively with Dp. Therefore even infinitely many cluster-monomial tests at
this truncation give no upper bound on lambda. Actual seed sign/reachability
information must supplement CM positivity. This is an interface diagnosis,
not a terminal exclusion argument.

## 05:20 — saturated-prefix test changes the priority

`saturated_prefix_scan.py` fixes a0=1 and recursively takes the smallest next
coefficient satisfying the currently selected rows, while holding proper
predecessors fixed. It does not assert a coordinatewise least full jet.

Across the 128 degree-four label cases, all tested long-word saturated prefixes
agree with short-five prefixes. Short-four fails in exactly one label case:

B = [[0,-2,9,10],[3,0,-6,-5],[-9,4,0,-10],[-6,2,6,0]],
g = (-2,-3,0,1), p=(1,2,0,1): the required coefficient is 306 instead of 298,
witness word (1,3,1,0,1). The other 127 labels already agree at short three.
These remain finite-depth experiments, not a general theorem.

The new B223 counterexample was tested with five labels, including all-negative
labels -1 and -2: short-three saturated coefficients through degree four agree
with every tested depth-16 row. Hence its full-cone failure does not yet affect
the proposed minimal-prefix recurrence. Next priority: derive a general
third-order saturated mechanism, while keeping global pointedness and ordinary
Laurent admissibility as distinct requirements.

## 05:21–05:35 — general radical identities and a sharp positive recurrence

The root agent correctly redirected the unbounded-endpoint problem to the
Hamiltonian radical. Independent proofs now establish:

1. For every rank and every non-axis radical degree p (Bp=0), the E_p component
   of the operator logarithm log T is zero. A c-vector cannot be radical in a
   nontrivial connected component, and a final bracket of degrees summing to p
   has zero structure coefficient.
2. For every squarefree radical p, the actual coefficient [z^p]H_i is zero for
   every initial variable image. More generally this holds for an individual i
   when p_i<=1. Direct proof: H_i-1 is divisible by z_i; the binomial update at a
   radical target has exponent proportional to c_i, so every potential
   nonconstant contribution exhausts the sole i-coordinate and vanishes.
3. The root agent's stronger central-log proposal is correct: for all units F,
   labels g, and non-isolated radical degrees p,
   [z^p]log(T^g F)=[z^p]log F. This uses the same zero exponent in substitution
   of log F and exclusion of a radical c-vector. Every normalized cluster
   monomial is therefore central-log-free.
4. Added an integrality proof for central normalization. A multivariable unit
   with integer coefficients has a unique Euler product with integer powers
   of (1-z^a). Because a belongs to ker B iff ma does, deleting the radical
   Euler factors implements exp(-Pi_ker log F) integrally. This normalization
   commutes with actual transports. Its preservation of positivity is not
   proved and must not be assumed.

The general squarefree radical identity yields a complete **sharp** cubic
coefficient formula for arbitrary positive integers x,y,z and
B=[[0,x,-x],[-y,0,y],[z,-z,0]], including nontrivial symmetrizers. With the proven
minimal first/two-coordinate coefficients, define r_i=[-g_i]+, s_i=[g_i]+,
C_ij=[a_j r_i-s_j min(r_i,a_i)]+ along the directed cycle. Then, for **every
integer label g**,

    A111 = r0*r1*r2 + r2*C01 + r0*C12 + r1*C20.

This is the nonnegative weighted matching sum on a triangle. It satisfies all
fourteen possible proper binary states, including unrealizable ones. Thus no
G-fan classification or positive grading is needed for this sharper saturation
claim. Sharpness is forced by an actual word through length three. The proof is
a complete symbolic sign-case calculation, recorded in
`SHARP_RADICAL_CUBIC_RECURRENCE.md`. `sharp_radical_cubic.py` reproduces the
fourteen-state polynomial tables and verifies 4,096 parameter/label samples
plus 512 independent actual-short-word sharpness checks. All pass.

The formula is exactly central-log-free at degree111. Its vanishing logarithmic
coefficient is proved from positivity/sharpness, rather than imposed as an
unjustified normalization. This is the main positive result of this work wave.

## 05:35 — second literature / route refresh

Searched the central-log coefficient invariant, F-polynomial kernel directions,
and multivariable Euler/Witt factorizations. The returned primary cluster
sources included Fomin–Zelevinsky, *Cluster algebras IV: Coefficients*,
arXiv:math/0602259, and Cao–Keller–Qin, *The valuation pairing on an upper
cluster algebra*, arXiv:2204.09576. The latter's advertised irreducibility and
valuation results may interface with primitive normalization, but were not
used here. Search results did not establish that the new invariant is novel;
no novelty claim is made. Euler-product integrality was proved directly, so
no secondary Witt-vector exposition was imported as a theorem.

2026 search hits about integrable cluster maps or Euler–Mellin integrals were
not used: their abstracts do not address the current positivity-preservation
gap. The useful 2026 tight-gradings source from the previous refresh is being
handled by root's independent review, not reused without an audit.

Route decision: primitive normalization is a general integer and mutation-
compatible operation, but positivity and sharpness remain the substantive
issues. The cubic matching theorem provides one fully closed instance of the
general radical mechanism. Next work should attack larger radical squarefree
degrees or nonradical endpoint control, preserving the separate all-seed
pointedness/Laurent-admissibility requirement.

## Additional exact normalization of the short-five counterexample

`normalized_short5_counterexample.py` extends the B223 squarefree separator to
the **entire total-degree-three** coefficient table. It checks all 360 rows of
18 exact universal jets from all 86 seed states through length five (no
pruning). Every row is nonnegative. The actual word (0,2,0,1,2,0,2,1) has
coefficient -6 at111. Constant coefficient is exactly1. This removes any
ambiguity about normalized jets or unchecked repeated-coordinate targets;
the counterexample still has a deliberately nonminimal proper prefix.
