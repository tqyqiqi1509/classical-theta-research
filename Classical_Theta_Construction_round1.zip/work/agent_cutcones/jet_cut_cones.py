"""Exact certified conic domination of bounded-degree cluster positivity cuts.

LP is used only to find candidates. Accepted Farkas combinations are reconstructed
over QQ and checked entry by entry. A failed numerical LP is not by itself a
mathematical counterexample: a rational separating coefficient table is separately
reconstructed and checked.
"""
import sys, json, time, random
from pathlib import Path
from fractions import Fraction
from itertools import product
import numpy as np
import sympy as sp
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'agent_division'))
from atlas_bfs_study import atlas_total

def exact_nonnegative_combination(rows, target):
    """Return a sparse exact Farkas combination or a certified separator."""
    if target in rows:
        return {'kind':'direct','index':rows.index(target)}
    rr=np.asarray(rows,dtype=float)
    tt=np.asarray(target,dtype=float)
    res=linprog(np.ones(len(rows)),A_eq=rr.T,b_eq=tt,
                bounds=(0,None),method='highs')
    if res.success:
        supp=[i for i,v in enumerate(res.x) if v>1e-8]
        M=sp.Matrix([rows[i] for i in supp]).T
        vec=sp.Matrix(target)
        try:
            sol,params=M.gauss_jordan_solve(vec)
            if params.rows:
                # The solver generally returns a basic solution; use the found
                # rational values for free coordinates if degeneracy remains.
                sol=sol.subs({v:0 for v in params})
            sol=list(sol)
        except ValueError:
            return {'kind':'unverified_lp','message':'support does not span exactly'}
        if any(v<0 for v in sol) or M*sp.Matrix(sol)!=vec:
            return {'kind':'unverified_lp','message':'exact support coefficients invalid'}
        return {'kind':'farkas','weights':[[i,str(v)]for i,v in zip(supp,sol)if v]}
    # Compact homogeneous separation problem. Initial-coordinate positivity is
    # present in rows, so any successful separator has nonnegative entries.
    sep=linprog(tt,A_ub=-rr,b_ub=np.zeros(len(rows)),
                A_eq=np.ones((1,len(target))),b_eq=[1],
                bounds=[(0,None)]*len(target),method='highs')
    if not sep.success or sep.fun>=-1e-8:
        return {'kind':'unverified_lp','message':f'no exact cone certificate; separator status {sep.status}'}
    # Reconstruct from active equalities to avoid trusting floating point signs.
    active=[list(rows[i])for i,v in enumerate(rr@sep.x)if abs(v)<1e-7]
    active += [[int(i==j)for i in range(len(target))]for j,v in enumerate(sep.x)if abs(v)<1e-8]
    active.append([1]*len(target))
    rhs=[0]*(len(active)-1)+[1]
    try:
        sol,pars=sp.Matrix(active).gauss_jordan_solve(sp.Matrix(rhs))
        sol=sol.subs({v:0 for v in pars})
    except ValueError:
        sol=sp.Matrix([sp.Rational(Fraction(float(v)).limit_denominator(10**6))for v in sep.x])
    if any(v<0 for v in sol) or any(sum(x*y for x,y in zip(row,sol))<0 for row in rows):
        return {'kind':'unverified_lp','message':'separator exact positivity invalid'}
    value=sum(x*y for x,y in zip(target,sol))
    if value>=0:
        return {'kind':'unverified_lp','message':'separator exact violation lost'}
    den=sp.ilcm(*[v.q for v in sol]); ivec=[int(v*den)for v in sol]
    return {'kind':'separator','integer_table':ivec,'target_value':int(value*den),
            'constant':ivec[0],'normalized_constant_one':ivec[0]==1}

def cut_cone_study(B,g,degree,depth,short_bounds=(3,5,7),seed_cap=200000):
    started=time.time()
    meta,ee,TT=atlas_total(B,g,degree,depth,seed_cap=seed_cap,bit_cap=2048)
    paths=meta['transform_representatives']; idx={p:i for i,p in enumerate(ee)}
    result={'B':B,'g':g,'degree':degree,'depth':depth,'atlas':meta,
            'tests':[], 'seconds':None}
    for cutdepth in short_bounds:
        short=[T for T,w in zip(TT,paths) if len(w)<=cutdepth]
        stat={'short_bound':cutdepth,'short_transforms':len(short),'direct':0,'farkas':0,
              'separators':[],'unverified':[],'checks':0,'max_farkas_terms':0}
        for p in ee:
            if sum(p)!=degree: continue
            qs=[q for q in ee if all(x<=y for x,y in zip(q,p))]
            inds=[idx[q]for q in qs]
            rowdata={}
            for T,w in zip(TT,paths):
                row=tuple(T[idx[p]][j]for j in inds)
                rowdata.setdefault(row,w)
            rows=sorted(set(tuple(T[idx[q]][j]for j in inds)for T in short for q in qs))
            for row,w in rowdata.items():
                ans=exact_nonnegative_combination(rows,row);stat['checks']+=1
                kind=ans['kind']
                if kind in ['direct','farkas']:
                    stat[kind]+=1
                    if kind=='farkas':stat['max_farkas_terms']=max(stat['max_farkas_terms'],len(ans['weights']))
                elif kind=='separator':
                    stat['separators'].append({'p':p,'q':qs,'path':w,'row':row,
                                               'certificate':ans,'short_rows':rows})
                else:stat['unverified'].append({'p':p,'path':w,'certificate':ans})
        result['tests'].append(stat)
    result['seconds']=time.time()-started
    return result

def universal_cut_cones(B,g,degree,ee,HH,paths,short_bounds=(4,5,6,7)):
    """Use small coordinate downsets rather than full total-degree matrices."""
    from universal_atlas import JetRing
    idx={p:i for i,p in enumerate(ee)}
    stats={d:{'short_bound':d,'checks':0,'direct':0,'farkas':0,
              'separators':[],'unverified':[],'nontrivial_certificates':[]}for d in short_bounds}
    for p in ee:
        if sum(p)!=degree:continue
        qs=[q for q in ee if all(x<=y for x,y in zip(q,p))]
        inds=[idx[q]for q in qs];R=JetRing(qs)
        projected={}
        for H,w in zip(HH,paths):
            h=tuple(tuple(hi[j]for j in inds)for hi in H)
            if h not in projected or len(w)<len(projected[h]):projected[h]=w
        Ts=[(R.transform(B,g,H),w)for H,w in projected.items()]
        targetrows={}
        for T,w in Ts:targetrows.setdefault(T[-1],w)
        for d in short_bounds:
            st=stats[d]
            rows=sorted(set(row for T,w in Ts if len(w)<=d for row in T))
            for row,w in targetrows.items():
                ans=exact_nonnegative_combination(rows,row);st['checks']+=1
                kind=ans['kind']
                if kind in ['direct','farkas']:
                    st[kind]+=1
                    if kind=='farkas' and len(st['nontrivial_certificates'])<3:
                        st['nontrivial_certificates'].append({'p':p,'q':qs,'path':w,'row':row,
                            'combination':[[rows[i],weight]for i,weight in ans['weights']]})
                elif kind=='separator':
                    st['separators'].append({'p':p,'q':qs,'path':w,'row':row,
                        'certificate':ans,'short_rows':rows})
                else:st['unverified'].append({'p':p,'path':w,'certificate':ans})
    return list(stats.values())

def scan():
    rng=random.Random(202611130455)
    old=json.load(open(HERE.parent/'agent_division/atlas_bfs_degree3.json'))['results']
    samples=[(r['name'],r['B'])for r in old]
    for z in range(8):
        n=5;D=[1]*n if z<4 else [rng.randint(1,3)for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                a=rng.choice([-1,0,1]);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
        samples.append((f'rank5_{z}',B))
    out=[]
    for z,(name,B) in enumerate(samples):
        n=len(B); gs=[[-1]*n,[rng.randint(-3,3)for _ in range(n)]]
        for ng,g in enumerate(gs):
            dep=12 if n==3 else 10 if n==4 else 8
            r=cut_cone_study(B,g,3,dep,(3,5,7),seed_cap=180000)
            r['name']=name;r['label_index']=ng;out.append(r)
            print(name,ng,'seeds',r['atlas']['seed_count'],'cuts',
                  [(s['short_bound'],s['checks'],len(s['separators']),len(s['unverified']))for s in r['tests']],
                  'sec',round(r['seconds'],2),flush=True)
            json.dump({'results':out,'completed':False},open(HERE/'degree3_cone_results.json','w'),indent=2)
    json.dump({'results':out,'completed':True},open(HERE/'degree3_cone_results.json','w'),indent=2)

if __name__=='__main__':scan()
