"""Finite positive cluster-function bounds on a last Hamiltonian jet parameter.

This is a certificate verifier, not a reachability heuristic.  For cap (1,1,1),
the proved degree-two normal form lists every possible proper universal jet.
Every extension of one such jet has top H-vector H_base[p] + lambda Dp.
Positivity of finitely many actual cluster variables bounds lambda.  The
adverse endpoint row is then checked exactly in the cone of short-word rows.
When every lower candidate is certified, the result is an all-word theorem for
the selected B, g and coefficient downset.  Unbounded or undecided states are
reported; no numerical failure is called a counterexample.
"""
from pathlib import Path
import sys, json, itertools, time
import sympy as sp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from third_order_endpoint_certificate import binary_bases,short_seeds,proper_key
from universal_atlas import JetRing
from jet_cut_cones import exact_nonnegative_combination
from truncated_atlas import symmetrizer

def initial_functions(B,ee,seeds):
    """Return x^h F(z) for actual cluster variables, truncated on ee.

    T_s takes a variable of s to a monomial after its G-part is removed, hence
    T_s^h F = 1.  Solve this unitriangular integer system by substitution.
    """
    n=len(B);R=JetRing(ee);seen={};out=[]
    for s in seeds:
        for j in range(n):
            h=tuple(s['G'][i][j]for i in range(n))
            if h in seen:continue
            T=R.transform(B,h,s['H']);F=[1]
            for i in range(1,len(ee)):
                F.append(-sum(T[i][k]*F[k]for k in range(i)))
            assert all(v>=0 for v in F),('known cluster F positivity',B,s['word'],j,F)
            item={'g':h,'F':tuple(F),'word':s['word'],'column':j}
            seen[h]=item;out.append(item)
    return out

def interval_for_base(B,D,R,H,known):
    lower=None;upper=None;lo_wit=None;hi_wit=None
    for f in known:
        T=R.transform(B,f['g'],H)
        vals=[sum(a*b for a,b in zip(row,f['F']))for row in T]
        if any(v<0 for v in vals[:-1]):
            return {'kind':'excluded_proper','function':f,'values':vals}
        b=vals[-1];v=sum(d*h for d,h in zip(D,f['g']))
        if v==0:
            if b<0:return {'kind':'excluded_top_constant','function':f,'value':b}
        elif v>0:
            bd=sp.Rational(-b,v)
            if lower is None or bd>lower:lower=bd;lo_wit={'function':f,'base_value':b,'slope':v}
        else:
            bd=sp.Rational(-b,v)
            if upper is None or bd<upper:upper=bd;hi_wit={'function':f,'base_value':b,'slope':v}
    if lower is not None and upper is not None and lower>upper:
        return {'kind':'excluded_interval','lower':str(lower),'upper':str(upper),
                'lower_witness':lo_wit,'upper_witness':hi_wit}
    return {'kind':'interval','lower':lower,'upper':upper,'lower_witness':lo_wit,'upper_witness':hi_wit}

def certify_intervals(B,g,cut_depth=4,known_depth=4,radical_zero=False):
    D=symmetrizer(B);ee,bases=binary_bases(B);_,seeds=short_seeds(B,max(cut_depth,known_depth))
    R=JetRing(ee);known=initial_functions(B,ee,[s for s in seeds if len(s['word'])<=known_depth])
    cut_rows=sorted(set(row for s in seeds if len(s['word'])<=cut_depth
                       for row in R.transform(B,g,s['H'])))
    is_radical=all(sum(row)==0 for row in B)
    answer={'B':B,'D':D,'g':g,'cut_depth':cut_depth,'known_depth':known_depth,
            'radical_zero_used':bool(radical_zero and is_radical),
            'known_functions':len(known),'states':[],'complete':True}
    for bas in bases:
        bound=interval_for_base(B,D,R,bas['H'],known)
        rec={'u':bas['u'],'taus':bas['taus']}
        if bound['kind'].startswith('excluded'):
            rec['certificate']=bound;answer['states'].append(rec);continue
        if radical_zero and is_radical:
            if ((bound['lower']is not None and bound['lower']>0)or
                (bound['upper']is not None and bound['upper']<0)):
                rec['certificate']={'kind':'excluded_radical_interval','interval':str(bound)}
                answer['states'].append(rec);continue
            bound['lower']=bound['upper']=sp.Integer(0)
            bound['radical_identity']='log(T)_p=log(base)_p=0, hence lambda=0'
        slope=sum(d*h for d,h in zip(D,g))
        endpoint=bound['lower']if slope>0 else bound['upper']if slope<0 else sp.Integer(0)
        bound['lower']=str(bound['lower'])if bound['lower']is not None else None
        bound['upper']=str(bound['upper'])if bound['upper']is not None else None
        rec['interval']=bound
        if endpoint is None:
            rec['certificate']={'kind':'unbounded_adverse_endpoint','slope':slope};answer['complete']=False
        else:
            row=list(R.transform(B,g,bas['H'])[-1]);row[0]+=endpoint*slope;row=tuple(row)
            ans=exact_nonnegative_combination(cut_rows,row)
            if ans['kind']=='direct':
                rec['certificate']={'kind':'direct_endpoint','endpoint':str(endpoint),'row':row}
            elif ans['kind']=='farkas':
                rec['certificate']={'kind':'farkas_endpoint','endpoint':str(endpoint),'row':row,
                    'combination':[[cut_rows[i],wt]for i,wt in ans['weights']]}
            else:
                rec['certificate']={'kind':'unresolved_endpoint','endpoint':str(endpoint),'row':row,'diagnostic':ans}
                answer['complete']=False
        answer['states'].append(rec)
    return answer

def json_default(v):
    if isinstance(v,sp.Integer):return int(v)
    if isinstance(v,sp.Rational):return str(v)
    raise TypeError(type(v))

if __name__=='__main__':
    import collections
    out=[];start=time.time()
    for a,b,c in itertools.product(range(0,4),repeat=3):
        for orient in [1,-1]:
            B=[[0,a,orient*b],[-a,0,c],[-orient*b,-c,0]]
            r=certify_intervals(B,[-1,-1,-1],4,4);out.append(r)
            ct=collections.Counter(s['certificate']['kind']for s in r['states'])
            print((a,b,c,orient),r['complete'],dict(ct),flush=True)
            json.dump({'results':out,'seconds':time.time()-start,'completed':False},
                      open(HERE/'cm_interval_results.json','w'),default=json_default,indent=2)
    json.dump({'results':out,'seconds':time.time()-start,'completed':True},
              open(HERE/'cm_interval_results.json','w'),default=json_default,indent=2)
