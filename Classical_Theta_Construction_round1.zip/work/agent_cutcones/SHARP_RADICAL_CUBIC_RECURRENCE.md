# A sharp cubic recurrence from the general radical mechanism

This is a proved fixed-minimal-prefix statement for all integer labels and a
nontrivial skew-symmetrizable family. It is **not** a claim that original-frozen
formal positivity alone constructs a cluster basis. Its role is to demonstrate
how the arbitrary-rank radical coefficient identity turns a finite overestimate
of possible lower jets into a sharp, nonnegative combinatorial recurrence.

## Theorem

Let x,y,z be arbitrary positive integers and

\[
 B=\begin{pmatrix}0&x&-x\\-y&0&y\\z&-z&0\end{pmatrix}.
\]

This matrix is skew-symmetrizable (take D proportional to diag(1/x,1/y,1/z))
and B(1,1,1)^T=0. Use cyclic indices 0->1->2->0 and put a_0=x,a_1=y,a_2=z.
For every label g in Z^3, define

\[
 r_i=[-g_i]_+,\qquad s_i=[g_i]_+,\qquad
 C_{ij}=\big[a_j r_i-s_j\min(r_i,a_i)\big]_+
\]

on each cyclic directed edge i->j. Fix the proven least first/second-order
coefficients

\[
 A_0=1,\quad A_{e_i}=r_i,\quad
 A_{e_i+e_j}=r_i r_j+C_{ij}.
\]

Then the least integer A_111 for which **all actual seed transports** have
nonnegative coefficient at 111 is

\[
 \boxed{A_{111}=r_0r_1r_2+r_2 C_{01}+r_0 C_{12}+r_1 C_{20}.}
\]

Every term is nonnegative. It is exactly the weighted matching sum on a triangle:
an unmatched vertex i has weight r_i; the directed edge i->j, regarded as one
available pair, has weight C_ij. A matching contains either no edge or one edge.
Thus this coefficient has a finite, positive, integer weighted combinatorial
interpretation. The edge direction enters only its explicitly defined weight.

The maximum is forced by actual mutation words of length at most three. Thus
the formula is sharp on the fixed minimal proper prefix. No classification of
the rank-three mutation class or G-fan is used.

## Why the finite calculation covers arbitrary mutation words

The first/second-order all-word theorem says every actual proper universal jet
on the 111 cap has binary u and tau satisfying

\[
 u_i u_j\le \tau_{ij}\le u_i,
 \qquad u_i,\tau_{ij}\in\{0,1\}.
\]

There are fourteen such proper states. They need not all be actual. By the
general radical squarefree theorem in `RADICAL_AND_SQUAREFREE_MECHANISM.md`,
the top coefficient [z^111]H_i is zero for every actual seed. The complete
universal image on this cap is therefore determined by its proper binary state:

\[
 [z_i]H_i=u_i,
\]

and on every directed edge i->j,

\[
 [z_i z_j]H_i=a_j(\tau_{ij}-u_i u_j),\qquad
 [z_i z_j]H_j=a_i\tau_{ij}.
\]

All other singleton/pair image coefficients vanish. No top extension parameter
remains. The squarefree block formula gives the transport row directly:

\[
 T^g(z^q)=z^q\prod_i\bigl(1+(g_i+(Bq)_i)(H_i-1)\bigr).
\]

Consequently checking these fourteen explicit rows proves the upper bound for
all mutation words. It is legitimate to include unrealizable states here,
because the proposed coefficient satisfies every one of their rows.

## Complete symbolic verification and sharpness

All possibilities for g reduce by cyclic rotation to four cases. Zero labels
may be assigned to either adjacent case; the displayed formulas agree.

### All three labels nonpositive

Write g=(-A,-B,-C), A,B,C>=0. Then

\[
 A_{01}=AB+yA,\quad A_{12}=BC+zB,\quad A_{20}=CA+xC,
\]

and the claimed coefficient is

\[
 M=ABC+zAB+yAC+xBC.
\]

The fourteen transported top coefficients, after setting A_111=M, take only
the following five values:

\[
 M,\quad B(Az+Cx),\quad A(Bz+Cy),\quad C(Ay+Bx),\quad 0.
\]

The first is the empty state; the next three are the three singleton states
with tau=0; all remaining states have value zero. All are nonnegative.

For sharpness, take any edge i->j and the actual word (j,i,j). Its proper
state is u_i=1,u_j=0,tau_ij=1, with the other coordinate zero, and hence its
top row vanishes exactly at M. The coefficient of A_111 is one, so any smaller
choice violates this actual word's inequality.

### Exactly two labels negative

Rotate so g=(-A,-B,C), A,B,C>=0. Set

\[
 P=[zB-C\min(B,y)]_+.
\]

The fixed proper coefficients are A_01=A(B+y), A_12=P, A_20=0. The claimed
answer is M=AP. It suffices to check the lower thresholds for A_111. Across all
fourteen states, these thresholds belong to

\[
\begin{gathered}
0,\quad -AC(B+y),\quad
A(zB-yC)-BC(A+x),\quad A(zB-yC),\\
AP,\quad AP-ACy-BCx.
\end{gathered}
\]

Since

\[
 P\ge0,\qquad P\ge zB-yC,
\]

each threshold is at most AP. The actual one-step word 0 gives the threshold
AP: its exponent at 111 is g_0+(B(111))_0=-A. Thus the result is sharp.

### Exactly one label negative

Rotate so g=(-A,B,C), A,B,C>=0, and put

\[
 P=[yA-B\min(A,x)]_+.
\]

Only A_01=P may be nonzero among the pair coefficients; the claimed top
coefficient is zero. All fourteen lower thresholds belong to

\[
\begin{gathered}
0,\quad -PC,\quad -A(Bz+Cy),\quad -PC-ABC-ABz,\\
-C(P+AB+Bx),\quad -C(P-Ay+Bx).
\end{gathered}
\]

They are nonpositive, because P>=0 and P>=Ay-Bx. Initial coefficient positivity
requires A_111>=0, giving sharpness.

### All labels nonnegative

All proper coefficients other than the constant vanish, and M=0. With
g=(A,B,C), the fourteen transported top values are among

\[
0,\quad B(Az+Cx),\quad C(Ay+Bx),\quad A(Bz+Cy),\quad
ABC+ABz+ACy+BCx.
\]

They are nonnegative. Again the initial row makes zero sharp. This exhausts
all labels and completes the proof. □

## What this adds to the general programme

The proof uses a finite compatible list of proper jets, an arbitrary-rank
coefficient identity at a radical squarefree degree, and a positive local
matching expression. It does not require deciding which formal lower states
are actual. The proof succeeds because the extra states are harmless on the
minimal prefix, even though their rows can overconstrain arbitrary larger
prefixes. This gives a concrete reason to focus future recurrence work on
saturated prefixes rather than first classifying the entire universal-positive
coefficient cone.

For a radical squarefree degree of larger support, the same vanishing identity
and rooted-disjoint-block expansion remain valid. The unresolved general step
is to find a nonnegative combinatorial formula for the maximum over compatible
proper jets and to prove an actual word attains it. The present theorem solves
that step at a three-point radical cap, including nontrivial symmetrizers.
