# Central logarithmic invariants and integral primitive normalization

Independent verification of the root agent's proposed invariant, with an
integrality improvement. Everything below concerns ordinary classical formal
power series and integer binomial mutations. No scattering or geometric model
is used.

## 1. Invariant central logarithmic coefficients

Retain B,D,z and normalized transports T_t from the other notes. Let

\[
 \mathcal R=\{p\in\mathbb N^n\setminus\{0\}:Bp=0,\
 p\text{ is not a multiple of an initially isolated axis}\}.
\]

For any unit F in 1+(z)Q[[z]] and any label g, one has

\[
 \boxed{[z^p]\log(T_t^gF)=[z^p]\log F\quad(p\in\mathcal R).}
\]

Here T_t^gF is the normalized series in T_t(x^gF)=x^g T_t^gF after removing
the tropical monomial part in the fixed original-coordinate frame.

**Proof.** A single root factor of direction alpha=|c| substitutes

\[
 z^q\longmapsto z^q(1+z^\alpha)^{\epsilon\alpha^TDBq/\delta},
\]

with epsilon the sign of c and delta its positive root-length denominator.
If a new term reaches p=q+j alpha, j>=1, its exponent is

\[
 \alpha^TDBq=\alpha^TDB(p-j\alpha)=0.
\]

Thus the coefficient at p of the substituted log F equals its old coefficient.
The additional logarithm from x^g is

\[
 \epsilon\langle D\alpha,g\rangle\log(1+z^\alpha)/\delta.
\]

It could contribute at p only if p is a multiple of alpha. That would make the
c-vector radical, impossible outside an initially isolated component by
C_t^TDBC_t=DB_t and invariance of connected components. Each step therefore
preserves the coefficient, and induction proves the formula. □

In particular,

\[
 [z^p]\log H_{i,t}=0\qquad(p\in\mathcal R).
\]

This is a statement about the commutative formal logarithm of the variable
image H_i, not merely the logarithm of T as an operator.

## 2. Cluster monomials are centrally primitive

Let x^gF be any cluster monomial, normalized with F(0)=1 in the initial seed.
Its transport to its own seed is a monomial, whose normalized series is 1.
Applying the invariant gives

\[
 [z^p]\log F=0\qquad(p\in\mathcal R).
\]

Thus vanishing of the indicated central logarithmic coefficients is already a
necessary property of every normalized cluster monomial. It is a natural
candidate normalization for a larger basis. This observation alone does not
prove that every theta or greedy element has the property.

## 3. Integral normalization by a multivariable Euler product

Every F in 1+(z)Z[[z]] has a unique factorization

\[
 F=\prod_{a\in\mathbb N^n\setminus\{0\}}(1-z^a)^{c_a},
 \qquad c_a\in\mathbb Z,
\]

where products are taken in the degree-completed sense. This elementary
factorization requires no divisibility theorem: after all lower degrees have
been removed, a residual coefficient b at z^a is cancelled by the factor
(1-z^a)^{-b}; factors of a fixed total degree do not interact at that degree.
Induction proves existence and uniqueness with integer exponents.

Let Pi_R retain precisely the monomials z^p with p in R. The condition
ma in R is equivalent to a in R for every integer m>=1: ker B is saturated,
and being supported on an isolated axis is also unchanged by positive scaling.
Since

\[
 \log(1-z^a)=-\sum_{m\ge1}z^{ma}/m,
\]

we obtain

\[
 C(F):=\exp(\Pi_{\mathcal R}\log F)
      =\prod_{a\in\mathcal R}(1-z^a)^{c_a}
      \in1+(z)\mathbb Z[[z]],
\]

and

\[
 \mathcal N(F):=F/C(F)
      =\prod_{a\notin\mathcal R}(1-z^a)^{c_a}
      \in1+(z)\mathbb Z[[z]].
\]

Thus removing the central logarithmic part is an **integral** operation,
despite the rational coefficients in formal log and exp. Both C and N are
multiplicative homomorphisms on the formal unit group. Since Bp=0 means
z^p=y^p, C(F) is a series purely in original frozen monomials and every actual
transport fixes it. Section 1 yields

\[
 C(T_t^gF)=C(F),\qquad
 \mathcal N(T_t^gF)=T_t^g\mathcal N(F).
\]

This gives an explicit finite-at-each-degree, mutation-compatible, integer
coefficient normalization. **Coefficient positivity is not established by this
argument**; division by C(F) may introduce negative coefficients. The missing
general theorem is whether the intended minimal positive family is already
fixed by N, or whether a positivity-preserving combinatorial realization of
this normalization exists.

The displayed equivariance is in the fixed original-frozen transport frame.
It does not by itself identify N with a normalization performed after
reinitializing the coefficient variables at another seed. That operation may
change the positive completion cone and may first require the separate global
normalized-pointedness/Laurent-admissibility condition.

## 4. The cubic theorem supplies a first sharpness proof

For the arbitrary positive x,y,z row-balanced cycle of
`SHARP_RADICAL_CUBIC_RECURRENCE.md`, write r_i and C_ij as there. At p=111,

\[
 [z^{111}]\log F
  =A_{111}-\sum_i r_i A_{e_j+e_k}+2r_0r_1r_2.
\]

The proved sharp recurrence

\[
 A_{111}=r_0r_1r_2+r_2C_{01}+r_0C_{12}+r_1C_{20}
\]

sets this expression to zero for every label g. This is a consequence of a
complete all-word positivity and sharpness proof, rather than an assumption
imposed on the desired basis. It connects primitive central normalization to
a positive matching model at the first true three-direction coefficient.
