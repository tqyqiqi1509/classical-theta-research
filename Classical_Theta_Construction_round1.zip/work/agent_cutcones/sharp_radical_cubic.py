"""Exact positive cubic recurrence on a row-balanced skew-symmetrizable cycle.

The proof covers all integer labels and all positive integer edge parameters;
the symbolic tables are verified here.  Numerical tests are independent sanity
checks of the closed formula and actual short-word sharpness, not the source of
the all-word claim.  See SHARP_RADICAL_CUBIC_RECURRENCE.md.
"""
from pathlib import Path
import sys,itertools,json,random,time
import sympy as sp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import third_order_endpoint_certificate as ep
from universal_atlas import JetRing

def matrix(parameters):
    x,y,z=parameters
    return [[0,x,-x],[-y,0,y],[z,-z,0]]

def coefficients(parameters,g):
    x,y,z=parameters;aa=[x,y,z];r=[max(-v,0)for v in g];s=[max(v,0)for v in g]
    C={(i,(i+1)%3):max(aa[(i+1)%3]*r[i]-s[(i+1)%3]*min(r[i],aa[i]),0)
       for i in range(3)}
    pairs={(i,(i+1)%3):r[i]*r[(i+1)%3]+C[i,(i+1)%3]for i in range(3)}
    top=r[0]*r[1]*r[2]+r[2]*C[0,1]+r[0]*C[1,2]+r[1]*C[2,0]
    return [1,r[2],r[1],r[0],pairs[1,2],pairs[2,0],pairs[0,1],top]

def squarefree_row(B,g,H,ee):
    """No generalized-binomial evaluation: use divisibility H_i-1 by z_i."""
    R=JetRing(ee);out=[]
    for q in ee:
        pp=R.unit
        for i in range(3):
            power=g[i]+sum(B[i][j]*q[j]for j in range(3))
            ff=tuple(1 if k==0 else power*v for k,v in enumerate(H[i]))
            pp=R.mul(pp,ff)
        out.append(pp[R.idx[tuple(1-v for v in q)]])
    return tuple(out)

def symbolic_tables():
    x,y,z=sp.symbols('x y z',positive=True,integer=True)
    A,B,C,P=sp.symbols('A B C P',nonnegative=True,integer=True)
    BB=matrix((x,y,z));old=ep.generalized_binomial
    ep.generalized_binomial=lambda v,j:sp.prod(v-k for k in range(j))/sp.factorial(j)
    try:ee,bases=ep.binary_bases(BB)
    finally:ep.generalized_binomial=old
    assert all(sp.expand(h[-1])==0 for bas in bases for h in bas['H'])
    M=A*B*C+z*A*B+y*A*C+x*B*C
    modes={
        'all_nonpositive':((-A,-B,-C),[1,C,B,A,B*C+z*B,A*C+x*C,A*B+y*A,M],False,
            [M,B*(A*z+C*x),A*(B*z+C*y),C*(A*y+B*x),0]),
        'two_negative':((-A,-B,C),[1,0,B,A,P,0,A*(B+y),0],True,
            [0,-A*C*(B+y),A*(z*B-y*C)-B*C*(A+x),A*(z*B-y*C),A*P,A*P-A*C*y-B*C*x]),
        'one_negative':((-A,B,C),[1,0,0,A,0,0,P,0],True,
            [0,-P*C,-A*(B*z+C*y),-P*C-A*B*C-A*B*z,-C*(P+A*B+B*x),-C*(P-A*y+B*x)]),
        'all_nonnegative':((A,B,C),[1,0,0,0,0,0,0,0],False,
            [0,B*(A*z+C*x),C*(A*y+B*x),A*(B*z+C*y),M])}
    answer={}
    for name,(g,coef,threshold,allowed)in modes.items():
        expected={sp.expand(v)for v in allowed};table=[];actual=set()
        for bas in bases:
            row=squarefree_row(BB,g,bas['H'],ee)
            val=sp.expand(sum(a*b for a,b in zip(row,coef)))
            if threshold:val=-val
            val=sp.expand(val);assert val in expected,(name,bas,val)
            actual.add(val)
            table.append({'u':bas['u'],'tau':[v for ij,v in bas['taus']],'value':str(sp.factor(val))})
        assert actual==expected,(name,actual,expected)
        answer[name]={'type':'lower_threshold'if threshold else'transported_value','states':table}
    return answer

def numerical_checks():
    rng=random.Random(202611130537);count=0;actual_count=0
    for parameters in itertools.product(range(1,5),repeat=3):
        BB=matrix(parameters);ee,bases=ep.binary_bases(BB);R=JetRing(ee)
        for j in range(64):
            g=tuple(rng.randint(-12,12)for _ in range(3));coef=coefficients(parameters,g)
            vals=[sum(a*b for a,b in zip(squarefree_row(BB,g,bas['H'],ee),coef))for bas in bases]
            assert min(vals)>=0,(parameters,g,coef,vals)
            assert min(vals)==0,(parameters,g,coef,vals)
            # For one representative of every sign pattern, verify a real
            # mutation word reaches the stated minimum, independently of the
            # compatible-state enumeration.
            if j<8:
                _,seeds=ep.short_seeds(BB,3)
                best=max([0]+[-sum(a*b for a,b in zip(R.transform(BB,g,s['H'])[-1][:-1],coef[:-1]))for s in seeds])
                assert best==coef[-1],(parameters,g,best,coef[-1])
                actual_count+=1
            count+=1
    return {'parameter_label_checks':count,'actual_short_word_sharpness_checks':actual_count,
            'seed':202611130537}

if __name__=='__main__':
    start=time.time();tables=symbolic_tables();checks=numerical_checks()
    out={'symbolic_tables':tables,'checks':checks,'seconds':time.time()-start,'all_passed':True}
    json.dump(out,open(HERE/'sharp_radical_cubic_verification.json','w'),indent=2)
    print(json.dumps({'checks':checks,'seconds':out['seconds'],'all_passed':True}))
