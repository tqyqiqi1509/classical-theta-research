"""Compare recursive saturated coefficient prefixes, not full positivity cones.

At each initial frozen degree p, set A_p to the smallest nonnegative integer
making the currently tested original-frozen coefficient rows nonnegative while
holding every proper predecessor fixed.  This does NOT prove a coordinatewise
least jet, common pointedness, Laurent admissibility, or a basis identity.
"""
import sys,json,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from universal_atlas import universal_atlas,JetRing

def saturated(B,g,ee,HH,paths,bound=None):
    idx={p:i for i,p in enumerate(ee)};A=[1];witness=[]
    for ip,p in enumerate(ee[1:],1):
        qs=[q for q in ee if all(a<=b for a,b in zip(q,p))]
        inds=[idx[q]for q in qs];R=JetRing(qs);subA=[A[i]for i in inds[:-1]]
        projected={}
        for H,w in zip(HH,paths):
            if bound is not None and len(w)>bound:continue
            h=tuple(tuple(hi[j]for j in inds)for hi in H)
            projected.setdefault(h,w)
        v=0;wit=None
        for h,w in projected.items():
            row=R.transform(B,g,h)[-1]
            val=-sum(a*b for a,b in zip(row[:-1],subA))
            if val>v:v=val;wit=w
        A.append(v);witness.append(wit)
    return A,witness

if __name__=='__main__':
    old=json.load(open(HERE/'degree4_cone_results.json'))['results'];out=[];start=time.time()
    for z,dat in enumerate(old):
        B=dat['B'];meta,ee,HH,words=universal_atlas(B,4,dat['atlas']['depth'],250000,2048)
        r={'name':dat['name'],'B':B,'atlas':meta,'cases':[]}
        for cas in dat['cases']:
            g=cas['g'];full,fw=saturated(B,g,ee,HH,words)
            rec={'g':g,'full':full,'differences':[]}
            for bd in [3,4,5,6]:
                aa,aw=saturated(B,g,ee,HH,words,bd)
                diff=[{'p':p,'short':a,'long':b,'long_witness':fw[i-1]}
                      for i,(p,a,b)in enumerate(zip(ee,aa,full))if a!=b]
                rec['differences'].append({'bound':bd,'differences':diff})
            r['cases'].append(rec)
        out.append(r)
        print(z,dat['name'],[[len(x['differences'])for x in c['differences']]for c in r['cases']],flush=True)
        target=HERE/'saturated_prefix_results.json';tmp=target.with_suffix('.tmp')
        json.dump({'results':out,'seconds':time.time()-start,'completed':z==len(old)-1},open(tmp,'w'),indent=2)
        tmp.replace(target)
