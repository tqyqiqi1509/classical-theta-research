"""An exact normalized degree-three counterexample to uniform short-five cuts.

The prescribed squarefree table is extended to the entire total-degree-three
jet by triangular recursion, so every short-word coefficient through degree
three is checked, not only the target downset.  This is deliberately distinct
from the minimal-proper-prefix recurrence: the prescribed prefix is not minimal.
"""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from universal_atlas import universal_atlas,JetRing
from third_order_endpoint_certificate import root_step
from principal_cluster import mutate_matrix
from exact_laurent_mutation import initial_E

B=[[0,2,-2],[-2,0,3],[2,-3,0]];g=(-1,-1,-1)
word=(0,2,0,1,2,0,2,1);top=(1,1,1)
meta,ee,HH,paths=universal_atlas(B,3,5,100000,4096);R=JetRing(ee)
Ts=[R.transform(B,g,H)for H in HH]
qs=[p for p in ee if max(p)<=1]
prescribed=dict(zip(qs,[1,4,1,1,4,12,3,12]))
A=[]
for ip,p in enumerate(ee):
    if ip==0:A.append(1);continue
    need=max([0]+[-sum(T[ip][j]*A[j]for j in range(ip))for T in Ts])
    if p in prescribed:
        assert prescribed[p]>=need,(p,prescribed[p],need)
        A.append(prescribed[p])
    else:A.append(need)
all_values=[sum(a*b for a,b in zip(row,A))for T in Ts for row in T]
assert min(all_values)>=0
E=initial_E(B);H=((1,)+(0,)*(len(ee)-1),)*3
for k in word:
    c=tuple(E[3+i][k]for i in range(3));alpha=tuple(abs(v)for v in c)
    H=root_step(B,H,ee,alpha,c);E=mutate_matrix(E,k)
badT=R.transform(B,g,H);badvalue=sum(a*b for a,b in zip(badT[ee.index(top)],A))
assert badvalue==-6
out={'B':B,'g':g,'short_bound':5,'short_atlas':meta,'coefficients':list(zip(ee,A)),
     'short_coefficient_checks':len(all_values),'minimum_short_value':min(all_values),
     'bad_word':word,'bad_target':top,'bad_value':badvalue,
     'minimal_proper_prefix':False,'normalized_constant_one':True}
json.dump(out,open(HERE/'normalized_short5_counterexample.json','w'),indent=2)
print(json.dumps(out))
