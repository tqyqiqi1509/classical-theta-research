import sys,json,random,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from universal_atlas import universal_atlas
from jet_cut_cones import universal_cut_cones

rng=random.Random(202611130502)
old=json.load(open(HERE/'degree3_cone_results.json'))['results']
samples=[];seen=set()
for r in old:
    B=r['B'];key=tuple(map(tuple,B))
    if key not in seen:
        seen.add(key);samples.append((r['name'],B))
# Broader edge magnitudes and integral symmetrizers test the proposed uniform
# word bound, not a classification of selected finite types.
for z in range(12):
    n=3 if z<8 else 4;D=[1]*n if z<6 else [rng.randint(1,5)for _ in range(n)]
    B=[[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1,n):
            a=rng.choice([-3,-2,-1,0,1,2,3]);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
    samples.append((f'broad_{z}',B))
out=[]
for z,(name,B) in enumerate(samples):
    start=time.time();n=len(B);depth=13 if n==3 else 10 if n==4 else 8
    meta,ee,HH,paths=universal_atlas(B,4,depth,seed_cap=250000,bit_cap=2048)
    gs=[[-1]*n,[rng.randint(-5,5)for _ in range(n)]]
    cases=[]
    for g in gs:
        ss=universal_cut_cones(B,g,4,ee,HH,paths,(4,5,6,7))
        cases.append({'g':g,'tests':ss})
    r={'name':name,'B':B,'atlas':meta,'cases':cases,'seconds':time.time()-start};out.append(r)
    print(z,name,'seeds',meta['seeds'],'H',len(HH),'cuts',[[len(s['separators'])for s in c['tests']]for c in cases],
          'sec',round(r['seconds'],2),flush=True)
    json.dump({'results':out,'completed':z==len(samples)-1},open(HERE/'degree4_cone_results.json','w'),indent=2)
