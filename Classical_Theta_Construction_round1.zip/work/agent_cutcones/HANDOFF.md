# Handoff — higher-degree cuts, radical identities, sharp cubic recurrence

Owner `/root/higher_degree_cut_cones`; work wave began 2026-11-13 04:55 UTC.
The live chronology and literature audit are in `RESEARCH_LOG.md`.

## Read these first

1. `SHARP_RADICAL_CUBIC_RECURRENCE.md`: the main new sharp positive recurrence,
   all integer labels, arbitrary positive row-balanced edge parameters,
   including nontrivial symmetrizers. Proof is complete on its stated cap.
2. `CENTRAL_LOG_NORMALIZATION.md`: the root agent's general central-log invariant
   independently verified, plus integral Euler-product normalization.
3. `RADICAL_AND_SQUAREFREE_MECHANISM.md`: arbitrary-rank radical log-degree and
   squarefree coefficient vanishing, multiaffine block rows, finite CM interval
   criterion, and a universal balanced-cycle transport classification.

## Scope that must be preserved

All current coefficients live in the **original principal frozen formal jets**.
Nonnegativity here does not imply ordinary Laurent admissibility, normalized
pointedness after resetting coefficients, a finite polynomial, a basis, or a
theta identity. Root's other branch is treating the global pointedness issue.

Do not turn finite BFS stabilization into an all-word theorem. Only the explicit
finite certificate mechanisms / algebraic proofs below justify all-word claims.

## New proved general mechanisms

- Root-factor logarithms lie in the Hamiltonian span E_p. For Bp=0 outside an
  isolated axis, no actual c-vector is proportional to p; C^TDBC=DB_t would
  create an isolated vertex in a nontrivial mutation component. A final bracket
  of degrees a+b=p has coefficient a^TDBb=a^TDBp=0. Hence [E_p]log T=0.
- H_i-1 is divisible by z_i. For squarefree radical p, [z^p]H_i=0, directly
  from the binomial recurrence. More generally this holds for an individual i
  when p_i<=1.
- On a squarefree cap, H_i^{g_i}=1+g_i(H_i-1). Every coefficient row is a
  multiaffine polynomial in g+Bq, computed by rooted disjoint blocks. This is
  an explicit finite combinatorial expansion, but its signed-row minimization
  remains substantive.
- Root's proposed invariant is correct:
  [z^p]log(T_t^g F)=[z^p]log F for every unit F and non-isolated radical p.
  Consequently every normalized cluster monomial F is central-log-free.
- Integral primitive normalization: F has a unique Euler product
  product_a (1-z^a)^{c_a}, c_a integer. Projection of log to radical degrees
  retains exactly the radical Euler factors. Thus C(F)=exp(Pi_rad logF) and
  N(F)=F/C(F) are integral formal units; N commutes with actual transport.
  **No positivity preservation theorem for N has been proved.**

## Main sharp recurrence — usable for every label

For arbitrary positive integers a0,a1,a2, put

    B = [[0,a0,-a0],[-a1,0,a1],[a2,-a2,0]].

Let r_i=[-g_i]+, s_i=[g_i]+, and along the cyclic arrows i->j set

    C_ij = [a_j*r_i - s_j*min(r_i,a_i)]+.

Fix the known least proper coefficients a0=1, A_ei=r_i,
A_ei+ej=r_i*r_j+C_ij. Then the exact minimum A_111 for **all actual words** is

    A_111 = r0*r1*r2 + r2*C01 + r0*C12 + r1*C20.

This is the weighted triangle matching sum (monomers r_i, dimers C_ij).
The proof enumerates the fourteen possible degree-two binary lower states,
sets every top H_i coefficient to zero by the arbitrary-rank radical theorem,
and verifies nonnegativity symbolically in four sign cases. Extra unrealizable
states are harmless on the minimal prefix. Actual words of length<=3 attain
the maximum. Therefore the formula is sharp without classifying reachability.

The formula is equivalent to [z^111]logF_g=0 on this minimal prefix; thus there
is a first genuine positivity/sharpness justification for primitive central
normalization, rather than an imposed condition.

`sharp_radical_cubic.py` reproduces all symbolic tables, plus 4,096 random
parameter/label checks and 512 independent actual-word sharpness checks.
`sharp_radical_cubic_verification.json`: all passed, 13.3 seconds.

## Exact all-word certificate machinery

### Endpoint / G-sign cones

For fixed proper jets below p, actual top values differ by lambda E_p.
There are at most two actual lambda values. With three, positivity at the two
outer endpoint seeds would make every column of the middle G pair both >=0
and <=0 with Dp, contradicting invertibility.

`third_order_endpoint_certificate.py` enumerates cap111 binary lower states.
Minimal-difference comparisons with actual short seeds force linear signs on
prospective G columns. Exact conic implication / rank exclusion / a mixed-sign
actual representative / two actual representatives can certify completeness.
With words through four, the first method proves 35/128 edge-0..3 skew
rank-three matrices universally in g. `third_endpoint_certificates.json` has
the actual certificates. It is a verifier, not an automatic stopping theorem.

Balanced cyclic r>=2 has exactly ten cap111 transports represented by empty,
i, reversed-arrow pairs (j,i), and triples (j,i,j); r=1 has fourteen, needing
four letters. A short direct proof is in the radical note. This universal list
is useful to root's structure-constant computation, but the sharp recurrence
above is stronger for saturation and does not need that classification.

### Positive CM intervals and Farkas

`cm_interval_certificates.py` computes finite initial F-jets of real cluster
variables by unitriangular inversion of their universal transports. Known
cluster variables bound the remaining lambda parameter exactly. An adverse
endpoint row is then expressed as a nonnegative rational combination of actual
short-word rows. Every accepted combination is reconstructed and checked over
QQ; numerical LP is only a search aid.

For edge0..3 skew rank-three B and **g=(-1,-1,-1) only**, this certifies all-word
short-four sufficiency in 120/128 matrices. This is not a universal-label result.
Call `certify_intervals(B,g,4,4)` for a new label. It is usually fast. The eight
unresolved cyclic matrices exposed both a real short-bound failure and a
structural incompleteness of CM tests alone.

When all cluster g-vectors pair positively with Dp, even infinitely many CM
tests cannot bound the adverse upper endpoint. In balanced Markov directions,
radical vanishing fixes the parameter; otherwise genuine seed admissibility
or another invariant is still needed.

## Computation results and corrected conjectures

- Initial N3 scan: 52 matrices x2 labels, ranks3/4/5, depths12/10/8,
  1,939,236 states, no pruning. 9,007 target-row tests per bound. Short3 has
  seven exact separators, all squarefree support3. Short4/5/7 all pass this
  restricted sample. **Never extrapolate uniform short4.**
- New larger-edge counterexample:
  B=[[0,2,-2],[-2,0,3],[2,-3,0]], g=(-1,-1,-1). Short<=5 fails at cap111.
  An exact a0=1 table, extended to all total-degree-three coefficients, is in
  `normalized_short5_counterexample.json`. Every one of 360 rows from the 18
  jets / 86 seeds through depth5 is nonnegative; actual word 02012021 has
  coefficient -6 at111. No pruning is involved in this counterexample proof.
  Its proper prefix is not minimal. The exploratory depth16 atlas had 278
  bit-pruned branches; do not call it exhaustive beyond the displayed witness.
- N4 full-cone scan: 64 matrices x2 labels, 1,733,750 unique universal seed
  states, depths13/10/8, no pruning. 30,546 target rows per bound; short4/5/6/7
  have 21/8/0/0 exact separators.
- N4 **saturated** prefix scan changes the priority: all 128 tested labels agree
  at short5 with every tested deeper row. Short4 has one coefficient increase:
  B=[[0,-2,9,10],[3,0,-6,-5],[-9,4,0,-10],[-6,2,6,0]],
  g=(-2,-3,0,1), p=(1,2,0,1), 298 ->306, word (1,3,1,0,1).
  The other127 labels already agree at short3. This is finite-depth evidence,
  not a general least-prefix theorem.
- B223 with five chosen labels has no saturated-prefix discrepancy through
  degree4 between short3 and all tested depth16 rows. Thus its full-cone
  counterexample does not yet obstruct the intended greedy-style construction.

## Main code APIs

- `universal_atlas.universal_atlas(B, degree, maxdepth, seed_cap, bit_cap)` returns
  metadata, exponents, universal H lists, first words. No inactive branch
  pruning. Detects mismatches at repeated B,C seeds.
- `JetRing(ee).transform(B,g,H)` reconstructs exact coefficient matrix.
- `jet_cut_cones.exact_nonnegative_combination(rows,target)` returns direct,
  exact Farkas, exact integer separator, or unverified. The separator branch
  assumes initial coordinate-positive rows; when used on signed normal cones,
  only successful exact Farkas results may be used as conclusions.
- `saturated_prefix_scan.saturated(...)`: fixed-prefix recursive minimum only;
  does not prove coefficientwise leastness or all-word completeness.

## Highest-value next work

1. Generalize the successful radical squarefree saturation step to larger
   support: top H vanishes, so only finite compatible proper jets and the
   rooted-block expansion remain. Seek a positive combinatorial maximum and an
   actual endpoint attaining it, as in the cubic matching proof.
2. For nonradical degrees, combine finite positive-function intervals with
   genuine admissibility information; CM positivity alone cannot be assumed
   complete. Focus on minimal proper prefixes, not the stronger full cone.
3. Test central primitive normalization on intended **minimal** positive
   families, while retaining all-seed pointedness and Laurent admissibility.
   Integrality/equivariance are solved; positivity is the new central gap.

## Literature refresh

Refreshes at about05:15 and05:35 are recorded, including useful/unused status.
New direct combinatorial interface sent to root:
Burcroff–Lee–Mou, arXiv:2611.10154v1, 6 Nov2026, m-leafy trees / m-Tamari
intervals / central rank-two tight gradings. It is an extended abstract and is
under root's independent strong review; no result from it is used here.
Akagi–Chen2603.16326v2 (8 Jun2026) is a promising G-fan bound interface but also
unused pending audit. The radical and cubic proofs use no 2026 conclusion.

## Files / persistence

This directory is about15MB uncompressed, dominated by reproducible JSON data.
Root handles durable checkpoints and the final combined ZIP; no separate
Library artifact was created by this child. The four Markdown notes and the
symbolic verification JSON are the high-value compact proof handoff.
