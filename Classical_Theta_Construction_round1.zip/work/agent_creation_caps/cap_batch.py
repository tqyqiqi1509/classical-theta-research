#!/usr/bin/env python3
"""Exact star + pair-creation upper-cap experiment.

All constraints are proved necessary for theta. A selected point is not
called theta. LPs supply proposals only; every conclusion is checked over Q.
"""
from pathlib import Path
import sys,json,time,argparse
HERE=Path(__file__).resolve().parent
WORK=HERE.parent
sys.path[:0]=[str(WORK/'agent_overlap_completion')]
from pair_upper_caps import pair_upper_caps,build_logic,primitive,exact_conic_scaled,propose_optimum,dump_poly
from independent_closure_counterexample import parameters,evaluate
from independent_chart_closure import coefficient_references
from fractions import Fraction
from collections import defaultdict
from itertools import product
import math
from ranktwo_packets import section_rows
from linear_carrier import mutate_rows
from schofield_carrier import acyclic_dimension
from block_upper_caps import block_upper_caps


def quotient_rows(B,g,Frows):
    n=len(g);width=len(next(iter(Frows.values())));out=[];zero=(0,)*width
    for k in range(n):
        fibers=defaultdict(dict)
        for p,row in Frows.items():
            if any(row):fibers[p[:k]+p[k+1:]][p[k]]=row
        for off,f in fibers.items():
            pp=off[:k]+(0,)+off[k:]
            c=max(-g[k]-sum(B[k][j]*pp[j] for j in range(n)),0)
            hi=max(f);qq=[]
            for s in range(hi+1):
                row=list(f.get(s,zero))
                for j in range(1,min(c,s)+1):
                    coeff=math.comb(c,j)
                    row=[x-coeff*y for x,y in zip(row,qq[s-j])]
                qq.append(tuple(row))
            if c and any(any(row) for row in qq[max(0,len(qq)-c):]):
                raise ArithmeticError(('not Laurent',k,off,c))
            out.extend(row for row in qq if any(row))
    return out


def cap_polynomial(family,d):
    I,J=family['I'],family['J'];n=len(d);G=exact_poly(family['rank_two_F']);out={}
    for p,a in G.items():
        for off in product(*(range(d[j]+1) for j in J)):
            q=[0]*n;q[I[0]],q[I[1]]=p
            assert a.denominator==1
            b=int(a)
            for j,t in zip(J,off):q[j]=t;b*=math.comb(d[j],t)
            if b:out[tuple(q)]=b
    return out


def atomic(path,obj):
    path=Path(path);tmp=path.with_suffix('.writing')
    tmp.write_text(json.dumps(obj,separators=(',',':')));tmp.replace(path)


def exact_poly(raw):return {tuple(x['p']):Fraction(x['a']) for x in raw}


def run_case(case,prove_all=True,mode='coeff'):
    tic=time.time();B,g=case['B'],case['g'];n=len(g)
    C=case.get('carrier') or {'d':case['d'],'vertices':case['vertices'],'lattice_points':case['points']}
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*n]]
    caps,families=pair_upper_caps(B,g,C['d'],M['ids'])
    block_stats=[];block_polys=[]
    if mode.startswith('block') or mode.startswith('graph'):
        if mode.startswith('graph') and case.get('precomputed_graph_caps'):
            capb={tuple(q['p']):q['a'] for q in case['precomputed_graph_caps']}
            block_stats=case['precomputed_graph_families']
        else:
            capb,block_stats,block_polys=block_upper_caps(B,C['d'],M['ids'],keep_polynomials=mode in ['block_pair_star','block_pair_pair'],graph=mode.startswith('graph'))
        for p in caps:
            if capb[p] is not None:caps[p]=min(caps[p],capb[p])
    upper=[tuple(caps[p]*x-y for x,y in zip(origin,R[i])) for p,i in M['ids'].items()]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])};extra=[];extra_stats=[]
    if case.get('extra_rows'):
        extra+=list(map(tuple,case['extra_rows']))
        extra_stats.append({'kind':'supplied_exact_necessary_rows','rows':len(case['extra_rows'])})
    if mode in ['pair','pair_star','pair_pair','neighbor_caps','neighbor_pair','block_pair','block_pair_star','block_pair_pair','graph_pair','graph_neighbor_pair']:
        rows,info=section_rows(B,g,source)
        extra += [row for key,row in rows]
        extra_stats.append({'kind':'pair_lower','rows':len(rows)})
    if mode in ['star','pair_star','pair_pair']:
        for family in families:
            P=cap_polynomial(family,C['d']);zero=(0,)*len(origin)
            Drows={p:tuple(P.get(p,0)*a-b for a,b in zip(origin,source.get(p,zero))) for p in set(P)|set(source)}
            Drows={p:r for p,r in Drows.items() if any(r)}
            rows=quotient_rows(B,g,Drows);extra += rows
            extra_stats.append({'kind':'cap_star','I':family['I'],'rows':len(rows)})
            if mode=='pair_pair':
                rows,info=section_rows(B,g,Drows)
                extra += [row for key,row in rows]
                extra_stats.append({'kind':'cap_pair','I':family['I'],'rows':len(rows)})
    if mode in ['block_pair_star','block_pair_pair']:
        for bi,P in enumerate(block_polys):
            zero=(0,)*len(origin)
            Drows={p:tuple(P.get(p,0)*a-b for a,b in zip(origin,source.get(p,zero))) for p in set(P)|set(source)}
            Drows={p:r for p,r in Drows.items() if any(r)}
            rows=quotient_rows(B,g,Drows);extra+=rows
            extra_stats.append({'kind':'block_star','block_index':bi,'rows':len(rows)})
            if mode=='block_pair_pair':
                rows,info=section_rows(B,g,Drows);extra+=[row for key,row in rows]
                extra_stats.append({'kind':'block_pair','block_index':bi,'rows':len(rows)})
    if mode in ['neighbor_caps','neighbor_pair','graph_neighbor_pair']:
        for k in range(n):
            if case.get('neighbor_directions') is not None and k not in case['neighbor_directions']:continue
            if not (all(b>=0 for b in B[k]) or all(b<=0 for b in B[k])):continue
            state,err=mutate_rows(B,g,source,k,cap=200000)
            if err:raise OverflowError(('neighbor creation cap transport',k,err))
            BB,gg,T=state;dt,_,_=acyclic_dimension(BB,gg)
            caps2,families2=pair_upper_caps(BB,gg,dt,T)
            if mode=='graph_neighbor_pair':
                capb,_,_=block_upper_caps(BB,dt,T,graph=True)
                for p in caps2:caps2[p]=min(caps2[p],capb[p])
            rows=[tuple(caps2[p]*a-b for a,b in zip(origin,row)) for p,row in T.items()]
            extra += rows
            extra_stats.append({'kind':'neighbor_caps','direction':k,'B':BB,'g':gg,'d':dt,'rows':len(rows)})
            if mode in ['neighbor_pair','graph_neighbor_pair']:
                rows,info=section_rows(BB,gg,T)
                extra += [row for key,row in rows]
                extra_stats.append({'kind':'neighbor_pair','direction':k,'rows':len(rows)})
    RR=list(dict.fromkeys(primitive(row) for row in R+upper+extra if any(row)))
    cost=tuple(sum(R[i][j] for i in M['ids'].values()) for j in range(S['dimension']))
    old=exact_poly(case['F']) if case.get('F') else None
    refs=coefficient_references(M,R)
    oldx=parameters(old,M,refs) if old is not None else None
    old_bad=[] if oldx is None else [i for i,row in enumerate(RR) if evaluate(row,oldx)<0]
    candidate=old if old is not None and not old_bad else None
    out={'B':B,'g':g,'D':case.get('D'),'d':C['d'],'carrier':C,'space':S,'mode':mode,'extra_row_statistics':extra_stats,
         'constraint_rows':len(RR),'families':families,'block_families':block_stats,'old_candidate_feasible':candidate is not None,
         'old_violation_rows':old_bad,'caps':[{'p':p,'a':a} for p,a in caps.items()]}
    if candidate is not None:
        mass=sum(candidate.values());target=tuple(a-mass*b for a,b in zip(cost,origin))
        cp=exact_conic_scaled(target,RR)
        if cp is not None:
            optimum={'status':'exact_optimum','value':str(mass),'parameters':[str(x) for x in oldx],
                     'dual':[[i,str(a)] for i,a in cp]}
        else:optimum=propose_optimum(cost,RR,origin)
    else:optimum=propose_optimum(cost,RR,origin)
    out['mass_optimization']=optimum
    if not optimum.get('parameters'):
        out.update(status='mass_unresolved',seconds=time.time()-tic);return out
    x=list(map(Fraction,optimum['parameters']))
    F={p:evaluate(R[i],x) for p,i in M['ids'].items() if evaluate(R[i],x)}
    assert evaluate(origin,x)==1 and all(evaluate(row,x)>=0 for row in RR)
    out.update(F=dump_poly(F),integral=all(a.denominator==1 for a in F.values()),mass=str(sum(F.values())),
               old_candidate_equal=old==F if old is not None else None)
    proofs=[];unknown=[];failure=None
    for p,a in sorted(F.items(),key=lambda x:(-sum(x[0]),-x[1],x[0])):
        row=R[M['ids'][p]];target=tuple(v-a*w for v,w in zip(row,origin))
        cp=exact_conic_scaled(target,RR)
        if cp is not None:
            proofs.append({'p':p,'value':str(a),'combination':[[i,str(v)] for i,v in cp]});continue
        lower=propose_optimum(row,RR,origin)
        if lower.get('parameters') and Fraction(lower['value'])<a:
            xx=list(map(Fraction,lower['parameters']))
            G={q:evaluate(R[i],xx) for q,i in M['ids'].items() if evaluate(R[i],xx)}
            failure={'p':p,'F_value':str(a),'lower_value':lower['value'],'optimization':lower,
                     'other_F':dump_poly(G),'integral':all(b.denominator==1 for b in G.values())}
            break
        unknown.append({'p':p,'optimization':lower})
        if not prove_all:break
    least=not failure and not unknown
    out.update(status='exact_least' if least else ('exact_coordinate_tradeoff' if failure else 'unresolved_coordinates'),
               a_least_proved=least,coordinate_proofs=proofs,coordinate_failure=failure,unresolved=unknown,
               seconds=time.time()-tic)
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');ap.add_argument('--start',type=int,default=0)
    ap.add_argument('--stop',type=int,default=10000);ap.add_argument('--stop-on-failure',action='store_true')
    ap.add_argument('--mode',default='coeff',choices=['coeff','star','pair','pair_pair','pair_star','neighbor_caps','neighbor_pair','block','block_pair','block_pair_star','block_pair_pair','graph','graph_pair','graph_neighbor_pair'])
    ar=ap.parse_args();raw=json.loads(Path(ar.input).read_text());cases=raw['results'] if isinstance(raw,dict) else raw
    results=[];tic=time.time()
    for ci,c in enumerate(cases[ar.start:ar.stop],ar.start):
        if not c.get('carrier') and not c.get('points'):continue
        print('START',ci,'rank',len(c['g']),'d',c['d'],flush=True)
        try:r=run_case(c,mode=ar.mode)
        except Exception as e:
            r={'B':c['B'],'g':c['g'],'d':c['d'],'status':'unresolved_exception','reason':repr(e)}
        r['source_index']=ci;results.append(r);atomic(ar.output,{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'integer',r.get('integral'),'mass',r.get('mass'),'seconds',r.get('seconds'),flush=True)
        if r.get('coordinate_failure'):
            print('TRADEOFF',r['coordinate_failure']['p'],r['coordinate_failure']['F_value'],r['coordinate_failure']['lower_value'],flush=True)
            if ar.stop_on_failure:break


if __name__=='__main__':main()
