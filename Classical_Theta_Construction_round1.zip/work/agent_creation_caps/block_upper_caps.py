#!/usr/bin/env python3
"""Genuine rank-two block product upper bounds, entirely integer arithmetic.

For a capacity partition d=sum e, each e supported on at most two vertices,
multiply the corresponding genuine LLZ polynomials.  The product contains
the full-rank theta at capacity d with coefficient one.  No unidentified
higher-rank candidate is used in any upper bound here.
"""
from pathlib import Path
import sys,math
from itertools import combinations,product
from functools import lru_cache
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'agent_overlap_completion'))
from ranktwo_packets import greedy


@lru_cache(None)
def block_polynomial(B,e):
    n=len(e);I=tuple(i for i,a in enumerate(e) if a)
    if not I:return {(0,)*n:1}
    if len(I)==1:
        i=I[0]
        return {tuple(t if j==i else 0 for j in range(n)):math.comb(e[i],t) for t in range(e[i]+1)}
    assert len(I)==2
    if B[I[0]][I[1]]<0:I=tuple(reversed(I))
    h=tuple(-e[i]+sum(max(-B[i][j],0)*e[j] for j in I) for i in I)
    G=greedy(B[I[0]][I[1]],-B[I[1]][I[0]],h)
    out={}
    for p,a in G.items():
        q=[0]*n;q[I[0]],q[I[1]]=p;out[tuple(q)]=int(a)
    return out


def multiply(F,G):
    H=defaultdict(int)
    for p,a in F.items():
        for q,b in G.items():H[tuple(u+v for u,v in zip(p,q))]+=a*b
    return dict(H)


def two_pair_partitions(d):
    """Every 3-vertex two-edge allocation, singleton factors elsewhere.

    In rank three this is every two-block split with supports of size <=2.
    In higher rank the same local allocations are paired with singleton
    capacities elsewhere.  This is a finite subset of the general graph
    capacity partition family; it makes no completeness claim.
    """
    n=len(d);seen=set()
    for triple in combinations(range(n),3):
        for shared in triple:
            i,j=(v for v in triple if v!=shared)
            for s in range(d[shared]+1):
                a=[0]*n;b=[0]*n;a[i]=d[i];a[shared]=s;b[j]=d[j];b[shared]=d[shared]-s
                blocks=[tuple(a),tuple(b)]
                for k in range(n):
                    if k not in triple:
                        e=[0]*n;e[k]=d[k];blocks.append(tuple(e))
                blocks=tuple(sorted(e for e in blocks if any(e)))
                if blocks not in seen:seen.add(blocks);yield blocks


@lru_cache(None)
def compositions(a,k):
    if not k:return ((),) if not a else ()
    if k==1:return ((a,),)
    return tuple((b,)+c for b in range(a+1) for c in compositions(a-b,k-1))


def graph_allocation_count(B,d):
    return math.prod(math.comb(d[i]+sum(bool(x) for x in B[i])-1,sum(bool(x) for x in B[i])-1)
                     for i in range(len(d)) if any(B[i]))


def graph_partitions(B,d,max_allocations=200000):
    """Exactly one capacity block per original edge, singleton if isolated.

    Merging equal-edge factors and absorbing a singleton into an incident
    edge weakly decreases the product by genuine rank-two strong positivity.
    Thus this finite family dominates all capacity partitions of support <=2,
    including partitions along nonedges (whose polynomial factors split).
    """
    n=len(d);edges=[(i,j) for i in range(n) for j in range(i+1,n) if B[i][j]]
    inc=[[k for k,e in enumerate(edges) if i in e] for i in range(n)]
    count=graph_allocation_count(B,d)
    if count>max_allocations:raise OverflowError(('graph allocations',count,max_allocations))
    parts=[compositions(d[i],len(inc[i])) if inc[i] else ((),) for i in range(n)]
    seen=set()
    for assign in product(*parts):
        ee=[[0]*n for _ in edges];single=[0]*n
        for i,allocation in enumerate(assign):
            if not inc[i]:single[i]=d[i]
            for k,a in zip(inc[i],allocation):ee[k][i]=a
        # Coalesce all pure singleton factors at a vertex, avoiding duplicate
        # polynomials at degenerate endpoints of the allocation simplex.
        blocks=[]
        for e in ee:
            supp=[i for i,a in enumerate(e) if a]
            if len(supp)==1:single[supp[0]]+=e[supp[0]]
            elif supp:blocks.append(tuple(e))
        for i,a in enumerate(single):
            if a:blocks.append(tuple(a if j==i else 0 for j in range(n)))
        blocks=tuple(sorted(blocks))
        if blocks not in seen:seen.add(blocks);yield blocks


def block_upper_caps(B,d,points,keep_polynomials=False,graph=False):
    B=tuple(map(tuple,B));n=len(d);caps={tuple(p):None for p in points};families=[];polys=[]
    partitions=graph_partitions(B,d) if graph else two_pair_partitions(d)
    for blocks in partitions:
        F={(0,)*n:1}
        for e in blocks:F=multiply(F,block_polynomial(B,e))
        improve=0
        for p in caps:
            a=F.get(p,0)
            if caps[p] is None or a<caps[p]:caps[p]=a;improve+=1
        families.append({'blocks':blocks,'mass':sum(F.values()),'terms':len(F),'new_minimum_points':improve})
        if keep_polynomials:polys.append(F)
    return caps,families,polys
