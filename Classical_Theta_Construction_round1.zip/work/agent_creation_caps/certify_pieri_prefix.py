#!/usr/bin/env python3
"""Locate exactly which local lower coefficients in a Pieri row remain free."""
from cap_batch import *


if __name__=='__main__':
    info=json.loads((HERE/'pieri_creation_cut.json').read_text());root=tuple(info['root']);n=len(root)
    needs=defaultdict(set);creator=(21,6,9,2)
    needs[creator].update(product(*(range(a+1) for a in root)))
    for term in info['terms_before_and_at_root']:
        q=tuple(term['q']);d=tuple(term['capacity'])
        if q==root:continue
        needs[d].update(product(*(range(root[i]-q[i]+1) for i in range(n))))
    output=[]
    for d,ps in sorted(needs.items(),key=lambda z:(sum(z[0]),z[0])):
        file=WORK/'agent_two_sided_pieri'/'graph_target_lower_cache'/('d_'+'_'.join(map(str,d))+'.json')
        c=json.loads(file.read_text());F=exact_poly(c['F']);M,R,S=build_logic(c['B'],c['g'],c['carrier'])[:3]
        origin=R[M['ids'][(0,)*n]];caps={tuple(q['p']):q['a'] for q in c['caps']}
        upper=[tuple(caps[p]*a-b for a,b in zip(origin,R[i])) for p,i in M['ids'].items()]
        source={p:R[i] for p,i in M['ids'].items() if any(R[i])};pairs,_=section_rows(c['B'],c['g'],source)
        RR=list(dict.fromkeys(primitive(r) for r in R+upper+[r for key,r in pairs] if any(r)))
        fixed=[];free=[];zerooutside=[]
        for p in sorted(ps,key=lambda p:(sum(p),p)):
            if p not in M['ids']:zerooutside.append(p);continue
            a=F.get(p,0);row=R[M['ids'][p]];target=tuple(a*u-v for u,v in zip(origin,row))
            cp=exact_conic_scaled(target,RR)
            if cp is not None:fixed.append({'p':p,'value':str(a),'upper_dual':[[i,str(v)] for i,v in cp]});continue
            opt=propose_optimum(tuple(-x for x in row),RR,origin)
            free.append({'p':p,'candidate':str(a),'negative_maximum':opt})
        rr={'d':d,'dimension':S['dimension'],'checked_prefix_points':len(ps),'fixed':fixed,'free':free,'outside_support_forced_zero':zerooutside}
        output.append(rr);atomic(HERE/'pieri_prefix_certification_results.json',{'results':output})
        print('PREFIX',d,'dim',S['dimension'],'fixed',len(fixed),'outsidezero',len(zerooutside),'free',[(q['p'],q['candidate'],q['negative_maximum'].get('value')) for q in free],flush=True)
