#!/usr/bin/env python3
"""Genuine source/sink inequalities for the ambiguous creation dependency."""
from cap_batch import *


if __name__=='__main__':
    file=WORK/'agent_two_sided_pieri'/'graph_target_lower_cache'/'d_21_6_9_2.json'
    c=json.loads(file.read_text());c['neighbor_directions']=[0]
    r=run_case(c,mode='graph_neighbor_pair')
    atomic(HERE/'creator_neighbor_repair_results.json',r)
    print('CREATOR',r['status'],r.get('mass'),'integral',r.get('integral'),'old_equal',r.get('old_candidate_equal'),flush=True)
    old=exact_poly(c['F']);F=exact_poly(r['F']) if r.get('F') else {}
    diff={p:F.get(p,0)-old.get(p,0) for p in set(old)|set(F) if F.get(p,0)!=old.get(p,0)}
    print('DIFFERENCE',dump_poly(diff),flush=True)
