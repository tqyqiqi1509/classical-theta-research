# Graph capacity products: a finite combinatorial upper envelope

Working note, 2026-11-13 08:32 UTC. Classical cluster algebras only.
The independent proof of the product upper bound is coordinated with
`agent_two_sided_pieri` and the root's creation-cap theorem. No Li–Pan theorem
is used. The finite selector below is a **candidate**, and its completeness
has now been disproved in rank four. The upper-bound theorem remains valid.

## 1. Genuine graph factors

Let B be acyclic and skew-symmetrizable. Set A=[-B]_+ and
g(d)=-d+Ad for d in N^n. A positive decoration v with v_i d_i=0 can be
restored by multiplication by x^v; it does not change the F-polynomial.

For every capacity vector e supported on at most two vertices, define
L_e to be the genuine rank-two LLZ F-polynomial, embedded into the full
variable set, at label -e_I+A_II e_I. For singleton e=a epsilon_i this is
(1+z_i)^a. For an edgeless pair it factors into these singleton polynomials.
The embedding is justified by freezing; outside x-exponents are retained
in x^{g(e)}, although L_e uses only the two selected z-variables.

For every partition d=sum e^(a), with each e^(a) supported on at most two
vertices, strong positivity and the leading coefficient one give

    product_a L_{e^(a)} = F_d + sum_(q>0) c_q z^q F_{g(d)+Bq},  c_q>=0.

This identity is used only to prove necessary conditions. The right-hand
side unknown high-rank F-polynomials are **never program inputs**. The
products on the left use integer binomial arithmetic and the LLZ recurrence.

Consequently every product supplies coefficient upper bounds and also
genuine positive remainder constraints.

## 2. Reduction to an ordinary graph capacity allocation

For each actual unoriented edge {i,j}, choose endpoint capacities
e_i^{ij},e_j^{ij}>=0. At each non-isolated vertex require

    sum_(j adjacent i) e_i^{ij}=d_i.

Isolated vertices have the single factor (1+z_i)^{d_i}. The associated
polynomial is P_E=product_(edges) L_(e^{ij}).

This finite family dominates all partitions in Section 1. Indeed, factors
on the same pair can be merged because rank-two strong positivity gives
L_(a+b) <= L_a L_b coefficientwise. Nonedge factors split into singletons;
a singleton may be absorbed into any incident edge, again by the same
rank-two product inequality. Multiplying by other nonnegative factors
preserves the inequality. The stronger statement holds in theta-positive
order, so the same reduction applies to the remainder constraints.

Before removal of duplicate degenerate allocations, the family size is

    product_(i non-isolated) binom(d_i+deg(i)-1,deg(i)-1).

The exact implementation is `block_upper_caps.py:graph_partitions`.
It coalesces singleton factors at degenerate endpoints but never drops a
distinct factor product without an exact equality/dominance argument.

Define U(p)=min_E [z^p]P_E and S={p:U(p)>0}. The theorem proves that S
contains the support of the genuine high-rank theta polynomial. Therefore
one may construct a finite coefficient space directly from S, without a
Newton polytope, representation variety, scattering diagram, or broken
line computation.

## 3. The tested selector

On S impose a_0=1, a_p>=0, all initial-star Laurent divisibility equations,
nonnegative initial-star binomial quotients, all initial rank-two LLZ slice
expansion coefficients nonnegative, and a_p<=U(p). These are exact rational
linear constraints with integer coefficients, all theta-necessary.

The candidate rule asks for a coefficientwise least feasible point. In all
reported successes every coordinate lower bound has a rational conic
certificate. Numerical linear programs only propose witnesses and dual
supports. They are reconstructed and verified over Q before any assertion.

Five previously hard rank-three inputs pass even after replacing their
Newton carriers by S. Their ambient linear dimensions become 31,24,23,15,15.
The selected masses are 3160,21206,3150,6586129065,59085 respectively.
The graph support can include points outside the Newton carrier: the second
case has six such points and the last two have one each. These coordinates
are zero in the exact least candidate.

The original 43 skew-symmetric and 45 valued cached inputs pass a weaker
two-edge subfamily; all 45 valued inputs also pass the full graph family on
its support (see output for any resource exception before quoting a count).
Eighteen new ranks 4–6 inputs pass full graph allocation, but most have
one-dimensional Laurent spaces and provide only limited stress coverage.
Connected extensions of the hard fork have ranks 4,5,6, support sizes
520,993,1615, and Laurent-space dimension 31 in all three cases. They pass,
with masses 145740,271421,436128. These claims concern the finite selector,
not independently identified theta polynomials.

## 4. Exact rank-four failure under source mutation

The first substantive source/sink covariance test fails. Start with

    B = [[0,0,3,1],[0,0,2,0],[-3,-2,0,0],[-1,0,0,0]],
    g = (-8,-7,29,6), d = (8,7,9,2).

Its pure graph selector has an exact integer coefficientwise least point
of mass 145740. Mutate the source 0. The target is

    B' = [[0,0,-3,-1],[0,0,2,0],[3,-2,0,0],[1,0,0,0]],
    g' = (8,-7,5,-2), d' = (21,7,9,2).

The target has 220 distinct graph factor products, 759 support points,
43 linear parameters and 761 deduplicated positivity inequalities. The
actual Laurent transport of the source candidate is feasible and integral,
with mass 15151380. Nevertheless:

* An integral feasible F has exact minimum mass 15151164; a nonnegative
  combination of 41 inequality rows certifies this minimum.
* Another integral feasible G has mass 15151332 and
  G(2,6,2,2)=216 < 219=F(2,6,2,2).

Thus no coefficientwise least point exists. If L were least, L<=F and the
minimum mass property would force L=F; the displayed G contradicts that.
Both primal witnesses satisfy every full graph coefficient upper bound,
every initial star condition and every initial pair lower condition.

`graph_transport_extension_results.json` contains all exact data.
`verify_graph_counterexample.py` reconstructs the inequalities and verifies
the primal and dual certificates without calling an optimizer; its result
is `graph_covariance_counterexample_audit.json`.

This counterexample invalidates the general completeness and mutation
covariance of the selector in Section 3. It does not invalidate graph
product upper bounds, their support consequence, or the dominance reduction.

## 5. Current repair mechanism: positive graph-product remainders

For every genuine graph product P_E, require P_E-F to have nonnegative
initial-star quotients and nonnegative LLZ expansions on every rank-two
slice. These inequalities are stronger than coefficient upper caps and
remain theta-necessary with no presumed higher-rank factor. The finite
separation implementation is `graph_remainder_completion.py`.

On the rank-four failure, star-quotient remainder positivity alone does not
repair the failure: both displayed integer witnesses pass all 102465
generated rows. They also pass all 112142 rows after adding every genuine
rank-two remainder slice. The next structural extension is a
strict-smaller-capacity positive-basis remainder recursion; unidentified
lower-rank candidates must remain labelled until identification is proved.

## 6. A single genuine transported pair condition repairs this failure

The source mutation supplies one missing pair lower inequality. Its source
pair is (1,2), outside exponents on (0,3) are (6,2), its greedy root is
(3,2), and its rank-two label is (-3,5). Written in target coefficients,
the exact inequality is

    a_(5,6,3,2) - a_(8,6,4,2) - 51 >= 0.

This is a genuine theta-necessary condition: it is an actual Laurent
transport followed by an actual rank-two LLZ expansion. It takes values
-9 and -12 on the two counterexample points. Adding this single row to the
graph selector restores an exact integer coefficientwise least point of
mass 15151380, equal coefficient by coefficient to the source candidate's
Laurent transport. This is in `minimal_neighbor_repair_results.json`.

The Pieri branch independently recovered the same row as a lowering row
after correcting two smaller graph candidates by genuine neighbor
conditions. A creation row is its opposite, giving the equality

    a_(5,6,3,2) - a_(8,6,4,2) = 51.

An earlier provisional creation row had constant 33, rather than 51.
It incorrectly excluded the transported candidate because the creator
capacity (21,6,9,2) had itself lost a necessary positive term. The genuine
neighbor repair adds

    18 z^(2,3,2,2) ((1+z1)^2 + z1^2 z2 (1+z0)^3)

to that creator, increasing its mass from 14900652 to 14900868.
Consequently `graph_plus_one_creation_results.json` records an obsolete,
explicitly conditional experiment, not a valid theta selector.

The symbolic creation prefix uses 13 smaller capacities. For 11, every
coefficient actually used is uniquely forced by genuine graph and pair
constraints, even when the full polynomial is not unique. The only two
locally ambiguous inputs were (18,5,7,2) and (21,6,9,2); adding the source
neighbor conditions changes only the latter. Exact local uniqueness
certificates are in `pieri_prefix_certification_results.json`.

## 7. Fundamental-capacity interface under investigation

Every full graph-selector failure currently found has a positive Cartan
coordinate, using C_ii=2 and C_ij=-|B_ij|. In particular the target above has
(Cd)_0=13, whereas its source capacity (8,7,9,2) is Cartan fundamental.
This suggested constructing only at fundamental capacities, then using
genuine source/sink transport elsewhere. The hypothesis was disproved at
08:46 by the strict fundamental counterexample below.

Purpose-built full-allocation tests include K4 with unit edge weights and
capacity (4,4,4,4), a doubled 4-cycle at capacity 6, K3,3 at capacity 2,
K2,3 at capacity 3, and valued examples. All completed cases have exact
integer least points, including ambient dimensions 16,14,17,8 and32.
Their source/sink transports have also passed the actual pair positivity
and genuine single-pair creation-cap checks completed so far. The files
`fundamental_results_*.json` and `fundamental_forward_probe_results.json`
record the precise scope; no uncompleted case is counted as evidence.

### Strictly fundamental counterexample, completed08:46

Take B_ij=1 for i<j and B_ij=-1 for i>j on four vertices, and
d=(4,5,5,6). Then g=(-4,-1,4,8) and Cd=(-8,-5,-5,-2), strictly negative.
All185220 graph capacity allocations were enumerated, giving81897 distinct
products. Their positive-support intersection has173 points. The Laurent
space has47 parameters and the final genuine constraint system215 rows.

An integer feasible F of mass1829 has an exact45-term nonnegative dual
certificate of minimum mass. A second integer feasible G has mass2824 but
G_(3,2,2,1)=2<6=F_(3,2,2,1). Hence there is no coefficientwise least point,
even in the integer feasible set. This refutes fundamental completeness,
not just its rational-relaxation version. The sweep stopped immediately.

Exhaustive caps are in `fundamental_input_6.json`; full primal/dual witnesses
are in `fundamental_results_6_8.json`. `fundamental_counterexample_audit.json`
rebuilds Laurent/pair rows and checks both integer points and the exact dual,
reusing the saved exhaustive integer caps and calling no optimizer.
