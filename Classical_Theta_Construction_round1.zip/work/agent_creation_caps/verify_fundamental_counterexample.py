#!/usr/bin/env python3
"""Optimizer-free exact counterexample audit; saved exhaustive graph caps reused."""
from cap_batch import *
from block_upper_caps import graph_allocation_count


if __name__=='__main__':
    c=json.loads((HERE/'fundamental_results_6_8.json').read_text())['results'][0]
    inp=json.loads((HERE/'fundamental_input_6.json').read_text());B,g,C=c['B'],c['g'],c['carrier'];n=len(g)
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*n]]
    caps={tuple(q['p']):q['a'] for q in inp['precomputed_graph_caps']}
    cp,_=pair_upper_caps(B,g,C['d'],M['ids'])
    for p in caps:caps[p]=min(caps[p],cp[p])
    assert caps=={tuple(q['p']):q['a'] for q in c['caps']}
    upper=[tuple(caps[p]*a-b for a,b in zip(origin,R[i])) for p,i in M['ids'].items()]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])};pp,_=section_rows(B,g,source)
    RR=list(dict.fromkeys(primitive(row) for row in R+upper+[r for key,r in pp] if any(row)))
    assert len(RR)==c['constraint_rows']
    def check(opt,Fraw):
        x=list(map(Fraction,opt['parameters']));F=exact_poly(Fraw)
        assert evaluate(origin,x)==1 and all(evaluate(row,x)>=0 for row in RR)
        assert all(F.get(p,0)==evaluate(R[i],x) for p,i in M['ids'].items())
        return x,F
    x,F=check(c['mass_optimization'],c['F']);failure=c['coordinate_failure'];y,G=check(failure['optimization'],failure['other_F'])
    mass=sum(F.values());cost=tuple(sum(R[i][j] for i in M['ids'].values()) for j in range(S['dimension']))
    target=tuple(a-mass*b for a,b in zip(cost,origin));ans=[Fraction(0)]*S['dimension']
    for i,a in c['mass_optimization']['dual']:
        a=Fraction(a);assert a>=0
        for j,b in enumerate(RR[i]):ans[j]+=a*b
    assert tuple(ans)==target
    p=tuple(failure['p']);assert G[p]<F[p]
    Cd=[2*c['d'][i]-sum(abs(B[i][j])*c['d'][j] for j in range(n)) for i in range(n)];assert max(Cd)<0
    result={'verified':True,'B':B,'g':g,'d':c['d'],'Cartan_d':Cd,'full_allocation_count':graph_allocation_count(B,c['d']),
            'distinct_products':len(c['block_families']),'support':len(C['lattice_points']),'dimension':S['dimension'],
            'constraint_rows':len(RR),'minimum_mass':str(mass),'minimum_integer':all(a.denominator==1 for a in F.values()),
            'other_mass':str(sum(G.values())),'other_integer':all(a.denominator==1 for a in G.values()),
            'coordinate':p,'minimum_point_value':str(F[p]),'other_value':str(G[p]),'no_coefficientwise_least':True,
            'verification_scope':'Rebuilt exact Laurent/pair rows, reused saved exhaustive integer graph caps, verified both feasible points and exact conic mass dual. No optimizer called.'}
    atomic(HERE/'fundamental_counterexample_audit.json',result);print(json.dumps(result,indent=2))
