#!/usr/bin/env python3
"""Creation bounds after the proved single-theta auxiliary star surgery.

The construction is finite and uses only binomial/LLZ coefficients. It
does not use any unidentified high-rank lower theta table.
"""
from cap_batch import *
from enlarged_surgery_pair_test import extension
from itertools import product


def substar_families(B,i):
    n=len(B)
    options=[]
    for j in range(n):
        b,c=abs(B[i][j]),abs(B[j][i])
        step=b//math.gcd(b,c) if b else 1
        options.append(range(0,b+1,step))
    for a in product(*options):
        if any(a):yield a


def auxiliary_caps(B,g,C,partial=True):
    n=len(g);P=list(map(tuple,C['lattice_points']));caps,f0=pair_upper_caps(B,g,C['d'],P)
    caps={p:Fraction(a) for p,a in caps.items()};certificates={};records=[]
    for i in range(n):
        if not (all(b>=0 for b in B[i]) or all(b<=0 for b in B[i])):continue
        choices=substar_families(B,i) if partial else [tuple(abs(b) for b in B[i])]
        for a in choices:
            if not any(a):continue
            BB,gg,T,info=extension(B,g,{p:(1,) for p in P},P,i,a)
            dd,_,_=acyclic_dimension(BB,gg)
            cc,families=pair_upper_caps(BB,gg,dd,T)
            changed=[]
            for q,row in T.items():
                p=q[:-1];weight=row[0]
                if not weight:continue
                bound=Fraction(cc[q],weight)
                if bound<caps[p]:
                    caps[p]=bound
                    certificates[p]={'vertex':i,'removed':a,'lambda':info['lambda'],'extended_p':q,
                                     'upper':cc[q],'binomial':weight,'bound':str(bound)}
                    changed.append(p)
            records.append({**info,'target_d':dd,'tightened_coefficients':len(set(changed))})
            print('AUX',i,a,'lambda',info['lambda'],'points',len(T),'tightened',len(set(changed)),flush=True)
    return caps,certificates,records


def main():
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');ap.add_argument('--fullstar-only',action='store_true')
    ar=ap.parse_args();raw=json.loads(Path(ar.input).read_text());cases=raw['results'] if isinstance(raw,dict) else raw
    results=[];tic=time.time()
    for ci,c in enumerate(cases):
        B,g=c['B'],c['g'];C=c.get('carrier') or {'d':c['d'],'vertices':c['vertices'],'lattice_points':c['points']}
        print('START',ci,B,g,flush=True)
        try:
            caps,certs,records=auxiliary_caps(B,g,C,partial=not ar.fullstar_only)
            F=exact_poly(c['F']) if c.get('F') else {}
            violations=[{'p':p,'F':str(a),'bound':str(caps[p])} for p,a in F.items() if a>caps[p]]
            r={'B':B,'g':g,'d':C['d'],'carrier':C,'caps':[{'p':p,'a':str(a)} for p,a in caps.items()],
               'tightening_certificates':[{'p':p,**v} for p,v in certs.items()],
               'families':records,'old_candidate_violations':violations}
        except Exception as e:r={'B':B,'g':g,'d':C['d'],'status':'exception','reason':repr(e)}
        r['source_index']=ci;results.append(r);atomic(ar.output,{'seconds':time.time()-tic,'results':results})
        print('END',ci,'violations',len(r.get('old_candidate_violations',[])),'tightened',len(r.get('tightening_certificates',[])),r.get('reason'),flush=True)


if __name__=='__main__':main()
