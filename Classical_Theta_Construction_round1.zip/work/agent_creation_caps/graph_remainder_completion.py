#!/usr/bin/env python3
"""Separate full graph-product remainders by exact star and rank-two positivity.

Every added inequality is theta-necessary and uses only genuine LLZ factors.
No higher-rank candidate polynomial is used as a presumed theta factor.
"""
from cap_batch import *
from block_upper_caps import graph_partitions,block_polynomial,multiply


def make_product(B,blocks):
    F={(0,)*len(B):1};B=tuple(map(tuple,B))
    for e in blocks:F=multiply(F,block_polynomial(B,e))
    return F


def completion(case,outpath,iterations=40,batchsize=80,kind='pair'):
    B,g,C=case['B'],case['g'],case['carrier'];n=len(g)
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*n]]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])};zero=(0,)*len(origin)
    families=list(graph_partitions(B,C['d']));cache={};extra=[];seen=set();log=[]
    refs=coefficient_references(M,R)
    # The cache holds the symbolic rows once, so later separation has no
    # recurrence/transport recomputation and every selected row is reproducible.
    def rows_at(bi):
        if bi in cache:return cache[bi]
        P=make_product(B,families[bi]);Drows={p:tuple(P.get(p,0)*a-b for a,b in zip(origin,source.get(p,zero))) for p in set(P)|set(source)}
        Drows={p:r for p,r in Drows.items() if any(r)}
        rows=quotient_rows(B,g,Drows)
        if kind=='pair':
            pp,info=section_rows(B,g,Drows);rows+=[r for key,r in pp]
        rows=list(dict.fromkeys(primitive(r) for r in rows if any(r)))
        cache[bi]=rows;return rows
    def separate(x):
        additions=[];evidence=[];checked=0
        for bi in range(len(families)):
            for ri,row in enumerate(rows_at(bi)):
                checked+=1
                if row in seen:continue
                val=evaluate(row,x)
                if val<0:
                    seen.add(row);additions.append(row)
                    evidence.append({'family':bi,'row_index':ri,'value':str(val),'row':row})
                    if len(additions)>=batchsize:return additions,evidence,checked,False
        return additions,evidence,checked,True
    for iteration in range(iterations):
        print('ITERATION',iteration,'extra',len(extra),'cached_families',len(cache),flush=True)
        r=run_case({**case,'extra_rows':extra},mode='graph_pair')
        if not r.get('F'):
            log.append({'iteration':iteration,'selection_status':r['status']});break
        x=list(map(Fraction,r['mass_optimization']['parameters']))
        add,ev,checked,full=separate(x)
        rec={'iteration':iteration,'selection_status':r['status'],'mass':r['mass'],'integral':r['integral'],
             'mass_candidate_checked_rows':checked,'mass_candidate_full_scan':full,'added_rows':ev}
        print('MASS',r['mass'],'integral',r['integral'],'status',r['status'],'newcuts',len(add),'scanned',checked,flush=True)
        if not add and r.get('coordinate_failure'):
            y=list(map(Fraction,r['coordinate_failure']['optimization']['parameters']))
            add,ev,checked,full=separate(y)
            rec.update(coordinate_witness_checked_rows=checked,coordinate_witness_full_scan=full,coordinate_added_rows=ev)
            print('COORDINATE','newcuts',len(add),'scanned',checked,'full',full,flush=True)
        extra+=add;log.append(rec)
        output={'kind':kind,'B':B,'g':g,'d':C['d'],'families':families,'iterations':log,
                'extra_rows':extra,'cached_families':len(cache),'final':r,
                'final_status':'running' if add else r['status'],'fully_scanned_final':not add and full}
        atomic(outpath,output)
        if not add:return output
    return output


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');ap.add_argument('--kind',choices=['star','pair'],default='pair');args=ap.parse_args()
    c=json.loads(Path(args.input).read_text());completion(c,args.output,kind=args.kind)
