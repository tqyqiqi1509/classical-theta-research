# Literature and route log

All times UTC, 2026-11-13. This branch began at approximately 08:08.

## 08:08–08:18: inherited gaps and genuine single-pair creation caps

Read predecessor HANDOFF, PAIR_UPPER_CAPS, all relevant exact scripts, and
the root's ACYCLIC_CREATION_CAPS theorem. Broad skew-symmetric and valued
tests retained exact coefficient tradeoffs in three skew examples and an
integrality failure in the reverse hard fork. Adding pair lower positivity
repairs the three original orientations; the reverse fork remains a true
tradeoff even with positive single-pair cap remainders. This identifies
interaction between upper and lower decompositions as the active gap.

Auxiliary-star creation caps were tried on five hard inputs. All unit
partial-star variants gave no coefficient tightening. Root supplied a
Vandermonde dominance mechanism for new pairs; stop this route rather than
expanding auxiliary parameters.

## 08:20–08:28: graph allocation mechanism and substantive covariance test

The two-sided Pieri branch proposed genuine rank-two block capacity products.
Two-edge shared-vertex allocations repaired the reverse fork, including
all coordinates by exact conic certificates. Root and theory branch then
proved reduction to one factor per actual edge. Implemented full graph
allocation, direct support pruning and independent exact certificate audit.

Large cached sweeps were used only to expose general failures; three
connected rank4–6 hard-core extensions retained a 31-dimensional Laurent
space. Their first independent source mutation gives an exact rank-four
failure. Stopped the covariance sweep immediately and changed the mechanism
to positive product remainders, with every failure and exact witness saved.

## Literature refresh (search and primary-page verification, 08:23–08:27)

Queries covered higher-rank greedy bases, pair-product upper bounds, theta
Pieri rules, compatible pairs, tight gradings, and 2025–2026 publications.
Search dates were not treated as publication dates.

1. Lee–Li–Zelevinsky, *Greedy elements in rank 2 cluster algebras*,
   https://arxiv.org/abs/1208.2391 . The existing exact LLZ recurrence remains
   the only rank-two coefficient oracle. Original article is classical and
   matches the needed scope. No higher-rank conclusion is imported.
2. Burcroff–Lee, *Broken lines and compatible pairs for rank 2 quantum
   cluster algebras*, https://arxiv.org/abs/2404.14369 . Primary abstract
   checked. Its weighted bijection covers A2 and Kronecker, and a partial
   cluster-monomial result in arbitrary skew-symmetric rank two. It is not a
   higher-rank pure-combinatorial construction. Useful comparison/interface;
   no new theorem from it is used in the graph mechanism.
3. Burcroff–Lee–Mou, *Scattering diagrams, tight gradings, and generalized
   positivity*, https://arxiv.org/abs/2409.15235 and full HTML
   https://arxiv.org/html/2409.15235v1 . Primary text checked, including the
   announcement status and statement that full proofs are forthcoming.
   Tight gradings are finite Dyck-path objects, but the high-rank part passes
   through scattering diagrams. Therefore this is an interface for a future
   local coefficient packing rule, not an allowed replacement construction.
   The present work uses no generalized/quantum conclusion from it.
4. A search returned the 2026 Hexagon quantum rank-two title
   https://hexagonmath.org/2610.00029v3 and quantum all-valued title
   https://hexagonmath.org/2610.00201v1 . Neither was audited in this branch
   and neither is used. Their quantum scope does not supply the missing
   classical graph-cap gluing theorem. This is explicitly an unused lead.
5. Search returned Li–Pan 2201.01440. Excluded as an authority by the user's
   instruction. No conclusion, recurrence correctness, or positivity result
   is cited or used.
6. ALCO 10.5802/alco.141 primary PDF/article requests returned 403. Search
   snippet alone is insufficient for theorem use; no claim imported.

No 2026 assertion was accepted on search snippets or claimed AI review.

## 08:30 onward: positive graph remainders

Implemented exact finite separation for P_E-F star and pair positivity.
The rank-four two witnesses satisfy every 102465 star-remainder row, so
that variant is insufficient. Pair-remainder completion remains active.
The theory branch is independently examining complete capacity bisection
and one-step lowering/creation in a recursively constructed lower basis.

## 08:33–08:43: distinguish a wrong top from a wrong lower input

The complete pair remainder family also failed to remove either witness.
A provisional smaller-basis creation cut excluded both the mass minimum
and transported candidate. Exact prefix audits narrowed all uncertainty
to two smaller capacities. A genuine source pair condition corrected the
creator (21,6,9,2), changing the cut constant from33 to51. Thus the old cut
was not legitimate evidence against the transported top. A separate true
transported-pair inequality, opposite to the corrected creation row,
restores the transported candidate as the exact least target. The theory
branch subsequently obtained this same inequality from corrected lowering.
This records the correction explicitly so that provisional lower objects
are never silently promoted to theta factors.

At root's request the next mechanism is Cartan-fundamental normalization,
not more arbitrary local cuts. All currently known full-graph failures are
non-fundamental. Dedicated connected ranks4–6 and valued tests and actual
forward source/sink positivity probes are recorded separately.

## 08:44 literature refresh: fundamental regions and imaginary functions

Primary arXiv metadata and full HTML were opened for Reading–Stella,
*Theta functions in acyclic affine type*, arXiv:2603.23429v1 (submitted
2026-03-24), https://arxiv.org/html/2603.23429v1 . The author's publication
list independently confirms the title and year. The text is restricted to
acyclic affine type; it uses dominance regions, mutation symmetries and
scattering methods. Therefore it is a lead about reducing imaginary
functions by mutation, not a proof of graph-cap completeness in indefinite
Cartan type. No theorem from this 2026 paper has been imported here: full
proof audit of the relevant interface remains outstanding. The HTML title
block has an impossible displayed date, "February 52, 2026"; this is noted
as a typographical/formatting issue, not evidence of a mathematical error.

The search also returned Dupont's arXiv:0910.5494 on transverse quiver
Grassmannians and affine bases, and GLS arXiv:1001.3545 on Kac–Moody groups
and cluster algebras. These are unused leads for distinguishing generic
from theta/greedy multiplicities; neither supplies the requested pure
combinatorial construction or the missing indefinite fundamental theorem.

## 08:46 decisive fundamental counterexample and route correction

Unequal-capacity K4 completed: d=(4,5,5,6), all unit arrows in total order,
Cd=(-8,-5,-5,-2). All185220 allocations give81897 distinct products. Exact
integer minimum mass1829 and integer alternative mass2824 have coefficient
(3,2,2,1)6 versus2. Thus no integer least exists strictly inside the Cartan
fundamental region. Immediately stopped the sweep and marked that shortcut
false. Parent requested a fresh joint inventory/positive-resource exchange
branch, rather than repeating local graph upper families.
