#!/usr/bin/env python3
"""Optimizer-free exact audit of graph-selector covariance failure."""
from cap_batch import *


def run():
    case=json.loads((HERE/'graph_transport_extension_results.json').read_text())['results'][0]
    B,g,C=case['B'],case['g'],case['carrier'];n=len(g)
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*n]]
    caps,_=pair_upper_caps(B,g,C['d'],M['ids']);cb,fs,_=block_upper_caps(B,C['d'],M['ids'],graph=True)
    for p in caps:caps[p]=min(caps[p],cb[p])
    assert caps=={tuple(q['p']):q['a'] for q in case['caps']}
    upper=[tuple(caps[p]*a-b for a,b in zip(origin,R[i])) for p,i in M['ids'].items()]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])};pairs,_=section_rows(B,g,source)
    RR=list(dict.fromkeys(primitive(row) for row in R+upper+[r for key,r in pairs] if any(row)))
    assert len(RR)==case['constraint_rows']
    def point(opt,rawF):
        x=list(map(Fraction,opt['parameters']));F=exact_poly(rawF)
        assert evaluate(origin,x)==1 and all(evaluate(r,x)>=0 for r in RR)
        assert all(F.get(p,0)==evaluate(R[i],x) for p,i in M['ids'].items())
        assert all(a.denominator==1 for a in F.values())
        return x,F
    x,F=point(case['mass_optimization'],case['F']);counter=case['coordinate_failure']
    y,G=point(counter['optimization'],counter['other_F']);mass=sum(F.values())
    cost=tuple(sum(R[i][j] for i in M['ids'].values()) for j in range(S['dimension']))
    target=tuple(a-mass*b for a,b in zip(cost,origin));ans=[Fraction(0)]*S['dimension']
    for i,c in case['mass_optimization']['dual']:
        c=Fraction(c);assert c>=0
        for j,a in enumerate(RR[i]):ans[j]+=c*a
    assert tuple(ans)==target
    p=tuple(counter['p']);assert G[p]<F[p]
    oldcase=json.loads((HERE/'graph_transport_current_input.json').read_text())
    H=exact_poly(oldcase['F']);refs=coefficient_references(M,R);z=parameters(H,M,refs)
    assert all(evaluate(r,z)>=0 for r in RR) and sum(H.values())>mass
    result={'verified':True,'arithmetic':'exact integer/Fraction, no optimizer call',
            'B':B,'g':g,'d':C['d'],'capacity_allocations':len(fs),'points':len(C['lattice_points']),
            'dimension':S['dimension'],'inequality_rows':len(RR),'minimum_mass':str(mass),
            'minimum_mass_dual_terms':len(case['mass_optimization']['dual']),
            'minimum_mass_integral':True,'alternative_integral':True,'alternative_mass':str(sum(G.values())),
            'coordinate':p,'minimum_mass_point_coordinate':str(F[p]),'alternative_coordinate':str(G[p]),
            'transported_source_feasible':True,'transported_source_mass':str(sum(H.values())),
            'no_coordinatewise_least':True,
            'proof':'If a coordinatewise least L existed, L<=F. Since F minimizes the sum of all coefficients, sum(L)>=sum(F), forcing L=F. But the feasible G has G[p]<F[p], contradiction.'}
    atomic(HERE/'graph_covariance_counterexample_audit.json',result);print(json.dumps(result,indent=2))


if __name__=='__main__':run()
