#!/usr/bin/env python3
"""Exact symbolic smaller-candidate Pieri cut, explicitly conditional.

Unlike genuine graph-product rows, these use computed high-rank smaller
candidate polynomials.  They become theta-necessary only after the missing
inductive identification theorem; all dependencies retain their status.
"""
from cap_batch import *
sys.path.insert(0,str(WORK/'agent_two_sided_pieri'))
from graph_lower_probe import GraphCache


def symbolic_prefix(case,direction,root,kind='creation'):
    B,g,C=case['B'],case['g'],case['carrier'];d=C['d'];n=len(g)
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*n]];zero=(0,)*len(origin)
    cache=GraphCache(B,'graph_target_lower_cache');dependencies=set()
    points=sorted(product(*(range(a+1) for a in root)),key=lambda p:(sum(p),p))
    if kind=='creation':
        dd=tuple(d[j]-(j==direction) for j in range(n));H=cache.get(dd);dependencies.add(dd)
        P=dict(H)
        for p,a in H.items():
            q=tuple(p[j]+(j==direction) for j in range(n));P[q]=P.get(q,0)+a
        rem={p:tuple(P.get(p,0)*a-b for a,b in zip(origin,R[M['ids'][p]] if p in M['ids'] else zero)) for p in points}
        label=g
    else:
        rem={p:R[M['ids'][p]] if p in M['ids'] else zero for p in points}
        label=tuple(g[j]+(j==direction) for j in range(n))
    terms=[]
    for q in points:
        row=rem.pop(q,zero)
        if not any(row):continue
        h=tuple(label[k]+sum(B[k][j]*q[j] for j in range(n)) for k in range(n));dh=tuple(acyclic_dimension(B,h)[0])
        if not all(q[k]+dh[k]<=d[k] for k in range(n)) or sum(dh)>=sum(d):
            raise ArithmeticError(('outside strict lower span',q,dh,row))
        terms.append({'q':q,'capacity':dh,'row':[str(a) for a in row]})
        if q==root:
            # Clear denominators without changing sign.
            den=math.lcm(*(Fraction(a).denominator for a in row))
            rr=primitive(tuple(int(a*den) for a in row))
            deps=[{'d':u,'status':cache.records[u]['status'],'comparison_status':'candidate; not theta identification'} for u in sorted(dependencies)]
            return rr,{'kind':kind,'direction':direction,'root':root,'capacity':dh,'raw_row':[str(a) for a in row],
                       'integer_row':rr,'terms_before_and_at_root':terms,'dependencies':deps}
        H=cache.get(dh);dependencies.add(dh)
        if cache.records[dh]['status']!='exact_least':raise ArithmeticError(('lower candidate not least',dh,cache.records[dh]['status']))
        for p,a in H.items():
            if not any(p):continue
            s=tuple(q[k]+p[k] for k in range(n))
            if all(s[k]<=root[k] for k in range(n)):
                rem[s]=tuple(x-a*y for x,y in zip(rem.get(s,zero),row))
    return zero,{'kind':kind,'direction':direction,'root':root,'zero_row':True}


if __name__=='__main__':
    case=json.loads((HERE/'graph_transport_current_input.json').read_text())
    row,info=symbolic_prefix(case,1,(2,3,2,2))
    bad=json.loads((HERE/'graph_transport_extension_results.json').read_text())['results'][0]
    info['bad_mass_min_value']=str(evaluate(row,list(map(Fraction,bad['mass_optimization']['parameters']))))
    atomic(HERE/'pieri_creation_cut.json',info)
    print('CUT',info['bad_mass_min_value'],'dependencies',len(info.get('dependencies',[])),flush=True)
    r=run_case({**case,'extra_rows':[row]},mode='graph_pair')
    atomic(HERE/'graph_plus_one_creation_results.json',{'conditional_candidate_cut':info,'result':r})
    print('RESULT',r['status'],r.get('mass'),'integral',r.get('integral'),'equals_transport',r.get('old_candidate_equal'),flush=True)
