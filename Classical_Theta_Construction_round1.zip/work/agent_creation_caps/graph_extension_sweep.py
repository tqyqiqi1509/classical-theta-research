#!/usr/bin/env python3
"""Connected high-rank tests retaining a previously nontrivial capacity core."""
from graph_box_sweep import *


def inputs():
    cores=[{'B':[[0,0,3],[0,0,2],[-3,-2,0]],'d':[8,7,9],'D':[1,1,1]},
           {'B':[[0,9,4],[-3,0,0],[-2,0,0]],'d':[5,5,5],'D':[1,3,2]}]
    for ci,core in enumerate(cores):
        for n in [4,5,6]:
            D=core['D']+[1,2,3][:n-3] if ci else [1]*n
            B=[[core['B'][i][j] if i<3 and j<3 else 0 for j in range(n)] for i in range(n)]
            for j in range(3,n):
                i=0 if j==3 else j-1
                h=math.gcd(D[i],D[j]);B[i][j]=D[j]//h;B[j][i]=-D[i]//h
            d=core['d']+[2]*(n-3)
            g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n)]
            yield {'B':B,'g':g,'d':d,'D':D,'valued':bool(ci),'topology':'connected_hard_core_path'}


def main():
    results=[];tic=time.time()
    for ci,c in enumerate(inputs()):
        print('START',ci,'rank',len(c['g']),'valued',c['valued'],'d',c['d'],'allocations',graph_allocation_count(c['B'],c['d']),flush=True)
        try:
            points=list(product(*(range(a+1) for a in c['d'])))
            caps,fs,_=block_upper_caps(c['B'],c['d'],points,graph=True)
            P=[p for p in points if caps[p]]
            C={'kind':'graph_capacity_support','d':c['d'],'vertices':[],'lattice_points':P,
               'full_box_points':len(points),'zero_removed':len(points)-len(P)}
            print('SUPPORT',ci,len(P),'of',len(points),'families',len(fs),flush=True)
            source={**c,'carrier':C,'precomputed_graph_caps':[{'p':p,'a':caps[p]} for p in P],
                    'precomputed_graph_families':fs}
            atomic(HERE/f'graph_extension_input_{ci}.json',source)
            r=run_case(source,mode='graph_pair');r['source_case']=c
        except Exception as e:r={**c,'status':'unresolved_exception','reason':repr(e)}
        r['source_index']=ci;results.append(r)
        atomic(HERE/'graph_extension_sweep_results.json',{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'dim',r.get('space',{}).get('dimension'),'mass',r.get('mass'),'reason',r.get('reason'),flush=True)


if __name__=='__main__':main()
