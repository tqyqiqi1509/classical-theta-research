#!/usr/bin/env python3
"""Cartan-fundamental generic mechanism stress tests, no Newton carrier."""
from graph_box_sweep import *


def inputs():
    specs=[(4,'complete',1,[4]*4),(4,'cycle',2,[6]*4),
           (5,'cycle',2,[4]*5),(6,'cycle',2,[3]*6),
           (6,'bipartite',1,[2]*6),(5,'bipartite',1,[3]*5)]
    for n,typ,w,d in specs:
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                edge=typ=='complete' or (typ=='cycle' and (j==i+1 or (i==0 and j==n-1))) or (typ=='bipartite' and i<n//2<=j)
                B[i][j]=w if edge else 0;B[j][i]=-B[i][j]
        C=[2*d[i]-sum(abs(B[i][j])*d[j] for j in range(n)) for i in range(n)]
        assert max(C)<=0
        g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n)]
        yield {'B':B,'g':g,'d':d,'D':[1]*n,'Cartan_d':C,'topology':typ,'weight':w,'fundamental':True}
    for d,D,typ in [([4,5,5,6],[1]*4,'unequal_complete'),([3,5,4,5],[1]*4,'mixed_complete'),
                    ([4]*4,[1,2,3,2],'valued_complete'),([5,4,5,4],[1,2,1,2],'valued_cycle')]:
        n=4;B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                edge=typ!='valued_cycle' or j==i+1 or (i==0 and j==3)
                w=(2 if typ=='mixed_complete' and (i,j)==(0,1) else 1) if edge else 0
                h=math.gcd(D[i],D[j]);B[i][j]=w*D[j]//h;B[j][i]=-w*D[i]//h
        C=[2*d[i]-sum(abs(B[i][j])*d[j] for j in range(n)) for i in range(n)];assert max(C)<=0
        g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n)]
        yield {'B':B,'g':g,'d':d,'D':D,'Cartan_d':C,'topology':typ,'fundamental':True}


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=100);args=ap.parse_args()
    results=[]
    for ci,c in enumerate(list(inputs())[args.start:args.stop],args.start):
        print('START',ci,'rank',len(c['g']),'d',c['d'],'Cartan',c['Cartan_d'],'allocations',graph_allocation_count(c['B'],c['d']),flush=True)
        try:
            points=list(product(*(range(a+1) for a in c['d'])))
            caps,fs,_=block_upper_caps(c['B'],c['d'],points,graph=True)
            P=[p for p in points if caps[p]]
            C={'kind':'graph_capacity_support','d':c['d'],'vertices':[],'lattice_points':P,'full_box_points':len(points)}
            print('SUPPORT',ci,len(P),'families',len(fs),flush=True)
            source={**c,'carrier':C,'precomputed_graph_caps':[{'p':p,'a':caps[p]} for p in P],'precomputed_graph_families':fs}
            atomic(HERE/f'fundamental_input_{ci}.json',source)
            r=run_case(source,mode='graph_pair');r['Cartan_d']=c['Cartan_d'];r['fundamental']=True
        except Exception as e:r={**c,'status':'unresolved_exception','reason':repr(e)}
        r['source_index']=ci;results.append(r);atomic(HERE/f'fundamental_results_{args.start}_{args.stop}.json',{'results':results})
        print('END',ci,r['status'],'dimension',r.get('space',{}).get('dimension'),'mass',r.get('mass'),'reason',r.get('reason'),flush=True)
        if r.get('coordinate_failure'):
            print('FUNDAMENTAL_FAILURE',r['coordinate_failure']['p'],r['coordinate_failure']['F_value'],r['coordinate_failure']['lower_value'],flush=True);break
