#!/usr/bin/env python3
"""Extract exact violated transported pair rows at the graph-cap counterexample."""
from cap_batch import *


if __name__=='__main__':
    case=json.loads((HERE/'graph_transport_current_input.json').read_text())
    bad=json.loads((HERE/'graph_transport_extension_results.json').read_text())['results'][0]
    B,g,C=case['B'],case['g'],case['carrier'];M,R,S=build_logic(B,g,C)[:3]
    origin=R[M['ids'][(0,)*len(g)]];source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    state,err=mutate_rows(B,g,source,0,cap=200000);assert not err
    BB,gg,T=state;rows,_=section_rows(BB,gg,T)
    xx=list(map(Fraction,bad['mass_optimization']['parameters']))
    yy=list(map(Fraction,bad['coordinate_failure']['optimization']['parameters']))
    caps,_,_=block_upper_caps(BB,acyclic_dimension(BB,gg)[0],T,graph=True)
    violations=[];cutrows=[]
    for key,row in rows:
        row=primitive(row);a,b=evaluate(row,xx),evaluate(row,yy)
        if min(a,b)<0:
            violations.append({'kind':'transported_pair_lower','key':key,'row':row,'massmin_value':str(a),'other_value':str(b)})
            cutrows.append(row)
    for p,row in T.items():
        rr=primitive(tuple(caps[p]*a-b for a,b in zip(origin,row)));a,b=evaluate(rr,xx),evaluate(rr,yy)
        if min(a,b)<0:
            violations.append({'kind':'transported_graph_upper','p':p,'row':rr,'massmin_value':str(a),'other_value':str(b)})
            cutrows.append(rr)
    atomic(HERE/'minimal_neighbor_violations.json',{'B':B,'g':g,'direction':0,'violations':violations})
    print('VIOLATIONS',[(x['kind'],x.get('key',x.get('p')),x['massmin_value'],x['other_value'])for x in violations],flush=True)
    cutrows=list(dict.fromkeys(cutrows))
    r=run_case({**case,'extra_rows':cutrows},mode='graph_pair')
    atomic(HERE/'minimal_neighbor_repair_results.json',{'cuts':violations,'result':r})
    print('RESULT',len(cutrows),r['status'],r.get('mass'),r.get('old_candidate_equal'),r.get('integral'),flush=True)
