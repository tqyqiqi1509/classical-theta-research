#!/usr/bin/env python3
"""Compare pure graph selectors across genuine source/sink mutation maps."""
from graph_box_sweep import *


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');ap.add_argument('--start',type=int,default=0);ap.add_argument('--stop',type=int,default=1000);args=ap.parse_args()
    raw=json.loads(Path(args.input).read_text());cases=raw['results'] if isinstance(raw,dict) else raw
    results=[];count=0
    for ci,c in enumerate(cases[args.start:args.stop],args.start):
        B,g=c['B'],c['g'];F=exact_poly(c['F'])
        for k in range(len(g)):
            if not (all(a>=0 for a in B[k]) or all(a<=0 for a in B[k])):continue
            print('START',ci,'direction',k,'rank',len(g),flush=True)
            try:
                state,err=mutate_rows(B,g,{p:(int(a),) for p,a in F.items()},k,cap=200000)
                if err:raise OverflowError(('transport',err))
                BB,gg,T=state;FF={p:row[0] for p,row in T.items()};dd,v,order=acyclic_dimension(BB,gg)
                points=list(product(*(range(a+1) for a in dd)))
                cap,fs,_=block_upper_caps(BB,dd,points,graph=True)
                P=[p for p in points if cap[p]]
                C={'kind':'graph_capacity_support','d':dd,'vertices':[],'lattice_points':P,
                   'full_box_points':len(points),'zero_removed':len(points)-len(P)}
                print('SUPPORT',ci,k,len(P),'box',len(points),'families',len(fs),'target_d',dd,flush=True)
                source={'B':BB,'g':gg,'d':dd,'D':c.get('D'),'carrier':C,'F':dump_poly(FF),
                        'precomputed_graph_caps':[{'p':p,'a':cap[p]} for p in P],'precomputed_graph_families':fs}
                atomic(HERE/'graph_transport_current_input.json',source)
                r=run_case(source,mode='graph_pair')
                r['transport_source']={'case':ci,'direction':k,'B':B,'g':g,'F':c['F']}
            except Exception as e:r={'B':B,'g':g,'direction':k,'status':'unresolved_exception','reason':repr(e)}
            r['source_index']=count;count+=1;results.append(r);atomic(args.output,{'results':results})
            print('END',ci,k,r['status'],'dim',r.get('space',{}).get('dimension'),'mass',r.get('mass'),'equal',r.get('old_candidate_equal'),'reason',r.get('reason'),flush=True)
            if r.get('coordinate_failure') or r.get('old_candidate_equal') is False:
                print('EXACT FAILURE; STOP',flush=True);raise SystemExit(0)
