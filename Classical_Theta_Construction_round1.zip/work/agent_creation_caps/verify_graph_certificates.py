#!/usr/bin/env python3
"""Rebuild every graph-bound row and verify all displayed LP certificates over Q.

No optimizer is called.  This is independent of the optimizer's selected
support and feasibility tolerances, though it shares the exact LLZ and
Laurent-divisibility integer routines.
"""
from cap_batch import *


def verify(case):
    B,g,C=case['B'],case['g'],case['carrier'];n=len(g)
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*n]]
    caps,_=pair_upper_caps(B,g,C['d'],M['ids'])
    cb,_,_=block_upper_caps(B,C['d'],M['ids'],graph=case['mode']=='graph_pair')
    for p in caps:
        if cb[p] is not None:caps[p]=min(caps[p],cb[p])
    assert caps=={tuple(a['p']):a['a'] for a in case['caps']}
    upper=[tuple(caps[p]*x-y for x,y in zip(origin,R[i])) for p,i in M['ids'].items()]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    pairs,_=section_rows(B,g,source)
    RR=list(dict.fromkeys(primitive(r) for r in R+upper+[r for key,r in pairs] if any(r)))
    assert len(RR)==case['constraint_rows']
    F=exact_poly(case['F']);xx=list(map(Fraction,case['mass_optimization']['parameters']))
    assert evaluate(origin,xx)==1
    assert all(evaluate(row,xx)>=0 for row in RR)
    assert all(evaluate(R[i],xx)==F.get(p,0) for p,i in M['ids'].items())
    assert all(a.denominator==1 for a in F.values())
    count=0
    def combination(entries):
        ans=[Fraction(0)]*S['dimension']
        for i,c in entries:
            a=Fraction(c);assert a>=0
            for j,b in enumerate(RR[i]):ans[j]+=a*b
        return tuple(ans)
    mass=sum(F.values());cost=tuple(sum(R[i][j] for i in M['ids'].values()) for j in range(S['dimension']))
    if case['mass_optimization'].get('dual') is not None:
        assert combination(case['mass_optimization']['dual'])==tuple(a-mass*b for a,b in zip(cost,origin));count+=1
    proven=set()
    for cert in case['coordinate_proofs']:
        p=tuple(cert['p']);a=Fraction(cert['value']);assert a==F[p]
        assert combination(cert['combination'])==tuple(u-a*v for u,v in zip(R[M['ids'][p]],origin))
        proven.add(p);count+=1
    assert proven==set(F)
    assert not case['unresolved'] and not case['coordinate_failure']
    return {'source_index':case.get('source_index'),'rank':n,'mode':case['mode'],'support':len(F),
            'integer':True,'row_count':len(RR),'exact_certificates':count,'mass':str(mass)}


if __name__=='__main__':
    ar=argparse.ArgumentParser();ar.add_argument('input');ar.add_argument('output');args=ar.parse_args()
    result=[]
    for c in json.loads(Path(args.input).read_text())['results']:
        if c['status']!='exact_least':continue
        r=verify(c);result.append(r);print(r,flush=True)
        atomic(args.output,{'verified':result,'arithmetic':'exact integers and fractions; no LP solver called'})
