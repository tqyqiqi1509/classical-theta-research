#!/usr/bin/env python3
"""Try exact uniqueness of genuine graph constraints for smaller candidates.

A unique feasible normalized point is genuinely theta, since graph and pair
constraints are theta-necessary.  A least point alone does not imply this.
"""
from cap_batch import *


def certify(c):
    M,R,S=build_logic(c['B'],c['g'],c['carrier'])[:3];origin=R[M['ids'][(0,)*len(c['g'])]]
    if S['dimension']==1:return {'d':c['d'],'status':'unique_Laurent_point','dimension':1}
    caps={tuple(q['p']):q['a'] for q in c['caps']}
    upper=[tuple(caps[p]*a-b for a,b in zip(origin,R[i])) for p,i in M['ids'].items()]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])};rows,_=section_rows(c['B'],c['g'],source)
    RR=list(dict.fromkeys(primitive(row) for row in R+upper+[r for key,r in rows] if any(row)))
    F=exact_poly(c['F']);mass=sum(F.values());cost=tuple(sum(R[i][j] for i in M['ids'].values()) for j in range(S['dimension']))
    target=tuple(mass*a-b for a,b in zip(origin,cost));cp=exact_conic_scaled(target,RR)
    if cp is not None:
        return {'d':c['d'],'status':'unique_feasible_graph_point','dimension':S['dimension'],'maximum_mass':str(mass),'dual':[[i,str(a)]for i,a in cp]}
    opt=propose_optimum(tuple(-a for a in cost),RR,origin)
    return {'d':c['d'],'status':'not_certified_unique','dimension':S['dimension'],'least_mass':str(mass),
            'negative_maximum_mass_optimization':opt}


if __name__=='__main__':
    dep=json.loads((HERE/'pieri_creation_cut.json').read_text())['dependencies'];results=[]
    for q in dep:
        file=WORK/'agent_two_sided_pieri'/'graph_target_lower_cache'/('d_'+'_'.join(map(str,q['d']))+'.json')
        c=json.loads(file.read_text());r=certify(c);results.append(r)
        atomic(HERE/'pieri_lower_uniqueness_results.json',{'results':results})
        print(r['d'],r['status'],r['dimension'],r.get('negative_maximum_mass_optimization',{}).get('value'),flush=True)
