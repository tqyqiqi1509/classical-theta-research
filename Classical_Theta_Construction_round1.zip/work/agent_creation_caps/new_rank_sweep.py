#!/usr/bin/env python3
from cap_batch import *
import random
from theta_newton_pruning import prune


def inputs():
    rng=random.Random(808184561)
    for valued in [False,True]:
        for n,reps in [(5,6),(6,12)]:
            for rep in range(reps):
                D=[rng.choice([1,2,3]) for _ in range(n)] if valued else [1]*n
                if valued and len(set(D))==1:D[-1]=2 if D[0]!=2 else 1
                B=[[0]*n for _ in range(n)]
                for i in range(n):
                    for j in range(i+1,n):
                        if rep%3==0:w=rng.choice([1,2]) if j==i+1 or (i==0 and j==n-1) else 0
                        elif rep%3==1:w=rng.choice([1,2]) if i<n//2<=j else 0
                        else:w=rng.choice([0,1,1,2])
                        gg=math.gcd(D[i],D[j]);B[i][j]=w*D[j]//gg;B[j][i]=-w*D[i]//gg
                d=[rng.choice([1,2,2,3]) for _ in range(n)]
                while math.prod(x+1 for x in d)>2500:d[d.index(max(d))]-=1
                g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n)]
                # Permute the acyclic orientation labels; no assumption that
                # topological order equals the numerical vertex order.
                perm=list(range(n));rng.shuffle(perm)
                B=[[B[i][j] for j in perm] for i in perm]
                g=[g[i] for i in perm];d=[d[i] for i in perm];D=[D[i] for i in perm]
                assert all(D[i]*B[i][j]==-D[j]*B[j][i] for i in range(n) for j in range(n))
                yield {'B':B,'g':g,'d':d,'D':D,'valued':valued,'rep':rep}


def main():
    folder=HERE/'rank_sweep_carriers';folder.mkdir(exist_ok=True)
    results=[];tic=time.time()
    for ci,c in enumerate(inputs()):
        print('START',ci,'rank',len(c['g']),'valued',c['valued'],'d',c['d'],flush=True)
        try:
            path=folder/f'carrier_{ci:03d}.json'
            if path.exists():C=json.loads(path.read_text())
            else:C=prune(c['B'],c['g'],cap=3000);atomic(path,C)
            case={**c,'carrier':C};r=run_case(case)
            r['source_case']=c
        except Exception as e:r={**c,'status':'unresolved_exception','reason':repr(e)}
        r['source_index']=ci;results.append(r)
        atomic(HERE/'new_rank_caps_results.json',{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'dim',r.get('space',{}).get('dimension'),'mass',r.get('mass'),flush=True)


if __name__=='__main__':main()
