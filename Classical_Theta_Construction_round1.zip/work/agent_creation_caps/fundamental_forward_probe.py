#!/usr/bin/env python3
"""Genuine necessary forward checks on Cartan-fundamental graph candidates."""
from cap_batch import *


if __name__=='__main__':
    cases=[]
    for file in sorted(HERE.glob('fundamental_results_*.json')):
        cases+=json.loads(file.read_text())['results']
    results=[]
    for c in sorted(cases,key=lambda c:c['source_index']):
        if c['status']!='exact_least':continue
        B,g=c['B'],c['g'];F=exact_poly(c['F'])
        for k in range(len(g)):
            if not (all(a>=0 for a in B[k]) or all(a<=0 for a in B[k])):continue
            print('START',c['source_index'],'direction',k,flush=True)
            st,err=mutate_rows(B,g,{p:(int(a),) for p,a in F.items()},k,cap=200000);assert not err
            BB,gg,T=st;rows,_=section_rows(BB,gg,T)
            bad=[{'key':key,'coefficient':str(row[0])}for key,row in rows if row[0]<0]
            dd,_,_=acyclic_dimension(BB,gg);caps,_=pair_upper_caps(BB,gg,dd,T)
            capbad=[{'p':p,'value':str(row[0]),'upper':caps[p]}for p,row in T.items()if row[0]>caps[p]]
            r={'source_index':c['source_index'],'B':B,'g':g,'d':c['d'],'Cartan_d':c['Cartan_d'],'direction':k,
               'target_B':BB,'target_g':gg,'target_d':dd,'pair_rows':len(rows),'pair_failures':bad,
               'cap_failures':capbad,'transport_coefficients_positive':all(row[0]>=0 for row in T.values()),
               'status':'necessary_checks_pass' if not bad and not capbad else 'fundamental_candidate_counterexample'}
            results.append(r);atomic(HERE/'fundamental_forward_probe_results.json',{'results':results})
            print('END',c['source_index'],k,r['status'],'pairbad',len(bad),'capbad',len(capbad),flush=True)
            if bad or capbad:
                atomic(HERE/'fundamental_forward_failure.json',{'source':c,'result':r,'target_F':dump_poly({p:row[0] for p,row in T.items()})})
                raise SystemExit(0)
