# Creation-cap branch handoff

**08:47 decisive update: the fundamental shortcut is FALSE. Read the concise
`HANDOFF_NEXT.md` first. Input6 completed with an exact integer no-least
counterexample even though every Cartan coordinate is strictly negative.
The large fundamental job stopped automatically; do not resume its sweep.**

Owner `/root/creation_cap_completion`, started about08:08 UTC; refreshed near
08:48 on2026-11-13. Parent endpoint10:12:08. All data in this directory.

## Current main mechanism and scope

The genuine theorem is **rank-two block graph capacity upper bounds**:
for d=sum e with each e supported on at most2 vertices, multiply genuine
LLZ F-polynomials at the canonical acyclic labels. This product contains
theta_d with coefficient1 and theta-positive remainder. No higher-rank
candidate is used. Merge equal-edge blocks and absorb singletons to reduce
to one block per actual edge. Each vertex distributes all d_i among its
incident edges; isolated vertices give binomials. Exact finite count before
duplicate removal is product_i binom(d_i+deg_i-1,deg_i-1).

`block_upper_caps.py` implements this using exact integer LLZ recurrences
and convolution. Full graph caps give U(p); support U(p)>0 can be computed
directly from the standard box and used as a pure combinatorial finite
carrier. This replaces Newton pruning in all newer experiments.

Candidate: on that finite carrier impose initial-star Laurent equations,
star quotient positivity, all initial LLZ pair-slice positivity and graph
coefficient upper bounds, then ask for coefficientwise least. Exact least
is proved by rational conic certificates for every positive coefficient.
**This rule is false as a seed-independent/general selector.** Genuine
upper bounds survive; the general completeness claim does not.

## Most important exact counterexample and its repair

Fundamental source:

    B=[[0,0,3,1],[0,0,2,0],[-3,-2,0,0],[-1,0,0,0]]
    g=(-8,-7,29,6), d=(8,7,9,2)

Pure graph selector exact least mass145740, space dimension31.

After source mutation0:

    B'=[[0,0,-3,-1],[0,0,2,0],[3,-2,0,0],[1,0,0,0]]
    g'=(8,-7,5,-2), d'=(21,7,9,2)

759 support points,43 parameters,220 distinct graph products,761 inequalities.
Transported source candidate is feasible integer mass15151380. Target
graph selector has integer exact minimum mass15151164 but no least:
another integer feasible G of mass15151332 lowers a_(2,6,2,2)219→216.
Exact mass dual has41 terms. Independent no-optimizer verifier:

* `verify_graph_counterexample.py`
* `graph_covariance_counterexample_audit.json`
* full data `graph_transport_extension_results.json`
* target standalone input `graph_transport_current_input.json`

Both witnesses pass **all102465 graph-product star-remainder rows** and
**all112142 graph-product star+pair-remainder rows**. Therefore that larger
genuine family is also insufficient. Do not repeat this expansion.

There is a simple genuine missing condition: mutate0 and take pair(1,2),
outside coordinates(0,3)=(6,2), greedy root(3,2), label(-3,5). It is

    a_(5,6,3,2) - a_(8,6,4,2) - 51 >= 0.

It evaluates -9/-12 on the two witnesses and0 on transported source.
Adding **this single row** restores an exact integral coefficientwise least
point of mass15151380, exactly the actual source transport.

* `minimal_neighbor_violations.json`
* `minimal_neighbor_repair_results.json`
* general implementation `cap_batch.run_case(...,mode='graph_neighbor_pair')`
  with `case['neighbor_directions']=[0]`.

## Crucial correction to a provisional Pieri test

The other branch originally got creation1 row
`a_(8,6,4,2)-a_(5,6,3,2)+33>=0`. It used smaller graph candidates as if they
were correct, and excluded both the target mass minimum and source transport.
Adding it gives exact least15155092, but this is an **obsolete conditional
experiment**, not a theta-necessary cut. Do not present it as a repair.

The creator capacity(21,6,9,2) itself failed genuine neighbor pair positivity.
Our neighbor repair changes its mass14900652→14900868 by adding

    18 z^(2,3,2,2) ((1+z1)^2+z1^2 z2 (1+z0)^3).

File `creator_neighbor_repair_results.json`. This corrects33→51, so the
corrected creation row is the **opposite** of the genuine neighbor row above.

Of the13 smaller capacities used in that108-point symbolic prefix,11 have
all actually used coefficients uniquely forced by genuine graph constraints;
full-polynomial uniqueness was not needed. The two remaining locally free
capacities are(18,5,7,2) and(21,6,9,2). The former stays unchanged under the
same neighbor repair (mass1445424). Exact prefix certificates:
`pieri_prefix_certification_results.json`.

The other branch also repaired creator3 capacity(21,7,9,1), whose original
graph cone had no least, to mass10090920; see its own file
`work/agent_two_sided_pieri/creator3_neighbor_repair_results.json`.
After those two corrections, its symbolic lowering3 row is EXACTLY the
genuine neighbor row above. Transport passes all8 lowering/creation tests;
the old mass minimum fails just lowering3. Its final files:
`graph_target_lowering3_symbolic.json`, `graph_target_two_corrected_*_pieri.json`.

The general interface emerging there is the finite positive inventory
identity b_j+M_j c_i=a_ij, coming from x_j theta_d+x_j(P_i-theta_d)=x_jP_i.
Zero inventory makes opposite upper/lower inequalities into an equality.
This is stronger structural information than isolated extra cuts.

## Parent's newest priority: Cartan fundamental capacities

Parent asked near08:41 to check whether graph selection should be made only
at capacities satisfying Cd<=0, C_ii2,C_ij=-|B_ij|, and transported elsewhere.
All known **full graph+pair** failures are non-fundamental:

* target(21,7,9,2): (Cd)_0=13;
* creator(21,6,9,2): (Cd)_0=13;
* creator3(21,7,9,1): (Cd)_0=14.

Do not confuse old fundamental failures of **single-pair** caps with full
graph failures: those three rank3 cases were repaired by full graph+pair.
The source(8,7,9,2) is fundamental.

`fundamental_sweep.py` tests this using full graph support, no Newton input.
Completed inputs0–5 and8–9 all exact integral least, including:

* K4 unit edges d4:50625 allocations,17419 distinct products,dim16,mass307;
* doubled4-cycle d6:2401 allocations,dim14,mass958;
* K3,3 unit edges rank6 d2:46656 allocations,dim17,mass193;
* K2,3 rank5 d3:6400 allocations,dim8,mass1193;
* valued4-cycle D=(1,2,1,2),d=(5,4,5,4):dim32,mass703.

Their23 actual source/sink forward transports all pass full pair-slice
positivity and genuine single-pair creation caps. This checks identification
more strongly than merely finding a least point, but is not universal
positivity or theta identification. See `fundamental_forward_probe_results.json`.

Input6 (unequal K4 capacities4,5,5,6) is the large running test:185220 complete
allocations. Input7 mixed K4 follows it. Check `fundamental_6_8.log` and
`fundamental_results_6_8.json`. If a failure appears, alert root immediately.
Once those finish, rerun `fundamental_forward_probe.py` to include them;
the existing output currently covers only0–5,8–9.

## Other useful breadth, with appropriate caution

* 43 cached skew rank3–5: two-edge block subfamily+pairlower all exactleast.
* 45 cached valued rank3–5: full graph+pair on pure graph support all exactleast.
* 18 new ranks4–6 full graph tests all exactleast, mostlydim1 (limited stress).
* Connected hard-core extensions ranks4/5/6 have graph support520/993/1615,
  dimension31 each, exactleast masses145740/271421/436128. First source
  mutation gave the counterexample above. This sweep stopped immediately.
* 5 hard rank3 inputs all pass pure graph support selector; graph support can
  contain points outside the proved Newton carrier. Output
  `failure_pure_graph_results.json` records exact outside/removed counts.

## Code entry points

`cap_batch.py`:

    run_case(case, mode='graph_pair')

case needs B,g,carrier{d,lattice_points}; optional F is only a proposed
candidate. `precomputed_graph_caps` plus `precomputed_graph_families` avoids
convolving twice. Optional `extra_rows` are integer linear rows in the exact
`build_logic` parameterization; callers must state whether they are genuine
or conditional. `graph_neighbor_pair` adds genuine source/sink graph caps
and pair lower constraints, optionally restricted by `neighbor_directions`.

Exact feasibility/conic rows are in `pair_upper_caps.py` and inherited
`critical_overlap_covariance.py`. `propose_optimum` may return unresolved
on conditioning failure; unresolved is never evidence for either outcome.

## Running processes at handoff

My shell session IDs are not necessarily usable by a fresh agent, but all
processes checkpoint shared files. Do not re-launch their jobs blindly.

* session90236: `fundamental_sweep.py --start6 --stop8`, currentlylargeinput6.
* session5114: old `new_rank_sweep.py`, Newton-pruning sweep, now aroundinput8;
  not a priority, do not expand it. Its slow convex-hull certificates explain
  the switch to graph support. All later tests avoid this.

All other branch jobs listed in logs completed by08:45. There is no need to
repeat weak auxiliary-star caps or graph product pair-remainder enumeration.

`GRAPH_CAPACITY_SELECTOR.md` gives the evolving mathematics, and
`LITERATURE_AND_ROUTE_LOG.md` records literature refreshes and rejected uses,
including the unimported2026 Reading–Stella affine paper.
