#!/usr/bin/env python3
"""Full graph allocation tests using only finite integer support pruning.

Support is the intersection of supports of rank<=2 block products.  This
does not call Newton polytopes, representations or an unidentified basis.
"""
from cap_batch import *
from block_upper_caps import graph_allocation_count
import random


def cases():
    rng=random.Random(202611130830)
    for valued in [False,True]:
        for n in [4,5,6]:
            for topology in ['cycle','fork','dense']:
                D=[rng.choice([1,2,3]) for _ in range(n)] if valued else [1]*n
                if valued and len(set(D))==1:D[0]=2 if D[0]!=2 else 1
                B=[[0]*n for _ in range(n)]
                for i in range(n):
                    for j in range(i+1,n):
                        edge=(j==i+1 or (i==0 and j==n-1)) if topology=='cycle' else ((i==0 or j==n-1) if topology=='fork' else (j-i<=2 or (i==0 and j==n-1)))
                        w=rng.choice([1,2,3]) if edge else 0
                        h=math.gcd(D[i],D[j]);B[i][j]=w*D[j]//h;B[j][i]=-w*D[i]//h
                d=[rng.choice([2,3,4]) if n==4 else rng.choice([1,2,3]) for _ in range(n)]
                while graph_allocation_count(B,d)>20000 or math.prod(x+1 for x in d)>1800:
                    k=max(range(n),key=lambda i:(sum(bool(x) for x in B[i]),d[i]) if d[i]>1 else (-1,-1))
                    if d[k]<=1:raise RuntimeError('cannot reduce allocation budget')
                    d[k]-=1
                g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n)]
                perm=list(range(n));rng.shuffle(perm)
                yield {'B':[[B[i][j] for j in perm] for i in perm],'g':[g[i] for i in perm],
                       'd':[d[i] for i in perm],'D':[D[i] for i in perm],'valued':valued,'topology':topology}


def main():
    results=[];tic=time.time()
    for ci,c in enumerate(cases()):
        print('START',ci,'rank',len(c['g']),'valued',c['valued'],'d',c['d'],'allocations',graph_allocation_count(c['B'],c['d']),flush=True)
        try:
            points=list(product(*(range(a+1) for a in c['d'])))
            caps,fs,_=block_upper_caps(c['B'],c['d'],points,graph=True)
            P=[p for p in points if caps[p]]
            C={'kind':'graph_capacity_support','d':c['d'],'vertices':[],'lattice_points':P,
               'full_box_points':len(points),'zero_removed':len(points)-len(P)}
            print('SUPPORT',ci,len(P),'of',len(points),'families',len(fs),flush=True)
            source={**c,'carrier':C,'precomputed_graph_caps':[{'p':p,'a':caps[p]} for p in P],
                    'precomputed_graph_families':fs}
            r=run_case(source,mode='graph_pair');r['source_case']=c
        except Exception as e:r={**c,'status':'unresolved_exception','reason':repr(e)}
        r['source_index']=ci;results.append(r)
        atomic(HERE/'graph_box_sweep_results.json',{'seconds':time.time()-tic,'results':results})
        print('END',ci,r['status'],'dim',r.get('space',{}).get('dimension'),'mass',r.get('mass'),'reason',r.get('reason'),flush=True)


if __name__=='__main__':main()
