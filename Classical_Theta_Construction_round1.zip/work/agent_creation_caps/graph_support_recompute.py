#!/usr/bin/env python3
"""Remove the Newton-carrier hypothesis from graph-cap selection experiments."""
from graph_box_sweep import *


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('input');parser.add_argument('output');args=parser.parse_args()
    raw=json.loads(Path(args.input).read_text());cases=raw['results'] if isinstance(raw,dict) else raw
    results=[]
    for ci,c in enumerate(cases):
        print('START',ci,'rank',len(c['g']),'d',c['d'],flush=True)
        try:
            points=list(product(*(range(a+1) for a in c['d'])))
            caps,fs,_=block_upper_caps(c['B'],c['d'],points,graph=True)
            P=[p for p in points if caps[p]]
            oldC=c.get('carrier') or {'lattice_points':c['points']}
            oldset=set(map(tuple,oldC['lattice_points']));newset=set(P)
            compare={'graph_positive_support_points':len(P),'newton_lattice_points':len(oldset),
                     'graph_points_outside_newton':len(newset-oldset),'newton_points_graph_forces_zero':len(oldset-newset),
                     'outside_points':sorted(newset-oldset),'forced_zero_points':sorted(oldset-newset)}
            C={'kind':'graph_capacity_support','d':c['d'],'vertices':[],'lattice_points':P,
               'full_box_points':len(points),'zero_removed':len(points)-len(P)}
            print('SUPPORT',ci,len(P),'outsideNewton',compare['graph_points_outside_newton'],'zeroNewton',compare['newton_points_graph_forces_zero'],flush=True)
            source={**c,'carrier':C,'precomputed_graph_caps':[{'p':p,'a':caps[p]} for p in P],
                    'precomputed_graph_families':fs}
            r=run_case(source,mode='graph_pair');r['support_comparison']=compare
        except Exception as e:r={**c,'status':'unresolved_exception','reason':repr(e)}
        r['source_index']=ci;results.append(r);atomic(args.output,{'results':results})
        print('END',ci,r['status'],'dim',r.get('space',{}).get('dimension'),'mass',r.get('mass'),'reason',r.get('reason'),flush=True)
