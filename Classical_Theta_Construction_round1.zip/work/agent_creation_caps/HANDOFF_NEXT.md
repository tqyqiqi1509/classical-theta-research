# Fresh branch handoff —08:47 UTC

Next target assigned by root: a **general joint inventory / positive-resource
exchange mechanism**. Do not repeat local graph upper variants or revive
fundamental normalization. Root endpoint10:12:08.

## Valid theorem retained

For acyclic classical skew-symmetrizable B, A=[-B]_+, g(d)=-d+Ad. If
d=sum e^(a), each supported on at most2 vertices, the product of genuine
LLZ F-polynomials L_e contains theta_d with coefficient1 and theta-positive
remainder. Same-edge factors merge and singleton capacity is absorbed by
incident edges. Thus each vertex distributes d_i among its incident edges,
with one genuine LLZ factor per edge. Count before duplicates:
product_i binom(d_i+deg_i-1,deg_i-1).

Coefficient minima give U(p); U(p)>0 contains true theta support. This is a
finite pure graph carrier, with no Newton geometry. The candidate adds
star Laurent equations/quotient positivity and initial LLZ pair positivity,
then asks for a coefficientwise least point. That candidate is incomplete.

## Definitive strictly fundamental counterexample

    B=[[0,1,1,1],[-1,0,1,1],[-1,-1,0,1],[-1,-1,-1,0]]
    d=(4,5,5,6), g=(-4,-1,4,8), Cd=(-8,-5,-5,-2).

All185220 allocations completed;81897 distinct products;173 support points;
47 parameters;215 inequalities. Integer F has exact minimum mass1829 with
a45-term rational dual. Integer G has mass2824 and coefficient(3,2,2,1)=2
instead of F's6. Therefore no least exists even in the integer feasible set.

* `fundamental_input_6.json`: standalone input, exact caps cached; reuse it
  instead of repeating the several-minute185220-allocation computation.
* `fundamental_results_6_8.json`: one completed result, full primal/dual data.
* `fundamental_counterexample_audit.json`: exact rows/primal/dual verified
  without an optimizer; saved exhaustive graph caps explicitly reused.

The sweep stopped automatically. Input7 was not run. Fundamental shortcut
is false, not unresolved. Earlier uniform-capacity successes do not rescue it.

## Rank-four repair exposed the inventory equality51

Source B=[[0,0,3,1],[0,0,2,0],[-3,-2,0,0],[-1,0,0,0]],
d=(8,7,9,2),g=(-8,-7,29,6): pure graph exactleast mass145740.
After source mutation0:

    B'=[[0,0,-3,-1],[0,0,2,0],[3,-2,0,0],[1,0,0,0]]
    d'=(21,7,9,2),g'=(8,-7,5,-2).

Target graph minimum15151164 has no least; true Laurent transport of the
source candidate has mass15151380. Both bad witnesses pass all112142
genuine graph-product star+pair remainder rows. Do not repeat that family.

One actual transported pair inequality restores exactleast15151380:

    a_(5,6,3,2)-a_(8,6,4,2)-51 >= 0.

Source pair(1,2), outside(0,3)=(6,2), greedy root(3,2), label(-3,5).
See `minimal_neighbor_repair_results.json` and `minimal_neighbor_violations.json`.

Pieri initially produced the opposite row with constant33, using a wrong
smaller creator. Genuine neighbor conditions repair creator(21,6,9,2),
mass14900652→14900868, by adding
18z^(2,3,2,2)[(1+z1)^2+z1²z2(1+z0)^3]. Creation constant becomes51.
The other branch also repaired creator3(21,7,9,1); its corrected lowering3
row is exactly the genuine inequality above. The two bounds force the
equality with51. Transport then passes all8 one-step Pieri tests.

General interface: b_j+M_j c_i=a_ij follows from
x_j theta_d+x_j(P_i-theta_d)=x_jP_i; zero inventory forces compatible
creation/lowering packets. Read the latest `agent_two_sided_pieri` handoff.

WARNING: `graph_plus_one_creation_results.json` is an obsolete conditional
experiment with wrong constant33 and mass15155092; it is not theta-valid.
`pieri_prefix_certification_results.json` proves the actually used prefix
coefficients of11/13 lower inputs are forced; the only locally ambiguous
ones were(18,5,7,2) and the creator above. No original cache was overwritten.

## APIs for next computation

Add `work/agent_creation_caps` to sys.path; import from `cap_batch`.

    run_case(case,mode='graph_pair')

case needs B,g,carrier{d,lattice_points}; optional F is only a proposal.
Load `fundamental_input_6.json` to reuse its precomputed_graph_caps and
precomputed_graph_families. `build_logic(B,g,C)[:3]` returns M,R,S.
Coefficient p is R[M['ids'][p]] in S['dimension'] exact parameters; origin
is R[M['ids'][zero]]. `case['extra_rows']` adds integer rows>=0 in these
parameters. Clearly label conditional lower-candidate rows as conditional.

`run_case` stores exact mass primal/dual, every least-coordinate conic proof,
or exact coordinate tradeoff. Numerical unresolved statuses are not results.
`mode='graph_neighbor_pair'` adds genuine source/sink graph caps+pair lower;
optionally restrict `case['neighbor_directions']=[0]`.

`mutate_rows`, `section_rows`, `exact_conic_scaled`, `propose_optimum` are
available through these imports. Clear Fraction denominators before
`primitive`, which expects integer rows. `block_upper_caps(...,graph=True)`
returns **three** values caps,families,polynomials and defaults to a200000
allocation safety cap.

All decisive graph jobs completed. Only old session5114 (`new_rank_sweep.py`,
slow Newton pruning) may remain; it is irrelevant to the new route and must
not be expanded. Broader proofs, corrections and literature logs are in
`GRAPH_CAPACITY_SELECTOR.md` and `LITERATURE_AND_ROUTE_LOG.md`.
