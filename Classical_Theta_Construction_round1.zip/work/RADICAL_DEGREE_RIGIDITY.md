# Radical degrees do not create independent transport parameters

Date: 2026-11-13. Classical principal coefficients; B is skew-symmetrizable, D B is skew-symmetric. This is a refinement of `agent_frame/FINITE_SIGNATURE_THEOREM.md`, not a basis theorem.

Write the normalized elementary transport in a sign-coherent c-direction alpha as

\[
\log U_{\alpha,\epsilon}
=\frac{\epsilon}{\delta_\alpha}\sum_{m\geq 1}\frac{(-1)^{m+1}}{m^2}E_{m\alpha},
\qquad [E_a,E_b]=(a^TDBb)E_{a+b}.
\]

All assertions may be interpreted in any finite degree quotient, so BCH is finite.

## Proposition

Let p be a positive integer vector with Bp=0. Unless p is supported on a single initially isolated vertex, the E_p coefficient of log T_t is zero for every actual normalized seed transport T_t.

Consequently, if two actual transports agree at every proper coordinate subdegree of p, then their coefficients at p also agree, simultaneously for every label g. There is no independent top-degree endpoint parameter at p.

## Proof

Every term of BCH that is a bracket of total degree p vanishes at its top bracket: if its two outer degrees are a and b, then a+b=p and

\[
a^TDBb=a^TDB(p-a)=0.
\]

Thus a nonzero log coefficient in degree p could only come directly from a single elementary log, with p=m alpha. This would imply B alpha=0.

For an actual c-vector column c=C_t e_k, tropical duality gives

\[
G_t B_t=B C_t.
\]

Hence Bc=0 forces B_t e_k=0, because G_t is invertible. Vertex k is isolated at seed t. Isolation of a specified vertex is invariant under every matrix mutation: mutation at that vertex only changes signs; mutation at a different vertex cannot connect an isolated vertex. The reverse mutation gives the converse. Therefore k was isolated initially. Its c-column remains plus or minus e_k, since its matrix row and column stay zero throughout. So alpha=e_k and p is supported on that isolated axis, as claimed.

For the consequence, equality at proper subdegrees makes log(T_s T_t^{-1}) in the coordinate box [0,p] a scalar multiple of E_p. Its degree-p term is zero by the same BCH argument and the vanishing degree-p logs of T_s and T_t. QED.

## Scope and use

This works in arbitrary rank and for a nontrivial symmetrizer. It uses neither a reddening sequence nor a classification of rank-three mutation classes. For a balanced cyclic three-vertex matrix and p=(1,1,1), it closes the apparent missing endpoint immediately. More generally it removes all non-axis radical degrees from the finite-signature distinguishing set.

It does not decide nonradical singleton endpoints and does not establish all-seed normalized polynomiality or theta equality. The isolated-axis exception is essential: mutation of an isolated variable has a nontrivial rank-one binomial transport.
