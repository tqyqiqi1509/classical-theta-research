#!/usr/bin/env python3
"""Exact positive-orthant certificates from rational weighted AM-GM.

The search is heuristic; acceptance is an exact rational identity plus an
integer-power AM-GM inequality. Failure to find a certificate proves nothing.
This tool concerns values on the positive orthant, NOT coefficient positivity.
"""
from fractions import Fraction as Q
from itertools import combinations
from math import gcd, lcm, log, exp, ceil
import json, random


def segment_weights(beta, a, b):
    lam = next((Q(beta[i]-b[i], a[i]-b[i])
                for i in range(len(beta)) if a[i] != b[i]), None)
    if lam is None or not 0 < lam < 1:
        return None
    if any(lam*a[i]+(1-lam)*b[i] != beta[i] for i in range(len(beta))):
        return None
    return (lam, 1-lam)


def exact_barycentric(beta, vertices):
    import sympy as sp
    A = sp.Matrix([[1]*len(vertices)] +
                  [[p[i] for p in vertices] for i in range(len(beta))])
    target = sp.Matrix([1]+list(beta))
    if A.rank() != len(vertices):
        return None
    try:
        w, free = A.gauss_jordan_solve(target)
    except ValueError:
        return None
    if free.rows or any(x <= 0 for x in w):
        return None
    return tuple(Q(int(x.p), int(x.q)) for x in w)


def amgm_check(weights, allocated, negative):
    """Check product((a_i/lambda_i)^lambda_i) >= negative exactly."""
    if sum(weights) != 1 or any(w <= 0 for w in weights):
        return False
    if any(a <= 0 for a in allocated) or negative <= 0:
        return False
    L = lcm(*(w.denominator for w in weights))
    powers = [int(w*L) for w in weights]
    lhs = Q(1)
    for a, w, k in zip(allocated, weights, powers):
        lhs *= (a/w)**k
    return lhs >= negative**L


def candidates(beta, capacities, negative, lp_trials=8):
    """Propose two-term circuits and sparse convex combinations from LP."""
    pts = list(capacities)
    out = {}
    for a, b in combinations(pts, 2):
        w = segment_weights(beta, a, b)
        if w is not None:
            out[(a, b)] = w
    if lp_trials and len(pts) >= 3:
        import numpy as np
        from scipy.optimize import linprog
        A = np.array([[1.0]*len(pts)] +
                     [[float(p[i]) for p in pts] for i in range(len(beta))])
        rhs = np.array([1.0]+list(beta))
        rng = random.Random(1729+sum((i+1)*a for i,a in enumerate(beta)))
        costs = [[-log(float(capacities[p])) for p in pts],
                 [sum((a-b)**2 for a,b in zip(p,beta)) for p in pts]]
        costs += [[rng.randint(-100,100) for p in pts] for _ in range(lp_trials)]
        for cost in costs:
            r = linprog(cost, A_eq=A, b_eq=rhs, bounds=(0,None), method='highs')
            if not r.success:
                continue
            support = tuple(pts[i] for i,x in enumerate(r.x) if x > 1e-8)
            if support in out or not 2 <= len(support) <= len(beta)+1:
                continue
            w = exact_barycentric(beta, support)
            if w is not None:
                out[support] = w
    scored = []
    for support, weights in out.items():
        lg = sum(float(w)*log(float(capacities[p]/w))
                 for p,w in zip(support,weights))
        ratio = exp(lg-log(float(negative)))
        if ratio >= 1-1e-10 and amgm_check(weights,
                [capacities[p] for p in support], negative):
            scored.append((ratio,support,weights))
    return sorted(scored,reverse=True,key=lambda x:x[0])


def verify(poly, certificate):
    remainder = dict(poly)
    for c in certificate['circuits']:
        beta = tuple(c['beta']); b = Q(c['negative'])
        support = list(map(tuple,c['support']))
        weights = list(map(Q,c['weights']))
        alloc = list(map(Q,c['allocated']))
        if any(sum(w*p[j] for w,p in zip(weights,support)) != beta[j]
               for j in range(len(beta))):
            return False
        if not amgm_check(weights,alloc,b):
            return False
        remainder[beta] = remainder.get(beta,Q(0))+b
        for p,a in zip(support,alloc):
            remainder[p] = remainder.get(p,Q(0))-a
    claimed = {tuple(t['p']):Q(t['a']) for t in certificate['remainder']}
    remainder = {p:a for p,a in remainder.items() if a}
    return remainder == claimed and all(a >= 0 for a in remainder.values())


def search(poly, lp_trials=8, branch_cap=8, node_cap=1000):
    poly = {tuple(p):Q(a) for p,a in poly.items() if a}
    negative = [(p,-a) for p,a in poly.items() if a < 0]
    positive = {p:a for p,a in poly.items() if a > 0}
    nodes = 0
    def visit(remaining, caps, records):
        nonlocal nodes
        nodes += 1
        if nodes > node_cap:
            return None
        if not remaining:
            cert = {'circuits':records,
                    'remainder':[{'p':p,'a':str(a)} for p,a in caps.items() if a]}
            if not verify(poly,cert):
                raise ArithmeticError('certificate verification failed')
            return cert
        opts = []
        for beta,b in remaining:
            cs = candidates(beta,caps,b,lp_trials)
            if not cs:
                return None
            opts.append((len(cs),beta,b,cs))
        _,beta,b,cs = min(opts,key=lambda t:t[0])
        others = [(p,a) for p,a in remaining if p != beta]
        for ratio,support,weights in cs[:branch_cap]:
            # Rational rounding is only a proposal. Exact AM-GM acceptance
            # below is authoritative, including at a nearly tight boundary.
            tau = min(Q(1), Q(ceil(1000000/ratio)+1,1000000))
            allocated = [tau*caps[p] for p in support]
            if not amgm_check(weights,allocated,b):
                allocated = [caps[p] for p in support]
            newcaps = dict(caps)
            for p,a in zip(support,allocated):
                newcaps[p] -= a
                if not newcaps[p]:
                    del newcaps[p]
            rec = {'beta':beta,'negative':str(b),'support':support,
                   'weights':list(map(str,weights)),
                   'allocated':list(map(str,allocated))}
            ans = visit(others,newcaps,records+[rec])
            if ans is not None:
                return ans
        return None
    result = visit(negative,positive,[])
    return {'status':'certified' if result is not None else 'not_found',
            'search_nodes':nodes,'certificate':result,
            'scope':'Nonnegative values for strictly positive variables only.'}


if __name__ == '__main__':
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser()
    parser.add_argument('input')
    parser.add_argument('output')
    args = parser.parse_args()
    source = json.loads(Path(args.input).read_text())
    result = search({tuple(t['p']):Q(t['a']) for t in source['terms']})
    Path(args.output).write_text(json.dumps(result,indent=2))
    print({k:v for k,v in result.items() if k != 'certificate'})
