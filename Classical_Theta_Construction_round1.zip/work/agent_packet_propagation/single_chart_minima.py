#!/usr/bin/env python3
"""Test initial-coefficient positivity alone, keeping full Laurent membership."""
from linear_carrier import *
from schofield_carrier import solve_carrier_packets
from normalized_fibers import mutate

def rational_vertex(R,origin,x):
    m=len(origin);rows=[origin];rhs=[sp.Integer(1)]
    for r in R:
        value=sum(float(a)*b for a,b in zip(r,x))
        if abs(value)<1e-7:
            rows.append(r);rhs.append(sp.Integer(0))
    A=sp.Matrix(rows);b=sp.Matrix(rhs)
    try:sol,params=A.gauss_jordan_solve(b)
    except ValueError:return None
    if params.rows:sol=sol.subs({p:0 for p in params})
    if sum(a*b for a,b in zip(origin,sol))!=1:return None
    if any(sum(a*b for a,b in zip(r,sol))<0 for r in R):return None
    return tuple(sol)

def solve_single(B,g,C):
    R,S=divisibility_space(B,g,C['lattice_points']);points=list(R);rows=list(R.values());origin=R[(0,)*len(g)];m=S['dimension']
    cost=tuple(sum(r[j]for r in rows)for j in range(m))
    lp=linprog(np.array(cost,float),A_ub=-np.array(rows,float),b_ub=np.zeros(len(rows)),A_eq=[origin],b_eq=[1],bounds=(None,None),method='highs')
    if lp.x is None:return {'status':int(lp.status)},None
    x=rational_vertex(rows,origin,lp.x)
    if x is None:return {'status':int(lp.status),'exact_vertex_failed':True},None
    F={p:sum(a*b for a,b in zip(R[p],x))for p in points};F={p:a for p,a in F.items()if a}
    value=sum(F.values());diff=tuple(sp.Rational(a)-value*b for a,b in zip(cost,origin))
    den=sp.ilcm(*[a.q for a in diff])if len(diff)>1 else diff[0].q
    objcert=exact_conic(tuple(int(a*den)for a in diff),rows)
    least=[];unverified=[]
    for p,a in F.items():
        difference=tuple(sp.Rational(v)-a*w for v,w in zip(R[p],origin));d=sp.ilcm(*[v.q for v in difference])if len(difference)>1 else difference[0].q
        cert=exact_conic(tuple(int(v*d)for v in difference),rows)
        if cert is not None:least.append(p)
        else:unverified.append(p)
    star=[]
    for k in range(len(g)):
        st,err=mutate(B,g,F,k)
        if err:star.append({'k':k,'error':err})
    return {'B':B,'g':g,'space':S,'mass':[int(value.p),int(value.q)],'integer':all(a.q==1 for a in F.values()),
            'mass_dual_verified':objcert is not None,'least_certified':len(least),'least_unverified':unverified,'star_failures':star,
            'F':[[p,[int(a.p),int(a.q)]]for p,a in sorted(F.items())]},F

if __name__=='__main__':
    folder=Path(__file__).parent;out=[]
    cases=[([[0,3],[-3,0]],(7,7)),([[0,3,3],[-3,0,3],[-3,-3,0]],(3,3,3)),
           ([[0,0,2,2],[0,0,2,2],[-2,-2,0,0],[-2,-2,0,0]],(2,2,2,2))]
    for B,d in cases:
        n=len(d);g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j]for j in range(n))for i in range(n));C=carrier(B,d)
        r,F=solve_single(B,g,C);out.append(r);print({k:v for k,v in r.items()if k!='F'},flush=True)
        (folder/'single_chart_minima_results.json').write_text(json.dumps(out,indent=2,default=str))
