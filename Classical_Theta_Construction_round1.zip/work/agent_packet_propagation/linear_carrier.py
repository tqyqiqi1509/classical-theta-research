#!/usr/bin/env python3
"""Exact linear coefficient rows in a finite principal F-polynomial carrier.

The source vector space is cut out by Laurent divisibility in the initial
star.  No positivity or unproved finite-seed acceptance is assumed.
"""
from pathlib import Path
import sys, math, json, random, time
from collections import defaultdict, deque
from fractions import Fraction
import sympy as sp
import numpy as np
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_acceptance'),str(ROOT/'agent_polytope'),str(ROOT/'agent_mass')]
from schofield_carrier import acyclic_dimension, carrier
from normalized_fibers import mutate_matrix, mutate_g

def divisibility_space(B,g,points,vertices=None):
    """An exact Q-basis of U intersect the specified finite coefficient space."""
    points=tuple(map(tuple,points)); ids={p:i for i,p in enumerate(points)}
    n=len(g); rows=[]
    for k in range(n):
        fibers=defaultdict(list)
        for p in points: fibers[p[:k]+p[k+1:]].append(p)
        for off,ps in fibers.items():
            p=off[:k]+(0,)+off[k:]
            r=g[k]+sum(B[k][j]*p[j] for j in range(n));d=max(-r,0)
            N=max(p[k] for p in ps)
            # Derivatives at t=-1 of orders 0,...,d-1 vanish.
            for j in range(min(d,N+1)):
                row=[0]*len(points)
                for p in ps:
                    if p[k]>=j: row[ids[p]]=math.comb(p[k],j)*(-1)**(p[k]-j)
                if any(row): rows.append(row)
    if vertices is not None:
        origin=(0,)*n
        for vertex in vertices:
            vertex=tuple(vertex)
            if vertex==origin:continue
            row=[0]*len(points);row[ids[vertex]]=1;row[ids[origin]]=-1
            rows.append(row)
    A=sp.Matrix(rows) if rows else sp.zeros(0,len(points))
    null=A.nullspace();m=len(null)
    # Each column is cleared separately; this retains a Q-basis.
    columns=[]
    for v in null:
        den=sp.ilcm(*[x.q for x in v]) if len(v)>1 else v[0].q
        columns.append([int(x*den) for x in v])
    F={p:tuple(columns[j][i] for j in range(m)) for i,p in enumerate(points)}
    F={p:r for p,r in F.items() if any(r)}
    return F,{'points':len(points),'equations':A.rows,'dimension':m,'rank':len(points)-m}

def add(a,b,mult=1): return tuple(x+mult*y for x,y in zip(a,b))

def mutate_rows(B,g,F,k,cap=5000):
    """Mutation of all basis functions at once, without positivity assumptions."""
    n=len(g);m=len(next(iter(F.values())));z=(0,)*m
    fibers=defaultdict(dict)
    for p,c in F.items(): fibers[p[:k]+p[k+1:]][p[k]]=c
    out={}
    for off,row in fibers.items():
        p=off[:k]+(0,)+off[k:]
        r=g[k]+sum(B[k][j]*p[j] for j in range(n));d=max(-r,0)
        alpha=max(-g[k],0)+sum(max(-B[k][j],0)*p[j] for j in range(n))
        N=max(row);q=[]
        if N>cap or max(r,0)>cap:return None,{'resource':'fiber_length','N':N,'r':r}
        for s in range(N+1):
            a=row.get(s,z)
            for j in range(1,min(d,s)+1): a=add(a,q[s-j],-math.comb(d,j))
            q.append(a)
        if any(any(q[s]) for s in range(max(0,N-d+1),N+1)):
            raise ArithmeticError(('not divisible',k,off,r,q))
        for s,a in enumerate(q):
            if not any(a):continue
            for j in range(max(r,0)+1):
                e=alpha-d-s+j
                if e<0:raise ArithmeticError(('negative reset exponent',k,off,s,e))
                target=off[:k]+(e,)+off[k:]
                out[target]=add(out.get(target,z),a,math.comb(max(r,0),j))
                if len(out)>cap:return None,{'resource':'terms','count':len(out)}
    out={p:a for p,a in out.items() if any(a)}
    return (mutate_matrix(B,k),mutate_g(B,g,k),out),None

def primitive(row):
    h=math.gcd(*row)
    return tuple(a//h for a in row) if h else row

def exact_conic(target,generators):
    """A verified rational nonnegative combination, or None (not a disproof)."""
    if target in generators:return [(generators.index(target),Fraction(1))]
    if not generators:return None
    A=np.array(generators,dtype=float).T
    lp=linprog(np.zeros(len(generators)),A_eq=A,b_eq=np.array(target,dtype=float),bounds=(0,None),method='highs')
    if lp.x is None:return None
    active=[i for i,x in enumerate(lp.x) if x>1e-8]
    if not active:return [] if not any(target) else None
    AA=sp.Matrix.hstack(*(sp.Matrix(generators[i]) for i in active))
    try:sol,params=AA.gauss_jordan_solve(sp.Matrix(target))
    except ValueError:return None
    if params.rows:sol=sol.subs({p:0 for p in params})
    if any(x<0 for x in sol) or AA*sol!=sp.Matrix(target):return None
    return [(i,Fraction(int(x.p),int(x.q))) for i,x in zip(active,sol) if x]

def census():
    out=[];rng=random.Random(413163)
    for n in [2,3,4,5]:
      for edge in [2,3]:
       for rep in range(12):
        B=[[0]*n for _ in range(n)]
        for i in range(n):
         for j in range(i+1,n):
          a=edge if (i,j)==(0,1) else (1 if j==i+1 or rng.random()<0.35 else 0)
          B[i][j]=a;B[j][i]=-a
        # Prescribe d so the carrier size is controlled and has imaginary directions.
        d=tuple(rng.choice([1,2,3]) for _ in range(n))
        A=[[max(-B[i][j],0) for j in range(n)] for i in range(n)]
        g=tuple(-d[i]+sum(A[i][j]*d[j] for j in range(n)) for i in range(n))
        C=carrier(B,d,cap=1200)
        F,S=divisibility_space(B,g,C['lattice_points'])
        out.append({'B':B,'g':g,'d':d,'vertices':C['vertices'],'points':C['lattice_points'],'space':S})
        print(n,edge,rep,d,S,flush=True)
    (Path(__file__).parent/'carrier_space_census.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':census()
