#!/usr/bin/env python3
"""Positive-circuit support certificates via packet zero propagation.

A proved sufficient criterion, not assumed complete. All operations are exact.
"""
from packet_coordinate_minima import *
from itertools import product
from packet_minimum import build

def packet_linear_rows(B,g,C,M):
    R,S=divisibility_space(B,g,C['lattice_points']);m=S['dimension'];zero=(0,)*m
    result=[]
    for key in M['columns']:
        if key[0]=='a':result.append(R.get(key[1],zero));continue
        _,k,off,s,d=key
        value=zero
        for j in range(s+1):
            coef=(int(j==0)if d==0 else(-1)**j*math.comb(d+j-1,j))
            p=off[:k]+(s-j,)+off[k:]
            value=add(value,R.get(p,zero),coef)
        result.append(value)
    return result,S

def build_logic(B,g,C):
    M=build(B,g,list(map(tuple,C['lattice_points'])));R,S=packet_linear_rows(B,g,C,M)
    groups=defaultdict(list);forced_zero=set()
    for i,row in enumerate(R):
        if not any(row):forced_zero.add(i);continue
        h=math.gcd(*row);first=next(a for a in row if a);sign=1 if first>0 else-1
        groups[tuple(sign*a//h for a in row)].append((i,sign))
    classes=[];group_ids={}
    for members in groups.values():
        ids=[i for i,s in members];gi=len(classes);classes.append(ids)
        for i in ids:group_ids[i]=gi
        if len({s for i,s in members})>1:forced_zero.update(ids)
    # Each packet equation is a_p = sum positive_integer*q_j.
    rows=[];touch=[[]for _ in R]
    for (k,p),rowid in sorted(M['rows'].items(),key=lambda x:x[1]):
        coeff=M['ids'][p];packets=[]
        for j,key in enumerate(M['columns']):
            if key[0]!='q'or key[1]!=k:continue
            _,kk,off,s,d=key
            if p[:k]+p[k+1:]==off and s<=p[k]<=s+d:packets.append(j)
        rows.append((coeff,packets))
        for j in [coeff]+packets:touch[j].append(len(rows)-1)
    return M,R,S,rows,touch,classes,group_ids,forced_zero

def zero_closure(start,logic):
    M,R,S,rows,touch,classes,gids,base=logic
    Z=set(base);Z.update(start);queue=deque(Z);processed=set()
    while queue:
        i=queue.popleft()
        if i in processed:continue
        processed.add(i)
        if i in gids:
            for j in classes[gids[i]]:
                if j not in Z:Z.add(j);queue.append(j)
        for rid in touch[i]:
            a,qq=rows[rid]
            if a in Z:
                new=qq
            elif all(q in Z for q in qq):
                new=[a]
            else:continue
            for j in new:
                if j not in Z:Z.add(j);queue.append(j)
    return Z

def construct(B,g,C,logic=None):
    if logic is None:logic=build_logic(B,g,C)
    M,R,S=logic[:3];origin=M['ids'][(0,)*len(g)]
    mandatory=[];not_certified=[]
    for i in range(len(R)):
        if origin in zero_closure([i],logic):mandatory.append(i)
        else:not_certified.append(i)
    # Search for a normalized solution whose support is entirely certified
    # mandatory. This is one exact linear system, not an optimization call.
    m=S['dimension'];eq=[R[origin]]+[R[i]for i in not_certified];rhs=[1]+[0]*len(not_certified)
    A=sp.Matrix(eq);b=sp.Matrix(rhs)
    try:x,params=A.gauss_jordan_solve(b)
    except ValueError:
        return {'B':B,'g':g,'space':S,'variables':len(R),'mandatory':len(mandatory),'constructed':False,'reason':'mandatory_support_not_feasible'}
    if params.rows:x=x.subs({p:0 for p in params})
    vals=[sum(a*b for a,b in zip(row,x))for row in R]
    if vals[origin]!=1 or any(v<0 for v in vals):
        return {'B':B,'g':g,'space':S,'variables':len(R),'mandatory':len(mandatory),'constructed':False,'reason':'nonnegative_solution_not_obtained'}
    support=[i for i,a in enumerate(vals)if a]
    if not set(support).issubset(set(mandatory)):raise ArithmeticError('uncertified support')
    F={p:vals[j]for p,j in M['ids'].items()if vals[j]}
    return {'B':B,'g':g,'space':S,'variables':len(R),'mandatory':len(mandatory),'constructed':True,
            'integer':all(a.q==1 for a in vals),'mass':str(sum(F.values())),
            'F':[[p,[int(a.p),int(a.q)]]for p,a in sorted(F.items())],
            'mandatory_column_indices':mandatory,'linear_parameters':[[int(a.p),int(a.q)]for a in x]}

if __name__=='__main__':
    folder=Path(__file__).parent;tic=time.time();results=[];seen=set()
    cases=[]
    for name in ['large_carrier_results.json','topology_cones_results.json']:
        cases.extend(json.loads((folder/name).read_text())['results'])
    for ci,c in enumerate(cases):
        B,g=c['B'],c['g'];key=(tuple(map(tuple,B)),tuple(g))
        if key in seen:continue
        seen.add(key)
        if len(g)<3:continue
        C={'d':c['d'],'vertices':c['vertices'],'lattice_points':c['points']}
        r=construct(B,g,C);results.append(r)
        print(ci,'rank',len(g),'dim',r['space']['dimension'],'constructed',r['constructed'],'mandatory',r['mandatory'],'mass',r.get('mass'),flush=True)
        (folder/'mandatory_support_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':results},indent=2))
        if not r['constructed']:break
    print('seconds',time.time()-tic,flush=True)
