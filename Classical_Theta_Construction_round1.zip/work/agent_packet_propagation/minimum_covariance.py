#!/usr/bin/env python3
"""Test the canonical minimum and LP/integer gaps on certified minimal carriers.

No finite-depth success is an all-seed positivity proof. Source carrier
minimality is certified by forced vertex coefficients, under root's VIT bridge.
"""
from linear_carrier import *
from schofield_carrier import solve_carrier_packets,exact_barycentric,exact_separator
from theta_newton_pruning import prune,exact_vertices
from normalized_fibers import mutate
from itertools import product

def minimality_certificate(B,g,C):
    R,S=divisibility_space(B,g,C['lattice_points']);origin=R[(0,)*len(g)]
    fixed=all(R.get(tuple(v))==origin for v in C['vertices'])
    if fixed:return C,{'all_vertices_forced_equal_origin':True,'space':S}
    P=prune(B,g,points=C['lattice_points'],cap=5000)
    return P,{'pruning_used':True,'deletions':P['nontrivial_deletions'],'space':P['initial_space']}

def carrier_from_polynomial(F,cap=2500):
    V,certs=exact_vertices(F);n=len(V[0]);d=[max(p[i]for p in V)for i in range(n)]
    raw=math.prod(a+1 for a in d)
    if raw>cap:return None,{'kind':'target_box','size':raw}
    pts=[]
    for p in product(*(range(a+1)for a in d)):
        if exact_barycentric(p,V)is not None:pts.append(list(p))
        elif exact_separator(p,V)is None:raise ArithmeticError('unverified lattice containment')
    return {'d':d,'vertices':V,'lattice_points':pts,'vertex_certificates':certs},None

def objective_status(rep):
    ans={'integer_mass':rep.get('mass'),'lp_status':rep.get('lp_status'),'milp_status':rep.get('milp_status')}
    cert=rep.get('dual',{})
    if cert.get('valid'):
        val=Fraction(*cert['value']);ans['certified_rational_lower_bound']=[val.numerator,val.denominator]
        if rep.get('mass')is not None:
            gap=Fraction(rep['mass'])-val;ans['integer_minus_lp_bound']=[gap.numerator,gap.denominator]
            ans['integer_optimum_certified']=gap<1
    else:ans['dual_unverified']=True
    ans['uniqueness']=rep.get('uniqueness')
    return ans

def main():
    folder=Path(__file__).parent;tic=time.time();cases=[]
    for name in ['large_carrier_results.json','topology_cones_results.json']:
        cases.extend(json.loads((folder/name).read_text())['results'])
    out=[];seen=set();stats={'cases':0,'source_minima':0,'target_minima':0,'min_covariance_failures':0,'positivity_failures':0,'resource_cuts':0,'lp_gap_cases':0,'nonunique':0}
    for ci,c in enumerate(cases):
        B=c['B'];g=tuple(c['g']);key=(tuple(map(tuple,B)),g)
        if key in seen or len(g)<3:continue
        seen.add(key);stats['cases']+=1
        C={'d':c['d'],'vertices':c['vertices'],'lattice_points':c['points']}
        P,mincert=minimality_certificate(B,g,C)
        rep,F,M=solve_carrier_packets(B,g,P,seconds=20);status=objective_status(rep)
        if F is None:out.append({'B':B,'g':g,'source_failed':rep});continue
        stats['source_minima']+=1
        if status.get('integer_minus_lp_bound',[0])[0]:stats['lp_gap_cases']+=1
        if not status.get('uniqueness',{}).get('unique',False):stats['nonunique']+=1
        rec={'B':B,'g':g,'d':P['d'],'source':status,'minimality_certificate':mincert,'neighbors':[]}
        for k in range(len(g)):
            state,err=mutate(B,g,F,k)
            if err:raise AssertionError(('source not positive star',err))
            BB,gg,T=state;Q,cut=carrier_from_polynomial(T)
            if cut:stats['resource_cuts']+=1;rec['neighbors'].append({'k':k,'resource_cut':cut});continue
            r2,H,MM=solve_carrier_packets(BB,gg,Q,seconds=20)
            if H is None:rec['neighbors'].append({'k':k,'failed':r2});continue
            stats['target_minima']+=1;s2=objective_status(r2)
            same=T==H;bad=sum(T.values())!=sum(H.values())
            if bad or not same:stats['min_covariance_failures']+=1
            item={'k':k,'transported_mass':sum(T.values()),'target':s2,'same_polynomial':same,'same_mass':not bad}
            if bad or not same:
                item.update({'source_candidate':rep,'target_candidate':r2,'target_B':BB,'target_g':gg,'target_vertices':Q['vertices']})
                (folder/f'minimum_covariance_failure_{ci}_{k}.json').write_text(json.dumps({'B':B,'g':g,**item},indent=2))
            rec['neighbors'].append(item)
        out.append(rec)
        (folder/'minimum_covariance_results.json').write_text(json.dumps({'stats':stats,'seconds':time.time()-tic,'results':out},indent=2))
        print(ci,stats,'rank',len(g),'space',c.get('unrestricted_space',c['stats']['space'])['dimension'],'mass',sum(F.values()),flush=True)
    print(stats,'seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
