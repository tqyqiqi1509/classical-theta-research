#!/usr/bin/env python3
"""Re-solve all-pair minimum in true adjacent charts with exact certificates."""
from large_origin_complete import *
from normalized_fibers import mutate
from scipy.optimize import linprog


def reconstruct_vertex(M,R,raw):
    if raw is None:return None
    origin=M['ids'][(0,)*len(M['g'])]
    for tol in [1e-8,1e-6,1e-4]:
        zeros=[R[i] for i,a in enumerate(raw) if abs(a)<tol]
        try:
            parameters,free=sp.Matrix([R[origin]]+zeros).gauss_jordan_solve(sp.Matrix([1]+[0]*len(zeros)))
        except ValueError:continue
        if free.rows:continue
        values=[sum(a*b for a,b in zip(row,parameters)) for row in R]
        if any(a<0 for a in values):continue
        vector=[Fraction(int(a.p),int(a.q)) for a in values]
        # All equations are rechecked independently by the generic verifier.
        A=M['A'].tocsr()
        if all(sum(Fraction(int(round(a)))*vector[int(j)] for j,a in zip(A.indices[A.indptr[i]:A.indptr[i+1]],A.data[A.indptr[i]:A.indptr[i+1]]))==Fraction(int(round(b))) for i,b in enumerate(M['b'])):
            return vector
    return None


def minimum(B,g,C):
    tic=time.time();logic=build_logic(B,g,C);M,R,S=logic[:3]
    from commuting_packets import augment as ca
    from ranktwo_packets import augment as pa
    M,R,ci=ca(B,g,C,M,R);M,R,pi=pa(B,g,C,M,R)
    lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':45})
    x=exact_vector(M,lp.x);used_reconstruction=False
    if x is None:x=reconstruct_vertex(M,R,lp.x);used_reconstruction=True
    record={'B':B,'g':g,'dimension':S['dimension'],'points':len(C['lattice_points']),'variables':len(R),'lp_status':int(lp.status),'reconstructed_vertex':used_reconstruction,
            'ranktwo_sections':pi['sections'],'ranktwo_coordinates':pi['new_coordinates'],'commuting_coordinates':ci['new_coordinates']}
    if x is None:return {**record,'unresolved':'no exact primal'},None
    F={p:x[j] for p,j in M['ids'].items() if x[j]};mass=sum(F.values());dc={}
    for den in [1000000,1,2,3,4,6,8,12,16,24,32,64,128,256,1024,4096]:
        trial=finite_dual(M,lp.eqlin.marginals,max_den=den)
        if trial.get('valid') and Fraction(*trial['value'])==mass:dc=trial;record['dual_denominator_cap']=den;break
    record.update({'mass':str(mass),'integral':all(a.denominator==1 for a in x),'optimum_certified':bool(dc),'dual':dc,'seconds':time.time()-tic,'F':[{'p':p,'a':str(a)} for p,a in F.items()]})
    return record,F


def main():
    folder=Path(__file__).parent;src=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text());B,g=src['B'],src['g'];F={tuple(z['p']):Fraction(z['a']) for z in src['F']};out=[];tic=time.time()
    for k in range(len(g)):
        print('start neighbor',k,flush=True);state,err=mutate(B,g,F,k)
        if err:raise ArithmeticError(err)
        BB,gg,T=state;d=acyclic_dimension(BB,gg)[0];C=faster_carrier(BB,d,cap=12000)
        print('carrier',k,'d',d,'points',len(C['lattice_points']),flush=True)
        try:
            rec,H=minimum(BB,gg,C)
            rec['k']=k;rec['transported_mass']=str(sum(T.values()));rec['same_polynomial']=H==T if H is not None else None
            rec['same_mass']=sum(H.values())==sum(T.values()) if H is not None else None
            if H is not None and H!=T:rec['transported_F']=[{'p':p,'a':str(a)} for p,a in T.items()]
        except OverflowError as e:rec={'k':k,'B':BB,'g':gg,'resource_cut':str(e)}
        out.append(rec);print('end',k,'mass',rec.get('mass'),'expected',rec.get('transported_mass'),'same',rec.get('same_polynomial'),'certified',rec.get('optimum_certified'),flush=True)
        (folder/'pair_minimum_covariance_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))


if __name__=='__main__':main()
