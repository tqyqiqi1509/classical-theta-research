# Rank3 overlap and positive integer circuit replacement

2026-11-13. A proved finite-cone instance and a generally defined algorithm;
the arbitrary-rank theorem and mutation stability remain open.

## General finite construction

Given B,g and a certified finite Newton carrier P, form the exact rational
Laurent-divisibility space W. For each pair I=(i,j), freeze the outside
exponent eta and use the effective label h_I=g_I+B_(I,J)eta. Unitriangularly
subtract z_I^q G_(h_I+B_(I,I)q), where G is the explicit classical rank2 LLZ
greedy polynomial. Each resulting coefficient is an integer linear form on
W. Require all these forms to be nonnegative.

For every independent set S of the ORIGINAL exchange graph, mutate S, whose
mutations commute, transport all of W by exact signed binomial division, and
impose every rank2 section's nonnegative greedy coefficients in that chart.
This is a finite rule involving B,g,P, integer recurrence and linear algebra.
It uses no theta coefficients. Resource caps raise exceptions; there is no
degree truncation. Theta feasibility uses the separate root/interior positive
slice theorem in ../agent_interior/POSITIVE_SLICE_THEOREM.md; feasibility does
not by itself prove equality with theta or mutation covariance.

## The hard fork and the failure before completion

Let B=[[0,0,3],[0,0,2],[-3,-2,0]],g=(-8,-7,29),d=(8,7,9). The Newton-minimal
carrier has252 lattice points and W has dimension57. The original initial-star
cone has a unique fractional mass minimum59030. Adding22 independent-color
common-quotient variables yields integer minimum59085. Adding279 initial-chart
rank2 greedy-section variables leaves the same integer polynomial F, but
initial a-coefficient leastness still fails: a653 can drop from104 to21.

The tangent cone at F in this intermediate cone has dimension56,460 active
zero coordinates and99 distinct row directions. Exact double description
gives56 extreme rays; each is independently checked by active rank55.
Fifty-five have nonnegative initial coefficients. The remaining ray D47 has
two negative coefficients. Write

    A = u v w (1+u)^5 (1+v)^5,
    B0 = u^4 v^3 w^2 (1+u)^2 (1+v)^3,
    C = u^6 v^5 w^3 (1+v).

The relevant directions are exactly D47=A-C and D2=B0+C. D47 is negative
at(u,v,w)=(1,1,32), so positive-point leastness also fails. F+epsilon D47 is
feasible in the intermediate cone for0<=epsilon<=45, including the integer
F+D47 of mass60107. The64 smaller evaluation tests were all certified but
were insufficient to prove a global positive-point assertion.

## The exact overlap proof

After SINGLE mutation0, consider the rank2 pair(1,2), outside exponent2,
greedy shift(3,2), and local rank2 label(-3,5). Its coefficient is0 at F and
has the following exact value on the complete tangent-ray coordinates:

    ell(sum_r t_r D_r)=t_2-t_47.

Thus the legal added inequality requires t2>=t47. Every surviving tangent
vector can be written

    (t2-t47)D2 + t47(D2+D47) + sum_(r!=2,47)t_r D_r.

Every coefficient here is nonnegative. Moreover D2+D47=A+B0 is a sum of two
positive Boolean-binomial blocks, with48 positive monomials. Therefore every
surviving tangent vector has nonnegative initial coefficients.

Every normalized feasible H in the augmented cone has H-F in this tangent
cone: at each coordinate zero at F, the variation equals a nonnegative
coordinate of H. Consequently H>=F coefficientwise. This proves leastness
for the ENTIRE enhanced finite cone, not just the tested candidates.

Replacing D47,D2 by D2+D47,D2 is an integer shear on their generated ray
lattice. No ambient total-unimodularity assertion is made.

## Independent general implementation

independent_chart_closure.augment adds1013 distinct forms in the four charts
S={0},{1},{0,1},{2}; all are feasible at F. Whole-W transport and section
expansion take about0.9 seconds. Complete tangent enumeration of this full
finite cone again gives56 rays, now all initial-a nonnegative, in about27s.

Files: independent_chart_closure_results.json and
commuting_overlap_independent_verification.json. The latter recomputes the
displayed cut directly from its original-a linear identity and checks it on
all56 old primitive polynomial rays. The interior agent independently found
equivalent rows after the commuting block(0,1).

Next structural question: do legal rank3-overlap rows always permit a positive
integer replacement of signed tangent circuits on Newton-minimal carriers,
and is an appropriate finite completion stable under mutation? This example
supplies a concrete algebraic/combinatorial rule, not its general proof.
