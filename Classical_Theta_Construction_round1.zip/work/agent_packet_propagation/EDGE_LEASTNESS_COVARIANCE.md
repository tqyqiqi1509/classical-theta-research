# Two-chart leastness gives mutation covariance

2026-11-13. General classical skew-symmetrizable algebraic lemma.

This is a sufficient bridge from a finite coefficient-minimum problem to
mutation covariance. Its universal least-point hypothesis is FALSE, as the
exact rank3 example in section6 shows. The conditional lemma remains valid;
it is not a solution of the general covariance problem.

## 1. The two-chart feasible set

Fix two adjacent seeds t and t'=mu_k(t), a compatible tropical degree g, and
finite Newton carriers P_t,P_t' that transport into each other. Assume the
coefficient normalizations at the distinguished vertex agree under mutation.
For example, the root's Newton-pruning construction provides this setting
under its stated finite-theta-expansion and valuative-independence hypotheses.

Let E(t,k) be the set of normalized functions f in U with support in P_t whose
Laurent coefficients are nonnegative in both t and t'. This is the same set
of functions as E(t',k), expressed in the other chart.

E(t,k) has a finite linear description. All initial-star divisibility equations
are retained to ensure f belongs to U. Initial a-coefficients and the k-fiber
quotients are nonnegative. Quotient variables for every other direction are
allowed to be signed. Since each coordinate fiber of a convex lattice carrier
is an interval, a divisible polynomial supported in that interval has quotient
support in the corresponding shortened interval; no omitted signed packet
outside the carrier is needed.

The distinction from the full positive-star cone matters: E(t,k) is generally
larger, and it is symmetric in the two adjacent charts.

## 2. A positive evaluation identity

For any normalized Laurent function F that is polynomial in both charts,
write its k-fibers as P_eta(s)=(1+s)^d Q_eta(s), with

    r=g_k+sum_{j != k} b_kj eta_j,
    d=[-r]_+,      e=[r]_+.

The target fiber is a monomial shift times (1+s)^e Q_eta(s^-1). Consequently

    mass(F') = sum_eta 2^(e-d) P_eta(1)
             = 2^g_k sum_p a_p 2^(sum_j b_kj p_j).           (1)

All weights in this linear functional of the initial coefficients are strictly
positive rational numbers, including when g_k or the exponent is negative.
No coefficient positivity is needed to establish the identity itself.

## 3. Covariance lemma

Suppose a rule assigns to every pointed seed/carrier pair a function F_t with
the following two **finite, local** properties:

1. F_t is positive in t and every immediate neighbor (positive-star feasible).
2. For each neighbor t'=mu_k(t), F_t is coefficientwise least in E(t,k), when
   coefficients are compared in chart t.

Then F_t and F_t' are the same function for every adjacent pair. In particular,
the selected family is mutation-covariant and universally positive.

Proof. Put H=F_t'. Its pullback to t lies in E(t,k), because H is positive at
t' and its neighbor t. Thus leastness of F_t in E(t,k) gives

    a_t(F_t) <= a_t(H).

Applying the strictly positive functional (1) gives

    mass_t'(F_t) <= mass_t'(H).

In the other direction, F_t belongs to E(t',k), since it is positive in the
two charts. Leastness of H at t' gives

    a_t'(H) <= a_t'(F_t).

The sums of these nonnegative coefficients satisfy the reverse mass inequality.
The two masses are equal, so every coordinate difference vanishes. Hence the
two functions agree. Repeating along the connected exchange graph proves the
claim. QED.

The proof does not require the *whole* positive-star cone to be mutation
invariant. That stronger assertion is false, even on a Newton-minimal carrier,
as the exact rank2 example in verified_newton_star_failure.json shows.

It also does not require theta coefficients as an algorithm input. Identifying
the resulting family with theta is a further question, and a basis statement
uses the separate pointed-basis theorem and its assumptions.

## 4. Finite exact dual certificates for hypothesis2

Write the finite two-chart equations as A x=b. The a-coordinates and direction-k
q-coordinates are nonnegative; the other q-coordinates are free. To certify
that selected coefficient x*_p is least, give a rational row potential lambda
such that

    lambda A_j <= delta_(j,p)      on nonnegative columns,
    lambda A_j  = delta_(j,p)      on free columns,
    lambda b = x*_p.

Then x_p >= x*_p for every two-chart feasible x. Zero selected a-coordinates
need no certificate beyond nonnegativity. Clearing denominators leaves a
finite integer-weight certificate. The implementation checks the equalities
for every free column; a positive-star dual alone is not accepted here.

Structural existence at arbitrary rank is disproved below. Verifying these
certificates at one seed alone also does not verify them at all other seeds.
This note retains only the precise conditional covariance implication.

## 5. Independent nontrivial checks

For B=[[0,3],[-3,0]], g=(-7,14), minimal Newton triangle with vertices
(0,0),(7,0),(7,7), the positive-star minimum has mass458 and equals the known
LLZ greedy polynomial. Every one of its23 positive initial coefficients is
least in E(t,1), and also in E(t,2), by46 exact two-chart duals. The other
direction's quotient variables really are free in each test.

The same test gives30 certificates for an acyclic rank3 matrix with every
upper-triangular entry3 and d=(3,3,3), and68 for the rank4 bipartite K2,2 matrix
with edge multiplicity2 and d=(2,2,2,2). These are finite checks supporting the
local-existence question, not a proof of it.

Deleting even the one-neighbor positivity condition is too strong a shortcut.
For the same rank2 triangle, initial coefficients alone plus U divisibility
admit a rational minimum of mass339 with half-integral coefficients; its
neighbor quotients have negative coefficients. It is therefore essential to
keep the two-chart positivity assumption in this bridge.

## 6. Exact failure of the universal two-chart hypothesis

Take B=[[0,3,3],[-3,0,3],[-3,-3,0]], g=(-5,10,25), d=(5,5,5).
The minimal Newton carrier has56 lattice points and U_P has dimension33.
Its unique full-star minimum has mass134.

In E(t,1), there is an exact integer normalized U element of mass184 with
a_(5,4,1)=0, whereas the full-star minimum has that coefficient10. In E(t,3)
there is an analogous integer mass184 element with a_(4,1,0)=0 instead of10.
Both witnesses preserve all monic carrier vertices and all U divisibility
equations. Positivity in the designated two charts is checked exactly.
There are also rational mass124 witnesses lowering other positive selected
coefficients to zero. File: verified_edge_least_failure.json.

Consequently full-star leastness, even where verified, cannot be replaced by
two-chart leastness as a general route to covariance. The example does not
disprove full-star leastness or covariance of its minimum. The middle edge
passes the finite test, illustrating why small or symmetric checks were
insufficient to establish the proposed hypothesis.
