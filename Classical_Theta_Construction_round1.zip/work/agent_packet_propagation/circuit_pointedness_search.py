#!/usr/bin/env python3
"""Exact pointedness/integrality tests of all positive packet extreme rays."""
from large_origin_screen import *
import signal
sys.path.insert(0,str(ROOT/'agent_interior'))
from positive_circuits import enumerate_packet_circuits,integer_parameter_rows


def deadline(signum,frame):raise TimeoutError('per-cone exact enumeration deadline')


def analyze(B,g,C,cap=10000):
    result=enumerate_packet_circuits(B,g,C,ray_cap=cap)
    M=build(B,g,list(map(tuple,C['lattice_points'])))
    rows,_,_,_=integer_parameter_rows(B,g,M);summaries=[];bad=[]
    for ri,ray in enumerate(result['rays']):
        vals=[sum(a*b for a,b in zip(row,ray['parameter_ray'])) for row in rows]
        support=[p for p,i in M['ids'].items() if vals[i]]
        q=tuple(min(p[k] for p in support) for k in range(len(g)))
        pointed=q in support;record={'ray_index':ri,'origin':ray['origin'],'pointed':pointed,'q':q,'a_support_size':len(support)}
        if pointed:
            lead=vals[M['ids'][q]]
            record['integral_after_lead_normalization']=all((v/lead).q==1 for v in vals)
            record['normalized_mass']=str(sum(vals[:len(M['points'])])/lead)
        if not pointed or not record.get('integral_after_lead_normalization',False):
            record['parameter_ray']=ray['parameter_ray']
            record['full_coefficients']=[{'p':p,'a':str(vals[i])} for p,i in M['ids'].items() if vals[i]]
            bad.append(record)
        summaries.append(record)
    return {'B':B,'g':g,'points':len(C['lattice_points']),'space':result['space'],
            'extreme_rays':result['extreme_rays'],'unique_origin_ray':result['unique_origin_ray'],
            'ray_summaries':summaries,'failures':bad,'seconds':result['seconds'],
            'complete_enumeration':True}


def main():
    folder=Path(__file__).parent;out=[];tic=time.time()
    signal.signal(signal.SIGALRM,deadline)
    specs=[([[0,3],[-3,0]],(7,7)),([[0,3],[-3,0]],(7,8)),
           ([[0,3],[-3,0]],(4,4)),([[0,4],[-4,0]],(4,5)),
           ([[0,2,1],[-2,0,0],[-1,0,0]],(3,2,2)),
           ([[0,3,2],[-3,0,3],[-2,-3,0]],(3,3,3)),
           ([[0,0,2],[0,0,3],[-2,-3,0]],(3,3,3)),
           ([[0,2,1],[-2,0,3],[-1,-3,0]],(4,3,4)),
           ([[0,1,1,0],[-1,0,0,2],[-1,0,0,2],[0,-2,-2,0]],(2,2,2,2))]
    for ci,(B,d) in enumerate(specs):
        n=len(d);g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n))
        for mode in ['minimal','box']:
            print('start',ci,mode,'rank',n,'d',d,flush=True)
            try:
                signal.alarm(55)
                C=faster_carrier(B,d) if mode=='minimal' else {'d':d,'lattice_points':list(product(*(range(a+1) for a in d)))}
                r=analyze(B,g,C)
                r['carrier_mode']=mode
                print('end',ci,mode,'rays',r['extreme_rays'],'failures',len(r['failures']),flush=True)
                if r['failures']:
                    r['carrier']=C
                    (folder/f'circuit_pointedness_failure_{ci}_{mode}.json').write_text(json.dumps(r,indent=2))
                out.append(r)
            except (TimeoutError,OverflowError) as e:
                out.append({'B':B,'g':g,'d':d,'carrier_mode':mode,'resource_cut':str(e),'complete_enumeration':False})
                print('cut',ci,mode,str(e),flush=True)
            finally:signal.alarm(0)
            (folder/'circuit_pointedness_search_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))


if __name__=='__main__':main()
