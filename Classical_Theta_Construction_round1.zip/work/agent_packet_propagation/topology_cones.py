#!/usr/bin/env python3
"""Probe the row mechanism over DAG topologies with several sources/sinks."""
from row_cones import *

def main():
    folder=Path(__file__).parent;tic=time.time();rng=random.Random(778103);out=[]
    cases=[]
    for n in [3,4,5]:
      for rep in range(20):
        B=[[0]*n for _ in range(n)]
        for i in range(n):
          for j in range(i+1,n):
            a=rng.choice([0,0,1,2,3])
            B[i][j]=a;B[j][i]=-a
        d=tuple(rng.choice([1,2,3,4])for _ in range(n))
        cases.append((B,d))
    for n,sources in [(3,2),(4,2),(5,2),(5,3)]:
      for edge in [1,2,3]:
        B=[[0]*n for _ in range(n)]
        for i in range(sources):
          for j in range(sources,n):B[i][j]=edge;B[j][i]=-edge
        cases.append((B,(2,)*n))
    for i,(B,d) in enumerate(cases):
        n=len(d);g=tuple(-d[j]+sum(max(-B[j][k],0)*d[k]for k in range(n))for j in range(n))
        C=carrier(B,d,cap=3000);F,S=divisibility_space(B,g,C['lattice_points'])
        if S['dimension']==1:continue
        c={'B':B,'g':g,'d':d,'points':C['lattice_points'],'vertices':C['vertices'],'space':S}
        r=run_one(c,depth=3,cap=1800)
        r.update({'case':i,'unrestricted_space':S,'points':C['lattice_points'],'vertices':C['vertices']})
        out.append(r)
        (folder/'topology_cones_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))
        print(i,'B',B,'d',d,'space',S,r['stats'],flush=True)
    print('seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
