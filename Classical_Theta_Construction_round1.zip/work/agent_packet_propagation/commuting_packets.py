#!/usr/bin/env python3
"""Independent-color common binomial packets.

For an independent set I in the exchange graph, each required divisor
(1+z_i)^d_i has d_i independent of all other I-coordinates. Requiring their
common quotient nonnegative is a finite compatibility condition stronger than
separate one-color quotients. All coefficient identities are integer exact.
"""
from mandatory_support import *
from scipy.sparse import coo_matrix, hstack, vstack


def augment(B,g,C,M,R):
    n=len(g);points=list(map(tuple,C['lattice_points']));P=set(points);m=len(R[0])
    independent=[]
    for mask in range(1,1<<n):
        I=tuple(i for i in range(n) if mask>>i&1)
        if len(I)>1 and all(B[i][j]==0 for i in I for j in I):independent.append(I)
    new=[];extra_rows=[];old_count=len(M['columns'])
    for I in independent:
        for p in points:
            ds=tuple(max(0,-g[i]-sum(B[i][j]*p[j] for j in range(n))) for i in I)
            # Zero exponents reduce to a smaller independent set, already
            # considered. One-color rows are in the original packet system.
            if any(d==0 for d in ds):continue
            if any(tuple(p[j]+(ds[I.index(j)] if j in I and mask>>I.index(j)&1 else 0)
                         for j in range(n)) not in P for mask in range(1<<len(I))):continue
            raw=defaultdict(int)
            for shifts in product(*(range(p[i]+1) for i in I)):
                pp=list(p);w=1
                for i,d,j in zip(I,ds,shifts):pp[i]-=j;w*=(-1)**j*math.comb(d+j-1,j)
                pp=tuple(pp)
                if pp in M['ids'] and w:raw[M['ids'][pp]]+=w
            row=[0]*m
            for j,w in raw.items():row=[a+w*b for a,b in zip(row,R[j])]
            if not any(row):continue
            new.append({'key':('qset',I,p,ds),'raw':dict(raw)})
            extra_rows.append(tuple(row))
    nc=len(new)
    if not nc:return M,R,{'independent_sets':independent,'new_coordinates':0}
    rr=[];cc=[];vv=[]
    for t,q in enumerate(new):
        rr.append(t);cc.append(old_count+t);vv.append(1)
        for j,w in q['raw'].items():rr.append(t);cc.append(j);vv.append(-w)
    Aextra=coo_matrix((vv,(rr,cc)),shape=(nc,old_count+nc)).tocsc()
    A=vstack([hstack([M['A'],coo_matrix((M['A'].shape[0],nc))]),Aextra]).tocsc()
    N=dict(M);N['A']=A;N['b']=np.r_[M['b'],np.zeros(nc)];N['c']=np.r_[M['c'],np.zeros(nc)]
    N['columns']=list(M['columns'])+[q['key'] for q in new]
    return N,list(R)+extra_rows,{'independent_sets':independent,'new_coordinates':nc,
                               'identities':[{'key':q['key'],'raw':[[j,w] for j,w in q['raw'].items()]} for q in new]}
