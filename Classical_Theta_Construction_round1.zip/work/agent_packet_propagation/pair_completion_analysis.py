#!/usr/bin/env python3
"""Separate a-coordinate leastness, uniform bounds and mutation pair closure."""
from large_origin_complete import *
from normalized_fibers import mutate
from itertools import combinations
import signal


def scalar_sections(B,g,F,cap=20000):
    from ranktwo_packets import greedy
    sections=0;negatives=[];terms=0
    for pair in combinations(range(len(g)),2):
        I=pair if B[pair[0]][pair[1]]>=0 else tuple(reversed(pair));outside=tuple(j for j in range(len(g)) if j not in I)
        b,c=B[I[0]][I[1]],-B[I[1]][I[0]];fibres=defaultdict(dict)
        for p,a in F.items():fibres[tuple(p[j] for j in outside)][tuple(p[i] for i in I)]=a
        for off,remainder in fibres.items():
            sections+=1;h=tuple(g[i]+sum(B[i][j]*a for j,a in zip(outside,off)) for i in I);steps=0
            while remainder:
                steps+=1;terms+=1
                if steps>cap:raise OverflowError('scalar greedy expansion cap')
                q=min(remainder,key=lambda p:(sum(p),p));a=remainder[q];label=(h[0]+b*q[1],h[1]-c*q[0])
                if a<0:negatives.append({'pair':I,'off':off,'q':q,'label':label,'coefficient':str(a)})
                G=greedy(b,c,label)
                for p,v in G.items():
                    r=(p[0]+q[0],p[1]+q[1]);remainder[r]=remainder.get(r,0)-a*v
                    if not remainder[r]:del remainder[r]
    return {'sections':sections,'greedy_terms':terms,'negatives':negatives}


def main():
    folder=Path(__file__).parent;data=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    src=json.loads((folder/'large_origin_exact_failure_2.json').read_text());B,g=src['B'],src['g'];C=src['carrier']
    logic=build_logic(B,g,C);M,R,S=logic[:3];base_count=len(R);origin=M['ids'][(0,)*len(g)]
    from commuting_packets import augment as cubeaugment
    from ranktwo_packets import augment as pairaugment
    M,R,_=cubeaugment(B,g,C,M,R);M,R,_=pairaugment(B,g,C,M,R)
    F={tuple(z['p']):Fraction(z['a']) for z in data['F']};out={'B':B,'g':g,'mass':str(sum(F.values()))}
    certs=[];failures=[];unknown=[]
    for p,i in M['ids'].items():
        a=F.get(p,0)
        if not a:continue
        cert=exact_conic(tuple(Fraction(v)-a*w for v,w in zip(R[i],R[origin])),R)
        if cert is not None:certs.append({'p':p,'value':str(a),'identity':[[j,str(v)] for j,v in cert]});continue
        cost=np.zeros(len(R));cost[i]=1;lp=linprog(cost,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs');H=exact_vector(M,lp.x)
        MM=dict(M);MM['c']=cost;dc=finite_dual(MM,lp.eqlin.marginals) if lp.x is not None else {}
        if H is not None and H[i]<a:
            failures.append({'p':p,'selected':str(a),'smaller':str(H[i]),'other_point':rational_dump(H),'dual':dc});break
        if dc.get('valid') and Fraction(*dc['value'])>=a:certs.append({'p':p,'value':str(a),'dual':dc})
        else:unknown.append({'p':p,'selected':str(a)})
    out['a_least']={'certificates':certs,'failures':failures,'unresolved':unknown,'proved':not failures and not unknown}
    print('a least',out['a_least']['proved'],'fails',[(r['p'],r['selected'],r['smaller'])for r in failures],flush=True)
    zero=[R[j] for p,j in M['ids'].items() if not F.get(p,0)];out['a_support_dimension']=S['dimension']-(sp.Matrix(zero).rank() if zero else 0)
    # Add the explicit standard-product upper bounds for original a/q only.
    from scipy.sparse import vstack,hstack,coo_matrix
    ds=acyclic_dimension(B,g)[0];upper=[]
    for key in M['columns'][:base_count]:
        if key[0]=='a':u=math.prod(math.comb(ds[i],p) for i,p in enumerate(key[1]))
        else:
            _,k,off,s,d=key;p=off[:k]+(0,)+off[k:]
            u=math.comb(ds[k]-d,s)*math.prod(math.comb(ds[i],p[i]) for i in range(len(ds)) if i!=k)
        upper.append(u)
    N=dict(M);old=M['A'].shape[1]
    X=coo_matrix((np.ones(base_count*2),(np.r_[np.arange(base_count),np.arange(base_count)],np.r_[np.arange(base_count),old+np.arange(base_count)])),shape=(base_count,old+base_count))
    N['A']=vstack([hstack([M['A'],coo_matrix((M['A'].shape[0],base_count))]),X]).tocsc();N['b']=np.r_[M['b'],np.array(upper)];N['c']=np.r_[M['c'],np.zeros(base_count)]
    qidx=data['failures'][0]['column'];cost=np.zeros(N['A'].shape[1]);cost[qidx]=1;N['c']=cost
    lp=linprog(cost,A_eq=N['A'],b_eq=N['b'],bounds=(0,None),method='highs');v=exact_vector(N,lp.x);dc=finite_dual(N,lp.eqlin.marginals) if lp.x is not None else {}
    out['bounded_q_test']={'column':M['columns'][qidx],'selected':data['failures'][0]['selected'],'exact_value':None if v is None else str(v[qidx]),'dual':dc}
    if v is not None:out['bounded_q_test']['witness']=rational_dump(v)
    print('bounded q',out['bounded_q_test']['selected'],'to',out['bounded_q_test']['exact_value'],flush=True)
    out['source_sections']=scalar_sections(B,g,F);out['neighbor_sections']=[]
    (folder/'pair_completion_analysis.json').write_text(json.dumps(out,indent=2))
    for k in range(len(g)):
        state,err=mutate(B,g,F,k)
        if err:raise ArithmeticError(err)
        r=scalar_sections(*state);r['k']=k;out['neighbor_sections'].append(r)
        print('neighbor',k,'negative',len(r['negatives']),'first',r['negatives'][:3],flush=True)
        (folder/'pair_completion_analysis.json').write_text(json.dumps(out,indent=2))


if __name__=='__main__':main()
