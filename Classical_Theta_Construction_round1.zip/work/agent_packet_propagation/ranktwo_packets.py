#!/usr/bin/env python3
"""Exact all-pair greedy-section cone, using only rank-two integer recurrence.

Every two-coordinate section is expanded by unitriangular subtraction in
shifted rank-two greedy polynomials. Rows are transported symbolically on the
whole finite U-space; a zero row is discarded only after exact verification.
There is no degree truncation. A resource cap raises an exception.
"""
from commuting_packets import *
from itertools import combinations
from functools import lru_cache
sys.path.insert(0,str(ROOT/'agent_division'))
from rank2_saturation_check import llz_F


@lru_cache(None)
def greedy(b,c,h):
    F,_=llz_F(b,c,h)
    if F.get((0,0))!=1 or any(v<0 for v in F.values()):raise ArithmeticError('invalid rank-two positive recurrence')
    return F


def dict_add(a,b,mult):
    out=dict(a)
    for i,v in b.items():
        out[i]=out.get(i,0)+mult*v
        if not out[i]:del out[i]
    return out


def section_rows(B,g,Frows,step_cap=20000):
    """Yield every greedy coefficient row without introducing chart variables."""
    n=len(g);width=len(next(iter(Frows.values())));out=[];sections=0;max_steps=0
    for pair in combinations(range(n),2):
        I=pair if B[pair[0]][pair[1]]>=0 else tuple(reversed(pair));outside=tuple(j for j in range(n) if j not in I)
        b,c=B[I[0]][I[1]],-B[I[1]][I[0]];fibres=defaultdict(dict)
        for p,row in Frows.items():
            if any(row):fibres[tuple(p[j] for j in outside)][tuple(p[i] for i in I)]=row
        for off,remainder in fibres.items():
            sections+=1;steps=0;h=tuple(g[i]+sum(B[i][j]*a for j,a in zip(outside,off)) for i in I)
            while remainder:
                if steps>=step_cap:raise OverflowError('symbolic greedy section step cap')
                steps+=1;q=min(remainder,key=lambda p:(sum(p),p));row=remainder[q];label=(h[0]+b*q[1],h[1]-c*q[0])
                out.append((('qrank2',I,off,q,label),row))
                for p,value in greedy(b,c,label).items():
                    r=(p[0]+q[0],p[1]+q[1]);new=add(remainder.get(r,(0,)*width),row,-value)
                    if any(new):remainder[r]=new
                    elif r in remainder:del remainder[r]
            max_steps=max(max_steps,steps)
    return out,{'sections':sections,'coefficient_rows':len(out),'max_steps':max_steps}


def augment(B,g,C,M,R,step_cap=20000):
    n=len(g);width=len(R[0]);new=[];new_rows=[];section_count=0;max_steps=0
    for pair in combinations(range(n),2):
        I=pair if B[pair[0]][pair[1]]>=0 else tuple(reversed(pair))
        b,c=B[I[0]][I[1]],-B[I[1]][I[0]]
        if b<0 or c<0:raise ArithmeticError('pair was not reoriented positively')
        outside=tuple(j for j in range(n) if j not in I);fibres=defaultdict(dict)
        for p,j in M['ids'].items():
            if not any(R[j]):continue
            off=tuple(p[k] for k in outside);q=tuple(p[k] for k in I)
            fibres[off][q]=(R[j],{j:1})
        for off,remainder in fibres.items():
            h=tuple(g[i]+sum(B[i][j]*v for j,v in zip(outside,off)) for i in I)
            section_count+=1;steps=0
            while remainder:
                if steps>=step_cap:raise OverflowError('exact two-section expansion step cap')
                steps+=1;q=min(remainder,key=lambda p:(sum(p),p));row,raw=remainder[q]
                label=(h[0]+b*q[1],h[1]-c*q[0]);G=greedy(b,c,label)
                new.append({'key':('qrank2',I,off,q,label),'raw':raw});new_rows.append(row)
                for p,value in G.items():
                    r=(p[0]+q[0],p[1]+q[1]);rr,ww=remainder.get(r,((0,)*width,{}))
                    rr=add(rr,row,-value);ww=dict_add(ww,raw,-value)
                    if any(rr):remainder[r]=(rr,ww)
                    elif r in remainder:del remainder[r]
            max_steps=max(max_steps,steps)
    old_count=len(M['columns']);nc=len(new);rr=[];cc=[];vv=[]
    for t,q in enumerate(new):
        rr.append(t);cc.append(old_count+t);vv.append(1)
        for j,w in q['raw'].items():
            if abs(w)>=2**53:raise OverflowError('integer entry exceeds exact float representation')
            rr.append(t);cc.append(j);vv.append(-w)
    extra=coo_matrix((vv,(rr,cc)),shape=(nc,old_count+nc)).tocsc()
    A=vstack([hstack([M['A'],coo_matrix((M['A'].shape[0],nc))]),extra]).tocsc()
    N=dict(M);N['A']=A;N['b']=np.r_[M['b'],np.zeros(nc)];N['c']=np.r_[M['c'],np.zeros(nc)]
    N['columns']=list(M['columns'])+[q['key'] for q in new]
    return N,list(R)+new_rows,{'sections':section_count,'new_coordinates':nc,'max_expansion_steps':max_steps,
                             'identities':[{'key':q['key'],'raw':[[j,w] for j,w in q['raw'].items()]} for q in new]}
