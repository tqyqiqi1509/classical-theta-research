#!/usr/bin/env python3
"""Scale coupled imaginary directions to stress the two-chart leastness bridge."""
from edge_least_bridge import *
from minimum_covariance import minimality_certificate

def main():
    folder=Path(__file__).parent;out=[];tic=time.time()
    patterns=[[[0,3,3],[-3,0,3],[-3,-3,0]],
              [[0,0,3],[0,0,3],[-3,-3,0]],
              [[0,3,0],[-3,0,3],[0,-3,0]]]
    for B in patterns:
      for N in [5,6,7]:
        d=(N,)*len(B);g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j]for j in range(len(B)))for i in range(len(B)))
        C=carrier(B,d,cap=2000);P,mc=minimality_certificate(B,g,C)
        r=test_edge_least(B,g,P,seconds=20);r['minimality_certificate']=mc;r['d']=d;out.append(r)
        summary=[(e['k'],len(e['least_certificates']),len(e['unverified_or_strict_lower']))for e in r['edges']]
        print('B',B,'N',N,'mass',r['minimum'].get('mass'),'space',mc.get('space'),'edges',summary,flush=True)
        (folder/'scaled_edge_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))
        if any(e['unverified_or_strict_lower']for e in r['edges']):
            print('EDGE BRIDGE REQUIRES CORRECTION',flush=True);return
    print('seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
