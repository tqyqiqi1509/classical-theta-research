#!/usr/bin/env python3
"""Exact tangent-ray polynomials for positive-torus comparison certificates."""
from large_origin_complete import *
import signal
sys.path.insert(0,str(ROOT/'agent_interior'))
from positive_circuits import double_description,primitive


def deadline(signum,frame):raise TimeoutError('tangent enumeration wall-time cap')


def main():
    folder=Path(__file__).parent;src=json.loads((folder/'large_origin_exact_failure_2.json').read_text());candidate=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    B,g,C=src['B'],src['g'],src['carrier'];M,R,S=build_logic(B,g,C)[:3]
    from commuting_packets import augment as ca
    from ranktwo_packets import augment as pa
    M,R,_=ca(B,g,C,M,R);M,R,_=pa(B,g,C,M,R)
    v=[sp.Rational(*a) for a in candidate['mass_minimum_full_packet_point']];origin=M['ids'][(0,)*len(g)]
    if len(v)!=len(R):raise ArithmeticError('coordinate replay mismatch')
    K=sp.Matrix([R[origin]]).nullspace();N=sp.Matrix.hstack(*K);T=sp.Matrix(R)*N
    active=[i for i,a in enumerate(v) if a==0];A=T[active,:]
    pivots=A.T.rref()[1];dimension=N.cols
    if len(pivots)!=dimension:raise ArithmeticError('candidate is not a vertex')
    refs=[active[i] for i in pivots];P=T[refs,:].inv();forms=T*P
    rows=[]
    for i in active:
        row=list(forms.row(i));den=sp.ilcm(*[a.q for a in row]);rows.append(primitive([int(a*den) for a in row]))
    print('dimension',dimension,'active',len(active),'distinct',len(set(rows)),'basis',len(refs),flush=True)
    tic=time.time();signal.signal(signal.SIGALRM,deadline);signal.alarm(55)
    try:rays,steps=double_description(rows,dimension,ray_cap=10000)
    except (TimeoutError,OverflowError) as e:
        signal.alarm(0);out={'B':B,'g':g,'dimension':dimension,'active_constraints':len(active),'resource_cut':str(e),'seconds':time.time()-tic}
        (folder/'pair_tangent_circuits_results.json').write_text(json.dumps(out,indent=2));print(out,flush=True);return
    finally:signal.alarm(0)
    results=[]
    for ri,ray in enumerate(rays):
        vals=forms*sp.Matrix(ray)
        if vals[origin]!=0 or any(vals[i]<0 for i in active):raise ArithmeticError('invalid tangent direction')
        zero=[rows[j] for j,i in enumerate(active) if vals[i]==0]
        if sp.Matrix(zero).rank()!=dimension-1:raise ArithmeticError('not an extreme tangent ray')
        av=[vals[j] for p,j in M['ids'].items()];den=sp.ilcm(*[a.q for a in av]);iv=[int(a*den) for a in av];gcd=math.gcd(*iv);iv=[a//gcd for a in iv]
        poly={p:a for p,a in zip(M['ids'],iv) if a};neg=[p for p,a in poly.items() if a<0]
        results.append({'ray_index':ri,'parameter_ray':ray,'coefficient_polynomial':[{'p':p,'a':a} for p,a in poly.items()],
                        'terms':len(poly),'negative_terms':len(neg),'mass':sum(poly.values())})
    out={'B':B,'g':g,'dimension':dimension,'active_constraints':len(active),'parameter_reference_columns':refs,
         'extreme_rays':len(rays),'complete_enumeration':True,'steps':steps,'rays':results,'seconds':time.time()-tic}
    (folder/'pair_tangent_circuits_results.json').write_text(json.dumps(out,indent=2));print('complete rays',len(rays),'seconds',time.time()-tic,flush=True)


if __name__=='__main__':main()
