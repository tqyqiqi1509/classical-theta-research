#!/usr/bin/env python3
"""Stress the structural row-cone question beyond small denominator vectors."""
from row_cones import *

def main():
    folder=Path(__file__).parent;tic=time.time();results=[];cases=[]
    for edge in [3,4,5]:
      for d in [(3,4),(4,4),(4,5),(5,5)]:
        cases.append(([[0,edge],[-edge,0]],d))
    for edges in [(3,1,1),(3,2,1),(3,3,3),(4,1,2)]:
      B=[[0,edges[0],edges[1]],[-edges[0],0,edges[2]],[-edges[1],-edges[2],0]]
      for d in [(3,3,3),(4,3,3),(3,4,4)]:cases.append((B,d))
    for n in [4,5]:
      for density in [0,1]:
        B=[[0]*n for _ in range(n)]
        for i in range(n):
          for j in range(i+1,n):
            a=3 if(i,j)==(0,1)else int(j==i+1 or density)
            B[i][j]=a;B[j][i]=-a
        cases.append((B,(3,)*n))
    for i,(B,d) in enumerate(cases):
        n=len(d);g=tuple(-d[j]+sum(max(-B[j][k],0)*d[k]for k in range(n))for j in range(n))
        C=carrier(B,d,cap=5000)
        F,S=divisibility_space(B,g,C['lattice_points'])
        FF,SS=divisibility_space(B,g,C['lattice_points'],C['vertices'])
        c={'B':B,'g':g,'d':d,'points':C['lattice_points'],'vertices':C['vertices'],'space':S}
        r=run_one(c,depth=4 if n<=3 else 3,cap=800)
        r.update({'case':i,'unrestricted_space':S,'vertex_space':SS,'points':C['lattice_points'],'vertices':C['vertices']})
        results.append(r)
        (folder/'large_carrier_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':results},indent=2))
        print(i,'d',d,'space',S,'fixedvertices',SS['dimension'],r['stats'],flush=True)
    print('seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
