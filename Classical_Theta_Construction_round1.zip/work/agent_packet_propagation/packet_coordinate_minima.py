#!/usr/bin/env python3
"""Test coefficientwise and packetwise leastness of a certified mass minimum."""
from linear_carrier import *
from schofield_carrier import solve_carrier_packets,finite_dual
from packet_minimum import packet_degree,exact_primal

def exact_vector(M,raw):
    if raw is None:return None
    x=[Fraction(float(a)).limit_denominator(1000000) for a in raw]
    if any(a<0 for a in x):return None
    A=M['A'].tocsr()
    for i,b in enumerate(M['b']):
        value=sum((Fraction(int(round(a)))*x[int(j)] for j,a in
          zip(A.indices[A.indptr[i]:A.indptr[i+1]],A.data[A.indptr[i]:A.indptr[i+1]])),Fraction(0))
        if value!=int(round(b)):return None
    return x

def full_coordinates(M,F):
    n=len(M['g']); qmap={}
    for k in range(n):
        fibers=defaultdict(dict)
        for p,a in F.items():fibers[p[:k]+p[k+1:]][p[k]]=a
        for off,row in fibers.items():
            d=packet_degree(M['B'],M['g'],k,off);q=[]
            for s in range(max(row)+1):
                q.append(row.get(s,0)-sum(math.comb(d,j)*q[s-j]for j in range(1,min(d,s)+1)))
                if q[-1]:qmap[k,off,s,d]=q[-1]
    return [F.get(key[1],0)if key[0]=='a'else qmap.get(tuple(key[1:]),0)for key in M['columns']]

def test(B,g,C,seconds=10):
    rep,F,M=solve_carrier_packets(B,g,C,seconds=seconds)
    if F is None:return {'minimum':rep}
    xx=full_coordinates(M,F);bad=[];certs=0;least_certificates=[]
    for i,a in enumerate(xx):
        if not a:continue
        cost=np.zeros(len(xx));cost[i]=1
        lp=linprog(cost,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':seconds})
        MM=dict(M);MM['c']=cost
        cert=finite_dual(MM,lp.eqlin.marginals)if lp.x is not None else {}
        if cert.get('valid')and Fraction(*cert['value'])>=a:
            certs+=1
            least_certificates.append({'column':i,'value':a,'dual_value':cert['value'],
                'lambda':[[j,z]for j,z in enumerate(cert['lambda'])if z[0]]})
            continue
        rational=exact_vector(M,lp.x)
        if rational is not None and rational[i]<a:
            bad.append({'column':M['columns'][i],'selected':a,'rational_smaller':[rational[i].numerator,rational[i].denominator],
                'rational_primal':[[j,[z.numerator,z.denominator]]for j,z in enumerate(rational)if z],
                'exact_lp_optimal':cert.get('valid')and rational[i]==Fraction(*cert['value']),
                'integer_witness':all(z.denominator==1 for z in rational),'dual':cert})
            continue
        H=exact_primal(M,lp.x)
        if H is None:bad.append({'column':M['columns'][i],'selected':a,'lp_fun':float(lp.fun)if lp.fun is not None else None,'unverified_witness':True});continue
        yy=full_coordinates(M,H)
        if yy[i]<a:
            bad.append({'column':M['columns'][i],'selected':a,'smaller':yy[i],'other_mass':sum(H.values()),'other_F':[[p,c]for p,c in sorted(H.items())],'dual':cert})
    return {'B':B,'g':g,'minimum':rep,'tested_positive_coordinates':sum(a>0 for a in xx),'exact_least_certificates':certs,
            'coordinate_dual_certificates':least_certificates,'failures':bad}

if __name__=='__main__':
    root=Path(__file__).parent;out=[]
    for B,d in [([[0,3],[-3,0]],(7,7)),([[0,3,3],[-3,0,3],[-3,-3,0]],(3,3,3)),
                ([[0,0,2,2],[0,0,2,2],[-2,-2,0,0],[-2,-2,0,0]],(2,2,2,2))]:
        n=len(d);g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j]for j in range(n))for i in range(n));C=carrier(B,d)
        r=test(B,g,C);out.append(r)
        print('rank',n,'d',d,'mass',r['minimum'].get('mass'),'tested',r['tested_positive_coordinates'],'certified',r['exact_least_certificates'],'failures',len(r['failures']),flush=True)
        for a in r['failures'][:4]:print({k:v for k,v in a.items()if k not in ['other_F','dual']},flush=True)
        (root/'packet_coordinate_minima_results.json').write_text(json.dumps(out,indent=2))
