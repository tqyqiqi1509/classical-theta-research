#!/usr/bin/env python3
"""Finite commuting-chart completion of all rank-two greedy section cones.

Each independent subset of the ORIGINAL exchange graph specifies one actual
commuting mutation chart. Transport the entire U basis, then impose every
rank-two greedy section there. This is a finite combinatorial rule; no theta
coefficients and no seed-depth truncation enter its definition.
"""
from large_origin_complete import *
from scipy.sparse import coo_matrix,hstack,vstack
from ranktwo_packets import section_rows


def primitive_row(row):
    d=math.gcd(*row)
    return tuple(a//d for a in row) if d else tuple(row)


def coefficient_references(M,R):
    width=len(R[0]);refs=[]
    for j in range(width):
        options=[i for p,i in M['ids'].items() if R[i][j] and sum(a!=0 for a in R[i])==1]
        if not options:raise ArithmeticError('nullspace basis lost its free coefficient reference')
        i=options[0];refs.append((i,R[i][j]))
    return refs


def augment(B,g,C,M,R,cap=12000):
    refs=coefficient_references(M,R);source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    seen={primitive_row(row) for row in R};new=[];chart_records=[];n=len(g)
    for mask in range(1,1<<n):
        I=tuple(i for i in range(n) if mask>>i&1)
        if not all(B[i][j]==0 for i in I for j in I):continue
        state=(B,g,source)
        for k in I:
            state,err=mutate_rows(*state,k,cap=cap)
            if err:raise OverflowError(('independent-chart exact transport',I,err))
        BB,gg,T=state;rows,info=section_rows(BB,gg,T);added=0
        candidates=[(('chart_a',I,p),row) for p,row in T.items()]
        candidates += [(('chart_rank2',I,key),row) for key,row in rows]
        for key,row in candidates:
            primitive=primitive_row(row)
            if primitive in seen:continue
            seen.add(primitive);new.append((key,row));added+=1
        chart_records.append({'independent_set':I,'B':BB,'g':gg,'coefficient_points':len(T),'new_inequalities':added,**info})
    old=len(M['columns']);nc=len(new);rr=[];cc=[];vv=[];identities=[]
    for t,(key,row) in enumerate(new):
        coeff=[Fraction(a,d) for a,(j,d) in zip(row,refs)];den=math.lcm(*(a.denominator for a in coeff))
        rr.append(t);cc.append(old+t);vv.append(den);raw=[]
        for a,(j,d) in zip(coeff,refs):
            if not a:continue
            w=int(a*den)
            if abs(w)>=2**53 or den>=2**53:raise OverflowError('transported row float representation cap')
            rr.append(t);cc.append(j);vv.append(-w);raw.append([j,w])
        identities.append({'key':key,'denominator':den,'raw':raw})
    extra=coo_matrix((vv,(rr,cc)),shape=(nc,old+nc)).tocsc()
    N=dict(M);N['A']=vstack([hstack([M['A'],coo_matrix((M['A'].shape[0],nc))]),extra]).tocsc()
    N['b']=np.r_[M['b'],np.zeros(nc)];N['c']=np.r_[M['c'],np.zeros(nc)];N['columns']=list(M['columns'])+[key for key,row in new]
    return N,list(R)+[row for key,row in new],{'charts':chart_records,'new_coordinates':nc,'identities':identities}


def main():
    folder=Path(__file__).parent;src=json.loads((folder/'large_origin_exact_failure_2.json').read_text());cand=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    B,g,C=src['B'],src['g'],src['carrier'];M,R,S=build_logic(B,g,C)[:3]
    from commuting_packets import augment as ca
    from ranktwo_packets import augment as pa
    M,R,_=ca(B,g,C,M,R);M,R,_=pa(B,g,C,M,R)
    tic=time.time();M,R,info=augment(B,g,C,M,R)
    F={tuple(z['p']):Fraction(z['a']) for z in cand['F']};refs=coefficient_references(M,R)
    params=[F.get(M['columns'][i][1],0)/d for i,d in refs];values=[sum(a*b for a,b in zip(row,params)) for row in R]
    bad=[{'column':i,'key':M['columns'][i],'value':str(a)} for i,a in enumerate(values) if a<0]
    out={'B':B,'g':g,'dimension':S['dimension'],'variables':len(R),'new_chart_info':info,'candidate_feasible':not bad,'negative_coordinates':bad,'seconds':time.time()-tic}
    (folder/'independent_chart_closure_results.json').write_text(json.dumps(out,indent=2))
    print('added',info['new_coordinates'],'total',len(R),'feasible',not bad,'seconds',time.time()-tic,flush=True)
    if bad:return
    # Exact tangent cone in the new finite chart system.
    sys.path.insert(0,str(ROOT/'agent_interior'))
    from positive_circuits import double_description,primitive
    origin=M['ids'][(0,)*len(g)];N=sp.Matrix.hstack(*sp.Matrix([R[origin]]).nullspace());T=sp.Matrix(R)*N
    active=[i for i,a in enumerate(values) if a==0];A=T[active,:];piv=A.T.rref()[1];dim=N.cols
    if len(piv)!=dim:raise ArithmeticError('candidate has a tangent line')
    ref=[active[i] for i in piv];forms=T*T[ref,:].inv();half=[]
    for i in active:
        row=list(forms.row(i));den=sp.ilcm(*[a.q for a in row]);half.append(primitive([int(a*den) for a in row]))
    rays,steps=double_description(half,dim,ray_cap=10000);records=[]
    for ri,ray in enumerate(rays):
        vv=forms*sp.Matrix(ray);zeros=[half[j] for j,i in enumerate(active) if vv[i]==0]
        if any(vv[i]<0 for i in active) or sp.Matrix(zeros).rank()!=dim-1:raise ArithmeticError('unverified tangent ray')
        aa=[vv[j] for p,j in M['ids'].items()];den=sp.ilcm(*[a.q for a in aa]);iv=[int(a*den) for a in aa];gd=math.gcd(*iv);iv=[a//gd for a in iv]
        records.append({'ray_index':ri,'parameter_ray':ray,'negative_a':sum(a<0 for a in iv),'coefficient_polynomial':[{'p':p,'a':a} for p,a in zip(M['ids'],iv) if a]})
    out.update({'tangent_dimension':dim,'tangent_rays':len(rays),'a_least_proved':all(r['negative_a']==0 for r in records),'tangent_ray_records':records,'dd_steps':steps,'seconds':time.time()-tic})
    (folder/'independent_chart_closure_results.json').write_text(json.dumps(out,indent=2));print('rays',len(rays),'a_least',out['a_least_proved'],'seconds',time.time()-tic,flush=True)


if __name__=='__main__':main()
