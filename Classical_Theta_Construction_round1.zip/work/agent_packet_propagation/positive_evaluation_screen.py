#!/usr/bin/env python3
"""Exact rational positive-torus evaluation objectives on an all-pair cone."""
from large_origin_complete import *
from functools import reduce


def main():
    folder=Path(__file__).parent;src=json.loads((folder/'large_origin_exact_failure_2.json').read_text());candidate=json.loads((folder/'pair_completion_fork_8_7_9.json').read_text())
    B,g,C=src['B'],src['g'],src['carrier'];logic=build_logic(B,g,C);M,R,S=logic[:3];origin=M['ids'][(0,)*len(g)]
    from commuting_packets import augment as ca
    from ranktwo_packets import augment as pa
    M,R,_=ca(B,g,C,M,R);M,R,_=pa(B,g,C,M,R)
    F={tuple(z['p']):Fraction(z['a']) for z in candidate['F']};out=[];tic=time.time()
    for z in product([Fraction(1,2),Fraction(1),Fraction(2),Fraction(3)],repeat=3):
        weights={p:math.prod(a**v for a,v in zip(z,p)) for p in M['ids']};den=math.lcm(*(a.denominator for a in weights.values()))
        iw={p:int(a*den) for p,a in weights.items()};gg=math.gcd(*iw.values());iw={p:a//gg for p,a in iw.items()}
        if max(iw.values())>=2**53:raise OverflowError('evaluation objective representation')
        cost=np.zeros(len(R));target=[0]*S['dimension'];selected=Fraction(0)
        for p,j in M['ids'].items():
            cost[j]=iw[p];selected+=iw[p]*F.get(p,0);target=[a+iw[p]*b for a,b in zip(target,R[j])]
        MM=dict(M);MM['c']=cost
        lp=linprog(cost,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':20})
        x=exact_vector(M,lp.x);dual=finite_dual(MM,lp.eqlin.marginals) if lp.x is not None else {}
        value=None if x is None else sum(iw[p]*x[j] for p,j in M['ids'].items())
        rec={'z':[str(a) for a in z],'scale':str(Fraction(den,gg)),'candidate_objective':str(selected),'exact_other_objective':None if value is None else str(value),'lp_status':int(lp.status)}
        if value is not None and value<selected:
            rec['failure']=True;rec['other_point']=rational_dump(x);rec['dual']=dual
            out.append(rec);(folder/'positive_evaluation_exact_failure.json').write_text(json.dumps({'B':B,'g':g,'carrier':C,'candidate':candidate['F'],'result':rec},indent=2))
            print('FAIL',rec['z'],selected,value,flush=True)
            break
        if dual.get('valid') and Fraction(*dual['value'])==selected:
            rec['candidate_optimal_certified']=True;rec['dual']=dual
        else:
            cert=exact_conic(tuple(a-selected*b for a,b in zip(target,R[origin])),R)
            rec['candidate_optimal_certified']=cert is not None
            if cert is not None:rec['positive_identity']=[[j,str(a)] for j,a in cert]
        out.append(rec)
        print(len(out),rec['z'],'certified',rec['candidate_optimal_certified'],flush=True)
        (folder/'positive_evaluation_screen_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))
    (folder/'positive_evaluation_screen_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))


if __name__=='__main__':main()
