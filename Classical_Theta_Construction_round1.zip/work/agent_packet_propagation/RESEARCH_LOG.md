# Packet positivity propagation research log

Session start: 2026-11-13 05:41 UTC. Classical cluster algebras only.

## 05:41–05:55 — scope and first correction

Read the mass/packet handoffs, the exact finite packet dual theorem, fixed-mass
cutting planes, the two-sided boundary recurrence, the finite signature theorem,
and the radical/squarefree handoff. The remaining target is an all-mutation
coefficient-positivity acceptance theorem; finite Laurent membership and
all-seed pointedness are not substituted for it.

Handelman/De Angelis–Tuncel was read directly through its theorem and proof.
The proposed bridge via positive multipliers is too weak: every initially
coefficient-positive Laurent function, after a subtraction-free cluster change,
is already a ratio P/Q with P,Q coefficient-positive. If the target expression
is Laurent, Q is a positive multiplier. Thus numerical positivity of all Newton
face polynomials and eventual multiplier positivity are already automatic;
they do not prove coefficient positivity after removing Q. Status: useful
boundary diagnosis, not a solution, no polynomial-positivity identification.

Primary source checked:
https://vdeangel.xula.edu/Publications/htheorem.pdf, theorem on p.1 and proof p.4.

Current constructive route: in an acyclic Schofield–Newton carrier, form the
exact rational vector space cut out by initial-star Laurent divisibility.
Transport an entire basis simultaneously by exact binomial division. Every
coefficient in every chart becomes an integer row on this finite vector space.
Seek a finite positive cone of rows that is closed by a general mutation rule.
Finite-depth stabilization alone will never be called an acceptance certificate.

New 2026 lead Fei2610.09868v2 was cross-checked against the previous local strong
audit. Monodromy character mutation is relevant to valued Newton carriers;
alternating monodromy traces and generic bases do not by themselves yield
coefficient or multiplication positivity. Acceptance agent was informed.

Searches on finite positivity tests and good/indecomposable elements did not
produce a theorem that good elements are atomic in the cluster atlas. Mandel's
atomicity is for the scattering atlas, a strictly different condition, so it
cannot be used as a missing cluster-atlas positivity theorem.

## 06:01–06:09 — finite rows, a genuine correction, and a stronger target

Twenty-minute literature refresh found Baker–Handelman, *Positive polynomials
and time dependent integer-valued random variables*, Canadian J.Math.44(1992),
3–41. Its theorem concerns multiplying a fixed signed polynomial by tails of
positive polynomial sequences. This remains a possible tail interface, but an
identification of actual mutation tails with such products is missing; no
positivity conclusion was imported. Source:
https://www.cambridge.org/core/services/aop-cambridge-core/content/view/B2FEE6EE34CB916486CD0A29B2F22376/S0008414X00010348a.pdf/positive_polynomials_and_time_dependent_integervalued_random_variables.pdf

Also read LLZ1303.5806 directly, Theorem1.3 and the following explanation. Its
positive nongreedy combination uses incomparable leading labels, so it does
not itself disprove a common pointed carrier criterion. It was used to choose
larger denominator vectors rather than to assert an unsupported implication.

The initial finite-row experiments were extended to larger dimensions and
multiple-source DAG topologies. In rank2 with B12=3,d=(7,7), a new two-step row
gave a genuine exact failure of whole-cone closure. The new inequality is

    a_(5,3)-a_(5,4)+a_(5,5)-a_(6,6) >= 0.

An integer source F with mass491 is positive in the entire initial star,
has all carrier vertices monic, and lies in the Newton-minimal triangle.
At word(1,2) in one-based indexing, its coefficient at (2,4) is-1. This was
checked using simultaneous coefficient rows and independently scalar exact
mutation. File: verified_newton_star_failure.json. This corrects the conjecture
that the *whole* initial-star positive cone automatically propagates.

It does not refute the minimum selector: the exact initial-star minimum in
that carrier is458, unique by zero-slack rank73/73, and equals the known LLZ
greedy polynomial coefficient by coefficient. Its four coefficients in the
new cut are all zero. File: ranktwo_minimum_vs_new_cut.json.

The stronger packet-coordinate observation is now the main route: in that
rank2 example all45 positive coefficient/packet coordinates of the minimum
are individually least, each with an exact dual certificate. A rank3 dense
acyclic example gives31/31 such certificates; a rank4 bipartite example gives
61/61. Thus their feasible packet polyhedra are translations of the homogeneous
nonnegative kernel cone by the least point. This is stronger than mass
minimality, but mutation covariance has not yet been proved. The fresh agent
interior_coefficients_sharpness is examining its general proof implications.

Numerical cone failures are not treated as nonmembership: large binomial rows
can defeat floating LP proposals. The field was renamed uncertified_conic_rows;
only an exact rational separating functional or an exact integer negative
witness establishes nonmembership. The verified rank2 failure has such a
witness. Routine failed proposals remain unresolved and are not mathematical
counterexamples.

## 06:09–06:21 — leastness and a failed covariance strengthening

On68 distinct rank3–5 carriers, exact source minima transported to243 computed
neighbor minima with complete coefficient agreement, no rational/integer gap,
and unique certified optima. Thirty target boxes exceeded the stated resource
cap. On56 nontrivial carriers, all6944 positive a/q coordinates of the chosen
minimum received exact individual lower-bound duals. These are finite data.

Initial-only positivity fails already in the rank2(7,7) triangle: its exact
rational minimum has mass339 with half-integral coefficients and negative
neighbor quotients, whereas the star least point has mass458.

A two-chart leastness hypothesis gives a short correct covariance lemma by
positive weighted evaluation under mutation. The hypothesis itself fails at
B upper-triangular entries3, d=(5,5,5): a full-star mass134 point has positive
coefficients10 that designated two-chart positive integer U elements can
reduce to0. These explicit mass184 witnesses are exact. The conditional
lemma is retained, the general hypothesis is rejected.

## 06:21–06:35 — positive circuits and audited cross-field interfaces

Proved the mandatory-support lemma and its equivalence to uniqueness of the
positive-origin extreme ray in a finite nonnegative kernel cone. Packet zero
propagation, augmented by exact proportional coefficient rows, constructs
all68 earlier least solutions with one final linear solve and no LP.
The first genuine incompleteness of this simple support logic is rank2
d=(7,8), g=(-7,13). A four-term positive linear identity forces a42>=15;
its exact integer certificate is retained. This is a cross-color circuit,
not a new unsupported positivity assumption.

Primary literature refresh:

* Bond–Levine, Abelian Networks I, primary Cornell PDF, read definitions2.1–2.2,
  the least-action framework, and the stated monotone-integer-program interface.
  https://pi.math.cornell.edu/~levine/abelian-networks-I-foundations.pdf
  Useful concept: locally commuting processors produce a least action rule.
  No local commutativity for packet repair has been proved, so the theorem is
  not imported. Its hypotheses cannot be inferred from order-independent
  bound tightening alone.
* Kimura–Makino, A Combinatorial Certifying Algorithm for Linear Programming
  Problems with Gainfree Leontief Substitution Systems, published24 January2026,
  primary https://link.springer.com/article/10.1007/s10479-026-07064-6.
  This round audited the definitions, theorem scope, and application boundary;
  the entire proof has NOT been independently checked. Leontief requires at
  most one positive entry per column, Horn its transpose, plus gainfree
  restrictions. The packet equalities have one positive a per row but repeat
  that a across colors; imposing both equality directions breaks the Horn
  inequality pattern. Status: useful adjacent interface, NOT a verified bridge,
  no conclusion used. No error in that paper is asserted.
* Adler–Cosares1991 strongly-polynomial special LP class was found through its
  Berkeley primary PDF. It concerns pre-Leontief structure. Abstract/interface
  only; unused as a theorem about packet cones.

The Boolean graph agent found two minimal fork shadow excesses. Independently
checked that both differences are genuine nonnegative origin-zero packet
vectors in every initial-star chart. The graph agent subsequently detached
them by finite neutral switches followed by component separation. This is
consistent with the unique-origin-circuit route; it is not yet a global proof.

## 06:35 onward — broadened origin-circuit failure discovery

At root's direction, shifted from the already-tested68 carriers to higher
d random rank3–5 acyclic matrices and stronger coupled topologies. The new
screen computes exact Schofield carriers, verifies forced vertex minimality,
then applies mandatory-support reconstruction. Every unresolved case is saved
for complete exact circuit enumeration by the interior-coefficients agent.
No failed sufficient screen is called a counterexample. The large-origin
screen records integrality and a-coefficient support rigidity separately.

## 06:39–06:55 — higher-d failure and genuine compatibility repair

Completed43 new rank3–5 carriers,5707 points,22785 coordinates, dimensions up
to148. Mandatory screening succeeded in9 and was unresolved in34. Exact
completion of the first two unresolved cases succeeded; the third produced
the rank3 fork d=(8,7,9),g=(-8,-7,29),arrows3,2 with unique fractional optimum
59030. Exact active zero rank56/57 and mass-optimal-face dimension1 exclude
numerical ambiguity. The missing compatibility is common-quotient positivity
for commuting colors: their double mutation has coefficient-15/2 although
all individual quotients are positive.

Implemented independent-set common binomial packets, then all-pair greedy
sections by whole-U unitriangular LLZ expansion. Both stronger cones have
integer minimum59085 in the hard fork, but still permit coefficient tradeoffs,
including a653=104->21. Source standard-product a/q bounds do not remove the
alternative q45->0 tradeoff. These failures identify genuine missing local
compatibility; they are not treated as failure of all possible constructions.

## 06:55–07:05 — pointwise correction and rank3 overlap certificate

Literature refresh opened primary arXiv1810.01614v2, Murray–Chandrasekaran–Wierman,
Newton Polytopes and Relative Entropy Optimization, and read Theorems5,9,11
and their scopes. SAGE extreme supports and special Newton/sign-pattern
equivalences are relevant interfaces, not universal polynomial-positivity
statements. A2016 author-PDF fetch failed502 and supplied no theorem. Sources:
https://arxiv.org/html/1810.01614v2 and https://arxiv.org/pdf/1810.01614.
No new2026 theorem was used in this refresh.

All64 positive evaluation objectives z_i in{1/2,1,2,3} have exact duals with
the same59085 minimum. A complete56-dimensional tangent enumeration then
corrected the pointwise conjecture:55 rays are coefficient-positive, one
ray D47=A-C is negative at(1,1,32). Thus the finite evaluation sample is not
an all-positive-point theorem. Parent's initial tradeoff SOS certificate is
still correct for that particular tradeoff, not all tangent directions.

Interior found a legal missing pair row after commuting source mutations.
Independent whole-U transport locates the same row after ONE mutation0:
pair(1,2),off2,shift(3,2),label(-3,5). Its exact tangent coordinate is t2-t47.
Since a good ray D2=B0+C, imposing this row replaces the bad direction by
D2+D47=A+B0, two positive Boolean-binomial blocks. This proves initial-a
leastness on the full enhanced finite cone. The general independent-chart
completion adds1013 distinct forms, and complete independent DD gives56 rays,
all initial-a nonnegative. RANK_THREE_OVERLAP.md gives the compact proof.

Actual one-neighbor reoptimization gives the same function in all3 charts;
two masses1690300 and24711 have exact duals. The third mass6586129065 has an
exact identical primal but unresolved dual recovery, explicitly not labeled
certified optimal. Parent asked this optional repair to stop at handoff.
