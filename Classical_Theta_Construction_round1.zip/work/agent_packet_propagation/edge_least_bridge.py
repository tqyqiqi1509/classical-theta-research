#!/usr/bin/env python3
"""Two-chart leastness: a strictly local route to minimum covariance."""
from packet_coordinate_minima import *

def test_edge_least(B,g,C,seconds=10):
    rep,F,M=solve_carrier_packets(B,g,C,seconds=seconds)
    if F is None:return {'minimum_failed':rep}
    xx=full_coordinates(M,F);out=[]
    for k in range(len(g)):
        free=[j for j,key in enumerate(M['columns'])if key[0]=='q'and key[1]!=k]
        free_set=set(free)
        bounds=[(None,None)if j in free_set else(0,None)for j in range(len(xx))]
        certs=[];failures=[]
        for i,a in enumerate(xx[:len(M['points'])]):
            if not a:continue
            cost=np.zeros(len(xx));cost[i]=1
            lp=linprog(cost,A_eq=M['A'],b_eq=M['b'],bounds=bounds,method='highs',options={'time_limit':seconds})
            MM=dict(M);MM['c']=cost
            cert=finite_dual(MM,lp.eqlin.marginals)if lp.x is not None else {}
            dual_ok=cert.get('valid')and free_set.issubset(set(cert.get('zero_slack_columns',[])))
            if dual_ok and Fraction(*cert['value'])>=a:
                certs.append({'coefficient':M['points'][i],'value':a,'lambda':[[j,z]for j,z in enumerate(cert['lambda'])if z[0]]})
            else:
                failures.append({'coefficient':M['points'][i],'selected':a,'lp_value':None if lp.fun is None else float(lp.fun),'dual_valid_for_free_variables':bool(dual_ok),
                    'dual_value':cert.get('value'),'raw_coordinates':None if lp.x is None else list(map(float,lp.x))})
        out.append({'k':k,'least_certificates':certs,'unverified_or_strict_lower':failures})
    return {'B':B,'g':g,'minimum':rep,'edges':out}

if __name__=='__main__':
    folder=Path(__file__).parent;out=[]
    for B,d in [([[0,3],[-3,0]],(7,7)),([[0,3,3],[-3,0,3],[-3,-3,0]],(3,3,3)),
                ([[0,0,2,2],[0,0,2,2],[-2,-2,0,0],[-2,-2,0,0]],(2,2,2,2))]:
        n=len(d);g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j]for j in range(n))for i in range(n));C=carrier(B,d)
        r=test_edge_least(B,g,C);out.append(r)
        print('rank',n,'mass',r['minimum']['mass'],[(x['k'],len(x['least_certificates']),len(x['unverified_or_strict_lower']))for x in r['edges']],flush=True)
        (folder/'edge_least_results.json').write_text(json.dumps(out,indent=2))
