#!/usr/bin/env python3
"""Large exact Newton-carrier origin-circuit screen.

No positivity conclusion is extrapolated from the finite sample. A failed
mandatory-support reconstruction is unresolved, not a counterexample. This
program writes every unresolved carrier for complete circuit enumeration.
"""
from mandatory_support import *
from schofield_carrier import Schofield, exact_barycentric, exact_separator
from theta_newton_pruning import exact_vertices, prune


def faster_carrier(B,d,cap=12000):
    if math.prod(a+1 for a in d)>cap:raise OverflowError('raw Schofield box cap')
    tic=time.time();sc=Schofield(B);S=sc.sub(tuple(d))
    V,certs=exact_vertices(S);points=[];inside=[];outside=[]
    # Every proposed convex-hull vertex and every lattice membership is checked
    # rationally. Qhull supplies proposals only; no floating hull is trusted.
    for p in product(*(range(a+1) for a in d)):
        cert=exact_barycentric(p,V)
        if cert is not None:points.append(list(p));inside.append({'p':p,'barycentric':cert})
        else:
            sep=exact_separator(p,V)
            if sep is None:raise ArithmeticError('unverified lattice classification')
            outside.append({'p':p,'normal':sep})
    return {'d':list(d),'vertices':[list(p) for p in V],'lattice_points':points,
            'generic_subdimensions':[list(p) for p in S],
            'vertex_certificates':certs,'inside_certificates':inside,
            'outside_certificates':outside,'euler_tests':sc.checks,
            'carrier_seconds':time.time()-tic}


def cases():
    rng=random.Random(61473519)
    explicit=[
      ([[0,3,2],[-3,0,3],[-2,-3,0]],(7,8,9)),
      ([[0,3,3],[-3,0,3],[-3,-3,0]],(9,9,9)),
      ([[0,0,3],[0,0,2],[-3,-2,0]],(8,7,9)),
      ([[0,3,2],[-3,0,0],[-2,0,0]],(9,8,7)),
      ([[0,2,0,2],[-2,0,3,0],[0,-3,0,1],[-2,0,-1,0]],(5,6,5,6)),
      ([[0,0,2,3],[0,0,3,2],[-2,-3,0,0],[-3,-2,0,0]],(5,6,5,6)),
      ([[0,2,1,0,1],[-2,0,0,3,0],[-1,0,0,2,1],[0,-3,-2,0,2],[-1,0,-1,-2,0]],(4,4,5,4,4)),
    ]
    for B,d in explicit:yield B,d
    for n,reps,choices in [(3,14,[6,7,8,9]),(4,12,[4,5,6]),(5,10,[3,4,5])]:
        for j in range(reps):
            B=[[0]*n for _ in range(n)]
            for a in range(n):
                for b in range(a+1,n):
                    w=rng.choice([0,1,2,3,4])
                    if b==a+1 and not w:w=rng.choice([1,2,3])
                    B[a][b]=w;B[b][a]=-w
            d=tuple(rng.choice(choices) for _ in range(n))
            yield B,d


def main():
    folder=Path(__file__).parent;tic=time.time();out=[]
    stats=defaultdict(int)
    for ci,(B,d) in enumerate(cases()):
        n=len(d);g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(n)) for i in range(n))
        print('start',ci,'rank',n,'d',d,flush=True);case_start=time.time()
        C=faster_carrier(B,d)
        if len(C['lattice_points'])>1800:
            out.append({'B':B,'g':g,'d':d,'resource_cut':'1800 lattice points','points':len(C['lattice_points'])});stats['resource_cuts']+=1;continue
        logic=build_logic(B,g,C);M,R,S=logic[:3];origin=M['ids'][(0,)*n]
        fixed=all(R[M['ids'][tuple(v)]]==R[origin] for v in C['vertices'])
        if not fixed:
            C=prune(B,g,points=C['lattice_points'],cap=12000);logic=build_logic(B,g,C)
        r=construct(B,g,C,logic=logic)
        r.update({'d':C['d'],'vertices':C['vertices'],'points':C['lattice_points'],
                  'all_vertices_forced_origin_before_pruning':fixed,
                  'seconds':time.time()-case_start,'carrier_seconds':C.get('carrier_seconds')})
        stats['cases']+=1;stats['points']+=len(C['lattice_points']);stats['variables']+=r['variables']
        if r['constructed']:
            stats['least_constructed']+=1
            if r['integer']:stats['integral_least']+=1
            else:stats['nonintegral_least']+=1
            F={tuple(p):Fraction(*a) for p,a in r['F']}
            rows=logic[1];zero_a=[rows[j] for j,key in enumerate(logic[0]['columns']) if key[0]=='a' and key[1] not in F]
            dim=logic[2]['dimension'];rank=sp.Matrix(zero_a).rank() if zero_a else 0
            r['coefficient_support_dimension']=dim-rank
            if dim-rank>1:stats['support_nonrigid']+=1
        else:
            stats['unresolved']+=1
            (folder/f'large_origin_unresolved_{ci}.json').write_text(json.dumps({'B':B,'g':g,'carrier':C,'screen':r},indent=2))
        out.append(r)
        (folder/'large_origin_screen_results.json').write_text(json.dumps({'seconds':time.time()-tic,'stats':dict(stats),'results':out},indent=2))
        print('end',ci,dict(stats),'dim',r['space']['dimension'],'seconds',r['seconds'],'mass',r.get('mass'),flush=True)
    print('finished',dict(stats),'seconds',time.time()-tic,flush=True)


if __name__=='__main__':main()
