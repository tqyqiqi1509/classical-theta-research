#!/usr/bin/env python3
"""Explore exact all-chart coefficient rows on fixed Newton carrier spaces.

Every implication is rationally verified. Depth stabilization is evidence only.
"""
from linear_carrier import *

def run_one(case,depth=4,cap=1600):
    B=case['B'];g=tuple(case['g']);n=len(g)
    F,space=divisibility_space(B,g,case['points'],case['vertices'])
    stats={'space':space,'states':0,'transitions':0,'resource_cuts':0,'unique_rows':0,
           'first_star_rows':0,'new_rows_per_depth':[0]*(depth+1),'uncertified_conic_rows':0}
    if space['dimension']==0:raise ArithmeticError('reference existence violated')
    if space['dimension']==1:return {'B':B,'g':g,'d':case['d'],'stats':stats,'trivial_space':True}
    row_words={};node_rows=[];seen=set();star=set();origin=F.get((0,)*n)
    queue=deque([(B,g,F,())])
    while queue:
        BB,gg,FF,w=queue.popleft()
        key=(tuple(map(tuple,BB)),gg,tuple(sorted(FF.items())))
        if key in seen:continue
        seen.add(key);stats['states']+=1
        for p,row in FF.items():
            r=primitive(row)
            if len(w)<=1:star.add(r)
            if r not in row_words:
                row_words[r]={'word':w,'p':p};stats['new_rows_per_depth'][len(w)]+=1
        if len(w)>=depth:continue
        for k in range(n):
            if w and k==w[-1]:continue
            state,err=mutate_rows(BB,gg,FF,k,cap)
            if err:stats['resource_cuts']+=1;continue
            stats['transitions']+=1;queue.append((*state,w+(k,)))
    stats['unique_rows']=len(row_words);stats['first_star_rows']=len(star)
    generators=sorted(star);new=[];certs=[]
    for r,where in row_words.items():
        cert=exact_conic(r,generators)
        if cert is None:
            stats['uncertified_conic_rows']+=1
            new.append({'row':r,**where});generators.append(r)
        else:
            certs.append({'row':r,'terms':[(i,[a.numerator,a.denominator]) for i,a in cert]})
    # Remove redundant rows from the final observed cone, with exact certificates.
    extreme=[]
    for i,r in enumerate(generators):
        others=generators[:i]+generators[i+1:]
        if exact_conic(r,others) is None:extreme.append({'row':r,**row_words[r]})
    stats['observed_extreme_rays']=len(extreme)
    return {'B':B,'g':g,'d':case['d'],'origin_row':origin,'stats':stats,
            'new_generators':new,'observed_extreme_rays':extreme,
            'conic_certificates':certs,'initial_star_rows':sorted(star)}

if __name__=='__main__':
    tic=time.time();folder=Path(__file__).parent
    cases=json.loads((folder/'carrier_space_census.json').read_text())
    out=[]
    for i,c in enumerate(cases):
        if c['space']['dimension']<2 or c['space']['dimension']>8:continue
        if len(c['g'])>4:continue
        r=run_one(c,depth=5,cap=1600);r['case_index']=i;out.append(r)
        (folder/'row_cones_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))
        print(i,r['stats'],flush=True)
    print('seconds',time.time()-tic,flush=True)
