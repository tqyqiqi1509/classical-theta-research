#!/usr/bin/env python3
"""Exact negative witnesses for rows; solver failure alone is never a witness."""
from row_cones import *
from scipy.optimize import milp,Bounds,LinearConstraint
from normalized_fibers import mutate

def separate(B,g,C,target,star,seconds=30):
    F,S=divisibility_space(B,g,C['lattice_points'],C['vertices']);m=S['dimension'];origin=F[(0,)*len(g)]
    mass=tuple(sum(row[j]for row in F.values())for j in range(m))
    A=np.array(list(star)+[target,origin],dtype=float)
    lower=np.r_[np.zeros(len(star)),-np.inf,1]
    upper=np.r_[np.full(len(star),np.inf),-1,1]
    lp=milp(np.array(mass,dtype=float),integrality=np.ones(m),bounds=Bounds(-np.inf,np.inf),
            constraints=LinearConstraint(A,lower,upper),options={'time_limit':seconds})
    if lp.x is None:return {'status':int(lp.status),'verified':False}
    x=tuple(int(round(a))for a in lp.x)
    dot=lambda a:sum(s*t for s,t in zip(a,x))
    if dot(origin)!=1 or dot(target)>-1 or any(dot(a)<0 for a in star):
        return {'status':int(lp.status),'verified':False,'rounding_failed':True}
    f={p:dot(a)for p,a in F.items()if dot(a)}
    if any(a<0 for a in f.values()):raise AssertionError('negative source')
    return {'status':int(lp.status),'verified':True,'coordinates':x,'mass':sum(f.values()),
            'negative_coefficient':dot(target),'F':[[p,a]for p,a in sorted(f.items())]}

if __name__=='__main__':
    folder=Path(__file__).parent
    data=json.loads((folder/'wide_ranktwo_rows.json').read_text())
    row=next(a for a in data if a['d']==[7,7]);B=row['B'];g=row['g'];C=carrier(B,row['d'])
    target=row['new_generators'][0]
    ans=separate(B,g,C,target['row'],row['initial_star_rows'])
    ans.update({'B':B,'g':g,'d':row['d'],'row_witness':target})
    if ans['verified']:
        FF={tuple(p):a for p,a in ans['F']}
        for k in range(2):
            state,err=mutate(B,g,FF,k)
            if err:raise AssertionError(err)
        state=(B,g,FF)
        for k in target['word']:
            state,err=mutate(*state,k,require_positive=False)
            if err:raise AssertionError(err)
        value=state[2].get(tuple(target['p']),0)
        if value!=ans['negative_coefficient']:raise AssertionError((value,ans['negative_coefficient']))
        ans['independent_scalar_transport_coefficient']=value
    (folder/'verified_newton_star_failure.json').write_text(json.dumps(ans,indent=2))
    print(json.dumps(ans,indent=2))
