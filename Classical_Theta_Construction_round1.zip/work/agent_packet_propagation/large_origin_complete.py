#!/usr/bin/env python3
"""Complete unresolved origin-support screens by exact positive identities.

Floating LP supplies proposals only. Every used primal, dual and cone identity
is checked over Q. A failure is decisive only with an exact mass-optimal point
and an exact feasible point lowering one of its coordinates.
"""
from large_origin_screen import *
from packet_coordinate_minima import exact_vector
from schofield_carrier import finite_dual


def rational_dump(v):return [[a.numerator,a.denominator] for a in v]


def run_case(c,commuting=False,pairwise=False):
    B,g=c['B'],c['g'];C={'d':c['d'],'vertices':c['vertices'],'lattice_points':c['points']}
    tic=time.time();logic=build_logic(B,g,C);M,R,S=logic[:3];origin=M['ids'][(0,)*len(g)]
    base_count=len(R);cube_info=None;pair_info=None
    if commuting:
        from commuting_packets import augment
        M,R,cube_info=augment(B,g,C,M,R)
    if pairwise:
        from ranktwo_packets import augment
        M,R,pair_info=augment(B,g,C,M,R)
    lp=linprog(M['c'],A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':25})
    x=exact_vector(M,lp.x);dual=finite_dual(M,lp.eqlin.marginals) if lp.x is not None else {}
    record={'B':B,'g':g,'d':c['d'],'points':len(C['lattice_points']),'space':S,'variables':len(R),'commuting_packets':cube_info,'ranktwo_packets':pair_info}
    mass=None if x is None else sum(x[i] for i,key in enumerate(M['columns']) if key[0]=='a')
    if x is None or not dual.get('valid') or Fraction(*dual['value'])!=mass:
        return {**record,'unresolved':'exact rational mass optimum unavailable','lp_status':int(lp.status)}
    record.update({'mass':str(mass),'mass_dual':dual,'mass_point_integral':all(a.denominator==1 for a in x)})
    certificates=[];positive=[i for i,a in enumerate(x) if a>0];failures=[];unknown=[];graph_count=0
    for i in positive:
        if i<base_count and origin in zero_closure([i],logic):graph_count+=1;continue
        c0=min(Fraction(1),x[i]);target=tuple(Fraction(a)-c0*b for a,b in zip(R[i],R[origin]))
        cert=exact_conic(target,R)
        if cert is not None:
            certificates.append({'column':i,'lower_bound':str(c0),'identity':[[j,str(a)] for j,a in cert]})
            continue
        cost=np.zeros(len(R));cost[i]=1
        q=linprog(cost,A_eq=M['A'],b_eq=M['b'],bounds=(0,None),method='highs',options={'time_limit':25})
        y=exact_vector(M,q.x);MM=dict(M);MM['c']=cost
        dc=finite_dual(MM,q.eqlin.marginals) if q.x is not None else {}
        if y is not None and y[i]<x[i]:
            failures.append({'column':i,'key':M['columns'][i],'selected':str(x[i]),'smaller':str(y[i]),
                             'smaller_point':rational_dump(y),'coordinate_dual':dc})
            break
        if dc.get('valid') and Fraction(*dc['value'])>0:
            certificates.append({'column':i,'lower_bound':str(Fraction(*dc['value'])),'dual':dc})
        else:unknown.append({'column':i,'key':M['columns'][i],'selected':str(x[i]),'lp_status':int(q.status)})
    record.update({'positive_coordinates':len(positive),'graph_mandatory':graph_count,
                   'positive_relation_certificates':certificates,'failures':failures,'unresolved_coordinates':unknown,
                   'origin_ray_uniqueness_proved':not failures and not unknown,
                   'seconds':time.time()-tic})
    F={p:x[j] for p,j in M['ids'].items() if x[j]}
    record['F']=[{'p':p,'a':str(a)} for p,a in F.items()]
    if failures:record['mass_minimum_full_packet_point']=rational_dump(x);record['carrier']=C
    if record['origin_ray_uniqueness_proved']:
        zero_a=[R[j] for j,key in enumerate(M['columns']) if key[0]=='a' and x[j]==0]
        record['a_support_space_dimension']=S['dimension']-(sp.Matrix(zero_a).rank() if zero_a else 0)
    return record


def main():
    folder=Path(__file__).parent;cases=json.loads((folder/'large_origin_screen_results.json').read_text())['results'];out=[];tic=time.time()
    for ci,c in enumerate(cases):
        if c.get('constructed'):continue
        if 'space' not in c:continue
        print('start',ci,'rank',len(c['g']),'dim',c['space']['dimension'],flush=True)
        r=run_case(c);r['source_index']=ci;out.append(r)
        print('end',ci,'unique',r.get('origin_ray_uniqueness_proved'),'mass',r.get('mass'),'integer',r.get('mass_point_integral'),'fails',len(r.get('failures',[])),'seconds',r.get('seconds'),flush=True)
        (folder/'large_origin_complete_results.json').write_text(json.dumps({'seconds':time.time()-tic,'results':out},indent=2))
        if r.get('failures') or r.get('origin_ray_uniqueness_proved') and not r.get('mass_point_integral'):
            (folder/f'large_origin_exact_failure_{ci}.json').write_text(json.dumps(r,indent=2))
            break


if __name__=='__main__':main()
