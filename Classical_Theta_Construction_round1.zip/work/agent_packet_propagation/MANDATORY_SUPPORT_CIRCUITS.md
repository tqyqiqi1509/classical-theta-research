# Mandatory support and the unique origin circuit

2026-11-13. General rational-cone theorem; application to classical finite
binomial packet systems. No theta coefficient is an input to the construction.

## 1. The exact finite packet cone

For each carrier point p introduce a coefficient a_p. For each direction k
and each admissible fiber start s introduce a quotient coefficient q_(k,eta,s).
The equations are

    a_(eta,t) = sum_s binom(d,t-s) q_(k,eta,s),
    d = max(0,-g_k-sum_(j != k)b_kj eta_j).

All a and q coordinates are nonnegative. Write their homogeneous equations
as Av=0, and let o be the coordinate a_0. The pointed section is v_o=1.
All statements below concern the rational cone K={v>=0:Av=0}. They hold for
classical skew-symmetrizable matrices as well as skew-symmetric matrices.
The existence/construction of an appropriate Newton carrier is a separate
input and is not silently inferred from an unproved valued Euler recursion.

## 2. Mandatory-support lemma

A coordinate i is mandatory if v_o>0 implies v_i>0 for every v in K.
Suppose F belongs to K, F_o=1, and every coordinate in supp(F) is mandatory.
Then F is the coordinatewise least point of K intersect {v_o=1}.

Proof. Let H be another normalized feasible point and set

    lambda = min_(i:F_i>0) H_i/F_i.

Mandatory support gives lambda>0. The origin ratio is1, so lambda<=1.
If lambda<1, then H-lambda F is nonnegative, belongs to ker A, has positive
origin1-lambda, and has a zero coordinate at a minimizer of the ratio.
This contradicts that coordinate's mandatory property. Hence lambda=1,
and H>=F in every coordinate. QED.

The origin coordinate must be included in the minimum. Omitting it would
invalidate the argument that the residual still has positive origin.

## 3. Equivalent positive-circuit statements

Assume the pointed section is nonempty. The following are equivalent:

1. It has a coordinatewise least point F.
2. K has exactly one extreme ray on which v_o>0.
3. It contains a normalized point supported entirely in mandatory coordinates.
4. K intersect {v_o=1} = F + (K intersect {v_o=0}) for some F.

Indeed, decomposition into extreme rays proves2=>4=>1; a least point is an
extreme point, and any other positive-origin extreme ray would decompose into
it plus a nonzero origin-zero point, proving1=>2. Leastness makes every positive
coordinate mandatory, and section2 proves3=>1. This is an equivalence for a
finite rational cone, not a theorem that all Newton-minimal packet cones
possess the property.

An extreme ray of {v>=0:Av=0} is a support-minimal nonzero nonnegative kernel
vector, hence a positive circuit of the column oriented matroid of A. Thus
the remaining existence question is concrete: is the origin contained in a
unique positive circuit for these particular Newton-minimal packet matrices?

Integrality is separate. The primitive integer ray must have origin coordinate1
for its normalized least point to be integral. No total-unimodularity claim is
made, and the existence of an integer pointed ambient product does not by
itself prove that every rational extreme point is integral.

## 4. A support algorithm using no optimization objective

The program mandatory_support.py forms an exact rational basis R of the
finite Laurent-divisibility space. Every a or q coordinate is an integer row
on this basis, after clearing denominators. It uses the following sound rules:

* A zero row is identically zero.
* Proportional nonzero rows have the same zero set.
* Opposite-sign proportional rows, both constrained nonnegative, are zero.
* In a_p=sum_j c_j q_j, with every c_j>0, a_p=0 iff every q_j=0.

For each coordinate i, temporarily set it to zero and close these rules.
If the origin is forced to zero, i is certified mandatory. Then set every
uncertified coordinate to zero and solve one exact rational linear system
with origin1. If its solution is nonnegative, section2 certifies that solution
as the least point. Integrality is checked coordinate by coordinate.

An unsuccessful reconstruction means these support rules are incomplete or
the least point does not exist; it is not classified as a counterexample.
The reconstruction succeeded on all68 previously generated rank3–5 carriers,
without a linear-programming call, in about7.7 seconds. These are finite
certified instances, not an all-rank theorem.

## 5. Completing the support logic by positive linear relations

If coordinate rows are r_i, a certificate

    r_i = c r_o + sum_j lambda_j r_j,   c>0, lambda_j>=0

proves i mandatory. Since the cone is rational polyhedral, mandatoryness is
equivalent to the existence of such a rational certificate: minimize v_i on
the nonempty section v_o=1; a finite attained minimum cannot be zero, and
finite-dimensional duality supplies the displayed identity. Equivalently,
one can enumerate positive circuits exactly, without treating a floating
optimization proposal as proof. Clearing denominators produces integer
weighted finite relations.

Using all such sign-compatible circuit relations makes the support test
complete. It does not establish that the resulting mandatory support carries
a feasible normalized point; that is exactly the unique-origin-ray question.

The first failure of the simpler zero rules occurs for
B=[[0,3],[-3,0]], g=(-7,13), d=(7,8), with37 carrier points and U-dimension10.
There are84 packet coordinates; simple propagation certifies47 mandatory
ones but their supported affine system is inconsistent. The missing short
identity is, with one-based color indices,

    a_(4,2) = 15 a_(0,0) + 2 a_(1,1) + 3 a_(6,6)
              + q_(1,eta=2,s=3,d=1)
              + q_(2,eta=5,s=2,d=2).

All rows and all four nonnegative integer weights are checked exactly in
ranktwo_positive_circuit_7_8.json. It gives the missing lower bound15 and
repairs the interval candidate of mass808 toward the true LLZ mass823.
Unlike a single-fiber zero rule, this relation couples the two colors.

## 6. Mutation boundary

A source-star least point is not automatically positive in every seed.
The whole source-star cone is known here not to propagate. Two-chart
leastness would imply covariance, but its universal hypothesis is also
false; see EDGE_LEASTNESS_COVARIANCE.md.

Thus neither the mandatory-support lemma nor finite circuit enumeration is
being called a theta construction. The remaining tasks are structural
uniqueness/integrality for these packet matrices and a mutation correspondence
for the primitive origin circuit, or another genuine all-seed positivity
argument. The graph agent's slot-matching component switches are a concrete
combinatorial interface to the first question.

## 7. Later decisive correction

General uniqueness/integrality of the positive-origin packet ray is FALSE,
even for a Newton-minimal carrier. The hard skew fork
B=[[0,0,3],[0,0,2],[-3,-2,0]],g=(-8,-7,29),d=(8,7,9) has252 carrier points
and U-dimension57. Its unique rational initial-star mass minimum is59030,
with coefficients15/4,45/4,5/2,... . Active zero rank56 and mass-optimal cone
face dimension1 are exact; an integer feasible competitor lowers a332 to0.
After commuting mutation word(0,1) a coefficient is-15/2. Thus separate
positive one-color quotients do not imply a positive common quotient.
Files: large_origin_exact_failure_2.json and
large_origin_failure_independent_verification.json.

The later successful mechanism uses rank2 greedy sections in neighboring
charts. It restores INITIAL a-coordinate leastness in this hard fork through
an exact positive integer overlap identity. It does not revive the false
original-cone theorem. Read RANK_THREE_OVERLAP.md and HANDOFF.md.
