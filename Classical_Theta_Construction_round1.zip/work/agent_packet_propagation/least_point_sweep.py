#!/usr/bin/env python3
"""General mechanism test: leastness, exact rational optima, integer witnesses."""
from packet_coordinate_minima import *
from minimum_covariance import minimality_certificate

def main():
    folder=Path(__file__).parent;tic=time.time();out=[];stats={'cases':0,'tested_coordinates':0,'certified_least_coordinates':0,'strict_tradeoffs':0,'unresolved':0}
    cases=[]
    for name in ['large_carrier_results.json','topology_cones_results.json']:
        cases.extend(json.loads((folder/name).read_text())['results'])
    seen=set()
    for i,c in enumerate(cases):
        B=c['B'];g=c['g'];key=(tuple(map(tuple,B)),tuple(g))
        if key in seen:continue
        seen.add(key)
        if len(g)<3:continue
        if c.get('unrestricted_space',c['stats']['space'])['dimension']<3:continue
        C={'d':c['d'],'vertices':c['vertices'],'lattice_points':c['points']}
        P,mincert=minimality_certificate(B,g,C)
        r=test(B,g,P,seconds=15);r['minimality_certificate']=mincert
        stats['cases']+=1
        stats['tested_coordinates']+=r.get('tested_positive_coordinates',0)
        stats['certified_least_coordinates']+=r.get('exact_least_certificates',0)
        stats['strict_tradeoffs']+=sum('rational_smaller'in x or 'smaller'in x for x in r.get('failures',[]))
        stats['unresolved']+=sum(x.get('unverified_witness',False)for x in r.get('failures',[]))
        out.append(r)
        (folder/'least_point_sweep_results.json').write_text(json.dumps({'stats':stats,'seconds':time.time()-tic,'results':out},indent=2))
        print(i,'rank',len(g),'mass',r['minimum'].get('mass'),'space',c.get('unrestricted_space',c['stats']['space'])['dimension'],stats,flush=True)
        if stats['strict_tradeoffs']:
            print('EXACT TRADEOFF',r['failures'],flush=True)
            break
    print(stats,'seconds',time.time()-tic,flush=True)

if __name__=='__main__':main()
