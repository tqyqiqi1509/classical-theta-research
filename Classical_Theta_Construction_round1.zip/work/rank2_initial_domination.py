"""Test a general proposed finite-cone mechanism against known rank-two theta.

Each test asks whether a shifted different greedy element is coefficientwise
bounded by a greedy element in the initial chart, then in the initial star.
This is a mechanism test, not a claimed all-rank criterion.
"""
from pathlib import Path
from functools import lru_cache
import sys,json,time
from itertools import product
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'agent_division'),str(ROOT/'agent_polytope')]
from rank2_saturation_check import llz_F

@lru_cache(None)
def poly(b,c,g):return llz_F(b,c,g)[0]

def run():
    started=time.time();out=[];tested=0;dom=[]
    for b,c in [(2,2),(3,3),(2,3),(3,2),(1,5)]:
        for a1,a2 in product(range(1,16),repeat=2):
            g=(-a1,c*a1-a2);F=poly(b,c,g)
            for q in F:
                if q==(0,0):continue
                h=(g[0]+b*q[1],g[1]-c*q[0]);H=poly(b,c,h)
                if len(H)>len(F):continue
                tested+=1
                shifted={(q[0]+r[0],q[1]+r[1]):v for r,v in H.items()}
                if not all(F.get(p,0)>=v for p,v in shifted.items()):continue
                candidate={p:v-shifted.get(p,0) for p,v in F.items() if v!=shifted.get(p,0)}
                dom.append({'b':b,'c':c,'g':g,'q':q,'h':h,'F':[[p,v] for p,v in F.items()],'Hshift':[[p,v]for p,v in shifted.items()]})
        print(b,c,'tested',tested,'dominations',len(dom),flush=True)
    data={'tested':tested,'dominations':dom,'seconds':time.time()-started,'scope':'Exact known LLZ coefficients; no mutation-depth truncation in the coefficientwise comparison.'}
    (ROOT/'rank2_initial_domination_results.json').write_text(json.dumps(data,indent=2))
    print({k:v for k,v in data.items()if k!='dominations'},'number',len(dom),flush=True)

if __name__=='__main__':run()
