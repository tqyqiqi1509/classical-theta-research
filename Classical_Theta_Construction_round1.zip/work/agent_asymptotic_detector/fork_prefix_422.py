from prefix_caps import *
sys.path[:0]=[str(ROOT/'agent_overlap_completion')]
from block_upper_caps import block_upper_caps
from cap_batch import build_logic,primitive,section_rows,propose_optimum,evaluate,atomic,exact_conic_scaled
from fractions import Fraction

def run(B,d,target):
    g=[-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(len(d))) for i in range(len(d))]
    P=list(product(*(range(a+1) for a in d)));tic=time.time()
    U,fam,_=block_upper_caps(B,d,P,graph=True)
    P=[p for p in P if U[p]]
    print('SUPPORT',d,len(P),'alloc',len(fam),time.time()-tic,flush=True)
    C={'kind':'full_graph_support','d':d,'vertices':[],'lattice_points':P}
    M,R,S=build_logic(B,g,C)[:3];origin=R[M['ids'][(0,)*len(d)]]
    source={p:R[i] for p,i in M['ids'].items() if any(R[i])}
    oi=next(j for j,a in enumerate(origin) if a)
    free=[p for p,row0 in source.items() if any(a*origin[oi]!=row0[oi]*b for a,b in zip(row0,origin))]
    print('AFFINE_FREE',min(map(sum,free)) if free else None,sorted(free,key=lambda p:(sum(p),p))[:8],flush=True)
    pair,_=section_rows(B,g,source)
    upper=[tuple(U[p]*x-y for x,y in zip(origin,R[i])) for p,i in M['ids'].items()]
    RR=list(dict.fromkeys(primitive(row) for row in R+upper+[r for key,r in pair] if any(row)))
    if target not in M['ids']:return {'status':'forced_zero','d':d,'g':g,'seconds':time.time()-tic}
    row=R[M['ids'][target]]
    lo=propose_optimum(row,RR,origin);hi=propose_optimum(tuple(-x for x in row),RR,origin)
    out={'B':B,'d':d,'g':g,'target':target,'carrier_points':len(P),'dimension':S['dimension'],
        'affine_first_free':sorted(free,key=lambda p:(sum(p),p))[:12],'rows':len(RR),'minimum':lo,'maximum_negative':hi,'seconds':time.time()-tic}
    if lo.get('parameters') and hi.get('parameters'):
        out['range']=[lo['value'],str(-Fraction(hi['value']))]
        for key,opt in [('lo',lo),('hi',hi)]:
            xx=list(map(Fraction,opt['parameters']));assert evaluate(origin,xx)==1
            assert all(evaluate(r,xx)>=0 for r in RR)
            out[key+'_polynomial']=[{'p':p,'a':str(evaluate(R[i],xx))} for p,i in M['ids'].items() if evaluate(R[i],xx)]
        out['status']='exact_prefix_freedom' if Fraction(lo['value'])!=-Fraction(hi['value']) else 'exact_prefix_fixed'
    else:
        import numpy as np
        from scipy.optimize import linprog
        A=-np.array(RR,dtype=float);A/=np.maximum(np.max(np.abs(A),axis=1),1)[:,None]
        vals=[]
        for sign in [1,-1]:
            cn=max(1,max(abs(x) for x in row));lp=linprog(np.array(row,dtype=float)*sign/cn,A_ub=A,b_ub=np.zeros(len(RR)),A_eq=[origin],b_eq=[1],bounds=(None,None),method='highs')
            vals.append(None if lp.fun is None else float(lp.fun)*cn*sign)
        out['numerical_range']=vals;out['status']='unresolved'
        if all(x is not None for x in vals) and abs(vals[0]-vals[1])<1e-5:
            vv=Fraction(vals[0]).limit_denominator(100000)
            delta=tuple(a-vv*b for a,b in zip(row,origin));cp=exact_conic_scaled(delta,RR);cm=exact_conic_scaled(tuple(-a for a in delta),RR)
            if cp is not None and cm is not None:
                out['status']='exact_fixed_by_duals';out['range']=[str(vv),str(vv)]
                out['double_dual']=[[[i,str(a)] for i,a in pp] for pp in [cp,cm]]
    out['constraint_data']={'origin':list(map(str,origin)),'target_row':list(map(str,row)),
       'rows':[list(map(str,r)) for r in RR]}

    return out

if __name__=='__main__':
 B=((0,0,3),(0,0,2),(-3,-2,0));results=[]
 for N in [1,2]:
    print('START',N,flush=True)
    r=run(B,[8*N,7*N,9*N],(4,2,2));r['scale']=N;results.append(r)
    atomic(Path(__file__).with_suffix('.json'),{'results':results})
    print('END',N,r['status'],r.get('range'),r.get('dimension'),r['seconds'],flush=True)
