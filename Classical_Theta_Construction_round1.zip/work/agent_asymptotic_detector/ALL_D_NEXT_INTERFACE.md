# Next interface: all symmetrizers, with the missing premise isolated

This is not an unconditional all-D theta theorem. The matrix algebra below
is exact. The absent input is a sufficiently strong quantum degree bound,
or an independent classical proof of Q_D support.

Let B be topologically ordered acyclic and D positive diagonal integral with
DB skew-symmetric. Set A=[-B]_+, C=I-A, and

    U=(D C)^T=D-A^T D,
    DB=U^T-U,
    g_d=-C d=-D^(-1) U^T d,
    V=C^(-1) B=U^(-T) DB,
    L=I-V=U^(-T) U,
    T=-L^(-1)=-U^(-1) U^T.

U^(-1) and U^(-T) are entrywise nonnegative. V and L are integral, det L=1,
so T is integral. L^T U=U^T and L^T U L=U. Define

    Q_D,d(p)=(d-p)^T U p
      =sum_i D_i p_i(d_i-p_i)
       -sum_(i<j) D_i B_ij(d_i-p_i)p_j.

The all-D torus phase identity in the main quadratic note proves that this
is the maximal exponent of the corresponding standard coefficient.

For h=g_d+B r with actual capacity decomposition h=v-C c and
 e=d-r-c, multiply by D to obtain

    U r=-D v-U^T e,
    r=-U^(-1)D v+T e<=T e.

Thus the same bounded far-layer argument works. For bounded r at large
 d=N a+s, c=d-Vr and sigma(r)=d+Lr. The same two-corner identities hold,
with lambda(r)=a^T U r=-u^T D r when u=-C a. All constants remain integers,
so the explicit threshold method survives after replacing U,V,L,T.

For the final finite-direction construction, the containing hyperplanes
are (Dq)^T m=0 for positive root increments q. Primitive wall normals may
be Dq divided by a positive gcd, which does not change the hyperplane.
With K fixed, use

    M>max(K max_i D_i, C_B),  C_B=max row-sum C^(-1),
    u=M(g+Bp)+ones.

The monomial-truncation bound becomes

    N> K max_i D_i (1+K max_ij |B_ij|).

Everything after Q_D support therefore has a natural all-D extension.

## Possible substitute for full quantum positivity

Full coefficientwise quantum positivity is stronger than the support proof
needs. Suppose one establishes, for this all-D quantization:

1. every nonzero normalized quantum theta Laurent coefficient has positive
   highest Laurent coefficient;
2. every nonzero structure coefficient in the standard product's theta
   expansion has positive highest Laurent coefficient;
3. the leading theta summand has coefficient1 and is bar invariant.

Then at a fixed torus monomial no maximal-degree contributions can cancel.
The degree of the leading theta coefficient is at most the standard degree
Q_D. Bar invariance gives Q_D<0 zero; Q_D=0 forces a constant, and the
standard endpoint coefficient1 gives a value at most1. This would supply
the classical support premise without full coefficientwise positivity.
Each of1–3 must actually be proved. In particular, positivity of leading
Laurent coefficients alone says nothing about the signs of the multiplication
structure coefficients.

A2026 candidate located but not audited is Qiyue Tang, 'Finite quantum theta
functions for skew-symmetrizable seeds', Hexagon2610.00201, with three
versions shown on the landing page https://hexagonmath.org/2610.00201v1 .
The abstract claims leading-coefficient positivity. Its exact scope,
proof, and whether it includes the necessary structure-coefficient statement
must be strongly audited before use. Nothing in the completed skew theorem
depends on this source.
