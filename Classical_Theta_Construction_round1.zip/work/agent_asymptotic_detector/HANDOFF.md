# Handoff: classical finite integer theta reconstruction

Branch /root/asymptotic_positive_detector, worked about08:36–09:17UTC,
2026-11-13. Parent requested context refresh after this mechanism closed.

## What is now proved

Read these three files in order:

1. CLASSICAL_QUADRATIC_CAP_FROM_POSITIVE_LIFT.md
2. GENERIC_LARGE_LABEL_PREFIX_RIGIDITY.md
3. FINITE_INTEGER_THETA_RECONSTRUCTION.md

Together they give a finite explicit integer weighted DAG algorithm for every
classical principal theta F-polynomial of an acyclic skew-symmetric exchange
matrix, in arbitrary rank. A supplied acyclic seed extends the construction
by ordinary mutation to the corresponding mutation-acyclic class.

The algorithm takes only B,g and integer combinatorial data. It never
constructs or queries a scattering diagram, wall function, broken line,
representation, or theta coefficient. Correctness comparison uses audited
DM quantum theta positivity to prove the classical Q support condition,
CMMM VIT to prove prefix rigidity, and the ordinary theta formalism only in
a final no-last-bend identification. No Li--Pan conclusion is used.

Root independently audited all three steps. The pieri_diamond_completion
agent independently audited the signed-cancellation prefix theorem; the
positive_inventory_exchange agent independently audited the complete final
substitution and extraction proof. Their audit records/tests are maintained
in their own branch directories.

## Central ideas

The standard-product coefficient has center-R and halfwidth S, so
Q=S-R<0 excludes a theta coefficient by bar symmetry and positivity.
The new support is strictly stronger than the complete old graph caps.

For a bounded correction root r, the origin and far-corner Q slopes are
lambda(r) and-lambda(r). The nontrivial cancellation step is finite:
Ur=-v-U^T e, U^-1>=0, where e measures distance from the far capacity corner.
So every summand able to cancel a bounded far layer has bounded r independent
of N. Maximizing lambda and then the far-corner partial order isolates it.
This proves large generic prefix uniqueness even among signed Laurent
solutions, with a fully explicit O_B(K^2+K||s||) threshold.

Large-label jets of theta_(Nu+e_i)/theta_(Nu) then give a root-filtered
leading-unit substitution. Inverting its finite unitriangular integer
matrix gives T. For target p choose u_p=M(g+Bp)+ones with explicit M.
The theta comparison proves

    a_0=1,  a_p=-sum_(q<p) T^(u_p,g)_(p,q) a_q.

Equivalently, put a directed edge q->p of integer weight
 -T^(u_p,g)_(p,q). The coefficient a_p is the sum of path weights from0 to p
in this finite acyclic graph. Weights may be negative; efficiency is not
claimed. This is the third class of combinatorial objects requested by the
user, rather than a promised positive matching count.

## Code and computation

- verify_phase_and_bounds.py/.json: direct literal quantum-torus bitword
  enumeration, independent of the charge DP;80 matrices,1203 root histogram
  comparisons,2367 literal bitwords,1000 exact two-corner tests all pass.
  All-D instances validate only algebra, not positive theta premises.
- wolfram_two_corner_verification.json: full symbolic rank-four Euler matrix
  with six independent entries checked by the Wolfram computation plugin;
  both matrix identities and the quadratic identity return zero.
- prefix_caps.py/.json: exact fast rank-two prefix routine,729 comparisons
  with full LLZ; used by the other branch for independent ratio tests.
- full_prefix_test.py/.json: earlier full support experiments; four scales
  completed, target111 uniquely16,30,54,84. These support the research route,
  not the general proof.
- fork_prefix_dual.py/.json: exact conic dual certificate fixing q221=6 at
  doubled fork capacity despite numerical primal reconstruction failure.
- fork_prefix_422.py/.json: old graph/pair cone exact range[0,40] at q422,
  subsequently eliminated by Q. Its scaled unresolved LP output is not a
  counterexample or theorem.

The pieri branch is implementing an independent rank-two test of the final
ratio/transport recurrence using LLZ probes. That tests the transport layer;
LLZ probes are not the oracle-free general algorithm itself.

## Limits and next task

Do not claim all skew-symmetric mutation-cyclic matrices or all-D theta
positivity. ALL_D_NEXT_INTERFACE.md gives the exact general-symmetrizer
Euler algebra and the remaining premise: Q_D support. It also isolates a
possible weaker sufficient quantum hypothesis, highest-coefficient positivity
of both theta coefficients AND standard-product structure coefficients.
A2026 Hexagon2610.00201 candidate claims some leading positivity, but only its
abstract has been located; no claim from it is accepted. Strong audit needed.

RESEARCH_LOG.md records successful and unsuccessful routes and source scope.
There is no need to repeat the failed Newton-only or naive stable-N=1 routes.
