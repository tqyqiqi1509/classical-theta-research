# Research and audit log: asymptotic detector branch

2026-11-13, approx.08:36–09:16 UTC. Parent retains the whole research workspace
and will include these files in the persistent final package.

## 08:36–08:56: stronger classical carriers and actual obstruction

Read root's Newton pruning, negative-frame carrier/freezing, source/sink
integer-orbit cutoff, prior asymptotic handoff, and graph capacity proofs.
The prior failure of stable evaluation at N=1 and single-seed ascent was
explicitly retained; neither was retried as a purported solution.

A rank-two exact Newton comparison shows Newton data alone permits fixed
small-root corrections along arbitrarily large labels: B12=3, d=N(8,9),
g=N(-8,15), shift q=(1,1), shifted capacity(8N-3,9N-6). The translated
triangle vertices are(1,1),(8N-2,1),(8N-2,9N-5), strictly inside the original
triangle for N>=1. An earlier message misstated the last y-coordinate as
9N-7; immediately corrected to9N-5 before use. This is a failure of Newton
alone, not a counterexample to strong-basis minimality.

Built exact rank-two prefix evaluation in prefix_caps.py, independently
checked729 parameter cases against full LLZ. Exploratory prefix LPs showed
apparent freedoms, but complete full-support star equations eliminated them
in several scaled rank-three examples. No floating LP output is promoted to
an exact theorem. The hard fork at q=(4,2,2) retained an exact old-cap range
[0,40] at N=1. Its new quadratic bound is Q=8-12N, hence genuine theta has
coefficient0 for every N>=1.

The direct principal compatible-form phase calculation produced
M_(d,p)(t)=t^(-R) product_i [d_i choose p_i]_t. With positive quantum theta
comparison this gives Q<0 zero, Q=0 coefficient<=1, and the symmetric charge
matching cap. The construction and all output coefficients remain classical.
The independent matching-cap implementation belongs to
work/agent_positive_inventory/charged_caps.py.

## 08:56–09:08: general rigidity mechanism

Found the two-corner Euler identities and the decisive thin-layer bound.
For a summand's origin r and far corner sigma(r)=r+c_r, write
 e=d-sigma(r). Then Ur=-v-U^T e gives r<=-U^(-1)U^T e.
This bounds every contributor near a fixed far corner independently of N.
Maximizing lambda(r)=a^TUr within that bounded contributor set, then taking
componentwise maximal far corner among ties, isolates a signed correction.
Q gives opposite asymptotic signs at the two corners, ruling it out.

The resulting generic-prefix theorem is fully written in
GENERIC_LARGE_LABEL_PREFIX_RIGIDITY.md. Root and a separate agent independently
checked the entire cancellation argument and the explicit threshold. A
suggestion that all root-difference lambda hyperplanes must also be excluded
was considered and resolved: componentwise maximality handles equal lambda,
so only original prefix positive-root hyperplanes need be excluded.

## 09:08–09:16: finite reconstruction closure

Large-prefix jets of theta_(Nu+e_i)/theta_(Nu) define leading-unit integer
coordinate substitutions. Directions u=M(g+Bp)+ones are chosen purely from
integer data. They avoid all degree<=K positive-normal hyperplanes and all
capacity-chamber boundaries, with explicit M. The finite hyperplane set
contains every possible relevant wall support, so a no-last-bend comparison
proves the inverse substitution kills the target nonleading coefficient.
This yields the exact unitriangular integer recurrence and a weighted finite
DAG, with no wall/chart input in the construction.

The complete proof is FINITE_INTEGER_THETA_RECONSTRUCTION.md. Root checked the complete proof independently; one other agent checked
the complete transport/extraction proof, and another audited the generic
prefix theorem and is testing the implementation. A separate rank-two ratio
implementation is being checked by the pieri_diamond_completion branch.
The present construction proves arbitrary acyclic skew-symmetric rank;
mutation-cyclic and unconditional all-D extensions are not claimed.

## Primary-source refresh and2026 audit record

- Davison--Mandel, arXiv:1910.12915v3, primary HTML read. Theorem1.1,
  §§1.2–1.3 and3.3 were checked for strong positivity, coefficient positivity,
  bar invariance, cluster-monomial inclusion and dequantization. Accepted in
  its stated skew-symmetric scope. It does not supply all-D positivity.
  Sources https://arxiv.org/html/1910.12915v3 and journal
  https://doi.org/10.1007/s00222-021-01061-1 .
- CMMM, arXiv:2505.09585v2, VIT/reciprocity: parent-audited input reused.
  Reciprocity controls valuations, not interior coefficients; no stronger
  unproved coefficient claim is used.
- Qiyue Tang, Hexagon2610.00025v3 (2026), 10-page primary PDF read in the
  relevant large-label and detector sections. Useful structural inspiration:
  large-label rigidity followed by monomial probes and target extraction.
  Its rank-two quantum theorem depends on the external companion
  theta=greedy/positivity claim; this branch does not use that theorem as an
  unconditional all-rank or classical premise. The classical arbitrary-basis
  specialization is invalid without the degree/bar hypothesis. Our Q theorem
  is proved directly from audited2021 skew theta positivity.
  Source https://hexagonmath.org/pdf/2610.00025v3 .
- Mandel, arXiv:1503.06183v5, trace pairing sections primary-read. Trace²/Trace³
  determine multiplication only once theta-indexed trace data are supplied;
  this is not a theta construction from known cluster-variable traces.
  Positivity of traces against positive Laurent multipliers follows already
  from initial Laurent positivity and does not detect basis positivity.
  No assumed mutable constant-term delta rule was used in the proof. The
  final no-last-bend lemma independently settles the relevant zero-terminal-
  mutable-velocity situation in the principal setting.
- Refresh around09:13 found Hexagon2610.00201 (three versions), 'Finite quantum
  theta functions for skew-symmetrizable seeds', claiming leading-coefficient
  positivity. Abstract only located; NOT accepted or used. Potential next
  interface: highest-coefficient positivity might suffice for the degree
  carrier even where full quantum positivity fails. Parent informed that a
  strong audit of both coefficients and structure constants is necessary.
- The same refresh found Gao's2024 thesis on quantum greedy/theta bases and
  finite-type positivity. Abstract does not prove general all-D positivity;
  not used. Search also confirms DM's explicit restriction to skew-symmetric
  input, so no accidental all-D scope extension is made.

## Independent computation record

verify_phase_and_bounds.py directly multiplies literal torus bitwords,
independently of the Gaussian DP used for comparison.80 acyclic matrices,
including nontrivial symmetrizers,1203 root coefficient histograms,2367 bitwords
all match the exact phase formula;1000 random exact two-corner matrix checks
passed. Nontrivial symmetrizers check algebra only. One initial test-harness
SymPy BooleanTrue conversion error was corrected; it was not a mathematical
failure. Data are in verify_phase_and_bounds.json.

Wolfram Language evaluator independently expanded the general symbolic
rank-four unitriangular Euler matrix (six independent arrow entries), and
returned zero for L^T U-U^T, L^T U L-U, and the full two-corner quadratic
identity. Exact code and response are in wolfram_two_corner_verification.json.
The Wolfram semantic-context lookup's scalar misinterpretation of a matrix
query was discarded; only the explicit matrix evaluator output is used.
