# Finite integer reconstruction of acyclic classical theta coefficients

2026-11-13. Status: the complete proof passed an independent root audit and a
separate complete transport/extraction audit on 2026-11-13. Another agent
independently audited the preceding generic-prefix theorem and is checking
the transport implementation. The construction below takes no scattering
diagram, wall function, broken line, representation, or theta coefficient as
input. Its correctness comparison uses the standard theta formalism, the
previously audited theta positivity/VIT inputs, and a last-bend observation
proved in Section 7.

**Scope:** arbitrary rank, acyclic skew-symmetric classical cluster algebras
with principal coefficients. It extends by ordinary cluster mutation to an
input supplied with an acyclic seed. No unconditional claim for arbitrary
skew-symmetrizable matrices or mutation-cyclic classes is made here.

## 1. Output and outline

For any integer mutable label g, the algorithm produces the full integer
polynomial F_g in

    theta_g=x^g F_g(z),  z_j=y_j product_i x_i^(B_ij).

Its only potentially very expensive step is a finite bounded search for
integer coefficient arrays satisfying elementary binomial equations. This
step can instead be performed with exact linear algebra whenever practical.
No efficiency claim is made.

The algorithm has four operations:

1. Determine the acyclic capacity box [0,d(g)].
2. For each required direction, compute finitely many large-label jets by
   the quadratic-carrier/binomial-equation algorithm.
3. Form leading-unit ratios and invert an integer unitriangular matrix.
4. Recover target coefficients by an explicit integer recurrence in total
   root degree.

## 2. Capacity decomposition and its finite chambers

Topologically order B so B_ij>=0 for i<j. Put A=[-B]_+, U=I-A^T. Compute

    d_i(g)=max(-g_i+sum_(j<i) A_ij d_j(g),0),
    v_i(g)=g_i+d_i(g)-sum_(j<i) A_ij d_j(g).

Then g=v-U^T d, d,v>=0, and d_i v_i=0. The independently proved standard
product majorant places F_g in [0,d]. Write

    K=sum_i d_i,     C_B=max_i sum_j (U^(-T))_ij.

If K=0, output F_g=1.

Every linear test defining a fixed active-capacity chamber has the form
q^T g, where q is a nonzero nonnegative integer vector and

    |q|_1<=C_B.                                           (1)

Indeed the capacity recursion only sums earlier tests with the nonnegative
weights A_ij. On a fixed active set, each q records sums of directed path
weights through that set; removing path restrictions bounds it componentwise
by a row of (I-A)^(-1)=U^(-T).

For a chamber-interior integer u, let I={i:d_i(u)>0}, a=d(u)_I. If I is
nonempty then every a_i>=1, and every inactive v_i(u)>=1. For
h in {0,e_1,...,e_n} and N>C_B, all vectors Nu+h have the same active set I.
To check this, use induction in the recursion: on every relevant fixed
linear piece, the nonzero integer value N q^T u has absolute value at least
N, while |q^T h|<=C_B.

Let B_I be the induced submatrix and U_I=I-[-B_I]_+^T. On this active set,

    d(Nu+h)_I=N a+s_h,   s_h=-U_I^(-T) h_I,
    (Nu+h)_I=-U_I^T(N a+s_h).                            (2)

All inactive capacities are0. Freezing/capacity invariance, independently
proved in the main project, identifies the full F-polynomial with the
principal F-polynomial for B_I and label (Nu+h)_I, using the same z_i for
i in I. This is an equality of coefficient polynomials; the outside x_j
are absorbed as frozen units. For I empty every such F-polynomial is1.

## 3. A finite oracle-free large-jet operation

The following subroutine is called Jet(B,u,h,K), simultaneously for
h=0,e_1,...,e_n. Require u to be an integer chamber-interior vector with

    q^T u !=0 for every q in N^n, 0<|q|_1<=K.             (3)

Find I,a,s_h as in (2). If I is empty return1. Otherwise apply the proved
GENERIC_LARGE_LABEL_PREFIX_RIGIDITY theorem to B_I,a,s_h,K. Its genericity
holds because a^T U_I q=-u_I^T q is nonzero by (3). Let N_rig be the maximum
of the explicit thresholds of that theorem over h=0,e_1,...,e_n. Take

    b_max=max_(i,j) |B_ij|,
    N>=max(N_rig, C_B+1, 1+K(1+K b_max)).                (4)

For each h, set c=N a+s_h and k=-U_I^T c. Enumerate integer arrays
(A_p) indexed by the finite box 0<=p<=c, subject to

    A_0=1,
    0<=A_p<=product_i binom(c_i,p_i),
    A_p=0 if Q_c(p)=(c-p)^T U_I p<0.                    (5)

Add the following entirely integer binomial equations. For each coordinate
i and fixed tuple p_hat_i, put

    m_i=k_i+sum_(j!=i) (B_I)_ij p_j.

If m_i<0, require the slice polynomial sum_t A_(p_hat_i,t) Z^t to be
divisible by (1+Z)^(-m_i). Equivalently, for 0<=r<-m_i require

    sum_(t>=r) (-1)^(t-r) binom(t,r) A_(p_hat_i,t)=0.     (6)

There are finitely many bounded integer arrays. At least one exists,
because the true theta polynomial satisfies (5)-(6). Every such array has
the same coefficients through total degree K, by the generic-prefix theorem
and the acyclic full-rank upper-bound equality. Choose the lexicographically
first array and return that common jet, with inactive variables absent.

This defines Jet by finite integer operations, without a theta oracle. The
standard binomial bound in (5) makes the search finite; no quantum quantity
is evaluated. Exact solution of the linear equations with the Q support
restriction computes the same uniquely determined jet and is preferable
in practice.

Denote the resulting polynomials, truncated through degree K, by

    P_h=Jet(B,u,h,K),      R_i=P_(e_i)/P_0 mod degree>K.

All P_h have constant coefficient1. Therefore the ratios have integer
coefficients and are computed by finite integer recursion.

## 4. Integer substitution and its inverse

Define, modulo root degree>K, a substitution

    psi_u(x_i)=x_i R_i(z),   psi_u(y_j)=y_j.

It sends

    psi_u(z_j)=z_j product_i R_i(z)^(B_ij),
    psi_u(x^g z^q)=x^g z^q product_i R_i(z)^(g_i+(Bq)_i). (7)

Every R_i is a leading-unit integer series. Any positive or negative integer
power is calculated using

    (1+H)^m=sum_(r=0)^K binom(m,r) H^r mod degree>K,

where H has zero constant term. The binomial coefficients are integers also
when m<0. This is a finite sum over ordered choices of nonzero root packets.

For the target box D=[0,d], form the integer matrix

    C^(u,g)_(p,q)
       =[z^(p-q)] product_i R_i(z)^(g_i+(Bq)_i)  if q<=p,
       =0 otherwise.                                     (8)

Order D by total degree, breaking ties arbitrarily. C is unitriangular.
Its inverse T^(u,g) is computed without division:

    T_(q,q)=1,
    T_(p,q)=-sum_(q<=r<p) C_(p,r) T_(r,q).                (9)

Equivalently, an entry is the signed sum of products of C-weights over all
strict chains from q to p. Thus (7)-(9) are explicit finite integer weighted
combinatorial operations. The inverse substitution tau_u has coefficient
matrix T on x^g times polynomials in the box. The box is a downward closed
set, so terms that leave it can never return under either substitution.

## 5. An explicit direction for every target coefficient

For each p in D put

    m_p=g+Bp,
    M=1+max(K,C_B),
    u_p=M m_p+(1,...,1).                                 (10)

For any nonzero q>=0 with |q|<=K,

    q^T u_p=M(q^T m_p)+|q|.

If q^T m_p is nonzero this has the same sign; if q^T m_p=0 it is positive.
Hence u_p satisfies (3). The same argument for the chamber test vectors in
(1) shows that u_p is in a capacity-chamber interior. No chamber enumeration,
scattering wall data, limiting real vector, or search for a generic point is
needed in the algorithm.

## 6. Final explicit coefficient recurrence

Set a_0=1. For p!=0 in increasing total degree, compute the integer matrix
row T^(u_p,g)_(p,q) from Sections 3-5 and set

    a_p=-sum_(q<p) T^(u_p,g)_(p,q) a_q.                 (11)

Here q<p means q<=p componentwise and q!=p. Output

    F_g(z)=sum_(p in D) a_p z^p.

There is also a direct finite directed-graph formulation. Use the lattice
points of D as vertices and, for every q<p, put a directed edge q->p of
integer weight

    w(q->p)=-T^(u_p,g)_(p,q).

The graph is acyclic because total degree strictly increases. Then a_p is
the sum of the products of edge weights over all directed paths from0 to p,
with the empty path at0 having weight1. This is the explicit recursively
weighted integer combinatorial object used by the construction.

All sums and all intermediate recursions are finite integer operations.
The weights in (9) and (11) may be signed. Their final values are nonnegative
because the comparison theorem below identifies the output with theta.
No claim that this already gives a cancellation-free positive matching
formula is made.

## 7. Comparison lemma: no possible final bend

This section is a correctness proof only; none of its geometric objects is
an input or intermediate step of the algorithm.

Use the principal full exponent lattice with a monomial written

    x^m y^r,        m,r in Z^n.

Every nontrivial theta increment is

    E q=(Bq,q),    q>=0, q!=0.

Write a wall normal in primitive form alpha>=0. Every nontrivial
monomial supplied by that wall has increment k E alpha with integer k>=1.
A wall capable of supplying a degree<=K increment therefore has
0<|alpha|<=K. Its support is contained in the central hyperplane
alpha^T m=0.
Consequently the finite hyperplane arrangement consisting of **all** such
q contains the support of every relevant wall, whether or not a hyperplane
actually carries a wall. This finite containing arrangement is enough.

Let Q be a generic comparison endpoint whose mutable component belongs to
an open cell of that arrangement. Let a proposed final full exponent have
mutable part m. Suppose for every such q, either q^T m=0 or q^T m has the
same sign as q^T Q. Then the backwards final ray has mutable part

    Q_mut+t m,  t>=0,

and never meets any relevant hyperplane: q^T Q+t q^T m stays nonzero with
its initial sign. Therefore no broken line of total increment degree<=K
with that final exponent can have a last nontrivial bend. The only possible
contribution is the unbent term, whose initial full exponent must equal its
final full exponent and whose coefficient is1.

If m=0, the same argument applies: the mutable part of the backwards ray
is constant and off every relevant hyperplane. The frozen part of its
velocity causes no problem, since all normals have zero frozen component.

### 7.1 Large monomial truncation with an explicit bound

Take Q in the open cell containing u. For h in {0,e_i} and |p|<=K, the
mutable part of a possible terminal exponent of theta_(Nu+h) is

    Nu+h+Bp.

For every 0<|q|<=K,

    |q^T(h+Bp)|<=K(1+K b_max).

Since the nonzero integer q^T u has absolute value at least1, (4) makes
Nu+h+Bp lie strictly in the same arrangement cell as u. Applying the
last-bend lemma to each possible p proves

    iota_Q(theta_(Nu+h))=x^(Nu+h)+terms of relative degree>K. (12)

No unknown wall coefficient, count, or location enters the bound.

### 7.2 Frozen variables are fixed

The full frozen exponent (0,e_j) pairs to zero with every normal (q,0).
Every wall transformation therefore fixes y_j. Equivalently y_j is its own
global theta monomial in every comparison chart. Thus iota_Q(y_j)=y_j.
This is why (7) transforms z_j exactly as displayed and does not introduce
an unaccounted frozen-coordinate factor.

### 7.3 The ratios are the inverse comparison transport

Both the initial and Q expansions are algebra homomorphisms into the
corresponding completed torus. By (12),

    iota_Q(theta_(Nu+e_i)/theta_(Nu))=x_i mod degree>K.

The initial expansion of the same ratio is x_i R_i(z), because the jets
P_h were calculated exactly by Section 3. Frozen variables are fixed.
Thus psi_u is, through degree K, the map from Q-coordinate monomials to
their initial-coordinate expressions, and tau_u=psi_u^(-1) is the inverse
transport. This proves the transformation claim without assuming that the
ratios stabilize for small N. The explicit single N in (4) suffices.

### 7.4 The coefficient recurrence equals theta

For target p, let the full final exponent be

    (g+Bp,p).

Take Q in the cell of u_p. Equation (10) makes the signs required by the
last-bend lemma agree with the mutable final exponent m_p=g+Bp. The total
increment of theta_g leading to this exponent is p, of degree<=K. Hence

    [x^g z^p] iota_Q(theta_g) = 1 if p=0, and0 if p!=0.   (13)

For p!=0, the initial full exponent (g,0) differs from (g+Bp,p), even if
Bp=0. So there is no unbent contribution. Formula (13), together with
Section 7.3, says that the genuine theta coefficients satisfy (11).
The matrix row is unitriangular and only depends on already computed
coefficients q<p. Induction therefore proves that the algorithm's output
is exactly F_g throughout D. The standard capacity bound proves that no
coefficient outside D is missing.

This also explains why the procedure can recover small finite-label
coefficients although naive evaluation at N=1 of stabilized large-label
coefficients can fail: it uses exact transport ratios and a fresh direction
for each target exponent, not such an evaluation.

## 8. Dependencies and limitations

The construction itself consists of the displayed finite integer data.
Its correctness requires:

- the acyclic standard-product carrier and capacity/freezing statements;
- acyclic full-rank upper-bound membership;
- the proved quadratic theta support bound in the skew-symmetric setting;
- the proved generic large-label prefix theorem, whose comparison uses
  valuative independence and finite theta expansions;
- the ordinary principal theta formalism for the no-last-bend comparison.

The last item is used to identify the independently specified integer
algorithm with theta, not to define its outputs. No theorem of Li--Pan is
used. The construction works in arbitrary acyclic rank, not by filling in
special cases. It is a finite signed integer recurrence, not yet a concise
positive set-counting formula. Its extension to genuinely mutation-cyclic
inputs and an unconditional all-skew-symmetrizable version remain open.
