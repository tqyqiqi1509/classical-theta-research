# Generic large-label prefix rigidity from a quadratic carrier

2026-11-13, 09:06 UTC. **Proved linear-algebra theorem, independently audited by root and a
second agent**, with its
comparison inputs stated explicitly. The application below is unconditional
for the audited acyclic skew-symmetric classical theta basis. It does not
assert that an arbitrary classical strongly positive basis satisfies the
quadratic carrier bound.

## 1. Setup and statement

Let B be an acyclic skew-symmetric integer matrix, topologically ordered so
B_ij>=0 for i<j. Put

    A=[-B]_+, U=I-A^T, B=U^T-U,
    V=U^(-T) B, L=I-V=U^(-T) U,
    T=-L^(-1)=-U^(-1) U^T.

All these matrices are integral; U and U^T are unitriangular, and
U^(-1), U^(-T) are entrywise nonnegative. For d>=0 define

    g_d=-U^T d,
    Q_d(p)=(d-p)^T U p.

Fix an integer a with every a_i>0, an arbitrary integer s, and a nonnegative
integer K. Assume the finite genericity condition

    lambda(q):=a^T U q != 0
    for every q in N^n with 0<|q|_1<=K.                    (G)

Set d(N)=N a+s and g(N)=-U^T d(N). There is an explicit N_0 depending only
on B,s,K, given in Section 6, with the following property. For N>=N_0,
any Laurent element

    f=x^g F(z), z_i=y_i x^(B e_i),

whose F is supported in

    C_d={p in Z^n: 0<=p<=d and Q_d(p)>=0},

and whose constant coefficient is1, has the **same coefficients as the
classical theta function theta_g at every |p|_1<=K**.

No positivity or integrality assumption on the coefficients of f is needed.
It suffices that f belong to the upper cluster algebra over a field of
characteristic zero. In the acyclic principal setup this membership is
certified by the initial chart and all its one-mutation neighbors, by the
full-rank acyclic upper-bound theorem already audited in the main project.
Thus the eventual prefix is computable by a finite rational linear system:
box carrier, the integer inequality Q>=0, origin coefficient1, and the
neighbor Laurent equations. The theorem is uniqueness of the prefix, not
uniqueness of the entire finite-label element.

## 2. Precisely stated comparison inputs

The proof uses the theta basis only for comparison, not in the algorithm.

1. Every homogeneous upper element has a finite expansion in frozen
   translates of theta functions.
2. Theta functions have valuative/Newton independence: the Newton polytope
   of every nonzero summand of a finite theta expansion is contained in
   the Newton polytope of the sum. This is the CMMM VIT input already
   audited for the project's finite Newton pruning theorem.
3. For every mutable label h, write its acyclic capacity decomposition

       h=v-U^T c,  v,c>=0, v_i c_i=0.

   Then theta_h=x^h F_h(z), F_h has constant coefficient1, is supported in
   the box [0,c], and has coefficient1 at c.
4. For canonical labels h=-U^T c with c>=0, the classical theta support
   satisfies Q_c>=0.

Input 3 follows from the ordinary standard-product majorant and elementary
Laurent divisibility. The product x^v product_i (x_i')^c_i has theta_h with
leading coefficient1 and nonnegative remaining terms, so F_h is in [0,c].
For the far corner, move from 0 to c in topological coordinate order. At
the slice with earlier coordinates c_j and later coordinates0, the mutable
exponent at i is v_i-c_i. If c_i>0 then v_i=0, and Laurentness in the i-th
neighbor forces the slice to be its constant term times (1+z_i)^c_i.
Starting with coefficient1 at0 proves coefficient1 at c. If c_i=0 no step
is needed.

Input 4 is proved in CLASSICAL_QUADRATIC_CAP_FROM_POSITIVE_LIFT.md by the
explicit standard-product phase formula plus Davison--Mandel positivity
and bar invariance. It is a statement about classical coefficients. That
comparison proof is currently audited for skew-symmetric B only.

## 3. Two algebraic identities

For a bounded root r and sufficiently large N, the capacity decomposition
of h_r=g+B r has v=0 and

    c_r=d-V r.

Its far corner, measured in the original F-coordinate, is

    sigma(r)=r+c_r=d+L r.                                 (1)

The identities L^T U=U^T and L^T U L=U imply

    Q_d(r)=d^T U r-r^T U r,
    Q_d(d+L r)=-d^T U r-r^T U r.                          (2)

Thus the two corners have opposite large-N slopes lambda(r) and
-lambda(r). The issue is signed cancellation among many theta summands;
Section 4 makes that cancellation local and finite.

## 4. Every near-far-corner contributor has a bounded root

Let H=F-F_theta and expand homogeneously

    x^g H(z)=sum_r b_r y^r theta_(g+B r).

After factoring x^g this is

    H(z)=sum_r b_r z^r F_(g+B r)(z).                     (3)

Only finitely many b_r are nonzero. If H=0 there is nothing to prove.
Valuative independence and the box support of H imply for every nonzero
summand

    r>=0, sigma(r):=r+c_r<=d.                            (4)

Here c_r is the actual capacity, which may initially have zeros. In
particular b_0=0, since the origin coefficient of H is0 and all other
summands start at nonzero r>=0.

Put e=d-sigma(r)>=0 and write h_r=v_r-U^T c_r. From
h_r=-U^T d+B r and c_r=d-e-r we obtain

    U r=-v_r-U^T e,
    r=-U^(-1)v_r+T e <= T e.                            (5)

The last inequality uses U^(-1)>=0. Therefore, whenever
sigma(r)>=d-C for a fixed C>=0,

    0<=r_i<=sum_j max(T_ij,0) C_j.                      (6)

This bound is independent of N, f, and the number of theta summands.
For N sufficiently large every such bounded r has c_r=d-Vr>0 and v_r=0,
so the exact affine formula (1) applies to all possible contributors.
This is the step that prevents an unbounded-root summand from cancelling
a fixed-root far corner.

## 5. Signed cancellation proof

First prove b_q=0 for all |q|_1<=K with lambda(q)<0, by induction on |q|_1.
The coefficient H_q is0 by Q_d(q)<0 for sufficiently large N. In (3),
only r<=q contribute. Contributions with lambda(r)<0 vanish by induction.
For all other r!=q, lambda(q-r)<0, so the coefficient at q-r of
F_(g+B r) vanishes by

    Q_(d-Vr)(q-r)=N lambda(q-r)+O(1)<0.

The term r=0 also has b_0=0. Thus H_q=b_q and b_q=0.

Now suppose b_q!=0 for some fixed |q|_1<=K with lambda(q)>0. For large N
its capacity is positive, so sigma(q)=d+Lq. Equation (4) gives Lq<=0.
Consider the finite nonempty set

    S={r: b_r!=0 and sigma(r)>=sigma(q)}.

By (6), with C=-Lq, every r in S lies in a fixed finite box independent
of N. Choose r_* in S maximizing lambda(r). Among equal maximizers,
choose one whose sigma(r) is maximal in the componentwise partial order.
Thus lambda(r_*)>=lambda(q)>0. Equation (2) gives

    Q_d(sigma(r_*))=-N lambda(r_*)+O(1)<0,

so H has coefficient0 at sigma(r_*).

Any summand in (3) contributing at sigma(r_*) must have
sigma(r)>=sigma(r_*)>=sigma(q), hence belongs to S. If r!=r_* and
lambda(r)=lambda(r_*), componentwise maximality excludes it. If
lambda(r)<lambda(r_*), put

    t=sigma(r)-sigma(r_*)=L(r-r_*)>=0.

The relevant coefficient of F_(g+B r) is its coefficient at c_r-t. Its
quadratic bound is

    Q_(c_r)(c_r-t)
       =t^T U(c_r-t)
       =N a^T U(r-r_*)+O(1)
       =N(lambda(r)-lambda(r_*))+O(1)<0.                 (7)

So that contribution is0. There is no contributor of larger lambda by
the choice of r_*. The only surviving contribution is b_(r_*) times the
far-corner coefficient1 of its theta function. It is nonzero, contradicting
the zero coefficient of H. This proves b_q=0 also when lambda(q)>0.

Under (G), every nonzero q of degree at most K has one of these two signs.
Consequently all those b_q vanish. In (3), a coefficient H_p with |p|<=K
only receives terms r<=p; hence every such coefficient H_p is0. This
proves prefix rigidity.

Notice that no genericity for differences r-r' is required. Equal lambda
values in the far-corner argument are removed by componentwise maximality.
The only excluded hyperplanes are the finitely many positive roots in (G).

## 6. A completely explicit uniform threshold

The following deliberately generous integer bound avoids all unknown theta
data and even avoids enumerating the possible signed summands. For K=0,
only the prescribed constant coefficient is asserted and take N_0 large
enough that d>=0. Suppose K>=1. All matrix absolute values below are
entrywise; maxima of vectors are entrywise unless marked as scalars.

Define

    C_i=K max_j max(-L_ij,0),
    R_i=max(K, sum_j max(T_ij,0) C_j),
    W_i=max(K, sum_j |L_ij| R_j),
    b_i=|s_i|+sum_j |V_ij| R_j.

These are nonnegative integers. Every small q of degree<=K lies in [0,R].
If Lq<=0, every contributor in its near-far-corner set also lies in [0,R]
by (6). Every relevant nonnegative difference t=L(r-r_*) lies in [0,W].
The vector b bounds the absolute value of s-Vr for every r in [0,R].

Set the following scalar integers:

    M_cap=max_i b_i,
    M_origin=sum_i (b_i+W_i) sum_j |U_ij| W_j,
    M_far=sum_i W_i sum_j |U_ij| (b_j+W_j),
    M_corner=sum_i (|s_i|+R_i) sum_j |U_ij| R_j,
    N_0=1+max(M_cap,M_origin,M_far,M_corner).

Because a_i>=1, N>=N_0 makes d-Vr strictly positive for every r in [0,R].
Every nonzero integer lambda slope has absolute value at least1. The
remaining three quantities bound all constant terms in the sign tests of
Sections 3 and 5; N>=N_0 therefore makes each required sign strict.
This proves the claimed explicit threshold.

For fixed B the bound is O_B(K^2+K||s||_1+||s||_1). It is not optimized.
If desired, the finite actual r,t sets yield much smaller exact thresholds.
Positive integral a satisfying (G) always exist: avoid finitely many
proper rational hyperplanes in the positive orthant. An elementary explicit
choice can be found by testing a=(1,M,...,M^(n-1)) for successive positive
integers M, since Uq!=0 makes each forbidden polynomial nonzero. There are
binom(K+n,n)-1 forbidden q, and each polynomial has degree at most n-1.
Thus at most (n-1)(binom(K+n,n)-1) positive integers M are forbidden;
testing the first one more than this number always succeeds.

## 7. Exact scope and next interface

The theorem gives a finite **classical combinatorial linear algorithm** for
every fixed jet of sufficiently large generic labels. Its input uses only
B, integer capacities, quadratic inequalities, and neighbor binomial
Laurent equations. Its correctness proof compares to theta using independent
published positivity and VIT inputs.

It does not yet compute arbitrary finite-label theta functions, and it does
not imply that every classical strongly positive basis obeys Q. The next
step is to construct positive multiplication probes from these uniquely
known large-label jets, isolating a finite target's coefficients. A proof
that such probes force a minimal positive family, or directly select all
finite-label coefficients, is still required.
