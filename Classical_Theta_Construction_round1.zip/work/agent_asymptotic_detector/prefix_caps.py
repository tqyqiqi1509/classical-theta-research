#!/usr/bin/env python3
"""Exact rank-two strips and finite pure graph prefix constraints."""
from functools import lru_cache
from itertools import product, combinations
from math import comb, ceil
from collections import defaultdict
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'agent_creation_caps'),str(ROOT/'agent_packet_propagation'),str(ROOT/'agent_acceptance'),str(ROOT/'agent_mass')]
from block_upper_caps import graph_partitions,graph_allocation_count

def bc(n,k):return comb(n,k) if n>=0 and 0<=k<=n else 0

@lru_cache(None)
def prefix(a,d,b,c,K):
    if a==0:return {(0,p):bc(d,p) for p in range(min(d,K)+1)}
    if b==0 or c==0:return {(r,p):bc(a,r)*bc(d,p) for r in range(min(a,K)+1) for p in range(min(d,K-r)+1)}
    # Each row is represented by (binomial power, quotient coefficient list).
    rows=[(a,[1])]
    def at(p,q):
        n,Q=rows[p]
        return sum(v*bc(n,q-s) for s,v in enumerate(Q))
    out={(r,0):bc(a,r) for r in range(min(a,K)+1)}
    for p in range(1,min(d,K)+1):
        n=a-b*p
        if n>0:
            lim=min(a,(b*d*p+c*a-1)//(c*a)-1)
            Q=[]
            for q in range(lim+1):
                m=d-c*q
                v=sum((-1)**(k-1)*bc(m+k-1,k)*at(p-k,q) for k in range(1,p+1)) if m>0 else 0
                Q.append(v-sum(Q[s]*bc(n,q-s) for s in range(q)))
            rows.append((n,Q))
        else:
            Q=[]
            for q in range(a+1):
                m=d-c*q
                Q.append(sum((-1)**(k-1)*bc(m+k-1,k)*at(p-k,q) for k in range(1,p+1)) if m>0 else 0)
            rows.append((0,Q))
        for r in range(min(a,K-p)+1):
            v=at(p,a-r)
            if v:out[r,p]=v
    return out

@lru_cache(None)
def gprefix(b,c,h,K):
    a=max(0,-h[0]);d=max(0,-h[1]+c*a)
    return prefix(a,d,b,c,K)

@lru_cache(None)
def blockprefix(B,e,K):
    n=len(e);I=tuple(i for i,v in enumerate(e) if v)
    if not I:return {(0,)*n:1}
    if len(I)==1:
        i=I[0];return {tuple(t if j==i else 0 for j in range(n)):bc(e[i],t) for t in range(min(e[i],K)+1)}
    if B[I[0]][I[1]]<0:I=I[::-1]
    H=prefix(e[I[0]],e[I[1]],B[I[0]][I[1]],-B[I[1]][I[0]],K)
    out={}
    for p,v in H.items():
        q=[0]*n;q[I[0]],q[I[1]]=p;out[tuple(q)]=v
    return out

def mult(F,G,K):
    H=defaultdict(int)
    for p,a in F.items():
        for q,b in G.items():
            r=tuple(u+v for u,v in zip(p,q))
            if sum(r)<=K:H[r]+=a*b
    return dict(H)

def points(n,K):return sorted((p for p in product(range(K+1),repeat=n) if sum(p)<=K),key=lambda p:(sum(p),p))

def caps(B,d,K):
    B=tuple(map(tuple,B));P=points(len(d),K);U={p:None for p in P};count=0
    for blocks in graph_partitions(B,d,max_allocations=1000000):
        F={(0,)*len(d):1}
        for e in blocks:F=mult(F,blockprefix(B,e,K),K)
        for p in P:
            if U[p] is None or F.get(p,0)<U[p]:U[p]=F.get(p,0)
        count+=1
    return U,count

def lower_rows(B,g,K):
    n=len(g);P=points(n,K);ids={p:i for i,p in enumerate(P)};out=[]
    for pair in combinations(range(n),2):
        I=pair if B[pair[0]][pair[1]]>=0 else pair[::-1];J=tuple(j for j in range(n) if j not in I)
        b,c=B[I[0]][I[1]],-B[I[1]][I[0]]
        for off in points(len(J),K):
            h=tuple(g[i]+sum(B[i][j]*v for j,v in zip(J,off)) for i in I)
            rem={}
            for q in points(2,K-sum(off)):
                p=[0]*n
                for j,v in zip(J,off):p[j]=v
                for i,v in zip(I,q):p[i]=v
                rem[q]={ids[tuple(p)]:1}
            for q in sorted(rem,key=lambda q:(sum(q),q)):
                row=rem[q];out.append((I,off,q,dict(row)))
                label=(h[0]+b*q[1],h[1]-c*q[0])
                for r,a in gprefix(b,c,label,K-sum(off)-sum(q)).items():
                    if r==(0,0):continue
                    t=(r[0]+q[0],r[1]+q[1])
                    if t not in rem:continue
                    for k,v in row.items():rem[t][k]=rem[t].get(k,0)-a*v
                    rem[t]={k:v for k,v in rem[t].items() if v}
    return P,out

def lp_analyze(B,d,K):
    import numpy as np
    from scipy.optimize import linprog
    g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(len(d))) for i in range(len(d)))
    start=time.time();U,fc=caps(B,d,K);P,rows=lower_rows(B,g,K)
    A=np.array([[-row.get(j,0) for j in range(len(P))] for *_,row in rows],dtype=float)
    bounds=[(1,1) if sum(p)==0 else (0,U[p]) for p in P]
    obj=np.ones(len(P));r=linprog(obj,A_ub=A,b_ub=np.zeros(len(rows)),bounds=bounds,method='highs')
    if not r.success:return {'status':'numerical_infeasible','message':r.message,'B':B,'d':d,'K':K}
    spread=[];vals=[]
    for j,p in enumerate(P):
        if not U[p] or j==0:continue
        c=np.zeros(len(P));c[j]=1
        lo=linprog(c,A_ub=A,b_ub=np.zeros(len(rows)),bounds=bounds,method='highs')
        hi=linprog(-c,A_ub=A,b_ub=np.zeros(len(rows)),bounds=bounds,method='highs')
        if not lo.success or not hi.success:spread.append({'p':p,'failure':True});continue
        vals.append([p,float(lo.fun),float(-hi.fun)])
        if -hi.fun-lo.fun>1e-6:spread.append({'p':p,'lo':float(lo.fun),'hi':float(-hi.fun)})
    return {'status':'unique_prefix' if not spread else 'prefix_freedom','B':B,'d':d,'g':g,'K':K,
      'allocations':fc,'seconds':time.time()-start,'spread':spread,'values':vals,
      'scope':'Finite prefix LP only; floating extrema exploratory until exact duals checked.'}

if __name__=='__main__':
    sys.path.insert(0,str(ROOT/'agent_source_surgery'))
    from common_slot_flows import llz
    count=0
    for a,d,b,c in product(range(9),range(9),range(1,4),range(1,4)):
        exact={p:v for p,v in llz(a,d,b,c).items() if sum(p)<=4}
        got=prefix(a,d,b,c,4)
        assert exact==got,(a,d,b,c,exact,got)
        count+=1
    print('RANK2 STRIPS',count,flush=True)
    result={'rank_two_strip_checks':count,'results':[]}
    cases=[(((0,3,1),(-3,0,2),(-1,-2,0)),(2,5,13)),
       (((0,2,2),(-2,0,2),(-2,-2,0)),(3,4,9)),
       (((0,3,2),(-1,0,1),(-2,-3,0)),(3,2,8))]
    for B,d0 in cases:
        for scale in [1,2,4,8]:
            d=tuple(scale*v for v in d0)
            print('START',B,d,flush=True)
            r=lp_analyze(B,d,4);result['results'].append(r)
            Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
            print('END',r['status'],'seconds',r.get('seconds'),'freedom',r.get('spread',[])[:8],flush=True)
