# A classical quadratic support bound from a positive lift

2026-11-13. The output is a finite integer condition on classical coefficients.
The comparison proof below uses the independently established quantum theta
positivity theorem in the **skew-symmetric** case. It does not define a quantum
basis, query a quantum theta coefficient, or claim an all-skew-symmetrizable
positivity theorem.

## 1. Integer data and classical assertion

Let B be an acyclic skew-symmetric exchange matrix, topologically ordered so
B_ij>=0 for i<j. Put A=[-B]_+ and let d in N^n. The canonical label is

    g_d=-d+Ad.

Write the classical theta function as x^(g_d) F_d(z), z_i=y_i x^(B e_i),
with F_d=sum_p a_p z^p. Define

    S_d(p)=sum_i p_i(d_i-p_i),
    R_d(p)=sum_(i<j) B_ij(d_i-p_i)p_j,
    Q_d(p)=S_d(p)-R_d(p).

**Quadratic support theorem.** If a_p is nonzero, then Q_d(p)>=0.
If Q_d(p)=0, then a_p is either0 or1.

This gives additional exact deletions from a classical finite carrier using
only integer matrix entries, capacities and lattice points. For a general
acyclic label g=v+g_d, the already-proved classical capacity invariance
identifies its F-polynomial with F_d, so the same assertion applies.

## 2. Direct normalization and phase calculation

Use the principal extended matrix E=(B;I). In the normalized quantum torus
X^u X^v=t^(Lambda(u,v)) X^(u+v), take

    Lambda = [[0,-I],[I,-B]].

Then E^T Lambda=[I,0]. Set m_i=(a_i,0), with a_i=-e_i+A e_i.
The one-step cluster variable is exactly

    x_i'=X^(m_i)+X^(m_i+E_i).

The normalized coefficient at d_i m_i+p_i E_i in (x_i')^d_i is the symmetric
Gaussian binomial [d_i choose p_i]_t. There is no unresolved torus monomial
normalization: Lambda(m_i,m_j)=0 for all i,j, since all m_i have only mutable
coordinates. In particular the leading coefficient of

    M_d=(x_1')^d_1 ... (x_n')^d_n

is already1 at X^(sum_i d_i m_i)=X^(g_d,0).

For i<j, skew symmetry and the topological order give

    Lambda(m_i,E_j)=-B_ij,
    Lambda(E_i,m_j)=0,
    Lambda(E_i,E_j)=B_ij.

Consequently the cross-factor exponent is

    sum_(i<j) [ -B_ij d_i p_j+B_ij p_i p_j ] = -R_d(p).

Thus the exact normalized coefficient of M_d at (g_d,0)+Ep is

    M_(d,p)(t)=t^(-R_d(p)) product_i [d_i choose p_i]_t.       (1)

Its largest t-exponent is Q_d(p). Its smallest exponent is -S_d(p)-R_d(p).
Both endpoint coefficients are1.

## 3. Why the classical coefficient is bounded

The cluster variables x_i' are quantum theta functions. Strong positivity
of their product gives a nonnegative theta expansion. Every nonleading
summand has a nonzero positive frozen shift. Therefore the coefficient of
the leading quantum theta function at label (g_d,0) is exactly1: only its
unshifted leading monomial can contribute to the coefficient1 of that
monomial in M_d.

Let a_p(t) denote the normalized Laurent coefficient of this quantum theta
function. Positive quantum theta coefficients and positive structure
constants imply coefficientwise in Z[t,t^-1] that

    0 <= a_p(t) <= M_(d,p)(t).                              (2)

The theta function is bar invariant, and normalized monomials are fixed by
bar, so a_p(t)=a_p(t^-1). If Q_d(p)<0, every exponent on the right of (2)
is negative, making a nonzero symmetric nonnegative polynomial impossible.
Hence a_p(t)=0. If Q_d(p)=0, symmetry allows only exponent0, whose coefficient
in (1) is1, so a_p(t) is0 or1.

Specialization t=1 gives the stated classical assertions. The construction
uses only the resulting integer bound; the quantum comparison theorem is
an explicit proof input, not a disguised coefficient algorithm.

## 4. Stronger finite Boolean statistic cap

Write M_(d,p)(t)=sum_k m_k t^k. Equations (1)-(2) give

    a_p(1) <= sum_k min(m_k,m_-k).                         (3)

This follows coefficient by coefficient and does not require Gaussian
unimodality. The m_k are computed without any theta function: at each vertex
choose p_i of d_i ordered slots, use the usual inversion statistic for the
Gaussian binomial, sum the symmetric slot charges, and subtract R_d(p).
For each charge k, at most min(m_k,m_-k) representatives can be paired with
the opposite charge. Formula (3) is the size of this finite symmetric
matching inventory. The positive_inventory_exchange branch implements and
independently verifies this integer dynamic program.

The quadratic bound is the zero/nonzero consequence of this inventory cap.
It should not be confused with a sufficient condition or a complete theta
construction; coefficient selection and packet coherence remain to be proved.

## 5. Symmetrizer boundary

The phase calculation itself extends to an integral symmetrizer D:

    Lambda=[[0,-D],[D,-DB]],
    S=sum_i D_i p_i(d_i-p_i),
    R=sum_(i<j) D_i B_ij(d_i-p_i)p_j.

The single-vertex Gaussian uses t^(D_i). All these are exact algebraic
identities. The comparison (2) additionally needs positive quantum theta
coefficients and strong positivity for that quantization. The audited
Davison--Mandel theorem is skew-symmetric; this note therefore does **not**
promote the all-D algebra identity to an unconditional all-D classical bound.

## 6. Comparison with existing graph caps

The full graph-allocation support does not already imply Q>=0. For the
hard skew fork, d=(8,7,9), it contains four negative-Q points:

    p=(4,2,2), Q=-4;
    p=(6,4,4), Q=-4;
    p=(7,3,4), Q=-5;
    p=(7,4,5), Q=-6.

The earlier least candidate has coefficient0 at all four, but that
observation is not the proof of the quadratic condition. For the dense
skew222 matrix at d=(7,6,9),22 graph-supported points have Q<0.

There is also a fixed-root asymptotic distinction: on the scaled hard-fork
ray d=N(8,7,9), Q_(4,2,2)=8-12N<0 for every N>=1. At N=1 the complete old
classical graph-cap/pair-lower cone allows this coefficient to range from0
to40 with exact certificates, so the new bound adds information even at a
fixed small root. No claim that those old feasible polynomials form a strong
basis is made.

## Proof inputs and audit scope

Davison--Mandel, *Strong positivity for quantum theta bases of quantum cluster
algebras*, arXiv:1910.12915v3 / Inventiones2021: skew-symmetric quantum theta
positivity, positive multiplication, bar invariance, specialization and
cluster-monomial inclusion. The principal compatible form is displayed
above and the needed product leading term is derived directly. No Li--Pan
statement or unverified2026 positivity conclusion enters the theorem.
