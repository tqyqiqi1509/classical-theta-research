#!/usr/bin/env python3
"""Independent literal torus-word and integer-matrix checks.

No theta routine is used. Nontrivial symmetrizers validate phase algebra only;
the positive-lift comparison in this project is asserted only for skew input.
"""
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json,random,math,time,sys
import sympy as sp
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agent_positive_inventory'))
from charged_caps import gaussian_layers,convolution

def phase(a,b,Lam):return sum(a[i]*Lam[i][j]*b[j] for i in range(len(a)) for j in range(len(b)))
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def fixture(B,D,d):
 n=len(B);A=[[max(-B[i][j],0) for j in range(n)]for i in range(n)]
 Lam=[[0]*(2*n) for _ in range(2*n)]
 for i in range(n):
  Lam[i][n+i]=-D[i];Lam[n+i][i]=D[i]
  for j in range(n):Lam[n+i][n+j]=-D[i]*B[i][j]
 E=[tuple([B[i][j] for i in range(n)]+[int(i==j) for i in range(n)])for j in range(n)]
 m=[tuple([A[i][j]-int(i==j) for i in range(n)]+[0]*n)for j in range(n)]
 assert all(phase(E[i],tuple(int(k==j) for k in range(2*n)),Lam)==(D[i] if i==j else 0) for i in range(n) for j in range(2*n))
 word=[i for i in range(n) for _ in range(d[i])]
 actual=defaultdict(Counter)
 for bits in product((0,1),repeat=len(word)):
  root=[0]*n;v=(0,)*(2*n);power=0
  for i,bit in zip(word,bits):
   w=add(m[i],E[i]) if bit else m[i]
   power+=phase(v,w,Lam);v=add(v,w);root[i]+=bit
  actual[tuple(root)][power]+=1
 checked=0
 for p in product(*(range(x+1) for x in d)):
  S=sum(D[i]*p[i]*(d[i]-p[i]) for i in range(n))
  R=sum(D[i]*B[i][j]*(d[i]-p[i])*p[j] for i in range(n) for j in range(i+1,n))
  hist={0:1}
  for i in range(n):hist=convolution(hist,dict(gaussian_layers(d[i],D[i])[p[i]]))
  expected=Counter({k-R:v for k,v in hist.items()})
  assert actual[p]==expected,(B,D,d,p,actual[p],expected)
  assert max(expected)==S-R and min(expected)==-S-R
  assert expected[S-R]==expected[-S-R]==1
  checked+=1
 return checked,1<<sum(d)

def matrices(B):
 B=sp.Matrix(B);n=B.rows;A=B.applyfunc(lambda x:max(-x,0));U=sp.eye(n)-A.T
 V=U.T.inv()*B;L=U.T.inv()*U;T=-U.inv()*U.T
 assert all(x>=0 for x in U.inv())
 assert V+L==sp.eye(n) and L.T*U==U.T and L.T*U*L==U
 return U,V,L,T

def threshold(B,s,K):
 U,V,L,T=matrices(B);n=len(s)
 C=[K*max(0,max(-L[i,j] for j in range(n))) for i in range(n)]
 R=[max(K,sum(max(T[i,j],0)*C[j] for j in range(n))) for i in range(n)]
 W=[max(K,sum(abs(L[i,j])*R[j] for j in range(n))) for i in range(n)]
 b=[abs(s[i])+sum(abs(V[i,j])*R[j] for j in range(n)) for i in range(n)]
 Mcap=max(b)
 Mo=sum((b[i]+W[i])*sum(abs(U[i,j])*W[j] for j in range(n)) for i in range(n))
 Mf=sum(W[i]*sum(abs(U[i,j])*(b[j]+W[j]) for j in range(n)) for i in range(n))
 Mc=sum((abs(s[i])+R[i])*sum(abs(U[i,j])*R[j] for j in range(n)) for i in range(n))
 return {'C':list(map(int,C)),'R':list(map(int,R)),'W':list(map(int,W)),'b':list(map(int,b)),'M_cap':int(Mcap),'M_origin':int(Mo),'M_far':int(Mf),'M_corner':int(Mc),'N0':int(1+max(Mcap,Mo,Mf,Mc))}

if __name__=='__main__':
 rng=random.Random(193519);tic=time.time();cases=[];points=words=0
 for n in range(2,6):
  for rep in range(20):
   D=[1]*n if rep<10 else [rng.randrange(1,4) for _ in range(n)]
   B=[[0]*n for _ in range(n)]
   for i in range(n):
    for j in range(i+1,n):
     k=rng.randrange(4);gg=math.gcd(D[i],D[j]);B[i][j]=k*D[j]//gg;B[j][i]=-k*D[i]//gg
   d=[rng.randrange(3) for _ in range(n)]
   num,w=fixture(B,D,d);points+=num;words+=w
   if rep<10:
    U,V,L,T=matrices(B)
    for z in range(25):
     q=sp.Matrix([rng.randrange(7) for _ in range(n)]);dd=sp.Matrix([rng.randrange(20,40)for _ in range(n)])
     pp=dd+L*q
     assert ((dd-pp).T*U*pp)[0]==(-dd.T*U*q-q.T*U*q)[0]
     assert ((dd-q).T*U*q)[0]==(dd.T*U*q-q.T*U*q)[0]
   cases.append({'B':B,'D':D,'d':d,'root_coefficients':num,'literal_bitwords':w})
 target=[[0,1,1,1],[-1,0,1,1],[-1,-1,0,1],[-1,-1,-1,0]]
 result={'scope':'literal algebra identity check; all-D positivity not asserted','cases':cases,'case_count':len(cases),'root_coefficients':points,'literal_bitwords':words,'two_corner_identity_checks':40*25,'example_threshold_K4':threshold(target,[0]*4,4),'seconds':time.time()-tic}
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items()if k!='cases'})
