# A finite Newton-vertex certificate relative to a known pointed element

Date: 2026-11-13. General classical positive birational cluster atlases. This is an interface for the carrier problem, not an assertion that a canonical carrier is already known. Related Newton-containment arguments occur in Cao 2608.30907v2 and Qiyue Tang's Hexagon2611.00284; no novelty claim is made without further comparison.

## Proposition

Let f and h be Laurent polynomials in every cluster of a classical cluster algebra of geometric type. Suppose in one fixed initial cluster:

1. their Newton polytopes are equal;
2. their coefficients at every vertex of that common Newton polytope are equal.

Then these two statements hold in every cluster.

In particular, if h is compatibly pointed at all seeds and its pointed coefficients are one, then f is compatibly pointed at the same tropical label. For principal coefficients one may work with the ordinary F-polynomial polytope, because the extended exchange matrix has full column rank and embeds its exponent lattice injectively in the full Laurent exponent lattice.

Neither the coefficients at interior lattice points nor their positivity in other clusters are asserted to be determined. This proposition handles the polynomial boundary and normalization part only.

## Proof

Fix any target cluster, connected to the initial cluster by a finite mutation word. Assign generic real weights w to its mutable and frozen variables, and evaluate variables as positive powers of an auxiliary parameter. Avoid the finitely many piecewise linear hypersurfaces where an exchange binomial has tied leading monomials or where two initial support monomials tie after tropical transport.

At each mutation, the dominant exchange monomial is unique and has coefficient one. Thus every initial variable, as a positive rational function of the target variables, has a unique leading monomial with coefficient one. The tropical coordinate change is a piecewise integral linear homeomorphism, so the excluded sets have empty interior.

For either f or h, a unique initial Newton vertex dominates at these generic weights. Its target leading weight is obtained by the same tropical map, and its leading coefficient is exactly its initial vertex coefficient. The equality of initial Newton polytopes therefore gives equality of target support functions at generic weights. By continuity, the target support functions agree everywhere, so the target Newton polytopes are equal.

For any target Newton vertex, choose a generic weight inside its open normal cone. The initial dominating vertex is the same for f and h, and the initial coefficients at that vertex agree. Thus the target vertex coefficients agree. Signed interior coefficients cause no difficulty: the unique leading monomial cannot cancel. QED.

## Consequence for the present construction

A finite initial carrier with prescribed vertex coefficients can transfer all-seed pointedness from any independently constructed reference element. This gives a legitimate finite certificate once that reference and its polytope are known.

It does **not** allow us to define the desired polytope as the Newton polytope of an unknown theta function. It also does not make initial positive coefficients imply all-seed positive coefficients. The useful next task is to derive a reference carrier or a carrier recurrence from integer packet and two-sided boundary data, and then solve the remaining coefficient positivity problem inside that carrier.
