# Classical arithmetic and trace interfaces

Research audit, 2026-11-13, approximately 06:25 UTC. These are interfaces under investigation, not a completed coefficient construction.

## 1. Classical Frobenius congruence

Primary source: Travis Mandel, *Scattering diagrams, theta functions, and refined tropical curve counts*, arXiv:1503.06183v5 (2019), Section 4.3, Theorem 4.2. The complete proof was directly read in the official arXiv HTML.

For every prime p, classical theta functions satisfy

    theta_g^p = theta_(p g) mod p.

With principal coefficients and the normalization theta_g=x^g F_g(z), this means

    F_(p g)(z) = F_g(z_1^p,...,z_n^p) mod p.

The published proof uses the positive binomial normal form of cluster scattering: a monomial crossing is multiplied by (1+z^n)^k with k a nonnegative integer. In characteristic p, the corresponding crossing for the p-fold exponent is its pth power. The same holds for the full theta sum. This is a valid external comparison property; it is not the proposed combinatorial algorithm and must not be confused with the distinct Frobenius-structure conjecture about traces and curve counts.

Independent exact calculation with known rank-two LLZ coefficients checked 1,200 inputs: b,c from 1 through 4, denominator labels from 1 through 5, and primes 2,3,5. There were no failures; `rank2_frobenius_results.json` records the outcome. This tests conventions and arithmetic only. It does not prove the higher-rank statement independently.

### Why it does not yet close the gap

- Ordinary integer polynomial powers satisfy Frobenius congruences automatically. A family satisfying them need not be the theta basis.
- A congruence for labels p g does not determine the coefficient of a primitive g.
- The all-seed greedy maximum does not obviously commute with reduction modulo p: each cut has a known residue, but the maximizing cut may change. No such commutation has been asserted.
- CMMM's specialized-coefficient valuative independence assumes nonzero integers are non-zero-divisors. It cannot be invoked in characteristic p to turn this congruence into a Newton-pruning proof.

## 2. The ordinary mutable constant-term trace

For a Laurent element f and an actual seed t, let Tr_t(f) be the coefficient of the zero mutable exponent, retaining the frozen Laurent polynomial. This is invariant under a single mutation: a term x_k^a changes to (x_k')^(-a) times a function of the other variables, so only a=0 can contribute to mutable exponent zero. For this slice the exchange factor has exponent zero. Hence the constant term is the same in every cluster chart.

This elementary observation suggests imposing trace or partial-freezing trace constraints on the finite Newton carrier. It does not supply the unknown traces of products involving the desired theta elements.

Mandel's Section 2.3, Proposition 2.15 and Theorem 2.16 were read. Under its stated domain and grading hypotheses, a nondegenerate trace pairing determines multiplication once its two- and three-point values on the theta-labelled module are given. This is not a method for finding those values from B alone. The proof explicitly uses theta functions with opposite leading labels to establish nondegeneracy.

Minor local source issues, not used in any argument here: the final line of the injectivity proof appears to lose the minus sign on the opposite label; Remark 2.17 calls the Frobenius trace an algebra homomorphism, where the usual definition requires a linear functional. Neither observation is a disproof of the nondegeneracy argument.

## 3. Least-action networks

Primary source: Benjamin Bond and Lionel Levine, *Abelian Networks I. Foundations and Examples* (2016), author PDF at https://pi.math.cornell.edu/~levine/abelian-networks-I-foundations.pdf. Definitions 2.1–2.2, Lemmas 4.1–4.4, and Theorem 4.9 were directly read.

Their least-action theorem applies to locally commuting processors with nonnegative message output. In optimization form, a nondecreasing map F:N^A->N^A has a coordinatewise least feasible vector for F(u)<=u, whenever feasible; the legal execution computes it. The feasible set is closed under coordinatewise minimum.

The cluster packet equations are not automatically such a system. Inverting a binomial fiber gives alternating coefficients, and unrestricted scalar interval propagation can miss affine consequences. Therefore a monotone processor realization or the required positive-circuit uniqueness must be established before importing this theorem. The current packet graph and interval recurrence are concrete attempts at that missing interface.
