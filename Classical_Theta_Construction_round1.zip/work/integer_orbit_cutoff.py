"""Exact finite bounds for bounded points in one unimodular integer orbit.

This is a coefficient-transport helper, not a positivity-atlas algorithm.
Only rational operations, polynomial factorization, certified root rectangles,
and finite integer loops are used.  See INTEGER_ORBIT_CUTOFF.md for the proof.
"""
from __future__ import annotations

from math import lcm
from functools import lru_cache
import sympy as sp

T = sp.Symbol("T")


def cyclic_data(A, beta):
    A, beta = sp.Matrix(A), sp.Matrix(beta)
    if A.rows != A.cols or beta.shape != (A.rows, 1):
        raise ValueError("matrix/vector dimensions")
    if any(x.q != 1 for x in A) or abs(A.det()) != 1:
        raise ValueError("A must be unimodular and integral")
    if any(x.q != 1 for x in beta):
        raise ValueError("beta must be integral")
    if not any(beta):
        return A, beta, sp.zeros(A.rows, 0), sp.zeros(0, A.rows), sp.Poly(1, T)
    cols, nxt = [], beta
    for _ in range(A.rows + 1):
        candidate = sp.Matrix.hstack(*(cols + [nxt]))
        if candidate.rank() == len(cols):
            break
        cols.append(nxt)
        nxt = A * nxt
    K = sp.Matrix.hstack(*cols)
    r = K.cols
    pivots = list(K.T.rref()[1])
    J = K.extract(pivots, range(r))
    Jinv = J.inv()
    L = sp.zeros(r, A.rows)
    for a in range(r):
        for b, j in enumerate(pivots):
            L[a, j] = Jinv[a, b]
    assert L * K == sp.eye(r)
    coeff = L * nxt
    assert K * coeff == nxt
    m = sp.Poly(T ** r - sum(coeff[j] * T ** j for j in range(r)), T)
    assert all(x.q == 1 for x in m.all_coeffs())
    assert abs(m.nth(0)) == 1
    return A, beta, K, L, m


def _distance_squared(a, b):
    """Minimum squared modulus on an exact real interval/complex rectangle."""
    def nearest(lo, hi):
        if lo > 0:
            return lo
        if hi < 0:
            return -hi
        return sp.S.Zero
    a, b = sp.sympify(a), sp.sympify(b)
    rx = nearest(sp.re(a), sp.re(b))
    ry = nearest(sp.im(a), sp.im(b))
    return rx * rx + ry * ry


@lru_cache(maxsize=None)
def outside_root_certificate(f):
    """Find a root of f with modulus > rho > 1, using certified rectangles."""
    eps = sp.Rational(1, 8)
    while True:
        real, nonreal = f.intervals(eps=eps, all=True)
        for (a, b), multiplicity in real + nonreal:
            lower2 = _distance_squared(a, b)
            if lower2 > 1:
                step = sp.S.One
                while (1 + step) ** 2 >= lower2:
                    step /= 2
                return {
                    "rho": 1 + step,
                    "rectangle": (a, b),
                    "min_modulus_squared": lower2,
                    "factor": f.as_expr(),
                    "multiplicity": multiplicity,
                }
        eps /= 2


def cyclotomic_order(f):
    e = f.degree()
    for k in range(1, 2 * e * e + 1):
        if sp.Poly(sp.cyclotomic_poly(k, T), T) == f:
            return k
    raise AssertionError("cyclotomic order bound failed")


def orbit_cutoff(A, beta, N):
    """Return a proof certificate and finite range containing all ||p||_1<=N hits.

    Nonperiodic result: every hit has 0 <= k <= last_possible_index.
    Periodic result: indices 0..period-1 represent the entire orbit.
    """
    if not isinstance(N, int) or N < 0:
        raise ValueError("N must be a nonnegative integer")
    A, beta, K, L, m = cyclic_data(A, beta)
    if not K.cols:
        return {"case": "zero", "period": 1, "last_possible_index": 0}
    M = [max(abs(L[j, i]) for i in range(L.cols)) for j in range(L.rows)]
    factors = sp.factor_list(m)[1]
    result = {"minimal_polynomial": m.as_expr(), "left_inverse": L,
              "row_bounds": M, "N": N, "cyclic_dimension": K.cols}
    noncyclotomic = [f for f, _ in factors if not f.is_cyclotomic]
    if noncyclotomic:
        cert = outside_root_certificate(noncyclotomic[0])
        R = 2 + max(abs(c) for c in m.all_coeffs()[1:])
        bound = N * sum(M[j] * R ** j for j in range(len(M)))
        rho = cert["rho"]
        k, power = 0, sp.S.One
        while power <= bound:
            k += 1
            power *= rho
        result.update(case="exponential", R=R, value_bound=bound,
                      last_possible_index=k-1, first_excluded_index=k,
                      excluded_power=power, root_certificate=cert)
    elif any(mult > 1 for _, mult in factors):
        bound = N * sum(j * M[j] for j in range(len(M)))
        result.update(case="unipotent", value_bound=bound,
                      last_possible_index=int(sp.floor(bound)))
    else:
        period = lcm(*(cyclotomic_order(f) for f, _ in factors))
        assert A ** period * beta == beta
        result.update(case="periodic", period=period, last_possible_index=period-1)
    return result


def bounded_orbit(A, beta, N, positive_only=False):
    """Enumerate every bounded point, with an actual proved stopping certificate."""
    cert = orbit_cutoff(A, beta, N)
    A, p = sp.Matrix(A), sp.Matrix(beta)
    hits = []
    for k in range(cert["last_possible_index"] + 1):
        if sum(abs(x) for x in p) <= N and (not positive_only or all(x >= 0 for x in p)):
            hits.append((k, tuple(int(x) for x in p)))
        p = A * p
    return hits, cert


def jsonable(x):
    if isinstance(x, dict):
        return {k: jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [jsonable(v) for v in x]
    if isinstance(x, sp.MatrixBase):
        return jsonable(x.tolist())
    if isinstance(x, sp.Integer):
        return int(x)
    if isinstance(x, sp.Basic):
        return str(x)
    return x

