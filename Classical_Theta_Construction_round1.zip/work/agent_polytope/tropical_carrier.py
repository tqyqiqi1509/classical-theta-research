#!/usr/bin/env python3
"""Seed-only tropical halfspaces for a principal normalized F-polynomial."""
from itertools import product
from normalized_fibers import mutate_matrix,mutate_g
from scipy.optimize import linprog
import numpy as np,json,math

def reverse_step(B,g,k,v):
 vk=v[k]
 delta=max(-g[k],0)*vk+g[k]*min(0,vk)
 out=tuple(-vk if i==k else v[i]+max(-B[k][i],0)*vk+B[k][i]*min(0,vk) for i in range(len(v)))
 return out,delta

def bounds_to_depth(B,g,depth):
 n=len(g);bounds={};frontier=[(B,g,(),())]
 while frontier:
  Bs,gs,word,history=frontier.pop(0)
  for j in range(n):
   v=tuple(int(i==j) for i in range(n));delta=0
   for Bi,gi,k in reversed(history):
    v,d=reverse_step(Bi,gi,k,v);delta+=d
   key=v
   if key not in bounds or delta<bounds[key]['delta']:
    bounds[key]={'v':v,'delta':delta,'word':word,'coordinate':j}
  if len(word)<depth:
   for k in range(n):
    if word and word[-1]==k:continue
    frontier.append((mutate_matrix(Bs,k),mutate_g(Bs,gs,k),word+(k,),history+((Bs,gs,k),)))
 return list(bounds.values())

def enumerate_carrier(bounds,max_points=100000):
 n=len(bounds[0]['v']);A=np.array([[-x for x in b['v']] for b in bounds]);rhs=np.array([b['delta'] for b in bounds]);limits=[]
 for k in range(n):
  c=np.zeros(n);c[k]=-1;r=linprog(c,A_ub=A,b_ub=rhs,bounds=[(0,None)]*n,method='highs')
  if not r.success:return None,{'status':r.status,'message':r.message,'axis':k}
  limits.append(math.floor(r.x[k]+1e-7))
 count=math.prod(t+1 for t in limits)
 if count>max_points:return None,{'status':'box too large','limits':limits,'box_points':count}
 pts=[p for p in product(*(range(t+1) for t in limits)) if all(sum(x*y for x,y in zip(b['v'],p))+b['delta']>=0 for b in bounds)]
 return pts,{'limits':limits,'box_points':count,'lattice_points':len(pts)}

if __name__=='__main__':
 cases=[([[0,1,-1],[-1,0,1],[1,-1,0]],(-1,-1,-1)),([[0,2],[-2,0]],(-2,2)),([[0,3],[-3,0]],(-2,2)),([[0,2,-2],[-2,0,2],[2,-2,0]],(-1,-1,-1))]
 out=[]
 for B,g in cases:
  for d in range(1,9):
   b=bounds_to_depth(B,g,d);pts,status=enumerate_carrier(b)
   e={'B':B,'g':g,'depth':d,'num_bounds':len(b),'status':status,'points':pts};out.append(e)
   print(json.dumps(e),flush=True)
 json.dump(out,open('work/agent_polytope/tropical_carrier_experiments.json','w'),indent=2)
