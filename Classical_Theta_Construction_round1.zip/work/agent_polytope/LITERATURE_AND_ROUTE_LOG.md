# Literature and route log

All entries dated 2026-11-13; started 04:13 UTC. User-visible times are UTC+8.

## Sources read

- Li–Pan, *Recurrence formula, positivity and polytope basis in cluster
  algebras via Newton polytopes*, arXiv:2201.01440v4,
  https://arxiv.org/html/2201.01440v4 . Also resolved and extracted all 63 pages
  of the user-uploaded `F-poly202608(4)(1).pdf`. The Library file is
  `libfile_fde3_f-686d8ed359b081918e4544642520559e_48bd88a843808191b2f169295ad46038`.
  Detailed scrutiny concentrated on §§1.2–1.3, 3.1, 3.3–3.4. Its theorems have
  not been adopted as inputs. Useful idea: positive binomial fiber packets and
  support control under principal reset. Unverified high-rank steps:
  Construction 3.13 assumes previously constructed sub-polytopes without a
  demonstrated well-founded rank in the admitted infinite-support setting;
  Remark 3.14 asserts choice-independence from minimality without a confluence
  argument; Theorem 3.16 uses this induction for universal conclusions. These
  are proof obligations, not a claimed counterexample to the theorem.

- Prior user `AUDIT_REPORT.md`, 2026-09-09,
  `libfile_4635866a8e088191b3604af2ec07573a`: read in full. It separates finite
  positive theta expansion from an unproved explicit support containment.
  Its observation that coefficientwise dominance need not survive division
  is elementary and valid. Its theta-based lifting route is excluded from our
  independent construction.

- Coates–Kasprzyk–Pitton–Tveiten, *Maximally Mutable Laurent Polynomials*,
  arXiv:2107.14253v1, https://arxiv.org/pdf/2107.14253 . Read §§1.3–1.6 and 2.
  Useful: exact divisibility criterion; combinatorial polytope mutation;
  distinction between mutability and rigidity; §1.4 Example 1.5 demonstrates
  different coefficient choices on the same Newton polytope. Remark 1.9
  explicitly says the combinatorial mutation of a polytope does not identify
  arbitrary chosen coefficient polynomials. The paper does not prove the
  desired cluster-basis construction, and its Fano mirror statements are not
  imported. Rigidity must be proved in the actual cluster problem.

- Peigen Cao, *Newton polytopes in cluster algebras and tau-tilting theory*,
  arXiv:2602.07929v2, https://arxiv.org/abs/2602.07929 . Metadata and abstract
  inspected: identification of non-initial cluster monomials by F-polynomial
  Newton polytopes, via Bongartz completions/F-invariants. Not fully audited,
  therefore no theorem imported. It does not by itself reconstruct general
  basis elements from g.

- Peigen Cao, *Linear independence of global monomials on positive spaces*,
  arXiv:2608.30907v2, https://arxiv.org/abs/2608.30907 . Located as an especially
  relevant 2026 comparison for Newton transport and rigidity. Full theorem
  audit still needed; do not label the independently derived Newton rigidity
  statement novel before comparing this source.

- Qiyue Tang, *Positive bases and polytopes for Laurent phenomenon algebras*,
  Hexagon2611.00284v1, https://hexagonmath.org/pdf/2611.00284v1 . Located §3 on
  Newton support transport and cluster-monomial separation, which cites
  Cao2608.30907. Relevant historical interface; not treated as an established
  theorem or as a proof of the present general basis goal.

## Routes and outcomes

1. Naive positive-binomial completion without reset bounds: refuted as a
   canonical selection mechanism by explicit local-positive tables; the
   counterexample is precisely scoped and does not attack the full Li–Pan
   hypotheses.
2. Fixed carrier linear rigidity: exact 17x17 determinant certificate obtained.
   Root supplied the more general positive-atlas Newton rigidity argument;
   independently checked and agreed, with frozen variables retained.
3. Principal reset bounds: proved exact one-step equivalence, leading to an
   explicit container C(B,g) and a backward boundary missed by the one-sided
   recurrence.
4. Seed-only tropical carrier: derived all mutation-word halfspaces, implemented
   them, and identified a finite negative tropical frame as a boundedness
   certificate. This changes the construction route from choosing coefficients
   in an unknown support to deriving a finite support container first.
5. Global weights: unresolved. Local normalized positivity is not mutation
   closed for arbitrary candidates; minimal total weight has only finite
   experimental support. Do not turn these observations into a basis claim.
6. Central directions (04:37--04:42 UTC): independently verified the parent's
   Markov persistent-radical suggestion exactly. All-word reset carriers can
   contain a ray even for the constant candidate. Simple initial coefficient
   content is invalid; rank-one cluster variables already show why.
7. Local mass enumeration: proved positive packet component restriction and
   the bound `|p|_1<=C-1` for minimum-mass local candidates. This gives a finite
   simplex search with no artificial coordinate box, but no global theorem.
8. Global packet components: defined the full-atlas hypergraph and proved that
   its finitely many components are global positive summands; the component
   containing zero preserves the global normalized label. Checked carefully
   that shared coefficients force all contributing packets into one component,
   so no token splitting is needed.
9. Tested whether the local degree bound follows from full-atlas connectivity:
   it does not. Persistent central multipliers can cause separated initial
   summands to overlap in a remote chart. Exact Markov transport gives initial
   mass-two connected examples with central displacements through 33. These
   are not minimum-mass candidates; no failure of a global-minimum theorem is
   claimed. The observed Fibonacci growth is unproved and explicitly labeled.

## Next handoff priority

Test the precise conjecture that the minimum-mass normalized local candidate
is unique and is carried to the corresponding candidate under every mutation.
Use the proved simplex bound rather than guessed boxes. Rank 4/5 random and
structured skew-symmetric and skew-symmetrizable matrices should be tested;
look specifically for multiple equal-mass solutions and transport failures.
Successful finite tests remain evidence, not a proof. A mass upper bound can
be supplied by any exact local feasible candidate, after which all smaller
masses have a certified finite support simplex.
