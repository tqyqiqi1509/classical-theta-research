# Handoff: normalized positive fibers, carriers, and mass selection

Time: 2026-11-13, 04:42 UTC. This subtask began about 04:13 UTC.
No basis theorem is established. All code and notes stay in this directory;
the parent agent owns final packaging and persistence.

## Established independently

1. Exact normalized one-step binomial transport, including the finite upper
   degree boundary missed by a one-sided coefficient recurrence. See
   `NEWTON_CARRIER_NOTES.md` and `normalized_fibers.py`.
2. Seed-only tropical halfspaces from arbitrary words, with a finite negative
   frame sufficient for boundedness. This is an optional certificate, not a
   necessary condition for existence of a finite distinguished element.
3. Persistent radical directions can make the full carrier unbounded.
   Markov `z=y1*y2*y3` is invariant for all normalized Y mutations.
4. Local minimum coefficient mass C implies support in `|p|_1<=C-1`, via
   complete positive-binomial packet component restriction. This gives a
   finite support search from a known mass upper bound.
5. Full-atlas packet hypergraph components give finitely many global positive
   summands; the component containing zero preserves all normalized constants.
   Coefficient overlap is handled by joining entire monomial vertices.

## Precisely scoped failures

- Ordinary one-neighbor positivity alone is too weak: 43-term cyclic A3
  witnesses with coefficient a111=2 or3 fail at two steps; they also violate
  normalized one-step degree bounds. They do not refute Li--Pan's full setup.
- Normalized one-step positivity for arbitrary candidates is not closed under
  transport. A2 `(1+u+uv)^2,g=(-2,1)` loses polynomial normalization at word12;
  it remains a positive cluster product, so this is not a positivity failure.
- Initial coefficient gcd cannot define primitive elements: rank-one cluster
  variable `(1+y)/x` supplies an immediate obstruction.
- Full-atlas packet connectivity does not imply the local C-1 degree bound:
  central multipliers can merge in remote charts. Exact connected mass-two
  Markov witnesses reach central displacement33. These candidates are not
  minimum mass. No arbitrary-growth theorem is claimed.

## Computational artifacts

- `positive_fiber_cone.py`: rectangular integer-cone discovery model; exact
  binomial verification. Function `model(B,g,L)` creates coefficient and
  positive quotient variables, convolution equations and finite tail bounds.
- `normalized_fibers.py`: exact sparse normalized mutation and failures.
- `scan_normalized_minweight.py`: completed896 matrix/label/box cases, including
  infeasible cases. Returned minimizers passed depth4 within stated truncation;
  this is only evidence. It did not prove uniqueness or global minimality.
- `a3_support_rigidity_certificate.json`: exact17x17 minor determinant1 and
  kernel vector on an18-point carrier; gives genuine algebraic rigidity.
- `tropical_carrier.py`: halfspace generator; exploratory SciPy LP bounds,
  not an exact general LP certificate. A3 has explicit coordinate bounds.
- `central_packets.py` and JSON: radical invariance and chord-overlap witnesses
  by exact integer arithmetic; does not store37850-term final polynomial,
  which is readily reproduced.

## Next substantive experiment requested by parent

Test this exact conjecture, rather than arbitrary local positivity:

> For every integral g and classical skew-symmetrizable B with a finite
> normalized local positive candidate, its minimum-mass candidate is unique
> and normalized mutation sends it to the corresponding selected candidate.

Use rank4/5 structured and random B and symmetrizers D. First obtain any exact
feasible candidate of mass C0, then replace the artificial rectangular box by
the proved simplex `|p|_1<=C0-1`, intersected with C(B,g). All true local
minimizers lie there. Build coefficient/quotient variables on arbitrary finite
point sets. Search equal-mass alternatives (force one coefficient to differ,
or optimize many independent objectives under the fixed mass). Transport the
returned candidate both to neighbors and through substantial random words.
At a neighbor, independently minimize for `(B',g')` and compare.

A floating-point MILP feasibility/optimality report is not itself an exact
mathematical certificate. Recheck every witness and any displayed negative
coefficient using the exact engine. Multiple equal-mass verified candidates
only refute uniqueness if the common mass is rigorously minimal; an integral
LP optimum with an exact dual bound can provide such a certificate. A verified
transport failure of a merely box-minimal candidate needs the same caveat.

If the conjecture fails, retain the full witness and identify the missing
general compatibility mechanism. Do not turn to case cataloguing.

## Literature boundaries

The full63-page Li--Pan revision is extracted locally and the sources/routes
are logged in `LITERATURE_AND_ROUTE_LOG.md`. Their conclusions were not used.
Construction3.13, Remark3.14 and Theorem3.16 have unverified confluence and
well-foundedness obligations. The local counterexample does not attack all
their hypotheses. MMLP offers a useful fixed-carrier/divisibility interface,
but mutability and rigidity are separate. Relevant2026 Cao/Hexagon results
were located for novelty comparison and not adopted without full audit.
