#!/usr/bin/env python3
from itertools import product
from scipy.optimize import milp,Bounds,LinearConstraint
import numpy as np,json,sys,random
from positive_fiber_cone import model,verify,dump_table
from normalized_fibers import in_container,all_neighbors,transport_check

def solutions(B,g,L,trials=0):
 points,ids,qids,A,lo,up=model(B,g,L);N=len(points)
 for p,j in ids.items():
  if not in_container(B,g,p):up[j]=0
 c=np.zeros(len(lo));c[:N]=1
 rng=random.Random(str(B)+str(g)+str(L));candidates=[p for p in points[1:] if up[ids[p]]>0];rng.shuffle(candidates)
 found=set()
 for tr in range(trials+1):
  lower=lo.copy()
  if tr and candidates:lower[ids[candidates[(tr-1)%len(candidates)]]]=1
  r=milp(c,integrality=np.ones(len(lo)),bounds=Bounds(lower,up),constraints=LinearConstraint(A,0,0),options={'time_limit':3})
  if r.x is None:continue
  F={p:round(v) for p,v in zip(points,r.x) if round(v)};key=tuple(sorted(F.items()))
  if key in found:continue
  found.add(key)
  assert verify(B,g,F)[0];assert all_neighbors(B,g,F)[0]
  fail=transport_check(B,g,F,depth=4)
  if fail:
   out={'B':B,'g':g,'L':L,'F':dump_table(F),'failure':fail};print(json.dumps(out),flush=True)
   json.dump(out,open('work/agent_polytope/normalized_minweight_failure.json','w'),indent=2)
   return out
 return None

if __name__=='__main__':
 tests=0
 matrices=[[[0,b],[-c,0]] for b,c in ((1,1),(2,2),(2,3),(3,3))]
 matrices += [[[0,a,-c],[-a,0,b],[c,-b,0]] for a,b,c in ((1,1,1),(1,2,2),(1,2,3),(2,2,2),(2,2,3),(2,3,3))]
 for B in matrices:
  n=len(B)
  for g in product(range(-2,2),repeat=n):
   for L in (3,5):
    tests+=1
    if solutions(B,g,L):sys.exit()
    print(json.dumps({'B':B,'g':g,'L':L,'test':tests}),file=sys.stderr,flush=True)
