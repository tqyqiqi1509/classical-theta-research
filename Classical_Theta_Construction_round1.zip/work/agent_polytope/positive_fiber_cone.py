#!/usr/bin/env python3
"""Finite exact certificates for positive binomial fiber constraints.

Uses MILP only to discover integer tables. Certificates are rechecked in Python
integer arithmetic; an optimality claim is never needed for a reported witness.
Convention: F(y) >= 0 and x^g F(y_i x^{B e_i}); d_k(p)=max(0,-g_k-(Bp)_k).
"""
from itertools import product
from math import comb
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix
import json,sys

def model(B,g,L):
    n=len(g); points=list(product(range(L+1), repeat=n)); ids={p:i for i,p in enumerate(points)}
    qids={}; fibers=[]; num=len(points)
    for k in range(n):
        for off in product(range(L+1),repeat=n-1):
            p=list(off[:k])+[0]+list(off[k:]); d=max(0,-g[k]-sum(B[k][j]*p[j] for j in range(n)))
            for s in range(max(0,L-d+1)):
                qids[k,off,s]=num;num+=1
            fibers.append((k,off,d))
    A=lil_matrix((len(points)*n,num),dtype=float);r=0
    for k,off,d in fibers:
        for s in range(L+1):
            p=off[:k]+(s,)+off[k:];A[r,ids[p]]=1
            for j in range(max(0,s-(L-d)),min(d,s)+1):
                key=(k,off,s-j)
                if key in qids:A[r,qids[key]]=-comb(d,j)
            r+=1
    lower=np.zeros(num);upper=np.full(num,np.inf);lower[0]=upper[0]=1
    return points,ids,qids,A.tocsc(),lower,upper

def verify(B,g,table):
    n=len(g)
    for k in range(n):
        offs=set(p[:k]+p[k+1:] for p in table)
        for off in offs:
            p=off[:k]+(0,)+off[k:];d=max(0,-g[k]-sum(B[k][j]*p[j] for j in range(n)))
            maxs=max(p[k] for p in table if p[:k]+p[k+1:]==off)
            q=[]
            for s in range(maxs+1):
                a=table.get(off[:k]+(s,)+off[k:],0)
                qs=a-sum(comb(d,j)*q[s-j] for j in range(1,min(d,s)+1))
                if qs<0:return False,(k,off,s,d,qs)
                q.append(qs)
            if any(q[s] for s in range(max(0,maxs-d+1),maxs+1)):
                return False,(k,off,'nonzero tail',d,q)
    return table.get((0,)*n)==1,None

def search(B,g,L,trials=10,seed=20261113):
    points,ids,qids,A,lower,upper=model(B,g,L);N=len(points);rng=np.random.default_rng(seed);found={}
    for trial in range(trials):
        c=np.zeros(len(lower)); c[:N]=1 if trial==0 else rng.integers(1,40,size=N)
        r=milp(c,integrality=np.ones(len(lower)),bounds=Bounds(lower,upper),constraints=LinearConstraint(A,0,0),options={'time_limit':5})
        if r.x is None: return list(found.values()),{'status':r.status,'message':r.message}
        vector=tuple(round(v) for v in r.x[:N]);table={p:a for p,a in zip(points,vector) if a}
        valid,why=verify(B,g,table)
        if not valid:raise ValueError(why)
        found.setdefault(vector,table)
    return list(found.values()),None

def dump_table(t):return [{'p':p,'a':a} for p,a in sorted(t.items())]

if __name__=='__main__':
    out=[]
    for abc in product(range(1,3),repeat=3):
      a,b,c=abc;B=[[0,a,-c],[-a,0,b],[c,-b,0]]
      for g in product(range(-2,1),repeat=3):
        for L in (2,3):
          found,err=search(B,g,L,trials=6)
          if len(found)>1:
            for ti,tj in product(range(len(found)),repeat=2):
              if ti>=tj:continue
              x,y=found[ti],found[tj]
              if not any(x.get(p,0)>y.get(p,0) for p in x):continue
              if not any(y.get(p,0)>x.get(p,0) for p in y):continue
              mn={p:min(v,y.get(p,0)) for p,v in x.items() if min(v,y.get(p,0))}
              valid,why=verify(B,g,mn)
              entry={'B':B,'g':g,'L':L,'tables':[dump_table(x),dump_table(y)],'min_valid':valid,'failure':why}
              out.append(entry);print(json.dumps(entry),flush=True)
              with open('work/agent_polytope/cone_witnesses.json','w') as f:json.dump(out,f,indent=2)
              if len(out)>=8:sys.exit()
          print(json.dumps({'B':abc,'g':g,'L':L,'solutions':len(found),'error':err}),file=sys.stderr,flush=True)
    with open('work/agent_polytope/cone_witnesses.json','w') as f:json.dump(out,f,indent=2)
