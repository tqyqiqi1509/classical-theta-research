"""Exact central-ray and cross-chart packet-overlap experiments.

The finite results are witnesses, not a proof of the observed Fibonacci law.
Run from this directory or with its parent on sys.path.
"""
from collections import defaultdict
from math import comb
import json
from pathlib import Path
from normalized_fibers import mutate


def radical_step(B, w, k):
    """Exponent of y^w under inverse normalized Y mutation, if B w=0."""
    assert all(sum(row[j] * w[j] for j in range(len(w))) == 0 for row in B)
    out = list(w)
    out[k] = -w[k] + sum(max(-B[k][j], 0) * w[j] for j in range(len(w)))
    return tuple(out)


def markov_experiments(depth=9):
    initial = [[0, 2, -2], [-2, 0, 2], [2, -2, 0]]
    delta = (1, 1, 1)
    for sign in (1, -1):
        B = [[sign * a for a in row] for row in initial]
        for k in range(3):
            assert radical_step(B, delta, k) == delta
            for N in (1, 2, 7):
                F = {tuple(j * a for a in delta): comb(N, j) for j in range(N + 1)}
                out, err = mutate(B, (0, 0, 0), F, k)
                assert err is None and out[2] == F
    B, g, F = initial, (1, 0, 0), {(0, 0, 0): 1}
    rows = []
    for step in range(depth):
        k = step % 3
        out, err = mutate(B, g, F, k)
        assert err is None, err
        B, g, F = out
        lines = defaultdict(list)
        for p in F:
            lines[(p[0] - p[2], p[1] - p[2])].append(p)
        pair = max(((min(v, key=lambda p: p[2]), max(v, key=lambda p: p[2]))
                    for v in lines.values()), key=lambda ab: ab[1][2] - ab[0][2])
        a, b = pair
        rows.append({"step": step + 1, "word_one_based": [j % 3 + 1 for j in range(step + 1)],
                     "g": g, "support_size": len(F), "coefficient_mass": sum(F.values()),
                     "central_chord_length": b[2] - a[2],
                     "endpoint_a": a, "endpoint_b": b,
                     "coefficient_a": F[a], "coefficient_b": F[b]})
    return {"B": initial, "delta": delta, "central_identity_verified": True,
            "initial_global_monomial_g": [1, 0, 0], "cyclic_transport": rows,
            "scope": "All operations exact integers. Observed chord growth is finite evidence only."}


if __name__ == "__main__":
    result = markov_experiments()
    path = Path(__file__).with_name("central_packets_experiments.json")
    path.write_text(json.dumps(result, indent=2))
    for row in result["cyclic_transport"]:
        print(row)
