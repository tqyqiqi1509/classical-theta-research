#!/usr/bin/env python3
"""Exact principal-coefficient reset mutation of homogeneous F-polynomials."""
from math import comb
from collections import defaultdict

def mutate_matrix(B,k):
 n=len(B)
 return [[-B[i][j] if i==k or j==k else B[i][j]+max(B[i][k],0)*max(B[k][j],0)-max(-B[i][k],0)*max(-B[k][j],0) for j in range(n)] for i in range(n)]

def mutate_g(B,g,k):
 return tuple(-g[k] if i==k else g[i]+max(B[i][k],0)*g[k]-B[i][k]*min(g[k],0) for i in range(len(g)))

def in_container(B,g,p):
 return all(p[k]<=max(-g[k],0)+sum(max(-B[k][j],0)*p[j] for j in range(len(g))) for k in range(len(g)))

def mutate(B,g,F,k,require_positive=True):
 """Return B',g',F', with an exact failure explanation if not normalized positive.
 Terms on the same p_{!=k} fiber are divided by (1+t)^d in integer arithmetic.
 All data in F are polynomial exponents (nonnegative).
 """
 n=len(g); fibers=defaultdict(dict)
 for p,c in F.items():
  if c:fibers[p[:k]+p[k+1:]][p[k]]=c
 out=defaultdict(int)
 for off,row in fibers.items():
  p=off[:k]+(0,)+off[k:];r=g[k]+sum(B[k][j]*p[j] for j in range(n));d=max(-r,0)
  alpha=max(-g[k],0)+sum(max(-B[k][j],0)*p[j] for j in range(n))
  q=[];N=max(row)
  for s in range(N+1):
   a=row.get(s,0)-sum(comb(d,j)*q[s-j] for j in range(1,min(d,s)+1));q.append(a)
   if require_positive and a<0:return None,{'kind':'negative_quotient','k':k,'off':off,'s':s,'value':a,'r':r}
  if any(q[s] for s in range(max(0,N-d+1),N+1)):
   return None,{'kind':'not_divisible','k':k,'off':off,'q':q,'d':d}
  for s,a in enumerate(q):
   if not a:continue
   for j in range(max(r,0)+1):
    e=alpha-d-s+j
    if e<0:return None,{'kind':'negative_reset_exponent','k':k,'off':off,'s':s,'e':e}
    out[off[:k]+(e,)+off[k:]]+=a*comb(max(r,0),j)
 out={p:c for p,c in out.items() if c}
 return (mutate_matrix(B,k),mutate_g(B,g,k),out),None

def all_neighbors(B,g,F):
 for k in range(len(g)):
  r,err=mutate(B,g,F,k)
  if err:return False,err
 return True,None

def transport_check(B,g,F,depth=3):
 frontier=[(B,g,F,())];seen=set()
 while frontier:
  B,g,F,w=frontier.pop(0)
  key=(tuple(map(tuple,B)),g,tuple(sorted(F.items())))
  if key in seen:continue
  seen.add(key)
  if len(w)>=depth:continue
  for k in range(len(g)):
   if w and k==w[-1]:continue
   r,err=mutate(B,g,F,k)
   if err:return {'word':w+(k,), 'failure':err}
   B2,g2,F2=r
   if len(F2)>2000:continue
   frontier.append((B2,g2,F2,w+(k,)))
 return None
