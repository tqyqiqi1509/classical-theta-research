# Central directions, packet components, and mass bounds

Independent exact arguments, 2026-11-13. These statements address the finite
search mechanism; they do not establish a cluster basis.

## 1. Persistent central coefficient directions

Use the normalized inverse Y-change from `NEWTON_CARRIER_NOTES.md`. If an
integer vector `w` satisfies `B w=0`, substitution into `y^w` cancels every
`(1+t)` factor. Its new exponent vector is

`w'_i=w_i` for `i!=k`,

`w'_k=-w_k+sum_j max(-b_kj,0) w_j`.

The positive and negative row sums agree because `B w=0`. Direct matrix
mutation verifies `B' w'=0`. Thus a radical vector whose transported vectors
stay nonnegative gives a polynomial coefficient monomial in every reset
chart. Multiplying any globally normalized positive candidate by a polynomial
with nonnegative coefficients in this persistent monomial and constant term
one preserves all those properties.

For `B=[[0,2,-2],[-2,0,2],[2,-2,0]]`, mutation replaces B by -B; the vector
`delta=(1,1,1)` is fixed by the displayed exponent rule in every direction
for both signs of B. Therefore `z=y1 y2 y3` is exactly invariant under all
reset Y-transformations. Every `(1+z)^N` with label `g=0` is a finite
polynomial with positive coefficients in every reset chart. Consequently the
all-word tropical Newton carrier contains the entire ray `R_+ delta`, even
though the distinguished constant candidate is just 1. Boundedness of that
carrier is not equivalent to finiteness of a distinguished basis element.

An initial-chart coefficient gcd is not a valid primitive-selection rule:
already a rank-one cluster variable is `(1+y)/x`, whose initial coefficient
content is `1+y`. Dividing it would discard a genuine cluster variable. A
content condition would have to be imposed across all charts and would also
need a proof that quotient positivity survives. No such rule is adopted here.

## 2. A finite mass search for the local problem

Fix B,g and let F be a finite nonnegative integer polynomial with constant
term one satisfying the ordinary positive binomial fiber criterion in every
direction. Form a graph on `Supp(F)` by joining lattice neighbors differing
by `e_k` for any k.

**Lemma.** Restriction of F to any connected component of this graph still
satisfies every positive binomial fiber criterion. If F also satisfies the
normalized one-step bounds, every component restriction does too.

**Proof.** In a fixed k-fiber write `P(t)=(1+t)^d Q(t)` with `Q>=0`. Every
nonzero quotient monomial `q_s t^s` contributes the entire interval of
exponents `s,s+1,...,s+d`, with positive binomial coefficients. This interval
lies in one graph component. Restricting to a component therefore selects
whole quotient packets. Contributions of packets that overlap a selected
monomial also belong to that component, so the full original coefficient is
retained. The restricted fiber is the same binomial factor times the sum of
the selected quotient monomials. Finally, the normalized support inequalities
hold pointwise and are inherited by a subset. This proves the lemma.

The component containing 0 retains constant term one. Therefore every
minimum-mass local solution has connected support. If its mass is
`C=F(1,...,1)`, it has at most C support points. A simple path from 0 to any
support point has at most C-1 edges. Consequently

`sum_i p_i <= C-1` for every p in its support.

This supplies a finite enumeration without a guessed Newton box: examine
mass C=1,2,... and all nonnegative coefficient tables supported in the finite
simplex `p>=0, sum p_i<=C-1`, with a0=1 and total mass C; test all exact local
fiber conditions. If a finite local solution exists, the procedure reaches
its minimum mass and lists every minimum-mass solution. This assertion is
only about the local problem. Uniqueness and mutation closure remain open.

## 3. A global packet component theorem

Suppose a finite pointed element is given by positive normalized polynomials
`F_t` in every seed t, with transported labels `g_t` and constant term one.
For each seed t and each nonzero monomial coefficient in `F_t`, introduce a
vertex `(t,p)`. Along every mutation edge `t --k--> t'`, fix an off-k exponent
eta. Put `r=g_k+sum_j b_kj eta_j`, `d=max(-r,0)`, `e=max(r,0)`, and
`alpha=max(-g_k,0)+sum_j max(-b_kj,0) eta_j`.

For every positive coefficient q_s in the uniquely determined quotient
`Q(t)=P(t)/(1+t)^d`, introduce a hyperedge containing all source support
vertices in

`q_s t^s (1+t)^d`

and all target support vertices in

`q_s t^(alpha-d-s) (1+t)^e`.

Off-k coordinates remain eta. We connect vertices, rather than making
arbitrary copies of their integer coefficient multiplicities.

**Theorem.** Each connected component of this full-atlas hypergraph defines
an integer positive global summand. There are finitely many such components.
The component containing the initial zero vertex has constant term one in
every reset chart and is a globally normalized pointed candidate with the
same tropical label.

**Proof.** At any vertex every packet contributing to its coefficient belongs
to the same component as that vertex. Hence restricting to component vertices
keeps exactly a collection of whole packets, including every contribution to
each retained coefficient. On both sides of every mutation edge the selected
polynomials are related by the exact normalized mutation formula. Thus they
define one global rational function, Laurent and positive in each chart.
Every vertex in any chart is contained in at least one packet along an edge
on a finite path back to the initial chart. Repeating this observation links
it to an initial support vertex. Therefore every component meets the finite
initial support and the number of components is finite.

For the zero off-k fiber, `r=g_k`, `alpha=d`, and polynomial normalization
forces `P=(1+t)^d`: its quotient has degree at most zero and constant one.
The corresponding target packet is `(1+t)^e`. This hyperedge contains zero
on both sides. Hence all zero vertices, in every chart, belong to one
component. Restricting to it preserves each constant coefficient one. QED.

These connected summands are not asserted to be additively indecomposable:
different positive summands can share support vertices and thus be joined by
this coarse graph. In particular the theorem alone gives no canonical basis.

## 4. Why the local mass bound does not follow from global connectivity

The full-atlas graph can join support points that are far apart in the initial
chart. Persistent central directions show exactly how this can happen.
Let z be invariant in all charts and let M be a global monomial. The two
positive summands M and `z^N M` of `M(1+z^N)` have initial mass two in a chart
where M is a monomial. Each summand's support, considered across the atlas,
is connected back to its single initial vertex. If some chart contains two
monomials of M separated by the central exponent `N delta`, the two summand
families overlap at a support vertex and the full-atlas graph for their sum
is connected.

This phenomenon occurs in the Markov example above with M equal to the first
initial cluster variable. Exact normalized transports along `(1,2,3)^3`
produce central chords of lengths

`0,0,1,2,4,7,12,20,33`

after each step. Thus already `F=1+z`, initial mass C=2, has a connected
full-atlas packet graph although its nonzero support point has total degree
3, exceeding C-1. The same calculation gives mass-two connected examples
`1+z^N` for N=2,4,7,12,20,33, whose initial labels are all `g=(1,0,0)`.
The reproduction script saves exact chord endpoints and their positive
integer coefficients. The apparent Fibonacci-minus-one growth is not proved
here and is not used to claim an infinite counterfamily.

These examples are not mass-minimal for their label: F=1 already exists.
They show that full-atlas packet connectivity alone cannot replace local
connectivity in the elementary C-1 argument. A theorem bounding genuinely
global minimum-mass candidates would need an additional mechanism, such as
valid universal primitive reduction or a positive splitting finer than this
coarse support graph. Neither is established here.
