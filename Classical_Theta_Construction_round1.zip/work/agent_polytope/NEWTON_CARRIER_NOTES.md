# Seed-only Newton carriers and positive fiber transport

Research notes, 2026-11-13. These notes do not establish a higher-rank greedy basis.
All matrices below use column exchange exponents and `g+Bp` for a pointed term.

## 1. Exact one-step normalized formula

Let `B` be skew-symmetrizable, `g` integral, and

`f=x^g F(y_1 x^{B e_1},...,y_n x^{B e_n})`, `F in N[y]`, `F(0)=1`.

Fix a mutation direction `k` and a fiber `p_{!=k}`. Write its polynomial as
`P(t)=sum_s a_s t^s`. Set

`r=g_k+sum_{j!=k} b_kj p_j`, `d=max(-r,0)`,
`alpha=max(-g_k,0)+sum_{j!=k} max(-b_kj,0) p_j`.

Ordinary Laurent positivity in the adjacent seed is equivalent on this fiber
to `P=(1+t)^d Q`, with `Q in N[t]`. This is just binomial division.
Resetting to principal coefficients at the new seed gives exactly

`P'(t)=t^(alpha-d) (1+t)^max(r,0) Q(t^-1)`.

Consequently, the reset expression is a polynomial with nonnegative coefficients
if and only if `Q in N[t]` and `deg P <= alpha`. The constant term remains one.
The new label is

`g'_k=-g_k`,
`g'_i=g_i+max(b_ik,0) g_k-b_ik min(g_k,0)` for `i!=k`.

### Derivation

The inverse normalized Y-change is
`y_k=1/t` and `y_i=y'_i t^max(-b_ki,0)(1+t)^b_ki`.
The prefactor is `t^max(-g_k,0)(1+t)^g_k`.
Substituting the fixed fiber and using
`(1+t^-1)^d=t^-d(1+t)^d` proves the displayed formula.
Its smallest exponent is `alpha-d-deg Q=alpha-deg P`.
All summands have nonnegative coefficients, so no cancellation can hide a
negative exponent. This proves both directions of the criterion.

Thus every admissible support lies in the explicit rational polyhedron

`C(B,g)={p>=0 : p_k<=max(-g_k,0)+sum_j max(-b_kj,0)p_j for every k}`.

When `B_-=(max(-b_ij,0))` is nilpotent, this has the explicit finite box bound
`p <= (I+B_-+...+B_-^(n-1)) (-g)_+`. For general cyclic matrices this
one-step container can be unbounded. This observation by itself is not a new
acyclic basis construction.

## 2. Tropical halfspaces along arbitrary mutation words

Let `v` be an integral weight on the reset variables. The inverse Y-map has
tropicalization

`T_k(v)_k=-v_k`,
`T_k(v)_i=v_i+max(-b_ki,0)v_k+b_ki min(0,v_k)` for `i!=k`.

The prefactor contributes
`delta_k(v)=max(-g_k,0)v_k+g_k min(0,v_k)`.

For a mutation word `w`, compute the seed matrices and the labels forward, then
apply these maps to `e_j` backward through the word. The result is a vector
`v(w,j)` and an accumulated integer `delta(w,j)`. Since the original F has
nonnegative coefficients, its valuation is the minimum of its monomial
valuations. Therefore the reset rational function has no negative exponent in
its `j`-th variable exactly when

`delta(w,j)+v(w,j).p >= 0` for every `p` in `Supp(F)`.

For a finite collection of words these are finite exact integer halfspaces.
They are computed from `B,g`, independently of any coefficient table or
scattering diagram. Their intersection is a necessary Newton carrier for a
universally pointed F-polynomial. They do not establish Laurentness or positive
coefficients in the distant charts.

### Finite certificate

If the resulting recession cone is `{0}`, the carrier is bounded, and all its
lattice points can be enumerated. A particularly simple certificate consists
of words and coordinates with `v(w_i,j_i)=-e_i`; then the inequalities give
`0<=p_i<=delta(w_i,j_i)` for all i. All steps are exact integer operations.

A reddening word for the opposite matrix provides such a negative tropical
frame through the sign relation `Psi_B(-v)=-Psi_{-B}(v)`, provided the stated
linear action on the relevant orthant is checked. The implementation checks
the actual integer tropical maps rather than assuming a reddening convention.

This supplies a finite candidate carrier, not a proof of canonical weights,
mutation covariance, a basis theorem, or positive multiplication.

## 3. A check of the mechanism and the omitted boundary

For the cyclic matrix

`B=[[0,1,-1],[-1,0,1],[1,-1,0]]`, `g=(-1,-1,-1)`,

the length-one carrier is unbounded. Length-two inequalities add `p_i<=2`.
Together with `p_1<=1+p_3`, `p_2<=1+p_1`, `p_3<=1+p_2`, these leave exactly
18 lattice points. Starting solely from these points, the elementary binomial
divisibility equations have rank 17. The minor obtained by deleting the
constant column has determinant one. Normalization therefore gives exactly

`F0=(1+u+uv)(1+v+vw)(1+w+uw)`.

This demonstrates a way to recover the missing boundary conditions before
minimizing coefficients. It is not offered as a special-case endpoint.

In particular, at the `(p_2,p_3)=(1,1)` fiber, the degree bound is two and the
divisor is `1+u`, so `a_111=a_011+a_211`. Positive binomial packets in other
fibers force `a_011>=2` and `a_211>=2`; hence `a_111>=4`.

If the reset-polynomial condition is dropped, there are finite 43-term
polynomials positive in the initial seed and all three neighboring seeds with
`a_111=3` or `2`. Their exact tables are stored in
`a3_local_positive_witness.json` and `a3_local_positive_witness_c1112.json`.
They satisfy all ordinary positive-binomial fiber conditions, checked with
integer arithmetic. They fail the normalized support bound; independently,
the division agent found a negative coefficient after the two-step word
`(1,2)`. These are counterexamples to the weaker local criterion, not to the
full Li–Pan construction.

The support-rigidity certificate shows there is no common coefficientwise
lower element for F0 and the 43-term witness in the weaker local cone:
anything below F0 is supported in its 18-point support, and the Laurent
equations plus constant term one force it to equal F0, which is not below the
witness at `(1,1,1)`.

## 4. Computation scope

`positive_fiber_cone.py` constructs finite integer linear systems and rechecks
every returned table by exact integer division. MILP is only a discovery tool;
explicit verified witnesses do not depend on solver optimality.

`normalized_fibers.py` implements the exact normalized formula and verified
involutivity on the cyclic A3 cluster monomial. `tropical_carrier.py` enumerates
the seed-only inequalities. The small LP used for enumerating a carrier is
only an exploratory bound finder; a formal proof should use an exact rational
boundedness certificate or explicit coordinate bounds such as the A3 ones.

`scan_normalized_minweight.py` completed 896 matrix/label/box cases (including
infeasible boxes) with no depth-four failure for the returned total-weight
minimizers. This is finite evidence only. A broader normalized positive cone
is not mutation closed: in rank-two A2, `g=(-2,1)` and
`F=(1+u+uv)^2` satisfy the first-neighbor criterion but acquire a negative reset
exponent at word `(1,2)`. This F is a positive product of cluster variables
whose initial leading label is not a single global tropical label. It does
not disprove positivity of that product.

## 5. Current constructive direction

Use a finite tropical frame to generate a Newton carrier, impose exact
binomial divisibility/positivity on its lattice points, and study whether
minimal carriers followed by coefficient minimization yield a canonical
mutation-covariant choice. What remains is a genuine theorem about global
compatibility and multiplication; no such theorem has been proved here.

**Subsequent correction and extension.** A finite tropical frame cannot be
required as a general hypothesis: persistent central coefficient directions
make the all-word carrier unbounded even for a finite constant candidate.
`PACKET_COMPONENTS_AND_MASS.md` proves this phenomenon, a finite mass-based
enumeration for the normalized local problem without a prechosen Newton box,
and a full-atlas positive packet component theorem. It also explains why
global packet connectivity alone does not inherit the local C-1 degree bound.
