# 经典高秩 greedy／theta 基的有限整数路径构造

## 阅读入口与结论

研究时间：2026 年 11 月 13 日 04:12:08 UTC 起，持续至 2026-11-13 10:12:23 UTC，已完成所要求的六小时。任意交换矩阵的全解仍未声称完成；本报告给出已证明范围、可复现程序和剩余核心缺口。

本轮工作的主结果，是一套针对**经典斜对称化丛代数**的有限整数路径公式。最直接的版本适用于任意秩无环交换矩阵：输入只有 $B,D,g$，使用整数二项式、一个显式有限盒、半空间条件和有限链，便给出 theta 系数；连负框架与变异序列也不再是这个版本的运行数据。无环情形的一般几何系数与无系数推广均已证明。

含环推广使用更弱的**有限负乘积证书**：有限个普通丛变量的正整数幂乘积，其首向量逐坐标为负；这些变量不必属于同一个丛。这样的证书通过有限普通变异核验，能逐次数恢复同一公式所需的整数矩阵。在给定种子坐标下，该条件等价于丛 g 向量集合不被任何过原点的闭半空间包含。单个终点 $C=-P$ 的负框架只是其特例。

输出系数是有限有向无环图中的**整数权重路径和**。程序不需要散射墙、broken lines、表示空间、Euler 特征或预先知道的 theta 系数。识别输出等于 theta 的证明仍引用经典 theta 的坐标变换与正性定理。路径权重允许为负，尚未得到无消去的正计数模型。这不是任意交换矩阵的无条件全解；同时缺少负乘积证书和可用覆盖等有限输入时的一般终止算法仍未完成。

全包中最值得先读的文件：

| 文件 | 内容 |
|---|---|
| `work/agent_cyclic_generic_bridge/HALFSPACE_CHAIN_FORMULA.md` | 最简主公式：二项式、半空间限制、有限链与路径 |
| `work/agent_cyclic_generic_bridge/ACYCLIC_LOCAL_BINOMIAL_COROLLARY.md` | 无环全秩、全斜对称化的直接整数公式及推导 |
| `work/agent_cyclic_generic_bridge/NEGATIVE_PRODUCT_INTEGER_THETA_THEOREM.md` | 多个种子恢复总矩阵，推广到有限负乘积证书 |
| `work/agent_cyclic_generic_bridge/FOLDING_CHAIN_EXTENSION.md` | 块常值覆盖的折叠机制，能越过目标的负乘积假设 |
| `work/agent_cyclic_generic_bridge/SEGMENTATION_CANCELLATION.md` | 把全部链切分消去为单链上的二值标记 |
| `work/agent_valued_leading/ACYCLIC_SIGNED_UNIT_OBJECTS.md` | 完全不以矩阵运算定义的子集／多重集装饰链，每个对象权重为正负一 |
| `work/agent_valued_leading/ACYCLIC_GEOMETRIC_COEFFICIENT_BASIS.md` | 任意几何系数、无系数、基性质与正性保持的完整证明 |
| `work/agent_cyclic_generic_bridge/NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md` | 主定理、完整算法、终止证明与 theta 识别证明 |
| `work/agent_cyclic_generic_bridge/INTEGER_OBJECTS_AND_EXCHANGE_RECURRENCES.md` | 把交换、多项式整数幂、矩阵分解和逆展开成有限 packet、树、链与路径 |
| `work/agent_valued_leading/NEGATIVE_FRAME_FACTOR_INDEPENDENT_AUDIT.md` | 独立检查斜对称化配对、分解顺序、截断及末项提取 |
| `work/THETA_NEWTON_PRUNING.md` | 独立的 Newton 多面体删除算法；明确其 2026 文献前提 |
| `work/agent_negative_frame/INJECTIVE_REACHABLE_NEWTON_AND_MARKING.md` | 含环情形的多面体、标记及精确冻结阈值 |
| `work/RUN_LOG.md` | 按时间记录的路线、文献、失败与纠偏 |

主定理不以 Li–Pan 的任何结论为前提，也不以任何 2026 年的量子正性主张为前提。有关后者的审核与未闭合推理分别保存，不能因主路线成功而自动升级为已证明。

## 0. 最简无环公式：只输入 B、D、g

拓扑排序使 $B_{ij}\ge0$（$i<j$）。取 $D$ 为正整数斜对称化矩阵，令 $A=[-B]_+$。依次计算

$$d_i=\max\left(0,-g_i+\sum_{j<i}A_{ij}d_j\right),\qquad
J=\{p\in\mathbb Z^n:0\le p\le d\}.$$

对 $q\le p$，直接定义整数

$$\boxed{\ C_{p,q}=\prod_{i=1}^n
\binom{-g_i-\sum_{j<i}B_{ij}p_j-\sum_{j>i}B_{ij}q_j}{p_i-q_i}\ }. \tag{A}$$

二项式的上标允许是负整数，按 $\binom{r}{k}=r(r-1)\cdots(r-k+1)/k!$ 定义，结果仍为整数。不可比的矩阵元取 0，且 $C_{p,p}=1$。

对每个 $p\ne0$，令 $m_p=g+Bp$，定义有限集合

$$\boxed{\ I_p=\{p\}\cup
\{q\le p:m_p^TD(p-q)<0\}\ }. \tag{B}$$

取主子矩阵 $C[I_p,I_p]$ 的逆的第 $p$ 行，记为 $t^{(p)}_q$。这里的逆完全是有限整数链公式：

$$t^{(p)}_q=\sum_{q=q_0<q_1<\cdots<q_\ell=p\atop q_j\in I_p}
(-1)^\ell\prod_{j=1}^{\ell}C_{q_j,q_{j-1}},\qquad t^{(p)}_p=1. \tag{C}$$

最后按总次数递推

$$\boxed{\ a_0=1,\qquad a_p=-\sum_{q\in I_p\setminus\{p\}}t^{(p)}_q a_q\ }. \tag{D}$$

则 $F_g=\sum_{p\in J}a_pz^p$ 正是经典 theta 多项式。把边 $q\to p$ 的权重设为 $-t^{(p)}_q$，$(D)$ 就是从 0 到 $p$ 的路径权重和。边权自身由 $(A)$–$(C)$ 的显式有限链决定。

这个版本的实际构造没有一般点 $u$，没有 chamber 搜索，没有矩阵符号分解，也没有辅助框架多项式。后文保留较早的负框架与符号分解证明，因为它们提供识别公式的理论接口。

关键化简的证明很短。此前的分解为 $C=A^-A^+$，$T=(A^-)^{-1}$。对目标 $p$，$T$ 的第 $p$ 行只支撑在 $(B)$ 的 $I_p$；由 $TC=A^+$，该行在 $I_p\setminus\{p\}$ 的乘积为 0，所以它恰为 $C[I_p,I_p]^{-1}$ 的第 $p$ 行。**$I_p$ 不需要向下闭合**：这里是利用该行支撑得到的主子矩阵方程，不是在声称任意非向下闭合集上的截断都与乘法交换。

闭式 $(A)$ 可由普通一次变异逐坐标推出，也可从无环框架多项式依次抽取系数得到。每一步只产生一个广义整数二项式。两种推导已独立核对。

## 0.1 任意几何系数的输出

对任意冻结矩阵 $\Gamma\in\mathbb Z^{m\times n}$，冻结变量 $f_1,\ldots,f_m$ 取可逆，定义

$$\Theta_g^\Gamma=\sum_p a_p x^{g+Bp}f^{\Gamma p}. \tag{E}$$

无环时，$(\Theta_g^\Gamma)_{g\in\mathbb Z^n}$ 是 $\mathbb Z[f^{\pm1}]$ 上的基，具有各丛 Laurent 正性和乘法正性；$\Gamma=0$ 就是无系数整数基。其证明通过 BFZ 的完整无环 presentation：主系数关系 $x_iu_i=y_iP_i+Q_i$ 在 $y_i\mapsto a_i/b_i$、$u_i\mapsto b_i^{-1}X_i'$ 下恰变为实际交换关系。这给出代数同构，而非假定张量积与 Laurent 环交集可交换。把已知主系数自由基张量过去即可，不需平坦性或特殊化后满秩。

如要求普通丛单项式本身恰好成为基成员，可进一步乘冻结单项式单位 $f^{-\nu(g)}$，其中 $\nu_r(g)=\min_{p:a_p\ne0}(\Gamma p)_r$。无系数时不需要这一步。

## 0.2 含环的更一般证书

假设给定有限普通丛变量 $X_s=x^{g_s}F_s(z)$ 及正整数 $b_s$，使 $h=\sum_s b_sg_s<0$。令 $P=\prod_sX_s^{b_s}=x^hH(z)$。对目标 $g$，取 $k$ 使 $g-kh\ge0$，则 $x^{g-kh}P^k$ 给出有限正上界，盒大小由 $H^k$ 明确决定。

对每个非零正向量 $\alpha$，$h^TD\alpha<0$ 保证某个 $g_s^TD\alpha<0$。该变量所在的种子足以处理这一个根；不同根可以使用不同种子。设该种子的 G 矩阵为 $G_s$，其普通 F 多项式为 $F_{s,j}$，由

$$\Phi_s(x_i)=x_i\prod_jF_{s,j}^{(G_s^{-1})_{ji}},\qquad \Phi_s(y)=y$$

算出有限整数矩阵 $C_s$ 及其逆 $S_s$。对 $\alpha=p-q$ 选择上述种子，按区间次数递推

$$C_{p,p}=1,\qquad C_{p,q}=-\sum_{q\le r<p}(S_s)_{p,r}C_{r,q}. \tag{F}$$

这样恢复的 $C$ 与各个有效种子的选择无关。然后直接使用 $(B)$–$(D)$ 的半空间链公式。这里**没有把普通乘积 $P$ 当成某个 theta 元素**；它只负责有限范围和每个根的种子覆盖。

有限负乘积证书与在当前种子坐标下丛 g 向量集合不落在任何闭半空间等价。若所有有限正组合都避开开负正交象限，凸锥分离给出一个在所有丛向量上非负的非零泛函；初始单位向量迫使这个泛函坐标非负，便得到所禁止的半空间。反向由 $h<0$ 直接得到。实系数的有限严格负组合可用有理数逼近并清分母，转为整数证书。

这与 GHKK 的 large cluster complex 条件相接。应保留其“在某个种子坐标下”的限定，不能未经证明把一个种子的证书存在性说成任意固定种子坐标下的自动性质。主系数上丛代数的基结论使用 GHKK Proposition8.28；整数性另由有限有理 theta 展开逐个取最小冻结总次数的首项得到，不能误套只覆盖 injective-reachable 情形的命题。

## 0.3 越过负乘积条件：有限覆盖与折叠

另一个已经闭合的机制从有限覆盖交换矩阵开始。给定斜对称整数矩阵 $\widetilde B$、一条它的有限负框架变异词，以及顶点分划 $O_1,\ldots,O_n$，大小为 $r_a$。要求每个块都为常值：$\widetilde B_{ij}=b_{ab}$（$i\in O_a,j\in O_b$）。这比一般箭图对称性强，内部块必为零。

在本文列根规范下，折叠矩阵和斜对称化矩阵是

$$\overline B_{ab}=r_a b_{ab},\qquad
\overline D_{aa}=L/r_a,\qquad L=\operatorname{lcm}(r_1,\ldots,r_n).$$

注意缩放的是行。把覆盖负框架多项式中的每个 $\widetilde z_i$ 换成 $Z_a$（$i\in O_a$），合并同项，即得有限整数多项式 $\overline H_a$。同轨道各个代表的结果相同。Zhou 的主系数折叠交换图及一个独立证明的负正交室单项式引理，识别

$$X_a^{-1}\overline H_a=\vartheta_{-e_a}.$$

因此这些已由覆盖普通交换算出的多项式，提供目标的总矩阵和正有限范围；继续用同一个半空间链公式即可。目标本身不必存在负框架或负乘积。

这项推广覆盖任意轨道大小，得到经典斜对称化目标。完整证明严格保留块常值条件；不会把任意 quiver automorphism 当成足够条件。一般折叠得到全部有限 theta 函数及其中间代数基；是否张成整个上丛代数需另有定理。主系数 Markov 情形由 Zhou 的定理给出全上丛代数基，系数自由的 Markov 上丛代数不能作同样外推。

覆盖端还可以只有有限负乘积证书：先用第 0.2 节构造覆盖端的有限负生成元，再作同样的整数重标记。此增强使用 Zhou 证明中的形式 intertwining 等式，而不是无依据地假定总形式变换有有理逆。正式证明见 `FOLDING_CHAIN_EXTENSION.md` 第 7 节及独立审核 `GENERAL_BLOCK_CONSTANT_FOLDING.md`。现成折叠命令行入口验证的是给定负框架的覆盖输入。

## 0.4 已完成的一层一般消去

路径的每条边本来还装饰着一条严格链。把所有这些链拼成单链 $0=s_0<\cdots<s_N=p$，令

$$b_j=\max\{k<j:(g+Bs_j)^TD(s_j-s_k)\ge0\},$$

空集时取 $-1$。定义二值标记 $P_{-1}=0,P_0=1,P_j=P_{b_j}$。那么这条固定单链的所有合法切分的总贡献恰为

$$(-1)^N(P_N-P_{N-1})\prod_{j=1}^N C_{s_j,s_{j-1}}.$$

故切分的有符号重数总是 $-1,0,1$，而非越来越复杂的交错计数。这是对任意秩有效的一般消去机制；它尚未把不同单链之间的剩余负号全部消掉。

还可以把公式完全写成带正负号的有限对象计数：对每条单链的每一步、每个坐标，记二项式为 $\binom{r}{k}$。当 $r\ge0$ 时，装饰一个 $r$ 元集合的 $k$ 元子集；当 $r=-\ell<0$ 时，装饰一个取自 $\ell$ 种颜色、大小为 $k$ 的多重集，并附符号 $(-1)^k$。$k=0$ 只有空装饰；$r=0<k$ 没有装饰。再乘上述二值标签给出的 $\eta=(-1)^N(P_N-P_{N-1})$；$\eta=0$ 的链直接丢弃。每个剩余装饰链权重均为 $+1$ 或 $-1$，其有符号总数就是 $a_p$。这样定义组合对象时连“求逆矩阵”也无需出现，但仍未得到每个对象均为正的模型。

## 1. 负框架特例与完整识别证明

设 $B\in\mathbb Z^{n\times n}$，$D=\operatorname{diag}(\delta_1,\ldots,\delta_n)$ 为正整数对角矩阵，且 $DB$ 斜对称。取主系数，写

$$z_j=y_j\prod_i x_i^{B_{ij}},\qquad \vartheta_g=x^gF_g(z).$$

给定一条普通变异序列，若终点 $C=-P$，则经重排，其丛变量为

$$I_i=x_i^{-1}H_i(z),\qquad H_i\in\mathbb N[z],\quad H_i(0)=1.$$

称这一组同属一个丛的变量为负框架。它是可核验的有限组合数据。热带对偶给 $G=-D^{-1}PD$；由于 $G$ 的整数性及置换循环上的比值乘积为 1，$P$ 保持 $D$，从而 $G=-P$。也可以直接递推 G 矩阵检查负单位列。

**主定理。** 对每个 $g\in\mathbb Z^n$，下文定义的有限整数路径和等于经典 $F_g$。因此，这一构造给出上述主系数上丛代数的 theta 基。在无环情形，这同时是普通丛代数的基。无环情形还可合法推广到任意几何系数，冻结变量取可逆。

一般负框架情形只宣称上丛代数 $\mathcal U$ 的基，不自动宣称 $\mathcal A=\mathcal U$，也不自动宣称任意系数特殊化保持上丛代数的基。

在二阶，经典 theta 基与 LLZ greedy 基相等。因此，本构造在二阶退化到同一组基元素，给出所述高秩范围内的推广。这里没有额外宣称所有高秩 theta 都具有二阶 greedy 的每一种极小性或原子性性质。

文献基础：GHKK 的经典 theta 正性、丛单项式包含和坐标变换；Qin 的 injective-reachable 上丛代数基定理；无环代数的标准单项式表示。准确版本与命题位置见第 8 节。一般负乘积证书版本改用 GHKK Proposition8.28，而非仅用于 injective-reachable 的 Qin 命题。

## 2. 第一步：从普通交换式取得有限组合数据

沿给定序列递推扩展交换矩阵、G 矩阵和 F 多项式。F 交换关系形如

$$F_kF_k'=N_k,
\quad N_k=z^{[C_{\bullet k}]_+}\prod_jF_j^{[B_{jk}]_+}
+z^{[-C_{\bullet k}]_+}\prod_jF_j^{[-B_{jk}]_+}.$$

由于 $F_k(0)=1$，商的系数不用除法黑箱：

$$F_k'[p]=N_k[p]-\sum_{0<r\le p}F_k[r]F_k'[p-r].$$

各坐标次数上界由 $\deg_iF_k'=\deg_iN_k-\deg_iF_k$ 得到，最后检查完整乘回恒等式。这样整个输入准备本身也是有限的整数递推。

无环情形更简单。把顶点拓扑排序，使 $A=[-B]_+$ 严格下三角，按 $n,n-1,\ldots,1$ 变异即可取得负框架。相应

$$H_i=1+z_i\prod_{j>i}H_j^{A_{ji}}.$$

这是一个普通有限有向图上的依次生成规则。可以直接把每个非恒定项视为带颜色和根向量的 packet。

若只知道交换矩阵属于有负框架的类，而没有现成序列，可以枚举有限变异词直到验证 $C=-P$。在这一类上搜索会终止；对不在这一类的输入，不能把该搜索称为有终止保证的算法。

## 3. 第二步：完全显式的有限范围

令 $a_i=[-g_i]_+$、$v_i=[g_i]_+$，构造普通丛变量乘积

$$M_g=x^v\prod_i I_i^{a_i}=x^g\prod_iH_i(z)^{a_i}.$$

取

$$b_j=\sum_i a_i\deg_{z_j}H_i,\qquad
\mathcal B=\{p\in\mathbb Z^n:0\le p\le b\},\qquad K=\sum_jb_j.$$

这给出算法的有限顶点集。其正确性来自经典正性：$M_g$ 的 theta 展开含 $\vartheta_g$，系数为 1，其余项非负。主系数齐次性迫使展开标签为 $(g+Bq,q)$；若 $q$ 有负坐标，该项自己的首单项式会在 $M_g$ 中产生负冻结指数，且正性排除了抵消。因此 $q\ge0$，只有 $q=0$ 能贡献冻结原点。故 $F_g$ 逐项不超过显式多项式 $\prod_iH_i^{a_i}$，支撑必在 $\mathcal B$ 内。

这一步没有未知支撑的循环定义，也不需要 Newton 多面体预言机。

无环时可以采用更小的标准单项式范围。依次计算

$$c_i=\max\left(0,-g_i+\sum_{j<i}A_{ij}c_j\right).$$

令 $v=g+(I-A)c$，则 $v,c\ge0$ 且 $v_ic_i=0$。普通一次变异变量的标准乘积为

$$x^v\prod_i(x_i')^{c_i}=x^g\prod_i(1+z_i)^{c_i}.$$

同一正性证明给出 $0\le p\le c$ 的有限上界。这一优化完全经典，不需要量子参数或二次型上界。

## 4. 第三步：有限整数矩阵与符号分解

定义形式代换

$$\Phi(x_i)=x_iH_i(z)^{-1},\qquad \Phi(y_j)=y_j.$$

要特别保留 $z_j=y_jx^{B_{\bullet j}}$ 的变化，不能把 $z$ 误当成固定系数。在齐次基

$$v_q=x^{g+Bq}y^q=x^gz^q$$

上，得到有限矩阵

$$C_{p,q}=[z^{p-q}]\prod_iH_i(z)^{-(g+Bq)_i}\quad(q\le p),$$

不可比索引处为 0，且 $C_{p,p}=1$。整数幂用广义二项式展开。例如

$$\binom{-\ell}{r}=(-1)^r\binom{\ell+r-1}{r}.$$

因此每个矩阵元都是有限 packet 组合的整数权重和。所有计算都在有限盒内完成。

选整数向量 $u$，使所有需要的非零正根向量 $\alpha$ 满足

$$\lambda_u(\alpha)=u^TD\alpha\ne0.$$

存在唯一分解

$$C=A^-A^+,$$

其中两因子单位三角，且非对角元分别只允许 $\lambda_u(p-q)<0$ 和 $\lambda_u(p-q)>0$。

完整计算规则如下。按**区间次数 $|p-q|$ 递增**，计算

$$R_{p,q}=C_{p,q}-\sum_{q<r<p}A^-_{p,r}A^+_{r,q}.$$

若 $\lambda_u(p-q)<0$，令 $A^-_{p,q}=R_{p,q}$、$A^+_{p,q}=0$；反之交换两者。每个乘积中的两个区间都更短，故递推确定、有限，且不涉及除法。

这也是一般有限单位三角矩阵的初等分解事实，不把这个抽象事实宣称为首次发现。这里使用的是从普通交换多项式得到总矩阵，并直接提取目标系数的完整构造。

令 $T^u=(A^-)^{-1}$。其条目是有限严格链的有符号乘积和，或者用

$$T^u_{p,q}=-\sum_{q\le r<p}A^-_{p,r}T^u_{r,q},\qquad T^u_{q,q}=1$$

递推。

## 5. 第四步：目标系数就是有限路径和

记 $D_{\max}=\max_i \delta_i$，取统一整数

$$M=1+D_{\max}K.$$

对每个非零 $p\in\mathcal B$，令

$$m_p=g+Bp,\qquad u_p=Mm_p+\mathbf1.$$

对 $0<|\alpha|\le K$，有

$$u_p^TD\alpha=M m_p^TD\alpha+\sum_i \delta_i\alpha_i.$$

第二项严格介于 0 与 $M$ 之间，故这个配对不为零，而且在 $m_p^TD\alpha\ne0$ 时与它同号。这给出无需寻找 chamber 的显式方向。

分别用 $u_p$ 完成上一节分解，定义

$$a_0=1,\qquad
a_p=-\sum_{q<p}T^{u_p}_{p,q}a_q.$$

最后输出 $F_g(z)=\sum_{p\in\mathcal B}a_pz^p$。

等价的组合对象非常直接：顶点为 $\mathcal B$，每个 $q<p$ 放一条有向边，权重

$$w(q\longrightarrow p)=-T^{u_p}_{p,q}.$$

则

$$a_p=\sum_{\gamma:0\rightsquigarrow p}\prod_{e\in\gamma}w(e).$$

边严格提高总次数，所以路径有限。边权已经由交换数据、整数幂和有限矩阵递推定义，没有把待求的 $a_p$ 填回边权。这个区别是本构造满足“显式递推整数权重组合对象”的实质。

### 识别为 theta 的证明

证明分三个环节。

第一，负框架的丛锥是整个负正交象限。经典 theta 的丛锥单项式性质说明，从该锥到初始正锥的总坐标变换正是 $\Phi$。冻结单项式固定，全部首指数为 $(-e_i,0)$，没有遗漏冻结因子。

第二，取方向 $u$ 的一般点。负锥到该点的路径只可能经过 $\lambda_u(\alpha)>0$ 的相关超平面；该点到初始正锥只可能经过 $\lambda_u(\alpha)<0$ 的相关超平面。两段坐标变换分别有相应的正根增量符号支撑。总变换的复合顺序在列向量约定下恰为 $A^-A^+$。有限分解的唯一性因而识别 $T^u$ 为初始坐标到该点坐标的变换。算法自身没有枚举这些超平面或变换因子。

第三，对目标 $p$，考察最终指数 $(g+Bp,p)$。从方向 $u_p$ 的点沿反向最终射线 $Q+t(g+Bp)$，上述同号性质保证不会遇到任何可能贡献 $p$ 的相关超平面。因此没有最后一次非平凡转折。未转折项的完整冻结指数为 0，所以 $p\ne0$ 时目标项系数为 0，即

$$\sum_{q\le p}T^{u_p}_{p,q}[z^q]F_g=0.$$

这正是构造的三角递推。即使 $Bp=0$ 或 $g+Bp=0$，完整冻结指数仍排除了例外。有限上界保证没有漏掉盒外项。

构造与识别证明的依赖应当分清：**构造是纯整数组合；识别证明使用已有 theta 理论。**尚未写出连识别证明都完全不使用 theta 几何语言的替代证明。

## 6. 多面体思想如何独立落地

本轮没有引用 Li–Pan 的基存在、选择无关或递归终止结论。我们独立得到两个可组合的步骤。

### 6.1 有限顶点删除

在显式有限盒中，令 $F=\sum a_pz^p$、$a_0=1$。对每个一次相邻种子，Laurent 性等价于一组二项式整除关系。例如固定第 $k$ 坐标之外的指数 $q$，需要

$$ (1+t)^{\max(0,-g_k-\sum_{j\ne k}B_{kj}q_j)}\mid\sum_m a_{(q,m)}t^m.$$

这是整数系数线性方程。主系数扩展矩阵满秩，所以初始种子与其邻种子的上界判别适用。对当前支撑多面体的非零顶点 $v$，测试这些方程加 $a_v=0$ 是否相容；若相容，删除该顶点，继续。

使用已审核的 valuative independence，任何初始 $g$-pointed 上丛元素的 Newton 多面体都包含 $\vartheta_g$ 的 Newton 多面体。于是可删的正好是尚在目标多面体之外的顶点。算法有限终止、与删除顺序无关，并返回准确 Newton 多面体。

这里确实使用了 CMMM 2026 修订稿的定理，详细依赖与审核记录已单独保存。**主整数路径定理不需要这一加速步骤或该 2026 定理。**

### 6.2 内部系数由路径递推填充

顶点删除本身不决定内部系数。此前多次计算表明，固定多面体、邻种子 Laurent 性、二阶正性甚至大量图容量上界后，内部仍有自由度。把这种自由度误称为唯一基元素会产生错误。

现在内部系数由第 5 节的有限递推确定。因此可采用“显式有限范围—可选多面体缩减—整数路径系数”的结构。若缩减后集合不是向下闭合，计算某个目标 $p$ 的矩阵时仍必须使用完整前缀盒 $[0,p]$，不能直接删去中间矩阵索引。

另有已证明的标记正性和精确同时冻结阈值，保存在负框架分支文件中。它们是可继续连接组合对象的结构定理，并不是主构造的隐藏前提。

## 7. 计算验证与此前缺口的实际闭合

计算用于检查构造、发现伪命题和检验实现；一般结论来自上面的证明。

| 检查 | 结果与用途 |
|---|---|
| 四阶完全图的拓扑定向，$g=(-4,-1,4,8)$ | 完整 1260 点上仅用二项式与半空间链重构：122 项、系数和 1829；与独立比值法及先前 LU 逐项相等，根代理复跑通过 |
| 二阶 wild，$B_{12}=3,B_{21}=-3$，$g=(-4,7)$ | 13 项、系数和 62；与独立 LLZ 计算逐项相等 |
| 斜对称化二阶，$B=\left(\begin{smallmatrix}0&4\\-2&0\end{smallmatrix}\right)$，$D=(1,2)$，$g=(-3,2)$ | 10 项、系数和 32；与独立 LLZ 计算逐项相等 |
| 六阶真正 mutation-cyclic 种子，$g=(-1,-1,1,0,0,0)$ | 17 步负框架；普通交换得到六个各 9 项的框架多项式；重构 22 项、系数和 27 |
| 六阶种子的变异类 | 完整队列耗尽，共 270 个带标号矩阵、1620 条有向变异边，无无环成员；不是有限深度抽查 |
| 不同种子的斜对称化三阶负乘积 | 完整 60 点正范围，28 项、系数和 666；与独立无环二项式公式逐项相等 |
| 块常值覆盖下降到主系数 Markov 目标 | 完整 31 点正范围，16 项、系数和 27；覆盖交换、同轨道代表一致性及目标 Laurent 方程均精确核验 |
| 不等大小的块：A3 覆盖到斜对称化 B2 | 块大小 (2,1)，折叠矩阵为 B12=2、B21=-1，D=(1,2)；目标 g=(-3,-2) 完整 18 点，18 项、系数和 108，与独立 B-only 公式逐项一致 |
| Wolfram 对一般符号分解的独立验证 | 120 个任意整数矩阵的分解检查，另 150 个任意整数矩阵的半空间逆行恒等式检查；最大 81 个顶点，零失败 |

四阶例子此前恰好暴露了“取系数最小者”的问题：全部 185220 种边容量分配、81897 个不同图乘积仍不足以给出逐项最小解。系数和 1829 当时只是一种优化结果，不能作为 theta 识别。现在额外的精确提取等式把剩余参数全部确定；因此相同的数字获得了新的证明依据。

大规模探索还包括 1260 个容量层、91404 个无序适当容量分解和 3721691 个结构系数坐标。这些有限数据本身不证明无限族强正性。相关旧候选、失败条件及已修正的常数都保留，避免把后来的成功倒写成早期已经证明。

## 8. 文献审核与使用等级

### 已用于主定理的经典基础

1. Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, arXiv:1411.1394v2。直接核读 Corollary 3.9 的丛锥单项式性质、经典正性及坐标变换。其 arXiv v2 与发表版本的部分命题编号不同，记录中明确区分。
2. Qin, *Bases for upper cluster algebras and tropical points*, arXiv:1902.09507v4，Appendix A.1，特别是 A.1.3–A.1.5。直接核读经典斜对称化、主系数满秩及 injective-reachable 范围。
3. Berenstein–Fomin–Zelevinsky, *Cluster algebras III*, arXiv:math/0305434v3。标准单项式基、无环 presentation 与上界判别分别使用，不能混淆其中不同的互素假设。
4. Muller, *A=U for locally acyclic cluster algebras*, SIGMA10(2014)094，arXiv:1308.1141v4。其独立证明消去无环 A=U 的互素限制。
5. Cheung–Gross–Muller–Musiker–Rupel–Stella–Williams, *The greedy basis equals the theta basis: a rank two haiku*, arXiv:1508.01404v2。用于二阶退化的识别。
6. Zhou, *Cluster Structures and Subfans in Scattering Diagrams*, SIGMA16(2020)013。核读第 3.3 节的块常值条件、Proposition3.4、Lemma3.5、主系数交换图及 Markov 的主系数与无系数差别；覆盖下降严格使用这里核实的范围。
7. Mozgovoy–Reineke, *Moduli spaces of stable pairs and non-abelian zeta functions of curves via wall-crossing*, JEP1(2014)117–146，第 8 节。最后一轮已严格识别：取系数环为有限矩阵环、用矩阵单位编码每个端点相关权重，本轮受限逆链公式正是其 Theorem8.3 的明确特化；不仅索引相似，带符号权重也一致。因此不能把这个反演恒等式宣称为新发现。具体无环二项式、有限范围、theta 系数提取与整数对象的整套结合仍需进一步优先权调查。该接口不提供跨链正消去；精确字典及剩余缺口见 `FRAMED_HN_INTERFACE.md`。

### 2026 文献与跨领域接口

| 文献或方向 | 本轮核查所得 | 使用情况 |
|---|---|---|
| CMMM, arXiv:2505.09585v2，2026-05-21 修订 | 逐读 valuative independence 证明与有限 Laurent 适用范围 | 仅用于独立 Newton 删除算法 |
| Reading–Stella, arXiv:2603.19391v4，2026-11-08；SIGMA22(2026)109 | 更新到实际 v4，阅读 pointed reduced bases、dominance 与 ray basis；ray basis 的定义仍输入 theta 射线元素 | 有用的结构接口；没有据此声称已给纯组合 theta 构造 |
| Burcroff–Lee–Mou–Musiker–Reineke, arXiv:2511.14672；2026 年发表 | 阅读 tight gradings 的定义、二阶计数与换格公式 | 二阶正计数接口；不直接升格为高秩系数模型 |
| Qiyue Tang, Hexagon2610.00201v3 | 核读 Hall 与最高次系数论证；不把最高次正性当成全部量子系数正性 | 启发旧支路，主定理完全不依赖 |
| Qiyue Tang, Hexagon2610.00025v3 | 核读二阶最小性中的量子 bar-degree 机制及其依赖 | 不能直接用于任意经典正基 |
| Qiyue Tang, Hexagon2611.00190v2 | 阅读修改量子群正性论证的具体接口；完整主链未重新认证 | 未引用其主结论 |
| Qiyue Tang, Hexagon2610.00587v1 | 已定位全文；一般 Lefschetz 主张尚未全链审核 | 未使用 |
| Armstrong-Williams–Hirst–Jackson–Lee, arXiv:2610.36179v1 | 明确四阶判定范围，未复演其全部 Lean 与计算附录 | 未当作任意秩终止定理 |
| Bridgeland, arXiv:1603.00416v4 | 确认旧 Lemma11.4 的勘误；不继续引用错误 genteel 证明 | 旧 Hall 支路已纠偏 |
| Nakanishi 的群分解与经典散射专著 | 比较已有正负群分解与本轮有限矩阵递推 | 不能把标准分解本身宣称为新颖性 |

Li–Pan 原文及用户修改稿的审核保留在 `work/agent_polytope/LITERATURE_AND_ROUTE_LOG.md`。记录的问题是指定论证的终止指标、选择无关与归纳依赖尚未建立；没有把“证明有缺口”自动写成“主定理已被反例推翻”。用户提供的论文全文不重复装入总包。

## 9. 尚未解决的核心问题

第一，进一步扩大有限证书范围。负框架限制已经被多种子逐根恢复突破，有限负乘积条件又被块常值覆盖下降越过。对既没有这些证书、也没有其他已核验有限总变换输入的交换矩阵，尚未得到一般终止算法。并没有证明任意交换矩阵都能找到这类覆盖。

第二，正计数。本轮权重有符号，最终非负由 theta 比较保证。若要求像 Dyck compatible pairs 或完美匹配那样每个对象均有非负权，需要新的消去配对或重匹配规则。此前“把所有容量分配中的固定 bitstring 直接取交”的方案不保持 Laurent 整除，已经停止。

最后一轮把这个缺口进一步具体化：令 $\widehat p=(1,p)$，取固定整数斜对称型 $\Omega=\left(\begin{smallmatrix}0&-g^TD\\Dg&DB\end{smallmatrix}\right)$，则 $(g+Bp)^TD(p-q)=\widehat p^T\Omega\widehat q$。全部随终点变化的允许性因此可以在同一个加框格中表达。已核实的 HN 矩阵字典同时处理了链的索引与带符号权重；仍缺的是与这些二项式权重相容的有限正 packet／flag 细化规则及跨链消去，不再把形式反演本身列作未解难点。

第三，完全初等的识别证明。现有构造已经不输入散射数据，但 theta 识别仍借助坐标变换与最后一段论证。若用户把“纯组合”理解为连识别证明也禁止这些工具，这一更强要求仍未完成。

第四，发表级新颖性。总变换、群分解与末项检测分别与既有文献有关。本轮独立推导、实现并多方审核了它们组成的明确有限整数路径公式，但没有完成足以宣称“文献首次”的穷尽检索。

## 10. 复现与记录

总包的 `main_program/` 是整理后的可运行程序与样例；先读其中 `README_CLASSICAL_FRAME_PATHS.md`。在该目录运行 `python -S halfspace_chain.py inputs/k4_acyclic_only.json --output result.json` 即可复现四阶完整计算。`-S` 禁止加载第三方 site-packages，最简无环程序只需 Python 标准库。

全部研究程序、完整多项式和验证证书还保留在 `work/agent_pieri_diamond/`；真正含环种子的变异类与负框架证书在 `work/agent_cyclic_generic_bridge/`；独立矩阵检查与 Wolfram 原始回执在 `work/agent_valued_leading/`。

`MANIFEST.json` 给出总包内每个记录的相对路径、字节数和 SHA-256。所有路线的成功、失败、条件性和修正记录保留在各分支的 `RESEARCH_LOG.md`、`HANDOFF.md` 及根目录 `RUN_LOG.md` 中。阅读数学结论应以本总报告及主定理为准；较早的阶段文件有意保留当时的未决状态，不应单独摘取为最终结论。
