#!/usr/bin/env python3
"""Exact integer polynomial operations for the classical frame algorithm.
The optional Laurent-space helper imports SymPy locally; the main direct
algorithm uses only Python integer arithmetic and the standard library.
"""
from pathlib import Path
from itertools import product
from collections import defaultdict
from math import comb
import json

def atomic(path,obj):
 path=Path(path);tmp=path.with_suffix('.writing');tmp.write_text(json.dumps(obj,separators=(',',':')));tmp.replace(path)

def dump_poly(F):return [{'p':p,'a':str(a)} for p,a in sorted(F.items(),key=lambda item:(sum(item[0]),item[0])) if a]

def divisibility_space(B,g,points):
 """Exact binomial Laurent equations; only B,g and integer points are used."""
 import sympy as sp
 points=tuple(map(tuple,points));ids={p:i for i,p in enumerate(points)};rows=[]
 for k in range(len(g)):
  fibers=defaultdict(list)
  for p in points:fibers[p[:k]+p[k+1:]].append(p)
  for off,P in fibers.items():
   p=off[:k]+(0,)+off[k:];order=max(-g[k]-sum(B[k][j]*p[j] for j in range(len(g))),0)
   for j in range(min(order,max(p[k] for p in P)+1)):
    row=[0]*len(points)
    for p in P:
     if p[k]>=j:row[ids[p]]=comb(p[k],j)*(-1)**(p[k]-j)
    if any(row):rows.append(row)
 A=sp.Matrix(rows) if rows else sp.zeros(0,len(points));null=A.nullspace();cols=[]
 for v in null:
  den=sp.ilcm(*[x.q for x in v]) if len(v)>1 else v[0].q
  cols.append([int(x*den) for x in v])
 fr={p:tuple(v[i] for v in cols) for i,p in enumerate(points)};fr={p:r for p,r in fr.items() if any(r)}
 return fr,{'points':len(points),'equations':A.rows,'dimension':len(cols),'rank':len(points)-len(cols)}

def pts(box):return sorted(product(*(range(a+1) for a in box)),key=lambda p:(sum(p),p))

def inside(p,box):return all(0<=a<=b for a,b in zip(p,box))

def addp(p,q):return tuple(a+b for a,b in zip(p,q))

def subp(p,q):return tuple(a-b for a,b in zip(p,q))

def mul(F,G,box):
 H=defaultdict(int)
 for p,a in F.items():
  for q,b in G.items():
   r=addp(p,q)
   if inside(r,box):H[r]+=a*b
 return {p:a for p,a in H.items() if a}

def inv(F,box):
 zz=(0,)*len(box);assert F.get(zz)==1
 H={zz:1}
 for p in pts(box)[1:]:
  a=-sum(v*H.get(subp(p,q),0) for q,v in F.items() if any(q) and inside(q,p))
  if a:H[p]=a
 return H

def power(F,k,box):
 if k<0:return power(inv(F,box),-k,box)
 H={(0,)*len(box):1}
 while k:
  if k&1:H=mul(H,F,box)
  k//=2
  if k:F=mul(F,F,box)
 return H

def monomial_image(R,h,box):
 H={(0,)*len(box):1}
 for F,k in zip(R,h):
  if k:H=mul(H,power({p:a for p,a in F.items() if inside(p,box)},k,box),box)
 return H

def seed_mutate(B,C,k):
 n=len(B)
 def update(r,is_mutable):
  return tuple(-r[j] if j==k or (is_mutable and is_mutable-1==k) else r[j]+max(r[k],0)*max(B[k][j],0)-max(-r[k],0)*max(-B[k][j],0) for j in range(n))
 BB=tuple(update(B[i],i+1) for i in range(n));CC=tuple(update(C[i],0) for i in range(n))
 return BB,CC

def cluster_F_jets(B,word,box):
 n=len(B);zz=(0,)*n;B=tuple(map(tuple,B));C=tuple(tuple(int(i==j) for j in range(n)) for i in range(n));F=[{zz:1} for _ in range(n)]
 for k in word:
  terms=[]
  for sign in (1,-1):
   p=tuple(max(sign*C[i][k],0) for i in range(n));P={p:1} if inside(p,box) else {}
   for j in range(n):
    a=max(sign*B[j][k],0)
    if a:P=mul(P,power(F[j],a,box),box)
   terms.append(P)
  H=defaultdict(int)
  for P in terms:
   for p,a in P.items():H[p]+=a
  F[k]=mul(dict(H),inv(F[k],box),box);assert F[k].get(zz)==1
  B,C=seed_mutate(B,C,k)
 return F
