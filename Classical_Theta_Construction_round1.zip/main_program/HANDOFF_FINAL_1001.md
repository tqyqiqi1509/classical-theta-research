# 最终实现交接：2026-11-13 10:01 UTC

## 当前主结果

**推荐入口：`halfspace_chain.py`；README：`README_CLASSICAL_FRAME_PATHS.md`。**

无环输入只需 B、D、g，程序验证拓扑顺序，使用完整 canonical 二项式盒、显式 generalized-binomial 总变换 C，以及严格半空间主子矩阵的逆行链。没有 Q、量子参数、Laurent-space solver、LU、方向搜索、theta oracle 或负框架输入需求。一般 frame 和 different-seed negative-product 模式复用完全相同的 `chain_recurrence`。

核心公式：

\[
C_{rq}=\prod_i\binom{-g_i-\sum_{j<i}B_{ij}r_j-\sum_{j>i}B_{ij}q_j}{r_i-q_i},\quad
I_p=\{p\}\cup\{q\le p:(g+Bp)^TD(p-q)<0\}.
\]

取 `T_p* = row_p(C[I_p,I_p]^-1)`，然后 `a_p=-sum_(q<p)T_pq a_q`。全部中间格点保留，等号不进入严格半空间。

## 已完成的完整运行

| 文件 | 载体点 | 非零项 | 质量 | 备注 |
|---|---:|---:|---:|---|
| halfspace_k4_result.json | 1260 | **122** | **1829** | 输入仅 B,D,g；全盒；约0.5秒 |
| halfspace_valued_rank2_result.json | 20 | 10 | 32 | D=(1,2)；独立完整 LLZ 相等 |
| halfspace_cyclic_rank6_result.json | 58 | 22 | 27 | 真 mutation-cyclic cover；17步 ordinary frame |
| halfspace_negative_product_valued3_result.json | 60 | 28 | 666 | 三单步 seed，powers(1,2,9)，D=(1,3,1)；无参考 frame 输入 |
| uniform_folded_markov_result.json | 31 | 16 | 27 | Markov target；无目标 frame；uniform skew-fold comparison gate 已由 root 通过 |

七项完整多项式比较全部通过，见 `FINAL_IMPLEMENTATION_COMPARISON.json`。K4 等于早先独立 ratio 和 signed-LU；cyclic6 等于完整 direct-LU；负乘积 rank3 等于独立 B-only closed formula。LLZ 仅在输出完成后作为独立核验，不在构造里调用。

## 负乘积内核

`negative_product_recovery.py` 先核实际不同 seed 的 g/C/G inverse，再选负配对 seed，逐增量恢复总 C。独立比较：valued3 的216个全部可比矩阵项、cyclic6 的729个全部可比矩阵项均等于参考 frame 总变换；reference 只在恢复之后使用。valued3 的216项另外全部等于无环二项式闭式。

主入口模式 `transport:"negative_product"` 已完整接通普通 seed F 多项式、H^N 正载体、总 C 恢复和半空间链。不是只提交未接入的矩阵样例。

## Uniform folding 的确切限制

`uniform_folded_halfspace.py` 是一般覆盖接口，非 Markov 硬编码。它验证 equal orbit size、block constant、zero internal block、cover skew symmetry、cover D 为同一正标量，以及同 orbit 各代表的聚合 H 完全相等。当前明确拒绝一般 valued cover folding，避免超出已审范围。

Root 已亲读 Zhou 的式(3.1),(3.2)、第20页并接受 uniform normalization + 负正交象限比较。结果 JSON 和 README 已由 conditional wording 改成引用独立已证明比较定理。一般情形只声称 theta functions / middle-algebra family；Markov U 全基还要 Zhou Theorem5.1。不得把全部折叠推广成 U 全基。

## 打包所需核心文件

最小无环包只有 `halfspace_chain.py` 和 `integer_polynomials.py`。完整主包再加：

- `exact_frame_polynomials.py`
- `signed_lu_reconstruction.py`（frame g/C 验证与旧独立 LU）
- `negative_product_recovery.py`
- `uniform_folded_halfspace.py`
- `inputs/` 中当前输入 JSON
- 本 README、当前结果 JSON、比较记录。

`classical_frame_paths.py`、`classical_*_result.json` 是独立 direct-LU 交叉核验，建议保留。旧 `integer_ratio_reconstruction.py`、严格 Pieri 和 Q 路线放研究附录；不再是最简主算法的依赖。研究目录约28MB，核心实现与当前完整结果远小于1MB。

## 精确性与已停止的工作

所有主入口均实际用 `python -S` 运行。普通 exchange 多项式整除逐步乘回检查；halfspace 每一逆行检查完整 `T C[I,I]=e_p`；无浮点数参与。

旧 K4 完整 Laurent-space symbolic-rank run 因960维而中止，没有完成结果。之后同一个1260点完整载体已由新半空间算法全部算完，不能再把旧中止当成当前限制。早期1260层 least/Pieri family 仍只保持当时的识别范围；一个 target 的新 theta 识别不自动把整个旧family升级。

文献刷新已记录：Nakanishi §2.3 已有符号群分解，不能将该唯一性本身宣称为新定理。当前交付是从普通交换数据得到显式有限整数矩阵与半空间链的纯组合构造。

## 10:05 补充：非等大 orbit 折叠已实现

Root 于10:02确认 nonuniform normalization 后，新增一般主扩展 `block_folded_halfspace.py`，旧 `uniform_folded_halfspace.py` 只是兼容入口。cover skew/common scalar D 的限制保留；orbit 大小可以不同。派生 **Bbar_ab=r_a b_ab（行缩放）**、Dbar_a=lcm(r)/r_a。

A3→valued B2 的完整目标 g=(-3,-2) 已重算：18点carrier、18项、mass108，18条星邻Laurent全通过；与独立 B-only 二项式闭式完全相等。文件 `block_folded_valued_b2_result.json` 和 `fold_comparison_valued_b2_result.json`。Markov旧例用一般代码重跑，仍16项mass27。README、比较记录和 manifest 的文件哈希均已随此更新。
