#!/usr/bin/env python3
"""Finite integer signed-LU reconstruction from an ordinary negative frame.

No quantum parameter, Q-cap, large-label solver, theta oracle, scattering
wall list, or broken line enters this construction. The proof comparison
uses the unique sign factorization of the actual chart transport.
"""
from pathlib import Path
from functools import lru_cache
from itertools import product
from collections import defaultdict
from fractions import Fraction
import json,time,sys
from integer_polynomials import (pts,inside,subp,addp,mul,power,inv,
 monomial_image,seed_mutate,cluster_F_jets,divisibility_space,
 atomic,dump_poly)


def frame_data(B,word,D=None):
 B=tuple(map(tuple,B));n=len(B);D=tuple(D or [1]*n)
 assert all(D[i]*B[i][j]==-D[j]*B[j][i] for i in range(n) for j in range(n))
 BB=B;C=tuple(tuple(int(i==j) for j in range(n)) for i in range(n));bounds=[[0]*n for _ in range(n)];G=[[int(i==j) for j in range(n)] for i in range(n)]
 for k in word:
  c=[C[i][k] for i in range(n)];eps=1 if all(a>=0 for a in c) else -1
  assert all(eps*a>=0 for a in c) and any(c),('non-sign-coherent actual seed',c)
  new_g=[-G[i][k]+sum(max(-eps*BB[j][k],0)*G[i][j] for j in range(n)) for i in range(n)]
  for i in range(n):G[i][k]=new_g[i]
  old=bounds[k]
  bounds[k]=[max(max(C[i][k],0)+sum(max(BB[j][k],0)*bounds[j][i] for j in range(n)),max(-C[i][k],0)+sum(max(-BB[j][k],0)*bounds[j][i] for j in range(n))) for i in range(n)]
  BB,C=seed_mutate(BB,C,k)
 assert all(sum(G[k][i]*D[k]*C[k][j] for k in range(n))==(D[i] if i==j else 0) for i in range(n) for j in range(n))
 perm={}
 for j in range(n):
  col=[G[i][j] for i in range(n)];hits=[i for i,a in enumerate(col) if a==-1]
  assert len(hits)==1 and all(a in (0,-1) for a in col),('not an ordinary negative frame',G)
  perm[hits[0]]=j
 assert len(perm)==n
 return {'B':B,'D':D,'word':tuple(word),'terminal_B':BB,'C':C,'G':G,'permutation':[perm[i] for i in range(n)],'frame_boxes':[bounds[perm[i]] for i in range(n)],'integer_tropical_duality_checked':True}


def near_direction(m,box,D):
 Q=pts(box)[1:];bound=sum(a*b for a,b in zip(D,box))
 for M in range(1,bound+2):
  u=tuple(M*a+1 for a in m)
  if all((v:=sum(u[i]*D[i]*q[i] for i in range(len(m))))!=0 and v*sum(m[i]*D[i]*q[i] for i in range(len(m)))>=0 for q in Q):return u,M
 raise ArithmeticError('finite generic direction bound failed')

class FactorResourceError(Exception):pass

class SignedLU:
 def __init__(self,B,negative_word,D=None,max_factor_points=20000):
  self.B=tuple(map(tuple,B));self.n=len(B);self.D=tuple(D or [1]*self.n);self.frame=frame_data(B,negative_word,self.D);self.word=tuple(negative_word);self.jetcache={};self.records=[];self.max_factor_points=max_factor_points
 def frame_jets(self,box):
  box=tuple(box)
  if box not in self.jetcache:
   F=cluster_F_jets(self.B,self.word,box);self.jetcache[box]=[F[j] for j in self.frame['permutation']]
  return self.jetcache[box]
 def factor(self,g,box,u):
  g=tuple(g);box=tuple(box);number=1
  for a in box:number*=a+1
  if self.max_factor_points is not None and number>self.max_factor_points:raise FactorResourceError({'status':'factor_box_resource_stop','box':box,'points':number,'budget':self.max_factor_points})
  P=pts(box);idx={p:i for i,p in enumerate(P)};N=len(P);FI=self.frame_jets(box)
  Phi=[]
  for q in P:
   h=tuple(-g[i]-sum(self.B[i][j]*q[j] for j in range(self.n)) for i in range(self.n));Phi.append(monomial_image(FI,h,subp(box,q)))
  minus=[{i:1} for i in range(N)];pluscol=[{i:1} for i in range(N)];nonzero_minus=nonzero_plus=0
  for delta in P[1:]:
   lam=sum(u[i]*self.D[i]*delta[i] for i in range(self.n));assert lam
   for q in pts(subp(box,delta)):
    p=addp(q,delta);ii=idx[p];jj=idx[q]
    r=Phi[jj].get(delta,0)
    # Both factors at strictly smaller total increment are already fixed.
    common=minus[ii].keys() & pluscol[jj].keys()
    r-=sum(minus[ii][kk]*pluscol[jj][kk] for kk in common if kk!=ii and kk!=jj)
    if r:
     if lam<0:minus[ii][jj]=r;nonzero_minus+=1
     else:pluscol[jj][ii]=r;nonzero_plus+=1
  # Check the entire exact product, not only signs or sampled entries.
  for ii,p in enumerate(P):
   for jj,q in enumerate(P):
    if not inside(q,p):continue
    value=sum(minus[ii][kk]*pluscol[jj][kk] for kk in minus[ii].keys() & pluscol[jj].keys())
    assert value==Phi[jj].get(subp(p,q),0),('factorization',p,q,value)
  return P,minus,{'points':N,'minus_nonzero':nonzero_minus,'plus_nonzero':nonzero_plus,'product_identity_checked':True}
 def extraction_row(self,g,p,fr):
  p=tuple(p);m=tuple(g[i]+sum(self.B[i][j]*p[j] for j in range(self.n)) for i in range(self.n));u,M=near_direction(m,p,self.D);P,minus,cert=self.factor(g,p,u);idx={q:i for i,q in enumerate(P)};width=len(next(iter(fr.values())));zero=(0,)*width;rem={q:tuple(fr.get(q,zero)) for q in P}
  for jj,q in enumerate(P):
   row=rem.pop(q,zero)
   if q==p:
    cert.update(p=p,m=m,u=u,M=M,row=row);self.records.append(cert);return row,cert
   if any(row):
    for ii,t in enumerate(P):
     if ii<=jj:continue
     a=minus[ii].get(jj,0)
     if a:rem[t]=tuple(x-a*y for x,y in zip(rem.get(t,zero),row))
  raise ArithmeticError('missing row')
 def reconstruct_space(self,g,S,outfile=None):
  import sympy as sp
  g=tuple(g);fr,space=divisibility_space(self.B,g,S);zz=(0,)*self.n;origin=fr[zz];j=next(i for i,a in enumerate(origin) if a);width=len(origin);rows=[origin];rhs=[1];steps=[];tic=time.time()
  # Earliest unfixed Laurent coefficients are the natural extraction roots.
  candidates=sorted((p for p,r in fr.items() if any(p) and any(Fraction(a)*origin[j]!=Fraction(r[j])*b for a,b in zip(r,origin))),key=lambda p:(sum(p),p))
  for p in candidates:
   if len(rows)==width:break
   row,cert=self.extraction_row(g,p,fr)
   if any(row) and sp.Matrix(rows+[row]).rank()>len(rows):
    rows.append(row);rhs.append(0);steps.append(cert);print('LU EXTRACT',p,'mutable',cert['m'],'rank',len(rows),'of',width,flush=True)
  x,param=sp.Matrix(rows).gauss_jordan_solve(sp.Matrix(rhs));assert not param.rows,('unfixed target',space,len(rows));F={p:sum(a*b for a,b in zip(r,x)) for p,r in fr.items()};assert all(a.q==1 for a in F.values());F={p:int(a) for p,a in F.items() if a}
  result={'status':'exact_signed_LU_reconstruction','B':self.B,'D':self.D,'g':g,'frame':self.frame,'space':space,'parameters':[str(a) for a in x],'rows':rows,'steps':steps,'F':dump_poly(F),'mass':sum(F.values()),'nonnegative':all(a>=0 for a in F.values()),'seconds':time.time()-tic,'scope':'pure exchange negative frame plus finite integer sign-LU and inverse extraction; no theta data supplied'}
  if outfile:atomic(outfile,result)
  return F,result
 def coefficient_recurrence(self,g,box,outfile=None,support=None):
  """Direct triangular recurrence; no Laurent-space membership test is used.

  Optional support is a proved positive standard-product carrier. Every
  coefficient outside it is prescribed zero; LU itself still uses full
  downward boxes, so no omitted intermediate matrix index is assumed zero.
  """
  zz=(0,)*self.n;F={zz:1};steps=[];tic=time.time()
  candidates=pts(box)[1:] if support is None else sorted((tuple(p) for p in support if any(p)),key=lambda p:(sum(p),p))
  for p in candidates:
   fr={q:(a,) for q,a in F.items()};fr.setdefault(zz,(1,));row,cert=self.extraction_row(g,p,fr);a=-row[0]
   if a:F[p]=a
   steps.append({'p':p,'a':a,'u':cert['u'],'M':cert['M'],'factor_points':cert['points'],'minus_nonzero':cert['minus_nonzero'],'plus_nonzero':cert['plus_nonzero'],'product_identity_checked':cert['product_identity_checked']})
  result={'status':'complete_integer_coefficient_recurrence','B':self.B,'D':self.D,'g':g,'box':box,'carrier_points':len(candidates)+1,'frame':self.frame,'F':dump_poly(F),'mass':sum(F.values()),'nonnegative':all(a>=0 for a in F.values()),'steps':steps,'seconds':time.time()-tic}
  if outfile:atomic(outfile,result)
  return F,result

def standard_carrier(B,negative_word,g,D=None):
 """Compute the full positive product of the ordinary negative-frame Fs."""
 from exact_frame_polynomials import frame_polynomials,pow_poly,multiply
 I,cert=frame_polynomials(B,negative_word,D);P={(0,)*len(g):1}
 for i,a in enumerate(g):
  if a<0:P=multiply(P,pow_poly(I[i],-a))
 return P,cert

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--case',default='valued2',choices=['k4','primitive','wild2','valued2','hardfork','cyclic6']);ap.add_argument('--input',type=str);ap.add_argument('--mode',choices=['direct','star'],default='direct');ap.add_argument('--output',type=str);ar=ap.parse_args();out=Path(__file__).parent
 if ar.case=='k4':B=[[1 if i<j else -1 if i>j else 0 for j in range(4)] for i in range(4)];d=(4,5,5,6);D=(1,)*4
 elif ar.case=='primitive':B=((0,1,1),(-1,0,1),(-1,-1,0));d=(2,2,2);D=(1,)*3
 elif ar.case=='wild2':B=((0,3),(-3,0));d=(4,5);D=(1,1)
 elif ar.case=='valued2':B=((0,4),(-2,0));d=(3,4);D=(1,2)
 elif ar.case=='hardfork':B=((0,3,1),(-3,0,2),(-1,-2,0));d=(4,6,7);D=(1,)*3
 elif ar.case=='cyclic6':
  B=((0,-1,1,1,-1,0),(1,0,-1,-1,0,1),(-1,1,0,0,1,-1),(-1,1,0,0,1,-1),(1,0,-1,-1,0,1),(0,-1,1,1,-1,0));D=(1,)*6;d=None
 if ar.input:
  inp=json.loads(Path(ar.input).read_text());B=inp['B'];D=inp.get('D',[1]*len(B));g=tuple(inp['g']);word=tuple(inp['negative_word'])
 elif ar.case=='cyclic6':g=(-1,-1,1,0,0,0);word=(2,0,1,5,3,5,2,4,0,3,0,4,5,3,1,4,3)
 else:g=tuple(-d[i]+sum(max(-B[i][j],0)*d[j] for j in range(len(d))) for i in range(len(d)));word=tuple(range(len(B)-1,-1,-1))
 E=SignedLU(B,word,D);P,framecert=standard_carrier(B,word,g,D);S=list(P);box=tuple(max(p[i] for p in P) for i in range(len(B)));outfile=Path(ar.output) if ar.output else out/('signed_lu_'+ar.case+'_'+ar.mode+'.json')
 if ar.mode=='direct':F,R=E.coefficient_recurrence(g,box,support=S)
 else:F,R=E.reconstruct_space(g,S)
 R.update(standard_carrier=dump_poly(P),standard_mass=sum(P.values()),exact_frame_certificate=framecert,algorithm_mode=ar.mode);atomic(outfile,R)
 print('DONE',ar.case,ar.mode,'carrier',len(S),'mass',R['mass'],'nonnegative',R['nonnegative'],'seconds',R['seconds'],flush=True)
