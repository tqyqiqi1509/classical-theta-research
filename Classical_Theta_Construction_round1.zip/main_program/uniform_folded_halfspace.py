#!/usr/bin/env python3
"""Compatibility entry point; general implementation is block_folded_halfspace."""
from block_folded_halfspace import *
if __name__=="__main__":main()
