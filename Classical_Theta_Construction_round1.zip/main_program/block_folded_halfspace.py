#!/usr/bin/env python3
"""Block-constant folding of an ordinary frame, then integer chains.

This file validates all finite input and matrix conditions. Identification
of the folded total transport with the target cluster transport additionally
uses the separately audited block-folding comparison theorem. No target
negative frame is presumed or supplied.
"""
from pathlib import Path
from functools import lru_cache
from collections import defaultdict
from math import comb,prod,lcm
import json,argparse,time
from exact_frame_polynomials import frame_polynomials,multiply,pow_poly
from integer_polynomials import dump_poly,monomial_image,subp,atomic
from halfspace_chain import chain_recurrence,ResourceStop

def validate_blocks(B,D,orbits):
    N=len(B);n=len(orbits)
    if len(D)!=N or any(a<=0 for a in D) or len(set(D))!=1:raise ValueError('the audited folding theorem requires a skew-symmetric cover: D is one common positive scalar')
    if any(B[i][j]!=-B[j][i] for i in range(N) for j in range(N)):raise ValueError('the audited block folding theorem requires skew-symmetric cover B')
    if not n or sorted(i for O in orbits for i in O)!=list(range(N)):raise ValueError('orbits must partition the covering vertices')
    sizes=tuple(len(O) for O in orbits)
    if any(a==0 for a in sizes):raise ValueError('orbits must be nonempty')
    common=lcm(*sizes)
    if any(D[i]*B[i][j]!=-D[j]*B[j][i] for i in range(N) for j in range(N)):raise ValueError('cover symmetrizer')
    target=[];d=[]
    for a,O in enumerate(orbits):
        if len({D[i] for i in O})!=1:raise ValueError('symmetrizer must be constant on each orbit')
        d.append(common//sizes[a]);row=[]
        for b,V in enumerate(orbits):
            entries={B[i][j] for i in O for j in V}
            if len(entries)!=1:raise ValueError('cover matrix is not constant on a block')
            v=next(iter(entries))
            if a==b and v!=0:raise ValueError('intra-orbit arrows are not allowed')
            row.append(sizes[a]*v)
        target.append(row)
    if any(d[i]*target[i][j]!=-d[j]*target[j][i] for i in range(n) for j in range(n)):raise ValueError('folded symmetrizer')
    return tuple(map(tuple,target)),tuple(d),sizes

def aggregate(F,orbits):
    H=defaultdict(int)
    for p,a in F.items():H[tuple(sum(p[i] for i in O) for O in orbits)]+=a
    return dict(H)

def star_laurent_check(B,g,F):
    checked=0
    for k in range(len(g)):
        fibers=defaultdict(dict)
        for p,a in F.items():fibers[p[:k]+p[k+1:]][p[k]]=a
        for off,fiber in fibers.items():
            p=off[:k]+(0,)+off[k:]
            order=max(-g[k]-sum(B[k][j]*p[j] for j in range(len(g))),0)
            for j in range(order):
                value=sum(a*comb(q,j)*(-1)**(q-j) for q,a in fiber.items() if q>=j)
                if value:return {'passed':False,'vertex':k,'off':off,'derivative':j,'value':value,'equations_checked':checked}
                checked+=1
    return {'passed':True,'equations_checked':checked}

def construct(data,max_points=20000):
    tic=time.time();B=data['cover_B'];D=data.get('cover_D',[1]*len(B));orbits=data['orbits'];g=tuple(data['g']);word=data['cover_negative_word']
    folded,folded_D,sizes=validate_blocks(B,D,orbits)
    if len(g)!=len(orbits):raise ValueError('target label dimension')
    I,certificate=frame_polynomials(B,word,D)
    H=[]
    for O in orbits:
        representatives=[aggregate(I[i],orbits) for i in O]
        if any(f!=representatives[0] for f in representatives):raise ValueError('folded frame polynomials depend on representative')
        H.append(representatives[0])
    P={(0,)*len(g):1}
    for i,a in enumerate(g):
        if a<0:P=multiply(P,pow_poly(H[i],-a))
    if max_points is not None and len(P)>max_points:raise ResourceStop({'stage':'folded_carrier','points':len(P),'budget':max_points})
    @lru_cache(None)
    def C(r,q):
        h=tuple(-g[i]-sum(folded[i][j]*q[j] for j in range(len(g))) for i in range(len(g)))
        delta=subp(r,q)
        return monomial_image(H,h,delta).get(delta,0)
    F,steps,queries=chain_recurrence(folded,folded_D,g,P,C,max_points)
    laurent=star_laurent_check(folded,g,F)
    return {'status':'complete_block_folded_theta_chain_recurrence','completed':True,
      'input':data,'B':folded,'D':folded_D,'orbit_sizes':sizes,'g':g,
      'constant_block_and_internal_zero_checks':True,'row_size_normalization':'Bbar_ab=|O_a| b_ab; Dbar_a=lcm(|O|)/|O_a|','orbit_representative_independence_checked':True,
      'cover_frame':certificate,'folded_H':[dump_poly(HH) for HH in H],
      'positive_carrier':dump_poly(P),'carrier_points':len(P),'carrier_mass':sum(P.values()),
      'F':dump_poly(F),'terms':len(F),'mass':sum(F.values()),'nonnegative':all(a>0 for a in F.values()),
      'steps':steps,'all_inverse_rows_checked':True,'star_laurent_check':laurent,
      'distinct_transport_entries':C.cache_info().currsize,'matrix_queries':queries,
      'seconds':time.time()-tic,'target_negative_frame_input':False,
      'comparison_theorem':'work/agent_cyclic_generic_bridge/FOLDING_CHAIN_EXTENSION.md; root primary audit of Zhou SIGMA16(2020)013 equations(3.1),(3.2), p20, and separate nonuniform row-size normalization check',
      'scope':'Theta functions and their middle-algebra family under the separately proved block skew-cover comparison theorem with arbitrary positive orbit sizes. Constant blocks, zero internal blocks and common scalar cover D are verified. Folded B uses row orbit sizes; folded D is lcm(orbit sizes) divided by each orbit size. General upper-algebra full-basis identification is not asserted; the Markov U-basis statement additionally uses Zhou Theorem5.1.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--max-points',type=int,default=20000);a=ap.parse_args()
    out=a.output or a.input.with_name(a.input.stem+'_result.json')
    try:R=construct(json.loads(a.input.read_text()),a.max_points)
    except ResourceStop as error:
        atomic(out,{'completed':False,'status':'resource_stop','detail':error.args[0]});raise SystemExit(2)
    atomic(out,R);print(json.dumps({k:R[k] for k in ['status','B','carrier_points','terms','mass','nonnegative','star_laurent_check','seconds']}))

if __name__=='__main__':main()
