#!/usr/bin/env python3
"""Finite integer recovery of negative-to-initial transport from many seeds.

The inputs are ordinary mutation words and a positive product of their cluster
variables whose sum of g-vectors is strictly negative.  A common negative
cluster is not an input.  The optional validation command compares the result
against a separately supplied negative frame only after recovery is complete.
"""
from integer_polynomials import (pts,inside,subp,addp,seed_mutate,
    cluster_F_jets,monomial_image,atomic)
from signed_lu_reconstruction import SignedLU
from pathlib import Path
import json,time

def seed_data(B,word,D):
    n=len(B);BB=tuple(map(tuple,B))
    C=tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
    G=[[int(i==j) for j in range(n)] for i in range(n)]
    for k in word:
        col=[C[i][k] for i in range(n)]
        eps=1 if all(a>=0 for a in col) else -1
        assert any(col) and all(eps*a>=0 for a in col)
        updated=[-G[i][k]+sum(max(-eps*BB[j][k],0)*G[i][j]
                    for j in range(n)) for i in range(n)]
        for i in range(n):G[i][k]=updated[i]
        BB,C=seed_mutate(BB,C,k)
    inverse=[]
    for i in range(n):
        row=[]
        for j in range(n):
            a=C[j][i]*D[j]
            assert a%D[i]==0
            row.append(a//D[i])
        inverse.append(row)
    assert all(sum(inverse[i][k]*G[k][j] for k in range(n))==int(i==j)
               for i in range(n) for j in range(n))
    return {'word':word,'G':G,'C':C,'G_inverse':inverse,
            'integer_tropical_inverse_checked':True}

def inverse_unitriangular(P,A):
    N=len(P);S=[{i:1} for i in range(N)]
    for i,p in enumerate(P):
        for j,q in enumerate(P[:i]):
            if not inside(q,p):continue
            value=-sum(a*S[r].get(j,0) for r,a in A[i].items() if r<i)
            if value:S[i][j]=value
    for i,p in enumerate(P):
        for j,q in enumerate(P[:i+1]):
            if inside(q,p):
                assert sum(a*S[r].get(j,0) for r,a in A[i].items())==int(i==j)
    return S

def seed_transport(B,g,box,D,data):
    P=pts(box);F=cluster_F_jets(B,data['word'],box)
    A=[{} for _ in P]
    for j,q in enumerate(P):
        h=[g[i]+sum(B[i][k]*q[k] for k in range(len(g))) for i in range(len(g))]
        e=[sum(data['G_inverse'][i][k]*h[k] for k in range(len(g))) for i in range(len(g))]
        column=monomial_image(F,e,subp(box,q))
        for i,p in enumerate(P):
            if inside(q,p):
                a=column.get(subp(p,q),0)
                if a:A[i][j]=a
    assert all(A[i].get(i)==1 for i in range(len(P)))
    return A,inverse_unitriangular(P,A)

def recover(B,D,g,box,words,product_factors):
    """Return the complete transport matrix on [0,box], with exact checks.

    product_factors contains (seed_index, column_index, positive_power).
    The matrix recurrence itself needs only a negative-pairing cover; the
    checked negative product supplies that cover uniformly in every box.
    """
    tic=time.time();n=len(g);P=pts(box);ids={p:i for i,p in enumerate(P)}
    assert all(D[i]*B[i][j]==-D[j]*B[j][i] for i in range(n) for j in range(n))
    data=[seed_data(B,word,D) for word in words]
    h=[0]*n
    for s,j,a in product_factors:
        assert int(a)==a and a>0
        for i in range(n):h[i]+=a*data[s]['G'][i][j]
    assert all(a<0 for a in h),('product is not strictly negative',h)
    chosen={};used=set();cover=[]
    for delta in P[1:]:
        s,j,a=next((s,j,a) for s,j,a in product_factors
             if sum(data[s]['G'][i][j]*D[i]*delta[i] for i in range(n))<0)
        chosen[delta]=s;used.add(s)
        pairing=sum(data[s]['G'][i][j]*D[i]*delta[i] for i in range(n))
        other=sum(data[s]['G'][i][k]*D[i]*delta[i]
                  for i in range(n) for k in range(n) if k!=j)
        M=1+max(0,other)
        v=[M*data[s]['G'][i][j]+sum(data[s]['G'][i][k]
                      for k in range(n) if k!=j) for i in range(n)]
        assert sum(v[i]*D[i]*delta[i] for i in range(n))<0
        cover.append({'delta':delta,'seed':s,'column':j,'pairing':pairing,
                      'interior_direction':v,'positive_cone_coordinate':M})
    matrices={}
    for s in sorted(used):
        A,S=seed_transport(B,g,box,D,data[s]);matrices[s]=(A,S)
    C=[{i:1} for i in range(len(P))]
    equations=0
    for delta in P[1:]:
        S=matrices[chosen[delta]][1]
        for q in pts(subp(box,delta)):
            p=addp(q,delta);i=ids[p];j=ids[q]
            value=-sum(a*C[r].get(j,0) for r,a in S[i].items() if r!=i)
            if value:C[i][j]=value
            assert sum(a*C[r].get(j,0) for r,a in S[i].items())==0
            equations+=1
    result={'status':'complete_negative_product_transport_recovery',
      'B':B,'D':D,'g':g,'box':box,'points':P,'seeds':data,
      'product_factors':product_factors,'negative_product_g':h,'cover':cover,
      'used_seed_indices':sorted(used),'checked_vanishing_equations':equations,
      'all_seed_inverse_products_checked':True,
      'matrix_rows':[{str(j):a for j,a in row.items()} for row in C],
      'seconds':time.time()-tic,'negative_frame_used_in_recovery':False,
      'wall_or_theta_input':False}
    return P,C,result

def compare_frame(B,D,g,box,reference_word,P,C):
    engine=SignedLU(B,reference_word,D);H=engine.frame_jets(box);checked=0
    for j,q in enumerate(P):
        h=tuple(-g[i]-sum(B[i][k]*q[k] for k in range(len(g))) for i in range(len(g)))
        column=monomial_image(H,h,subp(box,q))
        for i,p in enumerate(P):
            if inside(q,p):
                assert C[i].get(j,0)==column.get(subp(p,q),0),(p,q)
                checked+=1
    return {'all_comparable_entries_equal':True,'entries_checked':checked,
            'reference_word':reference_word,
            'reference_used_only_after_recovery':True}

if __name__=='__main__':
    out=Path(__file__).parent
    # Three genuinely different one-mutation seeds. None is a negative frame.
    B=((0,3,2),(-1,0,1),(-2,-3,0));D=(1,3,1);g=(-2,1,0);box=(2,2,2)
    words=[(0,),(1,),(2,)];factors=[(0,0,1),(1,1,2),(2,2,9)]
    P,C,R=recover(B,D,g,box,words,factors)
    R['independent_reference']=compare_frame(B,D,g,box,(2,1,0),P,C)
    atomic(out/'negative_product_valued3_result.json',R)
    print('VALUED3',R['negative_product_g'],R['checked_vanishing_equations'],R['independent_reference'],flush=True)
    # Actual mutation-cyclic rank six: select each final negative variable in
    # its first available prefix, then recover using those different seeds.
    B=((0,-1,1,1,-1,0),(1,0,-1,-1,0,1),(-1,1,0,0,1,-1),
       (-1,1,0,0,1,-1),(1,0,-1,-1,0,1),(0,-1,1,1,-1,0))
    D=(1,)*6;g=(-1,-1,1,0,0,0);box=(1,)*6
    word=(2,0,1,5,3,5,2,4,0,3,0,4,5,3,1,4,3)
    prefix_data=[seed_data(B,word[:k],D) for k in range(1,len(word)+1)]
    witnesses=[]
    for i in range(6):
        witnesses.append(next((k,j) for k,data in enumerate(prefix_data,1)
           for j in range(6) if all(data['G'][r][j]==(-1 if r==i else 0) for r in range(6))))
    lengths=sorted(set(k for k,j in witnesses));words=[word[:k] for k in lengths]
    factors=[(lengths.index(k),j,1) for k,j in witnesses]
    P,C,R=recover(B,D,g,box,words,factors)
    R['independent_reference']=compare_frame(B,D,g,box,word,P,C)
    atomic(out/'negative_product_cyclic6_result.json',R)
    print('CYCLIC6',R['negative_product_g'],R['checked_vanishing_equations'],R['independent_reference'],flush=True)
