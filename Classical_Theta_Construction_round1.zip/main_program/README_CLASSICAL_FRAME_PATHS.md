# 经典 theta 的有限整数半空间链：可运行实现

更新：2026-11-13 10:05 UTC。**最新主入口是 `halfspace_chain.py`。** 它已取代早先需要大标签比值、Q 支撑筛选或者 signed LU 的主计算路线。以下全部计算是经典的；没有量子参数。

## 1. 输入、输出与适用范围

对于任意秩的**斜对称化无环**交换矩阵，主入口只需要整数矩阵 `B`、正整数对角对称子 `D`（以对角数组给出，满足 `D B` 斜对称）和标签 `g`。它自动验证拓扑顺序，给出有限的二项式载体，并通过明确的有符号整数链计算每个系数。无环输入不需要 mutation word。

对于一般有向环输入，主入口接受一个明确的 ordinary negative-frame mutation word，或者采用 `transport:"negative_product"` 模式，输入不同 seed 的普通 mutation words 及其变量的正乘积。前者实际变异并核验负置换 g 矩阵；后者实际核验乘积 leading g 严格负。两种情况均从普通 exchange 计算完整 F 多项式。负乘积模式不要求这些变量属于同一个 cluster，其全矩阵恢复由 `negative_product_recovery.py` 完成。

规范为主系数、`z_j = y_j product_i x_i^(B_ij)`，输出

\[
\vartheta_g=x^g F_g(z),\qquad F_g(z)=\sum_p a_p z^p.
\]

比较定理识别这些完全独立定义的整数为 theta 系数。**算法输入没有散射图、墙函数、broken lines、几何对象、theta 系数或其 oracle。** 识别证明使用既有 theta 坐标变换理论；不宣称该比较证明也已完全初等化。链的权重允许负数，不能把它说成无消去的独立集计数。

无环时普通丛代数 `A` 与上丛代数 `U` 相等，因此这里给出普通丛代数的基。对一般 cyclic 输入，已采用的基定理的环境是 `U`；是否得到 `A` 的基需要另有 `A=U` 条件。程序没有把负框架存在误写成任意 cyclic 情形的 `A=U`。缺少目标负框架或负乘积时，第8节提供另一条经明确覆盖证书验证的途径；仍不声称任意交换矩阵自动具有所需证书。

## 2. 最简运行方式

只需 Python 标准库；以下命令使用 `-S` 禁止加载 site-packages，已经实际成功运行。

```sh
python -S halfspace_chain.py inputs/k4_acyclic_only.json --output halfspace_k4_result.json
python -S halfspace_chain.py inputs/valued_rank2_acyclic_only.json --output halfspace_valued_rank2_result.json
python -S halfspace_chain.py inputs/cyclic_rank6.json --output halfspace_cyclic_rank6_result.json
python -S halfspace_chain.py inputs/valued_rank3_negative_product.json --output halfspace_negative_product_valued3_result.json
```

这里在本目录运行。最小无环输入示例为：

```json
{"B":[[0,4],[-2,0]],"D":[1,2],"g":[-3,2]}
```

一般 cyclic 输入增加 `negative_word`，mutation 编号从 0 开始。结果 JSON 保存全部非零系数、整个正载体、每个目标点的半空间大小及逆矩阵行恒等式核验结果。系数以十进制字符串保存，避免读入程序把大整数转为浮点数。

## 3. 无环闭式与半空间整数链

把顶点置于拓扑顺序，令 `B_ij>=0` 当 `i<j`。正标准乘积的容量递推是

\[
d_i=\left[-g_i-\sum_{j<i}B_{ij}d_j\right]_+.
\]

载体为完整盒 `0<=p<=d`，正 majorant 为 `product_i (1+z_i)^d_i`。此处没有 Q 不等式，也没有通过后验 theta 支撑删点。

固定标签 g，总变换矩阵有纯二项式闭式：

\[
C_{rq}=\prod_i\binom{-g_i-\sum_{j<i}B_{ij}r_j-\sum_{j>i}B_{ij}q_j}{r_i-q_i}
\quad(q\le r).
\]

整数上指标可以是负数，采用通常的广义二项式约定。矩阵沿分量偏序为单位下三角。

对每个目标点 `p`，令 `m=g+Bp`，并只取有限半空间

\[
I_p=\{p\}\cup\{q:0\le q\le p,\ m^TD(p-q)<0\}.
\]

设 `T_pq` 是主子矩阵 `C[I_p,I_p]` 的逆矩阵第 p 行，行外取零。它直接按根度下降计算：

\[
T_{pp}=1,\qquad
T_{pq}=-\sum_{q<r\le p,\ r\in I_p}T_{pr}C_{rq}.
\]

最后按根度上升计算

\[
a_0=1,\qquad a_p=-\sum_{q<p}T_{pq}a_q.
\]

这里每一处 `q<r` 均指分量不等式且不相等。逆矩阵条目就是有限严格链上的符号乘积和；最外层递推也给出一个有限有向无环图上的整数路径权重和。因此主对象是用户要求的“显式递推的整数权重组合对象”。它不需要先构造任何墙数据再替换名称。

实现保留 `I_p` 内**全部**中间格点。即便某些点不属于正载体、因而最终系数已知为零，也没有从逆矩阵链中删去它们。等号 `m^TD(p-q)=0` 归入不选择的一侧；这个细节已和独立 signed-LU 实现逐系数核对。

## 4. 一般框架和不同 seed 的负乘积

若提供 ordinary negative frame，程序计算

\[
I_i=x_i^{-1}H_i(z),\qquad
C_{rq}=[z^{r-q}]\prod_i H_i(z)^{-(g+Bq)_i}.
\]

正载体取完整普通乘积 `product_i H_i^[-g_i]_+` 的支撑。每一步 exchange 的整除都由乘回原分子检查。随后使用的仍是同一个半空间链递推。

更一般的 `negative_product_recovery.py` 接收一组普通 mutation words 和三元组 `(seed_index,column_index,positive_power)`。先验证这些 g 向量的加权和 `h<0`。对于每个正增量 δ，它选择配对 `g_tj^T Dδ<0` 的一个 seed，计算其到初始坐标的矩阵 `C_t` 及整数逆 `S_t`，然后逐区间长度恢复

\[
C_{pq}=-\sum_{q\le r<p}(S_t)_{pr}C_{rq}.
\]

这里 seed 可以随 δ 改变。恢复过程没有读取参考负框架。参考框架只在恢复完成后作独立全矩阵比较。文件 `negative_product_valued3_result.json` 和 `negative_product_cyclic6_result.json` 保存了全部恢复矩阵、负乘积证书、所选内部方向和全项比较结果。

主入口已经接入负乘积的完整流程。若该乘积的 F 多项式为 H、leading g 为 h<0，则取最小非负整数 N 使 v=g−Nh≥0，以 H^N 为正载体；恢复总矩阵后，仍执行同一个 `chain_recurrence`。输入中 `product_factors` 的一个示例是 `[[0,0,1],[1,1,2],[2,2,9]]`，每项依次为 seed、变量列、正整数幂。这个模式没有使用参考负框架。

## 5. 已完成的关键计算

| 输入 | 完整载体 | 输出项数 | 系数总和 | 核验 |
|---|---:|---:|---:|---|
| 单位上三角 K4，g=(-4,-1,4,8)，d=(4,5,5,6) | 1260 | **122** | **1829** | 全载体半空间链；逐系数等于早先独立 ratio 和 LU 输出 |
| B=((0,4),(-2,0))，D=(1,2)，g=(-3,2) | 20 | 10 | 32 | 逐系数等于完整 frame-LU 和独立 LLZ |
| 四穿孔球面 rank6 cyclic 输入，g=(-1,-1,1,0,0,0) | 58 | 22 | 27 | 逐系数等于独立 direct-LU；完整 17 步 frame exchange |
| 三个不同 seed 的 valued rank3 负乘积，D=(1,3,1)，g=(-1,-1,-1) | 60 | 28 | 666 | 完整负乘积流程；逐系数等于独立 B-only 二项式闭式 |

K4 全载体计算约 0.5 秒，实际访问 22,806 个不同总变换矩阵条目；没有使用旧研究路线中的 Q 支撑压缩。rank6 cyclic 计算约 4.1 秒。耗时依赖机器，不是复杂度承诺。

四穿孔球面例确实 **mutation-cyclic**：另一独立分支穷尽了全部 270 个带标号 mutation 矩阵及 1620 条有向变异边，没有无环 seed；另以 Wolfram 计算插件独立复算。因此它不是把无环情形换到一个有环初始坐标后重复展示。

负乘积内核还通过了两个全矩阵比较：

- 值化 rank3，D=(1,3,1)，三个互异的单步 seed，乘积幂 (1,2,9)，给 h=(-1,-1,-1)。27 点盒的全部 216 个可比条目等于独立 frame transport；也等于无环二项式闭式。
- 真正 cyclic rank6，六个不同前缀 seed，64 点盒的全部 729 个可比条目等于独立 frame transport。

## 6. 文件职责与早期路线

- **`halfspace_chain.py`**：当前推荐入口，半空间链与无环二项式闭式。
- `integer_polynomials.py`：精确整数形式多项式。可选的旧 Laurent-space 函数局部导入 SymPy；当前主入口没有调用它。
- `exact_frame_polynomials.py`、`signed_lu_reconstruction.py`：普通负框架的 exchange 数据；后者还保留独立 signed-LU 实现用于比较。
- `classical_frame_paths.py`：旧一步主入口，完整正载体 + direct signed-LU；仍纯标准库、可运行。
- `negative_product_recovery.py`：多 seed 负乘积的全矩阵恢复内核。
- `block_folded_halfspace.py`：任意 orbit 大小的块常值斜对称覆盖、有限折叠验证及同一半空间链；`uniform_folded_halfspace.py` 保留为兼容入口。
- `halfspace_*_result.json`：当前主结果；`classical_*_result.json`：独立 direct-LU 结果。
- `RESEARCH_LOG.md`、`LITERATURE_REVIEW.json`：成功、失败、适用范围与文献接口记录。

早先的 1260 层最小性证书、91,404 个正乘法检查和 Q/large-label 路线仍是研究记录。它们没有被改名成当前主定理的前提；单独的“系数逐点最小”也没有被误称为 theta 识别。

## 7. 文献接口与未作出的主张

按符号分解幂零群的唯一性已有明确文献：Nakanishi, *Cluster Algebras and Scattering Diagrams, Part III*, arXiv:2111.00800，§2.3 Lemma 2.15 与 Proposition 2.16（后者指向 GHKK Theorem 1.17 的证明）。因此不把“正负子群唯一分解”本身宣称为新发现。这里的交付是从普通 exchange 输入出发的有限整数矩阵/半空间链递推，以及其明确终止载体、比较证明和可运行实现。

比较定理、全基范围和主系数规范见同项目的 `NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md`、`NEGATIVE_PRODUCT_INTEGER_THETA_THEOREM.md` 及无环闭式推导。没有采用 Li–Pan 的结论，也没有依赖未审的 2026 论文结论。

算法保证的是数学上的有限性。`--max-points` 是显式资源门槛；若触发，输出 `completed:false` 并退出 2，不把部分结果写成完成。一般多项式中间膨胀仍可能很大；不宣称任意输入均能在固定时间或内存内算完。

## 8. 块常值斜对称覆盖的折叠接口

`block_folded_halfspace.py` 接受 cover B、cover D、cover ordinary negative word、orbit partition 和目标 g。当前已审范围要求 **cover B 斜对称，cover D 为同一个正标量乘单位矩阵**；程序明确拒绝一般非等值 cover D 的折叠，避免超出已审证明。orbit 大小可不同。程序验证分划、每个矩阵 block 常值、每个内部 block 为零，并派生

\[
\bar B_{ab}=r_a b_{ab},\qquad
\bar D_a=\operatorname{lcm}(r_1,\ldots,r_n)/r_a,
\]

其中 r_a=|O_a|。这是**行 orbit 大小**，不能误用列大小。目标可为斜对称化矩阵。随后普通 exchange 计算 cover 的 H_i，按 orbit 聚合根指数，并检查同一个 orbit 的**每个**代表所得 H 完全一致。最终使用的是同一个 `chain_recurrence`，不输入目标负框架。

```sh
python -S block_folded_halfspace.py inputs/uniform_folded_markov.json --output uniform_folded_markov_result.json
python -S block_folded_halfspace.py inputs/block_folded_valued_b2.json --output block_folded_valued_b2_result.json
```

四穿孔球面覆盖按 `[[0,5],[1,4],[2,3]]` 折叠得到 B=((0,−2,2),(2,0,−2),(−2,2,0))。目标 g=(-1,-1,1) 的完整载体有 31 点，输出 16 项、总和 27，所有系数非负，16 条初始星邻 Laurent 方程全部精确满足。此为通用接口的一次完整执行。

非等大折叠另做了完整独立核验：A3 覆盖的 orbit 大小为 (2,1)，派生目标 B=((0,2),(-1,0))、D=(1,2)。对 g=(-3,-2)，完整18点载体输出18项、总和108，18条星邻 Laurent 方程通过；完整多项式与完全独立的 B-only 二项式闭式逐系数相等。其普通 exchange H 还与目标 valued frame 独立比较一致。

目标 theta 的识别已由同项目单独审定的 block folding normalization 和负正交象限比较引理闭合，见 `work/agent_cyclic_generic_bridge/FOLDING_CHAIN_EXTENSION.md` 及非等大规范补充。主审核分支直接核阅 Zhou, SIGMA16(2020),013，式(3.1)、(3.2)及第20页；10:02又确认非等大 orbit 的行缩放及 D 规范。有限数值检查本身不替代这些证明。一般折叠的 theta 函数/中间代数 family 不自动推出整个上丛代数的全基断言；Markov 情形的 U 全基范围另用 Zhou Theorem5.1，不能推广成所有折叠的无条件全基结论。
