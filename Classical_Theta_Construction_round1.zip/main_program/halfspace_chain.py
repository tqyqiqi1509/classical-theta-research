#!/usr/bin/env python3
"""Classical theta coefficients by finite integer chains in a halfspace.

Acyclic input needs only B,D,g.  Its total transport has a closed generalized
binomial formula. Other inputs may supply an ordinary negative mutation frame
or a negative product of cluster variables from different seeds. No signed LU,
Laurent-space solver, Q bound, wall functions, or theta oracle is used.
"""
from pathlib import Path
from functools import lru_cache
from math import comb,prod
import argparse,json,time,sys
from integer_polynomials import pts,inside,subp,monomial_image,atomic,dump_poly

class ResourceStop(Exception):pass

def binomial_integer(a,k):
    if k<0:return 0
    if a<0:return (-1)**k*comb(k-a-1,k)
    return comb(a,k) if k<=a else 0

def topological_order(B):
    remaining=set(range(len(B)));order=[]
    while remaining:
        available=sorted(i for i in remaining if all(B[j][i]<=0 for j in remaining))
        if not available:return None
        i=available[0];order.append(i);remaining.remove(i)
    return order

def acyclic_transport_entry(B,g,order,r,q):
    """Closed total-transport coefficient for any verified topological order."""
    value=1
    for k,i in enumerate(order):
        upper=-g[i]-sum(B[i][j]*r[j] for j in order[:k])-sum(B[i][j]*q[j] for j in order[k+1:])
        value*=binomial_integer(upper,r[i]-q[i])
        if not value:break
    return value

def acyclic_carrier(B,g,order,budget):
    n=len(g);d=[0]*n;v=[0]*n
    for i in order:
        lower=sum(max(-B[i][j],0)*d[j] for j in range(n))
        d[i]=max(lower-g[i],0);v[i]=g[i]+d[i]-lower
    count=prod(a+1 for a in d)
    if budget is not None and count>budget:raise ResourceStop({'stage':'acyclic_carrier','points':count,'budget':budget})
    P={p:prod(comb(di,pi) for di,pi in zip(d,p)) for p in pts(d)}
    return P,{'kind':'acyclic_one_step_standard_product','capacity':d,
              'positive_initial_factor':v,'topological_order':order}

def chain_recurrence(B,D,g,P,C,max_points=20000,progress_every=0):
    """Reusable finite integer kernel for a certified total transport C."""
    tic=time.time();n=len(g)
    box=tuple(max(p[i] for p in P) for i in range(n));zero=(0,)*n
    F={zero:1};steps=[];matrix_queries=0
    for number,p in enumerate(sorted((p for p in P if any(p)),key=lambda p:(sum(p),p)),1):
        count=prod(a+1 for a in p)
        if max_points is not None and count>max_points:raise ResourceStop({'stage':'downward_intermediate_box','p':p,'points':count,'budget':max_points})
        m=tuple(g[i]+sum(B[i][j]*p[j] for j in range(n)) for i in range(n))
        I=[q for q in pts(p) if q==p or sum(m[i]*D[i]*(p[i]-q[i]) for i in range(n))<0]
        T={p:1}
        # Descending degree is triangular inversion of C[I,I], row p.
        for q in reversed(I[:-1]):
            value=0
            for r,a in T.items():
                if inside(q,r):value-=a*C(r,q);matrix_queries+=1
            if value:T[q]=value
        coefficient=-sum(a*F.get(q,0) for q,a in T.items() if q!=p)
        if coefficient:F[p]=coefficient
        # Recheck the full inverse-row identity on the selected halfspace.
        for q in I:
            assert sum(a*C(r,q) for r,a in T.items() if inside(q,r))==int(q==p),(p,q)
        steps.append({'p':p,'a':coefficient,'mutable_final_exponent':m,
                      'halfspace_points':len(I),'inverse_row_nonzero':len(T),
                      'exact_inverse_row_identity_checked':True})
        if progress_every and number%progress_every==0:print('CHAINS',number,'of',len(P)-1,'terms',len(F),'seconds',time.time()-tic,flush=True)
    return F,steps,matrix_queries

def construct(data,max_points=20000,progress_every=0):
    tic=time.time()
    if any(int(a)!=a for row in data['B'] for a in row) or any(int(a)!=a for a in data['g']) or any(int(a)!=a for a in data.get('D',[])):raise ValueError('B, D and g must be integral')
    B=tuple(tuple(map(int,row)) for row in data['B']);n=len(B)
    D=tuple(map(int,data.get('D',[1]*n)));g=tuple(map(int,data['g']))
    if not n or len(D)!=n or len(g)!=n or any(len(row)!=n for row in B):raise ValueError('input dimensions')
    if any(a<=0 for a in D):raise ValueError('D must be positive')
    if any(D[i]*B[i][j]!=-D[j]*B[j][i] for i in range(n) for j in range(n)):raise ValueError('D B must be skew-symmetric')
    order=topological_order(B);frame=None;product_certificate=None
    mode=data.get('transport','auto')
    if mode not in ('auto','frame','negative_product'):raise ValueError('unknown transport mode')
    if order is not None and mode=='auto':
        P,carrier=acyclic_carrier(B,g,order,max_points)
        @lru_cache(None)
        def C(r,q):
            return acyclic_transport_entry(B,g,order,r,q)
        transport_kind='closed_acyclic_generalized_binomial'
    elif mode=='negative_product':
        from negative_product_recovery import seed_data,recover
        from exact_frame_polynomials import ordinary_seed_polynomials,multiply,pow_poly
        words=[tuple(w) for w in data['seeds']];factors=[tuple(f) for f in data['product_factors']]
        seed_cert=[seed_data(B,w,D) for w in words];h=[0]*n;HP={(0,)*n:1};Fseeds={};traces={}
        for s,j,a in factors:
            if int(a)!=a or a<=0:raise ValueError('product powers must be positive integers')
            if s not in Fseeds:Fseeds[s],traces[s]=ordinary_seed_polynomials(B,words[s])
            for i in range(n):h[i]+=a*seed_cert[s]['G'][i][j]
            HP=multiply(HP,pow_poly(Fseeds[s][j],a))
        if not all(a<0 for a in h):raise ValueError('product g-vector must be strictly negative')
        exponent=max([0]+[(max(-g[i],0)-h[i]-1)//(-h[i]) for i in range(n)])
        v=[g[i]-exponent*h[i] for i in range(n)];assert all(a>=0 for a in v)
        P=pow_poly(HP,exponent)
        box0=tuple(max(p[i] for p in P) for i in range(n));number=prod(a+1 for a in box0)
        if max_points is not None and number>max_points:raise ResourceStop({'stage':'negative_product_transport_box','points':number,'budget':max_points})
        points,entries,recovery=recover(B,D,g,box0,words,factors);indices={p:i for i,p in enumerate(points)}
        @lru_cache(None)
        def C(r,q):return entries[indices[r]].get(indices[q],0)
        carrier={'kind':'multiple_seed_negative_product','negative_product_g':h,
                 'product_power':exponent,'positive_initial_factor':v}
        product_certificate={'seed_data':seed_cert,'exchange_traces':traces,
                'product_F':dump_poly(HP),'transport_recovery':recovery}
        transport_kind='multiple_seed_negative_product_integer_recovery'
    else:
        from signed_lu_reconstruction import standard_carrier
        word=data.get('negative_word',data.get('word'))
        if word is None:raise ValueError('cyclic mode requires an explicit ordinary negative frame')
        P,frame=standard_carrier(B,tuple(word),g,D)
        if max_points is not None and len(P)>max_points:raise ResourceStop({'stage':'frame_carrier','points':len(P),'budget':max_points})
        carrier={'kind':'ordinary_negative_frame_product'}
        H=[{tuple(term['p']):int(term['a']) for term in F} for F in frame['F']]
        @lru_cache(None)
        def C(r,q):
            h=tuple(-g[i]-sum(B[i][j]*q[j] for j in range(n)) for i in range(n))
            delta=subp(r,q)
            return monomial_image(H,h,delta).get(delta,0)
        transport_kind='ordinary_negative_frame_exchange'
    box=tuple(max(p[i] for p in P) for i in range(n))
    F,steps,matrix_queries=chain_recurrence(B,D,g,P,C,max_points,progress_every)
    return {'status':'complete_halfspace_integer_chain_recurrence','completed':True,
      'input':data,'B':B,'D':D,'g':g,'box':box,'carrier_certificate':carrier,
      'carrier_points':len(P),'carrier_mass':sum(P.values()),
      'positive_carrier':dump_poly(P),'transport_kind':transport_kind,
      'exact_frame_certificate':frame,'negative_product_certificate':product_certificate,'F':dump_poly(F),'terms':len(F),
      'mass':sum(F.values()),'nonnegative':all(a>0 for a in F.values()),
      'steps':steps,'matrix_queries':matrix_queries,'distinct_transport_entries':C.cache_info().currsize,
      'all_inverse_rows_checked':True,'signed_LU_used':False,
      'wall_or_theta_input':False,'Q_or_quantum_input':False,
      'linear_Laurent_solver_used':False,'seconds':time.time()-tic,
      'scope':'Classical principal theta functions under the supplied comparison theorem. Acyclic inputs give ordinary cluster-algebra bases; for general cyclic frames the upper algebra is the guaranteed basis ambient, and A=U needs a separate hypothesis.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--max-points',type=int,default=20000);ap.add_argument('--progress-every',type=int,default=0);a=ap.parse_args()
    data=json.loads(a.input.read_text());output=a.output or a.input.with_name(a.input.stem+'_chains_result.json')
    try:result=construct(data,a.max_points,a.progress_every)
    except ResourceStop as error:
        atomic(output,{'status':'resource_stop','completed':False,'detail':error.args[0],'input':data});print(error.args[0]);return 2
    atomic(output,result);print(json.dumps({k:result[k] for k in ['status','carrier_points','terms','mass','nonnegative','seconds']}));return 0

if __name__=='__main__':sys.exit(main())
