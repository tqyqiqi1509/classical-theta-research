#!/usr/bin/env python3
"""Ordinary exchange F-polynomials, with exact multivariate division."""
from collections import defaultdict
from pathlib import Path
import sys,json,time
from signed_lu_reconstruction import frame_data
from integer_polynomials import seed_mutate,atomic,dump_poly

def multiply(F,G):
 H=defaultdict(int)
 for p,a in F.items():
  for q,b in G.items():H[tuple(x+y for x,y in zip(p,q))]+=a*b
 return {p:a for p,a in H.items() if a}
def pow_poly(F,k):
 H={(0,)*len(next(iter(F))):1}
 while k:
  if k&1:H=multiply(H,F)
  k//=2
  if k:F=multiply(F,F)
 return H
def exact_divide(N,D):
 if len(D)==1 and not any(next(iter(D))):
  a=next(iter(D.values()));assert all(b%a==0 for b in N.values());return {p:b//a for p,b in N.items()}
 R=dict(N);Q={};lead=max(D);lc=D[lead]
 while R:
  p=max(R);q=tuple(x-y for x,y in zip(p,lead));assert min(q)>=0,('nondivisible monomial',p,lead)
  a=R[p];assert a%lc==0,('nonintegral exact polynomial division',a,lc);a//=lc;Q[q]=Q.get(q,0)+a
  for r,b in D.items():
   s=tuple(x+y for x,y in zip(q,r));R[s]=R.get(s,0)-a*b
   if R[s]==0:R.pop(s)
 assert multiply(Q,D)==N
 return Q

def ordinary_seed_polynomials(B,word):
 n=len(B);zz=(0,)*n;F=[{zz:1} for _ in range(n)];C=tuple(tuple(int(i==j) for j in range(n)) for i in range(n));BB=tuple(map(tuple,B));steps=[];tic=time.time()
 for step,k in enumerate(word):
  H=defaultdict(int)
  for sign in (1,-1):
   p=tuple(max(sign*C[i][k],0) for i in range(n));P={p:1}
   for j in range(n):
    a=max(sign*BB[j][k],0)
    if a:P=multiply(P,pow_poly(F[j],a))
   for p,a in P.items():H[p]+=a
  F[k]=exact_divide(dict(H),F[k]);assert F[k][zz]==1 and all(a>0 for a in F[k].values())
  BB,C=seed_mutate(BB,C,k);steps.append({'step':step,'k':k,'terms':len(F[k]),'degrees':[max(p[i] for p in F[k]) for i in range(n)]})
  print('FRAME',step,k,'terms',len(F[k]),'degrees',steps[-1]['degrees'],flush=True)
 return F,{'steps':steps,'seconds':time.time()-tic,'all_exchange_divisions_checked':True}

def frame_polynomials(B,word,D=None):
 data=frame_data(B,word,D);F,trace=ordinary_seed_polynomials(B,word);n=len(B)
 I=[F[j] for j in data['permutation']];data.update(F=[dump_poly(P) for P in I],**trace,exact_boxes=[[max(p[i] for p in P) for i in range(n)] for P in I])
 return I,data

if __name__=='__main__':
 r=json.load(open('work/agent_cyclic_generic_bridge/four_punctured_sphere_frame.json'));I,data=frame_polynomials(r['B'],r['word']);atomic('work/agent_pieri_diamond/cyclic_rank6_exact_frame.json',data);print('DONE',data['exact_boxes'],data['seconds'])
