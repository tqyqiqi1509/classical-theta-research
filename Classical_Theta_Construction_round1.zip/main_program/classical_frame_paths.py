#!/usr/bin/env python3
"""Main classical integer-path construction, using only the Python stdlib.

Input JSON: B, D, g, negative_word (or word). All indices are zero-based.
The only required certificate is an ordinary mutation word reaching a
negative permutation g-matrix. The program computes the ordinary exchange
polynomials, their positive standard carrier, and every target coefficient
by the direct signed integer recurrence. No Laurent-space solver is used.
"""
from pathlib import Path
import argparse,json,sys,time
from signed_lu_reconstruction import SignedLU,standard_carrier,FactorResourceError
from integer_polynomials import atomic,dump_poly,pts
from math import comb,prod

def acyclic_standard_carrier(B,g,max_carrier_points=None):
 """Classical one-step standard product, with a verified topological order."""
 n=len(B);remaining=set(range(n));order=[]
 while remaining:
  available=sorted(i for i in remaining if all(B[j][i]<=0 for j in remaining))
  if not available:raise ValueError('acyclic carrier requested for a cyclic exchange matrix')
  i=available[0];order.append(i);remaining.remove(i)
 d=[0]*n;v=[0]*n
 for i in order:
  lower=sum(max(-B[i][j],0)*d[j] for j in range(n))
  d[i]=max(-g[i]+lower,0);v[i]=g[i]+d[i]-lower
 assert all(a>=0 for a in v) and all(a*b==0 for a,b in zip(d,v))
 number=prod(a+1 for a in d)
 if max_carrier_points is not None and number>max_carrier_points:raise FactorResourceError({'status':'acyclic_carrier_resource_stop','points':number,'budget':max_carrier_points,'capacity':d})
 P={p:prod(comb(a,b) for a,b in zip(d,p)) for p in pts(d)}
 return P,{'kind':'acyclic_one_step_standard_product','topological_order':order,'capacity':d,'initial_positive_factor':v,'majorant':'product_i (1+z_i)^d_i','uses_Q':False}

def construct(data,max_factor_points=20000,max_carrier_points=20000,carrier='frame'):
 B=data['B'];n=len(B);D=data.get('D',[1]*n);g=tuple(data['g']);word=tuple(data.get('negative_word',data.get('word',())))
 if len(g)!=n or len(D)!=n or any(len(row)!=n for row in B):raise ValueError('inconsistent input dimensions')
 if any(int(a)!=a for row in B for a in row) or any(int(a)!=a for a in g):raise ValueError('B and g must be integral')
 if any(int(a)!=a or a<=0 for a in D):raise ValueError('D must contain positive integers')
 if not n:raise ValueError('exchange matrix must have positive size')
 if any(int(k)!=k or k<0 or k>=n for k in word):raise ValueError('mutation index must be an integer in range')
 if any(B[i][i] for i in range(n)):raise ValueError('exchange matrix diagonal must vanish')
 B=[[int(a) for a in row] for row in B];D=[int(a) for a in D];g=tuple(map(int,g));word=tuple(map(int,word))
 if any(D[i]*B[i][j]!=-D[j]*B[j][i] for i in range(n) for j in range(n)):raise ValueError('D B must be skew-symmetric')
 tic=time.time();engine=SignedLU(B,word,D,max_factor_points=max_factor_points)
 if carrier=='frame':
  P,frame=standard_carrier(B,word,g,D);carrier_cert={'kind':'ordinary_negative_frame_product','majorant':'product_i F_Ii(z)^[-g_i]_+','uses_Q':False}
 elif carrier=='acyclic':
  P,carrier_cert=acyclic_standard_carrier(B,g,max_carrier_points)
  from exact_frame_polynomials import frame_polynomials
  _,frame=frame_polynomials(B,word,D)
 else:raise ValueError('unknown carrier mode')
 if max_carrier_points is not None and len(P)>max_carrier_points:raise FactorResourceError({'status':'positive_carrier_resource_stop','points':len(P),'budget':max_carrier_points})
 box=tuple(max(p[i] for p in P) for i in range(n));F,result=engine.coefficient_recurrence(g,box,support=P)
 result.update(input={'B':B,'D':D,'g':g,'negative_word':word},positive_carrier=dump_poly(P),positive_carrier_mass=sum(P.values()),carrier_certificate=carrier_cert,exact_frame_certificate=frame,total_seconds=time.time()-tic,construction='ordinary exchange polynomials; finite integer signed factorization; inverse weighted-chain recurrence',no_wall_or_theta_input=True,linear_star_solver_used=False,all_factorizations_checked=all(s['product_identity_checked'] for s in result['steps']),scope='Classical principal-coefficient theta functions for an explicit ordinary negative frame. The upper theta-basis statement uses the stated comparison theorem. An ordinary A-basis claim additionally requires A=U; this is not presumed for arbitrary cyclic seeds.')
 result['completed']=True
 return result

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);ap.add_argument('--output',type=Path);ap.add_argument('--max-factor-points',type=int,default=20000);ap.add_argument('--max-carrier-points',type=int,default=20000);ap.add_argument('--carrier',choices=['frame','acyclic'],default='frame');args=ap.parse_args()
 data=json.loads(args.input.read_text());dest=args.output or args.input.with_name(args.input.stem+'_result.json')
 try:result=construct(data,args.max_factor_points,args.max_carrier_points,args.carrier)
 except FactorResourceError as e:
  atomic(dest,{'status':'resource_stop','detail':e.args[0],'input':data,'completed':False});print(json.dumps({'status':'resource_stop','output':str(dest),'detail':e.args[0]}));return 2
 atomic(dest,result);print(json.dumps({'status':result['status'],'output':str(dest),'carrier_points':result['carrier_points'],'terms':len(result['F']),'mass':result['mass'],'nonnegative':result['nonnegative'],'seconds':result['total_seconds']}));return 0
if __name__=='__main__':sys.exit(main())
