# 主要计算的复算入口

从解压得到的 `Higher_Rank_Greedy_Theta` 目录运行。核心程序使用 Python 标准库的整数、`Fraction`、有限集合与递归；某些旁支几何计算另用 SymPy，见相应文件 import。不要把大规模测试全部串行运行当作使用算法的前提。

## 推荐的短入口

```bash
python computations/endpoint_matrix_multiplication.py
python computations/theta_multiplication_objects.py
python computations/intrinsic_two_page_trees.py
python computations/fast_framed_spine.py
python computations/fast_framed_sparse_polytope.py
```

第一个程序独立计算带符号运输矩阵与 theta 三角乘法，不调用 Dyck event grammar。第二个先建立实际有限集合 recipe，再计算基数、生成对象并与第一个程序比较；同时导出所选乘法系数的显式多面体。第三个直接从双页树图条件枚举，再与独立路径编码比较。

最后两个程序复算 framing 普通槽字压缩和完整稀疏多面体后端。`fast_framed_spine.py` 对 unframed 出生仍调用原始路径工厂；`fast_framed_sparse_polytope.py` 将这部分也替换为显式稀疏位置矩阵。它们在构造 recipe 时不调用基数；后续数值求值是独立步骤。

## 主程序与结果对应

| 输入／功能 | 程序或模块 | 主要结果文件 |
|---|---|---|
| 值域化有限事件及字面路径计数 | `computations/valued_event_flag_grammar.py` | 同名 `.json` |
| 实际不交并／乘积对象 | `computations/dyck_object_factory.py` | 相邻结果及 recipes |
| 原始 elementary 字母对象 | `computations/universal_dyck_object_factory.py` | 同名 `.json` |
| 展平对象并核逆映射 | `computations/flatten_dyck_objects.py` | 同名 `.json` |
| 不使用对象模型的整数算法 | `agents/incoming_recursion.py` | 各 independent-check `.json` |
| 多斜率局部算子比较 | `computations/valued_word_operator_check.py` | 同名 `.json` |
| 位置多面体编译 | `computations/sparse_position_polytopes.py` | 同名 `.json` |
| 全局有理多面体 recipe | `computations/global_sparse_polytope_recipe.py` | `.json` 及导出的 recipe |
| 复制参数实际对象 | `computations/dyck_replication_objects.py` | 同名 `.json` |
| 任意端点与乘法独立矩阵 | `computations/endpoint_matrix_multiplication.py` | 同名 `.json` |
| 乘法实际对象／多面体 | `computations/theta_multiplication_objects.py` | `theta_multiplication_objects.json`、两个 recipe |
| 压缩 framing 槽与完整稀疏多面体 | `computations/fast_framed_spine.py`、`computations/fast_framed_sparse_polytope.py` | 同名 `.json` 和实际 matrix recipes |
| 两向压缩槽到实际边的逆映射 | `computations/framed_spine_literal_inverse.py` | 同名 `.json` |
| 宽重复框架与有序 tight 幂 | `computations/repeated_frame_tight_power.py` | 同名 `.json` |
| 径向 endpoint 的全目录比较 | `computations/radial_endpoint_catalog.py` | 同名 `.json` |
| 自由循环相位与实际边逆映射 | `computations/singleton_cyclic_phase.py` | 同名 `.json` |
| 任意次数的标记原子分裂 | `computations/singleton_atom_splitting.py` | 同名 `.json` |
| 三个固定输入各出现一次的事件地址转换 | `computations/framed_two_packet_event_flip.py` | 同名 `.json` |
| 两套栈与森林判定 | `computations/two_stack_shadow_forests.py` | 同名 `.json` |
| 不调用 shadow 定义的图解码 | `computations/intrinsic_two_page_trees.py` | 同名 `.json` |
| 较大的 packet 负载 | `computations/packet_large_suite.py` | `packet_large_suite_results.json` |

调用模块的实际数据格式以文件内 `main()` 为准。需要自定义 (B,D,g,p) 时，用 `extended_data` 构造一次 framing；事件算法的根状态采用主稿 §7 的有理字典序协向量。核心对象构造与检查程序的 oracle 是分开的，不要把 main 中的验证导入误解为对象定义依赖已知系数。

## 运行时间与外部服务

保存的大规模 suite 实际运行约 57 分钟；百万级相位／字面分次检查也不是瞬时任务。一般输入没有声称实际枚举运行很快。多面体的固定次数复杂度结论使用理论固定维整数点算法，当前脚本没有实现该算法。

Wolfram JSON 回执记录实际服务调用，重新运行 Python 不会重新调用该服务。失败请求明确保留服务错误；其结果不记作 PASS。

`agents/verify_incoming_recursion.py` 是较早与上一轮包对照的历史脚本，它引用当时的 `source_materials/previous_greedy`，本总包未重复装入该大包。上表中的当前主要算法和乘法入口不依赖它。除这个明确说明的历史对照外，核心路径引用均相对当前包目录。

旧笔记可能保存一个后来被修正或放弃的尝试；最终数学范围与主入口以 `README.md` 和中文总报告为准。保留历史文件是为了记录失败路线和修正原因，不是把所有尝试同时列为定理。
