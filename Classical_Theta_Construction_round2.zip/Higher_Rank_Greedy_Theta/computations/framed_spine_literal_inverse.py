"""Sparse, decoration-preserving inverse from framed slot words to Dyck edges.

All edge indices are zero based within their own colour.  The definition
uses only occupied positions; Q may be arbitrarily large.  Dense words
and independent tight-grading enumeration occur exclusively in main().
"""
from math import comb
from pathlib import Path
import json
import time


def _validated(slots, occupied):
    occupied = tuple(occupied)
    assert slots >= 1
    assert all(0 <= s < slots and degree > 0 for s, degree, _ in occupied)
    assert all(occupied[i][0] < occupied[i+1][0] for i in range(len(occupied)-1))
    return occupied, sum(degree for _, degree, _ in occupied)


def slot_word_to_dyck(slots, weight, occupied, framed_decoration, side):
    """Actual inverse for a positive framed/unframed birth.

    `occupied` consists of (slot, positive degree, opaque decoration).
    `side` is the location of the framed input in a positively ordered
    input pair.  The unframed normal content is `weight`, and K=Q*weight.
    Empty words give the inherited object, not a positive birth.
    """
    assert weight >= 1 and side in ('left', 'right')
    occupied, total = _validated(slots, occupied)
    if total == 0:
        return {'inherited': framed_decoration, 'side': side}
    Q, d, t = slots, weight, total
    m = d*Q
    if side == 'left':
        W, H = Q, t*m+1
        # First global minimum of the horizontal stack-height process.
        # The minimum lies just before an occupied slot, or at the end.
        candidates = [(Q, -1)]
        prefix = 0
        for s, degree, _ in occupied:
            if s:
                candidates.append((s, m*prefix-t*d*s))
            prefix += degree
        cut, _ = min(candidates, key=lambda pair: (pair[1], pair[0]))
        positive_E = tuple((s, m*degree, decoration)
                           for s, degree, decoration in occupied)
        positive_N = ((H*cut//Q-1, Q, framed_decoration),)
    else:
        W, H = t*d*(Q+1)-1, Q+1
        # First maximum among indices 1,...,Q.  Maxima can only occur
        # immediately after an occupied slot, or at the terminal index.
        candidates = [(Q, 0)]
        prefix = 0
        for s, degree, _ in occupied:
            prefix += degree
            k = s+1
            candidates.append((k, Q*prefix-t*k))
        k, _ = min(candidates, key=lambda pair: (-pair[1], pair[0]))
        cut = k % Q
        phi = (-k) % Q
        residue = Q-1-phi
        i = pow(H, -1, W)*(W-Q+residue) % W if W > 1 else 0
        y0 = H*i//W
        positive_E = ((i, Q, framed_decoration),)
        positive_N = tuple(sorted(((y0+1+(s-cut)%Q) % H,
                                   m*degree, decoration)
                                  for s, degree, decoration in occupied))
    return {'rectangle': (W, H), 'positive_E': positive_E,
            'positive_N': positive_N, 'normal_copy': (0, 1), 'side': side}


def dyck_to_slot_word(slots, weight, data):
    """Sparse inverse on the image; no grading list or path is inspected."""
    if 'inherited' in data:
        return (), data['inherited']
    Q, m = slots, slots*weight
    W, H = data['rectangle']
    if data['side'] == 'left':
        assert W == Q and len(data['positive_N']) == 1
        framed_decoration = data['positive_N'][0][2]
        occupied = tuple((i, grade//m, deco) for i, grade, deco in data['positive_E'])
        assert all(grade % m == 0 for _, grade, _ in data['positive_E'])
    else:
        assert H == Q+1 and len(data['positive_E']) == 1
        i, grade, framed_decoration = data['positive_E'][0]
        assert grade == Q
        residue = H*i % W-(W-Q) if W > 1 else 0
        phi = Q-1-residue
        assert 0 <= phi < Q
        y0 = H*i//W
        occupied = []
        for j, grade, deco in data['positive_N']:
            index = (j-y0-1) % H
            assert index < Q and grade % m == 0
            occupied.append(((index-phi) % Q, grade//m, deco))
        occupied = tuple(sorted(occupied))
    _validated(Q, occupied)
    assert slot_word_to_dyck(Q, weight, occupied, framed_decoration, data['side']) == data
    return occupied, framed_decoration


def fusion_strip_to_dyck(m, residue, left_decoration, right_decoration):
    assert m >= 1 and 0 <= residue < m
    return {'rectangle': (m, m+1),
            'positive_E': ((residue, m, right_decoration),),
            'positive_N': (((residue+m) % (m+1), m, left_decoration),),
            'normal_copy': (0, 1), 'side': 'both'}


def dense(data):
    from tight_grading_two_input import dyck_word
    word = dyck_word(*data['rectangle'])
    edata = {i: grade for i, grade, _ in data['positive_E']}
    ndata = {i: grade for i, grade, _ in data['positive_N']}
    e = n = 0
    grading = []
    for colour in word:
        if colour == 'E':
            grading.append(edata.get(e, 0)); e += 1
        else:
            grading.append(ndata.get(n, 0)); n += 1
    return word, tuple(grading)


def main():
    from tight_grading_two_input import compositions, is_tight, tight_profiles, direct_compatible
    from fast_framed_spine import FastFramedSpineObjects
    from dyck_object_factory import DyckObjects
    begin = time.monotonic()
    checked = exact_sets = candidates = 0
    for Q in range(1, 7):
        for d in range(1, 5):
            for t in range(1, 5):
                for side in ('left', 'right'):
                    images = set()
                    for weights in compositions(t, Q):
                        occupied = tuple((s, degree, ('decoration', s, degree))
                                         for s, degree in enumerate(weights) if degree)
                        data = slot_word_to_dyck(Q, d, occupied, 'frame', side)
                        word, grading = dense(data)
                        assert is_tight(word, grading), (Q,d,t,side,weights,data)
                        if checked % 113 == 0:
                            assert direct_compatible(word, grading)
                        assert dyck_to_slot_word(Q,d,data) == (occupied,'frame')
                        images.add(grading)
                        checked += 1
                    assert len(images) == comb(t+Q-1,Q-1)
                    m = d*Q
                    if side == 'left':
                        A,B,ell,v,u = 1,t*d,Q,Q,m
                        W,H = Q,t*m+1
                        work = comb(t+W-1,W-1)*H
                    else:
                        A,B,ell,v,u = t*d,1,Q,m,Q
                        W,H = t*d*(Q+1)-1,Q+1
                        work = W*comb(t+H-1,H-1)
                    if work <= 7000 and W+H <= 80:
                        _, actual, rectangle = tight_profiles(A,B,ell,v,u,True)
                        assert rectangle == (W,H)
                        assert images == set(actual), (Q,d,t,side,len(images),len(actual))
                        exact_sets += 1
                        candidates += work
    fusion = 0
    for m in range(1, 19):
        images = set()
        for residue in range(m):
            data = fusion_strip_to_dyck(m,residue,'left','right')
            word, grading = dense(data)
            assert is_tight(word,grading)
            images.add(grading)
            fusion += 1
        _, actual, _ = tight_profiles(1,1,m,m,m,True)
        assert images == set(actual)
    # Check the actual integrated two_inputs method with valued and
    # nonprimitive unframed inputs; both orientation formulas are tested.
    integration = []
    for Q in (1,2,3):
        for baseweight in (2,3):
            for multiple in (1,2):
                for side in ('left','right'):
                    matrix = [[0,baseweight*Q],[-Q,0]]
                    if side == 'right':
                        matrix = [[0,-baseweight*Q],[Q,0]]
                    fast = FastFramedSpineObjects(matrix,[1,baseweight])
                    slow = DyckObjects(matrix,[1,baseweight])
                    outputs = []
                    for model in (fast,slow):
                        ss = model.sets
                        full = {j: ss.union(ss.tag(('unframed',j,k)) for k in range(j+1))
                                for j in range(1,4)}
                        framed = {1:ss.tag(('framed',))}
                        frame = ((1,0),framed,'frame',False)
                        other = ((0,multiple),full,'unframed',False)
                        pair = (frame,other) if side == 'left' else (other,frame)
                        result = model.two_inputs(*pair,(1,3*multiple))
                        if model is fast:
                            assert ss.cardinality_queries == 0
                        outputs.append({gamma:ss.cardinality(H[1]) for gamma,H,_,_ in result})
                    assert outputs[0] == outputs[1]
                    integration.append({'Q':Q,'weight':baseweight*multiple,
                                        'side':side,'counts':list(outputs[0].values())})
    # No iteration up to Q or path length: this literal inverse scales
    # with occupied positions and integer bit lengths.
    huge = []
    Q = 10**50
    occupied = ((0,2,'A'),(Q//2,1,'B'),(Q-1,2,'C'))
    for side in ('left','right'):
        data = slot_word_to_dyck(Q,6,occupied,'frame',side)
        assert dyck_to_slot_word(Q,6,data) == (occupied,'frame')
        huge.append(data)
    for side in ('left','right'):
        inherited = slot_word_to_dyck(Q,6,(),'frame',side)
        assert dyck_to_slot_word(Q,6,inherited) == ((),'frame')
    report = {'status':'PASS','sparse_decorated_roundtrips':checked,
              'exact_literal_sets':exact_sets,'literal_candidates':candidates,
              'fusion_residues':fusion,'valued_orientation_integrations':integration,
              'huge_sparse_examples':huge,'seconds':time.monotonic()-begin,
              'definition_uses_cardinality':False,'dense_materialization_only_in_test':True}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k not in ('huge_sparse_examples','valued_orientation_integrations')},indent=2))


if __name__ == '__main__':
    main()
