"""Exact structural test of forward exchange for nearby stable tree bases.

Lenz Definition 6.1 uses maximal-element external activity.  A basis subset
has that property iff, for every fundamental circuit C and every forbidden
exchange b, b is not the maximum of C.  The constraints allow a greedy exact
decision over all ground-set orders: remove an admissible largest element.
This tests both the graphic and cographic matroid. No theta/fan oracle is used.
"""
from itertools import combinations, combinations_with_replacement
from collections import defaultdict
import json
from pathlib import Path


def graph(charges):
    n = len(charges)
    edges = []
    for i, j in combinations(range(n), 2):
        d = charges[i][0] * charges[j][1] - charges[i][1] * charges[j][0]
        edges += [(i, j) if d > 0 else (j, i)] * abs(d)
    theta = [0] * n
    for u, v in edges:
        theta[u] += 1
        theta[v] -= 1
    # This infinitesimal perturbation avoids every proper balanced subset.
    psi = [-(n-1)] + [1] * (n-1)
    theta1 = [(n+1)*t+p for t,p in zip(theta,psi)]
    return edges, theta1


def components(n, edges, selected):
    parent = list(range(n))
    def root(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for e in selected:
        u,v = edges[e]
        a,b = root(u),root(v)
        if a == b:
            return None
        parent[a] = b
    return [root(i) for i in range(n)]


def tree_data(charges):
    edges, theta = graph(charges)
    n,m = len(charges),len(edges)
    all_trees, stable = set(),set()
    cuts = {}
    for tup in combinations(range(m), n-1):
        T = frozenset(tup)
        if components(n,edges,T) is None:
            continue
        all_trees.add(T)
        cs = {}
        valid = True
        for x in T:
            comp = components(n,edges,T-{x})
            u,v=edges[x]
            side = frozenset(i for i in range(n) if comp[i] == comp[u])
            flow=sum(theta[i] for i in side)
            if flow <= 0:
                valid=False
            cross=frozenset(e for e,(a,b) in enumerate(edges) if (a in side)!=(b in side))
            cs[x] = cross
        cuts[T] = cs
        if valid:
            stable.add(T)
    return edges,theta,all_trees,stable,cuts


def exact_order(m, forbids):
    remaining=set(range(m))
    descending=[]
    while remaining:
        banned=set()
        for C,F in forbids.items():
            if C <= remaining:
                banned |= F
        allowed=remaining-banned
        if not allowed:
            return None, sorted(remaining)
        e=min(allowed)
        descending.append(e)
        remaining.remove(e)
    return list(reversed(descending)),[]


def test(charges):
    edges,theta,all_trees,stable,cuts=tree_data(charges)
    n,m=len(charges),len(edges)
    result={"charges":charges,"edges":edges,"theta_prime_scaled":theta,
            "all_trees":len(all_trees),"stable_trees":len(stable)}
    for dual in (False,True):
        forbids=defaultdict(set)
        witnesses={}
        for T in stable:
            if dual:
                for x,C in cuts[T].items():
                    for b in C-{x}:
                        if frozenset(T-{x}|{b}) not in stable:
                            forbids[C].add(b)
                            witnesses[(C,b)]={"tree":sorted(T),"remove":x,"add":b}
            else:
                for x in set(range(m))-T:
                    # x is in the fundamental cycle precisely for the
                    # tree edges b whose fundamental cut contains x.
                    C=frozenset({x}|{b for b,D in cuts[T].items() if x in D})
                    for b in C-{x}:
                        if frozenset(T-{b}|{x}) not in stable:
                            forbids[C].add(b)
                            witnesses[(C,b)]={"tree":sorted(T),"remove":b,"add":x}
        order,obstruction=exact_order(m,forbids)
        name="cographic" if dual else "graphic"
        result[name]={"order":order,"residual_obstruction":obstruction,
                      "constraints":[{"circuit":sorted(C),"forbidden_max":sorted(F),
                                      "witnesses":[witnesses[(C,b)] for b in sorted(F)]}
                                     for C,F in forbids.items() if C<=set(obstruction)]}
    return result


if __name__=="__main__":
    families=[[(1,0),(1,0),(0,1),(0,1)],
              [(1,0),(1,0),(1,1),(0,1),(0,1)],
              [(1,0),(1,1),(1,1),(0,1),(0,1)],
              [(1,0),(1,0),(1,1),(1,1),(0,1),(0,1)],
              [(1,0),(1,1),(1,2),(0,1)],
              [(1,0),(1,0),(1,1),(1,2),(0,1)],
              [(1,0),(1,1),(1,2),(0,1),(0,1)]]
    results=[]
    for charges in families:
        r=test(charges)
        results.append(r)
        print(json.dumps({k:r[k] for k in ("charges","all_trees","stable_trees")}
                         | {name:r[name]["order"] is not None for name in ("graphic","cographic")}))
    Path(__file__).with_suffix(".json").write_text(json.dumps(results,indent=2))
