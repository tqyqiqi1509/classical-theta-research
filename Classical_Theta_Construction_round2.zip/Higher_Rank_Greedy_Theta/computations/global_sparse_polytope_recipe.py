"""Build global theta coefficient sets as unions/products of polytopes.

The definition enumerates sparse support/endpoint order patterns and
their linear constraints. It never enumerates tight gradings or known
coefficient values. Occupied slots of a normal power are represented by
the simplex 1<=i_1<...<i_P<=c, without enumerating c empty positions.
"""
from collections import Counter
from functools import cmp_to_key, lru_cache
from math import comb, gcd
from pathlib import Path
import json
import time

from dyck_object_factory import FiniteSets
from universal_dyck_object_factory import UniversalDyckObjects
from valued_event_flag_grammar import extended_data, add, scale, le, sign
from tight_grading_two_input import bezout_rectangle
from sparse_position_polytopes import (compile_pattern, admissible_patterns,
        integer_points, positive_compositions, Polytope)


def slot_polytope(c, occupied):
    variables = tuple(('normal_slot', i) for i in range(occupied))
    inequalities = []
    for i in range(occupied):
        row = [0]*occupied
        row[i] = -1
        inequalities.append((tuple(row), -1))
        row = [0]*occupied
        row[i] = 1
        inequalities.append((tuple(row), c))
    for i in range(occupied-1):
        row = [0]*occupied
        row[i], row[i+1] = 1, -1
        inequalities.append((tuple(row), -1))
    return Polytope(variables, inequalities, [], {'kind': 'normal_slots',
                    'copies': c, 'occupied': occupied})


class SparseSets(FiniteSets):
    def __init__(self):
        super().__init__()
        self.polytopes = []
        self.poly_index = {}

    def polytope(self, key, poly):
        if key not in self.poly_index:
            self.poly_index[key] = len(self.polytopes)
            self.polytopes.append(poly)
        return self.node(('polytope', self.poly_index[key]))

    def slots(self, c, occupied):
        if occupied > c:
            return 0
        return self.polytope(('normal_slots', c, occupied), slot_polytope(c, occupied))

    def _cardinality(self, identifier):
        node = self.nodes[identifier]
        if node[0] == 'polytope':
            poly = self.polytopes[node[1]]
            if poly.metadata.get('kind') == 'normal_slots':
                return comb(poly.metadata['copies'], poly.metadata['occupied'])
            return sum(1 for _ in integer_points(poly))
        return super()._cardinality(identifier)

    def profiles(self, root, rank):
        """Evaluate the completed polyhedral recipe in original leaf symbols."""
        @lru_cache(None)
        def evaluate(identifier):
            node = self.nodes[identifier]
            if node[0] == 'empty':
                return Counter()
            if node[0] == 'unit':
                return Counter({tuple(() for _ in range(rank)): 1})
            if node[0] == 'polytope':
                value = self.cardinality(identifier)
                return Counter({tuple(() for _ in range(rank)): value}) if value else Counter()
            if node[0] == 'tag':
                if node[1][0] == 'original_axis_leaf':
                    label = node[1]
                    mon = [() for _ in range(rank)]
                    mon[label[1]] = (label[2] if len(label) > 2 else 1,)
                    return Counter({tuple(mon): 1})
                return evaluate(node[2])
            if node[0] == 'union':
                result = Counter()
                for child in node[1]:
                    result.update(evaluate(child))
                return result
            if node[0] == 'product':
                result = Counter({tuple(() for _ in range(rank)): 1})
                for child in node[1]:
                    next_result = Counter()
                    for a, x in result.items():
                        for b, y in evaluate(child).items():
                            mon = tuple(tuple(sorted(a[i]+b[i], reverse=True)) for i in range(rank))
                            next_result[mon] += x*y
                    result = next_result
                return result
            raise ValueError(node)
        return evaluate(root)

    def dimension_bound(self, root):
        @lru_cache(None)
        def dimension(identifier):
            node = self.nodes[identifier]
            if node[0] in ('empty', 'unit'):
                return 0
            if node[0] == 'polytope':
                return len(self.polytopes[node[1]].variables)
            if node[0] == 'tag':
                return dimension(node[2])
            if node[0] == 'union':
                return max(map(dimension, node[1]))
            return sum(map(dimension, node[1]))
        return dimension(root)

    def export(self, root):
        reachable = set()
        def visit(identifier):
            if identifier in reachable:
                return
            reachable.add(identifier)
            node = self.nodes[identifier]
            if node[0] == 'tag':
                visit(node[2])
            elif node[0] in ('product', 'union'):
                for child in node[1]:
                    visit(child)
        visit(root)
        poly_ids = sorted({self.nodes[i][1] for i in reachable if self.nodes[i][0] == 'polytope'})
        def sparse_serialization(poly):
            def matrix(rows):
                return {'shape': [len(rows), len(poly.variables)],
                        'entries': [(i, j, value) for i, (row, rhs) in enumerate(rows)
                                    for j, value in enumerate(row) if value]}
            return {'variables': poly.variables,
                    'A': matrix(poly.inequalities),
                    'b': [rhs for row, rhs in poly.inequalities],
                    'E': matrix(poly.equalities),
                    'd': [rhs for row, rhs in poly.equalities],
                    'metadata': poly.metadata}
        return {'root': root,
                'nodes': {str(i): self.nodes[i] for i in sorted(reachable)},
                'polytopes': {str(i): sparse_serialization(self.polytopes[i]) for i in poly_ids},
                'reachable_nodes': len(reachable), 'reachable_polytopes': len(poly_ids),
                'matrix_format': 'sparse integer matrices: shape and (row,column,value) entries',
                'union_semantics': 'tagged disjoint union',
                'product_semantics': 'Cartesian product in separate coordinate blocks'}


class SparsePolytopeObjects(UniversalDyckObjects):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sets = SparseSets()

    def two_inputs(self, left, right, S):
        alpha, F, aid, _ = left
        beta, G, bid, _ = right
        m = self.pair(alpha, beta)
        da, db = self.weight(alpha), self.weight(beta)
        u, v = m//da, m//db
        assert m > 0 and m % da == m % db == 0
        acap = min(S[i]//alpha[i] for i in range(self.r) if alpha[i])
        bcap = min(S[i]//beta[i] for i in range(self.r) if beta[i])
        outputs = []
        for a in range(1, acap+1):
            for b in range(1, bcap+1):
                if gcd(a, b) != 1:
                    continue
                gamma = add(scale(a, alpha), scale(b, beta))
                if not le(gamma, S):
                    continue
                ncap = min(S[i]//gamma[i] for i in range(self.r) if gamma[i])
                ell = gcd(a*v, b*u)
                A, B = a*v//ell, b*u//ell
                denominator = gcd(a*da, b*db)
                assert self.weight(gamma) % denominator == 0
                copies = self.weight(gamma)//denominator
                assert copies > 0
                base = {}
                for j in range(1, ncap+1):
                    r, s = bezout_rectangle(A, B, j*ell)
                    branches = []
                    for hindices in positive_compositions(j*b):
                        if any(G.get(k, 0) == 0 for k in hindices):
                            continue
                        qH = tuple(u*k for k in hindices)
                        for vindices in positive_compositions(j*a):
                            if any(F.get(k, 0) == 0 for k in vindices):
                                continue
                            pV = tuple(v*k for k in vindices)
                            for pattern in admissible_patterns(len(qH), len(pV)):
                                key = ('sparse_path', r, s, qH, pV, pattern)
                                if key in self.sets.poly_index:
                                    cell = self.sets.node(('polytope', self.sets.poly_index[key]))
                                else:
                                    poly = compile_pattern(r, s, qH, pV, pattern)
                                    assert poly is not None
                                    cell = self.sets.polytope(key, poly)
                                decorations = []
                                for block in pattern:
                                    for label in block:
                                        if label[0] == 'H':
                                            decorations.append(G[hindices[int(label[1:])]])
                                        elif label[0] == 'V':
                                            decorations.append(F[vindices[int(label[1:])]])
                                term = self.sets.product((cell, *decorations))
                                label = ('sparse_path', r, s, hindices, vindices, pattern, j)
                                branches.append(self.sets.tag(label, term))
                    base[j] = self.sets.union(branches)
                H = {}
                for n in range(1, ncap+1):
                    terms = []
                    for degree_allocation in positive_compositions(n):
                        occupied = len(degree_allocation)
                        if occupied > copies:
                            continue
                        slots = self.sets.slots(copies, occupied)
                        value = self.sets.product((slots, *(base[j] for j in degree_allocation)))
                        terms.append(self.sets.tag(('occupied_normal_slots', copies, degree_allocation), value))
                    coefficient = self.sets.union(terms)
                    if coefficient:
                        newid = (aid, bid, a, b)
                        H[n] = self.sets.tag(('birth', alpha, beta, gamma, a, b, n, newid), coefficient)
                if H:
                    newid = (aid, bid, a, b)
                    outputs.append((gamma, H, newid, True))
                    self.stats['born_factors'] += 1
                    self.stats['max_normal_copies'] = max(self.stats['max_normal_copies'], copies)
                    if gcd(*gamma) > 1:
                        self.stats['nonprimitive_births'] += 1
        outputs.sort(key=cmp_to_key(lambda x, y: sign(self.pair(x[0], y[0]))))
        return outputs


def run_case(name, B, D, g, p, export=True):
    from valued_event_formal_profiles import GeneralizedSchur, EPoly
    Bhat, Dhat = extended_data(B, D, g)
    begin = time.monotonic()
    model = SparsePolytopeObjects(Bhat, Dhat)
    root = model.framed_theta(tuple(g), tuple(p))
    construction_seconds = time.monotonic()-begin
    print(json.dumps({'name': name, 'stage': 'recipe_constructed',
                      'seconds': construction_seconds,
                      'nodes': len(model.sets.nodes),
                      'polyhedra': len(model.sets.polytopes)}), flush=True)
    # The complete geometric recipe exists before any count is evaluated.
    recipe = model.sets.export(root)
    dimension = model.sets.dimension_bound(root)
    assert dimension <= 9*sum(p)
    count = model.sets.cardinality(root)
    full = model.sets.profiles(root, model.r)
    profile = Counter()
    for mon, coefficient in full.items():
        assert mon[0] == (1,)
        profile[mon[1:]] += coefficient
    independent = GeneralizedSchur(B, D).theta_prefix(tuple(g), tuple(p)).get(
        tuple(p), EPoly.scalar(0, len(D)))
    assert profile == independent.t
    assert count == sum(profile.values())
    ordinary = profile.get(tuple((1,)*k for k in p), 0)
    row = {'name': name, 'B': B, 'D': D, 'g': g, 'p': p,
           'universal_cardinality': count, 'ordinary_coefficient': ordinary,
           'formal_profile': [{'partitions': mon, 'coefficient': value}
                              for mon, value in sorted(profile.items())],
           'formal_signed_incoming_equal': True, 'maximum_piece_ambient_dimension': dimension,
           'dimension_bound': 9*sum(p), 'stats': dict(model.stats),
           'reachable_recipe_nodes': recipe['reachable_nodes'],
           'reachable_polytopes': recipe['reachable_polytopes'],
           'construction_seconds': construction_seconds,
           'seconds': time.monotonic()-begin,
           'definition_enumerates_gradings': False,
           'definition_calls_cardinality': False}
    if export:
        recipe.update({'input': {k: row[k] for k in ('B', 'D', 'g', 'p')},
                       'validation': row})
        path = Path(__file__).with_name(f'global_sparse_recipe_{name}.json')
        path.write_text(json.dumps(recipe, separators=(',', ':')))
        row['recipe_file'] = path.name
    print(json.dumps(row), flush=True)
    return row


def run_nonprimitive_normal_check():
    """One exact operator check for an unreduced birth with c=2."""
    from valued_word_operator_check import word_matrix
    model = SparsePolytopeObjects([[0, 1], [-1, 0]], [1, 1])
    S = (2, 2)
    alpha, beta = (1, 0), (1, 2)
    inputs = [(alpha, {1: 1}), (beta, {1: 1})]
    word = model.sort_word(inputs, S)
    numerical = [(a, {n: model.sets.cardinality(value) for n, value in F.items()}, tag, born)
                 for a, F, tag, born in word]
    original = [(a, F, ('initial', i), False) for i, (a, F) in enumerate(inputs)]
    assert model.stats['max_normal_copies'] == 2
    born = [(a, F) for a, F, tag, new in numerical if new]
    assert born == [((2, 2), {1: 4})]
    matrix_entries = 0
    for w in [(-2, 1), (1, -3)]:
        left = word_matrix(model, original, S, w)
        right = word_matrix(model, numerical, S, w)
        assert left == right
        matrix_entries += len(left)
    root = next(F[1] for a, F, tag, born in word if born)
    recipe = model.sets.export(root)
    recipe['validation'] = {'normal_copies': 2, 'nonprimitive_carrier': [2, 2],
                            'lattice_point_count': 4, 'operator_entries': matrix_entries}
    path = Path(__file__).with_name('global_sparse_recipe_nonprimitive_normal.json')
    path.write_text(json.dumps(recipe, separators=(',', ':')))
    record = {'status': 'PASS', 'parents': [alpha, beta], 'carrier': [2, 2],
              'normal_copies': 2, 'lattice_point_count': 4,
              'independent_operator_monomials': 2,
              'independent_operator_entries': matrix_entries,
              'reachable_recipe_nodes': recipe['reachable_nodes'],
              'reachable_polytopes': recipe['reachable_polytopes'],
              'recipe_file': path.name}
    print(json.dumps(record), flush=True)
    return record


def main():
    start = time.monotonic()
    cases = [
        ('valued_degree_three', [[0, 2], [-1, 0]], [1, 2], (-3, -1), (1, 1)),
        ('valued_phase_mixing', [[0, 2], [-1, 0]], [1, 2], (-6, 2), (2, 2)),
    ]
    results = []
    for case in cases:
        results.append(run_case(*case))
        Path(__file__).with_suffix('.json').write_text(json.dumps(
            {'status': 'RUNNING', 'results': results}, indent=2))
    normal_check = run_nonprimitive_normal_check()
    report = {'status': 'PASS', 'results': results,
              'nonprimitive_normal_word_check': normal_check,
              'seconds': time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
