"""Adversarial necessary-condition check for the primitive-center mechanism.

The proposed actual coordinate-point realization would force h-positivity.
This checks full characters of several multi-slope charge families, using
the proved local Laurent-jet algorithm. Passing is not a proof of a set model.
"""
from pathlib import Path
from itertools import product
import sys,time,json
import sympy as sp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from local_young_permutation_probe import young_character
from orbit_schur_positive import partitions
from local_primitive_laurent_jets import LocalPrimitiveJets,eta_from_types


def run(charges,counts,m):
    types=tuple(a for a,n in zip(charges,counts) for _ in range(n))
    groups=[];offset=0
    for n in counts:groups.append(tuple(range(offset,offset+n)));offset+=n
    eta=eta_from_types(types,m);engine=LocalPrimitiveJets(len(types))
    classes=tuple(product(*(partitions(n) for n in counts)));traces=[]
    for mus in classes:
        sigma=list(range(len(types)))
        for group,mu in zip(groups,mus):
            offset=0
            for k in mu:
                C=group[offset:offset+k];offset+=k
                for j,a in enumerate(C):sigma[a]=C[(j+1)%k]
        traces.append(engine.trace(eta,tuple(sigma),tuple(sum(a) for a in types)))
    matrices=[sp.Matrix([[young_character(lam,mu) for lam in partitions(n)]
                        for mu in partitions(n)]) for n in counts]
    matrix=sp.kronecker_product(*matrices)
    h=list(matrix.inv()*sp.Matrix(traces))
    return {'charges':charges,'counts':counts,'multiplicity':m,'dimension':traces[-1],
            'class_partitions':classes,'traces':traces,
            'h_coefficients':[str(a) for a in h],
            'negative_terms':[{'shape':s,'coefficient':str(a)} for s,a in zip(classes,h) if a<0],
            'all_integral':all(a.q==1 for a in h),'jet_work':engine.calls}


def main():
    out=[]
    cases=[(((1,0),(0,1)),(4,3),1),
           (((1,0),(0,1)),(4,4),1),
           (((1,0),(0,1),(1,1)),(3,2,2),1),
           (((1,0),(0,1),(1,1)),(3,3,2),1),
           (((1,0),(0,1),(1,1)),(3,3,3),1),
           (((1,0),(1,1),(1,2),(0,1)),(2,2,2,2),1),
           (((1,0),(0,1),(2,1)),(3,2,2),2),
           (((1,0),(1,2),(0,1)),(3,3,2),3)]
    for charges,counts,m in cases:
        start=time.time();r=run(charges,counts,m);r['seconds']=time.time()-start
        out.append(r);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
        print(json.dumps({k:v for k,v in r.items() if k not in ('traces','h_coefficients','class_partitions')}),flush=True)
        if r['negative_terms'] or not r['all_integral']:break


if __name__=='__main__':main()
