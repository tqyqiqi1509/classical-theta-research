"""Independent exact monomial-operator check of positive packet words.

Several slopes, repeated parallel carriers, and non-binomial inputs are
checked against the literal automorphism action. Local output coefficients
come only from actual tight gradings in valued_event_flag_grammar.py.
"""
from collections import Counter
from functools import cmp_to_key
from math import gcd,comb,lcm
from pathlib import Path
import json,random,time
from valued_event_flag_grammar import EventFlags,box,add,scale,le,prim,sign,poly_mul


def ibinom(a,k):
    if a>=0:return comb(a,k) if k<=a else 0
    return (-1)**k*comb(-a+k-1,k)


def polynomial_power(F,e,cap):
    out=Counter({0:1});p={0:1}
    for k in range(1,cap+1):
        p=poly_mul(p,F,cap)
        if not p:break
        c=ibinom(e,k)
        for j,v in p.items():out[j]+=c*v
    return dict(out)


def matrix_factor(R,carrier,F,S,w,J):
    M={}
    for q in J:
        cap=min((S[i]-q[i])//carrier[i]
                for i in range(R.r) if carrier[i])
        numerator=R.pair(carrier,add(w,q));d=R.weight(carrier)
        assert numerator%d==0
        powers=polynomial_power(F,numerator//d,cap)
        for k,c in powers.items():
            if c:M[add(q,scale(k,carrier)),q]=c
    return M


def matrix_mul(A,B):
    Brow={}
    for (p,q),v in B.items():Brow.setdefault(p,[]).append((q,v))
    out=Counter()
    for (p,r),x in A.items():
        for q,y in Brow.get(r,[]):out[p,q]+=x*y
    return {k:v for k,v in out.items() if v}


def word_matrix(R,word,S,w):
    J=box(S);ans={(q,q):1 for q in J}
    for a,F,*rest in word:
        ans=matrix_mul(ans,matrix_factor(R,a,F,S,w,J))
    return ans


def diagonal_packet(word,S,born=None):
    rho=prim(S);cap=gcd(*S);out={0:1}
    for a,F,tag,isborn in word:
        if prim(a)!=rho or (born is not None and born!=isborn):continue
        k=gcd(*a)
        part={0:1};part.update({k*j:v for j,v in F.items() if k*j<=cap})
        out=poly_mul(out,part,cap)
    return out


def main():
    start=time.monotonic();rng=random.Random(4141113);results=[]
    shapes=[[(1,0),(1,1),(0,1)],
            [(1,0),(2,1),(1,1),(1,2),(0,1)],
            [(1,0),(2,0),(1,1),(2,2),(0,1),(0,2)]]
    for D in [(1,1),(1,2),(2,3),(2,2),(2,4)]:
        for multiplicity in [1,2]:
            K=lcm(*D)*multiplicity
            B=[[0,K//D[0]],[-K//D[1],0]]
            for shape_id,shape in enumerate(shapes):
                R=EventFlags(B,D);S=(2,2)
                inputs=[]
                for a in shape:
                    cap=min(S[i]//a[i] for i in range(2) if a[i])
                    F={j:rng.randrange(1,5) for j in range(1,cap+1)}
                    inputs.append((a,F))
                original=[(a,F,('initial',i),False) for i,(a,F) in enumerate(inputs)]
                original.sort(key=cmp_to_key(lambda A,B:-sign(R.pair(A[0],B[0]))))
                final=R.sort_word(inputs,S)
                entries=0
                for w in [(-2,1),(1,-3),(0,1)]:
                    left=word_matrix(R,original,S,w)
                    right=word_matrix(R,final,S,w)
                    assert left==right,('operator discrepancy',D,K,shape_id,w,
                                        [(a,left.get(a),right.get(a))
                                         for a in set(left)|set(right)
                                         if left.get(a)!=right.get(a)])
                    entries+=len(set(left)|set(right))
                old=diagonal_packet(original,S)
                inherited=diagonal_packet(final,S,False)
                born=diagonal_packet(final,S,True)
                total=diagonal_packet(final,S)
                assert old==inherited
                assert poly_mul(old,born,2)==total
                assert all(v>=0 for v in born.values())
                row={'D':D,'K':K,'shape':shape_id,'initial_factors':len(original),
                     'final_factors':len(final),'checked_nonzero_matrix_entries':entries,
                     'inherited_diagonal':old,'born_diagonal':born,'total_diagonal':total,
                     'stats':dict(R.stats)}
                results.append(row)
                if shape_id==2:print(json.dumps(row),flush=True)
    result={'status':'PASS','word_inputs':len(results),'test_monomials':3*len(results),
            'checked_nonzero_matrix_entries':sum(x['checked_nonzero_matrix_entries'] for x in results),
            'results':results,'seconds':time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))


if __name__=='__main__':main()
