"""Actual finite-set recipes for individual classical theta products.

Definition: at U=D(g1+g2+Bp)+positive independent infinitesimals, take
the tagged union over a+b=p of the two literal one-frame endpoint sets.
Only the final test harness imports a signed multiplication algorithm.
"""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import json
import time

from dyck_object_factory import DyckObjects, FiniteSets
from valued_event_flag_grammar import extended_data, box


def endpoint_covector(degree, base):
    """The exact rational coefficient vectors of (-U.degree,U)."""
    rank = len(degree)
    U = tuple((Q(base[i]),)+tuple(Q(i == j) for j in range(rank))
              for i in range(rank))
    frame = tuple(-sum(degree[i]*U[i][j] for i in range(rank))
                  for j in range(rank+1))
    return (frame,)+U


class ThetaMultiplicationObjects:
    def __init__(self, B, D, g1, g2, factory=DyckObjects):
        self.B, self.D = tuple(map(tuple, B)), tuple(D)
        self.g1, self.g2 = tuple(g1), tuple(g2)
        self.rank = len(D)
        self.sets = None
        self.factors = []
        for g in (self.g1, self.g2):
            Bhat, Dhat = extended_data(B, D, g)
            model = factory(Bhat, Dhat)
            # The two factors share only the literal finite-set operations;
            # their matrices, state caches, and framed sources remain distinct.
            if self.sets is None:
                self.sets = model.sets
            else:
                model.sets = self.sets
            self.factors.append(model)
        self.coefficient = lru_cache(None)(self._coefficient)

    def output_label(self, p):
        return tuple(self.g1[i]+self.g2[i]+sum(self.B[i][j]*p[j]
                     for j in range(self.rank)) for i in range(self.rank))

    def _coefficient(self, p):
        h = self.output_label(p)
        base = tuple(self.D[i]*h[i] for i in range(self.rank))
        terms = []
        for a in box(p):
            b = tuple(p[i]-a[i] for i in range(self.rank))
            left = self.factors[0].count((1,)+a, endpoint_covector(a, base))
            right = self.factors[1].count((1,)+b, endpoint_covector(b, base))
            left = self.sets.tag(('theta_factor', 0, self.g1), left)
            right = self.sets.tag(('theta_factor', 1, self.g2), right)
            value = self.sets.product((left, right))
            terms.append(self.sets.tag(('coefficient_split', a, b), value))
        value = self.sets.union(terms)
        return self.sets.tag(('theta_structure_coefficient', self.g1, self.g2, p, h), value)


def export_polyhedral_coefficient(B, D, g1, g2, p):
    """The same pair definition with literal sparse-polytope input sets."""
    from global_sparse_polytope_recipe import SparsePolytopeObjects

    class OrdinarySparseObjects(SparsePolytopeObjects):
        # Retain only unit original leaves for classical multiplication.
        _count = DyckObjects._count

    model = ThetaMultiplicationObjects(B, D, g1, g2, factory=OrdinarySparseObjects)
    root = model.coefficient(tuple(p))
    recipe = model.sets.export(root)
    dimension = model.sets.dimension_bound(root)
    assert dimension <= 9*sum(p)
    # The geometric construction and exported systems precede counting.
    value = model.sets.cardinality(root)
    recipe['input'] = {'B': B, 'D': D, 'g1': g1, 'g2': g2, 'p': p,
                       'full_principal_output': [model.output_label(p), p]}
    recipe['validation'] = {'lattice_point_count': value,
                            'maximum_piece_ambient_dimension': dimension,
                            'dimension_bound': 9*sum(p),
                            'definition_enumerates_gradings': False,
                            'definition_calls_cardinality': False}
    path = Path(__file__).with_name('theta_multiplication_polyhedral_recipe.json')
    path.write_text(json.dumps(recipe, separators=(',', ':')))
    return {'degree': p, 'lattice_point_count': value,
            'maximum_piece_ambient_dimension': dimension,
            'reachable_recipe_nodes': recipe['reachable_nodes'],
            'reachable_polytopes': recipe['reachable_polytopes'],
            'recipe_file': path.name}


def main():
    begin = time.monotonic()
    B = [[0, 2, -1], [-1, 0, 1], [1, -2, 0]]
    D = [1, 2, 1]
    g1, g2, cap = (-1, -1, 1), (-1, 2, 2), (2, 1, 1)
    model = ThetaMultiplicationObjects(B, D, g1, g2)
    # First construct every actual recipe.  Cardinality and independent
    # signed recursion are evaluated only after this boundary.
    roots = {p: model.coefficient(p) for p in box(cap)}
    nodes_after_construction = len(model.sets.nodes)

    from endpoint_matrix_multiplication import EndpointMatrices
    independent = EndpointMatrices(B, D)
    signed = {tuple(row['degree']): row for row in independent.multiplication(g1, g2, cap)}
    rows, objects = [], {}
    for p, root in roots.items():
        value = model.sets.cardinality(root)
        assert value == signed[p]['triangular_structure_constant'] == signed[p]['endpoint_product']
        assert len(model.sets.nodes) == nodes_after_construction
        actual = [model.sets.select(root, i) for i in range(value)]
        encoded = [json.dumps(obj, sort_keys=True) for obj in actual]
        assert len(set(encoded)) == value
        objects[str(p)] = actual
        rows.append({'degree': p, 'output_label': model.output_label(p),
                     'actual_object_count': value, 'root_recipe': root,
                     'signed_triangular_structure_constant': signed[p]['triangular_structure_constant'],
                     'independent_signed_endpoint_product': signed[p]['endpoint_product']})
    recipe = {'B': B, 'D': D, 'g1': g1, 'g2': g2, 'cap': cap,
              'nodes': model.sets.nodes,
              'roots': {str(p): root for p, root in roots.items()},
              'actual_objects': objects,
              'definition_calls_cardinality': False,
              'definition_uses_signed_recursion': False}
    recipe_path = Path(__file__).with_name('theta_multiplication_object_recipes.json')
    recipe_path.write_text(json.dumps(recipe, indent=2))
    polyhedral = export_polyhedral_coefficient(B, D, g1, g2, (1, 1, 0))
    assert polyhedral['lattice_point_count'] == model.sets.cardinality(roots[(1, 1, 0)])
    report = {'status': 'PASS', 'B': B, 'D': D, 'g1': g1, 'g2': g2, 'cap': cap,
              'coefficient_comparisons': len(rows),
              'actual_objects_materialized': sum(row['actual_object_count'] for row in rows),
              'recipe_nodes': nodes_after_construction,
              'signed_matrix_entries': independent.entries,
              'results': rows, 'recipe_file': recipe_path.name,
              'factor_statistics': [dict(m.stats) for m in model.factors],
              'polyhedral_coefficient': polyhedral,
              'seconds': time.monotonic()-begin}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
