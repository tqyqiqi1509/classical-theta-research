"""Literal repeated-frame decomposition, independent of a coefficient oracle."""
from itertools import product
from pathlib import Path
import json

from tight_grading_two_input import bezout_rectangle, dyck_word, compositions, tight_profiles, is_tight
from intrinsic_two_page_trees import encode_grading


def check(A, B, k, M):
    W, H = bezout_rectangle(A, B, k)
    while W+H <= 2*k*(A+B)+2:
        W += A; H += B
    baseword = dyck_word(W, H)
    word = baseword*M
    L = len(baseword)
    x = y = 0
    rank_positions = {}
    for i, c in enumerate(baseword):
        rank_positions[H*x-W*y] = i
        if c == 'E': x += 1
        else: y += 1
    factors = {0: (None,)}
    for j in range(1, k+1):
        _, objects, rect = tight_profiles(A, B, j, 1, 1, True)
        smallword = dyck_word(*rect)
        factors[j] = tuple(encode_grading(A, B, j, smallword, g) for g in objects)
    images = set()
    tuple_count = 0
    for degrees in compositions(k, M):
        for trees in product(*(factors[j] for j in degrees)):
            grading = [0]*len(word)
            occupied = set()
            for slot, (j, tree) in enumerate(zip(degrees, trees)):
                if j == 0: continue
                root = slot*L+rank_positions[W+tree.residue]
                start = root-j*(A+B)
                window = tuple((start+i) % len(word) for i in range(j*(A+B)+1))
                assert not occupied.intersection(window)
                occupied.update(window)
                for parent, child in tree.edges:
                    grading[window[parent]] += 1
            grading = tuple(grading)
            assert is_tight(word, grading)
            assert grading not in images
            images.add(grading)
            tuple_count += 1
    E = [i for i, c in enumerate(word) if c == 'E']
    N = [i for i, c in enumerate(word) if c == 'N']
    actual = set()
    candidates = 0
    for evalues in compositions(k*B, len(E)):
        for nvalues in compositions(k*A, len(N)):
            candidates += 1
            g = [0]*len(word)
            for i, a in zip(E, evalues): g[i] = a
            for i, a in zip(N, nvalues): g[i] = a
            if is_tight(word, g): actual.add(tuple(g))
    assert actual == images, (A, B, k, M, len(actual), len(images))
    return dict(parameters=[A, B, k, M], base_rectangle=[W, H],
                literal_candidates=candidates, actual_objects=len(actual),
                ordered_tuple_objects=tuple_count)


if __name__ == '__main__':
    results = [check(*x) for x in [(1,1,1,2),(1,1,2,2),(1,2,1,2),(2,1,1,2)]]
    out = dict(status='PASS',checks=results)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))
