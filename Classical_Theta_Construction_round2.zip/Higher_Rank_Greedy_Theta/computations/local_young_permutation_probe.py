"""Test a structural candidate: ungraded local IH might be Young-permutation.

This is a route discriminator, not a conjecture inferred from small examples.
The first negative h coefficient terminates the stronger proposed mechanism.
"""
from pathlib import Path
import sys,json,time
from itertools import product
from functools import lru_cache
import sympy as sp
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'natural_incoming_module')]
from orbit_schur_positive import partitions
from equivariant_toric_ih import flow_polytope,equivariant_ih


@lru_cache(None)
def young_character(lam,mu):
    if not mu:return int(not any(lam))
    ans=0;k=mu[0]
    for j,a in enumerate(lam):
        if a>=k:
            rest=list(lam);rest[j]-=k
            ans+=young_character(tuple(rest),mu[1:])
    return ans


def run(charges,counts):
    types=[a for a,n in zip(charges,counts) for _ in range(n)]
    groups=[];off=0
    for n in counts:groups.append(tuple(range(off,off+n)));off+=n
    eta=tuple(tuple(a[0]*b[1]-a[1]*b[0] for b in types) for a in types)
    data=flow_polytope(eta);ix={tuple(e):i for i,e in enumerate(data['edges'])}
    classes=tuple(product(*(partitions(n) for n in counts)));traces=[]
    for mus in classes:
        sigma=list(range(len(types)))
        for g,mu in zip(groups,mus):
            off=0
            for k in mu:
                c=g[off:off+k];off+=k
                for i,a in enumerate(c):sigma[a]=c[(i+1)%k]
        ep=tuple(ix[sigma[a],sigma[b],k] for a,b,k in data['edges'])
        r=equivariant_ih(data['incidence'],data['vertices'],ep)
        traces.append(r['trace_total'])
    matrices=[sp.Matrix([[young_character(lam,mu) for lam in partitions(n)]
                         for mu in partitions(n)]) for n in counts]
    A=sp.kronecker_product(*matrices)
    h=list(A.inv()*sp.Matrix(traces))
    return {'charges':charges,'counts':counts,'dimension':traces[-1],
            'class_partitions':classes,'traces':traces,
            'h_coefficients':[str(a) for a in h],
            'negative_terms':[{'shape':s,'coefficient':str(a)} for s,a in zip(classes,h) if a<0],
            'all_integral':all(a.q==1 for a in h)}


def main():
    out=[]
    for charges,counts in [(((1,0),(0,1)),(3,3)),
                           (((1,0),(0,1)),(4,2)),
                           (((1,0),(0,1),(1,1)),(2,2,2))]:
        start=time.time();r=run(charges,counts);r['seconds']=time.time()-start
        out.append(r);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
        print(json.dumps(r),flush=True)
        if r['negative_terms']:break


if __name__=='__main__':main()
