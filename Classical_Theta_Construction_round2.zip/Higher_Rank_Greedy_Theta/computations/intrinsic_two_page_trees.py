"""Pure graph local objects; neither definition nor decoder uses shadows.

Vertices are positions in a fixed Christoffel interval.  An object is
(root rank residue, directed spanning-tree edges), with two noncrossing
pages and prescribed outdegree divisibilities.  Decorations may be
attached directly to the positive-outdegree vertices.
"""
from dataclasses import dataclass
from itertools import product
from math import gcd

from tight_grading_two_input import bezout_rectangle, dyck_word


@dataclass(frozen=True)
class TwoPageTree:
    residue: int
    edges: tuple


def geometry(A, B, k, residue):
    if min(A, B, k) <= 0 or gcd(A, B) != 1 or not 0 <= residue < k:
        raise ValueError('Invalid primitive slope, degree, or root residue')
    W, H = bezout_rectangle(A, B, k)
    p, q = k*A, k*B
    word = dyck_word(W, H)
    x = y = 0
    ranks = []
    for c in word:
        ranks.append(H*x-W*y)
        if c == 'E': x += 1
        else: y += 1
    root = ranks.index(W+residue)
    start = ranks.index(W+residue-k)
    window = []
    v = start
    while True:
        window.append(v)
        if v == root: break
        v = (v+1) % len(word)
    interval_word = tuple(word[v] for v in window)
    assert len(window) == p+q+1
    assert interval_word[0] == 'E' and interval_word[-1] == 'N'
    assert interval_word.count('E') == p and interval_word.count('N') == q+1
    return word, tuple(window), interval_word, (W, H)


def decode_tree(A, B, k, tree, u=1, v=1):
    """Validate only graph conditions and read its outdegrees as a grading."""
    if min(u, v) <= 0:
        raise ValueError('Divisibility factors must be positive')
    word, window, colors, rectangle = geometry(A, B, k, tree.residue)
    n = len(window)
    edges = tuple(tree.edges)
    if len(edges) != n-1 or len(set(edges)) != len(edges):
        raise ValueError('A spanning tree has n-1 distinct edges')
    parent = [-1]*n
    children = [[] for _ in range(n)]
    pages = {'E': [], 'N': []}
    for a, b in edges:
        if not 0 <= a < n or not 0 <= b < n or a == b or colors[a] == colors[b]:
            raise ValueError('Invalid bipartite edge')
        if parent[b] != -1 or b == n-1:
            raise ValueError('Every nonroot has one parent; root has none')
        parent[b] = a
        children[a].append(b)
        h, z = (a, b) if colors[a] == 'E' else (b, a)
        if h >= z:
            raise ValueError('Horizontal endpoint must precede vertical endpoint')
        pages[colors[a]].append((h, z))
    if any(parent[a] == -1 for a in range(n-1)):
        raise ValueError('A nonroot has no parent')
    reached = set()
    todo = [n-1]
    while todo:
        a = todo.pop()
        if a in reached:
            raise ValueError('Cycle')
        reached.add(a)
        todo.extend(children[a])
    if len(reached) != n:
        raise ValueError('Tree is disconnected')
    for arcs in pages.values():
        for i, (a, b) in enumerate(arcs):
            for c, d in arcs[i+1:]:
                if a < c < b < d or c < a < d < b:
                    raise ValueError('Same-page crossing')
    grading = [0]*len(word)
    for a, original in enumerate(window):
        degree = len(children[a])
        divisor = u if colors[a] == 'E' else v
        if degree % divisor:
            raise ValueError('Outdegree violates valued divisibility')
        grading[original] = degree
    return word, tuple(grading), rectangle


def encode_grading(A, B, k, word, grading):
    """Use the two-stack theorem to encode an existing local object."""
    from two_stack_shadow_forests import boundary_forest
    f = boundary_forest(word, grading)
    if not f.tight or len(f.nontrivial_roots) != 1:
        raise ValueError('Not a determinant-one tight tree')
    root = f.nontrivial_roots[0]
    W, H = word.count('E'), word.count('N')
    x = sum(c == 'E' for c in word[:root])
    y = root-x
    residue = H*x-W*y-W
    expected_word, window, colors, rectangle = geometry(A, B, k, residue)
    if tuple(word) != expected_word:
        raise ValueError('Path does not match the requested frame')
    positions = {v: i for i, v in enumerate(window)}
    edges = tuple(sorted((positions[a], positions[b]) for a, b in f.edges))
    tree = TwoPageTree(residue, edges)
    assert decode_tree(A, B, k, tree)[1] == tuple(grading)
    return tree


def validate():
    """Independent graph enumeration verifies the inverse, not just counts."""
    import json, time
    from pathlib import Path
    from tight_grading_two_input import tight_profiles, is_tight, direct_compatible
    start = time.monotonic()
    candidates = accepted = words = wraps = valued_filters = 0
    for total in range(2, 8):
        for p in range(1, total):
            q = total-p
            k = gcd(p, q)
            A, B = p//k, q//k
            decoded = set()
            for residue in range(k):
                word, window, colors, rectangle = geometry(A, B, k, residue)
                wraps += any(a > b for a, b in zip(window, window[1:]))
                words += 1
                n = len(window)
                choices = []
                for child in range(n-1):
                    if colors[child] == 'E':
                        choices.append(tuple(a for a in range(child+1, n) if colors[a] == 'N'))
                    else:
                        choices.append(tuple(a for a in range(child) if colors[a] == 'E'))
                for parents in product(*choices):
                    candidates += 1
                    tree = TwoPageTree(residue, tuple(sorted((a, b) for b, a in enumerate(parents))))
                    try:
                        outword, grading, _ = decode_tree(A, B, k, tree)
                    except ValueError:
                        continue
                    accepted += 1
                    assert is_tight(outword, grading) and direct_compatible(outword, grading)
                    assert encode_grading(A, B, k, outword, grading) == tree
                    decoded.add(grading)
                    for u in range(1, q+1):
                        if q % u: continue
                        for v in range(1, p+1):
                            if p % v: continue
                            possible = all(a % (u if c == 'E' else v) == 0 for a, c in zip(grading, word))
                            try:
                                decode_tree(A, B, k, tree, u, v)
                                success = True
                            except ValueError:
                                success = False
                            assert possible == success
                            valued_filters += 1
            literal = set(tight_profiles(A, B, k, 1, 1, True)[1])
            assert decoded == literal, (p, q, len(decoded), len(literal))
    result = dict(status='PASS',pure_graph_candidates=candidates,
                  accepted_actual_trees=accepted,root_windows=words,
                  wrapped_windows=wraps,valued_divisibility_filters=valued_filters,
                  seconds=time.monotonic()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    import json
    print(json.dumps(validate(), indent=2))
