"""Literal singleton-side tight gradings and a free cyclic slot-word quotient.

No coefficient oracle, set ranking, or sorting of decorations is used.
The circle action uses an explicit Bezout cocycle; the normal cut is
chosen by rational-Dyck prefix maxima and return intervals.
"""
from math import gcd, comb
from collections import Counter
from pathlib import Path
import json, time, random

from tight_grading_two_input import (
    bezout_rectangle, dyck_word, compositions, is_tight, direct_compatible,
)


def xgcd(a, b):
    if not b:
        return a, 1, 0
    g, x, y = xgcd(b, a % b)
    return g, y, x - (a // b) * y


def rotate(weights, phase, steps=1, copies=1):
    """Left rotation and its cocycle, on phase modulo copies*gcd(P,Q)."""
    P, Q = sum(weights), len(weights)
    ell, lam, mu = xgcd(P, Q)
    steps %= Q
    delta = copies * (lam * sum(weights[:steps]) + mu * steps)
    return weights[steps:] + weights[:steps], (phase-delta) % (copies*ell)


def cut_statistics(weights):
    P, Q = sum(weights), len(weights)
    ell = gcd(P, Q)
    A, B = P//ell, Q//ell
    running = 0
    returns = [0]
    for k, x in enumerate(weights[:-1], 1):
        running += x
        if Q*running > P*k:
            return None
        if Q*running == P*k:
            assert k % B == 0 and running == A*(k//B)
            returns.append(k//B)
    return returns


def normalize(weights, phase, copies=1):
    """Unique orbit representative with phase in the last-return interval."""
    # P=0 is the virtual inherited object, used only by the atom-split
    # constant term. Its unique phase is Q-1 when copies=1.
    assert len(weights) > 0 and min(weights) >= 0
    P, Q = sum(weights), len(weights)
    ell = gcd(P, Q)
    assert 0 <= phase < copies*ell
    # Rotate after the first maximum of the rational height process.
    running, best, cut = 0, 0, 0
    for k, x in enumerate(weights[:-1], 1):
        running += x
        value = Q*running - P*k
        if value > best:
            best, cut = value, k
    weights, phase = rotate(weights, phase, cut, copies)
    returns = cut_statistics(weights)
    assert returns is not None
    phi, slot = divmod(phase, copies)
    # The half-open cyclic intervals [previous return, next return)
    # choose exactly one return cut, without looking at decorations.
    next_return = next((r for r in returns if r > phi), 0)
    weights, phase = rotate(weights, phase, next_return*(Q//ell), copies)
    final_returns = cut_statistics(weights)
    phi, new_slot = divmod(phase, copies)
    assert new_slot == slot and final_returns[-1] <= phi < ell
    return weights, phase


def to_cyclic(word, grading, slot=0, copies=1):
    E = [i for i, x in enumerate(word) if x == 'E']
    N = [i for i, x in enumerate(word) if x == 'N']
    positive = [i for i, e in enumerate(E) if grading[e]]
    assert len(positive) == 1
    i0 = positive[0]
    Q = grading[E[i0]]
    P = sum(grading[n] for n in N)
    W, H = len(E), len(N)
    ell = gcd(P, Q)
    assert P*H-Q*W == ell
    residue = (H*i0) % W - (W-ell)
    assert 0 <= residue < ell
    y = H*i0//W
    indices = [(y+1+j) % H for j in range(Q)]
    weights = tuple(grading[N[j]] for j in indices)
    assert all(grading[N[j]] == 0 for j in range(H) if j not in indices)
    phi = ell-1-residue
    phase = copies*phi+slot
    assert normalize(weights, phase, copies) == (weights, phase)
    return weights, phase


def from_cyclic(weights, phase, copies=1):
    weights, phase = normalize(tuple(weights), phase, copies)
    P, Q = sum(weights), len(weights)
    assert P > 0, "The zero word is inherited; it has no positive Dyck factory."
    ell = gcd(P, Q)
    W, H = bezout_rectangle(P//ell, Q//ell, ell)
    word = dyck_word(W, H)
    E = [i for i, x in enumerate(word) if x == 'E']
    N = [i for i, x in enumerate(word) if x == 'N']
    phi, slot = divmod(phase, copies)
    residue = ell-1-phi
    i0 = (pow(H, -1, W)*(W-ell+residue)) % W if W > 1 else 0
    y = H*i0//W
    grading = [0]*len(word)
    grading[E[i0]] = Q
    for j, weight in enumerate(weights):
        grading[N[(y+1+j) % H]] = weight
    return word, tuple(grading), slot


def literal_objects(P, Q, v=1):
    ell = gcd(P, Q)
    W, H = bezout_rectangle(P//ell, Q//ell, ell)
    word = dyck_word(W, H)
    E = [i for i, x in enumerate(word) if x == 'E']
    N = [i for i, x in enumerate(word) if x == 'N']
    out = set()
    for i in E:
        for weights in compositions(P//v, H):
            grading = [0]*len(word)
            grading[i] = Q
            for j, weight in enumerate(weights):
                grading[N[j]] = v*weight
            grading = tuple(grading)
            if is_tight(word, grading):
                out.add(grading)
    return word, out


def main():
    start = time.monotonic()
    rng = random.Random(2611131517)
    nparams = nwords = nphase = norbit = nliteral = nfree = 0
    actual_input_grading_checks = 0
    for P in range(1, 13):
        for Q in range(1, 13):
            if comb(P+Q-1,Q-1) > 50000:
                continue
            ell = gcd(P, Q)
            normalized = set()
            for weights in compositions(P, Q):
                nwords += 1
                for phase in range(ell):
                    normal = normalize(weights, phase)
                    normalized.add(normal)
                    nphase += 1
                    if nphase % 13 == 0:
                        for cut in range(Q):
                            rotated = rotate(weights, phase, cut)
                            assert normalize(*rotated) == normal
                            norbit += 1
                    if nphase % 37 == 0:
                        orbit = {rotate(weights, phase, cut) for cut in range(Q)}
                        assert len(orbit) == Q
                        nfree += 1
            assert len(normalized)*Q == ell*comb(P+Q-1,Q-1)
            for normal in normalized:
                word, grading, slot = from_cyclic(*normal)
                assert slot == 0 and is_tight(word, grading)
                assert to_cyclic(word, grading) == normal
                if nliteral % 79 == 0:
                    assert direct_compatible(word, grading)
                nliteral += 1
            W,H = bezout_rectangle(P//ell,Q//ell,ell)
            if W*comb(P+H-1,H-1) <= 250000:
                word, actual = literal_objects(P,Q)
                inverse_actual = {from_cyclic(*normal)[1] for normal in normalized}
                assert actual == inverse_actual, (P,Q,len(actual),len(inverse_actual))
                actual_input_grading_checks += W*comb(P+H-1,H-1)
            nparams += 1
    # Divisibility, nontrivial tuple slots, and natural decorations are
    # transported by exactly the same cyclic permutation of slot indices.
    nvalued = 0
    for _ in range(5000):
        Q = rng.randrange(1,18)
        a = rng.randrange(1,15)
        v = rng.randrange(1,11)
        positions = [rng.randrange(Q) for _ in range(a)]
        weights = tuple(v*positions.count(i) for i in range(Q))
        ell = gcd(a*v,Q)
        copies = rng.randrange(1,9)
        phase = rng.randrange(copies*ell)
        normal = normalize(weights,phase,copies)
        word, grading, slot = from_cyclic(*normal,copies)
        assert is_tight(word,grading)
        assert to_cyclic(word,grading,slot,copies) == normal
        for cut in (0,1,Q//2,Q-1):
            assert normalize(*rotate(weights,phase,cut,copies),copies) == normal
        nvalued += 1
    result = dict(status='PASS',parameter_pairs=nparams,slot_words=nwords,
                  word_phase_points=nphase,orbit_rotation_checks=norbit,
                  free_action_checks=nfree,reconstructed_actual_gradings=nliteral,
                  independent_literal_candidates=actual_input_grading_checks,
                  valued_divisibility_tuple_tests=nvalued,
                  seconds=time.monotonic()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
