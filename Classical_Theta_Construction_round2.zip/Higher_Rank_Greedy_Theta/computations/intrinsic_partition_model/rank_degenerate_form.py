"""A nonzero seven-mutable-leaf check with rank-two ambient skew form."""
import json,time
from pathlib import Path
import sympy as sp
from intrinsic_partitions import PartitionModel
from structural_verification import structure
from verify_partitions import direct_dimension,FlowPackets

start=time.time()
B=[[0,1,2,3],[-1,0,1,2],[-2,-1,0,1],[-3,-2,-1,0]]
D=[1]*4;g=(-3,)*4;p=(2,2,2,1)
M=PartitionModel(B,D,g,p);direct=sum(direct_dimension(T,M.eta)for T in M.trees())
F=FlowPackets(B,D,g,tuple((i,1)for i,k in enumerate(p)for _ in range(k)),color_perturb=True)
raw=F.flow(F.full,F.theta)
row={'B':B,'D':D,'g':g,'p':p,'framed_skew_rank':sp.Matrix(M.color_eta).rank(),
     'skeletons':M.trees(),'direct_raw_dimension':direct,'independent_binary_recursion':raw,
     'structure':structure(M),'seconds':time.time()-start,'pass':direct==raw and direct>0,
     'implementation_correction':'Initial serialization used M.trees instead of M.trees(); corrected before this successful rerun.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(row,indent=2))
print(json.dumps({k:row[k]for k in ['framed_skew_rank','direct_raw_dimension','independent_binary_recursion','seconds','pass']}),flush=True)
