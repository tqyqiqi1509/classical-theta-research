"""Actual matrices for the direct partition/fan coefficient-space candidate.

Only the standalone verification at the bottom imports an independent theta
recursion.  The construction accepts the exchange matrix and pointed data.
"""
from pathlib import Path
import sys,json,time
from itertools import product
from functools import lru_cache
from math import prod
import sympy as sp

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(HERE),str(ROOT/'computations'/'ih_global_independent'),str(ROOT/'computations'/'natural_incoming_module')]
from intrinsic_partitions import PartitionModel,leaves,rename
from fan_linear_module import FanModule,sign_subspace
from equivariant_toric_ih import flow_polytope


def flat_index(t,dims):
    a=0
    for x,d in zip(t,dims):a=a*d+x
    return a


class LocalModule:
    def __init__(self,eta):
        self.eta=eta;self.n=len(eta);self.parity=sum(abs(eta[i][j])for i in range(self.n)for j in range(i+1,self.n))%2
        self.hub=next((h for h in range(self.n) if all(eta[h][i] for i in range(self.n)if i!=h) and all(not eta[i][j] for i in range(self.n) for j in range(self.n) if i!=h and j!=h)),None)
        if self.hub is not None:
            self.leaves=[i for i in range(self.n)if i!=self.hub]
            self.sizes=[abs(eta[self.hub][i])for i in self.leaves]
            self.basis=list(product(*(range(m)for m in self.sizes)))
            self.dimension=len(self.basis);self.kind='projective-star'
        else:
            data=flow_polytope(eta);self.edges=data['edges']
            d=len(self.edges)-self.n+1
            self.fan=FanModule(data['incidence'],data['vertices'],max_degree=d//2)
            ds=self.fan.dimensions();self.dimension=sum(ds[h] if h<len(ds) else ds[d-h] for h in range(d+1))
            self.kind='minimal-extension-matrices'
        self.action=lru_cache(None)(self._action)

    def _action(self,cp):
        assert all(self.eta[i][j]==self.eta[cp[i]][cp[j]]for i in range(self.n)for j in range(self.n))
        if self.hub is not None:
            assert cp[self.hub]==self.hub
            out=sp.zeros(self.dimension)
            for j,t in enumerate(self.basis):
                u=[0]*len(t)
                for k,i in enumerate(self.leaves):u[self.leaves.index(cp[i])]=t[k]
                out[flat_index(u,self.sizes),j]=1
            return out
        positions={tuple(e):i for i,e in enumerate(self.edges)}
        perm=tuple(positions[cp[a],cp[b],k] for a,b,k in self.edges)
        return self.fan.ungraded_action(perm)


class GlobalModule:
    def __init__(self,B,g,p):
        if any(B[i][j]!=-B[j][i]for i in range(len(B))for j in range(len(B))):
            raise ValueError('Natural matrix decorations currently require skew-symmetric B')
        self.model=PartitionModel(B,[1]*len(B),g,p)
        self.trees=self.model.trees();self.types={};self.nodes={};self.dimensions={};self.offsets={};self.dimension=0
        def gather(T,result):
            if isinstance(T,int):return
            S=tuple(sorted(leaves(T)))
            cs=sorted((tuple(sorted(leaves(C)))for C in T),key=lambda C:(self.block_charge(C),C))
            eta=tuple(tuple(sum(self.model.eta[i][j]for i in A for j in B)for B in cs)for A in cs)
            if eta not in self.types:self.types[eta]=LocalModule(eta)
            result[S]={'children':cs,'eta':eta,'module':self.types[eta]}
            for C in T:gather(C,result)
        for T in self.trees:
            nodes={};gather(T,nodes);ordered=sorted(nodes,key=lambda S:(len(S),S))
            self.nodes[T]=(ordered,nodes)
            d=prod(nodes[S]['module'].dimension for S in ordered)
            self.dimensions[T]=d;self.offsets[T]=self.dimension;self.dimension+=d

    def block_charge(self,S):
        return tuple(sum(self.model.colors[i]==c for i in S)for c in range(self.model.n+1))

    def block_action(self,T,sigma):
        target=rename(T,sigma);srcorder,srcnodes=self.nodes[T];dstorder,dstnodes=self.nodes[target]
        images=[tuple(sorted(sigma[i]for i in S))for S in srcorder]
        factor_perm=[dstorder.index(S)for S in images]
        parities=[srcnodes[S]['module'].parity for S in srcorder]
        sign=(-1)**sum(parities[i]*parities[j]for i in range(len(srcorder))for j in range(i+1,len(srcorder))if factor_perm[i]>factor_perm[j])
        mats=[]
        for S,U in zip(srcorder,images):
            src,dst=srcnodes[S],dstnodes[U]
            assert src['eta']==dst['eta']
            cp=tuple(dst['children'].index(tuple(sorted(sigma[i]for i in C)))for C in src['children'])
            mats.append(src['module'].action(cp))
        K=sp.kronecker_product(*mats) if mats else sp.ones(1)
        dims=[srcnodes[S]['module'].dimension for S in srcorder]
        outdims=[dstnodes[S]['module'].dimension for S in dstorder]
        out=sp.zeros(K.rows,K.cols)
        for j,t in enumerate(product(*(range(d)for d in dims))):
            u=[0]*len(t)
            for i,x in enumerate(t):u[factor_perm[i]]=x
            out[flat_index(u,outdims),:]=sign*K[j,:]
        return target,out

    def action(self,sigma):
        sigma=tuple(sigma)
        assert sorted(sigma)==list(range(self.model.r))
        assert all(self.model.colors[i]==self.model.colors[sigma[i]]for i in range(self.model.r))
        out=sp.zeros(self.dimension)
        for T in self.trees:
            U,M=self.block_action(T,sigma);a=self.offsets[U];b=self.offsets[T]
            out[a:a+M.rows,b:b+M.cols]=M
        return out

    def adjacent_generators(self):
        result=[]
        for i in range(1,self.model.r-1):
            if self.model.colors[i]!=self.model.colors[i+1]:continue
            sigma=list(range(self.model.r));sigma[i],sigma[i+1]=i+1,i
            result.append((tuple(sigma),self.action(sigma)))
        return result

    def coefficient_space(self):
        generators=self.adjacent_generators()
        if not generators:return sp.eye(self.dimension),generators
        return sign_subspace([M for sigma,M in generators]),generators


def sparse_data(M):
    return {'shape':M.shape,'entries':[[i,j,str(M[i,j])]for i in range(M.rows)for j in range(M.cols)if M[i,j]]}


def main():
    start=time.time()
    B=[[0,2,-3],[-2,0,2],[3,-2,0]];g=(-3,3,-2);p=(2,2,1)
    M=GlobalModule(B,g,p);basis,generators=M.coefficient_space()
    A,C=[a for sigma,a in generators]
    checks={'first_square':A*A==sp.eye(M.dimension),'second_square':C*C==sp.eye(M.dimension),'commute':A*C==C*A,
            'basis_first_sign':A*basis==-basis,'basis_second_sign':C*basis==-basis}
    # Independent comparison only after every actual matrix and kernel exists.
    sys.path.insert(0,str(ROOT/'agents'))
    from incoming_recursion import IncomingSchur
    theta=IncomingSchur(B,[1]*3).theta_prefix(g,p)[p]
    result={'B':B,'g':g,'p':p,'skeletons':M.trees,'module_dimension':M.dimension,
            'summand_dimensions':[M.dimensions[T]for T in M.trees],
            'local_types':[{'eta':eta,'dimension':L.dimension,'kind':L.kind,'parity':L.parity}for eta,L in M.types.items()],
            'traces':[M.dimension,int(A.trace()),int(C.trace()),int((A*C).trace())],
            'coefficient_kernel_dimension':basis.cols,'independent_theta':theta,'checks':checks,
            'generators':[{'permutation':sigma,'matrix':sparse_data(a)}for sigma,a in generators],
            'coefficient_basis':sparse_data(basis),'seconds':time.time()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:result[k]for k in ['module_dimension','summand_dimensions','traces','coefficient_kernel_dimension','independent_theta','checks','seconds']},indent=2),flush=True)


if __name__=='__main__':main()
