"""Direct simultaneous-event trees from finite set partitions.

This construction uses only B,D,g,p, integer charges and lexicographic
rational vectors.  It does not enumerate binary flow trees, invoke a wall
completion, or evaluate theta coefficients.  The binary construction is
imported only by the separate verification script.
"""
from fractions import Fraction
from functools import lru_cache
from itertools import product
from math import gcd


def lexsign(v):
    return next((1 if a > 0 else -1 for a in v if a), 0)


def leaves(T):
    return (T,) if isinstance(T, int) else tuple(i for C in T for i in leaves(C))


def rename(T, permutation):
    if isinstance(T, int):
        return permutation[T]
    return tuple(sorted((rename(C, permutation) for C in T), key=lambda C:min(leaves(C))))


class PartitionModel:
    """Exact recursive set-partition model, including nonscalar D.

    D affects the skew form, not the set-partition algorithm.  For D!=1 the
    raw local IH decorations still need the separate valued normalization.
    """
    def __init__(self, B, D, g, p, color_order=None):
        n = len(B)
        assert len(D) == len(g) == len(p) == n
        assert all(D[i]*B[i][j] == -D[j]*B[j][i] for i in range(n) for j in range(n))
        assert all(d > 0 for d in D) and all(a >= 0 for a in p)
        self.B, self.D, self.g, self.p = tuple(map(tuple,B)), tuple(D), tuple(g), tuple(p)
        self.n = n
        self.colors = (0,)+tuple(i+1 for i in range(n) for _ in range(p[i]))
        self.r = len(self.colors)
        self.full = (1 << self.r)-1
        self.ids = {S:tuple(i for i in range(self.r) if S>>i&1) for S in range(1,self.full+1)}
        self.charge = {S:tuple(sum(self.colors[j] == i for j in self.ids[S]) for i in range(n+1)) for S in self.ids}
        C = [[0]*(n+1) for _ in range(n+1)]
        for i in range(n):
            C[0][i+1] = D[i]*g[i]
            C[i+1][0] = -D[i]*g[i]
            for j in range(n):
                C[i+1][j+1] = -D[i]*B[i][j]
        self.color_eta = tuple(map(tuple,C))
        self.eta = tuple(tuple(C[i][j] for j in self.colors) for i in self.colors)
        self.out = {S:tuple(sum(self.eta[a][i] for a in self.ids[S]) for i in range(self.r)) for S in self.ids}
        self.connected = {S:self._connected(S) for S in self.ids}
        order = tuple(range(n)) if color_order is None else tuple(color_order)
        assert sorted(order) == list(range(n))
        mutable = [tuple([Fraction(1)]+[Fraction(i == j) for j in order]) for i in range(n)]
        frame = tuple(-sum(p[i]*mutable[i][j] for i in range(n)) for j in range(n+1))
        self.theta = (frame,)+tuple(mutable[i-1] for i in self.colors[1:])
        self.states = self.planes_examined = self.admissible_events = 0
        self.solve = lru_cache(None)(self._solve)
        self.planes = lru_cache(None)(self._planes)
        self.plane_subsets = lru_cache(None)(self._plane_subsets)

    def _connected(self,S):
        ids=self.ids[S]
        reached={ids[0]};stack=[ids[0]]
        while stack:
            i=stack.pop()
            for j in ids:
                if j not in reached and self.eta[i][j]:
                    reached.add(j);stack.append(j)
        return len(reached)==len(ids)

    def pair(self,S,T):
        return sum(self.out[S][j] for j in self.ids[T])

    @staticmethod
    def wedge_key(a,b):
        wedge=tuple(a[i]*b[j]-a[j]*b[i] for i in range(len(a)) for j in range(i+1,len(a)))
        h=0
        for v in wedge:h=gcd(h,abs(v))
        if not h:return None
        first=next(v for v in wedge if v)
        return tuple(v//(h if first>0 else -h) for v in wedge)

    @staticmethod
    def in_plane(a,b,c):
        n=len(a)
        i,j=next((i,j) for i in range(n) for j in range(i+1,n) if a[i]*b[j]!=a[j]*b[i])
        det=a[i]*b[j]-a[j]*b[i]
        u=c[i]*b[j]-c[j]*b[i]
        v=a[i]*c[j]-a[j]*c[i]
        return all(det*c[k]==u*a[k]+v*b[k] for k in range(n))

    def _planes(self,S):
        """Planes span(S,T), represented once by a primitive exterior vector."""
        result={}; first=S&-S; T=(S-1)&S
        while T:
            if T&first and self.pair(S,T):
                key=self.wedge_key(self.charge[S],self.charge[T])
                result.setdefault(key,T)
            T=(T-1)&S
        return tuple(sorted(result.items()))

    def _plane_subsets(self,S,T):
        a,b=self.charge[S],self.charge[T]
        subsets=[];U=(S-1)&S
        while U:
            if self.connected[U] and self.in_plane(a,b,self.charge[U]):
                subsets.append(U)
            U=(U-1)&S
        return tuple(sorted(subsets))

    def _solve(self,S,theta):
        self.states+=1
        ids=self.ids[S]
        if len(ids)==1:return (ids[0],)
        if not self.connected[S]:return ()
        assert not any(sum(row[j] for row in theta) for j in range(len(theta[0])))
        positions={i:j for j,i in enumerate(ids)}
        answer=set()
        for key,T in self.planes(S):
            self.planes_examined+=1
            denom=self.pair(S,T)
            h=tuple(sum(theta[positions[i]][j] for i in self.ids[T]) for j in range(len(theta[0])))
            time=tuple(-v/denom for v in h)
            if lexsign(time)<=0:continue
            projected=tuple(tuple(row[j]+time[j]*self.out[S][i] for j in range(len(time))) for i,row in zip(ids,theta))
            options={}
            for U in self.plane_subsets(S,T):
                subtheta=tuple(projected[positions[i]] for i in self.ids[U])
                assert not any(sum(row[j] for row in subtheta) for j in range(len(time)))
                values=self.solve(U,subtheta)
                if values:options[U]=values
            @lru_cache(None)
            def partitions(R):
                if not R:return ((),)
                first=R&-R
                return tuple((U,)+tail for U in options if U&first and U&R==U for tail in partitions(R^U))
            for blocks in partitions(S):
                # A purely parallel partition is not an event and belongs to
                # the surrounding plethystic ray assembly instead.
                if len(blocks)<2 or not any(self.pair(S,U) for U in blocks):continue
                self.admissible_events+=1
                for children in product(*(options[U] for U in blocks)):
                    answer.add(tuple(children))
        return tuple(sorted(answer,key=repr))

    def trees(self):
        return self.solve(self.full,self.theta)

    def statistics(self):
        return {'states':self.states,'planes_examined':self.planes_examined,
                'admissible_events':self.admissible_events,'cache':str(self.solve.cache_info())}


if __name__=='__main__':
    B=[[0,2,-3],[-2,0,2],[3,-2,0]]
    P=PartitionModel(B,[1,1,1],(-3,3,-2),(2,2,1))
    for T in P.trees():print(T)
    print(P.statistics())
