"""Structural cases: coincident colors, nonprimitive charges and rank loss.

This is deliberately a mechanism check, not an attempt to build evidence by
padding the random suite with many low-degree cases.
"""
import json,time,sys
from pathlib import Path
from fractions import Fraction
from functools import reduce
from math import gcd
import sympy as sp
from intrinsic_partitions import PartitionModel,leaves,lexsign
from verify_partitions import check_one


def structure(M):
    records=[]
    def visit(T,theta):
        if isinstance(T,int):return
        ids=tuple(sorted(leaves(T)));S=sum(1<<i for i in ids)
        blocks=[sum(1<<i for i in leaves(C)) for C in T]
        T0=next(U for U in blocks if M.pair(S,U))
        timevec=tuple(-sum(theta[i][j]for i in M.ids[T0])/M.pair(S,T0) for j in range(M.n+1))
        assert lexsign(timevec)>0
        projected={i:tuple(theta[i][j]+timevec[j]*M.out[S][i] for j in range(M.n+1))for i in ids}
        assert all(not any(sum(projected[i][j]for i in M.ids[U])for j in range(M.n+1))for U in blocks)
        charges=[M.charge[U]for U in blocks]
        assert sp.Matrix(charges).rank()==2
        parallel=sum(M.wedge_key(a,b)is None for k,a in enumerate(charges)for b in charges[k+1:])
        primitive=reduce(gcd,M.charge[S])
        records.append({'leaves':ids,'charge':M.charge[S], 'children':charges,
                        'content':primitive,'parallel_child_pairs':parallel,
                        'incoming_rank':sp.Matrix([theta[i]for i in ids]).rank(),
                        'projected_rank':sp.Matrix([projected[i]for i in ids]).rank(),
                        'time':[str(a)for a in timevec]})
        for C in T:visit(C,projected)
    for T in M.trees():visit(T,{i:M.theta[i]for i in range(M.r)})
    return {'events':len(records), 'nonprimitive_events':sum(x['content']>1 for x in records),
            'parallel_child_events':sum(x['parallel_child_pairs']>0 for x in records),
            'zero_projected_rank_events':sum(x['projected_rank']==0 for x in records),
            'nonprimitive_examples':[x for x in records if x['content']>1][:3],
            'rank_zero_examples':[x for x in records if x['projected_rank']==0][:3]}


def main():
    start=time.time();out=[]
    # The first input forces a genuine change of the color-lex chamber.
    cases=[('color-order-boundary',[[0,1],[-1,0]],[1,1],(-2,0),(1,1)),
           ('nonprimitive-K33',[[0,2,-3],[-2,0,2],[3,-2,0]],[1]*3,(-5,5,-2),(3,3,1)),
           ('ambient-form-rank-two',[[0,2,-3],[-2,0,2],[3,-2,0]],[1]*3,(-3,2,0),(3,2,2)),
           ('rank-four-seven-leaves',[[0,1,-1,2],[-1,0,2,-1],[1,-2,0,1],[-2,1,-1,0]],[1]*4,(-3,-2,-2,-1),(2,2,2,1)),
           ('rank-five-valued-seven-leaves',[[0,2,-3,1,-2],[-1,0,3,-1,2],[1,-2,0,1,-2],[-1,2,-3,0,2],[1,-2,3,-1,0]],[1,2,3,1,2],(-3,-2,-1,-2,-1),(3,1,1,1,1))]
    for label,B,D,g,p in cases:
        try:
            row=check_one(B,D,g,p,do_colors=label=='color-order-boundary',do_char=label=='color-order-boundary')
            M=PartitionModel(B,D,g,p);row['structure']=structure(M);row['label']=label
        except Exception as e:
            import traceback
            row={'label':label,'pass':False,'error':repr(e),'traceback':traceback.format_exc()}
        out.append(row)
        Path(__file__).with_suffix('.json').write_text(json.dumps({'elapsed':time.time()-start,'results':out},indent=2))
        print(json.dumps({k:row.get(k)for k in ['label','skeletons','direct_seconds','seconds','pass','error']}) ,flush=True)
        if not row['pass']:break
    print(json.dumps({'all_pass':all(r['pass']for r in out),'seconds':time.time()-start}),flush=True)

if __name__=='__main__':main()
