"""Full matrices: noncommuting S3 relations and the odd factor interchange."""
from pathlib import Path
from itertools import permutations,product
import json,time,sys
import sympy as sp
from global_matrix_module import GlobalModule,sparse_data,ROOT
sys.path[:0]=[str(ROOT/'computations'/'squarefree_polytope_action'),str(ROOT/'agents')]
from global_tensor_ih import partitions,representative,weighted_theta
from incoming_recursion import IncomingSchur


def test_case(label,B,g,p):
    start=time.time();M=GlobalModule(B,g,p);basis,gens=M.coefficient_space()
    A=[sp.SparseMatrix(a)for sigma,a in gens];identity=sp.eye(M.dimension)
    checks={'involutions':all(a*a==identity for a in A),
            'sign_kernel':all(a*basis==-basis for a in A)}
    # Presentation relations are sufficient for an abstract symmetric-group
    # action; all six permutations additionally test the implementation map.
    if p[0]==3:
        checks['S3_braid']=A[0]*A[1]*A[0]==A[1]*A[0]*A[1]
        checks['S3_noncommuting']=A[0]*A[1]!=A[1]*A[0]
        matrices={}
        for q in permutations(range(1,4)):
            sigma=(0,)+q+tuple(range(4,M.model.r))
            matrices[sigma]=sp.SparseMatrix(M.action(sigma))
        checks['all_36_S3_products']=all(a*b==matrices[tuple(s[t[i]]for i in range(M.model.r))]
            for s,a in matrices.items()for t,b in matrices.items())
    else:checks['commute']=all(a*b==b*a for a in A for b in A)
    character=[]
    for parts in product(*(partitions(k)for k in p)):
        sigma=representative(p,parts);a=int(M.action(sigma).trace());target=weighted_theta(B,g,parts)
        character.append({'cycles':parts,'actual_matrix_trace':a,'weighted_cycle_theta':target,'pass':a==target})
    theta=IncomingSchur(B,[1]*len(B)).theta_prefix(g,p)[p]
    result={'label':label,'B':B,'g':g,'p':p,'dimension':M.dimension,'skeletons':M.trees,
            'summand_dimensions':[M.dimensions[T]for T in M.trees],
            'local_types':[{'eta':eta,'dimension':L.dimension,'parity':L.parity,'kind':L.kind}for eta,L in M.types.items()],
            'kernel_dimension':basis.cols,'theta_comparison':theta,'checks':checks,
            'character':character,'generators':[{'permutation':sigma,'matrix':sparse_data(a)}for sigma,a in gens],
            'coefficient_basis':sparse_data(basis)}
    if label=='odd-Koszul':
        saved=[L.parity for L in M.types.values()]
        for L in M.types.values():L.parity=0
        sigma=representative(p,((2,),(2,),(1,)))
        result['ordinary_tensor_double_trace']=int(M.action(sigma).trace())
        for L,v in zip(M.types.values(),saved):L.parity=v
        result['correct_double_trace']=int(M.action(sigma).trace())
        checks['odd_sign_has_effect']=result['ordinary_tensor_double_trace']!=result['correct_double_trace']
    result['seconds']=time.time()-start
    result['pass']=all(checks.values())and all(x['pass']for x in character)and basis.cols==theta
    return result


def main():
    start=time.time();results=[]
    cases=[('noncommuting-S3',[[0,1],[-1,0]],(-4,1),(3,1)),
           ('odd-Koszul',[[0,-1,2],[1,0,2],[-2,-2,0]],(1,-3,0),(2,2,1))]
    for label,B,g,p in cases:
        row=test_case(label,B,g,p);results.append(row)
        Path(__file__).with_suffix('.json').write_text(json.dumps({'seconds':time.time()-start,'results':results},indent=2))
        print(json.dumps({k:row[k]for k in ['label','dimension','kernel_dimension','theta_comparison','checks','pass','seconds']},indent=2),flush=True)
    print(json.dumps({'all_pass':all(x['pass']for x in results),'seconds':time.time()-start}),flush=True)

if __name__=='__main__':main()
