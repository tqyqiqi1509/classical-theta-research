"""Independent comparisons for the direct partition construction."""
from pathlib import Path
import sys,json,time,random
from itertools import product
from math import gcd,prod

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(HERE),str(ROOT/'agents'),str(ROOT/'computations'/'simultaneous_packet_vertices'),str(ROOT/'computations'/'squarefree_polytope_action')]
from intrinsic_partitions import PartitionModel,leaves,rename
from universal_flow_tree_probe import FlowPackets
from universal_twig_action_probe import trees
from zero_flow_contraction import evaluate_contract
from global_tensor_ih import generic_tree_dimension,trace_skeleton,partitions,representative,weighted_theta


def binary_old(B,D,g,p):
    packets=tuple((i,1) for i,k in enumerate(p) for _ in range(k))
    F=FlowPackets(B,D,g,packets,color_perturb=True)
    out={};positive=0
    for T in trees(F.full):
        row=evaluate_contract(F,T)
        if row is not None:
            w,K,_=row;out[K]=out.get(K,0)+w;positive+=1
    return out,positive


def direct_dimension(T,eta):
    if isinstance(T,int):return 1
    cs=[leaves(C) for C in T]
    q=tuple(tuple(sum(eta[i][j] for i in A for j in B) for B in cs)for A in cs)
    return generic_tree_dimension(q)*prod(direct_dimension(C,eta) for C in T)


def check_one(B,D,g,p,do_old=True,do_colors=False,do_char=False):
    start=time.time();M=PartitionModel(B,D,g,p);direct=M.trees()
    row={'B':B,'D':D,'g':g,'p':p,'direct_seconds':time.time()-start,'skeletons':len(direct),'statistics':M.statistics()}
    if do_old:
        now=time.time();old,positive=binary_old(B,D,g,p)
        row['binary_seconds']=time.time()-now;row['positive_binary']=positive
        row['same_skeletons']=set(direct)==set(old)
        row['same_weights']=all(direct_dimension(T,M.eta)==old.get(T) for T in direct)
        if not row['same_skeletons']:
            row['extra']=list(set(direct)-set(old))[:2];row['missing']=list(set(old)-set(direct))[:2]
    else:row['same_skeletons']=row['same_weights']=None
    direct_set=set(direct);clonechecks=0
    for i in range(1,M.r):
        for j in range(i+1,M.r):
            if M.colors[i]!=M.colors[j]:continue
            sigma=list(range(M.r));sigma[i],sigma[j]=j,i
            assert {rename(T,sigma) for T in direct}==direct_set
            clonechecks+=1
    row['clone_set_checks']=clonechecks
    if do_char:
        assert all(d == 1 for d in D)
        row['characters']=[]
        for parts in product(*(partitions(k) for k in p)):
            sigma=representative(p,parts)
            observed=sum(trace_skeleton(T,M.eta,sigma) for T in direct)
            target=weighted_theta(B,g,parts)
            row['characters'].append({'cycle_type':parts,'trace':observed,'target':target,'pass':observed==target})
    if do_colors:
        order=tuple(reversed(range(len(B))))
        M2=PartitionModel(B,D,g,p,color_order=order);other=M2.trees()
        row['reverse_color_order']={'skeletons':len(other),'same_set':set(other)==direct_set,'same_identity_dimension':sum(direct_dimension(T,M.eta)for T in direct)==sum(direct_dimension(T,M.eta)for T in other)}
        if do_char:
            vals=[]
            for parts in product(*(partitions(k) for k in p)):
                sigma=representative(p,parts)
                a=sum(trace_skeleton(T,M.eta,sigma)for T in direct)
                b=sum(trace_skeleton(T,M.eta,sigma)for T in other)
                vals.append(a==b)
            row['reverse_color_order']['all_characters_equal']=all(vals)
    row['seconds']=time.time()-start
    row['pass']=row.get('same_skeletons')is not False and row.get('same_weights')is not False and all(x['pass']for x in row.get('characters',[])) and row.get('reverse_color_order',{}).get('same_identity_dimension',True) and row.get('reverse_color_order',{}).get('all_characters_equal',True)
    return row


def main():
    rng=random.Random(131126);start=time.time();out=[]
    cases=[([[0,2,-3],[-2,0,2],[3,-2,0]],[1]*3,(-3,3,-2),(2,2,1)),
           ([[0,1],[-1,0]],[1,1],(-6,1),(4,2)),
           ([[0,3],[-2,0]],[2,3],(-2,1),(2,2))]
    profiles=[(2,1,1),(2,2,1),(3,1,1),(2,2,2),(1,1,1,1),(2,1,1,1),(2,2,1,1),(1,1,1,1,1),(2,1,1,1,1)]
    for profile in profiles:
        for trial in range(8):
            n=len(profile);D=[1]*n if trial<5 else [rng.choice([1,2,3])for _ in profile]
            B=[[0]*n for _ in profile]
            for i in range(n):
                for j in range(i+1,n):
                    c=rng.choice([-2,-1,1,2]);d=gcd(D[i],D[j]);B[i][j]=c*D[j]//d;B[j][i]=-c*D[i]//d
            g=tuple(rng.randint(-4,1)for _ in profile)
            cases.append((B,D,g,profile))
    for index,(B,D,g,p) in enumerate(cases):
        try:row=check_one(B,D,g,p,True,index<3 or index%8==0,index<2 or(index%8==3 and all(d == 1 for d in D)))
        except Exception as e:
            import traceback;row={'B':B,'D':D,'g':g,'p':p,'pass':False,'error':repr(e),'traceback':traceback.format_exc()}
        out.append(row)
        Path(__file__).with_suffix('.json').write_text(json.dumps({'elapsed':time.time()-start,'results':out},indent=2))
        print(json.dumps({'index':index,'p':p,'skeletons':row.get('skeletons'),'direct_seconds':row.get('direct_seconds'),'seconds':row.get('seconds'),'pass':row['pass'],'error':row.get('error')}),flush=True)
        if not row['pass']:break
    print(json.dumps({'inputs':len(out),'all_pass':all(r['pass']for r in out),'seconds':time.time()-start}),flush=True)


if __name__=='__main__':main()
