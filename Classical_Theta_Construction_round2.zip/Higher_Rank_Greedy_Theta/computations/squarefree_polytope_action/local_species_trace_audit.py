"""Exact local HN/PBW species traces, independently compared with fan IH.

The HN side uses only cycle-invariant ordered set partitions and the entire
thin representation-stack trace. The primitive side retains all invariant
unordered set partitions, including orbits of parallel blocks. No theta
coefficient is imported. Weight variable t is cohomological degree one.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import permutations, product
from pathlib import Path
import json
import sys
import time
import sympy as sp

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computations'/'natural_incoming_module'))
from equivariant_toric_ih import event_ih

t=sp.Symbol('t')
H=t/(1-t*t)


@lru_cache(None)
def set_partitions(items):
    if not items:
        return ((),)
    head,*tail=items
    answer=[]
    for partition in set_partitions(tuple(tail)):
        answer.append(((head,),)+partition)
        for i,block in enumerate(partition):
            answer.append(partition[:i]+((head,)+block,)+partition[i+1:])
    return tuple(answer)


def cycle_orbits(permutation):
    unseen=set(range(len(permutation)))
    answer=[]
    while unseen:
        i=min(unseen);cycle=[];j=i
        while j in unseen:
            unseen.remove(j);cycle.append(j);j=permutation[j]
        assert j==i
        answer.append(tuple(cycle))
    return tuple(answer)


def restrict(eta,permutation,block,power=1):
    block=tuple(sorted(block));index={a:i for i,a in enumerate(block)}
    def image(a):
        for _ in range(power):a=permutation[a]
        return a
    assert all(image(a) in index for a in block)
    return (tuple(tuple(eta[a][b] for b in block) for a in block),
            tuple(index[image(a)] for a in block))


def arrow_count(eta,block=None):
    if block is None:block=range(len(eta))
    return sum(abs(eta[a][b]) for a in block for b in block if a<b)


@lru_cache(None)
def semistable_trace(eta,permutation,theta,kappa):
    """HN recursion at the slope of the entire thin component."""
    n=len(eta)
    if not n:return sp.Integer(1)
    cycles=cycle_orbits(permutation)
    total=t**(n-arrow_count(eta))
    for orbit in cycles:total/=1-t**(2*len(orbit))
    correction=0
    # A fixed ordered HN partition consists of unions of whole sigma cycles.
    for cycle_partition in set_partitions(tuple(range(len(cycles)))):
        if len(cycle_partition)<2:continue
        blocks=[tuple(sorted(a for c in C for a in cycles[c])) for C in cycle_partition]
        slopes=[sp.Rational(sum(theta[a] for a in B),sum(kappa[a] for a in B)) for B in blocks]
        if len(set(slopes))!=len(slopes):continue
        blocks=[B for _,B in sorted(zip(slopes,blocks),reverse=True)]
        weight=1
        for B in blocks:
            restricted_eta,restricted_permutation=restrict(eta,permutation,B)
            weight*=semistable_trace(restricted_eta,restricted_permutation,tuple(theta[a] for a in B),tuple(kappa[a] for a in B))
            if weight==0:break
        if weight==0:continue
        twist=sum(eta[a][b] for i,A in enumerate(blocks) for B in blocks[i+1:] for a in A for b in B)
        correction+=t**twist*weight
    return sp.cancel(total-correction)


@lru_cache(None)
def primitive_trace(eta,permutation,kappa=None):
    """Plethystic primitive extraction via every invariant block partition."""
    n=len(eta)
    if n==1:return sp.Integer(1)
    if kappa is None:kappa=(1,)*n
    # This is anti-attractor for eta<0 oriented arrows and positive submodule
    # stability. It is the incidence flow * ones convention of event_ih.
    theta=tuple(-sum(eta[a][b] for a in range(n)) for b in range(n))
    ss=semistable_trace(eta,permutation,theta,kappa)
    correction=0
    for partition in set_partitions(tuple(range(n))):
        if len(partition)<2:continue
        if any(sum(theta[a] for a in C)!=0 for C in partition):continue
        blocks={frozenset(C) for C in partition}
        image=lambda C:frozenset(permutation[a] for a in C)
        if {image(C) for C in blocks}!=blocks:continue
        unseen=set(blocks);weight=sp.Integer(1)
        while unseen:
            C=min(unseen,key=lambda x:(len(x),tuple(sorted(x))))
            D=C;k=0
            while True:
                unseen.remove(D);k+=1;D=image(D)
                if D==C:break
            restricted_eta,return_permutation=restrict(eta,permutation,C,k)
            omega=primitive_trace(restricted_eta,return_permutation,tuple(kappa[a] for a in sorted(C)))
            if omega==0:weight=0;break
            weight*=(-1)**((k-1)*arrow_count(eta,C))
            weight*=(H*omega).subs(t,t**k)
        correction+=weight
    return sp.cancel((ss-correction)/H)


def eta_from_types(types,multiplicity=1):
    # Sign chosen to order beta=(1,0),(1,1),(0,1) as an acyclic source-to-sink list.
    return tuple(tuple(-multiplicity*(a[0]*b[1]-a[1]*b[0]) for b in types) for a in types)


def main():
    started=time.time();rows=[]
    previous_path=Path(__file__).with_name('local_species_trace_audit_uniform_slope.json')
    previous={}
    if previous_path.exists():
        previous={(r['name'],tuple(r['permutation'])):r for r in json.loads(previous_path.read_text())['results']}
    cases=[]
    # The K22 family detects the multicover/parallel-block subtraction sign.
    for r in (1,2,3):
        types=((1,0),)*2+((0,1),)*2
        for perm in ((0,1,2,3),(1,0,2,3),(1,0,3,2)):
            cases.append((f'K22_{r}',types,perm,r))
    # beta3=beta1+beta2 is a proper input parallel to the total root. These
    # cases retain different input-type contents on the same outgoing ray.
    for counts in ((1,1,2),(2,2,1)):
        types=((1,0),)*counts[0]+((0,1),)*counts[1]+((1,1),)*counts[2]
        groups=[];base=0
        for size in counts:
            groups.append(tuple(range(base,base+size)));base+=size
        for local_perms in product(*(tuple(permutations(G)) for G in groups)):
            perm=tuple(a for G in local_perms for a in G)
            cases.append((f'parallel_type_{counts}',types,perm,1))
    for name,types,perm,r in cases:
        eta=eta_from_types(types,r)
        omega=primitive_trace(eta,perm)
        weighted_omega=primitive_trace(eta,perm,tuple(sum(beta) for beta in types))
        if (name,perm) in previous:
            cached=previous[(name,perm)]
            normalized=sp.sympify(cached['normalized_fan_IH'])
            fan={'dimension':cached['dimension'],'graded_traces':[cached['trace_at_one']]}
        else:
            fan=event_ih(eta,perm)
            poly=sum(c*t**(2*i) for i,c in enumerate(fan['graded_traces']))
            normalized=t**(-fan['dimension'])*poly
        residual=sp.cancel(omega-normalized)
        weighted_residual=sp.cancel(weighted_omega-normalized)
        row={'name':name,'types':types,'permutation':perm,'arrows':arrow_count(eta),
             'dimension':fan['dimension'],'HN_PBW_primitive':str(omega),
             'normalized_fan_IH':str(sp.expand(normalized)),
             'charge_linear_mass_primitive':str(weighted_omega),
             'difference':str(residual),'charge_linear_mass_difference':str(weighted_residual),
             'trace_at_one':sum(fan['graded_traces']),
             'agrees':residual==0 and weighted_residual==0}
        rows.append(row)
        print(json.dumps(row),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps({'seconds':time.time()-started,'results':rows,'all_pass':all(x['agrees'] for x in rows)},indent=2))
        if residual!=0 or weighted_residual!=0:raise AssertionError(row)
    print(json.dumps({'seconds':time.time()-started,'cases':len(rows),'all_pass':all(x['agrees'] for x in rows)}),flush=True)


if __name__=='__main__':main()
