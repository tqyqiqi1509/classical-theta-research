from flow_box_holonomy import *
from itertools import permutations

def clone_input(B,g,p):
 colors=[-1]+[i for i,num in enumerate(p)for j in range(num)]
 eta=[[0]*len(colors)for _ in colors]
 for a,i in enumerate(colors):
  for b,j in enumerate(colors):
   if i==-1 and j>=0:eta[a][b]=g[j]
   elif j==-1 and i>=0:eta[a][b]=-g[i]
   elif i>=0 and j>=0:eta[a][b]=-B[i][j]
 return eta,colors

def relabel(P,perm):
 T,dec=P
 def trans(T):return perm[T]if isinstance(T,int)else canon(tuple(trans(t)for t in T))
 def smask(m):return sum(1<<perm[i]for i in range(len(perm))if(m>>i)&1)
 return trans(T),tuple(sorted((smask(m),v)for m,v in dec))

def permtheta(theta,perm):
 out=[0]*len(theta)
 for i,j in enumerate(perm):out[j]=theta[i]
 return tuple(out)

def swapper(f,theta,i,j,seed=0):
 perm=list(range(f.n));perm[i],perm[j]=perm[j],perm[i]
 start=permtheta(theta,perm)
 try:E=f.events(start,theta);paths=[E]
 except RuntimeError:
  rng=random.Random(seed)
  for attempt in range(30):
   eps=F(1,10**8)*(attempt+1)
   mid=[(a+b)/2+eps*rng.randint(-100,100)for a,b in zip(start,theta)]
   mid[0]=-sum(mid[1:]);mid=tuple(mid)
   try:paths=[f.events(start,mid),f.events(mid,theta)];break
   except RuntimeError:continue
  else:raise RuntimeError('no generic waypoint')
 def act(P):
  P=relabel(P,perm)
  for E in paths:P=f.transport_point(P,E)
  return P
 return act,[len(e)for e in paths]

def run_case(B,g,p):
 eta,colors=clone_input(B,g,p);f=FlowBoxes(eta);n=f.n
 rng=random.Random(3401)
 base=[F(13**i,7**i)for i in range(len(B))]
 # all values positive and only tiny distinct atom perturbations
 v=[base[c]+F(rng.randint(1,1000),10**7)for c in colors[1:]];theta=tuple([-sum(v)]+v)
 pts=f.points(theta);gens=[];records=[]
 for c in range(len(B)):
  ids=[i for i,k in enumerate(colors)if k==c]
  for i,j in zip(ids,ids[1:]):
   act,steps=swapper(f,theta,i,j);output=tuple(act(P)for P in pts)
   if set(output)!=set(pts):raise AssertionError(('not permutation',i,j))
   index={P:a for a,P in enumerate(pts)};perm=[index[P]for P in output]
   gens.append((c,i,j,perm));records.append({'color':c,'swap':(i,j),'events':steps,'fixed':sum(a==v for a,v in enumerate(perm)),'involution':all(perm[perm[a]]==a for a in range(len(pts)))})
 relations=[]
 for k,(c,i,j,s)in enumerate(gens):
  for l,(d,u,v,t)in enumerate(gens[k+1:],k+1):
   if c==d and j==u:
    fails=[a for a in range(len(pts))if s[t[s[a]]]!=t[s[t[a]]]];name='braid'
   else:
    fails=[a for a in range(len(pts))if s[t[a]]!=t[s[a]]];name='commute'
   relations.append({'k':k,'l':l,'name':name,'failures':len(fails),'example':fails[:1]})
 return {'B':B,'g':g,'p':p,'eta':eta,'theta':theta,'points':len(pts),'generators':records,'relations':relations}

def main():
 cases=[([[0]],[-2],[3]),([[0,2],[-2,0]],[-1,-1],[3,1]),([[0,2],[-2,0]],[-2,1],[3,1]),([[0,2,-2],[-2,0,2],[2,-2,0]],[-1,-1,-1],[2,1,1]),([[0,2,-2],[-2,0,2],[2,-2,0]],[-1,-1,-1],[2,2,1]),([[0,2,-3],[-2,0,2],[3,-2,0]],[-3,3,-2],[2,2,1])]
 out=[];start=time.time()
 for B,g,p in cases:
  try:r=run_case(B,g,p)
  except Exception as e:r={'B':B,'g':g,'p':p,'error':repr(e)}
  out.append(r);print(json.dumps(plain(r)),flush=True)
 Path(__file__).with_suffix('.json').write_text(json.dumps(plain({'seconds':time.time()-start,'results':out}),indent=2))
if __name__=='__main__':main()
