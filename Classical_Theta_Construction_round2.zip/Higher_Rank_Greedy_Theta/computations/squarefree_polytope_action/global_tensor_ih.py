"""Global clone characters from simultaneous skeletons and local toric IH.

Input only skew-symmetric B,g,p. A theta oracle is used only for the final independent
comparison. Tensor factors in a node orbit are cyclically permuted; their
trace is the trace of the return permutation on one local IH module.
"""
from pathlib import Path
import sys,json,time,random
from itertools import combinations,product
from functools import lru_cache
from collections import defaultdict
from math import prod

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'agents'))
sys.path.insert(0,str(ROOT/'computations'/'simultaneous_packet_vertices'))
sys.path.insert(0,str(ROOT/'computations'/'natural_incoming_module'))
from zero_flow_contraction import check,all_leaves,permute
from equivariant_toric_ih import event_ih
from incoming_recursion import IncomingSchur

@lru_cache(None)
def partitions(n,min_part=1):
 if n==0:return ((),)
 return tuple((k,)+tail for k in range(min_part,n+1)for tail in partitions(n-k,k))
def cycles(perm):
 seen=set();out=[]
 for i in range(len(perm)):
  if i in seen:continue
  orb=[];j=i
  while j not in seen:seen.add(j);orb.append(j);j=perm[j]
  out.append(tuple(orb))
 return out

def tree_nodes(K):
 if isinstance(K,int):return {}
 out={frozenset(all_leaves(K)):K}
 for C in K:out.update(tree_nodes(C))
 return out

def eta_from_input(B,g,p):
 colors=[-1]+[i for i,k in enumerate(p)for _ in range(k)]
 n=len(colors);eta=[[0]*n for _ in colors]
 for u,i in enumerate(colors):
  for v,j in enumerate(colors):
   if i==-1 and j>=0:eta[u][v]=g[j]
   elif j==-1 and i>=0:eta[u][v]=-g[i]
   elif i>=0 and j>=0:eta[u][v]=-B[i][j]
 return tuple(map(tuple,eta)),colors

def simple_trees(eta):
 n=len(eta);edges=[(i,j,abs(eta[i][j]))for i in range(n)for j in range(i+1,n)if eta[i][j]]
 for inds in combinations(range(len(edges)),n-1):
  parent=list(range(n))
  def root(i):
   while parent[i]!=i:i=parent[i]
   return i
  okay=True
  for k in inds:
   i,j,w=edges[k];ri,rj=root(i),root(j)
   if ri==rj:okay=False;break
   parent[ri]=rj
  if okay:yield tuple(edges[k]for k in inds)

@lru_cache(None)
def generic_tree_dimension(eta):
 """Number of vertices after generic anti-attractor stability deformation."""
 n=len(eta);theta=[sum(eta[i])for i in range(n)]
 delta=[2**i for i in range(n-1)];delta.append(-sum(delta))
 total=0
 for E in simple_trees(eta):
  adj=[[]for _ in range(n)]
  for i,j,w in E:adj[i].append(j);adj[j].append(i)
  good=True
  for i,j,w in E:
   # Remove edge and take i-side. For eta[i,j]<0 arrow goes i->j,
   # so sum theta on that side is negative for positive flow.
   seen={i};stack=[i]
   while stack:
    u=stack.pop()
    for v in adj[u]:
     if (u==i and v==j)or(u==j and v==i)or v in seen:continue
     seen.add(v);stack.append(v)
   h=sum(theta[u]for u in seen);d=sum(delta[u]for u in seen)
   sign=1 if h>0 or(h==0 and d>0)else -1
   if sign!=(1 if eta[i][j]>0 else -1):good=False;break
  if good:total+=prod(w for _,_,w in E)
 return total

LOCAL_CALLS=defaultdict(int)
@lru_cache(None)
def local_trace(eta,permutation):
 n=len(eta);ident=tuple(range(n))
 # Stars are products of projective spaces with a literal tensor action.
 for hub in range(n):
  if all(eta[hub][i]for i in range(n)if i!=hub)and all(not eta[i][j]for i in range(n)for j in range(n)if i!=hub and j!=hub):
   if permutation[hub]!=hub:continue
   ans=1
   for orb in cycles(permutation):
    if hub in orb:continue
    ans*=abs(eta[hub][orb[0]])
   LOCAL_CALLS['star']+=1;return ans
 if permutation==ident:
  LOCAL_CALLS['generic_tree_dimension']+=1
  return generic_tree_dimension(eta)
 # The independently derived full K22,m character is a safe fast path.
 if n==4:
  groups=[]
  for i in range(n):
   G=tuple(j for j in range(n)if eta[i][j]==0)
   if G not in groups:groups.append(G)
  if len(groups)==2 and all(len(G)==2 for G in groups)and set(groups[0]).isdisjoint(groups[1]):
   mags={abs(eta[i][j])for i in groups[0]for j in groups[1]}
   if len(mags)==1 and all(permutation[i]in G for G in groups for i in G):
    m=mags.pop();swaps=sum(permutation[G[0]]!=G[0]for G in groups)
    LOCAL_CALLS['K22_family']+=1
    return 2*m*m if swaps==1 else 2*m*(m%2)
 LOCAL_CALLS['general_fan']+=1
 result=event_ih(eta,permutation)
 return result['trace_total']

def trace_skeleton(K,eta,permutation):
 mapping=dict(enumerate(permutation))
 if permute(K,mapping)!=K:return 0
 ns=tree_nodes(K);unseen=set(ns);answer=1
 def image(S):return frozenset(permutation[i]for i in S)
 while unseen:
  S=min(unseen,key=lambda x:(len(x),tuple(sorted(x))));T=S;length=0
  while True:
   unseen.remove(T);length+=1;T=image(T)
   if T==S:break
  children=ns[S];cs=[frozenset(all_leaves(C))for C in children]
  def return_image(C):
   for _ in range(length):C=image(C)
   return C
  cp=tuple(cs.index(return_image(C))for C in cs)
  ep=tuple(tuple(sum(eta[i][j]for i in A for j in B)for B in cs)for A in cs)
  # Effective parity after the tau-twisted Hall symmetry: arrow-count parity.
  parity=sum(abs(ep[i][j]) for i in range(len(ep)) for j in range(i+1,len(ep)))%2
  answer*=(-1)**((length-1)*parity)*local_trace(ep,cp)
  if not answer:break
 return answer

def representative(p,parts):
 n=1+sum(p);perm=list(range(n));base=1
 for size,pp in zip(p,parts):
  for k in pp:
   for j in range(k):perm[base+j]=base+(j+1)%k
   base+=k
 return tuple(perm)

def weighted_theta(B,g,parts):
 tags=[(i,k)for i,ps in enumerate(parts)for k in ps]
 if not tags:return 1
 C=[[l*B[i][j]for j,l in tags]for i,k in tags];D=[k for i,k in tags];gg=tuple(g[i]for i,k in tags);ones=(1,)*len(tags)
 return IncomingSchur(C,D).theta_prefix(gg,ones).get(ones,0)

def one_case(B,g,p,details=False):
 start=time.time();original=(B,g,p)
 if any(B[i][j]!=-B[j][i] for i in range(len(B)) for j in range(len(B))):
  raise ValueError('This natural toric-IH assembler currently requires skew-symmetric B; valued extension is not implemented.')
 support=[i for i,k in enumerate(p) if k]
 if len(support)<len(p):
  B=[[B[i][j] for j in support] for i in support];g=tuple(g[i] for i in support);p=tuple(p[i] for i in support)
 eta,colors=eta_from_input(B,g,p)
 collapse=check(B,[1]*len(B),g,p,detail=True)
 skeletons=[s['tree']for s in collapse['skeletons']]
 dimfails=[]
 for row in collapse['skeletons']:
  dimension=trace_skeleton(row['tree'],eta,tuple(range(len(eta))))
  if dimension!=row['raw_weight']:dimfails.append({'skeleton':row['tree'],'IH_dimension':dimension,'flow_dimension':row['raw_weight']})
 records=[]
 for parts in product(*(partitions(k)for k in p)):
  sigma=representative(p,parts);contrib=[trace_skeleton(K,eta,sigma)for K in skeletons];observed=sum(contrib);target=weighted_theta(B,g,parts)
  rec={'cycle_type':parts,'trace':observed,'weighted_cycle_theta':target,'agrees':observed==target}
  if details:rec['skeleton_contributions']=contrib
  records.append(rec)
 return {'B':B,'g':g,'p':p,'seconds':time.time()-start,'skeletons':len(skeletons),'binary_refinements':collapse['positive_binary_trees'],'raw_dimension':collapse['raw_weight'],'dimension_failures':dimfails,'cycle_characters':records,'all_pass':not dimfails and all(r['agrees']for r in records)}

def main():
 start=time.time();rng=random.Random(713031);out=[]
 cases=[([[0,2,-3],[-2,0,2],[3,-2,0]],(-3,3,-2),(2,2,1)),([[0,2,-2],[-2,0,2],[2,-2,0]],(-1,-1,-1),(2,2,1)),([[0,1,-1],[-1,0,1],[1,-1,0]],(-1,-1,-1),(3,2,1))]
 for p in ((2,2,1),(3,1,1),(2,1,1,1),(2,2,1,0),(2,2,2)):
  for trial in range(12):
   n=len(p);B=[[0]*n for _ in p]
   for i in range(n):
    for j in range(i+1,n):B[i][j]=rng.randint(-2,2);B[j][i]=-B[i][j]
   g=tuple(rng.randint(-3,2)for _ in p)
   cases.append((B,g,p))
 for index,(B,g,p)in enumerate(cases):
  try:r=one_case(B,g,p,index<3)
  except Exception as e:
   r={'B':B,'g':g,'p':p,'error':repr(e),'all_pass':False}
   import traceback;r['traceback']=traceback.format_exc()
  out.append(r)
  report={'index':index,'p':p,'seconds':r.get('seconds'),'skeletons':r.get('skeletons'),'checks':len(r.get('cycle_characters',[])),'pass':r['all_pass'],'error':r.get('error')}
  print(json.dumps(report),flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps({'seconds':time.time()-start,'local_calls':dict(LOCAL_CALLS),'results':out},indent=2))
  if not r['all_pass']:break
 print(json.dumps({'total_seconds':time.time()-start,'inputs':len(out),'all_pass':all(r['all_pass']for r in out),'local_calls':dict(LOCAL_CALLS)}),flush=True)
if __name__=='__main__':main()
