"""Exact chamber transport using the integer rectangle Ptolemy bijection.
No theta coefficient enters construction. Trees carry boxes of skew pairings.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from collections import defaultdict
from pathlib import Path
import random,json,time,sys

@lru_cache(None)
def mask(T):
 if isinstance(T,int):return 1<<T
 return sum(mask(t)for t in T)
def canon(ts):return tuple(sorted(ts,key=lambda T:(mask(T)&-mask(T))))
@lru_cache(None)
def trees(S):
 if S&(S-1)==0:return (S.bit_length()-1,)
 out=[];first=S&-S;L=(S-1)&S
 while L:
  R=S^L
  if R and L&first:
   for A in trees(L):
    for B in trees(R):out.append(canon((A,B)))
  L=(L-1)&S
 return tuple(out)
def nodes(T,path=()):
 if isinstance(T,int):return []
 return [(path,T)]+nodes(T[0],path+(0,))+nodes(T[1],path+(1,))
def get(T,path):
 for i in path:T=T[i]
 return T
def replace(T,path,new):
 if not path:return new
 ts=list(T);ts[path[0]]=replace(ts[path[0]],path[1:],new);return canon(ts)

def dot(x,S):return sum(x[i]for i in range(len(x))if (S>>i)&1)

class FlowBoxes:
 def __init__(self,eta):
  self.eta=eta;self.n=len(eta);self.full=(1<<self.n)-1
  self.pair=lru_cache(None)(lambda S,T:sum(eta[i][j]for i in range(self.n)for j in range(self.n)if (S>>i)&1 and (T>>j)&1))
  self.T=tuple(T for T in trees(self.full) if all(self.pair(mask(N[0]),mask(N[1])) for _,N in nodes(T)))
 def forms(self,T,theta):
  out={}
  def rec(T,th,path):
   if isinstance(T,int):return
   L,R=map(mask,T);S=L|R;a=self.pair(L,R);h=dot(th,L)
   out[path]=(h,a)
   th2=tuple(th[i]+h*F(self.pair(S,1<<i),a)for i in range(self.n))
   rec(T[0],th2,path+(0,));rec(T[1],th2,path+(1,))
  rec(T,tuple(map(F,theta)),())
  return out
 def stable(self,T,theta):return all(h*a>0 for h,a in self.forms(T,theta).values())
 def points(self,theta):
  out=[]
  for T in self.T:
   if not self.stable(T,theta):continue
   ns=nodes(T);dims=[abs(self.pair(mask(N[0]),mask(N[1])))for _,N in ns]
   for vals in product(*(range(k)for k in dims)):
    out.append((T,tuple(sorted((mask(N),v)for (_,N),v in zip(ns,vals)))))
  return tuple(out)
 def events(self,start,end):
  fs={T:self.forms(T,start)for T in self.T};fe={T:self.forms(T,end)for T in self.T};times=set()
  for T in self.T:
   for p,(h,a) in fs[T].items():
    delta=fe[T][p][0]-h
    if delta:
     t=-h/delta
     if 0<t<1:times.add(t)
  intervals={};event_sides=defaultdict(lambda:[set(),set()])
  for T in self.T:
   low=F(0);high=F(1);possible=True
   for path,(h,a) in fs[T].items():
    v=h*a;delta=(fe[T][path][0]-h)*a
    if not delta:
     if v<=0:possible=False;break
    elif delta>0:low=max(low,-v/delta)
    else:high=min(high,-v/delta)
   if possible and low<high:
    intervals[T]=(low,high)
    if 0<low<1:event_sides[low][1].add(T)
    if 0<high<1:event_sides[high][0].add(T)
  events=[]
  for t,(gone,new) in sorted(event_sides.items()):
   def th(u):return tuple((1-u)*a+u*b for a,b in zip(start,end))
   groups=defaultdict(lambda:[[],[]]);at=th(t)
   for side,TT in enumerate((gone,new)):
    for T in TT:
     zeros=[p for p,(h,a) in self.forms(T,at).items()if h==0]
     if len(zeros)!=1 or not zeros[0]:raise RuntimeError(('non-simple transition',t,T,zeros))
     p=zeros[0];parentp=p[:-1];parent=get(T,parentp);child=get(T,p);sib=parent[1-p[-1]]
     children=canon((*child,sib));skel=replace(T,parentp,children)
     groups[skel][side].append((T,parentp,children))
   transitions={}
   for skel,(old,new_) in groups.items():
    if not old or not new_:raise RuntimeError(('one-sided',t,skel,old,new_))
    branch=old[0][2];A,B,C=map(mask,branch);a=self.pair(A,B);b=self.pair(B,C);c=self.pair(C,A)
    values=(0,a,b,c);order=sorted(range(4),key=lambda i:(values[i],i));ranks={i:j for j,i in enumerate(order)}
    endpoints=[values[i]for i in order];info={}
    for T,p,children in old+new_:
     local=get(T,p);U,V=local
     joined=U if not any(U==x for x in children)else V
     pairmask=mask(joined);S=A|B|C
     if pairmask==A|B:ids=((0,1),(2,3))
     elif pairmask==B|C:ids=((0,2),(3,1))
     elif pairmask==C|A:ids=((0,3),(1,2))
     else:raise AssertionError((joined,children))
     ranked=tuple(tuple(sorted(ranks[i]for i in pair))for pair in ids)
     intervals=tuple(tuple(sorted(values[i]for i in pair))for pair in ids)
     swap=ranked[0][0]>ranked[1][0]
     canonical=ranked[::-1]if swap else ranked
     t0,t1,t2,t3=endpoints
     if canonical==((0,2),(1,3)):typ='big'
     elif canonical==((0,1),(2,3)):typ='caps'
     elif canonical==((0,3),(1,2)):typ='wide'
     else:raise AssertionError(canonical)
     info[T]={'pairmask':pairmask,'topmask':S,'intervals':intervals,'swap':swap,'type':typ}
    oldT={t for t,_,_ in old};newT={t for t,_,_ in new_};target_by_type={info[t]['type']:t for t in newT}
    for T in oldT:transitions[T]=(info[T],target_by_type,info,endpoints)
   events.append((t,transitions))
  return events
 def transport_point(self,point,events):
  T,dec=point;dec=dict(dec)
  for time,trans in events:
   if T not in trans:continue
   source,targets,info,(t0,t1,t2,t3)=trans[T]
   x=source['intervals'][0][0]+dec[source['pairmask']]
   y=source['intervals'][1][0]+dec[source['topmask']]
   if source['swap']:x,y=y,x
   if source['type']=='big':
    if x<t1 and y>=t2:typ='caps'
    else:
     typ='wide'
     if y>=t2:x,y=y,x
   else:
    typ='big'
    if source['type']=='wide' and x>=t2:x,y=y,x
   target=targets[typ];dest=info[target]
   if dest['swap']:x,y=y,x
   dec.pop(source['pairmask']);dec.pop(source['topmask'])
   dec[dest['pairmask']]=x-dest['intervals'][0][0]
   dec[dest['topmask']]=y-dest['intervals'][1][0]
   T=target
  return T,tuple(sorted(dec.items()))

def randtheta(rng,n):
 v=[F(rng.randrange(1,100),rng.randrange(1,20))for _ in range(n-1)]
 return tuple([-sum(v)]+v)
def plain(v):
 if isinstance(v,F):return str(v)
 if isinstance(v,dict):return {str(k):plain(w)for k,w in v.items()}
 if isinstance(v,(list,tuple)):return [plain(w)for w in v]
 return v

def run():
 rng=random.Random(456791);reports=[];start=time.time();skip=0;success=0
 for rank2 in (True,False):
  for n in (4,5):
   for trial in range(30):
    if rank2:
     vec=[(rng.randint(-3,3),rng.randint(-3,3))for _ in range(n)]
     eta=[[a*d-b*c for c,d in vec]for a,b in vec]
    else:
     eta=[[0]*n for _ in range(n)]
     for i in range(n):
      for j in range(i+1,n):eta[i][j]=rng.randint(-4,4);eta[j][i]=-eta[i][j]
    f=FlowBoxes(eta);thetas=[randtheta(rng,n)for _ in range(3)];thetas.append(thetas[0])
    try:
     events=[f.events(thetas[i],thetas[i+1])for i in range(3)]
     pts=f.points(thetas[0]);p=pts
     for E in events:
      p=tuple(f.transport_point(q,E)for q in p)
     if len(set(p))!=len(p):raise AssertionError('not injective')
     moved=[(q,r)for q,r in zip(pts,p)if q!=r]
     success+=1
     record={'rank2':rank2,'n':n,'trial':trial,'eta':eta,'thetas':thetas[:-1],'points':len(pts),'events':[len(e)for e in events],'moved':len(moved),'example':moved[:1]}
     reports.append(record)
     print(json.dumps(plain({k:record[k]for k in ('rank2','n','trial','points','events','moved')})),flush=True)
     if moved:break
    except RuntimeError as e:skip+=1
 print(json.dumps({'seconds':time.time()-start,'success':success,'skip':skip},indent=2))
 Path(__file__).with_suffix('.json').write_text(json.dumps(plain({'seconds':time.time()-start,'success':success,'skip':skip,'reports':reports}),indent=2))
if __name__=='__main__':run()
