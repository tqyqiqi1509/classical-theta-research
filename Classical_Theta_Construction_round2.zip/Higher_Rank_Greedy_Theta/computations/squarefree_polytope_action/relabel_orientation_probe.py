from clone_ptolemy_probe import *

def relabel_mode(P,perm,f,mode):
 T,dec=P;dec=dict(dec);newdec={}
 def smask(m):return sum(1<<perm[i]for i in range(len(perm))if(m>>i)&1)
 def trans(T):
  if isinstance(T,int):return perm[T]
  A,B=T;left,right=trans(A),trans(B);S=mask(T);v=dec[S]
  if (mask(left)&-mask(left))>(mask(right)&-mask(right)):
   bound=abs(f.pair(mask(A),mask(B)))
   if mode=='reverse':v=bound-1-v
   elif mode=='negate':v=(-v)%bound
  newdec[smask(S)]=v
  return canon((left,right))
 TT=trans(T);return TT,tuple(sorted(newdec.items()))

def run(B,g,p):
 eta,colors=clone_input(B,g,p);f=FlowBoxes(eta);rng=random.Random(3401);base=[F(13**i,7**i)for i in range(len(B))]
 v=[base[c]+F(rng.randint(1,1000),10**7)for c in colors[1:]];theta=tuple([-sum(v)]+v);pts=f.points(theta);index={P:i for i,P in enumerate(pts)}
 data={}
 for mode in ('identity','reverse','negate'):
  gens=[];recs=[]
  for c in range(len(B)):
   ids=[i for i,k in enumerate(colors)if k==c]
   for i,j in zip(ids,ids[1:]):
    perm=list(range(f.n));perm[i],perm[j]=perm[j],perm[i];E=f.events(permtheta(theta,perm),theta)
    gen=[index[f.transport_point(relabel_mode(P,perm,f,mode),E)]for P in pts]
    gens.append((c,i,j,gen));recs.append({'color':c,'fixed':sum(i==j for i,j in enumerate(gen)),'square_fail':sum(gen[gen[i]]!=i for i in range(len(gen)))})
  relations=[]
  for k,(c,i,j,s)in enumerate(gens):
   for d,u,v,t in gens[k+1:]:
    if c==d and j==u:bad=sum(s[t[s[a]]]!=t[s[t[a]]]for a in range(len(pts)));name='braid'
    else:bad=sum(s[t[a]]!=t[s[a]]for a in range(len(pts)));name='commute'
    relations.append((name,bad))
  data[mode]={'generators':recs,'relations':relations}
 return {'B':B,'g':g,'p':p,'points':len(pts),'variants':data}
if __name__=='__main__':
 out=[]
 for B,g,p in [([[0]],[-2],[3]),([[0,2,-2],[-2,0,2],[2,-2,0]],[-1,-1,-1],[2,2,1]),([[0,2,-3],[-2,0,2],[3,-2,0]],[-3,3,-2],[2,2,1])]:
  r=run(B,g,p);out.append(r);print(json.dumps(r),flush=True)
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
