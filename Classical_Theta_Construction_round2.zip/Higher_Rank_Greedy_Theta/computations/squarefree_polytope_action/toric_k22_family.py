"""Independent toric-orbit IH character for the m-arrow K_(2,2) family.
The calculation uses the transportation polytope and local Segre-cone IH;
no theta coefficients or flow-tree counts are inputs.
"""
from pathlib import Path
import json
import sympy as s

t=s.symbols('t')
def geometric(m,z):return sum(z**k for k in range(m))
def character(m):
 G=geometric(m,t);G2=geometric(m,t*t);Gneg=geometric(m,-t)
 return tuple(s.expand(v)for v in (G**3*(1+t**m),(1+t)*G2**2,(1+t)*G2**2,(t-1)*G2**2+2*G2*Gneg))
def records(m):
 c=character(m)
 irreps=[s.expand(sum(signs[i]*c[i]for i in range(4))/4)for signs in ((1,1,1,1),(1,1,-1,-1),(1,-1,1,-1),(1,-1,-1,1))]
 assert all(all(v.is_Integer and v>=0 for v in s.Poly(pol,t).all_coeffs())for pol in irreps)
 return {'m':m,'graded_characters':[str(v)for v in c],'ungraded':[int(v.subs(t,1))for v in c], 'graded_irreducible_multiplicities':[str(v)for v in irreps]}

if __name__=='__main__':
 out={'local_family':[records(m)for m in range(1,13)],'global_hard_case':{'two_crossed_skeletons':[16,0,0,8],'core_skeleton':[64,32,32,0],'last_skeleton':[8,8,4,4],'sum':[88,40,36,12],'irreducible_multiplicities':[44,20,18,6]}}
 for i in range(4):assert sum(out['global_hard_case'][k][i]for k in ('two_crossed_skeletons','core_skeleton','last_skeleton'))==out['global_hard_case']['sum'][i]
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
 print(json.dumps({'families_checked':len(out['local_family']),'m2':out['local_family'][1],'global':out['global_hard_case']},indent=2))
