from itertools import permutations,product
from functools import lru_cache
from pathlib import Path
import sys,random,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'agents'))
from incoming_recursion import IncomingSchur

def maximal_boxes(B,g):
 n=len(B);r=[-v for v in g];boxes=set()
 for perm in permutations(range(n)):
  dims=[0]*n;done=[]
  for i in perm:
   cap=r[i]-sum(B[i][j]for j in done)
   if cap<=0:break
   dims[i]=cap;done.append(i)
  else:boxes.add(tuple(dims))
 # Remove coordinatewise dominated boxes
 return tuple(sorted(x for x in boxes if not any(x!=y and all(a<=b for a,b in zip(x,y))for y in boxes)))

@lru_cache(None)
def box_union_count(boxes):
 if not boxes:return 0
 if not boxes[0]:return 1
 vals=sorted(set([0]+[x[0]for x in boxes]));ans=0
 for low,high in zip(vals,vals[1:]):
  rest=set(x[1:]for x in boxes if x[0]>=high)
  rest=tuple(sorted(x for x in rest if not any(x!=y and all(a<=b for a,b in zip(x,y))for y in rest)))
  ans+=(high-low)*box_union_count(rest)
 return ans

def run():
 rng=random.Random(130421);out=[];start=time.time()
 for n in range(2,6):
  for t in range(200):
   D=[rng.choice([1,2,3])for _ in range(n)]
   from math import gcd
   B=[[0]*n for _ in range(n)]
   for i in range(n):
    for j in range(i+1,n):
     b=rng.randint(-3,3);d=gcd(D[i],D[j]);B[i][j]=b*D[j]//d;B[j][i]=-b*D[i]//d
   g=tuple(rng.randint(-3,2)for _ in range(n))
   actual=IncomingSchur(B,D).theta_prefix(g,(1,)*n).get((1,)*n,0)
   boxes=maximal_boxes(B,g);prediction=box_union_count(boxes)
   if prediction!=actual:
    out.append({'B':B,'D':D,'g':g,'theta':actual,'boxes':boxes,'box_count':prediction})
    if len(out)>=12:break
  print(n,'tested',t+1,'fails',len(out),flush=True)
  if len(out)>=12:break
 res={'seconds':time.time()-start,'counterexamples':out}
 Path(__file__).with_suffix('.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
if __name__=='__main__':run()
