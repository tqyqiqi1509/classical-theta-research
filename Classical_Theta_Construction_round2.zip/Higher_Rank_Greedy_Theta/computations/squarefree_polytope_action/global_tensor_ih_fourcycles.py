from global_tensor_ih import *
from fractions import Fraction
from math import factorial
from collections import Counter

def zpart(ps):
 return prod(k**m*factorial(m)for k,m in Counter(ps).items())

def main():
 cases=[([[0,1],[-1,0]],(-6,1),(4,2)),([[0,2],[-2,0]],(-12,1),(4,2)),([[0,2,-1],[-2,0,2],[1,-2,0]],(-3,1,-2),(4,1,1))]
 out=[];start=time.time()
 for B,g,p in cases:
  r=one_case(B,g,p,True)
  sign=sum((Fraction((-1)**(sum(p)-sum(len(x)for x in rec['cycle_type']))*rec['trace'],prod(zpart(ps)for ps in rec['cycle_type']))for rec in r['cycle_characters']),Fraction(0))
  direct=IncomingSchur(B).theta_prefix(g,p).get(p,0)
  r['sign_multiplicity']=str(sign);r['ordinary_theta']=direct;r['all_pass']=r['all_pass']and sign==direct
  out.append(r);print(json.dumps({'p':p,'seconds':r['seconds'],'skeletons':r['skeletons'],'cycles':len(r['cycle_characters']),'sign':str(sign),'theta':direct,'all_pass':r['all_pass'],'calls':dict(LOCAL_CALLS)}),flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps({'seconds':time.time()-start,'local_calls':dict(LOCAL_CALLS),'results':out},indent=2))
  if not r['all_pass']:break
if __name__=='__main__':main()
