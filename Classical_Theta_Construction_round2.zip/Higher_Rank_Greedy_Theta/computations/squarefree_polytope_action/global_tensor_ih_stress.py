from global_tensor_ih import *
import traceback

def main():
 rng=random.Random(71938);start=time.time();out=[]
 cases=[([[0,1],[-1,0]],(-4,2),(3,2)),([[0,1],[-1,0]],(-10,-1),(3,3)),([[0,2],[-2,0]],(-7,4),(3,2))]
 for p in ((2,2,1),(3,1,1),(2,1,1,1),(2,2,2),(3,2,1),(2,2,1,1)):
  for trial in range(8):
   n=len(p);B=[[0]*n for _ in p]
   for i in range(n):
    for j in range(i+1,n):B[i][j]=rng.randint(-2,2);B[j][i]=-B[i][j]
   g=[-rng.randint(1,4)for _ in p]
   if trial%4==0:g[rng.randrange(n)]=rng.randint(0,2)
   cases.append((B,tuple(g),p))
 for index,(B,g,p)in enumerate(cases):
  try:r=one_case(B,g,p,index<3)
  except Exception as e:r={'B':B,'g':g,'p':p,'all_pass':False,'error':repr(e),'traceback':traceback.format_exc()}
  out.append(r)
  print(json.dumps({'index':index,'p':p,'seconds':r.get('seconds'),'skeletons':r.get('skeletons'),'checks':len(r.get('cycle_characters',[])),'pass':r['all_pass'],'calls':dict(LOCAL_CALLS),'error':r.get('error')}),flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps({'seconds':time.time()-start,'local_calls':dict(LOCAL_CALLS),'results':out},indent=2))
  if not r['all_pass']:break
 print(json.dumps({'seconds':time.time()-start,'inputs':len(out),'cycle_types':sum(len(r.get('cycle_characters',[]))for r in out),'all_pass':all(r['all_pass']for r in out),'local_calls':dict(LOCAL_CALLS)}),flush=True)
if __name__=='__main__':main()
