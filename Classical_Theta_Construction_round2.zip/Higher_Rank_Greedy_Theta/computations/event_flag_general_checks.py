"""Root's independent matrix/phase/degree checks of the new positive grammar."""
from pathlib import Path
import sys,json,time,random,math
from valued_event_flag_grammar import EventFlags,extended_data,local_profiles
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agents'))
from incoming_recursion import IncomingSchur


def main():
    rng=random.Random(7131417)
    cases=[]
    for D in [(1,1),(1,2),(2,3),(1,1,1),(1,2,1),(1,2,3),
              (2,3,2),(1,1,1,1),(1,2,2,1)]:
        r=len(D)
        for repetition in range(8):
            C=[[0]*r for _ in range(r)]
            for i in range(r):
                for j in range(i+1,r):
                    C[i][j]=rng.choice([-1,0,1])*math.lcm(D[i],D[j])
                    C[j][i]=-C[i][j]
            if r>=3 and repetition%2==0:
                for i,j in [(0,1),(1,2),(2,0)]:
                    C[i][j]=math.lcm(D[i],D[j]);C[j][i]=-C[i][j]
            B=[[C[i][j]//D[i] for j in range(r)] for i in range(r)]
            g=tuple(-rng.randrange(1,4) if repetition%3 else rng.randrange(-3,3) for i in range(r))
            p=[1]*r
            if r<=3 and repetition%4==1:p[rng.randrange(r)]=2
            if repetition%4==3:p[rng.randrange(r)]=0
            cases.append((B,D,g,tuple(p)))
    results=[];start=time.monotonic();path=Path(__file__).with_suffix('.json')
    for j,(B,D,g,p) in enumerate(cases):
        t=time.monotonic();Bh,Dh=extended_data(B,D,g)
        R=EventFlags(Bh,Dh)
        actual=R.framed_theta(g,p)
        oracle=IncomingSchur(B,D).theta_prefix(g,p).get(p,0)
        row={'case':j,'B':B,'D':D,'g':g,'p':p,
             'dyck_event_count':actual,'independent_integer_count':oracle,
             'agrees':actual==oracle,'stats':dict(R.stats),
             'seconds':time.monotonic()-t}
        results.append(row)
        print(json.dumps(row),flush=True)
        data={'status':'RUNNING','results':results,'seconds':time.monotonic()-start}
        path.write_text(json.dumps(data,indent=2))
        assert actual==oracle,row
    data={'status':'PASS','cases':len(results),'results':results,
          'nonzero_cases':sum(x['dyck_event_count']>0 for x in results),
          'total_states':sum(x['stats'].get('states',0) for x in results),
          'total_exchanges':sum(x['stats'].get('word_exchanges',0) for x in results),
          'local_cache':str(local_profiles.cache_info()),
          'seconds':time.monotonic()-start}
    path.write_text(json.dumps(data,indent=2))
    print(json.dumps({k:v for k,v in data.items() if k!='results'}),flush=True)


if __name__=='__main__':main()
