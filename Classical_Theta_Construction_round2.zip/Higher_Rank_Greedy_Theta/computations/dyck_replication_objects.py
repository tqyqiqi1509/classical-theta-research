"""Actual Dyck multiplicities for the proved vertex-replication formula.

The defining counter is EventFlags (bounded tight gradings only).
IncomingSchur and FrozenChamber occur only in the independent checks.
"""
from itertools import product
from math import comb, lcm
from pathlib import Path
import json
import sys
import time

from valued_event_flag_grammar import EventFlags, extended_data


def positive_compositions(total, length):
    if length == 0:
        return [()] if total == 0 else []
    if length == 1:
        return [(total,)] if total > 0 else []
    return [(first,) + tail
            for first in range(1, total-length+2)
            for tail in positive_compositions(total-first, length-1)]


def dyck_count(B, D, g, p):
    Bhat, Dhat = extended_data(B, D, g)
    engine = EventFlags(Bhat, Dhat)
    count = engine.framed_theta(g, p)
    return count, dict(engine.stats)


def active_copy_multiplicities(B, D, g, p):
    result = []
    for k in product(*(range(1, v+1) if v else [0] for v in p)):
        original = [i for i, ki in enumerate(k) for _ in range(ki)]
        Bcopy = [[B[i][j] for j in original] for i in original]
        Dcopy = [D[i] for i in original]
        gcopy = tuple(g[i] for i in original)
        terms = []
        for blocks in product(*(positive_compositions(v, ki)
                                for v, ki in zip(p, k))):
            u = tuple(x for block in blocks for x in block)
            count, stats = dyck_count(Bcopy, Dcopy, gcopy, u)
            terms.append({'copy_degrees': u, 'actual_dyck_count': count,
                          'stats': stats})
        result.append({'active_copy_counts': k,
                       'multiplicity': sum(t['actual_dyck_count'] for t in terms),
                       'terms': terms})
    return result


def evaluate(multiplicities, r):
    total = 0
    for row in multiplicities:
        factor = row['multiplicity']
        for ri, ki in zip(r, row['active_copy_counts']):
            factor *= comb(ri, ki) if ri >= ki else 0
        total += factor
    return total


def main():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'agents'))
    from incoming_recursion import IncomingSchur
    t = time.monotonic()
    cases = [
        ('cyclic_skew', [[0,2,-2],[-2,0,2],[2,-2,0]], [1,1,1],
         (-1,-1,-1), (2,2,1)),
        ('cyclic_valued', [[0,2,-1],[-1,0,1],[1,-2,0]], [1,2,1],
         (-2,-1,1), (2,1,1)),
    ]
    output = []
    for name, B, D, g, p in cases:
        multiplicities = active_copy_multiplicities(B, D, g, p)
        checks = []
        for r in [(1,1,1), (1,2,1), (2,1,2), (2,3,1), (3,2,2)]:
            # D R^{-1}, cleared by one common positive scalar.
            common = lcm(*r)
            Br = [[r[i]*x for x in B[i]] for i in range(len(D))]
            Dr = [common*D[i]//r[i] for i in range(len(D))]
            gr = tuple(r[i]*g[i] for i in range(len(D)))
            actual = evaluate(multiplicities, r)
            independent = IncomingSchur(Br, Dr).theta_prefix(gr, p).get(p, 0)
            assert actual == independent, (name, r, actual, independent)
            checks.append({'replication': r, 'dyck_subset_count': actual,
                           'independent_integer_formula': independent})
        if name == 'cyclic_skew':
            assert [row['multiplicity'] for row in multiplicities] == [9,27,46,133]
        output.append({'name': name, 'B': B, 'D': D, 'g': g, 'p': p,
                       'multiplicities': multiplicities, 'checks': checks})
    report = {'status': 'PASS', 'seconds': time.monotonic()-t, 'results': output}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
