"""Full original-elementary profiles of the finite Dyck event grammar.

The positive construction retains independent e_j(X_i) symbols.  It is
compared to a signed incoming recursion, all weighted-cycle polarizations,
and already constructed actual global fan matrices.  No scalar sampling
is used to infer a polynomial identity.
"""
from collections import Counter
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import product
from math import gcd
from pathlib import Path
import json,sys,time

from valued_event_flag_grammar import EventFlags,box,add,scale,le,prim,sign,poly_mul,local_profiles,extended_data
from tight_grading_two_input import evaluate_profile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agents'))
from replication_independent_compute import (EPoly,GeneralizedSchur,partitions,
    cycle_model,epower_to_power,zpart)


class FormalEventFlags(EventFlags):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.nonprimitive_records=set()

    def symbol(self,color,k):
        mon=[()]*self.r;mon[color]=(k,)
        return EPoly({tuple(mon):1},self.r)

    def two_inputs(self,A,B,S):
        a,F,aid,aborn=A;b,G,bid,bborn=B
        K=self.pair(a,b);assert K>0
        acap=min(S[i]//a[i] for i in range(self.r) if a[i])
        bcap=min(S[i]//b[i] for i in range(self.r) if b[i])
        outputs=[]
        for u in range(1,acap+1):
            for v in range(1,bcap+1):
                if gcd(u,v)>1:continue
                gamma=add(scale(u,a),scale(v,b))
                if not le(gamma,S):continue
                ncap=min(S[i]//gamma[i] for i in range(self.r) if gamma[i])
                H={}
                for n in range(1,ncap+1):
                    profile=local_profiles(K,self.weight(a),self.weight(b),
                                           self.weight(gamma),u,v,n)
                    h=evaluate_profile(profile,F,G)
                    if not h:continue
                    assert all(c>0 for c in h.t.values())
                    H[n]=h
                if H:
                    newid=(aid,bid,u,v)
                    outputs.append((gamma,H,newid,True))
                    self.stats['born_factors']+=1
                    if gcd(*gamma)>1:
                        self.stats['nonprimitive_births']+=1
                        self.nonprimitive_records.add((a,b,u,v,gamma,K,
                                                       self.weight(a),self.weight(b),
                                                       self.weight(gamma)))
        outputs.sort(key=cmp_to_key(lambda A,B:sign(self.pair(A[0],B[0]))))
        return outputs

    def sort_word(self,inputs,S):
        inherited={prim(a) for a,F in inputs if F}
        final=super().sort_word(inputs,S)
        self.stats['born_on_inherited_parallel_ray']+=sum(
            born and prim(a) in inherited for a,F,tag,born in final)
        return final

    def _count(self,S,theta):
        self.stats['states']+=1
        assert not any(self.evaluate_covector(theta,S))
        rho=prim(S);cap=gcd(*S)
        axis=sum(x!=0 for x in rho)==1
        answer={0:1}
        if axis:
            color=next(i for i,x in enumerate(rho) if x)
            answer.update({j:self.symbol(color,j) for j in range(1,cap+1)})
        for key,b,tau,q in self.events(S,theta):
            self.stats['events']+=1
            rays={}
            for T in box(S):
                if not any(T) or T==S or not self.in_plane(T,S,b):continue
                rhoT=prim(T)
                incoming=self.incoming_theta(q,rhoT)
                c=self.count(T,incoming)
                if c:rays.setdefault(rhoT,{})[gcd(*T)]=c
            factor=self.born_ray(sorted(rays.items()),S)
            answer=poly_mul(answer,factor,cap)
        value=answer.get(cap,EPoly.scalar(0,self.r))
        assert isinstance(value,EPoly)
        return value


def remove_frame(F):
    terms={}
    for mon,c in F.t.items():
        assert mon[0]==(1,)
        terms[mon[1:]]=terms.get(mon[1:],0)+c
    return EPoly(terms,F.n-1)


def power_expansion(F):
    out=Counter()
    for epart,c in F.t.items():
        exps=[epower_to_power(lam) for lam in epart]
        for item in product(*(tuple(x.items()) for x in exps)):
            mon=tuple(x[0] for x in item);coef=Q(c)
            for _,d in item:coef*=d
            out[mon]+=coef
    return {m:c for m,c in out.items() if c}


def records(F):
    return [{'partitions':[list(x) for x in mon],'coefficient':c}
            for mon,c in sorted(F.t.items())]


def polynomial_string(F):
    pieces=[]
    for mon,c in sorted(F.t.items()):
        factors=[]
        for i,part in enumerate(mon,1):
            for k,m in sorted(Counter(part).items()):
                factors.append(f'e_{k}(X_{i})'+(f'^{m}' if m>1 else ''))
        pieces.append((str(c)+' * ' if c!=1 else '')+' * '.join(factors))
    return ' + '.join(pieces) or '0'


def sparse_matrix_traces(record):
    mats=[{(i,j):int(v) for i,j,v in g['matrix']['entries']}
          for g in record['generators']]
    assert len(mats)==2
    A,B=mats
    trace=lambda M:sum(v for (i,j),v in M.items() if i==j)
    both=sum(v*B.get((j,i),0) for (i,j),v in A.items())
    return [record['module_dimension'],trace(A),trace(B),both]


def main():
    start=time.monotonic();results=[]
    cases=[
        ('phase_mixing',[[0,2],[-1,0]],[1,2],(-6,2),(2,2)),
        ('parallel_packet_23',[[0,3],[-2,0]],[2,3],(-5,2),(2,2)),
        ('degree_five_valued',[[0,2],[-3,0]],[3,2],(-4,2),(3,2)),
        ('skew_actual_graph',[[0,2,-3],[-2,0,2],[3,-2,0]],[1,1,1],(-3,3,-2),(2,2,1)),
        ('cyclic_valued',[[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],(-3,-2,1),(2,2,1)),
        ('cyclic_valued_23',[[0,3,-2],[-2,0,1],[4,-3,0]],[2,3,1],(-2,-1,-2),(2,1,2)),
        ('genuine_nonprimitive_birth_skew',[[0,-3,-1],[3,0,-1],[1,1,0]],[1,1,1],(8,-5,-6),(2,2,2)),
        ('genuine_nonprimitive_birth_valued',[[0,-6,-1],[3,0,-1],[1,2,0]],[1,2,1],(14,-5,-10),(2,2,2)),
    ]
    for name,B,D,g,p in cases:
        t=time.monotonic();Bh,Dh=extended_data(B,D,g)
        model=FormalEventFlags(Bh,Dh)
        F=remove_frame(model.framed_theta(g,p))
        independent=GeneralizedSchur(B,D).theta_prefix(tuple(g),tuple(p)).get(
            tuple(p),EPoly.scalar(0,len(D)))
        assert F.t==independent.t,('formal incoming mismatch',name,F.t,independent.t)
        assert all(c>0 for c in F.t.values())
        powers=power_expansion(F);classes=list(product(*(partitions(k) for k in p)))
        chars={};checks=[]
        for lam in classes:
            tr=cycle_model(B,D,g,lam);chars[lam]=tr
            z=1
            for li in lam:z*=zpart(li)
            expected=Q((-1)**(sum(p)-sum(map(len,lam)))*tr,z)
            assert powers.get(lam,0)==expected,('cycle mismatch',name,lam)
            checks.append({'cycle_partitions':[list(x) for x in lam],
                           'trace':tr,'power_coefficient':str(expected)})
        oldmatrix=None
        if name=='skew_actual_graph':
            saved=json.loads((ROOT/'computations/intrinsic_partition_model/global_matrix_module.json').read_text())
            assert B==saved['B'] and list(g)==saved['g'] and list(p)==saved['p']
            actual=sparse_matrix_traces(saved)
            class_order=[((1,1),(1,1),(1,)),((2,),(1,1),(1,)),
                         ((1,1),(2,),(1,)),((2,),(2,),(1,))]
            predicted=[chars[x] for x in class_order]
            assert actual==predicted
            oldmatrix={'actual_matrix_traces_recomputed':actual,
                       'formal_profile_cycle_traces':predicted,
                       'source':'intrinsic_partition_model/global_matrix_module.json'}
        row={'name':name,'B':B,'D':D,'g':g,'p':p,
             'formal_elementary_profile':records(F),'formula':polynomial_string(F),
             'formal_terms':len(F.t),'all_coefficients_positive':True,
             'independent_signed_recursion_equal':True,'cycle_checks':checks,
             'actual_graph_matrix_check':oldmatrix,'stats':dict(model.stats),
             'nonprimitive_birth_parameters':[{'left':a,'right':b,'pair':[u,v],
                    'carrier':gamma,'K':K,'weights':[da,db,dg]}
                    for a,b,u,v,gamma,K,da,db,dg in sorted(model.nonprimitive_records)],
             'seconds':time.monotonic()-t}
        results.append(row)
        print(json.dumps({k:row[k] for k in ['name','formula','formal_terms','stats','seconds']}),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(
            {'status':'RUNNING','results':results,'seconds':time.monotonic()-start},indent=2))
    result={'status':'PASS','formal_packets':len(results),
            'cycle_classes_checked':sum(len(r['cycle_checks']) for r in results),
            'actual_matrix_classes_checked':4,'results':results,
            'seconds':time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='results'},indent=2))


if __name__=='__main__':main()
