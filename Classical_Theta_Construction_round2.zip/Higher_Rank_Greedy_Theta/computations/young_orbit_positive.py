"""Positive local Young-orbit / subset-multiset evaluation of theta objects.

The independently defined objects are the actual primitive-center Gale
point orbits decorated by child selections. This program counts their orbit
profiles by the proved cycle-fold formula. It does not claim to have solved
the point equations or enumerated their algebraic coordinates.
"""
from pathlib import Path
from functools import lru_cache,reduce
from itertools import product
from fractions import Fraction
from math import comb,prod,gcd
import sys,json,time
import sympy as sp

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from unlabelled_charge_partitions import ChargeOrbitSchurModel
from orbit_schur_positive import partitions,cycles
from local_young_permutation_probe import young_character
from local_primitive_laurent_jets import LocalPrimitiveJets


@lru_cache(None)
def local_dimension(eta):
    n=len(eta)
    if n==1:return 1
    entries=[abs(eta[i][j]) for i in range(n) for j in range(i+1,n) if eta[i][j]]
    if not entries:return 0
    common=reduce(gcd,entries)
    if common>1:
        base=tuple(tuple(x//common for x in row) for row in eta)
        return common**(n-1)*local_dimension(base)
    return LocalPrimitiveJets(n).trace(eta,tuple(range(n)))


@lru_cache(None)
def folded_character(eta,sigma):
    cc=cycles(sigma);lengths=tuple(map(len,cc));g=reduce(gcd,lengths)
    E=sum(abs(eta[i][j]) for i in range(len(eta)) for j in range(i+1,len(eta)))
    factor=1 if g==1 else 2 if g==2 and (E//4)%2 else 0
    if not factor:return 0
    fold=tuple(tuple(len(A)*len(B)*eta[A[0]][B[0]] for B in cc) for A in cc)
    value=Fraction(factor*local_dimension(fold),prod(lengths))
    assert value.denominator==1
    return int(value)


@lru_cache(None)
def inverse_young_character(n):
    pp=partitions(n)
    M=sp.Matrix([[young_character(lam,mu) for lam in pp] for mu in pp]).inv()
    return tuple(tuple(Fraction(int(x.p),int(x.q)) for x in row) for row in M.tolist())


@lru_cache(None)
def local_orbit_profiles(eta,multiplicities):
    axes=tuple(partitions(n) for n in multiplicities)
    keys=tuple(product(*(range(len(p)) for p in axes)))
    groups=[];offset=0
    for m in multiplicities:groups.append(tuple(range(offset,offset+m)));offset+=m
    values={}
    for key in keys:
        sigma=list(range(len(eta)))
        for inds,axis,i in zip(groups,axes,key):
            offset=0
            for k in axis[i]:
                C=inds[offset:offset+k];offset+=k
                for j,a in enumerate(C):sigma[a]=C[(j+1)%k]
        values[key]=Fraction(folded_character(eta,tuple(sigma)))
    # Apply the independent Young-character transforms one tensor axis at a
    # time; do not invert an unnecessarily large Kronecker matrix.
    for j,m in enumerate(multiplicities):
        inv=inverse_young_character(m);new={}
        for key in keys:
            new[key]=sum(inv[key[j]][k]*values[key[:j]+(k,)+key[j+1:]]
                         for k in range(len(axes[j])))
        values=new
    answer=[]
    for key,v in values.items():
        assert v.denominator==1 and v>=0,(eta,multiplicities,key,v)
        if v:answer.append((tuple(axes[j][key[j]] for j in range(len(axes))),int(v)))
    return tuple(answer)


def selection_count(k,b,parity):
    if parity:return comb(k,b) if k>=b else 0
    return comb(k+b-1,b) if k else int(b==0)


class YoungOrbitChargeModel(ChargeOrbitSchurModel):
    def _value(self,T):
        if T[0]=='L':return 1
        children=T[1];types=tuple(sorted(set(children)))
        multiplicities=tuple(children.count(C) for C in types)
        values=tuple(self.value(C) for C in types)
        if not all(values):
            self.records[repr(T)]={'value':0,'reason':'empty child set'}
            return 0
        charges=[self.charge(C) for C in children];E=self.model.color_eta
        eta=tuple(tuple(sum(a[i]*E[i][j]*b[j] for i in range(len(a)) for j in range(len(b)))
                        for b in charges) for a in charges)
        parities=tuple((sum(self.charge(C))+self.parity(C))%2 for C in types)
        total=0;terms=[]
        for profile,orbit_count in local_orbit_profiles(eta,multiplicities):
            selections=tuple(tuple(selection_count(k,b,e) for b in blocks)
                             for k,e,blocks in zip(values,parities,profile))
            value=orbit_count*prod(prod(row) for row in selections)
            if value:
                total+=value;terms.append({'coordinate_block_profiles':profile,
                    'number_of_actual_point_orbits':orbit_count,
                    'selection_counts':selections,'contribution':value})
        self.records[repr(T)]={'value':total,'eta':eta,'child_values':values,
            'child_multiplicities':multiplicities,'selection_parities':parities,
            'positive_orbit_terms':terms}
        return total


def main():
    out=[]
    sources=json.loads((HERE/'unlabelled_jet_formula.json').read_text())
    for source in sources:
        B=source['B'];g=tuple(source['g']);p=tuple(source['p']);start=time.time()
        model=YoungOrbitChargeModel(B,g,p);value,terms=model.coefficient()
        passed=(value==source['independent_theta'] and list(terms)==source['orbit_contributions'])
        result={'B':B,'g':g,'p':p,'coefficient':value,'tree_orbit_contributions':terms,
                'agrees_with_independent_Specht_and_theta':passed,
                'seconds':time.time()-start,'local_profile_cache':str(local_orbit_profiles.cache_info()),
                'local_dimension_cache':str(local_dimension.cache_info()),'node_records':model.records}
        out.append(result);Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
        print(json.dumps({k:v for k,v in result.items() if k!='node_records'}),flush=True)
        assert passed


if __name__=='__main__':main()
