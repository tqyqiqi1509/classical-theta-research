"""Actual one-active-input splitting by one same-ray marked atom.

The bijection uses the cyclic slot normal form, a local phase carry,
and a cycle-lemma cut. Original coefficient decorations are rotated
as intact blocks, never ordered or inspected.
"""
from math import gcd
from pathlib import Path
import json, time, random

from singleton_cyclic_phase import (
    xgcd, cut_statistics, normalize, rotate, from_cyclic, to_cyclic,
)
from tight_grading_two_input import is_tight, compositions


def rotate_payload(weights, phase, payload, cut, copies):
    result, phase = rotate(weights, phase, cut, copies)
    cut %= len(weights)
    return result, phase, payload[cut:]+payload[:cut]


def normalize_payload(weights, phase, payload, copies):
    P, Q = sum(weights),len(weights)
    ell = gcd(P,Q)
    running,best,cut=0,0,0
    for k,x in enumerate(weights[:-1],1):
        running+=x
        value=Q*running-P*k
        if value>best:
            best,cut=value,k
    weights,phase,payload=rotate_payload(weights,phase,payload,cut,copies)
    returns=cut_statistics(weights)
    phi=phase//copies
    next_return=next((r for r in returns if r>phi),0)
    weights,phase,payload=rotate_payload(weights,phase,payload,
                                       next_return*(Q//ell),copies)
    assert normalize(weights,phase,copies)==(weights,phase)
    return weights,phase,payload


def params(m,da,db,dmid,dfinal,a,b=1):
    Q=m//da
    v=m//db
    vmid=m//dmid
    assert m%da==m%db==m%dmid==0
    ell1=gcd(a*v,Q)
    ell2=gcd(b*vmid,Q)
    ellt=gcd((a+b)*v,Q)
    assert (Q*dmid)%(ell1*db)==0
    assert (Q*dfinal)%(ell2*dmid)==0
    assert (Q*dfinal)%(ellt*db)==0
    c1=Q*dmid//(ell1*db)
    c2=Q*dfinal//(ell2*dmid)
    ct=Q*dfinal//(ellt*db)
    L1,L2,Lt=c1*ell1,c2*ell2,ct*ellt
    assert L1*L2==Q*Lt
    return Q,v,vmid,ell1,ell2,ellt,c1,c2,ct,L1,L2,Lt,b


def split_forward(inner_weights,inner_phase,outer_phase,payload,parameters):
    Q,v,vmid,e1,e2,et,c1,c2,ct,L1,L2,Lt,b=parameters
    assert normalize(inner_weights,inner_phase,c1)==(inner_weights,inner_phase)
    assert 0<=outer_phase<L2
    last_return=cut_statistics(inner_weights)[-1]*(Q//e1)
    cut,newphase=divmod(inner_phase*L2+outer_phase,Lt)
    assert last_return<=cut<Q
    inner_weights=inner_weights[cut:]+inner_weights[:cut]
    payload=payload[cut:]+payload[:cut]
    weights=list(inner_weights)
    weights[-1]+=b*v
    # Payload (original F decoration, marker flag) records the exact
    # Cauchy factorization F*(1+epsilon*z) at this input edge.
    newpayload=tuple((p,i==Q-1) for i,p in enumerate(payload))
    return normalize_payload(tuple(weights),newphase,newpayload,ct)


def split_backward(weights,phase,payload,parameters):
    Q,v,vmid,e1,e2,et,c1,c2,ct,L1,L2,Lt,b=parameters
    marked=next(i for i,p in enumerate(payload)if p[1])
    assert sum(p[1] for p in payload)==1
    weights,phase,payload=rotate_payload(weights,phase,payload,(marked+1)%Q,ct)
    assert payload[-1][1]
    oldweights=list(weights);oldweights[-1]-=b*v
    oldweights=tuple(oldweights)
    oldpayload=tuple(p[0] for p in payload)
    P=sum(oldweights)
    # First maximum among indices 1,...,Q, including Q. This is the
    # unique cut whose inverse rotation lies after the last return.
    running=0
    heights=[]
    for k,x in enumerate(oldweights,1):
        running+=x
        heights.append(Q*running-P*k)
    cut=1+heights.index(max(heights))
    cut%=Q
    normalweights=oldweights[cut:]+oldweights[:cut]
    normalpayload=oldpayload[cut:]+oldpayload[:cut]
    inversecut=(-cut)%Q
    inner_phase,outer_phase=divmod(Lt*inversecut+phase,L2)
    assert normalize(normalweights,inner_phase,c1)==(normalweights,inner_phase)
    assert 0<=outer_phase<L2
    return normalweights,inner_phase,outer_phase,normalpayload


def content(D,v):
    ans=0
    for d,x in zip(D,v):ans=gcd(ans,d*x)
    return ans


def main():
    rng=random.Random(2611131525)
    start=time.monotonic()
    checks=literal=phase_changes=nonprimitive=unequal=0
    samples=[]
    for _ in range(6000):
        D=(rng.randrange(1,13),rng.randrange(1,13))
        alpha=(rng.randrange(0,7),rng.randrange(0,7))
        beta=(rng.randrange(0,7),rng.randrange(0,7))
        det=alpha[0]*beta[1]-alpha[1]*beta[0]
        if det<=0:continue
        m=D[0]*D[1]*rng.randrange(1,5)*det
        a=rng.randrange(1,12)
        b=rng.randrange(1,8)
        mid=tuple(a*x+y for x,y in zip(alpha,beta))
        final=tuple((a+b)*x+y for x,y in zip(alpha,beta))
        da,db,dm,dt=(content(D,x)for x in(alpha,beta,mid,final))
        par=params(m,da,db,dm,dt,a,b)
        Q,v,vmid,e1,e2,et,c1,c2,ct,L1,L2,Lt,b=par
        unequal+=da!=db
        nonprimitive+=max(dm,dt)>1
        for z in range(10):
            indices=[rng.randrange(Q)for _ in range(a)]
            oldweights=tuple(v*indices.count(i)for i in range(Q))
            # Distinct input decorations, retained intact under all moves.
            payload=tuple(('F',i,oldweights[i]//v)if oldweights[i]else None
                          for i in range(Q))
            oldweights,ip,payload=normalize_payload(oldweights,rng.randrange(L1),payload,c1)
            jp=rng.randrange(L2)
            out=split_forward(oldweights,ip,jp,payload,par)
            back=split_backward(*out,par)
            assert back==(oldweights,ip,jp,payload)
            word,grading,slot=from_cyclic(out[0],out[1],ct)
            if len(word)<=1000:
                assert is_tight(word,grading)
                literal+=1
            assert to_cyclic(word,grading,slot,ct)==out[:2]
            old_objects=sorted(str(p)for p in payload if p is not None)
            new_objects=sorted(str(p[0])for p in out[2]if p[0]is not None)
            assert old_objects==new_objects
            phase_changes+=ip!=out[1]
            checks+=1
            if len(samples)<3:
                samples.append(dict(D=D,alpha=alpha,beta=beta,a=a,b=b,
                                    normal_contents=[da,db,dm,dt],
                                    parameters=par,old_weights_sparse=[(i,x)for i,x in enumerate(oldweights)if x],
                                    old_phases=[ip,jp],new_weights_sparse=[(i,x)for i,x in enumerate(out[0])if x],
                                    new_phase=out[1],marker=next(i for i,p in enumerate(out[2])if p[1])))
    # An independent exhaustive source/target comparison in the standard
    # D=(1,1), alpha=(1,0), beta=(0,1) family, with arbitrary a and m.
    exhaust=0
    for m in range(1,8):
        for a in range(1,8):
            par=params(m,1,1,1,1,a)
            Q,v,vmid,e1,e2,et,c1,c2,ct,L1,L2,Lt,b=par
            if Q**a>150000:continue
            inner=set()
            for degreeword in compositions(a,Q):
                weights=tuple(v*x for x in degreeword)
                for phase in range(L1):
                    inner.add(normalize(weights,phase,c1))
            images=set()
            for weights,phase in inner:
                payload=tuple(weights)
                for op in range(L2):
                    out=split_forward(weights,phase,op,payload,par)
                    assert split_backward(*out,par)==(weights,phase,op,payload)
                    images.add(out)
                    exhaust+=1
            target=set()
            for degreeword in compositions(a,Q):
                oldweights=tuple(v*x for x in degreeword)
                weights=list(oldweights);weights[-1]+=b*v
                payload=tuple((x,i==Q-1)for i,x in enumerate(oldweights))
                for phase in range(Lt):
                    target.add(normalize_payload(tuple(weights),phase,payload,ct))
            assert images==target,(m,a,len(images),len(target))
    result=dict(status='PASS',actual_valued_maps=checks,
                literal_tightness_checks=literal,unequal_input_contents=unequal,
                nonprimitive_intermediate_or_final=nonprimitive,
                phase_changes=phase_changes,exhaustive_maps=exhaust,
                samples=samples,seconds=time.monotonic()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items()if k!='samples'},indent=2))


if __name__=='__main__':main()
