"""Independent polynomial-quotient versus actual weighted-Jacobian action."""

from itertools import product
from math import gcd, lcm, prod
from pathlib import Path
import json
import sympy as sp

from ramified_cut_character import quotient_character, cycle_factor, convolve
from weighted_jacobian import laplacian, cokernel_data, permute_tuple


def fullcuts(d, edges, kind):
    n = len(d)-1
    variables = sp.symbols(f'x1:{n+1}')
    x = (sp.Integer(0),) + variables
    factors = {}
    for i, j, m in edges:
        if kind == 'raw':
            factors[i, j] = (x[j]-x[i])**m
        else:
            h = gcd(d[i], d[j])
            ui, uj = (x[i], x[j]) if kind == 'valued' else (x[i]**d[i], x[j]**d[j])
            factors[i, j] = (uj**(d[i]//h)-ui**(d[j]//h))**(m//lcm(d[i], d[j]))
    generators = []
    for mask in range(1, 1 << n):
        S = {i+1 for i in range(n) if mask >> i & 1}
        generators.append(sp.expand(prod(factors[i, j] for i, j, m in edges if (i in S) != (j in S))))
    return variables, generators


def run(name, d, edges, permutations):
    data = {}
    for kind in ('valued', 'gain', 'raw'):
        variables, generators = fullcuts(d, edges, kind)
        weights = d[1:] if kind == 'valued' else [1]*(len(d)-1)
        data[kind] = quotient_character(variables, generators, weights, permutations)
    L, M = laplacian(d, edges)
    points, reduce = cokernel_data(M)
    checks = []
    for index, sigma in enumerate(permutations):
        factor = cycle_factor(d, sigma)
        predicted = convolve(data['valued']['traces'][index], factor)
        assert predicted == data['gain']['traces'][index] == data['raw']['traces'][index]
        action = tuple(sigma[i]-1 for i in range(1, len(d)))
        fixed = sum(reduce(permute_tuple(a, action)) == a for a in points)
        trace = sum(data['valued']['traces'][index].values())
        assert fixed == trace
        checks.append({'permutation': sigma, 'actual_lattice_fixed_points': fixed,
                       'polynomial_trace': trace, 'all_graded_gain_checks_passed': True})
    return {'name': name, 'weights': d, 'edges': edges, 'L': [list(map(int, L.row(i))) for i in range(L.rows)],
            'M': [list(map(int, M.row(i))) for i in range(M.rows)],
            'quotients': data, 'checks': checks}


if __name__ == '__main__':
    cases = [
        ('triangle_S2', [1,2,2], [(0,1,2),(0,2,2),(1,2,2)], [(0,1,2),(0,2,1)]),
        ('diamond_S2', [1,2,2,3], [(0,1,2),(0,2,2),(0,3,3),(1,3,6),(2,3,6)],
         [(0,1,2,3),(0,2,1,3)]),
        ('triangle_nonconstant', [1,2,3], [(0,1,2),(0,2,3),(1,2,6)], [(0,1,2)]),
        ('complete_four_S3', [1,2,2,2],
         [(i,j,2) for i in range(4) for j in range(i+1,4)],
         [(0,1,2,3),(0,2,1,3),(0,2,3,1)])
    ]
    results = []
    for case in cases:
        result = run(*case)
        results.append(result)
        print(json.dumps({'name': result['name'], 'checks': result['checks']}), flush=True)
    Path(__file__).with_name('fullcut_jacobian_character_results.json').write_text(json.dumps(results, indent=2))
