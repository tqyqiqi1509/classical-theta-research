"""Test phase normalization on entire rooted skeleton orbits.

This is a necessary representation-theoretic test for a proposed gluing, not
a definition of a valued module.  A negative irreducible multiplicity shows
that local or per-skeleton division must be replaced by cross-skeleton maps.
"""

from fractions import Fraction
from itertools import product
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'computations' / 'squarefree_polytope_action'))
from global_tensor_ih import (eta_from_input, check, permute, trace_skeleton,
                             representative, cycles, IncomingSchur)


def weighted_target(B, D, g, parts):
    tags = [(i, k) for i, pp in enumerate(parts) for k in pp]
    matrix = [[l * B[i][j] for j, l in tags] for i, k in tags]
    weights = [k * D[i] for i, k in tags]
    degree = (1,) * len(tags)
    return IncomingSchur(matrix, weights).theta_prefix(
        tuple(g[i] for i, k in tags), degree).get(degree, 0)


def run(B, D, g, p=(2, 2)):
    assert p == (2, 2)
    C = [[D[i] * B[i][j] for j in range(2)] for i in range(2)]
    gg = tuple(D[i] * g[i] for i in range(2))
    eta, colors = eta_from_input(C, gg, p)
    collapse = check(C, [1, 1], gg, p, True)
    skeletons = [row['tree'] for row in collapse['skeletons']]
    parts = list(product(((1, 1), (2,)), repeat=2))
    permutations = [representative(p, part) for part in parts]
    divisors = []
    for sigma in permutations:
        value = 1
        for cycle in cycles(sigma):
            if 0 not in cycle:
                value *= D[colors[cycle[0]]]
        divisors.append(value)
    signs = list(product(range(2), repeat=2))
    seen = set()
    records = []
    total = [Fraction(0)] * 4
    for tree in skeletons:
        if tree in seen:
            continue
        orbit = {permute(tree, dict(enumerate(sigma))) for sigma in permutations}
        seen |= orbit
        assert orbit.issubset(set(skeletons))
        raw = [sum(trace_skeleton(t, eta, sigma) for t in orbit) for sigma in permutations]
        normalized = [Fraction(x, d) for x, d in zip(raw, divisors)]
        irreducibles = [sum(value * (-1)**(a*i+b*j)
                            for value, (i, j) in zip(normalized, signs)) / 4
                        for a, b in signs]
        records.append({'trees': sorted(orbit, key=str), 'raw_character': raw,
                        'normalized_character': list(map(str, normalized)),
                        'irreducible_multiplicities': list(map(str, irreducibles)),
                        'is_actual_character': all(x >= 0 and x.denominator == 1 for x in irreducibles)})
        total = [x+y for x, y in zip(total, normalized)]
    targets = [weighted_target(B, D, g, part) for part in parts]
    assert total == targets
    multiplicities = [sum(value * (-1)**(a*i+b*j)
                          for value, (i, j) in zip(total, signs)) / 4
                      for a, b in signs]
    assert all(x >= 0 and x.denominator == 1 for x in multiplicities)
    return {'B': B, 'D': D, 'g': g, 'p': p, 'raw_skew_matrix': C,
            'raw_g': gg, 'cycle_types': parts, 'cycle_divisors': divisors,
            'skeleton_orbits': records, 'total_normalized_character': list(map(str, total)),
            'independent_incoming_cycle_character': targets,
            'total_irreducible_multiplicities': list(map(str, multiplicities)),
            'total_matches_incoming': True}


if __name__ == '__main__':
    result = run([[0, 2], [-1, 0]], [1, 2], (-6, 2))
    Path(__file__).with_name('rooted_orbit_normalization_results.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
