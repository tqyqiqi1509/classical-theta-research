"""Independent ambient-normal arithmetic for the sparse tight-grading conversion."""
from math import gcd,lcm
from functools import reduce
from pathlib import Path
import json,random,time

def vecgcd(v):return reduce(gcd,v,0)
def pair(C,a,b):return sum(a[i]*C[i][j]*b[j] for i in range(len(a)) for j in range(len(a)))
def main():
    rng=random.Random(20261113);start=time.time();checks=0;nontrivial=0;maximum=1;samples=[]
    while checks<50000:
        n=rng.randrange(2,7);D=[rng.randrange(1,13) for _ in range(n)]
        C=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                C[i][j]=lcm(D[i],D[j])*rng.randrange(-4,5);C[j][i]=-C[i][j]
        alpha=[rng.randrange(0,8) for _ in range(n)]
        beta=[rng.randrange(0,8) for _ in range(n)]
        m=pair(C,alpha,beta)
        if m==0:continue
        if m<0:alpha,beta=beta,alpha;m=-m
        a,b=rng.randrange(1,15),rng.randrange(1,15)
        if gcd(a,b)!=1:continue
        da=vecgcd([x*y for x,y in zip(D,alpha)])
        db=vecgcd([x*y for x,y in zip(D,beta)])
        gamma=[a*x+b*y for x,y in zip(alpha,beta)]
        dg=vecgcd([x*y for x,y in zip(D,gamma)])
        assert m%lcm(da,db)==0 and m%dg==0
        u,v=m//da,m//db
        ell=gcd(a*v,b*u);base_index=gcd(a*da,b*db)
        assert ell*da*db==m*base_index
        assert dg%base_index==0
        copies=dg//base_index
        assert copies*ell*da*db==m*dg
        p,q=a*v//ell,b*u//ell
        assert gcd(p,q)==1
        assert [p*D[i]*alpha[i]//da+q*D[i]*beta[i]//db for i in range(n)]==[copies*D[i]*gamma[i]//dg for i in range(n)]
        # Exact minimal sparse exponent, with no reliance on a wall function.
        minimal=lcm(v//gcd(v,p),u//gcd(u,q))
        assert minimal==ell
        checks+=1
        if copies>1:
            nontrivial+=1;maximum=max(maximum,copies)
            if len(samples)<6:samples.append({'D':D,'alpha':alpha,'beta':beta,'m':m,'a':a,'b':b,'weights':[da,db,dg],'ell':ell,'copies':copies})
    out={'status':'PASS','ambient_inputs':checks,'nontrivial_normal_powers':nontrivial,
         'maximum_power':maximum,'examples':samples,'seconds':time.time()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
