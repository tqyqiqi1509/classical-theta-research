"""Independent exact checks: phase permutation actions and Fei 2611.07549 §8.5.

The finite-field trace check enumerates connected invariant supports. It does
not invoke the 2026 BPS theorem. Phase actions use actual quotient cosets.
"""
from itertools import permutations, product
from math import gcd, prod
from pathlib import Path
import json
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from phase_groups import phase_image, quotient_representatives, check_contraction

q=sp.Symbol('q')


def cycles(p):
    result=[];seen=set()
    for i in range(len(p)):
        if i in seen:continue
        row=[];j=i
        while j not in seen:seen.add(j);row.append(j);j=p[j]
        result.append(tuple(row))
    return result


def power(p,r):
    out=list(range(len(p)))
    for _ in range(r):out=[p[i] for i in out]
    return tuple(out)


def connected(n,edges):
    if not edges:return n==1
    seen={0};stack=[0]
    while stack:
        v=stack.pop()
        for i,j in edges:
            u=j if i==v else i if j==v else None
            if u is not None and u not in seen:seen.add(u);stack.append(u)
    return len(seen)==n


def thin_absolute_count(n,edges,p):
    """Twisted finite-field count of geometrically connected thin supports.

    Each invariant edge orbit contributes F_(q^length)^*, every vertex orbit
    contributes its gauge F_(q^length)^*, and common scalars F_q^* are restored.
    Geometric connectedness makes the stabilizer exactly common scalars.
    """
    edge_index={e:i for i,e in enumerate(edges)}
    ep=tuple(edge_index[(p[i],p[j])] for i,j in edges)
    ecs=cycles(ep)
    numerator=0;support_count=0
    for choice in product((0,1),repeat=len(ecs)):
        selected=[edges[e] for yes,C in zip(choice,ecs) if yes for e in C]
        if not connected(n,selected):continue
        numerator+=prod(q**len(C)-1 for yes,C in zip(choice,ecs) if yes)
        support_count+=1
    value=sp.cancel((q-1)*numerator/prod(q**len(C)-1 for C in cycles(p)))
    assert sp.denom(value)==1
    return sp.expand(value),support_count


def phase_actions(ds,es):
    pairs={(i,j):m for i,j,m in es}
    autos=[]
    for p in permutations(range(len(ds))):
        if any(ds[i]!=ds[p[i]] for i in range(len(ds))):continue
        if any(pairs.get(tuple(sorted((p[i],p[j]))))!=m for i,j,m in es):continue
        autos.append(p)
    cosets=quotient_representatives(ds,es)
    owner={x:k for k,(_,C) in enumerate(cosets) for x in C}
    inds={tuple(sorted((i,j))):k for k,(i,j,_) in enumerate(es)}
    actions={}
    for p in autos:
        def act(x):
            y=[0]*len(es)
            for k,(i,j,m) in enumerate(es):
                u,v=p[i],p[j];ell=inds[tuple(sorted((u,v)))]
                y[ell]=(x[k] if u<v else -x[k])%m
            return tuple(y)
        actions[p]=tuple(owner[act(rep)] for rep,_ in cosets)
        for k,(_,C) in enumerate(cosets):
            assert all(owner[act(x)]==actions[p][k] for x in C)
    for p in autos:
        for r in autos:
            pr=tuple(p[r[i]] for i in range(len(ds)))
            assert actions[pr]==tuple(actions[p][actions[r][i]] for i in range(len(cosets)))
    return {"weights":ds,"edges":es,"automorphisms":len(autos),
            "quotient_order":len(cosets),"group_law_checks":len(autos)**2,
            "characters":[{"permutation":p,"trace":sum(i==j for i,j in enumerate(actions[p]))}
                          for p in autos]}


def main():
    es=[(i,j) for i in range(3) for j in range(3,5)]
    a=(1,2,0,4,3)
    expected=[q*q+4*q+7,q*q-q+1,q*q+q+1,q*q+2*q+1,q*q+q+1,q*q-q+1]
    trace_records=[]
    for r in range(6):
        p=power(a,r)
        value,supports=thin_absolute_count(5,es,p)
        assert value==expected[r]
        trace_records.append({"power":r,"vertex_cycles":cycles(p),
                              "connected_invariant_supports":supports,
                              "trace_polynomial":str(value),"q1":int(value.subs(q,1))})
    action_records=[]
    for ds,edges in [((1,2,2,2),((0,1,4),(0,2,4),(0,3,4))),
                     ((2,3,3,2),((0,1,6),(1,2,9),(2,3,6))),
                     ((2,2,2,2),((0,1,4),(0,2,4),(0,3,4))),
                     ((1,3,3,3),((0,1,6),(0,2,6),(0,3,6)))]:
        action_records.append(phase_actions(ds,edges))
    # This exact sequence is non-split: Z/4 -> Z/2 with kernel Z/2.
    ds=(1,2,3);edges=((0,1,4),(1,2,6))
    A=sp.Matrix([[4,-2,0],[0,3,-2]])
    snf=smith_normal_form(A,domain=sp.ZZ)
    invariants=[abs(int(snf[i,i])) for i in range(2)]
    assert invariants==[1,4]
    nonsplit={"weights":ds,"edges":edges,"smith_invariants":invariants,
              "contraction":check_contraction(ds,edges,(0,))}
    result={"status":"all exact checks passed","fei_section_8_5":trace_records,
            "phase_automorphism_actions":action_records,"nonsplit_contraction":nonsplit}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({"status":result["status"],"trace_polynomials":[r["trace_polynomial"] for r in trace_records],
                      "group_law_checks":sum(r["group_law_checks"] for r in action_records),
                      "nonsplit_contraction":nonsplit},indent=2))


if __name__=='__main__':main()
