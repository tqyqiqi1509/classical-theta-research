"""Actual Young modules from the existing literal Dyck-object factories.

No new scalar theta tests: this attaches the external-label action to all
literal objects in the eight existing formal packets and compares every full
cycle trace with their independently established weighted-cycle characters.
"""

from pathlib import Path
import json
import sys
import time

HERE = Path(__file__).resolve().parent
COMPUTATIONS = HERE.parent
sys.path.insert(0, str(COMPUTATIONS))
from universal_dyck_object_factory import UniversalDyckObjects
from flatten_dyck_objects import flatten
from valued_event_flag_grammar import extended_data
from young_event_species import YoungEventModule, skeleton_from_flattened_event


def main():
    start = time.monotonic()
    source = json.loads((COMPUTATIONS/'valued_event_formal_profiles.json').read_text())
    reports = []
    total_objects = total_classes = 0
    for case in source['results']:
        B, D = case['B'], case['D']
        g, p = tuple(case['g']), tuple(case['p'])
        Bhat, Dhat = extended_data(B, D, g)
        factory = UniversalDyckObjects(Bhat, Dhat)
        root = factory.framed_theta(g, p)
        count = factory.sets.cardinality(root)
        skeletons = []
        for index in range(count):
            obj = factory.sets.select(root, index)
            tree = flatten(obj, len(Dhat))
            skeletons.append(skeleton_from_flattened_event(tree, index, len(Dhat)))
        M = YoungEventModule(skeletons, content=(1,) + p)
        expected_orbits = {((1,),) + tuple(tuple(sorted(q, reverse=True))
                                         for q in entry['partitions']):entry['coefficient']
                           for entry in case['formal_elementary_profile']}
        assert M.young_orbit_table == expected_orbits, case['name']
        chars = []
        for row in case['cycle_checks']:
            cycles = ((1,),) + tuple(tuple(x) for x in row['cycle_partitions'])
            actual = M.trace(cycles)
            assert actual == row['trace'], (case['name'], cycles, actual, row['trace'])
            chars.append({'original_color_cycles':cycles,
                          'literal_young_trace':actual,'independent_weighted_cycle_trace':row['trace']})
        report = {'name':case['name'],'literal_skeletons':count,
                  'young_orbit_types':len(M.young_orbit_table),
                  'permutation_module_dimension':M.dimension,
                  'sign_Hom_dimension':M.sign_multiplicity,
                  'cycle_characters':chars,'all_passed':True}
        reports.append(report)
        total_objects += count
        total_classes += len(chars)
        print(json.dumps({k:v for k,v in report.items() if k!='cycle_characters'}),flush=True)
    result = {'status':'PASS','packets':len(reports),
              'literal_objects_promoted_to_Young_modules':total_objects,
              'complete_cycle_classes_verified':total_classes,
              'results':reports,'seconds':time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='results'}))


if __name__=='__main__':
    main()
