"""Qin support dimensions from a finite negative-frame mutation certificate.

No theta coefficient or F-polynomial is an input.  The optional verification
computes cluster-variable F-vector degrees by integer tropical recurrence.
"""

from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from math import lcm
from pathlib import Path
from random import Random
import json
import sympy as sp


def positive(x):
    return max(int(x), 0)


def principal(B):
    n = len(B)
    return tuple(tuple(map(int, row)) for row in B) + tuple(
        tuple(int(i == j) for j in range(n)) for i in range(n))


def mutate(E, k):
    n = len(E[0])
    return tuple(tuple(-E[i][j] if i == k or j == k else
                       E[i][j] + positive(E[i][k]) * positive(E[k][j])
                       - positive(-E[i][k]) * positive(-E[k][j])
                       for j in range(n)) for i in range(len(E)))


def tropical_step(E, k, vector):
    a = int(vector[k])
    return tuple(-a if i == k else int(vector[i])
                 + positive(E[i][k]) * positive(a)
                 - positive(-E[i][k]) * positive(-a)
                 for i in range(len(vector)))


def mutate_word(E, word):
    for k in word:
        E = mutate(E, k)
    return E


@dataclass
class SupportCertificate:
    B: tuple[tuple[int, ...], ...]
    word: tuple[int, ...]

    def __post_init__(self):
        self.n = n = len(self.B)
        self.initial = principal(self.B)
        terminal = mutate_word(self.initial, self.word)
        self.sigma = tuple(next((i for i in range(n) if terminal[n+i][j] == -1), -1)
                           for j in range(n))
        if sorted(self.sigma) != list(range(n)) or any(
                terminal[n+i][j] != -int(i == self.sigma[j])
                for i in range(n) for j in range(n)):
            raise ValueError("The supplied word does not end in C=-P")
        P = sp.zeros(n)
        for j, i in enumerate(self.sigma):
            P[i, j] = 1
        assert sp.Matrix(terminal[:n]) == P.T * sp.Matrix(self.B) * P
        self.predecessor_word = tuple(self.sigma[k] for k in reversed(self.word))
        self.predecessor = mutate_word(self.initial, self.predecessor_word)
        assert sp.Matrix(self.predecessor[:n]) == P * sp.Matrix(self.B) * P.T
        forward = tuple(self.sigma[k] for k in self.word)
        assert mutate_word(self.predecessor, forward) == self.initial
        forward_principal = mutate_word(principal(self.predecessor[:n]), forward)
        assert sp.Matrix(forward_principal[n:]) == -P
        self.steps = []
        E = self.initial
        for k in self.predecessor_word:
            self.steps.append((E, k))
            E = mutate(E, k)
        columns = [self.phi(tuple(int(i == j) for i in range(2*n))) for j in range(2*n)]
        self.psi = sp.Matrix.hstack(*(sp.Matrix(v) for v in columns))
        assert abs(self.psi.det()) == 1
        self.psi_inverse = self.psi.inv()

    def phi(self, full_vector):
        out = tuple(map(int, full_vector))
        for E, k in self.steps:
            out = tropical_step(E, k, out)
        return out

    def support(self, g):
        if len(g) != self.n:
            raise ValueError("Supply the initial mutable theta label")
        full_g = tuple(map(int, g)) + (0,) * self.n
        eta = self.psi_inverse * sp.Matrix(self.phi(full_g))
        difference = eta - sp.Matrix(full_g)
        bound = tuple(int(x) for x in difference[self.n:])
        assert all(x >= 0 for x in bound)
        assert sp.Matrix(self.initial) * sp.Matrix(bound) == difference
        return bound


def cluster_g_and_fvectors(B, word):
    """Exact degrees from mutation; no polynomial expansion is used."""
    n = len(B)
    E = principal(B)
    G = [[int(i == j) for j in range(n)] for i in range(n)]
    F = [[0 for _ in range(n)] for _ in range(n)]
    for k in word:
        c = [E[n+i][k] for i in range(n)]
        eps = 1 if all(a >= 0 for a in c) else -1
        assert all(eps*a >= 0 for a in c)
        new_g = [-G[i][k] + sum(positive(-eps*E[j][k])*G[i][j] for j in range(n))
                 for i in range(n)]
        new_f = [max(positive(c[i]) + sum(positive(E[j][k])*F[i][j] for j in range(n)),
                     positive(-c[i]) + sum(positive(-E[j][k])*F[i][j] for j in range(n)))
                 - F[i][k] for i in range(n)]
        assert all(a >= 0 for a in new_f)
        for i in range(n):
            G[i][k], F[i][k] = new_g[i], new_f[i]
        E = mutate(E, k)
    return tuple(tuple(G[i][j] for i in range(n)) for j in range(n)), tuple(
        tuple(F[i][j] for i in range(n)) for j in range(n))


def checks():
    rng = Random(20261113)
    cases, arbitrary, variable_checks, nontrivial_permutations = 0, 0, 0, 0
    examples = []
    for trial in range(100):
        n = 1 + trial % 4
        D = [rng.randint(1, 4) for _ in range(n)]
        B = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                m = lcm(D[i], D[j]) * rng.randint(0, 2)
                B[i][j], B[j][i] = m//D[i], -m//D[j]
        change = tuple(rng.randrange(n) for _ in range(trial % 4))
        changed_B = mutate_word(principal(B), change)[:n]
        # A conjugated identity-permutation reddening word.  Validity is checked
        # from its exact principal C-matrix, not assumed by this test.
        word = tuple(reversed(change)) + tuple(reversed(range(n))) + change
        cert = SupportCertificate(changed_B, word)
        cases += 1
        for _ in range(30):
            g = tuple(rng.randint(-8, 8) for _ in range(n))
            cert.support(g)
            arbitrary += 1
        for _ in range(15):
            w = tuple(rng.randrange(n) for _ in range(rng.randint(0, 6)))
            gs, fs = cluster_g_and_fvectors(changed_B, w)
            for g, f in zip(gs, fs):
                assert cert.support(g) == f, (changed_B, word, w, g, cert.support(g), f)
                variable_checks += 1
        if trial in [2, 3, 6]:
            g = (-2,)*n
            examples.append({'B': changed_B, 'D': D, 'reddening_word_zero_based': word,
                             'g': g, 'support_dimension': cert.support(g)})
    # A certificate with a nonidentity terminal permutation tests precisely the
    # sigma-versus-sigma-inverse ambiguity in predecessor construction.
    for B, word in [(((0,1),(-1,0)), (0,1,0)),
                    (((0,1,0),(-1,0,1),(0,-1,0)), (0,1,2,0,1,0)),
                    (((0,1,0),(-1,0,1),(0,-1,0)), (0,1,2,1,0))]:
        cert = SupportCertificate(B, word)
        nontrivial_permutations += int(cert.sigma != tuple(range(len(B))))
        cases += 1
        for g in product(range(-3,4), repeat=len(B)):
            cert.support(g)
            arbitrary += 1
        for _ in range(30):
            w = tuple(rng.randrange(len(B)) for _ in range(8))
            gs, fs = cluster_g_and_fvectors(B, w)
            for g, f in zip(gs, fs):
                assert cert.support(g) == f, (B, word, w, g, f)
                variable_checks += 1
    report = {'certificates': cases, 'nonidentity_permutation_certificates': nontrivial_permutations,
              'arbitrary_g_support_checks': arbitrary, 'cluster_variable_fvector_checks': variable_checks,
              'all_passed': True, 'source': 'Qin Def3.4.4 and Prop3.4.8; no novelty claim for support dimensions',
              'examples_for_reproduction': examples}
    Path(__file__).with_name('tropical_support_certificate_results.json').write_text(
        json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    checks()
