"""Finite cyclic phase objects for primitive valued flow multiplicities.

No theta coefficients or dimensions from an oracle enter these objects.
The presentation is an actual finite abelian cokernel.  Enumeration below
is only an independent check of its order and contraction functoriality.
"""
from __future__ import annotations
from collections import deque
from functools import reduce
from itertools import combinations, product
from math import gcd, lcm, prod
from pathlib import Path
import json
import random


def phase_image(weights, edges):
    """Image of prod Z/d_v -> prod Z/m_e, edge i->j maps m/d_i,-m/d_j."""
    weights=tuple(weights);edges=tuple(edges)
    assert all(m%weights[i]==m%weights[j]==0 for i,j,m in edges)
    generators=[]
    for v,d in enumerate(weights):
        generators.append(tuple((m//d if i==v else -m//d if j==v else 0)%m
                                for i,j,m in edges))
    zero=(0,)*len(edges)
    image={zero};queue=deque([zero])
    while queue:
        x=queue.popleft()
        for g in generators:
            y=tuple((a+b)%e[2] for a,b,e in zip(x,g,edges))
            if y not in image:image.add(y);queue.append(y)
    return frozenset(image)


def quotient_representatives(weights, edges):
    """Actual cosets, represented lexicographically, with their members."""
    image=phase_image(weights,edges)
    unseen=set(product(*(range(m) for _,_,m in edges)))
    result=[]
    while unseen:
        x=min(unseen)
        coset=frozenset(tuple((a+b)%e[2] for a,b,e in zip(x,h,edges)) for h in image)
        assert coset<=unseen
        unseen-=coset;result.append((x,coset))
    return result


def kernel_count(weights, edges):
    return sum(all((m//weights[i]*x[i]-m//weights[j]*x[j])%m==0
                   for i,j,m in edges) for x in product(*(range(d) for d in weights)))


def connected_components(n,edges):
    adj=[[] for _ in range(n)]
    for i,j,_ in edges:adj[i].append(j);adj[j].append(i)
    unseen=set(range(n));parts=[]
    while unseen:
        v=min(unseen);seen={v};stack=[v]
        while stack:
            u=stack.pop()
            for w in adj[u]:
                if w not in seen:seen.add(w);stack.append(w)
        unseen-=seen;parts.append(tuple(sorted(seen)))
    return parts


def is_tree(n,edges):
    return len(edges)==n-1 and len(connected_components(n,edges))==1


def contract(weights,edges,contracted_indices):
    """Forest contraction uses gcd weights, retaining exact phase information."""
    inds=frozenset(contracted_indices)
    parts=connected_components(len(weights),[edges[i] for i in inds])
    owner={v:j for j,C in enumerate(parts) for v in C}
    newweights=[gcd(*(weights[i] for i in C)) for C in parts]
    newedges=[(owner[i],owner[j],m) for k,(i,j,m) in enumerate(edges) if k not in inds]
    return parts,newweights,newedges


def check_contraction(weights,edges,inds):
    """Check every fiber of C_T -> C_F has |C_(T/F)| points."""
    inds=tuple(sorted(inds))
    forestedges=[edges[i] for i in inds]
    forestimage=phase_image(weights,forestedges)
    def forestrep(x):
        return min(tuple((x[i]+h[k])%edges[i][2] for k,i in enumerate(inds))
                   for h in forestimage)
    fibers={}
    for rep,coset in quotient_representatives(weights,edges):
        target=forestrep(rep)
        assert all(forestrep(x)==target for x in coset)
        fibers[target]=fibers.get(target,0)+1
    parts,d2,e2=contract(weights,edges,inds)
    quotient_order=len(quotient_representatives(d2,e2))
    assert all(n==quotient_order for n in fibers.values())
    return {"parts":parts,"gcd_weights":d2,"fiber_order":quotient_order,
            "base_order":len(fibers),"total_order":sum(fibers.values())}


def run():
    rng=random.Random(20261113)
    cases=[];kernel_checks=0;contractions=0
    # All labelled trees through four vertices, many nonconstant weights,
    # with bounded actual edge-label sets for transparent enumeration.
    for n in range(2,5):
        pairs=list(combinations(range(n),2))
        for chosen in combinations(pairs,n-1):
            if not is_tree(n,[(i,j,1) for i,j in chosen]):continue
            for ds in product(range(1,5),repeat=n):
                es=[(i,j,lcm(ds[i],ds[j])) for i,j in chosen]
                if prod(m for _,_,m in es)>1500:continue
                image=phase_image(ds,es)
                h=gcd(*ds)
                assert len(image)==prod(ds)//h
                order=prod(m for _,_,m in es)//len(image)
                assert order==h*prod(m for _,_,m in es)//prod(ds)
                kernel_checks+=1
                if rng.randrange(45)==0:
                    reps=quotient_representatives(ds,es)
                    assert len(reps)==order
                    assert kernel_count(ds,es)==h
                    inds=tuple(k for k in range(n-1) if rng.randrange(2))
                    cc=check_contraction(ds,es,inds);contractions+=1
                    cases.append({"weights":ds,"edges":es,"phase_order":order,
                                  "contraction":cc})
    # A genuinely nonconstant example with nontrivial phase group.
    example_d=(2,3,5)
    example_e=((0,1,6),(1,2,15))
    example=quotient_representatives(example_d,example_e)
    record={"status":"all exact checks passed","kernel_order_checks":kernel_checks,
            "actual_coset_and_fiber_checks":contractions,
            "example":{"weights":example_d,"edges":example_e,
                       "coset_representatives":[r for r,_ in example],
                       "coset_sizes":[len(c) for _,c in example],
                       "contraction":check_contraction(example_d,example_e,(0,))},
            "sampled_cases":cases}
    out=Path(__file__).with_name("phase_group_checks.json")
    out.write_text(json.dumps(record,indent=2))
    print(json.dumps({k:v for k,v in record.items() if k!="sampled_cases"},indent=2))


if __name__=="__main__":run()
