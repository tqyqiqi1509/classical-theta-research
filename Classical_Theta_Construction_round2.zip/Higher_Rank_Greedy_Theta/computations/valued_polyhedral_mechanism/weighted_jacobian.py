"""Exact arithmetic critical groups, phase subgroups and permutation traces.

No cluster or theta data is used.  The object is coker(L D^{-1}), defined
before its size or character is computed.  The large suite independently
checks coinvariant indices by Smith normal form; small samples enumerate
actual cokernel elements, the free phase subgroup and quotient fibers.
"""

from collections import Counter
from itertools import product, combinations
from math import gcd, lcm, prod
from pathlib import Path
import json
import random
import time
import sympy as sp
from sympy.matrices.normalforms import hermite_normal_form, smith_normal_form
from sympy.polys.domains import ZZ


def cycles(sigma):
    remaining = set(range(len(sigma)))
    result = []
    while remaining:
        i = min(remaining)
        cycle = []
        while i not in cycle:
            cycle.append(i)
            remaining.remove(i)
            i = sigma[i]
        result.append(tuple(cycle))
    return result


def laplacian(d, edges):
    n = len(d)-1
    L = sp.zeros(n)
    for i, j, m in edges:
        assert m > 0 and m % lcm(d[i], d[j]) == 0
        if i:
            L[i-1, i-1] += m
        if j:
            L[j-1, j-1] += m
        if i and j:
            L[i-1, j-1] -= m
            L[j-1, i-1] -= m
    M = L * sp.diag(*(sp.Rational(1, x) for x in d[1:]))
    assert all(x.q == 1 for x in M)
    M = sp.Matrix(n, n, list(map(int, M)))
    return L, M


def coinvariant_matrix(M, sigma):
    cc = cycles(sigma)
    return sp.Matrix([[sum(M[i, col[0]] for i in row) for col in cc] for row in cc])


def smith_fixed_count(M, sigma):
    P = sp.zeros(len(sigma))
    for i, j in enumerate(sigma):
        P[j, i] = 1
    S = smith_normal_form(M.row_join(P-sp.eye(len(sigma))), domain=ZZ)
    return abs(prod(int(S[i, i]) for i in range(len(sigma))))


def cokernel_data(M):
    H = hermite_normal_form(M)
    diagonal = [int(H[i, i]) for i in range(H.rows)]
    reps = tuple(product(*(range(x) for x in diagonal)))

    def reduce(x):
        a = list(map(int, x))
        for j in reversed(range(H.cols)):
            quotient = a[j] // int(H[j, j])
            for i in range(j+1):
                a[i] -= quotient * int(H[i, j])
        return tuple(a)
    return reps, reduce


def permute_tuple(x, sigma):
    out = [0] * len(x)
    for i, j in enumerate(sigma):
        out[j] = x[i]
    return out


def actual_check(L, M, d, sigma):
    raw, reduce_raw = cokernel_data(L)
    val, reduce_val = cokernel_data(M)
    phase = {reduce_raw(M * sp.Matrix(a)) for a in product(*(range(x) for x in d[1:]))}
    assert len(phase) == prod(d[1:])
    fibers = Counter(reduce_val(a) for a in raw)
    assert set(fibers) == set(val)
    assert set(fibers.values()) == {len(phase)}
    for a in phase:
        assert reduce_val(a) == (0,) * M.rows
    raw_fixed = sum(reduce_raw(permute_tuple(a, sigma)) == a for a in raw)
    val_fixed = sum(reduce_val(permute_tuple(a, sigma)) == a for a in val)
    divisor = prod(d[c[0]+1] for c in cycles(sigma))
    assert raw_fixed == divisor * val_fixed
    # The canonical half-open parallelotope representative also commutes
    # with the permutation, independently of the Hermite basis.
    inverse = M.inv()
    polytope = []
    for a in val:
        x = sp.Matrix(a)
        coordinate = inverse*x
        z = x - M*sp.Matrix([sp.floor(v) for v in coordinate])
        normalized = inverse*z
        assert all(0 <= v < 1 for v in normalized)
        polytope.append(tuple(map(int, z)))
    polyset = set(polytope)
    assert len(polyset) == len(val)
    assert {tuple(permute_tuple(x, sigma)) for x in polyset} == polyset
    assert sum(tuple(permute_tuple(x, sigma)) == x for x in polyset) == val_fixed
    return {'raw_order': len(raw), 'valued_order': len(val),
            'phase_order': len(phase), 'raw_fixed': raw_fixed,
            'valued_fixed': val_fixed, 'cycle_divisor': divisor,
            'parallelotope_points': sorted(polyset) if len(polyset) <= 30 else None}


def random_case(rng, n):
    d = [1] + [rng.randrange(1, 6) for _ in range(n)]
    # Ensure symmetries are genuinely tested in most cases.
    if n >= 2:
        d[2] = d[1]
    if n >= 4 and rng.randrange(2):
        d[4] = d[3]
    sigma = list(range(n))
    for weight in set(d[1:]):
        block = [i for i in range(n) if d[i+1] == weight]
        shuffled = block[:]
        rng.shuffle(shuffled)
        for i, j in zip(block, shuffled):
            sigma[i] = j
    full = [0] + [x+1 for x in sigma]
    pairs = set(combinations(range(n+1), 2))
    edges = []
    while pairs:
        pair = min(pairs)
        orbit = set()
        while pair not in orbit:
            orbit.add(pair)
            pair = tuple(sorted((full[pair[0]], full[pair[1]])))
        pairs -= orbit
        multiplier = rng.randrange(1, 4) if any(i == 0 for i, j in orbit) else rng.randrange(4)
        if multiplier:
            edges += [(i, j, multiplier*lcm(d[i], d[j])) for i, j in orbit]
    return d, sorted(edges), tuple(sigma)


def main():
    started = time.time()
    rng = random.Random(2611131242)
    count = 6000
    smith_checks = 0
    actual = []
    maximum_order = 0
    nontrivial_permutations = 0
    for index in range(count):
        d, edges, sigma = random_case(rng, 1+index % 7)
        L, M = laplacian(d, edges)
        raw = abs(int(L.det(method='domain-ge')))
        val = abs(int(M.det(method='domain-ge')))
        assert raw == prod(d[1:]) * val
        maximum_order = max(maximum_order, raw)
        LL = coinvariant_matrix(L, sigma)
        MM = coinvariant_matrix(M, sigma)
        factor = prod(d[c[0]+1] for c in cycles(sigma))
        raw_fix = abs(int(LL.det(method='domain-ge')))
        val_fix = abs(int(MM.det(method='domain-ge')))
        assert raw_fix == factor * val_fix
        if sigma != tuple(range(len(sigma))):
            nontrivial_permutations += 1
        if index < 1500:
            assert smith_fixed_count(L, sigma) == raw_fix
            assert smith_fixed_count(M, sigma) == val_fix
            smith_checks += 2
        if raw <= 1200 and len(actual) < 120:
            data = actual_check(L, M, d, sigma)
            actual.append({'d': d, 'edges': edges, 'sigma': sigma, **data})
        if index % 1000 == 999:
            print(json.dumps({'processed': index+1, 'seconds': time.time()-started,
                              'actual_coset_samples': len(actual)}), flush=True)
    report = {'general_graph_inputs': count, 'nontrivial_permutations': nontrivial_permutations,
              'independent_Smith_coinvariant_checks': smith_checks,
              'actual_phase_coset_parallelotope_checks': len(actual),
              'largest_raw_group_order': maximum_order, 'all_passed': True,
              'seconds': time.time()-started, 'actual_samples': actual}
    Path(__file__).with_name('weighted_jacobian_results.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({k: v for k, v in report.items() if k != 'actual_samples'}), flush=True)


if __name__ == '__main__':
    main()
