"""One finite charge-graded theta Hom model from a reddening certificate.

Construction order:
  1. Check the exact principal C=-P certificate.
  2. Compute Qin's support dimension by tropical mutation and a linear inverse.
  3. Construct all literal singleton-leaf Dyck/event set recipes in that box.
  4. Only on request, evaluate the dimensions or select an actual basis object.

The set recipes form the explicit basis of the sign Hom spaces proved in
agents/valued_young_functor_reddening.md.  No cardinality or theta coefficient
is queried during steps1--3.
"""

from pathlib import Path
import json
import sys
import time

HERE = Path(__file__).resolve().parent
COMPUTATIONS = HERE.parent
sys.path.insert(0, str(COMPUTATIONS))
from dyck_object_factory import DyckObjects
from valued_event_flag_grammar import extended_data, box
from tropical_support_certificate import SupportCertificate


class WholeThetaHomSpace:
    def __init__(self, B, D, g, reddening_word, *, max_swaps=None):
        self.B = tuple(map(tuple, B))
        self.D = tuple(D)
        self.g = tuple(g)
        self.reddening_word = tuple(reddening_word)
        self.certificate = SupportCertificate(self.B, self.reddening_word)
        self.support_dimension = self.certificate.support(self.g)
        Bhat, Dhat = extended_data(self.B, self.D, self.g)
        self.factory = DyckObjects(Bhat, Dhat, max_swaps=max_swaps)
        self.roots = {p:self.factory.framed_theta(self.g, p)
                      for p in box(self.support_dimension)}
        # The independent finite-set recipes already exist at this point.
        assert self.factory.sets.cardinality.cache_info().currsize == 0

    def graded_dimensions(self):
        """Hilbert polynomial coefficient dictionary, after object construction."""
        return {p:c for p, root in self.roots.items()
                if (c := self.factory.sets.cardinality(root)) != 0}

    def basis_object(self, charge, index=0):
        """An actual nested grading basis object of Hom(sign,M_(1,charge))."""
        charge = tuple(charge)
        if charge not in self.roots:
            raise KeyError("Charge is outside the certified support box")
        return self.factory.sets.select(self.roots[charge], index)

    def support_certificate_data(self):
        return {'B':self.B,'D':self.D,'g':self.g,
                'reddening_word_zero_based':self.reddening_word,
                'terminal_permutation':self.certificate.sigma,
                'predecessor_word_zero_based':self.certificate.predecessor_word,
                'support_dimension':self.support_dimension,
                'Psi':[list(map(int,row)) for row in self.certificate.psi.tolist()]}


def main():
    started = time.monotonic()
    # A cyclic, nonconstant-symmetrizer regression for the complete finite
    # construction.  The algorithm and support proof are not restricted to it.
    B = ((0,-2,2),(1,0,-1),(-2,2,0))
    D, g, word = (1,2,1), (0,-1,1), (1,2,1,0,1)
    V = WholeThetaHomSpace(B,D,g,word)
    nodes_before_evaluation = len(V.factory.sets.nodes)
    dims = V.graded_dimensions()
    assert len(V.factory.sets.nodes) == nodes_before_evaluation
    # Verification starts only after all finite sets have been defined.
    sys.path.insert(0,str(COMPUTATIONS.parent/'agents'))
    from incoming_recursion import IncomingSchur
    oracle = IncomingSchur(B,D).theta_prefix(g,V.support_dimension)
    assert dims == oracle
    assert dims[V.support_dimension] == 1
    result = {'status':'PASS','certificate':V.support_certificate_data(),
              'entire_F_polynomial':[[list(p),c] for p,c in dims.items()],
              'support_box_states':len(V.roots),'finite_set_recipe_nodes':nodes_before_evaluation,
              'basis_objects_total':sum(dims.values()),
              'top_degree_Hom_dimension':dims[V.support_dimension],
              'coefficient_oracle_used_in_construction':False,
              'cardinality_used_in_construction':False,
              'independent_whole_polynomial_check':True,
              'top_degree_actual_basis_object':V.basis_object(V.support_dimension),
              'seconds':time.monotonic()-started}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='top_degree_actual_basis_object'},indent=2))


if __name__=='__main__':
    main()
