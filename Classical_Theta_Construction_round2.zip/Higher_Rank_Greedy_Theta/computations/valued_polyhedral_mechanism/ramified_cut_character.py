"""Exact generic ramified cut-algebra and full permutation-character check.

The polynomial quotient is constructed only from Q, theta and d.  No theta
coefficient or prescribed character enters its construction.  We independently
reduce raw, gain, and valued quotients and compare their graded actions.
"""

from collections import Counter
from itertools import combinations, product
import json
from math import gcd, lcm, prod
from pathlib import Path
import sympy as sp


def cut_generators(d, edges, theta, kind):
    n = len(d) - 1
    variables = sp.symbols(f'x1:{n+1}')
    x = (sp.Integer(0),) + variables
    polys = {}
    for i, j, m in edges:
        assert m % lcm(d[i], d[j]) == 0
        if kind == 'raw':
            polys[i, j] = (x[j] - x[i]) ** m
        else:
            h = gcd(d[i], d[j])
            ui = x[i] if kind == 'valued' else x[i] ** d[i]
            uj = x[j] if kind == 'valued' else x[j] ** d[j]
            polys[i, j] = (uj ** (d[i] // h) - ui ** (d[j] // h)) ** (m // lcm(d[i], d[j]))
    generators = []
    forbidden = []
    for mask in range(1, (1 << (n+1)) - 1):
        S = {i for i in range(n+1) if mask >> i & 1}
        value = sum(theta[i] for i in S)
        assert value != 0, (theta, S)
        if value < 0:
            forbidden.append(sorted(S))
            generators.append(sp.expand(prod(polys[i, j] for i, j, m in edges if i in S and j not in S)))
    return variables, generators, forbidden


def quotient_character(variables, generators, weights, permutations):
    gb = sp.groebner(generators, *variables, order='grevlex')
    assert gb.is_zero_dimensional, 'Expected a nonempty Artinian quotient'
    leading = [tuple(f.LM(order=gb.order).exponents) for f in gb.polys]
    n = len(variables)
    standard = {(0,) * n}
    frontier = [(0,) * n]
    while frontier:
        a = frontier.pop()
        for i in range(n):
            b = tuple(v + int(j == i) for j, v in enumerate(a))
            if b in standard or any(all(v <= w for v, w in zip(lm, b)) for lm in leading):
                continue
            standard.add(b)
            frontier.append(b)
            assert len(standard) < 20000, 'Unexpectedly large check'
    standard = sorted(standard, key=lambda a: (sum(a), a))
    traces = []
    for sigma in permutations:
        trace = Counter()
        for a in standard:
            degree = sum(v*w for v, w in zip(a, weights))
            b = [0] * n
            for i, v in enumerate(a):
                b[sigma[i+1]-1] = v
            if tuple(b) in standard:
                coefficient = int(tuple(b) == a)
            else:
                monomial = prod(x ** v for x, v in zip(variables, b))
                remainder = sp.Poly(gb.reduce(monomial)[1], *variables)
                coefficient = remainder.coeff_monomial(a)
            trace[degree] += coefficient
        traces.append({int(k): int(v) for k, v in sorted(trace.items()) if v})
    return {'dimension': len(standard), 'traces': traces,
            'groebner_basis': [str(p.as_expr()) for p in gb.polys]}


def convolve(a, b):
    out = Counter()
    for i, u in a.items():
        for j, v in b.items():
            out[i+j] += u*v
    return {k: v for k, v in sorted(out.items()) if v}


def cycle_factor(d, sigma):
    unseen = set(range(1, len(d)))
    result = {0: 1}
    while unseen:
        i = min(unseen)
        cycle = []
        j = i
        while j not in cycle:
            cycle.append(j)
            unseen.remove(j)
            assert d[j] == d[i]
            j = sigma[j]
        result = convolve(result, {len(cycle)*a: 1 for a in range(d[i])})
    return result


def run_case(name, d, edges, theta, permutations):
    assert sum(theta) == 0
    edge_set = set(edges)
    for sigma in permutations:
        assert sigma[0] == 0
        assert all(d[sigma[i]] == d[i] and theta[sigma[i]] == theta[i] for i in range(len(d)))
        assert {(sigma[i], sigma[j], m) for i, j, m in edges} == edge_set
    results = {}
    for kind in ('valued', 'gain', 'raw'):
        variables, generators, forbidden = cut_generators(d, edges, theta, kind)
        weights = d[1:] if kind == 'valued' else [1] * (len(d)-1)
        results[kind] = quotient_character(variables, generators, weights, permutations)
    checks = []
    for k, sigma in enumerate(permutations):
        factor = cycle_factor(d, sigma)
        predicted = convolve(results['valued']['traces'][k], factor)
        assert predicted == results['gain']['traces'][k], (name, sigma, 'phase-freeness')
        assert predicted == results['raw']['traces'][k], (name, sigma, 'gain-LSOP')
        checks.append({'permutation': sigma, 'cycle_factor': factor,
                       'raw_trace': sum(results['raw']['traces'][k].values()),
                       'valued_trace': sum(results['valued']['traces'][k].values()),
                       'full_graded_character_agrees': True})
    return {'name': name, 'd': d, 'edges': edges, 'theta': theta,
            'forbidden_subsets': forbidden, 'quotients': results, 'checks': checks}


def main():
    cases = [
        ('weighted_star_S2', [1, 2, 2], [(0, 1, 4), (0, 2, 4)], [-2, 1, 1],
         [(0, 1, 2), (0, 2, 1)]),
        ('diamond_source_chamber_S2', [1, 2, 2, 3],
         [(0, 1, 4), (0, 2, 4), (0, 3, 3), (1, 3, 6), (2, 3, 6)],
         [-3, 1, 1, 1], [(0, 1, 2, 3), (0, 2, 1, 3)]),
        ('diamond_sink_chamber_S2', [1, 2, 2, 3],
         [(0, 1, 2), (0, 2, 2), (0, 3, 3), (1, 3, 6), (2, 3, 6)],
         [-1, -1, -1, 3], [(0, 1, 2, 3), (0, 2, 1, 3)]),
        ('diamond_mixed_chamber_S2', [1, 2, 2, 3],
         [(0, 1, 2), (0, 2, 2), (0, 3, 3), (1, 3, 6), (2, 3, 6)],
         [-3, -1, -1, 5], [(0, 1, 2, 3), (0, 2, 1, 3)]),
        ('three_distinct_weights', [1, 2, 3, 5],
         [(0, 1, 2), (0, 2, 3), (0, 3, 5), (1, 2, 6), (2, 3, 15)],
         [-3, 1, 1, 1], [(0, 1, 2, 3)])
    ]
    output = {'theorem': 'generic_framed_gain_LSOP', 'cases': []}
    for case in cases:
        result = run_case(*case)
        output['cases'].append(result)
        print(json.dumps({'name': result['name'], 'checks': result['checks']}), flush=True)
        Path(__file__).with_name('ramified_cut_character_results.json').write_text(json.dumps(output, indent=2))
    print('All exact graded character comparisons passed.', flush=True)


if __name__ == '__main__':
    main()
