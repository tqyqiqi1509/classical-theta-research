"""Exact commutative-algebra checks for unrooted gain cut curves.

The generators come solely from graph cuts and nonzero rational gains.
For every connected signed simple graph on <=4 vertices, verify the
gain-independent Hilbert numerator and every nonbridge deletion/contraction
sequence.  Groebner arithmetic is over QQ, not floating point.
"""

from collections import Counter
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
import json
import sympy as s


def connected(n, edges):
    seen = {0}
    while True:
        old = len(seen)
        for i, j, z in edges:
            if i in seen or j in seen:
                seen.update((i, j))
        if len(seen) == old:
            return len(seen) == n


def cut_generators(n, edges):
    w = s.symbols(f'w0:{n}')
    generators = []
    # Complementary cuts have the same factors, so use cuts containing 0.
    for mask in range(1, (1 << n)-1, 2):
        fs = [w[j]-z*w[i] for i, j, z in edges
              if bool(mask & (1 << i)) != bool(mask & (1 << j))]
        generators.append(s.expand(s.prod(fs)))
    return w, generators


def monomial_numerator(lms, n):
    # Exact multigraded Taylor numerator, coalescing identical l.c.m.s.
    terms = {(0,)*n: 1}
    for lm in lms:
        new = dict(terms)
        for a, coefficient in terms.items():
            b = tuple(max(x, y) for x, y in zip(a, lm))
            new[b] = new.get(b, 0)-coefficient
        terms = {a:c for a,c in new.items() if c}
    out = Counter()
    for a, c in terms.items():
        out[sum(a)] += c
    return {i:c for i,c in sorted(out.items()) if c}


@lru_cache(None)
def numerator(n, edges):
    w, generators = cut_generators(n, edges)
    if not generators:
        return {0: 1}
    gb = s.groebner(generators, *w, order='grevlex', domain=s.QQ)
    lms = [f.LM(order=gb.order).exponents for f in gb.polys]
    return monomial_numerator(lms, n)


def add(*items):
    out = Counter()
    for scalar, shift, p in items:
        for k, c in p.items():
            out[k+shift] += scalar*c
    return {i:c for i,c in sorted(out.items()) if c}


def contract(n, edges, edge):
    a, b, gain = edge
    representatives = [i for i in range(n) if i != b]
    relabel = {i:j for j,i in enumerate(representatives)}
    def vertex(i):
        return relabel[a if i == b else i]
    def factor(i):
        return gain if i == b else 1
    out = []
    removed = False
    for e in edges:
        if e == edge and not removed:
            removed = True
            continue
        i,j,z = e
        u,v = vertex(i), vertex(j)
        if u == v:
            continue  # loops do not enter any cut product
        znew = s.Rational(z)*factor(i)/factor(j)
        if u > v:
            u,v,znew = v,u,1/znew
        out.append((u,v,znew))
    return n-1, tuple(sorted(out))


def actual_contraction_map(n, edges, edge):
    a,b,z = edge
    w, generators = cut_generators(n, edges)
    new_n, new_edges = contract(n, edges, edge)
    new_w, new_generators = cut_generators(new_n, new_edges)
    keep = [i for i in range(n) if i != b]
    substitutions = {w[i]:new_w[j] for j,i in enumerate(keep)}
    substitutions[w[b]] = z*substitutions[w[a]]
    images = [s.expand(f.subs(substitutions, simultaneous=True)) for f in generators]
    if not new_generators:
        assert all(f == 0 for f in images)
        return
    gb_new = s.groebner(new_generators, *new_w, order='grevlex', domain=s.QQ)
    assert all(gb_new.reduce(f)[1] == 0 for f in images)
    nonzero = [f for f in images if f != 0]
    gb_image = s.groebner(nonzero, *new_w, order='grevlex', domain=s.QQ)
    assert all(gb_image.reduce(f)[1] == 0 for f in new_generators)


def main():
    counts = Counter()
    for n in range(2,5):
        pairs = list(combinations(range(n), 2))
        for states in product((0,1,-1), repeat=len(pairs)):
            edges = tuple((i,j,z) for (i,j),z in zip(pairs,states) if z)
            if not connected(n, edges):
                continue
            counts['graphs'] += 1
            full = numerator(n, edges)
            raw = tuple((i,j,1) for i,j,z in edges)
            assert full == numerator(n, raw), (n,edges,'gain Hilbert')
            counts['gain_hilbert_equalities'] += 1
            for index,e in enumerate(edges):
                deleted = edges[:index]+edges[index+1:]
                new_n, new_edges = contract(n, edges, e)
                actual_contraction_map(n,edges,e)
                counts['actual_quotient_map_equalities'] += 1
                if not connected(n, deleted):
                    continue
                # H_G=q H_(G-e)+H_(G/e); denominator power drops by one.
                rhs = add((1,1,numerator(n,deleted)),
                          (1,0,numerator(new_n,new_edges)),
                          (-1,1,numerator(new_n,new_edges)))
                assert full == rhs, (n,edges,e,'deletion contraction')
                counts['deletion_contraction_hilbert_equalities'] += 1
        print(json.dumps({'completed_n':n, **counts}), flush=True)
    q=s.symbols('q')
    polynomials=[1+3*q+4*q**2+4*q**3+3*q**4+q**5,
                 1+q+2*q**2+2*q**3+q**4+q**5,
                 1-q-q**4+q**5]
    denominators=[(1-q)*(1+q)**4,
                  (1-q)*(1+q)**2*(1+q**2),
                  (1-q)*(1+q**2)**2]
    normalized=[s.factor(p/d) for p,d in zip(polynomials,denominators)]
    degree_two=[int(s.series(f,q,0,3).removeO().coeff(q,2)) for f in normalized]
    char=[degree_two[0],degree_two[1],degree_two[1],degree_two[2]]
    mult=(char[0]-char[1]-char[2]+char[3])//4
    assert char == [2,2,2,-2] and mult == -1
    output={'arithmetic':'exact QQ Groebner bases and integer Hilbert numerators',
            'counts':dict(counts),
            'nongeneric_obstruction':{'normalized_rational_functions':list(map(str,normalized)),
                'degree_two_character':char,'double_sign_multiplicity':mult}}
    Path(__file__).with_name('gain_curve_contraction_results.json').write_text(json.dumps(output,indent=2))
    print(json.dumps(output),flush=True)


if __name__ == '__main__':
    main()
