"""All-cycle verification of the ordinary Gale framing-power mechanism.

Generic cut traces are computed independently by feasible trees on the
vertex-cycle quotient.  Attached traces then follow from the actual
core/attached factorization, retaining induced characters.  They are
compared with the full Cauchy power of determinant-one attached traces.
No theta coefficients are used in constructing either side.
"""

from collections import Counter
from functools import lru_cache
from itertools import combinations, product
from math import comb, gcd, prod
from pathlib import Path
import json
import time


def partitions(n, lower=1):
    if n == 0:
        yield ()
    else:
        for i in range(lower,n+1):
            for rest in partitions(n-i,i):
                yield (i,)+rest


def bezout_framing(a,b,kappa):
    for P in range(1,b+kappa+b):
        value=P*a-kappa
        if value>0 and value%b==0:
            return P,value//b
    raise AssertionError((a,b,kappa))


@lru_cache(None)
def cycle_subsets(lam):
    counts=sorted(Counter(lam).items())
    out=[]
    for chosen in product(*(range(c+1) for _,c in counts)):
        left=tuple(v for (v,c),r in zip(counts,chosen) for _ in range(r))
        right=tuple(v for (v,c),r in zip(counts,chosen) for _ in range(c-r))
        coefficient=prod(comb(c,r) for (_,c),r in zip(counts,chosen))
        out.append((left,right,coefficient))
    return tuple(out)


def stable_tree(n, chosen, theta):
    adj=[[] for _ in range(n)]
    for i,(u,v,m) in enumerate(chosen):
        adj[u].append((v,i));adj[v].append((u,i))
    degree=list(map(len,adj))
    if any(d==0 for d in degree):
        return False
    todo=[i for i,d in enumerate(degree) if d==1]
    values=list(theta)
    removed=[False]*n
    seen=0
    while todo:
        u=todo.pop()
        if removed[u] or degree[u]!=1:
            continue
        removed[u]=True;seen+=1
        remaining=[(v,e) for v,e in adj[u] if not removed[v]]
        if not remaining:
            continue
        v,e=remaining[0]
        tail,head,_=chosen[e]
        if (head==u and values[u]<=0) or (tail==u and values[u]>=0):
            return False
        values[v]+=values[u]
        degree[v]-=1
        if degree[v]==1:
            todo.append(v)
    return seen==n-1


@lru_cache(None)
def cut_trace(m,a,b,P,Q,la,lb,sign):
    A,B=sum(la),sum(lb)
    assert A*b==B*a
    k=A//a
    if k==0:
        return 1
    na,nb=len(la),len(lb)
    n=1+na+nb
    NA,NB=P+m*B,Q+m*A
    large=1+A*NA+B*NB
    theta=[-sign*k*(P*a-Q*b)]
    theta += [s*(b*large+sign*NA) for s in la]
    theta += [s*(-a*large-sign*NB) for s in lb]
    assert sum(theta)==0
    edges=[(0,1+i,P*s) for i,s in enumerate(la)]
    edges += [(1+na+j,0,Q*s) for j,s in enumerate(lb)]
    edges += [(1+na+j,1+i,m*r*s) for i,r in enumerate(la) for j,s in enumerate(lb)]
    total=0
    for chosen in combinations(edges,n-1):
        if stable_tree(n,chosen,theta):
            total+=prod(e[2] for e in chosen)
    divisor=prod(la)*prod(lb)
    assert total%divisor==0
    return total//divisor


@lru_cache(None)
def attached(m,a,b,P,Q,la,lb):
    A,B=sum(la),sum(lb)
    assert A*b==B*a
    k=A//a
    if k==0:
        return 1
    answer=cut_trace(m,a,b,P,Q,la,lb,1)-cut_trace(m,a,b,P,Q,la,lb,-1)
    for ca,da,wa in cycle_subsets(la):
        for cb,db,wb in cycle_subsets(lb):
            R=sum(ca)
            if not (0<R<A and R*b==sum(cb)*a):
                continue
            r=R//a
            answer-=wa*wb*cut_trace(m,a,b,P,Q,ca,cb,-1)*attached(
                m,a,b,P+m*r*b,Q+m*r*a,da,db)
    return answer


@lru_cache(None)
def power_character(m,a,b,kappa,la,lb):
    if kappa==0:
        return int(not la and not lb)
    P,Q=bezout_framing(a,b,1)
    if kappa==1:
        return attached(m,a,b,P,Q,la,lb)
    total=0
    for ca,da,wa in cycle_subsets(la):
        for cb,db,wb in cycle_subsets(lb):
            if sum(ca)*b!=sum(cb)*a:
                continue
            total+=wa*wb*power_character(m,a,b,kappa-1,ca,cb)*attached(m,a,b,P,Q,da,db)
    return total


def main():
    start=time.time()
    tests=[]
    for m in range(1,7):
        for kappa in range(1,m+1):
            for a,b in [(1,1),(1,2),(2,1),(1,3),(3,1),(2,3),(3,2)]:
                if gcd(a,b)!=1:
                    continue
                for k in range(1,7//(a+b)+1):
                    P,Q=bezout_framing(a,b,kappa)
                    for la in partitions(k*a):
                        for lb in partitions(k*b):
                            predicted=power_character(m,a,b,kappa,la,lb)
                            actual=attached(m,a,b,P,Q,la,lb)
                            shifted=attached(m,a,b,P+2*b,Q+2*a,la,lb)
                            assert actual==predicted==shifted,(m,kappa,a,b,k,la,lb,actual,predicted,shifted)
                            tests.append({'m':m,'kappa':kappa,'slope':[a,b],'k':k,'cycle_A':la,'cycle_B':lb,
                                          'attached_trace':actual,'cauchy_power_trace':predicted})
        print(json.dumps({'m_finished':m,'all_cycle_cases':len(tests)}),flush=True)
    small=[attached(1,1,1,2,1,la,lb) for la,lb in [((1,1),(1,1)),((1,1),(2,)),((2,),(1,1)),((2,),(2,))]]
    assert small==[6,4,4,2]
    output={'all_cycle_framing_power_cases':len(tests),'framing_shift_comparisons':len(tests),
            'all_passed':True,'seconds':time.time()-start,'ordinary_k2_character':small,'cases':tests}
    Path(__file__).with_name('gale_framing_power_results.json').write_text(json.dumps(output,indent=2))
    print(json.dumps({k:v for k,v in output.items() if k!='cases'}),flush=True)


if __name__=='__main__':
    main()
