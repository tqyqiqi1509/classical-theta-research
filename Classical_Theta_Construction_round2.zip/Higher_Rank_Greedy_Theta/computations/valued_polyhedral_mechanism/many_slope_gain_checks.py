"""Exact attached algebras for a genuine three-slope heterogeneous-gain input.

A=(1,0), B=(1,1), C=(0,1), eta=2 det, r=(-1,2,3),
theta=(-1,0,1), weights=(1,2,1).  AB/BC have gains {1,s},
whereas AC has two ordinary gain-one arrows.  Eliminate x_A using
x_A=-b^2 c^3.  The generic square system becomes F_s=0,T=unit*G_s.
Since gcd(F_s,G_s)=1, its horizontal attached algebra is (F_s,G_s).
The complete root-of-unity packet occurs at s=-1, with phase b -> -b.
No cut-ring or theta coefficient is substituted for this actual algebra.
"""
from collections import deque
from pathlib import Path
import json,time
import sympy as S

b,c,v=S.symbols('b c v')

def standard_monomials(gb, cap=200000):
    leading=[p.LM(order=gb.order).exponents for p in gb.polys]
    if (0,)*len(gb.gens) in leading:
        return []
    zero=(0,)*len(gb.gens)
    queue=deque([zero]); seen={zero}
    while queue:
        a=queue.popleft()
        for i in range(len(a)):
            nxt=list(a);nxt[i]+=1;nxt=tuple(nxt)
            if nxt in seen or any(all(x>=y for x,y in zip(nxt,l)) for l in leading):
                continue
            seen.add(nxt);queue.append(nxt)
            if len(seen)>cap:
                raise AssertionError('Quotient did not reach a finite standard basis')
    return sorted(seen)

def main():
    start=time.time();rows=[]
    for s in [1,-1,2,-2,3,S.Rational(2,3)]:
        F=S.expand(b**4*(1+b*c**3)*(1+s*b*c**3)-(c-b)*(c-s*b))
        G=S.expand((1+b*c**3)*(1+s*b*c**3)*(1+b*b*c*c)**2)
        assert S.gcd(F,G)==1
        gb=S.groebner([F,G],b,c,order='grevlex')
        mons=standard_monomials(gb)
        assert len(mons)==40,(s,len(mons))
        row={'gain_s':str(s),'dimension':len(mons),
             'groebner_leading_exponents':[p.LM(order=gb.order).exponents for p in gb.polys],
             'horizontal_gcd':str(S.gcd(F,G))}
        if s==-1:
            assert S.expand(F.subs(b,-b)-F)==0
            assert S.expand(G.subs(b,-b)-G)==0
            row['phase_trace']=sum((-1)**a for a,_ in mons)
            row['phase_invariant_dimension']=sum(a%2==0 for a,_ in mons)
            assert row['phase_trace']==0 and row['phase_invariant_dimension']==20
        rows.append(row)
        print(json.dumps(row),flush=True)
    Fv=v**2-v**3*c**6-c*c+v
    Gv=(1-v*c**6)*(1+v*c*c)**2
    gbv=S.groebner([Fv,Gv],v,c,order='grevlex')
    mv=standard_monomials(gbv)
    assert len(mv)==20
    A=1-v*c**6;B=1+v*c*c
    da=len(standard_monomials(S.groebner([Fv,A],v,c,order='grevlex')))
    db=len(standard_monomials(S.groebner([Fv,B],v,c,order='grevlex')))
    assert (da,db)==(8,6)
    # Original all-coordinate framing identity is an actual Laurent elimination.
    xa=S.symbols('xa')
    total_root=S.expand((-xa)-b*b*c**3)
    assert S.expand(total_root.subs(xa,-b*b*c**3))==0
    out={'all_passed':True,'ordinary_and_heterogeneous_gain_algebras':rows,
         'valued_attached_dimension':len(mv),'simple_divisor_lengths':[da,db],
         'phase_trace':0,'gain_to_valued_ratio':2,
         'whole_length_check':'8+2*6=20','seconds':time.time()-start}
    Path(__file__).with_name('many_slope_gain_results.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({k:v for k,v in out.items() if k!='ordinary_and_heterogeneous_gain_algebras'}),flush=True)

if __name__=='__main__':main()
