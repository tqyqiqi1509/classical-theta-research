"""Independent full-cycle checks for the global Young-species interface.

Tests all block profiles/cycle types in a bounded degree, comparing actual
cycle allocation with independent power-sum multiplication, exact induction,
literal label-set actions, and exterior/symmetric functor dimensions.
This is a structural character check, not a theta dimension comparison.
"""

from collections import Counter, defaultdict
from fractions import Fraction
from functools import cache
from itertools import product
from math import comb, factorial, prod
from pathlib import Path
import json
import time

from young_event_species import partitions, centralizer, young_trace, ordered_blocks


@cache
def h_product(profile):
    out = {(): Fraction(1)}
    for k in profile:
        nxt = defaultdict(Fraction)
        for a, x in out.items():
            for b in partitions(k):
                nxt[tuple(sorted(a + b, reverse=True))] += x / centralizer(b)
        out = dict(nxt)
    return out


def induced_trace(profile_a, profile_b, mu):
    multiplicities = sorted(Counter(mu).items())
    total = 0
    for selected in product(*(range(k + 1) for _, k in multiplicities)):
        if sum(j * s for (j, _), s in zip(multiplicities, selected)) != sum(profile_a):
            continue
        a = tuple(j for (j, _), s in zip(multiplicities, selected) for _ in range(s))
        b = tuple(j for (j, k), s in zip(multiplicities, selected) for _ in range(k - s))
        choices = prod(comb(k, s) for (_, k), s in zip(multiplicities, selected))
        total += choices * young_trace(profile_a, a) * young_trace(profile_b, b)
    return total


def representative(mu):
    p = list(range(sum(mu)))
    offset = 0
    for k in mu:
        for i in range(k):
            p[offset + i] = offset + (i + 1) % k
        offset += k
    return p


def main():
    started = time.time()
    stats = Counter()
    degree_cap = 16
    for n in range(degree_cap + 1):
        for profile in partitions(n):
            power_sum = h_product(profile)
            sign_inner = Fraction(0)
            for mu in partitions(n):
                trace = young_trace(profile, mu)
                expected = power_sum.get(mu, 0) * centralizer(mu)
                assert trace == expected, (profile, mu, trace, expected)
                sign_inner += Fraction((-1) ** (n - len(mu)) * trace, centralizer(mu))
                stats['full_cycle_trace_comparisons'] += 1
            assert sign_inner == int(all(k == 1 for k in profile)), (profile, sign_inner)
            stats['sign_isotypic_profiles'] += 1
            for rank in range(9):
                sym_rank = sum(value * rank ** len(mu) for mu, value in power_sum.items())
                ext_rank = sum(value * (-1) ** (n - len(mu)) * rank ** len(mu)
                               for mu, value in power_sum.items())
                sym_formula = prod(comb(rank + k - 1, k) if rank else 0 for k in profile)
                ext_formula = prod(comb(rank, k) if rank >= k else 0 for k in profile)
                assert sym_rank == sym_formula, (profile, rank, sym_rank, sym_formula)
                assert ext_rank == ext_formula, (profile, rank, ext_rank, ext_formula)
                stats['symmetric_exterior_rank_pairs'] += 1

    # The induction character is computed by distributing cycles between two
    # child label sets, independently of the flattened leaf-slot recursion.
    for n in range(1, 7):
        for m in range(1, 7):
            for a in partitions(n):
                for b in partitions(m):
                    for mu in partitions(n + m):
                        assert induced_trace(a, b, mu) == young_trace(a + b, mu), (a, b, mu)
                        stats['cauchy_induction_cycle_checks'] += 1

    # Literal finite sets, not just two character formulas.
    for n in range(8):
        for profile in partitions(n):
            points = tuple(ordered_blocks(tuple(range(n)), profile))
            assert len(points) == factorial(n) // prod(factorial(k) for k in profile)
            for mu in partitions(n):
                p = representative(mu)
                count = sum(all(frozenset(p[x] for x in block) == block for block in point)
                            for point in points)
                assert count == young_trace(profile, mu), (profile, mu, count)
                stats['literal_set_action_cycle_checks'] += 1
                stats['literal_point_action_checks'] += len(points)

    result = {
        'scope': 'all Young profiles/cycle types through degree16; exact Cauchy induction of all pairs through child degree6; literal label actions through degree7',
        'checks': dict(stats), 'all_passed': True,
        'elapsed_seconds': round(time.time() - started, 3),
        'distinctions': [
            'Tests full characters, not only identity dimensions',
            'Sign multiplicity equals free-orbit count only because stabilizers are Young',
            'Cauchy induction is separately exact and uses distinguished slots',
            'No cohomological grading or canonical flag-change intertwiner is inferred']
    }
    destination = Path(__file__).with_name('young_event_species_results.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
