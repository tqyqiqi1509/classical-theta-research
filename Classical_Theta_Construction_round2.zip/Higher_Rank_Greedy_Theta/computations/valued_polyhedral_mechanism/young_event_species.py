"""Finite Young species from distinguished, original-color event leaf slots.

This module implements the representation interface, not the construction of
event/Dyck skeletons.  A producer supplies Skeleton objects with distinguished
slots.  The exact cycle trace is computed without constructing permutation
matrices or inferring dimensions from theta coefficients.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from functools import cache
from itertools import combinations, product
from math import comb, factorial, prod
from typing import Hashable, Iterable, Iterator


@cache
def partitions(n: int, largest: int | None = None) -> tuple[tuple[int, ...], ...]:
    if n < 0:
        return ()
    if n == 0:
        return ((),)
    if largest is None:
        largest = n
    return tuple((j,) + q for j in range(min(n, largest), 0, -1)
                 for q in partitions(n - j, j))


def centralizer(mu: tuple[int, ...]) -> int:
    return prod(j ** k * factorial(k) for j, k in Counter(mu).items())


@cache
def _cycle_allocations(capacities: tuple[int, ...], cycles: tuple[int, ...]) -> int:
    if not cycles:
        return int(not capacities)
    length = cycles[0]
    result = 0
    for cap, multiplicity in Counter(capacities).items():
        if cap < length:
            continue
        nxt = list(capacities)
        nxt.remove(cap)
        if cap > length:
            nxt.append(cap - length)
        # Equal remaining capacities represent distinct slots.  Their
        # multiplicity is retained before canonicalizing the state.
        result += multiplicity * _cycle_allocations(
            tuple(sorted(nxt, reverse=True)), cycles[1:])
    return result


def young_trace(profile: Iterable[int], cycle_type: Iterable[int]) -> int:
    """Trace on ordered set partitions with these distinguished block sizes."""
    lam = tuple(sorted((int(k) for k in profile if k), reverse=True))
    mu = tuple(sorted((int(k) for k in cycle_type if k), reverse=True))
    if any(k < 0 for k in lam + mu):
        raise ValueError("Block and cycle sizes must be positive")
    if sum(lam) != sum(mu):
        return 0
    return _cycle_allocations(lam, mu)


def ordered_blocks(labels: tuple[Hashable, ...], sizes: tuple[int, ...]
                   ) -> Iterator[tuple[frozenset[Hashable], ...]]:
    """The actual finite set on a label tuple; order inside a block is absent."""
    if len(set(labels)) != len(labels) or sum(sizes) != len(labels):
        raise ValueError("Distinct labels and matching total size are required")
    if not sizes:
        yield ()
        return
    if sizes[0] <= 0:
        raise ValueError("Nonempty leaf blocks are required")
    for index_set in combinations(range(len(labels)), sizes[0]):
        selected = set(index_set)
        first = frozenset(labels[j] for j in index_set)
        rest = tuple(x for j, x in enumerate(labels) if j not in selected)
        for tail in ordered_blocks(rest, sizes[1:]):
            yield (first,) + tail


@dataclass(frozen=True)
class LeafBlock:
    color: int
    size: int
    slot: Hashable

    def __post_init__(self):
        if self.color < 0 or self.size <= 0:
            raise ValueError("Use nonnegative original colors and positive sizes")


@dataclass(frozen=True)
class Skeleton:
    key: Hashable
    leaves: tuple[LeafBlock, ...]
    colors: int

    def __post_init__(self):
        if self.colors < 0 or any(l.color >= self.colors for l in self.leaves):
            raise ValueError("Color outside the specified color set")
        if len({l.slot for l in self.leaves}) != len(self.leaves):
            raise ValueError("Every leaf occurrence needs a distinct slot tag")

    @property
    def profile(self) -> tuple[tuple[int, ...], ...]:
        return tuple(tuple(l.size for l in self.leaves if l.color == i)
                     for i in range(self.colors))

    @property
    def content(self) -> tuple[int, ...]:
        return tuple(sum(p) for p in self.profile)

    @property
    def dimension(self) -> int:
        return prod(factorial(sum(p)) // prod(factorial(k) for k in p)
                    for p in self.profile)

    def trace(self, cycle_types: tuple[tuple[int, ...], ...]) -> int:
        if len(cycle_types) != self.colors:
            raise ValueError("One cycle type per original color is required")
        return prod(young_trace(p, mu) for p, mu in zip(self.profile, cycle_types))

    @property
    def sign_multiplicity(self) -> int:
        return int(all(l.size == 1 for l in self.leaves))

    def functor_dimension(self, dimensions: tuple[int, ...], *, exterior: bool) -> int:
        if len(dimensions) != self.colors or any(m < 0 for m in dimensions):
            raise ValueError("One nonnegative dimension per original color")
        if exterior:
            return prod(comb(dimensions[l.color], l.size)
                        if dimensions[l.color] >= l.size else 0 for l in self.leaves)
        return prod(comb(dimensions[l.color] + l.size - 1, l.size)
                    if dimensions[l.color] else 0 for l in self.leaves)

    def points(self, labels: tuple[tuple[Hashable, ...], ...]):
        if tuple(map(len, labels)) != self.content:
            raise ValueError("Labels must have the skeleton's color content")
        return product(*(ordered_blocks(I, p) for I, p in zip(labels, self.profile)))


class YoungEventModule:
    """A direct sum of the finite permutation modules of supplied skeletons."""

    def __init__(self, skeletons: Iterable[Skeleton], *, content: tuple[int, ...]):
        self.skeletons = tuple(skeletons)
        self.content = content
        if any(s.content != content for s in self.skeletons):
            raise ValueError("All skeletons must have the same original content")
        if len({s.key for s in self.skeletons}) != len(self.skeletons):
            raise ValueError("Disjoint-union summands need distinct tags")

    @property
    def dimension(self) -> int:
        return sum(s.dimension for s in self.skeletons)

    @property
    def sign_multiplicity(self) -> int:
        return sum(s.sign_multiplicity for s in self.skeletons)

    def trace(self, cycle_types: tuple[tuple[int, ...], ...], *, sign_twist=False) -> int:
        value = sum(s.trace(cycle_types) for s in self.skeletons)
        return value * ((-1) ** sum(n - len(mu)
                        for n, mu in zip(self.content, cycle_types)) if sign_twist else 1)

    @property
    def young_orbit_table(self) -> dict[tuple[tuple[int, ...], ...], int]:
        return dict(Counter(tuple(tuple(sorted(p, reverse=True)) for p in s.profile)
                            for s in self.skeletons))

    def frobenius_power_sum(self, *, sign_twist=False):
        out = {}
        for mus in product(*(partitions(n) for n in self.content)):
            value = Fraction(self.trace(mus, sign_twist=sign_twist),
                             prod(centralizer(mu) for mu in mus))
            if value:
                out[mus] = value
        return out


def graft_skeletons(key: Hashable, children: tuple[Skeleton, ...]) -> Skeleton:
    """The leaf-set flattening of colored Cauchy composition.

    Child positions are distinguished. This is not a quotient by permutations
    of isomorphic children. The nested label decomposition is uniquely recovered
    from unions of the leaf blocks in each child.
    """
    if not children:
        raise ValueError("Specify a zero-object separately if there are no children")
    colors = children[0].colors
    if any(c.colors != colors for c in children):
        raise ValueError("Original color sets must agree")
    return Skeleton(key, tuple(LeafBlock(l.color, l.size, (a, l.slot))
                               for a, child in enumerate(children)
                               for l in child.leaves), colors)


def skeleton_from_flattened_event(tree: dict, key: Hashable, colors: int) -> Skeleton:
    """Attach the actual external-label functor to a literal flattened object.

    The input is produced by computations/flatten_dyck_objects.py.  Its ordered
    child addresses distinguish leaf occurrences; no automorphism quotient is
    introduced.  The key only distinguishes direct-sum summands.
    """
    leaves = []

    def visit(node, address):
        if node['kind'] == 'leaf':
            tag = node['leaf_tag']
            leaves.append(LeafBlock(tag[1], tag[2] if len(tag) > 2 else 1, address))
            return
        for i, child in enumerate(node['children']):
            visit(child, address + (i,))

    visit(tree, ())
    result = Skeleton(key, tuple(leaves), colors)
    if result.content != tuple(tree['charge']):
        raise ValueError("Leaf content disagrees with the flattened event charge")
    return result


