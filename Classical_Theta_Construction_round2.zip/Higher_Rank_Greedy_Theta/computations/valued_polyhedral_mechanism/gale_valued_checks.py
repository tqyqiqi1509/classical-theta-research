"""Exact arithmetic and genuine attached-ring checks for the valued Gale theorem.

The arithmetic sweep checks every subset of thousands of primitive slope
inputs, rather than sampling coefficient values.  The algebra sweep forms
actual localized attached complete intersections for one particle of each
color; it does not prescribe their vector-space dimensions.
"""

from math import gcd, lcm
from pathlib import Path
from random import Random
import json
import time
import sympy as sp


def egcd(a,b):
    if b == 0:
        return a,1,0
    g,x,y = egcd(b,a%b)
    return g,y,x-(a//b)*y


def framing(da,db,a,b):
    kap,p,z=egcd(da*a,db*b)
    q=-z
    dp=db*b//kap
    dq=da*a//kap
    shift=max(0, (1-p+dp-1)//dp, (1-q+dq-1)//dq)
    p+=shift*dp
    q+=shift*dq
    return kap, da*p, db*q


def standard_dimension(gb,n):
    lm=[f.LM(order=gb.order).exponents for f in gb.polys]
    bounds=[]
    for i in range(n):
        pure=[e[i] for e in lm if e[i]>0 and sum(e)==e[i]]
        assert pure
        bounds.append(min(pure))
    from itertools import product
    return sum(not any(all(a>=b for a,b in zip(e,l)) for l in lm)
               for e in product(*(range(b) for b in bounds)))


def binary_ring(da,db,multiple):
    kap,P,Q=framing(da,db,1,1)
    ell=lcm(da,db)
    t,u,v=sp.symbols('t u v')
    first=u**(P//da)-(-1)**Q*v**(Q//db)
    second=(u**(ell//da)-v**(ell//db))**multiple
    # This is precisely (first,second):(uv)^infinity.
    gb=sp.groebner([first,second,1-t*u*v],t,u,v,order='lex',domain=sp.QQ)
    ideal=[f.as_expr() for f in gb.polys if not f.as_expr().has(t)]
    reduced=sp.groebner(ideal,u,v,order='grevlex',domain=sp.QQ)
    dim=standard_dimension(reduced,2)
    assert dim==multiple
    return {'d':[da,db],'framing':[P,Q],'kappa':kap,'mixed_multiplicity':ell*multiple,
            'computed_dimension':dim,'expected_binary_weight':ell*multiple*kap//(da*db),
            'localized_groebner_basis':[str(f.as_expr()) for f in reduced.polys]}


def main():
    start=time.time()
    rng=Random(261113)
    subset_checks=0
    center_checks=0
    input_count=12000
    max_subset=0
    for _ in range(input_count):
        da,db=rng.randint(1,24),rng.randint(1,24)
        a,b=rng.randint(1,11),rng.randint(1,11)
        while gcd(a,b)!=1:
            a,b=rng.randint(1,11),rng.randint(1,11)
        k=rng.randint(1,8)
        kap,P,Q=framing(da,db,a,b)
        ell=lcm(da,db)
        m=ell*rng.randint(1,4)
        assert ell%kap==0 and P%da==0 and Q%db==0
        assert P*a-Q*b==kap and P>0 and Q>0
        NA,NB=P+m*k*b,Q+m*k*a
        assert NA>kap*k*b
        for u in range(k*a+1):
            for v in range(k*b+1):
                if u==v==0:
                    continue
                delta=b*u-a*v
                d0=NA*u-NB*v
                assert b*d0==NA*delta+kap*v
                assert d0!=0
                if delta:
                    assert d0*delta>0
                else:
                    assert u%a==0 and v%b==0 and u//a==v//b
                    assert d0==kap*(u//a)
                subset_checks+=1
                max_subset=max(max_subset,u+v)
        sigma=(Q*b*ell+m*a*b*(k-1))%2
        for h in range(1,k+1):
            exponent=(Q*b*h*ell+m*a*b*h*(k-h))%2
            assert exponent==(sigma*h)%2
            P2,Q2=P+m*h*b,Q+m*h*a
            assert P2*a-Q2*b==kap and P2%da==0 and Q2%db==0
            # Full-gain decoupling changes only a constant target sign.
            target_sign=((m//ell-m)*h*a)%2
            assert target_sign in (0,1)
            center_checks+=1
    rings=[binary_ring(da,db,mult) for da in range(1,7) for db in range(1,7)
           for mult in (1,2,3)]
    output={'primitive_slope_inputs':input_count,'all_subset_sign_and_integrality_checks':subset_checks,
            'uniform_nonzero_center_and_shift_checks':center_checks,'largest_subset_cardinality':max_subset,
            'actual_localized_attached_ring_checks':len(rings),'all_passed':True,
            'seconds':time.time()-start,'binary_ring_data':rings}
    Path(__file__).with_name('gale_valued_checks_results.json').write_text(json.dumps(output,indent=2))
    print(json.dumps({k:v for k,v in output.items() if k!='binary_ring_data'}),flush=True)


if __name__=='__main__':
    main()
