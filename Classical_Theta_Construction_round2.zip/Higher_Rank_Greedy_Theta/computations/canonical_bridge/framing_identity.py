"""Independent two-layer versus one-framing recurrence checks.

This verifies conventions and zero faces; the proof is in
agents/ONE_FRAMING_COEFFICIENT_THEOREM.md.  No positivity is used in the test.
"""
import json
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "agents"))
from incoming_recursion import IncomingSchur, box


def framed(B, D, g):
    return [[0] + [-g[i] * D[i] for i in range(len(g))]] + [
        [g[i]] + list(B[i]) for i in range(len(g))
    ]


def run():
    started = time.time()
    rng = random.Random(261113913)
    cases = []
    total = 0
    zero_faces = 0
    sign_tests = 0
    for n, samples in [(2, 14), (3, 12), (4, 8)]:
        cap = (3, 3) if n == 2 else ((2, 2, 2) if n == 3 else (1, 1, 1, 1))
        for sample in range(samples):
            D = [1] * n if sample % 2 == 0 else [rng.randrange(1, 4) for _ in range(n)]
            B = [[0] * n for _ in range(n)]
            for i in range(n):
                for j in range(i + 1, n):
                    t = rng.randrange(-2, 3)
                    B[i][j], B[j][i] = D[j] * t, -D[i] * t
            g = tuple(rng.randrange(-3, 4) for _ in range(n))
            R = IncomingSchur(B, D)
            BH = framed(B, D, g)
            H = IncomingSchur(BH, [1] + D)
            old = R.theta_prefix(g, cap)
            nonzero = 0
            for p in box(cap):
                a = H.c((1,) + p, (-1,) + (0,) * n)
                assert a == old.get(p, 0), (B, D, g, p, a, old.get(p, 0))
                nonzero += bool(a)
                total += 1
                mp = R.shift(g, p)
                for q in box(p):
                    if q == p:
                        continue
                    h = sum(mp[i] * D[i] * (p[i] - q[i]) for i in range(n))
                    sg = H.sign((1,) + p, (1,) + q)
                    assert (sg > 0) == (h < 0), (B, D, g, p, q, h, sg)
                    zero_faces += h == 0
                    sign_tests += 1
            cases.append({"B": B, "D": D, "g": g, "cap": cap,
                          "coefficient_checks": len(box(cap)), "nonzero": nonzero})
    return {"status": "PASS", "seed": 261113913, "cases": cases,
            "coefficient_checks": total, "halfspace_sign_checks": sign_tests,
            "exact_zero_face_checks": zero_faces,
            "seconds": round(time.time() - started, 3)}


if __name__ == "__main__":
    result = run()
    path = Path(__file__).with_name("framing_identity_results.json")
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, indent=2))
