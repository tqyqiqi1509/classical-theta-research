"""Test the explicit framed squarefree W=0 shuffle-quotient candidate.

The quotient is defined before its dimension is computed.  This test locates
the extra incoming-information problem in a concrete finite ideal.
"""
import json
import sys
from itertools import product
from pathlib import Path
import sympy as sp

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'agents'))
from incoming_recursion import IncomingSchur


def cut_quotient(B, g):
    n = len(B)
    BH = [[0] + [-x for x in g]] + [[g[i]] + B[i] for i in range(n)]
    A = [[max(-x, 0) for x in row] for row in BH]
    variables = sp.symbols(f'z1:{n+1}')
    z = (sp.Integer(0),) + variables
    generators = []
    for mask in range(1, 1 << n):
        S = [i+1 for i in range(n) if mask >> i & 1]
        T = [j for j in range(n+1) if j not in S]
        generators.append(sp.prod((z[v]-z[u])**A[u][v] for u in S for v in T))
    G = sp.groebner(generators, *variables)
    leading = [tuple(p.LM(order=G.order).exponents) for p in G.polys]
    standard = {(0,)*n}
    frontier = [(0,)*n]
    while frontier:
        exponent = frontier.pop()
        for i in range(n):
            nxt = tuple(exponent[j] + int(i == j) for j in range(n))
            if nxt in standard:
                continue
            if not any(all(a <= b for a,b in zip(lm,nxt)) for lm in leading):
                standard.add(nxt)
                frontier.append(nxt)
            assert len(standard) < 100000, 'Candidate appears non-Artinian'
    theta = IncomingSchur(B).theta_prefix(tuple(g), (1,)*n).get((1,)*n, 0)
    return {'B': B, 'g': g, 'generators': list(map(str, generators)),
            'groebner_basis': [str(p.as_expr()) for p in G.polys],
            'is_zero_dimensional': G.is_zero_dimensional,
            'quotient_dimension': len(standard), 'theta_coefficient': theta,
            'standard_monomials': sorted(standard, key=lambda a:(sum(a),a)),
            'agrees': len(standard) == theta}


if __name__ == '__main__':
    cases = [cut_quotient([[0,r,-r],[-r,0,r],[r,-r,0]],[-1,-1,-1]) for r in [1,2]]
    result = {'status': 'NAIVE_QUOTIENT_REFUTED', 'cases': cases}
    Path(__file__).with_name('squarefree_cut_quotient_results.json').write_text(
        json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps([{k:c[k] for k in ['B','quotient_dimension','theta_coefficient','agrees']}
                      for c in cases], indent=2))
