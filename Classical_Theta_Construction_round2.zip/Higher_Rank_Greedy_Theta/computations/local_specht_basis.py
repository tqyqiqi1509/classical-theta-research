"""Construct the local labels in the positive tree/tableau model.

The input is a flow graph, equal-child groups, and Young diagrams.  All local
labels are actual rational intertwiners between standard polytabloid matrices
and the graph's minimal-extension matrices.  Theta coefficients, character
averages, and dimensions supplied by another oracle are not construction data.
"""
from pathlib import Path
import sys, json, time
from itertools import combinations, permutations, product
from functools import lru_cache
from math import prod
import sympy as sp

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'computations'/'intrinsic_partition_model'),
              str(ROOT/'computations')]
from global_matrix_module import LocalModule, sparse_data
from orbit_schur_positive import partitions, character, tableau_count


def perm_sign(p):
    return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))


@lru_cache(None)
def standard_tableaux(shape):
    """Rows of standard tableaux, with the labels 0,...,n-1."""
    n=sum(shape)
    if not n:return ((),)
    out=[]
    for i,a in enumerate(shape):
        if i+1<len(shape) and a==shape[i+1]:continue
        small=list(shape);small[i]-=1
        if not small[i]:small.pop(i)
        for t in standard_tableaux(tuple(small)):
            rows=[list(r) for r in t]
            if i==len(rows):rows.append([])
            rows[i].append(n-1)
            out.append(tuple(tuple(r) for r in rows))
    return tuple(sorted(out))


@lru_cache(None)
def tabloids(shape):
    def rec(remaining,sizes):
        if not sizes:
            yield ();return
        for row in combinations(remaining,sizes[0]):
            selected=set(row)
            tail=tuple(a for a in remaining if a not in selected)
            for rest in rec(tail,sizes[1:]):yield (row,)+rest
    return tuple(rec(tuple(range(sum(shape))),shape))


class SpechtModule:
    def __init__(self,shape):
        self.shape=tuple(shape);self.n=sum(shape)
        self.tableaux=standard_tableaux(self.shape)
        self.tabloids=tabloids(self.shape);self.index={t:i for i,t in enumerate(self.tabloids)}
        E=sp.zeros(len(self.tabloids),len(self.tableaux))
        for j,T in enumerate(self.tableaux):
            columns=[tuple(row[c] for row in T if c<len(row))
                     for c in range(self.shape[0] if self.shape else 0)]
            choices=[tuple(permutations(range(len(c)))) for c in columns]
            for maps in product(*choices):
                p=list(range(self.n));sign=1
                for c,s in zip(columns,maps):
                    sign*=perm_sign(s)
                    for k,a in enumerate(c):p[a]=c[s[k]]
                tab=tuple(tuple(sorted(p[a] for a in row)) for row in T)
                E[self.index[tab],j]+=sign
        self.embedding=E;self.dimension=E.cols
        self.pivot_rows=tuple(E.T.rref()[1])
        assert len(self.pivot_rows)==self.dimension
        self.left_inverse=E[list(self.pivot_rows),:].inv()
        self.action=lru_cache(None)(self._action)

    def _action(self,p):
        assert sorted(p)==list(range(self.n))
        PE=sp.zeros(*self.embedding.shape)
        for i,tab in enumerate(self.tabloids):
            target=tuple(tuple(sorted(p[a] for a in row)) for row in tab)
            PE[self.index[target],:]=self.embedding[i,:]
        A=self.left_inverse*PE[list(self.pivot_rows),:]
        assert self.embedding*A==PE
        return A

    def adjacent(self,k):
        p=list(range(self.n));p[k],p[k+1]=k+1,k
        return self.action(tuple(p))


def tensor_matrices(mats):
    return sp.kronecker_product(*mats) if mats else sp.ones(1)


def local_multiplicity_basis(eta,groups,shapes):
    """A finite, ordered RREF basis of Hom_{prod S_m}(Specht_shapes,L_eta).

    The returned matrices have rows in the independently constructed local
    fan module and columns in the standard polytabloid tensor basis.
    """
    eta=tuple(tuple(a) for a in eta);groups=tuple(tuple(g) for g in groups)
    shapes=tuple(tuple(s) for s in shapes)
    assert sorted(a for g in groups for a in g)==list(range(len(eta)))
    assert all(sum(s)==len(g) for s,g in zip(shapes,groups))
    local=LocalModule(eta);spechts=[SpechtModule(s) for s in shapes]
    dims=[s.dimension for s in spechts];f=prod(dims);d=local.dimension
    equations=[];generators=[]
    for j,g in enumerate(groups):
        for k in range(len(g)-1):
            cp=list(range(len(eta)));a,b=g[k:k+2];cp[a],cp[b]=b,a
            A=local.action(tuple(cp))
            mats=[sp.eye(x) for x in dims];mats[j]=spechts[j].adjacent(k)
            S=tensor_matrices(mats)
            equations.append(sp.kronecker_product(sp.eye(f),A)-sp.kronecker_product(S.T,sp.eye(d)))
            generators.append((tuple(cp),A,S))
    E=sp.Matrix.vstack(*equations) if equations else sp.zeros(0,d*f)
    kernel=E.nullspace()
    basis=[sp.Matrix(d,f,lambda i,j:v[j*d+i]) for v in kernel]
    assert all(A*M==M*S for cp,A,S in generators for M in basis)
    return {'basis':basis,'local':local,'spechts':spechts,'equations':E,
            'generators':generators,'multiplicity':len(basis)}


def main():
    start=time.time();specht_checks=[]
    # A distinct, character-theoretic check of the explicit polytabloid matrices.
    for n in range(1,6):
        for shape in partitions(n):
            S=SpechtModule(shape);ok=True
            for mu in partitions(n):
                p=list(range(n));off=0
                for k in mu:
                    for j in range(k):p[off+j]=off+(j+1)%k
                    off+=k
                ok &= int(S.action(tuple(p)).trace())==character(shape,mu)
            gens=[S.adjacent(k) for k in range(n-1)]
            ok &= all(A*A==sp.eye(S.dimension) for A in gens)
            ok &= all(gens[i]*gens[i+1]*gens[i]==gens[i+1]*gens[i]*gens[i+1]
                      for i in range(n-2))
            assert ok
            specht_checks.append({'shape':shape,'dimension':S.dimension,'pass':ok})
    # K22,2 is non-simple and its double-swap trace is zero.  All four
    # multiplicity spaces must be obtained from matrices, including the zero one.
    eta=((0,0,2,2),(0,0,2,2),(-2,-2,0,0),(-2,-2,0,0))
    rows=[]
    for a,b in product(((2,),(1,1)),repeat=2):
        r=local_multiplicity_basis(eta,((0,1),(2,3)),(a,b))
        row={'shapes':(a,b),'local_dimension':r['local'].dimension,
             'multiplicity':r['multiplicity'],
             'basis':[sparse_data(M) for M in r['basis']],
             'equation_shape':r['equations'].shape}
        rows.append(row)
        print(json.dumps({k:v for k,v in row.items() if k!='basis'}),flush=True)
    assert [r['multiplicity'] for r in rows]==[8,4,4,0]
    # Three equal star leaves give a genuinely two-dimensional Specht module.
    eta_star=((0,3,3,3),(-3,0,0,0),(-3,0,0,0),(-3,0,0,0))
    star=local_multiplicity_basis(eta_star,((0,),(1,2,3)),((1,),(2,1)))
    assert star['multiplicity']==tableau_count((2,1),3)==8
    star_record={'shapes':((1,),(2,1)),'dimension':star['local'].dimension,
                 'multiplicity':star['multiplicity'],
                 'basis':[sparse_data(M) for M in star['basis']],
                 'equation_shape':star['equations'].shape}
    data={'specht_checks':specht_checks,'K22_2':rows,'star_3':star_record,
          'seconds':time.time()-start,'all_checks_passed':True}
    Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2))
    print(json.dumps({'specht_shapes_checked':len(specht_checks),
                     'K22_multiplicities':[r['multiplicity'] for r in rows],
                     'star_21_multiplicity':star['multiplicity'],
                     'seconds':data['seconds']}),flush=True)


if __name__=='__main__':main()
