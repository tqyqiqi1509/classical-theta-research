"""Sparse rational-polytope recipes with compressed ordinary framing slots.

Framed local births reuse the actual slot-word rule from
fast_framed_spine.  Unframed births use SparsePolytopeObjects, including
occupied normal-copy positions and sparse edge/endpoint coordinates.
The construction never calls cardinality or scans a literal Dyck path.
See proofs/FRAMED_SPINE_SPARSE_BOUND.md for the general dimension proof.
"""
from math import comb
from pathlib import Path
from unittest.mock import patch
import json
import time

from dyck_object_factory import DyckObjects
from fast_framed_spine import FastFramedSpineObjects, SlotSets
from global_sparse_polytope_recipe import SparsePolytopeObjects, SparseSets
from sparse_position_polytopes import Polytope
from theta_multiplication_objects import ThetaMultiplicationObjects
from universal_dyck_object_factory import UniversalDyckObjects


class FramedSparseSets(SlotSets, SparseSets):
    """Both kinds of occupied positions are explicit matrix polytopes."""

    def selected_slots(self, size, occupied):
        assert size >= 0 and occupied >= 0
        if occupied > size:
            return 0
        if occupied == 0:
            return 1
        variables = tuple(('framed_slot', i) for i in range(occupied))
        inequalities = []
        for i in range(occupied):
            lower, upper = [0]*occupied, [0]*occupied
            lower[i], upper[i] = -1, 1
            inequalities.append((tuple(lower), 0))
            inequalities.append((tuple(upper), size-1))
        for i in range(occupied-1):
            row = [0]*occupied
            row[i], row[i+1] = 1, -1
            inequalities.append((tuple(row), -1))
        poly = Polytope(variables, inequalities, [],
                        {'kind': 'framed_slots', 'slots': size,
                         'occupied': occupied, 'coordinate_origin': 0})
        return self.polytope(('framed_slots', size, occupied), poly)

    def _cardinality(self, identifier):
        node = self.nodes[identifier]
        if node[0] == 'polytope':
            meta = self.polytopes[node[1]].metadata
            if meta.get('kind') == 'framed_slots':
                self.cardinality_queries += 1
                return comb(meta['slots'], meta['occupied'])
        return super()._cardinality(identifier)


class FastFramedSparseObjects(FastFramedSpineObjects, SparsePolytopeObjects):
    """Universal elementary leaves; sparse unframed and framed factories.

    The MRO is intentional: FastFramedSpineObjects.two_inputs delegates
    an unframed pair through super() to SparsePolytopeObjects.two_inputs.
    Its slot-power routine accepts FramedSparseSets as a SlotSets.
    """
    _count = UniversalDyckObjects._count

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.sets = FramedSparseSets()


class OrdinaryFastFramedSparseObjects(FastFramedSparseObjects):
    """Ordinary cluster specialization: only unit original leaves."""
    _count = DyckObjects._count


def export_multiplication(B, D, g1, g2, p, output_path=None):
    """Construct and export the complete recipe before evaluating it."""
    start = time.monotonic()
    model = ThetaMultiplicationObjects(
        B, D, g1, g2, factory=OrdinaryFastFramedSparseObjects)
    # Any accidental delegation back to the literal factory must fail.
    with patch('dyck_object_factory.tight_profiles',
               side_effect=AssertionError('Literal path scan forbidden')):
        root = model.coefficient(tuple(p))
    assert model.sets.cardinality_queries == 0
    recipe = model.sets.export(root)
    dimension = model.sets.dimension_bound(root)
    bound = 9*sum(p)-8 if any(p) else 0
    assert dimension <= bound, (dimension, bound)
    construction_seconds = time.monotonic()-start
    recipe['input'] = {'B': B, 'D': D, 'g1': g1, 'g2': g2, 'p': p,
                       'output_label': model.output_label(p)}
    recipe['construction'] = {
        'definition_calls_cardinality': False,
        'definition_enumerates_gradings': False,
        'maximum_piece_ambient_dimension': dimension,
        'proved_uniform_bound': bound,
        'construction_seconds': construction_seconds,
        'unframed_backend': 'SparsePolytopeObjects',
        'framed_backend': 'ordinary slot word with position inequalities'}
    if output_path is not None:
        Path(output_path).write_text(json.dumps(recipe, separators=(',', ':')))
    # Numerical evaluation is a separate operation on the completed recipe.
    value = model.sets.cardinality(root)
    kinds = {}
    for poly in recipe['polytopes'].values():
        kind = poly['metadata'].get('kind', 'sparse_path')
        kinds[kind] = kinds.get(kind, 0)+1
    return {'degree': tuple(p), 'lattice_point_count': value,
            'maximum_piece_ambient_dimension': dimension,
            'proved_uniform_bound': bound,
            'reachable_recipe_nodes': recipe['reachable_nodes'],
            'reachable_polytopes': recipe['reachable_polytopes'],
            'polytope_kinds': kinds,
            'construction_seconds': construction_seconds,
            'seconds': time.monotonic()-start,
            'factor_statistics': [dict(m.stats) for m in model.factors],
            'recipe_file': str(output_path) if output_path is not None else None,
            'definition_calls_cardinality': False,
            'literal_path_scan_forbidden': True}


def main():
    B, D = [[0, 2, -1], [-1, 0, 1], [1, -2, 0]], [1, 2, 1]
    g1, g2, p = (-1, -1, 1), (-1, 2, 2), (1, 1, 0)
    recipe_path = Path(__file__).with_name('fast_framed_sparse_recipe.json')
    report = export_multiplication(B, D, g1, g2, p, recipe_path)
    # Reuse the established literal/signed-matrix multiplication fixture.
    expected = 3
    assert report['lattice_point_count'] == expected
    assert report['maximum_piece_ambient_dimension'] <= 10
    # The preceding endpoint fixture has only framed nodes.  Check the
    # other MRO branch using the already established nonprimitive local
    # fixture (1,0),(1,2), K=det, with an inert zero frame prepended.
    local = OrdinaryFastFramedSparseObjects(
        [[0, 0, 0], [0, 0, 1], [0, -1, 0]], [1, 1, 1])
    F = {1: local.sets.tag(('fixture_left_decoration',))}
    G = {1: local.sets.tag(('fixture_right_decoration',))}
    with patch('dyck_object_factory.tight_profiles',
               side_effect=AssertionError('Literal path scan forbidden')):
        outputs = local.two_inputs(
            ((0, 1, 0), F, 'a', False),
            ((0, 1, 2), G, 'b', False), (0, 2, 2))
    local_root = next(H[1] for carrier, H, _, _ in outputs
                      if carrier == (0, 2, 2))
    assert local.sets.cardinality_queries == 0
    local_recipe = local.sets.export(local_root)
    assert any(p['metadata'].get('kind') == 'normal_slots'
               for p in local_recipe['polytopes'].values())
    assert any('r' in p['metadata']
               for p in local_recipe['polytopes'].values())
    assert local.sets.cardinality(local_root) == 4
    local_path = Path(__file__).with_name('fast_framed_sparse_unframed_fixture.json')
    local_path.write_text(json.dumps(local_recipe, separators=(',', ':')))
    report['unframed_backend_check'] = {
        'established_fixture': 'nonprimitive local parents (1,0),(1,2)',
        'lattice_point_count': 4,
        'maximum_piece_ambient_dimension': local.sets.dimension_bound(local_root),
        'reachable_polytopes': local_recipe['reachable_polytopes'],
        'normal_and_path_matrix_blocks_present': True,
        'definition_calls_cardinality': False,
        'literal_path_scan_forbidden': True,
        'recipe_file': str(local_path)}
    report.update({'status': 'PASS', 'established_fixture_count': expected,
                   'integration': 'complete framed and unframed matrix recipe'})
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
