"""Compile actual tight-path comparison cells into integer interval bounds.

The compiler uses only cyclic paths, integer totals and division rules.
The checks compare its full lattice-point fibres with an independent
literal grading enumeration, including cell-boundary cases.
"""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json
import time

from tight_grading_two_input import (dyck_word, compositions,
                                    bezout_rectangle, is_tight)


def comparisons(word):
    E = [i for i, c in enumerate(word) if c == 'E']
    V = [i for i, c in enumerate(word) if c == 'N']
    eindex, vindex = {x:i for i,x in enumerate(E)}, {x:i for i,x in enumerate(V)}
    horizontal, vertical = [], []
    for e in E:
        for v in V:
            path=[]; t=e
            while True:
                path.append(t)
                if t == v: break
                t=(t+1) % len(word)
            ei=tuple(eindex[t] for t in path if word[t]=='E')
            vi=tuple(vindex[t] for t in path if word[t]=='N')
            horizontal.append((ei,len(vi)))
            vertical.append((vi,len(ei)))
    # Zero/positive edge decisions are part of the signature.
    horizontal += [((i,),0) for i in range(len(E))]
    vertical += [((i,),0) for i in range(len(V))]
    return E,V,horizontal,vertical


def sign(x): return (x>0)-(x<0)


def signature(weights, divisor, tests):
    return tuple(sign(divisor*sum(weights[i] for i in interval)-constant)
                 for interval, constant in tests)


def compile_cell(length, total, divisor, tests, signs):
    """Return integral (start,end,lower,upper) interval constraints.

    Variables are nonnegative with fixed total, so every interval sum
    initially lies in [0,total]. None denotes an immediately empty cell.
    """
    bounds={}
    for (indices,constant),sgn in zip(tests,signs):
        if len(indices)==length:
            if sign(divisor*total-constant)!=sgn: return None
            continue
        if not indices:
            if sign(-constant)!=sgn: return None
            continue
        start=indices[0]; end=start+len(indices)
        assert indices==tuple(i % length for i in range(start,end))
        if end>length:
            # The wrapping interval is total minus its ordinary complement.
            start,end=end-length,start
            constant=divisor*total-constant
            sgn=-sgn
        lower,upper=bounds.get((start,end),(0,total))
        if sgn<0:
            upper=min(upper,(constant-1)//divisor)
        elif sgn>0:
            lower=max(lower,constant//divisor+1)
        else:
            if constant % divisor: return None
            lower=max(lower,constant//divisor)
            upper=min(upper,constant//divisor)
        if lower>upper: return None
        bounds[start,end]=(lower,upper)
    return tuple((a,b,lo,hi) for (a,b),(lo,hi) in sorted(bounds.items()))


def belongs(weights,cell):
    return cell is not None and all(lo<=sum(weights[a:b])<=hi
                                   for a,b,lo,hi in cell)


def grading(word,h,v,u,vdiv):
    hi=vi=0; out=[]
    for edge in word:
        if edge=='E': out.append(u*h[hi]);hi+=1
        else: out.append(vdiv*v[vi]);vi+=1
    return tuple(out)


def check_case(A,B,k,u,v):
    r,s=bezout_rectangle(A,B,k)
    assert k*B % u == k*A % v == 0
    H,V=k*B//u,k*A//v
    word=dyck_word(r,s)
    E,N,htests,vtests=comparisons(word)
    hvalues=compositions(H,r); vvalues=compositions(V,s)
    hgroups=defaultdict(list);vgroups=defaultdict(list)
    for h in hvalues:hgroups[signature(h,u,htests)].append(h)
    for w in vvalues:vgroups[signature(w,v,vtests)].append(w)
    hcells={sig:compile_cell(r,H,u,htests,sig) for sig in hgroups}
    vcells={sig:compile_cell(s,V,v,vtests,sig) for sig in vgroups}
    assert all(cell is not None for cell in hcells.values())
    assert all(cell is not None for cell in vcells.values())
    # These are independent integer-point enumerations of the compiled
    # interval regions, not another evaluation of the original tests.
    for sig,cell in hcells.items():
        assert tuple(h for h in hvalues if belongs(h,cell))==tuple(hgroups[sig])
    for sig,cell in vcells.items():
        assert tuple(w for w in vvalues if belongs(w,cell))==tuple(vgroups[sig])
    accepted=0;points=0;largest=0;sample=None
    for hs,vs in product(hgroups,vgroups):
        answers={is_tight(word,grading(word,h,w,u,v))
                 for h,w in product(hgroups[hs],vgroups[vs])}
        assert len(answers)==1, 'path tests were not constant on a comparison cell'
        if True in answers:
            size=len(hgroups[hs])*len(vgroups[vs])
            accepted+=1;points+=size;largest=max(largest,size)
            if sample is None or size>sample['lattice_points']:
                sample={'horizontal_interval_bounds':hcells[hs],
                        'vertical_interval_bounds':vcells[vs],
                        'lattice_points':size}
    direct=sum(is_tight(word,grading(word,h,w,u,v))
               for h,w in product(hvalues,vvalues))
    assert points==direct
    return {'parameters':{'A':A,'B':B,'k':k,'u':u,'v':v},
            'rectangle':[r,s],'normalized_totals':[H,V],
            'candidate_integer_gradings':len(hvalues)*len(vvalues),
            'comparison_cells':len(hgroups)*len(vgroups),
            'accepted_cells':accepted,'tight_lattice_points':points,
            'largest_accepted_cell_count':largest,'sample_cell':sample}


def main():
    start=time.monotonic()
    cases=[(1,1,2,1,1),(1,1,3,1,1),(2,1,1,1,1),
           (1,2,1,1,1),(2,3,1,3,2),(1,1,4,2,2),
           (1,1,6,3,3),(2,1,2,1,2),(3,2,1,2,3)]
    results=[check_case(*case) for case in cases]
    report={'status':'PASS','results':results,'seconds':time.monotonic()-start,
            'candidate_integer_gradings':sum(r['candidate_integer_gradings'] for r in results),
            'comparison_cells':sum(r['comparison_cells'] for r in results),
            'accepted_cells':sum(r['accepted_cells'] for r in results)}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
    print(json.dumps([{'parameters':r['parameters'],'tight':r['tight_lattice_points'],
                       'largest_cell':r['largest_accepted_cell_count']} for r in results]))


if __name__=='__main__':main()
