"""Positive finite event-flag grammar, using actual bounded Dyck gradings.

Definition: agents/valued_global_assembly.md, Sections 1--7.
The only imported coefficient operation enumerates tight Dyck gradings.
The incoming-normalized integer recursion is used solely in main(), as an
independent comparison oracle, never by the event grammar.
"""
from collections import Counter
from functools import lru_cache, cmp_to_key
from fractions import Fraction as Q
from itertools import product
from math import gcd
from pathlib import Path
import json
import sys
import time

from tight_grading_two_input import valued_profiles, evaluate_profile


def add(a,b): return tuple(x+y for x,y in zip(a,b))
def scale(k,a): return tuple(k*x for x in a)
def le(a,b): return all(x<=y for x,y in zip(a,b))
def sign(x): return (x>0)-(x<0)
def prim(a):
    d=gcd(*a)
    return tuple(x//d for x in a)
def box(a):
    return sorted(product(*(range(x+1) for x in a)),key=lambda x:(sum(x),x))
def scalar(a,b): return sum(x*y for x,y in zip(a,b))


@lru_cache(None)
def local_profiles(K,wa,wb,wgamma,a,b,n):
    return valued_profiles(K,wa,wb,wgamma,a,b,n)[0]


def poly_mul(A,B,cap):
    C=Counter()
    for i,x in A.items():
        for j,y in B.items():
            if i+j<=cap: C[i+j]+=x*y
    return dict(C)


class EventFlags:
    def __init__(self,B,D,max_swaps=None):
        self.B=tuple(map(tuple,B));self.D=tuple(D);self.r=len(D)
        assert all(D[i]*B[i][j]==-D[j]*B[j][i]
                   for i in range(self.r) for j in range(self.r))
        self.K=tuple(tuple(D[i]*B[i][j] for j in range(self.r))
                     for i in range(self.r))
        self.max_swaps=max_swaps
        self.stats=Counter()
        self.count=lru_cache(None)(self._count)
        self.pair=lru_cache(None)(self._pair)
        self.weight=lru_cache(None)(self._weight)

    def _pair(self,a,b):
        return sum(a[i]*self.K[i][j]*b[j]
                   for i in range(self.r) for j in range(self.r))

    def _weight(self,a): return gcd(*(self.D[i]*a[i] for i in range(self.r)))

    def eta_row(self,a):
        return tuple(-sum(a[i]*self.K[i][j] for i in range(self.r))
                     for j in range(self.r))

    def evaluate_covector(self,theta,a):
        return tuple(sum(a[i]*theta[i][h] for i in range(self.r))
                     for h in range(len(theta[0])))

    @staticmethod
    def lexsign(v):
        return next((sign(x) for x in v if x),0)

    def plane_key(self,a,b):
        w=tuple(a[i]*b[j]-a[j]*b[i]
                for i in range(self.r) for j in range(i+1,self.r))
        d=gcd(*w)
        w=tuple(x//d for x in w)
        if next(x for x in w if x)<0: w=tuple(-x for x in w)
        return w

    def in_plane(self,T,S,b):
        i,j=next((i,j) for i in range(self.r) for j in range(i+1,self.r)
                 if S[i]*b[j]!=S[j]*b[i])
        d=S[i]*b[j]-S[j]*b[i]
        x=Q(T[i]*b[j]-T[j]*b[i],d)
        y=Q(S[i]*T[j]-S[j]*T[i],d)
        return all(T[h]==x*S[h]+y*b[h] for h in range(self.r))

    def events(self,S,theta):
        result={};er=self.eta_row(S)
        for b in box(S):
            if not any(b) or b==S:continue
            e=scalar(er,b)
            if not e:continue
            tau=tuple(-x/e for x in self.evaluate_covector(theta,b))
            if self.lexsign(tau)<=0:continue
            key=self.plane_key(S,b)
            q=tuple(tuple(theta[i][h]+tau[h]*er[i]
                          for h in range(len(tau))) for i in range(self.r))
            if key in result:
                assert q==result[key][2]
            else:result[key]=(b,tau,q)
        return [(key,*result[key]) for key in sorted(result)]

    def incoming_theta(self,q,rho):
        er=self.eta_row(rho)
        return tuple(tuple(q[i])+(Q(er[i]),) for i in range(self.r))

    def two_inputs(self,A,B,S):
        a,F,aid,aborn=A;b,G,bid,bborn=B
        K=self.pair(a,b);assert K>0
        acap=min(S[i]//a[i] for i in range(self.r) if a[i])
        bcap=min(S[i]//b[i] for i in range(self.r) if b[i])
        outputs=[]
        for u in range(1,acap+1):
            for v in range(1,bcap+1):
                if gcd(u,v)>1:continue
                gamma=add(scale(u,a),scale(v,b))
                if not le(gamma,S):continue
                ncap=min(S[i]//gamma[i] for i in range(self.r) if gamma[i])
                H={}
                for n in range(1,ncap+1):
                    profile=local_profiles(K,self.weight(a),self.weight(b),
                                           self.weight(gamma),u,v,n)
                    h=evaluate_profile(profile,F,G)
                    assert h>=0
                    if h:H[n]=h
                if H:
                    newid=(aid,bid,u,v)
                    outputs.append((gamma,H,newid,True))
                    self.stats['born_factors']+=1
        outputs.sort(key=cmp_to_key(lambda A,B:sign(self.pair(A[0],B[0]))))
        return outputs

    def sort_word(self,inputs,S):
        word=[(rho,F,('initial',j),False)
              for j,(rho,F) in enumerate(inputs) if F]
        word.sort(key=cmp_to_key(lambda A,B:-sign(self.pair(A[0],B[0]))))
        exchanges=0
        while True:
            i=next((i for i in range(len(word)-1)
                    if self.pair(word[i][0],word[i+1][0])>0),None)
            if i is None:break
            A=word[i];B=word[i+1]
            new=self.two_inputs(A,B,S)
            word[i:i+2]=[B]+new+[A]
            exchanges+=1
            if self.max_swaps is not None and exchanges>self.max_swaps:
                raise RuntimeError('explicit max_swaps resource bound exceeded')
        self.stats['word_exchanges']+=exchanges
        self.stats['max_word_length']=max(self.stats['max_word_length'],len(word))
        return word

    def born_ray(self,inputs,S):
        word=self.sort_word(inputs,S)
        rho=prim(S);cap=gcd(*S);out={0:1}
        for carrier,F,identifier,born in word:
            if not born or prim(carrier)!=rho:continue
            power=gcd(*carrier)
            part={0:1}
            part.update({power*j:c for j,c in F.items() if power*j<=cap})
            out=poly_mul(out,part,cap)
        return out

    def _count(self,S,theta):
        self.stats['states']+=1
        assert not any(self.evaluate_covector(theta,S))
        rho=prim(S);cap=gcd(*S)
        axis=sum(x!=0 for x in rho)==1
        answer={0:1,1:1} if axis else {0:1}
        for key,b,tau,q in self.events(S,theta):
            self.stats['events']+=1
            rays={}
            for T in box(S):
                if not any(T) or T==S or not self.in_plane(T,S,b):continue
                rhoT=prim(T)
                incoming=self.incoming_theta(q,rhoT)
                c=self.count(T,incoming)
                if c:rays.setdefault(rhoT,{})[gcd(*T)]=c
            factor=self.born_ray(sorted(rays.items()),S)
            answer=poly_mul(answer,factor,cap)
        return answer.get(cap,0)

    def framed_theta(self,g,p):
        assert self.r==len(g)+1
        n=len(g);S=(1,)+tuple(p)
        theta=[]
        theta.append((Q(-sum(p)),)+tuple(Q(-x) for x in p))
        for i in range(n):
            theta.append((Q(1),)+tuple(Q(i==j) for j in range(n)))
        return self.count(S,tuple(theta))


def extended_data(B,D,g):
    n=len(D)
    out=[[0]+[-g[i]*D[i] for i in range(n)]]
    out += [[g[i]]+list(B[i]) for i in range(n)]
    return out,[1]+list(D)


def main():
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agents'))
    from incoming_recursion import IncomingSchur
    start=time.monotonic();results=[]
    cases=[
        ('A2',[[0,1],[-1,0]],[1,1],(-1,0),(1,1)),
        ('A2_2',[[0,1],[-1,0]],[1,1],(-2,1),(2,1)),
        ('B2',[[0,2],[-1,0]],[1,2],(-2,1),(1,1)),
        ('phase_mixing',[[0,2],[-1,0]],[1,2],(-6,2),(2,2)),
        ('cyclic_skew',[[0,1,-1],[-1,0,1],[1,-1,0]],[1,1,1],(-2,-1,1),(1,1,1)),
        ('cyclic_valued',[[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],(-3,-2,1),(1,1,1)),
    ]
    for name,B,D,g,p in cases:
        t=time.monotonic();Bhat,Dhat=extended_data(B,D,g)
        R=EventFlags(Bhat,Dhat)
        actual=R.framed_theta(g,p)
        oracle=IncomingSchur(B,D).theta_prefix(g,p).get(tuple(p),0)
        row={'name':name,'B':B,'D':D,'g':g,'p':p,
             'actual_tight_grading_count':actual,'independent_integer_oracle':oracle,
             'stats':dict(R.stats),'seconds':time.monotonic()-t}
        results.append(row)
        print(json.dumps(row),flush=True)
        assert actual==oracle,(name,actual,oracle)
        Path(__file__).with_suffix('.json').write_text(json.dumps(
            {'status':'RUNNING','results':results,'seconds':time.monotonic()-start},indent=2))
    result={'status':'PASS','results':results,
            'local_profile_cache':str(local_profiles.cache_info()),
            'seconds':time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
