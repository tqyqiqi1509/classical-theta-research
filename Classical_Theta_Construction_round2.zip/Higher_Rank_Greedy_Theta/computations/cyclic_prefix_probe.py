"""Exact prefixes aimed at the uniform cyclic-family finiteness question."""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agents'))
from incoming_recursion import IncomingRecursion

def main():
    weight=int(sys.argv[1]); cap=int(sys.argv[2]); started=time.time()
    B=[[0,weight,-weight],[-weight,0,weight],[weight,-weight,0]]
    R=IncomingRecursion(B)
    F=R.theta_prefix((-1,0,0),(cap,cap,cap))
    out={'B':B,'g':[-1,0,0],'cap':[cap]*3,
         'terms':[{'p':p,'coefficient':a} for p,a in sorted(F.items())],
         'nonnegative':all(a>=0 for a in F.values()),'mass':sum(F.values()),
         'zero_residual_checks':R.zero_residual_checks,'cache':str(R.c.cache_info()),
         'seconds':time.time()-started,
         'interpretation':'finite exact prefix only; no inference of global termination'}
    target=Path(__file__).with_name(f'cyclic_weight_{weight}_cap_{cap}.json')
    target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='terms'}),flush=True)

if __name__=='__main__':main()
