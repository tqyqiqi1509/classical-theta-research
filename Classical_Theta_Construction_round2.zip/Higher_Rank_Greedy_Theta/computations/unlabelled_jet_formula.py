"""Direct charge/tree + positive Schur recursion with exact local Laurent jets.

All local characters come from the finite support/partition formula. This
is a faster evaluation of the existing graph/fan/tableau object cardinality,
not a replacement of its independent object definition by a theta oracle.
"""
from pathlib import Path
from functools import lru_cache
import sys,json,time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from unlabelled_charge_partitions import ChargeOrbitSchurModel
from local_primitive_laurent_jets import LocalPrimitiveJets


@lru_cache(None)
def jet_local_trace(eta,sigma):
    return LocalPrimitiveJets(len(eta)).trace(eta,sigma)


class JetChargeOrbitSchurModel(ChargeOrbitSchurModel):
    trace_function=staticmethod(jet_local_trace)


def main():
    # Cyclic graphs, several simultaneous child types, and large arrow
    # multiplicities exercise the new general computational interface.
    cases=[
        ([[0,2,-3],[-2,0,2],[3,-2,0]],(-3,3,-2),(2,2,1)),
        ([[0,3,-2],[-3,0,2],[2,-2,0]],(-5,1,-1),(2,2,1)),
        ([[0,202,-303],[-202,0,202],[303,-202,0]],(-303,303,-202),(2,2,1)),
        ([[0,2,-3],[-2,0,2],[3,-2,0]],(-6,3,-4),(3,3,2)),
        ([[0,2,-1,1],[-2,0,3,-2],[1,-3,0,2],[-1,2,-2,0]],(-4,1,-3,2),(2,2,2,1)),
    ]
    results=[]
    for B,g,p in cases:
        start=time.time();model=JetChargeOrbitSchurModel(B,g,p)
        value,contributions=model.coefficient();construction_seconds=time.time()-start
        # Independent theta comparison is deliberately performed last.
        sys.path.insert(0,str(HERE.parent/'agents'))
        from incoming_recursion import IncomingSchur
        expected=IncomingSchur(B,[1]*len(B)).theta_prefix(g,p).get(p,0)
        row={'B':B,'g':g,'p':p,'coefficient':value,'independent_theta':expected,
             'tree_orbits':len(model.root_types),'labelled_tree_count':model.labelled_tree_count,
             'orbit_contributions':contributions,'direct_charge_statistics':model.model.statistics(),
             'local_trace_cache':str(jet_local_trace.cache_info()),
             'construction_seconds':construction_seconds,'all_seconds':time.time()-start,
             'pass':value==expected}
        results.append(row);Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2))
        print(json.dumps(row),flush=True)
        assert row['pass']


if __name__=='__main__':main()
