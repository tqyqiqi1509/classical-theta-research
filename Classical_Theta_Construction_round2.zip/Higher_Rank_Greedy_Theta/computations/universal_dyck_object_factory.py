"""Literal original-elementary coefficient objects for the valued grammar.

The only extension of DyckObjects is the initial alphabet: coefficient k
of axis i is one actual leaf (i,k), of charge k*e_i.  Union branches are
still literal tight gradings, never coefficient-sized placeholder sets.
The complete finite-set recipe is built before its profile is evaluated.
"""
from collections import Counter
from functools import lru_cache
from itertools import product
from math import gcd
from pathlib import Path
import json
import time

from dyck_object_factory import DyckObjects, set_series_multiply
from valued_event_flag_grammar import extended_data, box, prim


class UniversalDyckObjects(DyckObjects):
    def _count(self, S, theta):
        self.stats['states'] += 1
        assert not any(self.evaluate_covector(theta, S))
        rho, cap = prim(S), gcd(*S)
        answer = {0: 1}
        if sum(x != 0 for x in rho) == 1:
            color = next(i for i, x in enumerate(rho) if x)
            answer.update({k: self.sets.tag(('original_axis_leaf', color, k))
                           for k in range(1, cap+1)})
        for key, b, tau, q in self.events(S, theta):
            self.stats['events'] += 1
            rays = {}
            for T in box(S):
                if not any(T) or T == S or not self.in_plane(T, S, b):
                    continue
                rhoT = prim(T)
                child = self.count(T, self.incoming_theta(q, rhoT))
                if child != 0:
                    rays.setdefault(rhoT, {})[gcd(*T)] = child
            factor = self.born_ray(sorted(rays.items()), S)
            tagged = {j: self.sets.tag(('event', S, key, j), value) if j else value
                      for j, value in factor.items()}
            answer = set_series_multiply(answer, tagged, cap, self.sets)
        covector = tuple(tuple(str(x) for x in row) for row in theta)
        return self.sets.tag(('state', S, covector), answer.get(cap, 0))


def leaf_profiles(sets, root):
    """Evaluate a completed recipe, counting its actual leaf multisets."""
    @lru_cache(None)
    def evaluate(identifier):
        node = sets.nodes[identifier]
        kind = node[0]
        if kind == 'empty':
            return Counter()
        if kind == 'unit':
            return Counter({(): 1})
        if kind == 'tag':
            if node[1][0] == 'original_axis_leaf':
                label = node[1]
                k = label[2] if len(label) == 3 else 1
                assert node[2] == 1
                return Counter({((label[1], k),): 1})
            return evaluate(node[2])
        if kind == 'union':
            result = Counter()
            for child in node[1]:
                result.update(evaluate(child))
            return result
        if kind == 'product':
            result = Counter({(): 1})
            for child in node[1]:
                next_result = Counter()
                for a, x in result.items():
                    for b, y in evaluate(child).items():
                        next_result[tuple(sorted(a+b))] += x*y
                result = next_result
            return result
        raise ValueError(kind)
    return evaluate(root)


def elementary_partition_profile(profile, rank, remove_frame=True):
    result = Counter()
    for leaf_multiset, multiplicity in profile.items():
        colors = [[] for _ in range(rank)]
        for color, k in leaf_multiset:
            colors[color].append(k)
        if remove_frame:
            assert colors[0] == [1]
            colors = colors[1:]
        result[tuple(tuple(sorted(c, reverse=True)) for c in colors)] += multiplicity
    return result


def main():
    # These checks run after construction; none of these coefficient
    # algorithms or serialized coefficient values are used by the factory.
    from valued_event_formal_profiles import FormalEventFlags, remove_frame, records
    from valued_event_formal_profiles import GeneralizedSchur, EPoly
    start = time.monotonic()
    source = json.loads(Path(__file__).with_name('valued_event_formal_profiles.json').read_text())
    results = []
    for case in source['results']:
        B, D, g, p = case['B'], case['D'], tuple(case['g']), tuple(case['p'])
        Bhat, Dhat = extended_data(B, D, g)
        model = UniversalDyckObjects(Bhat, Dhat)
        root = model.framed_theta(g, p)
        nodes_after_construction = len(model.sets.nodes)
        profile = leaf_profiles(model.sets, root)
        actual = elementary_partition_profile(profile, model.r)
        # Independent formal positive computation and signed incoming one.
        positive = remove_frame(FormalEventFlags(Bhat, Dhat).framed_theta(g, p))
        signed = GeneralizedSchur(B, D).theta_prefix(g, p).get(
            p, EPoly.scalar(0, len(D)))
        assert actual == positive.t == signed.t
        assert len(model.sets.nodes) == nodes_after_construction
        count = model.sets.cardinality(root)
        assert count == sum(profile.values())
        ordinary_key = tuple((1,)*k for k in p)
        ordinary = actual.get(ordinary_key, 0)
        rows = [{'partitions': [list(c) for c in mon], 'coefficient': value}
                for mon, value in sorted(actual.items())]
        record = {'name': case['name'], 'B': B, 'D': D, 'g': g, 'p': p,
                  'literal_recipe_nodes': nodes_after_construction,
                  'root_recipe': root, 'universal_cardinality': count,
                  'ordinary_coefficient': ordinary, 'leaf_profile': rows,
                  'formal_event_profile_equal': True,
                  'signed_incoming_profile_equal': True,
                  'construction_calls_cardinality': False}
        results.append(record)
        print(json.dumps({k: record[k] for k in
              ('name', 'literal_recipe_nodes', 'universal_cardinality',
               'ordinary_coefficient')}), flush=True)
    report = {'status': 'PASS', 'cases': len(results), 'results': results,
              'seconds': time.monotonic()-start,
              'definition_uses_coefficient_oracle': False}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({'status': report['status'], 'cases': report['cases'],
                      'seconds': report['seconds']}))


if __name__ == '__main__':
    main()
