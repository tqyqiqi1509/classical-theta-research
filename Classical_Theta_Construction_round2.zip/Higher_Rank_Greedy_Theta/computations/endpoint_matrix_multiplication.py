"""Independent signed-matrix verification of endpoint theta multiplication.

This does not call the Dyck event grammar. It factors the finite incoming
operator into its negative/positive charge matrices, transports the
initial theta column, and compares endpoint products to triangular
theta-basis multiplication. Intended to test the arbitrary-endpoint
and output-label conventions in the two-framing theorem.
"""
from pathlib import Path
from collections import Counter
from functools import lru_cache
import sys, json, time, random

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'agents'))
from incoming_recursion import IncomingSchur, box, le, sub


class EndpointMatrices:
    def __init__(self, B, D):
        self.R = IncomingSchur(B, D)
        self.initial = lru_cache(None)(self.R.theta_prefix)
        self.at = lru_cache(None)(self._at)
        self.entries = 0

    def _at(self, g, cap, base):
        J = box(cap)
        # U=base+epsilon_1 e_1+...; every nonzero positive charge
        # on the base hyperplane has positive infinitesimal evaluation.
        A = {(q,q):1 for q in J}
        Cplus = {(q,q):1 for q in J}
        intervals = sorted(((p,q) for p in J for q in J if p!=q and le(q,p)),
                           key=lambda pq:(sum(sub(*pq)),pq))
        for p,q in intervals:
            alpha = sub(p,q)
            cross = sum(A.get((p,r),0)*Cplus.get((r,q),0)
                        for r in J if r!=p and r!=q and le(q,r) and le(r,p))
            residual = self.R.c(alpha,self.R.shift(g,q))-cross
            target = A if sum(x*y for x,y in zip(base,alpha)) < 0 else Cplus
            if residual:
                target[p,q] = residual
            self.entries += 1
        f = self.initial(g,cap)
        answer = {}
        for p in J:
            value = f.get(p,0)-sum(A.get((p,q),0)*answer.get(q,0)
                                  for q in J if q!=p and le(q,p))
            assert value >= 0, ('negative endpoint coefficient',g,cap,base,p,value)
            if value:
                answer[p] = value
        return answer

    def multiplication(self, g1, g2, cap):
        J = box(cap)
        f1, f2 = self.initial(g1,cap), self.initial(g2,cap)
        gg = tuple(x+y for x,y in zip(g1,g2))
        result = {}
        records = []
        for p in J:
            raw = sum(f1.get(a,0)*f2.get(sub(p,a),0) for a in J if le(a,p))
            coefficient = raw
            for q,c in result.items():
                if q!=p and le(q,p):
                    shifted = self.R.shift(gg,q)
                    coefficient -= c*self.initial(shifted,sub(p,q)).get(sub(p,q),0)
            assert coefficient >= 0
            if coefficient:
                result[p] = coefficient
            h = self.R.shift(gg,p)
            base = tuple(d*x for d,x in zip(self.R.D,h))
            e1,e2 = self.at(g1,p,base),self.at(g2,p,base)
            endpoint = sum(e1.get(a,0)*e2.get(sub(p,a),0) for a in box(p))
            assert endpoint == coefficient, (self.R.B,g1,g2,p,endpoint,coefficient)
            records.append({'degree':p,'output_label':h,'endpoint_product':endpoint,
                            'triangular_structure_constant':coefficient})
        return records


def main():
    start=time.monotonic()
    rng=random.Random(2611131531)
    cases=[
        ('rank_one',[[0]],[1],(5,)),
        ('A2',[[0,1],[-1,0]],[1,1],(2,2)),
        ('B2',[[0,2],[-1,0]],[1,2],(2,2)),
        ('cyclic_skew',[[0,2,-1],[-2,0,1],[1,-1,0]],[1,1,1],(1,1,1)),
        ('cyclic_valued',[[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],(2,1,1)),
        ('rank_four',[[0,1,-1,0],[-1,0,2,-1],[1,-2,0,1],[0,1,-1,0]],
         [1,1,1,1],(1,1,1,1)),
    ]
    rows=[]
    comparisons=entries=0
    for name,B,D,cap in cases:
        model=EndpointMatrices(B,D)
        pairs=[]
        for _ in range(4):
            g1=tuple(rng.randrange(-2,3) for _ in D)
            g2=tuple(rng.randrange(-2,3) for _ in D)
            records=model.multiplication(g1,g2,cap)
            comparisons+=len(records)
            pairs.append({'g1':g1,'g2':g2,'coefficients':records})
        entries+=model.entries
        row={'name':name,'B':B,'D':D,'cap':cap,'pairs':pairs,
             'signed_matrix_entries':model.entries}
        rows.append(row)
        print(json.dumps({'case':name,'status':'PASS','entries':model.entries}),flush=True)
    result={'status':'PASS','independent_signed_matrix_entries':entries,
            'structure_constant_comparisons':comparisons,'cases':rows,
            'seconds':time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='cases'}),flush=True)


if __name__=='__main__':
    main()
