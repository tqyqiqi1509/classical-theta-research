"""Fusion-label growth commutes with an actual valued ABC rectangle move.

The normal pattern is (1,1,d), so the two-level factory data exist
without any coplanarity assumption on the three input carriers.
"""
from pathlib import Path
import json,random,time

from valued_three_factor_coherence import to_cell,from_cell
from dyck_three_factor_coherence import literal_grading
from tight_grading_two_input import is_tight


def forward(i,j,d,q,r):
    if j<q:return 'R1',j,i+d*r
    if i<d*q:return 'R1',i//d,d*(j-q)+i%d
    return 'R2',j-q,i-d*q


def backward(branch,i,j,d,q,r):
    if branch=='R2':return j+d*q,i+q
    if j>=d*r:return j-d*r,i
    return d*i+j%d,q+j//d


def main():
    start=time.monotonic();params=points=growth=actual=literal=0
    rng=random.Random(2611131552)
    for d in range(1,9):
      for q in range(1,9):
        for r in range(1,9):
          for add in range(9):
            p=d*q+add
            images=set()
            for i in range(p):
              for j in range(q+r):
                out=forward(i,j,d,q,r)
                assert backward(*out,d,q,r)==(i,j)
                images.add(out);points+=1
            target={('R1',i,j)for i in range(q)for j in range(p+d*r)}
            target|={('R2',i,j)for i in range(r)for j in range(p-d*q)}
            assert images==target
            for j in range(q+r):
                out=forward(p,j,d,q,r)
                expected=('R1',j,p+d*r)if j<q else('R2',j-q,p-d*q)
                assert out==expected and out not in images
                growth+=1
            params+=1
    for _ in range(10000):
        d,q,r=[rng.randrange(1,25)for _ in range(3)]
        p=d*q+rng.randrange(0,80)
        args=(p,d*q,d*r,1,1,d,1,1,1,1)
        i=rng.randrange(p);j=rng.randrange(q+r)
        source=from_cell('L1',i,j,0,*args)
        assert to_cell(source,*args)==(i,j,0)
        branch,ii,jj=forward(i,j,d,q,r)
        target=from_cell(branch,ii,jj,0,*args)
        assert to_cell(target,*args)==(ii,jj,0)
        bi,bj=backward(branch,ii,jj,d,q,r)
        assert from_cell('L1',bi,bj,0,*args)==source
        # Increasing the fusion parameter changes actual path geometry,
        # but inclusion retains the existing edge-residue coordinates.
        args2=(p+1,d*q,d*r,1,1,d,1,1,1,1)
        upsource=from_cell('L1',i,j,0,*args2)
        uptarget=from_cell(branch,ii,jj,0,*args2)
        assert to_cell(upsource,*args2)==(i,j,0)
        assert to_cell(uptarget,*args2)==(ii,jj,0)
        actual+=1
    result=dict(status='PASS',parameter_choices=params,rectangle_points=points,
                new_fusion_boundary_checks=growth,actual_edge_growth_checks=actual,
                seconds=time.monotonic()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
