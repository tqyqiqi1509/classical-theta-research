"""Independent exact check of the new cycle-fold local-character theorem.

Inputs are the stored original full characters. Each nonidentity prediction
is computed afresh from a smaller folded charge graph and the divisor sum.
"""
from pathlib import Path
from math import gcd,prod
from functools import reduce
from fractions import Fraction
import sys,json,time
import sympy as sp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from local_primitive_laurent_jets import LocalPrimitiveJets,eta_from_types


def main():
    start=time.time();rows=[]
    data=json.loads((HERE/'local_young_jet_stress.json').read_text())
    for source in data:
        charges=source['charges'];m=source['multiplicity']
        types=[a for a,n in zip(charges,source['counts']) for _ in range(n)]
        E=sum(abs(a[0]*b[1]-a[1]*b[0])*m for i,a in enumerate(types) for b in types[i+1:])
        for mus,observed in zip(source['class_partitions'],source['traces']):
            lengths=[l for mu in mus for l in mu]
            if all(l==1 for l in lengths):continue
            g=reduce(gcd,lengths);fold=tuple(tuple(l*x for x in beta)
                 for beta,mu in zip(charges,mus) for l in mu)
            dimension=LocalPrimitiveJets(len(fold)).trace(eta_from_types(fold,m),tuple(range(len(fold))),tuple(sum(a) for a in fold))
            divisor_sum=sum(int(sp.mobius(d))*(-1)**(E-E//(d*d)) for d in sp.divisors(g))
            predicted=Fraction(dimension*divisor_sum,prod(lengths))
            assert predicted.denominator==1
            row={'charges':charges,'counts':source['counts'],'multiplicity':m,
                 'cycle_partitions':mus,'folded_charges':fold,'folded_dimension':dimension,
                 'gcd_cycles':g,'arrow_count':E,'divisor_sum':divisor_sum,
                 'prediction':int(predicted),'original_trace':observed,'pass':predicted==observed}
            rows.append(row)
            if not row['pass']:
                print(json.dumps(row),flush=True);break
        if rows and not rows[-1]['pass']:break
    result={'nonidentity_classes':len(rows),'all_pass':all(r['pass'] for r in rows),
            'seconds':time.time()-start,'results':rows}
    (HERE/'cycle_fold_character_check.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='results'}),flush=True)
    assert result['all_pass']


if __name__=='__main__':main()
