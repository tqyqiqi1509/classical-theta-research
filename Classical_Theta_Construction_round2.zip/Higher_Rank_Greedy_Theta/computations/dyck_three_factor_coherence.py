"""Actual first-trilinear Dyck-data move for equal input normal weights.

This is NOT a rank/unrank map on coefficient-sized object sets.  A local
one-pair grading is read from its horizontal-edge coordinate by a residue
formula, and the triple move cuts/transposes three explicit rectangles.
Intermediate and final carrier normals may be nonprimitive.

The general higher-degree/unequal-input-weight coherence problem remains
open in this project. See agents/DYCK_THREE_FACTOR_COHERENCE.md.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations, product
from math import gcd
from pathlib import Path
import json
import time

from tight_grading_two_input import bezout_rectangle, dyck_word, is_tight


@lru_cache(None)
def geometry(m, da, db, kgamma):
    assert min(m, da, db, kgamma) > 0
    assert m % da == m % db == 0
    u, v = m // da, m // db
    ell = gcd(u, v)
    aa, bb = v // ell, u // ell
    copies = kgamma // gcd(da, db)
    assert kgamma % gcd(da, db) == 0
    width, height = bezout_rectangle(aa, bb, ell)
    assert v * height - u * width == ell
    return u, v, ell, copies, width, height


@dataclass(frozen=True)
class PairObject:
    """Positive tuple copy and the actual 1-based positive edge positions."""
    copy: int
    horizontal: int
    vertical: int


def from_strip(m, da, db, kgamma, copy, residue):
    u, v, ell, copies, width, height = geometry(m, da, db, kgamma)
    assert 0 <= copy < copies and 0 <= residue < ell
    target_residue = width - ell + residue
    i = (pow(height, -1, width) * target_residue) % width + 1 if width > 1 else 1
    j = ((height * (i-1)) // width + u) % height + 1
    return PairObject(copy, i, j)


def to_strip(m, da, db, kgamma, obj):
    u, v, ell, copies, width, height = geometry(m, da, db, kgamma)
    assert 0 <= obj.copy < copies
    assert 1 <= obj.horizontal <= width and 1 <= obj.vertical <= height
    residue = (height * (obj.horizontal-1)) % width - (width-ell)
    assert 0 <= residue < ell
    expected = ((height * (obj.horizontal-1)) // width + u) % height + 1
    assert obj.vertical == expected
    return obj.copy, residue


def literal_grading(m, da, db, kgamma, obj):
    u, v, ell, copies, width, height = geometry(m, da, db, kgamma)
    word = dyck_word(width, height)
    ep = [i for i, e in enumerate(word) if e == 'E']
    np = [i for i, e in enumerate(word) if e == 'N']
    grading = [0] * len(word)
    grading[ep[obj.horizontal-1]] = u
    grading[np[obj.vertical-1]] = v
    return word, tuple(grading)


@dataclass(frozen=True)
class TripleObject:
    branch: str
    inner: PairObject
    outer: PairObject


def parameters(branch, p, q, r, kab, kac, kbc, ktotal):
    # Leaf normal weights are rescaled to one.  k's are actual output
    # normal contents divided by the common leaf normal content.
    if branch == 'L1':
        return (p, 1, 1, kab), (r+q, kab, 1, ktotal), kab
    if branch == 'L2':
        assert q > p
        return (r, 1, 1, kac), (q-p, 1, kac, ktotal), kac
    if branch == 'R1':
        return (q, 1, 1, kbc), (p+r, 1, kbc, ktotal), kbc
    if branch == 'R2':
        assert p > q
        return (r, 1, 1, kac), (p-q, kac, 1, ktotal), kac
    raise ValueError(branch)


def triple_from_cell(branch, i, j, root_copy, p, q, r, kab, kac, kbc, ktotal):
    ip, op, ki = parameters(branch, p, q, r, kab, kac, kbc, ktotal)
    # This carry has a structural meaning: the inner normal-copy index
    # becomes the residue within the next edge's intersection label.
    inner_copy = j % ki
    outer_residue = j // ki
    inner = from_strip(*ip, inner_copy, i)
    outer = from_strip(*op, root_copy, outer_residue)
    return TripleObject(branch, inner, outer)


def triple_to_cell(obj, p, q, r, kab, kac, kbc, ktotal):
    ip, op, ki = parameters(obj.branch, p, q, r, kab, kac, kbc, ktotal)
    inner_copy, i = to_strip(*ip, obj.inner)
    root_copy, outer_residue = to_strip(*op, obj.outer)
    return i, ki * outer_residue + inner_copy, root_copy


def forward_cell(branch, i, j, p, q, r):
    if branch == 'L2':
        assert q > p and 0 <= i < r and 0 <= j < q-p
        return 'R1', p+j, p+i
    assert branch == 'L1' and 0 <= i < p and 0 <= j < r+q
    if j < q:
        return 'R1', j, i
    k = j-q
    if i < q:
        return 'R1', i, p+k
    return 'R2', k, i-q


def inverse_cell(branch, i, j, p, q, r):
    if branch == 'R2':
        assert p > q and 0 <= i < r and 0 <= j < p-q
        return 'L1', q+j, q+i
    assert branch == 'R1' and 0 <= i < q and 0 <= j < p+r
    if j < p:
        return 'L1', j, i
    k = j-p
    if i < p:
        return 'L1', i, q+k
    return 'L2', k, i-p


def forward(obj, p, q, r, kab, kac, kbc, ktotal):
    i, j, k = triple_to_cell(obj, p, q, r, kab, kac, kbc, ktotal)
    branch, i2, j2 = forward_cell(obj.branch, i, j, p, q, r)
    return triple_from_cell(branch, i2, j2, k, p, q, r, kab, kac, kbc, ktotal)


def backward(obj, p, q, r, kab, kac, kbc, ktotal):
    i, j, k = triple_to_cell(obj, p, q, r, kab, kac, kbc, ktotal)
    branch, i2, j2 = inverse_cell(obj.branch, i, j, p, q, r)
    return triple_from_cell(branch, i2, j2, k, p, q, r, kab, kac, kbc, ktotal)


def main():
    start = time.monotonic()
    pair_parameters = pair_objects = literal_grid_pairs = 0
    # New verification target: exact edge-level residue bijection.  This
    # is not a rerun of the normal-power or theta coefficient batches.
    for u, v in product(range(1, 25), repeat=2):
        m = u*v
        da, db = v, u
        kg = gcd(da, db)
        _, _, ell, copies, width, height = geometry(m, da, db, kg)
        generated = set()
        for s in range(ell):
            obj = from_strip(m, da, db, kg, 0, s)
            assert to_strip(m, da, db, kg, obj) == (0, s)
            word, grading = literal_grading(m, da, db, kg, obj)
            assert is_tight(word, grading)
            generated.add((obj.horizontal, obj.vertical))
            pair_objects += 1
        literal = set()
        # Brute edge positions only: no profile oracle is used.
        if u <= 8 and v <= 8:
            for i, j in product(range(1, width+1), range(1, height+1)):
                word, grading = literal_grading(m, da, db, kg, PairObject(0, i, j))
                if is_tight(word, grading):
                    literal.add((i, j))
                literal_grid_pairs += 1
            assert generated == literal
        pair_parameters += 1

    rectangle_triples = rectangle_point_maps = 0
    for p, q, r in product(range(1, 33), repeat=3):
        for i, j in product(range(p), range(r+q)):
            image = forward_cell('L1', i, j, p, q, r)
            assert inverse_cell(*image, p, q, r) == ('L1', i, j)
            rectangle_point_maps += 1
        if q > p:
            for i, j in product(range(r), range(q-p)):
                image = forward_cell('L2', i, j, p, q, r)
                assert inverse_cell(*image, p, q, r) == ('L2', i, j)
                rectangle_point_maps += 1
        rectangle_triples += 1

    def det(a, b):
        return a[0]*b[1]-a[1]*b[0]
    def plus(a, b):
        return a[0]+b[0], a[1]+b[1]
    rays = [a for a in product(range(7), repeat=2) if gcd(*a) == 1]
    rays.sort(key=lambda a: (a[1]/a[0] if a[0] else float('inf')))
    ambient_triples = actual_maps = nonprimitive_inner = nonprimitive_root = 0
    for a, b, c in combinations(rays, 3):
        p, q, r = det(a, b), det(b, c), det(a, c)
        if min(p, q, r) <= 0:
            continue
        kab, kac, kbc = gcd(*plus(a,b)), gcd(*plus(a,c)), gcd(*plus(b,c))
        ktotal = gcd(*plus(plus(a,b),c))
        args = p,q,r,kab,kac,kbc,ktotal
        nonprimitive_inner += max(kab, kac, kbc) > 1
        nonprimitive_root += ktotal > 1
        # Boundary and interior points of each of the actual polyhedral
        # pieces, with every root copy, check normal carry and reattachment.
        for branch, wi, he in [('L1', p, r+q)] + ([('L2', r, q-p)] if q>p else []):
            cells = {(0,0),(wi-1,he-1),(wi//2,he//2)}
            if branch == 'L1':
                cells |= {(0,q-1),(0,q),(p-1,q-1),(p-1,q)}
            for i,j in cells:
                if not (0 <= i < wi and 0 <= j < he):
                    continue
                for k in range(ktotal):
                    obj = triple_from_cell(branch,i,j,k,*args)
                    moved = forward(obj,*args)
                    assert backward(moved,*args) == obj
                    actual_maps += 1
        ambient_triples += 1

    result = {
        'status':'PASS',
        'scope':'first multilinear three-factor component; equal input normal weights; arbitrary intermediate/final normal contents',
        'local_residue_parameter_pairs':pair_parameters,
        'local_generated_actual_gradings':pair_objects,
        'independent_literal_edge_pairs':literal_grid_pairs,
        'rectangle_parameter_triples':rectangle_triples,
        'rectangle_point_inverse_checks':rectangle_point_maps,
        'actual_ambient_charge_triples':ambient_triples,
        'actual_edge_object_inverse_checks':actual_maps,
        'triples_with_nonprimitive_intermediate':nonprimitive_inner,
        'triples_with_nonprimitive_final':nonprimitive_root,
        'seconds':time.monotonic()-start,
        'not_claimed':['all-order coherence','unequal-input-normal-weight triple bijection','path independence among triple moves']
    }
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
