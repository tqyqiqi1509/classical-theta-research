"""Direct unlabelled colored trees, without first enumerating leaf labels.

States are a color-content vector and a rational color covector.  Integer
subcharges replace subsets and multisets of child tree types replace set
partitions.  The orbit-bijection proof is in the companion theorem note.
"""
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
from itertools import product
from math import factorial,prod
from collections import Counter
import sys,json,time

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'intrinsic_partition_model')]
from intrinsic_partitions import PartitionModel,lexsign
from orbit_schur_positive import OrbitSchurModel


class ChargePartitionModel:
    def __init__(self,B,g,p,color_order=None):
        self.n=len(B);self.total=(1,)+tuple(p);N=self.n+1
        assert all(B[i][j]==-B[j][i] for i in range(self.n) for j in range(self.n))
        E=[[0]*N for _ in range(N)]
        for i in range(self.n):
            E[0][i+1]=g[i];E[i+1][0]=-g[i]
            for j in range(self.n):E[i+1][j+1]=-B[i][j]
        self.color_eta=tuple(map(tuple,E))
        order=tuple(range(self.n)) if color_order is None else tuple(color_order)
        mu=tuple(tuple([Fraction(1)]+[Fraction(i==j) for j in order]) for i in range(self.n))
        frame=tuple(-sum(p[i]*mu[i][j] for i in range(self.n)) for j in range(N))
        self.theta=(frame,)+mu
        self.state_count=self.plane_count=self.event_count=0
        self.solve=lru_cache(None)(self._solve)
        self.subcharges=lru_cache(None)(self._subcharges)
        self.planes=lru_cache(None)(self._planes)
        self.charge=lru_cache(None)(self._charge)

    def _charge(self,T):
        if T[0]=='L':return tuple(int(i==T[1]) for i in range(self.n+1))
        cc=[self.charge(c) for c in T[1]]
        return tuple(sum(c[i] for c in cc) for i in range(self.n+1))

    def pair(self,a,b):
        return sum(a[i]*self.color_eta[i][j]*b[j] for i in range(len(a)) for j in range(len(b)))

    def connected(self,a):
        support=[i for i,x in enumerate(a) if x]
        if sum(a)==1:return True
        if len(support)<2:return False
        seen={support[0]};todo=list(seen)
        while todo:
            i=todo.pop()
            for j in support:
                if j not in seen and self.color_eta[i][j]:seen.add(j);todo.append(j)
        return len(seen)==len(support)

    def _subcharges(self,a):
        return tuple(b for b in product(*(range(x+1) for x in a)) if any(b) and b!=a)

    def _planes(self,a):
        result={}
        for b in self.subcharges(a):
            if self.pair(a,b):result.setdefault(PartitionModel.wedge_key(a,b),b)
        return tuple(sorted(result.items()))

    def restricted(self,a,theta):
        zero=(Fraction(0),)*(self.n+1)
        return tuple(row if a[i] else zero for i,row in enumerate(theta))

    def _solve(self,a,theta):
        self.state_count+=1
        if sum(a)==1:return (('L',a.index(1)),)
        if not self.connected(a):return ()
        assert all(sum(a[i]*theta[i][j] for i in range(self.n+1))==0 for j in range(self.n+1))
        answer=set();N=self.n+1
        for key,b in self.planes(a):
            self.plane_count+=1
            denominator=self.pair(a,b)
            tau=tuple(-sum(b[i]*theta[i][j] for i in range(N))/denominator for j in range(N))
            if lexsign(tau)<=0:continue
            out=tuple(sum(a[i]*self.color_eta[i][j] for i in range(N)) for j in range(N))
            projected=tuple(tuple(theta[i][j]+tau[j]*out[i] for j in range(N)) for i in range(N))
            options=[]
            for c in self.subcharges(a):
                if not self.connected(c) or not PartitionModel.in_plane(a,b,c):continue
                subtheta=self.restricted(c,projected)
                for T in self.solve(c,subtheta):options.append((T,c))
            options.sort()
            @lru_cache(None)
            def split(remaining,minimum):
                if not any(remaining):return ((),)
                pieces=[]
                for j in range(minimum,len(options)):
                    T,c=options[j]
                    if all(c[i]<=remaining[i] for i in range(N)):
                        rest=tuple(remaining[i]-c[i] for i in range(N))
                        for tail in split(rest,j):pieces.append((T,)+tail)
                return tuple(pieces)
            for children in split(a,0):
                if len(children)>1 and any(self.pair(a,self.charge(C)) for C in children):
                    self.event_count+=1;answer.add(('N',children))
        return tuple(sorted(answer))

    def trees(self):return self.solve(self.total,self.restricted(self.total,self.theta))

    def statistics(self):
        return {'states':self.state_count,'planes':self.plane_count,
                'events':self.event_count,'cache':str(self.solve.cache_info())}


@lru_cache(None)
def automorphism_order(T):
    if T[0]=='L':return 1
    return prod(automorphism_order(C)**m*factorial(m) for C,m in Counter(T[1]).items())


class ChargeOrbitSchurModel(OrbitSchurModel):
    def __init__(self,B,g,p):
        self.model=ChargePartitionModel(B,g,p)
        self.root_types=self.model.trees();self.records={}
        self.value=lru_cache(None)(self._value)
        self.charge=lru_cache(None)(self._charge)
        self.labelled_tree_count=sum(prod(factorial(x) for x in p)//automorphism_order(T)
                                     for T in self.root_types)


def main():
    cases=[([[0,2,-3],[-2,0,2],[3,-2,0]],(-3,3,-2),(2,2,1)),
           ([[0,1],[-1,0]],(-6,1),(4,2)),
           ([[0,3,-2],[-3,0,2],[2,-2,0]],(-5,1,-1),(2,2,1))]
    results=[]
    for B,g,p in cases:
        start=time.time();M=ChargeOrbitSchurModel(B,g,p);ans,terms=M.coefficient()
        # Compare tree orbits to the separate labelled constructor only now.
        old=OrbitSchurModel(B,g,p)
        assert M.root_types==old.root_types
        assert M.labelled_tree_count==len(old.labelled_trees)
        old_value,old_terms=old.coefficient();assert (ans,terms)==(old_value,old_terms)
        row={'B':B,'g':g,'p':p,'tree_orbits':len(M.root_types),
             'labelled_tree_count_from_stabilizers':M.labelled_tree_count,
             'value':ans,'orbit_contributions':terms,'statistics':M.model.statistics(),
             'pass':True,'seconds':time.time()-start}
        results.append(row);Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2))
        print(json.dumps(row),flush=True)


if __name__=='__main__':main()
