"""Probe an actual general one-active same-ray series composition map.

Candidate: the marked-atom phase carry with an arbitrary outer slot
word. A failure is retained with exact source data; no theorem uses
this candidate until its natural inverse is proved.
"""
from singleton_atom_splitting import *
from itertools import product


def objects(degree,v,Q,c,L):
    ans=set()
    for ws in compositions(degree,Q):
        weights=tuple(v*x for x in ws)
        for phase in range(L):
            ans.add(normalize(weights,phase,c))
    return sorted(ans)


def candidate(x,I,y,J,par):
    Q,v,vmid,e1,e2,et,c1,c2,ct,L1,L2,Lt,b=par
    r,K=divmod(I*L2+J,Lt)
    xx=x[r:]+x[:r]
    weights=tuple(xx[i]+v*(y[i]//vmid)for i in range(Q))
    payload=tuple((xx[i]//v,y[i]//vmid)for i in range(Q))
    return normalize_payload(weights,K,payload,ct)


def run():
    checked=points=0;fail=None
    for d,e in product(range(1,4),repeat=2):
      D=(d,e)
      for alpha,beta in product(product(range(3),repeat=2),repeat=2):
        det=alpha[0]*beta[1]-alpha[1]*beta[0]
        if det<=0:continue
        m=d*e*det
        da,db=(content(D,z)for z in(alpha,beta))
        Q=m//da
        if Q>6:continue
        for a,b in product(range(1,4),repeat=2):
          mid=tuple(a*x+y for x,y in zip(alpha,beta))
          fin=tuple((a+b)*x+y for x,y in zip(alpha,beta))
          dm,dt=(content(D,z)for z in(mid,fin))
          par=params(m,da,db,dm,dt,a,b)
          Q,v,vm,e1,e2,et,c1,c2,ct,L1,L2,Lt,bb=par
          left=objects(a,v,Q,c1,L1);right=objects(b,vm,Q,c2,L2)
          if len(left)*len(right)>20000:continue
          seen={}
          for (x,I),(y,J) in product(left,right):
            out=candidate(x,I,y,J,par)
            source=(x,I,y,J)
            if out in seen and seen[out]!=source:
              fail=dict(reason='collision',D=D,alpha=alpha,beta=beta,a=a,b=b,
                        parameters=par,first=seen[out],second=source,target=out)
              break
            seen[out]=source;points+=1
          if fail:break
          checked+=1
        if fail:break
      if fail:break
    result=dict(status='FAIL'if fail else'NO_COUNTEREXAMPLE',parameter_choices=checked,
                map_points=points,counterexample=fail)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':run()
