"""Finite degree pieces of a principal upper cluster algebra when kappa < 1.

The theorem and proof are in agents/degree_finiteness_audit.md.  All arithmetic
is exact.  This constructs U_d over Q(y_1,...,y_n), not a theta basis and not a
principal-theta finiteness oracle.  The coefficient-free switch computes the
initial upper bound and is used only to check coefficient dependence.
"""

from collections import defaultdict
from fractions import Fraction
from math import comb
import json
from pathlib import Path
import sympy as sp
from sympy.polys.matrices import DomainMatrix


def weighted_compositions(weights, total):
    """All nonnegative z with dot(weights,z)=total, with no box overcount."""
    if len(weights) == 1:
        if total % weights[0] == 0:
            yield (total // weights[0],)
        return
    for first in range(total // weights[0] + 1):
        for tail in weighted_compositions(weights[1:], total-first*weights[0]):
            yield (first,) + tail


def degree_carrier(B, w, degree):
    n = len(B)
    assert len(w) == n and all(isinstance(x, int) and x > 0 for x in w)
    assert all(len(row) == n for row in B)
    assert all(sum(w[j]*B[j][i] for j in range(n)) == 0 for i in range(n))
    delta = [sum(w[j]*max(B[j][i], 0) for j in range(n)) for i in range(n)]
    assert all(x > 0 for x in delta)
    kappa = sum((Fraction(wi, di) for wi, di in zip(w, delta)), Fraction(0))
    if not kappa < 1:
        raise ValueError("The finite-carrier theorem requires kappa < 1.")
    if degree < 0:
        return [], [], delta, kappa
    H = [int(Fraction(degree, 1)/((1-kappa)*di)) for di in delta]
    shifted_degree = degree + sum(wi*hi for wi, hi in zip(w, H))
    E = [tuple(zi-hi for zi, hi in zip(z, H))
         for z in weighted_compositions(w, shifted_degree)]
    return E, H, delta, kappa


def moment_matrix(B, w, degree, principal=True):
    """Matrix whose kernel is the degree-d initial-plus-neighbors upper bound.

    Principal coefficients use independent symbols y_i.  If principal=False,
    y_i=1 is substituted before taking a kernel.  Row labels retain all fiber
    data, and E is the column-to-Laurent-monomial map.
    """
    E, H, delta, kappa = degree_carrier(B, w, degree)
    n = len(B)
    ys = sp.symbols(f"y1:{n+1}") if principal else [sp.Integer(1)]*n
    rows, row_labels = [], []
    for i in range(n):
        v = tuple(B[j][i] for j in range(n))
        pivot = next(j for j, x in enumerate(v) if x)
        fibers = defaultdict(list)
        for col, u in enumerate(E):
            if u[i] >= 0:
                continue
            k = u[pivot] // v[pivot]
            rep = tuple(uj-k*vj for uj, vj in zip(u, v))
            fibers[(-u[i], rep)].append((k, col))
        for (r, rep), members in sorted(fibers.items()):
            kmin, kmax = min(k for k, _ in members), max(k for k, _ in members)
            length = kmax-kmin
            for j in range(min(r, length+1)):
                row = {}
                for k, col in members:
                    ell = k-kmin
                    if ell >= j:
                        row[col] = (-1)**ell*comb(ell, j)*ys[i]**(length-ell)
                if row:
                    rows.append(row)
                    row_labels.append((i, r, rep, j, kmin, kmax))
    entries = {(row, col): value for row, data in enumerate(rows)
               for col, value in data.items()}
    M = sp.SparseMatrix(len(rows), len(E), entries)
    return M, E, {"H": H, "delta": delta, "kappa": str(kappa),
                  "row_labels": row_labels, "coefficient_symbols": ys}


def cycle(n, arrows):
    assert n >= 3
    B = [[0]*n for _ in range(n)]
    for i in range(n):
        j = (i+1) % n
        B[i][j] = arrows
        B[j][i] = -arrows
    return B


def exact_rank(M):
    if not M.rows or not M.cols:
        return 0
    return DomainMatrix.from_Matrix(M).to_field().rank()


def verification_runs():
    output = []
    for n, a, d in [(3, 4, 1), (3, 4, 2), (3, 4, 3), (4, 5, 1), (5, 7, 2)]:
        B, w = cycle(n, a), [1]*n
        for principal in [True, False]:
            M, E, info = moment_matrix(B, w, d, principal=principal)
            rank = exact_rank(M)
            record = {"rank": n, "arrows": a, "degree": d,
                      "coefficients": "independent_principal" if principal else "all_y_equal_1",
                      "kappa": info["kappa"], "pole_bounds": info["H"],
                      "carrier_size": len(E), "matrix_rows": M.rows,
                      "matrix_nonzero_entries": M.nnz(), "matrix_rank": rank,
                      "kernel_dimension": len(E)-rank,
                      "ordinary_polynomial_dimension": comb(d+n-1, n-1),
                      "arithmetic": "exact_Q(y)" if principal else "exact_Q"}
            output.append(record)
            print(json.dumps(record), flush=True)
    return output


if __name__ == "__main__":
    result = verification_runs()
    Path(__file__).with_name("weighted_degree_moment_kernel_results.json").write_text(
        json.dumps(result, indent=2)+"\n")
