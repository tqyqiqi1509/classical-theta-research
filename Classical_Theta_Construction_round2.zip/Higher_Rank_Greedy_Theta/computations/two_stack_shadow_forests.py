"""Actual tight gradings as two-stack boundary forests.

The two matchings are computed without shadows, pairwise compatibility,
or scattering coefficients.  See agents/TWO_STACK_DYCK_FORESTS.md for the
proof, including saturated totals and determinant-one single trees.
"""
from collections import Counter
from dataclasses import dataclass
from itertools import combinations
from math import gcd


@dataclass(frozen=True)
class BoundaryForest:
    word: tuple
    grading: tuple
    parent: tuple
    edges: tuple
    acyclic: bool
    roots: tuple
    nontrivial_roots: tuple

    @property
    def shadowed(self):
        return len({self.word[v] for v in self.nontrivial_roots}) <= 1

    @property
    def tight(self):
        return self.acyclic and self.shadowed


def cyclic_matching(word, grading, producer, reverse=False):
    """Producer pushes its weight; opposite-color positions are unit pops.

    Unused prefix service positions finish the still-open suffix stack.
    Both producer totals must be at most the number of service positions.
    The resulting edges are independent of the arbitrary cyclic cut.
    """
    order = range(len(word)-1, -1, -1) if reverse else range(len(word))
    stack, prefix_free, edges = [], [], []
    for v in order:
        if word[v] == producer:
            stack.extend([v]*grading[v])
        elif stack:
            edges.append((stack.pop(), v))
        else:
            prefix_free.append(v)
    for v in prefix_free:
        if not stack:
            break
        edges.append((stack.pop(), v))
    if stack:
        raise ValueError("Producer weight exceeds the number of service vertices")
    return tuple(edges)


def boundary_forest(word, grading):
    word, grading = tuple(word), tuple(grading)
    if len(word) != len(grading) or set(word) - {'E', 'N'}:
        raise ValueError("Expected equally long NE word and grading")
    if any(not isinstance(x, int) or x < 0 for x in grading):
        raise ValueError("Grading must consist of nonnegative integers")
    edges = cyclic_matching(word, grading, 'E') + cyclic_matching(word, grading, 'N', True)
    parent = [-1]*len(word)
    for u, v in edges:
        if parent[v] != -1:
            raise AssertionError("Unit service positions have at most one parent")
        parent[v] = u
    # Functional parent graph: each vertex is visited at most twice.
    done = [False]*len(word)
    acyclic = True
    for start in range(len(word)):
        if done[start]:
            continue
        path, active = [], set()
        v = start
        while v != -1 and not done[v] and v not in active:
            active.add(v)
            path.append(v)
            v = parent[v]
        if v in active:
            acyclic = False
        for v in path:
            done[v] = True
    roots = tuple(v for v, u in enumerate(parent) if u == -1)
    nontrivial = tuple(v for v in roots if grading[v])
    return BoundaryForest(word, grading, tuple(parent), edges, acyclic, roots, nontrivial)


def is_tight_by_forest(word, grading):
    return boundary_forest(word, grading).tight


def active_tree_vertices(forest):
    """All vertices in nontrivial components, when the graph is a forest."""
    if not forest.acyclic:
        raise ValueError("Not a forest")
    return frozenset(v for e in forest.edges for v in e)


def validate(max_side=5):
    """One structural test against the independent literal definitions.

    Exhaust all bounded weights for the maximal paths through max_side;
    also all cyclic NE words through length 7, bounded by each opposite
    service count.  These validate one general graph criterion, not a
    growing list of special scattering coefficients.
    """
    import json, time
    from pathlib import Path
    from tight_grading_two_input import compositions, dyck_word, shadow_sets, is_tight, direct_compatible
    start = time.monotonic()
    counts = Counter()
    root_counts = Counter()

    def check(word):
        W, H = word.count('E'), word.count('N')
        ep = [i for i, x in enumerate(word) if x == 'E']
        np = [i for i, x in enumerate(word) if x == 'N']
        for q in range(H+1):
            for p in range(W+1):
                for eh in compositions(q, W):
                    for nv in compositions(p, H):
                        grading = [0]*len(word)
                        for i, x in zip(ep, eh): grading[i] = x
                        for i, x in zip(np, nv): grading[i] = x
                        f = boundary_forest(word, grading)
                        sh, E, N = shadow_sets(word, grading)
                        assert f.acyclic == direct_compatible(word, grading), (word, grading, 'compatibility')
                        assert f.tight == is_tight(word, grading), (word, grading, 'tightness')
                        for color, domain in [('E', E), ('N', N)]:
                            union = set().union(*(sh[v] for v in domain))
                            targets = {v for u, v in f.edges if word[u] == color}
                            assert union == targets, (word, grading, 'shadow union', color)
                        assert len(f.roots) == W+H-p-q
                        if p == W and q == H:
                            assert not f.acyclic
                            counts['both_saturated'] += 1
                        if f.tight and p and q and abs(p*H-q*W) == gcd(p, q):
                            # Single-tree corollary applies only to the maximal path.
                            if tuple(word) == dyck_word(W, H) and gcd(W, H) == 1:
                                assert len(f.nontrivial_roots) == 1, (word, grading, 'single tree')
                                r = f.nontrivial_roots[0]
                                expected = 'N' if p*H-q*W > 0 else 'E'
                                assert word[r] == expected
                                assert len(active_tree_vertices(f)) == p+q+1
                                counts['single_tree_gradings'] += 1
                                root_counts[len(f.roots)] += 1
                        counts['gradings'] += 1
                        if p == W or q == H:
                            counts['at_least_one_saturated'] += 1

    for W in range(1, max_side+1):
        for H in range(1, max_side+1):
            check(dyck_word(W, H))
            counts['maximal_paths'] += 1
    maximal_count = counts['gradings']
    # A small, complete shape variation checks the "arbitrary word" premise.
    for L in range(2, 8):
        for W in range(1, L):
            for epos in combinations(range(1, L), W-1):
                word = tuple('E' if i == 0 or i in epos else 'N' for i in range(L))
                if word == dyck_word(W, L-W):
                    continue
                check(word)
                counts['other_words'] += 1
    result = {'status': 'PASS', 'criterion': 'literal compatibility iff two-stack acyclic; tight iff roots one color',
              'counts': dict(counts), 'maximal_path_gradings': maximal_count,
              'single_tree_total_root_distribution': dict(root_counts),
              'seconds': time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    import json
    print(json.dumps(validate(), indent=2))
