"""The failed spherical quotient exposes a specific incoming primitive block.

For the cyclic triangle with r parallel arrows per side and stability
(-2,1,1), the unframed thin stable cut algebra is
Q[u,v]/(u^r,v^r), and the spherical image is the ideal (u+v)^r.
This probe compares its exact multiplication rank with the framed excess.
"""
import json
from pathlib import Path
import sympy as sp
from spherical_image import candidate

rows=[]
for r in range(1,7):
    exponents=[(a,b) for a in range(r) for b in range(r)]
    index={a:i for i,a in enumerate(exponents)}
    M=sp.zeros(r*r)
    for j,(a,b) in enumerate(exponents):
        for k in range(r+1):
            if a+k<r and b+r-k<r:
                M[index[(a+k,b+r-k)],j]+=sp.binomial(r,k)
    rank=M.rank()
    framed=candidate([[0,r,-r],[-r,0,r],[r,-r,0]],[-1]*3)
    excess=framed['spherical_image_dimension']-framed['theta_coefficient']
    rows.append({'r':r,'attractor_spherical_image_rank':rank,
                 'floor_r_squared_over_four':r*r//4,'framed':framed,
                 'excess_equals_three_times_rank':excess==3*rank})
    print(r,rank,excess,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2))
