"""Equivariant toric intersection-cohomology recursion on a flow polytope.

The input is incidence data, its vertices, and a graph automorphism. No
theta coefficient is used. Cone stalks are computed from proper cone faces
and characteristic polynomials of quotient representations. Degrees use t
for cohomological degree two.
"""
from __future__ import annotations
import itertools
import json
from functools import lru_cache
from pathlib import Path
import sympy as sp

t=sp.Symbol("t")


def independent_columns(M):
    return M[:,list(M.rref()[1])]


def zero_faces(vertices):
    """All nonempty faces via intersections of active coordinate inequalities."""
    edge_count=len(vertices[0])
    zsets=[frozenset(i for i,x in enumerate(v) if x==0) for v in vertices]
    result={frozenset()}
    for z in zsets:
        result.update({z})
        result.update({f & z for f in tuple(result)})
    return sorted(result,key=lambda a:(len(a),tuple(a)))


def equivariant_ih(incidence,vertices,permutation):
    if not vertices:
        raise ValueError("The bounded flow polytope must be nonempty")
    D=sp.Matrix(incidence)
    e=D.cols
    if sorted(permutation)!=list(range(e)):
        raise ValueError("permutation must act on all arrows")
    L=independent_columns(D.T)
    ambient=sp.eye(e)
    P=sp.zeros(e)
    for i,j in enumerate(permutation):
        P[j,i]=1
    faces=zero_faces(vertices)
    fixed=[I for I in faces if frozenset(permutation[i] for i in I)==I]
    spaces={I:independent_columns(L.row_join(ambient[:,sorted(I)])) for I in fixed}
    ranks={I:spaces[I].cols-L.cols for I in fixed}
    dimension=e-L.cols
    identity=all(i==j for i,j in enumerate(permutation))

    @lru_cache(None)
    def char_w(I):
        W=spaces[I]
        if W.cols==0:
            return sp.Integer(1)
        if identity:
            return (t-1)**W.cols
        action=W.gauss_jordan_solve(P*W)[0]
        assert W*action==P*W
        return action.charpoly(t).as_expr()

    @lru_cache(None)
    def stalk(I):
        k=ranks[I]
        if not k:
            return sp.Integer(1)
        value=0
        for J in fixed:
            if J < I:
                quotient=sp.cancel(char_w(I)/char_w(J))
                assert sp.denom(quotient)==1
                value+=quotient*stalk(J)
        value=sp.Poly(sp.expand(-value),t)
        return sum(value.nth(i)*t**i for i in range((k+1)//2))

    char_ambient=P.charpoly(t).as_expr()
    H=0
    for I in fixed:
        quotient=sp.cancel(char_ambient/char_w(I))
        assert sp.denom(quotient)==1
        H+=quotient*stalk(I)
    H=sp.expand(H)
    return {"dimension":dimension,"face_count":len(faces),"fixed_faces":len(fixed),
            "ih_polynomial":str(H),"trace_total":int(H.subs(t,1)),
            "graded_traces":[int(H.coeff(t,i)) for i in range(dimension+1)],
            "nontrivial_stalks":[{"zero_edges":sorted(I),"cone_dimension":ranks[I],
                                  "polynomial":str(stalk(I))}
                                  for I in fixed if stalk(I)!=1]}


def flow_polytope(eta):
    """Exact anti-attractor polytope for an integer skew acyclic child quiver.

    Arrows a -> b have multiplicity -eta[a][b] when eta[a][b] < 0.
    The stability is theta = incidence * all_ones = -eta(total, -).
    Vertices are enumerated using simple spanning trees followed by parallel
    arrow choices. Degenerate vertices supported on smaller forests are
    retained once. No scattering or theta-coefficient input is involved.
    """
    if any(x!=int(x) for row in eta for x in row):
        raise ValueError("eta must have integer entries")
    eta=tuple(tuple(int(x) for x in row) for row in eta)
    n=len(eta)
    if not n:
        raise ValueError("At least one child is required")
    if any(len(row)!=n for row in eta):
        raise ValueError("eta must be square")
    if any(eta[i][j]!=-eta[j][i] for i in range(n) for j in range(n)):
        raise ValueError("eta must be skew-symmetric")
    if n==1:
        return {"incidence":[[]],"vertices":[[]],"edges":[],"theta":[0]}
    simple=[(i,j,-eta[i][j]) for i in range(n) for j in range(n) if eta[i][j]<0]
    # Acyclicity is essential for boundedness. Kahn's criterion avoids any
    # numerical LP check and rejects accidental cyclic input explicitly.
    indegree=[0]*n
    outgoing=[[] for _ in range(n)]
    for i,j,m in simple:
        outgoing[i].append(j);indegree[j]+=1
    frontier=[i for i in range(n) if not indegree[i]]
    order=[]
    while frontier:
        i=frontier.pop();order.append(i)
        for j in outgoing[i]:
            indegree[j]-=1
            if not indegree[j]:frontier.append(j)
    if len(order)!=n:
        raise ValueError("The child quiver has a directed cycle")
    edges=[(i,j,k) for i,j,m in simple for k in range(m)]
    edge_index={e:i for i,e in enumerate(edges)}
    D=[[0]*len(edges) for _ in range(n)]
    for a,(i,j,k) in enumerate(edges):D[i][a]=-1;D[j][a]=1
    theta=[sum(row) for row in D]
    vertices=set()
    tree_count=0
    for T in itertools.combinations(simple,n-1):
        parent=list(range(n))
        def root(v):
            while parent[v]!=v:
                parent[v]=parent[parent[v]];v=parent[v]
            return v
        cycle=False
        for i,j,m in T:
            u,v=root(i),root(j)
            if u==v:cycle=True;break
            parent[u]=v
        if cycle:continue
        tree_count+=1
        adjacent=[set() for _ in range(n)]
        for a,(i,j,m) in enumerate(T):adjacent[i].add(a);adjacent[j].add(a)
        residual=theta[:]
        flow=[0]*(n-1)
        leaves=[i for i in range(n) if len(adjacent[i])==1]
        for v in leaves:
            if not adjacent[v]:continue
            a=next(iter(adjacent[v]));i,j,m=T[a]
            u=j if v==i else i
            flow[a]=residual[v] * (-1 if v==i else 1)
            if flow[a]<0:break
            residual[u]+=residual[v]
            adjacent[v].remove(a);adjacent[u].remove(a)
            if len(adjacent[u])==1:leaves.append(u)
        else:
            positive=[a for a,x in enumerate(flow) if x]
            for slots in itertools.product(*(range(T[a][2]) for a in positive)):
                vertex=[0]*len(edges)
                for a,k in zip(positive,slots):
                    i,j,m=T[a]
                    vertex[edge_index[(i,j,k)]]=flow[a]
                vertices.add(tuple(vertex))
    if not tree_count:
        raise ValueError("The child graph must be connected")
    if not vertices:
        raise AssertionError("Acyclic incidence * ones must give a nonempty bounded polytope")
    return {"incidence":D,"vertices":[list(v) for v in sorted(vertices)],
            "edges":edges,"theta":theta,"simple_spanning_trees":tree_count}


def event_ih(eta,child_permutation=None):
    """Natural graded trace of a child permutation on the local fan IH.

    child_permutation[a] is the image of child a; it must preserve eta.
    Parallel arrow indices are fixed by the lifted action.
    """
    n=len(eta)
    if child_permutation is None:child_permutation=list(range(n))
    if sorted(child_permutation)!=list(range(n)):
        raise ValueError("child_permutation must permute all children")
    if any(eta[i][j]!=eta[child_permutation[i]][child_permutation[j]]
           for i in range(n) for j in range(n)):
        raise ValueError("child_permutation does not preserve eta")
    if n==1:
        return {"dimension":0,"face_count":1,"fixed_faces":1,
                "ih_polynomial":"1","trace_total":1,"graded_traces":[1],
                "nontrivial_stalks":[]}
    data=flow_polytope(eta)
    edges=data["edges"];indices={e:i for i,e in enumerate(edges)}
    permutation=[indices[(child_permutation[i],child_permutation[j],k)]
                 for i,j,k in edges]
    result=equivariant_ih(data["incidence"],data["vertices"],permutation)
    result.update(vertex_count=len(data["vertices"]),edge_count=len(edges),
                  theta=data["theta"],simple_spanning_trees=data["simple_spanning_trees"])
    return result


def k22_multiple(m):
    edges=[(i,j,k) for i in range(2) for j in range(2) for k in range(m)]
    D=[[0]*len(edges) for _ in range(4)]
    for a,(i,j,k) in enumerate(edges):
        D[i][a]=-1;D[2+j][a]=1
    # At equal margins, the vertices are supported on one perfect matching,
    # with one parallel arrow selected on each matched pair.
    vertices=[]
    for matching in (0,1):
        for k0,k1 in itertools.product(range(m),repeat=2):
            v=[0]*len(edges)
            v[edges.index((0,matching,k0))]=1
            v[edges.index((1,1-matching,k1))]=1
            vertices.append(v)
    out=[]
    for rowswap,colswap in itertools.product(range(2),repeat=2):
        perm=[edges.index((i^rowswap,j^colswap,k)) for i,j,k in edges]
        r=equivariant_ih(D,vertices,perm)
        r.update(rowswap=rowswap,colswap=colswap)
        out.append(r)
    return {"edge_multiplicity":m,"edges":edges,"vertices":vertices,"characters":out}


if __name__=="__main__":
    data={"construction":"Normal fan equivariant minimal-extension recursion",
          "cases":[k22_multiple(m) for m in (1,2,3)]}
    Path(__file__).with_name("equivariant_toric_ih_results.json").write_text(json.dumps(data,indent=2))
    for case in data["cases"]:
        print(case["edge_multiplicity"],[(c["rowswap"],c["colswap"],c["ih_polynomial"],c["trace_total"]) for c in case["characters"]])
