"""Independent natural-module assembly for the first simultaneous-event block.

The two matching skeletons form one group orbit. Their modules are tensor
products of two-dimensional arrow-slot spaces. The four-child event is
computed from its toric normal fan. The last skeleton is a slot-function
module. No theta value enters the definition of any of these modules.
"""
import json
import sys
from pathlib import Path
from fractions import Fraction
from equivariant_toric_ih import k22_multiple

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"agents"))
from incoming_recursion import IncomingSchur

B=[[0,2,-3],[-2,0,2],[3,-2,0]]
g=[-3,3,-2]

def weighted_cycle_character(row_swap,col_swap):
    blocks=([(0,2)] if row_swap else [(0,1),(0,1)])
    blocks+=([(1,2)] if col_swap else [(1,1),(1,1)])
    blocks+=[(2,1)]
    C=[[l*B[i][j] for j,l in blocks] for i,k in blocks]
    D=[k for i,k in blocks]
    h=[g[i] for i,k in blocks]
    p=(1,)*len(blocks)
    return IncomingSchur(C,D).theta_prefix(tuple(h),p).get(p,0)


if __name__=="__main__":
    local=k22_multiple(2)
    local_by={(c["rowswap"],c["colswap"]):c["trace_total"] for c in local["characters"]}
    rows=[]
    for a,b in [(0,0),(1,0),(0,1),(1,1)]:
        # Single swaps exchange the two matching skeletons, hence trace zero.
        # The double swap fixes each and transposes equal tensor factors:
        # Tr(flip | W tensor W)=dim W=2, times the fixed framing slot dim 2.
        matching=16 if (a,b)==(0,0) else 8 if (a,b)==(1,1) else 0
        event=4*local_by[a,b]
        # Last star has two slots at the two second-color leaves. First-color
        # slots have cardinality one. There is one extra fixed factor of dim 2.
        star=2*(2 if b else 4)
        assembled=matching+event+star
        independent=weighted_cycle_character(a,b)
        rows.append({"first_swap":a,"second_swap":b,"matching_orbit_trace":matching,
                     "four_child_event_trace":event,"star_trace":star,
                     "assembled_natural_trace":assembled,
                     "weighted_cycle_theta_trace":independent,
                     "agrees":assembled==independent})
    sign=Fraction(sum((-1)**(r["first_swap"]+r["second_swap"])*r["assembled_natural_trace"]
                      for r in rows),4)
    direct=IncomingSchur(B).theta_prefix(tuple(g),(2,2,1))[(2,2,1)]
    result={"B":B,"g":g,"p":[2,2,1],"local_polytope":local,"global":rows,
            "sign_multiplicity":str(sign),"ordinary_theta_coefficient":direct,
            "all_pass":all(r["agrees"] for r in rows) and sign==direct}
    Path(__file__).with_name("global_hardcase_ih_results.json").write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!="local_polytope"},indent=2))
