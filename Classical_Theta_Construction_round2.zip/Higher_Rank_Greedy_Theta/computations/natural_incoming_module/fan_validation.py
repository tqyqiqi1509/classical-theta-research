"""Independent checks of the general fan character engine.

The identity character is compared to nearby stable-tree counts using an
independent incidence-matrix solve. Nontrivial permutation checks include
order three; K22 family formulas are independently derived in the sibling
branch. No theta oracle enters these checks.
"""
import itertools,json,sys
from pathlib import Path
import sympy as sp
sys.path.insert(0,str(Path(__file__).parent))
from equivariant_toric_ih import event_ih


def eta_of(charges):
    return [[a[0]*b[1]-a[1]*b[0] for b in charges] for a in charges]


def nearby_tree_count(eta):
    n=len(eta)
    edges=[(i,j,-eta[i][j]) for i in range(n) for j in range(n) if eta[i][j]<0]
    D=sp.zeros(n,len(edges))
    theta=sp.zeros(n,1)
    for a,(i,j,m) in enumerate(edges):
        D[i,a]=-1;D[j,a]=1;theta[i]-=m;theta[j]+=m
    # theta + epsilon e0 + epsilon^2 e1 + ... with the final coordinate
    # adjusted so the sum remains zero; symbolic lex signs avoid bounds.
    perturb=sp.zeros(n,n-1)
    for i in range(n-1):perturb[i,i]=1;perturb[n-1,i]=-1
    RHS=theta.row_join(perturb)[:-1,:]
    total=0
    stable_trees=0
    for T in itertools.combinations(range(len(edges)),n-1):
        M=D[:-1,list(T)]
        if not M.det():continue
        F=M.inv()*RHS
        if all(next((x for x in F.row(a) if x),0)>0 for a in range(n-1)):
            stable_trees+=1
            total+=sp.prod(edges[a][2] for a in T)
    return int(total),stable_trees


cases=[[(1,0),(0,1)],[(1,0),(1,1),(0,1)],
       [(1,0),(1,0),(0,1)],[(1,0),(1,0),(0,1),(0,1)],
       [(1,0),(1,0),(1,1),(0,1)],
       [(1,0),(1,1),(1,1),(0,1)],
       [(1,0),(1,0),(1,0),(0,1)],
       [(2,0),(1,1),(0,1)],
       [(1,0),(1,0),(1,1),(0,1),(0,1)]]
rows=[]
for charges in cases:
    eta=eta_of(charges)
    h=event_ih(eta)
    count,trees=nearby_tree_count(eta)
    rows.append({"charges":charges,"eta":eta,"fan_ih":h,
                 "nearby_tree_count":count,"simple_stable_trees":trees,
                 "agrees":h["trace_total"]==count})
    print(charges,h["trace_total"],count,flush=True)

# Three repeated leaves and a hub, with two arrows from each leaf to hub.
# The polytope is a product of three segments, so a 3-cycle has trace 1+t^3.
eta=[[0,0,0,-2],[0,0,0,-2],[0,0,0,-2],[2,2,2,0]]
order_three=event_ih(eta,[1,2,0,3])
assert order_three["graded_traces"]==[1,0,0,1]
assert all(r["agrees"] for r in rows)
data={"checks":rows,"order_three_star":order_three,"all_pass":True}
Path(__file__).with_suffix(".json").write_text(json.dumps(data,indent=2))
