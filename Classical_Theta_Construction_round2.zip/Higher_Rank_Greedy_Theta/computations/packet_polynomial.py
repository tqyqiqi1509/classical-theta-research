"""Finite theta coefficients with formal elementary packet weights.

For each initial color i replace (1+z_i) by
1 + A[i,1] z_i + ... + A[i,d_i] z_i**d_i.
This is an auxiliary finite polynomial computation for classical theta
coefficients.  It does not assert a new generalized cluster basis.

Sparse integer polynomials are computed directly, without relying on
positivity or a presumed combinatorial model.  Their nonnegative output
is the target for a constructive packet model and a symmetric-group lift.
"""
from __future__ import annotations
from collections import defaultdict
from functools import lru_cache
from itertools import product
from math import factorial
from pathlib import Path
import argparse, json, sys, time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'agents'))
from incoming_recursion import IncomingSchur, ibinom, box, le, sub


def partitions_counts(k, maximum):
    """Multiplicities of parts 1,...,maximum with weighted sum k."""
    def rec(j, left, acc):
        if j==maximum+1:
            if left==0: yield tuple(acc)
            return
        for m in range(left//j+1):
            yield from rec(j+1,left-j*m,acc+[m])
    yield from rec(1,k,[])


class PacketTheta(IncomingSchur):
    def __init__(self, B, D, cap):
        self.cap=tuple(cap)
        self.variables=tuple((i,k) for i in range(len(B))
                             for k in range(1,cap[i]+1))
        self.variable_position={a:j for j,a in enumerate(self.variables)}
        self.mzero=(0,)*len(self.variables)
        self.one={self.mzero:1}
        self.additions=0
        self.products=0
        self.scalar_products=0
        super().__init__(B,D)
        self.S=lru_cache(None)(self._S)
        self.axis=lru_cache(None)(self._axis)

    def add(self,a,b,sign=1):
        self.additions+=1
        out=dict(a)
        for k,v in b.items():
            out[k]=out.get(k,0)+sign*v
            if not out[k]: del out[k]
        return out

    def mul(self,a,b):
        self.products+=1
        if not a or not b:return {}
        if a==self.one:return b
        if b==self.one:return a
        out=defaultdict(int)
        for u,x in a.items():
            for v,y in b.items():
                self.scalar_products+=1
                out[tuple(i+j for i,j in zip(u,v))]+=x*y
        return {k:v for k,v in out.items() if v}

    def _axis(self,i,k,m):
        out={}
        for counts in partitions_counts(k,min(k,self.cap[i])):
            length=sum(counts)
            value=ibinom(-m,length)*factorial(length)
            for count in counts:value//=factorial(count)
            if not value:continue
            mon=list(self.mzero)
            for j,count in enumerate(counts,1):
                mon[self.variable_position[i,j]]=count
            out[tuple(mon)]=value
        return out

    def _S(self,a):
        return tuple(q for q in box(a) if q!=a and q!=self.zero
                     and self.sign(a,q)>0)

    def _c(self,a,m):
        if not any(a):return self.one
        support=[i for i,x in enumerate(a) if x]
        if len(support)==1:
            i=support[0]
            return self.axis(i,a[i],m[i])
        v={}
        for s in self.S(a):
            value=self.c(s,m)
            for q,vq in v.items():
                if le(q,s):
                    value=self.add(value,self.mul(self.c(sub(s,q),self.shift(m,q)),vq),-1)
            v[s]=value
        ans={}
        for s,vs in v.items():
            ans=self.add(ans,self.mul(self.c(sub(a,s),self.shift(m,s)),vs))
        return ans

    def theta_polynomial_prefix(self,g,roots=None,progress=None):
        roots=box(self.cap) if roots is None else sorted(roots,key=lambda q:(sum(q),q))
        out={self.zero:self.one}
        for p in roots[1:]:
            mp=self.shift(g,p)
            I=[q for q in roots if le(q,p) and (q==p or
               sum(mp[i]*self.D[i]*(p[i]-q[i]) for i in range(self.n))<0)]
            t={p:self.one}
            for q in reversed(I[:-1]):
                v={}
                for r,tr in t.items():
                    if le(q,r):
                        v=self.add(v,self.mul(tr,self.c(sub(r,q),self.shift(g,q))),-1)
                t[q]=v
            ans={}
            for q in I[:-1]:ans=self.add(ans,self.mul(t[q],out[q]),-1)
            out[p]=ans
            if progress:progress(p,ans,self)
        return out

    def classical_specialization(self,poly):
        """A[i,1]=1 and A[i,k]=0 for k>1."""
        return sum(c for u,c in poly.items()
                   if all(k==1 or u[j]==0 for j,(i,k) in enumerate(self.variables)))

    def encode(self,poly):
        return [{'packets':[[i,k,u[j]] for j,(i,k) in enumerate(self.variables) if u[j]],
                 'coefficient':v} for u,v in sorted(poly.items())]


def run(case, output, progress_file=None):
    started=time.time()
    B=case['B'];D=case.get('D',[1]*len(B));g=tuple(case['g']);cap=tuple(case['cap'])
    engine=PacketTheta(B,D,cap)
    last_report=[started]
    def report(p,poly,E):
        if progress_file and (time.time()-last_report[0]>20 or p==cap):
            row={'time':time.time(),'elapsed_seconds':time.time()-started,
                 'root':p,'packet_monomials':len(poly),'products':E.products,
                 'scalar_products':E.scalar_products,'cache':str(E.c.cache_info())}
            with open(progress_file,'a') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
            last_report[0]=time.time()
    data=engine.theta_polynomial_prefix(g,progress=report)
    classical=IncomingSchur(B,D).theta_prefix(g,cap)
    mismatches=[];negative=[]
    for p,F in data.items():
        got=engine.classical_specialization(F)
        if got!=classical.get(p,0):mismatches.append([p,got,classical.get(p,0)])
        for u,c in F.items():
            if c<0:negative.append({'root':p,'packets':u,'coefficient':c})
    result={'case':case,'seconds':time.time()-started,'negative_packet_coefficients':negative,
            'classical_mismatches':mismatches,'root_count':len(data),
            'packet_monomial_count':sum(map(len,data.values())),
            'additions':engine.additions,'products':engine.products,
            'scalar_products':engine.scalar_products,'cache':str(engine.c.cache_info()),
            'coefficients':[{'root':p,'polynomial':engine.encode(F)} for p,F in data.items() if F]}
    Path(output).write_text(json.dumps(result,indent=2))
    assert not mismatches,mismatches[:3]
    print(json.dumps({k:v for k,v in result.items() if k!='coefficients'}),flush=True)
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--case',required=True)
    ap.add_argument('--output',required=True)
    ap.add_argument('--progress')
    args=ap.parse_args()
    run(json.loads(Path(args.case).read_text()),args.output,args.progress)
