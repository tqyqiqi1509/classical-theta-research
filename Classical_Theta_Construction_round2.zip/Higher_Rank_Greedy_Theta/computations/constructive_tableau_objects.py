"""Enumerate the positive graph/fan/tableau objects without character averaging.

Local star labels are explicit semistandard tableaux.  Other local labels are
the rational intertwiner bases constructed by local_specht_basis.py.  The
construction takes B,g,p only and never calls an incoming/theta algorithm.
"""
from pathlib import Path
import sys,json,time
from itertools import product
from functools import lru_cache

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from orbit_schur_positive import OrbitSchurModel,partitions,transpose
from local_specht_basis import local_multiplicity_basis,sparse_data


@lru_cache(None)
def ssyt(shape,alphabet_size):
    """Actual tableaux: weakly increasing rows and strictly increasing columns."""
    if len(shape)>alphabet_size:return ()
    cells=tuple((i,j) for i,row in enumerate(shape) for j in range(row))
    rows=[[0]*a for a in shape];answer=[]
    def rec(k):
        if k==len(cells):
            answer.append(tuple(tuple(r) for r in rows));return
        i,j=cells[k]
        low=max(rows[i][j-1] if j else 0,rows[i-1][j]+1 if i else 0)
        for v in range(low,alphabet_size):
            rows[i][j]=v;rec(k+1)
    rec(0)
    return tuple(answer)


class ConstructiveTableauModel(OrbitSchurModel):
    def __init__(self,B,g,p):
        super().__init__(B,g,p)
        self.local_cache={};self.local_basis_records={}
        self.objects=lru_cache(None)(self._objects)

    def local_labels(self,eta,groups,shapes):
        key=(eta,groups,shapes)
        if key in self.local_cache:return self.local_cache[key]
        n=len(eta)
        hub=next((h for h in range(n) if all(eta[h][i] for i in range(n) if i!=h)
                  and all(not eta[i][j] for i in range(n) for j in range(n)
                          if i!=h and j!=h)),None)
        if hub is not None:
            alphabets=tuple(1 if hub in g else abs(eta[hub][g[0]]) for g in groups)
            labels=tuple(('star-tableaux',t) for t in product(*(ssyt(s,d) for s,d in zip(shapes,alphabets))))
            record={'kind':'star-tableaux','shapes':shapes,'alphabets':alphabets,
                    'multiplicity':len(labels)}
        else:
            r=local_multiplicity_basis(eta,groups,shapes)
            labels=tuple(('intertwiner',j) for j in range(r['multiplicity']))
            record={'kind':'actual-fan-intertwiners','shapes':shapes,
                    'local_dimension':r['local'].dimension,
                    'multiplicity':len(labels),'basis':[sparse_data(M) for M in r['basis']]}
        self.local_cache[key]=labels;self.local_basis_records[repr(key)]=record
        return labels

    def _objects(self,sig):
        if sig[0]=='L':return (('leaf',sig[1]),)
        children=sig[1];types=tuple(sorted(set(children)))
        child_bases=tuple(self.objects(t) for t in types)
        if any(not b for b in child_bases):return ()
        groups=tuple(tuple(i for i,c in enumerate(children) if c==t) for t in types)
        charges=tuple(self.charge(c) for c in children);CE=self.model.color_eta
        eta=tuple(tuple(sum(a[i]*CE[i][j]*b[j] for i in range(len(a)) for j in range(len(b)))
                        for b in charges) for a in charges)
        twists=tuple((sum(self.charge(t))+self.parity(t))%2 for t in types)
        answer=[]
        for shapes in product(*(partitions(len(g)) for g in groups)):
            local_labels=self.local_labels(eta,groups,shapes)
            if not local_labels:continue
            child_shapes=tuple(transpose(s) if e else s for s,e in zip(shapes,twists))
            decorations=tuple(ssyt(s,len(b)) for s,b in zip(child_shapes,child_bases))
            for local_label in local_labels:
                for tabs in product(*decorations):
                    # Entries are themselves fully constructed child objects.
                    expanded=tuple(tuple(tuple(b[x] for x in row) for row in tab)
                                   for tab,b in zip(tabs,child_bases))
                    answer.append(('node',shapes,local_label,expanded))
        return tuple(answer)

    def enumerate(self):
        return tuple((sig,self.objects(sig)) for sig in self.root_types)


def main():
    cases=[([[0,2,-3],[-2,0,2],[3,-2,0]],(-3,3,-2),(2,2,1)),
           ([[0,-1,2],[1,0,2],[-2,-2,0]],(1,-3,0),(2,2,1)),
           ([[0,1],[-1,0]],(-6,1),(4,2))]
    output=[]
    for B,g,p in cases:
        start=time.time();M=ConstructiveTableauModel(B,g,p);objects=M.enumerate()
        counts=tuple(len(b) for t,b in objects);value=sum(counts)
        # Compare only after all actual object labels and local bases exist.
        sys.path.insert(0,str(HERE.parent/'agents'))
        from incoming_recursion import IncomingSchur
        independent=IncomingSchur(B,[1]*len(B)).theta_prefix(g,p)[tuple(p)]
        assert value==independent
        row={'B':B,'g':g,'p':p,'orbit_counts':counts,'object_count':value,
             'independent_theta':independent,'pass':True,
             'objects':objects,'local_basis_records':M.local_basis_records,
             'seconds':time.time()-start}
        output.append(row)
        Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2))
        print(json.dumps({k:v for k,v in row.items() if k not in ('objects','local_basis_records')}),flush=True)


if __name__=='__main__':main()
