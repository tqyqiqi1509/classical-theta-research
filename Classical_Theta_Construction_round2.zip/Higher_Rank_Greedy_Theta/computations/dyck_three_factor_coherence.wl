Module[{p,q,r,x,y,hgt,wid,ell, s, identity, partitions, strip},
identity = FullSimplify[
 {p (r+q)+r Max[q-p,0] == q (p+r)+r Max[p-q,0],
  p (r+q)+r Max[q-p,0] == p q+r Max[p,q]},
 Assumptions -> p>0 && q>0 && r>0 && Element[{p,q,r},Reals]];
partitions = {
 Reduce[p>0&&q>=p&&r>0&&0<=x<p&&0<=y<q&&
   !(0<=y<q&&0<=x<p), {p,q,r,x,y}, Reals],
 Reduce[p>0&&q>=p&&r>0&&0<=x<p&&q<=y<q+r&&
   !(0<=x<p&&p<=p+y-q<p+r), {p,q,r,x,y}, Reals],
 Reduce[p>0&&q>p&&r>0&&0<=x<r&&0<=y<q-p&&
   !(p<=p+y<q&&p<=p+x<p+r), {p,q,r,x,y}, Reals]};
strip = And@@Flatten[Table[Floor[(s+ell)/wid] == Boole[s>=wid-ell],
 {wid,1,256},{ell,1,wid},{s,0,wid-1}]];
<|"TrilinearIdentity"->identity,
 "CounterexampleSetsForThreeRectanglePieces"->partitions,
 "IntegralStripFloorCheck"->strip,
 "StripScalarChecks"->Sum[wid^2,{wid,1,256}]|>]
