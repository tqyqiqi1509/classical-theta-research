"""Local primitive characters by exact degree-weighted Laurent jets at t=1.

This implements the finite HN / balanced-partition identities proved in the
many-slope combinatorial bridge. It uses an alternating matrix, permutations,
and rational arithmetic. No scattering, theta, or fan oracle is used by the
constructor. The optional main() comparisons are made only afterwards.

A weight-w series is stored as h**(-w) times a polynomial modulo h**(N+1),
where h=t-1 and N is the number of labels in the requested local problem.
All products are therefore ordinary truncated polynomial products. This is
the precision needed for all intermediate poles, not numerical sampling.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import comb
from pathlib import Path
import json,sys,time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'squarefree_polytope_action'))
from local_species_trace_audit import (set_partitions,cycle_orbits,restrict,
                                      arrow_count,eta_from_types)


def integer_binomial(a,k):
    if k<0:return 0
    if a>=0:return comb(a,k) if k<=a else 0
    return (-1)**k*comb(k-a-1,k)


@dataclass(frozen=True)
class Jet:
    weight:int
    coefficients:tuple


class LocalPrimitiveJets:
    def __init__(self,precision_weight):
        self.N=precision_weight
        self.ss=lru_cache(None)(self._ss)
        self.primitive_stack=lru_cache(None)(self._primitive_stack)
        self.t_power=lru_cache(None)(self._t_power)
        self.unit_power=lru_cache(None)(self._unit_power)
        self.calls={'semistable':0,'primitive':0,'products':0}

    def zero(self,w):return Jet(w,(Q(0),)*(self.N+1))

    def scalar(self,c=1):
        return Jet(0,(Q(c),)+(Q(0),)*self.N)

    def add(self,A,B,sign=1):
        assert A.weight==B.weight
        return Jet(A.weight,tuple(a+sign*b for a,b in zip(A.coefficients,B.coefficients)))

    def scale(self,A,c):
        return Jet(A.weight,tuple(c*a for a in A.coefficients))

    def poly_mul(self,a,b):
        self.calls['products']+=1
        out=[Q(0)]*(self.N+1)
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b[:self.N+1-i]):
                    if y:out[i+j]+=x*y
        return tuple(out)

    def mul(self,A,B):
        assert A.weight+B.weight<=self.N
        return Jet(A.weight+B.weight,self.poly_mul(A.coefficients,B.coefficients))

    def poly_inv(self,a):
        assert a[0]
        b=[1/a[0]]
        for n in range(1,self.N+1):
            b.append(-sum(a[j]*b[n-j] for j in range(1,n+1))/a[0])
        return tuple(b)

    def _t_power(self,a):
        return Jet(0,tuple(Q(integer_binomial(a,j)) for j in range(self.N+1)))

    def _unit_power(self,k,j):
        """(((1+h)^k-1)/h)^j, including negative integer powers."""
        base=tuple(Q(integer_binomial(k,i+1)) for i in range(self.N+1))
        if j<0:base=self.poly_inv(base);j=-j
        result=self.scalar().coefficients
        while j:
            if j&1:result=self.poly_mul(result,base)
            j//=2
            if j:base=self.poly_mul(base,base)
        return result

    def adams(self,A,k):
        """Substitute t -> t^k and multiply the charge weight by k."""
        w=A.weight;new_w=k*w
        assert new_w<=self.N
        if k==1:return A
        out=[Q(0)]*(self.N+1)
        for i,c in enumerate(A.coefficients):
            if not c:continue
            exponent=i-w;start=new_w+exponent
            if start>self.N:continue
            assert start>=0
            p=self.unit_power(k,exponent)
            for j in range(self.N+1-start):out[start+j]+=c*p[j]
        return Jet(new_w,tuple(out))

    def stack_all(self,eta,sigma):
        n=len(eta);cycles=cycle_orbits(sigma)
        result=self.t_power(n-arrow_count(eta)).coefficients
        for C in cycles:
            # h/(1-(1+h)^(2|C|)).
            den=tuple(-Q(integer_binomial(2*len(C),j+1)) for j in range(self.N+1))
            result=self.poly_mul(result,self.poly_inv(den))
        shift=n-len(cycles)
        return Jet(n,(Q(0),)*shift+result[:self.N+1-shift])

    def _ss(self,eta,sigma,theta,kappa):
        self.calls['semistable']+=1
        n=len(eta)
        if not n:return self.scalar()
        cycles=cycle_orbits(sigma)
        answer=self.stack_all(eta,sigma)
        for cycle_partition in set_partitions(tuple(range(len(cycles)))):
            if len(cycle_partition)<2:continue
            blocks=[tuple(sorted(a for c in C for a in cycles[c])) for C in cycle_partition]
            slopes=[Q(sum(theta[a] for a in B),sum(kappa[a] for a in B)) for B in blocks]
            if len(set(slopes))!=len(slopes):continue
            blocks=[B for _,B in sorted(zip(slopes,blocks),reverse=True)]
            term=self.scalar()
            for B in blocks:
                sub_eta,sub_sigma=restrict(eta,sigma,B)
                value=self.ss(sub_eta,sub_sigma,tuple(theta[a] for a in B),tuple(kappa[a] for a in B))
                term=self.mul(term,value)
                if not any(term.coefficients):break
            if not any(term.coefficients):continue
            twist=sum(eta[a][b] for i,A in enumerate(blocks) for B in blocks[i+1:]
                      for a in A for b in B)
            answer=self.add(answer,self.mul(self.t_power(twist),term),-1)
        return answer

    def _primitive_stack(self,eta,sigma,kappa):
        """Return H(t)*Omega(t), with H=t/(1-t^2)."""
        self.calls['primitive']+=1
        n=len(eta)
        theta=tuple(-sum(eta[a][b] for a in range(n)) for b in range(n))
        answer=self.ss(eta,sigma,theta,kappa)
        if n==1:return answer
        for partition in set_partitions(tuple(range(n))):
            if len(partition)<2:continue
            if any(sum(theta[a] for a in C)!=0 for C in partition):continue
            blocks={frozenset(C) for C in partition}
            image=lambda C:frozenset(sigma[a] for a in C)
            if {image(C) for C in blocks}!=blocks:continue
            unseen=set(blocks);term=self.scalar()
            while unseen:
                C=min(unseen,key=lambda x:(len(x),tuple(sorted(x))))
                D=C;k=0
                while True:
                    unseen.remove(D);k+=1;D=image(D)
                    if D==C:break
                sub_eta,return_sigma=restrict(eta,sigma,C,k)
                value=self.primitive_stack(sub_eta,return_sigma,tuple(kappa[a] for a in sorted(C)))
                value=self.adams(value,k)
                if ((k-1)*arrow_count(eta,C))%2:value=self.scale(value,-1)
                term=self.mul(term,value)
                if not any(term.coefficients):break
            if not any(term.coefficients):continue
            answer=self.add(answer,term,-1)
        # The local primitive is regular at t=1, hence H*Omega has at most
        # one pole. This checks exact cancellation, not floating tolerance.
        assert not any(answer.coefficients[:n-1]),(eta,sigma,answer)
        return answer

    def trace(self,eta,sigma,kappa=None):
        n=len(eta)
        assert n<=self.N and n>0
        if kappa is None:kappa=(1,)*n
        P=self.primitive_stack(tuple(map(tuple,eta)),tuple(sigma),tuple(kappa))
        value=-2*P.coefficients[n-1]
        assert value.denominator==1,(eta,sigma,value)
        return int(value)


def main():
    started=time.time();results=[]
    # All conjugacy classes from the previous structural local calculations.
    cases=[]
    for m in (1,2,7,101):
        types=((1,0),(1,0),(0,1),(0,1))
        for sigma in ((0,1,2,3),(1,0,2,3),(1,0,3,2)):
            cases.append((f'K22_m{m}',types,sigma,m))
    cases += [
        ('three_slopes',((1,0),(1,0),(0,1),(0,1),(1,1)),(1,0,3,2,4),1),
        ('parallel_return',((1,0),(0,1),(1,1),(1,1)),(0,1,3,2),2),
        ('four_slopes',((1,0),(1,1),(1,2),(0,1)),(0,1,2,3),1),
        ('K33_identity',((1,0),)*3+((0,1),)*3,(0,1,2,3,4,5),1),
        ('K33_33',((1,0),)*3+((0,1),)*3,(1,2,0,4,5,3),1),
    ]
    for name,types,sigma,m in cases:
        local_start=time.time();eta=eta_from_types(types,m)
        engine=LocalPrimitiveJets(len(types))
        value=engine.trace(eta,sigma,tuple(sum(b) for b in types))
        if name.startswith('K22'):
            swaps=int(sigma[0]!=0)+int(sigma[2]!=2)
            expected=(2*m**3,2*m*m,2*m*(m%2))[swaps]
            comparison='proved K22 formula'
        else:
            from orbit_schur_positive import local_trace
            expected=local_trace(eta,sigma);comparison='independent fan calculation'
        row={'name':name,'types':types,'sigma':sigma,'arrow_multiplicity':m,
             'trace':value,'comparison':comparison,'expected':expected,
             'pass':value==expected,'calls':engine.calls,'seconds':time.time()-local_start}
        results.append(row);print(json.dumps(row),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps({'results':results,
            'all_pass':all(r['pass'] for r in results),'seconds':time.time()-started},indent=2))
        assert row['pass']


if __name__=='__main__':main()
