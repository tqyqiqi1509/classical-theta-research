"""Independent support-vs-fan audit of the many-slope balanced identity.

No theta coefficient, scattering wall, Hall algebra, or quiver-moduli oracle
is used. The left side is an explicit sum of finite arrow supports. The right
side is an independent normal-fan minimal-extension calculation plus set
partitions. Parallel balanced blocks must have zero connected primitive.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import combinations, permutations, product
from pathlib import Path
import json
import sys
import sympy as sp

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'natural_incoming_module'))
from equivariant_toric_ih import event_ih
q=sp.Symbol('q')

def det(a,b):return a[0]*b[1]-a[1]*b[0]

def cycles(p):
    seen=set();out=[]
    for x in range(len(p)):
        if x in seen:continue
        c=[];y=x
        while y not in seen:seen.add(y);c.append(y);y=p[y]
        out.append(c)
    return out

def perm_sign(p):return (-1)**(len(p)-len(cycles(p)))

def partitions(vertices):
    if not vertices:
        yield ();return
    x,*rest=vertices
    for rho in partitions(rest):
        yield ((x,),)+rho
        for i,C in enumerate(rho):
            yield rho[:i]+(tuple(sorted((x,)+C)),)+rho[i+1:]

def normalize(rho):return tuple(sorted(tuple(sorted(C)) for C in rho))

def v_sum(charges,C):return tuple(sum(charges[i][j] for i in C) for j in (0,1))

def semistable(support,theta,n):
    for mask in range(1,1<<n):
        if sum(theta[i] for i in range(n) if mask>>i&1)<=0:continue
        if not any((mask>>i&1) and not(mask>>j&1) for i,j in support):return False
    return True

def support_sum(charges,p):
    """Collapse parallel-arrow return cycles only after summing all nonempty supports."""
    n=len(charges);S=v_sum(charges,range(n))
    theta=[-det(S,a) for a in charges]
    pairs={(i,j):det(charges[i],charges[j]) for i in range(n) for j in range(n)
           if det(charges[i],charges[j])>0}
    unseen=set(pairs);orbits=[]
    while unseen:
        edge=min(unseen);O=[];e=edge
        while e not in O:
            O.append(e);unseen.remove(e);e=(p[e[0]],p[e[1]])
        orbits.append((O,pairs[edge]))
    ans=0;count=0
    for chosen in product((0,1),repeat=len(orbits)):
        H=[e for use,(O,m) in zip(chosen,orbits) if use for e in O]
        if not semistable(H,theta,n):continue
        count+=1;w=sp.Integer(1)
        for use,(O,m) in zip(chosen,orbits):
            if use:w*=q**(len(O)*m)-1
        ans+=w
    den=sp.prod(q**len(C)-1 for C in cycles(p))
    return sp.cancel(ans/den),count,len(orbits)

@lru_cache(None)
def fan_character(charges,p):
    n=len(charges)
    if n==1:return sp.Integer(1)
    if all(det(charges[0],a)==0 for a in charges):return sp.Integer(0)
    eta=[[det(a,b) for b in charges] for a in charges]
    r=event_ih(eta,list(p))
    return sum(sp.Integer(a)*q**i for i,a in enumerate(r['graded_traces']))

def partition_side(charges,p,wrong_parallel=False):
    n=len(charges);S=v_sum(charges,range(n));ans=0;number=0
    for rho0 in partitions(list(range(n))):
        rho=normalize(rho0)
        if any(det(S,v_sum(charges,C)) for C in rho):continue
        image=normalize([tuple(p[i] for i in C) for C in rho])
        if image!=rho:continue
        number+=1;indices={C:i for i,C in enumerate(rho)}
        bp=[indices[tuple(sorted(p[i] for i in C))] for C in rho]
        cross=0;epsilon=1
        for i,C in enumerate(rho):
            for j in range(i+1,len(rho)):
                D=rho[j]
                m=sum(max(det(charges[u],charges[v]),0) for u in C for v in D)
                opposite=sum(max(det(charges[v],charges[u]),0) for u in C for v in D)
                assert m==opposite
                cross+=m
                if bp[i]>bp[j]:epsilon*=(-1)**m
        term=sp.Integer(epsilon)*q**cross
        for O in cycles(bp):
            C=rho[O[0]];ell=len(O);cp=[]
            for i in C:
                j=i
                for _ in range(ell):j=p[j]
                cp.append(C.index(j))
            local=tuple(charges[i] for i in C)
            R=fan_character(local,tuple(cp))
            if wrong_parallel and len(C)>1 and R==0:R=sp.Integer(1)
            term*=R.subs(q,q**ell)/(q**ell-1)
        ans+=term
    return sp.cancel(ans),number

def main():
    cases=[
        ('three_slopes',((1,0),(0,1),(1,1))),
        ('parallel_balanced_pair',((1,0),(0,1),(1,1),(1,1))),
        ('parallel_balanced_triple',((1,0),(0,1),(1,1),(1,1),(1,1))),
        ('four_distinct_slopes',((1,0),(0,1),(1,1),(2,1))),
        ('nonprimitive_middle',((1,0),(0,1),(2,2))),
        ('balanced_block_orbit_sign',((1,0),(1,0),(0,1),(0,1),(1,1))),
    ]
    rows=[]
    for label,ch in cases:
        n=len(ch)
        perms=[p for p in permutations(range(n)) if all(ch[i]==ch[p[i]] for i in range(n))]
        for p in perms:
            lhs,nss,norb=support_sum(ch,p)
            rhs,nparts=partition_side(ch,p)
            delta=sp.cancel(lhs-rhs)
            row={'case':label,'charges':ch,'permutation':p,
                 'pair_orbits':norb,'tested_endpoint_supports':2**norb,
                 'semistable_endpoint_supports':nss,'balanced_invariant_partitions':nparts,
                 'fan_ih_character':str(fan_character(ch,p)),
                 'support_sum':str(lhs),'partition_sum':str(rhs),'difference':str(delta)}
            if label=='parallel_balanced_pair':
                bad,_=partition_side(ch,p,wrong_parallel=True)
                row['wrong_point_IH_convention_residual']=str(sp.cancel(lhs-bad))
            assert delta==0,row
            rows.append(row)
            print(label,p,'IH=',row['fan_ih_character'],'difference=',delta,flush=True)
    # A symbolic identity valid in every two-dimensional alternating space.
    s1,s2,c1,c2,x1,x2,k1,k2=sp.symbols('s1 s2 c1 c2 x1 x2 k1 k2')
    S=(s1,s2);C=(c1,c2);x=(x1,x2)
    kap=lambda a:k1*a[0]+k2*a[1]
    closure=sp.expand(det(S,x)*kap(C)-det(S,C)*kap(x)-kap(S)*det(C,x))
    assert closure==0
    # The smallest graph-cone action that cannot preserve any matching of
    # opposite arrows: transpose the two forward arrows, fix both reverse.
    # Its positive circulation supports must use both directions.
    Z=1+q;cone_dim=3
    independent_arrow_sum=Z
    for rev in ((1,0),(0,1),(1,1)):
        arrow_det=(q**2-1)*(q-1)**sum(rev)
        independent_arrow_sum+=sp.cancel(arrow_det/(q-1))
    arrow_residual=sp.expand(q**cone_dim*Z.subs(q,1/q)-independent_arrow_sum)
    assert arrow_residual==0
    out={'method':'Explicit finite support sums versus independent equivariant normal-fan IH',
         'all_passed':True,'case_characters':len(rows),
         'endpoint_supports_tested':sum(r['tested_endpoint_supports'] for r in rows),
         'general_rank_two_closure_symbolic_residual':str(closure),
         'independent_opposite_arrow_contraction_residual':str(arrow_residual),'cases':rows}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
