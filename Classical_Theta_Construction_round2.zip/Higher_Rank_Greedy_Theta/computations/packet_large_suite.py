"""Exact higher-rank packet polynomials for the symmetric-group mechanism.

Each job is a different structural class, including genuinely valued data
and mixed framings.  These are verification/discovery data for a general
module construction, not assertions based on a finite sample.
"""
from pathlib import Path
import json, subprocess, sys, time, resource

HERE=Path(__file__).resolve().parent

def valued(D, upper):
    from math import gcd
    n=len(D); B=[[0]*n for _ in D]
    for (i,j),b in upper.items():
        d=gcd(D[i],D[j])
        B[i][j]=D[j]//d*b; B[j][i]=-D[i]//d*b
    return B

cases=[
 ('cyclic_rank3_degree24', {'B':[[0,3,-3],[-3,0,3],[3,-3,0]],'D':[1]*3,'g':[-1,0,0],'cap':[8]*3}),
 ('valued_rank4_degree16', {'B':valued([1,2,1,2],{(0,1):1,(0,2):-1,(0,3):3,(1,2):2,(1,3):-1,(2,3):2}),'D':[1,2,1,2],'g':[-1,1,-1,0],'cap':[4]*4}),
 ('cyclic_rank5_degree15', {'B':valued([1]*5,{(0,1):2,(0,2):-1,(0,3):1,(0,4):-2,(1,2):3,(1,3):-1,(1,4):1,(2,3):2,(2,4):-1,(3,4):2}),'D':[1]*5,'g':[-1,0,1,-2,0],'cap':[3]*5}),
 ('valued_rank6_degree12', {'B':valued([1,1,2,2,3,3],{(0,1):1,(0,2):-1,(0,3):1,(0,4):0,(0,5):-1,(1,2):1,(1,3):-1,(1,4):1,(1,5):0,(2,3):1,(2,4):-1,(2,5):1,(3,4):1,(3,5):-1,(4,5):1}),'D':[1,1,2,2,3,3],'g':[-1,1,0,-1,2,0],'cap':[2]*6})
]

def limits():
    # Keep this isolated research process from exhausting the shared host.
    resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
    resource.setrlimit(resource.RLIMIT_CPU,(10800,10800))

started=time.time(); results=[]
for name,case in cases:
    target=HERE/(name+'_packet_results.json')
    inp=HERE/(name+'_packet_case.json')
    log=HERE/(name+'_packet_progress.jsonl')
    inp.write_text(json.dumps(case))
    print(json.dumps({'event':'start','name':name,'utc_epoch':time.time(),'case':case}),flush=True)
    t=time.time()
    cp=subprocess.run([sys.executable,str(HERE/'packet_polynomial.py'),'--case',str(inp),'--output',str(target),'--progress',str(log)],preexec_fn=limits)
    row={'name':name,'exit_code':cp.returncode,'seconds':time.time()-t}
    if target.exists():
        data=json.loads(target.read_text())
        row.update({k:data[k] for k in ['root_count','packet_monomial_count','products','scalar_products','negative_packet_coefficients','classical_mismatches']})
    results.append(row)
    (HERE/'packet_large_suite_results.json').write_text(json.dumps({'seconds':time.time()-started,'jobs':results},indent=2))
    print(json.dumps({'event':'finished',**row}),flush=True)
print(json.dumps({'event':'suite_complete','seconds':time.time()-started}),flush=True)
