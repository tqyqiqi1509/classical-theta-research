"""Positive orbit/Schur recursion for the intrinsic graph/fan module.

The constructor uses only the direct partition grammar, local fan characters,
and ordinary symmetric-group representation theory.  It never evaluates theta
coefficients.  The final main() comparison imports a separate oracle only after
the positive recursion is complete.
"""
from pathlib import Path
import sys, json, time
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import product
from math import factorial, prod

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'computations'/'intrinsic_partition_model'),
               str(ROOT/'computations'/'natural_incoming_module')]
from intrinsic_partitions import PartitionModel
from equivariant_toric_ih import event_ih


@lru_cache(None)
def partitions(n, maximum=None):
    if not n:
        return ((),)
    maximum = n if maximum is None else min(n, maximum)
    return tuple((a,)+b for a in range(maximum, 0, -1)
                 for b in partitions(n-a, a))


def zpart(mu):
    return prod(a**m*factorial(m) for a,m in Counter(mu).items())


@lru_cache(None)
def character(lam, mu):
    """Murnaghan--Nakayama, with explicit connected border-strip removal."""
    if not mu:
        return int(not lam)
    rem = sum(lam)-mu[0]
    if rem < 0:
        return 0
    outer = {(i,j) for i,row in enumerate(lam) for j in range(row)}
    ans = 0
    for nu in partitions(rem):
        if len(nu)>len(lam) or any(nu[i]>lam[i] for i in range(len(nu))):
            continue
        strip = outer-{(i,j) for i,row in enumerate(nu) for j in range(row)}
        if not strip or any({(i,j),(i+1,j),(i,j+1),(i+1,j+1)}<=strip
                            for i,j in strip):
            continue
        seen = {next(iter(strip))}; todo = list(seen)
        while todo:
            i,j = todo.pop()
            for v in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
                if v in strip and v not in seen:
                    seen.add(v); todo.append(v)
        if len(seen)==len(strip):
            ans += (-1)**(len({i for i,j in strip})-1)*character(nu, mu[1:])
    return ans


def transpose(lam):
    return tuple(sum(a>j for a in lam) for j in range(lam[0])) if lam else ()


def tableau_count(lam, alphabet_size):
    """Number of semistandard tableaux, by the exact hook-content formula."""
    if len(lam)>alphabet_size:
        return 0
    ans = Fraction(1)
    for i,row in enumerate(lam):
        for j in range(row):
            hook = row-j+sum(a>j for a in lam[i+1:])
            ans *= Fraction(alphabet_size+j-i, hook)
    assert ans.denominator==1 and ans>=0
    return int(ans)


def cycles(sigma):
    unseen = set(range(len(sigma))); ans = []
    while unseen:
        i = min(unseen); c = []; j = i
        while j in unseen:
            unseen.remove(j); c.append(j); j = sigma[j]
        ans.append(tuple(c))
    return tuple(ans)


@lru_cache(None)
def local_trace(eta, sigma):
    """A local graph/fan calculation; no global character or theta input."""
    n = len(eta)
    for hub in range(n):
        if (all(eta[hub][i] for i in range(n) if i!=hub)
            and all(not eta[i][j] for i in range(n) for j in range(n)
                    if i!=hub and j!=hub) and sigma[hub]==hub):
            return prod(abs(eta[hub][c[0]]) for c in cycles(sigma) if hub not in c)
    # Proven complete K_(2,2),m family, including the identity class.
    if n==4:
        groups = set(tuple(j for j in range(n) if not eta[i][j]) for i in range(n))
        if len(groups)==2 and all(len(a)==2 for a in groups):
            a,b = sorted(groups)
            if set(a).isdisjoint(b) and all(sigma[i] in c for c in (a,b) for i in c):
                magnitudes = {abs(eta[i][j]) for i in a for j in b}
                if len(magnitudes)==1:
                    m = next(iter(magnitudes))
                    swaps = sum(sigma[c[0]]!=c[0] for c in (a,b))
                    return (2*m**3, 2*m*m, 2*m*(m%2))[swaps]
    return int(event_ih(eta, sigma)['trace_total'])


class OrbitSchurModel:
    def __init__(self, B, g, p):
        if any(B[i][j]!=-B[j][i] for i in range(len(B)) for j in range(len(B))):
            raise ValueError('The natural local fan module here requires skew-symmetric B.')
        self.model = PartitionModel(B, [1]*len(B), g, p)
        self.labelled_trees = self.model.trees()
        self.root_types = tuple(sorted({self.signature(t) for t in self.labelled_trees}))
        self.records = {}
        self.value = lru_cache(None)(self._value)
        self.charge = lru_cache(None)(self._charge)

    def signature(self, tree):
        if isinstance(tree, int):
            return ('L', self.model.colors[tree])
        return ('N', tuple(sorted(self.signature(c) for c in tree)))

    def _charge(self, sig):
        if sig[0]=='L':
            return tuple(int(i==sig[1]) for i in range(self.model.n+1))
        cs = [self.charge(c) for c in sig[1]]
        return tuple(sum(c[i] for c in cs) for i in range(self.model.n+1))

    def parity(self, sig):
        a = self.charge(sig); eta = self.model.color_eta
        return sum(eta[i][j]*a[i]*a[j] for i in range(len(a))
                   for j in range(i+1,len(a))) % 2

    def _value(self, sig):
        if sig[0]=='L':
            return 1
        children = sig[1]
        types = tuple(sorted(set(children)))
        multiplicities = tuple(children.count(t) for t in types)
        values = tuple(self.value(t) for t in types)
        if not all(values):
            self.records[repr(sig)] = {'value':0, 'reason':'zero child coefficient space'}
            return 0
        groups = [tuple(i for i,c in enumerate(children) if c==t) for t in types]
        charges = [self.charge(c) for c in children]
        color_eta = self.model.color_eta
        eta = tuple(tuple(sum(a[i]*color_eta[i][j]*b[j]
                              for i in range(len(a)) for j in range(len(b)))
                          for b in charges) for a in charges)
        classes = tuple(product(*(partitions(m) for m in multiplicities)))
        traces = {}
        trace_function = getattr(self, 'trace_function', local_trace)
        for mus in classes:
            sigma = list(range(len(children)))
            for inds,mu in zip(groups,mus):
                off=0
                for k in mu:
                    cyc=inds[off:off+k];off+=k
                    for j,a in enumerate(cyc):sigma[a]=cyc[(j+1)%k]
            traces[mus] = trace_function(eta, tuple(sigma))
        twists = tuple((sum(self.charge(t))+self.parity(t))%2 for t in types)
        terms = []; answer = 0
        for lams in classes:
            mult = sum(Fraction(traces[mus]*prod(character(lam,mu)
                                  for lam,mu in zip(lams,mus)),
                                prod(zpart(mu) for mu in mus)) for mus in classes)
            assert mult.denominator==1 and mult>=0, (sig,lams,mult)
            if not mult:
                continue
            shapes = tuple(transpose(lam) if twist else lam
                           for lam,twist in zip(lams,twists))
            tableaux = tuple(tableau_count(lam,d) for lam,d in zip(shapes,values))
            contribution = int(mult)*prod(tableaux)
            if contribution:
                terms.append({'local_specht_shapes':lams,'local_multiplicity':int(mult),
                              'tableau_shapes':shapes,'child_dimensions':values,
                              'tableau_counts':tableaux,'contribution':contribution})
                answer += contribution
        self.records[repr(sig)] = {'value':answer, 'eta':eta,
            'child_multiplicities':multiplicities,'child_values':values,
            'sign_twists':twists,'positive_terms':terms}
        return answer

    def coefficient(self):
        values = tuple(self.value(t) for t in self.root_types)
        return sum(values), values


def main():
    cases = [
        ([[0,2,-3],[-2,0,2],[3,-2,0]],(-3,3,-2),(2,2,1)),
        ([[0,1],[-1,0]],(-4,1),(3,1)),
        ([[0,-1,2],[1,0,2],[-2,-2,0]],(1,-3,0),(2,2,1)),
        ([[0,1],[-1,0]],(-6,1),(4,2)),
        ([[0,0],[0,0]],(-5,-4),(3,2)),
    ]
    out=[]
    for B,g,p in cases:
        start=time.time(); M=OrbitSchurModel(B,g,p); value,parts=M.coefficient()
        # The independent theta comparison is deliberately last.
        sys.path.insert(0,str(ROOT/'agents'))
        from incoming_recursion import IncomingSchur
        target=IncomingSchur(B,[1]*len(B)).theta_prefix(g,p).get(tuple(p),0)
        row={'B':B,'g':g,'p':p,'labelled_trees':len(M.labelled_trees),
             'unlabelled_orbits':len(M.root_types),'positive_orbit_contributions':parts,
             'positive_formula':value,'independent_theta':target,'pass':value==target,
             'seconds':time.time()-start,'local_records':M.records}
        out.append(row)
        print(json.dumps({k:v for k,v in row.items() if k!='local_records'}),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
        assert value==target


if __name__=='__main__':
    main()
