"""Exact exhaustive checks of the all-Hom forbidden-cut identity.

Every edge is a separate formal indeterminate. Thus bit-mask containment
is exact divisibility of squarefree monomials, not a numerical substitution.
The proof in agents/klr_incoming_bridge.md covers arbitrary polynomials.
"""
from itertools import combinations, permutations, product
from pathlib import Path
import json
import time


def minimal_masks(gens):
    out = []
    for x in sorted(set(gens), key=lambda z: (z.bit_count(), z)):
        if not any(y & x == y for y in out):
            out.append(x)
    return tuple(sorted(out))


def checks(n, all_graphs):
    vertices = tuple(range(n))
    edges = tuple(combinations(vertices, 2))
    full = (1 << len(edges)) - 1
    words = tuple(permutations(vertices))
    positions = [{v: j for j, v in enumerate(w)} for w in words]
    comparisons = [sum((p[a] < p[b]) << k for k, (a, b) in enumerate(edges))
                   for p in positions]
    graphs = range(full + 1) if all_graphs else [full]
    records = []
    for signs in product((-1, 1), repeat=n - 1):
        first = [signs[i] * 2**i for i in range(n - 1)]
        theta = first + [-sum(first)]
        bad_subsets = [s for s in range(1, 2**n - 1)
                       if sum(theta[i] for i in vertices if s >> i & 1) < 0]
        bad_words = [j for j, w in enumerate(words)
                     if any(sum(theta[i] for i in w[:k]) < 0
                            for k in range(1, n))]
        cut_masks = []
        for p in positions:
            cuts = []
            for s in bad_subsets:
                mask = 0
                for k, (a, b) in enumerate(edges):
                    tail, head = (b, a) if p[a] < p[b] else (a, b)
                    if s >> tail & 1 and not (s >> head & 1):
                        mask |= 1 << k
                cuts.append(mask)
            cut_masks.append(cuts)
        count = 0
        for graph in graphs:
            for iv, cv in enumerate(comparisons):
                for iw, cw in enumerate(comparisons):
                    common = graph & (full ^ (cv ^ cw))
                    from_bad_words = minimal_masks(
                        (cv ^ comparisons[j]) & common for j in bad_words)
                    from_cuts = minimal_masks(cut & common for cut in cut_masks[iv])
                    assert from_bad_words == from_cuts, {
                        "n": n, "graph": graph, "theta": theta,
                        "v": words[iv], "w": words[iw],
                        "word_ideal": from_bad_words, "cut_ideal": from_cuts}
                    count += 1
        records.append({"theta": theta, "word_pairs_graphs": count,
                        "bad_words": len(bad_words)})
    return {"n": n, "graphs": len(graphs), "words": len(words),
            "checks": sum(x["word_pairs_graphs"] for x in records),
            "records": records}


def main():
    started = time.monotonic()
    records = [checks(3, True), checks(4, True), checks(5, False)]
    out = {"theorem": "all-Hom cut ideal", "status": "all passed",
           "checks": sum(x["checks"] for x in records),
           "seconds": round(time.monotonic() - started, 3), "records": records}
    dest = Path(__file__).with_name("all_hom_cut_identity_results.json")
    dest.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({k: v for k, v in out.items() if k != "records"}))


if __name__ == "__main__":
    main()
