"""Flatten and reconstruct literal valued Dyck coefficient objects.

Semantic vertices are original-color leaves, parallel-product assembly
vertices, and actual two-input Dyck vertices.  Unary state/event/union
choices are finite source flags.  Normal-copy zero slots are compressed
as unique empty choices; no unselected word occurrence is stored.
"""
from collections import Counter
from math import gcd
from pathlib import Path
import hashlib
import json
import time

from tight_grading_two_input import dyck_word, direct_compatible, is_tight
from universal_dyck_object_factory import UniversalDyckObjects, leaf_profiles
from valued_event_flag_grammar import extended_data


def vector_sum(vectors, rank):
    return tuple(sum(v[i] for v in vectors) for i in range(rank))


def strip_context(obj):
    context = []
    while True:
        if 'union_branch' in obj:
            context.append(('union', obj['union_branch']))
            obj = obj['object']
        elif 'tag' in obj and obj['tag'][0] in ('state', 'event'):
            context.append(('tag', obj['tag']))
            obj = obj['object']
        else:
            return context, obj


def wrap_context(context, obj):
    for kind, label in reversed(context):
        obj = ({'union_branch': label, 'object': obj} if kind == 'union'
               else {'tag': label, 'object': obj})
    return obj


def flatten(obj, rank):
    context, core = strip_context(obj)
    if 'ordered_product' in core:
        children = [flatten(child, rank) for child in core['ordered_product']]
        assert len(children) >= 2
        result = {'kind': 'parallel_assembly', 'context': context,
                  'children': children,
                  'charge': vector_sum([c['charge'] for c in children], rank)}
        # Every product here lies outside a local grading; it is a
        # Cauchy product of occurrences on a single ambient ray.
        rho = primitive(result['charge'])
        assert all(primitive(c['charge']) == rho for c in children)
    elif core['tag'][0] == 'original_axis_leaf':
        label = core['tag']
        color, k = label[1], label[2] if len(label) > 2 else 1
        charge = tuple(k if i == color else 0 for i in range(rank))
        assert core['object'] == {'unit': True}
        result = {'kind': 'leaf', 'context': context, 'leaf_tag': label,
                  'charge': charge, 'children': []}
    else:
        birth = core['tag']
        assert birth[0] == 'birth'
        _, alpha, beta, gamma, a, b, degree, address = birth
        children, copies = [], []

        def normal_layout(value):
            if 'union_branch' in value:
                return ('union', value['union_branch'], normal_layout(value['object']))
            if 'ordered_product' in value:
                return ('product', tuple(normal_layout(x) for x in value['ordered_product']))
            normal = value['tag']
            assert normal[0] == 'normal_copy'
            slot, multiplicity, j = normal[1:]
            if j == 0:
                assert value['object'] == {'unit': True}
                return ('zero_copy', normal)
            grading_context, grading_obj = strip_context(value['object'])
            grading_tag = grading_obj['tag']
            assert grading_tag[0] == 'tight_grading'
            _, rectangle, word, weights, j_tag, divisors = grading_tag
            assert j_tag == ('degree', j)
            v, u = divisors[1:]
            assert ''.join(dyck_word(*rectangle)) == word
            assert direct_compatible(word, weights) and is_tight(word, weights)
            assert len(word) == len(weights)
            expected = [tuple((w//v)*x for x in alpha) if edge == 'N'
                        else tuple((w//u)*x for x in beta)
                        for edge, w in zip(word, weights) if w]
            assert all(w % (v if edge == 'N' else u) == 0
                       for edge, w in zip(word, weights))
            assert sum(w for edge, w in zip(word, weights) if edge == 'N') == j*a*v
            assert sum(w for edge, w in zip(word, weights) if edge == 'E') == j*b*u
            decorations = grading_obj['object']['ordered_product']
            assert len(decorations) == len(expected) >= 2
            start = len(children)
            parsed = [flatten(x, rank) for x in decorations]
            assert [tuple(x['charge']) for x in parsed] == expected
            children.extend(parsed)
            copy = {'normal_tag': normal, 'grading_context': grading_context,
                    'grading_tag': grading_tag, 'child_range': (start, len(children))}
            copies.append(copy)
            return ('copy', len(copies)-1)

        layout = normal_layout(core['object'])
        assert sum(c['normal_tag'][3] for c in copies) == degree
        charge = tuple(degree*x for x in gamma)
        assert vector_sum([c['charge'] for c in children], rank) == charge
        assert len(children) >= 2
        result = {'kind': 'dyck', 'context': context, 'birth_tag': birth,
                  'charge': charge, 'copies': copies, 'normal_layout': layout,
                  'children': children}
    for kind, label in context:
        if kind == 'tag' and label[0] == 'state':
            assert tuple(label[1]) == tuple(result['charge'])
    return result


def primitive(charge):
    d = gcd(*charge)
    return tuple(x//d for x in charge)


def unflatten(tree):
    children = [unflatten(c) for c in tree['children']]
    if tree['kind'] == 'leaf':
        core = {'tag': tree['leaf_tag'], 'object': {'unit': True}}
    elif tree['kind'] == 'parallel_assembly':
        core = {'ordered_product': children}
    else:
        def restore(layout):
            kind = layout[0]
            if kind == 'union':
                return {'union_branch': layout[1], 'object': restore(layout[2])}
            if kind == 'product':
                return {'ordered_product': [restore(x) for x in layout[1]]}
            if kind == 'zero_copy':
                return {'tag': layout[1], 'object': {'unit': True}}
            assert kind == 'copy'
            c = tree['copies'][layout[1]]
            start, end = c['child_range']
            grading = {'tag': c['grading_tag'],
                       'object': {'ordered_product': children[start:end]}}
            value = wrap_context(c['grading_context'], grading)
            return {'tag': c['normal_tag'], 'object': value}
        core = {'tag': tree['birth_tag'], 'object': restore(tree['normal_layout'])}
    return wrap_context(tree['context'], core)


def tree_statistics(tree, N, M):
    result = Counter(leaves=0, internal_vertices=0, nonempty_paths=0,
                     path_edges=0, max_path_edges=0, max_weight=0,
                     nonprimitive_births=0, parallel_assemblies=0)
    profile = []

    def visit(node, depth=1):
        result['height'] = max(result['height'], depth)
        if node['kind'] == 'leaf':
            result['leaves'] += 1
            label = node['leaf_tag']
            profile.append((label[1], label[2] if len(label) > 2 else 1))
            return
        result['internal_vertices'] += 1
        if node['kind'] == 'parallel_assembly':
            result['parallel_assemblies'] += 1
        else:
            if gcd(*node['birth_tag'][3]) > 1:
                result['nonprimitive_births'] += 1
            for copy in node['copies']:
                result['nonempty_paths'] += 1
                tag = copy['grading_tag']
                path_size = len(tag[2])
                result['path_edges'] += path_size
                result['max_path_edges'] = max(result['max_path_edges'], path_size)
                result['max_weight'] = max(result['max_weight'], max(tag[3]))
                assert path_size <= 4*M*N*N
                assert max(tag[3]) <= M*N*N
                assert copy['normal_tag'][2] <= M*N*N
        for c in node['children']:
            visit(c, depth+1)
    visit(tree)
    assert sum(k for _, k in profile) == N
    assert result['leaves'] <= N
    assert result['internal_vertices'] <= result['leaves']-1
    assert result['nonempty_paths'] <= N-1
    assert result['path_edges'] <= 4*M*N*N*(N-1)
    assert result['height'] <= N
    return result, tuple(sorted(profile))


def main():
    start = time.monotonic()
    source = json.loads(Path(__file__).with_name('valued_event_formal_profiles.json').read_text())
    reports = []
    total = 0
    for case in source['results']:
        B, D, g, p = case['B'], case['D'], tuple(case['g']), tuple(case['p'])
        Bhat, Dhat = extended_data(B, D, g)
        model = UniversalDyckObjects(Bhat, Dhat)
        root = model.framed_theta(g, p)
        count = model.sets.cardinality(root)
        N, M = 1+sum(p), max(abs(Dhat[i]*Bhat[i][j])
                             for i in range(model.r) for j in range(model.r))
        hashes, actual_profiles, maxima = set(), Counter(), Counter()
        nonprimitive_example = first = None
        nonprimitive_objects = parallel_objects = 0
        for index in range(count):
            obj = model.sets.select(root, index)
            tree = flatten(obj, model.r)
            assert unflatten(tree) == obj
            stats, profile = tree_statistics(tree, N, M)
            actual_profiles[profile] += 1
            for key, value in stats.items():
                maxima[key] = max(maxima[key], value)
            encoded = json.dumps(tree, separators=(',', ':'), sort_keys=True)
            digest = hashlib.sha256(encoded.encode()).hexdigest()
            assert digest not in hashes
            hashes.add(digest)
            nonprimitive_objects += bool(stats['nonprimitive_births'])
            parallel_objects += bool(stats['parallel_assemblies'])
            if stats['nonprimitive_births'] and nonprimitive_example is None:
                nonprimitive_example = tree
            if first is None:
                first = tree
        assert actual_profiles == leaf_profiles(model.sets, root)
        row = {'name': case['name'], 'objects_exhaustively_checked': count,
               'inverse_equal_for_every_object': True,
               'flattened_objects_distinct': True,
               'enumerated_leaf_profile_equal': True,
               'N': N, 'M': M, 'maxima': dict(maxima),
               'objects_with_nonprimitive_births': nonprimitive_objects,
               'objects_with_parallel_assembly': parallel_objects,
               'first_flattened_object': first,
               'nonprimitive_flattened_example': nonprimitive_example}
        reports.append(row)
        total += count
        print(json.dumps({k: row[k] for k in ('name', 'objects_exhaustively_checked',
                         'maxima', 'objects_with_nonprimitive_births',
                         'objects_with_parallel_assembly')}), flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(
            {'status': 'RUNNING', 'objects_checked': total, 'results': reports}, indent=2))
    report = {'status': 'PASS', 'objects_checked': total, 'cases': len(reports),
              'results': reports, 'seconds': time.monotonic()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({k: report[k] for k in ('status', 'objects_checked', 'cases', 'seconds')}))


if __name__ == '__main__':
    main()
