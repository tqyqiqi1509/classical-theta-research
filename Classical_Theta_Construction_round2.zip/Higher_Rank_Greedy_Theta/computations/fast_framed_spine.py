"""Exact framed-spine set recipes without scanning long Dyck paths.

The construction is the proved singleton atom-split rule: at frame
degree one, an unframed input F and a framed input beta contribute
[t^a]F^Q times the beta decoration, Q=|K|/w(unframed).  The Q slots
are represented by their occupied-position simplex, not enumerated.
Both-framed fusion is one explicit residue in [0,|K|).

Unframed/unframed vertices use the unchanged literal Dyck factory.
No cardinality is called until each complete actual-set recipe exists.
"""
from functools import cmp_to_key
from itertools import combinations
from math import comb
from pathlib import Path
import json
import time

from dyck_object_factory import DyckObjects, FiniteSets
from valued_event_flag_grammar import add, scale, le, sign, extended_data, box


def positive_compositions(total, length):
    """Ordered positive compositions; complexity depends on degree only."""
    if length == 0:
        if total == 0:
            yield ()
        return
    if length == 1:
        if total > 0:
            yield (total,)
        return
    for first in range(1, total-length+2):
        for rest in positive_compositions(total-first, length-1):
            yield (first,)+rest


class SlotSets(FiniteSets):
    """Add the literal integer simplex 0<=s1<...<sk<Q."""
    def __init__(self):
        self.cardinality_queries = 0
        super().__init__()

    def selected_slots(self, size, occupied):
        assert size >= 0 and occupied >= 0
        if occupied > size:
            return 0
        if occupied == 0:
            return 1
        return self.node(('selected_slots', int(size), int(occupied)))

    def _cardinality(self, identifier):
        self.cardinality_queries += 1
        node = self.nodes[identifier]
        if node[0] == 'selected_slots':
            return comb(node[1], node[2])
        return super()._cardinality(identifier)

    def select(self, identifier, index=0):
        node = self.nodes[identifier]
        if node[0] != 'selected_slots':
            return super().select(identifier, index)
        size, occupied = node[1:]
        if not 0 <= index < comb(size, occupied):
            raise IndexError(index)
        selected, lower = [], 0
        # Binary-search the lexicographic combination; never scan size slots.
        for remain in range(occupied, 0, -1):
            base = comb(size-lower, remain)
            lo, hi = lower, size-remain
            while lo < hi:
                middle = (lo+hi+1)//2
                before = base-comb(size-middle, remain)
                if before <= index:
                    lo = middle
                else:
                    hi = middle-1
            index -= base-comb(size-lo, remain)
            selected.append(lo)
            lower = lo+1
        return {'selected_slots': selected, 'ambient_slots': size}


def slot_power_coefficient(sets, F, slots, degree):
    """Actual coefficient set of (1+sum F[k]t^k)^slots.

    An object is an increasing occupied-slot tuple, a positive degree
    composition attached to these slots, and one F-decoration per slot.
    The slot positions are inequalities, not a list of slots.
    """
    assert isinstance(sets, SlotSets) and slots >= 0 and degree >= 0
    if degree == 0:
        return 1
    branches = []
    for occupied in range(1, min(slots, degree)+1):
        positions = sets.selected_slots(slots, occupied)
        for composition in positive_compositions(degree, occupied):
            decorations = sets.product(F.get(part, 0) for part in composition)
            child = sets.product((positions, decorations))
            branches.append(sets.tag(('slot_word', slots, composition), child))
    return sets.union(branches)


class FastFramedSpineObjects(DyckObjects):
    """Drop-in global factory; frame coordinates have weight/cutoff one."""
    def __init__(self, B, D, max_swaps=None, frame_indices=(0,)):
        self.frame_indices = tuple(frame_indices)
        assert all(D[i] == 1 for i in self.frame_indices)
        super().__init__(B, D, max_swaps=max_swaps)
        self.sets = SlotSets()

    def two_inputs(self, left, right, S):
        a, F, aid, _ = left
        b, G, bid, _ = right
        af = any(a[i] for i in self.frame_indices)
        bf = any(b[i] for i in self.frame_indices)
        if not (af or bf) or any(S[i] > 1 for i in self.frame_indices):
            self.stats['unframed_dyck_operations'] += 1
            return super().two_inputs(left, right, S)
        m = self.pair(a, b)
        assert m > 0
        outputs = []

        def emit(s, t, coefficient, operation):
            gamma = add(scale(s, a), scale(t, b))
            if not le(gamma, S) or coefficient == 0:
                return
            assert self.weight(gamma) == 1
            identifier = (aid, bid, s, t)
            coefficient = self.sets.tag(operation, coefficient)
            value = self.sets.tag(('birth', a, b, gamma, s, t, 1, identifier), coefficient)
            outputs.append((gamma, {1: value}, identifier, True))
            self.stats['born_factors'] += 1

        if af and bf:
            # Shared frame coordinates cannot fit the cutoff; disjoint ones fuse.
            gamma = add(a, b)
            if le(gamma, S):
                assert self.weight(a) == self.weight(b) == 1
                residue = self.sets.selected_slots(m, 1)
                coefficient = self.sets.product((residue, F.get(1, 0), G.get(1, 0)))
                emit(1, 1, coefficient, ('two_frame_fusion_strip', m))
                self.stats['fast_fusions'] += 1
        else:
            unframed, polynomial = (b, G) if af else (a, F)
            framed_decoration = F.get(1, 0) if af else G.get(1, 0)
            weight = self.weight(unframed)
            assert m % weight == 0
            slots = m//weight
            cap = min(S[i]//unframed[i] for i in range(self.r) if unframed[i])
            for degree in range(1, cap+1):
                s, t = (1, degree) if af else (degree, 1)
                if not le(add(scale(s, a), scale(t, b)), S):
                    continue
                power = slot_power_coefficient(self.sets, polynomial, slots, degree)
                coefficient = self.sets.product((power, framed_decoration))
                emit(s, t, coefficient, ('framed_spine', 'left' if af else 'right', slots, degree))
                self.stats['fast_spine_coefficients'] += 1
            self.stats['fast_spine_operations'] += 1
        outputs.sort(key=cmp_to_key(lambda x, y: sign(self.pair(x[0], y[0]))))
        return outputs


def main():
    begin = time.monotonic()
    cases = [
        ('valued_parallel_obstruction', [[0,2],[-1,0]], [1,2], (-6,2), (2,2)),
        ('cyclic_valued', [[0,2,-1],[-1,0,1],[1,-2,0]], [1,2,1],
         (-3,-2,1), (1,1,1)),
        ('cyclic_repeated', [[0,2,-2],[-2,0,2],[2,-2,0]], [1,1,1],
         (-1,-1,-1), (2,2,1)),
    ]
    rows, recipes = [], []
    for name, B, D, g, p in cases:
        Bhat, Dhat = extended_data(B, D, g)
        fast, slow = FastFramedSpineObjects(Bhat, Dhat), DyckObjects(Bhat, Dhat)
        start = time.monotonic()
        root = fast.framed_theta(g, p)
        construct_seconds = time.monotonic()-start
        assert fast.sets.cardinality_queries == 0
        oldroot = slow.framed_theta(g, p)
        value, oldvalue = fast.sets.cardinality(root), slow.sets.cardinality(oldroot)
        assert value == oldvalue
        actual = [fast.sets.select(root, i) for i in range(value)]
        assert len({json.dumps(x, sort_keys=True) for x in actual}) == value
        rows.append({'name': name, 'count': value, 'slow_literal_count': oldvalue,
                     'fast_nodes': len(fast.sets.nodes), 'slow_nodes': len(slow.sets.nodes),
                     'construction_seconds': construct_seconds, 'stats': dict(fast.stats)})
        recipes.append({'name': name, 'root': root, 'nodes': fast.sets.nodes,
                        'actual_objects': actual})

    # Reuse the previously verified twelve-coefficient valued multiplication.
    from theta_multiplication_objects import ThetaMultiplicationObjects
    B, D = [[0,2,-1],[-1,0,1],[1,-2,0]], [1,2,1]
    g1, g2, cap = (-1,-1,1), (-1,2,2), (2,1,1)
    fast = ThetaMultiplicationObjects(B, D, g1, g2, factory=FastFramedSpineObjects)
    slow = ThetaMultiplicationObjects(B, D, g1, g2)
    roots = {p: fast.coefficient(p) for p in box(cap)}
    assert fast.sets.cardinality_queries == 0
    multiplication = []
    for p, root in roots.items():
        oldroot = slow.coefficient(p)
        value = fast.sets.cardinality(root)
        assert value == slow.sets.cardinality(oldroot)
        multiplication.append({'degree': p, 'count': value})
    recipes.append({'name': 'cyclic_valued_multiplication', 'nodes': fast.sets.nodes,
                    'roots': [(p, root) for p, root in roots.items()]})

    # Verify combinadic materialization separately, including every small slot tuple.
    sets = SlotSets()
    for size in range(1, 9):
        for occupied in range(1, size+1):
            node = sets.selected_slots(size, occupied)
            assert [tuple(sets.select(node, j)['selected_slots'])
                    for j in range(comb(size, occupied))] == list(combinations(range(size), occupied))

    # Large Q test calls the integrated local operation while path calls are forbidden.
    from unittest.mock import patch
    large = []
    for slots in (10, 10**50):
        model = FastFramedSpineObjects([[0,slots],[-slots,0]], [1,1])
        ss = model.sets
        F = {1: ss.union(ss.tag(('A',j)) for j in range(2)),
             2: ss.union(ss.tag(('B',j)) for j in range(3))}
        with patch('dyck_object_factory.tight_profiles', side_effect=AssertionError('Dyck scan forbidden')):
            output = model.two_inputs(((1,0), {1:1}, 'frame', False),
                                      ((0,1), F, 'polynomial', False), (1,5))
        root = next(H[1] for carrier,H,_,_ in output if carrier == (1,5))
        assert ss.cardinality_queries == 0
        node_count = len(ss.nodes)
        value = ss.cardinality(root)
        expected = sum(comb(slots, 5-j)*comb(5-j,j)*2**(5-2*j)*3**j for j in range(3))
        assert value == expected
        large.append({'slots': slots, 'degree': 5, 'recipe_nodes': node_count,
                      'count': value, 'independent_polynomial_count': expected,
                      'first_actual_object': ss.select(root,0),
                      'last_actual_object': ss.select(root,value-1),
                      'dyck_path_calls': 0, 'stats': dict(model.stats)})
    assert large[0]['recipe_nodes'] == large[1]['recipe_nodes']

    recipe_path = Path(__file__).with_name('fast_framed_spine_recipes.json')
    recipe_path.write_text(json.dumps(recipes, separators=(',', ':')))
    report = {'status': 'PASS', 'scalar_cases': rows,
              'multiplication_coefficients': multiplication,
              'multiplication_fast_nodes': len(fast.sets.nodes),
              'multiplication_slow_nodes': len(slow.sets.nodes),
              'multiplication_stats': [dict(m.stats) for m in fast.factors],
              'large_slot_checks': large, 'recipe_file': recipe_path.name,
              'definition_calls_cardinality': False,
              'integration': 'global DyckObjects subclass and ThetaMultiplicationObjects factory',
              'seconds': time.monotonic()-begin}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
