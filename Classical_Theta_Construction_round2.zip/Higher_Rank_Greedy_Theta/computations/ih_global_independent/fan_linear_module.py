"""Finite rational matrices for canonical combinatorial intersection cohomology.

No character formula, tree count, or theta oracle enters this construction.
The only input is a bounded polytope in nonnegative slack coordinates, its
linear constraint row space, and permutations of the slack coordinates.
A point with every slack coordinate strictly positive is assumed, as it is
automatic for the anti-attractor flow polytopes used in this project.
Polynomial degrees are half cohomological degrees.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import product
import json,time
from pathlib import Path
import sympy as s


def cols(M):
    return M[:,list(M.rref()[1])]


def nullcols(M):
    v=M.nullspace()
    return s.Matrix.hstack(*v) if v else s.zeros(M.cols,0)


@lru_cache(None)
def monomials(n,h):
    if n==0:return ((),) if h==0 else ()
    if n==1:return ((h,),)
    return tuple((k,)+a for k in range(h+1) for a in monomials(n-1,h-k))


def linear_multiply(poly,linear):
    out={}
    for a,c in poly.items():
        for j,x in enumerate(linear):
            if x:
                b=list(a);b[j]+=1;b=tuple(b)
                out[b]=out.get(b,0)+c*x
    return {a:c for a,c in out.items() if c}


def substitute_monomial(a,A):
    """Pull a source monomial back by source coordinates = A target coords."""
    out={(0,)*A.cols:s.Integer(1)}
    for i,k in enumerate(a):
        for _ in range(k):out=linear_multiply(out,list(A.row(i)))
    return out


class FanModule:
    def __init__(self,incidence,vertices,max_degree=None):
        self.D=s.Matrix(incidence);self.e=self.D.cols
        self.R=s.Matrix.hstack(*self.D.nullspace()).T if self.D.nullspace() else s.zeros(0,self.e)
        self.d=self.R.rows;self.bound=self.d if max_degree is None else max_degree
        zsets=[frozenset(i for i,x in enumerate(v) if not x) for v in vertices]
        faces={frozenset()}
        for z in zsets:faces|={z}|{a&z for a in tuple(faces)}
        self.faces=sorted(faces,key=lambda I:(len(I),tuple(I)))
        self.V={I:cols(self.R[:,sorted(I)]) for I in self.faces}
        self.facets={I:[J for J in self.faces if J<I and not any(J<K<I for K in self.faces)] for I in self.faces}
        self.maximal=[I for I in self.faces if not any(I<J for J in self.faces)]
        self.generators={};self.bases={};self.restrictions={};self.local_mult={}
        self.genrestr={};self.boundary={};self.global_sections={};self.global_reps={};self.global_rel={}
        self.build()

    def coordinate_restriction(self,I,J):
        if not self.V[J].cols:return s.zeros(self.V[I].cols,0)
        return self.V[I].gauss_jordan_solve(self.V[J])[0]

    def basis(self,I,h):return self.bases[I,h]

    def multiply(self,I,h,poly):
        """E_I[h] -> E_I[h+degree(poly)] (homogeneous poly)."""
        deg=sum(next(iter(poly))) if poly else 0
        src=self.basis(I,h);dst=self.basis(I,h+deg);ix={a:i for i,a in enumerate(dst)}
        M=s.zeros(len(dst),len(src))
        for j,(g,a) in enumerate(src):
            for b,c in poly.items():M[ix[g,tuple(x+y for x,y in zip(a,b))],j]+=c
        return M

    def compatible(self,cones,h):
        offsets={};width=0
        for I in cones:offsets[I]=width;width+=len(self.basis(I,h))
        rows=[]
        for a,I in enumerate(cones):
            for J in cones[a+1:]:
                K=I&J;ni=len(self.basis(K,h))
                if not ni:continue
                M=s.zeros(ni,width)
                M[:,offsets[I]:offsets[I]+len(self.basis(I,h))]=self.restrictions[I,K,h]
                M[:,offsets[J]:offsets[J]+len(self.basis(J,h))]=-self.restrictions[J,K,h]
                rows.append(M)
        C=s.Matrix.vstack(*rows) if rows else s.zeros(0,width)
        return nullcols(C),offsets

    def boundary_mult(self,I,h,j):
        fs=self.facets[I]
        blocks=[]
        for F in fs:
            A=self.coordinate_restriction(I,F)
            lin={(tuple(1 if k==a else 0 for k in range(A.cols))):A[j,a] for a in range(A.cols) if A[j,a]}
            blocks.append(self.multiply(F,h,lin) if lin else s.zeros(len(self.basis(F,h+1)),len(self.basis(F,h))))
        return s.diag(*blocks) if blocks else s.zeros(0,0)

    def build(self):
        empty=frozenset();self.generators[empty]=[0]
        for h in range(self.bound+1):
            self.bases[empty,h]=[(0,())] if not h else []
            self.restrictions[empty,empty,h]=s.eye(len(self.bases[empty,h]))
        for I in self.faces:
            if not I:continue
            k=self.V[I].cols;gd=[];glifts=[]
            for h in range((k+1)//2):
                B,offsets=self.compatible(self.facets[I],h);self.boundary[I,h]=B
                if h:
                    prev=self.boundary[I,h-1]
                    images=[self.boundary_mult(I,h-1,j)*prev for j in range(k)]
                    M=s.Matrix.hstack(*images) if images else s.zeros(B.rows,0)
                else:M=s.zeros(B.rows,0)
                piv=(M.row_join(B)).rref()[1]
                chosen=[j-M.cols for j in piv if j>=M.cols]
                for j in chosen:gd.append(h);glifts.append((h,B[:,j],offsets))
            self.generators[I]=gd
            for h in range(self.bound+1):
                self.bases[I,h]=[(g,a) for g,r in enumerate(gd) if r<=h for a in monomials(k,h-r)]
                self.restrictions[I,I,h]=s.eye(len(self.bases[I,h]))
            for g,(h,b,off) in enumerate(glifts):
                for J in self.faces:
                    if not J<I:continue
                    F=next(F for F in self.facets[I] if J<=F)
                    bf=b[off[F]:off[F]+len(self.basis(F,h)),0]
                    self.genrestr[I,J,g]=self.restrictions[F,J,h]*bf
            for J in self.faces:
                if not J<I:continue
                A=self.coordinate_restriction(I,J)
                for h in range(self.bound+1):
                    M=s.zeros(len(self.basis(J,h)),len(self.basis(I,h)))
                    for c,(g,a) in enumerate(self.basis(I,h)):
                        poly=substitute_monomial(a,A)
                        if poly:M[:,c]=self.multiply(J,gd[g],poly)*self.genrestr[I,J,g]
                    self.restrictions[I,J,h]=M
        self.global_offsets={}
        for h in range(self.bound+1):
            B,offs=self.compatible(self.maximal,h);self.global_sections[h]=B;self.global_offsets[h]=offs
            images=[]
            if h:
                for j in range(self.d):
                    blocks=[]
                    for I in self.maximal:
                        linear=list(self.V[I].row(j))
                        poly={tuple(1 if k==a else 0 for k in range(len(linear))):c for a,c in enumerate(linear) if c}
                        blocks.append(self.multiply(I,h-1,poly) if poly else s.zeros(len(self.basis(I,h)),len(self.basis(I,h-1))))
                    images.append(s.diag(*blocks)*self.global_sections[h-1])
            M=s.Matrix.hstack(*images) if images else s.zeros(B.rows,0)
            M=cols(M);piv=M.row_join(B).rref()[1]
            chosen=[j-M.cols for j in piv if j>=M.cols]
            self.global_rel[h]=M;self.global_reps[h]=B[:,chosen]

    def action(self,permutation):
        P=s.zeros(self.e)
        for i,j in enumerate(permutation):P[j,i]=1
        A=(self.R*P)*self.R.T*(self.R*self.R.T).inv() if self.d else s.zeros(0)
        assert A*self.R==self.R*P
        image=lambda I:frozenset(permutation[i] for i in I)
        maps={};empty=frozenset()
        for h in range(self.bound+1):maps[empty,h]=s.eye(len(self.basis(empty,h)))
        for I in self.faces:
            if not I:continue
            J=image(I);k=self.V[I].cols
            # g*f is f after g^{-1}; both are rational polynomial modules.
            change=(self.V[J].gauss_jordan_solve(A*self.V[I])[0]).inv()
            genimages=[]
            for g,h in enumerate(self.generators[I]):
                target=[];restriction=[]
                for F in self.facets[J]:
                    E=next(E for E in self.facets[I] if image(E)==F)
                    target.append(maps[E,h]*self.genrestr[I,E,g])
                    restriction.append(self.restrictions[J,F,h])
                bb=s.Matrix.vstack(*target);rr=s.Matrix.vstack(*restriction)
                xx,params=rr.gauss_jordan_solve(bb)
                assert params.rows==0,'Local vanishing must force uniqueness'
                genimages.append(xx)
            for h in range(self.bound+1):
                M=s.zeros(len(self.basis(J,h)),len(self.basis(I,h)))
                for c,(g,a) in enumerate(self.basis(I,h)):
                    pol=substitute_monomial(a,change)
                    M[:,c]=self.multiply(J,self.generators[I][g],pol)*genimages[g]
                maps[I,h]=M
        out={}
        for h in range(self.bound+1):
            ambient=s.zeros(self.global_sections[h].rows)
            off=self.global_offsets[h]
            for I in self.maximal:
                J=image(I);M=maps[I,h]
                ambient[off[J]:off[J]+M.rows,off[I]:off[I]+M.cols]=M
            relations=self.global_rel[h];reps=self.global_reps[h]
            total=relations.row_join(reps)
            coordinates=total.gauss_jordan_solve(ambient*reps)[0]
            out[h]=coordinates[relations.cols:,:]
        return out

    def dimensions(self):return [self.global_reps[h].cols for h in range(self.bound+1)]

    def ungraded_action(self,permutation):
        """Actual ungraded action, using equivariant PD for uncomputed high degrees.

        Enough local computation is bound >= floor(d/2). A chosen basis in
        degree h has its dual basis in degree d-h; hence the latter action
        is inverse-transpose. This constructs matrices, not only characters.
        """
        if self.bound<self.d//2:raise ValueError('Need every degree through floor(d/2)')
        a=self.action(permutation)
        blocks=[a[h] if h in a else a[self.d-h].inv().T for h in range(self.d+1)]
        return s.diag(*blocks)


def sign_subspace(generator_matrices):
    """Basis of the sign-isotypic space for adjacent-transposition matrices."""
    if not generator_matrices:raise ValueError('Supply at least one generator matrix')
    n=generator_matrices[0].rows
    return nullcols(s.Matrix.vstack(*(a+s.eye(n) for a in generator_matrices)))


def octahedron():
    facets=list(product((-1,1),repeat=3));vertices=[]
    for i in range(3):
        for sign in (-1,1):vertices.append([1-sign*a[i] for a in facets])
    delta=s.Matrix([[v[j]-vertices[0][j] for j in range(8)] for v in vertices[1:]])
    D=s.Matrix.hstack(*delta.nullspace()).T
    return D.tolist(),vertices,facets


if __name__=='__main__':
    start=time.time();D,vertices,facets=octahedron();M=FanModule(D,vertices)
    perms={
        'identity':list(range(8)),
        'swap12':[facets.index((a[1],a[0],a[2])) for a in facets],
        'cycle123':[facets.index((a[2],a[0],a[1])) for a in facets],
        'central':[facets.index(tuple(-x for x in a)) for a in facets],
    }
    records={}
    for name,p in perms.items():
        a=M.action(p);records[name]={'traces':[int(a[h].trace()) for h in a],
                                  'matrices':{h:[list(map(str,a[h].row(i))) for i in range(a[h].rows)] for h in a}}
    result={'input':'octahedron normal fan, full matrix minimal extension construction',
            'dimensions':M.dimensions(),'actions':records,'seconds':time.time()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'dimensions':result['dimensions'],'traces':{k:v['traces'] for k,v in records.items()},'seconds':result['seconds']}))
