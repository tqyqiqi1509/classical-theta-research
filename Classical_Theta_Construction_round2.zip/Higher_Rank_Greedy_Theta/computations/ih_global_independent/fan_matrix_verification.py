"""Independent actual-matrix checks against the fast determinant trace engine."""
import json,time,sys
from pathlib import Path
from itertools import permutations,product
import sympy as s
from fan_linear_module import FanModule,octahedron
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computations'/'natural_incoming_module'))
from equivariant_toric_ih import equivariant_ih,flow_polytope

def compose(p,q):return tuple(p[q[i]] for i in range(len(p)))

start=time.time();D,v,fs=octahedron();M=FanModule(D,v);actions={};rows=[]
for pp in permutations(range(3)):
 for z in (-1,1):
  p=tuple(fs.index(tuple(z*a[i] for i in pp)) for a in fs)
  act=M.action(p);actions[p]=act
  exact=[int(act[h].trace()) for h in act]
  fast=equivariant_ih(D,v,p)['graded_traces']
  assert exact==fast
  rows.append({'axis_permutation':pp,'central_sign':z,'trace':exact})
relations=0
for p,a in actions.items():
 for q,b in actions.items():
  c=actions[compose(p,q)]
  for h in a:
   assert a[h]*b[h]==c[h]
   relations+=1
print(json.dumps({'octahedron_matrices':len(actions),'group_law_matrix_checks':relations,'seconds':time.time()-start}),flush=True)
eta=((0,0,-2,-2),(0,0,-2,-2),(2,2,0,0),(2,2,0,0))
data=flow_polytope(eta);K=FanModule(data['incidence'],data['vertices'],max_degree=2)
edgeidx={e:i for i,e in enumerate(data['edges'])};krows=[];kacts={}
for a,b in product((0,1),repeat=2):
 cp=(1,0,2,3) if a else (0,1,2,3)
 if b:cp=tuple(5-i if i>=2 else i for i in cp)
 p=tuple(edgeidx[(cp[i],cp[j],k)] for i,j,k in data['edges'])
 act=K.action(p);kacts[p]=act
 exact=[int(act[h].trace()) for h in act]
 fast=equivariant_ih(data['incidence'],data['vertices'],p)['graded_traces'][:3]
 assert exact==fast
 krows.append({'row_swap':a,'column_swap':b,'trace_degrees_0_to_2':exact,
               'matrices':{h:[[str(x) for x in act[h].row(i)] for i in range(act[h].rows)] for h in act}})
 print(json.dumps({'K22_m2':(a,b),'traces':exact,'seconds':time.time()-start}),flush=True)
for p,a in kacts.items():
 for q,b in kacts.items():
  c=kacts[compose(p,q)]
  for h in a:
   assert a[h]*b[h]==c[h];relations+=1
result={'octahedron_dimension':M.dimensions(),'octahedron':rows,'K22_m2':krows,
        'all_exact_matrix_group_relations':relations,'seconds':time.time()-start,'all_pass':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'all_pass':True,'matrix_relations':relations,'seconds':result['seconds']}),flush=True)
