"""Materialize the finite combinatorial recipe, not coefficient-sized sets.

Every node is a literal singleton, disjoint union, Cartesian product, or
structural tag. Local union branches are actual integer Dyck gradings.
The numerical cardinality is evaluated only after the complete recipe
has been constructed. No theta or wall oracle is used in the definition.
"""
from functools import lru_cache
from math import gcd, prod
from pathlib import Path
import json
import sys
import time

from tight_grading_two_input import tight_profiles, dyck_word
from valued_event_flag_grammar import EventFlags, extended_data, box, prim, le, add, scale


class FiniteSets:
    """Hash-consed set expressions; sum repetitions are kept distinct."""
    def __init__(self):
        self.nodes = [('empty',), ('unit',)]
        self.intern = {v: i for i, v in enumerate(self.nodes)}
        self.cardinality = lru_cache(None)(self._cardinality)

    def node(self, key):
        if key not in self.intern:
            self.intern[key] = len(self.nodes)
            self.nodes.append(key)
        return self.intern[key]

    def union(self, children):
        children = tuple(c for c in children if c != 0)
        if not children: return 0
        if len(children) == 1: return children[0]
        return self.node(('union', children))

    def product(self, children):
        children = tuple(children)
        if 0 in children: return 0
        children = tuple(c for c in children if c != 1)
        if not children: return 1
        if len(children) == 1: return children[0]
        return self.node(('product', children))

    def tag(self, label, child=1):
        return self.node(('tag', label, child)) if child != 0 else 0

    def _cardinality(self, identifier):
        node = self.nodes[identifier]
        if node[0] == 'empty': return 0
        if node[0] == 'unit': return 1
        if node[0] == 'union': return sum(map(self.cardinality, node[1]))
        if node[0] == 'product': return prod(map(self.cardinality, node[1]))
        if node[0] == 'tag': return self.cardinality(node[2])
        raise ValueError(node[0])

    def select(self, identifier, index=0):
        """Return the actual nested grading object of a given finite rank."""
        total = self.cardinality(identifier)
        if not 0 <= index < total: raise IndexError((index, total))
        node = self.nodes[identifier]
        if node[0] == 'unit': return {'unit': True}
        if node[0] == 'tag':
            return {'tag': node[1], 'object': self.select(node[2], index)}
        if node[0] == 'union':
            for branch, child in enumerate(node[1]):
                c = self.cardinality(child)
                if index < c:
                    return {'union_branch': branch, 'object': self.select(child, index)}
                index -= c
        if node[0] == 'product':
            values = []
            for child in reversed(node[1]):
                index, digit = divmod(index, self.cardinality(child))
                values.append(self.select(child, digit))
            return {'ordered_product': list(reversed(values))}
        raise AssertionError(node)


def set_series_multiply(A, B, cap, sets):
    result = {}
    for i, a in A.items():
        for j, b in B.items():
            if i+j <= cap:
                term = sets.product((a, b))
                result.setdefault(i+j, []).append(term)
    return {i: sets.union(terms) for i, terms in result.items()
            if any(t != 0 for t in terms)}


class DyckObjects(EventFlags):
    def __init__(self, B, D, max_swaps=None):
        self.sets = FiniteSets()
        super().__init__(B, D, max_swaps=max_swaps)

    def two_inputs(self, left, right, S):
        a, F, aid, _ = left
        b, G, bid, _ = right
        m = self.pair(a, b)
        wa, wb = self.weight(a), self.weight(b)
        u, v = m//wa, m//wb
        assert m > 0 and m % wa == m % wb == 0
        acap = min(S[i]//a[i] for i in range(self.r) if a[i])
        bcap = min(S[i]//b[i] for i in range(self.r) if b[i])
        outputs = []
        for s in range(1, acap+1):
            for t in range(1, bcap+1):
                if gcd(s, t) != 1: continue
                gamma = add(scale(s, a), scale(t, b))
                if not le(gamma, S): continue
                ncap = min(S[i]//gamma[i] for i in range(self.r) if gamma[i])
                ell = gcd(s*v, t*u)
                A, B = s*v//ell, t*u//ell
                numerator, denominator = m*self.weight(gamma), ell*wa*wb
                assert numerator % denominator == 0
                copies = numerator//denominator
                base = {0: 1}
                for j in range(1, ncap+1):
                    _, gradings, rectangle = tight_profiles(A, B, j*ell, v, u, True)
                    word = dyck_word(*rectangle)
                    actual = []
                    for grading in gradings:
                        decorations = []
                        for edge, weight in zip(word, grading):
                            if not weight: continue
                            decorations.append(F.get(weight//v, 0) if edge == 'N'
                                               else G.get(weight//u, 0))
                        child = self.sets.product(decorations)
                        if child != 0:
                            label = ('tight_grading', rectangle, ''.join(word),
                                     grading, ('degree', j), ('divisors', v, u))
                            actual.append(self.sets.tag(label, child))
                    base[j] = self.sets.union(actual)
                series = {0: 1}
                for slot in range(copies):
                    tagged = {j: self.sets.tag(('normal_copy', slot, copies, j), value)
                              for j, value in base.items() if value != 0}
                    series = set_series_multiply(series, tagged, ncap, self.sets)
                newid = (aid, bid, s, t)
                H = {j: self.sets.tag(('birth', a, b, gamma, s, t, j, newid), value)
                     for j, value in series.items() if j and value != 0}
                if H:
                    outputs.append((gamma, H, newid, True))
                    self.stats['born_factors'] += 1
        from functools import cmp_to_key
        from valued_event_flag_grammar import sign
        outputs.sort(key=cmp_to_key(lambda x,y: sign(self.pair(x[0], y[0]))))
        return outputs

    def born_ray(self, inputs, S):
        word = self.sort_word(inputs, S)
        rho, cap = prim(S), gcd(*S)
        result = {0: 1}
        for carrier, F, identifier, born in word:
            if not born or prim(carrier) != rho: continue
            power = gcd(*carrier)
            part = {0: 1}
            part.update({power*j: value for j,value in F.items() if power*j <= cap})
            result = set_series_multiply(result, part, cap, self.sets)
        return result

    def _count(self, S, theta):
        # The inherited method name is historical: the return value is a
        # finite-set recipe node, never its numerical cardinality.
        self.stats['states'] += 1
        assert not any(self.evaluate_covector(theta, S))
        rho, cap = prim(S), gcd(*S)
        axis = sum(x != 0 for x in rho) == 1
        answer = {0: 1}
        if axis:
            color = next(i for i, x in enumerate(rho) if x)
            answer[1] = self.sets.tag(('original_axis_leaf', color))
        for key, b, tau, q in self.events(S, theta):
            self.stats['events'] += 1
            rays = {}
            for T in box(S):
                if not any(T) or T == S or not self.in_plane(T, S, b): continue
                rhoT = prim(T)
                child = self.count(T, self.incoming_theta(q, rhoT))
                if child != 0: rays.setdefault(rhoT, {})[gcd(*T)] = child
            factor = self.born_ray(sorted(rays.items()), S)
            tagged = {j: self.sets.tag(('event', S, key, j), value) if j else value
                      for j, value in factor.items()}
            answer = set_series_multiply(answer, tagged, cap, self.sets)
        covector = tuple(tuple(str(x) for x in row) for row in theta)
        return self.sets.tag(('state', S, covector), answer.get(cap, 0))


def main():
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'agents'))
    from incoming_recursion import IncomingSchur
    start = time.monotonic()
    cases = [
        ('valued_parallel_obstruction', [[0,2],[-1,0]], [1,2], (-6,2), (2,2)),
        ('cyclic_valued', [[0,2,-1],[-1,0,1],[1,-2,0]], [1,2,1],
         (-3,-2,1), (1,1,1)),
        ('cyclic_repeated', [[0,2,-2],[-2,0,2],[2,-2,0]], [1,1,1],
         (-1,-1,-1), (2,2,1)),
    ]
    results = []
    for name, B, D, g, p in cases:
        Bhat, Dhat = extended_data(B, D, g)
        objects = DyckObjects(Bhat, Dhat)
        root = objects.framed_theta(g, p)
        # Only now is the completed set recipe evaluated numerically.
        count = objects.sets.cardinality(root)
        independent = IncomingSchur(B, D).theta_prefix(g, p).get(p, 0)
        assert count == independent
        if count <= 100:
            encoded = [json.dumps(objects.sets.select(root, i), sort_keys=True)
                       for i in range(count)]
            assert len(set(encoded)) == count
        artifact = {'B': B, 'D': D, 'g': g, 'p': p, 'root': root,
                    'cardinality': count, 'nodes': objects.sets.nodes,
                    'first_actual_object': objects.sets.select(root) if count else None}
        destination = Path(__file__).parent/f'dyck_objects_{name}.json'
        destination.write_text(json.dumps(artifact, indent=2))
        results.append({'name': name, 'count_after_construction': count,
                        'independent_integer_formula': independent,
                        'recipe_nodes': len(objects.sets.nodes),
                        'recipe_file': destination.name,
                        'stats': dict(objects.stats)})
    report = {'status': 'PASS', 'results': results,
              'seconds': time.monotonic()-start,
              'definition_uses_coefficient_oracle': False}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__': main()
