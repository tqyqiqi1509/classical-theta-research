"""Explicit Dyck grading objects for a classical valued two-input exchange.

The local tight-grading identity is Burcroff--Lee--Mou 2503.03719,
Theorem 1.2. This file supplies actual bounded grading enumeration and
the original-normal lattice conversion; it does not call a wall oracle.
"""
from collections import Counter
from functools import lru_cache
from math import gcd
from itertools import product


@lru_cache(None)
def compositions(total, length):
    if length == 0:
        return ((),) if total == 0 else ()
    if length == 1:
        return ((total,),)
    return tuple((i,) + a for i in range(total+1)
                 for a in compositions(total-i, length-1))


def dyck_word(d1, d2):
    assert d1 > 0 and d2 > 0
    word=[]
    y=0
    for x in range(1,d1+1):
        word.append('E')
        goal=(d2*x)//d1
        while y<goal:
            word.append('N'); y+=1
    assert word.count('E')==d1 and word.count('N')==d2
    return tuple(word)


def bezout_rectangle(a,b,k):
    """a*d2-b*d1=1 and d1>=k*a, d2>=k*b; deterministic smallest d1."""
    assert gcd(a,b)==1 and min(a,b,k)>0
    d1=k*a
    while (1+b*d1)%a:
        d1+=1
    d2=(1+b*d1)//a
    assert d2>=k*b and a*d2-b*d1==1
    return d1,d2


def shadow_sets(word, grading):
    L=len(word)
    E={i for i,w in enumerate(word) if w=='E'}
    N=set(range(L))-E
    sh={}
    for i in range(L):
        if grading[i]==0:
            sh[i]=frozenset();continue
        own=word[i]
        direction=1 if own=='E' else -1
        count=0; weight=0; seen=set(); found=False
        for h in range(L):
            j=(i+direction*h)%L
            if word[j]==own:
                weight+=grading[j]
            else:
                count+=1;seen.add(j)
                if count==weight:
                    sh[i]=frozenset(seen);found=True;break
        if not found:
            sh[i]=frozenset(N if own=='E' else E)
    return sh,E,N


def is_tight(word,grading):
    sh,E,N=shadow_sets(word,grading)
    positiveE=[i for i in E if grading[i]]
    positiveN=[i for i in N if grading[i]]
    # An earlier shadow endpoint is precisely an allowed compatibility
    # witness. The simultaneous inclusions are precisely its failure.
    if any(v in sh[u] and u in sh[v] for u in positiveE for v in positiveN):
        return False
    shadowE=set().union(*(sh[u] for u in positiveE))
    shadowN=set().union(*(sh[v] for v in positiveN))
    return set(positiveE)<=shadowN or set(positiveN)<=shadowE


def direct_compatible(word,grading):
    """Independent literal subpath definition, used only to verify shadows."""
    L=len(word)
    E=[i for i,w in enumerate(word) if w=='E' and grading[i]]
    N=[i for i,w in enumerate(word) if w=='N' and grading[i]]
    for u in E:
        for v in N:
            path=[];j=u
            while True:
                path.append(j)
                if j==v:break
                j=(j+1)%L
            good=False
            for h,e in enumerate(path):
                if word[e]=='N' and e!=v:
                    prefix=path[:h+1]
                    if sum(word[j]=='N' for j in prefix)==sum(grading[j] for j in prefix if word[j]=='E'):
                        good=True;break
                if word[e]=='E' and e!=u:
                    suffix=path[h:]
                    if sum(word[j]=='E' for j in suffix)==sum(grading[j] for j in suffix if word[j]=='N'):
                        good=True;break
            if not good:return False
    return True


@lru_cache(None)
def tight_profiles(a,b,k,v=1,u=1,keep_objects=False):
    """Standard primitive slope (a,b), total exponent k*(a,b).

    Nonzero vertical weights must be multiples of v, horizontal of u.
    Returned keys are sorted positive input-coefficient indices on each
    side; values count actual gradings, not prescribed multiplicities.
    """
    d1,d2=bezout_rectangle(a,b,k)
    if (k*a)%v or (k*b)%u:
        return {},(),(d1,d2)
    word=dyck_word(d1,d2)
    epos=[i for i,w in enumerate(word) if w=='E']
    npos=[i for i,w in enumerate(word) if w=='N']
    profiles=Counter();objects=[]
    for hvals in compositions(k*b//u,d1):
        for vvals in compositions(k*a//v,d2):
            grading=[0]*len(word)
            for i,z in zip(epos,hvals):grading[i]=u*z
            for i,z in zip(npos,vvals):grading[i]=v*z
            if not is_tight(word,grading):continue
            key=(tuple(sorted(z for z in vvals if z)),
                 tuple(sorted(z for z in hvals if z)))
            profiles[key]+=1
            if keep_objects:objects.append(tuple(grading))
    return dict(profiles),tuple(objects),(d1,d2)


def mul_profiles(A,B):
    ans=Counter()
    for (a,b),x in A.items():
        for (c,d),y in B.items():
            ans[(tuple(sorted(a+c)),tuple(sorted(b+d)))]+=x*y
    return dict(ans)


def valued_profiles(K,wa,wb,wgamma,a,b,n):
    assert min(K,wa,wb,wgamma,a,b,n)>0 and gcd(a,b)==1
    assert K%wa==K%wb==0
    u=K//wa;v=K//wb
    ell=gcd(a*v,b*u)
    aa=a*v//ell;bb=b*u//ell
    numer=K*wgamma;denom=ell*wa*wb
    assert numer%denom==0,(K,wa,wb,wgamma,a,b)
    copies=numer//denom
    base=[{((),()):1}]
    for j in range(1,n+1):
        base.append(tight_profiles(aa,bb,j*ell,v,u)[0])
    series=[{((),()):1}]+[{} for _ in range(n)]
    for _ in range(copies):
        new=[]
        for j in range(n+1):
            result=Counter()
            for h in range(j+1):result.update(mul_profiles(series[h],base[j-h]))
            new.append(dict(result))
        series=new
    return series[n],{'u':u,'v':v,'ell':ell,'slope':[aa,bb],'copies':copies}


def evaluate_profile(profile,A,B):
    ans=0
    for (aa,bb),c in profile.items():
        for a in aa:c*=A.get(a,0)
        for b in bb:c*=B.get(b,0)
        ans+=c
    return ans


def main():
    import json,time,random
    from pathlib import Path
    start=time.monotonic()
    rng=random.Random(20261113)
    compat_checks=0
    for d1,d2 in [(1,2),(2,3),(3,2),(3,4),(5,3)]:
        w=dyck_word(d1,d2)
        for _ in range(200):
            gr=tuple(rng.randrange(4) for _ in w)
            sh,E,N=shadow_sets(w,gr)
            quick=not any(v in sh[u] and u in sh[v]
                          for u in E for v in N if gr[u] and gr[v])
            assert quick==direct_compatible(w,gr),(w,gr)
            compat_checks+=1
    p,objects,rectangle=tight_profiles(1,1,2,1,1,True)
    expected={((1,1),(2,)):1,((2,),(1,1)):1,((2,),(2,)):2}
    assert p==expected,(p,expected)
    checks=[]
    for K,wa,wb,wg,a,b,n in [
        (1,1,1,1,1,1,1),(1,1,1,1,1,1,2),
        (2,1,1,1,1,1,1),(2,1,1,1,1,1,2),
        (3,1,1,1,1,1,1),(3,1,1,1,1,1,2),
        (6,2,3,1,1,1,1),(6,2,3,1,1,1,2),
        (4,2,2,2,1,1,1),(4,2,2,2,1,1,2),
        (2,1,2,1,1,1,1),(2,1,2,2,2,1,1)]:
        poly,normal=valued_profiles(K,wa,wb,wg,a,b,n)
        value=evaluate_profile(poly,{1:1},{1:1})
        if a==b==n==1:
            assert value==K*wg//(wa*wb)
        if (K,wa,wb,wg,a,b)==(1,1,1,1,1,1):assert value==(1 if n==1 else 0)
        if (K,wa,wb,wg,a,b)==(2,1,1,1,1,1):assert value==n+1
        checks.append({'parameters':[K,wa,wb,wg,a,b,n],
                       'normalization':normal,'binomial_input_count':value,
                       'profiles':[[list(x),list(y),z] for (x,y),z in sorted(poly.items())]})
    result={'status':'PASS','literal_compatibility_checks':compat_checks,
            'BLM_lambda_2_2':[[list(x),list(y),z] for (x,y),z in sorted(p.items())],
            'actual_lambda_2_2_gradings':objects,'rectangle':rectangle,
            'valued_checks':checks,'seconds':time.monotonic()-start}
    path=Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
