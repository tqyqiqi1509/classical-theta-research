"""Actual first-in-each-packet rank-three event flip, all normal contents.

The three boundary packets are fixed atomic decorated inputs.  This is
not a transport of their possibly varying descendant event catalogs.
"""
from math import gcd
from fractions import Fraction
from pathlib import Path
import json
import time
from dyck_three_factor_coherence import from_strip, to_strip, literal_grading
from tight_grading_two_input import is_tight


def forward(branch, i, j, A, B, d, e, F, ell):
    g = gcd(d,e)
    dp, ep = d//g, e//g
    delta, epsilon = dp*ell, ep*ell
    assert (dp*A+ep*B) % F == 0
    if branch == 'L2':
        assert A < epsilon and 0 <= i < B and 0 <= j < epsilon-A
        i, j = A+j, i
    else:
        assert branch == 'L1' and 0 <= i < A and 0 <= j < B+delta
        if j < B and i >= epsilon:
            return 'R2', j, i-epsilon, 0
        if j >= B:
            h, residue = divmod(j-B,dp)
            z = dp*i+residue
            outer, copy = divmod(z,F)
            return 'R1', h, outer, copy
    h, residue = divmod(i,ep)
    z = dp*A+ep*j+residue
    outer, copy = divmod(z,F)
    return 'R1', h, outer, copy


def backward(branch, i, j, copy, A, B, d, e, F, ell):
    g = gcd(d,e)
    dp, ep = d//g, e//g
    epsilon = ep*ell
    if branch == 'R2':
        assert A > epsilon and copy == 0 and 0 <= i < B and 0 <= j < A-epsilon
        return 'L1', j+epsilon, i
    assert branch == 'R1' and 0 <= i < ell and 0 <= copy < F
    assert 0 <= j < (dp*A+ep*B)//F
    z = F*j+copy
    if z < dp*A:
        ii, residue = divmod(z,dp)
        return 'L1', ii, B+dp*i+residue
    jj, residue = divmod(z-dp*A,ep)
    ii = ep*i+residue
    return ('L1',ii,jj) if ii < A else ('L2',jj,ii-A)


def pair_parameters(branch, A,B,d,e,F,ell):
    g=gcd(d,e)
    p,r,q,f=d*A,e*B,d*e//g*ell,g*F
    if branch == 'L1': return (p,1,d,1),(q+r,1,e,1)
    if branch == 'L2': return (r,1,e,1),(q-p,d,1,1)
    if branch == 'R1': return (q,d,e,f),(p+r,1,f,1)
    if branch == 'R2': return (r,1,e,1),(p-q,1,d,1)
    raise ValueError(branch)


def addressed_conditions(p,q,r,y,z):
    """Root time and projected inner time, not an enumerator identity."""
    result={}
    root=z/(q+r)
    inner=(y-(p-q)*root)/p
    if root>0 and inner>0: result['L1']=(root,inner)
    root=(y+z)/(p+r)
    inner=(z-(q+r)*root)/q
    if root>0 and inner>0: result['R1']=(root,inner)
    if p>q:
        root=y/(p-q)
        inner=(z-(q+r)*root)/r
        if root>0 and inner>0: result['R2']=(root,inner)
    elif p<q:
        root=-y/(q-p)
        inner=(z-(q+r)*root)/r
        if root>0 and inner>0: result['L2']=(root,inner)
    return result


def main():
    begin=time.monotonic()
    parameter_sets=points=actual_pairs=event_checks=0
    for d in range(1,6):
      for e in range(1,6):
       g=gcd(d,e); dp,ep=d//g,e//g
       for ell in range(1,4):
        for F in range(1,6):
         for A in range(1,7):
          for B in range(1,6):
           if (dp*A+ep*B)%F: continue
           parameter_sets+=1
           epsilon,delta=ep*ell,dp*ell
           images=set()
           source=[('L1',i,j) for i in range(A) for j in range(B+delta)]
           source += [('L2',i,j) for i in range(B) for j in range(max(0,epsilon-A))]
           target={('R1',i,j,c) for i in range(ell)
                   for j in range((dp*A+ep*B)//F) for c in range(F)}
           target|={('R2',i,j,0) for i in range(B) for j in range(max(0,A-epsilon))}
           for point in source:
            image=forward(*point,A,B,d,e,F,ell)
            assert backward(*image,A,B,d,e,F,ell)==point
            images.add(image); points+=1
            if points%157==0:
             for branch,i,j,copy in ((*point,0),image):
              ip,op=pair_parameters(branch,A,B,d,e,F,ell)
              io=from_strip(*ip,copy,i)
              oo=from_strip(*op,0,j)
              assert to_strip(*ip,io)==(copy,i)
              assert to_strip(*op,oo)==(0,j)
              for par,obj in ((ip,io),(op,oo)):
               word,grading=literal_grading(*par,obj)
               assert is_tight(word,grading)
               actual_pairs+=1
           assert images==target
           p,q,r=d*A,d*e//g*ell,e*B
           z=Fraction(1)
           centre=Fraction(p-q,q+r)
           # Stay within the positive-root neighborhood of the critical face.
           eps=min(Fraction(1),Fraction(p+r,q+r),abs(centre) if centre else 1)/100
           plus=addressed_conditions(p,q,r,centre+eps,z)
           minus=addressed_conditions(p,q,r,centre-eps,z)
           assert set(plus)==({'L1','L2'} if p<q else {'L1'})
           assert set(minus)==({'R1','R2'} if p>q else {'R1'})
           event_checks+=2
    report={'status':'PASS','parameter_sets':parameter_sets,'rectangle_points':points,
            'literal_binary_edge_factories':actual_pairs,'exact_event_address_tests':event_checks,
            'includes_p_equal_q':True,'scope':'first occurrence of each of three fixed decorated boundary packets',
            'not_claimed':'transport of descendant packet catalogs or all-degree crossing',
            'seconds':time.monotonic()-begin}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__': main()
