"""Independent check of the F-to-S normalization and decreasing HN order.

This targets the genuine sign gap found in the first many-slope bridge.  It
does not call a theta routine.  S is obtained from finite support sums, while
HN sums and primitive block-cycle sums are assembled separately.
"""
from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import json
import sympy as sp
from many_slope_balanced_partition import (support_sum,fan_character,partitions,
    normalize,v_sum,det,cycles,perm_sign,q)

t=sp.Symbol('t')

@lru_cache(None)
def S(charges,p):
    f,_,_=support_sum(charges,p)
    E=sum(max(det(a,b),0) for a in charges for b in charges)
    return sp.cancel(t**(E-len(charges))*f.subs(q,t**-2))

def restriction(charges,p,C):
    return tuple(charges[i] for i in C),tuple(C.index(p[i]) for i in C)

def ordered_HN(charges,p):
    total=v_sum(charges,range(len(charges)));ans=0;terms=0
    for part in partitions(list(range(len(charges)))):
        if any({p[i] for i in C}!=set(C) for C in part):continue
        data=[]
        for C in part:
            beta=v_sum(charges,C)
            slope=Fraction(-det(total,beta),sum(beta))
            data.append((slope,C,beta))
        if len({x[0] for x in data})<len(data):continue
        data.sort(reverse=True)
        exponent=sum(det(A[2],B[2]) for j,A in enumerate(data) for B in data[j+1:])
        term=t**exponent
        for slope,C,beta in data:
            ch,cp=restriction(charges,p,C)
            term*=S(ch,cp)
        ans+=term;terms+=1
    return sp.cancel(ans),terms

def primitive_cycle_sum(charges,p):
    total=v_sum(charges,range(len(charges)));ans=0;number=0
    for part0 in partitions(list(range(len(charges)))):
        part=normalize(part0)
        if any(det(total,v_sum(charges,C)) for C in part):continue
        if normalize(tuple(tuple(p[i] for i in C) for C in part))!=part:continue
        bp=tuple(part.index(tuple(sorted(p[i] for i in C))) for C in part)
        term=sp.Integer(1)
        for O in cycles(bp):
            ell=len(O);C=part[O[0]];ret=[]
            for i in C:
                j=i
                for _ in range(ell):j=p[j]
                ret.append(C.index(j))
            ch=tuple(charges[i] for i in C)
            E=sum(max(det(a,b),0) for a in ch for b in ch)
            d=E-len(C)+1 if len(C)>1 else 0
            R=fan_character(ch,tuple(ret))
            term*=(-1)**((ell-1)*E)*t**(ell*(1-d))*R.subs(q,t**(2*ell))/(1-t**(2*ell))
        ans+=term;number+=1
    return sp.cancel(ans),number

def main():
    cases=[
      ('one_arrow',((1,0),(0,1)),(0,1)),
      ('four_slopes',((1,0),(0,1),(1,1),(2,1)),(0,1,2,3)),
      ('proper_parallel_swap',((1,0),(0,1),(1,1),(1,1)),(0,1,3,2)),
      ('balanced_block_swap',((1,0),(1,0),(0,1),(0,1),(1,1)),(1,0,3,2,4)),
      ('all_parallel_3cycle',((1,1),(1,1),(1,1)),(1,2,0)),
      ('one_local_factor_4cycle',((0,1),(1,0),(1,0),(1,0),(1,0)),(0,2,3,4,1)),
    ]
    out=[]
    for label,ch,p in cases:
        E=sum(max(det(a,b),0) for a in ch for b in ch)
        full=t**(len(ch)-E)/sp.prod(1-t**(2*len(C)) for C in cycles(p))
        hn,nparts=ordered_HN(ch,p)
        pbw,nbal=primitive_cycle_sum(ch,p)
        row={'case':label,'charges':ch,'permutation':p,'full_trace':str(full),
             'support_semistable_trace':str(S(ch,p)),
             'HN_partition_count':nparts,'PBW_partition_count':nbal,
             'HN_residual':str(sp.cancel(full-hn)),
             'PBW_residual':str(sp.cancel(S(ch,p)-pbw))}
        assert row['HN_residual']==row['PBW_residual']=='0',row
        out.append(row);print(json.dumps(row),flush=True)
    Path(__file__).with_suffix('.json').write_text(json.dumps({'all_passed':True,'cases':out},indent=2))

if __name__=='__main__':main()
