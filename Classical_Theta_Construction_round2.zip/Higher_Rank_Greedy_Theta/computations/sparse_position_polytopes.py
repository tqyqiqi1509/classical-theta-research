"""Compile sparse tight-grading patterns to exact rational polytopes.

Input: a rectangle, ordered positive weights, and a weak order of marked
edges and their opposite-orientation endpoint labels.  The definition
does not use a list of gradings or their vertices.  The verifier compares
the compiled integer points with independently enumerated literal paths.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations, product
from math import gcd
from pathlib import Path
import json
import time

from tight_grading_two_input import tight_profiles, dyck_word, compositions
from sparse_shadow_endpoint_check import coordinates, direct_endpoint


def labels(kH, kV):
    return (tuple(f'H{i}' for i in range(kH)) + tuple(f'V{i}' for i in range(kV)) +
            tuple(f'h{i}' for i in range(kH)) + tuple(f'v{i}' for i in range(kV)))


def orientation(label):
    return 'E' if label[0] in ('H', 'v') else 'N'


@lru_cache(None)
def weak_patterns(kH, kV):
    """All weak time orders, respecting each ordered positive support."""
    initial = labels(kH, kV)
    result = []

    def rec(remaining, blocks):
        if not remaining:
            result.append(tuple(blocks))
            return
        for color in ('E', 'N'):
            positive = [l for l in remaining if l[0] == ('H' if color == 'E' else 'V')]
            available = [l for l in remaining if orientation(l) == color and l[0].islower()]
            if positive:
                available.append(min(positive, key=lambda l: int(l[1:])))
            for size in range(1, len(available)+1):
                for chosen in combinations(available, size):
                    block = tuple(sorted(chosen))
                    rec(tuple(l for l in remaining if l not in chosen), blocks+[block])
    rec(initial, [])
    return tuple(result)


def pattern_membership(pattern, kH, kV):
    rank = {label: i for i, block in enumerate(pattern) for label in block}
    L = len(pattern)
    hs = lambda h, v: 0 < (rank[v]-rank[h]) % L <= (rank[h.lower()]-rank[h]) % L
    vs = lambda v, h: 0 < (rank[v]-rank[h]) % L <= (rank[v]-rank[v.lower()]) % L
    H, V = [f'H{i}' for i in range(kH)], [f'V{i}' for i in range(kV)]
    compatible = not any(hs(h, v) and vs(v, h) for h in H for v in V)
    shadowed = (all(any(vs(v, h) for v in V) for h in H) or
                all(any(hs(h, v) for h in H) for v in V))
    return compatible and shadowed


@lru_cache(None)
def admissible_patterns(kH, kV):
    """Order-only compatibility and shadow filtering, independent of sizes."""
    return tuple(pattern for pattern in weak_patterns(kH, kV)
                 if pattern_membership(pattern, kH, kV))


@dataclass
class Polytope:
    variables: tuple
    inequalities: list
    equalities: list
    metadata: dict

    def contains(self, point):
        return (all(sum(a*x for a, x in zip(row, point)) <= rhs
                    for row, rhs in self.inequalities) and
                all(sum(a*x for a, x in zip(row, point)) == rhs
                    for row, rhs in self.equalities))

    def serialized(self):
        return {'variables': self.variables,
                'A': [row for row, rhs in self.inequalities],
                'b': [rhs for row, rhs in self.inequalities],
                'E': [row for row, rhs in self.equalities],
                'd': [rhs for row, rhs in self.equalities],
                'metadata': self.metadata}


def compile_pattern(r, s, qH, pV, pattern):
    """Return A z<=b, E z=d, or None for a forbidden weak-order pattern."""
    qH, pV = tuple(qH), tuple(pV)
    assert r > 0 and s > 0 and qH and pV
    assert all(w > 0 for w in qH+pV)
    assert sum(qH) <= s and sum(pV) <= r
    kH, kV = len(qH), len(pV)
    names = labels(kH, kV)
    flat = [label for block in pattern for label in block]
    if len(flat) != len(set(flat)) or set(flat) != set(names):
        raise ValueError('The weak order must contain every label exactly once.')
    ranks = {label: i for i, block in enumerate(pattern) for label in block}
    if any(len({orientation(l) for l in block}) != 1 or
           sum(l[0].isupper() for l in block) > 1 for block in pattern):
        return None
    if any(ranks[f'H{i}'] >= ranks[f'H{i+1}'] for i in range(kH-1)) or any(
            ranks[f'V{i}'] >= ranks[f'V{i+1}'] for i in range(kV-1)):
        return None
    if not pattern_membership(pattern, kH, kV):
        return None
    variables = tuple((l, axis) for l in names for axis in ('x', 'y'))
    index = {name: i for i, name in enumerate(variables)}
    inequalities, equalities = [], []

    def constraint(terms, rhs, equality=False):
        row = [0]*len(variables)
        for variable, coefficient in terms:
            row[index[variable]] += coefficient
        (equalities if equality else inequalities).append((tuple(row), int(rhs)))

    def tdiff(left, right):
        return [((left, 'x'), 1), ((left, 'y'), 1),
                ((right, 'x'), -1), ((right, 'y'), -1)]

    for label in names:
        x, y = (label, 'x'), (label, 'y')
        horizontal = orientation(label) == 'E'
        constraint([(x, -1)], 0 if horizontal else -1)
        constraint([(x, 1)], r-1 if horizontal else r)
        constraint([(y, -1)], 0)
        constraint([(y, 1)], s-1)
        if horizontal:
            constraint([(y, r), (x, -s)], 0)
            constraint([(x, s), (y, -r)], r-1)
        else:
            constraint([(y, r), (x, -s)], -r)
            constraint([(x, s), (y, -r)], s+r-1)
    for block in pattern:
        for label in block[1:]:
            constraint(tdiff(label, block[0]), 0, True)
    for left, right in zip(pattern, pattern[1:]):
        constraint(tdiff(left[0], right[0]), -1)
    L = len(pattern)
    endpoints = []
    for color, weights in (('H', qH), ('V', pV)):
        for i, weight in enumerate(weights):
            source, endpoint = f'{color}{i}', f'{color.lower()}{i}'
            forward = color == 'H'
            dist = ((lambda j: (ranks[j]-ranks[source]) % L) if forward else
                    (lambda j: (ranks[source]-ranks[j]) % L))
            before = [j for j in range(len(weights)) if dist(f'{color}{j}') < dist(endpoint)]
            total = sum(weights[j] for j in before)
            wrap = int(ranks[endpoint] < ranks[source]) if forward else int(ranks[endpoint] > ranks[source])
            if forward:
                constraint([((endpoint, 'y'), 1), ((source, 'y'), -1)], total-1-wrap*s, True)
            else:
                constraint([((source, 'x'), 1), ((endpoint, 'x'), -1)], total-wrap*r, True)
            for j in before:
                mark = f'{color}{j}'
                if mark == source:
                    continue
                prior = sum(weights[h] for h in before if dist(f'{color}{h}') < dist(mark))
                wj = int(ranks[mark] < ranks[source]) if forward else int(ranks[mark] > ranks[source])
                if forward:
                    constraint([((mark, 'y'), 1), ((source, 'y'), -1)], prior-1-wj*s)
                else:
                    constraint([((source, 'x'), 1), ((mark, 'x'), -1)], prior-1-wj*r)
            endpoints.append({'source': source, 'endpoint': endpoint, 'forward': forward,
                              'wrap': wrap, 'total': total})
    return Polytope(variables, inequalities, equalities,
                    {'r': r, 's': s, 'qH': qH, 'pV': pV, 'pattern': pattern,
                     'endpoint_equations': endpoints})


def integer_points(poly):
    """Exact check enumerator using only path equations and linear balances.

    This is not Barvinok's algorithm. Endpoint coordinates are eliminated
    from their balance equations and the digital-path membership rules;
    no shadow walk or precomputed grading is used here.
    """
    meta = poly.metadata
    r, s, qH, pV = meta['r'], meta['s'], meta['qH'], meta['pV']
    horizontal = [(x, s*x//r) for x in range(r)]
    vertical = [((r*(y+1)+s-1)//s, y) for y in range(s)]
    for HH in combinations(horizontal, len(qH)):
        for VV in combinations(vertical, len(pV)):
            point = {f'H{i}': coord for i, coord in enumerate(HH)}
            point.update({f'V{i}': coord for i, coord in enumerate(VV)})
            valid = True
            for item in meta['endpoint_equations']:
                x, y = point[item['source']]
                if item['forward']:
                    ye = y+item['total']-1-item['wrap']*s
                    if not 0 <= ye < s:
                        valid = False
                        break
                    xe = (r*(ye+1)+s-1)//s
                else:
                    xe = x+item['wrap']*r-item['total']
                    if not 0 <= xe < r:
                        valid = False
                        break
                    ye = s*xe//r
                point[item['endpoint']] = (xe, ye)
            if not valid:
                continue
            vector = tuple(point[label][0 if axis == 'x' else 1] for label, axis in poly.variables)
            if poly.contains(vector):
                yield vector


def literal_pattern(word, weights):
    H = [i for i, w in enumerate(weights) if w and word[i] == 'E']
    V = [i for i, w in enumerate(weights) if w and word[i] == 'N']
    points = {f'H{i}': j for i, j in enumerate(H)}
    points.update({f'V{i}': j for i, j in enumerate(V)})
    for label, j in tuple(points.items()):
        points[label.lower()] = direct_endpoint(word, weights, j)
    groups = {}
    for label, position in points.items():
        groups.setdefault(position, []).append(label)
    pattern = tuple(tuple(sorted(groups[i])) for i in sorted(groups))
    coord = coordinates(word)
    names = labels(len(H), len(V))
    vector = tuple(z for label in names for z in coord[points[label]])
    return tuple(weights[i] for i in H), tuple(weights[i] for i in V), pattern, vector


def positive_compositions(n):
    if n == 0:
        yield ()
    for first in range(1, n+1):
        for rest in positive_compositions(n-first):
            yield (first,)+rest


def verify_local(a, b, k, v=1, u=1):
    profiles, gradings, rectangle = tight_profiles(a, b, k, v, u, True)
    r, s = rectangle
    word = dyck_word(r, s)
    literal = {}
    for grading in gradings:
        qH, pV, pattern, vector = literal_pattern(word, grading)
        literal.setdefault((qH, pV, pattern), set()).add(vector)
    compiled, counts, patterns_total = {}, [], 0
    for h in positive_compositions(k*b//u):
        qH = tuple(u*z for z in h)
        for n in positive_compositions(k*a//v):
            pV = tuple(v*z for z in n)
            for pattern in weak_patterns(len(qH), len(pV)):
                poly = compile_pattern(r, s, qH, pV, pattern)
                if poly is None:
                    continue
                patterns_total += 1
                points = set(integer_points(poly))
                assert points == literal.get((qH, pV, pattern), set()), (a, b, k, v, u, qH, pV, pattern)
                if points:
                    compiled[(qH, pV, pattern)] = points
                    counts.append(len(points))
    assert compiled == literal
    assert sum(counts) == len(gradings)
    return {'input': [a, b, k, v, u], 'rectangle': rectangle,
            'literal_gradings': len(gradings), 'compiled_nonempty_patterns': len(compiled),
            'retained_weak_patterns_checked': patterns_total, 'pattern_counts': sorted(counts)}


def first_degree_family(m):
    r, s = m, m+1
    cells = []
    for pattern in weak_patterns(1, 1):
        poly = compile_pattern(r, s, (m,), (m,), pattern)
        if poly is None:
            continue
        points = sorted(integer_points(poly))
        if points:
            cell = {'pattern': pattern, 'integer_points': points,
                    'polytope': poly.serialized()}
            if len(points) > 1:
                direction = tuple(y-x for x, y in zip(points[0], points[1]))
                assert gcd(*direction) == 1
                assert all(p == tuple(x+t*d for x, d in zip(points[0], direction))
                           for t, p in enumerate(points))
                cell['integer_segment'] = {'base': points[0], 'primitive_direction': direction,
                                           'parameter_bounds': [0, len(points)-1]}
            cells.append(cell)
    sizes = sorted(len(c['integer_points']) for c in cells)
    assert sizes == sorted([1, 1, m-2]) if m >= 3 else sizes == [1, 1]
    return {'m': m, 'pattern_counts': sizes, 'cells': cells}


def main():
    start = time.monotonic()
    cases = [(1, 1, 1, 1, 1), (1, 2, 1, 1, 2), (2, 1, 1, 1, 1),
             (2, 3, 1, 2, 3), (1, 1, 4, 2, 2)]
    checks = []
    for parameters in cases:
        row = verify_local(*parameters)
        checks.append(row)
        print(json.dumps(row), flush=True)
    family = [first_degree_family(m) for m in range(2, 13)]
    report = {'status': 'PASS', 'local_checks': checks,
              'first_degree_family': family, 'seconds': time.monotonic()-start,
              'definition_uses_gradings_or_vertices': False,
              'integer_point_checker_uses_shadow_walk': False,
              'polytope_format': 'A z <= b; E z = d, all integer coefficients'}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({'status': 'PASS', 'seconds': report['seconds'],
                      'family_pattern_counts': [[x['m'], x['pattern_counts']] for x in family]}))


if __name__ == '__main__':
    main()
