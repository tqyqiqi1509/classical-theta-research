"""Reproduce the local rank-two simultaneous-event refinement diagnostic."""
from pathlib import Path
import sys,random,json
from fractions import Fraction
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'agents'))
from universal_twig_action_probe import trees,tree_value


def run():
    rng=random.Random(1129);out=[]
    for r in range(3,8):
        mx=0;first=None
        for _ in range(120):
            qs=[(rng.randrange(0,5),rng.randrange(0,5))for _ in range(r)]
            if any(q==(0,0)for q in qs):continue
            eta=[[a*d-b*c for c,d in qs]for a,b in qs]
            full=(1<<r)-1
            ids={s:[i for i in range(r)if s>>i&1]for s in range(1,full+1)}
            theta=[(Fraction(-sum(eta[j][i]for j in range(r))),)+
                   tuple(Fraction((i==j)-(i==r-1))for j in range(r-1))
                   for i in range(r)]
            F=SimpleNamespace(eta=eta,theta=theta,theta_width=r,r=r,ids=ids,
                  pair=lambda L,R:sum(eta[i][j]for i in ids[L]for j in ids[R]))
            values=[tree_value(F,T)for T in trees(full)]
            count=sum(v!=0 for v in values)
            if count>mx:
                mx=count;first={'charges':qs,'positive_trees':count,'raw_sum':sum(values)}
        out.append({'leaves':r,'maximum':mx,'example':first})
        print(out[-1],flush=True)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))


if __name__=='__main__':run()
