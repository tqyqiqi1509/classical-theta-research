"""Color-generic zero-flow contraction, independent of target theta coefficients.

Every positive labeled binary flow tree is contracted along internal edges
whose flow time vanishes after forgetting the final leaf infinitesimals.
The result is a nonbinary tree with genuinely simultaneous events.
"""
from pathlib import Path
import sys,json,time,random
from fractions import Fraction
from itertools import combinations
from collections import defaultdict,Counter
from functools import lru_cache
import sympy as sp

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'agents'))
from universal_flow_tree_probe import FlowPackets,lexsign
from universal_twig_action_probe import trees,leaves


def keynode(children):
    return tuple(sorted(children,key=lambda x:min(all_leaves(x))))


def all_leaves(T):
    if isinstance(T,int):return (T,)
    return tuple(a for C in T for a in all_leaves(C))


def permute(T,permutation):
    if isinstance(T,int):return permutation.get(T,T)
    return keynode([permute(C,permutation)for C in T])


def charge(F,T):
    a=[0]*len(F.B)
    for j in all_leaves(T):
        i,k=F.packets[j];a[i]+=k
    return tuple(a)


def mask(T):return sum(1<<j for j in all_leaves(T))


def evaluate_contract(F,T):
    """Return weight, collapsed tree, full event records, or None if inadmissible."""
    basewidth=1+len(F.B)-1
    events=[]
    def rec(T,theta,isroot=False):
        if isinstance(T,int):return {'weight':1,'tree':T,'zero':False,'children':None,'local_weight':1}
        A,B=T;L=mask(A);R=mask(B);S=L|R
        a=F.pair(L,R)
        if not a:return None
        h=tuple(sum(theta[i][j]for i in F.ids[L])for j in range(F.theta_width))
        if lexsign(h)!=(1 if a>0 else -1):return None
        zero=not any(h[:basewidth])
        theta2=tuple(tuple(theta[i][j]+h[j]*Fraction(
                      sum(F.eta[k][i]for k in F.ids[S]),a)
                          for j in range(F.theta_width))for i in range(F.r))
        left=rec(A,theta2);right=rec(B,theta2)
        if left is None or right is None:return None
        children=[];local_weight=abs(a)
        for z in [left,right]:
            if z['zero']:
                children.extend(z['children']);local_weight*=z['local_weight']
            else:children.append(z['tree'])
        collapsed=keynode(children)
        if not zero:
            cs=[charge(F,C)for C in children]
            vals=[[sum(theta2[j][k]for j in all_leaves(C))for k in range(basewidth)]for C in children]
            assert all(not any(v)for v in vals),('nonzero event child',T,cs,vals)
            qrank=sp.Matrix(cs).rank()
            assert qrank==2,(T,cs,qrank)
            # The entire image on the original color lattice has dimension n-1.
            outmatrix=sp.Matrix([[theta2[j][k]for k in range(1,basewidth)]for j in range(F.r)])
            image_rank=outmatrix.rank()
            n=len({i for i,k in F.packets if i})
            assert image_rank==n-1,(n,T,image_rank)
            brackets=[[sum(cs[u][i]*(-F.D[i]*F.B[i][j])*cs[v][j]
                               for i in range(len(F.B))for j in range(len(F.B)))
                       for v in range(len(cs))]for u in range(len(cs))]
            cyclic_triples=sum(1 for i,j,k in combinations(range(len(cs)),3)
                              if brackets[i][j]*brackets[j][k]*brackets[k][i]>0
                              and ((brackets[i][j]>0)==(brackets[j][k]>0)==(brackets[k][i]>0)))
            assert cyclic_triples==0,(cs,brackets)
            framed=[i for i,c in enumerate(cs)if c[0]]
            if framed:
                assert len(framed)==1
                nf=[i for i in range(len(cs))if i!=framed[0]]
                assert all(brackets[i][j]==0 for i in nf for j in nf)
            events.append({'root_leaves':list(F.ids[S]),'children':[list(all_leaves(C))for C in children],
                           'charges':cs,'arity':len(cs),'framed':bool(framed),
                           'local_weight':local_weight,'brackets':brackets,
                           'flow_time_color':[str(x/a)for x in h[:basewidth]],
                           'input_color_values':[[str(sum(theta[j][k]for j in all_leaves(C)))
                                                  for k in range(basewidth)]for C in children],
                           'charge_rank':qrank,'image_rank':image_rank})
        return {'weight':abs(a)*left['weight']*right['weight'], 'tree':collapsed,
                'zero':zero,'children':children,'local_weight':local_weight}
    val=rec(T,F.theta,True)
    if val is None:return None
    assert not val['zero']
    return val['weight'],val['tree'],events


def check(B,D,g,p,detail=False):
    packets=tuple((i,1)for i,k in enumerate(p)for _ in range(k))
    F=FlowPackets(B,D,g,packets,color_perturb=True)
    groups=defaultdict(lambda:{'raw_weight':0,'refinements':0,'trees':[],'events':[]})
    hist=Counter();eventhist=Counter();valid=0
    for T in trees(F.full):
        ans=evaluate_contract(F,T)
        if ans is None:continue
        w,K,es=ans;valid+=1;G=groups[K];G['raw_weight']+=w;G['refinements']+=1
        if detail:G['trees'].append({'tree':T,'weight':w});G['events'].append(es)
        for e in es:
            hist[e['arity']]+=1;eventhist[(e['arity'],e['framed'])]+=1
    fails=[]
    for K,G in groups.items():
        for i,j in combinations(range(1,F.r),2):
            if F.packets[i]!=F.packets[j]:continue
            K2=permute(K,{i:j,j:i})
            if K2 not in groups or groups[K2]['raw_weight']!=G['raw_weight']:
                fails.append({'tree':K,'weight':G['raw_weight'],'swap':[i,j],
                              'target_tree':K2,'target_weight':groups[K2]['raw_weight']if K2 in groups else None})
    out={'positive_binary_trees':valid,'collapsed_skeletons':len(groups),
         'raw_weight':sum(G['raw_weight']for G in groups.values()),
         'arity_histogram':dict(hist),'event_types':{str(k):v for k,v in eventhist.items()},
         'skeleton_equivariance_failures':fails[:4]}
    if detail:out['skeletons']=[{'tree':K,**G}for K,G in groups.items()]
    return out


def run():
    start=time.time();examples=[]
    inputs=[([[0]], [1],(-3,),(4,)),
            ([[0,2,-3],[-2,0,2],[3,-2,0]],[1]*3,(-3,3,-2),(2,2,1)),
            ([[0,2,-2],[-2,0,2],[2,-2,0]],[1]*3,(-1,-1,-1),(2,2,1)),
            ([[0,3],[-2,0]],[2,3],(-2,1),(2,2))]
    for B,D,g,p in inputs:
        result=check(B,D,g,p,True);examples.append({'B':B,'D':D,'g':g,'p':p,'result':result})
        print({'p':p,'positive_binary':result['positive_binary_trees'],
               'skeletons':result['collapsed_skeletons'],'failures':len(result['skeleton_equivariance_failures']),
               'events':result['event_types']},flush=True)
    rng=random.Random(26111315);random_results=[]
    for p in [(2,1),(3,1),(2,2),(2,1,1),(2,2,1),(2,1,1,1)]:
        n=len(p);passed=failed=0;first=None
        for _ in range(30):
            D=[rng.choice([1,2,3])for _ in p];B=[[0]*n for _ in p]
            for i in range(n):
                for j in range(i+1,n):
                    z=rng.randrange(-2,3);d=sp.gcd(D[i],D[j])
                    B[i][j]=int(D[j]//d*z);B[j][i]=-int(D[i]//d*z)
            g=tuple(rng.randrange(-3,4)for _ in p)
            out=check(B,D,g,p)
            if out['skeleton_equivariance_failures']:
                failed+=1
                if first is None:first={'B':B,'D':D,'g':g,'p':p,'result':out}
            else:passed+=1
        random_results.append({'p':p,'passed':passed,'failed':failed,'first_failure':first})
        print(random_results[-1],flush=True)
    result={'seconds':time.time()-start,'examples':examples,'random':random_results}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print({'status':'finished','seconds':result['seconds']},flush=True)


if __name__=='__main__':run()
