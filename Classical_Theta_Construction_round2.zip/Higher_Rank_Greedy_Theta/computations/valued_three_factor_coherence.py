"""Actual first ABC Dyck diamond for arbitrary valued planar inputs.

Local input/output objects are real positive edge positions and normal
tuple slots. Two explicit gcd carries, followed by a weighted rectangle
cut, give the map. No global ranking of equal-size sets occurs.
"""
from dataclasses import asdict
from itertools import combinations, product
from math import gcd, lcm
from pathlib import Path
import json
import random
import time

from dyck_three_factor_coherence import (
    PairObject, TripleObject, from_strip, to_strip, literal_grading, geometry)
from tight_grading_two_input import is_tight


def pair_to_phase(m, da, db, kgamma, h, obj):
    assert da % h == db % h == kgamma % h == m % h == 0
    numerator=m*h
    assert numerator % (da*db) == 0
    primitive=numerator//(da*db)
    common=gcd(da//h,db//h)
    copy,residue=to_strip(m,da,db,kgamma,obj)
    phase=common*copy+residue%common
    intersection=residue//common
    assert 0<=intersection<primitive and 0<=phase<kgamma//h
    return intersection,phase


def pair_from_phase(m,da,db,kgamma,h,intersection,phase):
    assert m*h % (da*db)==0
    assert 0<=intersection<m*h//(da*db) and 0<=phase<kgamma//h
    common=gcd(da//h,db//h)
    copy=phase//common
    residue=common*intersection+phase%common
    return from_strip(m,da,db,kgamma,copy,residue)


def parameters(branch,p,q,r,da,db,dc,kab,kac,kbc,ktotal):
    if branch=='L1':return (p,da,db,kab),(r+q,kab,dc,ktotal),kab
    if branch=='L2':
        assert q>p
        return (r,da,dc,kac),(q-p,db,kac,ktotal),kac
    if branch=='R1':return (q,db,dc,kbc),(p+r,da,kbc,ktotal),kbc
    if branch=='R2':
        assert p>q
        return (r,da,dc,kac),(p-q,kac,db,ktotal),kac
    raise ValueError(branch)


def rectangle_parameters(p,q,r,da,db,dc,kab,kac,kbc,ktotal):
    h=gcd(da,db,dc)
    A,B,C=da//h,db//h,dc//h
    assert all(x%h==0 for x in (p,q,r,kab,kac,kbc,ktotal))
    assert p*h%(da*db)==q*h%(db*dc)==r*h%(da*dc)==0
    P,Q,R=p*h//(da*db),q*h//(db*dc),r*h//(da*dc)
    return h,A,B,C,P,Q,R,ktotal//h


def to_cell(obj,*args):
    h,*_=rectangle_parameters(*args)
    innerpar,outerpar,ki=parameters(obj.branch,*args)
    i,innerphase=pair_to_phase(*innerpar,h,obj.inner)
    outerintersection,rootphase=pair_to_phase(*outerpar,h,obj.outer)
    j=(ki//h)*outerintersection+innerphase
    return i,j,rootphase


def from_cell(branch,i,j,rootphase,*args):
    h,*_=rectangle_parameters(*args)
    innerpar,outerpar,ki=parameters(branch,*args)
    outerintersection,innerphase=divmod(j,ki//h)
    inner=pair_from_phase(*innerpar,h,i,innerphase)
    outer=pair_from_phase(*outerpar,h,outerintersection,rootphase)
    return TripleObject(branch,inner,outer)


def forward_cell(branch,i,j,A,B,C,P,Q,R):
    if branch=='L2':
        assert C*Q>A*P and 0<=i<R and 0<=j<C*Q-A*P
        U=A*P+j
        ir,c=divmod(U,C)
        return 'R1',ir,B*P+C*i+c
    assert branch=='L1' and 0<=i<P and 0<=j<A*R+B*Q
    if j<B*Q:
        qr,b=divmod(j,B)
        return 'R1',qr,B*i+b
    t,a=divmod(j-B*Q,A)
    U=A*i+a
    if U<C*Q:
        ir,c=divmod(U,C)
        return 'R1',ir,B*P+C*t+c
    return 'R2',t,U-C*Q


def backward_cell(branch,i,j,A,B,C,P,Q,R):
    if branch=='R2':
        assert A*P>C*Q and 0<=i<R and 0<=j<A*P-C*Q
        U=C*Q+j
        il,a=divmod(U,A)
        return 'L1',il,B*Q+A*i+a
    assert branch=='R1' and 0<=i<Q and 0<=j<B*P+C*R
    if j<B*P:
        pl,b=divmod(j,B)
        return 'L1',pl,B*i+b
    t,c=divmod(j-B*P,C)
    U=C*i+c
    if U<A*P:
        il,a=divmod(U,A)
        return 'L1',il,B*Q+A*t+a
    return 'L2',t,U-A*P


def forward(obj,*args):
    h,A,B,C,P,Q,R,total=rectangle_parameters(*args)
    i,j,k=to_cell(obj,*args)
    out,i2,j2=forward_cell(obj.branch,i,j,A,B,C,P,Q,R)
    return from_cell(out,i2,j2,k,*args)


def backward(obj,*args):
    h,A,B,C,P,Q,R,total=rectangle_parameters(*args)
    i,j,k=to_cell(obj,*args)
    out,i2,j2=backward_cell(obj.branch,i,j,A,B,C,P,Q,R)
    return from_cell(out,i2,j2,k,*args)


def test_rectangles(bound=5):
    cases=points=0
    for A,B,C,P,Q,R in product(range(1,bound+1),repeat=6):
        args=A,B,C,P,Q,R
        targets=set()
        for branch,wi,he in [('L1',P,A*R+B*Q)]+(
                [('L2',R,C*Q-A*P)] if C*Q>A*P else []):
            for i,j in product(range(wi),range(he)):
                out=forward_cell(branch,i,j,*args)
                assert backward_cell(*out,*args)==(branch,i,j)
                assert out not in targets
                targets.add(out);points+=1
        expected={('R1',i,j) for i,j in product(range(Q),range(B*P+C*R))}
        if A*P>C*Q:expected|={('R2',i,j) for i,j in product(range(R),range(A*P-C*Q))}
        assert targets==expected
        cases+=1
    return cases,points


def ambient_parameters(D,K,a,b,c):
    def dot(x,y):return sum(x[i]*K[i][j]*y[j] for i in range(len(D)) for j in range(len(D)))
    def weight(x):return gcd(*(D[i]*x[i] for i in range(len(D))))
    def add(x,y):return tuple(u+v for u,v in zip(x,y))
    p,q,r=dot(a,b),dot(b,c),dot(a,c)
    assert min(p,q,r)>0
    return (p,q,r,weight(a),weight(b),weight(c),weight(add(a,b)),
            weight(add(a,c)),weight(add(b,c)),weight(add(add(a,b),c)))


def sampled_cells(wi,he,extra=()):
    values={(0,0),(wi-1,he-1),(wi//2,he//2)}
    values.update(extra)
    return {(i,j) for i,j in values if 0<=i<wi and 0<=j<he}


def test_actual(trials=12000,seed=20261113):
    rng=random.Random(seed)
    rays=[x for x in product(range(5),repeat=2) if any(x)]
    rays.sort(key=lambda a:a[1]/a[0] if a[0] else float('inf'))
    triples=[(a,b,c) for a,b,c in combinations(rays,3)
             if a[0]*b[1]>a[1]*b[0] and b[0]*c[1]>b[1]*c[0]]
    # No common primitive or equal-normal assumption on these carriers.
    statistics={'ambient_triples':0,'edge_inverse_checks':0,'literal_tight_checks':0,
                'unequal_input_weights':0,'common_h_greater_than_one':0,
                'nonprimitive_intermediates':0,'changed_actual_root_copy':0}
    sample=None
    for trial in range(trials):
        rank=2+trial%4
        D=[rng.randint(1,9) for _ in range(rank)]
        U=[(rng.randint(0,4),rng.randint(0,4)) for _ in range(rank)]
        K=[[0]*rank for _ in range(rank)]
        for i in range(rank):
            for j in range(i+1,rank):
                K[i][j]=lcm(D[i],D[j])*rng.randint(-3,3)
                K[j][i]=-K[i][j]
        effective=sum(U[i][0]*K[i][j]*U[j][1] for i in range(rank) for j in range(rank))
        if effective==0:continue
        if effective<0:K=[[-x for x in row] for row in K]
        raw=rng.choice(triples)
        a,b,c=[tuple(row[0]*x+row[1]*y for row in U) for x,y in raw]
        args=ambient_parameters(D,K,a,b,c)
        h,A,B,C,P,Q,R,total=rectangle_parameters(*args)
        statistics['ambient_triples']+=1
        statistics['unequal_input_weights']+=len(set(args[3:6]))>1
        statistics['common_h_greater_than_one']+=h>1
        statistics['nonprimitive_intermediates']+=max(args[6:9])>h
        left=[('L1',P,A*R+B*Q)]
        if C*Q>A*P:left.append(('L2',R,C*Q-A*P))
        for branch,wi,he in left:
            extra=[]
            if branch=='L1':extra=[(0,B*Q-1),(0,B*Q),(P-1,B*Q-1),(P-1,B*Q)]
            for i,j in sampled_cells(wi,he,extra):
                for k in {0,total-1,total//2}:
                    obj=from_cell(branch,i,j,k,*args)
                    moved=forward(obj,*args)
                    assert backward(moved,*args)==obj
                    assert to_cell(obj,*args)==(i,j,k)
                    statistics['edge_inverse_checks']+=1
                    if obj.outer.copy!=moved.outer.copy:
                        statistics['changed_actual_root_copy']+=1
                        if sample is None:
                            sample={'D':D,'K':K,'carriers':[a,b,c],'parameters':args,
                                    'source':asdict(obj),'target':asdict(moved),
                                    'normalized_root_phase':k}
                    if statistics['literal_tight_checks']<2000:
                        for item in (obj,moved):
                            ip,op,_=parameters(item.branch,*args)
                            for par,value in ((ip,item.inner),(op,item.outer)):
                                if sum(geometry(*par)[4:])<=200:
                                    word,gr=literal_grading(*par,value)
                                    assert is_tight(word,gr)
                                    statistics['literal_tight_checks']+=1
    return statistics,sample


def main():
    start=time.monotonic()
    cases,points=test_rectangles()
    statistics,sample=test_actual()
    report={'status':'PASS','scope':'first ABC critical diamond for arbitrary valued coplanar inputs',
            'weighted_rectangle_parameters':cases,'weighted_rectangle_point_maps':points,
            **statistics,'actual_root_copy_mixing_sample':sample,
            'seconds':time.monotonic()-start,
            'not_claimed':['all-degree triple coherence','path independence among local moves']}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
