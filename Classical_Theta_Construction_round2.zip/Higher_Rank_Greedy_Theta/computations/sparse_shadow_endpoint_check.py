"""Independent verification of sparse position/endpoint inequalities.

The direct oracle walks every edge until the first balance.  The sparse
predicate uses only marked-edge coordinates, one proposed endpoint,
fixed cyclic order, its balance equality, and inequalities immediately
before earlier positive edges of the same orientation.
"""
from collections import Counter
from itertools import combinations_with_replacement
from pathlib import Path
import json
import random
import time

from tight_grading_two_input import dyck_word, is_tight


def coordinates(word):
    x = y = 0
    result = []
    for edge in word:
        result.append((x, y))
        if edge == 'E':
            x += 1
        else:
            y += 1
    return result


def direct_endpoint(word, weights, start):
    orientation = word[start]
    direction = 1 if orientation == 'E' else -1
    total = opposite = 0
    for step in range(len(word)):
        j = (start+direction*step) % len(word)
        if word[j] == orientation:
            total += weights[j]
        else:
            opposite += 1
            if opposite == total:
                return j
    raise AssertionError('No balance despite the total-weight bound.')


def sparse_endpoint_predicate(word, coords, weights, start, end):
    orientation = word[start]
    assert weights[start] > 0 and word[end] != orientation
    L, r, s = len(word), word.count('E'), word.count('N')
    forward = orientation == 'E'
    distance = (lambda j: (j-start) % L) if forward else (lambda j: (start-j) % L)
    end_distance = distance(end)
    positive = [j for j, w in enumerate(weights)
                if w and word[j] == orientation and distance(j) < end_distance]
    x, y = coords[start]
    xe, ye = coords[end]
    wrap = int(end < start) if forward else int(end > start)
    balance = ye+1+wrap*s-y if forward else x-xe+wrap*r
    if balance != sum(weights[j] for j in positive):
        return False
    for j in positive:
        if j == start:
            continue
        before = sum(weights[h] for h in positive if distance(h) < distance(j))
        xj, yj = coords[j]
        wj = int(j < start) if forward else int(j > start)
        opposite_before = yj+wj*s-y if forward else x-xj+wj*r
        if opposite_before >= before:
            return False
    return True


def sparse_tight(word, weights, endpoints):
    L = len(word)
    H = [i for i, w in enumerate(weights) if w and word[i] == 'E']
    V = [i for i, w in enumerate(weights) if w and word[i] == 'N']
    hs = lambda h, v: 0 < (v-h) % L <= (endpoints[h]-h) % L
    vs = lambda v, h: 0 < (v-h) % L <= (v-endpoints[v]) % L
    if any(hs(h, v) and vs(v, h) for h in H for v in V):
        return False
    return (all(any(vs(v, h) for v in V) for h in H) or
            all(any(hs(h, v) for h in H) for v in V))


def main():
    begin = time.monotonic()
    counts = Counter()
    # Exhaust every one-color grading whose total obeys the shadow bound.
    # Opposite-color weights cannot affect this endpoint, so no Cartesian
    # duplication of the two independent endpoint checks is necessary.
    for r in range(1, 7):
        for s in range(1, 7):
            word = dyck_word(r, s)
            coords = coordinates(word)
            for j, edge in enumerate(word):
                x, y = coords[j]
                assert x+y == j
                if edge == 'E':
                    assert 0 <= x < r and r*y <= s*x < r*(y+1)
                else:
                    assert 0 <= y < s and s*(x-1) < r*(y+1) <= s*x
            for orientation in ('E', 'N'):
                positions = [i for i, e in enumerate(word) if e == orientation]
                opposite = [i for i, e in enumerate(word) if e != orientation]
                for total in range(1, len(opposite)+1):
                    for selected in combinations_with_replacement(positions, total):
                        weights = [0]*len(word)
                        for j in selected:
                            weights[j] += 1
                        counts['one_color_gradings'] += 1
                        for start in sorted(set(selected)):
                            actual = direct_endpoint(word, weights, start)
                            accepted = []
                            for end in opposite:
                                ok = sparse_endpoint_predicate(word, coords, weights, start, end)
                                assert ok == (end == actual), (r, s, weights, start, end, actual)
                                counts['candidate_endpoint_checks'] += 1
                                if ok:
                                    accepted.append(end)
                            assert accepted == [actual]
                            counts['positive_shadow_checks'] += 1
    rng = random.Random(202611131500)
    for _ in range(12000):
        r, s = rng.randint(1, 35), rng.randint(1, 35)
        word = dyck_word(r, s)
        coords = coordinates(word)
        H = [i for i, e in enumerate(word) if e == 'E']
        V = [i for i, e in enumerate(word) if e == 'N']
        weights = [0]*len(word)
        for i in rng.choices(H, k=rng.randint(1, s)):
            weights[i] += 1
        for i in rng.choices(V, k=rng.randint(1, r)):
            weights[i] += 1
        endpoints = {i: direct_endpoint(word, weights, i)
                     for i, w in enumerate(weights) if w}
        assert all(sparse_endpoint_predicate(word, coords, weights, i, j)
                   for i, j in endpoints.items())
        assert sparse_tight(word, weights, endpoints) == is_tight(word, weights)
        counts['two_color_tightness_checks'] += 1
    report = {'status': 'PASS', 'counts': dict(counts),
              'seconds': time.monotonic()-begin,
              'one_color_rectangles': [6, 6],
              'random_rectangles_bounded_by': [35, 35],
              'direct_oracle': 'first balance in an edge-by-edge cyclic walk',
              'sparse_predicate': 'coordinate balance plus earlier positive jump inequalities'}
    Path(__file__).with_suffix('.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
