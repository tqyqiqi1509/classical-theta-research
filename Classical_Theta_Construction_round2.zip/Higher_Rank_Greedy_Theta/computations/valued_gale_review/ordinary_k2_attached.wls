(* Exact call executed through the actual Wolfram Language plugin. *)
Module[{x1,x2,y1,y2,t,z,w,eq,gb,hor,att,vars,basis,swaps,red,tr},
 vars={x1,x2,y1,y2};
 basis={1,y2,y2^2,y2^3,y2^4,x2};
 eq={x1^2 (x1-y1)(x1-y2)-t,
     x2^2 (x2-y1)(x2-y2)-t,
     -y1 (x1-y1)(x2-y1)-t,
     -y2 (x1-y2)(x2-y2)-t};
 gb=GroebnerBasis[Append[eq,1-z t],{z,t,x1,x2,y1,y2},
                 MonomialOrder->Lexicographic];
 hor=Select[gb,FreeQ[#,z]&];
 gb=GroebnerBasis[Append[hor/.t->0,1-w x1 x2 y1 y2],
                 {w,x1,x2,y1,y2},MonomialOrder->Lexicographic];
 att=Select[gb,FreeQ[#,w]&];
 swaps={{},{x1->x2,x2->x1},{y1->y2,y2->y1},
         {x1->x2,x2->x1,y1->y2,y2->y1}};
 tr=Table[
   Sum[
     red=Last[PolynomialReduce[basis[[j]]/.swaps[[r]],att,vars,
                               MonomialOrder->Lexicographic]];
     If[j==1,red/.Thread[vars->0],Coefficient[red,basis[[j]]]],
     {j,Length[basis]}],
   {r,4}];
 <|"HorizontalGenerators"->Length[hor],
   "AttachedGroebnerBasis"->att,
   "StandardMonomials"->basis,
   "TracesIdentitySwapASwapBBoth"->tr,
   "DoubleSignMultiplicity"->(tr[[1]]-tr[[2]]-tr[[3]]+tr[[4]])/4|>
]
