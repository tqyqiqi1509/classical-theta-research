"""Exact comparison of the special radial endpoint perturbation catalogs.

Compares structural event/child flags only. No coefficient counts enter.
The root endpoints are H+epsilon and lambda*H+epsilon+delta*v, with
lambda allowed independent epsilon terms and positive constant term.
"""
from fractions import Fraction as Q
from functools import lru_cache
from collections import Counter
from pathlib import Path
import random,json,time

from valued_event_flag_grammar import EventFlags,extended_data,box,prim


def endpoint_theta(H,p,scale=Q(1),lin=None,v=None):
    n=len(H)
    if lin is None:lin=[0]*n
    cols=1+n+(v is not None)
    orig=[]
    for i in range(n):
        row=[scale*H[i]]+[Q(i==j)+lin[j]*H[i]for j in range(n)]
        if v is not None:row.append(Q(v[i]))
        orig.append(tuple(map(Q,row)))
    framing=tuple(-sum(p[i]*orig[i][j]for i in range(n))for j in range(cols))
    return (framing,)+tuple(orig)


def compare(B,D,g,p,H,lam,lin,v):
    Bhat,Dhat=extended_data(B,D,g)
    E=EventFlags(Bhat,Dhat)
    stats=Counter()

    @lru_cache(None)
    def rec(S,theta,other):
        stats['paired_states']+=1
        assert not any(E.evaluate_covector(theta,S))
        assert not any(E.evaluate_covector(other,S))
        for b in box(S):
            s1=E.lexsign(E.evaluate_covector(theta,b))
            s2=E.lexsign(E.evaluate_covector(other,b))
            assert s1==s2,(S,b,theta,other)
            stats['charge_sign_checks']+=1
        left=E.events(S,theta);right=E.events(S,other)
        assert [x[0]for x in left]==[x[0]for x in right]
        stats['paired_events']+=len(left)
        for (_,b,tau,joint),(_,bb,tt,jj) in zip(left,right):
            assert b==bb and E.lexsign(tau)==E.lexsign(tt)
            for T in box(S):
                if not any(T)or T==S or not E.in_plane(T,S,b):continue
                child=E.incoming_theta(joint,prim(T))
                child2=E.incoming_theta(jj,prim(T))
                stats['paired_child_edges']+=1
                rec(T,child,child2)

    rec((1,)+tuple(p),endpoint_theta(H,p),endpoint_theta(H,p,lam,lin,v))
    return stats


def main():
    start=time.monotonic();rng=random.Random(2611131533)
    stats=Counter();samples=[]
    for trial in range(180):
        n=2 if trial<120 else 3
        D=[rng.randrange(1,5)for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                t=rng.randrange(-2,3)
                B[i][j]=D[j]*t;B[j][i]=-D[i]*t
        g=[rng.randrange(-3,4)for _ in range(n)]
        p=[rng.randrange(0,3)for _ in range(n)] if n==2 else [rng.randrange(0,2)for _ in range(n)]
        H=[rng.randrange(-4,5)for _ in range(n)]
        lam=Q(rng.randrange(1,8),rng.randrange(1,5))
        lin=[Q(rng.randrange(-3,4),rng.randrange(1,4))for _ in range(n)]
        v=[rng.randrange(-5,6)for _ in range(n)]
        stats.update(compare(B,D,g,p,H,lam,lin,v))
        stats['endpoint_pairs']+=1
        if len(samples)<3:samples.append(dict(B=B,D=D,g=g,p=p,H=H,
                                             lam=str(lam),lin=list(map(str,lin)),v=v))
    result=dict(status='PASS',**stats,samples=samples,seconds=time.monotonic()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items()if k!='samples'},indent=2))


if __name__=='__main__':main()
