# A positive recursion on unlabelled trees and tableaux

2026-11-13. This is a representation-theoretic theorem about the graph/fan
module already constructed in `agents/intrinsic_partition_model.md`. Its
identification with theta coefficients uses the separately audited global
species-completion theorem. No theta value is used in the construction below.

## 1. Why take a further step

The sign-isotypic kernel is already an actual finite vector space. A character
average, however, displays alternating signs and a factorial denominator. We
can remove that global average entirely. The construction below uses one
representative of each unlabelled coloured tree, local nonnegative Specht
multiplicities, and counts of semistandard Young tableaux. It also avoids
building the often much larger global action matrices.

This is an application of induction, Frobenius reciprocity, and Schur--Weyl
duality. Those representation-theoretic facts are not claimed new. The point
is the explicit resulting recursion for the present graph-defined spaces.

## 2. Data attached to one tree

Fix the original-colour lexicographic order used by the direct set-partition
grammar. A tree has leaves coloured in {0,1,...,n}; colour 0 occurs exactly once
at the global root input. Let G be the product of symmetric groups permuting
the mutable labels of each colour. Write [T] for an orbit of admissible labelled
trees. Two trees are in the same orbit exactly when they are isomorphic as
unlabelled rooted coloured trees.

For a representative T let H_T be its colour-preserving automorphism group.
Let U_T be the tensor product of its local fan modules, with the arrow-parity
super symmetry. Let sgn_T be the sign of the permutation of all its leaves;
this equals the restriction of the product-of-colours sign character. Define

    K_T = Hom_(H_T)(sgn_T, U_T),        k_T = dim K_T.

For a singleton leaf, K_T=Q and k_T=1. If beta(T) is the colour-content vector,
put

    ell_T = number of leaves,
    q_T = sum_(i<j) eta_ij beta_i beta_j  (mod 2).

The leaf-pair identity proves that q_T is the total super parity of U_T.

## 3. The positive local formula

At the root of T, collect the immediate children into distinct isomorphism
types C_1,...,C_s with multiplicities m_1,...,m_s. Let L_T be the ordinary,
even, local intersection-cohomology representation of the root flow polytope.
Its child permutation group contains

    J_T = product_(j=1)^s S_(m_j).

For partitions lambda_j of m_j define the **actual** local multiplicity space

    M_T(lambda_1,...,lambda_s)
      = Hom_(J_T)(tensor_j Specht_(lambda_j), L_T),

and let b_T(lambda)=dim M_T(lambda). These integers are nonnegative because
L_T is a graph/fan-defined representation. They can be computed from its
actual matrices by solving intertwining equations. Computing their characters
is a faster equivalent option, not a use of theta coefficients.

Set e_j = ell_(C_j)+q_(C_j) modulo 2 and let lambda^[e] mean lambda if e=0,
and its conjugate partition if e=1. Then

    k_T = sum_(lambda_j partitions m_j)
            b_T(lambda_1,...,lambda_s)
            product_j SSYT(lambda_j^[e_j], k_(C_j)).             (3.1)

Here SSYT(lambda,d) is the number of semistandard tableaux of shape lambda
with entries from {1,...,d}. It is zero when lambda has more than d rows.
Every displayed summand is a nonnegative integer. There is no alternating
global cycle average and no division by |G| in (3.1).

Finally,

    dim Hom_G(sgn, W) = sum_[T] k_T.                           (3.2)

The sum is over the unlabelled tree orbits produced by the direct grammar.

## 4. Proof

The summands of W over one G-orbit of trees form Ind_(H_T)^G U_T. Frobenius
reciprocity gives (3.2).

The automorphism group at a root is the product of wreath products

    H_T = product_j (H_(C_j) wr S_(m_j)).

First impose the leaf-sign condition for the normal subgroup consisting of
the individual child automorphism groups. This replaces each child tensor
factor U_(C_j) by K_(C_j). No other child representation survives, because
the relevant functor is exact over Q.

Now interchange two copies of C_j. Their exchange as leaf sets has sign
(-1)^ell_(C_j). Their exchange as super tensor factors contributes
(-1)^q_(C_j). Thus the remaining symmetric-group sign to impose on the
ordinary tensor power K_(C_j)^(tensor m_j), together with L_T, is
sgn^(ell_(C_j)+q_(C_j)). This is the exponent e_j above.

Decompose L_T under J_T into its Specht isotypic summands. Schur--Weyl duality
decomposes each ordinary tensor power as

    K^(tensor m) = direct_sum_(mu partitions m)
                       Specht_mu tensor Schur_mu(K).

All Specht modules over Q are self-dual, and Specht_lambda tensor sgn is
Specht_(lambda transpose). Taking the requested sign multiplicity therefore
leaves exactly Schur_(lambda^[e_j])(K_(C_j)) for the j-th factor. Its dimension
is SSYT(lambda^[e_j], k_(C_j)). This proves (3.1).

This argument also proves that the full vector space is a direct sum of

    M_T(lambda) tensor product_j Schur_(lambda_j^[e_j])(K_(C_j)).

It establishes actual spaces, not merely a numerical positivity identity.

## 5. A finite counted-object interpretation

Choose, by fixed rational row reduction, a basis of each local intertwiner
space M_T(lambda). These matrices are constructed only from the local face
incidence data and standard polytabloid matrices. Having chosen bases of the
child spaces recursively, the usual semistandard-tableau basis of each Schur
functor gives a basis of the displayed direct sum.

Thus a basis label consists of an unlabelled admissible coloured tree, a local
Specht-multiplicity basis label at each node, and semistandard tableaux whose
entries are recursively constructed child basis labels. The number of such
labels is (3.2). No step first evaluates a theta coefficient and then declares
that many artificial objects.

This is a pure graph/fan **linear-algebra and tableau** model. It should not be
misdescribed as a proved elementary Dyck-path bijection, as a point-set basis
of the local polytope, or as a recovery of the user's unavailable original
figure. The remaining local linear algebra is substantive and explicit.

## 6. Normalization checks

For B=0, a framed colour-i star has local module (Q^(r_i))^(tensor p_i).
Its child is a leaf, so ell=1, q=0 and e=1. Formula (3.1) gives the exterior
power Lambda^(p_i)(Q^(r_i)), of dimension binomial(r_i,p_i). Several colours
give the product of these binomial coefficients.

For two identical one-arrow two-leaf branches, ell=2 and q=1, so e=1. For
three-leaf two-arrow branches, ell=3 and q=0, again e=1. These exponents are
consistent with the corrected arrow-parity rule and detect the previously
failed self-Euler normalization.

The implementation `computations/orbit_schur_positive.py` independently
constructs the direct trees and local fan characters, then applies (3.1).
Five initial structural comparisons agree with the existing actual-kernel
calculations or the independent theta recursion. For the S4 input with
65 labelled trees and a 15,670-dimensional global module, only eight tree
orbits are needed; one contributes 60 and the other seven contribute zero.
This takes under half a second in the recorded run. The tests check this
implementation; the representation-theoretic proof is Section 4.

## 7. Theta consequence after the independent review

The global species identification in `agents/species_completion_bridge.md`
has now passed a separate internal adversarial proof review, with the genuine
section-equivariance and all-slope-genericity corrections recorded in
`agents/species_adversarial_audit.md`. Consequently, for every skew-symmetric B, integral g
and p>=0, the classical formal theta coefficient a_g^B(p) is the positive
sum (3.1)--(3.2). For finite theta functions the same construction determines
the actual Laurent polynomial. The global identification remains a separate proof dependency; no extension
of the natural local modules to nonscalar D is asserted here.


## 8. Actual constructive implementation (12:38 UTC update)

`computations/local_specht_basis.py` constructs standard polytabloids in the
tabloid permutation module, computes adjacent-transposition matrices, and
solves the actual equations A_s M = M S_s. It never uses a character average
to construct a multiplicity space. Eighteen Specht shapes through size five
were checked against an independent Murnaghan--Nakayama implementation. The
non-simple K22,2 local fan gives intertwiner dimensions (8,4,4,0), including
the vanishing double-sign space. A three-leaf star with a genuine
two-dimensional Specht source gives eight explicit intertwiners.

`computations/constructive_tableau_objects.py` now enumerates all recursive
basis labels, including each complete child object as an entry of the parent
tableau. Star multiplicity labels themselves are ordinary tableaux; other
local labels index the computed rational intertwiner basis. No theta value
or global character is passed into this constructor. After construction the
three recorded inputs agree with independent coefficients 6, 8, and 60. The
JSON contains the actual objects and sparse local basis matrices.

This supplies a reproducible finite object construction. The local linear
algebra is still part of the definition: no elementary parking-function or
Dyck-path replacement of all local Specht multiplicity spaces is claimed.

## 9. Direct generation by colour contents (13:08 UTC update)

The labelled-set enumeration can be removed from the construction itself.
For a state of colour content alpha, enumerate nonzero proper integer
subcontents beta<=alpha. Each nonzero wedge alpha^beta determines one
candidate nondegenerate charge plane. The time and projected covector are
computed on colour contents, exactly as in the labelled construction.
For every proper subcontent in this plane, recursively construct its
admissible unlabelled child types. Enumerate nondecreasing multisets of
these child types whose contents sum to alpha. Retain the strict-positive
time and nonparallel conditions. This is the algorithm implemented in
`computations/unlabelled_charge_partitions.py`.

**Orbit-bijection proposition.** This algorithm produces exactly one type
for each orbit of the labelled admissible trees under the product of the
leaf-colour symmetric groups.

Proof. Every defining admissibility condition uses only subtree colour
contents, the alternating form on contents, and the covector restricted to
those contents. It is consequently invariant under colour-preserving leaf
relabelling. Forgetting labels therefore maps every admissible labelled tree
to an output of the content algorithm, by induction from the leaves.
Conversely, assign the prescribed distinct labels of each colour to the
leaves of an output tree. Its content tests are unchanged, so every such
assignment yields an admissible labelled tree. Any two assignments differ
by a product of colour permutations. Finally, two labelled trees lie in
the same such orbit if and only if their underlying coloured rooted trees
are isomorphic. Sorted multisets of child types encode precisely these
isomorphism classes, again by induction. Deduplication by their complete
tree signatures also removes any repeated generation from the same plane.
This proves the bijection.

The stabilizer order is computed intrinsically by

    aut(leaf)=1,
    aut(T)=product_C aut(C)^(m_C) m_C!.

Thus an orbit has product_i p_i!/aut(T) labelled representatives. This
identity is used only for a verification statistic, not as a weight in the
positive recursion. The recorded comparisons recover respectively 3, 8,
and 7 tree orbits, and all positive contributions agree term by term with
the independent labelled constructor. In particular the coefficient-315
case is generated from seven unlabelled types without first constructing
individual leaf labels.
