# Tight Dyck gradings as integral alcoved cells

Root branch, 2026-11-13. Independently checked by
`valued_polyhedral_mechanism` against the actual BLM definitions.

This strengthens the rational-cell observation in
`TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md`. The relevant cells have an
interval-sum structure, so their integer-equivalent closed forms are
integral alcoved polytopes with unimodular triangulations. It does not
claim that the closure of each original rational open cell is integral.

## 1. Fixed path and normalized weights

Fix the maximal path P(r,s), with horizontal edges h_1,...,h_r and
vertical edges v_1,...,v_s in their cyclic path order. For the valued
operation, horizontal weights have the form u x_i and vertical weights
v y_j, where x_i,y_j are nonnegative integers and u,v are fixed positive
integers. Their two total sums are fixed:

    sum x_i=H,                 sum y_j=V.                (1.1)

In the local coefficient at j(a alpha+b beta), H=jb and V=ja. The
unscaled path dimensions can be much larger than these normalized sums.

The compatible-grading condition of BLM Definition3.14 compares

    u sum_(h_i in a cyclic interval) x_i
        with the number of vertical path edges in that interval,

or the analogous expression involving only the y variables and a
horizontal edge count. The shadow endpoint in Definition5.1 is the
first equality in exactly one of these lists. The tests never contain
a row mixing horizontal and vertical WEIGHTS. The opposite-color
quantity is a fixed geometric length, not a variable grading sum.

The two shadow-inclusion alternatives in Definition5.3 subsequently
couple the resulting discrete truth values, but do not introduce a new
mixed linear form.

## 2. A finite sign signature determines every path condition

List all cyclic prefix and suffix comparisons that can occur while
testing a horizontal/vertical edge pair or a shadow endpoint. Include
the conditions x_i=0 and y_j=0. For every comparison record its sign
in {-1,0,1}. A signature epsilon determines:

- exactly which edges carry positive weight;
- the first balancing endpoint for each positive edge, or the absence
  of such an endpoint, in which case its shadow is all opposite edges;
- whether every required pair has a compatible intermediate witness;
- whether one of the two shadow inclusions holds.

Thus admissibility is constant on a sign cell. All possible signatures
are enumerated from the path, independently of the coefficient to be
counted. Infeasible signatures and those failing the path tests are
discarded. This is a finite system; no wall list or algebraic roots enter.

The sign cell factors as C_H x C_V because all listed linear forms use
one color. The retained subset of signatures need not be a Cartesian
product, but each individual retained cell is one.

## 3. Cyclic intervals become ordinary interval bounds

A cyclic interval that does not wrap is an ordinary consecutive sum.
For one that wraps, (1.1) expresses its weight as the fixed total minus
the weight of the complementary ordinary interval. Therefore all the
conditions can be written using ordinary interval sums only.

On integer variables, for positive u and integer c,

    u L < c    iff L <= ceil(c/u)-1,
    u L > c    iff L >= floor(c/u)+1,
    u L <= c   iff L <= floor(c/u),
    u L >= c   iff L >= ceil(c/u).

The equality uL=c gives L=c/u when u divides c, and is infeasible
otherwise. The same statements hold with v. In particular a zero edge
is x_i=0, and a positive edge is x_i>=1. Fixed totals and nonnegativity
are already integral interval conditions.

It follows that every signature has exactly the same integer points as
one closed region of the form

    P_H(epsilon)={x>=0: sum x_i=H,
                     a_ij <= x_(i+1)+...+x_j <= b_ij},  (3.1)

with integral bounds, and similarly P_V(epsilon). Empty regions are
allowed and discarded. The new closed region is an integer-equivalent
representative; it is not generally the real closure of the old cell.

Different signatures have disjoint integer-point sets after this
replacement. In fact any differing comparison imposes incompatible
integer-rounded bounds on its linear form, unless one cell is empty.
Thus there is no boundary double count.

## 4. Integrality and an explicit unimodular triangulation

Set X_0=0 and X_j=x_1+...+x_j, so X_r=H. This gives a lattice
isomorphism between the affine lattice sum x_i=H and the lattice of
(X_1,...,X_(r-1)). An interval constraint becomes

    a_ij <= X_j-X_i <= b_ij.                            (4.1)

The coefficient matrix has rows e_j-e_i, with the anchored coordinate
X_0 or X_r replaced by its fixed integer. It is a transpose of a
directed graph incidence matrix with an anchored column removed.
Therefore it is totally unimodular: equivalently, each square minor
is 0,1 or -1, as follows by the usual leaf-column expansion, while a
cycle gives a dependent row set. With integral right sides, every
vertex of the bounded region is integral.

In the cumulative coordinates, (4.1) is precisely a type-A alcoved
polytope. An explicit triangulation is obtained by all affine braid
hyperplanes

    X_j-X_i=m,                   m in Z.

Inside a unit cube, fix an ordering of the fractional parts of the
coordinates. The resulting simplex has vertices obtained by adding
successive coordinate unit vectors; its determinant has absolute
value one. All defining bounds of (4.1) are unions of faces of this
triangulation, so the restriction triangulates P_H. The same argument
handles lower-dimensional cells in their affine integer lattice:
equalities identify coordinates up to integral translations, and the
remaining difference constraints have the same form.

This is the classical alcove triangulation, not a new theorem about
alcoved polytopes. Lam--Postnikov's primary text, Section2.3 and
Theorem3.1, gives the general framework. The direct argument above
states exactly the specialization needed here.

Products P_H x P_V have integral vertices. The standard staircase
triangulation of products of unimodular simplices gives a unimodular
triangulation of their product lattice. Products at independent
recursive nodes have the same property.

## 5. The precise local counting statement

For fixed local valued input data and output degree, the unadorned
tight gradings are the integer points of the disjoint finite union

    disjoint union_(epsilon admissible)
        P_H(epsilon) x P_V(epsilon).                    (5.1)

Their coefficient decorations are still the actual input sets indexed
by the corresponding normalized edge weight. If a single unweighted
polyhedral description is desired, refine by the finite choices of
positive edge weights and child-decoration types. Fixing one weight
is another one-coordinate interval equality, so it preserves the
alcoved description. No multiplicity is replaced by an unexplained
number of copies.

The positive ambient normal power c is represented by ordered copies
of (5.1) with output degrees summing to the requested degree. Empty
copies can instead be encoded by choosing the occupied positions in
[c]. Their order constraints are another elementary integral order
simplex. Both descriptions are actual finite objects.

## 6. Global consequence and its limits

The finite event-flag grammar uses only a finite tagged union of local
objects, products, and positive ordered tuples. For a fixed normalized
tree and fixed child-degree choices, replace each local tight grading
by its alcoved cell. The resulting global polyhedral pieces are finite
products of integral alcoved polytopes and order simplices. Their
integer points, with their explicit tree labels, give exactly the
theta coefficient. This strengthens the earlier rational-cell claim.

The same replacement applies to the actual active-copy objects of
`POLYHEDRAL_REPLICATION_OBJECTS.md`. Thus its binomial factors and its
formerly unknown multiplicities both have explicit integral-polyhedral
descriptions rooted in path compatibility.

Nothing here proves that all pieces are the faces of a single convex
polytope, or that their union is a regular subdivision of a common
Newton polytope. It also does not prove a canonical equivalence with
the primitive-center Gale/IH model. Convexifying the labelled union
would generally forget compatibility and multiplicities. Those are
separate questions, not consequences of total unimodularity.

## 7. Computation and source audit

The actual Wolfram Language service checked 112,608 integer rounding
equivalences with no error. It independently evaluated all 3,003 full
minors of the complete anchored difference-constraint matrix on six
vertices: 1,296 have absolute determinant one and 1,707 are zero, with
no other values. This is the expected spanning-tree count 6^4. The
receipt is `computations/tight_alcoved_wolfram.json`.

These checks test the rounding and matrix conventions. The theorem
for arbitrary paths follows from Sections1--4, not from those samples.

Primary sources read:

- A. Burcroff, K. Lee, L. Mou, arXiv2503.03719v1, Definitions3.12,
  3.14,5.1,5.3,5.4: https://arxiv.org/html/2503.03719v1 . The interval
  and first-endpoint rules were checked in the displayed definitions.
- T. Lam, A. Postnikov, *Alcoved Polytopes I*, arXiv:math/0501246v2,
  Section2.3,Theorem3.1:
  https://math.mit.edu/~apost/papers/alcoved1.pdf . The paper was opened
  and the defining inequalities and triangulation were read. Theorem3.2
  is a volume formula, so it is not mis-cited as the triangulation
  theorem.

The targeted search did not locate this exact tight-grading cell
decomposition, but that is not a proof of priority. The new use is the
explicit translation of the actual compatible/shadow conditions into
integer interval cells, followed by the independently constructed
all-rank valued event grammar. No Li--Pan conclusion is invoked.
