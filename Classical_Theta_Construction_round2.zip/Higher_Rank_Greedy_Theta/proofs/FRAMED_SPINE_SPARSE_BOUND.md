# Framed spines improve the uniform sparse dimension bound

2026-11-13. Classical skew-symmetrizable setting only.

This note proves a general refinement of the tagged-polytope model in
`GLOBAL_SPARSE_POLYHEDRAL_RECIPE.md`. It uses the actual ordinary-slot
bijection of `agents/FRAMED_SPINE_FUSION_TRANSPORT.md`, Section 1, and
the flattened-tree bijection of `BOUNDED_FLAGGED_DYCK_TREES.md`,
Sections 2--4. No equality-of-cardinalities matching is used.

The refined uniform bound for a positive one-frame coefficient of
unframed degree `p` is

\[
                 d_\sigma\leq 9|p|-8.                 \tag{0.1}
\]

The same bound applies to every positive-degree coefficient in the
flat all-arity multiplication formula. More precisely, a coefficient
split having `j` positive-degree factors has bound `9|p|-8j`.
Here and throughout, dimension means the number of scalar coordinates
in the displayed rational-polytope description; intrinsic dimension
can be smaller.

## 1. An unframed coefficient costs at most nine per non-root leaf

**Lemma 1.1.** Fix any positive unframed coefficient object in any
state, incoming packet, or tagged occurrence of the finite event
catalog. Let its charge be `T`, let `ell=|T|`, and let `L` be the
number of its original-color leaves in the flattened tree. Every
sparse-polyhedral piece of this discrete tree type has at most

\[
                    9(L-1)\leq9(\ell-1)              \tag{1.1}
\]

coordinates. This includes an object whose root is a parallel
assembly vertex.

**Proof.** Suppress one-factor wrappers while retaining their full
state, event, occurrence, and allocation tags, as in the flattened
tree construction. Every remaining internal vertex has at least two
positive children. If there are `I` internal vertices, the number
of edges is `E=L+I-1`, and `E>=2I`. Hence

\[
                 I\leq L-1,\qquad E\leq2(L-1).
\]

Let `E_D` be the number of child edges at Dyck vertices and `P_D`
the total number of nonempty normal copies at these vertices. Each
nonempty copy has a positive horizontal and a positive vertical
decoration, so

\[
           E_D\leq E,\qquad 2P_D\leq E_D.
\]

The sparse position model uses four coordinates for every positive
decoration slot: its edge position and its uniquely determined
minimal shadow-endpoint position. It uses one additional coordinate
for every occupied normal-copy position. Consequently its total
ambient coordinate count is

\[
       4E_D+P_D\leq4\cdot2(L-1)+(L-1)=9(L-1).
\]

An original leaf `(i,k)` has positive integer mass `k`; charge
conservation therefore gives `L<=ell`. A leaf alone has no polytope
coordinate, as required when `L=1`. QED.

### 1.1 Why parallel products and catalog labels do not add coordinates

A parallel coefficient product with two or more positive allocations
becomes a parallel assembly vertex. The allocations and the ordered
packet identifiers are discrete type labels. The coefficient recipe
is the Cartesian product of its child recipes; it introduces no
additional polytope coordinate. Zero allocations have their unique
empty decoration. A one-factor allocation only adds its saved tag.

Equivalently, if such an object is stored as a forest with `r` positive
roots, applying the same count componentwise gives
`9(L-r)<=9(L-1)`. Adding a formal assembly root introduces no geometric
coordinate. Thus calling the representation a tree or a forest cannot
invalidate (1.1).

Normal copies are already included in `P_D`. Their possibly large
ambient copy count `c` is the upper bound in
`1<=t_1<...<t_s<=c`, with precisely `s` variables for the occupied
copies. It is not a list of `c` additional discrete choices or
coordinates. Distinct source occurrences, repeated words, inherited
parallel packets, and contracted unary wrappers retain their full
catalog tags. Tags can increase the number of pieces; they contribute
zero to the dimension of each piece.

## 2. One framing coordinate gives a spine of ordinary slot words

Take unit framing weight and target `(1,p)`. Every ancestor of the
unique frame leaf has exactly one child containing that frame.
These ancestors form the framing spine. All other child objects are
unframed and have positive charge.

At a local birth on this spine, name the unframed carrier `alpha`
and the framed carrier `beta`, reversing the two orientations if
necessary. The cutoff forces the framed carrier and the output
coefficient to occur once. Hence the output is `a alpha+beta`,
where `a>=1`, and

\[
 d=w(\alpha),\quad m=|K(\alpha,\beta)|>0,\quad
 Q=m/d\in\mathbb Z_{>0}.
\]

The framing coordinate and its unit symmetrizer entry imply
`w(beta)=w(a alpha+beta)=1`. In the singleton-factory normalization,
the horizontal total is `Q`, the vertical total is `a m`,
`gcd(a m,Q)=Q`, and the normal-copy multiplicity is one. The free
cyclic phase action therefore shifts its phase by minus one modulo
`Q` with each slot rotation. Each orbit has exactly one phase-zero
representative, even when the decorated word is periodic.

The proved actual-edge map consequently identifies this factory,
including all its coefficient decorations, with

\[
        [t^a]F(t)^Q\ \times\ \mathcal B,              \tag{2.1}
\]

where `F` is the unframed input coefficient-set packet and
`B` in (2.1) is the already chosen framed child decoration. The
word in (2.1) has `Q` ordered slots, and empty slots have their
unique degree-zero decoration. This map uses the cyclic phase and
prefix-height normal form, with the explicit actual-edge inverse
in the cited framed-spine theorem. It does not match finite sets
by rank or by a known coefficient value.

For one such node, fix the number `c_v>=1` of occupied slots and
the ordered positive composition

\[
                 j_1+\cdots+j_{c_v}=a.
\]

The occupied positions are the lattice points of the integral
polytope

\[
 \Delta_{Q,c_v}=\{(s_1,\ldots,s_{c_v}):
              0\leq s_1,\quad s_i+1\leq s_{i+1},
              \quad s_{c_v}\leq Q-1\}.             \tag{2.2}
\]

The decorations are, in the same order, one complete unframed
object from each `F_(j_i)`. Reading the nonempty positions of a
word gives (2.2), its composition, and these decorations; inserting
the unique empty entries is the inverse. This is an exact object
bijection with exactly `c_v` position variables. The discrete
composition has no continuous coordinates. The formulas do not
scan the `Q` slots, and `Q` may be arbitrarily large.

A framed positive parallel assembly cannot occur: charges on its
ambient ray are positive integer multiples of the primitive ray
whose frame coordinate is one, and two positive such charges
would exceed the framing cutoff. Inherited one-factor/state
wrappers only add tags to the spine. Thus there is no omitted
geometric contribution at its root or between its nodes.

## 3. The refined dimension theorem

**Theorem 3.1.** Fix classical skew-symmetrizable data, a unit frame,
any permitted generic endpoint/state covector, and a coefficient
degree `p>=0`. The corresponding one-frame coefficient set has an
explicit tagged rational-polytope recipe, obtained by replacing
each framed factory by (2.2) and each attached unframed coefficient
by the existing sparse recipe. For `p!=0`, fix one discrete piece
type and let

* `C` be the total number of occupied ordinary slots over its
  framing spine;
* `T_1,...,T_C` be the charges of the complete unframed objects in
  those slots;
* `ell_i=|T_i|` and `L_i` be their masses and original-leaf counts;
* `L=sum_i L_i` be the total number of unframed original leaves.

Then

\[
 \begin{split}
 d_\sigma
   &\leq C+9\sum_{i=1}^{C}(L_i-1)\\
   &=9L-8C
    \leq9|p|-8C
    \leq9|p|-8.                                    \tag{3.1}
 \end{split}
\]

For `p=0`, the coefficient object is the unique frame leaf, and
its dimension is zero.

**Proof.** The unframed objects meant here are the maximal subobjects
attached directly to the spine, one complete coefficient object per
occupied slot. Internal unframed subtrees are not counted again.
Every original unframed leaf belongs to exactly one of these
subobjects. Charge conservation gives

\[
        T_1+\cdots+T_C=p,\quad
        \ell_i\geq1,\quad \sum_i\ell_i=|p|.
\]

If `p!=0`, there is an unframed leaf, hence `1<=C<=|p|`. The spine
slot polytopes use exactly `sum_v c_v=C` position coordinates.
Each attached object has the bound of Lemma 1.1. Cartesian products
use disjoint coordinate blocks; their dimensions therefore add to
the first expression in (3.1). All remaining operations are tagged
unions or structural tags and add no coordinate. QED.

In the ordinary cluster specialization every unframed original leaf
has mass one, so `L=|p|`. In the universal elementary version one
may use the sharper leaf-profile bound `9L-8C`. Both constructions
preserve the original elementary monomial and any external leaf
labels, because the maps only move entire decorated slots.

### 3.1 Finiteness and binary size

The construction retains the finite, independent event catalog;
it changes only the local representation of the framed objects.
Every positive spine node attaches at least one positive-charge
object, so the number of such nodes is at most `C<=|p|`. The number
of compositions, tree shapes, unframed weak-order types, and event
tags remains bounded in terms of `|p|` after restricting to its
support. Occupied slot indices are variables, not `Q` separate
tags. Thus the number of pieces retains the arrow-independent
fixed-degree bound of the original sparse recipe.

The new inequalities have coefficients in `{0,1,-1}` and bounds
`Q-1`; the binary length of `Q` is controlled by the pairing and
normal-weight input. Their construction adds no dependence
polynomial in the numerical size of `Q`. The other blocks retain
the original fixed-degree binary-size estimates. This is a sharper
fixed-dimensional counting interface, not a claim of polynomial
complexity in varying degree or an implemented Barvinok counter.

## 4. Flat theta multiplication in every arity

Use the already established flat endpoint formula from
`TWO_FRAMING_THETA_MULTIPLICATION.md`, Corollary 3.2:

\[
 \bigsqcup_{p_1+\cdots+p_k=p}
                    \prod_{i=1}^k O(g_i,p_i;U).       \tag{4.1}
\]

Fix one degree split, and let `j` be the number of indices with
`p_i!=0`. The zero-degree factors are frame-leaf singletons. Apply
Theorem 3.1 separately to each positive-degree factor. Every piece
in this split then satisfies

\[
 \begin{split}
 d_\sigma
 &\leq\sum_{p_i\ne0}(9|p_i|-8)\\
 &=9|p|-8j.                                         \tag{4.2}
 \end{split}
\]

If `p!=0`, every split has `j>=1`, giving the uniform bound
`9|p|-8`, independent of the number of input theta factors. The
degree-zero coefficient again has dimension zero. Keeping the
attachment counts gives the stronger per-piece inequality
`d_sigma<=9|p|-8 sum_i C_i`.

Equation (4.2) concerns the flat product recipe (4.1). It does not
identify differently bracketed binary object models and does not
resolve the causal catalog-rerouting problem for a theta
associator. In particular no fusion coordinate is silently omitted:
(4.1) is a product of one-frame objects, not the separate mixed
two-frame fusion model.

## 5. Implementation boundary

`computations/fast_framed_spine.py` implements the actual compressed
slot sets (2.2), their positive compositions, and the original
unframed coefficient decorations. Its original unframed backend
is the literal Dyck factory.

The separate `computations/fast_framed_sparse_polytope.py` now
implements the substitution in Theorem 3.1. It reuses the framed
local rule, compiles every occupied framed-slot set into the
explicit zero-based inequalities (2.2), and delegates unframed
births to `SparsePolytopeObjects`. Both local families therefore
export integer `A,b,E,d` data. The universal original-elementary
and ordinary-unit-leaf specializations are separate classes. The
complete recipe is constructed and exported before cardinality
is evaluated.

Two existing fixtures check the integration boundary. The already
verified valued multiplication input

`B=[[0,2,-1],[-1,0,1],[1,-2,0]], D=(1,2,1)`,

`g1=(-1,-1,1), g2=(-1,2,2), p=(1,1,0)`

still has count `3`. Its new recipe has 52 reachable nodes, two
framed-slot polytopes, and maximum ambient dimension `2`, below
the new bound `10`. This fixture alone does not exercise an
unframed local birth. The established local nonprimitive fixture
with parents `(1,0),(1,2)` and determinant pairing, with an inert
zero frame prepended, separately exercises that delegation. It
retains explicit normal-copy and sparse path matrix blocks,
15 reachable polytopes, count `4`, and maximum dimension `9`.
Both constructions succeed while the literal path factory is
patched to raise if called, and both make zero cardinality calls
before their recipes have been completed. The report and both
matrix recipes are exported beside the implementation. These
checks test the two backend branches; the general bound is not
inferred from them.

The proof of the dimension bound is the tree and charge count
above. It requires no enumeration of low-rank examples. Its
object maps are the existing sparse edge/endpoint bijection,
the framed cyclic-phase normal form, and compression of occupied
positions. No conclusion about a Li--Pan basis, quantum
coefficients, invariant geometric strata, or a global associator
is asserted.
