# Explicit Dyck objects for every classical valued two-input operation

2026-11-13. This note replaces the algebraic local orbit labels in the
positive charge-word grammar by bounded integer gradings of lattice
paths. The rank-two tight-grading identity is prior work of
Burcroff--Lee--Mou, *Positivity of generalized cluster scattering
diagrams*, arXiv:2503.03719v1, Theorem1.2 and Definitions3.14,3.17,5.1--5.4.
The original-normal calculation below spells out its exact use in the
present valued charge grammar. No Li--Pan theorem is used.

Primary text: https://arxiv.org/pdf/2503.03719 . The local definitions and
Theorem9.5's change-of-lattice argument were read in the primary paper.
The construction here uses the direct normal calculation below rather
than relying on a possibly ambiguous printed exponent substitution.

## 1. Integer conversion of a pair

Let K be the integral alternating form in the charge-word convention,
let D be the original symmetrizer, and put

    w(a)=gcd_i(D_i a_i),     n_a=D a/w(a).

Take two nonparallel positive carriers alpha,beta with

    m=K(alpha,beta)>0,     d=w(alpha),     e=w(beta).

Then d and e divide m. In the rational plane they span set

    u=m/d,    v=m/e,    e_1=alpha/v,    e_2=beta/u.

The normalized first input has exponent +1 on e_2, and the normalized
second input has exponent -1 on e_1. Thus in these coordinates their
functions are P_1(x)=F(x^v) and P_2(y)=G(y^u), with the standard
determinant-one normal action.

For coprime positive a,b retain the carrier gamma=a alpha+b beta. Put

    ell=gcd(a v,b u),
    A=a v/ell, B=b u/ell,
    c=m w(gamma)/(ell d e).

The pair (A,B) is primitive in the enlarged coordinate lattice. Its
standard normal is

    n_delta=A n_alpha+B n_beta=c n_gamma.

The first expression is an integral normal on the ORIGINAL ambient
lattice, since A and B are integers. The vector n_gamma is primitive
there. Therefore c is a strictly positive integer. This proves the
required integrality even when the original two carriers span a proper
sublattice; there is no fractional root at any step.

If f_delta is the standard output function in the enlarged coordinates,
the correctly normalized original output is

    H_gamma=f_delta^c.                                      (1.1)

Indeed both actions raise a test monomial by the same exponent, since
n_delta=c n_gamma. Carrier gamma itself is never divided by its ambient
gcd: it remains the variable step of H_gamma.

## 2. The finite local objects

First define the coefficient objects of f_delta at z^(j gamma), j>0.
Choose the deterministic integer pair (r,s) with

    A s-B r=1,     r>=j a v,     s>=j b u,

by taking the smallest r satisfying the congruence and then s=(1+B r)/A.
Use the maximal northeast lattice path from (0,0) to (r,s) lying weakly
below its diagonal. An object is a nonnegative grading omega on its
horizontal and vertical edges, subject to the following requirements.

1. The total vertical weight is j a v, and the total horizontal weight is
   j b u. Each vertical weight is divisible by v; each horizontal weight
   is divisible by u.
2. For every positive horizontal edge h and positive vertical edge t,
   some proper intermediate vertical edge closes a prefix starting at h
   with equal vertical length and horizontal weight, OR some proper
   intermediate horizontal edge closes a suffix ending at t with equal
   horizontal length and vertical weight. Subpaths are read cyclically.
   This is the usual compatible-grading condition.
3. The positive horizontal edges lie in the union of the shadows of the
   vertical edges, OR the positive vertical edges lie in the union of
   the shadows of the horizontal edges. A horizontal shadow ends at the
   first vertical edge where prefix vertical length equals horizontal
   weight. A vertical shadow begins at the first horizontal edge found
   backwards where suffix horizontal length equals vertical weight.
   If no such equality occurs, its shadow is all opposite edges.
4. A positive vertical edge of weight v t is decorated by one object
   from the input coefficient set F_t. A positive horizontal edge of
   weight u t is decorated by one object from G_t. Zero-weight edges
   have no decoration.

Conditions1--3 are precisely the tight-grading condition at this chosen
rectangle: the determinant of the total weights and (r,s) is j ell,
the gcd of those total weights. They use only integer edge weights,
cyclic intervals, lengths, sums and comparisons. There are finitely
many gradings because each weight is bounded by its prescribed total.

The coefficient object for j=0 is the singleton empty object. To obtain
the coefficient of z^(k gamma) in (1.1), take an ordered c-tuple of
these objects, with nonnegative degrees j_1+...+j_c=k. This is an actual
finite set defined by paths and decorations, rather than an index set
whose size is a coefficient computed elsewhere.

## 3. Why the coefficient is exact

The standard tight-grading theorem identifies the weighted sum of
conditions1--3 with the coefficient of f_delta. Substituting
P_1(x)=F(x^v), P_2(y)=G(y^u) removes precisely those gradings violating
the divisibilities in condition1, and condition4 replaces each surviving
weight monomial by a Cartesian product of input coefficient objects.

Only powers z^(j gamma) remain on this ray. To see this directly, the
standard factorization is invariant under x->xi x, y->zeta y for
xi^v=zeta^u=1, since its input product is. Uniqueness of the ordered
ray factors forces the same invariance on each factor. For an exponent
t(A,B), divisibility v|tA and u|tB says

    a(t/ell) and b(t/ell) are integers.

As gcd(a,b)=1, t/ell is an integer. Thus t is a multiple of ell, exactly
the charge multiples j gamma used above.

Finally the positive integer normal power c gives the ordered tuple
rule. The resulting local transformation agrees with the previously
proved ramified attached-algebra transformation. These are two separate
realizations of the same universal coefficient polynomial: one by
finite representation-theoretic objects and one by explicit Dyck
gradings. No claim of a canonical bijection between the realizations
is needed for the global recursion.

## 4. Exact implementation and checks

`computations/tight_grading_two_input.py` constructs the maximal path,
enumerates bounded gradings, finds the minimal shadow endpoints, checks
compatibility and the shadow condition, and retains the input-decoration
profile of each actual grading. Its `valued_profiles` function then
performs exactly the c-fold tuple operation.

An independent literal cyclic-subpath implementation agrees with the
minimal-shadow compatibility test on 1,000 inputs. The four actual
gradings for the standard (2,2) coefficient give

    p_1,1^2 p_2,2 + p_1,2 p_2,1^2 + 2 p_1,2 p_2,2,

matching the primary paper's explicit coefficient. Checks with distinct
weights (2,3), nonprimitive carriers, the first commutator coefficient,
and the two-arrow diagonal series also pass. These tests check the
normal and implementation; the general identity follows from Section3.

## 5. A direct polyhedral interpretation

After dividing the two kinds of edge weights by u or v, the variables
are nonnegative integers with two fixed sum constraints. Every shadow
or compatibility test compares an integer linear form in these variables
with an integer path length. Take the finite arrangement of all those
comparison hyperplanes. On each sign cell, compatibility and the shadow
condition are constant. Retain exactly the cells satisfying them.

This produces a disjoint finite union of bounded relatively open
rational polytopes whose integer points are exactly the admissible
gradings. Equalities are retained as their own cells; strict inequalities
on integer points can equivalently be shifted by one. The construction
keeps the boundary data, not merely the convex hull of the support.

Input decorations and the c ordered copies are finite Cartesian products.
Once the global event grammar is proved, iterating this construction
therefore gives a finite union of explicit integer polyhedral cells for
each coefficient. The local polyhedral cells already have a direct
integer definition; they are not obtained from algebraic root counts or
from a theta coefficient prescribed in advance.
