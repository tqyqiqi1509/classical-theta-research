# A symmetric-group route to intrinsic packet objects

Research proposal initiated 2026-11-13, within the classical higher-rank
greedy/theta project. Do not confuse an abstract representation whose
multiplicities are computed from theta coefficients with the requested
independent combinatorial model.

## Proposed cycle index and its useful implication

For a root index p, let G_p be the product of symmetric groups S_(p_i).
For a permutation in G_p replace every cycle of length k and color i by
a vertex (i,k,a), with exchange entries Bcycle[(i,k),(j,l)]=l B[i,j],
symmetrizer Dcycle[(i,k)]=k D_i and framing gcycle[(i,k)]=g_i.
The fresh independent agent is proving the expected cycle-index identity

  a_g^B(p) = (1/product_i p_i!) sum_(sigma in G_p)
                  sign(sigma) chi(sigma),

where chi(sigma) is the square-free theta coefficient of this weighted
cycle-clone matrix. It is not yet assumed to be a character merely
because all its values are nonnegative integers.

Introduce alphabets X_i only as an auxiliary polarization. The formal
initial functions are P_i(t)=product_a(1+x_(i,a)t)=sum_k e_k(X_i)t^k.
Their logarithmic initial data use (-1)^k p_k(X_i)/(D_i k^2).
If the cycle-index identity holds with these power sums retained, the
auxiliary coefficient polynomial is

  T_p(X) = sum_lambda sign(lambda) chi(lambda) p_lambda(X)/z_lambda.

Thus the Frobenius characteristic of the candidate character is omega(T_p).
The exact coefficient-positivity interface of Burcroff--Lee--Mou (2025)
is being checked independently, including scaling the entire extended
matrix and the exchange degrees. If T_p is a nonnegative polynomial in
the independent elementary generators, omega(T_p) is a nonnegative
combination of products of complete symmetric functions. This proves
that chi is a sum of Young permutation characters.

The sign multiplicity counts only the terms with trivial Young stabilizer:
all parts of all color partitions must have size one. This recovers the
classical coefficient by the specialization e_1(X_i)=1, e_k(X_i)=0 for k>1.

## What must still be constructed

The goal is a G_p-set or a finite diagrammatic/vector-space quotient
defined before computing chi or T_p. Its cycle traces should equal the
weighted square-free coefficients by a proved fixed-point/restriction
identity. A construction that first computes all nonnegative coefficients
of T_p and declares that many copies of Young orbits does not close the
user's combinatorial problem.

Promising interface: one-framing reduction
a_g^B(p)=c^Bfr_(1,p)(-e_0), a unique first framing leaf, and attractor-flow
multicover weights (-1)^(k-1)/k. Their permutation-cycle interpretation
matches the above cycle index. A local colored-cycle cancellation must
preserve the cut/stability conditions; this is the remaining substantive
combinatorial issue.

The sparse exact implementation in computations/packet_polynomial.py
computes T_p in elementary packet variables directly using integer
triangular recurrences. It is used to discover and test such local rules,
not to define an arbitrary set of the desired cardinality.
