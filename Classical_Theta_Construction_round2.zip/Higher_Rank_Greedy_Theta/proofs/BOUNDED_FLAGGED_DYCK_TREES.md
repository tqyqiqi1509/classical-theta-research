# Bounded flagged Dyck trees: a static form of the valued coefficient objects

2026-11-13. This note flattens the already proved finite event grammar
into bounded rooted trees with integer constraints. It also states exactly
which changes of auxiliary flags have direct bijections, and which do not
yet have such a bijection. It makes no new general positivity assertion.

The underlying theorem and the finite-group identification are in
`agents/valued_global_assembly.md`, especially Sections4--7. Literal local
objects are defined in `TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md`. In the
notation here `K=DB` is the charge-word pairing and `eta=-K` is the
covector convention. For theta coefficients use the one-frame extension
from the main note.

Priority scope: Tang II Section8.1 already bounds bounded-charge
histories by their number of input leaves. The role of the bounds here
is to control the particular literal valued Dyck objects, their path
coordinates, and the independent catalog. No priority is claimed for
the basic charge-to-leaf bound itself.

## 1. Static input and the finite catalog

Fix a positive target charge `S`, a rationally generic formal covector
`Theta` with kernel `Q S`, and the weighted integer lattice. Put

\[
 N=|S|=\sum_i S_i,\qquad
 Q=\prod_i(S_i+1),\qquad M=\max_{i,j}|K_{ij}|.
\]

The **catalog** consists of the following finite data, all determined
before any coefficient nonvanishing is tested.

1. Every reachable state flag `(S_0,b_0;...;S_h,b_h)` in the main event
   construction. Its covectors are obtained by the explicit rational
   projections

\[
 P_{A,b}(\Xi)=\Xi-\frac{\Xi(b)}{\eta(A,b)}\eta(A,-)
\]

   and by appending the next formal infinitesimal row. Thus a flag is a
   list of bounded integer charges, not a stored path through walls.
2. At each event, all bounded primitive input rays and the complete
   deterministic unpruned charge word. Identity packets are retained.
   Every syntactically possible output carrier is retained.
3. Each factor occurrence has a birth address. An initial address is its
   input-ray label. A later address is

\[
           (\text{left parent},\text{right parent};a,b),
 \qquad \gcd(a,b)=1,\quad a,b>0.
\]

   Its carrier is `a alpha+b beta`, without primitive reduction. Two
   fixed parent occurrences exchange at most once, so this address is
   unique. No extra mutable crossing counter is needed.
4. Every bounded coefficient slot of every occurrence; its local normal
   multiplicity, deterministic Bezout rectangle, and possible source
   slots for its input decorations.

No algebraic point, theta coefficient, wall support, or nonzero coefficient
list is an argument of this catalog. Its construction is finite integer
arithmetic and exact comparisons of rational coefficient vectors.

### 1.1 Explicit bounds for the catalog

Every state creates at most `Q^2` candidate child states, and the charge
mass drops at least one at a child step. Consequently the unmerged state
tree has at most

\[
             (N+1)Q^{2(N-1)}                              \tag{1.1}
\]

vertices. Also `Q<=2^N`, since `s+1<=2^s` for every nonnegative integer
coordinate `s`.

At a local event there are at most `I<=Q` initial occurrences. Unfold a
birth address as an ordered full binary tree. If its carrier has mass at
most `N`, this tree has at most `N` leaves: at every birth the parent
masses sum to at most the new carrier mass. Each leaf has `I` possible
labels and each internal vertex has at most `N^2` possible pairs `(a,b)`.
Hence the number of possible occurrence addresses is at most

\[
 R_N(I)=\sum_{l=1}^{N}\operatorname{Cat}_{l-1}
                    I^l N^{2(l-1)}
       \leq N(4 I N^2)^N.                               \tag{1.2}
\]

There are at most `R_N(I)(R_N(I)-1)/2` exchanges. These deliberately loose
bounds depend on the charge box, not on coefficients or on `M`. They
give an explicit finite horizon for a flat list of adjacency and rewrite
constraints if one wants to materialize the entire unpruned word.

## 2. The flattened objects

Use an ordered rooted tree whose vertices have positive charges in the
box and whose parent charge is the sum of its children's charges. Its
vertex kinds are as follows.

### 2.1 Original-color leaves

A leaf has a label `(i,k)` and charge `k e_i`, representing one original
elementary symbol `e_k(X_i)`. It also has the fixed catalog source flag
which identifies the original incoming axis coefficient. In the ordinary
cluster specialization only `k=1` leaves are permitted.

### 2.2 Parallel assembly vertices

Such a vertex records a coefficient of a product of distinct tagged
packets on one ambient ray. It has at least two positive children, all
parallel to its own charge. Its flag lists the nonzero Cauchy allocations
in the prescribed catalog order, including each selected packet's
occurrence address. Zero allocations have their unique empty objects and
need not be stored.

### 2.3 Dyck vertices

A Dyck vertex has a catalog birth with parents `alpha,beta`, a coprime
pair `(a,b)`, and carrier `gamma=a alpha+b beta`. Its own charge is
`k gamma`. Let `m=K(alpha,beta)>0`, `d=w(alpha)`, `e=w(beta)`, and

\[
 u=m/d,\quad v=m/e,\quad \ell=\gcd(av,bu),\quad
 (A,B)=(av/\ell,bu/\ell),\quad
 c=\frac{w(\gamma)}{\gcd(ad,be)}.
\]

Choose an ordered `c`-tuple of degrees `j_1+...+j_c=k`. For every
nonzero degree `j_t`, store its literal tight grading from the local
definition. Its vertical weights sum to `j_t a v` and are divisible
by `v`; horizontal weights sum to `j_t b u` and are divisible by `u`.
The compatible-grading and tight-shadow inequalities are part of the
constraint system.

Every positive vertical weight `v h` has exactly one child of charge
`h alpha`, taken from the left parent occurrence's coefficient slot.
Every positive horizontal weight `u h` has one child of charge `h beta`
from the right parent. Order these child slots by normal-copy position,
then by path edge position. Empty normal copies have their unique empty
object; only the positions of nonempty copies need be stored.

The source occurrence of a child is essential. Charges alone do not
identify a coefficient slot: distinct incoming packets and distinct
births can have the same charge. Retaining this finite catalog label is
precisely what prevents unjustified subtree compression.

### 2.4 Contracted one-factor choices

A Cauchy allocation with only one positive factor does not make a unary
vertex. Save its state/event/occurrence flag at the root of its selected
subtree. This flag reconstructs the unique one-factor allocation. No
decoration is forgotten. A local factor coefficient is then a Dyck
vertex, or eventually an original-color leaf, so suppressing such unary
wrappers does not conceal an unbounded chain of positive-degree nodes.

## 3. Explicit bijection with the event objects

**Proposition 3.1.** The tagged trees in Section2 are in a weight-preserving
bijection with the literal objects of the event grammar.

**Proof.** Expand a coefficient object by its actual set recipe. A
nonzero coefficient of a product chooses a unique degree allocation;
retain its positive factors in their tagged order. Use an assembly vertex
if there are at least two, and save the flag if there is exactly one.
An original axis coefficient is the indicated leaf.

For a born local coefficient, its object is already an ordered tuple of
actual gradings with decorated positive edges. Make one Dyck vertex for
the whole tuple and recursively expand its input decorations. The total
input charge is

\[
 \sum_t j_t a\,\alpha+\sum_t j_t b\,\beta=k\gamma,
\]

so charge is conserved. Every nonempty grading has positive weight of
both edge orientations and therefore at least two positive input slots.
The recursively followed source coefficient has strictly smaller charge
mass. This produces a finite tree of the indicated kind.

Conversely, proceed upward from the leaves. At a Dyck vertex the stored
grading and child-slot order recover exactly its decorated path tuple;
insert the unique empty objects in omitted zero slots. At an assembly
vertex its occurrence labels recover every omitted zero factor and the
original Cauchy allocation. A saved one-factor flag restores its unary
wrapper. Each operation is uniquely inverse to the expansion. Original
leaf symbols are unchanged. QED.

The final one-frame target is primitive and has no positive proper
parallel charge. Its root is therefore a single Dyck tree, or the frame
leaf in degree zero. Parallel assembly vertices may still occur below
the root, in unframed subobjects.

## 4. Uniform size and path bounds

**Theorem 4.1.** Let an object have target charge `S` and `N=|S|`.

1. In the universal elementary version it has at most `N` leaves; in
   the ordinary cluster specialization it has exactly `N` original-color
   leaves. It has at most `N-1` internal vertices and height at most `N`.
2. Across the entire object, the number of nonempty local Dyck paths is
   at most `N-1`.
3. If `M>0`, each such path has at most `4MN^2` edges. Every local edge
   weight and every normal-copy slot number is at most `MN^2`.
4. Thus at most `4MN^2(N-1)` path-edge entries need be recorded. The
   object need not store the unselected word occurrences or a full sweep.

**Proof.** Leaves have positive integer charge mass and their masses sum
to `N`. All internal vertices have at least two positive children. If
there are `L` leaves and `J` internal vertices, the number of edges is
`L+J-1`, while it is also the sum of internal arities and is at least
`2J`. Therefore `J<=L-1<=N-1`.

Each nonempty normal copy at a Dyck vertex has at least one positive
edge of each orientation, hence consumes at least two of that vertex's
child slots. If `P` is the total number of these paths, then

\[
 2P\leq \sum_{\text{Dyck vertices}}\!\operatorname{arity}(v)
      \leq L+J-1\leq2N-2.
\]

For one path put `lambda_1=j a v`, `lambda_2=j b u`. As all charges
are nonnegative,

\[
 m=|K(\alpha,\beta)|\leq M|\alpha||\beta|,
 \qquad j(a|\alpha|+b|\beta|)\leq N.
\]

It follows that both `lambda_1,lambda_2<=MN^2`. The chosen rectangle
satisfies `A h-B r=1`, where
`lambda_1=j ell A`, `lambda_2=j ell B`. Write `r=lambda_1+t` for the
smallest nonnegative solution of the congruence, so `0<=t<A`. Then

\[
 r\leq\lambda_1+A-1,\qquad
 h=\lambda_2+\frac{1+B t}{A}\leq\lambda_2+B.
\]

Since `A<=lambda_1` and `B<=lambda_2`, the path length is at most
`2lambda_1+2lambda_2<=4MN^2`. Every edge weight is bounded by its
orientation's total. Finally `c<=w(gamma)<=m<=MN^2`, by the ambient
normal divisibilities already proved. This also bounds the slot numbers.
If `M=0` there are no Dyck births. QED.

The global flag depth is at most `N-1`; a local birth address unfolds
to at most `N` initial leaves. These labels can also be stored without
the complete word history. Catalog membership may still require its
finite precomputation; no polynomial-time membership claim is made.

The literal implementation `computations/flatten_dyck_objects.py` stores
the semantic tree, its selected source/union flags, and the compressed
normal-copy layout. Its inverse reconstructs the original decorated
recipe object, including empty normal slots; it never inserts unselected
word occurrences. An exhaustive check of 19,834 universal objects from
eight inputs verifies exact inversion, distinctness, every bound above,
and the complete leaf-profile polynomial. The two inputs with genuine
nonprimitive births contain respectively 960 and 6,024 actual such
objects; 24 and 84 objects also have a genuine parallel assembly vertex.
This computation verifies the implementation of the bijection, rather
than replacing its charge-conservation proof.

### 4.1 Dependence on large arrow multiplicities

For one local path, after dividing weights by `v,u`, the two weak
compositions have total `j a` and `j b`, whose sum is at most `N`.
Their lengths are at most `2MN^2`. Hence the number of candidate
gradings is bounded by `(2MN^2+N)^N`, before testing compatibility.
Choosing the positions of nonempty normal copies introduces another
fixed-degree polynomial bound in `M`.

Thus at fixed charge mass the literal path enumeration is polynomial in
the numerical arrow bound `M`; the independent catalog bound (1.2) has
no `M` dependence. This is not a polynomial bound in the bit length of
`M`, and not a useful sharp complexity estimate in `N`.

## 5. Static integer constraints and polyhedral pieces

One can enumerate ordered rooted tree shapes with at most `2N-1`
vertices and impose the following finite constraints directly:

- charge conservation and the initial-color leaf profiles;
- vertex type and source-slot membership in the precomputed catalog;
- positive event signs from the rational projection flags;
- Cauchy degree allocations on parallel assembly vertices;
- the coprime birth pairs and normal-copy positions at Dyck vertices;
- nonnegative edge weights, their fixed sums and divisibilities;
- the finite compatible-grading and tight-shadow interval comparisons.

This is a finite, static definition of exactly the same set. For each
fixed tree and discrete catalog labels, divide out the known weight
divisibilities and cut the bounded coordinate simplices by all comparison
hyperplanes. The admissible sign cells give disjoint rational polyhedral
pieces. The leaf profile records the monomial in the original elementary
variables. It is not recovered from a known coefficient's value.

The catalog still contains angular order and the deterministic adjacent
exchange rule. That is the remaining auxiliary word-order choice. It has
no need for precomputed geometric wall supports, and an individual object
stores only its bounded source flags and decorations.

## 6. Direct bijections for some changes of flags

The following equivalences are combinatorial, before using any equality
of cardinalities or theta functions.

**Product-order change.** Reordering the factors of one parallel-ray
product permutes the tagged Cauchy slots. Retain each nonzero allocation
with its factor identifier and permute the tuple positions accordingly.
All subtrees and leaf profiles are unchanged. The inverse permutation is
the inverse bijection.

**Sign-chamber change.** Suppose two choices of numerical infinitesimals
give the same signs to every bounded flag comparison in the catalog.
Match flags by their bounded charge lists. They have the same event
planes, word occurrences, and local integer data. Keeping every tree and
grading gives the required bijection. This statement does not assert that
arbitrary generic color orders have the same sign catalog.

**Disjoint exchange diamond.** Suppose two currently available adjacent
inversions use disjoint pairs of occurrence identifiers. Performing the
first replacement inserts its born factors entirely within its pair's
position; it does not change the other pair or its local coefficient
sets. Performing both replacements in either order produces the same
tagged word, because birth addresses use the two parent identifiers and
the coprime pair, not a global step counter. The bijection swaps the
independent Cartesian decoration factors and leaves all later data
unchanged. It preserves every original elementary monomial.

These generate explicit local changes of flags on the corresponding
commutation class of exchange schedules.

### 6.1 The genuinely unresolved overlap

An exchange of `(A,B)` and an exchange of `(B,C)` share an occurrence.
Their replacements create new factors which can subsequently interact
with the third one. This is not a disjoint diamond. Changing initial
parallel order before interactions can have the same issue. The two
deterministic schedules have equal multigraded generating polynomials by
finite ordered-factor uniqueness, but that fact alone does not supply a
local bijection of their Dyck decorations.

No universal overlap/associator bijection is claimed here. Canonically
ordering both finite sets and matching ranks would be an enumerable
bijection, but would not explain the combinatorics and is not proposed
as a solution. The static object model remains valid with its fixed
catalog, just as a tableau model may retain a fixed reading order.

The new mathematical interface is therefore precise: construct a
profile-preserving local transformation for a shared-occurrence exchange
diamond, including normal-copy slots and unequal phase weights. A proof
would make the finite tree model independent of more auxiliary flags at
the level of objects, rather than only at the level of its polynomial.

## 7. Literature check for that remaining interface

On 2026-11-13 the primary full HTML of Burcroff--Lee--Mou,
arXiv:2611.10154v1, was inspected. Its explicit preorder/auxiliary-vertex
construction connects a restricted central, equal-weight family of tight
gradings to vertex-pointed leafy trees. It does not state the unequal-
weight shared-occurrence exchange bijection needed in Section6.1. The
extended abstract explicitly defers proofs to a later full version.
Therefore its construction is an idea source, not a premise of this
theorem. The actual scope and deferred-proof status are recorded rather
than inferred from its title.

Primary source: <https://arxiv.org/html/2611.10154v1>.

Rimanyi, arXiv:2608.05057, was located as a possible colored-partition
exchange interface. Its primary abstract/HTML/PDF endpoints could not be
read in this session; only metadata was retrieved. No statement from it
is used. The general overlap remains open in this branch.
