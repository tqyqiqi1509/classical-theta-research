# A finite graph, fan and tableau formula for classical skew theta coefficients

Date: 2026-11-13. This note integrates the substantive proof obtained during
the present run. The statement is coefficientwise and concerns classical
cluster algebras. It neither asserts finite support for every tropical label
nor identifies theta with the dual canonical or generic basis.

The older proof through local quiver moduli and equivariant PBW remains in
`agents/species_completion_bridge.md` and its independent review. The local
identities below have a second, purely combinatorial proof, obtained by a
many-slope extension of the graph-cone argument in Qiyue Tang's November 2026
paper. Its ordering correction is explicit in
`agents/tang_ii_combinatorial_bridge.md`, Section 4. The global induction is
unchanged. No Li--Pan conclusion is used.

**Subsequent strengthening.** The full primitive-center character bridge is
now proved in `agents/primitive_center_ih_bridge.md` and independently in
`proofs/GALE_DEGREE_AND_CYCLE_TORI.md`. Consequently every ungraded local
fan module below is an actual Young-permutation module. The alternative
global formula in `GLOBAL_YOUNG_ORBIT_FORMULA.md` replaces local Specht
kernels and tableaux by explicit finite Gale point orbits and selections
of multisets or strict subsets. The graph/fan construction below remains
the version using only rational polyhedral and linear operations; the new
point-orbit model has an algebraic local indexing set. Neither is claimed
to reproduce the unavailable original picture literally.

## 1. Statement

Let B be any integral skew-symmetric n by n matrix. Retain principal
coefficients and write the formal theta expansion, in the chosen seed, as

\[
 \vartheta_g=x^g\sum_{p\in\mathbb N^n}a_g^B(p)y^p x^{Bp},
 \qquad g\in\mathbb Z^n.
\]

For every prescribed p the construction in Sections 2--4 produces a finite
set O(B,g,p), using only finite set partitions, integer skew pairings,
rational polyhedral fans, rational linear algebra, and Young tableaux.

**Theorem.** With the explicit conventions below,

\[
                    a_g^B(p)=|O(B,g,p)|.                 \tag{1.1}
\]

The set is constructed before any theta coefficient is known. In particular,
no set is declared to have the size of a coefficient. The construction does
not take a scattering diagram, a wall list, broken lines, or a mutation
sequence as input. Scattering uniqueness is used only to prove that the
independently defined answer is the desired coefficient.

The local rational linear algebra is an essential part of this result. This
is not yet a claimed universal Dyck-path formula or a bijection with the
unavailable pictured algorithm in the user's request.

## 2. The finite partition grammar

Take one frame label of color 0 and p_i distinct labels of color i. A label
of color i has charge e_i. On the color lattice set

\[
 \eta(e_0,e_i)=g_i,\qquad \eta(e_i,e_j)=-B_{ij}.
\]

For a label set S let beta(S) be its color-content vector. Choose independent
positive original-color infinitesimals epsilon_i in a fixed lexicographic
order, put mu_i=1+epsilon_i, and set

\[
 \Theta(e_i)=\mu_i,\qquad
 \Theta(e_0)=-\sum_i p_i\mu_i.
\]

Every expression is stored as a rational vector of its constant and epsilon
coefficients. The first nonzero coordinate determines its sign.

A state consists of S and a covector Theta with Theta(beta(S))=0. A singleton
has its one leaf tree. At a larger set, enumerate unordered proper
partitions S=U_1 disjoint union ... disjoint union U_m, m>=2. Write
beta_j=beta(U_j) and beta=sum beta_j. Retain a partition exactly when:

1. Its child charges span a two-dimensional rational plane on which eta is
   nondegenerate.
2. For a child with eta(beta,beta_j) nonzero, the vector
   tau=-Theta(beta_j)/eta(beta,beta_j) is strictly positive.
3. Theta'=Theta+tau eta(beta,-) annihilates every child charge.
4. Every child admits a tree at its restricted covector Theta'.

Take all independent choices in item 4. Entirely parallel partitions and
identically zero times are excluded. Proper parallel children in a mixed
partition are allowed. The ratio in item 2 is independent of the chosen
nonparallel child, since both covectors on the plane annihilate beta.

This is a finite recursion: each child has fewer labels. Its implementation
deduplicates planes by primitive wedge products and lists only feasible
subsets; it does not first enumerate binary trees. Same-color label
permutations preserve all tests. Passing to their orbits gives unlabelled
rooted colored trees. The chosen color order is auxiliary; different choices
need not give the same tree set.

## 3. Local fan matrices, independently defined

At an internal vertex with child charges beta_1,...,beta_m form the acyclic
multiquiver with max(eta(beta_i,beta_j),0) arrows i to j. Use the incidence
convention partial(e_i_to_j)=e_i-e_j and form

\[
       P=\{f\in\mathbb R_{\ge0}^{E}:\partial f=\partial\mathbf1\}.
                                                               \tag{3.1}
\]

All child charges lie in a pointed two-plane. Ordering their slopes makes
every arrow point forward, so P is bounded. The all-one flow is strictly
positive. The graph is connected, and dim P=E-m+1.

Use the normal fan of P and its normalized minimal-extension polynomial
module. This can be constructed entirely from cone incidence and rational
linear maps: at each cone take compatible sections on its boundary, divide
by positive-degree linear forms, choose the fixed row-reduction lifts, and
extend freely over the cone polynomial ring. Global compatible sections,
modulo global linear forms, give a finite graded space L. The strict local
degree bound gives unique normalized lifts of graph automorphisms. Thus the
same computation gives actual rational matrices on L. It need not identify
L with the cohomology of a variety.

In the implementation, upper degrees can equivalently be constructed using
equivariant duality; the complete action still consists of actual matrices.
Give the whole local factor the separate super parity E mod2. A permutation
of children acts on this one factor by its ordinary fan matrix. It does not
receive an additional local sign character.

For a labelled tree T, let U_T be the tensor product of its local factors,
with this super interchange rule. Let W be their direct sum over all
labelled trees. The product G_p=product_i S_{p_i} acts by relabelling trees
and by the induced local and super tensor maps. This defines W without any
theta data.

## 4. Objects from tree orbits and tableaux

For a colored tree C put ell_C=#leaves and

\[
 q_C=\sum_{i<j}\eta(e_i,e_j)\beta(C)_i\beta(C)_j\pmod2.
\]

This is its total arrow parity: each pair of leaves first separates at
exactly one internal vertex. For a leaf define O_C to have one element.

At the root of T, let C_1,...,C_s be its distinct child isomorphism types,
with multiplicities m_1,...,m_s. The root fan space L_T carries the group
J=product_j S_{m_j}. For partitions lambda_j of m_j form the actual space

\[
 M_T(\boldsymbol\lambda)
 =\operatorname{Hom}_J(\bigotimes_j S^{\lambda_j},L_T).       \tag{4.1}
\]

Build the Specht matrices by standard polytabloids in tabloid permutation
modules. For adjacent generators solve A_s M=M S_s and take the ordered
rational nullspace basis. These are the local basis labels. No character
average is required. At a projective-star vertex these labels can themselves
be chosen as explicit semistandard tableaux by Schur--Weyl duality.

Set e_j=ell_(C_j)+q_(C_j) modulo2. Choose one basis label of (4.1), together
with a semistandard tableau of shape lambda_j if e_j=0 and its transpose if
e_j=1, whose ordered alphabet is the already constructed set O_(C_j).
The resulting decorated node is an element of O_T. Take the disjoint union
over all tuples of partitions and all tree orbits. In particular,

\[
 |O_T|=\sum_{\boldsymbol\lambda}\dim M_T(\boldsymbol\lambda)
       \prod_j\#\operatorname{SSYT}
           (\lambda_j^{[e_j]},|O_{C_j}|).                  \tag{4.2}
\]

Every summand is nonnegative. The tableaux are lattice points in their
standard Gelfand--Tsetlin interlacing polytopes, so the final step is also a
polyhedral count. The local multiplicity spaces remain part of the input to
that polyhedral step; equation (4.2) is not a claim that one Newton hull
already determines every coefficient.

Frobenius reciprocity on each orbit of trees, followed by the wreath-product
description of its stabilizer, proves

\[
 |O(B,g,p)|=\dim\operatorname{Hom}_{G_p}(\operatorname{sgn},W).
                                                               \tag{4.3}
\]

Indeed, after imposing the child sign conditions, swapping identical child
blocks gives leaf sign (-1)^ell_C and super sign (-1)^q_C. Schur--Weyl
duality then gives precisely the transpose exponent in (4.2). This proves
the positive object formula for W independently of its theta identification.

## 5. Purely combinatorial local factorization

The following argument replaces the local moduli/PBW theorem in the older
proof. Let a finite list of charges beta_v span a pointed nondegenerate
two-plane, S=sum beta_v, and Theta_v=-eta(S,beta_v).

A support H is semistable exactly when it carries a nonnegative Theta-flow.
The union of the supports of all such flows is its unique positive-flow
core K. The connected components C of K satisfy Theta(C)=0, hence beta_C is
a positive multiple of S. Missing internal arrows can be added by a small
path correction; quotient arrows cannot contain a directed cycle, by the
same correction. Thus H decomposes uniquely as its core plus an acyclic
cross support.

Between balanced components C,D the cross-arrow difference is
eta(beta_C,beta_D)=0. Their contraction is therefore a symmetric directed
graph, with arbitrary independent permutations of opposite arrows. The
normal cone at K is its graph cone times a smooth orthant. Tang's audited
graph-cone theorem identifies its reduced fan character with the finite
graph cut algebra. Its proof uses cographic shelling, a regular Koszul
quotient, the cellular formula and equivariant fan duality; no representation
moduli are required.

Summing invariant supports gives the balanced-partition identity. Put

\[
 A(J,\sigma;t)=\frac{t^{|J|-E_J}}
 {\prod_{c\in\operatorname{cyc}(\sigma)}(1-t^{2|c|})},\qquad
 H(t)=\frac{t}{1-t^2}.
\]

For a positive charge-linear mass kappa, the decreasing-slope support
filtration yields

\[
 A(J,\sigma;t)=\sum_{J_1>\cdots>J_r}
 t^{\sum_{a<b}\eta(\beta_{J_a},\beta_{J_b})}
 \prod_a S(J_a,\sigma|_{J_a};t).                           \tag{5.1}
\]

Here each block is sigma-invariant and the order means strictly decreasing
Theta/kappa slope. To obtain this normalization from the raw support sum F,
one must use S(J,sigma;t)=sgn(sigma)F(J,sigma;t^{-1}). Before this conversion
the decreasing-order cross exponent is negative. This is the correction
found by the independent review.

At slope zero one has

\[
 S(J,\sigma;t)=\sum_{\rho}\prod_{C\in\rho/\langle\sigma\rangle}
 (-1)^{(\ell_C-1)E_C}H(t^{\ell_C})
 \Omega_C(\sigma^{\ell_C};t^{\ell_C}),                    \tag{5.2}
\]

where rho ranges over invariant balanced set partitions, and
Omega_C(h;t)=t^{-(E_C-|C|+1)}Tr(h|L_C;t^2). A singleton has Omega=1;
a larger entirely parallel block has Omega=0. The latter block is
disconnected, so its point-flow-polytope cohomology must not be substituted.

The block-cycle sign is determined directly: two identical charge multisets
have E_C arrows in either cross direction. A cycle of ell_C such blocks
therefore has orientation sign (-1)^((ell_C-1)E_C). Parameter inversion,
the vertex signs, and fan duality give (5.2) term by term. No commuting of
the sign involution with signed Adams operations is assumed.

Every centered HN block remains in this same family, since

\[
 \Theta_v-\frac{\Theta(C)}{\kappa(\beta_C)}\kappa(\beta_v)
 =-\frac{\kappa(S)}{\kappa(\beta_C)}\eta(\beta_C,\beta_v).
\]

Thus (5.1)--(5.2) hold for arbitrary many-slope local events. They are full
character identities over every finite input-type set, hence identities of
symmetric sequences, and permit substitution of arbitrary homogeneous
incoming representations. The separate parity is E_C, exactly as in
Section 3.

## 6. Global induction and the theta identification

Use the completed colored super-species algebra with product
z^beta*z^gamma=(epsilon t)^eta(beta,gamma)z^(beta+gamma), and initial axis
factors Exp_lambda(H(t)p_1(X_i)z^(e_i)). Always truncate the original positive
charge first; all operations are finite at a prescribed coefficient.

On a ray take H^{-1}Log_lambda of the entire factor, retaining all parallel
charges before primitive extraction. Equations (5.1)--(5.2) say that crossing
a local joint creates exactly the root decoration in Section 3 on partitions
of proper incoming blocks. Strict pullback of eta under the free-type charge
map preserves incoming directions. This is not a general folding assertion.

For a target charge S follow the line q(tau)=Theta+tau eta(S,-), tau>=0.
At a joint q evaluate a child beta at q+delta eta(beta,-), where delta is
later than all original-color parameters. A nontrivial split inside the
current joint plane has time -delta and is excluded. Outside that plane its
leading time has the same sign as before. Proper parallel child charges obey
the same argument. Purely parallel partitions create no primitive.

In any finite charge truncation there are finitely many joints. At the
incoming end a nonaxis primitive is zero. Telescoping the joint differences,
and inducting on the number of original labels, gives exactly the direct
partition grammar of Section 2, with no binary-refinement multiplicity.
For a radical target there are no nonzero joint brackets and the same zero
statement holds. This proves the global species identity.

Only after all Fock operations, forget epsilon and take the classical
limit. The initial logarithm has

\[
 (t-t^{-1})\log F_i\longrightarrow
       -\sum_{k\ge1}\frac{p_k(X_i)}{k^2}z^{ke_i}.
\]

Identifying z^beta with minus the classical root derivation gives the
sign-involuted cluster wall input. Incoming uniqueness identifies the
resulting system. The one-frame identity and independent cycle-index
polarization give

\[
 \operatorname{Tr}(\sigma|W)
       =a_{g^\lambda}^{B^\lambda}(\mathbf1),\qquad
 B^\lambda_{ab}=k_b B_{i_a i_b},\quad g^\lambda_a=g_{i_a}.
\]

The frame has multiplicity one, so neither a nontrivial multicover nor a
product of two framed roots contributes. Taking the product-of-colors sign
multiplicity recovers a_g^B(p). Equation (4.3) proves (1.1).

## 7. Scope, provenance and reproducibility

The graph-cone and two-slope character mechanism is prior work of Qiyue
Tang, *Another proof of quantum Laurent positivity, II*, Hexagon2611.00279v1,
Sections 3--6. The whole relevant proof chain was read and independently
challenged before this use. The direct many-slope extension and its precise
normalization are recorded in the bridge and independent review. The
general incoming principle and tropical-flow induction are older ideas;
neither is claimed new. The addition here is their explicit assembly into
the direct graph/fan representation and finite positive object recursion
for a prescribed arbitrary classical skew theta coefficient.

Reproducible construction files are `intrinsic_partitions.py`,
`fan_linear_module.py`, `global_matrix_module.py`, `local_specht_basis.py`,
and `constructive_tableau_objects.py`, in the computation directories. Their
constructors do not import a theta oracle. Independent coefficient routines
are called only in separate verification blocks after the objects exist.

For example, the recorded cyclic input with local global-module dimension88
has six actual coefficient objects; an odd-parity input has eight; the S4
input with65 labelled trees and global-module dimension15670 has60. These
are normalization and implementation checks, not substitutes for the proof.

For a nonconstant symmetrizer, the integer prefix recursion remains valid,
but this positive module theorem is not extended by scalar division. A
verified full-tree orbit already acquires a negative Specht multiplicity
under such division. The separate weighted chip-firing, gain-cut and KLR
work attacks the required cross-tree mechanism; it is not silently included
in Theorem1.1.
