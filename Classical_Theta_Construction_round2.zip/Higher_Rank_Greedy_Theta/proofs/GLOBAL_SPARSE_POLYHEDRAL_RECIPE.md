# A global sparse polyhedral recipe for classical theta coefficients

2026-11-13. This note specifies the set-valued assembly of the sparse
position polytopes. Its implementation is
`computations/global_sparse_polytope_recipe.py`. It uses the finite
charge-box event catalog proved in `agents/valued_global_assembly.md`
and the local polyhedral bijection proved in
`SPARSE_POSITION_POLYTOPES.md`.

The input is the classical skew-symmetrizable data `(B,D)`, a theta
label `g`, and a nonnegative coefficient degree `p`. The construction
produces a finite expression involving tagged disjoint unions and
Cartesian products of explicit rational lattice-point polytopes. It
does not take a scattering diagram, a list of walls, an enumerated set
of gradings, or a coefficient value as input.

## 1. What a recipe means

A recipe has nodes of the following types.

1. The empty set and a singleton.
2. A tagged disjoint union of finitely many child recipes.
3. An ordered Cartesian product of finitely many child recipes.
4. A structural tag recording a state, event, birth, or decoration slot.
5. A rational polytope given by integer matrices

   `A z <= b,  E z = d`,

   interpreted as its set of integer points.

Repeated occurrences of the same child recipe in a product use separate
coordinate blocks. Repeated children in a disjoint union retain their
branch tags. Thus hash-consing the expression does not identify objects.
Every branch choice in this finite expression gives one product of
polytopes, whose single matrix description is obtained by block-diagonal
concatenation. Empty pieces may remain in the recipe.

The original axis coefficient of order `k` and color `i` is one leaf
tag `(i,k)`, of charge `k e_i`, carrying the formal symbol `e_k(X_i)`.
For ordinary cluster coefficients retain only leaves with `k=1`. No
cardinality evaluation is used to create any of these nodes.

## 2. The local sparse recipe

Consider a positive local word exchange with parent carriers
`alpha,beta`, pairing `m=K(alpha,beta)>0`, and normal weights
`d=w(alpha), e=w(beta)`. The output carrier

`gamma=a alpha+b beta`, `gcd(a,b)=1`,

is retained without primitive reduction. Put

\[
 u=m/d,\quad v=m/e,\quad
 \ell=\gcd(av,bu),\quad (A,B)=(av/\ell,bu/\ell),\quad
 c=\frac{w(\gamma)}{\gcd(ad,be)}.
\]

The valued normalization theorem proves that `c` is a positive integer.
For coefficient order `j`, choose the specified Bezout rectangle
`P(r,s)` with `A s-B r=1`, `r>=j a v`, and `s>=j b u`.

Enumerate the ordered positive compositions

\[
 h_1+\cdots+h_{k_H}=j b,\qquad
 v_1+\cdots+v_{k_V}=j a.
\]

The actual edge weights are `u h_i` and `v v_i`. Enumerate all weak
orders of their positive-support and endpoint labels, respecting the
two strict positive-support orders. Discard the patterns that fail the
order-only compatibility and shadow-cover tests. For every remaining
pattern construct the sparse polytope using the digital-path,
endpoint-balance, and pre-jump inequalities. This enumeration depends
only on the bounded compositions and label orders; it does not scan the
`r+s` path edges.

Decorate each positive horizontal slot with the right input coefficient
recipe `G_(h_i)` and each positive vertical slot with the left input
recipe `F_(v_i)`. The weak order specifies their path order. The local
base recipe is the tagged disjoint union

\[
 \mathcal B_j=
 \bigsqcup_{h,v,\sigma}
 \left(P_{h,v,\sigma}\cap\mathbb Z^{4(k_H+k_V)}\right)
 \times\prod_{\text{positive edge slots}}\mathcal C_{\text{slot}}.
 \tag{2.1}
\]

The local sparse bijection identifies (2.1), object by object, with the
actual decorated tight-gradings in the valued local theorem. In
particular, the lattice points are not placed to realize an already
known positive coefficient.

## 3. Normal powers without enumerating empty copies

To obtain coefficient `n` in the positive integer power `c`, choose an
ordered positive composition

`j_1+...+j_P=n`, `1<=P<=min(c,n)`.

Let

\[
 Q_{c,P}=\{(t_1,\ldots,t_P):1\le t_1<\cdots<t_P\le c\}.
\]

It has integer affine inequalities after replacing each strict
inequality by a gap of one. Define the local output coefficient by

\[
 \mathcal H_n=
 \bigsqcup_{j_1+\cdots+j_P=n}
 (Q_{c,P}\cap\mathbb Z^P)
 \times\mathcal B_{j_1}\times\cdots\times\mathcal B_{j_P}.
 \tag{3.1}
\]

A point of `Q_(c,P)` gives the occupied positions of the ordered
`c`-tuple; every omitted position has its unique empty object. This is
an explicit bijection with the original normal-power tuple. Its inverse
forgets the empty entries and reads their occupied positions. The
construction therefore keeps the full normal-power information while
using at most `n` slot coordinates, even when `c` is very large.

When cardinalities are eventually evaluated, the slot factor contributes
`binom(c,P)`. This binomial coefficient counts the displayed integer
simplex. It is not an unspecified multiplicity placed in the definition.

## 4. Global composition and coefficient identification

Use (3.1) as the local positive exchange operation in the independent
finite event catalog. Keep inherited parallel occurrences, unreduced
birth carriers, and their addresses. Product coefficients use ordinary
tagged Cauchy allocations. The incoming-state recursion has strictly
smaller charge at each child, and the local word histories terminate by
strict increase of birth mass. Hence the resulting recipe is finite.

For the one-frame data

\[
 \widehat B=\begin{pmatrix}0&-g^tD\\g&B\end{pmatrix},\qquad
 \widehat D=\operatorname{diag}(1,D),\qquad S=(1,p),
\]

choose the positive generic covector of the global theorem. That theorem
identifies its final coefficient recipe with the coefficient of the
classical theta expansion. The two local bijections, (2.1) and (3.1),
are preserved by disjoint unions and Cartesian products, so replacing
each local path recipe by its sparse polyhedral recipe preserves this
identification.

**Theorem 4.1.** For every classical skew-symmetrizable `(B,D)`, integral
label `g`, and nonnegative degree `p`, this construction gives an
explicit finite family of tagged rational polytopes such that

\[
 a_g^B(p)=\sum_{\sigma}\#(P_\sigma\cap\mathbb Z^{d_\sigma}).
 \tag{4.1}
\]

Each polytope is defined from integer charge data, event flags, positive
weight compositions, support/endpoint weak orders, and occupied normal
positions. The interpretation is coefficientwise and does not assert
finite support of every formal theta expansion without additional
hypotheses.

In the universal original-elementary version, each discrete type has a
fixed leaf profile, and the stronger identity is

\[
 P_{g,p}(X)=\sum_\sigma
 \#(P_\sigma\cap\mathbb Z^{d_\sigma})
 \prod_{\substack{\ell\text{ a leaf of }\sigma\\ i(\ell)>0}}
                       e_{k(\ell)}(X_{i(\ell)}).
 \tag{4.2}
\]

There is always one frame leaf. Its common factor `e_1(X_0)` is
suppressed in (4.2); equivalently set that factor equal to one. The
ordinary coefficient (4.1) retains precisely the types whose leaves
all have size one. This also makes clear which information the formal
profile verification tests beyond scalar specialization.

## 5. Uniform size of the polyhedral description

Let `N=1+sum p_i`. The flattened tree has at most `N` leaves, `N-1`
internal vertices, `N-1` nonempty local paths, and `2N-2` positive edge
slots across those paths. Equations (2.1) use at most four variables per
positive slot. Equations (3.1) add one variable per occupied normal
position. Consequently

\[
                  d_\sigma\le9(N-1)=9\sum_i p_i.       \tag{5.1}
\]

After restricting to the support of `p`, the rank is at most `N`.
The finite event/word catalog has size bounded by a function of `N`.
Tree shapes, charge allocations, ordered normalized weight compositions,
positive-degree copy allocations, and the weak orders of at most `2k`
local labels have numbers bounded by functions of `N` alone. Occupied
copy positions are variables rather than arrow-dependent discrete
choices. Thus the number of pieces in (4.1), including empty ones,
is bounded by a function of `N` independent of arrow magnitudes.

With `M=max|Dhat_i Bhat_ij|`, every active pairing, edge weight, and
rectangle constant is bounded by a function of `N` times `M`. The
normalization uses gcds and a Bezout congruence. Exact event covectors
have depth at most `N`. Therefore at fixed `N` the binary lengths of
the matrices describing all pieces are polynomial in the binary length
of the input. These are the precise hypotheses for applying Barvinok's
fixed-dimensional counting theorem. They do not assert a uniform
polynomial in the varying parameter `N`, nor an implemented Barvinok
counter in this package.

## 6. Natural Young modules of the individual pieces

This construction has a direct representation meaning compatible with
`agents/valued_young_functor_reddening.md`. For a fixed piece type
`sigma`, let `H_sigma` be the Young subgroup associated to its ordered
original-color leaf sizes, inside `G_S=product_i S_(S_i)`. Give the
finite lattice-point set its trivial label-permutation action. Define

\[
 M_\sigma=
 \mathbb Q[P_\sigma\cap\mathbb Z^{d_\sigma}]
 \otimes\operatorname{Ind}_{H_\sigma}^{G_S}\mathbf1.
 \tag{6.1}
\]

Equivalently, an element consists of a lattice point and an ordered
partition of each external label set into its distinguished leaf blocks.
Relabeling acts only on these blocks. Thus (6.1) is an actual permutation
module, natural under label bijections, with characteristic

\[
 \operatorname{ch}M_\sigma=
 \#(P_\sigma\cap\mathbb Z^{d_\sigma})
                     \prod_\ell h_{k(\ell)}(X_{i(\ell)}).
\]

The direct sum over pieces is exactly the global Young-species module
after the sparse bijections. Its sign twist has characteristic (4.2).
Here again the common degree-one frame characteristic is suppressed.
The ordinary coefficient is its total sign multiplicity, one line for
each lattice point of every singleton-leaf type. This is a natural
interpretation of individual polyhedral cells; it does not assert that
they are invariant algebraic strata of a Gale variety or provide a
canonical change-of-flag equivalence.

## 7. Implemented data and verification scope

The implementation builds the complete finite recipe before calling its
cardinality routine. It includes empty polyhedral pieces and does not
use tight-grading enumeration to select the nonempty patterns. Exported
JSON stores the recipe DAG and every reachable `A,b,E,d`, with sparse
matrix triplets. Cartesian products mean separate coordinate blocks.

Two complete global checks pass, including the former valued phase
obstruction. Their full elementary profiles agree with the independent
signed incoming recursion. For the phase case

`B=[[0,2],[-1,0]], D=(1,2), g=(-6,2), p=(2,2)`,

the recipe gives

\[
 e_1(X_1)^2e_1(X_2)^2+6e_1(X_1)^2e_2(X_2)
 +2e_2(X_1)e_1(X_2)^2+4e_2(X_1)e_2(X_2).
\]

Its 13 universal objects specialize to one ordinary object. The recipe
has 11,084 reachable expression nodes and 3,551 explicit polytopes,
including empty pieces; its maximum piece ambient dimension is31,
within the bound36.

A separate single local word check takes `D=I`, `K=det`, parents
`(1,0)` and `(1,2)`, and bound `(2,2)`. Its unreduced birth carrier is
`(2,2)` and its normal power is `c=2`. The sparse recipe has four integer
points, and two independent literal monomial-operator matrices agree
entry by entry, covering 41 nonzero entries. This checks the occupied
normal slots and nonprimitive ambient normalization without reducing
the birth carrier.

One larger complete pipeline with target `(1,2,2,2)` was stopped after
several minutes without a final result. The older runner printed no
stage timings, so its unfinished stage is not established and that
pipeline is not recorded as passed. Its formal and literal-Dyck
coefficient checks had already passed in the separate implementations;
no performance or correctness conclusion is inferred from the stopped
polyhedral run. Subsequent runners report the construction boundary.

The supplied numerical counter enumerates the integer points of each
compiled polytope using its linear endpoint elimination. The coefficient
formula and the exported systems are independent of that evaluation
method; the fixed-dimensional counting theorem gives a different,
binary-complexity algorithmic interface.
