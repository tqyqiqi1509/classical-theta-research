# Sparse support-position polytopes for arbitrary classical theta coefficients

Root branch, 2026-11-13. The local endpoint/minimality mechanism is being
independently checked by `valued_global_assembly`.

The earlier full-comparison alcoved cells are correct but can over-refine
the set into one-point cells. This note gives a different polyhedral
model: vary the positions of the finitely many positive edges, keeping
their positive weights and relative endpoint order as discrete data.
Its dimension is bounded by coefficient degree, independently of arrow
multiplicities. It does NOT inherit the total-unimodularity assertion
of the weight-coordinate model.

## 1. A digital path edge has two linear coordinate inequalities

Fix P(r,s), the maximal northeast path below its diagonal, with r,s>0.
Use the starting lattice point (x,y) of an edge. A horizontal edge is
characterized exactly by

    0<=x<=r-1, 0<=y<=s-1,
    r y <= s x <= r(y+1)-1.                             (1.1)

A vertical edge is characterized exactly by

    1<=x<=r, 0<=y<=s-1,
    s(x-1)+1 <= r(y+1) <= s x.                          (1.2)

Indeed its horizontal start has y=floor(s x/r); the vertical edge with
start height y occurs at x=ceil(r(y+1)/s). These statements include the
extra consecutive vertical edges when s>r.

Let t=x+y. Each edge on this fixed path has a distinct integer start
time t in {0,...,r+s-1}; the path increases t by one at every step.
Thus edge order, coincidence and cyclic order are encoded by linear
comparisons between the t variables. The periodic copy of an edge
one full turn later has coordinates (x+r,y+s) and time t+r+s.

## 2. Discrete data and continuous coordinates

Fix k_H positive horizontal edges with prescribed positive weights
q_1,...,q_(k_H), and k_V positive vertical edges with positive weights
p_1,...,p_(k_V). In the valued operation these are multiples of u and
v respectively. The weights themselves are fixed discrete data here;
their normalized indices specify the child decorations in the tree.
The horizontal labels are in their strict left-to-right path order,
and the vertical labels are in their strict bottom-to-top path order.
Every weak-order pattern below must preserve these two orders. Even
when weights coincide, relabelling two positive edges is not a second
object. This convention is essential for the uniqueness in Section6.
Assume their totals satisfy

    sum q_i <= s,                   sum p_j <= r.       (2.1)

This is exactly the total-weight inequality of a tight grading. At the
chosen positive-determinant rectangle the first inequality is strict,
but the argument does not need strictness.

For each positive edge introduce its start coordinates (x,y). Also
introduce the start coordinates of its minimal shadow endpoint, which
has the opposite orientation. There are 4(k_H+k_V) scalar coordinates.

Choose a weak linear order of all positive-edge and endpoint labels by
their times t, allowing endpoint coincidences. Distinct positive-edge
labels must have distinct times. Equal-time groups can contain only
labels of one orientation. Impose this order by equalities and strict
integer inequalities t_i<=t_j-1. Only finitely many such weak orders
exist, as a function of k_H+k_V; their enumeration does not enumerate
the r+s edges of the path.

The weak order determines the wrap bit for each shadow: a horizontal
source uses its endpoint in the forward interval (t_h,t_h+r+s); a
vertical source uses its endpoint in the backward interval
(t_v-r-s,t_v). It also determines which other positive edges are in
each such interval. Hence the list of weights accumulated along that
interval is fixed discrete data.

## 3. Horizontal shadow: balance and jump inequalities

Let h have start (x_h,y_h), and let its chosen vertical endpoint e have
start (x_e,y_e). Let w in {0,1} be the forward wrap bit. Its unwrapped
time is t_e+w(r+s), strictly after t_h and less than t_h+r+s.

Lift each positive horizontal edge h_i into that same forward turn;
its lift has coordinates (x_i+w_i r,y_i+w_i s), w_i in {0,1}. The
weak order determines every w_i and the subset I lying from h through
the chosen endpoint. Write Q_I=sum_(i in I) q_i. The endpoint balance
is the single affine equation

    y_e+1+w s-y_h = Q_I.                                (3.1)

The +1 matters: the endpoint's vertical edge is included in the
shadow. For every OTHER positive horizontal edge h_i encountered
before e, impose the pre-jump inequality

    y_i+w_i s-y_h <= Q_(before i)-1,                    (3.2)

where Q_(before i) is the sum of positive horizontal weights from h
up to, but excluding, h_i.

**Minimality lemma.** Equations(3.1)--(3.2) are equivalent to e being
the first balancing vertical edge.

Proof. Starting just after h, the balance
vertical_count minus accumulated_horizontal_weight is negative. At a
positive horizontal edge it decreases by that edge's positive weight;
at a vertical edge it increases by exactly one; at a zero horizontal
edge it stays constant. Between two positive horizontal jumps it is
nondecreasing. Inequality(3.2) says it is still strictly negative just
before the next positive jump, so no earlier segment can have reached
zero. In the last segment, (3.1) forces the balance to reach zero at e,
and its unit increases make that the first such vertical edge. The
converse follows by looking just before every earlier positive jump.
QED.

This checks only the positive edges, whose number is bounded by the
root degree. It does not list inequalities for every zero edge of a
potentially very long path.

## 4. Vertical shadow: the backward version

Let v have start (x_v,y_v), and let its chosen horizontal endpoint e
have start (x_e,y_e). With backward wrap bit w in {0,1}, the endpoint
has unwrapped start (x_e-wr,y_e-ws). Lift all positive vertical edges
into the backward interval and let J be the included subset. Put
P_J=sum_(j in J) p_j. The balance equation is

    x_v-x_e+w r = P_J.                                  (4.1)

For every other positive vertical edge v_j encountered before the
endpoint in the backward traversal, with lifted start x_j+w_j r and
w_j in {0,-1}, impose

    x_v-(x_j+w_j r) <= P_(already passed j)-1.           (4.2)

The accumulated weight on the right includes the source v and the
positive vertical edges passed before v_j, but excludes v_j itself.
There is no +1 in (4.1): the number of horizontal edges from the
endpoint's starting x-coordinate to x_v is exactly their difference.

The proof of minimality is identical in reverse traversal. At an
opposite horizontal edge the horizontal count increases by one; at a
positive vertical jump the balance decreases by the fixed weight.

Existence of a balancing endpoint is not an extra assumption. In a
full turn the opposite-edge count is at least the total own-color
weight by (2.1). The balance starts negative, its increases are unit
steps, and its other jumps are nonpositive. It must therefore reach
zero in that turn. This includes the equality case in (2.1).

## 5. Compatibility is a finite condition on the weak order

For a positive horizontal h and positive vertical v, a compatible
forward witness exists before v precisely when v is outside sh(h).
The backward witness exists after h precisely when h is outside sh(v).
Indeed any allowed balancing witness is preceded by the minimal
balancing endpoint in its direction. Thus the pair is compatible iff

    NOT( v in sh(h) AND h in sh(v) ).                    (5.1)

Membership here includes the shadow endpoint. It is decided entirely
by the weak time order and its wrap bits. The same finite membership
table decides the shadowed condition

    {positive H} subset union sh(positive V)
        OR {positive V} subset union sh(positive H).    (5.2)

Discard weak-order patterns failing (5.1) or (5.2). If the fixed total
weights and path rectangle satisfy the tight determinant condition,
the surviving patterns describe exactly the tight gradings with the
specified ordered positive weights.

## 6. Exact polyhedral bijection, with no witness multiplicities

For every retained discrete pattern, impose (1.1)--(1.2), the weak
time order, the shadow balance equations, and the pre-jump inequalities.
All are linear equalities and inequalities with integer coefficients;
strict conditions have already been shifted by one. The coordinates
are bounded by the path rectangle. Call this rational polytope P_sigma.

An integer point of P_sigma gives distinct positive edges with the
prescribed weights; put weight zero on every other edge. Sections3--4
prove that its auxiliary endpoints are the actual minimal shadows.
Section5 proves compatibility and shadowedness. Conversely, an actual
tight grading has unique support coordinates, unique minimal endpoints
and a unique weak time order. These give one integer point of exactly
one P_sigma.

Consequently there is a direct bijection

    actual tight gradings with fixed weight data
       <--> disjoint union_sigma (P_sigma intersect Z^(4k)),
       k=k_H+k_V.                                      (6.1)

The endpoint coordinates are uniquely determined by a grading. They
do not count arbitrary choices of a compatibility witness. This
uniqueness is the essential reason the model has no overcount.

The polytopes in (6.1) need not be integral or alcoved. Their use here
is bounded dimension and explicit sparse path constraints. The
different weight-coordinate alcoved model remains correct, but its
integrality should not be transferred to these position polytopes.

## 7. A uniform dimension bound for a theta coefficient

Set N=1+sum p_i after adding the frame. The normalized event-Dyck tree
has N original unit leaves and at most N-1 true internal vertices.
Every nonempty Dyck grading consumes at least two positive children.
Parallel products with one child and empty products are suppressed.
Thus the total number of positive-edge slots across all local paths
is at most 2N-2, and the number of nonempty local paths is at most N-1.
These bounds are proved with the exact flattening inverse in
`BOUNDED_FLAGGED_DYCK_TREES.md`.

Fix one such discrete tree, all child charges and local weight data.
Use four coordinates per positive-edge slot as in Section2. The total
number of position/endpoint coordinates is at most 8N-8. A normal
power c is recorded by the increasing list of its occupied copy
positions in [c], with at most one further variable per nonempty local
path. There are at most N-1 such variables. Therefore every global
piece has an ambient coordinate dimension at most

                         9(N-1).                       (7.1)

All tree labels, event-state types, child-charge allocations and weak
orders are finite discrete data determined from the original input.
They do not depend on knowing the coefficient or its nonvanishing.
The local bijections and the flattening bijection give

    a_g^B(p) = sum_sigma #(P_sigma intersect Z^(d_sigma)),
                  d_sigma <= 9 sum p_i.                (7.2)

The pieces are tagged, so their geometric images may overlap without
identifying distinct configurations. They are defined by the path
equations above, rather than by placing a prescribed number of points.

For the replication objects, add the selected-copy positions. Their
number is at most sum p_i; hence dimension at most 10 sum p_i is a
uniform bound for that version.

## 8. Size and counting consequences

Delete coordinates outside supp(p), using support locality. The
effective framed rank is at most N. The independent event and word
catalog has a size bounded by a function of N alone: the charge box
has at most 2^N elements, state height strictly decreases, and a birth
tag is a binary charge genealogy with at most N leaves. The explicit
bounds are in `BOUNDED_FLAGGED_DYCK_TREES.md`.

Let M=max|Dhat_i Bhat_ij|. For an active local pair, m<=M N^2; both
input normal weights and the output normal weight divide the relevant
pairing. The local path length is at most 4M N^2. All path and weight
constants therefore have bit length bounded in terms of N and the
bit length of the input. Every region above has a number of variables
and inequalities bounded in terms of N alone. The exact rational
event arithmetic also has bounded depth N.

For FIXED coefficient degree N, this yields a finite reduction to
bounded-dimensional rational lattice-point counting with polynomial
binary description size. Barvinok's fixed-dimensional counting theorem
therefore gives a polynomial-time-in-input-bit-length counting route
for each fixed N. The degree of that polynomial may depend on N;
no stronger parameterized complexity statement is claimed here.

This does not assert an implementation of Barvinok's algorithm in the
current package. The package's actual counter enumerates tight
gradings and the signed integer-prefix algorithm supplies a separate
fast arithmetic check. The new consequence is an explicit positive
polyhedral reduction whose dimension does not grow with arrow counts.

## 9. Nontriviality and priority

For the first coefficient with ordinary two-input pairing m, the local
path is P(m,m+1), with one positive edge of each orientation, both of
weight m. There are m tight configurations. The sparse endpoint order
groups them into two boundary patterns and, when m>=3, one pattern
with m-2 points parametrized by a consecutive integer position. Thus
this model can contain genuine positive-dimensional regions, unlike
the fully refined weight-comparison cells. This family only checks
that the construction has geometric content; Sections1--7 are general.

The path definitions and coefficient identity are due to BLM2025.
The new argument here is the sparse endpoint encoding, its first-hit
linear inequalities, and its all-rank degree-bound composition. The
targeted literature search did not establish priority for this exact
encoding. No result from Li Fang or Pan Jie is used.

The fixed-dimensional counting input is A. Barvinok, *A Polynomial
Time Algorithm for Counting Integral Points in Polyhedra When the
Dimension Is Fixed*, Mathematics of Operations Research19(1994),
769--779, DOI10.1287/moor.19.4.769. The primary publisher statement and
the original paper's Theorem1.2 were checked; this standard result is
credited rather than claimed as a new complexity theorem.
