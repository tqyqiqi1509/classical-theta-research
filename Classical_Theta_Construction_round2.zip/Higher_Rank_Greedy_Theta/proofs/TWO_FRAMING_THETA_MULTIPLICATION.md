# Theta multiplication from two framings and endpoint Dyck pairs

2026-11-13. Classical principal-coefficient cluster scattering data only.
This note extends the finite positive coefficient objects to individual
theta structure constants. It uses the proved charge-box event grammar
and the credited GHKK endpoint extraction theorem. It does not claim a
new proof of abstract theta positivity or a coherent associator between
the resulting object sets.

## 1. The full principal output label

Let `DB` be skew-symmetric, `g_1,g_2 in Z^n`, and `p>=0`. Put

\[
 h=g_1+g_2+Bp,\qquad H=Dh.
\]

Write `c_(g_1,g_2)(p)` for the coefficient of the full principal theta
label `(h,p)`, equivalently of `y^p theta_h`, in the product of the
labels `(g_1,0)` and `(g_2,0)`. Thus

\[
 \vartheta_{g_1}\vartheta_{g_2}
   =\sum_{p\ge0}c_{g_1,g_2}(p)\,y^p\vartheta_{g_1+g_2+Bp}.
 \tag{1.1}
\]

This is interpreted coefficientwise in the principal completion. The
frozen degree `p` is retained even when `B` has a kernel. If the inputs
belong to the GHKK middle algebra, its usual finiteness theorem makes
the corresponding product finite; no such global finiteness is needed
for one fixed coefficient.

More explicitly, for fixed total initial exponent `g_0`, work in
`x^(g_0) Z[[z_1,...,z_n]]`, where `z_i=y_i x^(B e_i)`. The family
`y^p theta_(g_0+Bp)` has leading terms `x^(g_0) z^p` and is
unitriangular in the nonnegative root degree. Every finite charge-box
quotient therefore has a unique expansion in this family, and the
quotients are compatible. This is the formal scope for arbitrary integral
`g`; it does not assert that every such theta is Laurent finite. The
principal exponent map `q -> (Bq,q)` is injective, including when `B`
itself has a kernel.

The input theta basis and its abstract multiplication are established
objects. The new construction below concerns their explicit finite
Dyck/Young/polyhedral coefficient objects.

Choose independent positive formal infinitesimals
`epsilon_1 >> ... >> epsilon_n > 0` and set

\[
                       U_i=H_i+\epsilon_i.             \tag{1.2}
\]

In the covector coordinates used by the event grammar, this is a generic
endpoint immediately adjacent to the mutable exponent `h`. The factor
`D` converts the ordinary monomial coordinates to evaluations on charge
normals. The coefficient directions of the principal endpoint may be
chosen near `p`; the walls are invariant under their translations.

## 2. One-frame packets at an arbitrary endpoint

For a label `g` and degree `a`, let

\[
 B_g^\mathrm f=\begin{pmatrix}0&-g^tD\\g&B\end{pmatrix},
 \quad D^\mathrm f=\operatorname{diag}(1,D),\quad
 S_a=(1,a),\quad \Xi_a=(-U\cdot a,U).
\]

The formal infinitesimals imply `ker_Q Xi_a=Q S_a`. Let
`O(g,a;U)` be the literal finite Dyck object set from the global event
grammar at this state, and put `A_g(a;U)=|O(g,a;U)|`.

**Lemma 2.1.** `A_g(a;U)` is the coefficient of
`x^(g+Ba)y^a` in the theta expansion at endpoint `U`.

**Proof.** Work in a finite charge truncation and kill framing degree
at least two. The extended Lie algebra is a semidirect product of the
unframed algebra with an abelian framed ideal `M`. For framing charge
`(1,a)`, use a basis `E_a` whose derivation satisfies

`E_a(x^(-e_f))=+x^(-e_f)X^(1,a)`.

This is the negative of the raw positive-normal derivation. The sign
matters because the transport convention is `C_0=T_positive^(-1)`.
Sending `E_a` to `x^(g+Ba)y^a` intertwines the adjoint unframed action
with its monomial action: both exponents for a charge `b` are
`b^tD(g+Ba)/w(b)`.

Let `C_hat` be the incoming-normalized finite transport and `C` its
unframed quotient. Support locality identifies `C` with the original
unframed transport `C^B`, independently of the framing label `g`.
Consequently its abstract sign factor `C_(U,-)` depends only on `(B,U)`;
its action on the framed module still depends on `g`. At a positive
unframed covector and a sufficiently
negative frame coordinate, factor uniquely as

\[
                      \widehat C=\exp(M_+)C.           \tag{2.1}
\]

The unframed factor fixes `x^(-e_f)`. Since `M` is abelian and has
framing degree one, the framed transport column reads off the
coefficients of `M_+` without higher powers. The already proved
one-framing coefficient theorem identifies them with the initial-seed
theta expansion.

At a generic unframed endpoint `U`, write its unique sign factorization
as `C=C_(U,-)C_(U,+)`. Then

\[
 \widehat C=C_{U,-}\exp(M_U)C_{U,+},\qquad
 M_U=\operatorname{Ad}(C_{U,-}^{-1})M_+.                \tag{2.2}
\]

Split the abelian `M_U` according to the signs of the framed charges
at `Xi_a`. Its negative and positive parts can be absorbed into the
two outer sign subgroups. Uniqueness of three-factor decomposition
identifies its zero part with the packet at `(1,a)`. The sign convention
for `E_a` makes the resulting coefficient exactly the positive packet
coefficient, not its negative.

Under the monomial intertwiner, (2.2) is ordinary unframed transport
from the positive chamber to `U`. Theta functions satisfy the same
transport rule and agree in the initial chamber. Their transported
series therefore agree in every finite truncation. This proves the
lemma coefficientwise. QED.

This argument uses a finite abelian ideal and unique sign
factorization. It does not assume a canonical bijection between event
objects belonging to different endpoint flags.

## 3. Endpoint extraction of a multiplication coefficient

The primary GHKK source is *Canonical bases for cluster algebras*,
Definition-Lemma 6.2 and Proposition 6.4(3), particularly the proof on
printed pages63--64:

<https://paulhacking.github.io/canonicalbases.pdf>

In a finite principal truncation, choose a generic endpoint sufficiently
close to the full output label. The coefficient of that output monomial
in a theta product is its theta structure constant. The key observation
is that a broken line with that final exponent cannot bend: its last
ray avoids walls not containing the exponent, and walls containing it
pair trivially with it. This is the credited endpoint-duality input;
our objects below do not use broken lines in their definition.

There is also a direct finite-event proof of the needed delta property.
For a single framed target `(1,a)`, put `h'=g+Ba` and choose
`U'=Dh'+epsilon`. Its state satisfies

\[
 (-U'\cdot a,U')=
       \eta_{(1,a)}+(-\epsilon\cdot a,\epsilon),        \tag{3.0}
\]

because `a^tDBa=0`. Every potential event with nonzero denominator has
time `-1` plus an infinitesimal correction and is therefore negative;
zero denominators are excluded. If `a>0`, the target is a non-axis
charge and its initial incoming set is empty. If `a=0`, it is the
single frame leaf. Thus

`O(g,a;D(g+Ba)+epsilon)` is empty for `a>0` and a singleton for `a=0`.

Now a contribution of `y^s theta_r` to the full output monomial
`x^h y^p` requires `a=p-s>=0` and `h=r+Ba`. At the endpoint (1.2),
the preceding event calculation makes its coefficient zero unless
`a=0`, in which case `(r,s)=(h,p)` and the coefficient is one.
Consequently this endpoint monomial coefficient is the theta-basis
dual functional. Applying it to the unique unitriangular expansion in
the principal completion proves the required endpoint extraction
without any additional broken-line enumeration. This is an internal
finite proof of the standard duality just attributed to GHKK.

Apply this statement at (1.2). By Lemma2.1, ordinary monomial
multiplication gives

\[
 c_{g_1,g_2}(p)
     =\sum_{a+b=p} A_{g_1}(a;U)A_{g_2}(b;U).           \tag{3.1}
\]

**Theorem 3.1.** The explicit finite set

\[
 \mathcal C_{g_1,g_2}(p)
       =\bigsqcup_{a+b=p}
                 O(g_1,a;U)\times O(g_2,b;U)           \tag{3.2}
\]

has cardinality `c_(g_1,g_2)(p)`. Each component is defined only by
the charge-box flags and literal local Dyck gradings. The decomposition
is over the finitely many coordinatewise splits of `p`.

Equation (3.2) is already a complete coefficientwise positive
combinatorial multiplication rule. The next section realizes it as
the coefficient of one mixed framing packet and explains the unique
fusion parameter.

**Corollary 3.2 (all arities).** For finitely many labels
`g_1,...,g_k`, put `h=sum_i g_i+Bp` and `U=Dh+epsilon`. The finite set

\[
 \bigsqcup_{p_1+\cdots+p_k=p}
                         \prod_{i=1}^k O(g_i,p_i;U)     \tag{3.3}
\]

counts the coefficient of `y^p theta_h` in their product. The proof is
the same finite delta-functional extraction applied to ordinary
monomial multiplication. Permuting the input factors and their degree
allocations gives literal bijections of these sets. Their sparse
polyhedral pieces have dimension at most `9 sum_i|p_i|=9|p|`, independent
of the arity. This is a direct unbracketed formula; it does not assert
a bijection from every iterated binary construction to (3.3).

## 4. Two framing vertices and the exact affine packet

Let `f_0,f_1` be two framing charges of weight one. Extend the skew form
by

\[
 K_{01}=L>0,\quad K_{0i}=-D_i(g_1)_i,\quad
 K_{1i}=-D_i(g_2)_i,\quad K_{ij}=(DB)_{ij}.
\]

The remaining entries follow by skew-symmetry. This defines an integral
exchange matrix with symmetrizer `diag(1,1,D)`. Truncate each framing
degree at one, and set `S=(1,1,p)`. Choose

\[
 \Theta_0=-T-p\cdot U,\quad\Theta_1=T,\quad
 \Theta_{\rm orig}=U.                                  \tag{4.1}
\]

One may take

\[
 L\ge L_0:=1+|g_1^tDp|+\sum_i p_i|H_i|,\qquad
 T=2+\sum_i p_i|H_i|,
\]

with sufficiently small positive infinitesimals. The epsilon coefficients
and then the nonzero `T` show `ker_Q Theta=Q S`.

Let `F_S(Theta;L)` be the positive whole-ray packet coefficient at this
state. Along its incoming event line `Theta+t eta(S,-)`, with `eta=-K`,
the unframed covector is

\[
                         (1+t)H+\epsilon.              \tag{4.2}
\]

For a nonzero proper unframed charge `b`, its sign never changes for
`t>=0`: if `H dot b` is nonzero its sign is fixed by that leading term,
and otherwise it is fixed by the infinitesimal part. Hence there is no
positive-time event from an unframed charge. A proper mixed charge
`(1,1,q)` has the negative of the sign of its unframed complement, so
it also produces no event.

The remaining events are indexed exactly by splits `a+b=p`, with

\[
 \alpha=(1,0,a),\quad\beta=(0,1,b),\quad
 m_a=K(\alpha,\beta)
      =L-g_1^tDp+a^tDh.                                \tag{4.3}
\]

Here `eta(S,alpha)=m_a>0` and `Theta(alpha)=-T-U dot b<0`, so the
event time is

\[
                    \tau_a=(T+U\cdot b)/m_a>0.         \tag{4.4}
\]

Distinct splits give distinct event planes. In
`span_Q(S,alpha)`, the two framing coordinates force any bounded
nonzero positive charge to be `alpha`, `beta`, or `S`: solving the
two frame coordinates first leaves no nonzero unframed vector.
Consequently the local incoming word has only the two parents; it has
no proper inherited parallel input. Their weights and the output
weight are all one. The only possible birth contributing to `S` has
`(a,b,j)=(1,1,1)` in the local two-input notation.

At this event the original covector is

`U_event=(1+tau_a)H+epsilon`.

It has exactly the same signs as `U` on every unframed charge in the
finite truncation. The further fresh incoming perturbations also
preserve that finite chamber. By Lemma2.1 the two parent packet
coefficients are `A_(g_1)(a;U)` and `A_(g_2)(b;U)`. The literal
first-degree Dyck rule has `m_a` choices, equivalently the strip
coordinate `0<=s<m_a`.

There is no initial incoming coefficient at the non-axis charge `S`.
There are also no proper parallel charges because its frame coordinates
are one. The event formula therefore gives the exact identity

\[
 \boxed{\displaystyle
 F_S(\Theta;L)
   =\sum_{a+b=p}(L-g_1^tDp+a^tDh)
                   A_{g_1}(a;U)A_{g_2}(b;U).}           \tag{4.5}
\]

It holds for every integer `L>=L_0`, with the indicated finite generic
choices. In particular the packet is affine in `L`, and

\[
                    [L]F_S(\Theta;L)=c_{g_1,g_2}(p).    \tag{4.6}
\]

## 5. Literal radial-germ identification and the unique fusion strip

For one fixed admissible `L`, every two-frame root object consists of
exactly one fusion grading, one child with frame0 and one child with
frame1. The fusion grading is the explicit first-degree strip from
Section4. Erasing its strip coordinate gives a genuine finite set of
paired child objects at their actual event flags. Equation (4.5) shows
that this set has cardinality (4.6).

Chamber constancy alone would give only equality of cardinalities of
these child sets. For the present special endpoint germs there is a
stronger literal comparison, independently proved in
`agents/RADIAL_ENDPOINT_LITERAL_CATALOG_REVIEW.md`.

Along a fixed recursive charge/plane address, each queried covector is
`A U + sum_j delta_j v_j`, with rational `A,v_j` determined only by
that address. The actual child endpoint is

`U' = lambda H + epsilon + delta_0 v`,

where `lambda=1+tau_a>1` has positive real leading term, and `delta_0`
is smaller than every `epsilon_i`. For any scalar rational test put
`ell A=L_test`. If `L_test H` is nonzero, the positive leading factor
of `lambda` preserves its sign. If it is zero but `L_test` is nonzero,
the first independent epsilon coefficient determines the same sign.
If the entire epsilon functional vanishes, then `L_test=0`, so the
extra term `delta_0 L_test v` also vanishes exactly. All later fresh
incoming columns match in order.

Induction through the rational-linear projections therefore identifies
the entire unpruned catalogs at `U` and `U'`. It retains each charge
address, Dyck grading, occupied normal slot, and child decoration, and
only renames the covector query at that address. This is an actual
bijection. The assertion is confined to these radial germs; it is not
a general same-chamber or arbitrary schedule coherence theorem.

Combining this identification with the explicit fusion strip gives

\[
 \mathcal F_S(L)\cong
 \bigsqcup_{a+b=p}
 [0,L-g_1^tDp+a^tDh)_{\mathbb Z}
             \times O(g_1,a;U)\times O(g_2,b;U).        \tag{5.1}
\]

Hence increasing `L` by one has an explicit injection retaining the
strip residue and all child data. Its complement is one copy of each
component of (3.2), represented by the newly available final residue.
The construction gives both a literal strip-erasure model and a
positive difference family; no rank matching is used.

The basic coefficient object removes one explicit interval coordinate.
It does not define its objects by a difference of known cardinalities,
divide virtual characters, or choose a matching using structure constants.

## 6. Polyhedra and actual Young modules

The pair model (3.2) directly inherits the sparse polyhedral recipe.
For a split `a+b=p`, its two factors have dimensions at most `9|a|`
and `9|b|`. Thus each multiplication coefficient has a positive
rational lattice-point description

\[
 c_{g_1,g_2}(p)=\sum_\sigma
          \#(P_\sigma\cap\mathbb Z^{d_\sigma}),\qquad
                         d_\sigma\le9|p|.              \tag{6.1}
\]

At fixed `|p|`, the number of pieces is bounded independently of arrow
magnitudes and their binary descriptions have polynomial size, as in
the coefficient theorem. The number of splits is at most `2^|p|`.

Suppress the two trivial degree-one frame groups. Let
`G_p=product_i S_(p_i)`. The universal original-elementary versions of
the endpoint object sets give actual Young modules `M_(g,a)^U` by
partitioning external labels among their distinguished leaf slots.
Define

\[
 \mathcal M_{g_1,g_2,p}=
 \bigoplus_{a+b=p}
 \operatorname{Ind}_{G_a\times G_b}^{G_p}
       \left(M_{g_1,a}^U\boxtimes M_{g_2,b}^U\right).
 \tag{6.2}
\]

The ordinary structure coefficient is the sign multiplicity

\[
 c_{g_1,g_2}(p)=
 \dim\operatorname{Hom}_{G_p}
          (\operatorname{sgn}_{G_p},\mathcal M_{g_1,g_2,p}).
 \tag{6.3}
\]

This follows by induction/restriction of the sign and the endpoint
Young-species construction: precisely the singleton-leaf types
contribute. The induction is a literal partition of each color's label
set between the two factors; there is no automorphism quotient of the
rooted objects. The matrix coefficients and the polyhedral point sets
therefore admit actual representation objects, not only virtual
characters.

## 7. Scope and implementation target

The identification uses ordinary theta transport and the primary GHKK
endpoint theorem. The object definition (3.2) uses only the already
explicit charge-box/Dyck grammar. Its two-frame interpretation and
polyhedral composition apply to arbitrary classical skew-symmetrizable
data coefficientwise.

Associativity of the numerical multiplication constants follows from
their identified theta-algebra multiplication. A coherent combinatorial
associator between all iterated pair objects, or a canonical transport
between all auxiliary flags, has not been constructed. These are
separate further problems.

Commutativity does have a direct object bijection: swap the two factors
and the split `(a,b)`. Their common endpoint depends only on
`g_1+g_2+Bp`. For the unit label `g=0`, the framing is isolated, so
`O(0,a;U)` is empty unless `a=0`, when it is a singleton. Applying the
empty/unit endpoint calculation preceding (3.1) to the remaining factor
then gives the unit property directly.

### 7.1 Finite whole products from support certificates

Suppose finite input support boxes `d_1,d_2` are supplied, so
`supp F_(g_i) subset [0,d_i]`. Positivity and the leading coefficient
one imply that every nonzero coefficient in (1.1) has

`p <= d_1+d_2`.

Thus enumerating this finite box and using (3.2) gives the complete
product. The same argument shows that any output theta with nonzero
coefficient has support contained in `[0,d_1+d_2-p]`: each of its
positive terms must occur in the input product. Hence finiteness of
those output series is a consequence of the supplied input support
certificates, not an additional assumption. If a reddening certificate
is supplied, the tropical support
algorithm in `agents/valued_young_functor_reddening.md`, Section9.1,
also gives the top corner `n(h)` of each output theta polynomial, with
coefficient one. Every surviving term then satisfies the sharper filter

`p+n(g_1+g_2+Bp) <= d_1+d_2`.

Indeed its translated top monomial must occur in the positive product
of the two input Laurent polynomials. With the sharp tropical input
boxes, take `d_i=n(g_i)`. These are effective finite bounds from the
certificate, not assumptions about unknown interior coefficients.

A different certificate is given in
`proofs/COERCIVE_GAUGE_FINITE_SUPPORT.md`: a rational coercive gauge
whose affine-time convexity along broken lines has been verified gives
an explicit total-degree support bound from `(B,D,g)` and its facet data.
Two bounds `N_1,N_2` restrict the complete multiplication to
`|p|<=N_1+N_2`. That conditional estimate does not assume a full
Fock--Goncharov theorem or certify the convexity hypothesis by itself.

### 7.2 Actual recipes and independent checks

`computations/theta_multiplication_objects.py` builds the actual pair
recipes before evaluating any cardinality. One cyclic valued input
with `D=(1,2,1)`, labels `(-1,-1,1)` and `(-1,2,2)`, and box `(2,1,1)`
gives twelve structure coefficients. All agree with an independent
signed triangular theta-basis multiplication and an independently
factored endpoint matrix. The recipe has 493 nodes, and all nine
objects across its nonzero coefficients are materialized and distinct.
The output includes the complete recipe and the actual objects.
For degree `(1,1,0)` of the same input, the separate sparse-polyhedral
backend exports 201 reachable recipe nodes and 43 explicit polytopes;
its three integer points agree with the three literal multiplication
objects. The maximum piece ambient dimension is18, exactly the bound
`9|p|`. This backend enumerates weak orders and inequalities in its
definition, with no grading or coefficient oracle.

The separate root implementation `endpoint_matrix_multiplication.py`
does not call the event grammar. Its six rank-one through rank-four
inputs test 240 multiplication coefficients and 3,743 signed matrix
entries. The actual Wolfram symbolic sign/block checks are retained in
`computations/two_frame_symbolic_wolfram.json`. These calculations test
the identified interfaces; the general proofs are Sections2--6.

`computations/fast_framed_spine.py` is a second global factory, using the
literal singleton/slot bijection proved in
`agents/FRAMED_SPINE_FUSION_TRANSPORT.md`, Section1. Every framed-spine
coefficient is constructed as `[t^a]F(t)^Q`, with the occupied slots
stored as the integer simplex `0<=s_1<...<s_k<Q`; positive degree
compositions and all unframed child decorations are retained. Two-frame
fusion is one residue in `[0,m)`. Unframed vertices retain the original
Dyck factory. The new factory agrees with the original on the three
previous scalar inputs and all twelve coefficients of the same valued
multiplication input. A direct local full-polynomial check with `Q=10`
and `Q=10^50`, degree5, constructs exactly83 recipe nodes in either
case, with Dyck-path enumeration disabled by an exception guard. Thus
the compression removes the long-path scan along framed spines; it
does not claim to accelerate every remaining unframed operation.

## 8. Replication gives positive binomial structure polynomials

Fix `(B,D,g_1,g_2,p)`. For positive integers `r_i`, let
`R=diag(r_i)`, `B_r=RB`, and `g_(j,r)=R g_j`, with rational symmetrizer
`D_r=DR^(-1)` cleared by one common positive factor when needed. There
are independently defined finite sets `N_(p,k)`, for `0<=k<=p`, such that

\[
 c^{RB}_{Rg_1,Rg_2}(p)
   =\sum_{0\le k\le p}|N_{p,k}|\prod_i\binom{r_i}{k_i}.
 \tag{8.1}
\]

Here is their definition. Make `k_i` ordered copies of color `i`, with
block-constant matrix `B^[k]_((i,a),(j,b))=B_ij`, weights `D_i`, and
input labels `(g_j)^[k]_(i,a)=(g_j)_i`. Let `pi` sum clone degrees in
each color. Set

\[
 N_{p,k}=\bigsqcup_{\substack{w_{i,a}>0\\\pi w=p}}
     \mathcal C^{B^{[k]}}_{g_1^{[k]},g_2^{[k]}}(w),
 \tag{8.2}
\]

where each summand is the actual endpoint pair construction (3.2), not
a set specified by a known coefficient. The union is tagged by `w`.
A block with `k_i=0<p_i` gives the empty set; for `p=k=0` the set is a
singleton. In a pair split `u+v=w`, a clone may occur in either or both
factors. The active requirement is `w_(i,a)>0`, so it records the union
of the two factors' used clone labels and imposes no false disjointness.

**Proof of (8.1).** The strong block-constant coefficient-folding identity
proved in `agents/polyhedral_parameter_formula.md`, Sections3.3--3.4,
has checked both the initial axis logarithms and finite extraction
matrices. Apply the multiplicative monomial map

`x^mtilde y^u -> x^(sum_copies mtilde) y^(pi u)`.

Its root-degree fibers are finite, so it extends continuously to the
principal completion. The proved folding identity sends the lifted
theta with a block-constant label `g^[r]` to `theta_(Rg)` for matrix
`RB`. Every lifted output label in the product is also block constant:
if `pi u=p`, then its entries in block `i` are
`(g_1+g_2+Bp)_i`. Thus applying the map to both the lifted product and
its unitriangular theta expansion, then grouping by `p`, gives

\[
 c^{RB}_{Rg_1,Rg_2}(p)
   =\sum_{\pi u=p}
            c^{B^{[r]}}_{g_1^{[r]},g_2^{[r]}}(u).
 \tag{8.3}
\]

Uniqueness here is precisely the finite principal unitriangular
uniqueness of Section1. No extra arbitrary-endpoint folding theorem is
being assumed. Partition `u` by the subset of active clones in each
color. Support locality deletes unused clones, and relabelling preserves
the coefficient. For subsets of sizes `k`, (3.2) identifies the
remaining sum with the actual set (8.2). There are
`product_i binom(r_i,k_i)` such subsets. This proves (8.1). QED.

Equivalently, the objects for parameter `r` are pairs of an element of
`N_(p,k)` and ordered selected subsets
`1<=s_(i,1)<...<s_(i,k_i)<=r_i`. This gives explicit inclusions when
any replication parameter increases and positive mixed forward
differences by requiring specified new labels to be selected. The
polynomial has separate degree at most `p_i` and total degree at most
`|p|`. Values at zero parameters refer only to its polynomial
continuation, without forming `DR^(-1)` there. Uniform replication has
a nonnegative expansion in `binom(t,j)` by first choosing the union of
the selected color subsets.

The sparse polyhedral pieces of (8.2) have dimension at most `9|p|`.
Adding the selected-copy coordinates gives dimension at most `10|p|`,
with a number of pieces bounded in terms of `|p|` alone. As in the
coefficient replication theorem, this is a direct independent object
model and an equality of counts; no canonical identification with a
separate run of the folded event grammar is asserted. The same proof
applies to the flat all-arity objects (3.3). Their dimension bound remains
`10|p|`, although the number of degree-allocation pieces may also depend
on the arity.

### 8.1 Parameter strata

For fixed `D,p`, the structure coefficient is also an integer-valued
polynomial of degree at most `|p|` on each stratum of a finite rational
central sign arrangement in `(B,g_1,g_2)`, and `product_i p_i!` clears
its ordinary polynomial denominators. Indeed write

\[
 T_p=\sum_{a+b=p}a_{g_1}(a)a_{g_2}(b),\qquad
 c_p=T_p-\sum_{q<p}c_q\,a_{g_1+g_2+Bq}(p-q).
 \tag{8.4}
\]

Take the common finite refinement of the coefficient arrangements in
`agents/polyhedral_parameter_formula.md`, Section2, for every term
needed through degree `p`. All substitutions `g -> g_1+g_2+Bq` are
linear, so the pulled-back sign equations remain linear. Root degrees
add in every product; induction gives the degree bound. The same
root conservation makes the coordinate factorial `p!` divisible by
every product of leaf factorials. Integer-valuedness is preserved by
the displayed additions and products. This assertion includes zero
strata and makes no positivity claim for ordinary polynomial
coefficients. The actual positive binomial formula (8.1) is stronger
for its replication family.
