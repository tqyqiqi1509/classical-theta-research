# A positive global formula using local point orbits and finite selections

Date: 2026-11-13. Classical skew-symmetric cluster algebras.

This strengthens the local construction in
`COMBINATORIAL_GLOBAL_THETA_THEOREM.md`. The direct colour-content tree
grammar and its incoming-only proof remain unchanged. The newly proved
primitive-center theorem replaces each ungraded local fan module by an
actual Young-permutation set. The final recursion therefore needs only
multisets and subsets of already constructed child objects, rather than
local Specht multiplicity spaces.

The local set is defined by explicit graph equations and a finite generic
perturbation. It is not yet a universal Dyck-path set or the integer points
of one polytope. The original graph/fan rational-linear-algebra construction
remains a separate purely combinatorial implementation of the same count.

## 1. The independent local finite set

At an admissible node take its child charges beta_1,...,beta_m, with the
integer alternating pairing eta inherited from B and the frame. They span
a pointed nondegenerate two-plane. In the saturated lattice of that plane
write S=sum beta_i=k alpha, with alpha primitive. Choose an integral
functional f satisfying f(alpha)=1, an explicit quadratic refinement q of
eta modulo two, and a primitive k-th root zeta.

Orient m_ij=max(eta(beta_i,beta_j),0) arrows i->j. With o_i its outdegree,
put

    Q_i=(-1)^(o_i+q(beta_i)-f(beta_i)q(alpha)) zeta^(-f(beta_i)).

Define the finite scheme in vertex coordinates u by

    product_(arrows out of i)(u_i-u_j)
       /product_(arrows into i)(u_j-u_i)=Q_i,
    sum_i u_i=0,
    all arrow differences nonzero.

Retain all Artin multiplicities. Clear denominators in the graph-defined
square map described in PRIMITIVE_CENTER_GALE_FINITE_MODEL.md and apply
the specified coordinatewise polynomial perturbation, preserving the
equal-child-type symmetric groups. The full finite factor specializing to
this scheme has a reduced generic fiber. Let Z_T be its actual set of
geometric points. The coefficients may lie in a cyclotomic field; the set
is taken over its algebraic closure, not by restricting scalars and
artificially multiplying its cardinality.

The primitive-center theorem proves

    Q[Z_T] tensor_Q C is isomorphic to the ungraded local fan module L_T.

The local set is constructed from the charge graph before a theta
coefficient, fan character, or multiplicity is known. Its finite group
action permutes coordinates. Consequently every point stabilizer is a
Young subgroup, determined by equality blocks of its coordinates.

## 2. Orbit profiles and the recursive sets

Let C_1,...,C_s be the distinct isomorphism types among the children of T,
with multiplicities m_1,...,m_s. The node group is

    J_T=product_j S_(m_j).

It can be smaller than the group permuting all equal charges: two different
child types can have the same charge. Restriction causes no difficulty,
since coordinate-equality stabilizers remain Young subgroups within each
child type.

For each actual orbit z in Z_T/J_T choose a representative by a fixed
algebraic ordering. Within child type j, let B_(j,1),...,B_(j,r_j) be its
equal-coordinate blocks and put b_(j,a)=|B_(j,a)|. Distinct blocks are
distinguished by their coordinate values, even when their sizes agree.
There is no division by a factorial of equal block sizes.

For each child type C_j let O_(C_j) already be constructed and write
k_j=|O_(C_j)|. Define

    e_j = number_of_leaves(C_j)
          + sum_(i<h) eta(e_i,e_h) beta(C_j)_i beta(C_j)_h mod 2.

The leaf object set is a singleton. At T, an object consists of one of the
above actual point orbits and, independently for every equality block,

- a multiset of b_(j,a) child objects from O_(C_j), if e_j=0;
- a subset of b_(j,a) distinct child objects from O_(C_j), if e_j=1.

This defines O_T recursively. Finally take the disjoint union of O_T over
the admissible unlabelled tree types produced by the direct colour-content
grammar. Every item in the definition is independent of a theta answer.

## 3. Positive coefficient theorem

Set

    M_0(k,b)=binomial(k+b-1,b),
    M_1(k,b)=binomial(k,b),

with the natural zero conventions when no selection exists. Then

    k_T = sum_(z in Z_T/J_T)
                  product_(j,a) M_(e_j)(k_(C_j),b_(j,a)).       (3.1)

For every integral skew-symmetric B, integral g and p>=0,

    a_g^B(p) = sum_(admissible unlabelled T) k_T.                (3.2)

These are finite positive sums. They determine the formal classical theta
coefficient; finite support for every g is not part of the assertion.

### Proof

The earlier global theorem identifies the coefficient with the original
leaf-sign multiplicity in the graph/fan tree module. The primitive-center
theorem replaces each local L_T by Q[Z_T] without changing its character.

After imposing each child's sign condition, the remaining node action is
on Q[Z_T] tensor product_j K_j^(tensor m_j), with the required character
product_j sgn^(e_j). The exponent combines the sign of permuting leaf
blocks, (-1)^(number of leaves), with the super interchange parity of the
child, (-1)^(its total internal arrow count).

For one actual orbit with stabilizer H_z, Frobenius reciprocity gives

    Hom_(J_T)(product_j sgn^(e_j),
          Q[J_T/H_z] tensor product_j K_j^(tensor m_j))
       = Hom_(H_z)(product_j sgn^(e_j),
                   product_j K_j^(tensor m_j)).

The stabilizer is the product of symmetric groups on the coordinate
equality blocks. The right side therefore decomposes as the tensor product
of Sym^(b_(j,a))(K_j) when e_j=0 and exterior^(b_(j,a))(K_j) when e_j=1.
Their ordinary monomial and wedge bases are exactly the multisets and
strict subsets in Section 2. Their dimensions are M_0 and M_1.

Summing the actual point orbits proves (3.1). The same tree-orbit
Frobenius-reciprocity argument as in the earlier theorem then proves (3.2).
No local or global alternating character average is needed to define the
objects, and no coefficient is used to prescribe the number of objects.

## 4. The explicit polyhedral part

After fixing orders on the recursively constructed child sets, the two
selection types are the integer points in

    1 <= x_1 <= ... <= x_b <= k,      e=0,
    1 <= x_1 <  ... <  x_b <= k,      e=1.

For e=1, replacing x_i by x_i-i changes the strict inequalities into weak
ones. Thus each fixed tree and local orbit profile contributes a product
of elementary order polytopes. The resulting total model is a disjoint
union of such products indexed by explicit local point orbits and trees.

It is not claimed that the Newton hull alone records these multiplicities,
or that the algebraic local orbit indexing has already been replaced by
integer points. A direct parking-function or lattice-polytope replacement
of that indexing is a separate active problem.

## 5. Exact evaluation without solving every point

For counting purposes, the number of local orbits of each stabilizer
profile is uniquely the coefficient of the corresponding product of
complete symmetric functions in ch(L_T). The primitive-center theorem
proves these coefficients are nonnegative integers and identifies them
with actual orbits, not arbitrary formal labels.

They can be evaluated quickly from the proved cycle-fold character formula
or the exact local Laurent jets, followed by the change from permutation
characters to their Young-subgroup basis. Substitution into (3.1) counts
the independently defined finite sets. This is a fast counting method;
it does not pretend to enumerate the algebraic points when it has only
computed their orbit counts.

The complete-character formula at a permutation with cycle lengths l_i is

    Tr(sigma;L_T)=D_fold/product_i l_i times C,

where D_fold is the nearby generic stable-tree count on charges l_i beta_i,
and C is 1 if gcd(l_i)=1, 2 if gcd(l_i)=2 and E/4 is odd, and 0 otherwise.
Its proof retains all block returns, the primitive-center parity, and all
scheme multiplicities. It is not an untwisted mirror-volume substitution.

## 6. Relation to the valued problem

This theorem is currently for skew-symmetric B. It does not normalize
individual tree summands by vertex symmetrizers. Such a normalization can
fail to be a character. The separate valued work constructs phase actions
on whole attached Gale factors before any tree resolution and is pursuing
the appropriate global composition. The ordinary local Young model and
the whole-factor phase descent are compatible pieces of the research,
but their combination is not assumed without a proof.
