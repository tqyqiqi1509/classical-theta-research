# A weighted-degree restriction from the adjacent Laurent rings

Status: root derivation, pending an independent adversarial check. 2026-11-13.

This note addresses a necessary distinction in the arbitrary-seed goal. A formula for every formal theta coefficient can exist even when not every tropical label gives a finite regular theta element. It is not a substitute for the ongoing constructive work.

## Proposition

Let K be a field of coefficients, let x_1,...,x_n be algebraically independent, and let the exchange polynomials P_i in K[x_j:j!=i] have two relatively prime monomial terms, neither involving x_i. Suppose there is a positive integral weight vector w such that P_i is weighted homogeneous of positive degree delta_i. Write x_i'=P_i/x_i, and let U_0 be the intersection of the initial Laurent ring with its n adjacent Laurent rings. Put

    kappa = sum_i w_i/delta_i.

If kappa<=1, every nonzero weighted-homogeneous f in U_0 has degree d>=0. If kappa<1, the denominator exponents h_i=max(0,-min exponent of x_i in f) obey

    h_i <= d / ((1-kappa) delta_i).

The claim is independent of positivity of the coefficients of f and uses only the initial star of seeds.

## Proof

Let h_i be the denominator exponents above, and set F=x^h f. It is a nonzero ordinary polynomial of weighted degree L=d+sum_i w_i h_i>=0. If h_i>0, the coefficient Q_i of x_i^{-h_i} in f is nonzero. Expand f as a Laurent polynomial in x_i over K[x_j^{+/-1}:j!=i]. Under x_i=P_i/x_i', distinct powers of x_i become distinct powers of x_i'. Adjacent Laurentness therefore forces P_i^{h_i} to divide Q_i in this coefficient Laurent ring.

The coefficient F_i=[x_i^0]F=(product_{j!=i}x_j^{h_j})Q_i is an ordinary polynomial, nonzero, of weighted degree L. Since P_i is coprime to every variable x_j (its two terms have disjoint supports), divisibility in the Laurent localization implies P_i^{h_i} divides F_i in the polynomial ring. Consequently delta_i h_i<=L. This also holds trivially for h_i=0.

Multiplying by w_i/delta_i and summing gives sum_i w_i h_i<=kappa L. Hence

    d=L-sum_i w_i h_i >= (1-kappa)L.

For kappa<=1 this gives d>=0. For kappa<1 it also gives L<=d/(1-kappa), which combined with delta_i h_i<=L proves the displayed denominator bound.

No cancellation assumption, irreducibility of P_i, coprimeness between different P_i, or mutation invariance of the upper bound is required. The polynomial-localization argument needs only that P_i is coprime to each inverted variable; this holds for the usual geometric-type exchange binomial.

## Rank-three cyclic family

Take B=[[0,a,-c],[-a,0,b],[c,-b,0]] with a,b,c positive integers and principal coefficients. Give x the weights w=(b,c,a), and give every frozen variable weight zero. The equation B^T w=0 makes the two monomials of each exchange polynomial homogeneous, with

    delta=(ac,ab,bc),
    kappa=(a^2+b^2+c^2)/(abc).

Thus the condition a^2+b^2+c^2<=abc implies that the upper cluster algebra has no negative weighted-degree component, over the fraction field of the frozen variables and hence over the frozen Laurent polynomial ring.

For a=b=c=3, all mutable variables can instead be given weight 1, every exchange polynomial has degree 3, and kappa=1. In particular a finite regular pointed expression with leading label g=-e_i is impossible: every term x^{g+Bp}y^p has degree -1 because the columns of B sum to zero. It cannot be a member of U_0, hence cannot be a member of the upper cluster algebra.

This does not itself prove that the initial-chart formal theta series is infinite, unless its finiteness-to-global-regularity theorem is explicitly supplied. The unconditional conclusion needed here is that there is no all-lattice, finite, g-pointed theta basis of the upper algebra for this example.

## General balanced families

If every column of B sums to zero, use w=(1,...,1). Let delta_i=sum_j [B_{ji}]_+. Whenever sum_i 1/delta_i<=1, the same obstruction applies. For a directed n-cycle with a parallel arrows on every edge, delta_i=a; all a>=n satisfy the hypothesis. This is a uniform degree mechanism, rather than a finite numerical search.

## Literature status

Related rank-three gradings, counterexamples to full Fock--Goncharov statements, and upper-cluster non-finite-generation results must be compared before claiming novelty. No novelty assertion is made here.
