# Gale degree, stable trees, and the cycle-target isogeny

Date: 2026-11-13. Authoring branch: `local_permutation_upgrade`.

This note supplies the remaining non-equivariant degree bridge and independently
checks the fixed-cycle torus calculation used in
`../agents/primitive_center_ih_bridge.md`. It uses the finite-map theorem in
`PRIMITIVE_CENTER_GALE_FINITE_MODEL.md`. The comparison of **all** characters
uses the separate cycle-cumulant argument; a dimension comparison alone is never
used to assert an equivariant mirror correspondence.

## 1. The graph and its Gale degree

Use the rank-two pointed charge data of the companion note. Write
\(n=|V|\), \(m=|E|\), \(r=m-n+1\), and

\[
 \partial e_{u\to v}=e_u-e_v,\qquad
 \Theta=\partial\mathbf1.
\]

The graph is connected and acyclic. A spanning-tree basis of its integral
circulation lattice gives a matrix

\[
 A:\mathbb Z^E\longrightarrow\mathbb Z^r,
 \qquad \ker A=\operatorname{im}\partial^T.
\tag{1.1}
\]

The rows of \(A\) are integral circulations; thus a vector \(z\in\mathbb C^E\)
has the form \(z_e=u_{s(e)}-u_{t(e)}\) precisely when \(Az=0\).
Translation is removed by \(\sum_vu_v=0\). The cographic matrix \(A\) is
totally unimodular. In particular, its nonsingular maximal column minors are
\(\pm1\), and its column bases are the complements of spanning trees. These
facts also follow directly by solving the tree incidence equations successively
from leaves; no determinant index is suppressed in what follows.

Let \(d\) denote the degree of the finite flat Gale map over the signed
nonresonant open torus. We prove

\[
 d=\#\{\text{positive-flow spanning trees for }\Theta'\}
   =\dim L_V
\tag{1.2}
\]

for a sufficiently small generic perturbation \(\Theta'\) of \(\Theta\).

## 2. A direct lattice-ideal degeneration

Choose a positive rational vector \(w\in\mathbb Q_{>0}^E\) such that
\(\partial w=\Theta'\), where

\[
 \Theta'(C)\ne0\quad
 (\varnothing\ne C\subsetneq V).
\tag{2.1}
\]

Such a \(w\) exists for every sufficiently small perturbation: lift its
sum-zero difference from \(\Theta\) through \(\partial\) and add that small
lift to \(\mathbf1\).

The lattice ideal of \(A\) is

\[
 I_A=(z^{a_+}-z^{a_-}:a\in\operatorname{im}\partial^T).
\tag{2.2}
\]

Its initial ideal for the weight \(w\), with the larger weight leading, is
the squarefree Stanley--Reisner ideal whose facets are

\[
 I_T=E\setminus T,
 \quad T\text{ a spanning tree whose unique }\Theta'\text{-flow is positive}.
\tag{2.3}
\]

Here is a direct verification, including the needed integrality. Consider the
linear optimization problem

\[
 \min\{w\cdot x:Ax=b,\ x\ge0\}.
\tag{2.4}
\]

It has a minimum whenever its fiber is nonempty, since \(w>0\). Every vertex
of an integral fiber is integral by total unimodularity. Its dual feasible
polytope is

\[
 \{y:A^Ty\le w\}.
\tag{2.5}
\]

The map \(y\mapsto w-A^Ty\) identifies (2.5) with the flow polytope
\(\{x\ge0:\partial x=\Theta'\}\). Acyclicity makes this polytope bounded.
Condition (2.1) makes it simple: every vertex support is a spanning tree with
strictly positive tree flow. Its active set is therefore exactly \(I_T\).

A monomial \(z^a\) is absent from the initial ideal if and only if \(a\)
minimizes (2.4) among integer points in its fiber. Integrality makes this
equivalent to continuous optimality. Duality then says that its support is
contained in some active set \(I_T\). Conversely, when its support is in
\(I_T\), the invertibility of \(A_{I_T}\) gives a unique optimum, so that
monomial is indeed absent from the initial ideal. This proves (2.3), including
squarefreeness, directly. Constants and zero cographic columns cause no problem:
a zero column yields a relation \(z_e-1\), hence its variable is killed in the
initial ideal and belongs to no facet.

The resulting simplicial complex is the complete simplicial normal fan of the
simple flow polytope, viewed on its rays. It is a polytopal sphere (with possible
unused variables), hence its Stanley--Reisner ring is Cohen--Macaulay. The
\(r\) linear forms \(Az\) form a system of parameters: their restriction to
every facet \(I_T\) has coefficient matrix \(A_{I_T}\), whose determinant is
\(\pm1\). Consequently they form a regular sequence. Its Artin quotient

\[
 C_{\Theta'}=\mathbb C[z]/(\operatorname{in}_w I_A,Az)
\tag{2.6}
\]

has length equal to the number of facets, hence to the number of trees in
(2.3). This last assertion follows from the Hilbert series: quotienting a
\(r\)-dimensional Cohen--Macaulay Stanley--Reisner ring by \(r\) linear
parameters leaves its \(h\)-polynomial, whose value at one is the number of
facets.

### Twisted coefficients and completion

For arbitrary nonzero constants \(q_v\) with \(\prod_vq_v=1\), the rule

\[
 \partial^Ta\longmapsto\prod_vq_v^{a_v}
\]

is a character of the saturated lattice \(\operatorname{im}\partial^T\).
It extends to a character of \(\mathbb Z^E\), since the quotient is free.
Thus constants \(c_e\ne0\) can be chosen with
\(\prod_{\rm out(v)}c_e/\prod_{\rm in(v)}c_e=q_v\).

After clearing denominators of \(w\), take the weighted, coefficient-twisted
Rees algebra generated by \(T\) and

\[
 z_e=c_eT^{w_e}x^{A_e}
 \quad\text{inside }\mathbb C[T,x_1^{\pm1},\ldots,x_r^{\pm1}].
\tag{2.7}
\]

It is torsion-free, hence flat, over \(\mathbb C[T]\). Equivalently, its
ideal is the \(T\)-saturated weighted homogenization of the twisted lattice
ideal. Its special fiber is the ring in (2.6) before imposing \(Az\); nonzero
coefficient twists do not change the monomial initial ideal.

Complete at \((T,z_e:e\in E)\), and then impose \(Az=0\). The regular
sequence just verified in the special fiber lifts across the flat Rees family.
The resulting complete algebra \(B_{\Theta',q}\) is flat over
\(\mathbb C[[T]]\). Its special fiber is (2.6), a finite Artin algebra; lifts
of a finite basis generate by complete Nakayama. Therefore
\(B_{\Theta',q}\) is finite free, of rank

\[
 \operatorname{rank}B_{\Theta',q}=\#\mathcal T(\Theta').
\tag{2.8}
\]

Its generic fiber is precisely the factor of the Gale equations with positive
valuation on every arrow coordinate. Indeed, all special-fiber arrow variables
are nilpotent, so every point in the completed factor has positive arrow
valuation. Conversely, a finite Artin factor with positive arrow valuations
extends through the completion, by continuity of its topologically nilpotent
arrow multiplication operators. The same argument keeps nilpotents; it is not
an assertion only about reduced supports.

There are no extra generic solutions on coordinate boundary components.
The vertex equations at a source make the product of its outgoing arrows a
unit; each such arrow is a unit. Inducting along an acyclic ordering makes
every arrow a unit. Thus the generic lattice-ideal equations are exactly
the multiplicative Gale equations, even before explicitly inverting arrows.

## 3. Why the completed factor contains the whole generic degree

Choose an integral sum-zero vector \(\psi\) avoiding every proper-subset
zero equation. Choose generic constants \(q_v\) as above. The target curve

\[
 q_v s^{\psi_v}
\tag{3.1}
\]

lies in the nonresonant torus over \(\mathbb C((s))\). The constants can
also be chosen so that its generic fiber avoids the finite map's branch
discriminant. It then has exactly \(d\) simple points over an algebraic
closure; the argument with full lengths gives the same result without this
choice. There are finitely many arrow valuations \(\nu_e\) among these
points, and they are all finite because every arrow is nonzero.

Replace \(s\) by \(T^\epsilon\) and replace every vertex coordinate by
\(Tu_v\). Since \(\Gamma_v\) is homogeneous of degree \(\Theta_v\), the
new target is

\[
 q_vT^{\Theta_v+\epsilon\psi_v}.
\tag{3.2}
\]

Choose a sufficiently small positive rational \(\epsilon\). It can
simultaneously ensure

\[
 1+\epsilon\nu_e>0\text{ for every solution and arrow},\qquad
 \Theta' =\Theta+\epsilon\psi\text{ generic},
\tag{3.3}
\]

and preserve the signs of all nonzero old subset weights. Such a choice exists
because each requirement is a finite strict inequality. Clear all denominators
by a finite ramified base change.

Scaling gives a bijection of the entire generic solution algebras. Thus every
one of its \(d\) factors lies in the completed positive-arrow factor of §2,
and that factor has no additional generic solutions. Equations (2.8) and (3.3)
prove

\[
 d=\#\mathcal T(\Theta').
\tag{3.4}
\]

In particular the argument does not merely compare one selected branch with
some generic cut quotient. The small scaling puts **all** generic branches
inside the same completed factor.

## 4. From stable trees to the local fan dimension

There are two independent ways to complete (1.2).

The finite support/HN proof is given in §3 of
`../agents/primitive_center_ih_bridge.md`. In the squarefree label algebra,
refine the old semistable series by the generic stability \(\Theta'\).
All HN factors are old balanced, so their pairwise charge pairings are zero.
The product is commutative. Its ordinary logarithm in total degree \(V\)
selects only the refined zero-slope factor, since \(\Theta'(V)=0\). Genericity
leaves no proper zero-slope subset. Therefore

\[
 H(t)\Omega_V(1;t)=S_V^{\Theta'}(1;t),
 \qquad H(t)=\frac{t}{1-t^2}.
\tag{4.1}
\]

In the finite support expansion on the right, all semistable supports are
connected. Only supports with \(n-1\) arrows contribute a pole at \(t=1\);
they are exactly the positive-flow spanning trees. Each has residue \(-1/2\),
equal to the residue of \(H\). This proves
\(\dim L_V=\#\mathcal T(\Theta')\) purely from the previously established
finite combinatorial identities.

For an older geometric cross-check, Reineke's *Quiver moduli and small
desingularizations of some GIT quotients*, arXiv:1511.08316v1, Theorem 4.3,
applies. Here is the complete hypothesis check. The thin vector
\(\mathbf d=\mathbf1\) is indivisible. The representation with all arrows
nonzero is stable: a proper nonempty successor-closed subset has strictly
negative \(\Theta\)-weight because the graph is connected. The antisymmetric
part of the Euler form is, up to the orientation convention,
\(\eta(\beta_x,\beta_y)\). If \(\Theta(x)=\Theta(y)=0\), then both charges
are parallel to \(S\), so this pairing vanishes. Thus the Euler form is
symmetric on the required kernel. A sufficiently small generic deformation
of stability yields a small smooth resolution. Its toric fixed points are
exactly the trees in (2.3); its ordinary cohomology has the total dimension
of the original intersection cohomology. This recovers (4.1)'s consequence.

Primary source read: https://arxiv.org/html/1511.08316v1, Theorem 4.3 and
Corollary 4.4. No group action on this resolution is asserted or needed.

## 5. Fixed cycles and the connected target torus

Let \(\sigma\in G\) have cycles of lengths \(l_1,\ldots,l_c\), with charge
\(\beta_i\) on the \(i\)-th cycle. Put \(g=\gcd_i l_i\). The folded charge
list is \(\widehat\beta_i=l_i\beta_i\), and its arrow multiplicities are
\(l_il_j a_{ij}\), where \(a_{ij}=\max(\eta(\beta_i,\beta_j),0)\).
There are no arrows inside a cycle. Its total arrow count is the original
\(E\), and \(g^2\mid E\).

At a fixed tuple, all coordinates in a cycle equal \(u_i\). Translation can
be removed either by \(\sum_i l_i u_i=0\) or by \(\sum_i u_i=0\); both
gauges give the same edge-difference scheme. The fixed map is

\[
 \gamma_i(u)=
 \frac{\prod_j(u_i-u_j)^{l_j a_{ij}}}
      {\prod_j(u_j-u_i)^{l_j a_{ji}}}.
\tag{5.1}
\]

Edgewise cancellation gives the **primitive** relation

\[
 \prod_i\gamma_i^{l_i/g}=1.
\tag{5.2}
\]

Thus its image lies in the connected torus

\[
 T_l^0=\{z\in(\mathbb G_m)^c:\prod_i z_i^{l_i/g}=1\}.
\tag{5.3}
\]

The folded Gale map is exactly
\(\Gamma_{\rm Fold,i}=\gamma_i^{l_i}\). The power map

\[
 \pi:T_l^0\longrightarrow T_c,
 \quad (z_i)\longmapsto(z_i^{l_i}),
 \quad T_c=\{\prod_i z_i=1\},
\tag{5.4}
\]

is an isogeny of degree

\[
 \deg\pi=\frac{\prod_i l_i}{g}.
\tag{5.5}
\]

To see the denominator exactly, its kernel lies in \(\prod_i\mu_{l_i}\).
The map from this product to \(\mu_g\) given by
\(z\mapsto\prod_i z_i^{l_i/g}\) is surjective: any one factor already
surjects. Its kernel therefore has size \(\prod_i l_i/g\). This also
proves surjectivity of (5.4) by dimensions, since source and target are
connected tori of the same dimension.

Let \(W\subset T_c\) be the folded signed nonresonant open. The folded
Gale map is finite flat of degree \(D_F=\dim L_{\rm Fold}\), by §§1–4.
The factorization \(\Gamma_{\rm Fold}=\pi\circ\gamma\) makes
\(\gamma\) finite over \(\pi^{-1}(W)\). It is dominant, since the folded
map is dominant and the target is irreducible. Its source and target are
smooth of equal dimension; hence it is flat. The open
\(\pi^{-1}(W)\) is irreducible, so its degree is constant and equals

\[
 \deg\gamma=\frac{gD_F}{\prod_i l_i}.
\tag{5.6}
\]

This is a degree of an actual finite map, so the divisibility is automatic.
There is no assumption that different components of a disconnected torus
receive equal numbers of roots: the primitive relation (5.2) selects the
single connected torus on which flatness is used.

## 6. The canonical target selects precisely the Möbius cycle factor

Use \(Q_v\) from (1.1) of the primitive-center note and denote its constant
value on cycle \(i\) by \(Q_i\). Since \(S/g\) is integral and
\(S=k\alpha\) with \(\alpha\) primitive, \(g\mid k\). A direct use of the
quadratic refinement gives

\[
 \prod_iQ_i^{l_i/g}
 =(-1)^{E/g+E/g^2}\zeta_k^{-k/g}.
\tag{6.1}
\]

Indeed, the outdegree contribution is \(E/g\). Apply the refinement identity
to the list containing \(l_i/g\) copies of \(\beta_i\): its total is
\((k/g)\alpha\) and its internal arrow count is \(E/g^2\). Thus the
remaining sign contribution is \(E/g^2\) modulo two; the linear \(f\)-term
gives the displayed root of unity.

The root \(\zeta_k^{k/g}\) has order exactly \(g\), whereas the sign has
order at most two. Hence \(Q\in T_l^0\) holds exactly in the following cases:

\[
 \begin{array}{c|c}
  g=1 & \text{always},\\
  g=2 & E/4\text{ odd},\\
  g>2 & \text{never}.
 \end{array}
\tag{6.2}
\]

The powered target \((Q_i^{l_i})\) belongs to \(W\): every balanced proper
union of cycles has charge \(h\alpha\), \(0<h<k\), so the boundary-sign
identity leaves the nontrivial phase \(\zeta_k^{-h}\). Thus (5.6) applies
whenever (6.2) is compatible. The fixed-scheme length is consequently

\[
 \operatorname{length}(Z_V^\sigma)=
 \frac{D_F}{\prod_i l_i}
 \begin{cases}
  1,&g=1,\\
  2,&g=2\text{ and }E/4\text{ odd},\\
  0,&\text{otherwise}.
 \end{cases}
\tag{6.3}
\]

Incompatible targets have empty fixed scheme, rather than a formal negative
or virtual multiplicity. Formula (6.3) agrees term by term with the fan
character formula obtained by cycle cumulants and Möbius inversion in §6
of `../agents/primitive_center_ih_bridge.md`. The fixed-zero trace lemma,
proved there and in the Young perturbation construction, identifies its left
side with \(\operatorname{Tr}(\sigma;\mathcal O(Z_V))\).

Therefore, after that independently checked cumulant argument, the equality
\(\mathcal O(Z_V)\cong L_V\) is an equality of complete ungraded
\(G\)-characters. The degree argument in §§1–4 is only its identity-trace
input; §§5–6 and the cumulant calculation provide the missing nonidentity
information.
