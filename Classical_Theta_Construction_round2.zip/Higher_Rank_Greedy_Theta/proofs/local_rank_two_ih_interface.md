# A canonical local module for simultaneous flow events

Date: 2026-11-13. Root branch. All conclusions about cluster algebras remain classical.

## Status and purpose

This note proves the hypotheses needed to apply Reineke's small-resolution theorem to the rank-two child quivers arising from simultaneous events. It supplies a canonical, graph-defined local representation, not a representation manufactured from a previously computed theta coefficient.

The global assertion that induced tensor products of these local representations have the desired weighted-cycle character is **not yet proved here**. In particular a nonprimitive unframed event must not be identified termwise with one primitive folded flow coefficient. The first hard diagnostic shows why this distinction matters.

## 1. Input and a consistent sign convention

Let `K` be a rational two-dimensional plane in a rational vector space with an integral alternating form `eta`. Suppose the restriction of `eta` to `K` is nondegenerate. Let nonzero integral vectors

`beta_1,...,beta_s`

lie in `K` and in one pointed positive cone, span `K`, and put `S=sum_a beta_a`. Define an ordinary quiver on the displayed child labels by

`A_ab = max(eta(beta_a,beta_b),0)` arrows from `a` to `b`.

Define the stability

`Theta_a = -eta(S,beta_a) = sum_b eta(beta_a,beta_b)`.

We use King's convention that every proper nonzero subrepresentation `U` of a stable representation of total stability zero satisfies `Theta(dim U)<0`. With this convention `Theta` is **outgoing minus incoming** divergence of the flow assigning value one to every arrow. Reversing all arrows and reversing this stability gives the equivalent opposite-quiver formulation. This sign choice should be kept separate from other agents' incoming-minus-outgoing convention.

The dimension vector is the thin vector `d=(1,...,1)` on the displayed children, irrespective of divisibility of the projected vector `S` in the original color lattice.

## 2. The local quiver is acyclic and connected

Choose a linear functional positive on the positive cone and intersect its level-one hyperplane with `K`. The normalized child vectors lie on an interval. Ordering them along this interval orders their slopes. In a nondegenerate alternating plane the sign of `eta(beta_a,beta_b)` is determined by this order. Equal-slope children have zero pairing; different-slope children have nonzero pairing, oriented consistently with the total order. Thus `Q` is acyclic.

There are at least two slope classes. Every child has a nonzero pairing with every child in a different slope class, so the underlying undirected graph is connected.

## 3. Stable points exist, including on balanced zero faces

Consider the thin representation which assigns the scalar one to every arrow. A subrepresentation is determined by a subset of vertices, because every vertex space is one-dimensional. Its support must be successor-closed: no nonzero arrow can leave it.

For a nonempty proper successor-closed subset `U`, connectedness supplies an arrow across the cut. Every such crossing arrow enters `U`. Therefore

`Theta(U) = #arrows leaving U - #arrows entering U < 0`.

The all-nonzero representation is consequently `Theta`-stable. A subset with `Theta(U)=0` necessarily has arrows in both directions across the cut and is not a subrepresentation of this particular point. Thus the existence of balanced proper subsets does not invalidate the stable-locus hypothesis.

## 4. Symmetry on the stability kernel

Let `pi:Q^s -> K` send the child basis vector to `beta_a`. The antisymmetric part of the quiver Euler form is, up to the harmless overall orientation sign, the pullback of `eta` under `pi`.

If `Theta(v)=0`, then `eta(S,pi(v))=0`. Since `eta` is nondegenerate on the plane, the orthogonal complement of nonzero `S` in `K` is exactly the line `Q S`. Thus `pi(v)` is proportional to `S`. For two vectors in `ker Theta`,

`eta(pi(v),pi(w))=0`.

The Euler form is symmetric on the **whole rational kernel** of `Theta`, not merely on the proper nonnegative subvectors of `d`. This verifies the stronger printed hypothesis of the external theorem.

## 5. The small-resolution input, and the resulting module

Reineke, *Quiver moduli and small desingularizations of some GIT quotients*, arXiv:1511.08316, Theorem 4.3, applies when the stable locus is nonempty, the chosen stability has total value zero, the new stability is a generic deformation, and the Euler form restricts symmetrically to the stability kernel. It gives a small desingularization by the generically stable moduli space. Theorem 5.1 supplies a generic deformation for an indivisible dimension vector. Corollary 4.4 identifies its cohomology with the intersection cohomology of the undeformed quotient and gives vanishing of odd degrees.

All these hypotheses have now been proved for our local input: `d` is indivisible because every entry is one, `Theta(d)=0` by alternation, and Sections 2--4 establish the other requirements. The quiver is acyclic, so the moduli are projective. Hence

`H_loc = IH^*(M_Theta(Q,d), Q)`

is a finite, even-graded vector space, canonically defined at the symmetric stability. Any permutation of child labels preserving the displayed charges and arrow colors acts on the quiver and the symmetric quotient, and therefore naturally on `H_loc`. A generic small resolution need not preserve that group; the group action is defined on the undeformed intersection cohomology.

The original paper's proof was inspected at Definition 3.1, Proposition 3.3, Theorems 4.1 and 4.3, Corollary 4.4, Theorem 5.1 and Proposition 5.2. Its nullcone argument supplies the strict dimension estimate on every non-dense Luna stratum. No 2026 theorem is needed for this application.

Primary source: https://arxiv.org/pdf/1511.08316 .

## 6. A literal polyhedral input

Let `partial` be the incidence matrix with outgoing-minus-incoming convention. The all-unit arrow flow belongs to

`P_Theta = {f in R^(Q_1): f>=0, partial f=Theta}`.

The polytope is bounded: a nonzero recession vector would be a nonnegative circulation, and such a circulation would contain a directed cycle, contradicting acyclicity. It is integral because a directed-graph incidence matrix is totally unimodular and `Theta` is integral. The all-unit point gives relative interior in the affine flow space.

The thin toric quiver quotient is encoded by this flow polytope and its normal fan. Combinatorial intersection cohomology of the rational fan therefore supplies a route to defining `H_loc` using finite polyhedral linear algebra. The natural action is the action on this fan, not an arbitrarily selected bijection between two sets of the same cardinality.

## 7. Why the equivariant issue cannot be skipped

The local quiver `K_(2,2)` with two parallel arrows on every edge has thin generic Euler characteristic 16. Its symmetric quotient has natural graded intersection-cohomology traces

* identity: `1+3t+4t^2+4t^3+3t^4+t^5`;
* a row or column transposition: `1+t+2t^2+2t^3+t^4+t^5`;
* both transpositions: `1-t-t^4+t^5`.

Thus the ungraded character is `(16,8,8,0)`. Independent fan and local-Segre calculations in the active branches agree. The zero last trace is required by the complete hard example after its other macro-tree summands are accounted for. Replacing it by the primitive weighted-cycle tree number 4 would be incorrect at this unframed event.

This example shows that a local natural vector-space representation is more flexible than a naive action on decorated binary trees. It does **not** yet establish the all-rank global character identity.

## 8. Next proof interface: equivariant finite-field and species methods

One possible proof of the required trace identities is to compose Frobenius with a permutation of clone vertices. A vertex cycle of length `k` gives a field-extension degree `k`. Between cycles of lengths `k,l`, complete clone blocks split into `gcd(k,l)` arrow orbits of length `lcm(k,l)`, producing the valued matrix entry `l B_ij` and symmetrizer entry `k D_i` after descent. This agrees with the weighted-cycle matrix in the established coefficient formula.

However, local nonprimitive charges can have strictly semistable and multicover contributions. One must use the correct equivariant ray/primitive decomposition, or prove the global framed identity before taking traces. A bare application of point counting to each local primitive coefficient is insufficient. This is the present research task, not an asserted theorem.
