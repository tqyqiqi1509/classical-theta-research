# An explicit finite support bound from a verified coercive gauge

2026-11-13. Classical principal coefficients, skew-symmetrizable input.

This is a quantitative version of the early/late bend argument in Qiyue
Tang, *Positive polytopes and the full Fock--Goncharov conjecture*,
Hexagon2611.00015v1, Section3, Proposition `prop:finite`. The primary
source was read directly at
<https://hexagonmath.org/api/v1/works/2611.00015v1/source?path=main_GHKK.tex>.
The proof below rederives the needed estimates with explicit constants.
It uses neither that manuscript's full Fock--Goncharov conclusion nor
an unaudited implication from positivity of a polytope to affine-time
convexity. That convexity is an explicit additional hypothesis here.

## 1. Certificate and conclusion

Let `B` be integral, `D=diag(D_i)` positive integral, and `DB` alternating.
In the principal exponent lattice `Z^(2n)`, put

\[
 P=\begin{pmatrix}B\\I\end{pmatrix},\qquad
 R=\begin{pmatrix}D\\0\end{pmatrix},\qquad
 \ell(x)=\sum_{i=1}^n x_{n+i}.
 \tag{1.1}
\]

Thus `R^tP=DB` is skew-symmetric, `ell(Pa)=|a|_1`, and `P,R` are
integral. A genuine broken-line bend changes its exponent by `Pa` for
some nonzero integral `a>=0`; the bend point lies on `(Ra)^perp`.

The additional certificate is a rational piecewise-linear function

\[
 G(x)=\max_{1\le j\le s} l_j(x)
 \tag{1.2}
\]

and a positive rational `r`, satisfying:

1. `||x||_infinity <= r G(x)` for every `x`.
2. On every relevant broken line, `t -> G(gamma(t))` is convex in the
   affine time parameter with velocity equal to minus its exponent.

Condition1 is a coercivity certificate and can be checked by bounded
linear optimization on `G(x)<=1`. Condition2 is substantive: an ordinary
convex polytope, or the word "positive" without a verified theorem,
does not by itself supply it in this note. The object formulas and the
coefficientwise theorem do not require this additional certificate.

For an integral input principal exponent `m in Z^(2n)`, define constants

\[
 \begin{aligned}
 H&=2\max_j\|l_j\|_1,& H_m&=G(m),\\
 \lambda&=\min_iD_i,& A&=\max_iD_i,\\
 Q_R&=2A,& M_R&=\max_i|\langle R_i,m\rangle|,\\
 \epsilon&=\min\left(1,\frac{\lambda}{2\max(1,M_R)}\right),&
 R_0&=r(H+\epsilon H_m),\\
 K&=\left\lceil |\ell(m)|+
                  \frac{4nrH}{\epsilon}+3nrH_m\right\rceil,&
 P_*&=\max_i\|P_i\|_\infty,\\
 E&=\|m\|_\infty+KP_*,& C&=KA.
 \end{aligned}                                                   \tag{1.3}
\]

If `K>=1`, set

\[
 U=\epsilon+KC R_0(1+CE)^{K-1},\qquad
 N=K+\left\lceil\frac{2K(Q_R+UM_R)}{\lambda}\right\rceil.
 \tag{1.4}
\]

If `K=0`, set `N=0` and `U=epsilon`. The zero input can also be handled
directly by `theta_0=1`. When there are no mutable indices, every theta
is a character and `N=0`.

**Finite support lemma.** Under the two certificate hypotheses, every
term of the initial positive-chamber theta expansion of input `m` has
exponent `m+Pp` with `p>=0` and `|p|_1<=N`.

In particular for the standard input `m=(g,0)`, `ell(m)=0` and
`M_R=max_i D_i|g_i|`. The bound is computed solely from `(B,D,g)` and
the verified gauge data. It does not require an enumeration of walls
or a previously known theta coefficient.

## 2. A uniform endpoint box

Choose a generic endpoint `q` with mutable coordinates in `(1,2)` and
principal coefficient coordinates in `(-1,1)`. This box lies in the
initial positive chamber. It gives, uniformly,

\[
 \|q\|_\infty\le2,\quad G(q)\le H,\quad
 \lambda\le\langle R_i,q\rangle\le Q_R.
 \tag{2.1}
\]

One can avoid the countably many exceptional rational bend records
inside this nonempty open box. Only existence of such a generic `q` is
used; no unknown coordinate of `q` occurs in (1.3)--(1.4). All generic
endpoints in this chamber give the same initial theta coefficients.
The choice of epsilon gives

\[
 \langle R_i,q+um\rangle\ge\lambda/2
                  \qquad(0\le u\le\epsilon).             \tag{2.2}
\]

## 3. Position and early-charge estimates

For a broken line `gamma` ending at `q`, its first exponent is `m`, so
`gamma(-T)/T -> m`. Convexity along its affine time parameter and
positive homogeneity of `G` give, by the chord from `-T` to `0` and
then `T -> infinity`,

\[
 G(\gamma(t))\le G(q)-tG(m),\qquad
 \|\gamma(t)\|_\infty\le r(H-tH_m)\quad(t\le0).
 \tag{3.1}
\]

Write the nontrivial bends as `Pa_j` at times `-u_j<0`. Call a bend
early when `u_j>=epsilon`. The function `F=ell(gamma)` is concave:
its initial derivative is `-ell(m)`, and a bend decreases the derivative
by `|a_j|_1`. Hence the early total charge `k_early` satisfies

\[
 \begin{aligned}
 k_{\rm early}
 &=-\ell(m)-F'_+(-\epsilon)\\
 &\le |\ell(m)|+
       \frac{2}{\epsilon}
          \bigl(|F(-\epsilon)|+|F(-\epsilon/2)|\bigr)\\
 &\le |\ell(m)|+\frac{4nrH}{\epsilon}+3nrH_m\le K.
 \end{aligned}                                                   \tag{3.2}
\]

The last inequality uses `|ell(x)|<=n||x||_infinity` and (3.1) at
the two indicated times. There are at most `K` early bends, since each
has positive integral charge.

## 4. Explicit bound on early bend times

Start at `X_0=gamma(-epsilon)`, of norm at most `R_0`, and reconstruct
the early portion backwards. Every segment exponent encountered has
the form `e=m+Pb` with `b>=0` and `|b|_1<=K`, so `||e||_infinity<=E`.
For a next reversed bend of charge `a`, its normal `Ra` has
`||Ra||_1<=A|a|_1<=C`. The reversed elapsed time is

\[
 \tau=-\frac{\langle Ra,X\rangle}{\langle Ra,e\rangle},
                  \qquad X'=X+\tau e.
 \tag{4.1}
\]

At a genuine bend the denominator is nonzero. It is an integer, because
both `R` and `e` are integral, so its absolute value is at least one.
Using a nonprimitive multiple `Ra` causes no difficulty. Thus

\[
 0\le\tau\le C\|X\|_\infty,\qquad
 \|X'\|_\infty\le(1+CE)\|X\|_\infty.                 \tag{4.2}
\]

After at most `K` steps, the sum of these elapsed times is at most
`KC R_0(1+CE)^(K-1)`. Every early bend therefore has `u_j<=U`.
An early bend exactly at `-epsilon` has elapsed time zero and obeys
the same estimate.

## 5. Skew cancellation bounds all remaining charge

Integrating the segment velocities gives at each bend

\[
 \gamma(-u_j)=q+u_jm+
                 P\sum_k\min(u_j,u_k)a_k.
 \tag{5.1}
\]

Pair with `Ra_j` and sum over all bends. Every left side vanishes,
while the double sum cancels in pairs since its scalar time coefficient
is symmetric in `j,k` and `R^tP` is skew-symmetric. Therefore

\[
                    \sum_j\langle Ra_j,q+u_jm\rangle=0.
 \tag{5.2}
\]

By (2.2), each late bend contributes at least
`(lambda/2)|a_j|_1`. The absolute sum of all early contributions is at
most `K(Q_R+UM_R)`, using their total charge and time bounds. It follows
that the late total charge is at most
`2K(Q_R+UM_R)/lambda`. Adding (3.2) proves (1.4). If `K=0`, (5.2)
and the strict positivity of every late term force there to be no
bends at all, as prescribed separately above.

This proof applies to each finite broken-line contribution. The bound
is uniform over all degrees, so no contribution above it can occur.
The known finite-record property at each fixed principal degree then
gives Laurent finiteness in the initial chamber. Only this finite support
conclusion is used here; no spanning or upper-algebra equality follows
from the argument as stated.

## 6. Interface with the pure combinatorial algorithms

The hypothesis is used to certify a finite cutoff, not to redefine the
objects. Compute the event/Dyck objects for all `p>=0` with `|p|<=N`;
the coefficient-identification theorem then gives the complete theta
polynomial, and the above lemma guarantees that no term is omitted.
Its sparse position-polyhedral formula is unchanged.

For two certified inputs with degree bounds `N_1,N_2`, positivity and
the leading coefficient one imply that every theta structure degree
in their product has `|p|<=N_1+N_2`. The endpoint pair objects therefore
compute the entire product on this finite simplex. This is another
support-certificate interface, complementary to a reddening sequence.

The new content here is the explicit wall-free bound (1.3)--(1.4) and
its use with the independently defined finite combinatorial objects.
The qualitative early/late argument is credited to the source above.
Whether a proposed gauge meets hypothesis2 remains a separate proof
obligation; this note does not certify that condition merely from a
file labelled "positive polytope".
