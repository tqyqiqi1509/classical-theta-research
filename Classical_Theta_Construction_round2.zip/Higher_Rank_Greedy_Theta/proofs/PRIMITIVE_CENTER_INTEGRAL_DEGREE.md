# The primitive-center torus obstruction is an integral divisor degree

2026-11-13. Independent derivation by root of the degree observation from
the polyhedral-objects branch. This is a bridge toward a lattice-point
model, not a construction of the missing finite stability region.

Retain the charge list, quadratic refinement q with values chosen in
{0,1}, total S=k alpha, f(alpha)=1, and E arrows from the primitive-center
theorem. Let o_v be the outdegree of vertex v. Define

    t_v=(o_v+q(beta_v)-f(beta_v) q(alpha))/2 - f(beta_v)/k,
    d_*=(E+sum_v q(beta_v)-k q(alpha))/2 - 1.

Then the Gale target is Q_v=exp(2 pi i t_v), and sum_v t_v=d_*.

## 1. Integrality

The quadratic-refinement identity gives

    q(S)=sum_v q(beta_v)+sum_(u<v) eta(beta_u,beta_v) mod 2.

The last sum equals E modulo two regardless of the chosen vertex order.
Since eta(alpha,alpha)=0, q(k alpha)=k q(alpha) modulo two. Hence the
numerator defining d_*+1 is even. Thus d_* is an integer, determined from
the graph charges and parity refinement before any character is known.

## 2. The connected-target condition

Let sigma permute equal charges. Its cycle lengths are l_1,...,l_c, with
g=gcd(l_i). Write Q_i and t_i for their common values on a cycle. The
weighted fixed-coordinate Gale map lands in the connected torus

    product_i z_i^(l_i/g)=1.

At the primitive-center target, its defining monomial has value

    product_i Q_i^(l_i/g)=exp(2 pi i d_*/g).

Consequently the target belongs to that component exactly when g divides
d_*. Independently, the affine integer divisor lattice

    Div^(d_*)={a in Z^V : sum_v a_v=d_*}

has a sigma-fixed point exactly under this same divisibility condition:
fixed coordinates are constant on cycles, so the possible total degrees
are precisely the integer combinations of the l_i.

This identifies the actual obstruction with the familiar obstruction for
a degree-d_* integer divisor. It does not prove that an arbitrary finite
subset of this affine lattice has the required fixed-point counts.

## 3. Derivation of the exceptional gcd-two case

Put l_i=g m_i, U=sum_i m_i beta_i, so S=gU, k=gk_0 and U=k_0 alpha.
There are no arrows between equal-charge vertices in one permutation
cycle. Hence

    E=g^2 E_0,
    sum_v q(beta_v)-k q(alpha)=g M,
    M=sum_i m_i q(beta_i)-k_0 q(alpha).

Applying the quadratic-refinement identity to U gives M=E_0 modulo two.
It follows that

    d_*+1=g(g E_0+M)/2.

If g is odd, g E_0+M is even, and d_*=-1 modulo g. If g is even,

    d_*=(g/2)(E_0 mod 2)-1 modulo g.

Therefore g divides d_* precisely in the two cases

    g=1;
    g=2 and E/4 is odd.

This recovers the primitive-center character's support on conjugacy
classes without a complex-coordinate calculation or a character oracle.

## 4. What this gives and what it does not give

The correct candidate for a direct polyhedral object is now constrained:
it should be a G-invariant finite region in Div^(d_*), or a finite union
of such regions with a proved combinatorial identification. Its lattice
and affine degree already have exactly the right fixed-coordinate
obstruction. The remaining nontrivial requirement is the size of every
fixed slice: the folded stable-tree count divided by the cycle-torus
isogeny degree.

Ordinary break divisors or an entire graph Jacobian cannot be substituted.
They count all spanning trees; the local fan module counts nearby stable
trees. Likewise, matching the divisibility obstruction alone is not an
equivariant bijection and does not establish the desired polyhedral model.

This lemma is retained as a productive general interface. The separate
forward-exchange route has been tested and found not to apply to all of
these stability-selected basis families; no general forward-exchange
theorem is assumed here.
