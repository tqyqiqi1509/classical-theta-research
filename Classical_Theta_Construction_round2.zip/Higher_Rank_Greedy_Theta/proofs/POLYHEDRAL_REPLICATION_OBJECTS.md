# Actual Dyck multiplicities and polyhedral replication objects

2026-11-13, root branch. Classical skew-symmetrizable cluster algebras.

This note closes a specific missing interface in
`agents/polyhedral_parameter_formula.md`: the positive binomial
multiplicities there were still sums of theta coefficients, so they did
not define independent combinatorial objects. The finite Dyck event
grammar now supplies such objects. The replication identity and its
normalization are proved in that earlier note, Sections3--4; no new
unrestricted folding theorem is being assumed here.

## 1. Input and the independently defined base sets

Let B be integral, D positive integral diagonal, and DB alternating.
Write

    theta_g = x^g sum_(p>=0) a^B_g(p) z^p,
    z_i = y_i x^(B e_i).

For any fixed p, let O(B,D,g,p) be the following finite set, not a set
specified by its cardinality:

1. Add the frame with matrix [[0,-g^t D],[g,B]] and symmetrizer (1,D).
2. Set S=(1,p) and use the fixed ordered covector with entries
   Theta_i=1+epsilon_i and Theta_0=-sum p_i Theta_i.
3. Enumerate the exact bounded charge states, rational event planes and
   strict incoming infinitesimal flags of `valued_global_assembly.md`.
4. At every local birth use the actual tight Dyck gradings defined in
   `TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md`, with the prescribed positive
   integer normal power and actual recursive decorations.
5. Specialize all original alphabets to one letter; equivalently every
   original nonzero leaf coefficient is of degree one and has its unique
   original-color decoration.

The state graph, all path rectangles, all allowed integer weights and
every compatibility/shadow test are determined by (B,D,g,p). Their
definition does not call a theta coefficient, a wall list, a geometric
root solver, or a positivity theorem. The main event-flag identification
proves

    |O(B,D,g,p)| = a^B_g(p).                              (1.1)

Only coefficientwise formal theta functions are needed. No Laurent
finiteness or equality between an ordinary and an upper cluster algebra
is part of the statement.

## 2. All active copies, with no coefficient in the definition

Fix k with 0<=k_i<=p_i. Make k_i ordered copies of vertex i. On these
copies put

    B^[k]_((i,a),(j,b)) = B_ij,
    D^[k]_(i,a)=D_i,       g^[k]_(i,a)=g_i.

Let U(p,k) consist of positive integer tuples u_(i,a)>0 with
sum_a u_(i,a)=p_i. A block with k_i=0 is allowed only when p_i=0.
Define the actual active-copy set

    M_(p,k) = disjoint union_(u in U(p,k))
              O(B^[k],D^[k],g^[k],u).                    (2.1)

The union is tagged by u. Every copy is active, and the total number of
copies is at most |p|. Thus (2.1) is a finite bounded construction in
rank at most |p|, independent of any later replication parameter.
It does not define M_(p,k) to be {1,...,A_(p,k)}.

Set A_(p,k)=|M_(p,k)| only AFTER defining these objects. From (1.1),

    A_(p,k) = sum_(u in U(p,k)) a^(B^[k])_(g^[k])(u).   (2.2)

Equation (2.2) identifies these multiplicities with those in the proved
replication formula; it is not their combinatorial definition.

## 3. A positive object for every replication parameter

For positive integers r_i, put R=diag(r_i), B_r=RB and g_r=Rg. The
symmetrizer D_r=DR^(-1) can be multiplied by one common positive
denominator. Define

    C_(r_i,k_i) = {(s_1,...,s_ki): 1<=s_1<...<s_ki<=r_i}.

For k_i=0 this is the singleton empty tuple. For k_i>r_i it is empty.
The replication object is

    O_rep(B,D,g,p;r)
      = disjoint union_(0<=k<=p)
          M_(p,k) x product_i C_(r_i,k_i).               (3.1)

Its data have a direct meaning: choose which labelled copies of each
original vertex occur, then place an all-active-copy Dyck configuration
on the selected copies in their inherited increasing order.

**Theorem.** For every positive integral r,

    |O_rep(B,D,g,p;r)|
      = a^(RB)_(Rg)(p)
      = sum_(k<=p) |M_(p,k)| product_i binom(r_i,k_i).   (3.2)

**Proof.** The strong block-constant folding theorem proved in the
parameter note gives

    a^(RB)_(Rg)(p) = sum_(pi u=p) a^(B^[r])_(g^[r])(u).

Its proof checks the primitive normalization of all initial axis
logarithms and intertwines the finite endpoint extraction matrices;
ordinary quiver symmetry alone is insufficient. Partition the lifted
indices by their used subsets. Support locality deletes unused copies,
and relabelling leaves the coefficient unchanged. For fixed subsets of
sizes k, (1.1) identifies the remaining sum with the actual disjoint
union (2.1). There are product_i binom(r_i,k_i) subset choices. This is
exactly (3.1), proving (3.2). No external positivity theorem is needed
after the event-flag identification. QED.

The theorem is an equality of counts and an explicit independent object
construction. It does not assert a canonical bijection between
O_rep and the event grammar run directly on (RB,Rg): their deterministic
auxiliary flags can differ. No arbitrary rank/unrank bijection is being
offered as a geometric explanation.

## 4. Polyhedra that retain the actual compatibility conditions

Each fixed local Dyck shape carries nonnegative integer variables on
its edges, with fixed total horizontal and vertical weights. Dividing
the respective edge weights by the two compulsory divisors leaves
ordinary integer variables. Every cyclic compatibility or shadow test
is a finite Boolean combination of comparisons

    sum_(edges in an interval) c_e w_e <=,=,>= path_length,

where c_e and path_length are explicit integers. Add the comparisons
w_e=0 that decide which decorations are present. The finite arrangement
of these hyperplanes cuts the bounded product of weight simplices into
disjoint relatively open rational cells; retain precisely the cells
satisfying the path tests.

For a fixed recursive combinatorial skeleton and fixed child-degree
choices, the global region is the Cartesian product of its local cells.
The finite union over the independently defined skeletons is labelled
and disjoint. Its integer points are the actual objects of M_(p,k),
including their recursive decorations. If a strict inequality has an
integer left side, replace <b by <=b-1 when describing integer points.
Equality faces are kept separately, so this transformation loses no
boundary configurations.

Consequently (3.1) is an explicit finite union of lattice-point regions

    P_sigma x product_i
       {1<=s_(i,1)<...<s_(i,k_i)<=r_i},                 (4.1)

where P_sigma is built from the original path inequalities, not from a
previously known coefficient. The parameter factors are elementary
partly open order simplices. This gives a meaningful polyhedral
interpretation of the entire replication polynomial, and a path-based
polyhedral interpretation of each fixed theta coefficient.

The labelled union in (4.1) is deliberate. It is not asserted to be one
canonical convex polytope, to be a normal Newton polytope, or to carry
the intersection cohomology of the primitive-center Gale fiber. Those
would require additional theorems. Taking the convex hull would forget
the compatibility conditions and multiplicities that (4.1) retains.

## 5. Monotonicity and differences as actual selections

Increasing r_i gives an injection by retaining every old selected subset
and the same M-object. More precisely, mixed forward differences have
the independent object interpretation

    Delta^ell F(r)
      = sum_(k>=ell) |M_(p,k)|
           product_i binom(r_i,k_i-ell_i) >= 0.         (5.1)

For the term indexed by k, reserve ell_i distinguished new labels in
color i, require all of them to be used, and choose the remaining
k_i-ell_i labels in [r_i]. Inclusion-exclusion for the required labels
is exactly the finite difference, proving (5.1) directly. At r=0 the
polynomial continuation is used; no symmetrizer with r_i=0 is formed.

At the top multi-index k=p every copy degree is one, so M_(p,p) is the
single square-free event-flag set in rank |p|. Therefore

    [product_i r_i^(p_i)] F(r)
       = |M_(p,p)| / product_i p_i!.

This explains both the positive top coefficient and the factorial
denominator using actual configurations. It is a general mechanism,
not interpolation from a few values.

For uniform r_i=t, an object additionally determines the union of the
selected label sets. First choose that union, then its colored subsets.
Thus F(t,...,t) has a nonnegative expansion in binom(t,j), with objects
whose union is exactly [j]. The degree is at most |p|. The old example's
negative coefficient in the monomial basis is compatible with this
positive selection formula.

## 6. Exact checks of the newly closed interface

`computations/dyck_replication_objects.py` computes (2.1) using only the
literal event/Dyck counter. Its validation uses the separate signed
integer-prefix engine on the folded input; that engine is not used to
define any M-object.

For the cyclic skew matrix with rows (0,2,-2),(-2,0,2),(2,-2,0),
g=(-1,-1,-1) and p=(2,2,1), the actual all-active-copy counts are

    A_(1,1,1)=9, A_(1,2,1)=27,
    A_(2,1,1)=46, A_(2,2,1)=133.

Hence the previously unexplained positive expansion is now counted by
specific Dyck configurations:

    9 r1 r2 r3 + 27 r1 binom(r2,2) r3
      + 46 binom(r1,2) r2 r3
      + 133 binom(r1,2) binom(r2,2) r3.

The four multiplicities were obtained independently from the new path
counter, not inferred by matching this polynomial. A valued cyclic
input similarly gives active-copy multiplicities 3 and 12. Five
nonuniform replication vectors per input agree with the independent
folded integer formula. These ten checks specifically verify this
composition interface; the general argument is Sections2--5.

## 7. Priority and exact scope

The labelled-support regrouping behind positive binomial formulas has
rank-two precedents in Graefnitz--Luo arXiv2312.13990, Section4.
Zhou, SIGMA16(2020),013, Section3.1, supplies the strong pairing
condition used in block-constant folding. Neither idea is claimed as
new. The earlier parameter note contains the complete hypothesis audit.

The step added here is to replace the previously circular positive
multiplicities by the independently defined all-rank valued Dyck sets,
and thereby obtain (3.1) and (4.1) with no coefficient-sized placeholder.
It uses no conclusion of Li Fang or Pan Jie. It supplies a finite union
of explicit compatibility cells, not a new claim about their proposed
polyhedral basis or a single-polytope basis theorem.

## 8. Multiplication extension

`proofs/TWO_FRAMING_THETA_MULTIPLICATION.md`, Section8, proves the
parallel statement for every individual theta structure constant:
`c^(RB)_(Rg_1,Rg_2)(p)` has a nonnegative binomial expansion with actual
all-active-copy endpoint pair objects as multiplicities. Its proof uses
the existing coefficient-folding theorem through the multiplicative
principal monomial map, not an unproved arbitrary-endpoint folding
claim. Shared clone labels in the two factors are handled by their
union of active copies. The replication polyhedral dimension is at
most `10|p|`; the same construction applies to all flat arities.
