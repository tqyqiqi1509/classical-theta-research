# A finite Young-equivariant Gale model at a parity-corrected primitive center

Status: the finite-algebra and Young-permutation statements below are proved
in this note. The identification with the singular local fan module is now
**proved at every group character**, by the independent cycle-cumulant bridge
in `../agents/primitive_center_ih_bridge.md` and the independently checked
degree/torus proof in `GALE_DEGREE_AND_CYCLE_TORI.md`. Authoring branch:
`/root/local_permutation_upgrade`, 2026-11-13. This is classical data;
no quantum parameter is a target.

## 1. Data and the canonical multiplicative target

Let \(\Lambda\) be a rank-two lattice with a nondegenerate integral
alternating form \(\eta\). Let nonzero charges \(\beta_v\), indexed by a
finite labeled set (V), lie in one pointed cone and span \(\Lambda_\mathbb Q\).
Put

\[
S=\sum_{v\in V}\beta_v=k\alpha,
\]

where \(\alpha\in\Lambda\) is primitive and (k>0). Form the acyclic
multigraph with \(a_{uv}=\max(\eta(\beta_u,\beta_v),0)\) arrows (u\to v).
Use \(\partial(e_{u\to v})=e_u-e_v\), and set

\[
\Theta_v=\sum_w(a_{vw}-a_{wv})=-\eta(S,\beta_v),\qquad
o_v=\sum_w a_{vw}.
\]

Let \(G=\prod_c S_{n_c}\) permute equal charges. Choose an integral
linear form \(f:\Lambda\to\mathbb Z\) with \(f(\alpha)=1\).
Choose a quadratic refinement

\[
q:\Lambda\to\mathbb Z/2,
\qquad q(x+y)=q(x)+q(y)+\eta(x,y)\pmod2.
\]

For example, in a lattice basis with \(\eta(e_1,e_2)=d\), take
\(q(xe_1+ye_2)=dxy\pmod2\). Let \(\zeta\) be a primitive (k)-th root
of unity, with \(\zeta=1\) when (k=1). Define

\[
\tau_v=(-1)^{o_v+q(\beta_v)-f(\beta_v)q(\alpha)},
\qquad
Q_v=\tau_v\zeta^{-f(\beta_v)}.
\tag{1.1}
\]

These values are constant on charge colors. Their product is one: the
quadratic-refinement identity gives

\[
q(S)=kq(\alpha)
=\sum_vq(\beta_v)+|E|\pmod2,
\]

while \(\sum_v o_v=|E|\) and \(\sum_v f(\beta_v)=k\).

All finite-scheme lengths below are over \(\mathbb C\), after choosing the
displayed primitive root, or equivalently ranks over its cyclotomic field
\(K=\mathbb Q(\zeta)\). Restricting the entire algebra from \(K\) to
\(\mathbb Q\) would multiply its dimension by \([K:\mathbb Q]\) and is
not the construction. The eventual finite permutation set supplies its own
rational permutation representation with the required character.

## 2. The boundary-sign identity

Write (A(C,D)=\sum_{u\in C,v\in D}a_{uv}\).
Call (C\subset V) balanced when \(\Theta(C)=0\).
For a nonempty proper balanced subset, pointedness and dimension two imply

\[
\beta_C=h\alpha\quad\text{for an integer }0<h<k.
\tag{2.1}
\]

The integrality of (h) uses primitivity of \(\alpha\), not coprimality
of color multiplicities.

**Lemma 2.1.** For every balanced subset (C),

\[
\prod_{v\in C}Q_v
=(-1)^{A(C,V\setminus C)}\zeta^{-h},
\qquad \beta_C=h\alpha.
\tag{2.2}
\]

**Proof.** If (E_C=A(C,C)) denotes the number of internal arrows, then

\[
q(\beta_C)=\sum_{v\in C}q(\beta_v)+E_C\pmod2.
\]

Furthermore \(\sum_{v\in C}o_v=E_C+A(C,V\setminus C)\) and
\(q(\beta_C)=h q(\alpha)\). Substitution into (1.1) cancels the two
copies of (E_C) and proves (2.2). \(\square\)

Consequently the target avoids every proper balanced boundary relation:

\[
\prod_{v\in C}Q_v\ne(-1)^{A(C,V\setminus C)}
\quad(\varnothing\ne C\subsetneq V,\ \Theta(C)=0).
\tag{2.3}
\]

The sign in (2.3) is essential. Avoiding the unsigned relation
\(\prod_{v\in C}Q_v=1\) is not the correct condition.

## 3. A general finite-map theorem

Let

\[
U=\{u\in\mathbb A^V:\sum_vu_v=0,
\quad u_{s(e)}-u_{t(e)}\ne0\text{ for all }e\in E\},
\]

and define

\[
\Gamma_v(u)=
\frac{\prod_{e\text{ out of }v}(u_{s(e)}-u_{t(e)})}
     {\prod_{e\text{ into }v}(u_{s(e)}-u_{t(e)})}.
\tag{3.1}
\]

Its image lies in the torus \(T_V=\{q\in(\mathbb G_m)^V:\prod_vq_v=1\}\).
Let (T_V^{\rm nr}\) be the open subset obtained by excluding the
finitely many proper balanced signed equations in (2.3).

**Theorem 3.1.** The restriction

\[
\Gamma^{-1}(T_V^{\rm nr})\longrightarrow T_V^{\rm nr}
\tag{3.2}
\]

is finite and flat. It is dominant, hence has positive degree. In
particular \(Z_V:=\Gamma^{-1}(Q)\), with (1.1), is a nonempty finite
scheme with its full Artin structures and a natural (G)-action.

### Proof of finiteness

It suffices to prove the valuative criterion for properness, because the
map is affine. Work over a DVR after a finite extension if necessary,
with valuation \(\nu\), a target whose entries and inverses are integral,
and special target in (T_V^{\rm nr}).

Suppose some (u_v) has negative valuation, and let \(r<0\) be the least
valuation. Partition the vertices with valuation (r) according to their
nonzero leading coefficient. Fix one block (C). Every edge from (C)
to its complement has difference of valuation exactly (r); internal
edge factors cancel after multiplying (3.1) over (C). Therefore

\[
0=\nu\Bigl(\prod_{v\in C}\Gamma_v\Bigr)=r\Theta(C).
\]

Thus (C) is balanced. The same argument makes every other least-valuation
block balanced. Their complement, being the difference from (S), is
balanced as a whole. Between any two such blocks the numbers of arrows in
opposite directions coincide, because their charges are parallel to (S).
The ratios of leading differences therefore cancel, leaving only a sign:

\[
\prod_{v\in C}\overline{\Gamma_v}
=(-1)^{A(C,V\setminus C)}.
\tag{3.3}
\]

The block (C) is proper. If all vertices had the same negative leading
coefficient, the equation \(\sum_vu_v=0\) would have a nonzero leading
coefficient \(|V|c\), impossible in characteristic zero. Equation (3.3)
contradicts the nonresonance assumption. Hence all (u_v) are integral.

Now every edge difference has nonnegative valuation. Since every target
entry is a unit, their valuations satisfy

\[
\partial\bigl(\nu(u_{s(e)}-u_{t(e)})\bigr)_{e\in E}=0.
\]

A nonnegative circulation on an acyclic quiver is zero. All edge differences
are therefore units, so the limit lies in (U). Uniqueness follows from
separatedness. This proves properness and hence finiteness.

### Dominance and flatness

Choose real (u_v) strictly decreasing along the acyclic orientation and
then subtract their mean. Every edge difference is positive. The derivative
of \(\log\Gamma\), on the sum-zero space, is

\[
\partial\operatorname{diag}
  \bigl((u_{s(e)}-u_{t(e)})^{-1}\bigr)\partial^T.
\tag{3.4}
\]

It is a positive weighted graph Laplacian, nonsingular on the sum-zero
space because the graph is connected. Thus \(\Gamma\) is dominant.
The source and target of (3.2) are smooth of the same dimension; the finite
map is flat by the Cohen–Macaulay/regular-base criterion (equivalently,
local systems of parameters are regular sequences). The nonempty open
target is irreducible, so the degree is a positive constant. \(\square\)

## 4. Actual Young-permutation objects

The finite scheme (Z_V) has a graph-defined polynomial realization with
the same coordinate Young action in source and target. Set

\[
D(u)=\prod_e(u_{s(e)}-u_{t(e)}),\qquad
a_v(u)=\Gamma_v(u)/Q_v,
\quad\bar a=|V|^{-1}\sum_va_v,
\quad\bar u=|V|^{-1}\sum_vu_v,
\]

and define

\[
F_v(u)=D(u)(a_v(u)-\bar a(u))+\bar u.
\tag{4.1}
\]

This is polynomial. Near (Z_V), the factors (D\ne0) and \(\bar a=1\)
select exactly the original Gale scheme: \(F=0\) implies \(\bar u=0\)
and all (a_v\) equal, while \(\prod_va_v=1\) separates the possible
\(|V|\)-th roots from the factor (1).

For every color (c), add a generic polynomial of degree at most (n_c-1)
to its coordinate equations, multiplied by a new parameter (s). Retain
the full finite flat factor specializing to (Z_V). The generic fiber
is a finite reduced set of coordinate tuples. Its stabilizers are Young
subgroups, and its function algebra has the same (G)-character as
\(\mathcal O(Z_V)\). The interpolation and flatness proof is given in
`../agents/local_permutation_upgrade.md`, §3, and was checked directly
against Tang's Lemma 6.1, not borrowed from any cluster positivity claim.

Thus the model already supplies genuine finite Young-permutation objects
for every many-slope charge configuration. What it counts is not defined
using the theta coefficient or the desired IH character.

## 5. Relation to a primitive attached center

For two charge types with multiplicities (ka,kb), the original attached
Gale family has center equation

\[
c^h=\sigma_k^h,
\qquad
\sigma_k=(-1)^{qb+mab(k-1)}
\]

for a balanced center block of multiplicity (h); here (pa-qb=1\).
Choosing \(c=\sigma_k\zeta_k\) with \(\zeta_k\) primitive forces (k\mid h).
Within the all-particle sector, it therefore forces the entire packet into
that one center. This is a genuine idempotent factor of the finite attached
algebra, selected by the center values.

After tangent rescaling, its unframed multiplicative targets have exactly
the signed nonresonance in (2.3). The universal formula (1.1) packages that
parity shift for arbitrarily many slope types. It uses the fact that the
antisymmetric form vanishes on the balanced lattice; one need not assume
that cross-arrow multiplicities depend only on total physical degree.

For higher slopes, a full framed-center deformation realizing (1.1) can be
constructed by adding an integral framing form (f+N\Theta) with (N\)
large and incorporating its boundary sign as target units. The unframed
finite scheme (3.1), which is all that is proved here, does not require
the existence of that additional family.

## 6. The complete ungraded character identification

The theorem, now proved using the two companion arguments, is

\[
\boxed{\mathcal O(Z_V)\cong L_{P_V}
       \quad\text{as ungraded (G)-modules}.}
\tag{6.1}
\]

It upgrades the previously proved local Schur representation to an actual
Young-permutation model in all singular cases of the rank-two local charge
construction. The full comparison proceeds as follows.

For a permutation with cycle lengths \(l_1,\ldots,l_c\), put
\(g=\gcd_i l_i\), let \(E\) be the arrow count, and fold each cycle to
the charge \(l_i\beta_i\). If \(D_F\) denotes the total fan dimension
of that folded graph, the cycle-cumulant calculation proves

\[
 \operatorname{Tr}(\sigma;L_{P_V})
 =\frac{D_F}{\prod_i l_i}
   \sum_{d\mid g}\mu(d)(-1)^{E-E/d^2}.
\tag{6.2}
\]

The divisor sum is one for \(g=1\), two for \(g=2\) and odd
\(E/4\), and zero otherwise. Independently, the fixed Gale map lands
in the connected torus \(\prod_i z_i^{l_i/g}=1\). Its power map to
the folded ordinary target has degree \(\prod_i l_i/g\). The canonical
target (1.1) belongs to that torus in precisely the same two nonzero
cases. Finite flatness and the degree lemma give the fixed-scheme length
equal to (6.2). Finally the Young square-map deformation identifies this
fixed-scheme length with the trace on \(\mathcal O(Z_V)\).

The non-equivariant degree lemma is proved by a weighted cographic
lattice-ideal degeneration. Its initial ideal is the Stanley--Reisner
ideal of the nearby generic flow fan; the cycle equations are a regular
parameter system because every tree-complement minor is unimodular.
A sufficiently small common scaling puts every generic Gale branch in
its completed positive-arrow factor. The resulting degree is the stable
spanning-tree count. The finite HN logarithm identifies that count with
the folded fan dimension. This dimension step is used only at the identity;
the cycle-torus and cumulant arguments supply all nonidentity traces.

Thus no invariant small resolution, naive equivariant polar Ehrhart
identification, or coefficient-one mirror action is assumed. The output
is an actual finite set of algebraic coordinate tuples, with Young
stabilizers, defined from the graph by §4. A direct lattice-point or
elementary Dyck-path realization remains a separate strengthening.

Independent proof audit completed on 2026-11-13 by the
`local_permutation_upgrade` and `primitive_center_ih_bridge` branches;
root also checked the entire character chain and compared 135 nonidentity
traces with the pre-existing exact HN engine. Those computations detect
normalization mistakes and are not substitutes for the proofs above.

Two possible precise bridges remain under investigation:

1. a signed toric-face-ring degeneration whose local graph-cone factors
   identify with RRT cut modules, compatibly with the full vertex action;
2. a genuine center-factor species decomposition whose connected factor
   obeys the already proved balanced-partition character identity,
   including every cycle return and arrow parity.

The group acting on the mirror torus torsor need not be its ordinary
coefficient-one lattice action. That distinction is necessary and is
explicit in the target (Q).

