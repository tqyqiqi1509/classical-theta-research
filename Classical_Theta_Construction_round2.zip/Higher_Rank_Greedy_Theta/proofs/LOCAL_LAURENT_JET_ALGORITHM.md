# Exact local primitive characters without parallel-arrow fan enumeration

Date: 2026-11-13. Classical specialization only.

The finite support/HN and balanced-partition identities in
`agents/many_slope_independent_review.md` determine the local primitive
character Omega(J,sigma;t). This note supplies an exact finite arithmetic
algorithm for its value at t=1. It is an evaluation of those independently
proved combinatorial identities. It neither queries a theta coefficient nor
constructs artificial objects from a known answer.

## 1. Weighted Laurent precision

Fix a target containing N labels, put h=t-1, and assign weight w to any
series belonging to a component of w labels. The entire representation
stack trace has a pole of order at most w. Its HN subtractions preserve
that bound. Store a weight-w series F as

    h^w F(1+h) modulo h^(N+1).

Equivalently, retain its Laurent exponents from -w through N-w. A product
of weights u and v is then just the truncated product of their two stored
polynomials. If the first unknown term of F has order N-u+1 and the other
factor has pole order at most v, their error product starts at order
N-(u+v)+1. Thus every discarded term is immaterial to the prescribed
precision of the product. Addition is performed only at equal weights.

The scalar twist t^a, for any integer a, has weight zero and exact stored
coefficients binomial(a,j), 0<=j<=N. Negative a uses the ordinary generalized
integer binomial formula, without approximation.

For an Adams operation t -> t^k the charge weight changes from w to kw.
Write ((1+h)^k-1)=h U_k(h), where U_k(0)=k is nonzero. A known term c h^j
becomes c h^j U_k(h)^j, allowing negative j by power-series inversion.
The first unknown order remains N-w+1, which is at least N-kw+1.
Hence the stored input always has sufficient precision. In normalized
polynomial indices the term's first possible output position is
(k-1)w+i, where i was its input position. This proves the precision rule
used by the implementation; no cancellation is guessed numerically.

## 2. Finite combinatorial recursion

For a local alternating matrix eta and a type-preserving permutation sigma,
the all-support trace is

    A=t^(w-E)/product_(cycles C)(1-t^(2|C|)).

Its weighted jet is computed by multiplying exact truncated power series
for h/(1-(1+h)^(2|C|)) and shifting by w minus the number of cycles.

The semistable trace is A minus all nontrivial HN products. A sigma-fixed
ordered HN decomposition is a partition of the sigma cycles into blocks
with distinct slopes, followed by their unique decreasing-slope order.
Each factor is a smaller semistable trace; the twist is t^sum eta(A,B)
over ordered block pairs, with the corrected convention of the reviewed
local proof.

Let H=t/(1-t^2) and write P=H Omega. Compute P from the semistable trace by
subtracting all nontrivial balanced sigma-invariant set partitions. For
a length-k orbit of blocks represented by C, the factor is

    (-1)^((k-1) E_C) P(C,sigma^k|C;t^k).

Keep every balanced partition, including cycles of parallel blocks. All
components are smaller, so this recursion terminates. The total weight of
every term is the original number of labels. Therefore Section 1 proves
that every arithmetic operation retains enough precision.

The independently proved primitive regularity says that P has at most a
simple pole at h=0. The implementation checks exact vanishing of all lower
Laurent coefficients as a consistency check. Since

    H(1+h)=-1/(2h)-1/4+h/8-h^2/16+...,

the answer is exactly

    Omega(1) = -2 coefficient_(h^-1) P.

Thus a character value can be computed without constructing every edge or
the full fan, and without expanding a Laurent polynomial whose exponents
grow with the arrow multiplicity. The number of jet coefficients is N+1;
arrow multiplicities affect integer sizes and binomial values, rather than
the length of a fan-ray list. Set partitions can still be expensive when
the number of distinct labels is large; no polynomial-time claim is made.

## 3. Verification and correction record

`computations/local_primitive_laurent_jets.py` implements the algorithm over
exact rational numbers. Seventeen structural comparisons passed, including
proper parallel-block returns, four different slopes, all relevant K22
cycle types with multiplicities 1,2,7,101, and both the identity and a
three-cycle pair on K33. Comparisons are made with separately constructed
fan characters or an already proved family formula only after the jet
calculation. The local trace of K22 with multiplicity 101 is 2,060,602 at
the identity and 202 at the double transposition; the computation did not
build its 404 individual arrows.

The actual Wolfram plugin independently checked negative-power binomial
coefficients through order twelve, the residue normalization, and the
Adams substitution. An initially hand-typed expected expansion of H(t^2)
was incorrect and produced a nonzero residual. It was corrected by directly
expanding the rational function; the corrected substitution residual is
zero. This typo was only in the external verification expression, not the
jet implementation. Both receipts are retained.

The algorithm accelerates character evaluation. Actual counted objects
continue to be defined by the independent fan/intertwiner/tableau
construction. A fast character formula alone is not presented as a new
finite-set basis.

## 4. Combination with the unlabelled positive recursion

`computations/unlabelled_jet_formula.py` substitutes this exact local
character evaluator into the proved orbit/Schur recursion. The tree types
are generated from colour contents, so neither a global permutation
module nor all labelled trees are materialized. Nonnegative local Specht
multiplicities and tableau dimensions still evaluate the same independently
defined objects.

Five structural global comparisons passed after the constructor finished.
For the cyclic matrix with upper entries (202,-303,202), g=(-303,303,-202)
and p=(2,2,1), the positive answer is

    229248154306 = 20709050100 + 166496641600 + 42042462606.

The three terms are distinct unlabelled tree orbits. The construction took
about 0.02 seconds in the recorded environment. The rank-four cyclic input
in the same file gives 2598 from 28 tree orbits, in about 0.31 seconds.
These timings illustrate removal of a concrete computational bottleneck;
they are not a general complexity bound or a proof of the global theorem.
