# Higher Rank Greedy / Theta：本轮总研究包

**范围：经典丛代数；任意有限秩斜对称，以及可斜对称化交换矩阵。**

先读 [中文总报告](00_MAIN_REPORT_ZH.md)。本包的主结果是独立定义的有限 Dyck／双页树对象、任意端点的 theta 系数、正的 theta 乘法对象、稀疏多面体公式，以及 Young 模与 reddening 的接口。

## 核心阅读顺序

| 内容 | 文件 |
|---|---|
| 查新判断、主定理、意义、未解加强项 | [00_MAIN_REPORT_ZH.md](00_MAIN_REPORT_ZH.md) |
| 任意可斜对称化数据的完整正组合构造与一般证明 | [agents/valued_global_assembly.md](agents/valued_global_assembly.md) |
| 局部 Dyck 对象与正确的法向整数幂 | [proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md](proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md) |
| 不使用 shadow 判定作为定义的双页树 | [agents/TWO_STACK_DYCK_FORESTS.md](agents/TWO_STACK_DYCK_FORESTS.md)，尤其 §6.1 |
| theta 乘法、双 framing、任意多因子、复制参数 | [proofs/TWO_FRAMING_THETA_MULTIPLICATION.md](proofs/TWO_FRAMING_THETA_MULTIPLICATION.md) |
| 局部稀疏整数约束 | [proofs/SPARSE_POSITION_POLYTOPES.md](proofs/SPARSE_POSITION_POLYTOPES.md) |
| 全局多面体组合与稀疏位置约束 | [proofs/GLOBAL_SPARSE_POLYHEDRAL_RECIPE.md](proofs/GLOBAL_SPARSE_POLYHEDRAL_RECIPE.md) |
| framing 槽位压缩后的更强维数界 | [proofs/FRAMED_SPINE_SPARSE_BOUND.md](proofs/FRAMED_SPINE_SPARSE_BOUND.md) |
| 普通槽字、融合与实际 Dyck 边逆映射 | [agents/FRAMED_SPINE_FUSION_TRANSPORT.md](agents/FRAMED_SPINE_FUSION_TRANSPORT.md) |
| 秩三 first-multilinear 实际事件地址双射 | [agents/FRAMED_TWO_PACKET_EVENT_FLIP.md](agents/FRAMED_TWO_PACKET_EVENT_FLIP.md) |
| 原始字母、Young 模、对称／外幂、reddening 支持盒 | [agents/valued_young_functor_reddening.md](agents/valued_young_functor_reddening.md) |
| 另一种已验证 gauge 输入下的显式有限支持界 | [proofs/COERCIVE_GAUGE_FINITE_SUPPORT.md](proofs/COERCIVE_GAUGE_FINITE_SUPPORT.md) |
| 复制参数的非负二项式展开与实际选择对象 | [proofs/POLYHEDRAL_REPLICATION_OBJECTS.md](proofs/POLYHEDRAL_REPLICATION_OBJECTS.md) |
| 可复算的主要程序入口 | [REPRODUCING.md](REPRODUCING.md) |

## 文件层次

- `proofs/`：专题证明。当前主路径以上表为准。
- `agents/`：分支证明、独立核对、文献接口和被否定的路线。保留形成过程，不把较早的“尚未完成”描述当成最终状态。
- `computations/`：精确计算程序、实际对象及多面体 recipes、JSON 结果、Wolfram 成功或失败的原始回执。
- `logs/route_reviews.md`：约每二十分钟的查新和路线记录，包含失败与纠偏。
- `logs/RUN_LOG.md`：实际计时。

较早的 `proofs/COMBINATORIAL_GLOBAL_THETA_THEOREM.md` 是先取得的斜对称 graph/fan 版本，保留作为另一条表示论接口；其中“尚无通用 Dyck 公式”的历史描述已经由当前 valued 主稿取代。不要将两个阶段的范围混读。

本包没有重复打包下载的论文全文及上一轮大包；参考文献的版本、具体调用范围、链接和审核结论保存在相应笔记中。唯一依赖上一轮文件的历史检查脚本在 `REPRODUCING.md` 中另行指出。当前主要构造程序不依赖上一轮大包。

## 数学状态

主定理有一般证明与独立交叉审查，计算用于检查实现和规范；计算不是证明。结论是逐系数的，对任意整数标签的形式 theta 都有意义。给出 reddening 等已验证的有限支持证书后，可计算完整 theta 多项式及完整乘积。这里没有断言所有矩阵的所有形式标签都自动 Laurent 有限，也没有断言普通丛代数等于上丛代数。

未调用 Li Fang／Pan Jie 的任何结论。保留他们提示的“系数应有多面体含义”这一研究方向，实际多面体来自本轮独立的路径位置与首返约束。
