# Targeted primary audit: Fei 2610.09868v2 and the valued phase problem

Stage: 2026-11-13, 14:07 UTC. This is a targeted audit of the interfaces
relevant to the present construction, not an endorsement of the entire
87-page basis theorem.

## Verified identity and version

Primary record: <https://arxiv.org/abs/2610.09868>.
Primary text: <https://arxiv.org/pdf/2610.09868v2>.
Jiarui Fei, *Ramified Quivers with Potentials, Monodromy Characters, and
Cluster Bases I*, v1 October 7, 2026; v2 October 10, 2026, 87 pages.
The record and PDF agree. The basis theorem has hypotheses of a good
ramified modulation, a Jacobi-finite nondegenerate potential, a full initial
order and seed reachability. A reddening sequence supplies certain
realization/reachability conditions; its presence does not eliminate all
these hypotheses by itself.

## Interfaces read and independently checked

1. Definition 7.1 uses the alternating trace of a specified tame generator
   on balanced-rank representation Grassmannians. It does not use their
   ordinary Euler characteristic, and it does not take phase invariants.
2. Lemma 7.3's trace stratification proof is sound: an orbit of more than
   one stratum contributes an off-diagonal cyclic block, whose trace is
   zero. The return map on an individual stratum need not be trivial.
3. Lemma 7.4's relative Grassmannian formula is sound. After splitting a
   degree-d vertex field, the Schubert cohomology basis is a d-fold tensor
   product. The generator cyclically permutes the factors. The only fixed
   basis tuples are constant tuples, giving binomial(m,e), rather than
   binomial(m,e)^d. Every Schubert degree is even and inertia acts trivially
   on Tate twists over these fields. Thus no omitted Koszul sign occurs.
4. Proposition 11.1 provides a direct check of order dependence. For
   T_m=[[-t^m alpha,-t^m gamma],[1-t^m beta,-t^m epsilon]], elementary
   expansion gives discriminant
   t^m*(-4 gamma+t^m*((alpha-epsilon)^2+4 beta gamma)).
   With independent generic coefficients its valuation is m. The two
   eigenlines are fixed separately when m is even and exchanged when m is
   odd. Their trace is respectively 2 and 0 although their geometric
   number is always two. This independently verifies the displayed
   coefficient change in that proposition.

## Exact scope of the basis claim

Section 8.3 explicitly identifies the algebra spanned by the characters
with the middle cluster algebra, under the stated hypotheses. The text
after Corollary 8.6 explicitly warns that this does not identify the
individual character-basis elements with individual theta functions.
Section 11.1 gives actual full orders changing their coefficients in the
same fixed acyclic Jacobian algebra and fixed weight. Therefore this
paper cannot supply the missing theta identification simply by naming its
basis a ramified cluster basis.

The proof of the full mutation theorem and the complete 87-page chain of
realization and basis results have not been independently re-proved in
this audit. They are not used as lemmas in our Gale construction.

## Use in the present task

Useful: the trace-versus-dimension distinction is a genuine structural
constraint, and compatible tame generators must be retained under field
changes. The local cyclic-Schubert calculation is an audited comparison
point for a future representation-theoretic interpretation.

Not used: no assertion of automatic folding, positivity of arbitrary
monodromy coefficients, equality of the order-dependent basis with theta,
or a finite-dimensional positive module obtained by taking one trace.
Our attached phase construction takes invariants of an actual finite
phase torsor and retains the whole particle-permutation character. This
is a different operation from the monodromy trace in Definition 7.1.

| Audited item | Verdict | Action |
|---|---|---|
| Record, authorship, version, length | Verified on primary sources | Recorded |
| Cyclic-stratum trace lemma | Correct by independent block-trace proof | Comparison only |
| Relative Grassmannian trace | Correct by explicit even Schubert basis | Comparison only |
| Order-dependent coefficient 2/0 | Correct by direct discriminant calculation | Rules out a shortcut |
| Basis equals theta elementwise | Not stated; text explicitly distinguishes them | Do not infer |
| General mutation/basis theorem | Not fully audited here | Not imported |
| Phase-invariant dimension equals monodromy trace | No such implication | Do not use |
