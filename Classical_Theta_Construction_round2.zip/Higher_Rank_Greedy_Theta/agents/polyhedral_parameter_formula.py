"""Exact symbolic chamber polynomials and finite-difference tests.

The proof does not rely on these finite checks.  Sign decisions are frozen at
one sample while all algebraic entries stay symbolic; this is deliberately
separate from evaluating the numerical incoming recursion.
"""
from functools import lru_cache
from itertools import product
from math import factorial, prod, lcm
import json
import random
import time
import sympy as sp
from incoming_recursion import IncomingSchur, box, sub, le


def polynomial_binomial(top, k):
    return prod(top-j for j in range(k))/sp.Integer(factorial(k))


class FrozenChamber:
    def __init__(self, B, g, sample_B, sample_g, D=None, tie_order=None):
        self.B=tuple(map(tuple,B))
        self.g=tuple(g)
        self.n=len(g)
        self.D=tuple(D or [1]*self.n)
        self.zero=(0,)*self.n
        self.sample=IncomingSchur(sample_B,self.D,tie_order)
        self.sample_g=tuple(sample_g)
        self.c=lru_cache(None)(self._c)

    def shift(self,m,q):
        return tuple(m[i]+sum(self.B[i][j]*q[j] for j in range(self.n))
                     for i in range(self.n))

    def _c(self,a,m):
        if not any(a): return sp.Integer(1)
        support=[i for i,v in enumerate(a) if v]
        if len(support)==1:
            i=support[0]
            return sp.expand(polynomial_binomial(-m[i],a[i]))
        S=[q for q in box(a) if q!=a and q!=self.zero and self.sample.sign(a,q)>0]
        v={}
        for s in S:
            v[s]=sp.expand(self.c(s,m)-sum(
                self.c(sub(s,q),self.shift(m,q))*v[q] for q in v if le(q,s)))
        return sp.expand(sum(self.c(sub(a,s),self.shift(m,s))*v[s] for s in S))

    def theta_prefix(self,cap):
        J=box(cap)
        a={self.zero:sp.Integer(1)}
        for p in J[1:]:
            mp=self.sample.shift(self.sample_g,p)
            I=[q for q in J if le(q,p) and (q==p or
                sum(mp[i]*self.D[i]*(p[i]-q[i]) for i in range(self.n))<0)]
            t={p:sp.Integer(1)}
            for q in reversed(I[:-1]):
                t[q]=sp.expand(-sum(t.get(r,0)*self.c(sub(r,q),self.shift(self.g,q))
                                    for r in I if r!=q and le(q,r)))
            a[p]=sp.expand(-sum(t[q]*a[q] for q in I if q!=p))
        return a


def differences(values):
    out=[]
    while values:
        out.append(values[0])
        values=[b-a for a,b in zip(values,values[1:])]
    return out


def symbolic_tests():
    b,u,v=sp.symbols('b u v')
    B=((0,b),(-b,0))
    examples=[]
    for B0,g0,cap in [(((0,2),(-2,0)),(-3,1),(3,2)),
                        (((0,0),(0,0)),(-3,-2),(2,2)),
                        (((0,2),(-2,0)),(-4,4),(2,2)),
                        (((0,2),(-2,0)),(-2,0),(2,2))]:
        F=FrozenChamber(B,(u,v),B0,g0).theta_prefix(cap)
        E=[]
        for p,f in F.items():
            poly=sp.Poly(f,b,u,v)
            assert poly.total_degree()<=sum(p)
            cleared=sp.Poly(f*prod(factorial(x) for x in p),b,u,v)
            assert all(c.q==1 for c in cleared.coeffs()),(p,f)
            num=IncomingSchur(B0).theta_prefix(g0,cap).get(p,0)
            assert f.subs({b:B0[0][1],u:g0[0],v:g0[1]})==num
            if f:
                E.append({'p':p,'polynomial':str(sp.factor(f)),
                          'degree':poly.total_degree(),
                          'coordinate_factorial':prod(factorial(x) for x in p)})
        examples.append({'sample_B':B0,'sample_g':g0,'cap':cap,'coefficients':E})
    return examples


def ray_tests(seed=132026, count=72):
    rng=random.Random(seed)
    examples=[]
    negative=[]
    checks=0
    for trial in range(count):
        n=2 if trial<count//3 else 3
        D=(1,)*n
        if n==2:
            b=rng.randint(-4,4)
            B=((0,b),(-b,0))
            cap=(3,3)
        else:
            x,y,z=[rng.randint(-3,3) for _ in range(3)]
            B=((0,x,y),(-x,0,z),(-y,-z,0))
            cap=(2,2,1)
        g=tuple(rng.randint(-5,5) for _ in range(n))
        maxdegree=sum(cap)
        values={p:[int(not any(p))] for p in box(cap)}
        for t in range(1,maxdegree+4):
            F=IncomingSchur(tuple(tuple(t*v for v in row) for row in B),D).theta_prefix(
                tuple(t*v for v in g),cap)
            for p in values:
                values[p].append(F.get(p,0))
        for p,vals in values.items():
            diffs=differences(vals)
            assert all(x==0 for x in diffs[sum(p)+1:]),(B,g,p,vals,diffs)
            if min(diffs[:sum(p)+1])<0:
                neg={'B':B,'g':g,'p':p,'values':vals,
                     'newton_coefficients_at_zero':diffs[:sum(p)+1]}
                negative.append(neg)
                if len(negative)==1:
                    examples.append(neg)
            checks+=1
        if trial%12==0:
            print(json.dumps({'progress':trial,'checked_coefficients':checks,
                              'negative_newton':len(negative)}),flush=True)
    return {'rays':count,'coefficient_checks':checks,
            'negative_newton_coefficients':len(negative),
            'first_negative_examples':negative[:8],
            'degree_and_zero_ray_checks':'PASS'}


def positive_compositions(total,parts):
    if parts==0: return [()] if total==0 else []
    if parts==1: return [(total,)] if total>=1 else []
    return [(first,)+rest for first in range(1,total-parts+2)
            for rest in positive_compositions(total-first,parts-1)]


def clone_support_coefficient(B,g,p,k,D=None):
    """The coefficient A_{p,k}, with every clone used at least once."""
    D=D or [1]*len(B)
    ids=[i for i in range(len(B)) for a in range(k[i])]
    if not ids: return int(not any(p))
    Bl=[[B[i][j] for j in ids] for i in ids]
    gl=tuple(g[i] for i in ids)
    Dl=tuple(D[i] for i in ids)
    R=IncomingSchur(Bl,Dl)
    answer=0
    for blocks in product(*[positive_compositions(p[i],k[i]) for i in range(len(B))]):
        root=sum(blocks,())
        answer+=R.theta_prefix(gl,root).get(root,0)
    return answer


def replication_tests():
    examples=[]
    input_data=[([[0,2],[-2,0]],(-2,1),(3,2),(1,1)),
                ([[0,3],[-2,0]],(-2,1),(2,3),(2,3)),
                ([[0,2,-2],[-2,0,2],[2,-2,0]],(-1,-1,-1),(2,2,1),(1,1,1)),
                ([[0,2,-2],[-1,0,1],[2,-2,0]],(-2,-1,1),(2,1,2),(1,2,1)),
                ([[0,1,0,-2],[-1,0,2,0],[0,-2,0,1],[2,0,-1,0]],
                 (-1,-1,-1,-1),(2,2,1,1),(1,1,1,1)),
                ([[0,1,0,0,-1],[-1,0,1,0,0],[0,-1,0,1,0],
                  [0,0,-1,0,1],[1,0,0,-1,0]],
                 (-1,-1,-1,-1,-1),(2,1,1,1,1),(1,1,1,1,1))]
    count=0
    for B,g,cap,D in input_data:
        n=len(B)
        variables=sp.symbols('r0:'+str(n))
        Bs=[[variables[i]*B[i][j] for j in range(n)] for i in range(n)]
        gs=tuple(variables[i]*g[i] for i in range(n))
        Fs=FrozenChamber(Bs,gs,B,g,D).theta_prefix(cap)
        for p,F in Fs.items():
            terms=[]
            reconstructed=sp.Integer(0)
            for k in box(p):
                if any((p[i]>0 and k[i]==0) or (p[i]==0 and k[i]!=0) for i in range(n)):
                    continue
                A=clone_support_coefficient(B,g,p,k,D)
                assert A>=0,(B,g,p,k,A)
                if A:
                    terms.append({'k':k,'A':A})
                    reconstructed+=A*prod(polynomial_binomial(variables[i],k[i]) for i in range(n))
            assert sp.expand(F-reconstructed)==0,(B,g,p,F,terms)
            P=sp.Poly(F,*variables)
            assert all(P.degree(variables[i])<=p[i] for i in range(n))
            if p==cap:
                examples.append({'B':B,'D':D,'g':g,'p':p,
                                 'polynomial':str(sp.factor(F)),
                                 'positive_binomial_expansion':terms})
            count+=1
        for r in [(2,)*n,tuple(i+1 for i in range(n))]:
            scale=lcm(*r)
            Bf=[[r[i]*B[i][j] for j in range(n)] for i in range(n)]
            Df=[scale*D[i]//r[i] for i in range(n)]
            gf=tuple(r[i]*g[i] for i in range(n))
            Fn=IncomingSchur(Bf,Df).theta_prefix(gf,cap)
            for p,F in Fs.items():
                assert F.subs(dict(zip(variables,r)))==Fn.get(p,0)
    return {'symbolic_replication_coefficients':count,
            'polynomial_equals_clone_support_binomial_sum':'PASS',
            'examples':examples}


if __name__=='__main__':
    started=time.time()
    result={'symbolic':symbolic_tests(),'rays':ray_tests(),
            'replication':replication_tests(),
            'seconds':time.time()-started}
    path=__file__.replace('.py','_results.json')
    with open(path,'w') as f: json.dump(result,f,indent=2)
    print(json.dumps({'output':path,'seconds':result['seconds'],
                      'ray_summary':result['rays']},indent=2))
