# Independent proof review of the valued attached Gale algebra

Reviewer: `valued_gale_independent_review`. Begun 2026-11-13 13:14 UTC.
This is a proof-level review, with independent derivations below. The target
is classical two-input reordering. No Li--Pan result is used.

## 1. Current conclusion and source inspection

The phase descent, whole-factor comparison and Young-positivity theorem in
`valued_gale_attached_theorem.md`, Sections 1--7, survives this independent
review. Several compressed steps need the explicit lemmas in Sections 3--5
below; in particular, a constant dimension or a set-theoretic comparison
would not suffice. I found no counterexample to the claimed theorem and
did not use its computation totals as a proof. The separate wall-function
identification for determinant kappa also passes the independent review
recorded in Sections 8--10 below. No arbitrary-valued theta statement
follows merely from this two-input theorem.

Primary source read independently: Qiyue Tang, *Another Proof of Laurent
Positivity for Generalized Cluster Algebras*, Hexagon 2611.00238v1,
November 9, 2026, 41 pages,
<https://hexagonmath.org/pdf/2611.00238v1>.
The work page gives v1 as current and the exact deposit date:
<https://hexagonmath.org/2611.00238v1>.

I read the finite-map and center proof (Section 3), cut initial ideal and
complete positive factor (Section 4), the full completion lemma, coupled
family, universal unit deformation and nilpotent-factor comparison
(Section 5), and the entire Hermite-interpolation Young lemma (Section 6).
The paper is used for these explicit local proofs, not for its concluding
arbitrary-rank claims. The proof below checks precisely which parts survive
complete gain packets and determinant kappa.

## 2. Valuation, center and sign calculations

Write ell=lcm(d_A,d_B), M=m/ell, A=ka, B=kb and
N_A=P+mkb, N_B=Q+mka. The assumption gcd(a,b)=1 implies
kappa=gcd(d_A a,d_B b) divides ell, prime by prime. Thus m>=kappa.

For a nonempty subset with counts (u,v),

    b(N_A u-N_B v)=N_A(bu-av)+kappa v.

If Delta=bu-av<0, the right side is at most -N_A+kappa kb<0.
For positive Delta it is positive. If Delta=0 then (u,v)=h(a,b)
and N_Au-N_Bv=kappa h>0. This proves all required nonvanishing;
no determinant-one identity is used.

For the independent-target moment map, suppose a valuation ring solution
has minimal negative coordinate valuation nu. Group coordinates with
that valuation by their nonzero residual ell-th powers. In the quotient
of the first-color and second-color equations of one group, all internal
mixed factors cancel, even though individual linear factors have different
root-of-unity gains. Every external mixed packet has valuation m nu.
The quotient has valuation nu D_0, whereas its target is a unit. This is
impossible. All coordinates are consequently integral; their equations
also keep the extension inside the preimage of the target torus. The DVR
valuative criterion for the finite-type separated map proves properness,
and affineness proves finiteness.

On the central curve the same quotient gives nu D_0=Delta val(T).
The sign assertion excludes poles. For an all-positive valuation tuple,
the minimal valuation is at least 1/max(ka N_A,kb N_B). Thus a small
rational epsilon genuinely separates the whole family and the all-zero
core after homogeneous scaling of all arrow forms.

For a nonzero center c=x_i^ell=y_j^ell, the residue cluster has charge
h(a,b). After raising its equation quotient to the ell-th power, its
framing contribution is (-1)^(Q b h ell)c^(kappa h). Its interaction
with an external balanced cluster of charge j(a,b) contributes
(-1)^(mab h j). Hence

    c^(kappa h)=(-1)^(Q b h ell+mab h(k-h)).

This independently confirms the displayed center polynomial F_k of the
main note. It holds also for interactions with the zero cluster. A
projective boundary point above T=0 would produce a normalized curve
with a coordinate pole; this was excluded. The special support is finite,
and the horizontal closure is finite near T=0. Its completion is finite
and T-torsion-free, hence free over the DVR. All-zero, all-nonzero and
mixed sectors are actual idempotent factors of this completion.

In the s-coupling, a core center c and attached center d contribute
(s^ell c-d)^(Mab h j)/(d-s^ell c)^(Mab h j), whose ell-th power is the
same sign as above. Inverting the cross packets makes this calculation
legitimate. It follows that the finite support remains independent of s.

At s=0 the attached exponents become P'=P+mrb and Q'=Q+mra. The
second equation differs from the standard one by
(-1)^((M-m)ra). This sign is real and cannot be omitted. Two nonzero
constant target units can be removed by scaling all particles by lambda
and T by mu. The exponent matrix is

    [[P'+mlb,-b],[Q'+mla,-a]],

of determinant -kappa. It defines a surjective isogeny of complex
two-tori. Choosing a preimage gives an equivariant algebra isomorphism
preserving the selected valuation factors. No canonical root is claimed.

## 3. A detailed finite-family lemma

Let K have characteristic zero, let F_1,...,F_N,h be polynomials in
K[s,T,z_1,...,z_N], and put

    A_0=K[s,T,z,h^-1]/((F_1,...,F_N):T^infinity).

Assume A_0/TA_0 is finite over K[s]. Set R=K[s][[T]], S=R[T^-1]
and B=lim A_0/T^j A_0. Then:

1. B is a finite R-algebra.
2. The map A_0 tensor R -> B is a surjective flat map, hence selects a
   genuine idempotent direct factor.
3. B[T^-1] is finite locally free over the connected regular
   one-dimensional ring S.
4. A finite group preserving the equations and localization, and fixing
   s,T, has equal characters on the s=0 and s=1 generic fibers.

Here are the necessary algebraic details. Lift finitely many K[s]-module
generators of A_0/TA_0 to A_0. Successive reduction modulo powers of T
expresses every element of B as an R-linear combination of those same
lifts. Thus B is finite and the indicated completion map is surjective.
It is flat because it is Noetherian completion. A flat quotient has
kernel I satisfying I/I^2=0; Noetherianity makes I finitely generated,
so I is generated by an idempotent. This proves item 2 without assuming
flatness of the desired square-system family.

T lies in the Jacobson radical of R, since 1-Tf has a power-series
inverse. Its maximal ideals are (T,g(s)), with g irreducible. Their local
rings have dimension two and are regular, with the displayed two
generators. Every prime avoiding T has height at most one. S is thus a
regular integral domain of dimension one; for example (s) survives.

After T is inverted, saturation disappears. At a maximal point of the
selected factor, localize S[z,h^-1]. The resulting local ring D is regular
of dimension N+1, since its base is a DVR and the closed fiber is an
N-variable polynomial ring at a closed point with finite residue field.
The selected local ring is D/(F_1,...,F_N). If pi is the base
uniformizer, finiteness makes D/(F_1,...,F_N,pi) Artinian and nonzero.
These N+1 elements form a system of parameters in the regular local ring,
and therefore a regular sequence. In particular pi is a nonzerodivisor
modulo the N equations. The finite selected module is torsion-free over
each base DVR, hence free. This proves item 3.

After a finite splitting-field extension, the group isotypic summands
are projective of constant rank on the still-connected base. Evaluation
s=0 or 1 takes S to K((T)), so these ranks, and hence all character
values, agree. This is stronger than equality of total lengths.

For the gain-coupled equations the hypothesis is verified scheme
theoretically: on reduced special support, core coordinates vanish and
attached coordinates belong to a fixed finite nonzero root set. The
localization denominator takes only finitely many nonzero constant
values. Every generator and the inverse denominator therefore satisfy
monic polynomials modulo the nilradical. A power of each monic equation
kills the nilpotent error, since the ring is Noetherian. Thus the full
special algebra, including nilpotents, is finite over K[s].

The endpoint identification also retains all nilpotents. In any full
Artin local factor of an endpoint, each coordinate operator is an
integral scalar plus a nilpotent operator; inverse denominator operators
are integral because their residual values are units. The generated
operator algebra is finite over the complete valuation ring, and the
map extends through completion. Conversely a factor of the completion
has precisely the prescribed special support. This proves equality of
the whole selected factors, not merely of their geometric points.

## 4. Gain Rees sections and arbitrary unit base change

For a generic stability of an acyclic rooted graph, the graph-cut lattice
L=im(partial*) is saturated in Z^E. Its weight initial ideal is the
forbidden outgoing-cut monomial ideal. One can prove this directly by
decomposing an integral vertex potential into threshold indicators: a
maximum-weight monomial of a lattice binomial contains a forbidden cut;
tied binomials have both terms in the cut ideal. Grouping general
polynomials by quotient-lattice degree proves the full initial-ideal
claim, not just the assertion for chosen generators.

The cut complex is the dual boundary of the simple generic flow
polytope, allowing ghost vertices. Its facets are complements of stable
spanning trees. A gain-incidence matrix restricted to any rooted tree
has determinant a nonzero signed product of gains, by leaf elimination.
The kernel of the full gain-incidence map is therefore a regular LSOP
of the Stanley--Reisner ring. This is the only replacement needed for
the ordinary unimodular-incidence step in Tang's proof.

Now let R_0 be a Laurent-polynomial ring of unit parameters and let
chi:L->R_0^* be a monomial-valued character preserved by the finite
group. Saturation of L lets chi extend to Z^E. Diagonal multiplication
by these extended units untwists the lattice/Rees ideal, so its special
initial ideal stays the same cut ideal. Crucially, the gain linear
relations are kept in their original coordinates. One must not infer
that the entire cut section is unchanged under that diagonal change.

Complete the twisted Rees ring at (t,arrows) and then impose those gain
linear relations. Before the section t is regular. Modulo t the linear
relations form the same regular LSOP after scalar extension to R_0 and
completion. They lie in the Jacobson radical, so local permutability of
regular sequences makes t regular after the section. Modulo t the
result is the fixed finite cut algebra H tensor R_0. Its arrow ideal
is nilpotent, so the completed topology is t-adic. Lift a polynomial
basis of H. Successive reduction proves generation over R_0[[t]];
cancelling t in a relation repeatedly proves independence. Averaging
the lift gives an equivariant module isomorphism

    U = H tensor R_0[[t]].

The same polynomial basis lifts make the completion map surjective;
flatness gives a genuine idempotent factor as in Section 3. Therefore
both this product decomposition and the module trivialization survive
arbitrary base change, including into a nonreduced attached algebra.

For the decoupled gain system the two substituted units are products of
attached ell-th powers, with a constant sign. They are invariant under
the attached permutation group (and its phase group), so the attached
group acts trivially on the chosen universal core basis. Tensor-product
characters follow.

To identify this base-changed factor with the full decoupled core factor,
let A_K be the core moment algebra over the generic attached algebra D_K.
It is finite over D_K by the independent-target moment-map argument.
Reduce D_K by its nilradical. On each resulting field factor the units
and their inverses are integral, hence have valuation zero. The valuation
gap and the full positive-factor statement identify the two selected
idempotents over each field. Their difference is therefore in a
nilpotent ideal of A_K. Two idempotents in a commutative ring that agree
modulo a nilpotent ideal agree exactly: e(1-f) and f(1-e) are nilpotent
idempotents and must vanish. This supplies the missing scheme-level
justification for the tensor-product comparison.

## 5. Whole-factor characters and phase descent

The adjacent generic framed cut algebras have identical ordinary and
full-gain characters by the equivariant Koszul formula. The group here
is S_A times S_B, which preserves arrow orientation and the individual
gain labels; no edge-reversal issue is needed for this step. In the
representation ring, ker(gain incidence) equals the fixed arrow
permutation representation minus the fixed nonroot vertex representation.
Its exterior-power character is independent of the gain values. Both
full and core central algebras therefore agree in ordinary/gain character.

The separation of Sections 2--4 yields, for either system,

    [B(P,Q,k)] = sum_(r+l=k) Ind_(G_r x G_l)^G_k
                   ([C(P,Q,r)] tensor [D(P+mrb,Q+mra,l)]).

The summands are actual sectors indexed by the zero-coordinate labels.
Induction simultaneously over k and all admissible P,Q now proves
[D_gain]=[D_raw]. The r=0 term is the desired D; every other attached
degree is smaller and the shifted framings retain all divisibilities
and determinant kappa. Subtraction is used to prove a comparison of
already defined finite factors, never to define those factors.

For u_i=x_i^(d_A), v_j=y_j^(d_B), the polynomial extension is finite
free with its canonical bounded-monomial basis W. Flat base change
commutes with J:T^q for every q by the exact sequence of multiplication
by T^q, hence with T-saturation; Noetherianity stabilizes the latter.
It also commutes with specialization. The final root-variable and
invariant-variable products have the same nonvanishing locus, so their
infinite saturations agree after extension. Therefore

    D_gain = Q[x,y] tensor_(Q[u,v]) D_val.

This is an actual equivariant finite free extension, and its phase
invariants are D_val. On the attached factor each coordinate is a unit,
so the power maps are finite etale; the extension is a phase torsor.
For a particle permutation, bounded-monomial exponents must be constant
along each cycle. Thus the trace multiplier is
d_A^(number of A cycles) d_B^(number of B cycles), proving all-cycle
normalization from an actual module. It does not normalize individual
flow-tree summands.

## 6. Young positivity and its constructive content

The relevant source lemma applies to an equivariant polynomial map
F:V->V where V is a sum of coordinate permutation representations, and
to a finite union of full isolated local factors. It is not an arbitrary
statement about a finite algebra with group action.

Perturb each color by one polynomial of degree less than its number of
coordinates. On a fixed coordinate-equality stratum, values at distinct
blocks make the block equations universally transverse. The incidence
variety has the dimension of the parameter space; its nondominating or
non-etale image lies in a proper closed subset. The full Jacobian also
has one scalar eigenvalue on the standard representation of each repeated
block. If a color has d distinct blocks and r repeated blocks, d+r is
at most its number of coordinates. Hermite interpolation independently
controls the d values and r relevant derivatives. Each vanishing
standard-block eigenvalue thus also has a proper bad image. Finitely
many equality strata leave a nonempty good parameter open set.

Choose a one-parameter line meeting it. Isolate the original full factor
using an invariant polynomial lift of its idempotent and complete.
The square system plus the deformation parameter forms a regular
sequence locally, proving finite freeness. The completion is a direct
factor of the polynomial zero algebra, so the generic selected fiber
is reduced. Its points are coordinate tuples, whose stabilizers are
exactly Young subgroups. Equality of all characters across the finite
free family proves the claimed Young-permutation decomposition.

For D_val the generic attached factor is exactly of this form, by
Sections 2--3. This proves its ungraded h-positivity. The construction
is effective by rational parameter enumeration plus the Groebner
Jacobian test, but it does not provide a canonical graded monomial
basis. The tensor-product phase factor itself is not a permutation
basis for the graded algebra.

## 7. Independent actual computation

The actual Wolfram plugin directly performed both saturations for the
first nontrivial four-particle ordinary system, a=b=m=1, k=2, P=2,Q=1.
The horizontal ideal has thirteen elimination generators. The attached
special ideal has a six-element standard monomial basis

    1, y_2, y_2^2, y_2^3, y_2^4, x_2.

Normal-form substitution for the identity, A swap, B swap and both swaps
gave the character (6,4,4,2). Its double-sign multiplicity is zero.
This retains full nilpotent lengths and checks genuine nonidentity traces,
rather than comparing dimensions inferred from a wall coefficient.

An attempted nine-sector Wolfram batch for the squared map returned an
internal tool error, with no answer. It is not counted as successful
verification. The successful raw receipts and this error are preserved
in `computations/valued_gale_review/wolfram_receipts.json`.

## 8. Independent review of the determinant-kappa framing identity

The companion `valued_gale_wall_identification.md` was read in full. I
independently opened the published Franzen--Reineke source,
<https://msp.org/ant/2018/12-5/ant-v12-n5-p01-p.pdf>, and read the
Theorem 6.2 HN-section argument and Theorem 8.1 forbidden-shuffle kernel
proof. The source explicitly allows arbitrary quivers and non-generic
stabilities in Theorem 6.2. The symmetric-quiver conclusions of its
Section 9 are not needed. The arXiv v2 URL did not load in this review;
the published primary PDF did.

The based multiplication convention is eta(d,e)=chi(e,d)-chi(d,e),
with X^d X^e=v^eta X^(d+e). The shuffle degree shift is -chi(d,e), so

    chi(d+e,d+e)+2(i+j-chi(d,e))
      =chi(d,d)+2i+chi(e,e)+2j+eta(d,e).

This directly checks the descending HN exponent. For the framed graph,
eta(delta,d)=P A(d)-Q B(d)=k kappa on the central slope. The common
frame variable contributes v/(1-v^2); moving X^delta to the left
multiplies by v^(-PA+QB), so the residual finite chamber polynomial
has Euler multiplier v^(chi(d,d)-2PA). This independently verifies both
the scalar and the commutator U z=v^(-2 kappa) z U.

There is a small chamber-comparison detail worth spelling out. For a
framed total (k(a,b),1), the positive refined total slope is
epsilon k kappa/(k(a+b)+1). On an unframed subvector r(a,b), the
centered framing functional is

    kappa r - [k kappa/(k(a+b)+1)] r(a+b)
      = kappa r/(k(a+b)+1)>0.

Thus the positive refinement gives the forbidden balanced subsets of the
core chamber. Noncentral subvector signs are unchanged for sufficiently
small epsilon at the fixed degree cutoff. Subsets containing the frame
are handled by the complementary subset. This is equality of the
complete forbidden-split systems, not just an order comparison of total
charges. The negative refinement yields the full-family chamber.

At frame degree one, the old central HN factor is therefore expressed
as H T_after=T_before H. Canceling the common scalar and z gives

    A_before=A_after H(v^(-2 kappa)U)/H(U).

The unframed H is independent of the framing. Determinant-one positive
framings make F_1=H(v^-2 U)/H(U) coefficientwise Laurent-polynomial,
because A_after has constant coefficient one and both finite chamber
series have Laurent-polynomial coefficients. Hence the exact telescoping
product

    H(v^(-2 kappa)U)/H(U)
       = product_(j=0)^(kappa-1) F_1(v^(-2j)U)

has classical specialization f(U)^kappa. This is an ordinary product of
commuting central series. There is no plethystic-power substitution and
no omitted block-permutation sign.

The two-input identification itself is also sign-consistent. For
gamma=(a,b) and w=(R,S), put K=m(aS-bR). Then eta(gamma,w)=-K,
and conjugation by H gives X^w H(v^(-2K)U)/H(U). The one-vertex series
E_v satisfies E_v(v^-2 z)=(1+v^-1 z)E_v(z), so the classical axis
operations are y->y P_alpha(x)^m and x->x Q_beta(y)^(-m).
Equivalently, the classical Hamiltonian bracket is written with K=-eta
in this dictionary. This last sign should be stated if the Hamiltonian
formulas are reused independently of the displayed axis operations.

## 9. Why the conclusion is the whole Frobenius characteristic

Fix an alphabet multiplicity vector d, of total bidegree (ka,kb), and
its Young subgroup W_d. Let Delta_d be the product of same-color
Vandermondes. The forbidden thin-cut ideal J is stable under W_d.
For a fixed forbidden particle subset, its cut polynomial is invariant
under the two packet subgroups. Alternating a general multiple first
within these two packets yields Delta_e Delta_f times an arbitrary
packet-invariant polynomial. Alternating over the remaining shuffles
and dividing by Delta_d yields precisely the colored shuffle kernel,
including its denominator of same-color cross-packet differences.
Summing over all forbidden subsets proves

    J intersect P_all^(sgn W_d) = Delta_d I.

Every alternating polynomial is Delta_d times an invariant polynomial,
and the finite-group alternating projector is exact in characteristic
zero. Thus multiplication by Delta_d identifies the colored shuffle
quotient with the entire sign-isotypic thin-cut quotient. This proves
both inclusions, rather than only showing that shuffle images vanish.
The free frame coordinate can be subtracted before setting it to zero,
because all ordinary factors are differences and Delta_d omits it.
The degree shift is sum_i binomial(d_i,2); twice this is the difference
between colored and thin Euler normalizations.

For a G_k-module E, the coefficient of the alphabet monomial of
multiplicity vector d in omega_A omega_B ch(E) equals
dim Hom_(W_d)(sgn_(W_d),E). This follows by expanding each power sum in
the Frobenius average and regrouping by label colorings. As d and the
finite alphabets vary, these are all monomial-symmetric coefficients.
Alphabets of sizes at least ka and kb already distinguish them. Thus
the framed identity recovers the complete symmetric function and every
permutation-cycle trace; it is much stronger than one alternating
dimension.

This argument only requires the colored HN Hilbert identities. It does
not assert that the sections chosen in Franzen--Reineke's proof are
canonical or equivariant under a particle group. The all-Young-subgroup
Vandermonde construction is the separate exact mechanism recovering
equivariance here.

Comparing this full-character framed identity with the independently
proved core/attached decomposition, by induction simultaneously over
all positive framings of the same determinant, gives

    omega_A omega_B ch D_raw(P,Q,k) = [U^k] f(U)^kappa.

The framing shift preserves kappa and lowers the attached degree in
every non-leading term, so this induction has no circular degree step.

## 10. Valued normalization and the precise resulting theorem

The phase character identity means exactly that rho_D sends each power
sum p_j(alpha) to p_j(alpha)/d_A and p_j(beta) to p_j(beta)/d_B.
This map commutes with omega because both are diagonal in the power-sum
basis. No assertion that omega commutes with signed Adams operations is
used. Consequently the actual finite algebra satisfies

    omega_A omega_B ch D_val(P,Q,k)
        = [U^k] rho_D(f(U))^kappa.

Applying rho_D to the incoming Hamiltonians divides their logarithms
by d_A and d_B. Uniqueness of finite-degree ordered reordering makes
this coefficient-ring substitution commute with the formal factorization.
The resulting inputs have powers m/d_A and m/d_B, and the output with
function f_val=rho_D(f)^kappa has exponent

    m(aS-bR)/kappa

on x^R y^S. These integers are valid because kappa divides m. In the
ambient lattice the corresponding normal is D(a beta_A+b beta_B)/kappa.
Its primitive normalization multiplies the wall function by the positive
integer power d(a beta_A+b beta_B)/kappa. Thus the actual phase algebra
realizes all coefficients of the correctly normalized valued two-input
ray factor, including every positive multiple of its primitive slope.

This closes the stated local wall theorem after independent review. Its
new content is the direct complete-gain/phase finite algebra and its
whole-character comparison. It is not a first proof of valued
positivity: Tang's original Section 9.2 already treats arbitrary
skew-symmetrizable ambient normals by an enlarged lattice, inputs
P_1(x^v),P_2(y^u), permitted zero specialization of absent coefficients,
and a positive integral normal power. BLM's earlier general positivity
is also prior work.

The reviewed local theorem still does not construct a many-slope
incoming primitive functor, identify a singular IH stalk with an
attached factor, or prove arbitrary-valued global theta coefficients
come from the proposed graph/tableau objects. Those are distinct next
interfaces, not consequences to insert without a proof.
