# Reddening / incoming-normalization branch report

2026-11-13. This branch is complete and releases its research slot.

## Main result

The previous package already handled negative frames, finite negative
products and certain folded covers. Repeating a reddening extension would
therefore have duplicated previous work. Reading those actual proofs led
instead to a coefficientwise construction valid for **every integral
skew-symmetrizable exchange matrix**.

The new construction removes the external certificate from the total
transport matrix C. For a nonaxis positive root alpha, take the incoming
direction B alpha and use a lexicographic infinitesimal perturbation within
alpha^perp. The signs use only B,D,alpha and integer cross products. The
incoming factor on that ray is the identity. Hence the degree-alpha
coefficient is fixed by strictly smaller root intervals.

The preferred implementation is particularly short. Let

    S_alpha={0<q<alpha : sigma_alpha(q)>0},
    C_(s,q)=c_(s-q)(m+Bq).

Then

    c_alpha(m)=C[alpha,S_alpha]
                  C[S_alpha,S_alpha]^(-1) C[S_alpha,0].

For alpha=k e_i the leaf value is binom(-m_i,k). Every entry on the
right of the displayed identity has smaller total root degree. Expand
the unitriangular inverse as finite strict chains to obtain a formula
using only integers, binomial coefficients, halfspaces, and finite chains.

Combining this with the previous last-exponent halfspace formula computes
any prescribed formal theta coefficient in finite time from B,D,g,p.
No wall enumeration, mutation search, negative frame, cover or theta oracle
is an input. The proof identifies the construction with theta by the
established GHKK incoming-factor theorem and the previous last-exponent
lemma.

**Exact scope:** arbitrary classical skew-symmetrizable B, arbitrary label
g, and an arbitrary prescribed finite coefficient prefix. This is not a
proof that all formal theta functions are Laurent polynomials. It does
not give a finite basis of A or U in arbitrary type. A finite carrier is
still required to declare that the complete polynomial has been computed.
The intermediate integer weights can be negative; a cancellation-free
positive greedy model remains a separate problem.

## Files, in reading order

| File | Purpose |
|---|---|
| `INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md` | Complete construction, proof, radical case, D convention, halfspace extraction, and novelty boundaries. Section 3.1 is the shortest usable formula. |
| `incoming_recursion.py` | Two independent implementations: `IncomingRecursion` uses finite signed factors; `IncomingSchur` uses only one halfspace principal submatrix. Both expose `c(alpha,m)` and `theta_prefix(g,cap)`. |
| `incoming_recursion_initial_checks.json` | Direct acyclic closed-form comparisons and corrected Kronecker imaginary-direction theta prefixes. |
| `verify_incoming_recursion.py` | Independent comparison to the old folded Markov transport, multiplicativity, tie independence, and vertex relabeling. |
| `incoming_recursion_extended_checks.json` | Exact results of that comparison; also records a genuinely cyclic 3-arrow formal prefix without a finiteness claim. |
| `verify_schur_recursion.py` | Independent equality check of signed-factor and Schur versions. |
| `incoming_schur_checks.json` | Exact 936-entry comparison and theta prefix comparisons. |

All files are under
`/workspace/scratch/6791391cdece/higher_rank_greedy_theta/agents/`.

## Verification and independent review

1. 516 transport entries agree with the earlier direct acyclic binomial
   formula. The cases include nontrivial symmetrizers. The corresponding
   1,893 proper parallel-root residuals vanish exactly.
2. The three Markov labels -e_i agree with the previously computed folded
   seven-term polynomials on [0,3]^3. Another 81 arbitrary-exponent total
   transport entries agree with direct substitution into those independent
   folded generators.
3. Four general-risk classes—cyclic three-arrow, genuinely valued cyclic,
   disconnected with an isolated vertex, and zero exchange matrix—pass
   324 multiplicativity and tie-order comparisons and 108 relabeling
   comparisons.
4. The two separately coded recursion forms agree on 936 transport entries
   and four full prescribed theta prefixes.
5. The separate `incoming_independent_audit` agent reports a rational
   Lie-logarithm/matrix-exponential reconstruction agreeing on 2,016 entries
   in eight cases, with different pivot and tie choices. It also checked
   the GHKK convention: for L=lcm(D_i), take d_i=L/D_i and epsilon=B^T;
   then the incoming mutable direction is B alpha and the normal pairing
   is alpha^T D m/L. The audit's own report is maintained by that agent
   and the parent rather than duplicated here.

These computations were chosen to detect sign, radical, valued-lattice,
integer-normalization and truncation mistakes. The proof is in the theorem
file; the finite checks do not replace it.

## Literature and route record

### Used: classical incoming factors

GHKK, *Canonical bases for cluster algebras*, version
https://arxiv.org/pdf/1411.1394v2 . Definition 1.11 fixes the incoming
direction. Proposition 1.20 makes the incoming-factor map a bijection
order by order. Theorem 1.21(1) identifies the local ray factor near the
incoming direction. These are the precise external inputs. Their scope
includes the skew-symmetrizable principal setting. The integer recursion
above is an explicit realization of the inverse map, not a claim to have
discovered the incoming-factor principle.

### Useful context, not an extension achieved here

Fan Qin, *Bases for upper cluster algebras and tropical points*,
JEMS 26 (2024), https://ems.press/content/serial-article-files/47257 .
Theorem 1.2.4 / 6.3.1 identifies cluster and stability scattering for
skew-symmetric injective-reachable seeds. Proposition 3.4.8 and Definition
3.4.4 describe support dimensions. Its general basis theorem permits
different bases with identical tropical leading behavior, so that behavior
alone cannot identify theta. Section 6.3 explicitly refers to Bridgeland's
formula for some theta functions; it does not say every theta is an
ordinary quiver-Grassmannian character.

### Earlier route revised after reading actual previous materials

Initial proposal: derive finite coefficients from a reddening word and
double-pointed support bounds. This was abandoned as a new contribution
because the previous package already supplies a stronger negative-product
construction. The actual unresolved input was C for classes with no
covering negative certificate. Incoming normalization addresses exactly
that input instead of adding more cases.

### Polytope-only selection is insufficient

The Kronecker family provides a precise diagnostic: the generic powers
z^m and normalized Chebyshev theta elements have identical Newton hulls
but different coefficients for m>=2. At m=2 the difference is 2. This is
consistent with Qin's deformation space of compatibly pointed bases.
Therefore support dimensions or convex hulls alone do not select the
desired basis. No new general theorem was based on this observation; it
was used to keep the representation-theoretic route from silently
identifying the generic basis with theta.

Primary context sources:

- Dupont, *Generic Variables in Acyclic Cluster Algebras*,
  https://arxiv.org/abs/1006.0166 .
- Cheung–Gross–Muller–Musiker–Rupel–Stella–Williams,
  *The greedy basis equals the theta basis*,
  https://arxiv.org/abs/1508.01404 .
- Mandel–Qin, *Bracelets bases are theta bases*,
  https://arxiv.org/abs/2301.11101 .

### Recent searches and exclusions

Queries covered theta/reddening coefficient formulas, incoming integer
recursions, halfspace extraction and Schur complements. No identical
complete two-stage formula was located in this limited search. This is
not an exhaustive priority certificate. The search did locate recent
quantum/generalized-cluster manuscripts, including the user's 2026
finite-quantum-theta posting at https://hexagonmath.org/2610.00201v1 and
a November 2026 generalized quantum item. They were **not used**: the
present result has classical inputs already established by GHKK. No
2026 statement has been admitted without proof review. Li–Pan results
are not used anywhere in this branch.

## Remaining meaningful next steps

1. Use the universal incoming Schur recursion to attack cancellation among
   signed finite chains, retaining the actual general g and B parameters.
2. Determine finite support by an independent general mechanism, or give
   a rigorous obstruction; never infer finiteness from a long zero tail
   in a computed prefix.
3. Audit how a polyhedral model must retain multiplicities and open faces;
   a convex Newton hull cannot by itself encode the coefficients.

The parent has a separate proposed negative-degree obstruction for cyclic
three-arrow seeds. This branch does not use or certify that argument; its
unconditional prefix construction continues to make sense whether or not
the resulting formal theta series is finite.
