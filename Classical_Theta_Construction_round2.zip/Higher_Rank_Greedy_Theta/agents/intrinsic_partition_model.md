# Direct set partitions and actual coefficient-space matrices

Branch `intrinsic_partition_model`, 2026-11-13, beginning 11:56 UTC.
Only classical cluster algebras are considered. The direct skeleton algorithm
accepts skew-symmetrizable input. The natural global vector-space construction
in this note is restricted to skew-symmetric input.

## Result and precise boundary

The auxiliary procedure “list positive binary flow trees, then contract their
zero original-color times” has been replaced by a memoized recursion on
**unordered finite set partitions**. Its construction imports neither binary
flow enumeration, scattering diagrams, broken lines, wall coefficients, nor
theta coefficients. The only input is `B,D,g,p`, together with an explicitly
fixed ordering of the original-color infinitesimals.

The recursion is equivalent to the contracted binary construction. Its proof
uses the already established local acyclic refinement/IH comparison, stated
precisely in Section 4 below. This equivalence is not offered as a new
flow-tree theorem: the earlier literature already contains the planar
nontrivalent geometry. The implementation removes the binary and
packet-infinitesimal layers from the actual definition of the objects.

For skew-symmetric `B`, actual local fan matrices are now assembled into
actual matrices on the entire direct sum of tensor products. The proposed
coefficient space is the simultaneous negative eigenspace of the adjacent
same-color transpositions. Thus it is a concrete rational vector space,
defined without using a known theta coefficient to set its dimension.

**The global character/theta identity is not proved in this branch.** That is
the separate species/completion theorem. Consequently the object below is a
high-rank greedy/theta candidate until that bridge is supplied. The user's
original pictured algorithm has not been recovered in this branch; no claim
is made that these objects reproduce that particular algorithm.

## 1. Exact finite input and root normalization

Let `B` be an integral exchange matrix, `D=diag(D_i)` a positive integral
symmetrizer, `g in Z^n`, and `p in N^n`. Take one framing label `0` and `p_i`
distinct labels of each color `i`. A label of color `i` has charge `e_i`,
and the framing label has charge `e_0`. For a set of labels `S`, write
`a(S)` for its charge. The total charge is `alpha=(1,p)`.

Use the integral skew form on the color lattice

```
eta(e_0,e_i) = D_i g_i,
eta(e_i,e_j) = -D_i B_ij,
eta(e_i,e_0) = -D_i g_i.
```

Equivalently `eta=-Dhat Bhat`, with `Dhat=diag(1,D)` and the framed matrix
whose lower left column is `g` and upper right row is `-g^T D`.

Fix an ordering of the original colors. Let
`mu_i=1+epsilon_i`, where all `epsilon_i` are independent and positive, in
the selected lexicographic hierarchy. Store a linear expression in these
symbols as an exact rational vector `(constant, epsilon_1,...,epsilon_n)`.
Set

```
Theta(e_i)=mu_i,
Theta(e_0)=-sum_i p_i mu_i.
```

Hence `Theta(alpha)=0`. The independent epsilon columns span the whole
space `alpha^perp`; the constant column is an intentional redundant positive
base point. No independence of the redundant constant column is assumed.
All later operations remain linear in these symbols, so rational vectors
are sufficient: no numerical infinitesimal, floating-point comparison,
transcendental value, or final label-specific infinitesimal is required.

The framing label is fixed by all label permutations and has multiplicity
one. There is no extra root weight and no division by a framing factorial.
When `p=0`, the unique tree is the framing leaf and its vector space is `Q`.

As a normalization check valid in every rank, let `B=0`. For every used color
with `g_i<0`, there is one framed star with `-g_i` parallel arrows to each
label of that color. The distinct-color events form the framed chain ordered
by the distinct lexicographic ratios `mu_i/(-g_i)`; equal-color labels belong
to one simultaneous event. The full space is
`tensor_i (Q^(-g_i))^(tensor p_i)`, with the ordinary permutation action on
the equal-color factors. The simultaneous sign space therefore has dimension
`product_i binomial(-g_i,p_i)`. A used color with `g_i>=0` produces no valid
event. These are exactly the independent rank-one binomial normalizations.
This check fixes the frame sign and confirms that no label factorial belongs
inside the vector-space construction.

## 2. The direct recursion

A state consists of a nonempty label set `S` and a covector `Theta` restricted
to its labels, with `Theta(a(S))=0`. A singleton returns its one leaf. For a
larger set, enumerate unordered partitions

```
S = U_1 disjoint-union ... disjoint-union U_k,   k>=2.
```

Write `beta_j=a(U_j)` and `a=a(S)`. Retain the partition precisely when:

1. The vectors `beta_j` span a two-dimensional rational plane `K`, and the
   restriction of `eta` to `K` is nondegenerate.
2. Choose any `beta_j` with `eta(a,beta_j)!=0` and compute
   `t=-Theta(beta_j)/eta(a,beta_j)` as a rational lexicographic vector.
   Require `t>0`; the identically zero vector is excluded.
3. Put `Theta'=Theta+t eta(a,-)`. Require `Theta'(beta_j)=0` for every child.
4. Every child set admits a recursively valid tree at the restriction of
   `Theta'`. Take all independent choices of these child trees.

The displayed ratio is independent of the selected nonparallel child:
`Theta(a)=0`, and both `Theta|K` and `eta(a,-)|K` have the same one-dimensional
kernel containing `a`. The extra annihilation test in item 3 expresses this
fact directly and remains meaningful without a preselected plane basis.

All comparisons are exact. In particular a time with zero constant term but
positive first nonzero original-color infinitesimal is a positive event. A
time identically zero in **all** original-color columns is forbidden. The
latter condition is what makes the tree maximally contracted.

### Implementation by plane keys, rather than all Bell partitions

The implementation obtains the same recursion more efficiently:

* Enumerate proper subsets `T` containing the smallest label of `S` and with
  `eta(a(S),a(T))!=0`.
* Deduplicate the planes `span(a(S),a(T))` using the primitive, sign-normalized
  exterior product `a(S) wedge a(T)`.
* Compute its single time and projected covector. List only proper child
  subsets whose charge belongs to that plane and whose recursive result is
  nonempty. Form unordered partitions from these surviving subsets, always
  choosing next the block containing the smallest remaining label.
* Exclude partitions for which every child pairs to zero with `a(S)`. In a
  nondegenerate two-plane these are exactly the all-parallel partitions;
  they are not events. Parallel children are otherwise fully allowed.

This enumerates every required plane. If a nonparallel child does not contain
the smallest label, its complement does, has the same plane, and has the
opposite nonzero pairing. A primitive exterior-product key is valid even
when the total charge or a child charge is nonprimitive. If two representatives
span the same plane, they have the form `a(T')=u a(S)+v a(T)` with `v!=0`,
so the two ratios defining `t` agree exactly.

The plane condition implies the projected covector annihilates every allowed
child charge, making item 3 an assertion in the implementation rather than a
costly repeated linear solve. Membership in a plane uses integer 2-by-2
minors, with no symbolic matrix rank computation in the generator.

Disconnected induced label graphs can be discarded: a valid nontrivial event
has connected local graph, and joining recursively connected children by its
nonzero pairings produces a connected label graph. This pruning therefore
cannot remove a valid object.

Termination is immediate. Every recursive child is strictly smaller, and
every internal vertex has at least two children, so a tree on `r` labels has
at most `r-1` internal vertices. At each state only finitely many subsets and
partitions are tested. The state is memoized by `(S, restricted Theta)`;
planes and admissible plane subsets are independently cached.

## 3. Equivalence with zero-time contraction: the linear half

Consider the old positive binary construction with the same original-color
covector and a later independent infinitesimal for every individual label.
Delete the latter columns to get its leading covector. A binary split
`S=L disjoint-union R` is performed by

```
P_(S,L)(Theta)=Theta-Theta(a(L))/eta(a(S),a(L)) * eta(a(S),-).
```

Its time is exactly the `t` in Section 2. Thus the sign agrees with the old
condition `sign Theta(a(L)) = sign eta(a(L),a(R))`.

At the root the initial parameter image is `alpha^perp`. The kernel of the
projection on this image is the line `Q eta(alpha,-)`, and the new image is
exactly `span(alpha,a(L))^perp`. Suppose later the incoming image is
`span(P,a(S))^perp`, with `eta(P,a(S))!=0`. The kernel line of the next
projection is `Q eta(a(S),-)`, which meets that incoming image only at zero,
because evaluation on `P` is nonzero. Its image therefore still has
codimension two and is exactly
`span(a(S),a(L))^perp`.

This is a statement about the whole original-color parameter family, not a
rank claim about a restricted list of leaf values. Restricting to the labels
of a child can lower the visible rank to zero, and the algorithm permits
that. The full skew form may also be rank-deficient. Neither phenomenon
invalidates the two-plane argument.

A leading time is identically zero precisely when its tested charge lies in
the current plane. Since its pairing with the parent is nonzero, that split
spans the same plane. Hence an entire connected zero-time component has one
common nondegenerate two-plane and all of its exiting charges lie in it.
Contracting the component produces exactly one of the admissible partitions
in Section 2. All remaining times are lexicographically positive. Recursive
contraction therefore maps every old positive binary tree to a directly
generated tree.

## 4. Equivalence: every direct event has positive refinements

The converse uses the local interface already established in
`agents/simultaneous_packet_vertices.md` and
`proofs/local_rank_two_ih_interface.md`:

> For a nondegenerate two-plane event with nonnegative child charges and
> anti-attractor stability `zeta_j=-eta(a,beta_j)`, every sufficiently small
> generic deformation has a positive binary refinement. The sum of its raw
> bracket weights is the dimension of the canonical intersection cohomology
> of its thin flow-polytope quotient, independent of that generic deformation.

Here are the hypotheses and why this interface applies at every state.

The cone of child charges is pointed. Normalize charges by any strictly
positive linear functional and order them by their coordinate on the resulting
line segment in the event plane. The signs of their pairings agree with this
slope order. Therefore the local graph with `-eta(beta_i,beta_j)` arrows
`i->j` when that number is positive is acyclic. It is connected because the
charges occupy at least two slopes, with every pair of distinct slopes joined.
Repeated and parallel children are allowed.

For the incidence convention incoming minus outgoing, `zeta` is the incidence
vector of the all-one arrow flow. This gives a point in

```
P = {f >= 0 : partial f = partial 1}.
```

Acyclicity makes this flow polytope bounded. The thin representation whose
arrow maps are all nonzero is stable: a proper subrepresentation is an
outward-closed vertex subset, and its stability is the strictly positive
number of entering arrows. Stability persists under sufficiently small
generic deformations.

The thin dimension vector is all ones, hence indivisible, even when its
**color-lattice charge** is nonprimitive. On `ker zeta`, all charge images
are parallel to `a`; therefore the skew Euler form vanishes on the entire
zero-slope lattice. These are exactly the symmetry, indivisibility, and
nonemptiness hypotheses used in the audited small-resolution comparison.
The generic stable toric quotient is nonempty and projective, so its torus
fixed-point count is positive. The acyclic flow expansion computes that
count by nonnegative raw bracket products. The small resolution identifies
the resulting cohomology dimension with the undeformed canonical IH.

No hidden nongeneric perturbation is imposed by the ancestors. In the free
lattice of individual labels, the eventual label infinitesimals span the
full annihilator of total charge. Immediately before a child event, the
preceding parent has labels outside that child. Consequently the two incoming
annihilator equations, restricted to the span of that event's disjoint child
blocks, leave only the total-charge equation. The induced label perturbation
is fully generic on the local block span. This works for every fixed generic
label order, not merely for a specially selected one.

Now start at a direct event. Its incoming color covector restricts to
`-t eta(a,-)` on the event plane, with `t>0`. Every first local binary split
therefore has the same positive leading time, and after that split the leading
covector vanishes on the whole plane. All later splits resolving this event
have zero color time. The local interface gives at least one positive
refinement for the actual induced later-label perturbation. Apply the same
argument successively inside each child. This constructs an old positive
binary tree whose contraction is exactly the prescribed direct tree.

Thus the two sets of trees coincide. Moreover, the local refinement sum is
independent of the perturbation inherited from ancestor refinements. Summing
over a fixed direct tree therefore factors into the product of local IH
dimensions. This proves the raw-weight equality checked by the implementation.
For nonconstant `D` this is a statement about the raw skew-form construction;
it does not erase the separate valued leaf normalization.

## 5. Actual global matrices and the proposed coefficient kernel

For a direct tree `T`, attach to every event `v` the even combinatorial
minimal-extension space of the normal fan of its flow polytope. Its dimensions
and automorphisms are computed by finite rational linear algebra from face
incidences and ray/linear-form data. The algorithm does not infer a space from
a character or a known dimension. The implementation reuses the independently
audited local constructor `fan_linear_module.py`.

Let `E_v` be the number of local arrows, counting multiplicity. Give this
factor parity `E_v mod 2` and form

```
W_(B,g,p) = direct-sum_T tensor_(v internal in T) H_fan(P_v)[E_v].
```

The same-color permutation group `G_p=product_i S_(p_i)` permutes the direct
trees, transports their local fans, and permutes their tensor factors with
the indicated Koszul sign. This defines an honest action. The implementation
constructs the entire rational matrix of each requested permutation, including
maps between distinct tree summands. Canonical child ordering by
`(color charge, label support)` makes equivalent local graph types share the
same local matrix constructor.

For projective-star factors the local matrices are literal coordinate
permutations on the product-projective cohomology basis. Other factors use
the actual minimal-extension matrices, with Poincare duality providing the
inverse-transpose action in complementary degrees. No local trace is used
as a substitute for a local action.

Define the candidate coefficient space by

```
C_(B,g,p) = intersection_(s adjacent same-color transposition) ker(rho(s)+I).
```

This is `Hom_(G_p)(sgn,W)` expressed as a concrete subspace of `W`. An exact
rational basis is returned. The general desired identity
`dim C_(B,g,p) = [z^p] x^(-g) theta_g` is the separate global theorem; it is
not assumed at any stage of this construction.

Arrow parity is essential. Its representation-theoretic derivation belongs
to `agents/equivariant_dt_proof.md`. Independently, the sum of event parities
equals the sum of original pairwise leaf pairings modulo two, because each
leaf pair contributes at its unique lowest common ancestor. Thus total parity
does not depend on the refinement or the tree.

## 6. Verification completed in this branch

The first deterministic suite contains 75 inputs, of which 53 have nonempty
object sets, with ranks 2--5 and 27 nonconstant symmetrizers. It compares
complete direct skeleton sets with old binary contractions and compares every
local-IH dimension product with the summed old raw weight. All comparisons
pass. Totals: 240 skeletons, 250 positive binary refinements, 115 same-color
transposition set checks, and 41 independently evaluated full-character
entries. Direct generation took 3.43 seconds in total; old binary enumeration
took 104.11 seconds in the same run. These are measured implementation times,
not asymptotic complexity claims.

The structural suite targets the mechanisms that the random suite can miss:
nonprimitive charges, parallel children, zero projected color rank, ambient
skew-rank loss, and seven mutable labels. In particular the rank-three
`p=(3,3,1)` input contains a six-child event of total charge `3(e_1+e_2)`,
with three children on each ray. Its 29 direct skeletons agree with all binary
contractions, including 10 nonprimitive events, 51 events with parallel
children, and 75 events with zero restricted projected color rank. The
rank-four seven-label input has 54 skeletons and also passes exact set/weight
comparison. The nonconstant-symmetrizer rank-five seven-label input has 80
skeletons and passes the same exact comparisons. All five structural inputs
completed successfully in 228.34 seconds; the three nonzero seven-label cases
use 0.12, 0.43, and 0.62 seconds for direct generation respectively. Counts of
event types here count their occurrences across the tree collection. The
machine-readable files retain full parameters and results.

### Full matrix computations, not character interpolation

| Input | Dimension of actual W | Character values by cycle class | Sign-kernel dimension |
|---|---:|---|---:|
| `B=[[0,2,-3],[-2,0,2],[3,-2,0]], g=(-3,3,-2), p=(2,2,1)` | 88 | `(88,40,36,12)` | 6 |
| `B=[[0,1],[-1,0]], g=(-4,1), p=(3,1)` | 155 | `(155,41,11)` on the three `S3` classes | 9 |
| `B=[[0,-1,2],[1,0,2],[-2,-2,0]], g=(1,-3,0), p=(2,2,1)` | 144 | `(144,80,64,32)` | 8 |

The first example has summand dimensions `64+8+8+8`; the weight-64 summand
contains the nontrivial sixteen-dimensional fan module of the double-arrow
`K_(2,2)` polytope. The two global generator matrices square to the identity
and commute, and their explicitly computed 88-by-6 kernel basis transforms
by sign under each. A separate Wolfram kernel calculation, supplied with the
actual sparse matrices, finds rank 82 for the stacked `(A+I,B+I)` system,
rank 6 for `(I-A)(I-B)/4`, and confirms that this projector is idempotent.

The second example has seven summands and genuinely noncommuting `S3`
generators. Their square and braid relations hold, and all 36 products of the
six independently assembled permutation matrices agree with the group law.
Its sign-kernel dimension is 9. This tests transport between summands as well
as the local tensor action.

In the third example, erasing the arrow-parity signs changes the double-swap
trace from the correct 32 to 96. The actual matrices with the signs have
sign-kernel dimension 8. All listed dimensions and class traces agree with
an independent theta recursion imported **only after** constructing the
spaces and matrices. These finite agreements test the candidate global
theorem; they are not its proof.

## 7. A necessary color-order qualification

Changing the original-color lexicographic order can change the skeleton set.
The smallest detected boundary is

```
B=[[0,1],[-1,0]], g=(-2,0), p=(1,1).
```

For one color order the sole tree is `((0,1),2)`; for the reversed order it
is `(0,(1,2))`. Both have dimension two, and both match the independent
coefficient. The distinguishing event has a time proportional to
`epsilon_1-epsilon_2`, with zero constant term. Thus restricting comparisons
to positive constant times would miss a real issue.

The fixed color order is therefore an explicit auxiliary input. Same-color
**label** relabeling preserves the entire direct tree set and gives the
actual group action proved above. Changing the order of distinct **colors**
is a separate operation. A general isomorphism/character-invariance theorem
under changing this order belongs to the global completion argument; it is
not claimed from these tests. Nor is a canonical basis-preserving bijection
between the two skeleton sets asserted.

## 8. Files and source interfaces

Construction and exact output:

* `computations/intrinsic_partition_model/intrinsic_partitions.py`
* `computations/intrinsic_partition_model/global_matrix_module.py` and `.json`
* `computations/intrinsic_partition_model/verify_partitions.py` and `.json`
* `computations/intrinsic_partition_model/structural_verification.py` and `.json`
* `computations/intrinsic_partition_model/rank_degenerate_form.py` and `.json`
* `computations/intrinsic_partition_model/verify_global_matrices.py` and `.json`
* `computations/intrinsic_partition_model/wolfram_global_kernel.wls` and `.json`

The relevant pre-2026 primary interfaces, audited by the preceding branches,
are Arguz--Bousseau, *Quivers, Flow Trees, and Log Curves*,
<https://arxiv.org/abs/2302.02068>, especially the planar-vertex discussion
and Lemmas 1.14--1.16/Theorem 1.17; Reineke's small-resolution theorem,
<https://arxiv.org/abs/1511.08316>; and the combinatorial minimal-extension
framework of Barthel--Brasselet--Fieseler--Kaup,
<https://arxiv.org/abs/math/0002181>. The finite-group PBW/parity interface is
audited separately against Davison--Meinhardt,
<https://arxiv.org/abs/1601.02479>.

No Li--Pan conclusion, no unaudited 2026 assertion, and no claimed recovery
of the user's missing pictured algorithm is used in this branch.
