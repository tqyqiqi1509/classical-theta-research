# Independent review of the valued event-flag graph

Reviewer: valued_polyhedral_mechanism. Stage: 2026-11-13, 14:22 UTC.
Files read: `agents/valued_global_assembly.md`,
`computations/valued_event_flag_grammar.py`,
`agents/INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`, and the local
word and tight-normal notes. This review concerns the complete structural
interface, not a deduction of a general theorem from numerical examples.

## 1. Verdict and dependencies

No fatal gap was found in the present finite-state construction. Its
definition uses bounded positive charges, exact rational covectors with
ordered infinitesimals, and finite tight Dyck gradings. It does not need
a precomputed higher-rank wall list. Its equality proof uses the established
incoming-factor description of scattering diagrams and the established
rank-two tight-grading identity; these should be credited as external
inputs. The separate one-frame transport identity is already part of the
project's proved interface.

The global identification is coefficientwise. It does not assert that
every formal theta function is a Laurent polynomial, or that every
integer tropical point indexes a regular basis element of an arbitrary
upper cluster algebra. Where a theta function is known to be regular,
its finite expansion is obtained once a valid support bound is supplied.

## 2. Candidate events are intrinsically finite and exact

For fixed positive S and a generic ordered covector Theta with rational
kernel Q S, every proper charge b<=S with eta(S,b) nonzero determines

`tau=-Theta(b)/eta(S,b)` and `q=Theta+tau eta(S,-)`.

If a second b gives the same rational two-plane K=span(S,b), it gives
the same tau and q: replace b by c S+d b and cancel d. Thus deduplication
by primitive Pluecker coordinates is mathematically valid.

For any rational c, q(c)=0 implies

`Theta(c-eta(S,c)*b/eta(S,b))=0`,

hence c belongs to K. The converse is immediate. Therefore q has rational
kernel exactly K, not merely a kernel containing K. This rules out an
uncontrolled higher-codimension collision. The restriction of eta to K
is nondegenerate by eta(S,b) nonzero.

A candidate is retained exactly when tau is positive in the ordered
coefficient field. Only finitely many charges b occur in the box, and
only finitely many planes result. A zero coefficient may make an event
inactive later; it does not affect the independently enumerated graph.

## 3. The incoming perturbation is coherent along an entire ray

For T=j rho proper in S, all coefficients of that incoming ray are
queried at `Theta_T=q+delta eta(rho,-)`, with one shared new infinitesimal
for that event. The old coordinates of a rational vector in the kernel
force it into K; the new coordinate then forces it to be parallel to rho.
Thus the child kernel is exactly Q T.

A putative child event in the current K has time

`-delta eta(rho,c)/eta(j rho,c)=-delta/j<0`.

It is excluded. A child event outside K has a nonzero old leading value,
so adding delta does not change its side. This is a strict, verifiable
incoming-side rule. It prevents the current event from supplying one of
its own inputs, while preserving all older events that matter.

Each child target T is proper in S. Total charge decreases at every
state edge, giving depth at most |S|-1. A formal infinitesimal can be
implemented by appending one exact rational coordinate; no analytic
choice of a tiny number is required.

## 4. Local positive words really give the outgoing increment

The local positive cone in K lies in an open angular half-plane. Its
incoming directions eta(rho,-) also lie in one half-plane. A small path
around the joint can therefore cross all incoming rays in one order and
all outgoing rays in the reverse order. The inverse of that path-product
identity is precisely the positive word identity used by the algorithm.

Here is a sign calibration that removes a possible convention ambiguity.
Take K(e1,e2)=m>0 and eta=-K. Then

`eta(e1,-)=(0,-m)`, `eta(e2,-)=(m,0)`,
`eta(e1+e2,-)=(m,-m)`.

The incoming halves are south and east, and the new outgoing half is
northwest. A negative-to-positive wall crossing acts on charge monomials
by the inverse of the positive tropical-vertex generator T. The southeast
path has column operator `T_B^(-1) T_A^(-1)`. The northwest path has
`T_A^(-1) (product_new)^(-1) T_B^(-1)`. Inverting their equality gives

`T_A T_B=T_B (product_new) T_A`,

exactly the word rule for positive K(A,B). The positive generator and
the actual negative-to-positive crossing must not be silently assigned
the same sign.

Along the target half-line, t decreases from larger than tau to smaller
than tau. The point goes from `q+epsilon eta(S,-)` to
`q-epsilon eta(S,-)`: incoming to outgoing. Hence its packet is multiplied
by the born factor R, not divided by it. This fixes the sign in the
product over candidate events.

## 5. Carrier retention and positive parallel bookkeeping

A local birth has carrier gamma=a alpha+b beta with a,b positive. The
integer d(gamma) normalizes its normal; the carrier itself is retained.
Positive mass therefore increases strictly at a birth. Every pair of
fixed factor instances crosses at most once. Induction on carrier mass
bounds all born instances below the charge box, proving finite word
termination independently of coefficient values.

Keeping each inherited factor instance separate is essential. All of
its later interactions may create other factors, but the instance itself
remains unchanged. At the end, the target ray is a product of its original
instances and born instances. Selecting the latter gives an actual
positive series. This is justified by the word identities and ordered
factor uniqueness; it does not identify it with the incorrect geometric
isolated-parallel locus.

Only proper incoming coefficient degrees can contribute to a born term
of degree S: every positive local decoration uses a positive amount of
each of two nonparallel parent directions. A hypothetical input of degree
S followed by any other positive input would leave the box. Omitting the
unknown inherited degree-S input from the local word is consequently
valid and removes a possible same-degree circular call.

## 6. Global telescoping

At every finite box the incoming completion has only finitely many
relevant walls and joints. A wall of charge outside the box cannot affect
its coefficients because charge increments never decrease. The target
half-line meets only the candidate planes described in Section2. Each
actual joint has the incoming packets obtained by the strictly smaller
child states; induction identifies them with the grammar's coefficient
sets.

The previous section gives its local outgoing increment. Packets on one
ray commute, so their multiplication telescopes from the prescribed
incoming axis packet (or the identity on a nonaxis ray) to the target
point. This proves the global product formula. Different candidate
planes can contribute proper parallel powers and their Cartesian-product
allocations are exactly the required Cauchy products.

If eta(S,-)=0 there is no candidate. For a nonaxis radical charge, every
nested commutator of total S has vanishing final bracket: if its last
split is S=A+B, eta(A,B)=eta(A,S)=0. Thus no additional incoming radical
packet is required. An initial radical axis keeps its prescribed packet.

## 7. One-frame extraction

For the extended matrix and S=(1,p), the chosen root covector has
Theta(1,q)<0 whenever q<p, and Theta(0,q)>0 for nonzero q. Its only
zero-slope positive charge in the box is S itself. It is primitive in the
weighted lattice because its frame coordinate is one.

In the column factorization C=C_- C_0 C_+, C_+ acts first on x^(-e0)
and is trivial there: its normals have zero frame coordinate. C_0 acts
with exponent one. Every term created by C_0 already uses the frame;
a further negative framed increment leaves the box. Acting once from
C_- on the unchanged leading term creates a proper negative-slope charge,
not S. Therefore the degree-S total-transport coefficient is exactly the
zero-ray packet coefficient, with no sign or averaging factor.

Combining this with the already established one-frame transport identity
identifies the finite event-flag count with the prescribed theta
coefficient. The framing hypothesis does not impose acyclicity on the
original matrix: only the local rank-two charge lists are ordered.

## 8. Implementation observations

The implementation uses exact Fractions, primitive Pluecker plane keys,
and exact two-by-two minors for plane membership. Its initial angular
comparator is the opposite of the target comparator; on a pointed
nondegenerate two-plane these comparators are transitive. New carriers
are retained unchanged. The final common-ray exponent is their positive
ambient gcd, correctly used only when multiplying terminal series.

The numerical implementation specializes the original input alphabets
to one letter. The mathematical definition in the manuscript retains
all coefficient sets. This distinction should be stated when describing
what the existing executable checks.

The hard guard at 100,000 word exchanges is an implementation safeguard,
not part of the mathematical construction. A valid finite input could
exceed it; it should be made optional for production calculations. The
proved termination does not supply a small complexity bound.

No new coefficient checks are duplicated here: the global-assembly
branch and parent are independently comparing this literal tight-grading
implementation with IncomingSchur. This review checks the mechanisms
that make those finite tests meaningful.
