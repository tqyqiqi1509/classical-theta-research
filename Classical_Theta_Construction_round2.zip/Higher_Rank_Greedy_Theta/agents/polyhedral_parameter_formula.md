# 参数多面体、复制参数与非负二项式展开

Author branch: `/root/polyhedral_parameter_formula`.
Date: 2026-11-13. Classical cluster algebras only.

**Update at 14:28 UTC.** The gap identified below in Sections0,5,8 has
now been closed by a separate construction, not by declaring sets of
known cardinality. `proofs/POLYHEDRAL_REPLICATION_OBJECTS.md` defines the
active-copy multiplicities using actual bounded Dyck event objects for
arbitrary skew-symmetrizable input, and proves the corresponding labelled
polyhedral/selection formula. The original argument and its historical
limitations below are retained for an honest route record. The new
counter independently obtains the multiplicities 9,27,46,133 in Section6.

## 0. Result and exact status

This branch proves two general consequences of the incoming-normalized integer-prefix theorem in `INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`.

1. **Finite parameter stratification.** Fix a root coefficient index \(p\in\mathbb N^n\) and a positive integral diagonal symmetrizer \(D\). The coefficient \(a^{B}_{g,p}\) is a polynomial of total degree at most \(|p|\) on every stratum of an explicit finite rational central hyperplane arrangement in \((B,g)\), restricted to \(DB\) skew-symmetric. Every branch polynomial is integer-valued on the entire ambient integer lattice, and \(p!:=\prod_i p_i!\) clears its ordinary polynomial denominators. Zero strata are included, with the algorithm's actual strict endpoint inequalities and fixed lexicographic ties.

2. **Positive replication expansion.** For \(R=\operatorname{diag}(r_i)\), positive integral \(r_i\), put
   \[
   F_{B,g,p}(r)=a^{RB}_{Rg,p},\qquad D_r=DR^{-1}.
   \]
   A common positive multiple makes \(D_r\) integral. Then there are explicit nonnegative integers \(A_{p,k}\), independent of \(r\), such that
   \[
   \boxed{F_{B,g,p}(r)=\sum_{0\le k\le p}A_{p,k}\prod_i\binom{r_i}{k_i}.}\tag{R}
   \]
   The multiplicities \(A_{p,k}\) are sums of theta coefficients for the block-constant quiver obtained by making \(k_i\) copies of vertex \(i\), requiring every copy to receive positive root degree. Consequently all mixed forward differences of this polynomial are nonnegative at nonnegative integer parameters. In particular \(a^{tB}_{tg,p}\) has a nonnegative Newton expansion in \(\binom tj\).

The first result is a direct, self-contained algebraic consequence of the integer formula. For the second, the transport projection is the strong block-constant folding mechanism of Zhou's 2020 work, with the normalization and theta-extraction compatibility proved below; coefficient nonnegativity uses classical theta positivity. This is a genuine structural improvement, but **does not close the requested purely combinatorial greedy problem**: the positive cell multiplicities in (R) are still theta coefficients. It would be incorrect to declare an arbitrary finite set of that size to be the missing compatible configurations.

No Li–Pan theorem is used. No 2026 result is needed in either proof.

## 1. Conventions and the finite arithmetic input

Write
\[
\vartheta_g=x^g\sum_{q\ge0}a^B_{g,q}z^q,
\qquad z_i=y_i x^{Be_i}.
\]
All statements concern a fixed finite formal coefficient. They require neither Laurent finiteness of the entire theta function nor a claim that every integral \(g\) indexes an element of the cluster algebra.

The transport entries are
\[
C^g_{s,q}=c_{s-q}(g+Bq),\qquad q\le s.
\]
Axis entries are generalized binomial polynomials
\[
c_{ke_i}(m)=\binom{-m_i}{k}
=\frac{(-m_i)(-m_i-1)\cdots(-m_i-k+1)}{k!}.
\]
For a nonaxis \(\alpha\), the Schur recursion uses
\[
S_\alpha=\{0<q<\alpha:\sigma_\alpha(q)>0\},
\]
where \(q<\alpha\) means \(q\le\alpha\), \(q\ne\alpha\), and
\[
\sigma_\alpha(q)=\operatorname{lexsign}\left(
(B\alpha)^TDq,\;\alpha_rq_i-\alpha_iq_r\ (i\ne r)
\right).
\]
Here \(r\) is a fixed deterministic nonzero coordinate of \(\alpha\), and the remaining coordinates have one fixed tie order. The Schur recursion is
\[
v_s=c_s(m)-\sum_{\substack{q\in S_\alpha\\q<s}}
c_{s-q}(m+Bq)v_q,
\qquad
c_\alpha(m)=\sum_{s\in S_\alpha}c_{\alpha-s}(m+Bs)v_s.
\]
The final extraction uses
\[
I_s=\{s\}\cup\{q<s:(g+Bs)^TD(s-q)<0\},
\]
and the last row of \((C^g[I_s,I_s])^{-1}\). These formulas use only finitely many additions, subtractions, multiplications and generalized binomials. Their recursive root charges add coordinatewise.

## 2. The precise parameter-space theorem

Let
\[
V_D=\{(B,g)\in\mathbb R^{n\times n}\times\mathbb R^n:
DB+B^TD=0\},\qquad J=[0,p]\cap\mathbb Z^n.
\]
Take all nonzero restrictions to \(V_D\) of the following linear forms:
\[
H_{\alpha,\beta}(B,g)=(B\alpha)^TD\beta,
\quad 0<\alpha\le p,\quad 0\le\beta\le\alpha,
\tag{H}
\]
\[
E_{s,q}(B,g)=(g+Bs)^TD(s-q),
\quad 0\le q<s\le p.
\tag{E}
\]
Keeping the identically zero forms in a list is harmless; they simply impose no geometric cut. Using all \(\alpha,\beta,s,q\in J\) overrefines the same valid arrangement.

For every realizable full sign assignment in \(\{-,0,+\}\), let \(\mathcal C\) be the corresponding nonempty stratum. Then there is a polynomial
\[
P_{\mathcal C,p}(B,g)\in\mathbb Q[B_{ij},g_i]
\]
with the following properties:

- \(a^B_{g,p}=P_{\mathcal C,p}(B,g)\) at every integral \((B,g)\in\mathcal C\).
- \(\deg P_{\mathcal C,p}\le |p|:=\sum_i p_i\).
- \(p!P_{\mathcal C,p}\in\mathbb Z[B_{ij},g_i]\).
- The chosen ambient extension \(P_{\mathcal C,p}\) is integer-valued on **every** integral assignment of its entries, including assignments outside \(\mathcal C\) and assignments not satisfying the skew-symmetrizer relation. Outside its stratum it need not give the theta coefficient.

Each \(\mathcal C\) is a relatively open rational polyhedral cone. The origin is its own possible face, not an automatically included point of every open cone. Restricting to a fixed \(B\) produces a finite arrangement of **affine** hyperplanes in \(g\), and the resulting cells are affine polyhedra rather than necessarily cones.

### 2.1 Why the full three-way sign stratification is required

On \(H_{\alpha,\beta}=0\), the next lexicographic coordinate is the fixed integer \(\alpha_r\beta_i-\alpha_i\beta_r\). It does not introduce another parameter hyperplane. If all such coordinates vanish, \(\beta\) is proportional to \(\alpha\), and the sign is exactly zero.

On \(E_{s,q}=0\), the endpoint rule excludes \(q\), because its inequality is strict. This is not a limit convention. Both kinds of zero are thus evaluated by the actual recursion, and every lower-dimensional stratum has its own unambiguous branch.

The proof does not assume that the ambient polynomials of adjacent full-dimensional chambers agree on their common face. Such a gluing assertion would require a separate argument and is not used here.

### 2.2 Proof of polynomiality and the degree bound

Freeze a stratum. Every finite set \(S_\alpha\) and \(I_s\) is then fixed. Replace every generalized binomial by its falling-factorial polynomial, retaining every arithmetic operation in the recursion. This constructs the branch polynomial without interpolation.

Assign root charge \(\alpha\) to \(c_\alpha\). An axis factor of charge \(ke_i\) has total degree \(k\). In every transport product the charges add to the output charge. Substitution
\[
m\longmapsto g+Bq
\]
is linear in the joint variables and cannot increase total polynomial degree. Induction therefore gives \(\deg c_\alpha\le |\alpha|\).

For a unitriangular matrix, every entry of its inverse is a finite signed sum over strict chains. The root increments along a chain from \(q\) to \(s\) add to \(s-q\). Its inverse entry therefore has degree at most \(|s-q|\). In the last-exponent extraction, multiplication by the already computed coefficient of charge \(q\) gives total degree at most \(|s-q|+|q|=|s|\). This proves the bound by induction.

### 2.3 The coordinate-factorial denominator improvement

Fully expand the finite recursion, including every unitriangular inverse, down to axis-binomial leaves. In each summand, write the leaf charges as \(k_\ell e_{i_\ell}\). Root-charge conservation gives
\[
\sum_{\ell:i_\ell=i}k_\ell=p_i
\quad\text{for every }i.
\]
The only denominators in that summand divide \(\prod_\ell k_\ell!\), and
\[
\frac{\prod_i p_i!}{\prod_\ell k_\ell!}
=\prod_i\binom{p_i}{(k_\ell)_{i_\ell=i}}\in\mathbb Z.
\]
Thus \(p!\) clears every summand and hence the entire polynomial. This is generally sharper than the degree-only denominator bound \(|p|!\).

The ordinary coefficients need not be integers: already \(B=0\), \(g_i<0\), \(p=2e_i\) gives \(\binom{-g_i}{2}=g_i(g_i+1)/2\). The correct term is **integer-valued polynomial**, not polynomial with integer coefficients.

Every leaf binomial is integer-valued on integer linear inputs. Closure under addition and multiplication proves the stronger ambient integer-valued assertion. It does not depend on a point remaining inside its sign stratum.

### 2.4 Lattice coordinates and finite differences

An integral coordinate system on \(V_D\) is available explicitly. For \(i<j\), let \(d_{ij}=\gcd(D_i,D_j)\) and use an independent integer parameter \(b_{ij}\) with
\[
B_{ij}=\frac{D_j}{d_{ij}}b_{ij},\qquad
B_{ji}=-\frac{D_i}{d_{ij}}b_{ij}.
\]
Together with the \(g_i\), these parametrize all integral points of \(V_D\). A branch polynomial consequently has an integral multivariate Newton expansion in the ordinary binomial basis of these coordinates. Its Newton coefficients may be signed; no chamberwise positivity follows merely from integer-valuedness.

For any lattice directions \(v_1,\ldots,v_m\), the iterated finite difference of a branch polynomial is zero when \(m>|p|\). Hence the corresponding finite difference of actual theta coefficients vanishes whenever its entire stencil lies in the same stratum. This yields exact finite interpolation and identity verification once a stratum is fixed, not a heuristic numerical fit.

### 2.5 What happens when the symmetrizer varies

For fixed positive rational \(D\), multiply by a common positive denominator and the theorem is unchanged. A common positive scalar never changes a sign or the binomial inputs.

If \((B,g,D)\) all vary, \(DB\) and the displayed sign expressions are generally not linear in the combined coordinates. The same finite algorithm gives a finite **semialgebraic** sign stratification, and on each stratum the formula is still a polynomial in \((B,g)\) of degree at most \(|p|\), independent of \(D\) in its algebraic coefficients. One must not call this a single rational hyperplane arrangement in the combined variables. The replication family below is a special varying-symmetrizer family in which all relevant products cancel exactly.

## 3. The replication theorem

Fix integral \(B,g\), and a positive integral \(D\) with \(DB\) skew-symmetric. For a vector of positive integers \(r\), let \(R=\operatorname{diag}(r_i)\). Define
\[
B_r=RB,\qquad g_r=Rg,\qquad D_r=DR^{-1}.
\]
Then \(D_rB_r=DB\) is skew-symmetric. Although \(D_r\) may be rational, a common positive multiple makes it an ordinary integral symmetrizer.

### 3.1 Polynomiality without any folding input

All first transport signs and all endpoint signs are independent of positive \(r\):
\[
(B_r\alpha)^TD_r\beta=(B\alpha)^TD\beta,
\]
\[
(g_r+B_rs)^TD_r(s-q)=(g+Bs)^TD(s-q).
\]
Lexicographic tie signs also stay fixed. Thus the entire formula is a single polynomial in \(r\) on the positive orthant. At an axis leaf of type \(i\), the binomial top is
\[
-r_i\left(g_i+(Bq)_i\right).
\]
Conservation of root charge now gives the stronger separate bound
\[
\deg_{r_i}F_{B,g,p}\le p_i.\tag{M}
\]
This part is independent of theta positivity or a folding theorem.

### 3.2 Block-constant replication

Replace vertex \(i\) by \(r_i\) labelled copies \((i,a)\), \(1\le a\le r_i\), and set
\[
\widetilde B_{(i,a),(j,b)}=B_{ij},\quad
\widetilde D_{(i,a)}=D_i,\quad
\widetilde g_{(i,a)}=g_i.
\]
There are no arrows between copies of the same vertex. Let the root-sum map be
\[
(\pi u)_i=\sum_{a=1}^{r_i}u_{i,a}.
\]
The essential strong condition is that the pairing is unchanged under **independent** permutations of its two copy indices. This is stronger than merely having a finite symmetry group of a quiver.

The coefficient folding identity is
\[
\boxed{a^{RB}_{Rg,p}=
\sum_{\substack{u\ge0\\\pi u=p}}
a^{\widetilde B}_{\widetilde g,u}.}\tag{F}
\]
The sum is finite for each \(p\). We next prove the normalization and the compatibility of the final coefficient extraction; this is where an informal vertex-folding analogy would be insufficient.

### 3.3 Transport projection: the normalization check

Use the root-graded Lie algebra with generators \(E_\alpha\), \(\alpha>0\), and bracket
\[
[E_\alpha,E_\beta]=(\alpha^TDB\beta)E_{\alpha+\beta}.
\]
Its action on the module generated by \(x^m\) is
\[
E_\alpha(x^mz^q)=\alpha^TD(m+Bq)x^mz^{q+\alpha}.
\]
The bracket follows by applying both sides to a monomial. In the negative-to-positive orientation used here, the axis logarithm is
\[
L_i=\sum_{k\ge1}\frac{(-1)^k}{D_i k^2}E_{ke_i},
\]
whose exponential acts as multiplication by \((1+z_i)^{-m_i}\) on an axis. This explicitly confirms that the leaf exponent is \(-m_i\), not \(-D_im_i\).

For the replicated and folded data,
\[
\alpha^T\widetilde D\widetilde B\beta
=(\pi\alpha)^TDB(\pi\beta)
=(\pi\alpha)^TD_rB_r(\pi\beta).
\]
Consequently \(E_\alpha\mapsto E_{\pi\alpha}\) is a continuous filtered Lie-algebra homomorphism. It sends all \(r_i\) initial logarithms above vertex \(i\) to
\[
\sum_{k\ge1}\frac{r_i(-1)^k}{D_i k^2}E_{ke_i}
=\sum_{k\ge1}\frac{(-1)^k}{(D_r)_i k^2}E_{ke_i},
\]
exactly the folded initial logarithm.

The incoming-normalized completion commutes with this projection. Here is the special condition that makes this valid. The skew form descends through \(\pi\), and the incoming direction of every lifted root is the pullback of the incoming direction of its image. Restricting to the copy-invariant subspace therefore does not turn an outgoing wall into an additional incoming wall. If multiple roots project to the same ray, their pairings are zero, so the coincident factors commute. Incoming uniqueness then identifies the image completion with the folded completion.

This is the block-constant mechanism in Zhou, §3.1, condition (3.1), the quotient Lie homomorphism, and Theorem 3.2. Its proof works with the rational positive \(D\)-normalization above, since that normalization merely changes the displayed initial logarithm coefficients. It is **not** an invocation of a claim that every symmetric quiver folding preserves the entire cluster scattering diagram. Mandel–Qin, Appendix A, explicitly discusses the distinction: general restriction can have extra incoming contributions.

In particular the transport coefficients satisfy, for every \(m\),
\[
c^{RB}_p(Rm)=\sum_{\pi\alpha=p}c^{\widetilde B}_\alpha(\widetilde m),
\quad\widetilde m_{i,a}=m_i.\tag{T}
\]
The module action is compatible because
\[
\alpha^T\widetilde D(\widetilde m+\widetilde Bq)
=(\pi\alpha)^TD(m+B\pi q)
=(\pi\alpha)^TD_r(Rm+RB\pi q).
\]

### 3.4 Why transport projection implies theta projection

This step avoids assuming an unrestricted broken-line folding theorem.

Fix a target root \(p\). Work on the finite lifted index set
\[
\widetilde J_p=\{u\ge0:\pi u\le p\}.
\]
Let \(\Phi\) be the linear map that sums coefficients over each fiber of \(\pi\). Since
\[
\widetilde g+\widetilde Bq
\quad\text{is constant on each copy block and depends only on }\pi q,
\]
(T) gives the matrix intertwining
\[
\Phi\widetilde C=C_r\Phi.\tag{C}
\]

For any lifted top index \(u\) with \(\pi u=p\), its endpoint halfspace condition is
\[
(\widetilde g+\widetilde Bu)^T\widetilde D(u-v)
=(g+Bp)^TD(p-\pi v).
\]
The folded condition is exactly the same. Hence the index selection is a union of full \(\pi\)-fibers: include the negative halfspace and the whole top fiber \(\pi^{-1}(p)\). Two different indices in that top fiber are incomparable, so their mutual off-diagonal transport entries vanish. Adding all of them therefore leaves each individual last-row extraction unchanged.

The restriction of (C) to these halfspace principal submatrices is still an intertwining. The matrices are unitriangular; multiplying by their finite inverses gives
\[
\Phi\widetilde C_I^{-1}=C_{r,I}^{-1}\Phi.
\]
The last-row vanishing equations for theta extraction can now be summed over the top fiber. They give exactly the folded last-row equation. Induction on \(|p|\), starting with coefficient \(1\) at zero, proves (F), including all strict-zero endpoint cases.

### 3.5 Support locality

If a root index \(u\) has zero coordinates outside a set \(S\), its coefficient uses only \(B[S,S]\), \(D[S]\) and \(g[S]\). This follows directly from the Schur recursion: all recursive charges and all halfspace differences are supported on \(S\); dot products discard the other coordinates, and the remaining shifted exponents only use the principal submatrix. The relative tie order on \(S\) is retained.

Thus an unused copy can be deleted without changing a coefficient. Copies are interchangeable by relabelling invariance of theta coefficients. These two facts are what turn folding into a binomial expansion.

## 4. The nonnegative binomial coefficients

For \(0\le k\le p\), make \(k_i\) copies of each vertex \(i\), deleting vertices with \(k_i=0\). Define
\[
A_{p,k}=
\sum_{\substack{u_{i,a}\ge1\\\sum_{a=1}^{k_i}u_{i,a}=p_i}}
a^{B^{[k]}}_{g^{[k]},u}.\tag{A}
\]
The empty block is permitted only when \(p_i=0\). Accordingly \(A_{p,k}=0\) if \(p_i>0=k_i\); the coefficient at \(p=k=0\) is \(1\).

In (F), partition the lifted root vectors by the subset of copies used in each block. Choosing those subsets contributes \(\prod_i\binom{r_i}{k_i}\). By support locality and permutation symmetry, the remaining coefficient sum is exactly (A), independent of which subsets were selected. This proves (R) for every positive integral \(r\). Since both sides are polynomials, it proves the polynomial identity.

Every summand of (A) is a classical theta coefficient for an integral skew-symmetrizable exchange matrix. Classical theta positivity gives
\[
A_{p,k}\in\mathbb Z_{\ge0}.
\]
This last implication is the one external positivity input. The new integer recursion by itself is signed and does not prove the nonnegativity.

### 4.1 All mixed finite differences are nonnegative

Extend \(F\) to \(r_i=0\) by its polynomial, not by an illegal inverse symmetrizer \(DR^{-1}\). Newton inversion gives
\[
A_{p,k}=\left.(\Delta_1^{k_1}\cdots\Delta_n^{k_n}F)(r)\right|_{r=0}.
\]
Moreover
\[
\Delta^\ell F(r)
=\sum_{k\ge\ell}A_{p,k}\prod_i\binom{r_i}{k_i-\ell_i}
\ge0
\quad(r\in\mathbb Z_{\ge0}^n).
\]
Terms of order \(\ell_i>p_i\) vanish. This is substantially stronger than eventual positivity of forward differences of an arbitrary nonnegative polynomial.

For uniform replication, \(r_i=t\), each product \(\prod_i\binom{t}{k_i}\) has a nonnegative expansion in \(\binom tj\): choose the union of the selected color subsets first, and then choose the subsets inside their union. Thus
\[
a^{tB}_{tg,p}=\sum_{j=0}^{|p|}b_{p,j}\binom tj,
\qquad b_{p,j}\in\mathbb Z_{\ge0}.
\]
In particular all forward differences at \(t\ge0\) are nonnegative. The value at \(t=0\) is its polynomial continuation, equal to zero for \(p\ne0\), and equal to one for \(p=0\).

### 4.2 The top coefficient is a square-free coefficient

When \(k=p\), every positive root on every copy must equal one. Therefore
\[
A_{p,p}=a^{B^{[p]}}_{g^{[p]},\mathbf1}.
\]
The coefficient of \(\prod_i r_i^{p_i}\) in \(F\) is
\[
\frac{a^{B^{[p]}}_{g^{[p]},\mathbf1}}{\prod_i p_i!}.
\]
This explicitly explains the coordinate-factorial scale in the highest homogeneous term. It also identifies a square-free coefficient interface for future combinatorial work. It does not reduce the entire original coefficient to that one top coefficient.

## 5. What the polytope statement really gives

For \(k\ge1\), the integer solutions of
\[
0<u_1<\cdots<u_k\le r
\]
are counted by \(\binom rk\). This is the lattice-point count in a partially open unimodular simplex dilated by \(r\); for \(k=0\) use one point. Consequently (R) is the lattice-point count of a finite **disjoint union** of products of such simplices, with \(A_{p,k}\) copies of the product indexed by \(k\). For uniform \(r_i=t\), this is an Ehrhart polynomial of a finite disjoint union of partially open lattice polytopes of potentially different dimensions.

This gives a valid positive polyhedral realization of the **replication-parameter polynomial** and the nonnegative finite-difference coefficients have the exact support-of-copies meaning (A).

It does not yet give the required local compatible-subset rule for the original theta coefficient. At \(r=(1,\ldots,1)\), only the terms with each used \(k_i=1\) survive, and their multiplicity includes the original coefficient itself. Thus treating the multiplicities as unexplained numbers would be circular for the main greedy goal. A useful next proof target is to describe the all-copies-used coefficients (A), particularly the square-free ones, by an intrinsic configuration set and establish the relevant cancellation mechanism without importing positivity.

## 6. Exact computation and independent plugin check

Code: `polyhedral_parameter_formula.py`.
Output: `polyhedral_parameter_formula_results.json`.
The code freezes a sign branch at an integral sample but keeps all algebraic inputs symbolic; this is separate from the numerical integer-recursion implementation.

Checks completed:

- Symbolic total-degree and coordinate-factorial denominator checks for positive, zero, and endpoint-tie parameter samples.
- 72 integral dilation rays, 1,248 root coefficients: exact differences above the proved degree vanish; all Newton coefficients through that degree are nonnegative.
- 144 symbolic replication coefficients, including skew-symmetrizable examples and cyclic ranks three, four, and five: the symbolic polynomial equals the independently computed all-copies-used sum (A) in the binomial basis. Every multiplicity is nonnegative.
- Numerical folded symmetrizers are cleared by a common positive scalar; independent evaluations agree with the symbolic replication polynomials.

One cyclic example, used only to validate the general mechanism, is
\[
B=\begin{pmatrix}0&2&-2\\-2&0&2\\2&-2&0\end{pmatrix},
\quad g=(-1,-1,-1),\quad p=(2,2,1).
\]
The polynomial is
\[
F(r_1,r_2,r_3)=
\frac{r_1r_2r_3}{4}
(133r_1r_2-41r_1-79r_2+23).
\]
Its positive expansion is
\[
9r_1r_2r_3
+27r_1\binom{r_2}{2}r_3
+46\binom{r_1}{2}r_2r_3
+133\binom{r_1}{2}\binom{r_2}{2}r_3.
\]
Wolfram Language independently returned zero for their difference, confirmed that multiplying by \(p!=4\) clears ordinary denominators, and gave the uniform-ray Newton coefficients
\[
(0,9,612,3942,7260,3990,0,0).
\]
The uniform-ray polynomial is \(23t^3/4-30t^4+133t^5/4\). This illustrates why ordinary monomial-coefficient positivity is the wrong demand: it has a negative coefficient of \(t^4\), but its Newton coefficients are all nonnegative.

These checks validate implementation and normalizations. They are not substitutes for the proofs in §§2–4.

## 7. Literature interface and novelty audit

### L1. Gräfnitz–Luo, 2023 — useful, directly relevant prior art

Tim Gräfnitz and Patrick Luo, *Scattering diagrams: polynomiality and the dense region*, arXiv:2312.13990v1, submitted 21 December 2023.

- Primary source: <https://arxiv.org/html/2312.13990v1>, §4, Proposition 4.1 and proof.
- Verified scope: rank-two scattering with initial powers \((1+tx)^\mu,(1+ty)^\nu\); coefficients are polynomial in \(\mu,\nu\). The proof splits the initial factors into labelled variables and groups by the support of the labels.
- Interface: the support-of-colors regrouping is existing mathematics. Our replication expansion uses that principle for arbitrary-rank theta coefficients, after a specific folding and extraction argument. Do not claim the idea of binomial polynomiality of scattering coefficients is new.
- Audit: useful; theorem statement and proof inspected, not only abstract. Version observed is v1, not a nonexistent v2.

### L2. Zhou, 2020 — useful, exact folding hypothesis

Yan Zhou, *Cluster Structures and Subfans in Scattering Diagrams*, SIGMA 16 (2020), 013.

- Primary source: <https://www.emis.de/journals/SIGMA/2020/013/sigma20-013.pdf>.
- Inspected: §3.1, especially independent-orbit condition (3.1), quotient Lie homomorphism and Theorem 3.2; also the stated scope of §3.3.
- Interface: our block-constant replication satisfies the strong pairing hypothesis. The Lie normalization and the finite theta-extraction argument are written out above. No assertion about every ordinary quiver folding is used.
- Audit: useful, hypothesis matched. The paper's full-Fock–Goncharov transfer theorem alone would not prove the coefficient identity needed here.

### L3. Mandel–Qin, *Bracelets bases are theta bases* — useful caution

Primary source: <https://arxiv.org/html/2301.11101v3>, Appendix A, especially Theorem A.7 and the subsequent folding discussion.

- General symmetric restriction is consistent but need only contain the folded cluster diagram; extra incoming behavior must be addressed.
- This prevents an invalid proof of (F) by symmetry alone. Our block-constant pairing condition and incoming-direction check are essential.
- Audit: useful as a scope check, not a theorem used to assert unrestricted equality. No 2026 revision or date inference is needed.

### L4. Burcroff–Lee–Mou–Musiker–Reineke, JLMS 2026 — relevant but not imported

Primary publisher page: <https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/jlms.70642>.

Search retrieval displayed polynomial and binomial formulas for rank-two wall coefficients. This is relevant prior art for any novelty statement. In this branch, the current publisher source was screened for scope, not fully proof-audited. **No conclusion from it is used in §§2–4.** Parent branches may have a separate full audit. Its scope is rank two; it does not by itself prove our arbitrary-rank theta statement.

### L5. Integer-valued polynomials — standard background only

Primary monograph: Paul-Jean Cahen and Jean-Luc Chabert, *Integer-Valued Polynomials*, Mathematical Surveys and Monographs 48, AMS, <https://doi.org/10.1090/surv/048>.

The binomial basis and finite-difference expansions are standard. We prove the required degree, denominator, and Newton identities directly; no newness is claimed for those algebraic facts by themselves.

### Novelty boundary

The checked literature supplies strong precedents for labelled initial factors, folding, and scattering polynomiality. The precise all-rank statement (R), its theta-extraction proof, and the explicit finite joint \((B,g)\) sign arrangement with coordinate-factorial denominator bound were not located in the targeted search. This is an evidence-limited novelty observation, not a proof of priority. The strongest safe contribution claim is an explicit arbitrary-rank classical theta specialization and a reproducible general proof from the new integer prefix formula plus established folding/positivity machinery.

## 8. Route ledger: successes, non-results, and next hard step

1. **Successful:** full parameter stratification, zero strata, degree bound, ambient integer-valuedness, and the sharper coordinate-factorial denominator.
2. **Successful:** fixed-stratum finite differences and exact interpolation; these do not establish positivity by themselves.
3. **Initially considered, then superseded:** every eventually nonnegative univariate polynomial has eventually nonnegative forward differences. That generic observation was too weak to address the greedy target. Replication proves all forward differences are nonnegative from parameter zero, with a support interpretation.
4. **Successful:** block-constant replication, explicit Lie normalization, halfspace principal-inverse intertwining, support locality, and positive binomial expansion.
5. **Rejected as insufficient:** unrestricted folding based only on quiver symmetry. General restriction can add incoming walls; the strong pairing condition is required.
6. **Not claimed:** continuous gluing of all adjacent parameter polynomials, convexity of their joint graph, or a single convex polytope whose lattice points give every theta coefficient.
7. **Still open for the main task:** intrinsic, subtraction-free configurations for the all-copies-used multiplicities. The new positive parameter expansion identifies these multiplicities precisely; it does not conceal them under an arbitrary-cell construction. In particular the square-free coefficient on the fully replicated quiver is the exact highest-degree target for a further combinatorial mechanism.

