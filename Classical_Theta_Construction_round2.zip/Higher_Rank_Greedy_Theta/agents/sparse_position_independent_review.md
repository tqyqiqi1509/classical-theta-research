# Independent review of the sparse support-position mechanism

2026-11-13. Reviewed `proofs/SPARSE_POSITION_POLYTOPES.md` in full. This
review concerns the general endpoint encoding and its degree-bounded
composition, together with an independent inequality compiler. It does
not infer the construction from a table of known coefficients.

## 1. Exact endpoint and minimality equations

For the maximal path `P(r,s)`, a horizontal start satisfies
`r y <= s x < r(y+1)` and `0<=x<r`; a vertical start satisfies
`s(x-1)<r(y+1)<=s x` and `0<=y<s`. These are equivalent to the
floor/ceiling formulas and give exactly one path edge at each integer
time `t=x+y`.

For a forward horizontal shadow from `h` to a vertical endpoint `e`,
the count of included vertical edges is

`y_e + 1 + w s - y_h`.

For a backward vertical shadow from `v` to a horizontal endpoint `e`,
the count of included horizontal edges is

`x_v - x_e + w r`.

The different endpoint offsets are necessary. They are correct in the
draft, including wrapped shadows.

Let the balance be the opposite-edge count minus accumulated own-color
weight. Immediately after a positive source it is negative. Its only
upward changes are unit increments at opposite-color edges. The other
nonconstant changes are downward jumps at positive own-color edges.
Before each earlier positive jump, the sparse inequalities say the
balance remains at most `-1`. This excludes a prior zero in every
intermediate segment. In the final segment, endpoint equality and unit
increments force the first zero exactly at the proposed endpoint.
Conversely an actual first zero satisfies all these inequalities.

The total-weight bounds ensure existence within one turn. No arbitrary
choice of a compatibility witness remains: every support and weighting
has a unique endpoint for each positive edge.

## 2. Weak orders and a necessary indexing convention

The support labels must be canonical: `H_0,...,H_(kH-1)` occur in that
strict order on the path, and likewise `V_0,...,V_(kV-1)`. Their weights
are the corresponding ordered positive weights. The weak order of the
`2k` support/endpoint labels must respect both positive-support orders.
Endpoints may coincide with each other or with a positive edge of the
same orientation. Positive support labels themselves are distinct.

Without this convention, interchanging equal-weight support labels can
describe the same grading twice. The implementation enforces the
convention, and it was communicated to the root for explicit inclusion
in the statement.

With that convention the weak time order determines all closed shadow
membership tests. For a pair of positive edges, compatibility excludes
simultaneous membership in their two shadows. The two possible
shadow-cover conditions are also determined by the same finite order.
The tests therefore require no comparisons at unmarked zero edges.

## 3. Bounded global dimension and description size

The flattening theorem gives at most `N-1` genuine internal vertices,
at most `N-1` nonempty local paths, and at most `2N-2` positive local
edge slots in the whole tree. Four support/endpoint coordinates per
slot use at most `8N-8` variables. An increasing list of occupied normal
copy positions uses at most one additional variable per nonempty path.
Thus the claimed global bound `9(N-1)` is valid.

Keeping occupied normal positions as variables is relevant to the
uniform piece count. Enumerating each of their numerical values as a
separate discrete type would instead introduce an arrow-dependent
number of pieces. The interval-order simplex

`1 <= j_1 < ... < j_P <= c`

encodes them with `P` variables and no such enumeration.

At fixed `N`, all normalized positive weights and coefficient allocations
are bounded compositions of integers at most `N`; all weak orders have
at most `2k<=2N` labels locally. The independent event/occurrence catalog
already has a bound depending only on `N`. Thus the number of discrete
piece types is bounded by a function of `N`, independent of arrow
magnitudes. Each active local `m`, normal divisor, and rectangle bound is
at most a function of `N` times `M`. Exact event arithmetic has depth at
most `N`, so its rational bit lengths are bounded by a function of `N`
times a polynomial in the input bit length. The compiler uses only
integer affine equations and inequalities of these sizes.

The position polytopes need not be integral or alcoved. The earlier
total-unimodularity result for weight-coordinate cells is not used here.
The fixed-dimensional counting consequence correctly invokes Barvinok
only after constructing the sparse rational pieces; no implementation
of that algorithm, nor a stronger parameterized running-time bound,
is being claimed.

## 4. Independent endpoint computation

`computations/sparse_shadow_endpoint_check.py` uses an edge-by-edge
first-balance walk as its oracle. Its separate sparse predicate uses
only coordinate balances and inequalities immediately before earlier
positive jumps.

The completed run checks:

- Every one-color grading of total weight at most the opposite path
  length on every rectangle with `1<=r,s<=6`: 6,764 gradings.
- All candidate endpoints for their positive shadows: 90,946 candidate
  tests and 17,162 positive shadows. Each has exactly the predicted
  endpoint.
- 12,000 two-color bounded gradings on rectangles up to `35 x 35`:
  the sparse order-only compatibility/shadowed test agrees with the
  literal shadow implementation.

All checks passed. The full record is
`computations/sparse_shadow_endpoint_check.json`.

## 5. A compiler from patterns, without a vertex oracle

`computations/sparse_position_polytopes.py` implements

`compile_pattern(r,s,ordered_H_weights,ordered_V_weights,weak_order)`.

It emits integer matrices `A,b,E,d` for

`A z <= b,  E z = d`.

Its inputs contain no grading enumeration, coefficient, or vertex list.
The emitted constraints are digital-path membership, the prescribed
weak order, endpoint balances, and positive-jump inequalities. Forbidden
compatibility/shadow patterns are discarded directly from their order.

The separate exact integer-point checker eliminates endpoint coordinates
using the linear balance equation and digital-path membership. It does
not walk a shadow. This yields an independent comparison with literal
tight-gradings. All weak orders are enumerated from label sets, including
empty patterns; they are not selected from already found gradings.

Five complete local checks include ordinary, unequal-divisor, and
repeated-degree inputs. In the repeated degree-two Kronecker check,
3,536 retained weak-order patterns are tested, and their 18 nonempty
polytopes have exactly the 19 literal gradings, with one two-point piece.
All five comparisons are bijective and exhaustive. The output JSON
exports the matrices for the nontrivial family below.

## 6. A nontrivial region for every arrow multiplicity

For `m>=2`, on `P(m,m+1)` place one positive edge of each orientation,
each of weight `m`. The horizontal edges are

`H_h=(h,h), 0<=h<m`.

The vertical edges are `V_j=(j,j-1)` for `1<=j<=m`, together with
`V_*=(m,m)`. Every such vertical shadow contains all horizontal edges.
The shadow of `H_h` omits exactly one vertical edge. Compatibility
therefore forces `V=V_*` when `h=0`, and `V=V_h` otherwise. Every forced
pair is shadowed, giving exactly `m` tight gradings.

The cases `h=0` and `h=1` have separate endpoint orders. For
`2<=h<=m-1`, all configurations have order

`horizontal-shadow endpoint < V < H=vertical-shadow endpoint`.

In the variable order `(H_x,H_y,V_x,V_y,h_x,h_y,v_x,v_y)`, their
integer points are exactly

`(h,h,h,h-1,h-1,h-2,h,h), 2<=h<=m-1`.

Thus this pattern has `m-2` consecutive points on a primitive integer
line. For `m>=4` it contains a nondegenerate segment. The compiler checks
`m=2,...,12`, giving pattern sizes `{1,1,m-2}` whenever `m>=3`, and
exports each exact linear system and the line parametrization.

This family illustrates the geometric content of the general encoding;
the bounded-dimension construction does not depend on a reduction to
this family.

## 7. Primary-source counting interface

A. Barvinok, *A Polynomial Time Algorithm for Counting Integral Points
in Polyhedra When the Dimension Is Fixed*, Mathematics of Operations
Research 19(1994), 769--779, DOI `10.1287/moor.19.4.769`.

Primary original scan opened and its first-page Theorem 1.2 and rational
polyhedron reduction read directly:

<https://www.math.ucdavis.edu/~deloera/MISC/LA-BIBLIO/trunk/Barvinok/barvinokpolytime.pdf>

The theorem supplies a polynomial-time lattice-point counter when the
dimension is fixed. Combined with the proved piece-count and binary-size
bounds, it applies at fixed coefficient degree `N`. This is a credited
algorithmic interface, not a new theorem about general lattice counting.
