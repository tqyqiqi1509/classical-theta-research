# Incoming-normalized integer recursion for every classical theta prefix

Date: 2026-11-13. Status: the argument below reduces to the established GHKK
incoming-factor theorem and the previously proved last-exponent extraction.
It removes the negative-frame, negative-product and covering hypotheses from
the computation of every prescribed finite prefix. It does not assert that
every formal theta function is a Laurent polynomial.

## 1. Statement and input

Let B be an integral n by n matrix and let D be a positive integral diagonal
matrix such that DB is skew-symmetric. Use classical principal coefficients
and put z_i=y_i*x^(B e_i). For g in Z^n write the formal theta function at the
initial positive chamber as

    theta_g = x^g sum_(p>=0) a_g(p) z^p.

For any prescribed p, the recursion in Sections 2–4 computes a_g(p) by a
finite calculation using integer binomial coefficients, finite boxes,
linear sign tests, and integer additions and multiplications. Its input is
only B,D,g,p. In particular it does not take a mutation word, a negative
certificate, an enumeration of walls, a broken line, or an unknown theta
coefficient as input.

The calculation may contain negative intermediate integers. Nonnegativity
of the resulting a_g(p) follows from its identification with the classical
theta function; no cancellation-free positive counting rule is claimed.

The result is coefficientwise and unconditional in B. A whole finite
polynomial requires a justified finite support bound. The earlier acyclic,
negative-product, or folded positive carriers still supply such a bound in
their respective classes, but are no longer needed to obtain the entries
inside the bound.

## 2. A root-dependent sign rule

For a nonzero alpha in N^n, choose any r with alpha_r>0. For beta in Z^n
define the following ordered list of integers:

    L_alpha(beta) = (
       (B alpha)^T D beta,
       alpha_r beta_i-alpha_i beta_r : i != r, in a fixed order
    ).                                                        (2.1)

Let sigma_alpha(beta) be the sign of the first nonzero entry of this list,
and let it be zero if the list is zero. Then

    sigma_alpha(beta)=0  iff  beta is a rational multiple of alpha. (2.2)

This is a sign rule for an ordered abelian group: a sum of two positive
lists is positive, and likewise for negative lists. Thus the roots of
either strict sign are closed under addition.

On any finite set of beta, the rule is realized by an ordinary rational
linear functional. Indeed start with the functional

    beta |-> (B alpha)^T D beta

and add successively sufficiently small positive rational multiples of
the remaining linear functionals in (2.1). Every additional functional
vanishes on alpha. Consequently the representing point Q is in
alpha^perp and can be taken arbitrarily close to B alpha, in the pairing
Q^T D beta. The finite inequalities determining the signs are strict, so
there is no uncomputable genericity choice in the recursion: (2.1) itself
decides every sign.

Changing r or the order of the secondary functionals does not change the
final answer, by the uniqueness proof in Section 5.

## 3. Universal integer transport coefficients

Define integers c_alpha(m), for alpha>=0 and m in Z^n, by induction on
|alpha|. Set c_0(m)=1.

If alpha=k e_i, k>=1, set

    c_(k e_i)(m) = binom(-m_i,k).                           (3.1)

For arbitrary integer a and k>=0, binom(a,k) has its usual polynomial
meaning; for a<0 this is

    binom(a,k)=(-1)^k binom(-a+k-1,k),

so (3.1) is an integer.

Suppose now that alpha has at least two nonzero coordinates. Work on the
finite box J_alpha={q in N^n: q<=alpha}. Construct two unitriangular
matrices U^- and U^+ on this box. Their diagonal entries are one.
Process pairs q<s with s-q!=alpha in increasing order of |s-q|. All
entries c_(s-q)(m+Bq) used in the following expression have already been
defined by the outer induction. Put

    R_(s,q) = c_(s-q)(m+Bq)
              - sum_(q<t<s) U^-_(s,t) U^+_(t,q).           (3.2)

Here q<t<s means componentwise inequalities with both endpoints excluded.

If sigma_alpha(s-q)<0, set U^-_(s,q)=R_(s,q), U^+_(s,q)=0.
If sigma_alpha(s-q)>0, set U^-_(s,q)=0, U^+_(s,q)=R_(s,q).
If sigma_alpha(s-q)=0, set both entries to zero. In this last case the
proof gives R_(s,q)=0; an implementation should verify it as an exact
consistency check.

Finally define

    c_alpha(m)=sum_(0<t<alpha) U^-_(alpha,t) U^+_(t,0).     (3.3)

Thus no equation at degree alpha has to be solved and no division by a
pairing, a symmetry factor, or an integer larger than one occurs.
For each requested c_alpha(m), all recursive calls have smaller root
degree, and every matrix in (3.2) is finite. Hence termination is explicit.

The answer on any homogeneous degree g is assembled as

    C^g_(p,q)=c_(p-q)(g+Bq)  for q<=p; otherwise zero.     (3.4)

This is the total negative-to-positive transport matrix that previously
required a finite negative certificate.

### 3.1. Preferred version: one halfspace inverse, no sign-factor matrices

The same recursion has a shorter formulation, implemented independently as
`IncomingSchur`. For a nonaxis alpha put

    S_alpha={q:0<q<alpha and sigma_alpha(q)>0}.             (3.5)

Let E be the unitriangular matrix on S_alpha with entries

    E_(s,q)=c_(s-q)(m+Bq),  q<=s,

and let b_s=c_s(m), r_s=c_(alpha-s)(m+Bs). Then

    c_alpha(m)=r E^(-1) b.                               (3.6)

Every entry on the right has smaller root degree. The empty-set value is
zero. Formula (3.6) is computed without forming a matrix inverse: process
s in increasing degree, set

    v_s=c_s(m)-sum_(q<s, q in S_alpha)c_(s-q)(m+Bq)v_q,
    c_alpha(m)=sum_(s in S_alpha)c_(alpha-s)(m+Bs)v_s.     (3.7)

Equivalently this is the finite explicit chain sum

    c_alpha(m)=sum_(k>=1) (-1)^(k-1)
      sum_(0<q_1<...<q_k<alpha, q_i in S_alpha)
        c_(alpha-q_k)(m+Bq_k)
        product_(j=1,...,k-1)c_(q_(j+1)-q_j)(m+Bq_j)
        c_(q_1)(m).                                      (3.8)

The binomial axis rule (3.1) is the only leaf datum. Recursively expanding
(3.8) gives finite signed trees whose leaves carry ordinary generalized
binomial objects. This is a direct rule in B,D,m,alpha and strict chains.
No signed-factor computation is required in the preferred implementation.

To prove (3.6), use C=U^-U^+ from Section 5. Because sigma_alpha(alpha)=0,
the off-diagonal alpha row of U^- and the zero column of U^+ can only meet
at indices in S_alpha. Moreover restriction to S_alpha respects the
factorization: if p is in S_alpha and U^-_(p,q) is nonzero, then either
q=p or sigma_alpha(p-q)<0, so sigma_alpha(q)>0. Hence

    C[S,S]=U^-[S,S] U^+[S,S],
    C[alpha,S]=U^-[alpha,S] U^+[S,S],
    C[S,0]=U^-[S,S] U^+[S,0].

Substitution gives the Schur identity (3.6). This argument uses sign closure
to justify the restricted multiplication; it does not assume S is downward
closed. It also explains why the positive halfspace in (3.5) cannot be
arbitrarily replaced by the negative one.

## 4. Theta extraction by a halfspace and finite chains

For each nonzero p set m_p=g+Bp and

    I_p={p} union {q:0<=q<=p and m_p^T D(p-q)<0}.          (4.1)

Let t^(p) be the last row of the inverse of C^g[I_p,I_p]. Equivalently,

    t^(p)_p=1,
    t^(p)_q=-sum_(q<r, r in I_p) t^(p)_r C^g_(r,q)       (4.2)

in descending order of |q|. This inverse is an integer matrix; it can
also be written as the finite signed sum over strict chains from q to p.
Define, in ascending order of |p|,

    a_g(0)=1,
    a_g(p)=-sum_(q in I_p, q!=p) t^(p)_q a_g(q).          (4.3)

Every step uses only smaller p. To obtain one coefficient at p, it is
enough to carry out the construction on [0,p]. A total-degree cutoff is
equally valid. Different finite downward-closed truncations agree on their
overlap.

## 5. Proof of the universal transport recursion

The external input is the incoming-factor description of consistent
scattering diagrams: GHKK, arXiv:1411.1394v2, Proposition 1.20 and
Theorem 1.21. In that convention, an incoming wall with normal gamma
contains p*(gamma); the cluster diagram has only its initial simple
incoming walls. Theorem 1.21(1) identifies the ray factor near p*(gamma)
with the prescribed incoming factor, at every finite order. This is an
established theorem; the present construction is an integer matrix
implementation of its inverse map, not a new proof of the existence or
uniqueness of scattering diagrams.

Let C_true be the actual formal total transport from the negative chamber
to the initial positive chamber, acting on monomials and keeping the
frozen variables fixed. Its action on x^m has the shape

    C_true(x^m)=x^m sum_(alpha>=0) c_true_alpha(m) z^alpha.

Because every increment is a nonnegative root, its action on a finite
downward-closed set is a finite unitriangular matrix. No term outside that
set can return to it.

Fix a nonaxis alpha and work to root degree |alpha|. Use Section 2 to take
a point Q in alpha^perp arbitrarily close to B alpha, generic except for
the hyperplane normal to alpha. The sign of every relevant root is exactly
sigma_alpha. The three-factor splitting of total transport at Q is

    C_true = U^- U^0 U^+,

where the nontrivial root increments in U^- and U^+ have respectively
negative and positive sigma_alpha, and U^0 contains only roots parallel
to alpha. The order here is for column vectors, with transport from the
negative side to the positive side.

The ray normal to alpha is nonaxis. Its incoming factor is the identity.
The GHKK incoming-factor theorem therefore gives U^0=1 to the requested
order. Thus C_true=U^- U^+ on the finite interval. At every proper
interval s-q, expanding this identity gives exactly (3.2). The specified
signs determine which factor is allowed to carry the residual. If the
increment is parallel to alpha, neither factor can carry it; its residual
is consequently zero. At the final interval (alpha,0), both factor
entries vanish, so the product identity gives precisely (3.3).

For alpha=k e_i, restriction to that coordinate ray sees only the initial
wall. In negative-to-positive orientation it acts on x^m by

    x^m |-> x^m (1+z_i)^(-m_i),

whose coefficient is (3.1). Induction on |alpha| now proves
c_alpha(m)=c_true_alpha(m) for every alpha,m. It simultaneously proves
integer output, the zero-residual assertion, independence of all tie
choices, and compatibility of finite truncations.

### Principal coefficients and the radical case

The full principal-coefficient incoming vector is (B alpha,alpha).
Frozen directions are linear directions of every relevant wall, so its
projection onto the mutable space is the point B alpha used above.
This agrees with the paired sign (B alpha)^T D beta. It is B alpha,
not -B alpha: in the rank-two convention B=[[0,b],[-c,0]], the recursion
gives c_(1,1)(m)=m_1(m_2-c), agreeing with the independently known acyclic
product formula.

If B alpha=0, no unjustified genericity assumption is made. The secondary
functionals in (2.1) still give a point arbitrarily close to zero in
alpha^perp, generic away from the alpha ray. The incoming-factor theorem
still applies. An independent Lie-algebra check explains why no additional
nonaxis radical factor can occur: for beta+gamma=alpha,

    beta^T DB gamma=beta^T DB alpha=0.

Any nested commutator of total root alpha therefore has zero final
bracket. A nonaxis radical charge is not an additional initial generator.
This check does not replace the incoming-factor theorem, but rules out a
common erroneous extra central-wall input.

## 6. Proof of theta extraction

For completeness, the bridge used in the earlier package is as follows.
For fixed p choose u very close to m_p=g+Bp, with a tiny positive shift,
so that u^T D beta has the sign of m_p^T D beta whenever the latter is
nonzero, and is positive when the latter is zero. One explicit choice on
a root cutoff |beta|<=K is

    u=M m_p+(1,...,1),  M>max_i(D_i) K.

The finite total matrix splits C^g=A^- A^+ by the signs at u. Its inverse
negative factor T=(A^-)^(-1) is the coordinate transport from the initial
positive chamber to u. The row of T indexed by p is supported precisely
inside I_p. From TC^g=A^+, the off-diagonal entries of that row at q in
I_p vanish. Thus its restriction is the last row of C^g[I_p,I_p]^(-1).
This argument does not require I_p to be downward closed.

The last-segment argument says the transported theta function has zero
coefficient at the nonleading increment p: a broken line ending near the
direction of its terminal exponent cannot have a final bend. Along its
last straight segment the pairing with every possible wall normal cannot
change sign, and the tie shift removes zero intersections. The unique
unbent contribution has p=0. Therefore (T a)_p=0 for p!=0. Substituting
the identified row of T is exactly (4.3).

The scattering language is used in this equality proof. It is absent
from all data and operations in Sections 2–4.

## 7. Independent exact verification

Implementation: `incoming_recursion.py`.

Initial checks (`incoming_recursion_initial_checks.json`):

- 516 total-transport coefficients agree with the separate closed acyclic
  generalized-binomial formula, including genuinely skew-symmetrizable
  examples.
- 1,893 residuals on proper roots parallel to the target root vanish.

Extended checks (`incoming_recursion_extended_checks.json`):

- The three Markov theta functions with labels -e_i agree exactly with
  the seven-term folded polynomials from the previous independent
  construction, throughout the larger box [0,3]^3.
- 81 Markov total-transport coefficients agree with direct substitution
  into those independently computed folded generators.
- For a 3-arrow cyclic seed, a cyclic seed with D=(1,2,1), a disconnected
  seed with an isolated vertex, and B=0, 324 paired checks verify both
  multiplicativity in the mutable exponent m and independence of the
  secondary-functional order. Another 108 checks verify relabeling
  covariance.
- The 3-arrow cyclic input with g=(-1,0,0) has 17 nonzero terms in [0,3]^3;
  their coefficients are positive. This is only a finite prefix. No
  global finite-support conclusion is inferred from that computation.

These checks address convention, zero-root, dependence-on-tie-order and
integer-normalization risks. They are not the proof of the general theorem.

## 8. Source and novelty boundary

[1] M. Gross, P. Hacking, S. Keel, M. Kontsevich, *Canonical bases for
cluster algebras*, J. Amer. Math. Soc. 31 (2018), 497–608.
Version read: https://arxiv.org/pdf/1411.1394v2 . The relevant statements
are Definition 1.11, Proposition 1.20 and Theorem 1.21; in that version
they appear on printed pages 21 and 27–28.

[2] F. Qin, *Bases for upper cluster algebras and tropical points*, J. Eur.
Math. Soc. 26 (2024), 1255–1312.
https://ems.press/content/serial-article-files/47257 . This supplies useful
comparison context but is not needed to impose injective-reachability in
the universal prefix theorem.

The mathematically correct novelty claim is limited: the incoming
normalization itself is established theory. What is assembled here is a
finite division-free integer recurrence directly on monomial coefficients,
combined with the explicit last-exponent halfspace extraction. Literature
priority for this exact combined implementation has not been established.
It gives a uniform explicit coefficient algorithm, not a newly proved
global theta-basis existence theorem and not a positive greedy model.
