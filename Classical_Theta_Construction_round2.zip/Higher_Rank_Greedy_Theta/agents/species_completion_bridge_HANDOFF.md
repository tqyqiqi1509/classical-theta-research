# Species completion bridge: final branch handoff

2026-11-13, 12:24 UTC. Main proof file: `agents/species_completion_bridge.md`.

## Delivered mathematical argument

The global reduced-skeleton identity now has a concrete proof draft, not only a functoriality claim:

1. A finite completed colored species algebra with quantum product `(epsilon t)^eta`; `eta=0` gives commutation, so incoming-only completion is algebraically legitimate even for cyclic original cluster data.
2. Local HN and PBW character identities are explicit finite set-partition formulas, (2.3)--(2.4). Every orbit of parallel blocks has the factor `(-1)^((k-1)E) H(t^k)` times the actual return trace.
3. Whole-component parity transport gives arrow parity `E`; no local sign representation or operadic suspension is inserted.
4. The family over all finite type-colored label sets is a symmetric-sequence identity. Schur substitution of arbitrary incoming super species, supported by Maxim--Schurmann Theorem 2.19, gives the exact local primitive-production formula (4.2).
5. The strict-time lemma is the key global step: incoming child `beta` at joint `q` is evaluated at `q+delta eta(beta,-)`. Every nonzero-bracket split confined to the joint plane then has time `-delta`, and is excluded. All other splits retain their strict leading sign. Hence local IC replaces exactly the zero-time refinements; incoming child factors contain exactly the reduced positive-time subtrees.
6. Incoming-half-line telescoping, degree induction, and the zero nonaxis incoming primitive unroll this recursion into exactly the proposed reduced skeleton module. Proper parallel internal children are handled before primitive extraction by the full Fock factor, and never fed back from the outgoing side of the same joint.
7. The classical limit, after forgetting parity only at the end, gives `omega T`; the framed coefficient is primitive because its frame content is one. This yields the weighted-cycle character and therefore the sign multiplicity formula if the draft is accepted.

## The main audit correction

Davison--Meinhardt Theorem D is not fully canonical. Its Section 6.4 explicitly chooses sections of restriction maps. The corrected proof chooses charge-linear positive masses so every slope is generic, averages a section over each stabilizer, and transports it over the group orbit of dimension vectors. Theorem 6.12's printed proof uses only the right-inverse equation, so the resulting Hall multiplication map is still an isomorphism and is equivariant. This is averaging a section of a split surjection, not averaging an arbitrary isomorphism. Both this branch and `species_adversarial_audit` independently inspected the proof's latter half and confirmed the point.

The zero-slope PBW map itself remains canonical and equivariant by the companion `equivariant_dt_proof` argument. No arbitrary global cyclic Hall/cluster identification is made.

## Exact independent computation

* Code: `computations/squarefree_polytope_action/local_species_trace_audit.py`.
* Current data: `computations/squarefree_polytope_action/local_species_trace_audit.json`.
* Preserved first data: `computations/squarefree_polytope_action/local_species_trace_audit_uniform_slope.json`.

The code imports no theta oracle. It starts from the whole thin stack trace, computes all ordered HN partitions, then extracts the primitive using all invariant zero-slope set partitions with block-orbit signs. It compares the result with the independently constructed normal-fan IC trace.

Fifteen full graded-character equalities pass, with both uniform and charge-linear masses. They include the three `K_(2,2),r` families `r=1,2,3`, and the genuinely relevant three-type input `beta_3=beta_1+beta_2` with multiplicities `(1,1,2)` and `(2,2,1)`. Thus proper parallel inputs and permuted parallel composite factors are tested together. These are checks of the general identity, not its proof.

## Scope and status

The main note remains explicitly marked a proof draft for adversarial review. Root and the independent audit agent are reviewing it. This branch has no known remaining mathematical counterexample or unfilled step after the corrections above, but it does not promote its own draft to a final theorem before that review concludes.

The natural graph/fan model here is for skew-symmetric matrices. The weighted-cycle character and sign-multiplicity target itself is already available for skew-symmetrizable matrices in the earlier proof. This branch does not pretend that the ordinary thin-quiver IC argument already solves that valued extension.

The user’s Qiyue Tang manuscript Hexagon `2611.00279v1` was discovered by root at handoff. This branch has not read it and does not rely on it. Root requested a fresh full audit of that manuscript, especially its graph-cone/transportation-polytope character formulas and incoming recursion, before any novelty statement is made. No priority claim is made in this handoff.

## Optional further general check, not started

After parity is forgotten, the quantum binary flow calculation should give the refined cycle character

`sum_T product_v [abs(eta_v)]_t / product_(cycle leaves c) [|c|]_t`,

with `[k]_t=(t^k-t^(-k))/(t-t^(-1))`. This follows formally from the initial cycle factor `H(t^k)` and the quantum bracket, dividing the frame-one output by `H(t)`. The refined module has local factor `t^(-dim) IH_t`; a node orbit of length `L` makes `t->t^L` and contributes its Euler sign. This would test the global graded assembly against general scattering flow, without a theta oracle. It has not been implemented here, since root requested the slot be released for the fresh literature audit.
