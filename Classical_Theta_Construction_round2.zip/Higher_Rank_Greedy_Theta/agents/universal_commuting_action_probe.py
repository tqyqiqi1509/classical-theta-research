"""Generalize twig bundles to commuting charge-subtree rotations.

The local relation ((A,C),B) <-> ((B,C),A) is allowed when eta(A,B)=0.
It preserves the full product of absolute bracket multiplicities, with the
two bracket-color labels following the two commuting branches.  We test
the necessary normal-form and clone-equivariance conditions on all trees.
"""
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import sys,random,json,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from universal_flow_tree_probe import FlowPackets
from universal_twig_action_probe import trees,node,relabel,tree_value


@lru_cache(None)
def mask(T):
    if isinstance(T,int):return 1<<T
    return mask(T[0])|mask(T[1])


def static_weight(F,T):
    if isinstance(T,int):return 1
    return abs(F.pair(mask(T[0]),mask(T[1])))*static_weight(F,T[0])*static_weight(F,T[1])


def rotations(F,T):
    if isinstance(T,int):return
    for side in range(2):
        child=T[side];C=T[1-side]
        if not isinstance(child,int):
            A,B=child
            if not F.pair(mask(B),mask(C)):
                yield node(node(A,C),B)
            if not F.pair(mask(A),mask(C)):
                yield node(node(B,C),A)
        for child2 in rotations(F,child):yield node(child2,C)


def check(B,g,p):
    packets=tuple((i,1)for i,k in enumerate(p)for _ in range(k))
    F=FlowPackets(B,[1]*len(B),g,packets,color_perturb=True)
    colors=tuple(i for i,k in F.packets)
    space=[T for T in trees(F.full)if static_weight(F,T)]
    ids={T:j for j,T in enumerate(space)};parents=list(range(len(space)))
    def find(i):
        while parents[i]!=i:parents[i]=parents[parents[i]];i=parents[i]
        return i
    def union(i,j):
        a,b=find(i),find(j)
        if a!=b:parents[b]=a
    edgecount=0
    for j,T in enumerate(space):
        for U in rotations(F,T):
            assert U in ids,(T,U)
            assert static_weight(F,T)==static_weight(F,U)
            union(j,ids[U]);edgecount+=1
    valid={};counts={};weights={}
    for j,T in enumerate(space):
        value=tree_value(F,T)
        if value:
            cl=find(j);counts[cl]=counts.get(cl,0)+1;valid.setdefault(cl,[]).append(T)
            weights[cl]=value
    dup=[{'class':c,'trees':valid[c],'weight':weights[c]}for c,k in counts.items()if k>1]
    failures=[]
    for cl,Ts in valid.items():
        T=Ts[0]
        for a,b in combinations(range(1,F.r),2):
            if colors[a]!=colors[b]:continue
            U=relabel(T,a,b);dest=find(ids[U])
            if dest not in valid:
                failures.append({'tree':T,'weight':weights[cl],'swap':[a,b],
                                 'relabelled_tree':U,'target_class_size':sum(find(j)==dest for j in range(len(space)))})
                break
        if failures:break
    return {'nonzero_bracket_trees':len(space),'rotation_edges_twice':edgecount,
            'positive_trees':sum(counts.values()),'positive_classes':len(counts),
            'duplicate_classes':len(dup),'duplicates':dup[:1],
            'equivariance_failures':failures,'weighted_total':sum(weights[c]*counts[c]for c in counts)}


def run():
    start=time.time();rng=random.Random(2026111302);records=[]
    examples=[([[0,2,-3],[-2,0,2],[3,-2,0]],(-3,3,-2),(2,2,1))]
    for B,g,p in examples:
        records.append({'B':B,'g':g,'p':p,'result':check(B,g,p)})
    for p in [(2,1),(3,1),(2,2),(2,1,1),(2,2,1)]:
        n=len(p);passes=0;fails=0;first=None
        for case in range(75):
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):B[i][j]=rng.randint(-3,3);B[j][i]=-B[i][j]
            g=tuple(rng.randint(-3,3)for _ in range(n))
            result=check(B,g,p)
            if result['equivariance_failures']or result['duplicate_classes']:
                fails+=1
                if first is None:first={'B':B,'g':g,'p':p,'result':result}
            else:passes+=1
        records.append({'p':p,'passes':passes,'fails':fails,'first_failure':first})
        print('p',p,'pass',passes,'fail',fails,flush=True)
    out={'seconds':time.time()-start,'records':records}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__':run()
