# Actual finite matrices for the local polyhedral module

Branch `/root/ih_global_independent`, 2026-11-13, approximately 11:39–11:50 UTC.
This branch treats classical skew-symmetric cluster inputs. It uses no
Li Fang/Pan conclusion and no theta multiplicity as construction data.

## Outcome

The local fan module and its natural action survive an independent check.
More substantially, there is now a second implementation which constructs
**actual rational vector spaces and matrices**, not merely a recursive
character polynomial. It starts with the face poset, rational spans, and
polynomial restrictions of the normal fan. It forms kernels and quotients
degree by degree and constructs the normalized automorphism lift by a
uniquely solvable linear system.

The new code is

`computations/ih_global_independent/fan_linear_module.py`.

It does not import the incoming recurrence, the theta oracle, the flow-tree
coefficient code, or the fast local determinant-character recursion.
The latter recursion is imported only by a separate comparison script.

The global equality between the skeleton module and the theta weighted-cycle
character remains a separate problem. This report does **not** infer that
equality from the local matrices or the tests.

## 1. The canonical action is genuinely unique

I read the primary text of Barthel–Brasselet–Fieseler–Kaup,
*Combinatorial Intersection Cohomology for Fans*, arXiv:math/0002181v1,
Proposition 1.3 and the full relevant proof of Remark 1.8(iii).

Proposition 1.3 alone proves existence and uniqueness up to isomorphism.
The stronger statement needed here is indeed printed and proved in Remark
1.8(iii): under their vanishing condition V, a degree-zero homomorphism
between minimal extension sheaves is determined by its map at the zero
cone. Remark 1.8(i) establishes V for rational fans.

The proof is particularly useful computationally. For a k-dimensional
cone, the restriction to its boundary is injective in cohomological degrees
at most k, while the free module is generated in degrees strictly below k.
Consequently, after the map has been defined on the boundary, each generator
has a **unique** possible image. Existence follows from Proposition 1.3.

Thus a rational fan automorphism has a unique semilinear normalized lift
which acts as identity at the zero cone. The lifts satisfy the group law,
because both compositions are normalized lifts of the same fan map.
The conclusion does not rely on choosing a symmetric small resolution.

Primary URL: https://arxiv.org/pdf/math/0002181 .

## 2. A fully finite linear-algebra definition

Let P be a d-dimensional bounded polytope presented in nonnegative slack
coordinates, with a point at which every slack coordinate is positive.
All the anti-attractor flow polytopes in the parent construction satisfy
this: the all-unit arrow flow is such a point. Let D be a matrix whose row
space is the linear constraint space. Put

`N = Q^E / image(D^T)`.

The normal fan is represented by the closed zero-coordinate sets I of the
nonempty faces of P. Its cone span is the image of `span(e_i : i in I)` in N.
Inclusion of these sets gives the cone face relation. All closed zero sets
are obtained by taking intersections of the vertex zero sets.

### 2.1 Local modules

For each cone sigma, let

`A_sigma = Sym(V_sigma^*)`,

where a linear polynomial is assigned polynomial degree one, i.e.
cohomological degree two. Start with the one-dimensional module at the zero
cone. Suppose all proper faces of sigma have been processed.

For each degree h, compute the boundary-section space B_(sigma,h): it is the
kernel imposing agreement of sections on intersections of facets. Every
restriction matrix is already available from the preceding cone stages.
Then take

`G_(sigma,h) = B_(sigma,h) / sum_j x_j B_(sigma,h-1)`.

Choose a rational complement by a fixed RREF convention and lift its chosen
basis to boundary sections. Define

`E_sigma = A_sigma tensor (direct sum_h G_(sigma,h))`.

The chosen lifts define restriction maps to every proper face. Multiplying
by restricted monomials gives the restrictions in every desired degree.

For a cone of dimension k, local vanishing says that only

`0 <= h < k/2`

can contain free generators. This gives a finite bound at every induction
stage. It is not a termination test based on a precomputed theta number.

### 2.2 Global quotient

The global section space S_h is the kernel imposing agreement between
sections on maximal cones. The desired degree-h space is

`H_h = S_h / sum_(j=1)^d x_j S_(h-1)`.

All these are ordinary kernels and column-space quotients of finite rational
matrices. The complete module is concentrated in polynomial degrees
`0,...,d`, so constructing through degree d suffices. The code also permits
a smaller degree bound for independent partial checks.

Equivariant Poincare duality gives a useful optional reduction: construct
through `floor(d/2)`, and use the dual of H_h in degree d-h. If a group element
has matrix M on the chosen basis of H_h, it has matrix `(M^-1)^T` on the
dual basis. This reconstructs an actual representation, not just its
dimension. The `ungraded_action` method implements this reduction.

### 2.3 Group matrices

For each fan automorphism g, process the cones in increasing dimension.
On a free generator of degree h at sigma, its already-known image on the
boundary is a vector b. Solve

`restriction_(g sigma, boundary) * x = b`.

The uniqueness statement in Section 1 ensures that this system has a unique
solution in generator degrees. The code checks the absence of free
parameters. Extend by semilinearity on polynomials, then pass to the global
section quotient. This produces exact rational matrices for g on every H_h.

The RREF choices provide convenient coordinates. A different choice gives
an isomorphic representation through the unique normalized sheaf
isomorphism. Neither a desired character nor a desired rank is prescribed.

## 3. The fast nonsimplicial character formula is consistent

The independent matrix implementation confirms the earlier fast algorithm.
Its proof can also be checked directly. For a finite-order rational fan
automorphism g preserving a cone sigma of dimension k, the orbit
corresponding to a face tau contributes

`det(t I - g | V_sigma/V_tau) * G_tau(g,t)`

to the compactly supported equivariant toric E-polynomial. The local
intersection complex is constant along a torus orbit, with the indicated
local fiber. Permuted non-fixed orbits have zero trace. Compact-support
duality identifies the total with `t^k G_sigma(g,t^-1)`; for a rational finite
group representation the inverse element has the same trace.

The local vanishing bound then gives exactly the earlier low-degree
truncation formula. Applying the same orbit decomposition to the complete
fan gives its global determinant formula. The sign coming from compact
support of a torus is already contained in the determinant. No additional
orientation sign should be inserted into the local toric formula.

This is a rational-toric argument. It does not import a conjectural
nonsimplicial extension from a 2026 paper.

## 4. Independent matrix evidence

`fan_matrix_verification.py` compares the actual matrices just constructed
with the separate fast character engine. It checks full group multiplication
as matrix equalities, so it tests more than agreement of dimensions.

### 4.1 Octahedron normal fan

This is a three-dimensional nonsimplicial normal fan. The actual module has
graded dimensions

`(1,5,5,1)`.

For the twelve-element group generated by permutations of the three
coordinate axes and central inversion, all twelve group-element matrices
were constructed. All 576 degreewise matrix multiplication identities pass.
Examples of graded traces are

| Action | Graded trace |
|---|---|
| Identity | `(1,5,5,1)` |
| One axis transposition | `(1,3,3,1)` |
| A three-cycle | `(1,2,2,1)` |
| Central inversion | `(1,3,3,1)` |
| Central inversion times a three-cycle | `(1,0,0,1)` |

All twelve agree with the determinant recursion.

### 4.2 The singular K_(2,2), two arrows per edge

The new engine directly constructed degrees zero through two, sufficient
with equivariant duality to recover the full sixteen-dimensional module.
For identity, row swap, column swap, and both swaps, its low-degree traces
are respectively

`(1,3,4), (1,1,2), (1,1,2), (1,-1,0)`.

For example, on degree one the two generating involutions have exact
matrices

```
R = [[1,0,0], [1,0,1], [-1,1,0]],
C = [[0,1,1], [0,1,0], [1,-1,0]].
```

They commute, square to identity, and `Tr(RC)=-1`. Thus the negative
primitive trace is visible in actual graph-defined matrices, rather than
being inferred from the desired global character.

The full module reconstructed by duality has character

`(16,8,8,0)`.

The simultaneous row-and-column sign-isotypic subspace has dimension zero.
The matrix check does not replace the other skeleton contributions needed
for the global theta character.

There are 624 group-law matrix checks in total. The complete verification
took approximately 6.6 seconds in the local exact rational engine. The
Wolfram plugin separately checked the two generator relations in degrees
one and two, their four traces, and the rank-zero sign projectors. Its raw
response is saved as `fan_matrices_wolfram.json`.

## 5. Correct tree parity: a quadratic-refinement identity

The ordinary tensor candidate first failed, and the initial replacement
`arity - #arrows` also failed at a higher permutation type. Those failures
belong to the global assembly branch. There is an elementary reason to
prefer the corrected local parity

`epsilon_v = #arrows(Q_v) mod 2`.

Let eta be the integral alternating form on the original framed color
lattice. Modulo two, define the quadratic refinement

`q(a) = sum_(i<j) eta(e_i,e_j) a_i a_j`.

It satisfies `q(e_i)=0` and

`q(a+b)-q(a)-q(b) = eta(a,b) mod 2`.

At an internal tree vertex with child charges beta_1,...,beta_s and sum S,

`#arrows(Q_v) = sum_(a<b) |eta(beta_a,beta_b)|`

has parity

`epsilon_v = q(S) - sum_a q(beta_a)`.

Summing over the internal vertices cancels every internal-edge charge once
positively and once negatively. Therefore

`sum_v epsilon_v = q(total charge) - sum_leaves q(leaf charge)`.

For the square-free clone leaves used here each leaf charge is a color basis
vector, including the unique frame, so the last sum is zero. **All skeleton
summands at a fixed degree have the same parity.** The assertion is
independent of the number and arity of contracted events.

By contrast, summing `arity-#arrows` introduces the number of internal
vertices; it is not invariant under an odd-arity contraction. This explains
why checks limited to binary or even-arity repeated packets did not reveal
the earlier problem.

The identity above proves parity compatibility under contraction. It does
not by itself prove that equivariant Hall/PBW maps use this exact action.
The parent and the dedicated DT branch are checking that remaining
categorical normalization. In particular one must track both the Hall
tau-twisted symmetry and the suspension of input leaves.

## 6. A concrete coefficient space, conditional only on the global identity

Suppose W is the direct sum of the graph-defined skeleton tensors, with
the canonical local matrices and corrected super tensor action. A
permutation of equal factors acts by the standard Koszul sign; this gives
an actual group action for any assigned invariant parity. Its cycle trace
formula is the one used by the global assembler.

For `G_p = product_i S_(p_i)`, let s_1,...,s_r be its adjacent-transposition
generators. The alternating coefficient space is computed directly as

`A_(B,g,p) = intersection_j ker(rho(s_j)+I)`.

Hence

`dim A_(B,g,p) = dim W - rank(stack_j (rho(s_j)+I))`.

This is a nonnegative integer by construction, and requires neither
division by the order of the group nor an external positivity theorem.
The helper `sign_subspace` returns an actual rational basis of this space.
If and when the global weighted-cycle character identity is established,
this dimension is the desired classical theta coefficient. Until then it
is a concrete graph/polytope candidate coefficient space, not an asserted
solution of the entire high-rank problem.

## Files and reproducibility

- `computations/ih_global_independent/fan_linear_module.py`: actual finite
  vector-space and canonical automorphism-matrix construction.
- `computations/ih_global_independent/fan_linear_module.json`: four basic
  octahedron matrices and traces.
- `computations/ih_global_independent/fan_matrix_verification.py` and `.json`:
  twelve octahedron actions, four local K22 actions, 624 exact group laws.
- `computations/ih_global_independent/full_local_module.json`: full local
  sixteen-dimensional action reconstructed by equivariant duality.
- `computations/ih_global_independent/fan_matrices_wolfram.json`: independent
  Wolfram raw receipt.

The only implementation issue found while constructing this independent
engine was SymPy's treatment of a zero-column right-hand side in a linear
solve. The zero-cone inclusion is now handled explicitly. This was not a
mathematical counterexample to the fan construction. No failure has been
suppressed from the above distinction between the local theorem and the
still conditional global character claim.
