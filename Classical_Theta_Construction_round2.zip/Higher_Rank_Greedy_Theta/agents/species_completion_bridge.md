# Species completion and the reduced simultaneous-event recursion

Branch: `species_completion_bridge`. 2026-11-13.

This is a proof draft for adversarial review, not a claim that scalar positivity already implies an equivariant theorem. The two points to review most closely are the transported PBW normalization in Section 2 and the local primitive identity in Section 4. The global induction is written independently of an arbitrary cyclic Hall category. Only classical cluster coefficients are the final objects.

## 0. Exact target

Fix an integral skew-symmetric matrix `B`, an integral vector `g`, and `p>=0`. Add one framing color, and write

`alpha=(1,p)`, `eta=-Bhat`, with `Bhat_0i=-g_i`, `Bhat_i0=g_i`.

Fix once and for all a generic lexicographic order on the original color parameters. The initial covector is

`theta_i=mu_i>0`, `theta_0=-sum p_i mu_i`.

The genericity is at the original-color level. Permutations of clone labels of a fixed color therefore preserve every leading test. A different color order can give a different skeleton collection; no canonical identification between those collections is asserted.

For every finite labeled color set `I` of content `(1,p)`, let `W[I]` be the direct sum over the intrinsic reduced simultaneous-event trees defined in `simultaneous_packet_vertices.md`. Its local factor at a vertex with child charges `beta_1,...,beta_m` is the canonical rational toric intersection cohomology of the corresponding thin acyclic quiver at anti-attractor stability. Give that factor parity

`E_v = sum_(a<b) |eta(beta_a,beta_b)| (mod 2)`.

The tensor symmetry is the resulting super symmetry. The local fan action itself is the ordinary graph-permutation action; no sign character is attached to a vertex-label permutation. The assertion to establish is

`Tr(sigma | W[I]) = a^(B^lambda)_(g^lambda)(1,...,1)`,

where `lambda=cyc(sigma)`, `B^lambda_ab=k_b B_(i_a i_b)`, and `g^lambda_a=g_(i_a)`.

All vector spaces used to define `W` are obtainable from the graph and its rational normal fan. The theta coefficient occurs only on the identification side of the statement.

## 1. The finite algebra in which completion is legitimate

Work first with rational Grothendieck classes of finite, weight-graded super representations of products of symmetric groups. The product of colored species is Cauchy induction over ordered disjoint subsets. Under the Frobenius characteristic this is the usual product in the tensor product of symmetric-function rings, one alphabet per color.

Keep the parity line `epsilon` separate from the weight variable `t`:

`epsilon^2=1`, `psi_k(epsilon)=(-1)^(k-1) epsilon^k`, `psi_k(t)=t^k`.

Thus forgetting parity sends `epsilon` to 1 as a ring homomorphism. It is deliberately **not** a lambda-ring homomorphism. All Fock operations must be performed before that forgetting map.

Let a homogeneous component have positive charge `beta`. Twist the Cauchy product by

`z^beta * z^gamma = (epsilon t)^eta(beta,gamma) z^(beta+gamma)`.  (1.1)

The twist is a bicharacter, so the product is associative. The coefficient ring is commutative. In particular `eta(beta,gamma)=0` implies that the corresponding homogeneous terms commute. This is exactly the property that can fail in a raw Hall algebra and that is needed by the incoming-only scattering construction.

Fix a finite upper charge bound before doing anything else. The positive-degree ideal is then nilpotent. Ordered products, inverses, ordinary logarithms, and exponentials are finite coefficientwise. On a ray the product is commutative, so plethystic `Exp` and `Log` are also defined coefficientwise. Inverting the finitely many factors `1-t^(2k)` needed at that bound causes no difficulty.

Put

`H(t)=t/(1-t^2)`.

The initial factor on color axis `i` is

`F_i = Exp_lambda( H(t) p_1(X_i) z^(e_i) )`.  (1.2)

For an ordinary even input alphabet its ordinary logarithm is exactly

`log F_i = sum_(k>=1) p_k(X_i) t^k / ( k(1-t^(2k)) ) z^(k e_i)`.  (1.3)

The finite positive-degree scattering construction and its uniqueness apply to the commutator Lie algebra of (1.1), with the specified incoming axis factors. This is an algebraic completion; it is not identified with the stability scattering diagram of the possibly cyclic original quiver.

For a ray factor `F_rho`, define its primitive species by

`Omega_rho = H(t)^(-1) Log_lambda(F_rho)`.  (1.4)

Whenever several positive charges are parallel, they are included in **one** factor before applying (1.4). Ordinary `log` is not the primitive operation in this statement.

## 2. The local equivariant identity and its normalization

Consider a finite list of input types `a`, with displayed positive charges `beta_a` in a nondegenerate alternating two-plane. All charges lie in a pointed cone. For every finite type-colored label set `J`, make the thin quiver with the prescribed absolute arrow multiplicities. Choose either consistent orientation convention together with the matching sign of King stability; reversing both gives the same construction.

Write `m=|J|`, `E=#arrows`, and `d=E-m+1`. At the anti-attractor stability for the total charge, define the local kernel

`K[J] = epsilon^E t^(-d) IH_t(M_J)`.  (2.1)

If there is no stable full-support locus, this kernel is zero. For the connected, two-slope-or-more event quivers used in a reduced tree, that locus is nonempty. A one-vertex kernel is 1. A multiple-vertex quiver with all displayed charges parallel has no stable full-support locus and contributes zero to the primitive kernel.

### 2.1 Why the family of identities is equivariant

The group preserving input types acts on every thin representation stack. Its action on the full stack cohomology is explicit: if `sigma` permutes the vertices, then

`Tr_sigma H(Rep(Q,1)/T)_vir = t^(m-E) / product_(c cycle(sigma))(1-t^(2|c|))`.  (2.2)

The affine arrow coordinates contribute a virtual weight shift, not a determinant character: a complex linear automorphism preserves the complex orientation. The remaining action is the permutation of the polynomial generators of `H(BT)`.

The unique HN filtration is carried to the unique HN filtration by any quiver automorphism. Thus the whole HN stratification, including the extension correspondences and their complex orientations, is equivariant. A nonfixed orbit of ordered HN strata has trace zero. Fixed ordered strata use invariant subsets, hence unions of complete permutation cycles. Consequently HN factorization is an identity of type-colored species classes, not merely an equality after forgetting group actions.

For completeness, the cohomological splitting used in that assertion can be made equivariant without pretending that an arbitrary decomposition-theorem isomorphism is canonical. Choose a linear form `ell>0` on the pointed charge cone and put `kappa_a=ell(beta_a)`. Use slope `theta(C)/kappa(C)`. Every equal-slope charge image lies on the line `ker(theta-mu ell)` in the event plane, so its skew pairing vanishes. The stability is generic for every slope in the precise sense of Davison--Meinhardt.

In their Section 6.4, the proof of Theorem 6.12 starts with a choice of a right inverse to the restriction from full Hall cohomology to semistable Hall cohomology. This choice is **not canonical**. The restriction map itself is equivariant. On each orbit of dimension components choose a representative, average its right inverse over the stabilizer, and transport it to the other components. Averaging a section preserves the equation `restriction composed with section=id`. All operations are defined in each finite cohomological degree.

The proof of Theorem 6.12 uses only this right-inverse equation: tensoring the sections gives its map `delta_*`; the extension-stack diagram identifies the associated graded of the Hall multiplication with the identity on each HN factor. Its resulting map is therefore still an isomorphism for the averaged sections, by exactly the printed triangular proof. The canonical semistable PBW inclusion is composed with these sections. This gives an actual equivariant ordered-HN/PBW isomorphism. It does not average an arbitrary isomorphism and does not claim that the resulting splitting is canonical. In the present acyclic case the coarse moduli space of all semisimple representations of a fixed dimension is a point, so the absolute version is sufficient. The alternative proof through the equivariant HN filtration and Theorem 4.12's pure split triangles gives the same character identity.

The canonical PBW map of Davison--Meinhardt is equivariant as proved in `equivariant_dt_proof.md`: the full-support IC inclusion and all extension-stack multiplication maps are intrinsic, and the canonical `tau` symmetrizer commutes with graph automorphisms. The anti-attractor Euler form is symmetric on the stability kernel, so the printed PBW hypothesis applies. Reineke's theorem identifies the local BPS factor with the canonical IC used in (2.1).

### 2.2 The parity conversion is not operadic suspension

The physical Hall generator `IC tensor H(BC*)_vir` has parity `chi(u,u)`. The canonical symmetry has exponent

`tau(u,v)+chi(u,u)chi(v,v)=chi(u,v)`.

For two disjoint, isomorphic type-colored blocks, the cross Euler form is minus the number of arrows in either block. Therefore a `k`-cycle of such blocks has precisely the sign

`(-1)^((k-1) E_block)`.

That is the super permutation sign of the kernel parity in (2.1). The weight normalization also agrees, since

`H(t) t^(-d)=t^(m-E)/(1-t^2)`.

The conversion shifts each **whole thin component** by its label count with a trivial action on that shift line. It does not tensor individual odd leaf lines and does not attach `sgn_(S_m)` to local IC. Equivariant identities are checked on the actual PBW permutation maps, using the preceding cross-Euler calculation.

One must not claim a stronger symmetric equivalence for arbitrary distinct dimension components. After projection, different type-count vectors can lie on the same ray and their residual `tau` symmetry need not be the standard super symmetry. This does not invalidate the species-class identity: a type-preserving permutation can cycle factors only when their type-count vectors agree. Distinct type-count components enter by `Exp(A+B)=Exp(A)Exp(B)` and are not permuted into one another. Thus the character of the actual PBW assembly equals the character of the super Fock assembly with (2.1), for every type-preserving permutation. Equality of all characters proves equality in the rational representation ring.

The Cauchy product normalization is (1.1). Indeed the parity difference between a full thin component and its ordered disjoint subcomponents is the total cross-arrow count, congruent to the alternating pairing modulo two. The ordinary weight twist is the familiar HN Euler twist. This gives `(epsilon t)^eta` rather than a guessed independent vertex sign.

For a zero-arrow graph, `E=0` and (2.2) is the ordinary symmetric Fock trace. This is the initial factor (1.2), with no sign on clone permutations.

### 2.3 Fully explicit finite character identities

Here are character identities that make the preceding species statement independently checkable. They also specify primitive extraction without shorthand lambda notation.

For a finite input label set `J`, an automorphism `sigma`, and a stability `theta`, write

`A[J,sigma](t) = t^(|J|-E_J) / product_(c in cyc(sigma))(1-t^(2|c|))`.

Let `S[J,sigma;theta]` be the normalized semistable-stack trace at the slope of `J`. Choose positive masses `kappa_a`, put `kappa(C)=sum_(a in C) kappa_a`, and `mu(C)=theta(C)/kappa(C)`. For the equivariant ordered-PBW proof just given, use `kappa_a=ell(beta_a)`. The ordered HN identity is

`A[J,sigma] = sum_(J=J_1 ordered-disjoint-union ... ordered-disjoint-union J_s)`

`    t^(sum_(a<b) eta(beta_(J_a),beta_(J_b))) product_a S[J_a,sigma|_(J_a);theta]`.  (2.3)

The sum uses exactly the ordered partitions whose blocks are individually `sigma`-invariant and satisfy `mu(J_1)>...>mu(J_s)`. The one-block partition is included. Subtracting all partitions with at least two blocks recursively computes `S`. No orbit factor, factorial, or hidden choice of a filtration occurs: HN filtrations are unique. The common epsilon parity has already been removed on both sides; the epsilon power of every summand is the same as that of the full component.

Any positive `sigma`-invariant masses can also be used in (2.3), by the nongeneric cohomological HN theorem 4.12. The zero-slope term, and hence (2.4), does not depend on these masses. The first version of the independent code used all masses equal to one; the proof may instead use the displayed charge-linear masses to make every intermediate slope generic.

Now suppose `theta(J)=0` and its zero-slope Euler form is symmetric, as at a local anti-attractor event. Write `Omega[C,rho](t)` for the ordinary trace of the normalized primitive kernel, with its epsilon parity remembered separately. Then canonical equivariant PBW gives

`S[J,sigma;theta] = sum_(P)`

`    product_(O in P/<sigma>) (-1)^((k_O-1) E_C) H(t^(k_O)) Omega[C,sigma^(k_O)|_C](t^(k_O))`.  (2.4)

The sum uses every `sigma`-invariant unordered set partition `P` of `J` such that `theta(C)=0` for every block. For each orbit `O` of blocks choose one representative `C` and let `k_O=|O|`. The choice of representative changes nothing. A non-invariant partition has trace zero and does not occur. The return permutation is the actual restriction of `sigma^(k_O)` to `C`.

The one-block term in (2.4) is exactly `H(t) Omega[J,sigma](t)`. Therefore (2.3)--(2.4) are a finite, triangular recursion for every primitive character. Every other primitive is evaluated on fewer original labels. In particular a pair of parallel blocks exchanged by `sigma` contributes one return trace at `t^2`, not the square of a fixed-block trace and not a separate primitive of the doubled projected charge.

For the local graph under consideration,

`Omega[C,rho](t) = t^(-dim M_C) Tr(rho | IH_t(M_C))`,  (2.5)

with parity `E_C`; it is zero if no stable full-support locus exists. Formula (2.5) is the BPS/IC theorem, and (2.4) is its actual canonical equivariant PBW map evaluated on a permutation. The sign in (2.4) was derived from that map's cross Euler symmetry in Section 2.2. These displayed finite identities are the promised generating identity behind the free-species substitution.

For example, for `K_(2,2)` with `r` arrows on each edge and the simultaneous row and column swap, (2.3) reduces to

`S_sigma(t)=(t^(4-4r)-t^(4+4r))/(1-t^4)^2`.

There are two nontrivial invariant zero-slope partitions, the two perfect matchings. Each has one orbit of two `(1,1)` blocks and contributes

`(-1)^r H(t^2) t^(-2(r-1)) (1+t^4+...+t^(4r-4))`.

Consequently (2.4) gives, for `r=2`,

`Omega_sigma(t)=t^(-5)(1-t^2-t^8+t^10)`.

This is the independently computed canonical IC trace; its value at 1 is zero. For `r=1` it gives `t^(-1)+t`, whose value at 1 is two. Thus the parallel-block terms and their Euler sign are indispensable even in this finite exact identity.

## 3. Universal input substitution, including odd modules

The preceding construction is made for **every** finite set of each input type, with its whole product-of-symmetric-groups action. It therefore gives an identity in the completed ring of symmetric sequences, equivalently in the free colored lambda ring.

Let `V_a` be any positive-degree homogeneous incoming super species, of displayed charge `beta_a`. Apply the lambda-ring substitution

`p_1(X_a) -> V_a`, hence `p_k(X_a) -> psi_k(V_a)`.

Concretely this is Schur substitution: a partition into input blocks receives the kernel on the block set tensored with the incoming species on each block, and one takes the corresponding induction/coinvariants. This definition does not choose bases of `V_a`, and does not assume that its representation is a permutation representation. It applies equally to an odd species.

The compatibility of this construction with characters is the standard symmetric-sequence composition identity: Maxim--Schurmann, Theorem 2.19 (also stated as Theorem 1.9), with their Definition 2.17 of coefficient-valued plethysm. Its hypothesis that the substituted sequence have zero degree-zero term holds here because every incoming block has positive charge. Their Theorem 2.2/1.4 identifies the Adams operation by the trace of a cycle, exactly the operation displayed in (2.4). The colored version is obtained by keeping one independent alphabet for each type.

The quantum twist is preserved because the pairing of input types is the pairing of their displayed charges, and the pairing is bilinear. Charge projection and this substitution commute with `Exp` and `Log`. Thus the local species identity remains valid after arbitrary such homogeneous substitution. No assertion about a `GL(V_a)` action on a basis-expanded quiver is needed. The odd-loop construction of Davison--Mandel is a compatible scalar device, but is not required for this substitution argument.

This is where parallel equal-charge branch plethysm enters. It is part of the same substitution, not an additional correction made after local traces have been computed.

## 4. A local primitive-production identity

Fix a joint `q`, a rank-two charge plane `K`, and a target charge `S` in its pointed positive cone. For every proper positive charge `beta` in `K`, let `V_beta` be the incoming primitive evaluated at

`q + delta eta(beta,-)`, with `delta>0` sufficiently small.  (4.1)

Use the whole local incoming factor, including every parallel charge. Form the local acyclic completion on the free input-type lattice and substitute the `V_beta` as in Section 3. The charge projection preserves both the skew pairing and the incoming direction. Hence no outgoing wall can become a new incoming wall under this projection: an outgoing support containing the projected incoming direction would already contain its pulled-back incoming direction.

More explicitly, for `phi(e_a)=beta_a` and `eta_free=phi^*eta`, every free charge `gamma` satisfies

`phi^*(eta(phi(gamma),-)) = eta_free(gamma,-)`.  (4.0)

Thus if restricting a free wall to the pullback stability subspace made its projected support contain the incoming direction, its original support would already contain the right-hand side of (4.0). This strong pullback identity is the reason the argument is valid. It is not a general assertion about arbitrary quiver folding.

The local projected completion therefore has exactly the prescribed incoming factors. At anti-attractor stability, its primitive `S` coefficient is

`V_S + sum_(P, |P|>=2) K[P] tensor product_(C in P) V_(beta_C)`.  (4.2)

Here `P` is a partition of the actual original labels, each block has its displayed charge, and `K[P]` is (2.1) for the child-block quiver. Induction over partitions is understood. Only partitions spanning the joint plane have a nonzero new full-support kernel.

There are three reasons (4.2) has no omitted term.

1. The preexisting degree-`S` incoming primitive passes unchanged: in the finite degree-`S` calculation it cannot combine with another positive charge and remain in degree `S`.
2. All nontrivial new terms use at least two proper positive blocks. They therefore involve strictly smaller label sets and can be handled by degree induction.
3. The operation giving (4.2) is plethystic `Log` of the **whole ray factor**, after projection/substitution. Pure parallel assemblies belong to the Fock operation; they do not become a second primitive. For a partition consisting solely of parallel input blocks, the stable full-support IC kernel is zero. For a mixed-slope partition that contains some blocks parallel to `S`, the full thin IC kernel remains and computes that contribution once.

In particular, indivisibility of `S` in the original color lattice is not used. The auxiliary all-one dimension vector on the child-block quiver is indivisible; projection may make its charge divisible, and the lambda-ring projection still commutes with primitive extraction.

Equation (4.2) is the substantive local statement supplied by the equivariant HN/PBW identity, rather than a consequence of scalar positivity.

## 5. From local production to exactly the reduced trees

We now give the global induction. Work in a fixed finite degree, and let `theta(S)=0`. Follow the incoming half-line

`q(t)=theta+t eta(S,-)`, `t>=0`.  (5.1)

Combine all parallel charges into one ray factor along this line. There are finitely many relevant joints after the degree truncation. Original-color genericity ensures that each nontrivial event is described by one nondegenerate two-plane; the plane lemma proves the same fact recursively after an ancestor projection. An identically parallel hyperplane is not an additional crossing.

At every relevant joint use the difference (4.2) between the outgoing and incoming primitive. The inherited incoming value on a child `beta` is precisely (4.1). The following sign observation identifies its induction expansion without ambiguity.

**Strict-time lemma.** Suppose a proposed split `beta=L+R` lies entirely in the current joint plane. Then `q(L)=0`, and its flow time at the incoming child point (4.1) is

`-[q(L)+delta eta(beta,L)]/eta(beta,L) = -delta < 0`,

provided its bracket is nonzero. It is therefore excluded from the incoming child expansion. A split outside that plane has a nonzero leading original-color form; a sufficiently small `delta` does not change its leading sign. Such a split is retained exactly when its leading flow time is strictly positive.

Thus the child species in (4.2) expands into precisely the reduced positive-time subtrees. The zero-leading-time refinements at the joint are represented by the single local IC kernel `K[P]`. They are not also inserted recursively into an incoming child.

The root event has positive time exactly when its joint lies on the positive half-line (5.1). Gluing its partition of children to their already determined reduced subtrees is bijective with the intrinsic reduced skeletons whose root event is that joint. The partition is recoverable from the immediate children of the skeleton, so there is no multiplicity from a choice of binary refinement.

Start sufficiently far along (5.1). Incoming normalization gives zero primitive for every nonaxis charge; a singleton axis has its prescribed input. Telescope the finitely many joint differences back to `theta`. Degree induction applies because every nontrivial child block is proper. The resulting primitive is exactly

`sum_(reduced skeleton T) tensor_(vertices v of T) epsilon^(E_v) t^(-d_v) IH_t(P_v)`.  (5.2)

Its group action is the natural action on the skeleton family and on the local factors, with the stated super permutation symmetry.

### 5.1 Divisible internal roots and proper parallel children

If a proper child `beta` is parallel to `S`, then `eta(beta,-)` is a positive multiple of `eta(S,-)`. Its incoming point (4.1) is on the same incoming side of the same joint. A nonparallel split of `beta` inside the joint plane still has time `-delta`; a parallel split has bracket zero. Thus no new primitive of `beta` produced at the current joint is fed back as an incoming child of the same joint.

All multiplicities of parallel children are already retained in the Fock factor and in the Schur partition operation of (4.2). Taking plethystic `Log` before the degree recursion prevents both omission and duplicate counting. The recursion terminates by the number of original labels, not by primitivity of their projected charge.

If `eta(S,-)=0`, a bracket with total charge `S` vanishes: `eta(L,R)=eta(L,S)=0`. Therefore no nonaxis primitive can be created in degree `S`; incoming normalization makes it zero. The reduced tree model has no permissible root split either. This treats the radical without pretending that its incoming direction is a nonzero generic vector.

## 6. The classical character and the framing extraction

Forget `epsilon` only after (5.2) and all Fock operations have been assembled. This is a ring homomorphism, so it sends the finite completion to the ordinary quantum completion with the same initial factors (1.2). It does not need to commute with `Exp` on arbitrary odd inputs.

From the exact initial logarithm (1.3),

`lim_(t->1) (t-t^(-1)) log F_i = -sum_(k>=1) p_k(X_i)/k^2 z^(k e_i)`.  (6.1)

The quantum commutator divided by `t-t^(-1)` tends to the Lie bracket with structure constant `eta`. In the framed wall convention of `universal_tree_positive.md`, identify this basis element with `-E_beta`, since `[E_beta,E_gamma]=-eta(beta,gamma) E_(beta+gamma)`. Then (6.1) is the wall input

`sum_(k>=1) p_k(X_i)/k^2 E_(k e_i)`.

The distinction between wall and transport logarithms is explicit in this dictionary:

| Quantity | Convention |
|---|---|
| Root derivation | `E_beta=z^beta partial_beta`, `[E_beta,E_gamma]=-eta(beta,gamma) E_(beta+gamma)` |
| Cluster wall logarithm | `I_i=sum_(k>=1) (-1)^(k-1) p_k(X_i) E_(k e_i)/k^2` |
| Cluster transport logarithm | `L_i=-I_i`, as in `replication_independent_proof.md` |
| Involuted wall logarithm | `omega I_i=+sum_(k>=1) p_k(X_i) E_(k e_i)/k^2` |
| Quantum-to-classical map | `z^beta -> -E_beta`; the limit (6.1) maps to `omega I_i` |
| Framed extraction | `+[E_alpha] I_theta`, since `alpha_0=1` |

Thus this limit is not being equated directly to the transport logarithm `L` of the replication note.

It is exactly the result of applying the symmetric-function involution `omega(p_k)=(-1)^(k-1)p_k` to the ordinary cluster wall input. Thus finite incoming uniqueness identifies the framed classical coefficient with `omega T_(B,g,p)`, where the independent polarization calculation gives

`omega T_(B,g,p) = sum_lambda chi(lambda) p_lambda(X)/z_lambda`.  (6.2)

At total framing degree one, no product of two positive parallel framed roots and no nontrivial multicover can have that degree. Therefore the framed ray coefficient is simply `H(t)` times its primitive. The one-frame wall extraction in `universal_tree_positive.md`, Section 1.1, cancels the remaining sign and identifies the coefficient of (5.2), at `t=1` and after forgetting parity, with (6.2).

Consequently its Frobenius coefficient is `chi(lambda)` for every cycle type. Equivalently, the proposed graph/fan module has the weighted-cycle character. Taking its sign-isotypic subspace gives the original classical theta coefficient by the independently proved cycle-index identity.

The equality is coefficientwise and does not assert that every formal theta series has finite Laurent support.

## 7. The arbitrary-star normalization test

Take `B=0` and `g_i=-r_i`, with `r_i>=0`. No unframed nonzero event exists. Original-color genericity orders the distinct colors along the framed spine. For color `i`, all its clone leaves occur in one star event, with `r_i` parallel arrows from the center to each leaf, up to the global orientation convention.

The local moduli space is `(P^(r_i-1))^(p_i)`. Its ordinary intersection cohomology is `(Q^(r_i))^(tensor p_i)`, and `S_(p_i)` acts by the ordinary permutation of these even cohomology factors. The whole vertex carries parity `p_i r_i`, but a permutation of its child labels acts trivially on that one parity line. The group does not exchange this framed vertex with another vertex. Therefore

`Tr(sigma | W) = product_i r_i^(number of cycles of sigma_i)`.

This is the required normalization. An extra local sign representation or an operadic desuspension would fail this test. The initial Fock formula gives the same result directly, because its zero-arrow axes have ordinary symmetric Fock trace.

### 7.1 An exact three-type challenge to parallel input assembly

The independent script `computations/squarefree_polytope_action/local_species_trace_audit.py` implements exactly (2.3)--(2.4), using rational functions in `t`, and compares the result with the independent normal-fan IC algorithm. It imports no theta routine. Its output is the companion JSON file.

All 15 recorded graded equalities pass for both the original uniform HN masses and the charge-linear masses `kappa_a=beta_(a,1)+beta_(a,2)`. The original uniform-mass result is preserved separately as `local_species_trace_audit_uniform_slope.json`; the current result records both calculations. Nine are the identity, one-side swap, and two-side swap on `K_(2,2)` with arrow multiplicity 1, 2, and 3. The remaining six use three input types

`beta_1=(1,0)`, `beta_2=(0,1)`, `beta_3=(1,1)=beta_1+beta_2`.

The third input is a proper parallel input for the total root. For type counts `(1,1,2)`, both type-preserving permutations give normalized IC trace

`t^2+1+t^(-2)`.

For type counts `(2,2,1)`, the four permutations give

* identity: `t^4+4t^2+5+4t^(-2)+t^(-4)`;
* either one-side swap: `t^4+2t^2+3+2t^(-2)+t^(-4)`;
* the two-side swap: `t^4+1+t^(-4)`.

These test both different input-type contents on the same projected ray and nontrivial cycles of parallel composite factors. They support the formulas but do not replace the equivariant HN/PBW argument.

## 8. Sources, scope, and route record

* Arguz--Bousseau, arXiv:2102.11200v2: the general scattering flow construction, especially the incoming-half-line telescoping in the proof of Theorems 4.14/4.23 and Theorems 4.22/4.24. The present Section 5 replaces generic binary joint brackets by the full local species identity; it does not cite a nonexistent equivariant theorem from that paper.
* Davison--Meinhardt, arXiv:1601.02479v5: canonical full-support inclusion, `tau` symmetry, and Theorem 6.9. The finite-group equivariant corollary is proved in the companion local note. This branch also directly inspected Theorem 4.12 and its proof (69)--(74), and Section 6.4/Theorem 6.12 through Corollary 6.13. The chosen restriction sections in that latter theorem are not canonical; the precise finite-group repair is in Section 2.1 above.
* Davison--Mandel, arXiv:1910.12915v3: Section 7.1, especially the corrected incoming definition and Lemma 7.5 for acyclic quivers. No claim that a cyclic zero-potential Hall diagram has only axis incoming data is used.
* Reineke, arXiv:1511.08316: the local small-resolution and IC identification, with all hypotheses checked in `proofs/local_rank_two_ih_interface.md`.
* Maxim--Schurmann, arXiv:1602.06546 / *Advances in Mathematics* 375 (2020), 107373: the abstract character and plethysm calculus for symmetric sequences. The author-hosted primary PDF `https://people.math.wisc.edu/~lmaxim/equivgen.pdf` was located in the 12:13 UTC review; Theorems 1.4, 1.9, Lemma 2.13, Definitions 2.15/2.17, Theorem 2.19 and its proof, and Example 2.20 were then inspected. They support the standard Schur substitution interface; they are not a substitute for the special `tau` trace calculation above.

Rejected or tightened steps recorded during this branch:

1. Ordinary Cauchy exponential is not the initial Fock species. It would lose nonidentity cycle traces. Equation (1.2) uses plethystic `Exp`.
2. A local IC trace is not a folded primitive tree coefficient. The `K_(2,2)` double-swap example already disproves that assertion. Sections 3--4 retain full parallel-factor assembly.
3. A global Hall category for the cyclic original quiver is not assumed. Only the explicit algebra (1.1) and acyclic local identities are used.
4. Self-Euler parity `m-E` at each tree node is incorrect. The canonical cross-Euler PBW symmetry gives `E`; the four-cycle counterexample remains preserved in the computation branch.
5. Whole-component parity regrading is not an operadic suspension. No sign representation is introduced at a local node.
6. A full symmetric untwisting of `tau` after an arbitrary charge projection is stronger than needed and can be false. The species-class statement is established by actual permutation traces, whose cycles preserve input-type content.
7. The treatment of a proper parallel child is degree induction plus plethystic primitive extraction, not a claim that the parent root is always primitive.
8. Theorem D was briefly proposed as a canonical HN map. Direct reading of Section 6.4 rejected that wording: it chooses right inverses. The corrected equivariant proof averages those sections and then applies the same printed triangular-isomorphism argument. An independent agent checked that only the right-inverse property is used.

No 2026 theorem and no Li--Pan conclusion is used in this draft.

At the 12:13 UTC search, arXiv:2611.02577 also appeared, on symmetric-product equivariant L-classes of Witt spaces. It is not used: its analytic characteristic-class conclusion does not supply the missing local Hall/PBW identity. Its mathematical correctness has not been audited here, and no inference in this note depends on it.
