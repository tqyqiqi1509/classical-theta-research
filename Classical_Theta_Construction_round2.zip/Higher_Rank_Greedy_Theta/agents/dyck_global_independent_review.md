# Independent review of the finite Dyck event grammar

Date: 2026-11-13, 14:27 UTC. Reviewer: fresh independent agent.

## Conclusion

The proposed construction gives a finite, positive, purely combinatorial
set for every prescribed coefficient of the classical formal theta
series, for an arbitrary integral skew-symmetrizable exchange matrix.
I found no counterexample or missing positivity operation in the five
requested interfaces. The global identification needs the finite-group
argument in Section 4 below: it makes completeness of the event list,
the direction of local refactorization, and multiplication of inherited
and new parallel factors precise. With that argument included, the proof
closes using the stated 2025 tight-grading identity and the established
incoming-normalization/theta bridge.

This conclusion is coefficientwise. It is not a proof that every formal
theta series has finite support, or that an arbitrary classical cluster
algebra has a theta basis indexed by every integral tropical point inside
the ordinary, uncompleted algebra. It also does not establish a literature
priority claim for this particular assembly of known identities.

I did not repeat the random, repeated-color, or local-normal numerical
batches. This review checks the general mechanism and its definitions.

## 1. Exact finite setting

Fix a target charge S in N^r, S nonzero, and retain only charges a with
0 <= a <= S componentwise. Charges outside this box form an additive
monoid ideal: a charge that leaves the box cannot return by addition of
positive charges. The associated positive-charge Lie algebra therefore
has a finite nilpotent quotient. Its height filtration is |a|=sum a_i.

Use K(a,b)=a^T D B b and eta=-K. The ambient normal is

    w(a)=gcd_i(D_i a_i),       n_a=D a/w(a).

For a positive packet F supported on multiples of a, write T_a(F) for
the positive-normal automorphism

    T_a(F)(x^m)=x^m F(z^a)^(n_a dot m).

Its action on root monomials z^b has exponent K(a,b)/w(a). The actual
negative-to-positive crossing has automorphism T_a(F)^(-1). Keeping this
distinction is essential: the local positive word is a factorization of
the inverse of the corresponding transport element.

One can work throughout in the faithful principal-coefficient ambient
action, or in the abstract charge-graded Lie algebra. Restricting only
to the root monomials can lose central operators when K has a radical;
that restricted action must not be used to justify uniqueness.

For any finite lexicographic rational covector theta, the positive,
zero, and negative root spaces are Lie subalgebras. The ordered product
map gives a unique factorization

    C = C_(theta,-) C_(theta,0) C_(theta,+).               (1)

This follows directly by height induction: in the next height quotient,
the three sign subspaces are a direct sum, and multiplication adds the
three components. In particular, (1) depends only on the signs of the
finitely many retained charges. No scattering support enumeration is
needed for this observation.

## 2. Genericity, event uniqueness, and termination

Assume ker_Q Theta=Q S and Theta(S)=0. For a proper charge b<=S with
eta(S,b) nonzero, define

    tau=-Theta(b)/eta(S,b),
    q=Theta+tau eta(S,-),
    P=span_Q(S,b).

If q(c)=0, then

    Theta(c-eta(S,c)b/eta(S,b))=0,

so c belongs to P. The reverse inclusion is immediate. Hence ker_Q q=P.
In particular, eta restricted to P is nondegenerate. Two choices of b
give the same event exactly when they give the same plane: on P, both
Theta and eta(S,-) vanish on S, so their quotient is fixed. Distinct
planes cannot have the same event time, since that would give a kernel
of dimension at least three.

For a child charge T=j rho in P, use

    Theta_child=q+delta eta(rho,-),

with a fresh final lexicographic coordinate delta>0. Its rational kernel
is Q T: the old coordinates first force c into P, and the final one
then forces eta(rho,c)=0 inside the nondegenerate plane P.

For a nonparallel c in that same plane, the child's event time is

    -Theta_child(c)/eta(T,c)=-delta/j<0.                 (2)

Thus the current joint cannot feed back as a future incoming event. For
c outside P with eta(T,c) nonzero, the old part q(c) is nonzero and the
same perturbation merely adds -delta/j to the previous event time. Its
leading sign is unchanged. This proves the intended incoming-germ
convention; it is not a numerical genericity assumption.

Every child has |T|<|S|. The branching set is finite and depth is at most
|S|-1. Hence the event recursion is well founded independently of all
coefficient values. Formal lexicographic signs can also be realized by
sufficiently separated positive rational infinitesimals on the finite
set of inequalities in any one computation.

## 3. The local Dyck operation and unreduced carriers

Take nonparallel positive carriers alpha,beta with m=K(alpha,beta)>0,
d=w(alpha), e=w(beta). Set u=m/d and v=m/e. Both are positive integers.
In the rational basis alpha/v, beta/u the two normalized derivations
are the standard determinant-one derivations. The two input functions
are F(x^v) and G(y^u).

For positive coprime a,b, retain gamma=a alpha+b beta without dividing
its ambient coordinate gcd. Put

    ell=gcd(av,bu),       A=av/ell,       B=bu/ell,
    c=m w(gamma)/(ell d e).

There is an exact equality of ambient normal vectors

    A n_alpha+B n_beta=c n_gamma.                       (3)

The left side is integral and n_gamma is primitive, so c is a positive
integer. Equivalently,

    c=w(gamma)/gcd(ad,be),

and the denominator divides every coordinate of D gamma. Equation (3)
proves the power rule H_gamma=f_(A,B)^c on the full ambient torus, not
merely after restricting to the two-dimensional charge plane.

The standard factor f_(A,B) has only exponents j gamma. Indeed invariance
under x->xi x, y->zeta y with xi^v=zeta^u=1 gives v|tA and u|tB for a
nonzero term of exponent t(A,B). These are a(t/ell),b(t/ell) integral;
coprimality of a,b gives ell|t. Thus there is no hidden fractional
carrier, and coefficients at other enlarged-lattice degrees vanish.

For coefficient j choose the deterministic rectangle (r,h) with

    A h-B r=1,       r>=j av,       h>=j bu.

The 2025 tight-grading formula applies at standard degree j ell. It
counts compatible, shadowed gradings of total vertical weight jav and
horizontal weight jbu. Replacing the two input series by F(x^v),G(y^u)
retains exactly weights divisible by v and u respectively. The vertical
edges are decorated by F's coefficient objects, and the horizontal
edges by G's. This is the same direction of weights as the primary
paper's definition. Taking c ordered copies realizes the power in (3).

These are actual bounded edge-weight objects. Their cardinalities are
not used to define them. The report's older option of orbit labels
{1,...,coefficient} is unnecessary and should be explicitly marked as
superseded by this Dyck construction wherever it remains in earlier
notes.

At a local word exchange, gamma has strictly greater height than both
parents. A fixed pair of occurrences can cross at most once, since only
a strict inversion is exchanged and insertion does not change the
relative order of existing other occurrences. Height induction gives
finitely many occurrences, then finitely many exchanges. Positive
charges in P lie in a pointed cone, so K supplies a consistent angular
order. Equal-ray occurrences commute and need not be merged.

The final packet on any ray is

    original incoming packet times all newly born packets on that ray.

There is no quotient, no cancellation, and no assertion that the
inherited coefficient was zero. Unreduced birth carriers are essential
to this statement: they keep their actual monomial steps while sharing
the correct primitive normal.

## 4. The missing global lemma, proved algebraically

Let C be the group element supplied by the proved
`INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`, restricted to the finite
box. That theorem establishes group membership and the prescribed
incoming zero-factor conditions, using the established GHKK result.
No wall-support geometry is assumed in the argument here. For a generic
point on S-perp write the zero factor of (1)
as the inverse of T_(rho(S))(F_S). The desired coefficient is the
coefficient at charge S in this ray function.

### 4.1 Why the event list is complete

Consider theta(t)=Theta+t eta(S,-) for decreasing t from a sufficiently
large positive value to zero. A retained charge a not parallel to S
can change sign only at

    t=-Theta(a)/eta(S,a),

with nonzero denominator. These are exactly the listed events; equal
planes have already been deduplicated. A charge with zero denominator
has constant nonzero sign. Since (1) depends only on these signs, the
zero-ray packet is constant between consecutive events.

For intermediate parameter values it suffices that the retained zero
charges are parallel to S. A rational kernel direction outside the box
does not affect the finite group. Thus this is a finite ordered-parameter
argument, with no assumption of global real genericity along the line.

This proves completeness using the finite sign arrangement itself.
It does not assume that a previously unknown wall boundary has already
been found. Events having no effective local factors simply contribute
the identity.

### 4.2 Why only the plane P matters at one event

At q use

    C=C_(q,-) C_(q,0) C_(q,+).

For q+delta psi, the signs of charges outside ker q=P are unchanged.
Factor C_(q,0) internally by the signs of psi. Its negative factor can
be combined with C_(q,-), and its positive factor with C_(q,+). Sign
closure shows that these products remain in the required negative and
positive subgroups. Uniqueness of (1) then identifies the perturbed
zero factor with the zero factor of C_(q,0) alone.

Thus all outer factors are fixed during the local analysis, and the
problem is exactly the rank-two group on P. No interaction with an
unlisted higher-dimensional joint remains.

### 4.3 Why the positive word gives multiplication, not division

Set H=C_(q,0)^(-1). Use the order alpha before beta when K(alpha,beta)>0.
For a ray rho, the covector eta(rho,-) has positive sign on the rays
before rho and negative sign on the rays after rho. Therefore the
incoming angular factorization of H has, on ray rho, exactly

    T_rho(A_rho),

where A_rho is the ray packet at q+delta eta(rho,-). The opposite angular
factorization similarly has the packet B_rho at
q-delta eta(rho,-). These facts follow directly from (1), taking its
inverse, and the angular ordering of the positive cone.

Apply the deterministic adjacent positive-word identities to H. All
original factors survive; only new factors are inserted. Uniqueness of
ordered factorization now gives

    B_rho=A_rho R_rho,                                  (4)

where R_rho is precisely the product of born packets retained by the
grammar. Parallel originals and births have the same primitive normal,
so (4) is an equality of packet functions as well as automorphisms.

For an elementary coordinate check, if K(e1,e2)=m>0, the incoming rays
are eta(e1,-)=(0,-m) and eta(e2,-)=(m,0). The incoming path transport is
T_beta^(-1)T_alpha^(-1)=(T_alpha T_beta)^(-1); the outgoing transport is
(T_beta product(T_gamma) T_alpha)^(-1). Their equality is exactly the
positive word identity. Thus the normal-action sign is consistent.

The target path crosses q from q+delta eta(S,-) to
q-delta eta(S,-). Equation (4) therefore multiplies its ray packet by
R_(P,S); it never calls for R_(P,S)^(-1).

### 4.4 Induction and the omitted top input coefficient

Every coefficient supplied to a born packet is of strictly smaller
positive charge than the output it helps form: each local birth uses
both nonparallel parents with positive multiplicities. To compute a
born contribution at charge S, only proper incoming coefficients T<S
are needed. The omitted degree-S coefficient is necessarily on the
target ray and is central modulo the box: multiplying it with any
nonzero other charge leaves the box. It cannot alter R_(P,S).

Height induction identifies all incoming packets used by the grammar
with the true A_rho to the needed order. Equation (4), multiplied along
the finite event list, gives

    F_S(Theta)=I_(rho(S)) product_(P in E(S,Theta)) R_(P,S).

Here is a purely algebraic verification of the starting value. Put
psi=eta(S,-). Inside the coarse zero Lie algebra g_(psi,0), the S-ray
subalgebra is a central direct summand. Its complement, the sum of the
root spaces not parallel to S, is a Lie ideal: if alpha+beta=lambda S
and psi(alpha)=psi(beta)=0, then

    K(alpha,beta)=lambda K(alpha,S)=0.                  (6)

Thus a bracket of two complementary roots cannot create an S-ray term.
The projection onto the S-ray is a group homomorphism on the coarse
zero group. Refining psi by any generic tie covector with kernel Q S
leaves this projected central factor unchanged.

For t sufficiently large, theta(t) has the sign of psi wherever psi is
nonzero, and uses Theta only on ker psi. Its S-ray factor therefore is
exactly this central projection. The sign sigma_S in the incoming-prefix
theorem is another such refinement, with the SAME first functional psi.
Its prescribed zero factor is T_rho(I_rho)^(-1), or the identity for a
nonaxis ray. Apply that theorem to each retained multiple of rho to fix
the whole packet through the cutoff. Tie independence follows from
(6), rather than any geometric assumption about wall support. Therefore
the starting packet is I_rho, or 1 on a nonaxis ray. Extracting charge S
is exactly the claimed recursive formula.

If eta(S,-)=0, the packet has no events and the same central-summand
argument applies to the whole Lie algebra. A nonaxis radical charge
cannot arise from a nonzero final commutator. The prescribed incoming
packet is therefore the whole packet. Initial radical axes are retained in the faithful
ambient action; they are not accidentally erased.

## 5. The one-frame extraction is exact

Let

    Bhat=[[0,-g^T D],[g,B]],       Dhat=diag(1,D),
    S=(1,p),
    Theta(e_i)=mu_i>0,
    Theta(e_0)=-sum_i p_i mu_i,

where the mu_i=1+epsilon_i are rationally independent formal positive
lexicographic quantities. Then ker_Q Theta=Q S. Inside the box [0,S],
every nonzero unframed charge has positive Theta, every proper framed
charge has negative Theta, and S is the sole zero charge.

In C=C_- C_0 C_+, C_+ acts trivially on x^(-e0), because all its normal
vectors have zero framing coordinate. Since w(S)=1, the inverse
positive-normal action of C_0 on x^(-e0) has exponent 1:

    C_0(x^(-e0))=x^(-e0)(1+f_S z^S) modulo the box.

Every nontrivial charge in C_- is proper framed. It cannot add to the
z^S term without producing framing degree at least two. Acting on the
original term, it can produce only its own proper framed charge, never
S; products of two such increments again leave the box. Consequently

    [z^S] C(x^(-e0))/x^(-e0)=f_S.                       (5)

The previously proved one-framing Schur identity identifies the left
side with a_g^B(p), and its theta identification is the established
incoming/last-exponent bridge. Thus

    a_g^B(p)=cardinality of F((1,p),Theta).

Equation (5) is the needed distinction between total transport and one
ray coefficient. They are not generally equal without this framing
and sign pattern.

## 6. Purity of the object definition and claims it supports

The event planes, formal covectors, allowable charges, deterministic
word exchanges, and allowed births are all defined from B,D,g,p before
coefficient nonvanishing is known. Keep empty identity packets in this
structural definition. Numerical pruning may remove them later without
changing any count, but pruning must not define the mathematical set.

At the leaves the ordinary classical packet has a singleton degree-one
set and empty higher-degree sets. Every later object is formed by
disjoint union, Cartesian product, positive ordered tuples, and an
explicit tight Dyck grading decorated by earlier objects. All choices
are bounded integers or finite charge allocations. Neither a wall list,
a coefficient oracle, a moduli-space root count, nor a set of prescribed
cardinality is part of the definition.

This is therefore a genuine finite combinatorial coefficient rule,
although the equality proof rightly uses known algebraic identities.
The construction supplies a positive theta-coefficient model and hence
the proposed theta-based extension of the greedy combinatorial goal.
It does not by itself prove a new intrinsic high-rank greedy minimality
axiom, a canonical bijection with rank-two compatible pairs, or finite
support for all labels. Those stronger statements must remain separate.

## 7. Sources actually checked for this review

1. A. Burcroff, K. Lee, L. Mou, *Positivity of generalized cluster
   scattering diagrams*, arXiv:2503.03719v1, Theorem 1.2,
   Definitions 3.14, 3.17, 5.1, 5.3, 5.4. Primary HTML inspected:
   https://arxiv.org/html/2503.03719v1 . The definition uses either
   shadow inclusion and the determinant condition with either sign;
   the present choice of determinant +1 is permitted. The paper also
   already proves higher-rank wall positivity; positivity itself must
   not be described as new here.
2. M. Gross, P. Hacking, S. Keel, M. Kontsevich, *Canonical bases for
   cluster algebras*, arXiv:1411.1394v2, incoming-factor framework in
   Proposition 1.20 and Theorem 1.21. Primary PDF inspected:
   https://arxiv.org/pdf/1411.1394v2 , printed pages 27--29, including
   the proof comparing the coarse zero-group projection with generic
   three-factor refinements. This agrees with the algebraic starting-
   value argument in Section 4.4. No 2026 result is used as a substitute
   for Section 4 above.

The finite-group argument of Section 4, including the central-projection
starting value and the distinction between C and H=C_(q,0)^(-1), has
also been integrated into Section 6 of `agents/valued_global_assembly.md`
at the parent agent's request. No other section was modified by this
reviewer.

Reviewed project files: `agents/valued_global_assembly.md`,
`proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md`,
`agents/valued_charge_word_grammar.md`,
`agents/ONE_FRAMING_COEFFICIENT_THEOREM.md`,
`agents/INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`, and the current
`computations/valued_event_flag_grammar.py`. The implementation follows
the same dependencies and uses the signed recursion only as a test
oracle. The local path implementation's independent audit and existing
test batches were not rerun in this review.
