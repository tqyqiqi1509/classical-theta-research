# Independent replication audit and a cycle-character strengthening

Branch: `/root/replication_independent_proof`.
Date: 2026-11-13. All cluster algebras in the conclusions are classical.

## 0. Outcome and scope

The replication formula in `polyhedral_parameter_formula.md` is correct. The Lie normalization and the restricted matrix-inverse argument survive an independent verification, including nonscalar symmetrizers, a degenerate zero matrix, and radical cyclic directions. A few details needed expansion rather than a change in the theorem.

There is a stronger general consequence. Every coefficient can be reduced, by an explicit cycle-index sum, to **square-free coefficients of weighted replication matrices**. The cycle values form an actual character of a product of symmetric groups. More precisely this is a nonnegative sum of Young permutation characters, using Burcroff--Lee--Mou's positivity in independent initial polynomial coefficients. The original theta coefficient is its sign multiplicity. This gives a representation-theoretic refinement of the replication polynomial and a nonnegative Schur--Weyl dimension formula.

The representation is determined up to isomorphism by explicit classical square-free coefficient values. We do not yet have a natural local configuration space with this group action. Constructing a vector space by taking the required number of copies of a Young module is not asserted to settle the user's pure combinatorial problem.

## 1. Independent check of the Lie action

Put `omega(alpha,beta)=alpha^T D B beta` and let

\[
 E_\alpha(x^m z^q)=\alpha^TD(m+Bq)x^m z^{q+\alpha}.
\]

Writing `A=alpha^T D(m+Bq)`, `C=beta^T D(m+Bq)`, and `s=omega(alpha,beta)`, the two compositions have coefficients `C(A+s)` and `A(C-s)`. Their difference is `s(A+C)`. Therefore

\[
[E_\alpha,E_\beta]=\omega(\alpha,\beta)E_{\alpha+\beta}.
\]

There is no missing minus sign. For the negative-to-positive convention,

\[
L_i=\sum_{k\ge1}\frac{(-1)^k}{D_i k^2}E_{ke_i}
\]

acts on a monomial with constant exponent `m_i` along the i-axis by multiplication with

\[
\exp\left(m_i\sum_{k\ge1}\frac{(-1)^k z_i^k}{k}\right)
=(1+z_i)^{-m_i}.
\]

The symmetrizer cancels exactly once. Multiplying every `D_i` by one positive constant scales the generators and inversely scales their logarithm coefficients, leaving the actual transport unchanged.

## 2. What is and is not supplied directly by Zhou

Zhou, *Cluster Structures and Subfans in Scattering Diagrams*, SIGMA 16 (2020), 013, was read at §3.1, Remark 3.1, condition (3.1), and the complete proof of Theorem 3.2.

The printed setup assumes the original seed has all lattice multipliers equal to one. Thus the general symmetrizable assertion is not literally the theorem's stated input. Its proof extends because it uses two algebraic facts, both checked here:

1. The skew form descends under the root projection, so the map on homogeneous Lie generators is a filtered Lie homomorphism.
2. Every incoming direction is the pullback of the incoming direction of the projected root. Therefore an outgoing wall cannot become an extra incoming wall under restriction to that subspace. Positive multiples of a normal define the same incoming direction ray.

The initial logarithms may have rational scalar coefficients constant on each copy block. Zhou's incoming-wall argument does not require those scalars to equal one. In our case their sum is exactly `r_i/D_i=1/(D_i/r_i)`. This proves the extension with `D_r=D R^{-1}`; if desired clear denominators by a common positive scalar.

More explicitly, for the copy-sum map `pi`,

\[
\widetilde\omega(\alpha,\beta)
=\omega(\pi\alpha,\pi\beta),
\qquad \widetilde\xi_\alpha=\pi^*\xi_{\pi\alpha}.
\]

If a restricted wall of normal `pi alpha` contains its incoming direction, its lifted support contains `pi^*xi_(pi alpha)=xi_alpha`; the lifted wall was already incoming. Initial walls in a block commute, and their logarithms add. This is the essential stronger hypothesis; arbitrary automorphism folding does not suffice.

For a radical image normal, no new nonaxis central logarithm is generated: if `beta+gamma` is radical then `omega(beta,gamma)=omega(beta,beta+gamma)=0`. This also handles the apparently degenerate incoming direction without interpreting zero as a generic point.

## 3. The finite-matrix inverse issue, written without hidden closure assumptions

Let `J=[0,p]`, `Jtilde={u>=0:pi u<=p}`, and let `Phi` sum coefficients over fibers. The transport projection is

\[
\Phi\widetilde C=C_r\Phi.
\]

Indeed for a fixed source `v`, the sum over targets `u` with `pi u=s` is a sum over nonnegative increments `u-v`, whose projected increment is `s-pi v`. The shifted mutable input is block-constant and depends only on `pi v`. Thus every column has exactly the required folded sum, including columns with different distributions inside one fiber.

Fix the folded endpoint `p` and select

\[
I=\{p\}\cup\{q\le p:(g+Bp)^TD(p-q)<0\},
\qquad \widetilde I=\pi^{-1}(I)\cap\widetilde J.
\]

The selection is a union of full fibers. Projection onto these coordinates commutes with `Phi`, hence

\[
\Phi_I\widetilde C_{\widetilde I}=C_{r,I}\Phi_I,
\qquad
\Phi_I\widetilde C_{\widetilde I}^{-1}
=C_{r,I}^{-1}\Phi_I.
\]

The only remaining concern is that the original extraction row for a single lifted top `u` uses `[0,u]`, whereas `Itilde` can include indices not below `u`. This causes no change. Every nonzero entry of a triangular transport, or of the inverse of any principal submatrix, is supported on comparable pairs. A chain ending at `u` has all its intermediate indices below `u`. Extra indices not below `u` never occur in its row. Distinct points in the top fiber are incomparable because their nonnegative block sums agree. Thus adding the whole top fiber and the extra lower fibers does not change any of the original last-row equations.

Summing those equations over the top fiber and inducting on `|p|` proves the theta replication formula, including strict-zero endpoint cases. No assertion that the selected halfspace is an order ideal is needed.

## 4. A weighted square-free reduction

Write `lambda=(lambda_1,...,lambda_n)` for a tuple of partitions with `lambda_i` a partition of `p_i`. A part of size `k` in `lambda_i` becomes a vertex `a=(i,k)`, with repeated parts kept as separate labelled vertices. For `a=(i,k)` and `b=(j,l)`, set

\[
B^\lambda_{ab}=lB_{ij},\qquad
D^\lambda_a=kD_i,\qquad
g^\lambda_a=g_i.
\tag{4.1}
\]

Then `D^lambda B^lambda` is skew-symmetric. Empty blocks are deleted. Define

\[
\chi_{B,g,p}(\lambda)
:=a^{B^\lambda}_{g^\lambda,\mathbf1}.
\tag{4.2}
\]

For a partition `lambda_i=(1^{m_i1}2^{m_i2}...)`, put

\[
z_{\lambda_i}=\prod_{k\ge1}k^{m_{ik}}m_{ik}!,
\quad z_\lambda=\prod_i z_{\lambda_i},
\quad \epsilon_\lambda=(-1)^{|p|-\sum_i\ell(\lambda_i)}.
\]

**Theorem 4.1 (cycle-index identity).** For every classical skew-symmetrizable `B`, every integral `g`, and every `p>=0`,

\[
\boxed{
a^B_{g,p}
=\sum_{\lambda_i\vdash p_i}
\frac{\epsilon_\lambda}{z_\lambda}
\chi_{B,g,p}(\lambda).
}
\tag{4.3}
\]

Equivalently, for `G_p=product_i S_(p_i)`,

\[
\left(\prod_i p_i!\right)a^B_{g,p}
=\sum_{\sigma\in G_p}\operatorname{sgn}(\sigma)
\chi_{B,g,p}(\operatorname{cyc}\sigma).
\tag{4.4}
\]

The identity is finite and coefficientwise; no Laurent-finiteness hypothesis is imposed. It reduces every root multiplicity to square-free roots, at the cost of larger rank and a signed cycle-index sum.

### Proof by incoming-log polarization

Replace the i-th incoming logarithm by the independent formal expression

\[
L_i(\mathbf u)=\sum_{k\ge1}u_{ik}E_{ke_i}.
\]

At root degree `p`, transport and endpoint extraction are finite polynomials in the `u_ik`. Every monomial has weighted multidegree `p`, assigning weight `ke_i` to `u_ik`; this follows from root-charge conservation in every product, inverse, and exponential. Consequently

\[
\mathcal A_{g,p}(\mathbf u)
=\sum_{\sum_k km_{ik}=p_i}q_{\mathbf m}\prod_{i,k}u_{ik}^{m_{ik}}.
\tag{4.5}
\]

Polarize each occurrence into a separate nilpotent variable `t_a`, with `t_a^2=0`, and use a lifted root projection

\[
\pi(e_a)=k_a e_{i_a}.
\]

First use the skew-preserving weighted matrix

\[
\widehat B_{ab}=k_a k_b B_{i_a i_b},
\quad\widehat D_a=D_{i_a},
\quad\widehat g_a=k_a g_{i_a}.
\]

Its skew pairing is the pullback of `DB`, and its module action projects to the original action because

\[
\sum_a \alpha_aD_{i_a}k_a
\left(g_{i_a}+(B\pi q)_{i_a}\right)
=(\pi\alpha)^TD(g+B\pi q).
\]

The incoming-direction argument of §2 works for this positive weighted projection as well: normals may map to positive multiples of an axis, but no outgoing wall becomes incoming. Modulo `t_a^2`, the lifted cluster incoming logarithm is precisely `-t_a E_(e_a)/D_(i_a)`; its higher multiples vanish. The coefficient of `product_a t_a` therefore gives

\[
q_{\mathbf m}
=\frac{a^{\widehat B}_{\widehat g,\mathbf1}
\prod_a(-D_{i_a})}{\prod_{i,k}m_{ik}!}.
\tag{4.6}
\]

This is ordinary polarization: expanding `u_ik=sum_a s_a` supplies the factor `m_ik!`. Endpoint extraction commutes with the projection by the argument of §3. In the Boolean nilpotent truncation, the top projected charge is attained only by selecting all atoms.

Now specialize the original incoming logarithms to `u_ik=(-1)^k/(D_i k^2)`. The contribution of (4.6) is

\[
\frac{a^{\widehat B}_{\widehat g,\mathbf1}}
{\prod_{i,k}m_{ik}!}
\prod_{i,k}\left(\frac{(-1)^{k-1}}{k^2}\right)^{m_{ik}}.
\tag{4.7}
\]

Finally `Bhat=K B^lambda`, `ghat=K g^lambda`, and `Dhat=D^lambda K^{-1}`, for `K=diag(k_a)`. At a square-free root, row dilation has the exact homogeneity

\[
a^{KC}_{Kh,\mathbf1}=\left(\prod_a k_a\right)a^C_{h,\mathbf1}.
\tag{4.8}
\]

To see this without any positivity input, expand the finite integer formula to its axis leaves. Every used vertex occurs exactly once, with a degree-one binomial `-m_a`. All sign tests remain unchanged under row dilation, and each summand acquires exactly one factor `k_a` per vertex. Substituting (4.8) in (4.7) cancels one power of each `k_a`, yielding (4.3).

This proof is the incoming-log version of the familiar multicover/abelianization mechanism. Its mathematical ingredients are not being claimed new; the arbitrary-label theta and symmetric-character formulation is the interface developed here.

## 5. Symmetric alphabets and an actual symmetric-group character

For each original vertex use an alphabet `X_i`. Replace the elementary incoming function `1+t` by

\[
P_i(t)=\prod_{x\in X_i}(1+xt)=\sum_{k\ge0}e_k(X_i)t^k.
\]

Let `T_(B,g,p)(X)` be the corresponding formal coefficient at root `p`. For a fixed `p`, only `e_k` with `k<=p_i` matter. Its incoming logarithm is

\[
L_i(X_i)=\sum_{k\ge1}\frac{(-1)^k p_k(X_i)}{D_i k^2}E_{ke_i}.
\]

Repeating (4.5)--(4.7), now retaining the power sums, proves

\[
\boxed{
T_{B,g,p}(X)
=\sum_{\lambda_i\vdash p_i}
\frac{\epsilon_\lambda\chi_{B,g,p}(\lambda)}{z_\lambda}
\prod_i p_{\lambda_i}(X_i).
}
\tag{5.1}
\]

This identity itself does not assume positivity.

### The exact external positivity interface

Burcroff--Lee--Mou, arXiv:2503.03719v1, Theorem 1.7(2), Theorem 8.11, and the theta definition in §8 give positivity over the ring of independent initial exchange coefficients. The companion branch `canonical_representation_bridge` completed its inspection of this input, including §9.3 through Lemma 9.16 and the limiting step. To place the present coefficient into their degree convention, choose one positive integer `L>=max_i p_i`, use the generalized extended exchange matrix `L[B;I]` (including the scaled frozen rows), and take every exchange degree equal to `L`. The divided exponent vectors are then the original principal vectors `(Be_i,e_i)`. Normal vectors and the elementary action exponent remain the same. Higher coefficient variables can be specialized to zero inside the positive polynomial coefficient ring. This is an application of the inspected 2025 theorem, not a claim to reprove its complete tight-grading positivity argument.

Therefore

\[
T_{B,g,p}(X)=\sum_{\nu_i\vdash p_i}
b_\nu\prod_i e_{\nu_i}(X_i),
\qquad b_\nu\in\mathbb Z_{\ge0}.
\tag{5.2}
\]

Only this finite formal auxiliary construction uses generalized initial polynomials. The coefficients `chi(lambda)` and the original `a` in the conclusions are ordinary classical theta coefficients. The choice of `L` does not affect degrees at most `p`.

Let `omega` be the symmetric-function involution in every alphabet, with `omega(e_k)=h_k` and `omega(p_k)=(-1)^(k-1)p_k`. Applying it to (5.1) gives

\[
\omega T_{B,g,p}
=\sum_\lambda\frac{\chi_{B,g,p}(\lambda)}{z_\lambda}
\prod_i p_{\lambda_i}
=\sum_\nu b_\nu\prod_i h_{\nu_i}.
\tag{5.3}
\]

Since `h_nu` is the Frobenius characteristic of the Young permutation module `Ind_(S_nu)^(S_p) 1`, equation (5.3) proves:

**Theorem 5.1.** The class function (4.2) is a genuine character of `G_p`, and indeed a nonnegative integral sum of Young permutation characters. Let `V_(B,g,p)` denote the uniquely determined isomorphism class of representations with this character. Then

\[
\boxed{
a^B_{g,p}=\dim\operatorname{Hom}_{G_p}
(\operatorname{sgn},V_{B,g,p}).
}
\tag{5.4}
\]

Its dimension is the completely replicated square-free coefficient

\[
\dim V_{B,g,p}=a^{B^{[p]}}_{g^{[p]},\mathbf1}.
\]

This is stronger than separately knowing that all class values are nonnegative. In particular all irreducible-character inner products are nonnegative integers, furnishing numerous exact congruences and inequalities among classical square-free coefficients of the weighted matrices (4.1).

## 6. A Schur--Weyl refinement of the replication polynomial

The replication polynomial of the previous branch is

\[
F_{B,g,p}(r)=a^{RB}_{Rg,p}=T_{B,g,p}(1^{r_1},...,1^{r_n}).
\]

For `W_i=Q^(r_i)`, the permutation action on `W_i^(tensor p_i)` has cycle character `r_i^(ell(lambda_i))`. Equations (5.1) and (5.4) give

\[
\boxed{
F_{B,g,p}(r)
=\dim\operatorname{Hom}_{G_p}\left(
\operatorname{sgn},
V_{B,g,p}\otimes\bigotimes_i W_i^{\otimes p_i}
\right).
}
\tag{6.1}
\]

If `m_mu` is the multiplicity of the product of Specht modules of shapes `mu_i` in `V`, Schur--Weyl duality yields the nonnegative expansion

\[
\boxed{
F_{B,g,p}(r)=\sum_{\mu_i\vdash p_i}m_\mu
\prod_i s_{\mu_i'}(1^{r_i}),\qquad m_\mu\ge0.
}
\tag{6.2}
\]

Each `s_(mu_i')(1^(r_i))` counts semistandard tableaux of the indicated shape with entries at most `r_i`, equivalently integer points in the corresponding Gelfand--Tsetlin polytope. Thus the previously proved nonnegative binomial expansion has an additional representation-theoretic refinement. The multiplicities are computed by finite character-table inner products from square-free coefficients.

The identity at `r_i=0` is polynomial evaluation; it does not create a cluster matrix with a zero symmetrizer entry. Formula (6.1) interprets this boundary using zero-dimensional vector spaces instead.

There is also an explicit relation between the elementary coefficients in (5.2) and the previously obtained binomial-basis coefficients. For a partition `nu`, let `N(nu,k)` count families of subsets `(A_1,...,A_ell)` of `[k]`, indexed by the displayed parts of `nu`, with `|A_j|=nu_j` and union `[k]`. Then

\[
\prod_j\binom r{\nu_j}=\sum_{k\ge0}N(\nu,k)\binom rk,
\qquad
A_{p,k}=\sum_\nu b_\nu\prod_iN(\nu_i,k_i).
\tag{6.3}
\]

This follows by first selecting the union of the subsets. Repeated parts still index separate factors, so no factorial is missing. It gives a concrete colored-cover interpretation of the change of basis; the still unknown local objects are the multiplicities `b_nu`, not the finite cover families. Thus (6.3) is a refinement and a target for a construction, not a substitution of an unknown theta number for the sought greedy objects.

## 7. An exact diagnostic example

For the cyclic matrix with all three weights 2, `g=(-1,-1,-1)` and `p=(2,2,1)`, the character on `S_2 x S_2` has values

| Cycle types at the first two vertices | Character value |
| --- | ---: |
| `(1,1),(1,1)` | 133 |
| `(2),(1,1)` | 79 |
| `(1,1),(2)` | 41 |
| `(2),(2)` | 23 |

The irreducible multiplicities, in the order trivial/trivial, trivial/sign, sign/trivial, sign/sign, are `69,37,18,9`. Thus the original coefficient equals

\[
(133-79-41+23)/4=9.
\]

Its elementary expansion is

\[
9e_1(X_1)^2e_1(X_2)^2e_1(X_3)
+9e_1(X_1)^2e_2(X_2)e_1(X_3)
+28e_2(X_1)e_1(X_2)^2e_1(X_3)
+23e_2(X_1)e_2(X_2)e_1(X_3).
\]

The example illustrates the general formulas and independently checks the factors `k`, `k^2`, factorials, and sign twist. It is not their proof.

## 8. Computation and audit records

`replication_independent_compute.py` performs two structurally different comparisons:

1. It uses the rational Lie-log reconstruction and matrix exponential implementation, not the scalar Schur coefficient code, to build complete folded/lifted matrices. It checked 846 full matrix intertwining entries, 863 restricted inverse intertwining entries, and all theta-fiber equations in four cases (including valued and radical data).
2. It implements a sparse polynomial recursion in independent elementary coefficients, and compares its power-sum expansion with independently computed classical square-free coefficients in (4.1). The first run verified 42 full cycle types across eight inputs, with all elementary coefficients and all irreducible multiplicities nonnegative integers. Character values are computed with an explicit Murnaghan--Nakayama implementation.
3. The systematic follow-up `replication_character_stress.py` completed 880 inputs in ranks 3--5 in 31.55 seconds. It checked 4,491 full cycle-type identities and 4,491 irreducible multiplicities, all nonnegative integers; 594 inputs had nonzero elementary expansions, totalling 2,695 nonzero elementary monomials, all positive. Inputs include nonscalar symmetrizers, arbitrary orientations, mixed-sign labels, and charges with zero coordinates. Its results are in `replication_character_stress.json`. Before applying the character code it independently verifies all character-table inner products and hook dimensions through degree 8 (919 inner-product checks).

The companion flow-tree branch separately reproduced the four diagnostic cycle values using primitive-normalized positive flow trees. Before normalizing, its products of absolute skew pairings were `92,158,82,133`; division by the cycle primitive factors gives `23,79,41,133`. This uses neither the elementary polynomial code nor the square-free integer recursion as the construction of those tree weights.

The Wolfram plugin independently returned zero for the weighted skew-form projection, the folded symmetrizer identity, and the Lie action commutator polynomial. It also reproduced the four multiplicities `9,37,18,69` for the diagnostic character table. Raw output is retained in `replication_independent_wolfram.json`.

## 9. Novelty and the remaining constructive problem

- Zhou's strong quotient mechanism is prior work; its extension to the displayed orbit-constant rational logarithm weights is written out rather than hidden behind an overbroad citation.
- The weights `1/(k^m m!)`, square-free expansion, and sign are the familiar cycle-index/abelianization pattern. Reineke--Stoppa--Weist's primary text was read at §§3.1--3.3: Theorem 3.5 gives a motivic formula for arbitrary quivers, dimensions and stabilities; Corollary 3.7 specializes to a thin-dimension Euler-characteristic expansion with weights `(-1)^(k-1)/k^2` for coprime dimension vectors. Proposition 3.8 explicitly maps elementary and power-sum symmetric functions to quiver motives, and the following paragraph asks about complete and Schur functions. Thus neither abelianization nor the symmetric-function language should be claimed new. What requires independent identification is the present arbitrary-label classical theta character and its integral `h`-positive structure.
- Gräfnitz--Luo already use color-support grouping for rank-two scattering polynomiality. The arbitrary-rank classical theta character with values (4.2), and its exact relation to the integer recursion, are the present formulation; absence of an identical source in the targeted searches is not proof of priority.
- The final hard step has become concrete: construct `V_(B,g,p)` from local colored configurations with character (4.2), or construct its sign multiplicity by a local cancellation/quotient without using the resulting multiplicities as input. The theorem proves that such a representation type exists; it does not yet supply the sought intrinsic action.
- The most useful next bridge is the companion branch's one-framing/primitive Lie interpretation. It may turn the abstract character into an action on explicit stable tree or shuffle spaces. This has not been assumed in any proof above.

### A concrete positive-model interface from the second literature pass

Reineke--Rhoades--Tewari, arXiv:2207.11861 / IMRN 2023, prove an equivariant chain connecting the permutation module on graph break divisors, the central zonotopal algebra, and the slim-subgraph space. Break divisors are lattice points in a trimmed graphical zonotope, whereas spanning trees count the dimension without transparently displaying the group action. In their application a product of symmetric groups acts, and symmetric-quiver DT invariants become orbit counts. This is a precise existing mechanism for passing from positive tree counts to a natural action with nontrivial stabilizers and a polytope model.

Its scope matters: the stated DT application assumes a **symmetric quiver with enough loops**. It does not identify our skew-form theta character with any of those modules. A viable new construction would have to replace the ordinary graphical cut/power-ideal constraints by the incoming/stability constraints while preserving the cycle traces (4.2). This is a research route, not a theorem imported across incompatible hypotheses.

Directly relabelling nonzero binary flow trees is insufficient: it gives too few stabilizers. Already the zero-matrix input with `g=-2,p=2` has cycle character `(4,2)`, realized by assignments of two labels to two fixed slots; a free action on labelled binary trees would have zero transposition trace. Commuting-twig relations or an orbit-harmonic model can merge such presentations while retaining the needed stabilizers. The companion branch is testing the former; the latter is now an explicit alternative with a literature precedent.

### Search and use record

| Item | Primary text checked | Use in this branch | Status |
|---|---|---|---|
| Zhou 2020, §3.1/Theorem 3.2 | Full folding proof, incoming-vector step | Extends exact Lie projection to rational orbit-constant weights | Useful, scope extension proved here |
| Reineke--Stoppa--Weist 2011/2012, §§3.1--3.3 | Thin quiver construction, Theorem 3.5, Corollary 3.7, Proposition 3.8 | Prior-art boundary and MPS interpretation | Useful, no arbitrary-theta identification assumed |
| Reineke--Rhoades--Tewari 2022/2023 | Primary PDF introduction/Theorems 1.1--1.2 | Orbit harmonics and trimmed-zonotope constructive route | Useful route; hypotheses do not directly apply |
| Burcroff--Lee--Mou 2025 | Definitions 8.1--8.2, Theorems 1.7/8.11, §9.3; companion audit covers remaining details | `e`-positivity and hence actual `h`-positive character | Used with explicit degree normalization |
| 2026 quiver-code / Young-module search hit, arXiv:2611.05526 | Search metadata only, not mathematical text | None: topic is quantum error correction, not this interface | Not relied on; not correctness-certified |

The generated HTML of arXiv:1110.4847v1 displays an incidental 2026 date in its body, but the primary abstract/version record is the 2011 submission and the publication is 2012. It is not treated as a new 2026 theorem. No new 2026 mathematical claim is used in this branch.

## Sources consulted

1. Yan Zhou, SIGMA 16 (2020), 013, §3.1 and Theorem 3.2. Primary PDF: https://www.emis.de/journals/SIGMA/2020/013/sigma20-013.pdf .
2. Burcroff--Lee--Mou, arXiv:2503.03719v1, Theorems 1.7 and 8.11, Definition 8.23, Proposition 8.25 and §9.3. The completed independent interface audit is in `canonical_representation_bridge.md`. Primary text: https://arxiv.org/html/2503.03719v1 .
3. Reineke--Stoppa--Weist, *MPS degeneration formula for quiver moduli and refined GW/Kronecker correspondence*, Geometry & Topology 16 (2012), 2097--2134. Primary full text: https://arxiv.org/html/1110.4847v1 .
4. Reineke--Rhoades--Tewari, *Zonotopal algebras, orbit harmonics, and Donaldson--Thomas invariants of symmetric quivers*, IMRN 2023, 20169--20210. Primary PDF: https://www.math.toronto.edu/vvtewari/draft_dt.pdf ; version record: https://arxiv.org/abs/2207.11861 .
5. The original incoming-prefix theorem and prior parameter formula in this research directory supply the finite coefficient recursion and root-charge conservation; their external existence/identification input remains GHKK.
