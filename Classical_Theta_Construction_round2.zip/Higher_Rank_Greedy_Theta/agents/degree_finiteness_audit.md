# Positive degree carriers and finite binomial moment equations

Independent audit and constructive extension, 2026-11-13 10:41 UTC.
Scope: classical cluster algebras, first skew-symmetric and then
skew-symmetrizable; principal coefficients are retained throughout the theta
statements. No Li–Pan polytope-basis conclusion is used.

## 1. Verdict and provenance

**PASS:** the proposition in `proofs/weighted_degree_obstruction.md` is
correct. Its proof needs coprimality of each exchange polynomial with the
mutable variables that are inverted, but neither positivity of the element
being tested nor pairwise coprimality of distinct exchange polynomials.

**Constructive extension proved here:** when the strict inequality
`kappa < 1` holds, every homogeneous degree piece has a finite lattice-point
carrier. On that carrier, initial-plus-neighbor Laurentness is exactly the
kernel of an explicit matrix of binomial coefficients and coefficient
monomials. With principal coefficients, BFZ Corollary 1.9 identifies this
kernel with the full upper cluster algebra's homogeneous piece. The matrix
works over the integral Laurent coefficient ring, as well as its fraction
field.

**Provenance must remain explicit.** Speyer's 2013 paper already contains the
negative-row divisibility criterion and a degree argument for the cyclic
`3,3,3` example. That example, non-finite-generation phenomena, and failures
of naive full Fock–Goncharov expectations are not new. The general `kappa`
estimate, its explicit finite carrier, and the fiberwise binomial matrix are
derivations of this research round. The searches below did not locate these
exact formulations; this is not a priority claim.

## 2. Weighted-degree theorem: full independent proof

Let `K` be a field, let `x_1,...,x_n` be algebraically independent, and let

\[
P_i\in K[x_j:j\ne i],\qquad x_i'=P_i/x_i.
\]

Assume the two monomials of each `P_i` have disjoint mutable support and
nonzero coefficients. Let `w_i>0` be integral weights for which `P_i` is
homogeneous of positive weighted degree `delta_i`. Define

\[
U_0=K[x_1^{\pm1},\ldots,x_n^{\pm1}]
\cap\bigcap_iK[x_1^{\pm1},\ldots,(x_i')^{\pm1},\ldots,x_n^{\pm1}],
\qquad \kappa=\sum_i\frac{w_i}{\delta_i}.
\]

For a nonzero homogeneous `f` of degree `d`, set

\[
h_i=\max(0,-\min\{u_i:[x^u]f\ne0\}),\qquad F=x^hf,
\qquad L=d+w\cdot h.
\]

Then `F` is an ordinary nonzero homogeneous polynomial of degree `L>=0`.
For each `i` with `h_i>0`, write `Q_i` for the nonzero coefficient of
`x_i^{-h_i}` in `f`. Substituting `x_i=P_i/x_i'` sends distinct powers of
`x_i` to distinct powers of `x_i'`. Thus adjacent Laurentness forces

\[
P_i^{h_i}\mid Q_i
\quad\text{in }K[x_j^{\pm1}:j\ne i].
\]

The polynomial

\[
F_i=[x_i^0]F=\Bigl(\prod_{j\ne i}x_j^{h_j}\Bigr)Q_i
\]

is nonzero, ordinary, and homogeneous of degree `L`. Because `P_i` is
coprime to every mutable variable, divisibility in the Laurent localization
implies divisibility in the polynomial ring. Hence

\[
\delta_i h_i\le L. \tag{2.1}
\]

For `h_i=0` this inequality also holds. Multiplying (2.1) by
`w_i/delta_i` and summing gives

\[
w\cdot h\le\kappa L,
\qquad d=L-w\cdot h\ge(1-\kappa)L. \tag{2.2}
\]

Consequently:

1. If `kappa<=1`, then `d>=0`.
2. If `kappa<1`, then
   \[
   L\le\frac{d}{1-\kappa},\qquad
   h_i\le\frac{d}{(1-\kappa)\delta_i}. \tag{2.3}
   \]

This argument only uses the initial star of seeds. It does not assume that
`U_0` is mutation invariant. For coefficients in an integral domain, the
same degree bounds follow by passing to its fraction field. They therefore
apply to the integral principal coefficient ring used below.

### Rank-three specialization

For

\[
B=\begin{pmatrix}0&a&-c\\-a&0&b\\c&-b&0\end{pmatrix},
\quad w=(b,c,a),
\]

one has `B^T w=0`,

\[
\delta=(ac,ab,bc),\qquad
\kappa=\frac{a^2+b^2+c^2}{abc}.
\]

Thus `a^2+b^2+c^2<=abc` rules out every negative-degree homogeneous
upper element. This numerical condition is stronger than the usual
mutation-cyclic condition with the additional `+4`; these conditions must
not be identified. The grading itself is already used in Lee–Li–Mills,
Section 4.2.

## 3. Theta finiteness: GHKK Proposition 7.1 really supplies the missing step

I independently read the entire proof of GHKK,
*Canonical bases for cluster algebras*, arXiv:1411.1394v2,
Proposition 7.1, printed pages 66–67:
https://arxiv.org/pdf/1411.1394v2

For the principal cluster variety, this proposition says that finiteness of
the theta broken-line sum in one cluster chamber implies finiteness in
every cluster chamber and a universally positive Laurent polynomial. The
proof uses adjacent chambers, separates final monomials by the sign of the
wall-normal pairing, and uses positivity to rule out an infinite collection
on the newly crossed side: their final segments could be extended back to
the original chamber. Thus the assertion is stronger than a mere formal
wall-crossing identity. Its hypotheses hold for actual classical principal
theta functions, not for arbitrary formal series.

For a principal label with mutable component `g`, the initial expansion is

\[
\vartheta_g=x^g\sum_{p\in\mathbb N^n}a_p\,y^p x^{Bp},\qquad a_0=1.
\]

If `B^T w=0`, every term has weighted degree `d=w\cdot g` when frozen
variables have weight zero. If this theta were finite and `d<0`, GHKK 7.1
would put it in the upper algebra, hence in `U_0`, contradicting (2.2).

**Corollary.** Under `kappa<=1`, every principal theta label with
`w\cdot g<0` has infinite full principal Laurent support. In particular,
the cyclic `3,3,3` matrix with weights `(1,1,1)` gives infinite formal theta
series for `g=-e_i`.

This is an actual infinite-support conclusion, not an inability of a
particular coefficient algorithm to terminate. It is also not a new
discovery of the `3,3,3` pathological example; see Section 8.

## 4. Positive result: a finite polytope carrier in every degree

Assume now `kappa<1`, fix an integer degree `d>=0`, and put

\[
H_i(d)=\left\lfloor\frac{d}{(1-\kappa)\delta_i}\right\rfloor,
\qquad
E_d=\{u\in\mathbb Z^n:u_i\ge-H_i(d),\ w\cdot u=d\}. \tag{4.1}
\]

The set `E_d` is finite: after `z=u+H`, it is exactly the set of
nonnegative integral solutions of

\[
w\cdot z=d+w\cdot H.
\]

Equivalently it is the lattice-point set of a translated rational simplex.
Explicit coordinate bounds are

\[
-H_i\le u_i\le
\left\lfloor\frac{d+\sum_{j\ne i}w_jH_j}{w_i}\right\rfloor.
\]

Every degree-`d` element of `U_0` belongs to

\[
V_d=\bigoplus_{u\in E_d}Kx^u. \tag{4.2}
\]

For fixed weights and exchange matrix, this carrier has at most
`O(d^{n-1})` lattice points. Enumerating weighted compositions gives it
without searching a full enclosing box. The carrier bounds whole
homogeneous components, not only cluster variables or a tested list of
examples.

A useful necessary region for regular principal theta labels is

\[
w\cdot g\ge0,\qquad
g_i\ge-H_i(w\cdot g).
\]

The corresponding real polyhedral cone has inequalities

\[
w\cdot g\ge0,\qquad
(1-\kappa)\delta_i g_i+w\cdot g\ge0\quad(1\le i\le n). \tag{4.3}
\]

These conditions are necessary, not sufficient. In the uniform low-degree
region

\[
0\le d<(1-\kappa)\min_i\delta_i,
\]

all `H_i` vanish. Here `U_d=K[x_1,...,x_n]_d`. For theta labels with frozen
component fixed to zero, the finite labels in this degree region are exactly
the nonnegative `g`, whose theta functions are initial cluster monomials.

## 5. Exact binomial moment matrix on the carrier

### 5.1 Fiber decomposition

Use principal coefficients and the convention

\[
P_i=y_i x^{\alpha_i}+x^{\beta_i},
\quad \alpha_i=[B_i]_+,\quad\beta_i=[-B_i]_+,
\quad v_i=\alpha_i-\beta_i=B_i.
\]

Here `B_i` is the `i`th column. For a trial polynomial

\[
f=\sum_{u\in E_d}c_u x^u,
\]

consider a negative row `u_i=-r`, `r>0`. Decompose its exponents into
cosets of `Z v_i` in the remaining exponent lattice. **Use `Z v_i`, not
its saturation:** if the column is nonprimitive, its distinct residue
classes must remain separate.

Within one nonempty fiber choose its minimal integral coordinate, so its
exponents are

\[
u_0+\ell v_i\quad(\ell\in S\subset\mathbb Z_{\ge0}),
\qquad \min S=0.
\]

Write `t=x^{v_i}` and

\[
q(t)=\sum_{\ell\in S}c_{u_0+\ell v_i}t^\ell.
\]

The Laurent ring is the direct sum of these coset modules over
`K[t^{+/-1}]`. Since `P_i` is a Laurent monomial unit times `(1+y_i t)`,
negative-row divisibility is exactly

\[
(1+y_i t)^r\mid q(t)
\quad\text{in }K[t^{\pm1}]. \tag{5.1}
\]

### 5.2 Binomial moments

Put `s=y_i t`. Divisibility (5.1) is equivalent to vanishing of the first
`r` Hasse coefficients at `s=-1`. Explicitly, for `0<=j<r`,

\[
\sum_{\ell\in S}(-1)^\ell
\binom{\ell}{j}y_i^{-\ell}c_{u_0+\ell v_i}=0. \tag{5.2}
\]

The harmless common sign `(-1)^j` has been removed. If `m=max S`, one can
multiply the equation by `y_i^m`, giving polynomial matrix entries

\[
(-1)^\ell\binom{\ell}{j}y_i^{m-\ell}. \tag{5.3}
\]

Equations with `j>m` are identically zero. Collect (5.3) over all mutable
indices, all negative rows, all fibers, and all `j<min(r,m+1)`. Denote the
resulting finite matrix by `M_d`, with columns indexed by `E_d`.

### 5.3 Kernel theorem, including integral coefficients

Let

\[
R=\mathbb Z[y_1^{\pm1},\ldots,y_n^{\pm1}],\qquad K=\mathbb Q(y_1,\ldots,y_n).
\]

Then the coefficient-vector identification gives

\[
U_{0,R,d}=\ker_R M_d,\qquad U_{0,K,d}=\ker_K M_d. \tag{5.4}
\]

**Proof.** The carrier theorem gives the finite ambient module. Membership
in an adjacent Laurent ring is equivalent to exchange-polynomial
divisibility in every negative row; nonnegative rows create no
denominators. The coset decomposition proves (5.1) fiber by fiber.
Taylor expansion about `s=-1`, using integer binomial coefficients, proves
(5.2). This works over `R`, not merely a field: the relevant polynomial is
`(1+s)^r`, which is monic, and `y_i` is a unit. Thus all equivalences hold
integrally. Conversely satisfying all moments gives adjacent Laurentness
for all `i`, proving (5.4).

For principal coefficients, the extended exchange matrix `[B;I]` has full
column rank. BFZ, *Cluster algebras III*, Proposition 1.8 and Corollary 1.9,
printed page 5, therefore imply

\[
U_{R,d}=U_{0,R,d}=\ker_R M_d. \tag{5.5}
\]

The same statement holds after passing to the coefficient field. Primary
source: https://arxiv.org/pdf/math/0305434 . No acyclicity hypothesis is
needed for this equality of the initial upper bound and the upper algebra.

This is a terminating computation of every degree piece. Over `K`, use
finite exact linear algebra; over `R`, use a syzygy-module computation.
Since `R` is Noetherian, each `U_{R,d}` is a finitely generated `R`-module.
The theorem does not assert that these modules are free, that a kernel
basis is positive, that it is a theta basis, or that the whole graded
algebra is finitely generated.

## 6. Rigorous interface with the formal theta coefficient algorithm

### 6.1 What a finite prefix can establish

Given `g`, compute `d=w\cdot g` and the carrier `E_d` when `d>=0`.
For a finite principal theta function, every nonzero coefficient `a_p`
must have

\[
g+Bp\in E_d. \tag{6.1}
\]

Therefore an independently certified formal theta coefficient
`a_p!=0` with `g+Bp` outside `E_d` is a rigorous witness of infinite
theta support. Distinct `p` give distinct frozen monomials, so the offending
term cannot disappear by aggregation of mutable exponents. The special
case `p=0` gives the necessary label cone (4.3).

The kernel construction also gives a finite candidate space in mutable
exponents. If one chooses a finite root set `S`, substitute

\[
c_u=\sum_{\substack{p\in S\\g+Bp=u}}a_p y^p
\]

into `M_dc=0`. Expanding in the independent coefficient monomials gives
finite rational/integer linear constraints on the root coefficients
`a_p`. A proposed finite formula can thus be checked for genuine upper
membership without enumerating mutations, and compared exactly with the
formal theta prefix. This is a constructive candidate-generation and
verification interface.

### 6.2 Why it is not a full theta-finiteness oracle

There is a stronger obstruction to bounding root degree here than an
occasional rank deficiency. It is automatic in the entire weighted setting.
If `D B` is skew-symmetric and `B^T w=0`, then

\[
B^T=-DBD^{-1}
\quad\Longrightarrow\quad B(D^{-1}w)=0.
\]

Since `w>0`, clearing denominators gives a strictly positive integer vector

\[
\rho\in\ker B\cap\mathbb Z_{>0}^n. \tag{6.2}
\]

For every root index `p>=0`, all `p+k rho` have the same mutable exponent
`g+Bp`. Consequently even a single mutable lattice point may support an
arbitrarily long series in the central coefficient monomial `y^rho`.
The finite carrier never bounds full principal root support in this class.

Passing to `K=Q(y)` also hides the distinction between a polynomial in
frozen monomials and the power-series expansion of a rational function.
Retaining the integral module (5.5) avoids discarding the coefficient ring,
but does not select theta functions by itself.

Thus none of the following certifies equality to a theta function:
membership in `ker M_d`, a pointed leading term, positivity in the initial
chart, or agreement with a finite prefix. Such a certificate needs an
additional bound on root support or a complete independent characterization
of theta. The matrix is not advertised as such a characterization.

## 7. Implementation and exact verification

Implementation:
`computations/weighted_degree_moment_kernel.py`.

Exact output:
`computations/weighted_degree_moment_kernel_results.json`.

The implementation accepts any integral `B`, positive integral `w` with
`B^T w=0`, and degree `d` for which `kappa<1`. It enumerates weighted
compositions, computes the `Z B_i` fiber representatives even for
nonprimitive columns, builds the moment matrix, and takes exact rank over
the rational function field. It does not test random coefficient
specializations in place of generic arithmetic.

| Balanced directed cycle | Degree | Carrier size | Matrix size | Dimension over Q(y) | Dimension after y=1 |
|---|---:|---:|---:|---:|---:|
| 3 vertices, 4 parallel arrows per edge | 1 | 15 | 12 x 15 | 3 | 4 |
| same | 2 | 45 | 36 x 45 | 9 | 10 |
| same | 3 | 91 | 72 x 91 | 19 | 20 |
| 4 vertices, 5 arrows per edge | 1 | 56 | 80 x 56 | 4 | 4 |
| 5 vertices, 7 arrows per edge | 2 | 330 | 595 x 330 | 15 | 15 |

These cases validate the general matrix implementation and expose the
coefficient-specialization distinction. They are not a substitute for the
general proof. In the coefficient-free column the program computes the
initial upper bound; a separate total-coprimeness result is needed whenever
one wishes to identify it with the full upper algebra.

One uniform useful candidate arising from the equations is, for the cyclic
`M(a)` matrix and independent principal coefficients,

\[
z_1=\frac{x_1^a+y_3x_2^a+y_2^{-1}x_3^a}{x_2x_3}\in U.
\]

Its only negative rows are the `x_2` and `x_3` rows, divisible respectively
by `y_2^{-1}P_2` and `P_3`; the `x_1` exponents are nonnegative. It has
degree `a-2`, and

\[
y_2z_1=x^{(0,-1,a-1)}(1+\widehat y_2+\widehat y_2\widehat y_3),
\qquad\widehat y_i=y_ix^{B_i}.
\]

This gives a finite upper element to pass to the formal-theta branch.
Neither its upper membership nor this three-term expression proves that it
is a theta function. No novelty claim is made for the element.

## 8. Literature audit and exact attribution

All items used below are pre-2026 primary sources. No 2026 theorem has been
used without a proof audit.

| Source | Read and checked | Use / restriction |
|---|---|---|
| Speyer, *An Infinitely Generated Upper Cluster Algebra*, arXiv:1305.6867v1, 2013; https://arxiv.org/pdf/1305.6867 | Entire three-page note, especially Lemmas 1–3 | Lemma 1 is the negative-row exchange-divisibility criterion. Lemma 2 uses denominator degrees for the `3,3,3` generic-coefficient example. This is the direct predecessor of the present degree argument. Do not claim this counterexample or row criterion as new. |
| Berenstein–Fomin–Zelevinsky, *Cluster algebras III*, arXiv:math/0305434v3; https://arxiv.org/pdf/math/0305434 | Definitions of upper bound, Theorem 1.5, Corollary 1.7, Proposition 1.8, Corollary 1.9 | The full-rank extended matrix gives total coprimeness and upper-bound invariance. Applied exactly to `[B;I]`; no acyclicity used. |
| Gross–Hacking–Keel–Kontsevich, arXiv:1411.1394v2; https://arxiv.org/pdf/1411.1394v2 | Entire proof of Proposition 7.1, printed pp.66–67, and Definition 7.2 | One-chart finite theta implies universally Laurent. Positivity in its proof is essential. This closes the infinite-support implication in Section 3. |
| Gross–Hacking–Keel, *Birational geometry of cluster algebras*, arXiv:1309.2573v2; https://arxiv.org/pdf/1309.2573 | Theorem 6.2, Example 6.3, Remark 6.4, Section 7 | Established principal/general-coefficient non-Noetherian families and failures of naive dual-basis expectations. Their `X`, `A`, fibers, and torsor statements have distinct hypotheses; no blanket transfer of every conclusion was used. |
| Lee–Li–Mills, *A Combinatorial Formula for Certain Elements of Upper Cluster Algebras*, arXiv:1409.8177v2; https://arxiv.org/pdf/1409.8177 | Introduction, Theorems 1.1–1.3, Section 4.2 grading and rank-three discussion | The positive combinatorial upper elements exist for arbitrary seeds; the acyclic basis theorem does not give a cyclic basis, and the paper explicitly says the cyclic family may be dependent/nonspanning. The weight `(b,c,a)` is already standard here. |
| Matherne–Muller, *Computing Upper Cluster Algebras*, arXiv:1307.0579v1; https://arxiv.org/pdf/1307.0579 ; author copy https://jpmather.math.ncsu.edu/documents/computingupper.pdf | Introduction and Proposition 6.2.2, including coefficient-free hypothesis | Their coefficient-free `M(a)` upper algebra is generated by initial variables and `(x_1^a+x_2^a+x_3^a)/(x_1x_2x_3)`. This confirms why generic principal coefficients cannot be silently specialized in the degree-zero/boundary discussion. |

Speyer's genericity condition excludes torsion of the product of the two
coefficient ratios. Independent principal coefficients meet it. His
degree-zero conclusion is stronger than mere nonnegativity at `kappa=1`.
The distinction between generic and coefficient-free algebras is already
visible in the cited sources and in the exact matrix ranks above.

## 9. Route and search record

| Route / search | Result | Status |
|---|---|---|
| Reprove the root's degree inequality without positivity | Localization and the lowest negative row suffice; proof is valid | Successful general mechanism |
| Convert finite-chart theta to global regularity | GHKK 7.1 supplies the precise implication; full proof read | Successful, literature input identified |
| Infer finite principal root support from the mutable bound | Fails: the hypotheses themselves force the positive kernel vector (6.2) | Rejected with a general reason; not used as a substitute for construction |
| Compute positive-degree spaces constructively | Finite carrier plus cosetwise Hasse moments gives exact `U_d` | Successful positive theorem and implementation |
| Preserve integral coefficients | Moment divisibility is monic after `s=y_it`; works over `Z[y^{+/-1}]` | Successful extension; syzygy module not automatically a positive/free basis |
| Search Speyer / GHK / LLM / rank-three upper algebra literature | Located the direct predecessors and coefficient caveats listed above | Useful, audited |
| Search exact phrases involving weighted degree, denominator, Hasse divisibility, kappa, Speyer, including recent results | No exact general `kappa`/fiber-matrix formulation located; this is not evidence of priority | Recorded negative search |
| Recent search lead: Cao–Keller–Qin, *The valuation pairing on an upper cluster algebra*, DOI 10.1515/crelle-2023-0080, published 2024 | Primary publisher result discusses denominator/valuation factorizations; exact full text was not independently audited in this task | Potential interface, not used as a theorem dependency |

Search refresh completed 2026-11-13 10:41 UTC. No claim was imported from a
search snippet in place of the primary proofs used above.

## 10. Handoff to the main theorem branch

The clean combination is now:

1. The arbitrary-`B` incoming-normalization recursion computes certified
   finite prefixes of formal principal theta functions.
2. For every positive balanced grading with `kappa<1`, the present theorem
   computes entire regular degree pieces by a finite polytope and an integer
   binomial matrix, over the actual coefficient ring.
3. A theta prefix outside the carrier is a certified infinite-support
   witness. Finite candidates inside the kernel can be passed back to the
   theta recursion and to representation-theoretic characterizations.

The unresolved bridge is a criterion that selects the theta elements
inside these finite modules and controls their frozen-root tails. It should
be attacked with genuinely new normalization, positivity, or categorical
input; neither a kernel basis nor stabilization of a finite prefix supplies
that criterion.
