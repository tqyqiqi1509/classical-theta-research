"""Independent classical framed flow-tree evaluation (rational signed packets).

Uses the Arguz--Bousseau binary attractor flow as an independently testable
candidate bridge. No theta coefficient or positivity oracle occurs in the
construction. Primitive vertex multiplicities are nonnegative. The axis
packets still carry (-1)^(k-1)/(D_i*k^2), and identical packets carry the usual
factorial denominator. Thus this is NOT an unsigned integer object model.
"""
from functools import lru_cache
from fractions import Fraction
from itertools import product
from collections import Counter
from math import factorial, gcd
from pathlib import Path
import json,time,sys,random
sys.path.insert(0,str(Path(__file__).resolve().parent))
from incoming_recursion import IncomingSchur,box


@lru_cache(None)
def partitions(n,minimum=1):
    if n==0:return ((),)
    return tuple((k,)+tail for k in range(minimum,n+1)
                 for tail in partitions(n-k,k))


def lexsign(x):
    for a in x:
        if a:return 1 if a>0 else -1
    return 0


def framed_matrix(B,D,g):
    return [[0]+[-D[i]*g[i] for i in range(len(B))]]+[
        [g[i]]+list(B[i]) for i in range(len(B))]


class FlowPackets:
    def __init__(self,B,D,g,packets,leaf_order=None,color_perturb=False):
        self.B=framed_matrix(B,D,g)
        self.D=(1,)+tuple(D)
        self.packets=((0,1),)+tuple((i+1,k)for i,k in packets)
        self.r=len(self.packets)
        self.eta=tuple(tuple(-self.D[i]*self.B[i][j]*k*l
                       for j,l in self.packets)for i,k in self.packets)
        self.full=(1<<self.r)-1
        self.ids={s:tuple(i for i in range(self.r) if (s>>i)&1)
                  for s in range(1,1<<self.r)}
        self.pair=lru_cache(None)(self._pair)
        self.charge=lru_cache(None)(self._charge)
        self.primitive_degree=lru_cache(None)(self._primitive_degree)
        self.flow=lru_cache(None)(self._flow)
        # Infinitesimally distinct positive mutable leaf weights; total is zero.
        # Optional earlier perturbations are generic on the original color lattice.
        leaf_order=tuple(leaf_order or range(len(packets)))
        ranks={v:j for j,v in enumerate(leaf_order)}
        ncolor=len(B) if color_perturb else 0
        self.theta_width=1+ncolor+len(packets)
        vals=[None]
        for j,(i,k) in enumerate(packets):
            vals.append((Fraction(k),)+tuple(Fraction(k*int(i==a))for a in range(ncolor))+
                        tuple(Fraction(int(ranks[j]==a))for a in range(len(packets))))
        vals[0]=tuple(-sum(vals[j][a]for j in range(1,self.r))for a in range(self.theta_width))
        self.theta=tuple(vals)
        self.valid_internal_nodes=0

    def _pair(self,S,T):
        return sum(self.eta[i][j]for i in self.ids[S]for j in self.ids[T])

    def _charge(self,S):
        a=[0]*len(self.B)
        for q in self.ids[S]:
            i,k=self.packets[q];a[i]+=k
        return tuple(a)

    def _primitive_degree(self,S):
        d=0
        for i,a in enumerate(self.charge(S)): d=gcd(d,self.D[i]*a)
        return d

    def _flow(self,S,theta):
        """Sum over unordered binary trees on S at the inherited flow covector."""
        if S&(S-1)==0:return 1
        first=S&-S;answer=0
        L=(S-1)&S
        while L:
            R=S^L
            if R and (L&first):
                a=self.pair(L,R)
                if a:
                    h=tuple(sum(theta[i][j]for i in self.ids[L])for j in range(self.theta_width))
                    s=lexsign(h)
                    if not s:raise ArithmeticError(('non-generic flow',S,L,theta))
                    if s==(1 if a>0 else -1):
                        theta2=tuple(tuple(theta[i][j]+h[j]*Fraction(
                                    sum(self.eta[k][i]for k in self.ids[S]),a)
                                           for j in range(self.theta_width))for i in range(self.r))
                        answer+=abs(a)*self.flow(L,theta2)*self.flow(R,theta2)
                        self.valid_internal_nodes+=1
            L=(L-1)&S
        return answer

    def evaluate(self):
        unsigned=self.flow(self.full,self.theta)
        leaf_degrees=1
        for i,k in self.packets: leaf_degrees*=self.D[i]*k
        primitive=Fraction(unsigned,leaf_degrees)
        assert primitive.denominator==1,(self.packets,unsigned,leaf_degrees)
        weight=Fraction(1)
        for i,k in self.packets:weight*=Fraction((-1)**(k-1),self.D[i]*k*k)
        for count in Counter(self.packets).values():weight/=factorial(count)
        return unsigned*weight,{'packets':self.packets,'flow_weight':unsigned,
            'primitive_flow_weight':int(primitive),'cycle_weight':str(weight*leaf_degrees),
            'packet_weight':str(weight),'contribution':str(unsigned*weight),
            'cached_flow_states':self.flow.cache_info().currsize}


def flow_coefficient(B,D,g,p):
    answer=Fraction(0);records=[]
    for parts in product(*(partitions(k)for k in p)):
        packets=tuple((i,k)for i,part in enumerate(parts)for k in part)
        model=FlowPackets(B,D,g,packets)
        value,record=model.evaluate();answer+=value
        if value:records.append(record)
    return answer,records


def run():
    start=time.time();reports=[]
    cases=[([[0,1],[-1,0]],[1,1],(-2,1),(3,3)),
           ([[0,3],[-2,0]],[2,3],(-2,1),(3,3)),
           ([[0,1,-1],[-1,0,1],[1,-1,0]],[1,1,1],(-1,0,0),(2,2,2)),
           ([[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],(-1,0,0),(2,2,2)),
           ([[0,3,-3],[-3,0,3],[3,-3,0]],[1,1,1],(-1,0,0),(2,2,2))]
    for B,D,g,cap in cases:
        truth=IncomingSchur(B,D).theta_prefix(g,cap);checks=0;errors=[];examples=[]
        for p in box(cap):
            if sum(p)>5:continue
            value,records=flow_coefficient(B,D,g,p);checks+=1
            if value!=truth.get(p,0):errors.append({'p':p,'flow':str(value),'theta':truth.get(p,0),'records':records})
            if any(Fraction(a['contribution'])<0 for a in records)and len(examples)<3:
                examples.append({'p':p,'total':str(value),'records':records})
        reports.append({'B':B,'D':D,'g':g,'cap':cap,'checks':checks,'errors':errors,
                        'signed_packet_examples':examples})
        print('case',B,'checks',checks,'errors',len(errors),flush=True)
    out={'seconds':time.time()-start,'reports':reports}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'seconds':out['seconds'],'checks':sum(r['checks']for r in reports),
                      'errors':sum(len(r['errors'])for r in reports)},indent=2))


if __name__=='__main__':run()
