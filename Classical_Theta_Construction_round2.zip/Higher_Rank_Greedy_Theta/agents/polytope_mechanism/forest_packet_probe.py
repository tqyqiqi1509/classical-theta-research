from itertools import product
from math import comb
import json
from pathlib import Path


def gb(n, k):
    if k < 0:
        return 0
    if n >= 0:
        return comb(n, k) if k <= n else 0
    return (-1)**k * comb(-n + k - 1, k)


def le(q, p):
    return all(a <= b for a, b in zip(q, p))


def theta(B, g, D=None):
    n = len(g)
    D = D or [1]*n
    d = []
    for i in range(n):
        d.append(max(0, -g[i] + sum(-B[i][j]*d[j] for j in range(i))))
    J = sorted(product(*(range(x+1) for x in d)), key=lambda p: (sum(p), p))
    C = {}
    for p in J:
        for q in J:
            if le(q, p):
                c = 1
                for i in range(n):
                    r = -g[i] - sum(B[i][j]*p[j] for j in range(i)) - sum(B[i][j]*q[j] for j in range(i+1, n))
                    c *= gb(r, p[i]-q[i])
                C[p, q] = c
    a = {(0,)*n: 1}
    for p in J[1:]:
        m = [g[i]+sum(B[i][j]*p[j] for j in range(n)) for i in range(n)]
        I = [q for q in J if le(q,p) and (q == p or sum(m[i]*D[i]*(p[i]-q[i]) for i in range(n)) < 0)]
        row = {p: 1}
        for q in reversed(I[:-1]):
            row[q] = -sum(row[s]*C[s,q] for s in row if le(q,s) and q != s)
        a[p] = -sum(row[q]*a[q] for q in I if q != p)
    return d, a, C


def nonnegative_forest_weight(B,g,p):
    value=1
    for i in range(len(g)):
        r=-g[i]-sum(B[i][j]*p[j] for j in range(i))
        if p[i] and (r < p[i]):
            return 0
        value*=gb(r,p[i])
    return value


def probe():
    tested=0
    mismatches=[]
    for b,c in [(1,1),(2,2),(3,3),(1,3),(2,3)]:
        B=[[0,b],[-c,0]]
        for a1 in range(1,7):
            for a2 in range(1,7):
                g=[-a1,c*a1-a2]
                d,a,C=theta(B,g,D=[c,b])
                tested+=1
                for p,value in a.items():
                    forest=nonnegative_forest_weight(B,g,p)
                    if value!=forest:
                        mismatches.append(dict(B=B,g=g,d=d,p=p,theta=value,positive_forest=forest,total_matrix=C[p,(0,0)]))
    result=dict(tested_inputs=tested,mismatch_coefficients=len(mismatches),first_mismatches=mismatches[:12])
    out=Path(__file__).with_name('forest_packet_probe.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    probe()
