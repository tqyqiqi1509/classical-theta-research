# Finite event flags and positive whole-ray words for valued theta coefficients

**Authoring branch:** `valued_global_assembly`, 2026-11-13, begun 13:50 UTC.
**Current stage:** full construction and proof, 14:21 UTC; the companion
`valued_charge_word_grammar.md` proves the local word lemma, and
`TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md` gives literal finite Dyck objects
for its coefficients. Parent and an independent agent are reviewing the
global identification. The ordinary and ramified attached algebras give
an additional representation-theoretic realization. This file does not
assume that a primitive tree admits a phase quotient.

The construction below takes only an integer matrix, a symmetrizer, a
coefficient bound, and a formal generic covector. Its intermediate states
are enumerated before any wall functions or coefficients are known. A
state uses finite positive charge words decorated by bounded integer
gradings of explicit Dyck paths. Actual two-input attached objects give
another realization of the same local polynomials. No scattering diagram
or broken-line list is an input.
The comparison to incoming completion is a proof of the answer, rather
than its definition.

## 1. Lattice, coefficients, and a primitive normal

Let `L=Z^r`, let `D=diag(D_i)` be positive integral, and let `B` satisfy
`DB=-(DB)^t`. Write

\[
 \eta(a,b)=-a^t DBb,\qquad
 d(a)=\gcd_i(D_i a_i),\qquad n(a)=Da/d(a).
\]

Positive charges are nonzero elements of `N^r`. The vector `n(a)` is the
primitive ambient normal even when `a` is not primitive. In particular
`n(ka)=n(a)` and `d(ka)=k d(a)`.

Fix a target charge `S`. All charges appearing in its construction lie in
the finite box `0<=T<=S`; multiplication discards monomials outside this
box. Every ray packet with carrier `a` has the form

\[
 F_a=1+\sum_{j\geq1} A_{a,j}z^{ja},
\]

where every coefficient is a finite set, or its polynomial in independent
elementary symbols. Only finitely many terms survive the box truncation.
Disjoint union and Cartesian product are the semiring operations. An
occurrence of a packet has its own tag, even if another occurrence has the
same carrier and polynomial. Parallel occurrences commute but need not
be merged during a local word computation.

For the original incoming axes the universal packet is

\[
 I_i=\sum_{j\geq0} e_j(X_i)z^{je_i}.
\]

The alphabets `X_i` keep the original types throughout the construction.
The classical ordinary-cluster specialization is `e_1(X_i)=1` and
`e_j(X_i)=0` for `j>1`. Each surviving original leaf retains its color.

## 2. The positive two-input operation with literal Dyck objects

Use the classical Hamiltonian pairing `K=-eta=DB` for word composition;
the incoming-time convention below continues to use `eta=-DB`.
Suppose two packet occurrences have carriers `a,b` with
`m=K(a,b)>0`. The local operation replaces their inverted word by the
oppositely ordered parents and the interior-ray packets:

\[
       [F_a,F_b]\quad\longmapsto\quad
       [F_b,\ \{H_{u,v}:u,v>0,\ \gcd(u,v)=1\}_{\rm angle},\ F_a].
                                                               \tag{2.1}
\]

Only carriers `gamma=u a+v b<=S` are retained. **Do not divide gamma by
the gcd of its ambient coordinates.** The output is a series in
`z^gamma`, with the primitive ambient normal `D gamma/d(gamma)`.

The coefficients of `H_{u,v}` are defined by the literal bounded Dyck
gradings in Section2.1. They are explicit positive polynomials in the
coefficients of the two input packets. The same polynomials have an
alternative actual Young-module realization, described in Section2.2.
For that realization the arrow multiplicity is `m`, the input phase
weights are `d(a),d(b)`, and the framing has pairing `d(gamma)` with
`u a+v b`. Such a framing exists. Indeed

\[
 \gcd(u d(a),v d(b))\mid d(gamma),\qquad d(gamma)\mid m.
\]

The second divisibility follows from `d(gamma)|u m` and
`d(gamma)|v m`. Choose positive `P` in `d(a)Z` and `Q` in `d(b)Z`
with `Pu-Qv=d(gamma)`. A sufficiently large common Bezout shift makes
both positive.

### 2.1 Literal finite path objects, requiring no algebraic roots

For the pure combinatorial definition use the construction in
`proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md` instead of algebraic orbit
labels. In the notation above put

\[
 u=m/d(a),\quad v=m/d(b),\quad
 \ell=\gcd(sv,tu),\quad (A,B)=(sv/\ell,tu/\ell),
 \quad c=\frac{m\,d(sa+tb)}{\ell\,d(a)d(b)}
       =\frac{d(sa+tb)}{\gcd(s d(a),t d(b))}
\]

for a coprime positive output pair `(s,t)`. The integer `c` is positive.
For coefficient degree `j` take the maximal Dyck path to the smallest
rectangle `(r,h)` with

\[
 A h-B r=1,\qquad r\geq jsv,\qquad h\geq jtu.
\]

Its vertical edge weights sum to `jsv` and are divisible by `v`; its
horizontal weights sum to `jtu` and are divisible by `u`. Impose the
explicit compatible-grading and tight-shadow conditions, both finite
cyclic-interval sum comparisons. A vertical weight `v k` receives a
decoration from the input coefficient set `A_{a,k}`; a horizontal weight
`u k` receives one from `A_{b,k}`. The coefficient at `z^(j(sa+tb))`
is the disjoint union of ordered `c`-tuples of these decorated gradings
whose degrees sum to `j`.

The cited companion note states all interval and shadow inequalities and
proves the normal conversion. Its only pre-existing coefficient identity
is the rank-two tight-grading theorem of Burcroff--Lee--Mou; no wall list
or theta coefficient is an argument of the object construction. These
literal path objects are the primary local definition in the implemented
global grammar. Their theorem proves (2.1) for arbitrary polynomial
inputs after the stated positive decoration substitution.

### 2.2 Alternative representation-theoretic realization

For an attached coefficient of content `(ku,kv)`, the actual finite
Young set of the valued Gale algebra has orbit stabilizers
`S_lambda x S_mu`. Each orbit gives a monomial

\[
              e_\lambda(X_a)e_\mu(X_b).
\]

Replacing `e_j(X_a)` by `A_{a,j}` and similarly for `b` gives another
finite coefficient object, tagged by these actual orbits. The two-input
attached-wall theorem identifies its complete Frobenius characteristic
with the same universal polynomial as Section2.1. Complete phase packets
are retained inside each actual attached algebra. This supplies the
representation-theoretic meaning of the literal Dyck operation; it is not
an additional input or a multiplicity oracle for its definition. Nothing
here makes a subtree into a new simple object of a KLR category.

## 3. A finite word with inherited factors retained

Let `K` be a nondegenerate rational two-plane in the positive cone. Start
with one full packet for each bounded primitive ambient ray in `K`, ordered so
that an adjacent inverted pair has positive Hamiltonian pairing `-eta`.
Repeatedly choose the
leftmost adjacent inverted pair and apply (2.1). The interior packets are
inserted already in the target angular order. Give every new occurrence
a birth tag consisting of the two parent occurrence tags and its coprime
pair `(u,v)`. Parent occurrences remain unchanged.

For this structural definition retain identity packets and retain every
syntactically possible birth `u a+v b<=S`, even if all its eventual
coefficient sets are empty. Thus the entire word history is fixed from
the charge data before any nonvanishing decision is made.

This procedure is finite at the fixed box bound. For the total carrier
mass `h(a)=sum_i a_i`, every birth satisfies

\[
 h(u a+v b)=u h(a)+v h(b)>\max\{h(a),h(b)\}.           \tag{3.1}
\]

It is essential not to primitive-reduce a born carrier. A fixed pair of
occurrences can exchange at most
once, since their relative order is then correct and no operation changes
their carriers. Induction on total degree therefore bounds the number of
possible occurrences and exchanges. The genealogy has strictly smaller
positive carrier degree at every parent edge. In addition, a nonempty
born coefficient contains a positive input coefficient degree from both
parents; this is the stronger coefficient ancestry used in Section5.

After sorting, keep separately the original occurrences and all born
ones. For each ambient ray `rho`, let `R_rho` be the product of the born
packets on that ray. The final ray packet is

\[
                     F^{\rm initial}_\rho R_\rho.       \tag{3.2}
\]

Equation (3.2) is a factorization with actual positive objects. There is
**no division by the inherited parallel factor**. It follows from the
local identities and ordered ray-factor uniqueness that `R_rho` is the
new local factor relative to the specified incoming packets. A different
deterministic exchange order may change the decoration set, but gives the
same coefficient polynomials by the same uniqueness theorem.

This positive-word theorem is local and uses no higher-rank wall list.
Existing positive reordering theorems are relevant prior work; the global
object below adds an independently enumerated finite causal state graph.
The unpruned structural history is fixed independently of coefficient
nonvanishing. Deleting identity occurrences is only an implementation
optimization. It may change auxiliary exchange history, but the positive
packet identities and uniqueness give the same coefficient cardinalities.

## 4. States and the independent finite event graph

A state is a pair `(S,Theta)` with `Theta(S)=0`. Covector entries belong
to a finite ordered rational vector space: every sign is the sign of its
first nonzero coordinate. Additional coordinates are smaller independent
positive infinitesimals. The root covector is generic modulo `S`; its
rational kernel is exactly `Q S`.

Enumerate every proper nonzero charge `b<=S` for which
`eta(S,b)!=0`. It defines

\[
 K=\operatorname{span}_{\mathbb Q}(S,b),\qquad
 \tau=-\Theta(b)/\eta(S,b),\qquad
 q=\Theta+\tau\eta(S,-).                                \tag{4.1}
\]

Keep the candidate if `tau>0`. Deduplicate candidates by their rational
two-plane. The common positive cone is simply `K intersect R^r_{>=0}`;
only its finitely many bounded positive charges are used. Call the finite
list of surviving candidates `E(S,Theta)`.

For every such `K` and every proper nonzero charge `T<S` in the box and
in `K`, put `rho(T)=T/gcd(T_i)`, and create the child state

\[
       (T,\ q+\delta\eta(\rho(T),-)).                   \tag{4.2}
\]

Here `delta` is one new positive infinitesimal smaller than every old
coordinate. Use the same `delta` for all coefficients of an incoming ray
at this event. Thus coefficients of `T=j rho` are evaluated at the same
incoming covector, rather than at unrelated perturbations.

All child states have smaller total degree than `S`. Enumerating these
states recursively therefore produces a finite graph, independent of all
coefficient values and all local word decorations. States may be merged
when their exact covectors and target charges coincide. At most `|S|-1`
new infinitesimal levels are needed.

### 4.1 Genericity and the strict local-time calculation

Inductively `ker_Q Theta=Q S`. For a candidate plane `K` in (4.1), if
`q(c)=0`, then

\[
 \Theta\left(c-\frac{\eta(S,c)}{\eta(S,b)}b\right)=0.
\]

Hence `c` lies in `K`. Thus `ker_Q q=K`; no unexamined higher-codimension
genericity assumption is made. In (4.2), the old coordinates first force
`c in K`; the new delta coordinate then forces
`eta(rho(T),c)=0`. Nondegeneracy on `K` makes this exactly `Q T`.
Consequently the genericity hypothesis propagates.

If a proposed child event lies in the current `K`, its time at (4.2) is

\[
 -\frac{q(c)+\delta\eta(\rho(T),c)}{\eta(T,c)}
                      =-\delta/j<0,\quad T=j\rho(T).    \tag{4.3}
\]

It is excluded. Events outside `K` retain their old nonzero leading
sign. This is the precise causal rule which prevents a factor born at the
current event from feeding back as one of that event's incoming packets.

## 5. Whole-ray forest objects at a state

Assume all smaller states have been constructed. For `K in E(S,Theta)`
and each primitive positive ambient ray `rho` in `K`, form the complete
incoming polynomial through proper degrees:

\[
 A_{K,\rho}=1+\sum_{\substack{j\rho\leq S\\|j\rho|<|S|}}
 \mathcal F\bigl(j\rho,q+\delta\eta(\rho,-)\bigr)z^{j\rho}.
                                                               \tag{5.1}
\]

Apply the deterministic word construction of Section 3 to all these
packets. Keep all its born factors whose carrier is parallel to `S`, and
multiply them; denote this finite-set series by `R_{K,S}`. Born carriers
are retained unchanged; conversion to the common ambient ray is only a
reindexing of their monomial powers.

Let `I_{rho(S)}` be the original incoming axis packet if the ray is an
axis, and `1` otherwise. Define

\[
 \boxed{\quad
 \mathcal F(S,\Theta)=
 [z^S]\ I_{\rho(S)}\prod_{K\in E(S,\Theta)} R_{K,S}.
 \quad}                                                       \tag{5.2}
\]

The product means disjoint union over all charge allocations among its
factors, with a Cartesian product for every allocation. Give the finite
event list a fixed lexicographic order, so these are actual tuples. They
are **event-flagged forests**: each chosen root has a local exchange
history, explicit tight-Dyck grading decorations, and children belonging to
the already constructed incoming coefficient sets.

Every born term of total charge `T` uses positive input degrees from at
least two nonparallel parents. Each such degree is proper in `T` and
hence in `S`. Therefore (5.1) contains every input needed in (5.2).
The omitted degree-`S` inherited parallel coefficient is central at this
cutoff: it cannot create another degree-`S` term by interacting with a
positive factor. Its unchanged inherited occurrence is deliberately not
part of a born factor. This proves the recursive definition without a
same-degree call, an inverse, or a virtual coefficient subtraction.

## 6. Identification with incoming normalization

The argument is entirely in a finite positive-charge Lie group. It does
not assume that an unknown wall support or joint has already been
enumerated. In this section write `P` for a two-plane and reserve
`K=-eta=DB` for the alternating form.

### 6.1 The finite group and the three-factor lemma

The charges outside the box `[0,S]` form a monoid ideal: adding a
positive charge cannot return to the box. Hence the corresponding
quotient of the positive-charge Lie algebra is finite and nilpotent,
filtered by `|a|`. Use its faithful principal-coefficient action, or its
abstract graded group. Restricting to root monomials alone can erase
central operators and must not be used to prove uniqueness.

For the ordinary classical specialization, let `C` be the group element
provided by `INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`. That
theorem establishes its group membership and its incoming zero-factor
conditions. For the independent alphabet variables, the same established
incoming-factor bijection prescribes the axis packets `I_i` and identity
on every nonaxis incoming ray. The following argument applies to either
choice.

For any finite lexicographic covector `theta`, its negative, zero, and
positive root spaces are Lie subalgebras, and there is a unique product
decomposition

\[
 C=C_{\theta,-}C_{\theta,0}C_{\theta,+}.               \tag{6.1}
\]

Indeed, at each next height quotient, the three sign subspaces are a
direct sum and multiplication adds their components. This proves
existence and uniqueness by height induction. In particular, (6.1)
depends only on the signs of the finitely many retained charges.

Let `T_a(F)` denote the positive-normal automorphism, with ambient action
`x^m -> x^m F^(n_a dot m)` and root action as in (2.1). A negative-to-
positive transport uses `T_a(F)^(-1)`. When the only retained nonzero
zero-sign charges are parallel to `rho` (in particular when
`ker_Q theta=Q rho`), define the packet `F_rho(theta)` by

\[
             C_{\theta,0}=T_\rho(F_\rho(\theta))^{-1}.
                                                               \tag{6.2}
\]

The packet function is not inverted in this notation.

### 6.2 Completeness of the finite event list

Follow `theta(t)=Theta+t eta(S,-)` with decreasing positive `t`. A
retained charge `a` not parallel to `S` changes sign only at

\[
              t=-\Theta(a)/\eta(S,a),
\]

with nonzero denominator. These are exactly the candidates of (4.1).
Equal planes give equal times and are deduplicated. If the denominator
is zero, the sign is constant and nonzero. The kernel calculation in
Section 4.1 shows that each event covector `q` has exactly the indicated
two-plane `P` as rational kernel; two different planes cannot occur at
the same time. Since (6.1) depends only on these signs, the target-ray
packet is constant between consecutive events. This proves event-list
completeness directly from the finite charge arrangement. An event
whose local packets contribute nothing simply has born factor `1`.
This is a finite ordered-parameter argument: select one parameter value
between consecutive listed times. Only the retained charges matter, so
an accidental kernel direction outside the finite box is irrelevant.

### 6.3 A local event is refactorization of one common group element

At an event first factor

\[
                  C=C_{q,-}C_{q,0}C_{q,+}.
\]

For a perturbation `q+delta psi`, all signs outside `ker q=P` stay
unchanged. Factor `C_{q,0}` internally by the signs of `psi`. Its
negative factor can be combined with `C_{q,-}`, and its positive factor
with `C_{q,+}`: sign closure keeps these products in the required
subgroups. Uniqueness of (6.1) proves that the perturbed zero factor is
computed wholly inside `C_{q,0}`. Thus the outside factors are fixed;
there is no unexamined higher-dimensional contribution at the event.

Put

\[
                         H=C_{q,0}^{-1}.               \tag{6.3}
\]

The positive charges of `P` lie in a pointed cone. Order their rays with
`alpha` before `beta` when `K(alpha,beta)>0`. For a ray `rho`, the
functional `eta(rho,-)` is positive on the rays before `rho` and negative
on the rays after `rho`. Taking the inverse of (6.1) therefore shows that
the corresponding ordered factor of `H` is exactly

\[
 T_\rho(A_\rho),\qquad
 A_\rho=F_\rho(q+\delta\eta(\rho,-)).
\]

The opposite angular factorization of the SAME element `H` similarly
has factors `T_rho(B_rho)`, with
`B_rho=F_rho(q-delta eta(rho,-))`. The packets `A_rho` and `B_rho`
themselves have not been inverted. Ordered ray factorization is unique
by the same height induction used above.

Apply all deterministic adjacent word exchanges of Section 3 to this
first factorization of `H`. The factors originally present survive
unchanged and the operation inserts only born factors. After sorting,
uniqueness of the opposite angular factorization gives

\[
                        B_\rho=A_\rho R_\rho.          \tag{6.4}
\]

Parallel factors share the same primitive normal and commute, so this
is an equality of packet functions. It retains every inherited parallel
factor and introduces no positive quotient. The valued normal power in
Section 2 is already an equality on the full ambient torus; there is no
extra fractional projection in this step.

For an elementary orientation check, take `K(e_1,e_2)=m>0`. The
incoming directions are `(0,-m)` and `(m,0)`. The two local transports
are `(T_a T_b)^(-1)` and
`(T_b (product of born T) T_a)^(-1)`. Their equality is exactly the
positive word identity after taking inverses. The target parameter
decreases from `q+delta eta(S,-)` to `q-delta eta(S,-)`, so (6.4)
multiplies its packet by `R_{P,S}`.

### 6.4 Incoming normalization fixes the starting packet algebraically

Set `psi=eta(S,-)`. Inside the coarse zero Lie algebra for `psi`, the
subalgebra on the `S` ray is a central direct summand. The sum of the
root spaces not parallel to `S` is a complementary Lie ideal: if
`alpha+beta=lambda S` and `psi(alpha)=psi(beta)=0`, then

\[
 K(\alpha,\beta)=\lambda K(\alpha,S)=0.               \tag{6.5}
\]

Consequently a bracket of complementary roots cannot create an `S`-ray
component. Projection of the coarse zero group onto this central ray
factor is a group homomorphism. Refining `psi` by any generic tie
covector with kernel `Q S` leaves that factor unchanged.

For sufficiently large `t`, the signs of `theta(t)` are those of `psi`
where `psi` is nonzero, with `Theta` resolving the zero ties. The
root-dependent `sigma_S` of the incoming-prefix theorem is another
refinement with the same first functional `psi`. Its zero-factor
normalization prescribes `T_rho(I_rho)^(-1)`, or identity on a nonaxis
ray. Applying the normalization at each retained multiple of `rho`
fixes the whole ray packet through the cutoff. Equation (6.5) proves
that the arbitrary tie refinement used here has the same factor.
Therefore the starting packet is exactly `I_rho`, or `1` on a nonaxis
ray. No assertion about a wall support at infinity is needed.

### 6.5 Induction closes the coefficient formula

Every born term uses positive coefficient degrees from both nonparallel
parents. Hence an output of charge at most `S` only needs proper input
coefficients `T<S`. By height induction these are exactly (5.1), using
the incoming perturbations proved valid in Section 4.1. The omitted
degree-`S` incoming coefficient is parallel to `S` and central at this
box cutoff: interacting with any positive charge leaves the box, so it
cannot alter a born contribution of degree `S`.

Equation (6.4) at each event, multiplied from the starting value of
Section 6.4 down to `Theta`, now gives

\[
 F_{\rho(S)}(\Theta)=
       I_{\rho(S)}\prod_{P\in E(S,\Theta)}R_{P,S}
       \quad\text{through the box cutoff}.             \tag{6.6}
\]

Extracting charge `S` is precisely (5.2). This proves, by height
induction, that the independently defined finite objects count the
normalized ray coefficients for every `B,D,S,Theta`.

If `eta(S,-)=0`, there are no events, and the central-summand argument
applies to the whole Lie algebra. The incoming normalization already
fixes the packet everywhere: it is the initial axis packet, or identity
on a nonaxis radical ray. Initial radical axes remain visible in the
faithful ambient action. This handles the radical without a transverse
flow direction.

## 7. One frame and the theta coefficient

For the user's theta coefficient data `(B,D,g,p)`, form

\[
 \widehat B=\begin{pmatrix}0&-g^tD\\g&B\end{pmatrix},
 \qquad \widehat D=\operatorname{diag}(1,D),
 \qquad S=(1,p).
\]

Set `mu_i=1+epsilon_i`, with independent ordered original-color
infinitesimals, and choose

\[
 \Theta(e_i)=\mu_i\ (i>0),\qquad
 \Theta(e_0)=-\sum_i p_i\mu_i.
\]

Its rational kernel is `Q S`. Apply (5.2) to the extended weighted
lattice and specialize each original alphabet, including the frame, to
one letter. We first distinguish the total incoming transport from the
single zero-ray packet.

**One-frame zero-ray lemma.** In the componentwise bound `S=(1,p)`,
factor the total transport at `Theta` as `C_- C_0 C_+`, with positive
`Theta` charges in the right factor, so they act first. Every proper
positive charge is unframed: a framed proper charge `(1,q)<=S` has
`Theta(1,q)=-sum_i(p_i-q_i)mu_i<0`. Conversely every nonzero unframed
charge is positive. An unframed wall acts trivially on the test monomial
`x^(-e_0)`, since its primitive normal has zero frame coordinate. Thus
`C_+` acts trivially. The rational zero kernel is `Q S`, and the only
nonzero zero-slope charge in the bound is `S` itself. It has `d(S)=1`,
so the action of its packet on `x^(-e_0)` has exponent one in the fixed
wall-action convention. Every charge in `C_-` contains a frame. Acting
on an already framed term exceeds the bound, while acting once on the
unchanged term can produce only a proper negative charge, never `S`.
Consequently the coefficient of charge `S` in the total transport is
exactly the coefficient of the zero-ray packet. This also verifies the
factor action order, rather than conflating the two operators.

The one-frame total-transport identity already established in
`INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`, followed by this lemma,
therefore gives

\[
                 a_g^B(p)=|\mathcal F((1,p),\Theta)|.    \tag{7.1}
\]

Here `d(S)=1`. There is no positive proper charge parallel to `S`, and
there can be no product of two positive framed charges at frame degree
one. The action on the test monomial `-e_0` therefore reads the packet
coefficient once, with exponent one. No final alternating sum is required:
the local Young involutions have already turned every operation into its
positive polynomial in original elementary coefficients.

Before the one-letter specialization, the result is an elementary-positive
polynomial in the original alphabets. Every monomial `e_lambda(X_i)`
is realized by the corresponding induced Young sign module, or after
applying the original-type omega by an actual Young permutation module.
Thus original types are retained throughout, although no claim is made
that this module is a termwise phase quotient of the old primitive-tree
module. The latter is false.

## 8. A rejected local sector and its explicit obstruction

A tempting shortcut was to remove the inherited parallel packet by
selecting attached points with no isolated parallel-input zero-edge
component. It works for ordinary all-one gains under generic typed
targets. It fails for complete ramified packets in general.

Take the rank-two weighted lattice `D=(2,3)`, `eta=6 det`, the two axis
charges `A=(1,0), B=(0,1)`, and a parallel input `R=(1,1)`. Their phase
weights are `2,3,1`. For the output ray `s=(1,1)`, use
`r(A)=-2,r(B)=3,r(R)=1`, so the primitive output frame has pairing one.
In a sector where `A,B` form a zero component, the six relative phases
are one orbit of `mu_2 x mu_3`. Gauge them to `a=b=c` and put `x_R=t c`.
The two remaining master functions are

\[
 \Gamma_R=c\,\frac{t(t-1)(t+1)^3}{(t^2+t+1)^2},\qquad
 \Gamma_{AB}=c\,\frac{(t^2+t+1)^2}{(t-1)(t+1)^3}.
\]

For independent targets their ratio gives

\[
 t(t-1)^2(t+1)^6-k(t^2+t+1)^4=0.                         \tag{8.1}
\]

This is generically a squarefree polynomial of degree nine, with no
forbidden roots `t=0,1,-1` or `t^2+t+1=0`. Thus the actual isolated-R
sector has nine generic points, whereas the inherited parallel packet
times the `AB` packet has coefficient one. The residual common phase
group is trivial. The literal zero-component selection is therefore not
the desired positive quotient.

An actual Wolfram Language computation on 2026-11-13 14:09 UTC returned
degree `9`, generic gcd with the derivative `1`, and discriminant

`81 k^6 (-47775744 - 51390208 k + 1562312313 k^2 + 53436672 k^3 + 47775744 k^4)`.

This route is closed. Sections 3--5 avoid the false sector by retaining
inherited occurrences and taking positively born factors instead.

## 9. Priority and route record

- **13:50--14:09:** explored a whole attached isolated-parallel sector.
  The ordinary version has a plausible finite-center separation, but
  its ramified analogue has the explicit degree-nine obstruction in
  Section 8. No positivity theorem is deduced from this failed sector.
- **14:09--14:16:** switched to actual two-input packet words and an
  independently enumerated event graph. The strict decrease is total
  original charge, not an informal assertion that a scattering process
  eventually stops. Local exchange histories preserve original inherited
  occurrences and their tags.
- **14:10 primary literature check:** Burcroff--Lee--Mou,
  arXiv:2503.03719v1, Sections 5 and 9, already proves positive rank-two
  coefficient operations and propagation to arbitrary rank. Qiyue Tang,
  Hexagon2611.00238v1, Sections 9.2--9.4, already treats enlarged lattices,
  ambient primitive normals, and positive formal wall operations.
  Hexagon2611.00279v1, Sections 8.3 and 9.3, already contains positive
  quantum-word reordering and an incoming decreasing recursion. These
  are prior interfaces, not novelty claims of this branch. The present
  proposed deliverable is the explicit valued coefficient object with
  finite charge-box states, strict incoming flags, whole-ray birth tags,
  and actual ramified Young decorations.
- **14:21 primary full-proof check:** Tang II Theorem9.3, specifically
  its paragraphs beginning with the incoming line and ending with
  degree-`d-1` inputs, already contains the general strategy of incoming
  line induction through local positive reordering. Tang Gale
  Proposition9.4 explicitly retains original parallel full lines while
  proving positivity of their additional correction factor; its proof
  uses translated diagrams and coefficient labels. BLM Theorem9.9 uses
  the corresponding finite-diagram perturbation method. These are useful
  and directly relevant. Our independent state graph, kernel proof,
  strict infinitesimal flags, literal Dyck decorations, and positive
  unpruned word histories make that strategy a coefficientwise finite
  object for arbitrary valued input. The incoming-induction strategy and
  the existence of positive corrections are not claimed as new here.
- **Later primary-proof recheck:** Tang II Section9.1 already uses the
  finite sign arrangement and its three-factor refinements. Its
  incoming coarse-zero trace is additive because `Omega(a,r)=0` kills
  the relevant brackets, which is the same central-projection mechanism
  expanded in Section6 here. Section8.1 also already bounds charge-`B`
  histories by at most `B` input leaves. The finite-group proof and leaf
  bounds here are detailed checks and inputs to this assembly, not
  claims of priority for those mechanisms. The specific new deliverables
  pursued here are the literal valued Dyck catalog and all-theta
  coefficient objects, their actual implementations, and the sparse
  support-position polyhedral realization.

Primary sources opened in this branch:

- <https://arxiv.org/html/2503.03719v1>
- <https://hexagonmath.org/pdf/2611.00238v1>
- <https://hexagonmath.org/pdf/2611.00279v1>

The 2026 papers are not used to bypass any of the normal-divisibility,
full-Artin-factor, or word-termination arguments above. The companion
local proofs and the present explicit state-graph argument are the
substantive checks required before claiming the global theorem.

## 10. Actual global implementation and independent operator checks

`computations/valued_event_flag_grammar.py` implements (4.1)--(5.2)
directly with rational covector vectors, positive time tests, nonprimitive
birth carriers, leftmost word exchanges, and the bounded tight gradings
from `tight_grading_two_input.py`. Its definition never calls the
incoming-integer oracle. That independent oracle is used only in the
test harness.

The initial six complete global checks pass. In particular the former
termwise phase obstruction

`D=(1,2), B=[[0,2],[-1,0]], g=(-6,2), p=(2,2)`

now produces one actual global object, agreeing with the independent
integer coefficient. A cyclic valued rank-three input with
`B=[[0,2,-1],[-1,0,1],[1,-2,0]], D=(1,2,1), g=(-3,-2,1), p=(1,1,1)`
produces twelve. The six-case output records every state, event, word
exchange, and born-factor count in `valued_event_flag_grammar.json`.
These examples test the interfaces; the general proof is in Sections4--7.

The separate `valued_word_operator_check.py` does not compare one
implementation of sorting with another. It evaluates the literal
monomial action of each input and output packet on a finite basis, using
integer polynomial powers, including negative exponents. Thirty inputs
with three to six slope/parallel occurrences, arbitrary non-binomial
positive input polynomials, symmetrizers `(1,1),(1,2),(2,3),(2,2),(2,4)`,
and edge multiplicities up to twelve give ninety independent monomial
operators. All 3,020 recorded nonzero matrix entries agree. Every test
also checks that inherited parallel packet occurrences remain exactly
unchanged, and that the diagonal total is their product with the positive
born packet. The record is `valued_word_operator_check.json`.

This second family specifically checks the general mechanism that failed
for literal isolated-particle subtraction: whole-ray polynomial inputs,
several slopes, repeated parallel carriers, and the ambient normalization
at nonprimitive births.

The full original-elementary verification in
`computations/valued_event_formal_profiles.py` compares eight formal
coefficient polynomials monomial by monomial with the signed incoming
recursion. It independently checks all forty-two weighted permutation
cycle classes and recomputes four traces from a previously constructed
actual 88-dimensional graph module. All agree. The cases include
genuinely nonprimitive born carriers and factors born on an inherited
parallel ray; no interpolation from scalar evaluations is used.

`computations/dyck_object_factory.py` constructs literal finite-set
recipes: units, disjoint unions indexed by actual tight gradings,
Cartesian products, and ordered normal-copy slots. Numerical cardinality
is evaluated only after the complete recipe has been constructed.
`universal_dyck_object_factory.py` extends its incoming axis coefficient
to the actual leaf `(i,k)` representing `e_k(X_i)`. The eight universal
recipes have exactly the same formal leaf profiles as the preceding
two coefficient algorithms. Thus the implementation does not substitute
a precomputed coefficient-sized set for the local objects.

`computations/flatten_dyck_objects.py` expands all 19,834 literal objects
in these eight universal recipes into the bounded trees of
`proofs/BOUNDED_FLAGGED_DYCK_TREES.md`. It reconstructs every original
object exactly, checks that the flattened trees are distinct, and checks
their charge, leaf, path, and normal-slot bounds. In the largest valued
case 6,024 actual objects contain a nonprimitive birth, and 84 contain a
parallel assembly vertex. These checks therefore exercise both kinds
of global behavior that cannot be justified by a primitive-tree
termwise phase quotient.

## 11. Global polyhedral objects

### 11.1 Sparse positions give dimension bounded by coefficient degree

The main polyhedral realization is now the sparse support-position
construction in `proofs/SPARSE_POSITION_POLYTOPES.md` and its explicit
set-valued assembly in `proofs/GLOBAL_SPARSE_POLYHEDRAL_RECIPE.md`.
Fix the positive edge weights and their support/endpoint weak order.
The digital-path membership, first shadow-balance equations, and
inequalities immediately before earlier positive jumps define a bounded
rational polytope. Every grading has unique minimal endpoints, so this
is an actual bijection on lattice points, without choosing witnesses.

The global flattened tree has at most `2N-2` positive edge slots and
`N-1` nonempty paths, where `N=1+|p|`. Four position/endpoint coordinates
per positive slot, together with one coordinate per occupied normal
copy, give the explicit coefficient formula

\[
 a_g^B(p)=\sum_\sigma\#(P_\sigma\cap\mathbb Z^{d_\sigma}),
 \qquad d_\sigma\le9|p|.
\]

The number of tagged pieces is bounded by a function of `N`, independent
of arrow magnitudes. Their binary descriptions have polynomial size at
fixed `N`. These are rational position polytopes; no integrality or
total-unimodularity assertion is transferred to them. Barvinok's
credited fixed-dimensional theorem supplies a polynomial-time counting
route for each fixed coefficient degree, while the actual implementation
currently uses an elementary finite lattice-point enumerator.

`computations/global_sparse_polytope_recipe.py` builds the global
polyhedral DAG directly from support patterns and matrices. It does
not enumerate gradings as part of the definition. The former valued
phase obstruction gives the full profile with coefficients `1,6,2,4`,
and the independent signed incoming formula agrees. A separate
nonprimitive local birth with carrier `(2,2)` and normal power `c=2`
passes an independent exact monomial-operator comparison. The exported
JSON contains all reachable polyhedra as sparse `A,b,E,d` data.

An individual piece also has a natural Young-species interpretation:
tensor its actual lattice-point permutation space with the Young module
of its original-color leaf blocks. The global sum gives the previously
constructed actual Young module, and singleton-leaf pieces contribute
exactly their lattice-point counts to its sign multiplicity.

### 11.2 The alternative weight-coordinate realization

Every fixed local path has finitely many nonnegative integer edge weights
with fixed total sums. Cut their bounded product of simplices by all
integer linear equalities used to decide the cyclic compatibility and
shadow tests. Each resulting relatively open rational cell has constant
truth values for all tests. Retain the admissible cells, including
separately their equality faces. Strict integer inequalities may be
shifted by one, so these are explicit bounded lattice-polyhedral pieces.

For a fixed event-flagged forest, take the Cartesian product of the local
pieces, the ordered normal-power copies, and the recursively chosen
decoration pieces. The forest histories are finite and disjointly tagged.
Their union therefore gives an explicit finite disjoint union of lattice
polyhedral pieces whose integer points count the theta coefficient.
The construction records compatibility and boundary data; taking a convex
hull alone would discard exactly that information. It is a direct
polyhedral realization of the general coefficient mechanism, rather
than an assertion that a Newton polytope determines its weights.

The sharper statement is proved in
`proofs/TIGHT_DYCK_ALCOVED_CELLS.md`. After fixing the comparisons and
dividing the permitted edge weights by their normal divisors, all tests
are interval-sum constraints. Integer floor/ceiling conversion replaces
each relatively open rational piece by a closed integral alcoved
polytope with exactly the same permitted integer points. Cumulative
coordinates make the constraint matrix a difference-constraint matrix,
so total unimodularity and the affine braid arrangement provide integral
vertices and a unimodular triangulation, also in the relative lattice
of lower-dimensional pieces. The resulting global model is the explicit
tree-tagged finite union of products of these pieces. No single convex
polytope, nor an integral unrounded rational closure, is asserted.

## 12. Multiplication has the same finite combinatorial and polyhedral interface

`proofs/TWO_FRAMING_THETA_MULTIPLICATION.md` extends the construction to
individual classical theta structure constants. For labels `g_1,g_2`,
degree `p`, output `h=g_1+g_2+Bp`, and the formal endpoint
`U=Dh+epsilon`, its actual object set is

\[
 \mathcal C_{g_1,g_2}(p)
   =\bigsqcup_{a+b=p} O(g_1,a;U)\times O(g_2,b;U).
\]

The arbitrary-endpoint one-frame lemma follows from the abelian framed
ideal and finite three-factor decomposition. The endpoint duality is
both credited to GHKK and checked directly by the event rule: at the
output exponent's own radial germ every prospective event time has
leading term `-1`, so a nontrivial correction object is empty. This
identifies the displayed pair set with the coefficient of the full
principal output label `(h,p)`.

The same set has a two-frame realization. With frame-frame pairing `L`
and the specified opposite frame covectors, the only positive root
events are the splits `a+b=p`. Each has exactly two incoming factors
and one fusion strip of length
`L-g_1^tDp+a^tDh`. A proved special radial-germ bijection identifies
its child catalogs with the fixed-endpoint catalogs, while preserving
literal Dyck data. Thus deleting that explicit strip gives the
multiplication objects, and increasing `L` gives a canonical injection
whose complement is one copy of them.

Their sparse polyhedral pieces still have dimension at most `9|p|`.
Their Young representation is the direct sum over splits of the induced
outer tensor products of the two endpoint Young modules; its sign
multiplicity is the structure constant. A reddening support certificate
makes the entire product finite, with candidate degrees bounded by the
sum of the two support boxes and the sharper tropical top-corner filter.

`computations/theta_multiplication_objects.py` supplies actual pair-set
recipes and materializes all objects for one cyclic valued verification.
The independent matrix and signed triangular comparisons agree. The
all-arity flat product formula and literal factor-permutation symmetry
also follow; a general coherent binary associator is not asserted.
