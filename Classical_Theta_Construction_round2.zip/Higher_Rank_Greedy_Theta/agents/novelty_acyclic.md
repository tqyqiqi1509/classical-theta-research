# 无环 theta 整数半空间链公式：查新与接口审查

日期：2026-11-13。分支：`novelty_acyclic`。这是当前六小时研究的第一波查新记录，不是任意秩问题完成报告。

## 1. 本次实际核对的上一轮公式

已亲读上一轮 `START_HERE.md`、`ACYCLIC_LOCAL_BINOMIAL_COROLLARY.md`、`HALFSPACE_CHAIN_FORMULA.md`、`FRAMED_HN_INTERFACE.md`。输入为拓扑排序后的无环斜对称化矩阵 B、整数正对角斜对称化矩阵 D、标签 g。先用

\[
d_i=\max\{0,-g_i+\sum_{j<i}[-B]_{ij}d_j\}
\]

给出有限盒，再以

\[
C_{p,q}=\prod_i\binom{-g_i-\sum_{j<i}B_{ij}p_j-\sum_{j>i}B_{ij}q_j}{p_i-q_i}
\]

及随 p 变化的半空间索引集 `I_p`，逆行提取 `a_p`。全部整数运算和有符号链均为明确有限的。其正性与 theta 识别尚依赖经典 theta 比较理论；本文不将前一轮自述“已证明”替代独立证明审核。

## 2. 对意义和新颖性的准确判断

**有实际意义的内容是：把所有无环类型、任意整数标签的 theta 系数，化为只输入 B、D、g 的显式有限整数计算。** 若主证明经本轮独立审核保持成立，它比只计算簇变量、有限型或仿射型更广，也不要求程序先构造完整散射图、求稳定模空间或预知 theta 系数。这个算法层面的改进具有明确内容。

以下四件事不能分别作为新结果宣传：

1. 无环 theta 基存在及其非负整数系数：来自既有经典 theta 理论。
2. 任意维数 theta 有组合表达：既有 broken-line/热带树公式已覆盖任意维数；“组合”这个词本身不形成差异。
3. 正负群分解或单位三角矩阵分解：是已知代数机制。
4. 半空间受限逆链：上一轮给出的 Mozgovoy–Reineke 非交换矩阵环字典成立，该反演恒等式应明确归入已有文献。

目前查到的最接近前例分别覆盖“有符号 HN 反演”“框架模空间的二项式乘积”“一般 theta 的热带树表达”“仿射全部 theta 的显式递推”，但没有找到将当前显式盒、该二项式矩阵、目标端点半空间逆行及 theta 系数抽取完整组合为同一 B-only 算法的公开前例。**这只支持“尚未找到同式前例”，不支持“已经证明原创优先权”。**

这项结果仍不能称为已经实现用户要求的高秩 Dyck-compatible-pairs 式正计数：每个对象权重可以为负，且识别证明仍使用 theta 理论。较稳妥的工作称谓是“无环 theta 系数的有限整数半空间链公式”。

## 3. 核心原始文献及使用范围

### 3.1 Mozgovoy–Reineke 2014：反演部分已有精确前例

Sergey Mozgovoy and Markus Reineke, *Moduli spaces of stable pairs and non-abelian zeta functions of curves via wall-crossing*, J. Éc. polytech. Math. 1 (2014), 117–146.

原文：https://www.numdam.org/article/JEP_2014__1__117_0.pdf

核读 Section 8.1–8.2，特别是 Theorem 8.3(2)。该节允许非交换系数环。取 `R=Mat_J(Z)`，按增量将 `C[p,q]E[p,q]` 编组，矩阵单位乘法只留下可拼接的链；取斜率 `mu(alpha)=-(g+Bp)^T D alpha/|alpha|` 后，其严格前缀斜率条件就是当前 `I_p` 的条件。符号和端点相关权重都匹配，不只是形式相似。

审查结论：**有用且可用；反演不得列为新定理；不能从任意环反演推出正性。**

### 3.2 Reineke 2004/2008：二项式权重的 Grassmann 塔接口

Markus Reineke, *Framed quiver moduli, cohomology, and quantum groups*, arXiv:math/0411101；J. Algebra 320 (2008).

原文：https://arxiv.org/pdf/math/0411101

核读 Theorems 4.10 and 5.2(4)：无环框架模空间是迭代 Grassmann 丛，Poincaré 多项式是 Gaussian 二项式乘积，Euler 数是普通二项式乘积。这里的框架维数是真实非负整数，不能换成任意有符号数仍宣称存在同样模空间。

审查结论：**有用；提供当前 C 的真实框架部分的表示论含义；一般虚框架部分尚未几何化。**

### 3.3 Reineke 2009：无环总变换与 HN 分解

Markus Reineke, *Poisson automorphisms and quiver moduli*, arXiv:0804.3214v2；J. Inst. Math. Jussieu 9 (2010), 653–667.

原文：https://arxiv.org/pdf/0804.3214

核读 Theorem 2.1、Definition 4.1、随后显式 HN 公式。无环情形的顶点自同构乘积分解为斜率因子，后者由框架模空间 Euler 数描述；已有的显式 HN 和式含有交错符号以及有限域计数分母。

审查结论：**有用；当前总变换不是全新对象；其 Euler/有理函数形式不等于当前整数半空间链的无消去正模型。**

### 3.4 Bridgeland：必须保留正标签限制与勘误

Tom Bridgeland, *Scattering diagrams, Hall algebras and stability conditions*, arXiv:1603.00416v4.

原文：https://arxiv.org/pdf/1603.00416

核读 Theorems 1.4–1.5 及 Section 11.7。Theorem 1.4 的框架模空间 theta 描述只取正锥标签；原文紧接着明确将一般标签描述列为后续问题。2020 勘误撤回 Lemma 11.4 的证明及一般 genteel 推论；无环等价 Theorem 1.5 则给出另一条有效证明。

审查结论：**有用但范围严格；不能用正标签框架公式声称已得到所有 theta；不得继续引用错误 Lemma 11.4。**

### 3.5 Qin：reddening 的接口是散射识别，不是全部系数公式

Fan Qin, *Bases for upper cluster algebras and tropical points*, arXiv:1902.09507v4；JEMS.

原文：https://arxiv.org/pdf/1902.09507

核读 Theorems 1.2.3–1.2.4、A.1.3–A.1.5、Appendix A.2。全秩、injective-reachable 是基定理的重要输入；weak genteelness 的表示论陈述限斜对称种子。A.2 在写出正标签框架公式后明确说明，其他 theta 的此类表示论公式当时未知。generic basis 与 theta basis 不能混为一谈。

审查结论：**有用；可支持已有负框架路线与稳定散射数据；不能把它当作消除当前有符号链的现成定理。**

### 3.6 Cheung：quiver Grassmannian 公式不覆盖所有标签

Man-Wai Cheung, *Theta functions and quiver Grassmannians*, arXiv:1906.12299v1.

原文：https://arxiv.org/pdf/1906.12299

核读 Theorem 1.2/7.1 的假设：初始点在 cluster complex。其 Hall-theta/Grassmannian 解释及按折点分层有用，但不能从标题推断它给出任意虚方向 theta 的普通 cluster-character 公式。

审查结论：**有用的簇单项式接口；作为全 theta 识别依据无效。**

### 3.7 Lee–Li–Mills：真正已有高秩 Dyck 构造，但不是目标基

Kyungyong Lee, Li Li, Matthew R. Mills, *A Combinatorial Formula for Certain Elements of Upper Cluster Algebras*, SIGMA 11 (2015), 049, arXiv:1409.8177v2.

原文：https://arxiv.org/pdf/1409.8177

核读 Introduction、Theorems 1.1–1.2、定义范围。globally compatible collections 给任意秩上代数元素，无环初始种子时这些元素构成基。它依赖所选种子；不能据此认定 theta 或高秩 greedy 的全部要求已实现。另一分支核实 Remark 5.6：即使秩二也不包含全部簇变量。

审查结论：**重要新颖性对照；禁止把“高秩无环正系数基”本身写为首次；不能替代 theta 识别。**

### 3.8 Mandel 2019/2021 与 Leung–Ma–Young 2021

Travis Mandel, *Scattering diagrams, theta functions, and refined tropical curve counts*, arXiv:1503.06183v5.

原文：https://arxiv.org/pdf/1503.06183

任意维数有按热带树/盘求和的 theta 表达，权重来自 Lie 括号。这是当前“只用有限整数对象”的比较基线。仅将散射树改名成组合树不产生新算法。

Naichung Conan Leung, Ziming Nikolas Ma, Matthew B. Young, *Refined scattering diagrams and theta functions from asymptotic analysis of Maurer–Cartan equations*, arXiv:1902.05765, IMRN 2021.

原文：https://arxiv.org/abs/1902.05765

已查到官方作者机构页面及原始稿 Theorem 4.29 的 acyclic/nondegenerate 情形。该方法以 Maurer–Cartan 展开和带标记热带树描述 theta，不是当前半空间整数矩阵公式。仅作为对照，不调用未经本分支全读的后续命题。

### 3.9 当前 Sage 实现

官方文档：https://doc.sagemath.org/html/en/reference/algebras/sage/algebras/cluster_algebra.html

`theta_basis_F_polynomial` 的算法说明是秩二 greedy–theta 等同及 LLZ 的递推；高秩示例抛 `NotImplementedError`。因此发现这个函数名不等于发现已有任意秩 theta 计算器。

审查结论：**有用的实现基线，不是数学原创性证明。**

## 4. 2026 文献的定点强审记录

### Reading–Stella, Theta functions in acyclic affine type

当前公开版本为 arXiv:2603.23429v1，2026-03-24，53页；截至本次查询 abs 页只有 v1。

原文：https://arxiv.org/html/2603.23429v1

实际阅读：Introduction；Theorems 3.1、3.3、3.4、3.5 的完整陈述；Sections 4.2–4.3 的关键限制；Sections 5.1–5.3 的证明结构；Section 5.6 的局部变异核对。不是逐页完整重证全篇。

可确认的比较点：论文处理全部无环仿射型，以虚墙、Chebyshev 递推和兼容锥分解确定 theta；这已经超出簇单项式。其范围不包含任意 wild 无环矩阵。当前 B-only 公式若正确，并没有被这篇仿射专门公式直接覆盖。

发现两处可局部改正的文字/符号错误，未据此宣称主定理错误：

- Theorem 3.3 后将初值 `T_0=2,T_1=x` 的规范称为“second kind”；应是规范化第一类 Chebyshev。递推公式本身与相乘关系相符。
- Lemma 5.8 证明中，当变异方向不是两个下标、且两步乘积为零时，写了 `b'=-b`；按变异公式应为 `b'=b`，与该 Lemma 的陈述一致。

使用结论：**用于查新比较；本轮主定理不依赖此稿。** 若下一轮要导入其管子代数结论，应对相应引理链另做逐项审核。

### Reading–Stella, Mutation of Theta Functions

截至本次查询最新为 arXiv:2603.19391v4（2026-11-08），SIGMA 22 (2026), 109。

原文：https://arxiv.org/html/2603.19391v4

核读 Introduction 与关于 small canonical algebra 的说明。任意交换矩阵上的该代数可通过形式幂级数定义；这不证明所有 theta 都是 Laurent 多项式，也不提供任意输入的有限终止算法。ray basis 的构造不能跳过 theta 射线元素的输入。

使用结论：**结构接口有用，不能作为当前一般有限性缺口已经解决的证据。**

## 5. 新增的精确表示论字典：真实框架与虚框架

下面是对用户给出的 C 的独立代数整理，不是引用新定理。令

\[
\alpha=p-q,\qquad n(q)=-(g+Bq),\qquad A=[-B]_+.
\]

直接展开得到

\[
C_{p,q}=\prod_i\binom{n_i(q)+\sum_{j<i}A_{ij}\alpha_j}{\alpha_i}.
\]

取箭图 `Q_A`，令 `A_ij` 条箭从 j 指向 i。若 `n(q)>=0`，从给定框架逐顶点生成一个 α 维商表示时，第 i 步是在维数 `n_i(q)+Σ_{j<i}A_ij α_j` 的空间上选 α_i 维商。因箭图无环，这给出迭代 Grassmann 丛；Euler 数恰为上式。等价地，可用 Reineke 的对偶共框架规范和反向箭图。

这不是当前 theta 系数的全局新几何公式：一般 q 会使 n(q) 含负分量，广义二项式此时是虚拟延拓。要把现有带符号链变为真实正对象，需要统一处理所有 n(q) 的变动，构造真实包含/商关系或符号相消映射，并验证该映射保持每个单项式权重。仅为每一项另选一个 Grassmann 空间、或只用半空间总和为负代替逐坐标框架非负，都不够。

这一字典把可尝试的下一步缩得更具体：找出 C 的虚框架增减如何在一个共同的有限有向对象空间上表现为插入/删除，然后与 endpoint halfspace 的 HN 重分段配合。若成功，剩余对象应同时提供非负整数系数和多面体支撑；若只证明 Grassmannian Euler 数等式，仍未满足纯组合正计数要求。

## 6. 路线状态与明确不采用的推论

| 路线 | 本分支结果 | 是否能直接推进主目标 |
|---|---|---|
| 现有 Grassmannian theta 公式直接覆盖全部 g | 范围不足：正标签或 cluster complex | 否 |
| generic basis 自动等于 theta | 错误混同；已有简单仿射区别 | 否 |
| HN 反演就是新的链公式 | 已有精确矩阵环特化 | 对识别有用，非新颖性核心 |
| C 的真实框架部分是 Grassmann 塔 Euler 数 | 上式逐项代数核对成立 | 是，给具体权重接口 |
| 负框架维数仍作为真实 Grassmann 塔 | 无定义依据 | 否 |
| 任意维数热带树可直接称 greedy 解释 | 仍需墙/权重数据，未给无消去模型 | 否 |
| Reading–Stella 2026 已解决所有无环 | 原文只解决仿射 | 否 |
| Sage theta 方法已可高秩运行 | 官方实现只含rank2 | 否 |
| 当前B-only有限算法的明确实用价值 | 有；尤其wild、真斜对称化、高秩计算 | 是；优先权仍谨慎 |

本分支未使用 Li–Pan 任何结论，未将 Qiyue Tang/Hexagon 的其他论文完成标签作为外部定理，未作量子推广。没有声称得到全部跨链正相消。
