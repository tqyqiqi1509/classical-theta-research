# A free cyclic phase model and an actual all-degree atom-splitting map

2026-11-13, branch `valued_coherence_phase_transport`.

This continues the explicit valued ABC diamond. It proves a general
one-active-input interface in every degree, rather than supplying more
isolated numerical examples. It does not claim full multi-input
coherence. All constructions below use the actual Dyck edges, their
coefficient decorations, and the existing ordered normal-copy slots.

## 0. Results, prior count, and exact scope

There are two new constructions in this note.

1. A tight grading with one positive horizontal edge is explicitly
   equivalent to a decorated cyclic slot word with a **free Bezout
   phase action**. This holds at arbitrary slope and with arbitrary
   vertical weights. Periodic words cause no stabilizer denominator.
   The inverse uses prefix heights and return intervals, not set ranking.
2. When the opposite input occurs once, adjoining a marked factor
   `1+epsilon*t^b` on the other ray has an actual all-degree splitting
   bijection. Its ingredients are a local phase carry and a cycle-lemma
   rotation. It keeps every old coefficient decoration intact. Both
   input normal weights and all intermediate contents are unrestricted.

The numerical singleton-profile formula is already Proposition 8.1 of
Burcroff--Lee--Mou--Musiker--Reineke, arXiv:2511.14672v1, Section 8.
Its general proof there uses wall crossing; that section supplies a
combinatorial bijection in the equal-total case. The count is not a
novelty claim here. Our contribution is the explicit all-slope phase
quotient, its actual-edge inverse, and its use in the splitting map.

The protected matching and single-root frame in Qiyue Tang,
<https://hexagonmath.org/pdf/2610.00645v1>, Sections 2--3, are another
prior interface. The companion `TWO_STACK_DYCK_FORESTS.md` gives a
self-contained proof including the minimal-rectangle boundary cases.
Only that matching argument is used below; no later algebraicity
claim from the 2026 manuscript is used.

## 1. The singleton boundary shape

Let P,Q be positive integers, ell=gcd(P,Q), A=P/ell, B=Q/ell.
Use the prescribed maximal lower Dyck path with W horizontal and H
vertical edges, where

    A H-B W=1,       W>=P,       H>=Q.

Thus P H-Q W=ell and gcd(W,H)=1. Give the unique positive horizontal
edge h_i weight Q. The vertical grades have total P. Write

    y_i=floor(H(i-1)/W),      R_i=H(i-1) mod W.

Index vertical edges cyclically by their vertical coordinates. Define
the Q consecutive slots

    v_(y_i+2), v_(y_i+3), ..., v_(y_i+Q+1).             (1.1)

The first vertical edge after h_i, namely v_(y_i+1), is deliberately
omitted. Put x_j equal to the grade in slot j, and X_k=sum_(j<=k)x_j.

**Theorem 1.1.** The actual grading is tight if and only if:

    R_i=W-ell+s,                    0<=s<ell;           (1.2)
    every vertical grade outside (1.1) is zero;
    x_j>=0,                         sum x_j=P;
    X_k<=floor(P k/Q),              1<=k<Q;             (1.3)
    s<ell-L(x),                                        (1.4)

where

    L(x)=max({0} union {t:1<=t<ell, X_(t B)=t A}).     (1.5)

All decorations on positive vertical edges are carried into their
respective slots without modification.

### Proof of the support and root position

By the self-contained single-tree theorem in
`TWO_STACK_DYCK_FORESTS.md`, Section 5, a tight grading in this frame
has exactly one nontrivial matching tree. It contains P horizontal and
Q+1 vertical vertices; its root is vertical, with rank W+s for
0<=s<ell. Every positive vertex lies in this tree.

The sole positive horizontal vertex has Q outgoing matching edges.
Its children are exactly the first Q vertical edges after it. The one
remaining vertical tree vertex is the root. The tree is the root's
maximal vertical shadow interval, so its root is the next, (Q+1)-st,
vertical edge after h_i. Within that interval h_i precedes the first
vertical vertex. If it were t horizontal steps after the interval's
first horizontal vertex, the rank difference from h_i to the root
would be ell-t H. It is positive, while ell<=H. Therefore t=0.
Consequently the root rank is R_i+ell. This proves (1.2) and identifies
the root as the last slot of (1.1). The first vertical child has zero
grade: a positive grade there would immediately consume h_i in the
backward matching, forming a two-cycle. All other positive vertical
vertices are among the Q slots in (1.1).

### Proof of the inequalities and their converse

For the first k slots, with k<Q, backward matching must not consume
h_i. The available horizontal services after h_i and before the last
of these slots number

    b_k(s)=floor((W k+ell-s-1)/H).                      (1.6)

Thus the no-overflow inequalities are X_k<=b_k(s). This can also be
read directly from the vertical-shadow first-return rule: the number
of horizontal edges from h_i through v_(y_i+k+1), minus the forbidden
edge h_i, is exactly (1.6).

Using P H-Q W=ell gives

    (W k+ell-s-1)/H
      = P k/Q +(ell-ell k/Q-s-1)/H.

If B does not divide k, the fractional part of P k/Q is at least 1/B
and at most 1-1/B. The correction has absolute value strictly less
than 1/B, because H>=ell B. Hence b_k(s)=floor(P k/Q).
If k=t B, then

    b_(tB)(s)=t A       when t<=ell-s-1,
             =t A-1   when t>=ell-s.                 (1.7)

Equations (1.3)--(1.4) are exactly these inequalities. They also force
x_Q>0. Conversely, with these inequalities the backward matchings
from the first Q vertical children never reach h_i. The last slot's
backward shadow reaches exactly h_i: the total vertical grade is P,
and the inequalities prevent an earlier first return. The horizontal
matching sends h_i to its first Q vertical children, avoiding that
root. The combined matching is therefore a tree on this interval,
with all other vertices isolated. Compatibility and tightness follow.
This proves the converse as well. QED.

The inverse edge position is completely explicit:

    i-1=H^(-1)(W-ell+s) mod W,                        (1.8)

with the evident i=1 convention when W=1. It then inserts the Q slot
grades at (1.1). No list of tight gradings is formed.

## 2. The free cyclic phase action

Let W(P,Q) be any set of Q-slot words with total grade P, where each
slot grade may carry an arbitrary coefficient decoration. Restrictions
such as divisibility of all grades by one fixed integer are allowed.
Choose integers lambda,mu satisfying

    lambda P+mu Q=ell.                                (2.1)

For any positive integer c, put L=c ell. The cyclic group C_Q acts on

    W(P,Q) x Z/L

by the following generator:

    (x_1,...,x_Q; phi)
      -> (x_2,...,x_Q,x_1;
          phi-c(lambda x_1+mu) mod L).                (2.2)

The entire decorated slot is rotated. Its decoration is not inspected.

**Lemma 2.1.** This action is well defined and free, including on
periodic decorated words.

After Q rotations the total phase shift is c(lambda P+mu Q)=L, so
the action is well defined. If a rotation by Q/s slots fixes the
decorated word, it has s identical blocks, each of grade P/s. Its
phase shift is

    c(lambda P/s+mu Q/s)=L/s.

For s>1 this is nonzero modulo L. Every possible nonidentity
stabilizer contains such a rotation, so none fixes the pair. QED.

### Actual-edge normal form

Take a tight grading and its already prescribed normal-copy slot
k in [0,c). Read x from (1.1), and set

    phi=c(ell-1-s)+k.                                 (2.3)

It is in the interval

    c L(x) <= phi < c ell.                            (2.4)

Conversely every orbit of (2.2) has **exactly one** representative
satisfying (1.3) and (2.4). To find it:

1. Rotate after a maximum of the prefix height Q X_k-P k. Transport
   the phase by (2.2). The word now satisfies (1.3).
2. Write phi=c phi_0+k. The zero-height returns occur at positions
   r B, where r is an integer in [0,ell). Let r be the first return
   value strictly greater than phi_0; use r=0 if none exists.
3. Rotate by r B slots and subtract c r from the phase modulo c ell.

Now phi_0 lies between the last zero return and ell-1. Recover
s=ell-1-phi_0 and the original tuple slot k, then apply (1.8).

For uniqueness, consider all zero-return cuts of a rational Dyck word.
At the cut r B, the phase change is c r by (2.1). If r_prev is the
previous return on the cyclic return circle, the allowed phases in
the original coordinates are exactly

    [c r_prev,c r).

These half-open intervals partition the phase circle. Repeated
decorated periods create no ambiguity, by Lemma 2.1. Thus (2.3)
induces an actual bijection

    {tight singleton gradings with c ordered copies}
           <-> (W(P,Q) x Z/(c ell))/C_Q.              (2.5)

All maps are natural in the coefficient-decoration sets. A relabeling
of decorations commutes with the prefix calculation, the cyclic
rotation, and the phase change.

## 3. Exact valued one-active-input interpretation

Let m=K(alpha,beta)>0, d=w(alpha), e=w(beta). Put

    Q=m/d,       v=m/e,       gamma_a=a alpha+beta.

The beta input occurs once, so its sole positive horizontal edge has
grade Q. On the alpha input take an arbitrary finite-set coefficient
series F(t)=1+sum_(j>0) F_j t^j. A slot of grade v j is decorated by
one object of F_j. For a>=1, define

    P=a v,       ell_a=gcd(a v,Q),
    c_a=Q w(gamma_a)/(ell_a e),
    L_a=c_a ell_a=Q w(gamma_a)/e.                      (3.1)

The local original-normal theorem proves c_a is a positive integer;
thus L_a is an integer as well. The carrier gamma_a is not divided by
its ambient content. The beta decoration itself is an untouched
external factor.

The full coefficient set at a alpha+beta is exactly (2.5), with these
parameters and with the beta decoration retained. In particular its
cardinality is

    w(gamma_a)/e * [t^a] F(t)^Q.                      (3.2)

The rational-looking factor in (3.2) has an integral object meaning:
it is the cardinality of the **free** quotient (2.5). Equation (3.2)
also follows from infinitesimal conjugation, but that algebraic
calculation is not used to define the quotient or its edge bijection.

For an undecorated partition profile, (3.2) gives precisely the known
singleton multinomial formula. Section 2 supplies its all-slope cyclic
construction, including arbitrary divisibilities and original-normal
copies.

## 4. A cycle-lemma unfolding with an explicit inverse

For a rational Dyck word x of length Q and total P, let l(x) be the
last zero-height return in **slot units**, including zero:

    l(x)=(Q/ell)L(x).

Then

    (x,r),  x rational Dyck,  l(x)<=r<Q
        -> RotateLeft(x,r)                            (4.1)

is a bijection to all decorated Q-slot words of total P.

To invert a word y, calculate its prefix heights Q Y_k-P k at indices
k=1,...,Q, including the final height zero. Choose the **first** index
k where the maximum occurs. Put

    x=RotateLeft(y,k),        r=(-k) mod Q.            (4.2)

The word x is rational Dyck and r lies after its last return. Indeed,
the maximal-height cuts are precisely its cyclic zero-return cuts.
Taking the first maximum at a positive index selects the unique one
whose previous maximum lies at or before the chosen origin. This is
equivalent to l(x)<=r<Q. This also works for periodic decorated words:
the final-return intervals partition the distinct rotations. No order
on the decorations is used.

## 5. Actual splitting by one marked same-ray atom

Fix b>0 and a marked atom epsilon at carrier b alpha, with epsilon^2=0.
Keep the beta input linear, and keep F arbitrary. We compare:

* first form the coefficient at gamma_a=a alpha+beta from F and beta,
  then combine it with the atom epsilon at b alpha;
* combine beta directly with the Cauchy product
  F(t)(1+epsilon t^b), and retain its epsilon-linear coefficient at
  Gamma=(a+b)alpha+beta.

Both sides are actual local-factory sets. In the product input, the
epsilon-bearing coefficient at degree j+b is decorated by the same
object of F_j together with epsilon; F_0 is the singleton empty object.

Put d_a=w(gamma_a), d_T=w(Gamma). In addition to (3.1), set

    ell_2=gcd(b m/d_a,Q),
    c_2=Q d_T/(ell_2 d_a),       L_2=c_2 ell_2=Q d_T/d_a,
    ell_T=gcd((a+b)v,Q),
    c_T=Q d_T/(ell_T e),         L_T=c_T ell_T=Q d_T/e.

All these c and L parameters are positive integers by the same local
normal calculation. They satisfy the exact identity

    L_a L_2=Q L_T.                                    (5.1)

The second source factory is a first binary coefficient. In its
singleton normal form its slot word is zero except for its final
slot. Consequently its actual edge and normal-copy data are exactly
one phase J in [0,L_2), through Section 2.
More explicitly, its actual strip residue s_2 and old tuple slot k_2
give J=c_2(ell_2-1-s_2)+k_2. Its word is
(0,...,0,b m/d_a), so it has no internal zero-height return and every
J in this interval occurs.

### Forward algorithm

Read the inner actual object as its normal decorated word x and phase
I. Write

    L_2 I+J=L_T r+K,       0<=K<L_T.                 (5.2)

Rotate x left by r slots. Place epsilon in the last slot, increasing
that slot's degree by b, while leaving its F-decoration unchanged.
Regard K as its phase in the target quotient of Section 2. Normalize
there and reconstruct the target's actual edges and tuple slot.

### Why the rotation is the correct one

For fixed x, its inner phases range over

    c_a L(x) <= I < L_a.

As J ranges over [0,L_2), the integer in (5.2) ranges over one interval.
Using (5.1), its lower endpoint is

    L_2 c_a L(x)=L_T (Q/ell_a)L(x)=L_T l(x),

and its upper endpoint is L_T Q. Therefore (5.2) is exactly a bijection

    {(I,J): I is allowed for x}
           <-> {[l(x),Q) x [0,L_T)}.                 (5.3)

By (4.1), the resulting rotated F-word is completely arbitrary. The
unique epsilon marks its final slot. On the target quotient, every
epsilon-bearing orbit has a unique representative with epsilon in
that slot, and its phase then ranges freely over [0,L_T). Hence
(5.2)--(5.3) prove surjectivity and injectivity on the actual objects.

### Full inverse

Read the target's cyclic word and phase. Rotate until epsilon is in
the last slot, transporting the phase with the target cocycle.
Remove epsilon from that slot; retain its old F-decoration, or the
empty object when its F-degree is zero. This gives an arbitrary
decorated F-word y and K in [0,L_T).

Apply (4.2) to recover x and r. Then divide

    L_T r+K=L_2 I+J,       0<=J<L_2.

The interval calculation (5.3) guarantees that I is a legitimate
inner normal phase. Reconstruct the inner actual grading from (x,I)
and the outer first-coefficient grading from its single-spike word
and phase J. This is inverse at every edge, tuple slot, and input
decoration.

The case a=0 is the inherited beta object. Its virtual zero slot word
has c_a=1, ell_a=Q, and sole normal phase I=Q-1. The same calculation
gives r=Q-1 and K=J; equivalently one may retain this inherited term
directly. There is no positive-degree inner grading to fabricate.

This proves an all-a, all-b, naturally decorated same-ray atom-split
equation. Taking a disjoint union over b also allows an arbitrary
positive infinitesimal multiplicative factor `1+epsilon H(t)`.

## 6. What this does and does not close

The splitting map is genuinely on multi-edge tight gradings: the F
side has arbitrary degree and arbitrarily many positive edges. All
of its coefficient objects survive intact as blocks. Since the map
uses only their degrees, it is natural under independent bijections
of every F_j, and equivariant under external relabelings that preserve
the distinguished new atom. It is compatible with truncation.

This is a concrete interface for original alphabet polarization.
For an actual alphabet, sum e_j(X)t^j equals product_(x in X)(1+x t),
so adjoining an actual alphabet letter is a legitimate multiplicative
factor. The map proves the corresponding split when the opposite
carrier occurs once. It does not replace an arbitrary positive series
by a product of positive linear factors.

A general marked leaf in a multi-edge grading does not automatically
put the local operation in this singleton situation. The marked
decoration can be on one edge while other edges use unmarked
coefficients of the same input carrier. Writing F=F_0+epsilon F_1
as F_0(1+epsilon F_1/F_0) may introduce signs. Therefore this note
does not infer full all-degree triple coherence, general alphabet
splitting, or marker-independent Young equivariance merely from a
unique ancestor spine.

The next concrete interface is to extend (5.3) to the several positive
horizontal vertices of the boundary matching tree. The two canonical
boundary orders and the unused service positions must be retained.
The singleton construction identifies exactly how one such boundary
root and its periodic phases are handled; it supplies an insertion
operation that a general mechanism must extend.

## 7. Exact implementation and research record

`computations/singleton_cyclic_phase.py` implements (1.8), (2.2), the
unique normal cut, and its actual-edge inverse. Completed checks:

* 129 parameter pairs P,Q;
* 463,815 slot words and 896,108 word-phase points;
* 629,492 cyclic-rotation invariance checks;
* 24,219 direct free-action checks, including periodic words;
* 102,376 reconstructed actual tight gradings;
* 2,291,418 independently enumerated literal grading candidates;
* 5,000 valued divisibility and nontrivial tuple-slot tests.

Every comparison passed. The code enumerates actual shadow conditions
for its independent checks; no wall coefficient supplies its target.

`computations/singleton_atom_splitting.py` implements Section 5 with
full decoration payloads. The first, b=1 calculation completed 54,040
actual valued maps and 23,248 exhaustive source/target maps; 28,190
outputs were additionally checked by the literal shadow predicate.
There were 4,419 unequal-input parameter choices and 4,925 choices
with a nonprimitive intermediate or final content. Every inverse and
decoration comparison passed. That first receipt is retained as
`singleton_atom_splitting_degree_one.json`; the general-b run is saved
separately in the script's standard `.json` result.

The general-b run also passed: 26,900 actual valued maps, with
11,920 literal shadow checks, 2,232 unequal-input parameter choices,
and 2,325 choices with a nonprimitive intermediate or final content.
The exhaustive source/target comparison again checked 23,248 maps.
Only sparse nonzero slot data are stored for the retained examples.
The independent reviewer subsequently checked the complete singleton
support/window proof, the strict return bound, and the free cocycle
action. The reviewer also independently verified the marked atom
carry proof: the complete phase interval (5.3), the first-maximum
cycle-lemma inverse including periodic words, and the unique
marker-last target representative. The constant inherited term is
handled explicitly, rather than omitted from the series equation.

Route record:

* 15:11--15:17: rejected the unsupported factorization of arbitrary
  positive input series; isolated the true singleton conjugation
  interface. Derived the residue support window and return bounds.
* 15:17--15:23: derived the Bezout cocycle, proved its freeness on
  periodic words, and implemented the actual normal cut. Read the
  primary Section 8 singleton formula and recorded its prior status.
* 15:23--15:29: derived the atom-split carry and the unique unfolding
  rotation, including arbitrary atom degree b. Kept the marked-leaf
  limitation explicit rather than claiming unsupported induction.
* 15:32: refreshed primary-source searches for a general tight-grading
  cyclic/splitting bijection. The retrieved 2026 Tamari abstract
  remains explicitly restricted to its central family; no general
  alphabet-splitting theorem was obtained from it. The primary
  BLMMR Section 8 remains the relevant prior singleton count.
* A real Wolfram call for an independent cyclic normal-form check
  returned an internal service error. The exact request and error
  receipt are retained in `singleton_phase_wolfram_attempt.json`;
  it is not counted as a successful verification. The earlier valued
  ABC Wolfram checks remain separate successful service calculations.
* A reduced independent Wolfram retry succeeded: 264 word-phase
  points, 946 cyclic rotation checks, and 121 cycle-lemma unfoldings,
  with zero error. Its exact request and result are retained in
  `singleton_phase_wolfram_success.json`.
* The virtual inherited a=0 term is also implemented and checked:
  1,151 actual valued atom births passed their complete inverse and
  literal tightness tests. The receipt is
  `singleton_atom_splitting_inherited.json`. The zero word is used
  only as the inherited combinatorial object, never as a fabricated
  positive-degree Dyck factory.

The proofs are the rank/shadow inequalities, the free cyclic action,
the disjoint return intervals, and the phase-carry interval identity.
The computations check those explicit maps; they are not the proof.
