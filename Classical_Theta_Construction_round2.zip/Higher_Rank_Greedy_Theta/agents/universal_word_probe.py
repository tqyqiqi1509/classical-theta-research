"""Formal word expansion of the universal incoming Schur recursion.

A letter (i,k) is the complete axis operator binom(-m_i,k) of degree k e_i.
Concatenation is chronological; its scalar weight uses the cumulative B-shift.
The integer coefficient of a word is independent of m.  This module never
uses theta positivity.  It exposes where cancellation by tree reassociation
can and cannot suffice.
"""
from functools import lru_cache
from itertools import product
from collections import Counter
from pathlib import Path
import json, sys, time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from incoming_recursion import IncomingSchur, ibinom, sub


class WordExpansion:
    def __init__(self, B, D=None):
        self.rec = IncomingSchur(B,D)
        self.n = len(B)
        self.zero = (0,)*self.n
        self.root=lru_cache(None)(self._root)
        self.cword=lru_cache(None)(self._cword)
        self.endpoint=lru_cache(None)(self._endpoint)

    def _root(self, word):
        a=[0]*self.n
        for i,k in word: a[i]+=k
        return tuple(a)

    def _cword(self, word):
        if not word: return 1
        if len(word)==1: return 1
        alpha=self.root(word)
        if sum(x!=0 for x in alpha)==1: return 0
        cuts=[j for j in range(1,len(word))
              if self.rec.sign(alpha,self.root(word[:j]))>0]
        v={}
        for j in cuts:
            v[j]=self.cword(word[:j])-sum(
                self.cword(word[h:j])*v[h] for h in v)
        return sum(self.cword(word[j:])*v[j] for j in cuts)

    def _endpoint(self, g, word):
        """Word coefficient after expanding both endpoint and C recursions.

        The endpoint inverse is first computed on the ordered prefix positions.
        Every C word occupies one consecutive interval.  Its free word label
        ignores any accidental scalar identities among the axis operators.
        """
        if not word: return 1
        p=self.root(word)
        mp=self.rec.shift(g,p)
        positions=[j for j in range(len(word)) if
            sum(mp[i]*self.rec.D[i]*(p[i]-self.root(word[:j])[i])
                for i in range(self.n))<0]
        t={len(word):1}
        for j in reversed(positions):
            t[j]=-sum(t[k]*self.cword(word[j:k]) for k in t)
        return -sum(t[j]*self.endpoint(g,word[:j]) for j in positions)

    def weight(self,g,word):
        q=self.zero
        value=1
        for i,k in word:
            m=self.rec.shift(g,q)
            value*=ibinom(-m[i],k)
            a=list(q); a[i]+=k; q=tuple(a)
        return value

    def words(self,alpha):
        if not any(alpha):
            yield ()
            return
        for i in range(self.n):
            for k in range(1,alpha[i]+1):
                a=list(alpha); a[i]-=k
                for tail in self.words(tuple(a)):
                    yield ((i,k),)+tail


def run():
    start=time.time()
    reports=[]
    data=[([[0,1],[-1,0]],None,(3,3)),
          ([[0,3],[-2,0]],[2,3],(3,3)),
          ([[0,1,-1],[-1,0,1],[1,-1,0]],None,(2,2,2)),
          ([[0,2,-2],[-2,0,2],[2,-2,0]],None,(2,2,2)),
          ([[0,1,1],[-1,0,1],[-1,-1,0]],None,(2,2,2)),
          ([[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],(2,2,2))]
    for B,D,cap in data:
        W=WordExpansion(B,D)
        hist=Counter(); ehist=Counter(); extremes=[]; endpointneg=[]
        checks=0; nonzero_words=0
        for alpha in product(*(range(k+1) for k in cap)):
            if not any(alpha): continue
            words=list(W.words(alpha))
            for word in words:
                c=W.cword(word); hist[c]+=1
                if c: nonzero_words+=1
                if abs(c)>1 and len(extremes)<8:
                    extremes.append({'word':word,'coefficient':c})
            gs=[tuple(-1 for _ in B),tuple((-2 if i==0 else 1) for i in range(len(B))),
                tuple((-1 if i==0 else 0) for i in range(len(B)))]
            for g in gs:
                csum=sum(W.cword(w)*W.weight(g,w) for w in words)
                assert csum==W.rec.c(alpha,g),(B,alpha,g,'C',csum,W.rec.c(alpha,g))
                tsum=sum(W.endpoint(g,w)*W.weight(g,w) for w in words)
                truth=W.rec.theta_prefix(g,alpha).get(alpha,0)
                assert tsum==truth,(B,alpha,g,'theta',tsum,truth)
                checks+=2
                for w in words:
                    e=W.endpoint(g,w); ehist[e]+=1
                    val=e*W.weight(g,w)
                    if val<0 and len(endpointneg)<12:
                        endpointneg.append({'g':g,'root':alpha,'word':w,
                            'word_coefficient':e,'leaf_weight':W.weight(g,w),'term':val})
        reports.append({'B':B,'D':D,'cap':cap,'C_word_hist':dict(hist),
            'endpoint_word_hist':dict(ehist),'C_large_examples':extremes,
            'negative_endpoint_terms':endpointneg,'numeric_checks':checks,
            'nonzero_C_words':nonzero_words})
    out={'seconds':time.time()-start,'cases':reports}
    target=Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__': run()
