# Tang II: audited interface and many-slope combinatorial extension

Status: proof and focused computations completed, 2026-11-13, ready for independent review. This file is a research contribution to the current run, not a claim that the entire target problem is already solved.

Primary source: Qiyue Tang, *Another proof of quantum Laurent positivity, II*, Hexagon 2611.00279v1, posted 2026-11-11, manuscript dated 2026-11-10, 50 pp. Record: <https://hexagonmath.org/2611.00279v1>; PDF: <https://hexagonmath.org/pdf/2611.00279v1>; TeX: <https://hexagonmath.org/api/v1/works/2611.00279v1/source?path=another_proof_quantum_positivity_combinatorial.tex>.

## 1. The new general mechanism

Tang's Section 6 treats a complete bipartite source--sink quiver. Its positive-flow-core and balanced-partition arguments extend to **every finite collection of charges in a pointed nondegenerate two-dimensional cone**. The reason is a two-dimensional balancing identity, not the bipartite shape. This gives a purely combinatorial replacement for the local semistable/primitive identification used in the present arbitrary-rank skew-symmetric theta construction.

### 1.1 Data and conventions

Let \(K\) be an oriented two-dimensional rational vector space with nonzero integral alternating form \(\eta\). Fix nonzero lattice charges \(\beta_v\in K\), \(v\in V\), all lying in a common pointed cone. Put

\[
 S=\sum_{v\in V}\beta_v,\qquad
 a_{uv}=\max\{\eta(\beta_u,\beta_v),0\}.
\]

Use \(a_{uv}\) arrows from \(u\) to \(v\), and define \(\partial(e_{u\to v})=e_u-e_v\). The quiver \(Q_V\) is acyclic: order the charge rays in the pointed cone; every arrow points in the same angular direction. If the charges span \(K\), its underlying undirected graph is connected. Let

\[
 \Theta_v=-\eta(S,\beta_v)=\sum_w\eta(\beta_v,\beta_w),\qquad
 P_V=\{f\in\mathbb R_{\ge0}^{E_V}:\partial f=\Theta\}.
\]

The all-one arrow flow satisfies \(\partial\mathbf1=\Theta\). Thus \(P_V\) has a strictly positive point. A nonnegative recession vector would be a nonzero circulation on an acyclic quiver, which is impossible. Consequently \(P_V\) is a bounded polytope of dimension

\[
 D_V=|E_V|-|V|+1
\]

whenever the induced graph is connected. All constructions are equivariant under permutations preserving the charges, allowing any incidence-compatible arrow permutation.

For a subset \(C\subseteq V\), write \(\beta_C=\sum_{v\in C}\beta_v\). Call \(C\) **balanced relative to \(S\)** when \(\Theta(C)=0\). Nondegeneracy in dimension two and pointedness give

\[
 \Theta(C)=0\iff\beta_C=c_CS\quad\text{for a unique }c_C>0.
 \tag{1}
\]

In particular, restriction of the global supply to a balanced block equals \(c_C^{-1}\) times the block's own anti-attractor supply. Positive supports and normal fans therefore agree after a positive dilation.

### 1.2 The support-core theorem

An arrow support \(H\subseteq E_V\) is semistable precisely when every successor-closed vertex subset \(U\) satisfies \(\Theta(U)\le0\). By the elementary network-flow feasibility criterion, this is equivalent to existence of a nonnegative \(\Theta\)-flow supported in \(H\).

**Theorem 1 (general positive-flow core).** Every semistable \(H\) has a unique maximal positive-flow support \(K\subseteq H\). Its connected components are balanced. Every arrow of \(H\) internal to one component belongs to \(K\); the remaining arrows descend to an acyclic support between the components. Conversely, a union of positive-flow supports on balanced blocks, together with any acyclic support between those blocks, is semistable and has precisely that union as maximal core.

**Proof.** Take the union of all feasible flow supports in \(H\). There are finitely many arrows, so averaging finitely many witnessing flows gives one flow positive on exactly this union \(K\). Summing divergence over a component gives \(\Theta(C)=0\). If an unused arrow of \(H\) has endpoints in the same component, add a small positive flow on it and cancel the divergence along an undirected path in \(K\). All path coordinates are positive; a sufficiently small perturbation stays nonnegative. This contradicts maximality. If the quotient cross support contains a directed cycle, put a small positive amount on every arrow of the cycle, correcting the resulting divergence inside each component along paths in \(K\); maximality is again contradicted. Conversely, every feasible flow on the enlarged support has, after summing over each balanced block, a nonnegative circulation on the acyclic quotient. Such a circulation is zero. Therefore every feasible flow is supported on the original core. \(\square\)

### 1.3 Why every singular cone is still a graph cone

For distinct balanced blocks \(C,D\), let (A(C,D)) be the number of ambient arrows from \(C\) to \(D\). Then

\[
 A(C,D)-A(D,C)
 =\sum_{u\in C,v\in D}\eta(\beta_u,\beta_v)
 =\eta(\beta_C,\beta_D)=0.
 \tag{2}
\]

Thus contraction of a balanced partition produces a symmetric directed configuration, with (m_{CD}=A(C,D)=A(D,C)) arrows in each direction. No matching between the opposite arrow sets is assumed.

Let \(K\) be a positive-flow support and \(\pi(K)\) its connected-component partition. The normal cone at the face with positive support \(K\) is generated by the coordinate classes outside \(K\) in

\[
 \mathbb Q^{E_V}/\operatorname{im}\partial^T.
\]

The relations among these generators are the image of vertex potentials constant on every component of \(K\). Such potentials vanish on unused internal arrows. Hence the normal cone decomposes, equivariantly, into a smooth orthant on unused internal arrows times the symmetric graph cone for the multigraph \(G_{\pi(K)}\) with multiplicities \(m_{CD}\). Its quotient normal representation is dual to

\[
 M_K=\ker(\partial:\mathbb Q^K\longrightarrow\mathbb Q^V).
 \tag{3}
\]

This proves the cone identification directly from incidence matrices. The absence of a preferred matching of opposite arrows is exactly why Tang's independent-arrow extension in Lemma 5.6 is needed.

## 2. The general balanced-partition character identity

For a connected undirected multigraph \(G\), define its finite cut algebra

\[
 A_G=\operatorname{Sym}(\mathbb Q^{V(G)}/\mathbb Q\mathbf1)
 \Big/\left(\prod_{e\in\delta(U)}(x_{h(e)}-x_{t(e)}):
 \varnothing\ne U\subsetneq V(G)\right).
\]

Let \(Z_G(g;q)=\operatorname{Tr}(g\mid A_G;q)\), with \(Z_G=0\) for disconnected \(G\) and \(Z_G=1\) for a single vertex. The action uses only the vertex permutation. Denote by (R_C(g;q)) the actual graded reduced global minimal-extension module of the normal fan of the intrinsic polytope \(P_C\), provided the charges in \(C\) span \(K\). For a singleton set put \(R_C=1\). For a larger set whose charges are all parallel, put **\(R_C=0\)**.

The last convention is essential. Such a parallel block has an edgeless disconnected quiver and no connected primitive. Its flow polytope is a point, but its point cohomology is not the primitive that enters the formula below.

For a balanced partition \(\rho\), set

\[
 R_{\rm cr}(\rho)=\sum_{\{C,D\}\subset\rho}m_{CD},
\]

half the number of cross arrows. Choose an order of the blocks and orient each undirected contracted edge in that order. Let \(\varepsilon_\rho(g)\) be the product of orientation-reversal signs under \(g\). This is independent of the chosen order and of permutations of parallel arrows.

**Theorem 2 (many-slope balanced partition).** For every charge-preserving vertex permutation \(g\), with any incidence-compatible arrow action,

\[
 \sum_{\substack{gH=H\\H\ {\rm semistable}}}
 \frac{\det(q-g\mid\mathbb Q^H)}{\det(q-g\mid\mathbb Q^V)}
 =
 \sum_{\substack{g\rho=\rho\\\rho\ {\rm balanced}}}
 \varepsilon_\rho(g)q^{R_{\rm cr}(\rho)}
 \prod_{C\in\rho/g}
 \frac{R_C(g^{\ell_C};q^{\ell_C})}{q^{\ell_C}-1}.
 \tag{4}
\]

Here \(C\) is one representative of a block orbit and \(\ell_C\) its length.

**Proof.** Theorem 1 splits each support uniquely into its core and an acyclic quotient support. The equivariant exact sequence

\[
 0\to M_K\to\mathbb Q^K\xrightarrow\partial\mathbb Q^V
 \to\mathbb Q^{\pi(K)}\to0
\]

replaces the core's arrow/vertex determinant quotient by
\(\det(q-g\mid M_K)/\det(q-g\mid\mathbb Q^{\pi(K)})\).
Equation (2) makes the quotient a symmetric graph configuration. Tang's audited acyclic-support partition identity (5.6), valid for independent opposite-arrow permutations by Lemma 5.6, expands its acyclic-support sum into partitions of components. Regroup these partitions as balanced partitions \(\rho\) of the original vertices. Cross-arrow multiplicities and orientation signs depend only on \(\rho\), by additivity of arrow counts. For a block orbit of length \(\ell\), cyclic block elimination gives

\[
 \det(q-g\mid\bigoplus_{j=0}^{\ell-1}g^jM)
 =\det(q^\ell-g^\ell\mid M).
\]

The remaining sum inside each connected block is

\[
 R_C(h;q)=\sum_{\substack{hK=K\\K\text{ positive-flow}}}
 \det(q-h\mid M_K) Z_{G_{\pi(K)}}(h;q).
 \tag{5}
\]

Indeed, this is the complete-fan cellular character formula, using the normal-cone decomposition above and the independently audited graph-cone character theorem (Tang, Theorem 5.7). For a parallel block with at least two vertices the same right side vanishes because every contracted graph is disconnected. For a singleton it equals one. This proves (4), including the parallel-block boundary case. \(\square\)

## 3. Primitive character and the parity that survives many slopes

Temporarily retain finitely many charge types \(\alpha_1,\ldots,\alpha_s\), with independent alphabets \(U_1,\ldots,U_s\). Permutations act only within identical types. For a labeled type multiplicity vector \(\mathbf n\), put

\[
 F_{\mathbf n}(g;t)=\operatorname{sgn}(g)\,t^{|V|-|E_V|}
 \sum_{\substack{gH=H\\H\text{ semistable}}}
 \frac{\det(t^2-g\mid\mathbb Q^H)}{\det(t^2-g\mid\mathbb Q^V)},
\]

and, for connected blocks or singletons,

\[
 P_{\mathbf n}(\mathbf U;t)
 =t^{-D_V}\operatorname{Frob}\bigl(\operatorname{sgn}\otimes R_V;t^2\bigr).
 \tag{6}
\]

Set \(P_{\mathbf n}=0\) on disconnected non-singleton parallel configurations. For a fixed physical charge ray, collect all multiplicity vectors whose total charge belongs to that ray, retaining their independent multidegrees. Use the signed Adams convention

\[
 \psi_\ell(t)=(-1)^{\ell-1}t^\ell,
 \qquad\psi_\ell(p_j(U_a))=p_{\ell j}(U_a).
\]

Define

\[
 A_{\rm ray}=1+\sum_{\substack{\mathbf n\ne0\\\sum n_a\alpha_a\in{\rm ray}}}
 \operatorname{Frob}(F_{\mathbf n}(\cdot;t))X^{\sum n_a\alpha_a}.
\]

Then this ray series satisfies

\[
 A_{\rm ray}=\operatorname{Exp}_\psi
 \left(\frac{\sum_{\mathbf n\ {\rm on\ ray}}P_{\mathbf n}X^{\sum n_a\alpha_a}}
 {t-t^{-1}}\right).
 \tag{7}
\]

**Proof of the new parity point.** In a cycle of blocks, every block has the same multiset of charge types. If \(C,D\) are two distinct copies of that multiset, the number of arrows in either cross direction is

\[
 A(C,D)=\sum_{u,v\in C}\max\{\eta(\beta_u,\beta_v),0\}=|E_C|.
 \tag{8}
\]

The orientation character of a block cycle of length \(\ell\) is therefore \( (-1)^{(\ell-1)|E_C|}\). The sign of its permutation on vertices is \( (-1)^{(\ell-1)|C|}\operatorname{sgn}(g^\ell|_C)\). Also

\[
 |E_V|=\sum_{C\in\rho/g}\ell_C|E_C|+2R_{\rm cr}(\rho).
\]

Multiplying (4) by the normalization cancels all cross powers, leaving exactly the signed Adams transform of the individual block weight. The usual labeled block-cycle count contributes \(1/\ell\), independently in each type alphabet, and unordered sets of block cycles exponentiate. This proves (7). No assumption of two initial rays was used. Each primitive in (6) is an actual finite graded character, so its Schur coefficients are nonnegative integers. The only nontrivial parity is arrow parity after the standard vertex-sign conversion. This matches the parity \(E_v\bmod2\) in the present species construction.

## 4. Ordered support filtration also closes under arbitrary slopes

Choose a linear form \(\kappa\) positive on the pointed cone. Give a nonempty subset \(C\) slope

\[
 \mu(C)=\Theta(C)/\kappa(\beta_C).
\]

The maximal-slope successor-closed subset exists uniquely after taking the union of all maximizers. Iterating on the complement yields a unique successor-closed filtration with strictly decreasing block slopes and semistable induced blocks. The proof uses only additivity of numerator and denominator, so it is unchanged for arbitrary numbers of charge types.

More significantly, the centered stability of every block is itself an anti-attractor stability:

\[
 \Theta_v-\mu(C)\kappa(\beta_v)
 =-\frac{\kappa(S)}{\kappa(\beta_C)}\eta(\beta_C,\beta_v).
 \tag{9}
\]

This follows from the two-dimensional identity

\[
 \eta(S,x)\kappa(c)-\eta(S,c)\kappa(x)
 =\kappa(S)\eta(c,x).
\]

Thus the support filtration stays inside the same family of local flow polytopes. **The ordering and normalization must be stated explicitly.** In decreasing filtration order, an earlier block \(C\) is successor-closed relative to every later block \(D\). Arrows from \(C\) to \(D\) are absent; arrows from \(D\) to \(C\) are unrestricted. In the support normalization \(F\) of Section 3, the cross factor is consequently

\[
 q^{A(D,C)}t^{-A(C,D)-A(D,C)}
 =t^{-\eta(\beta_C,\beta_D)}. \tag{10}
\]

Tang's source reverses the list of blocks before writing the positive exponent; see its support-factorization proof, immediately before its cross-phase equation. The first version of this bridge omitted that reversal. This is a real normalization omission, corrected here after independent review; the one-arrow residual and repair are recorded in `many_slope_independent_review.md`.

To use the decreasing-order convention in `species_completion_bridge.md`, define instead

\[
 S_V(g;t)=\operatorname{sgn}(g)F_V(g;t^{-1}). \tag{11}
\]

This is coefficientwise parameter inversion followed by the sign involution on every original alphabet. It changes (10) into \(t^{+\eta(\beta_C,\beta_D)}\). Summing over all supports gives exactly

\[
 A_V(g;t)=\frac{t^{|V|-|E_V|}}
 {\prod_{c\in\operatorname{cyc}(g)}(1-t^{2|c|})}.
\]

Hence the decreasing-order support filtration gives equation (2.3) of the species note, with precisely its sign and weight normalization.

### 4.1 The block-cycle conversion, without commuting involutions

One must not assert that the sign involution commutes with the signed Adams operations. Instead transform (4) term by term. If a balanced block orbit has length \(\ell\), representative \(C\), return map \(h=g^\ell|_C\), \(m_C=|C|\), \(E_C\) arrows, and \(d_C=E_C-m_C+1\), its orientation character is \((-1)^{(\ell-1)E_C}\). After (11), the external and original vertex-sign characters cancel. Cross powers cancel because \(E_V=\sum_C\ell E_C+2R_{\rm cr}\). Equivariant duality on the complete local fan gives

\[
 R_C(h;t^{-2\ell})=t^{-2\ell d_C}R_C(h;t^{2\ell}).
\]

Thus this block orbit contributes exactly

\[
 (-1)^{(\ell-1)E_C}
 \frac{t^{\ell(m_C-E_C)}R_C(h;t^{2\ell})}
      {1-t^{2\ell}}
 =(-1)^{(\ell-1)E_C}H(t^\ell)
   \Omega_C(h;t^\ell), \tag{12}
\]

where \(H(t)=t/(1-t^2)\) and
\(\Omega_C(h;t)=t^{-d_C}R_C(h;t^2)\).
For a singleton \(d_C=0\), while a non-singleton parallel block has \(\Omega_C=0\). Equation (12) is precisely (2.4)--(2.5) of the species note. No extra sign is attached to permutations inside a single local fan module.

Restoring the homogeneous parity \(\epsilon^{E_C}\) gives the super Fock interpretation: a block \(\ell\)-cycle contributes \((-1)^{(\ell-1)E_C}\). The HN Cauchy product restores \(\epsilon^{\eta}\), since total cross-arrow count and alternating pairing agree modulo two. All identities hold for every finite input-type set and every type-preserving permutation, so they are identities of symmetric-sequence classes and admit the substitutions used in Section 3 of the species note.

Therefore the many-slope factorization is proved by finite supports, determinants, graph-cut algebras, fan duality, and labeled partitions. It does not require Hall multiplication, a moduli-stack PBW theorem, or a geometric identification of BPS spaces.

## 5. Audit ledger

- Sections 4.1--4.3: flow feasibility, cographic shelling/regular sequence, contraction cone decomposition checked directly from incidence matrices.
- Section 5.3: graph partition identities checked via invariant support decomposition and the graphical-arrangement deletion/contraction identity.
- Section 5.5: independent opposite-arrow action checked. For one ordered-pair orbit of length \(\ell\) with \(r\) arrows, the sum over nonempty invariant arrow subsets is \(q^{\ell r}-1\), regardless of return permutation. This is the exact needed interface.
- Section 6: the source contains the two-slope version of (4)--(7). The new contribution here is the many-slope extension, its parallel-block boundary case, and the intrinsic anti-attractor closure (9).
- Existing present-run direct partition grammar and the final global theta identification are separate from the source's cluster-monomial positivity statement. Local graph fans, their character positivity, and Schur-positive reordering must be credited to the source and cannot be claimed new here.

The full 50-page body and bibliography were read through the primary PDF, and the decisive independent-arrow argument was also checked against the primary TeX. The audit below concerns mathematical use, not an assertion of peer review.

### 5.1 The graph-cone dependency is usable

The graph-cone theorem needed in (5) has the following checked proof chain.

1. For a connected multigraph with \(R\) edges and \(s\) vertices, generic supplies on its doubled orientation give a simple unbounded flow polyhedron. The active-coordinate normal fan subdivides the graph cone. Feasibility is equivalent to all directed-cut inequalities, by writing a Farkas separating potential as a nonnegative combination of upper-level-set indicators. Reduction of its Stanley--Reisner ring by global forms produces the full cut ideal displayed above.
2. The cographic complex has facets \(E\setminus T\), where \(T\) ranges over spanning trees. Projection of the cycle space to every facet is invertible. Lexicographic basis exchange gives a shelling; its successive ring kernels are free over the parameter ring. Consequently the parameters are a regular sequence and the quotient's degree is at most \(R-s+1\).
3. The fan decomposition theorem embeds the reduced local minimal extension into this quotient. Since (2(R-s+1)<2R-s+1\) for (s>1), its degree is strictly below half the cone dimension. The contraction description proves the same bound for every face and smooth orthant product.
4. This degree bound makes normalized sheaf maps unique: a difference with zero boundary restriction would map generators of degree below half dimension into a relative costalk whose free generators have complementary degrees above half dimension. It must vanish. Thus normalized finite group actions obey the group law without an arbitrary equivariant identification.
5. The cellular complex, reduced by the global Koszul complex, contributes \(\det(q-g\mid W/W_\tau)\) at a fixed cone. The orientation sign is indispensable: it combines with the alternating cellular sign and the determinant \(\det(1-qg^{-1})\) to give this expression.
6. Equivariant duality is legitimate. A fixed interior line is obtained by averaging an interior vector; the free cover lift can be averaged while preserving its restriction equation. The complementary generating space can be corrected into the restriction kernel by equivariant lifts. This is precisely the class of choices in the older algebraic intersection-product construction, and its pairing is perfect for those choices. The top relative generator is invariant, so evaluation is equivariant.
7. Invariant cographic monomials yield the graph character by a regular Koszul quotient. Decomposing invariant directed supports into strongly connected cores and acyclic quotients yields its contraction recursion. The independent-arrow reduction sums each nonempty ordered-pair support orbit to \(q^{\ell r}-1\); hence no opposite-arrow matching is needed.
8. The local fan character and the cut character satisfy the same contraction reciprocity. After induction on proper contracted cones, their difference \(f\) satisfies \(q^df(q^{-1})=f(q)\). Both characters have degree (<d/2\), forcing \(f=0\).

The older source behind steps 3, 4, 5, and 6 was checked directly: Barthel--Brasselet--Fieseler--Kaup, *Combinatorial Intersection Cohomology for Fans*, arXiv:math/0002181v1, especially §5.1 and Theorem 5.3. Primary PDF: <https://arxiv.org/pdf/math/0002181>. Its free lift, kernel-complement correction, and perfect-pairing construction match the operations used here. Thus this interface does not depend on an unaudited claim of canonical PBW splittings.

### 5.2 Remaining sections and exact scope

| Source portion | Review result | Use in the current extension |
|---|---|---|
| §§1--2,11 | Quantum skew-symmetric cluster-monomial scope and seed normalizations are internally consistent | Scope comparison only; no skew-symmetrizable theorem inferred |
| §§3--5 | Key fan and graph interface passed the algebraic checks in §5.1 | Used |
| §6 | Two-slope primitive proof passed; block-orbit return maps and signed Adams factors are retained | Generalized by §§1--4 above |
| §§7--8 | Atom types, exponent bounds, finite inversion ordering and admissible-list bounds checked | Supports parity and completion comparison |
| §9 | Incoming trace prescription and degree-decreasing recursion checked | Compatible with the present incoming grammar; not itself that grammar |
| §10 | Finite mutation-fiber argument, common rational ring and coefficient comparison read and checked | No new dependency for local theorem |
| Other 2026 works listed in the bibliography | Not imported as theorems in this branch | Their appearances are not independent validation |

For §§7--8, two details survive scrutiny. First, lexicographic inversion counts indexed by total charge decrease even when a swap creates new atoms, because every new mixed pair has strictly larger charge than the pair just swapped. Second, the input history bounds the number of leaves and the sum of pairings, so a fixed lower output energy involves finitely many input occurrences. Neither claim assumes a finite mutation type.

For §9, the no-feedback induction is in total root degree: a current-degree contribution can travel linearly only on its own ray; an interaction necessarily uses smaller degrees. The coefficient extracted at an incoming direction is insensitive to walls orthogonal to that exponent, because all potential predecessors pair to zero with that wall. These are directly verifiable finite-completion statements. They do not provide a finite Laurent expansion for arbitrary theta labels; the source obtains finite Laurent support at its last stage from the cluster-monomial Laurent phenomenon.

### 5.3 What the graph theorem does not supply

The equality of reduced graph-cone characters with the cut algebra is not an explicit isomorphism of polynomial sheaves with restriction maps. This matters for the valued extension. Diagonal substitution \(x_i=x_C\) defines a reduced cut-algebra map for connected contracted blocks, but it misses polynomial restriction data.

For example, the graph with two vertices and two parallel edges has a three-dimensional graph cone and local reduced character (1+q\). Every nontrivial contraction has only the degree-zero reduced factor. The degree-one local generator must nevertheless have nonzero polynomial restrictions on proper faces. Sending it to zero on every face would put a minimal free generator in the boundary kernel, contradicting the minimal-extension axiom. Therefore one cannot obtain a valued fan sheaf merely by replacing every reduced cut algebra and using vertex diagonals. Full polynomial stalks and their restriction lifts are required.

## 6. Focused computations

Reproducible code: `computations/many_slope_balanced_partition.py`; exact output: `computations/many_slope_balanced_partition.json`; separate computation-plugin receipt: `computations/many_slope_wolfram_receipt.json`.

The left side of (4) was computed by enumerating invariant endpoint supports and checking every successor-closed subset. Parallel-arrow choices were summed exactly. The right side was computed from independent equivariant normal-fan minimal-extension recursion, then a separate set-partition enumeration. No theta coefficient or local primitive value was supplied as input.

Fifteen complete permutation characters over six discriminating configurations were checked, totaling 696 endpoint-support states. Every symbolic residual was zero. The tests cover four distinct charge slopes, nonprimitive charges, balanced parallel subblocks, a block cycle with a negative cross-orientation sign, and independent permutations of opposite arrows.

| Charges and action | Independently computed local (R(g;q)\) |
|---|---|
| ((1,0),(0,1),(1,1)\), identity | (1+q\) |
| ((1,0),(0,1),(1,1),(1,1)\), identity or middle swap | \(1+q+q^2\) |
| ((1,0),(0,1),(1,1),(1,1),(1,1)\), every middle permutation | \(1+q+q^2+q^3\) |
| ((1,0),(0,1),(1,1),(2,1)\), identity | \(1+3q+5q^2+3q^3+q^4\) |
| ((1,0),(0,1),(2,2)\), identity | \(1+2q+2q^2+q^3\) |
| two ((1,0)\), two ((0,1)\), one ((1,1)\), identity | \(1+4q+5q^2+4q^3+q^4\) |
| same configuration, one endpoint pair swapped | \(1+2q+3q^2+2q^3+q^4\) |
| same configuration, both endpoint pairs swapped | \(1+q^2+q^4\) |

The deliberately incorrect convention \(R_C=1\) for a parallel two-vertex block produces the exact nonzero residual

\[
 -\frac{q^2}{(q-1)^2}.
\]

Thus the parallel-block repair is detected by computation, rather than merely added to definitions. The independent opposite-arrow test uses two forward and two reverse arrows, swaps the forward pair, and fixes the reverse pair. This action cannot preserve a matching of opposite arrows. Its graph-contraction residual is zero, as predicted by §5.5.

Wolfram Language independently returned zero for the general symbolic two-dimensional closure identity (9), the three-slope balanced identity, and the independent-arrow contraction identity. It also returned the same nonzero wrong-parallel-block residual. The computation plugin's context search found no relevant mathematical source; no information from that search was used.

## 7. Novelty comparison and handoff

This comparison is deliberately limited to the source just read and the present working files. It is not a claim of priority against all literature.

**Already in Tang II:** graph-cone cut algebra, the independent opposite-arrow character theorem, two-slope complete transportation fan primitives, full block-cycle/Adams bookkeeping, Schur-positive factorization, and positivity propagated by incoming coefficients. Discovering those ideas again during the current run adds no novelty and must be described as overlap with the user's earlier work.

**Added by this note:** a direct many-slope local primitive theorem for a single arbitrary pointed rank-two charge configuration; the identity \(\beta_C\parallel S\) that makes every balanced contraction symmetric; the necessary zero primitive on disconnected parallel blocks; and the centered-slope closure (9). The resulting proof replaces local Hall/PBW geometry with support enumeration and graph/fan linear algebra. Iterated two-atom positivity was already available in Tang II; the addition is the direct character identification for the many-slope local fan, including all permutation return maps.

**Separate additions in the current root work:** the intrinsic global set-partition grammar based only on \(B,D,g,p\), the one-frame translation for arbitrary formal theta coefficients, the actual global super-species assembly, and the positive unlabelled-tree/tableau recursion. The local Schur--Weyl step uses classical representation theory and overlaps in purpose with the source's Schur-positive atom expansion. The global tree-orbit recursion itself is a concrete application to the present grammar, not a new Schur--Weyl theorem.

**What the reviewer should check next:** equations (4), (7), and (9), especially the zero primitive for a disconnected parallel block and the orientation character (8). Then substitute this local theorem into the already audited incoming/species induction. This note does not reprove that global induction and does not assert the general valued theorem.

**Valued interface sent to both active agents:** every normal cone of a local event containing the frame retains a weight-one framed block after balanced contraction, so the rooted ramified cut-algebra construction has an appropriate local target. Unframed lower events still require a relative/central object or a whole framed gluing construction. Tang's reduced character theorem alone does not provide those restriction maps. The separate gain-fan branch has reported a character obstruction to a naive free-phase gluing of full nongeneric IH; that result is maintained in its own report, not silently bypassed here.

Primary source retrieval pointers for the root reviewer: Tang PDF `turn252view1`; independent-arrow TeX proof `turn263view0`; graph strict bound and canonical action `turn271view2`; equivariant duality `turn272view0`; balanced partition and primitive normalization `turn262view3`, `turn264view0`; original BBFK construction `turn277view0`, Theorem 5.3 `turn275view1`. The root should open any pointer it intends to cite in its final user response.
