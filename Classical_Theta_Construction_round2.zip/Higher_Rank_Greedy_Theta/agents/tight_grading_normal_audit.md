# Independent audit: tight gradings in the original valued normal lattice

Stage: 2026-11-13, 14:18 UTC. This note independently checks the normal
conversion implemented in `computations/tight_grading_two_input.py` and
identifies its literal Dyck decorations with the full valued Gale
coefficient tables. It supplies a purely combinatorial local factory for
`valued_charge_word_grammar.md`.

## 1. Primary source and exact input used

Amanda Burcroff, Kyungyong Lee, Lang Mou, *Positivity of generalized
cluster scattering diagrams*, arXiv2503.03719v1, March5,2025, 86 pages.
Primary record <https://arxiv.org/abs/2503.03719>; primary PDF
<https://arxiv.org/pdf/2503.03719v1>.

Theorem1.2 gives the coefficient of a standard primitive ray (p,q) as
tight gradings of a maximal Dyck path in a rectangle (d1,d2) with
`p d2-q d1=+/-1`, `d1>=k p`, `d2>=k q`. The total vertical grading is
k p and the total horizontal grading is k q. Definitions3.12,3.14 and
5.1--5.4 specify cyclic subpaths, compatibility, shadows and tightness.
These definitions and the theorem statement were read on the primary
PDF. The alternative proof in Section5.5 derives the shadowed formula
from compatible-gradings/greedy recurrences; the older local statement,
not the paper's general all-rank positivity conclusion, is the input here.

The source's Theorem9.5 already makes a nonstandard-lattice commutator
conversion. Lattice enlargement and rank-two positivity are therefore
prior work. The purpose of the calculation below is to verify the exact
original weighted normal for the new event grammar and code.

## 2. Independent normal calculation

Let alpha,beta be positive nonparallel charges and

\[
 m=K(\alpha,\beta)>0,\quad d=d(\alpha),\quad e=d(\beta),
 \quad\gamma=a\alpha+b\beta,\quad\gcd(a,b)=1.
\]

Put `u=m/d`, `v=m/e`. The old actions on `x=X^alpha,y=X^beta` are
`y -> y F(x)^u` and `x -> x G(y)^(-v)`.
In the enlarged lattice with basis

\[
 e_1=\alpha/v,\qquad e_2=\beta/u,\tag{2.1}
\]

they are the ordinary determinant-one input actions with polynomials
`F(x^v)` and `G(y^u)` in the new basis variables. Indeed the alpha normal
evaluates to1 on e2 and the beta normal evaluates to-1 on e1.

Define

\[
 l=\gcd(av,bu),\qquad(p,q)=(av/l,bu/l),
 \qquad g=\gcd(ad,be).
\]

A useful exact simplification is

\[
 l=\frac{m g}{de},\qquad
 c=\frac{m\,d(\gamma)}{l d e}
   =\frac{d(\gamma)}{g}\in\mathbb Z_{>0}.\tag{2.2}
\]

To check the first identity, write d=h d0,e=h e0 with coprime d0,e0,
and m=t h d0 e0. Then v=t d0,u=t e0 and both sides equal
`t gcd(a d0,b e0)`. The second follows because g divides every
weighted coordinate of gamma. Thus positivity and integrality of c are
proved in the original lattice; no divisibility is inferred merely from
a rational Poisson map.

Write `n(alpha)=D alpha/d`, and similarly for beta,gamma. The primitive
standard output normal is

\[
 p n(\alpha)+q n(\beta)
 =\frac{m}{l d e}D\gamma=c\,n(\gamma).\tag{2.3}
\]

Consequently the correctly normalized original wall function is

\[
 \boxed{F_\gamma=(f_{(p,q)})^c,}\tag{2.4}
\]

with monomials reindexed from the enlarged lattice back to gamma.
The direction of this power is checked by equality of the actions:
`f^(c n(gamma)(w))=(f^c)^(n(gamma)(w))`.

## 3. Sparse support: why the reindexing is integral

The enlarged input polynomials have nonzero coefficients only at
multiples of v on the first side and multiples of u on the second.
A tight grading contributing to enlarged degree k(p,q) must therefore
satisfy

\[
 v\mid kp,\qquad u\mid kq.
\]

Since p=av/l and q=bu/l, these conditions imply
`l|ka` and `l|kb`. Coprimality of a,b implies `l|k`. Conversely k=l j
clearly works. Equivalently

\[
 \operatorname{lcm}\left(\frac{v}{\gcd(v,p)},
                         \frac{u}{\gcd(u,q)}\right)=l.\tag{3.1}
\]

Thus f_(p,q) contains only powers `X^(j gamma)`. This proof uses the
actual grading weights and does not require an assumption about a
folded theta function or about an action on singular IH.

## 4. Literal local decorations

For j>=1 choose the deterministic smallest d1>=j l p for which
`p d2-q d1=1` gives an integral d2. This automatically has d2>=j l q.
Take the maximal lower Dyck path in that rectangle. Its edges carry
nonnegative integer gradings with

- vertical values multiples of v, of total `j l p=j a v`;
- horizontal values multiples of u, of total `j l q=j b u`;
- the compatibility and shadow inclusion of the source definitions.

A positive vertical edge of grading v r receives an object from the
coefficient set A_r of F; a positive horizontal edge of grading u s
receives an object from B_s of G. Zero edges have one empty decoration.
Denote this finite decorated-grading set by T_j, and let T_0 be a
singleton.

The coefficient set for degree n on gamma is exactly

\[
 \coprod_{j_1+\cdots+j_c=n}
       T_{j_1}\times\cdots\times T_{j_c}.\tag{4.1}
\]

The c slots are distinguished. The expression is a positive Cartesian
power, not a quotient by permutations of the slots. Its objects contain
both input types whenever n>0. The sums of their coefficient degrees
are n a and n b, so the strict ancestry proof of the charge-word grammar
applies unchanged.

## 5. Code audit

The code's dyck_word inserts each north step as soon as the lower
rational diagonal permits it, hence gives the maximal lower path.
The Bezout rectangle obeys the exact +1 condition. Its shadow scan runs
forward from a horizontal edge and backward from a vertical edge, with
the full cyclic wrap convention and the all-opposite-edges default.
Zero-graded edges have empty shadows, as explicitly stipulated in
Definition5.1.

For a pair of positive-graded edges u horizontal and v vertical,
compatibility fails precisely when v belongs to sh(u) and u belongs to
sh(v). Indeed the first equality of the horizontal prefix count can
occur only at a vertical step; the vertical suffix argument is dual.
Equality first attained at the forbidden other endpoint does not give an
allowed witness, and membership in the closed shadow records exactly
that case. Checking only positive-graded endpoints is legitimate because
a zero endpoint itself supplies a compatibility witness.

The code's shadow inclusion is Definition5.3. The extra determinant and
bound requirements of tightness are automatic from the chosen rectangle
and total sums. Its profile keys record vertical weights divided by v
on the first side, horizontal weights divided by u on the second. These
are exactly the indices of A_r and B_s. The c-fold convolution in
valued_profiles is therefore (4.1).

No discrepancy was found in this normal, orientation or grading audit.
The code's earlier 1000 direct compatibility comparisons are an
independent implementation check; the argument above proves the criterion
for arbitrary finite paths and gradings.

## 6. Full representation-theoretic comparison

The valued Gale theorem gives

\[
 \omega\,\operatorname{ch}D_{(a,b;n)}
   =[X^{n\gamma}]F_\gamma.
\]

The tight formula (4.1) gives the same polynomial in the independent
input elementary coefficients. Uniqueness of the elementary basis
therefore identifies every profile coefficient, not only a specialization
of its total dimension.

If `P_(lambda,mu)` is the set of c-tuples of tight gradings whose first
and second positive-edge profiles are lambda and mu, let `K` be the
coefficient field of the chosen Gale realization and `Omega` an
algebraically closed extension. Then

\[
 D_{(a,b;n)}\otimes_K\Omega\ \cong
 \Omega\otimes_{\mathbb Q}\left(
 \bigoplus_{\lambda,\mu}
 \mathbb Q[P_{(\lambda,\mu)}]\otimes
 \operatorname{Ind}_{S_\lambda\times S_\mu}^{S_{na}\times S_{nb}}
                    \mathbf1\right)
\tag{6.1}
\]

as ungraded representations after extension of scalars. The literal
rational-coefficient whole attached system can take `K=Q`; a cyclotomic
or generic-parameter realization need not. Restriction of scalars is not
being used. The Dyck Young module is defined over `Q` and supplies an
abstract rational form, without asserting canonical descent of the
chosen Gale algebra. This is an isomorphism of representations, not a
claimed canonical bijection between raw algebraic roots and Dyck paths.
The actual finite phase quotient is retained on
one side, while the other side is an entirely finite path-and-coloring
model. Their full Young multiplicities agree.

## 7. Independent arithmetic computation

`computations/valued_polyhedral_mechanism/tight_normal_audit.py` checks
50,000 independently generated ambient skew-symmetrizable inputs,
including nonprimitive birth charges and nontrivial powers c. It verifies
all three normal divisibilities, the simplified power formula, equality
of the entire normal vectors, and the exact minimal sparse exponent
(3.1). The output receipt gives counts and sample nontrivial powers.
The proof of these identities remains the integer argument in Sections2--3.
