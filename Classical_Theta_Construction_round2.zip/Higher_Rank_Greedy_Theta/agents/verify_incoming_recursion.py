from incoming_recursion import IncomingRecursion,box,sub,le
from itertools import product,permutations
from functools import lru_cache
import json,sys,time,random
from pathlib import Path

BASE=Path('/workspace/scratch/6791391cdece/higher_rank_greedy_theta')
OLD=BASE/'source_materials/previous_greedy'
sys.path.insert(0,str(OLD/'main_program'))
from integer_polynomials import monomial_image

start=time.time();checks=[];rng=random.Random(131126)

# Markov matrices have a positive radical, no negative-product certificate,
# and a separately computed covering construction available for comparison.
fold=json.loads((OLD/'work/agent_cyclic_generic_bridge/folded_markov_negative_polynomials.json').read_text())
R=IncomingRecursion(fold['B'],fold['D'])
for i,H in enumerate(fold['H']):
    g=tuple(-int(i==j) for j in range(3))
    F=R.theta_prefix(g,(3,3,3));expected={tuple(t['p']):int(t['a']) for t in H}
    assert F==expected,('Markov theta',i,F,expected)
checks.append({'kind':'Markov_theta_generators','labels':3,'cap':[3,3,3],
               'exact_equal_to_separate_folded_polynomials':True,
               'zero_parallel_residuals':R.zero_residual_checks})

# All transport entries, not just selected theta outputs, compared to the
# separate folded negative generators on a fixed downward-closed box.
H=[{tuple(t['p']):int(t['a']) for t in f} for f in fold['H']]
count=0
for m in [(1,-2,0),(-1,-1,-1),(2,0,-1)]:
    for a in box((2,2,2)):
        expected=monomial_image(H,tuple(-v for v in m),a).get(a,0)
        assert R.c(a,m)==expected,('Markov total',m,a,R.c(a,m),expected)
        count+=1
checks.append({'kind':'Markov_transport_entries','entries':count,'equal':True})

# Choice independence and multiplicativity for genuinely cyclic input with
# no use of any frame, including nontrivial symmetrizers and disconnected
# radical directions.
cases=[([[0,3,-3],[-3,0,3],[3,-3,0]],[1,1,1]),
       ([[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1]),
       ([[0,2,0],[-2,0,0],[0,0,0]],[1,1,7]),
       ([[0,0,0],[0,0,0],[0,0,0]],[2,3,5])]
for B,D in cases:
    R1=IncomingRecursion(B,D);R2=IncomingRecursion(B,D,tie_order=[2,1,0]);count=0
    for _ in range(3):
        m=tuple(rng.randrange(-2,3) for _ in D)
        n=tuple(rng.randrange(-2,3) for _ in D)
        for a in box((2,2,2)):
            lhs=R1.c(a,tuple(x+y for x,y in zip(m,n)))
            rhs=sum(R1.c(b,m)*R1.c(sub(a,b),n) for b in box(a))
            assert lhs==rhs,('multiplicativity',B,D,m,n,a,lhs,rhs)
            assert R1.c(a,m)==R2.c(a,m),('tie independence',B,D,m,a)
            count+=1
    q=(2,0,1)
    BP=[[B[q[i]][q[j]] for j in range(3)] for i in range(3)];DP=[D[q[i]] for i in range(3)]
    RP=IncomingRecursion(BP,DP)
    m=(-2,1,0)
    for a in box((2,2,2)):
        assert R1.c(a,m)==RP.c(tuple(a[i] for i in q),tuple(m[i] for i in q))
    check={'kind':'unconditional_cyclic_and_degenerate','B':B,'D':D,
           'multiplicativity_and_tie_checks':count,'permutation_checks':27,
           'parallel_zero_residuals':R1.zero_residual_checks+R2.zero_residual_checks+RP.zero_residual_checks}
    checks.append(check)

# Prefix beyond the first diagonal on the 3-arrow cyclic input. This does
# not claim global finiteness; it records exactly the coefficients obtained.
B=[[0,3,-3],[-3,0,3],[3,-3,0]];R=IncomingRecursion(B)
F=R.theta_prefix((-1,0,0),(3,3,3))
assert all(v>0 for v in F.values())
checks.append({'kind':'cyclic3_theta_prefix','B':B,'g':[-1,0,0],
               'cap':[3,3,3],'terms':[{'p':p,'a':v} for p,v in F.items()],
               'nonnegative':True,'finite_polynomial_claimed':False})

out={'status':'PASS','checks':checks,'seconds':time.time()-start}
(BASE/'agents/incoming_recursion_extended_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'status':out['status'],'groups':len(checks),'seconds':out['seconds']}))
