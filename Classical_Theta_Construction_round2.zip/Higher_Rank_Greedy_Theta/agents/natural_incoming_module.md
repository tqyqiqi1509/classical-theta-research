# Natural incoming modules and the local fan construction

Branch `/root/natural_incoming_module`; 2026-11-13, 11:04–11:40 UTC.
Only classical cluster algebras are targets. No Li Fang/Pan conclusion is used.

## Main result of this branch

There is now a **natural, finite, purely combinatorial local representation**
for every nonzero simultaneous event of the color-generic flow construction.
It is constructed from the normal fan of an explicit bounded flow polytope.
All required incidence data come from the child charges and their skew
pairings. No theta coefficient, wall multiplicity, or prescribed character
is supplied to the construction.

The representation has a canonical action of the child permutation group,
including at singular and non-coprime events. An exact character algorithm
for arbitrary acyclic child quivers and arbitrary preserving permutations is
implemented. In the previously difficult six-leaf case, the natural modules
of all four contracted skeletons independently assemble to the full correct
character `(88,40,36,12)` and sign multiplicity `6`.

**The remaining general theorem is not proved here:** the character of the
entire induced super tensor sum over collapsed skeletons must equal the weighted
cycle character of theta. This is an equivariant Hall/HN/plethystic
compatibility assertion. It is owned by the parent branch. Local IH traces
cannot simply be replaced by weighted-cycle binary counts separately at
nonprimitive events; doing that was the source of an incorrect intermediate
expectation, corrected below.

The earlier incoming-ideal approach is preserved in §7. Its most useful
output is an explicit incoming primitive block, rather than a correct
global quotient.

## 1. Exact local hypotheses, with proofs

The simultaneous-packet branch proves the following input statement. The
children of a nonzero event have nonzero positive charges
`beta_1,...,beta_s` in a rational two-plane `K`. The positive cone intersected
with `K` is pointed, the restriction of `eta` to `K` is nondegenerate, and
the stability immediately before the event is a positive multiple of

`theta_a = -eta(S,beta_a)`, where `S=sum_a beta_a`.

Our construction uses the child quiver

`a -> b` with `-eta(beta_a,beta_b)` arrows when that integer is positive.

Its incidence matrix `partial` has `-1` at an arrow source and `+1` at its
target. The chosen conventions are important; reversing both the arrows and
stability gives the isomorphic alternative convention.

### 1.1 Acyclicity and connectedness

Order the rays of `K` inside the pointed positive cone by slope. The sign of
the nondegenerate alternating form is constant for every ordered pair of
distinct rays. All arrows therefore point in the same slope direction.
The quiver is acyclic.

Any two nonparallel child charges have a nonzero pairing. Thus the underlying
graph is complete between the distinct slope classes. There are at least two
classes in a nonzero event, so the graph is connected. Repeated or parallel
children do not obstruct either assertion.

### 1.2 Strictly positive flow is automatic

Assign flow `1` to every parallel arrow. At child `a`, its divergence is

`sum_b eta(beta_a,beta_b) = eta(beta_a,S) = -eta(S,beta_a) = theta_a`.

Consequently `partial * 1 = theta`. This supplies the strict positive flow
required by the finite Gale and toric constructions; it is not an extra
genericity assumption.

### 1.3 Stable thin representations exist

Take a one-dimensional vector space at every child and a nonzero scalar on
every arrow. A proper subrepresentation is exactly a nonempty proper
successor-closed vertex subset `U`. It has no arrow leaving it, so

`theta(U) = incoming flow(U) > 0`.

The inequality is strict by connectedness and positivity of every arrow
flow. In the convention requiring positive stability on proper
subrepresentations, this representation is stable. Thus the stable locus is
nonempty. The opposite King convention merely negates theta.

### 1.4 The Euler form is symmetric on the zero-stability lattice

Let `beta: Q^s -> K` send the child basis vectors to their charges. If
`theta(u)=theta(v)=0`, both `beta(u)` and `beta(v)` lie on the line `Q*S`,
because the kernel of `eta(S,-)` on the two-plane is that line. Hence

`eta(beta(u),beta(v))=0`.

The antisymmetric part of the child-quiver Euler form is this pairing, up to
the already fixed global sign. Therefore the Euler form is symmetric on
`ker(theta)`. In addition, the child dimension vector `(1,...,1)` is
indivisible. These are precisely the concrete hypotheses that the parent is
checking against Reineke's small-desingularization theorem; no generic
potential or cyclic-quiver theorem is needed locally.

### 1.5 Events involving the frame are star events

There is only one child whose frame coordinate is nonzero. The intersection
of `K` with the hyperplane of zero frame coordinate is a line. Every other
child lies on its positive ray, so all their mutual pairings vanish. The
local quiver is a star around the unique framed child. Its polytope is a
product of simplices, and its module is a tensor product of slot modules.

The genuinely new modules are therefore the unframed simultaneous events.
Their total charge may be nonprimitive in the original color lattice even
though the thin child dimension vector is indivisible.

## 2. The polytope is completely explicit

Set

`P_theta = {f in R^E : f_e >= 0 and partial f = theta}`.

It contains the strictly positive vector `1`. It is bounded: an unbounded
recession direction would be a nonzero nonnegative circulation on an
acyclic graph, which is impossible. Since the graph is connected, its
relative dimension is `|E|-s+1`.

The incidence matrix is totally unimodular. In particular the vertices are
integral. A vertex has support contained in a spanning tree of the underlying
graph; a support forest may be extended to a spanning tree, so degenerate
vertices are included by the same enumeration. Parallel arrows can be handled
afterward: at a vertex, at most one arrow in any parallel class is positive.

The implementation first enumerates spanning trees of the simple underlying
graph, computes each tree flow by deleting leaves, rejects negative flows,
and then chooses a parallel-arrow label on each positive edge. Repeated
degenerate vertices are deduplicated. This avoids choosing `s-1` arrows out
of the potentially much larger multigraph arrow set.

Every permutation of the children preserving their pairings lifts by keeping
the parallel-arrow label fixed. It preserves `partial`, `theta`, the
polytope, and its normal fan. In the skeleton construction this includes all
permutations of identical-charge children that actually occur.

## 3. A canonical module defined by finite fan algebra

Let `Sigma` be the normal fan in

`N_Q = Q^E / image(partial^T)`.

For a cone `sigma`, write `A_sigma=Sym(span(sigma)^*)`, with linear functions
in degree two. A minimal extension sheaf is constructed on the cone poset as
follows. At the zero cone take `E_0=Q`. Once all proper faces of a cone have
been processed, compute the compatible boundary sections `E(boundary sigma)`.
Reduce these sections modulo the positive-degree ideal of `A_sigma`, and
take the free `A_sigma`-module on the resulting finite graded generator
space. A graded lift defines the restriction to the boundary. Repeat over
all cones. Finally take

`H(P_theta)= E(Sigma) / A_N^(>0) E(Sigma)`.

This is a finite graded vector space obtained from polynomial modules and
linear maps on a finite rational cone poset. It is a combinatorial definition;
intersection cohomology identifies and explains this module but is not
extra input to its construction.

### Canonical permutation action, not arbitrary chamber transport

There is a stronger uniqueness statement than merely invariance of the
isomorphism class. For rational fans, the reduced cone module vanishes in
cohomological degrees at least the dimension of the cone. Under this
vanishing condition, a morphism between minimal extension sheaves is
uniquely determined by its map at the zero cone.

For a fan automorphism `g`, the pullback `g^*E` is another minimal extension
sheaf. There is therefore a unique isomorphism `g^*E -> E` inducing identity
on `E_0=Q`. Compositions satisfy the group law by uniqueness. This produces
a canonical action on `H(P_theta)`, without choosing a chamber basis or
selecting transport maps between small resolutions.

The precise primary reference is Barthel–Brasselet–Fieseler–Kaup,
*Combinatorial Intersection Cohomology for Fans*, Proposition 1.3,
Theorem 1.6, and Remark 1.8(iii):
https://arxiv.org/pdf/math/0002181 . The existence and uniqueness proofs and
the rational-fan vanishing argument were read directly. The theorem is used
only in its rational scope here. The group-law consequence is the elementary
application just given.

## 4. Exact equivariant character recursion and its justification

Degrees below use `t` for cohomological degree two. Fix a finite-order fan
automorphism `g`. For a `g`-stable cone `sigma`, put `V_sigma=span(sigma)` and
let `G_sigma(g,t)` denote the trace on its reduced local module. Then

`G_0(g,t)=1`,

and for a nonzero cone of dimension `k`,

`G_sigma(g,t) = - trunc_(degree < k/2)`

`   sum_(tau proper face of sigma, g tau=tau)`

`       det(t I - g | V_sigma/V_tau) * G_tau(g,t)`.

The global character is

`H_Sigma(g,t) = sum_(sigma in Sigma, g sigma=sigma)`

`       det(t I - g | N_Q/V_sigma) * G_sigma(g,t)`.

This works for nonsimplicial cones and for permutations of arbitrary order.
It uses only face incidence, rational spans, determinants, multiplication,
and truncation.

### Why the recursion is the natural IH character

Here is a direct derivation in the rational case, avoiding any unproved
extension of a 2026 statement. For a full-dimensional pointed rational cone
`sigma`, the affine toric variety contracts to its closed orbit. Its ordinary
intersection cohomology is its local module `G_sigma`. Poincare duality gives
compactly supported trace `t^k G_sigma(g,t^(-1))`. The dual action has the
same trace: finite-order rational representations have real characters, so
`Tr(g^(-1))=Tr(g)`.

Decompose this affine variety into torus orbits. Only `g`-fixed orbits
contribute to the trace. The orbit corresponding to `tau` has compactly
supported equivariant E-polynomial

`det(t I-g | V_sigma/V_tau)`.

The local intersection complex is constant on the orbit, with fiber carrying
`G_tau`. Equivariant additivity therefore gives

`t^k G_sigma(g,t^(-1))`

` = sum_(tau <= sigma, g tau=tau)`

`       det(t I-g | V_sigma/V_tau) G_tau(g,t)`.

The local vanishing condition says `degree G_sigma < k/2`. Thus the left
side has no terms below degree `k/2`, and the displayed truncation recursion
follows. For a complete fan, the same orbit decomposition gives the global
formula. Its IH is even and pure, so its equivariant E-polynomial is exactly
the graded trace. Complex algebraic automorphisms preserve the relevant
orientation; there is no additional arbitrary determinant or sign twist.

The ordinary rational toric stalk comparison and purity are also described
in Proudfoot, *The algebraic geometry of Kazhdan–Lusztig–Stanley polynomials*,
§4.4, Corollary 4.20, whose toric argument was checked directly:
https://ems.press/content/serial-article-files/37003 . The finite-group
character version above follows from the same equivariant additivity and
duality, rather than being asserted as a theorem of that paper.

### Matrix realization used in the code

Represent a face by the set `I` of arrow coordinates zero everywhere on it.
All such sets are intersections of vertex zero sets. Write

`L=image(partial^T)`, `W_I=L+span(e_i : i in I)`.

The corresponding normal cone spans `W_I/L`. A fixed face is characterized
by `g(I)=I`. Quotient determinants are computed as exact quotients of
characteristic polynomials on invariant subspaces:

`det(tI-g | W_I/W_J)=char(W_I)/char(W_J)`.

The implementation asserts exact polynomial division and solves for each
restricted matrix over the rationals. It never guesses eigenvalues from
floating point approximations. For the identity permutation it uses the
equivalent power of `t-1` to reduce cost.

## 5. The hard case, checked as a full representation

Take

```
B = [[0,2,-3],[-2,0,2],[3,-2,0]],
g = (-3,3,-2), p=(2,2,1).
```

Label the frame `0`, the first-color leaves `1,2`, the second-color leaves
`3,4`, and the last leaf `5`. The group is `S_2 x S_2`.

The four contracted skeletons and their natural trace contributions are:

| Skeleton or orbit | Identity | First swap | Second swap | Both swaps |
|---|---:|---:|---:|---:|
| `((0,5),(1,4),(2,3))` together with `((0,5),(1,3),(2,4))` | 16 | 0 | 0 | 8 |
| `((0,5),(1,2,3,4))` | 64 | 32 | 32 | 0 |
| `(0,(1,2,(3,4,5)))` | 8 | 8 | 4 | 4 |
| **Total** | **88** | **40** | **36** | **12** |

The matching orbit has two eight-dimensional tensor modules. Each individual
swap exchanges the two skeletons. Their product fixes each skeleton and
swaps two equal two-dimensional factors, leaving trace four per skeleton.
The final row is a product of ordinary star slot modules. Thus the only new
factor is the four-child event in the middle row.

### The four-child event

Its child charges are `(e_1,e_1,e_2,e_2)` with cross pairing `-2`. The local
quiver is `K_(2,2)` with two arrows at every source-sink pair. Its stability is
`(-4,-4,+4,+4)`. The flow polytope has dimension five, eight vertices and 99
nonempty faces. It is the join of two squares.

The exact graded natural characters are

```
identity:      1+3t+4t^2+4t^3+3t^4+t^5,
first swap:    1+t+2t^2+2t^3+t^4+t^5,
second swap:   1+t+2t^2+2t^3+t^4+t^5,
both swaps:    1-t-t^4+t^5.
```

Their values at one are `(16,8,8,0)`. The exterior star factors have
dimension four and trivial action here, producing the middle row of the
table.

The double-swap zero has a concrete local origin. At an endpoint stratum the
transverse cone is the cone over `P^1 x P^1`. The primitive class
`H_1-H_2` changes sign when the rulings are exchanged. Thus the local stalk
trace is `1-t`, not `1+t`. This is forced by the canonical module action.

The independent incoming recurrence gives the same four global character
values. The sign multiplicity is

`(88-40-36+12)/4=6`,

and the ordinary theta coefficient is independently `6`.

**Correction record.** The simultaneous-event agent initially predicted a
local double-swap trace four by applying a raw weighted-cycle formula inside
this nonprimitive event. Our fan computation gave zero. After that agent
computed the complete global character and subtracted the other natural
skeletons, the required local trace was exactly zero. The initial prediction
was withdrawn. This was not a counterexample to the IH model, and no sign
twist or fitted correction was inserted. It exposes the need for global
plethystic compatibility rather than naive eventwise cycle substitution.

## 6. Computation interfaces and validation

### Assembly correction received at 11:38 UTC

The squarefree assembly branch has found that the general tensor assembly
must carry a uniform local **DT parity**, even though the fan IH itself is
in even cohomological degrees. Its convention is

`epsilon_event = (#children - #arrows) mod 2`.

Permuting a cycle of `k` identical event factors then gives the Koszul sign
`(-1)^((k-1)*epsilon_event)`. This changes the action on tensor factors, not
the local fan character or vector-space dimension. The resulting signed
tensor permutation is still an actual group action on the underlying vector
space, so it does not reduce the proposed final module to a virtual one.

The branch found the necessity in a new general-assembly test with
`B=[[0,-1,2],[1,0,2],[-2,-2,0]], g=(1,-3,0), p=(2,2,1)`: ordinary tensor
permutation gave double-swap trace 96 instead of 32. The odd binary factors
correct this to 32; the even `K_(2,2)` factor is unchanged. Its first 55
complete cycle-character tests then passed. This receipt is a mechanism
check from that branch, not an independent theorem proof in this report.
The parent is responsible for deriving the parity from the Hall/BPS
normalization. In the earlier hard case all relevant exchanged event factors
are even, so the table in §5 remains valid without modification.

The general implementation is

`computations/natural_incoming_module/equivariant_toric_ih.py`.

Its public functions are:

* `flow_polytope(eta)`: integer skew acyclic connected matrix; returns exact
  incidence, theta, arrows, and all vertices. Arrows are triples
  `(source,target,parallel_index)`.
* `event_ih(eta,child_permutation=None)`: returns `trace_total`,
  `graded_traces`, `ih_polynomial`, face and vertex counts, and nonscalar local
  stalk traces. A permutation is a list sending each child to its image.
* `equivariant_ih(incidence,vertices,permutation)`: lower-level arbitrary
  bounded positive-flow input, with a permutation of arrows.

The wrapper rejects cyclic or disconnected inputs, and permutations that do
not preserve eta. This documents the domain rather than silently applying
the local construction to a cyclic original exchange matrix.

Independent checks:

1. Full fan recursion for `m=1,2,3` arrows per pair in `K_(2,2)` gives
   characters `(2,2,2,2)`, `(16,8,8,0)`, and `(54,18,18,6)`. These agree
   with the sibling branch's independent geometric formulas, including all
   graded coefficients.
2. Nine rank-two positive-charge configurations, with two through five
   children and repetitions, compare the identity trace to a nearby generic
   stability's stable-tree count. The latter uses separate incidence-matrix
   inversion and exact lexicographic infinitesimals. All nine agree; counts
   include `1,2,5,3,6,15`.
3. A three-cycle acting on three identical two-slot star factors gives
   graded trace `1+t^3`. This checks a non-involutory action.
4. The complete hard case is independently assembled and compared to the
   weighted-cycle recurrence at all four conjugacy classes.
5. The actual Wolfram plugin independently verifies the primitive negative
   sign, the two characteristic polynomials for the `m=2` event, and the
   resulting sign multiplicity. An earlier Wolfram call separately checked
   the failed spherical quotient below.

Exact receipts and reproducible programs are retained in the computation
directory. These checks support the general construction and its code; they
are not substituted for the missing global theta theorem.

## 7. The incoming-ideal route: concrete progress and precise gap

The ordinary full shuffle cut quotient fails for cyclic quivers. A more
natural candidate is the image of the **actual spherical shuffle subalgebra**,
generated by all singleton polynomial pieces, inside that finite cut
quotient. In squarefree dimension, all words with an ordinary prefix before
the frame lie in the HN cut ideal. Consequently the spherical image is the
ideal generated by frame-first word products

`M_w = product_(a<b) (z_(w_b)-z_(w_a))^(A_(w_a,w_b))`.

This construction uses no theta value. It is natural under clone
permutations, but it is still wrong in general. In a balanced oriented
triangle with `r` arrows per side, `g=(-1,-1,-1)`, it has dimension

| r | Full cut quotient | Spherical image | Theta |
|---:|---:|---:|---:|
| 1 | 7 | 4 | 4 |
| 2 | 19 | 10 | 7 |
| 3 | 37 | 16 | 10 |
| 4 | 61 | 25 | 13 |
| 5 | 91 | 34 | 16 |
| 6 | 127 | 46 | 19 |

Of the first 100 deterministic rank-three/four test inputs, 95 agree and five
fail. This disproves the candidate, regardless of its high success rate.

### A specific incoming primitive is visible

For the unframed triangle, perturb the zero attractor stability to
`(-2,1,1)` and remove the simultaneous translation coordinate. The thin cut
algebra is exactly

`Q[u,v]/(u^r,v^r)`.

Its spherical image is the ideal generated by `(u+v)^r`. The multiplication
map by this power has rank `floor(r^2/4)`: the tensor product of the two
truncated polynomial strings has the standard Lefschetz decomposition, or
the same rank follows directly from its binomial coefficient matrices.

For `r=1,...,6`, the framed spherical excess is exactly three times this
rank. The number three is the pairing of the total triangle root with the
frame. This identifies the expected incoming primitive multiplied by its
framing extension space. It does not construct the required quotient map.

The proposed general algebraic route is root-graded: inside the
simple-generated Hall/shuffle algebra, take nonaxis attractor-stable
primitive pieces, remove zero-slope decomposable products, retain the
translation variable, and form their multiplication/extension ideal. A
canonical polynomial section, HN compatibility, and the resulting
kernel/cokernel decomposition still have to be proved. Merely subtracting
the primitive dimensions would not establish this route. Killing all simple
composition factors as a Serre quotient would instead destroy the whole
category, so that is not a valid replacement.

Other short probes were stopped when their mechanism failed: diagonal ideal
powers match an isolated triangle weight but fail at the next weight; direct
cyclic Gale ratio equations do not give the desired finite degree. No
claim from these probes is used in the local fan construction.

## 8. Literature and route review record

Initial review: 11:04–11:12 UTC. Route refresh: approximately 11:24 UTC.
Final local-fan audit: 11:32–11:38 UTC. The change of route was caused by the
new two-plane lemma and the successful natural character calculation, not by
substitution of a more deliverable task for the central problem.

| Source | Material directly checked | Decision and scope |
|---|---|---|
| Tang Qiyue, Hexagon `2611.00238v1`, https://hexagonmath.org/pdf/2611.00238v1 | §3 valuation/finite factors; §4 acyclic incidence/Gale/cut presentation and strict-positive-flow hypothesis; §6 Lemma 6.1 and its Hermite perturbation argument | Useful finite algebra and natural permutation-module mechanism. Only its stated acyclic/generic range may be used. It is not a theorem about our original cyclic exchange matrix. Proof audit was local to these interfaces, not a certification of every assertion in the paper. |
| RRT `2207.11861`, primary author PDF https://www.math.toronto.edu/vvtewari/draft_dt.pdf | Equivariant break-divisor/orbit-harmonics argument in §3 | Useful model of natural finite coordinate algebra. Its DT application concerns symmetric quivers with its own loop assumptions; no transplantation to skew cluster quivers. |
| BBFK `math/0002181`, https://arxiv.org/pdf/math/0002181 | Proposition 1.3 proof; Theorem 1.6; Remark 1.8 including uniqueness proof; local/global polynomial discussion | Directly used for the finite fan module, rational local vanishing, and canonical group action. Pre-2026 primary source. |
| Proudfoot, EMS 2018, https://ems.press/content/serial-article-files/37003 | §4.4 toric strata and Corollary 4.20 | Confirms the ordinary rational toric stalk interpretation and purity. The equivariant recursion above is explicitly derived, not quoted as a theorem that this paper does not state. |
| Proudfoot `2009.06696`, published https://alco.centre-mersenne.org/articles/10.5802/alco.174/ | Primary metadata and scope; publisher PDF access returned 403 | Relevant equivariant incidence-algebra interface. No uninspected proof used. |
| Gui `2605.15061v1`, https://arxiv.org/html/2605.15061v1 | Theorem 1.1 scope and Question 5.4 | The established displayed theorem is for complete simplicial fans; nonsimplicial IH is posed as a question. It cannot justify the nonsimplicial step needed here. This limitation is recorded, and the proof above uses rational IC directly. |
| Stapledon `2511.16612v1`, https://arxiv.org/html/2511.16612v1 | Determinant-kernel example and version/date information | Potential combinatorial presentation. Header says 2025 while displayed body is dated 2026; not used as an audited proof. |
| Jindal–Negut `2607.23544v1`, https://arxiv.org/html/2607.23544v1 | Introductory definitions, tripled quiver/cubic potential and loop-nilpotent scope | Possible incoming relation interface. Not a theorem for the original skew quiver; full proof not audited and no conclusion imported. |
| Chen–Mandel–Qin `2306.04104`, https://arxiv.org/abs/2306.04104 | Covering/nice-grading scope and once-punctured-torus caveat | Acyclic universal covers do not automatically repair cluster/stability incoming differences. Not used to identify our model. |
| Qin weak-genteel discussion, https://ems.press/content/serial-article-files/47257 | Conjectural versus injective-reachable statements | No assertion that an arbitrary generic Jacobi potential is weakly genteel. The local acyclic route avoids needing it. |

The RRT and Tang mechanisms motivated finite natural modules; neither is
used to assert the new global theta equality. The 2026 papers are retained
with their actual audit status, including useful limitations and unused
interfaces.

## 9. Precise handoff

The local module, canonical group action, exact fan recursion, and automatic
geometric hypotheses are ready. The sibling squarefree branch is building
the general induced super tensor assembly from these local modules. The parent is
checking Reineke's small resolution and the equivariant BPS/HN identity that
must connect the assembled representation to the weighted-cycle character.

Once that compatibility is proved, taking the sign-isotypic part of this
explicit finite combinatorial module would give the sought positive
integer coefficient formula. This last sentence is conditional, not a claim
that arbitrary high-rank theta/greedy combinatorics has already been proved.
