# Targeted primary-literature audit: Young profiles and reddening support

2026-11-13, 14:30--14:55 UTC. This records the literature refresh used for
`valued_young_functor_reddening.md`. It is not a claim to audit every theorem
in every source.

## 1. Qin: accepted exact classical support and endpoint interfaces

**Primary source.** Fan Qin, *Bases for upper cluster algebras and tropical
points*, J. Eur. Math. Soc.26 (2024),1255--1312, DOI10.4171/JEMS/1308,
<https://ems.press/content/serial-article-files/47257>. Also read the
locally preserved arXiv:1902.09507v4 full text to repair minus signs missing
from the web PDF extraction.

**Read and checked.** Definitions2.3.1--2.3.2, Proposition2.3.3,
Corollary2.3.4, Definition3.3.1, Propositions3.3.11--3.3.12,
Definition3.4.4, Proposition3.4.8, and TheoremA.1.5. The ambient seed
conventions permit skew-symmetrizable matrices. The weak-genteelness
application later in the article has a narrower skew-symmetric scope.

**Usable conclusion.** A terminal all-negative c-vector word is a
green-to-red/reddening certificate, with terminal `C=-P`; `P` preserves
the symmetrizer and `G=-P`. For injective-reachable full-rank principal
seeds, theta functions are finite Laurent polynomials and compatibly
pointed. Their codegree is `Psi^{-1}Phi(g)`, with `Phi` the tropical map
to `t[-1]` and `Psi` its basis-defined linear degree map. This yields the
nonnegative support dimension and its sharp coordinate box.

**Independent checks.** The predecessor word constructed from a supplied
reddening word, the full principal-lattice formula, and support dimensions
were tested against exact matrix mutation and cluster-variable F-vectors.
The current receipt has103 certificates,3735 arbitrary labels and3990
F-vector comparisons, including a three-cycle terminal permutation.

**Boundary.** Compatible pointedness and support do not distinguish theta
from every other good basis. They are used only to provide the finite
carrier for the independently identified event/Dyck coefficients. No
claim that all generic cluster characters equal theta is imported.

## 2. Keller and GHKK: established consequences, not novelty

**Keller primary.** *A survey on maximal green sequences*, with Demonet
appendix, arXiv:1904.09247v7,1December2020,
<https://arxiv.org/pdf/1904.09247>. Proposition2.4 identifies the terminal
framed quiver of a reddening sequence with the coframed quiver up to a
frozen-fixing permutation. Theorem3.5 states the theta-basis consequence
after its full-rank hypothesis. Scope is the skew-symmetric quiver
discussion; the valued statement is taken from Qin instead.

**GHKK primary.** <https://arxiv.org/pdf/1411.1394v2>, Definition8.27,
Proposition8.28. Large cluster complex gives the principal-coefficient
theta basis and finiteness. Arbitrary coefficient fibers have separate
conditions; the statement is not indiscriminately specialized to all
fibers. Qin cites published Proposition8.25, whose numbering differs from
this preprint. These established basis/support inputs are not described
as new consequences proved in the present project.

## 3. A 2026 quiver-moduli/tight-grading paper: useful local confirmation

**Verified publication.** Amanda Burcroff, Kyungyong Lee, Lang Mou,
Gregg Musiker, Markus Reineke, *Cluster scattering diagrams via quiver
moduli and tight gradings*, Journal of the London Mathematical Society
114(2),e70642, first published28July2026, DOI10.1112/jlms.70642.
Official primary full text:
<https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/jlms.70642>.
The previously recorded preprint is arXiv:2511.14672.

**Read and checked for this interface.** Section2, Proposition2.5;
Section3 through Corollary3.3; Theorem4.10 and its precise attribution to
Burcroff--Lee--Mou arXiv:2503.03719; Section6 proofs of Theorem1.2(1),(2),(4);
the abstract and scope of the remaining results. Theorem4.10 is the
same universal positive tight-grading profile identity used here, not
an independent source of a new high-rank construction. Section6(1)
specializes independent profile variables to binomial coefficients.
This is consistent with the exterior-power interpretation in our note.

**A concrete printed error, narrowly scoped.** In the proof of
Theorem1.2(2), the official HTML states the top degree term in `g` as
`(rho_1/(bc))^k g^k`. The required factor `1/k!` is absent. Directly from
the preceding correct identity

`1+sum tau_k x^k=(1+sum rho_k x^k)^(g/(bc))`,

the coefficient of `g^k x^k` is `(rho_1/(bc))^k/k!`. The displayed
Theorem1.2(2) itself has the correct binomial expansion, and
Theorem1.2(4) has the correct `1/n!`, so this is a localized proof-line
error and does not contradict their claimed degree/nonvanishing
conclusion. Wolfram independently returned the first four leading
terms `a, a^2/2, a^3/6, a^4/24` for `[t^k](1+at+bt^2+ct^3)^q`.

**What is not imported.** This article treats rank2. Its Euler-characteristic
quiver-moduli formula does not by itself give a full symmetric-group
representation, an action on primitive factors, or a high-rank event
gluing. Its scalar binomial specializations are not sufficient to infer
all original-alphabet Young multiplicities. Our full local comparison
uses the separately proved whole Gale character identity and the
universal profile theorem. No result from Sections5 or7 is needed for
the Young-species construction, and their full proofs have not been
reaudited in this targeted pass.

## 4. Additional results found and not used

* Tucker J.Ervin and Scott Neville, *Mutation Cycles from Reddening
  Sequences*, Annals of Combinatorics, published7September2026,
  DOI10.1007/s00026-026-00849-3,
  <https://link.springer.com/article/10.1007/s00026-026-00849-3>.
  Publication, authors, introduction and stated triangular-extension
  interface were checked. It supplies families of mutation cycles and
  reddening sequences, not the finite Young module or its theta
  coefficient identification. No new theorem from it is used; full
  correctness is not certified by this record.
* The search also returned Interdonato--Iraci, *The Theta Conjecture*,
  arXiv:2609.17744. The returned abstract is about diagonal coinvariants
  and decorated Dyck paths for symmetric-function Theta operators, not
  cluster theta bases. The direct abstract-page fetch failed. It is
  excluded as an input; its correctness and complete text were not
  audited. The shared word “theta” is not evidence of an interface.

## 5. Accepted route and rejected shortcut

Accepted: universal independent elementary profiles -> literal colored
leaf-block species -> complete Young characters -> sign Hom coefficients;
Qin tropical support dimension -> finite graded direct sum for one whole
classical theta element.

Rejected shortcut: substitute arbitrary coefficient functors directly
into a bare local Gale representation without choosing its Young orbit
lift. Full character determines a Young-set isomorphism class but does
not specify a natural splitting of reducible permutation modules or a
canonical map between algebraic roots and Dyck paths. Likewise, equality
of the one-letter specialization alone would not determine the full
Young character and is not used to do so.

