# The first three-factor Dyck diamond for arbitrary valued planar inputs

Branch `valued_coherence_phase_transport`, 2026-11-13, begun15:01 UTC.
The arithmetic mechanism and Smith lemma were independently reviewed by
root and `dyck_global_independent_review` before implementation.

## 0. The precise new result

The first multilinear ABC critical diamond now has an explicit bijection
for **arbitrary unequal input normal contents** in a rational rank-two
plane. All intermediate and final carriers may be nonprimitive in the
original ambient lattice. The bijection acts on the actual positive
Dyck-edge positions and ordered normal-copy slots; it preserves the
three input decorations. It is natural under their independent
bijections and becomes Young-equivariant after external labeling.

The earlier obstruction to preserving the old root-copy coordinate is
valid. The map below deliberately mixes that coordinate with a geometric
strip residue. It preserves a NEW normalized root coordinate derived
by an explicit gcd carry. It does not divide individual Gale/tree
characters by phase orders, and does not claim an identification with
the geometric phase action on a Gale fiber.

This proves the first trilinear component of the general triple-functor
equation in `DYCK_THREE_FACTOR_COHERENCE.md`, Section6. It does not prove
all-degree coherence, an arbitrary flag-change bijection, or independence
of the route through several local diamonds.

## 1. Input and the actual local coordinates

Let D be positive integral diagonal, DB alternating, and

    K(x,y)=x^t D B y,       w(x)=gcd_i(D_i x_i).

Let a,b,c be positive carriers in one nondegenerate rational two-plane,
in the inverted angular order, so

    p=K(a,b)>0,     q=K(b,c)>0,     r=K(a,c)>0.

Put d_a=w(a), d_b=w(b), d_c=w(c), and write d_ab,d_ac,d_bc,d_S for
the contents of the indicated sums. Here S=a+b+c.

For a single inverted pair x,y, let m=K(x,y), d=w(x), e=w(y),
kappa=w(x+y). The first-coefficient Dyck object has one positive
horizontal and one positive vertical edge, together with one occupied
normal-copy slot. The edge-residue lemma proved in the companion note
gives its explicit coordinates

    (k,s),   0<=k<kappa/gcd(d,e),
             0<=s<m/lcm(d,e).                           (1.1)

These are read from the actual positive edge positions, not from a list
of objects of known size. Explicitly, set u=m/d,v=m/e,ell=gcd(u,v),
A=v/ell,B=u/ell, and choose the standard minimal rectangle (W,H) with
A H-B W=1, W>=v,H>=u. If the horizontal edge is h_i, then

    s=(H(i-1) mod W)-(W-ell),
    j=(floor(H(i-1)/W)+u) mod H+1                        (1.2)

is its unique positive vertical edge index. The inverse is

    i-1=H^(-1)(W-ell+s) mod W,

followed by the formula for j. The actual tuple slot is k. All uses of
these coordinates below include this forward and inverse edge map.

## 2. A common-content integrality lemma

Set

    h=gcd(d_a,d_b,d_c),             Gamma=Za+Zb+Zc.

The rank of Gamma is two. Every x in Gamma satisfies h|w(x).

**Lemma.** For every nonzero x,y in Gamma,

    K(x,y) h / (w(x)w(y)) is an integer.                 (2.1)

The quotient may be zero or negative outside the positively ordered
pairs. In particular all active positively ordered pairs in the first
triple histories have a positive integral quotient.

**Proof.** Let Lambda be the saturation of D Gamma in its rational
two-plane inside Z^r. It is a saturated free rank-two lattice. The
first Smith invariant of D Gamma in Lambda is h: it is the gcd of
all coordinates of the generators Da,Db,Dc, equivalently the gcd of
their individual contents. Choose bases x_0,y_0 of Gamma and f_1,f_2
of Lambda such that

    D x_0=h f_1,               D y_0=h delta f_2,

where delta>0. A basis of the saturated Lambda extends to an ambient
integral basis, so f_1,f_2 are primitive ambient vectors. Hence
w(y_0)=h delta. Since

    K(x_0,y_0)=-(D y_0)^t B x_0,

it is divisible by h delta. Write it as h delta nu with nu integral.
For x=u x_0+v y_0 and y=s x_0+t y_0,

    K(x,y)=h delta nu(ut-vs),
    w(x)=h gcd(u,delta v),
    w(y)=h gcd(s,delta t).

The product of the last two gcds divides
det((u,delta v),(s,delta t))=delta(ut-vs), since it divides every
term of this determinant. Thus (2.1) is integral. QED.

Equivalently, after dividing all contents and pairings by h, the
alternating form on the saturated normal plane is an integral multiple
of its determinant form. This is the ingredient missing from the
unequal-content rectangle comparison.

The rank-two hypothesis is substantive. We do not assert (2.1) for
three unrelated carriers spanning a higher-dimensional lattice.

## 3. The local gcd carry absorbs unequal root-copy lengths

For any pair in Gamma, put

    d'=d/h, e'=e/h, kappa'=kappa/h,
    g=gcd(d',e'),       P_pair=m h/(d e).

By Section2, P_pair is a positive integer. Formula(1.1) becomes

    0<=k<kappa'/g,              0<=s<g P_pair.

Perform the explicit carry

    intersection=floor(s/g),
    phase=g k+(s mod g).                                (3.1)

This is a bijection onto

    0<=intersection<P_pair,         0<=phase<kappa'.

Its inverse is

    k=floor(phase/g),
    s=g intersection+(phase mod g).                     (3.2)

The term phase denotes this particular combinatorial coordinate. It is
not a claim that an unspecified geometric phase quotient has been made.
Both coordinates are computed directly from the existing edge residue
and existing normal-copy slot. This is a local Euclidean division, not
an arbitrary rank/unrank map on all histories.

The critical consequence is that the new root-coordinate range is
kappa/h, independent of the gcd of the two immediate input contents.
That range is the same at the root of all three-input histories.

## 4. Collapse a two-vertex history into a weighted rectangle

Set the normalized input contents and primitive pairings to

    A=d_a/h, B=d_b/h, C=d_c/h,
    P=p h/(d_a d_b), Q=q h/(d_b d_c), R=r h/(d_a d_c),
    T=d_S/h.                                            (4.1)

All six A,B,C,P,Q,R and T are positive integers. The four histories are

    L1=((a,b),c),
    L2=(b,(a,c)) if q>p,
    R1=(a,(b,c)),
    R2=((a,c),b) if p>q.

Apply (3.1) to the inner and outer binary objects. If the intermediate
content is d_xy, combine its new phase with the outer intersection by

    i=inner intersection,
    j=(d_xy/h) outer intersection + inner phase,
    k=outer phase.                                     (4.2)

Conversely, divide j by d_xy/h to recover the two entries. This carry
does not lose the intermediate normal content.

The resulting actual history spaces are the integer rectangles

    L1: [0,P) x [0,A R+B Q) x [0,T),
    L2: [0,R) x [0,C Q-A P) x [0,T), when C Q>A P,
    R1: [0,Q) x [0,B P+C R) x [0,T),
    R2: [0,R) x [0,A P-C Q) x [0,T), when A P>C Q.     (4.3)

For example the L1 second range is

    (d_ab/h) * ((r+q)h/(d_ab d_c))
          =(r+q)/d_c=A R+B Q.

All other cases follow by the same cancellation. Note that q>p is
equivalent to C Q>A P because q-p=h B(C Q-A P).

The old root-copy ranges can differ between histories, but the range
of k in (4.3) is always T. This is the precise repair of the previously
proved root-copy-preserving obstruction.

## 5. A weighted rectangle cut with a complete inverse

Keep the coordinate k and the original A,B,C input decorations fixed.
For a point L1(i,j), proceed as follows.

**Bottom part.** If j<B Q, write j=B j_0+b, 0<=b<B, and send

    L1(i,j) -> R1(j_0,B i+b).                           (5.1)

This transposes a P-by-Q rectangle inside each of the B layers.

**Upper part.** If j>=B Q, write

    j-B Q=A t+a_0,        0<=a_0<A,
    z=A i+a_0.

If z<C Q, write z=C i_0+c_0, 0<=c_0<C, and send

    L1(i,j) -> R1(i_0,B P+C t+c_0).                     (5.2)

If z>=C Q, send

    L1(i,j) -> R2(t,z-C Q).                             (5.3)

**Additional left rectangle.** If L2(i,j) is present, put z=A P+j.
Write z=C i_0+c_0 and send

    L2(i,j) -> R1(i_0,B P+C i+c_0).                     (5.4)

Here (5.3) is possible only when A P>C Q, and (5.4) only when
C Q>A P. These are exactly the allowed extra histories.

The inverse is the symmetric procedure. For R1(i,j):

- If j<B P, write j=B i_0+b and return L1(i_0,B i+b).
- Otherwise write j-B P=C t+c_0 and z=C i+c_0.
  If z<A P, write z=A i_0+a_0 and return
  L1(i_0,B Q+A t+a_0).
  If z>=A P, return L2(t,z-A P).
- From R2(i,j), put z=C Q+j=A i_0+a_0 and return
  L1(i_0,B Q+A i+a_0).

**Proof of bijectivity.** The bottom parts on both sides are the same
set [0,P)x[0,Q)x[0,B), read in two orders. For the upper parts, the
left L1 strip becomes [0,A P)x[0,R) in coordinates(z,t); L2, when
present, supplies [A P,C Q)x[0,R). The right R1 strip becomes
[0,C Q)x[0,R), and R2, when present, supplies [C Q,A P)x[0,R).
Both sides therefore cover the single rectangle

    [0,max(A P,C Q)) x [0,R)

by disjoint adjacent pieces. The divisions displayed above merely
read the same point in the two prescribed grids. The formulas include
every boundary integer point exactly once and are inverse on every
piece. QED.

After (5.1)--(5.4), undo (4.2), then (3.1), then the actual edge-residue
map(1.2). This is the required algorithm on two actual Dyck gradings
and their tuple slots.

## 6. Naturality, inherited parallel objects, and scope

The map never reads the three input decorations. It only moves their
parenthesization and leaves each attached to its original identity.
Thus arbitrary bijections of the three input coefficient sets commute
with the map. External original-color label blocks stay unchanged, so
the induced map on the Young species is equivariant. It may be inserted
into any larger event/Dyck construction as a natural local replacement.

When p=q, a+c is parallel to b. The inherited b packet times the (a,c)
birth is a common forest contribution on both schedules. It is retained
identically. The connected ABC histories in (4.3) still obey the
bijection with A P=C Q; no factor is divided out.

This closes the **entire first multilinear critical diamond**, not just
equal-content inputs. It does not make the old ramified isolated-sector
quotient correct. Nor does it give an all-degree map on a tight grading
with several positive edges of the same input type. The latter is the
remaining functor equation in the companion coherence report.

The normalized root-coordinate translation k->k+1 mod T defines a
combinatorial cyclic action with which this map commutes. No equality
with a geometric Gale phase action is asserted. Coherent relations
between sequences of these triple moves have also not been proved.

## 7. Computation and independent review

The actual implementation is
`computations/valued_three_factor_coherence.py`. It imports only the
proved binary edge-coordinate maps from the earlier implementation.
All triple maps are the explicit carries and rectangle formulas above.

Completed exact checks:

- 15,625 weighted-rectangle parameter tuples A,B,C,P,Q,R in[1,5];
- 1,006,800 complete forward/inverse integer-point checks, with image
  sets exactly equal to the independently enumerated right rectangles;
- 10,877 actual coplanar charge triples embedded in ambient ranks2--5,
  with integral DB alternating;
- 9,992 of those have unequal input normal contents;
- 3,907 have nontrivial common h;
- 9,857 have a nonprimitive intermediate normal content;
- 168,878 actual Dyck-edge history forward/inverse checks;
- 2,002 additional literal shadow/tightness checks;
- 37,616 checked moves change the OLD root-copy slot, while the new
  normalized root coordinate is preserved.

These tests use actual ambient charges and symmetrizers, not arbitrary
numerical contents assumed realizable. The test generator embeds a
rank-two positive cone into Z^r and uses K_ij divisible by lcm(D_i,D_j).

The real Wolfram Language service independently checked 4,096 weighted
parameter tuples and 151,280 complete point inverses with zero error.
It returned zero for the symbolic identity

    P(A R+B Q)+R max(C Q-A P,0)
     -Q(B P+C R)-R max(A P-C Q,0).

Its exact request and returned receipt are saved as
`computations/valued_three_factor_wolfram.json`.

Root and the fresh independent coherence reviewer separately checked
the Smith proof, the common-content division, and all weighted rectangle
pieces before these calculations. The tests check the implementation;
the general argument is Sections2--5.

## 8. Route and literature record

- 15:01--15:04: read the actual edge-residue and equal-content theorem,
  and the explicit unequal root-copy obstruction. Rejected the need
  to force a geometric per-tree phase quotient.
- Derived the common-content Smith lemma. This identifies the missing
  divisibility after normalizing by the gcd of all three input contents.
- Derived the local gcd carry, then the weighted rectangle identity.
  The inverse follows from a shared rectangular region, not from equal
  cardinalities or an ordering of all histories.
- 15:04--15:11: independent proof review, exact actual-edge implementation,
  and actual Wolfram verification.

The binary tight-grading formula is BLM2025 and the direct residue lemma
is proved in the companion note. Jacobi multiplicity equality and Smith
normal form are established mathematical inputs. The new construction
here is the specific common-content carry and its weighted rectangle
lift to actual valued Dyck histories. No 2026 theorem is required and
no Li--Pan conclusion is used. A targeted literature refresh continues
for a possible all-degree extension; no priority claim beyond the
explicit construction is inferred from not finding an earlier formula.
