# Equivariant local DT theory and the correct tensor sign

Branch `equivariant_dt_proof`, 2026-11-13. All target cluster-algebra statements are classical. Cohomological DT theory is used only as an intermediate proof mechanism. No Li--Pan assertion is used.

## 1. What is proved in this note

1. Davison--Meinhardt's canonical PBW map gives a genuinely finite-group-equivariant local wall-factorization identity for our acyclic simultaneous-event quivers. This is stronger than forgetting group actions in a Grothendieck-group identity.
2. The canonical PBW symmetry is **not** plain Koszul symmetry. It contains the Euler-form twist `tau`. On the pure local factors relevant here, its effective interchange sign is the cross Euler form.
3. For two disjoint isomorphic colored branches, this sign is the parity of the number of internal arrows of the branch. Consequently the natural proposed tensor normalization is

   `IH(P_v)[E_v]`, where `E_v` is the number of arrows of the local event quiver,

   rather than `IH(P_v)[arity_v-E_v]`.
4. This normalization has a refinement-independent total parity, proved below. It repairs the first four-cycle counterexample found by the computation branch. The general character equality with the weighted-cycle theta coefficient still requires the global species/completion step described in Section 7; it is **not asserted as proved merely from the local result**.

## 2. Primary sources actually inspected

* Davison--Meinhardt, *Cohomological Donaldson--Thomas theory of a quiver with potential and quantum enveloping algebras*, arXiv:1601.02479v5, 6 March 2020. Theorem A; equations (15)--(21); Corollaries 4.11 and 5.9; Section 6.1; the construction preceding Theorem 6.9 and its proof; Section 6.4. Local downloaded PDF and extracted text: `literature/davison_meinhardt_1601_02479.*`.
* Meinhardt--Reineke, arXiv:1411.4062v2. The earlier branch inspected the nonequivariant motivic identity. It is not used as if it already contained an equivariant theorem.
* Davison--Mandel, arXiv:1910.12915v3, 15 June 2021. Its Sections 5 and 7 give the useful local-to-global scattering interface, but its printed scalar positivity theorem is not an already-proved species-valued theorem.
* Mozgovoy, arXiv:2101.07636v1, 19 January 2021, Sections 1--2 and the collection/plethysm construction. Its collections take rational scalar values. The analogy with species is explicit in its introduction, but it does not itself prove our representation-valued completion statement.

All of these are pre-2026 sources. No 2026 claim is needed for the proved local statements.

## 3. A finite-group-equivariant PBW corollary

Let `Q` be a finite quiver, `Gamma` a finite group of quiver automorphisms, and `zeta` a `Gamma`-invariant stability which is `mu`-generic in the sense that the Euler form is symmetric on its slope-`mu` lattice. Work with zero potential. Let `A_mu` denote the relative cohomological Hall object over the moduli of semistable representations, and let `BPS_mu` be the direct sum of its intersection-complex BPS objects. The total dimension vector may be fixed by `Gamma`, or one may take a `Gamma`-stable sum of dimension components.

**Lemma.** The canonical PBW map of Davison--Meinhardt Theorem C is `Gamma`-equivariant, in its **tau-twisted** symmetric monoidal category.

**Proof.**

Theorem C is realized by two specified maps, rather than by a choice of an isomorphism between equal-dimensional spaces:

* Corollary 4.11 gives the canonical inclusion of `H(BC*)_vir tensor BPS_mu` into the relative Hall object. For zero potential, its proof identifies the source with the direct summand having full strict support on the corresponding coarse moduli component. A quiver automorphism acts on the semistable representation stack, the coarse moduli space, and their semisimplification map. It preserves these full strict supports. The normalized intersection complex is characterized by its constant local system on the stable open locus, so its identification and the full-support summand are preserved as well. The central scalar subgroup `C*` is preserved and its standard cohomology factor carries the induced canonical action.
* The relative Hall multiplication is obtained from the stack of short exact sequences and its forgetful maps. Quiver automorphisms carry an exact sequence to an exact sequence and commute with every map in this correspondence. Pullback, proper pushforward, and their canonical comparison maps therefore commute with the automorphism action. The same holds for any iterated multiplication.

The PBW morphism preceding Theorem 6.9 is this canonical inclusion followed by the symmetrized iterated multiplication. Its symmetrizer uses the Euler form, which a quiver automorphism preserves. It therefore also commutes with `Gamma`. Theorem 6.9 proves that this actual map is an isomorphism. An equivariant map whose underlying map is an isomorphism is an equivariant isomorphism. No equivariant generic resolution and no averaging of an arbitrarily selected PBW isomorphism is required.

The absolute version follows from Corollary 5.9 and the perverse filtration. That filtration, its first piece, and the `H(BC*)` action are intrinsic to the same equivariant maps. Alternatively, apply compactly supported cohomology to the relative construction in the proper local cases. This proves the lemma.

For our simultaneous-event quiver, `mu`-genericity is already verified in `proofs/local_rank_two_ih_interface.md`: all zero-slope charge images lie on one ray, so their skew pairings vanish. The quiver is acyclic, the thin total dimension vector is indivisible, and the stable locus is nonempty. Its BPS object is consequently the shifted toric intersection cohomology used by the computation branch.

## 4. The twist which cannot be dropped

Write `chi` for the quiver Euler form. Davison--Meinhardt equation (15) defines

`tau(d,e) = chi(d,e) + chi(d,d) chi(e,e) (mod 2)`.

For homogeneous vectors `a,b` in dimension components `d,e`, respectively, the canonical symmetry is

`tau_sw(a tensor b) = (-1)^[tau(d,e)+|a||b|] b tensor a`.

Replacing this by ordinary super symmetry requires a bilinear `psi` with `psi+psi^op=tau`. Such a `psi` need not be invariant under the finite automorphism group. Indeed, if an automorphism exchanges `d,e` and `tau(d,e)=1`, invariance would force `psi(d,e)=psi(e,d)`, contradicting the required sum over `F_2`. Therefore an arbitrary untwisting cannot be used to prove the clone-character statement.

This is the precise defect in the initially tested rule which used the parity `chi(1,1)=arity-E` independently at each node.

## 5. Effective cross-Euler sign and arrow parity

For the relevant local thin stable components, odd intersection cohomology vanishes. The ordinary intersection-cohomology vector space is even. Its BPS shift is

`dim M_d = 1-chi(d,d)`.

The additional factor `H(BC*)_vir` is odd in every degree modulo two. Hence the corresponding pure Hall generator has uniform parity

`|a| = chi(d,d) (mod 2)`.

The same is true for `b`. Substitution into the canonical symmetry gives

`tau(d,e)+|a||b| = chi(d,e) (mod 2)`.

Thus the correct effective interchange sign is **cross Euler**, not the product of self-Euler parities.

Now take two disjoint isomorphic colored branches `U,V`. Their vertices have the same displayed charges with the same multiplicities, and the arrows between any two displayed charges are prescribed by the same skew form. Identify the displayed vertices of `U` and `V` through the color-preserving isomorphism. Summing arrows from `U` to `V` is then the same sum as the total number `E_U` of arrows inside one copy: equal displayed charges contribute zero, and each unequal ordered pair contributes its prescribed arrow multiplicity. Since the supports are disjoint, the diagonal term in the Euler form is zero. Therefore

`chi(U,V) = -E_U`, and the interchange sign is `(-1)^E_U`.

This is exactly the sign needed for a cycle of isomorphic branch factors when their tensor parity is their internal arrow count. It explains why exchanging two two-leaf one-arrow branches is odd, whereas exchanging the three-leaf two-arrow star branches in the new counterexample is even.

For a node orbit of length `k`, with return permutation `rho` on one local factor, the corresponding proposed trace is therefore

`(-1)^[(k-1) E_v] Tr(rho | IH(P_v))`.

This derives the sign for isomorphic branch exchanges from the canonical local PBW symmetry. It does not, by itself, identify every global tree summand with a summand of one global Hall object.

## 6. A general refinement-independent parity identity

Let a rooted tree have labeled leaves with charges `alpha_i`. At an internal vertex `v`, let its child charges be `beta_1,...,beta_s`, and put

`E_v = sum_(a<b) |eta(beta_a,beta_b)|`.

Modulo two, absolute values can be removed. Expanding bilinearly, `E_v` is the sum of `eta(alpha_i,alpha_j)` over leaf pairs lying in distinct children of `v`. Every unordered pair of distinct leaves has exactly one lowest common ancestor, and occurs in exactly that vertex's sum. Consequently

`sum_v E_v = sum_(i<j) |eta(alpha_i,alpha_j)| (mod 2)`.

The right side depends only on the labeled input, not on the tree or its number of vertices. Thus all summands

`tensor_(v internal) IH(P_v)[E_v]`

have one common total parity. A single global shift makes their direct sum even if desired. The symmetric-group action obtained by permuting nodes and using the graded tensor symmetry is an honest action; its underlying ordinary character can be taken without defining an arbitrary basis or matching dimensions to a theta coefficient.

The analogous sum of `arity_v-E_v` depends also on the number of internal vertices and does not have this refinement invariance. This structural distinction was found independently of the successful retest.

## 7. The exact remaining global step

The local theorem suggests a rigorous route, but the following step must still be supplied rather than silently assumed.

Work in the completed algebra of colored species (or equivalently rational symmetric-group representations with Cauchy induction product), with the quantum-torus twist determined by `eta`. Initial ray factors are plethystic Fock factors. For each finite color-preserving permutation, taking its trace on a Cauchy product is a sum over invariant ordered subsets, hence over unions of whole cycles. The resulting cycle specialization has precisely the weighted charge matrix `B^lambda_ab = length(b) B_color(a),color(b)` and symmetrizer `D^lambda_a = length(a) D_color(a)`. This explains why the known target character is the weighted-cycle theta coefficient.

At a rank-two simultaneous event, the preceding equivariant PBW theorem gives the required local Fock-factor replacement, including parallel-block permutations. It is essential to use plethystic factorization: an individual nonprimitive local IH trace is not one primitive folded flow number.

To finish, one must prove that iterating these local replacements in the finite colored completion produces exactly the intrinsic positive-time collapsed-skeleton collection, with factors `IH(P_v)[E_v]`, and that no extra primitive or virtual term is introduced by repeated parallel branches. This is a species-valued local-to-global completion lemma. Scalar flow-tree formulas and scalar positivity theorems alone do not establish it: they forget the very cycle traces at issue. The canonical local PBW result removes the main equivariance obstruction, but the tree/completion identification remains a separate proof obligation.

The existing finite tests should be used to challenge this proposed lemma. They are not its proof.

## 8. Recorded correction, with its exact input

The first ordinary-tensor failure was repaired by the self-Euler rule on low-degree tests, but that intermediate rule subsequently failed at

`B=[[0,1],[-1,0]], g=(-6,1), p=(4,2)`.

The intrinsic model has 65 skeletons and the identity dimension is correct. For cycle types `((2,2),(2))` and `((4),(2))`, the self-Euler model gave `36` and `-22`, while the independently computed target values are `124` and `22`. The failed fixed summands exchange three-leaf two-arrow star factors. Their self-Euler parity is odd; their effective cross-Euler/arrow parity is even. The revised arrow-parity rule fixes these two entries, while retaining the earlier two-leaf one-arrow correction.

The computation branch owns the complete rerun, including the preserved failed results. Its current files are `computations/squarefree_polytope_action/global_tensor_ih*.json`. This note deliberately retains the failed intermediate rule and its reason for failure.

## 9. A concrete equivariant Hall trace identity for the next step

For a thin quiver with vertex set `I`, put `T=(C*)^I`. Its entire representation stack is the quotient of an affine representation of `T`, so its ordinary equivariant cohomology is `H(BT)`. A color-preserving permutation `sigma` acts by permuting the degree-two generators of this polynomial ring. Consequently its graded trace is exactly

`Tr_sigma H(Rep(Q,1)/T)_vir = t^[chi_Q(1,1)] / product_(c cycle of sigma)(1-t^(2|c|))`,

where `[dim stack]` is the usual cohomological shift, so a constant class moves to degree `-dim stack=chi_Q(1,1)`. This prefactor is a common shift, with trivial action on the standard shift line. The formula needs no point-counting conjecture and is independent of an arbitrary basis choice.

Harder--Narasimhan filtrations are unique and are carried to Harder--Narasimhan filtrations by every quiver automorphism preserving the stability. Thus the HN stratification is equivariant as a collection of strata. In the trace of a fixed permutation, an orbit of HN types with more than one member contributes zero. Each contributing ordered HN type consists of invariant vertex subsets, hence unions of entire permutation cycles. The extension-stack affine bundles and their Thom maps are equivariant for their complex orientations. This gives a direct equivariant version of the HN trace identity, with the usual Euler-form shifts.

Upon grouping vertex cycles, the cross-arrow pairing between a `k`-cycle of color `i` and an `l`-cycle of color `j` is `kl B_ij`. It is represented by the weighted matrix entry `l B_ij` with symmetrizer entry `k`. The denominator above simultaneously becomes the expected product of `(1-t^(2k))`. This verifies the exact cycle-weighted Hall input needed by the proposed global completion.

There is also a useful multilinear refinement of Davison--Mandel's construction in Section 7.2. Their `Q(V,P)` places a loop at an incoming vertex when the corresponding polynomial is odd. In thin dimension, each such loop is simply an independent scalar affine coordinate: it does not affect subrepresentations or stability. Removing these loops leaves the same ordinary local intersection-cohomology representation, tensor an affine factor; their virtual shifts supply the input-parity adjustment. Therefore one should not treat arbitrary already-graded incoming objects as automatically even. The loop device explains how to accommodate their parity while keeping the finite local toric IH factor visible.

This remains an interface for the global proof. Scalar positivity in Davison--Mandel does not by itself imply the desired identity of symmetric-group representations.
