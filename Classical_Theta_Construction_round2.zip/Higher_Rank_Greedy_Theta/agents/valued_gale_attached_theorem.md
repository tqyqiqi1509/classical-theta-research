# A finite attached algebra for valued two-input reordering

**Stage:** 2026-11-13, 13:10 UTC. Classical commutative algebras only.

This note proves a phase descent and character comparison for two-input
Gale algebras. The finite algebra is defined by explicit polynomial
relations and two saturations. Its definition uses no theta coefficient,
no reconstructed character, and no independent normalization of a flow
tree. Identifying its ordinary version with a wall coefficient remains a
separate interface; no arbitrary-rank theta theorem is asserted here.

The motivating ordinary construction is Qiyue Tang,
*Another Proof of Laurent Positivity for Generalized Cluster Algebras*,
Hexagon 2611.00238v1, Sections 3--6. We read the polynomial, Rees, and
core/attached arguments in those sections. The argument below extends the
numerical determinant to a general positive `kappa`, replaces differences
by complete gain packets, and proves the phase descent directly. It does
not use the paper's concluding arbitrary-rank statements.

## 1. Integer input and the actual algebra

Take positive integers `d_A,d_B`, a mixed multiplicity `m`, and a primitive
positive slope `(a,b)`, with

\[
 \ell=\operatorname{lcm}(d_A,d_B),\qquad \ell\mid m,
 \qquad \gcd(a,b)=1,
 \qquad \kappa=\gcd(d_Aa,d_Bb).
\]

Then `kappa` divides `ell`. At each prime, one of the valuations of `a,b`
is zero, so the valuation of their weighted gcd is at most the larger
valuation of `d_A,d_B`. In particular `m>=kappa`.

Choose positive integers `P,Q` such that

\[
 d_A\mid P,\quad d_B\mid Q,\quad Pa-Qb=\kappa.\tag{1.1}
\]

They exist by Bezout applied to `d_A a,d_B b`, followed by adding a large
positive multiple of their primitive relation. No coprimality of `P,Q`
is assumed. Put `M=m/ell` and

\[
 \Phi(x,y)=(x^\ell-y^\ell)^M.
\]

For every `k>=1` use `A=ka` variables `x_i` and `B=kb` variables `y_j`,
with `G_k=S_A x S_B`. The full-gain equations are

\[
 x_i^P\prod_{j=1}^{B}\Phi(x_i,y_j)=T^b,
 \qquad
 (-y_j)^Q\prod_{i=1}^{A}\Phi(x_i,y_j)=T^a.\tag{1.2}
\]

All equations are invariant under the independent finite phases

\[
 \mathcal A_k=\mu_{d_A}^{A}\times\mu_{d_B}^{B}.
\]

Indeed `d_A,d_B` divide `ell`, while the framing powers are divisible by
the corresponding vertex weights. Write `u_i=x_i^(d_A)` and
`v_j=y_j^(d_B)`. The descended equations are the square system

\[
 u_i^{P/d_A}\prod_j
   (u_i^{\ell/d_A}-v_j^{\ell/d_B})^M=T^b,
\]
\[
 (-1)^Qv_j^{Q/d_B}\prod_i
   (u_i^{\ell/d_A}-v_j^{\ell/d_B})^M=T^a.\tag{1.3}
\]

These are integer polynomials determined by the displayed input.

### Definition 1.1 — attached special algebra

For either system let `J` be its equation ideal in `Q[T,coordinates]`.
First take its horizontal ideal `J:T^infinity`, then specialize `T=0`,
and finally saturate by the product of all particle coordinates. The
resulting coordinate algebra is denoted `D_gain(P,Q,k)` for (1.2) and
`D_val(P,Q,k)` for (1.3). Equivalently, it is the full Artin factor of
the completed horizontal family whose particle coordinates have nonzero
limits. Finiteness is proved below. In particular, this definition does
not mean taking the reduced support: all local nilpotents are retained.

Let `D_raw(P,Q,k)` be the same construction with
`Phi(x,y)=(x-y)^m`, keeping the same `P,Q,a,b,m`. Set all three algebras
in degree `k=0` equal to `Q`.

Both saturations are ordinary polynomial-ideal computations. For example,
`J:T^infinity` is obtained by eliminating `z` from `(J,1-zT)`; the final
localization is computed similarly. Thus the definition is finite and
explicit whenever the input is fixed.

## 2. Statement

### Theorem 2.1 — attached phase descent and all-cycle character formula

For every input above and every `k`:

1. The three attached algebras are finite dimensional, and arise as
   special fibers of finite free algebras over `Q[[T]]`.
2. There is a natural `G_k`-equivariant phase descent

   \[
   D_{\rm gain}^{\mathcal A_k}=D_{\rm val},\qquad
   D_{\rm gain}\cong D_{\rm val}\otimes W_{d_A,d_B}
   \quad\text{as }G_k\text{-modules},\tag{2.1}
   \]

   where `W` has basis the bounded monomials
   `prod x_i^(r_i) prod y_j^(s_j)` with `0<=r_i<d_A`,
   `0<=s_j<d_B`.
3. The ordinary and full-gain attached algebras have the same ungraded
   `G_k`-character:

   \[
   \operatorname{Tr}(g;D_{\rm gain})
   =\operatorname{Tr}(g;D_{\rm raw}).\tag{2.2}
   \]

   Consequently, if `c_A(g),c_B(g)` are the numbers of cycles on the two
   particle colors,

   \[
   \operatorname{Tr}(g;D_{\rm val})
   =\frac{\operatorname{Tr}(g;D_{\rm raw})}
          {d_A^{c_A(g)}d_B^{c_B(g)}}.\tag{2.3}
   \]
4. `D_val`, ungraded, is a Young permutation representation of
   `S_(ka) x S_(kb)`. In particular its Frobenius characteristic is
   `h`-positive. This follows from its actual finite polynomial zero
   scheme; no irreducible-character reconstruction is used.

The theorem compares complete attached algebras. It does not claim that
an individual singular local IH module, or an individual framed tree
summand, admits this phase normalization. Section 12 of the companion
report gives an exact counterexample to that different assertion.

## 3. Valuative control for arbitrary kappa

Put

\[
 N_A=P+mkb,\quad N_B=Q+mka,\quad
 \Delta=bu-av,\quad D_0=N_Au-N_Bv.
\]

For `0<=u<=ka, 0<=v<=kb`, not both zero,

\[
 bD_0=N_A\Delta+\kappa v.\tag{3.1}
\]

If `Delta>0`, then `D_0>0`. If `Delta<0`, then
`bD_0<=-N_A+kappa kb<0`, since `m>=kappa` and `P>0`.
If `Delta=0`, primitivity gives `(u,v)=h(a,b)` and
`D_0=kappa h>0`. Thus `D_0` never vanishes, and has the sign of
`Delta` whenever the latter is nonzero.

Replace all right sides of (1.2) by independent nonzero parameters.
The inverse image of this target torus is finite over it. Here is the
valuative proof, which also controls the central specialization. Suppose
some coordinate has smallest negative valuation `nu`; divide all
coordinates of that valuation by one of them, and group the nonzero
residues by their common `ell`-th power. Pick one such group, containing
`u` first-color and `v` second-color particles. Multiply its first-color
equations and divide by its second-color equations. All internal factors
`Phi` cancel exactly. Every factor connecting the group to an outside
particle has valuation `m nu`. The valuation of the quotient is
`nu D_0`, contradicting `D_0!=0` when the target parameters are units.
The extension remains in the target-torus preimage, since each equation
has unit right side. The valuative criterion gives properness; an affine
proper morphism is finite.

For the central right sides `T^b,T^a`, the identical calculation gives

\[
 \nu D_0=\operatorname{val}(T)\Delta.\tag{3.2}
\]

The sign statement excludes every negative particle valuation. If all
particle valuations are positive and `val(T)=1`, their minimum is
`|Delta|/|D_0|>=1/M_k`, where
`M_k=max(ka N_A,kb N_B)`. Every full-gain linear factor also has valuation
at least that minimum.

### Nonzero centers

At `T=0`, group nonzero particles by `x_i^ell=y_j^ell=c`.
Every such group is balanced: its equation quotient has unit framing
and unit external factors, forcing `bu-av=0`. Thus its charge is
`h(a,b)`. The zero group is balanced as well.

Raise the limiting quotient for a nonzero group to the `ell`-th power.
The internal factors have already canceled. Its framing contributes
`c^(kappa h)` times the sign from `(-y)^Q`; interactions with every
other balanced group contribute only a sign. One obtains

\[
 c^{\kappa h}=(-1)^{Qbh\ell+mab h(k-h)}=\sigma_k^h,
 \qquad
 \sigma_k=(-1)^{Qb\ell+mab(k-1)}.\tag{3.3}
\]

The last equality uses the evenness of `h(h-1)`. In particular every
nonzero particle coordinate is a root of the explicit polynomial

\[
 F_k(z)=\prod_{h=1}^{k}(z^{\ell\kappa h}-\sigma_k^h),
 \qquad F_k(0)\ne0.\tag{3.4}
\]

There are consequently finitely many possible special support points.
Equation (3.2) rules out points at infinity of the horizontal closure
above `T=0`. Its completion there is finite; saturation makes `T` a
nonzerodivisor, so the completed algebra is finite free over the DVR.
The support conditions all-zero, all-nonzero, and mixed lift uniquely to
idempotent factors. Denote the full and all-zero special algebras by
`B_gain(P,Q,k)` and `C_gain(P,Q,k)`; the all-nonzero factor is the algebra
already defined as `D_gain`. The same proof, using ordinary differences,
works for `B_raw,C_raw,D_raw`: it only needs `m>=kappa`, not `kappa=1`.

## 4. Generic framed cut models for B and C

Use the acyclic graph with a weight-one root `0`, `ka` vertices `A_i`,
`kb` vertices `B_j`, and arrows

\[
 B_j\longrightarrow A_i\ (m\text{ copies}),\qquad
 0\longrightarrow A_i\ (P\text{ copies}),\qquad
 B_j\longrightarrow0\ (Q\text{ copies}).\tag{4.1}
\]

The vertex weights are `1,d_A,d_B`. Root edge multiplicities are divisible
by the corresponding particle weight, and mixed multiplicities are
divisible by their least common multiple. Factor `Phi` into its complete
`ell`-th-root gain packet. The remaining root forms are `x_i` and `-y_j`;
constant rescalings of these root factors have no effect on the cut
quotients or the arguments below.

Choose rational `epsilon>0` smaller than the valuation gap and than
`1/max |D_0|`. For each nonroot subset, the two nearby stability weights
are

\[
 \theta_\pm(S)=\Delta\pm\epsilon D_0.\tag{4.2}
\]

They are generic. Their root weights are respectively
`-epsilon k kappa` and `+epsilon k kappa`. Both admit a strictly positive
flow: put a sufficiently small positive amount on every mixed arrow and
supply the remaining vertex demands through the root arrows.

Scaling every particle by `T^epsilon` identifies the whole central
Gale solution algebra with the positive-arrow factor for `theta_+`.
Scaling by `T^(-epsilon)` identifies the core with the positive-arrow
factor for `theta_-`. The reverse identifications retain the entire
Artin local factors: positivity gives integral multiplication operators,
and their topological nilpotence makes evaluation factor through the
corresponding completed algebra. The valuation estimate in Section 3
excludes any omitted or additional central solutions.

For completeness, the generic cut/Rees input is as follows. Let
`L=im(partial^*)` be the saturated graph-cut lattice in `Z^E`. The
weight initial ideal of its lattice ideal, at generic stability, is the
forbidden outgoing-cut Stanley--Reisner ideal. Its faces have complements
containing a stable tree. The associated simple flow-polytope complex is
Cohen--Macaulay. After substituting nonzero-gain edge forms, every rooted
tree minor remains nonzero, so the kernel of the gain-incidence map is a
regular linear system of parameters. Completing the Rees family at its
positive arrow ideal and imposing these linear relations gives a finite
free `C[[t]]` algebra, after clearing the denominator of `epsilon`.
Its special fiber is exactly the generic gain cut algebra. Its generic
fiber is precisely the full positive-arrow factor: continuity of all
positive-valuation Artin multiplication operators proves the full-factor
assertion in both directions.

The `G_k` action preserves the orientation, stability, and gain packets.
The equivariant Koszul formula of Section 10 of the companion report
therefore identifies the gain and ordinary cut characters. Consequently

\[
 [B_{\rm gain}(P,Q,k)]=[B_{\rm raw}(P,Q,k)],\qquad
 [C_{\rm gain}(P,Q,k)]=[C_{\rm raw}(P,Q,k)]
 \quad\text{in }R(G_k).\tag{4.3}
\]

This is an equality for whole generic framed objects. It does not use an
isogeny-invariance assertion for singular IH.

## 5. Core/attached separation with gain packets

Fix `r+l=k`, label `r(a,b)` particles `x_i,y_j` as core and
`l(a,b)` particles `u_alpha,v_beta` as attached. Introduce `s` and
replace each mixed core/attached factor in both endpoint equations by

\[
 \Phi(sx_i,v_\beta),\qquad \Phi(u_\alpha,sy_j).\tag{5.1}
\]

The same factor is used in its two endpoint equations; hence cancellation
in every cluster quotient remains exact.

Take the horizontal saturation of these equations and localize at the
product of all attached coordinates, all cross factors in (5.1), and
all `F_k(x_i),F_k(y_j)`. Every special support point then has zero core
coordinates and nonzero attached coordinates in the finite root set of
(3.4), uniformly in `s`. Indeed any nonzero cluster inside either family
is balanced, since the cross factors are units. Interactions of a core
center `c` with an attached center `d` appear as
`(s^ell c-d)` and `(d-s^ell c)` to equal balanced powers; their quotient
is only a sign. Thus the derivation of (3.3) is unchanged. The factors
`F_k` exclude nonzero centers from the core.

On this reduced support, the localization denominator is independent of
`s` and has only nonzero constant values. The special algebra is finite
over `C[s]`: each coordinate and inverse denominator satisfies a monic
polynomial with constant coefficients modulo the nilradical, and a power
of that equation kills the nilpotent error. Its `T`-adic completion is
therefore finite over `C[s][[T]]`.

### The needed family lemma

After inverting `T`, this completed selected algebra is a direct factor
of the original square polynomial system. One can verify this without
assuming flatness: the completion map after extending coefficients to
`C[s][[T]]` is flat, and finite basis lifts make it surjective; its
finitely generated idempotent kernel defines a direct factor.

The base `S=C[s][[T]][T^(-1)]` is a connected regular one-dimensional
ring. At each local point, the selected system has `N` equations in `N`
variables over a DVR localization of `S`; finiteness of the closed fiber
makes these equations together with the base uniformizer a system of
parameters in a regular local ring. They form a regular sequence. The
uniformizer is consequently a nonzerodivisor after the equations, so the
finite module is locally free over `S`. Every finite-group isotypic
summand is locally free of constant rank. Evaluation at `s=0,1` gives
the same character.

The endpoint factors are exactly the prescribed core/attached sectors.
For a full Artin factor with these valuations, all particle operators
and the inverted denominator are integral, and the core operators are
topologically nilpotent. Their operator algebra factors through the
completion. Conversely, finiteness and the selected special support force
precisely these valuations. This verifies the full-factor condition,
including nilpotents, rather than only counting geometric points.

### At the decoupled endpoint

At `s=0`, the attached framing changes to

\[
 P'=P+mrb,\qquad Q'=Q+mra,\qquad P'a-Q'b=\kappa.\tag{5.2}
\]

Both new exponents retain the required divisibilities. There is a small
sign which must be kept: the standard second attached equation acquires
the constant right-side factor

\[
 (-1)^{(m/\ell-m)ra}.\tag{5.3}
\]

It is harmless for the character, but is not silently identified with
one. More generally, any pair of constant nonzero target units can be
removed by scaling all particles by one nonzero scalar and rescaling
`T`. The exponent matrix has determinant `kappa`, so this is an isogeny
of the two-dimensional complex torus and is surjective. Such a scaling
commutes with all particle permutations and phases and preserves the
valuation sectors. No canonical choice of a `kappa`-th root is required
for a character equality.

The core equations receive two units which are symmetric functions of
the attached particles. To separate them scheme-theoretically, first
replace them by independent invertible parameters `c_A,c_B`. The cut
lattice `L` is saturated, so the resulting unit character of `L` extends
to an integral Laurent-monomial character of `Z^E`. The twisted Rees
ideal therefore still has the same monomial initial cut ideal. Leave the
gain linear forms unchanged. Regularity modulo `t`, followed by the
complete-basis lifting argument, gives a free module

\[
 C_{\rm gain}(P,Q,r)\otimes
 \mathbb C[c_A^{\pm1},c_B^{\pm1}][[t]]\tag{5.4}
\]

with the natural group action. Averaging basis lifts over the finite
phase/permutation group makes this module identification equivariant.
The completed positive factor is an actual idempotent direct factor,
so (5.4) and its full-factor interpretation survive arbitrary base
change of the unit parameters into the attached algebra. The attached
permutation group fixes these two units, giving the ordinary tensor
product action. This argument uses the saturated graph lattice, and
requires no normalization of a ramified semigroup curve.

We obtain the induced-character identity

\[
 [B_{\rm gain}(P,Q,k)]
 =\sum_{r+l=k}\operatorname{Ind}_{G_r\times G_l}^{G_k}
   \left([C_{\rm gain}(P,Q,r)]\otimes
   [D_{\rm gain}(P+mrb,Q+mra,l)]\right).\tag{5.5}
\]

The summands are the actual sectors specified by the zero-coordinate
labels, transported through the family. The identical proof gives
(5.5) for the ordinary system. The constant-unit sign in (5.3) is removed
by the equivariant scaling just explained.

## 6. Character comparison and phase descent

Prove (2.2) simultaneously for all admissible positive framings by
induction on `k`. At `k=0` it is immediate. In (5.5), the `r=0` term is
`D(P,Q,k)`. Every other attached degree is smaller than `k`; the shifted
framings remain admissible. Their gain and ordinary characters agree by
induction, while both `B` and all `C` characters agree by (4.3).
Subtracting these established identities proves (2.2).

This subtraction occurs only in the proof of the comparison. The object
`D_gain` was defined independently as a full finite factor in Definition
1.1; no virtual difference is used to define it.

Finally, `Q[x,y]` is finite free over `Q[u,v]` with bounded-monomial basis
`W`. Flatness shows that both `T`-saturation and specialization commute
with this base change. The final saturation by the product of particles
also commutes: powers of the root-variable product and of its invariant
power have the same localization. Hence

\[
 D_{\rm gain}=D_{\rm val}\otimes_{\mathbb Q[u,v]}\mathbb Q[x,y].
\]

Taking phases recovers `D_val`, and the bounded monomial basis gives
(2.1). A permutation cycle contributes exactly `d_A` or `d_B` fixed
basis monomials, proving (2.3). On the attached factor all particle
coordinates are units, so this is moreover an actual finite etale phase
torsor in characteristic zero. This is stronger than divisibility of its
dimension.

## 7. Young positivity of the actual descended algebra

The generic attached factor of (1.3), over `Q((T))`, is a full finite
factor of a square polynomial map equivariant under permutations within
each coordinate color. Such a factor has a Young permutation character.
Here is the relevant algebraic reason.

Perturb the equation at a variable `u_i` by one common polynomial
`p_A(u_i)` for that color, and similarly by `p_B(v_j)`. On each
coordinate-equality stratum, value interpolation makes the block
constant equations transverse, while first-derivative Hermite
interpolation makes the Jacobian nonzero on each repeated-block standard
representation. There are finitely many equality strata, so a generic
choice makes the full zero scheme reduced and finite. Isolate the
original selected factor by an invariant polynomial lift of its
idempotent, and complete the perturbation along that factor. The square
system plus perturbation parameter is a regular sequence locally; hence
the selected deformation is finite free. Its special and generic group
characters agree.

The reduced generic fiber is a finite set of coordinate tuples. A tuple
stabilizer is exactly the product of symmetric groups on its equal-value
blocks within each color. Its permutation module is therefore induced
from a Young subgroup. This proves assertion 4. Finite freeness of the
original `T`-family transfers the character to the rational special
algebra `D_val`.

This gives a positive representation, but not a canonical graded
monomial basis or a theorem identifying singular toric IH with a zero
scheme. Those assertions are not needed here.

## 8. The ambient normal index

When the two inputs are mapped to original charges `beta_A,beta_B`, let
`d_A` and `d_B` divide all weighted coordinates of the respective charges.
Then `kappa=gcd(d_A a,d_B b)` divides every weighted coordinate of
`S=a beta_A+b beta_B`. In particular

\[
 \kappa\mid d(S)=\gcd_i D_i S_i.\tag{8.1}
\]

The two-input integral normal `D S/kappa` equals
`(d(S)/kappa)` times the primitive ambient normal `D S/d(S)`.
Accordingly a wall function expressed with the former normal becomes
its positive integer power `d(S)/kappa` with the latter. This is a
normal-vector calculation; the direction of the power is explicit.
Positive integer powers can be implemented by ordered products and
induction of the coefficient modules.

This interface does not justify replacing an existing original-label
center algebra by one new simple particle. Such a categorical compression
would require an additional theorem. Polynomial-functor substitution
can retain the input label modules, and the separate KLR project is
constructing compatible full-word central projectors.

## 9. Exact verification and scope

`computations/valued_polyhedral_mechanism/gale_valued_checks.py` verifies
12,000 primitive-slope inputs, using vertex weights up to 24, slope
coordinates up to 11 and multiplicities `k` up to 8. It checked every
subset for these inputs: **11,304,916** exact sign/nonvanishing identities,
plus **54,334** uniform-center parity and framing-shift identities, all
passed. The largest tested subset cardinality was 168.

A second part formed **108 actual localized attached ideals** for one
particle of each color, using vertex weights 1--6 and mixed packet
multiplicities 1--3. Groebner bases and standard-monomial counts gave the
predicted dimension `m/lcm(d_A,d_B)` in all cases. The ideal was supplied
from the equations and saturation, not from the expected dimension.
These tests check the new arithmetic and ramified algebra operations;
the all-degree proof is Sections 3--7.

The remaining wall interface is precise: prove or independently import
that the ordinary attached `D_raw(P,Q,k)` with `Pa-Qb=kappa` gives the
corresponding two-input wall-function power, with the required alphabet
and sign conventions. The ordinary determinant-one case is the audited
interface in Tang's Sections 7--8; the arbitrary determinant case should
be derived from the framed wall-crossing calculation, not silently
assumed. Once that interface is established, (2.1)--(2.3) supply an actual
valued module for the complete two-input reordering coefficient, including
the mixing across flow-tree presentations that local scalar division
cannot provide.
