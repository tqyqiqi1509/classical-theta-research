# Ordinary slots on framed spines and positive local fusion transport

2026-11-13, 15:42--16:02 research continuation.

This note proves two general local mechanisms toward a binary theta
associator. It does not assert that arbitrary event flags have been
matched. The latter requires routing the local moves through the
actual causal catalogs, not merely comparing their coefficient sums.

## 1. Every framed singleton factory is an ordinary slot word

Use unit symmetrizer entries at all added framing vertices. Let alpha
be unframed and let beta have only zero/one framing coordinates, with
at least one coordinate equal to one. A cutoff of one at each such
frame forces any occurrence of this beta carrier to be used only once.
This is a statement about a framing coordinate, not about an arbitrary
marked leaf hidden inside a nonlinear packet.

Put d=w(alpha), m=K(alpha,beta)>0 and Q=m/d. Because a framing
coordinate of beta is one,

    w(beta)=w(a alpha+beta)=1  for every a>=0.

For a>0 the singleton factory parameters are

    v=m=d Q,       P=a v=a d Q,
    ell=gcd(P,Q)=Q,       c=1.                         (1.1)

Choose the Bezout coefficients lambda=0, mu=1. The cyclic phase
action of `SINGLETON_CYCLIC_PHASE_AND_ATOM_SPLITTING.md` becomes

    (word,phi) -> (RotateLeft(word,1),phi-1 mod Q).   (1.2)

Therefore every orbit has a unique representative with phase zero.
If the actual grading has strip residue s and normalized slot word
x, its phase is phi=Q-1-s. Rotate x left by phi and divide every
grade by m. Retain each coefficient decoration in its rotated slot.
The result is an **arbitrary ordered Q-slot word** in the coefficient
sets of F, with total degree a:

    actual framed singleton factory at a alpha+beta
                 <-> [t^a] F(t)^Q.                  (1.3)

The right-hand side denotes the actual Cauchy-product set. It is not
a coefficient-sized placeholder. The inverse is the proved cyclic
normal cut and actual edge reconstruction. Explicitly, for a degree
word y, take the first maximum of Q Y_k-a k at k=1,...,Q, rotate
there, and set s=Q-1-((-k) mod Q). The grade in a slot of degree j
is m j. The original beta decoration is untouched. For a=0 use the
single inherited beta object and the all-empty slot word.

If the inversion puts beta first and alpha second, reverse the path
orientation and interchange the two edge colors before applying the
same statement. The number of slots is then |K(alpha,beta)|/d.

### Consequence for the entire framing spine

In a one-frame recursive object, exactly one child at every ancestor
contains the frame. The other children are unframed. At a rank-two
event plane, its intersection with framing degree zero is a single
rational ray. Thus a whole active framed birth is a singleton factory
with one arbitrary unframed incoming ray packet. Formula (1.3)
replaces every such Dyck node by its literal ordered slots.

The same conclusion applies to the trunk after the unique fusion in
a two-frame object: its carrier has frame profile (1,1), still with
normal content one, and it can be used only once. At the fusion itself
the two parents have disjoint frame profiles (1,0) and (0,1). They
must both occur once, so the fusion factory is its first binary
coefficient and has exactly K(beta_1,beta_2) actual edge residues.

Consequently a two-frame object has two ordinary slot-decorated
framing branches, one genuine first-coefficient fusion residue, and
an ordinary slot-decorated trunk. All unframed child objects retain
their existing finite Dyck constructions. This is an actual encoding,
not only an equality of its enumerator with a power series.

## 2. A positive one-wall fusion identity for every sign pattern

Fix one unframed ray alpha with coefficient-set packet F. Let
beta=beta_1+beta_2 be the framed fusion charge. Define the signed
integer wall exponents

    q_i=K(alpha,beta_i)/w(alpha),     q=q_1+q_2.

Write z_+=max(z,0), z_-=max(-z,0). There is a literal natural
bijection of positive slot sets

    F^[q_+] x F^[(q_1)_-] x F^[(q_2)_-]
          <->
    F^[q_-] x F^[(q_1)_+] x F^[(q_2)_+].              (2.1)

Here F^[r] means r ordered coefficient slots, including empty slots,
with the total degree retained. The lengths agree because

    q_+ +(q_1)_- +(q_2)_-
      =q_- +(q_1)_+ +(q_2)_+.

The map concatenates the slots in the displayed order and cuts the
same list into the displayed blocks on the other side. This preserves
every coefficient decoration, its degree, and any external labels.
The inverse is the opposite regrouping.

For q_1,q_2>=0, it simply splits the outgoing trunk's q slots into
blocks of lengths q_1 and q_2. If q_1>0>q_2 and q>=0, it is the
positive identity F^[q] x F^[-q_2] <-> F^[q_1]. No negative-power
coefficient series or subtraction is involved. The remaining sign
patterns are included in (2.1).

Adding multiples of alpha to any beta_i does not change q_i. Thus
the same block lengths remain valid while arbitrary degrees and
decorations on this one wall are redistributed. Through (1.3), this
is a local bijection of actual framed Dyck factories on the two
oriented sides of that wall. It is the set-level positive form of
the Leibniz rule needed to move a marked fusion through one wall.

Equation (2.1) includes the factors on the appropriate two sides of
the wall. It does not license deleting an unwanted factor from a
single endpoint catalog. A global transport must identify those
factors with actual adjacent pieces of the framing branches/trunk.

## 3. A fusion-growth-compatible valued ABC rectangle

The previously constructed ABC move can be chosen to commute with
adding one extra fusion residue. This gives a second, independent
actual-object check on the local splitting in Section 2.

Take the first two inputs to be the two framed carriers and the third
to be one unframed decorated carrier u. Put

    w(beta_1)=w(beta_2)=1,       w(u)=d,
    p=K(beta_1,beta_2),
    K(beta_2,u)=d q,            K(beta_1,u)=d r,

with q,r>0. Assume p>=d q, as holds at a sufficiently large framing
parameter in any fixed finite charge cutoff. The actual history
coordinate spaces are

    L1: [0,p) x [0,q+r),
    R1: [0,q) x [0,p+d r),
    R2: [0,r) x [0,p-d q).

The second left rectangle is empty. These rectangles follow directly
from the binary edge-residue lemma: the inner/outer pairings are
(p,d(q+r)), (d q,p+d r), and (d r,p-d q), respectively, with input
contents (1,1) or (1,d). Every intermediate and final carrier contains
a frame coordinate equal to one, so all normal-copy counts are one.
No common-plane Smith lemma is needed. In particular this statement
about two-level factory sets is valid when the three carriers are
linearly independent. It does not assert that those sets already
exhaust a rank-three event-flag change.

The following map is explicit:

    L1(i,j), j<q
        -> R1(j, i+d r);
    L1(i,j), j>=q and i<d q
        -> R1(floor(i/d), d(j-q)+(i mod d));
    L1(i,j), j>=q and i>=d q
        -> R2(j-q, i-d q).                            (3.1)

Its inverse is:

    R1(i,j), j>=d r -> L1(j-d r,i);
    R1(i,j), j<d r  -> L1(d i+(j mod d),q+floor(j/d));
    R2(i,j)         -> L1(j+d q,i+q).                 (3.2)

The first piece covers the upper strip [d r,p+d r) of R1. The second
covers its complementary prefix [0,d r); the third covers all of R2.
Thus (3.1)--(3.2) are inverse, including boundary integer points.
Composing them with the previously proved edge-residue carries gives
the map on literal Dyck positions and their original decorations.

Most significantly, these formulas contain **no p**. Hence they
strictly commute with the natural inclusions obtained by increasing
p to p+1 and retaining every old edge-residue coordinate. The new
source points are

    i=p,              0<=j<q+r.

They map to the new fusion positions on the right:

    j<q:        R1(j,p+d r),
    j>=q:       R2(j-q,p-d q).                        (3.3)

The marked new fusion label therefore splits its q+r attachment
choices into q and r choices, exactly as an ordinary slot cut. A
naive use of the earlier rectangle placement would put the first
image at an interior fusion index. Moving R1's common strip to its
upper end is what makes growth commute literally.

This applies to an arbitrary coefficient decoration on charge j alpha:
its normal content is j w(alpha), and both pairings scale by j, so
q and r in (3.1) do not change. A sufficiently large framing parameter
simultaneously covers all such j in a fixed degree truncation.

## 4. The remaining global associator interface

For arbitrary endpoint U, the desired positive substitution map is

    disjoint union_(a+t=v)
       C_(g1,g2)(a) x O(g1+g2+B a,t;U)
          <->
    disjoint union_(r+s=v)
       O(g1,r;U) x O(g2,s;U).                         (4.1)

The charge contraction is exact: the fused charge e_0+e_1+a has
normal content one and unframed pairing row

    K(e_0+e_1+a,e_i)=-D_i(g1+g2+B a)_i.

Thus the outgoing branch in the left side of (4.1) is precisely an
ordinary framed spine of Section 1. Sections 2--3 provide genuine
positive local rules for redistributing its unframed attachments
through a marked fusion.

What is still needed is a finite sweeping/routing construction that
matches the **actual** event addresses, chooses the next wall without
a coefficient oracle, and proves that the redistributed branch flags
are those of the canonical inner endpoint
U_a=D(g1+g2+B a)+epsilon. The endpoint U_a is generally not a radial
perturbation of U. The radial catalog lemma therefore does not supply
this step. Nor does a common numerical expansion of the two sides.

In particular, slot regrouping for one fixed wall has no unresolved
phase or sign problem. The outstanding issue is its compatibility
with the order and causal side of several different wall/event
packets, especially when moving the fusion changes a rank-three flag.
The present results give new local ingredients for that task but do
not establish the binary associator or its pentagon.

## 5. Exploration record

* The first attempted extension of the marked-atom carry to an
  arbitrary outer singleton slot word was rejected by an actual
  collision. Exact data are retained in
  `computations/singleton_series_composition_probe.json`. The marked
  atom theorem is unaffected: its unique marker removes precisely
  this outer periodic-word ambiguity.
* The framing constraint removes that phase obstruction completely:
  every carrier on a genuine framing spine has normal content one.
  This yields Section 1 for the whole framing spine, in all degrees.
* Mixed signs were treated by the positive balanced identity (2.1),
  not by asserting that negative powers have positive objects.
* The first ABC placement was adjusted to (3.1), producing literal
  compatibility with the framing-parameter inclusions. This is a
  general valued family and an exact local fusion-label transport.
* A global proof of (4.1) was not obtained in this interval. The new
  local identities do not by themselves justify changing the event
  catalog or eliminating an inherited packet.

## 6. Compressed slot recipes and a literal inverse, both orientations

Implementation completed and independently checked at 16:09 UTC.
The integrated module is `computations/fast_framed_spine.py`;
the independent inverse is
`computations/framed_spine_literal_inverse.py`. Neither definition
calls a cardinality oracle or scans the Q slots. The ambient simplex

    0 <= s_1 < ... < s_k < Q

is itself the occupied-position set. Its decoration consists of a
positive degree composition (u_1,...,u_k) of t and one original
unframed coefficient object of degree u_j at each occupied position.
The original framed coefficient object is retained separately.
Thus definition size depends on the degree and input recipes; huge
edge-pairing numbers remain integer bounds, not enumerated lists.

The precise substitution in a positively ordered pair (alpha,beta),
K(alpha,beta)=m, is as follows. If alpha is framed and beta has normal
content d, the only allowed new rays are alpha+t beta, at coefficient
degree one, with object set

    F_(alpha,1) x [z^t] G_beta(z)^(m/d).

If beta is framed and alpha has normal content d, they are
t alpha+beta, again at coefficient degree one, with object set

    [z^t] F_alpha(z)^(m/d) x G_(beta,1).

These statements permit nonprimitive unframed carriers. If both
inputs are framed with disjoint frame supports, only alpha+beta
fits the frame cutoffs; its local object is an edge residue in
[0,m) with the two original coefficient decorations. Overlapping
framing supports produce no birth at cutoff one.

### 6.1 Framed input on the right

Write Q=m/d and t=sum_j u_j>0. The original minimal determinant-one
rectangle is

    W=t d(Q+1)-1,      H=Q+1.

For the full degree word y, put Y_k=sum_(s<k) y_s. Choose the first
maximum of Q Y_k-t k among k=1,...,Q. Only the candidates
k=s_j+1 and k=Q need inspection, since the height decreases through
every empty interval. Set

    phi=(-k) mod Q,       r=Q-1-phi,
    i=H^(-1)(W-Q+r) mod W,       y0=floor(H i/W),

with i=0 when W=1. Here and below an edge index is zero based
within its color. The unique positive horizontal edge is i,
with grade Q and the framed decoration. Occupied slot s_j becomes
vertical edge

    (y0+1+((s_j-k) mod Q)) mod H,

with grade m u_j and its unchanged unframed decoration. The sole
normal copy is number zero. This is exactly the cyclic normal cut
of Section 1, evaluated sparsely.

The inverse recovers r=(H i mod W)-(W-Q), phi=Q-1-r, and y0.
For a positive vertical edge v, its normal slot is
j=(v-y0-1) mod H, necessarily less than Q. Its original occupied
position is (j-phi) mod Q, and its degree is its grade divided by m.
Thus even periodic degree words and repeated decorations are handled
without choosing an ordering among coefficient objects.

### 6.2 Framed input on the left

The minimal rectangle now is

    W=Q,       H=t m+1.

Slot s_j is already the corresponding horizontal edge: place grade
m u_j there, with its unchanged decoration. There is one positive
vertical edge, of grade Q, carrying the framed decoration. Its
one-based index is

    floor(H i/Q),

where i is the smallest minimizer on {1,...,Q} of

    nu_i=m Y_i-t d i-1_(i=Q).                         (6.1)

To evaluate (6.1), it suffices to inspect i=s_j>0, immediately before
each occupied horizontal slot, together with i=Q. The height strictly
decreases through a run of unoccupied slots. At i=Q it equals -1.
The choice of the first minimum includes the equality boundaries.

For completeness, this formula follows directly from the horizontal
cyclic stack. Its positive E-edges push H-1 unit tokens in total;
the H vertical edges each pop one token. Exactly one vertical edge
is unmatched. The cyclic stack's cut after the first global minimum
locates it. Between two horizontal edges the height decreases, and
after the vertical block following horizontal edge i the height is
exactly (6.1), because

    floor(H i/Q)=t d i+1_(i=Q).

The positive vertical edge of grade Q has all Q horizontal edges
in its reverse shadow. Compatibility therefore forces it to be the
unique vertical edge absent from the horizontal shadow union; and
placing it there gives compatibility and tightness. This proves
existence and uniqueness for every horizontal degree word. The
inverse simply reads the occupied horizontal positions and divides
their grades by m.

### 6.3 Fusion and inherited objects

For two framed inputs, the rectangle is (m,m+1). A residue s in
[0,m) gives the horizontal edge s of grade m, carrying the right
input decoration, and vertical edge (s+m) mod (m+1) of grade m,
carrying the left input decoration. This is the ordinary first
binary residue correspondence with normal-copy count one.

The zero-degree empty word represents the inherited framed input.
It is not assigned a positive-birth Dyck rectangle.

### 6.4 Independent computation and integration check

`computations/framed_spine_literal_inverse.json` records:

* 3,640 decoration-preserving sparse/Dyck round trips, over Q=1,...,6,
  d=1,...,4 and t=1,...,4, in both orientations;
* equality with 182 complete independently enumerated literal object
  sets, comprising 121,072 candidate gradings;
* all 171 first-binary fusion residues for m=1,...,18;
* 24 integrated valued/nonprimitive input comparisons, each in three
  output degrees (72 coefficients), between the new global subclass
  and the original literal Dyck factory;
* both sparse inverse orientations at Q=10^50, with three occupied
  slots and opaque decorations, without a Q-length or path-length loop.

The integrated comparisons include unframed normal contents 2,3,4,6,
both primitive and nonprimitive input carriers, and independent
coefficient sets in degrees 1,2,3. Cardinality is queried only after
each actual-set recipe is fully constructed. This implementation
result concerns local representation and its global substitution;
it does not change the unresolved associator statement in Section 4.

`computations/fusion_growth_bijection.py` checked 4,608 parameter
choices, 1,114,560 complete rectangle points, 41,472 new-fusion
boundary points, and 10,000 actual edge-level growth comparisons.
All inverse, image, and inclusion comparisons passed. The tests use
the literal binary edge-coordinate maps; the proof is (3.1)--(3.3).
The independent reviewer checked the framed ordinary-slot reduction,
the all-sign positive slot regrouping, and every forward/inverse
piece of (3.1)--(3.2). The reviewer also confirmed that p does not
occur in these formulas, so the framing-growth inclusions commute
strictly. This endorsement is local; no global associator is inferred.

### Latest primary-source check

At 15:54--15:56, the relevant primary section of
Burcroff--Lee--Mou, arXiv:2503.03719v1, was reopened:
<https://arxiv.org/html/2503.03719v1>, Section 5.5.
Lemma 5.31 removes a final bend and computes its weight; Lemma 5.33
uses equality of the theta coefficient at two endpoints; Proposition
5.34 compares recursions. These are useful enumerative identities,
but that argument does not supply the missing natural event-catalog
rerouting in (4.1). We therefore do not import it as an actual-object
associator. The 2026 Hexagon paper 2611.00238v1 was also inspected for
this interface; its introductory comparison accurately points to those
BLM recursion arguments, while its later attached-algebra construction
does not itself furnish the desired Dyck-data map. No unreviewed 2026
claim is used in Sections 1--3.

The remaining obstruction can be located more precisely than a sign
problem: when a framing endpoint crosses a single unframed wall,
downstream projected child flags can also change at a rank-three
collision involving a second, nonparallel unframed ray. Ordered
F-slots settle one fixed ray; they do not identify the coefficient
decorations of two differently ordered unframed ray packets. A
general positive two-ray action/crossing construction is therefore
still needed before a wall-by-wall fusion sweep is justified.
