# Local flow modules: the full Young-permutation upgrade

Branch `/root/local_permutation_upgrade`, begun 2026-11-13 12:52 UTC.
Only classical cluster algebras are targets. No Li–Pan conclusion is used.
This note supplements the proved arbitrary-skew fan/tableau construction.

**Final branch status, 2026-11-13 13:48 UTC.** The singular interface is
closed. The graph-defined parity-corrected primitive Gale scheme is finite,
its full ungraded character equals the local fan/IH character, and its
coordinatewise Hermite deformation gives an actual Young-permutation set.
The final proofs are
`../proofs/PRIMITIVE_CENTER_GALE_FINITE_MODEL.md`,
`../proofs/GALE_DEGREE_AND_CYCLE_TORI.md`, and
`primitive_center_ih_bridge.md`. Sections 1–6 below preserve the earlier
smooth theorem, literature audit, and corrected failed approaches; §7 records
the final handoff. No algebraic-point set is called a polytope lattice-point
set here.

## 1. Positive result obtained in this branch

**Theorem (smooth flow fans have a Young-permutation model).**
Let (Q=(V,E)) be a finite connected acyclic directed multigraph, with the
anti-attractor flow polytope

\[
P=\{f\in\mathbb R_{\geq0}^E:\partial f=\partial\mathbf1\}.
\]

Let (G=\prod_c S_{n_c}) act by permuting equal-charge vertices, with the
incidence-compatible arrow action. Suppose the normal fan of (P) is smooth.
Then its ungraded reduced global fan module (L_P) is a Young-permutation
representation. A finite (G)-set realizing it is obtained from explicit
Gale equations followed by bounded-degree coordinatewise perturbations.
No theta coefficient, prescribed character, or Specht multiplicity enters
the definition of the point set.

The hypothesis is smoothness of the normal fan, not necessarily genericity
of the original supply. Generic supply implies smoothness by total
unimodularity, but some nongeneric supplies also have smooth fans.
The construction below handles repeated coordinate rays and bridge arrows.

This smooth theorem alone does not cover singular local flow fans. The
additional full-character identification needed there is now supplied by the
primitive-center construction and cycle-cumulant proof named above. Sections
5–6 retain the precise earlier interface and the diagnostics that prevented
an incorrect generic-mirror argument.

## 2. Input-only construction of the finite set

Use the incidence convention \(\partial(e_{i\to j})=e_i-e_j\). Put

\[
N=\mathbb Z^E/\partial^T\mathbb Z^V,
\qquad v_e=[e]\in N,
\qquad M=\ker(\partial:\mathbb Z^E\to\mathbb Z^V).
\]

The incidence matrix is totally unimodular, so (N) is a lattice. The
all-one flow is interior and acyclicity gives boundedness. Delete the
zero-dimensional case separately: its module and point set are both one
point with trivial action.

### 2.1 A support-function deformation

Compute the normal fan \(\Sigma\) of (P), its distinct primitive ray
generators (v_\rho), and a positive integral (G)-invariant strictly
convex support function \(\phi\). One can obtain \(\phi\) by translating
an integral multiple of (P) to contain zero and summing its (G)-translates.
No cohomology calculation is needed for this step.

Construct the explicitly presented algebra

\[
R_\Sigma=\bigoplus_{u\in N}\mathbb Q[t]X^u,
\quad
X^uX^w=t^{\phi(u)+\phi(w)-\phi(u+w)}X^{u+w},
\]

and quotient it by

\[
\theta_m=\sum_\rho\langle m,v_\rho\rangle X^{v_\rho},
\qquad m\in M.
\tag{2.1}
\]

Only a basis of (M) is required. This is finite presentation data: in the
smooth case the (X^{v_\rho}) generate, and the defining ideal is obtained
by eliminating Laurent variables from
\(X_\rho=t^{\phi(v_\rho)}z^{v_\rho}\).

At (t=0), the ring is the Stanley–Reisner ring of the smooth fan and
(2.1) is its usual linear parameter system. The quotient special fiber is
the reduced global fan module, with its natural (G)-action. Near this
fiber, isolate the finite flat component, using completion or an elementary
étale neighborhood. Denote the resulting finite flat algebra by \(A^\circ\).
Selecting this component matters: unrelated solutions may escape to
infinity or occur away from the special fiber.

All of this can be performed with standard bases, finite algebra
factorization, and Hensel lifting. It is an algebraic algorithm, not an
efficient complexity bound.

### 2.2 Express the selected mirror factor in vertex coordinates

Choose a nonzero algebraic specialization (t=t_0) in the finite flat
neighborhood. Its selected algebra is a finite factor of the critical
scheme of

\[
W(z)=\sum_\rho t_0^{\phi(v_\rho)}z^{v_\rho}
\quad\text{on}\quad T=\operatorname{Spec}\overline{\mathbb Q}[N].
\tag{2.2}
\]

For an edge (e) whose coordinate class equals (v_\rho), let
\(k_\rho=\#\{e:v_e=v_\rho\}\) and put
\(c_e=1/k_\rho\). For a zero coordinate class choose (c_e=1).
Thus summing \(c_ez^{v_e}\) over edges gives the distinct-ray potential,
plus constants. The following elementary observation justifies using all
edges even when the supply is nongeneric.

**Coordinate-ray lemma.** Every nonzero (v_e) is primitive and, after
identifying duplicate columns, is a vertex of \(\operatorname{conv}(v_f)\).
Indeed, a fundamental-cycle basis presents the quotient classes by a
totally unimodular cographic matrix (V). If (v_e\ne0\) lay in the convex
hull of other distinct columns, minimize \(\sum_f\lambda_f\) subject to
\(V\lambda=v_e,\lambda\ge0\), using those columns. Total unimodularity
makes its finite optimum integral; it is positive and at most one, hence
one. Every vertex of its minimizing face is an integral vector of sum one,
so it selects a column equal to (v_e), a contradiction. Primitivity also
follows directly from an undirected cycle through a nonbridge edge, whose
circulation has coordinate (+1) or (-1) on that edge. Translating (P)
by the all-one flow identifies its polar with the convex hull of these
classes, up to the harmless global normal-sign convention. Thus the
nonzero distinct coordinate classes are exactly the fan rays.

Set

\[
z_e=c_e t_0^{\phi(v_e)}z^{v_e},\qquad
q_i=\prod_{e\text{ out of }i}
 c_e t_0^{\phi(v_e)}\bigg/
\prod_{e\text{ into }i}c_e t_0^{\phi(v_e)}.
\tag{2.3}
\]

The (q_i) are constant on vertex-color classes and \(\prod_iq_i=1\).
The map (T\to(\mathbb C^*)^E\) identifies (T) with the torus torsor
\(\delta(z)=q\), where \(\delta\) is multiplicative incidence.
The critical equations for (2.2) say

\[
\sum_ez_ev_e=0,
\]

so (z\) lies in \(\operatorname{im}\partial^T\). Consequently the
critical scheme is scheme-theoretically the Gale zero scheme

\[
z_e=u_{s(e)}-u_{t(e)}\ne0,
\qquad
\Gamma_i(u):=
\frac{\prod_{e\text{ out of }i}(u_{s(e)}-u_{t(e)})}
     {\prod_{e\text{ into }i}(u_{s(e)}-u_{t(e)})}=q_i,
\qquad \sum_i u_i=0.
\tag{2.4}
\]

The normalization removes common translation. These are equalities of
schemes obtained by linear elimination and the exact torus sequence, not
merely a bijection on reduced points.

### 2.3 An equivariant polynomial map with the same finite local factors

Put (m=|V|),

\[
D(u)=\prod_{e\in E}(u_{s(e)}-u_{t(e)}),\qquad
a_i(u)=\Gamma_i(u)/q_i,
\quad
\bar a=m^{-1}\sum_i a_i,
\quad \bar u=m^{-1}\sum_i u_i.
\]

Define

\[
F_i(u)=D(u)(a_i(u)-\bar a(u))+\bar u.
\tag{2.5}
\]

Every denominator in (a_i) divides (D), so (2.5) is a polynomial map
\(F:\mathbb A^V\to\mathbb A^V\). It is equivariant for the same
coordinate Young action on source and target.

Near a point satisfying (2.4), (D) is a unit. Summing (2.5) gives
\(m\bar u=0\). The remaining equations make all (a_i\) equal to one
number \(\lambda\). Since \(\prod_i a_i=1\), one has \(\lambda^m=1\).
The factor \(\lambda=1\) is separated from the other roots in
characteristic zero. Its full local scheme is exactly (2.4). Hence the
selected Rees algebra is a (G)-stable union of isolated full local factors
of (F^{-1}(0)), even though (F^{-1}(0)) may have other components on
\(D=0\).

### 2.4 Replace the finite algebra by actual coordinate tuples

For each color (c), choose a polynomial

\[
p_c(z)=\sum_{j=0}^{n_c-1} b_{c,j}z^j.
\]

Use the deformation

\[
F_{c,i}(u)+s\,p_c(u_{c,i})=0.
\tag{2.6}
\]

The coefficients (b_{c,j}) are chosen in the nonempty open set for which
the generic zero scheme is reduced and finite. This is an effective
selection: enumerate algebraic or rational tuples and test the Jacobian
and dimension by Gröbner elimination. Retain precisely the points whose
Puiseux limits lie in the selected full local factors from (2.4).
These points form the desired finite set \(S_P\).

Every stabilizer of a coordinate tuple is the product of the symmetric
groups permuting equal coordinates within each color. Thus \(S_P\) is a
disjoint union of Young coset sets. Its permutation representation is
\(L_P\), by the two finite-flat character comparisons.

This is a finite algebraic-point construction from the graph and fan.
It removes the local Specht-intertwiner calculation on its proved domain.
It is not yet an integer-point or parking-function realization, and it is
not being presented as one.

## 3. Why the coordinatewise perturbation works

For completeness, the only mechanism needed from Tang's 2026 paper is the
finite-zero-scheme lemma, not its cluster positivity conclusions.

Stratify coordinate space by within-color equality partitions. If a color
has (d_c) distinct values and (r_c) repeated blocks, then
\(d_c+r_c\le n_c\). Interpolation of degree at most (n_c-1) independently
prescribes values at the (d_c) blocks and derivatives at the (r_c)
repeated blocks. Values make the derivative in block-constant directions
surjective. Derivatives vary the scalar Jacobian on each sum-zero standard
representation. These standard summands belong to distinct stabilizer
factors, so they cannot mix. Excluding finitely many bad parameter loci
makes the entire Jacobian invertible at every zero.

The chosen finite local factors persist as a finite free algebra over
the deformation DVR. The equations and parameter form a system of
parameters in a regular local ring; permuting the regular sequence shows
that the parameter is a nonzerodivisor. Isotypic multiplicities are therefore
constant. At a reduced generic fiber, the algebra is the function algebra
of the actual coordinate tuple set. This proves the Young-permutation
claim without computing a character decomposition first.

## 4. Strong review of the newly found 2026 interface

**Gui–Qin–Shen–Xiong, arXiv:2609.06597v1 (2026-09-06),
Permutation Representations on Cohomology of Toric Varieties.**
Primary record and full HTML were read. Theorem 1.2 is explicitly restricted
to smooth projective toric varieties; it allows arbitrary finite lattice
automorphisms. Its proof's support-function deformation and local finite
flat factor are used in §2.1. They do not prove the singular IH case.

Audit of the needed steps: the zero fiber is SR only under smoothness;
regular-sequence permutation is used locally; the isolated finite flat
component is (G)-stable because the difference of two choices is finite
flat over a connected base with empty special fiber; the Laurent Jacobian
comparison is on the selected finite factor, so points are isolated.
No error was found in these needed steps. Roberts's real-action Morse
theorem is independently consistent with Montaldi 1993, §4, but §2.4 above
instead uses the more specific coordinate Young perturbation.

**Tang, Hexagon:2611.00238v1 (2026-11-10 record), Lemma 6.1.**
Read pp.16–17 in full. The Hermite interpolation bound, orbit-type Jacobian
factorization, and finite-flat completion argument support the lemma in
the stated isolated-full-factor scope. It is used only as that lemma.
The attached two-color wall algebra in that paper is not identified here
with the local primitive IH module.

**Reineke, arXiv:1511.08316, Theorem 4.3.**
Read the actual statement and proof. It applies to the present thin
anti-attractor data: stable locus nonempty, dimension vector indivisible,
and Euler form symmetric on the zero-stability subspace. Thus nearby generic
stabilities give small resolutions. This gives equality of dimensions,
and a character equality for a subgroup preserving the chosen resolution.
It does not give a full (G)-action on any chosen resolution when no
(G)-fixed generic chamber exists.

Primary sources:

- https://arxiv.org/abs/2609.06597
- https://arxiv.org/html/2609.06597v1
- https://hexagonmath.org/2611.00238v1
- https://hexagonmath.org/pdf/2611.00238v1
- https://arxiv.org/html/1511.08316v1
- https://eprints.maths.manchester.ac.uk/1415/1/Xpoints.pdf
- https://academic.oup.com/jlms/article-abstract/s2-31/3/487/788677

## 5. The original singular interface, now closed by the primitive center

For a singular anti-attractor fan, the task was to find a finite (G)-stable factor (Z)
of a graph-defined Young-equivariant map, together with a proof

\[
\mathcal O(Z)\cong L_P\quad\text{as ungraded (G)-representations}.
\tag{5.1}
\]

The all-lattice-point toric-face-ring degeneration does not automatically
have special fiber (L_P), and a chosen small resolution does not carry
the whole (G)-action. A numerical degree or total critical-point count
is therefore insufficient. A usable replacement must either isolate a
genuine primitive algebra factor by an idempotent, or produce a canonical
continuation action on the finite point sets of different chambers and
prove that action agrees with the minimal-extension action.

The existing RRT graph-cut theorem gives permutation models of the local
graph-cone stalks. It alone does not supply compatible restriction maps
or a positive set-level gluing of those stalks over the entire flow fan.

## 6. Route decisions and one diagnostic computation

The naive full mirror/ordinary equivariant Ehrhart bridge is excluded,
not adopted. For the (K_{3,3}) flow module, the existing exact fan
calculation has trace zero on a pair of three-cycles. In the polar lattice,
the nine ray vectors sum to zero, so the coefficient-one potential has a
(G)-fixed critical point at the torus identity. Its logarithmic Hessian is

\[
\begin{pmatrix}
4&2&2&1\\2&4&1&2\\2&1&4&2\\1&2&2&4
\end{pmatrix},\qquad \det=81.
\]

Thus counting all critical points with their ordinary coordinate action
cannot give this IH module. This is an interface diagnostic, not a proposed
construction by special examples. The determinant and the order-three
lattice action were independently evaluated by the actual Wolfram plugin.
The first Wolfram context call failed internally; the evaluator succeeded.

A naive unsigned torsion component of the (G)-fixed multiplicative parameter
torus was also considered. It gives an interesting candidate (18)-point
pattern for (K_{3,3}), but that rule has no general theorem: for (K_{2,2}),
its nontrivial component makes the potential identically zero, so the critical
locus is positive dimensional. The claim that this unsigned primitive
torsion rule automatically gives a finite generic zero scheme is false and
is discarded. This is distinct from the successful signed center: the
quadratic refinement and the outdegree sign change the row/column targets.

The intermediate core/attached direction required genuine idempotents, not
character subtraction. In the two-color k=2 test the whole attached factor
has length six, while the successful primitive-center factor has length two;
the other center carries proper semisimple content. The final theorem does
not identify a whole attached wall algebra with one local primitive module.

## 7. Final mechanism and handoff

For charges summing to (S=k alpha) with alpha primitive, choose integral
(f(alpha)=1), a quadratic refinement (q) of eta modulo two, and a primitive
k-th root (zeta). The successful target is

\[
 Q_v=(-1)^{\operatorname{outdeg}(v)+q(\beta_v)-f(\beta_v)q(\alpha)}
       \zeta^{-f(\beta_v)}.
\]

For every proper balanced subset of charge (h alpha), its target product
is the signed boundary product times (zeta^{-h}), hence misses that boundary
equation. A leading-valuation block argument proves the Gale map is finite
over this signed nonresonant open; its positive weighted Laplacian proves
dominance, and smooth source and target give flatness. This supplies an
actual finite full Artin scheme without a theta coefficient as input.

The general dimension lemma uses only cographic lattice ideals and linear
optimization. A generic positive flow gives a squarefree initial ideal whose
facets are stable-tree complements. Tree-complement minors make the cycle
equations a regular parameter system. A small common Puiseux scaling puts
every generic Gale root into the completed positive-arrow Rees factor, so
the whole degree equals the stable-tree count. The finite HN ordinary
logarithm identifies that count with the local fan dimension. Reineke's
older small-resolution theorem gives an independently checked geometric
confirmation, with no equivariant resolution assumption.

For a permutation with cycle lengths (l_i), put (g=gcd_i l_i). The independent
cycle-cumulant argument gives

\[
 \chi(\sigma)=\frac{\dim L_{\rm Fold}}{\prod_i l_i}
   \sum_{d\mid g}\mu(d)(-1)^{E-E/d^2}.
\]

The divisor factor is one for (g=1), two for (g=2) and odd (E/4), and zero
otherwise. The fixed Gale equations land in the connected torus
(product z_i^{l_i/g}=1); its power map to the ordinary folded target has
degree (product l_i)/g. The canonical target is compatible in exactly those
two nonzero cases. Finite flatness gives the same fixed-scheme lengths.
The Young square-map deformation identifies them with the traces of the
finite algebra. Thus the equality holds for every group element.

The Hermite perturbation supplies a genuine finite set of coordinate tuples.
Its stabilizers are products of symmetric groups on equal-coordinate blocks.
This permits the parent's global supertree recursion to use multisets on
even child slots and strict subsets on odd child slots, removing local
Specht intertwiners. The theorem is ungraded. A direct parking-function,
tree-decoration, or single-polytope integer-point realization remains a
separate next task; it is not concealed in the algebraic-point construction.

**Independent review completed.** Both branches checked the signed target,
the connected-torus isogeny, and the finite degree proof. This branch read
and recomputed every step of the other branch's HN refinement, transitive
block-orbit count, parity twist, Möbius inversion, and integral Fold/g
homogeneity argument. No unresolved proof step remained. Root also read
the complete chain and checked 135 nonidentity traces with the pre-existing
exact HN computation. These are normalization checks, not the proof.

**2026-source scope.** Gui–Qin–Shen–Xiong's smooth toric theorem was a useful
initial interface and is not extended to singular IH by citation. Tang's
coordinate Young deformation lemma was checked and reproduced; its final
cluster conclusions are not inputs. The final generic cut degeneration is
proved directly by TU/LP in our own degree note. The new full-character
primitive-center comparison is our independent argument from the already
proved local HN identities. No Li–Pan conclusion is used.

