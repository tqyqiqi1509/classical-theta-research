"""Independent rational Lie-log reconstruction for the incoming integer algorithm.

This deliberately uses rational Lie generators and matrix exponentials instead
of scalar integer coefficient recursion.  The two implementations may therefore
catch normalization and coherence errors in each other.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product, permutations
from math import factorial
from pathlib import Path
import sys, json, time, random
sys.path.insert(0, str(Path(__file__).parent))
from incoming_recursion import IncomingRecursion, IncomingSchur

def roots(n,K):
    return sorted((p for p in product(range(K+1), repeat=n) if sum(p)<=K),key=lambda p:(sum(p),p))

def le(p,q): return all(a<=b for a,b in zip(p,q))
def sub(p,q): return tuple(a-b for a,b in zip(p,q))
def pts(alpha): return sorted(product(*(range(x+1) for x in alpha)),key=lambda p:(sum(p),p))

class LieLog:
    def __init__(self,B,D):
        self.B=tuple(map(tuple,B)); self.D=tuple(D); self.n=len(D);self.zero=(0,)*self.n
        self.logs={};self.zero_residuals=0

    def shift(self,m,q):
        return tuple(m[i]+sum(self.B[i][j]*q[j] for j in range(self.n)) for i in range(self.n))

    def sign(self,a,b):
        # The independent choice reverses the auxiliary order.
        u=self.shift(self.zero,a)
        vals=[sum(u[i]*self.D[i]*b[i] for i in range(self.n))]
        r=max(i for i in range(self.n) if a[i])
        vals += [a[r]*b[i]-a[i]*b[r] for i in reversed(range(self.n)) if i!=r]
        return next((1 if v>0 else -1 for v in vals if v),0)

    def expmatrix(self,alpha,m):
        J=pts(alpha); N=len(J);C={(p,p):F(1) for p in J}
        # For each column, iteratively apply the Lie operator to its vector.
        for q in J:
            v={q:F(1)}
            for k in range(1,sum(alpha)+1):
                w={}
                for r,vr in v.items():
                    mr=self.shift(m,r)
                    for beta,l in self.logs.items():
                        p=tuple(r[i]+beta[i] for i in range(self.n))
                        if not le(p,alpha): continue
                        coeff=l*sum(beta[i]*self.D[i]*mr[i] for i in range(self.n))
                        if coeff: w[p]=w.get(p,F(0))+coeff*vr/F(k)
                v={p:c for p,c in w.items() if c}
                if not v:break
                for p,c in v.items(): C[p,q]=C.get((p,q),F(0))+c
        return J,C

    def add(self,alpha):
        if not any(alpha):return
        nz=[i for i,x in enumerate(alpha) if x]
        if len(nz)==1:
            i=nz[0];k=alpha[i]
            self.logs[alpha]=F((-1)**k,k*k*self.D[i]);return
        m=(1,)*self.n
        J,C=self.expmatrix(alpha,m)
        L={(p,p):F(1) for p in J};R=L.copy()
        for p,q in sorted(((p,q) for p in J for q in J if p!=q and le(q,p)),key=lambda pq:(sum(sub(*pq)),pq)):
            beta=sub(p,q)
            cross=sum((L.get((p,r),F(0))*R.get((r,q),F(0)) for r in J if r!=p and r!=q and le(q,r) and le(r,p)),F(0))
            if beta==alpha:
                diff=cross-C.get((p,q),F(0))
                self.logs[alpha]=diff/F(sum(alpha[i]*self.D[i] for i in range(self.n)))
                break
            residual=C.get((p,q),F(0))-cross
            sign=self.sign(alpha,beta)
            if sign<0:L[p,q]=residual
            elif sign>0:R[p,q]=residual
            else:
                assert residual==0,('Lie central residual',alpha,beta,m,residual)
                self.zero_residuals+=1

    def coefficient(self,alpha,m):
        _,C=self.expmatrix(alpha,m)
        return C.get((alpha,self.zero),F(0))

def main():
    start=time.time();rng=random.Random(381103);reports=[]
    cases=[
      ('zero3',[[0,0,0],[0,0,0],[0,0,0]],[1,3,2],5),
      ('acyclic2_valued',[[0,3],[-2,0]],[2,3],7),
      ('a3_cycle',[[0,1,-1],[-1,0,1],[1,-1,0]],[1,1,1],5),
      ('markov2',[[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],6),
      ('cycle3_weight3',[[0,3,-3],[-3,0,3],[3,-3,0]],[1,1,1],6),
      ('cyclic_valued',[[0,3,-1],[-2,0,2],[2,-6,0]],[2,3,1],5),
      ('cyclic4',[[0,1,0,-2],[-1,0,3,0],[0,-3,0,1],[2,0,-1,0]],[1,1,1,1],4),
      ('disconnected_valued',[[0,2,0,0],[-1,0,0,0],[0,0,0,-1],[0,0,3,0]],[1,2,3,1],4),
    ]
    for name,B,D,K in cases:
        t=time.time();L=LieLog(B,D);R=IncomingRecursion(B,D);S=IncomingSchur(B,D)
        rr=roots(len(D),K)
        for alpha in rr[1:]:L.add(alpha)
        count=0
        for m in [tuple(rng.randrange(-3,4) for _ in D) for j in range(4)]:
            for alpha in rr[1:]:
                v=L.coefficient(alpha,m);w=R.c(alpha,m);s=S.c(alpha,m)
                assert v==w,(name,alpha,m,str(v),w)
                assert v==s,('Schur mismatch',name,alpha,m,str(v),s)
                count+=1
        reports.append({'name':name,'B':B,'D':D,'total_degree':K,'matched_coefficients':count,
                        'lie_zero_residuals':L.zero_residuals,'integer_zero_residuals':R.zero_residual_checks,
                        'schur_coefficients_independently_matched':count,
                        'nonzero_log_terms':sum(v!=0 for v in L.logs.values()),
                        'nonintegral_log_terms':sum(v.denominator!=1 for v in L.logs.values()),
                        'seconds':time.time()-t})
        print(json.dumps(reports[-1]),flush=True)
        Path(__file__).with_name('incoming_independent_compute_results.json').write_text(json.dumps({'status':'running','cases':reports,'seconds':time.time()-start},indent=2))
    out={'status':'PASS','cases':reports,'matched_coefficients':sum(x['matched_coefficients'] for x in reports),'seconds':time.time()-start}
    Path(__file__).with_name('incoming_independent_compute_results.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'status':'PASS','matched':out['matched_coefficients'],'seconds':out['seconds']}),flush=True)

if __name__=='__main__':main()
