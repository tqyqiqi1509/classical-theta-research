# Gain curves, phase boundaries, and the nongeneric fan interface

Date: 2026-11-13. Agent: gain_fan_extension. Working record.

## 1. Independent audit of the generic framed theorem

Theorem 10.2 of `agents/valued_polyhedral_mechanism.md` is correct with its
printed generic, connected, acyclic, weight-one-frame hypotheses. In
particular, its equivariant conclusion is stronger than a dimension count.

The important points independently checked are these.

1. The forbidden outgoing-cut monomials are the Stanley--Reisner ideal of
   the generic thin-quiver fan. Its facets are complements of individual
   stable spanning trees, not complements of collapsed bundles.
2. After fixing the root coordinate to zero, every nonzero-gain tree
   incidence minor is invertible. Leaf elimination proves this without a
   balanced-cycle hypothesis.
3. Hence the kernel of the gain matrix is an l.s.o.p. for the same
   Cohen--Macaulay face ring for every nonzero gain assignment.
4. The equivariant Koszul character depends only on the exact sequence of
   arrow, kernel, and nonroot-vertex representations. All are genuinely
   equivariant when gain labels are matched under the vertex group.
5. At the complete root-of-unity specialization, the cut ideal is extended
   from the polynomial ring in `u_i=w_i^{d_i}`. Freeness over that polynomial
   ring, and its explicit residue-monomial basis, gives the actual module
   factorization. No division of anonymous dimensions is used.

The same proof does **not** give a flat deformation of intersection
cohomology at nongeneric stability. The obstruction in Section 4 below
rules out one especially natural version of such an assertion.

## 2. A general unrooted gain-curve theorem

This strengthens the generic theorem in a direction useful for preserving
the centre during gluing. All vertex coordinates are retained.

Let `G` be a connected multigraph on `n` vertices and `E` its individual
edges. Orient each edge only to write a form

`ell_e(w)=w_j-zeta_e w_i`, with `zeta_e != 0`.

There are two allowed simplicial complexes `K`:

* the complex whose facets are complements of the stable spanning trees of
  a nonempty generic thin-quiver chamber;
* the cographic matroid complex whose facets are complements of **all**
  spanning trees of `G`.

In either case `S_K=C[z_e]/I_K` is Cohen--Macaulay of dimension
`|E|-n+1`. Define

\[
 R_\zeta(K)=\mathbb C[w_1,\ldots,w_n]/
       \bigl(I_K(z_e=\ell_e(w))\bigr).
 \tag{2.1}
\]

In the chamber case this is the ordinary outgoing-cut presentation with
gain factors. In the cographic case its generators are all cut products.

### Theorem 2.1

For every assignment of nonzero gains, `R_zeta(K)` is a one-dimensional
Cohen--Macaulay ring, with gain-independent Hilbert series. For the
equivariant statement, assume a finite group preserves the chosen edge
orientations, the chamber/matroid, and the gains with their labels. Then
its graded character is independent of the gains. More generally, one
may use a fixed arrow linearization making every substitution equivariant.
If `R_0(K)`
denotes the ordinary finite cut/Chow algebra after quotienting the diagonal
translation direction, then

\[
 \operatorname{Tr}(g;R_\zeta(K);q)
   =\frac{\operatorname{Tr}(g;R_0(K);q)}{1-q}.
 \tag{2.2}
\]

**Proof.** Work in `S_K[w_1,...,w_n]`, a Cohen--Macaulay ring of dimension
`|E|+1`. Quotient by the `|E|` linear forms `z_e-ell_e(w)`.
Set-theoretically, the result is a finite union of the solution spaces

`ell_e(w)=0` for `e` in a spanning tree occurring in `K`.

Each is exactly a line: all nonzero gains propagate a chosen vertex
coordinate uniquely along the tree. A nonzero point on such a line has
every vertex coordinate nonzero. Thus the quotient has dimension one.
The displayed sequence has full possible height in a Cohen--Macaulay
ring and is a regular sequence. The equivariant Koszul formula is

\[
 \operatorname{Tr}(g;R_\zeta(K);q)
 =\operatorname{Tr}(g;S_K;q)
  \frac{\det(1-qg\mid\mathbb C^E)}
       {\det(1-qg\mid\mathbb C^V)}.
 \tag{2.3}
\]

It is independent of the gains. At all gains one, a group-invariant
diagonal coordinate (the average of the vertex coordinates) gives
`R_1(K)=R_0(K) tensor C[t]`, proving (2.2). This formulation remains valid
when the rank of the full gain-incidence matrix jumps. It avoids choosing
a kernel of varying dimension. Square-freeness or reducedness of the
specialized cut ideal is neither assumed nor needed. QED.

### Corollary 2.2: the actual ramified central curve

Give the vertices positive weights `d_i` and each bundle multiplicity
`m_ij` divisible by `lcm(d_i,d_j)`. Specialize the bundle to all
`lcm(d_i,d_j)`-th roots of unity, with equal repetition. Put

\[
 Q_{ij}(u_i,u_j)=
 \left(u_j^{d_i/h_{ij}}-u_i^{d_j/h_{ij}}\right)^{m_{ij}/\ell_{ij}},
 \quad h_{ij}=\gcd(d_i,d_j),\quad\ell_{ij}=\operatorname{lcm}(d_i,d_j).
\]

The unrooted algebra `R_val(K,d)` is defined by the corresponding cut
products in all variables `u_i`, with `deg u_i=d_i`. It is a
one-dimensional Cohen--Macaulay ring and

\[
 R_\zeta(K)=R_{\rm val}(K,d)\otimes
 \operatorname{span}\{w^a:0\leq a_i<d_i\}.
 \tag{2.4}
\]

For a weight-preserving vertex permutation satisfying the oriented-arrow
equivariance hypothesis of Theorem 2.1,

\[
 \operatorname{Tr}(g;R_{\rm val}(K,d);q)=
 \frac{\operatorname{Tr}(g;R_0(K);q)}
 {(1-q)\prod_{c\in\operatorname{Cycles}(g)}
       (1+q^{|c|}+\cdots+q^{(d_c-1)|c|})}.
 \tag{2.5}
\]

This is an actual infinite graded character for the two stated choices
of `K`. It must not be asserted for the global IH module of an arbitrary
nongeneric fan.

### An equivariant correction discovered before handoff

The orientation/linearization hypothesis above is essential. An earlier
draft said only that a group preserves the matroid and gains. That was
too weak for undirected graph automorphisms reversing edges.

For one unrooted edge and the vertex swap, gain `+1` imposes `w_2=w_1`,
so its curve coordinate is fixed and the character is `1/(1-q)`. Gain
`-1` imposes `w_2=-w_1`, so the coordinate changes sign and the character
is `1/(1+q)`. The induced arrow linearization has changed. There is no
equivariant gain-independence theorem covering both while ignoring that
change. The parent and valued agent were informed immediately.

The generic framed acyclic theorem is unaffected: its group preserves
the quiver orientation. The K_(2,2) obstruction below also uses only the
orientation-preserving row/column group. For full symmetric-graph-cone
automorphism groups, explicit scalar linearizations must be retained in
the phase groupoid. Nonequivariant Cohen--Macaulayness, Hilbert
independence, and the contraction exact sequences are unchanged.

## 3. Boundary weights and honest forest contraction

For a subtree `C` of the global framed partition grammar, define

`h_C = gcd of D_colour(leaf) over original leaves in C`.

The original frame has weight one. Therefore `h_root=1`,
`h_leaf=D_colour`, and `h_C=gcd(h_child)` at every internal node. Every
pairing between child charges is divisible by the l.c.m. of their `h`
weights. The local numerical factors `h_parent/prod h_child` telescope to
`1/prod_leaf D_colour`. This index choice is compatible with the canonical
forest phase exact sequence already proved by the valued agent. It does
not imply a finite local normalized representation.

For an oriented gain graph, let `F` be a forest. In each component choose
a vertex `r`; solve the forest equations as `w_i=a_i t_C`, with all
`a_i != 0`. On a surviving edge the new form is, up to a nonzero scalar,

`t_D - (zeta_e a_i/a_j) t_C`.

For the **all-cut** gain algebra there is an exact quotient identity

\[
 R_\zeta(G)/(\ell_f:f\in F)
   \cong R_{\zeta/F}(G/F).
 \tag{3.1}
\]

Indeed, a cut not consisting of whole forest components crosses some
edge of `F`, so its product maps to zero. A cut consisting of whole
components maps to exactly the corresponding contracted cut product.
These are all generators on both sides. Edges internal to a contracted
component become loops and do not appear in a cut product.

This statement has the following precise refinements.

* Changing the chosen root or gauge in a component rescales `t_C` and all
  incident gains, giving a canonical isomorphism in the gauge groupoid.
* Nested forest contractions are associative in this groupoid because
  they are iterated quotients by the same original linear equations.
* If one also imposes a nonforest internal edge, its transformed equation
  is `(1-zeta_cycle)t_C=0`. A balanced cycle contributes no equation; an
  unbalanced cycle forces the central parameter to zero. This is the
  explicit torsion event missed by naive full-fan gain deformation.
* A chosen forest is not preserved by all vertex phases. Retaining its
  full phase orbit before taking invariants gives an honest equivariant
  family of quotient maps. Taking invariants forest by forest would
  discard the boundary action.

### Theorem 3.2: deletion--contraction before centre reduction

For a nonloop nonbridge individual edge `e` of a connected gain graph,
there is a natural exact sequence

\[
 0\longrightarrow R_\zeta(G\setminus e)[-1]
 \xrightarrow{\ \ell_e\ }R_\zeta(G)
 \longrightarrow R_{\zeta/e}(G/e)\longrightarrow0.
 \tag{3.2}
\]

Here the last arrow is the quotient imposing `ell_e=0`, with the induced
gain data specified above. This is an exact sequence of actual modules,
not just a Hilbert-series identity.

**Proof.** Start with the standard deletion--contraction exact sequence
of cographic Stanley--Reisner rings, whose first map is multiplication by
`z_e`. Extend all three terms by the variables `w`, then quotient by
`z_f-ell_f(w)` for every original edge `f`. The three specialized terms
have dimension one: their supports are respectively the tree lines for
`G\e`, for `G`, and the tree lines for `G/e` in `ell_e=0`. Each original
term is Cohen--Macaulay of the required dimension, so this same sequence
of linear relations is regular on all three terms. Its Koszul resolution
therefore has no higher Tor on any term. Base change preserves exactness,
and the resulting maps are exactly those in (3.2). QED.

One can retain all edge orbits to obtain equivariant exact diagrams.
Neither an invariant choice of one edge nor a phase-invariant splitting
of (3.2) is asserted.

Under the weighted power diagonal `u_i=t_C^{d_i/h_C}`, the image is in
general the semigroup curve `C[t_C^{d_i/h_C}:i in C]`, not `C[t_C]`.
For example weights `(2,3)` give `C[t^2,t^3]`. Its normalization adds a
conductor correction. Also, an external edge bundle retains its entire
residual gain multiset after contraction; it cannot silently be replaced
by a fresh full root set of the smaller l.c.m. These two facts prevent an
incorrect assertion of ordinary polynomial boundary freeness.

## 4. A decisive nongeneric obstruction, and the correction it requires

Take the thin local quiver `K_(2,2)` with two arrows on each edge. The
already independently computed symmetric-stability IH character, on
identity, row swap, column swap, and both swaps, is

\[
\begin{aligned}
 P_1(q)&=1+3q+4q^2+4q^3+3q^4+q^5,\\
 P_r(q)=P_c(q)&=1+q+2q^2+2q^3+q^4+q^5,\\
 P_{rc}(q)&=1-q-q^4+q^5.
\end{aligned}
\]

Give every child weight two. The attempted extension of (2.5) from a
generic chamber to this **whole nongeneric IH module** gives

\[
 \frac{P_1}{(1-q)(1+q)^4}
 =\frac{P_r}{(1-q)(1+q)^2(1+q^2)}
 =\frac{1+q^2}{1-q^2},
\]

and

\[
 \frac{P_{rc}}{(1-q)(1+q^2)^2}
 =\frac{1-q^2}{1+q^2}.
\]

At degree `q^2` the putative character is `(2,2,2,-2)`. Its multiplicity
of the tensor product of the two sign characters is

`(2-2-2-2)/4 = -1`.

Thus there is no positive graded module with this character. Retaining a
single central polynomial direction does not, by itself, repair the
finite local normalization obstruction. A full-fan extension must either
retain genuinely nonfree/derived boundary terms or postpone its primitive
operation and phase quotient to the whole weight-one-framed object.

This is used to choose the next construction, not as a substitute for it.
The graph-cone cut rings of Section 2 remain valid: their reduced
characters are **not** the same as the whole nongeneric global IH module.

## 5. Full-fan route still under investigation

The independently audited Tang II many-slope extension identifies every
normal cone of an anti-attractor flow polytope as a symmetric graph cone
times a smooth orthant. Its reduced graph-cone character agrees with the
all-cut algebra. However this is a character identity, not a canonical
identification of sheaf restriction maps. In particular, replacing each
stalk by a reduced cut algebra and using only vertex-diagonal maps loses
the positive polynomial boundary data required by minimal extension.

The proved gain-curve objects and the forest quotient maps now supply a
concrete coefficient candidate **before** reduction. The unresolved step
is to construct the maps including cycle-holonomy torsion and semigroup
conductor terms, and prove that the globally framed primitive operation
has actual positive cohomology. No theorem asserting that step is used.

## 6. Literature and route log

2026-11-13, 12:25--12:35 UTC:

* Read and independently checked the generic gain-LSOP theorem. Accepted
  in its exact printed scope; no nongeneric conclusion imported.
* Read `proofs/local_rank_two_ih_interface.md` and the Tang II agent's
  Sections 1--4. The local normal-cone identification is useful, but
  reduced character equality alone does not provide restriction maps.
* Primary search found Braden--Proudfoot, *The hypertoric intersection
  cohomology ring*, arXiv:0802.0641; and Barthel--Brasselet--Fieseler--Kaup,
  *Equivariant Intersection Cohomology of Toric Varieties*,
  arXiv:math/9904159. These are prospective sheaf interfaces, not used
  without reading their precise hypotheses.
* The 2026 ICM survey *Intersection Cohomology Without Spaces* and a 2026
  matroid deformation-obstruction paper appeared in search. No conclusion
  from either has been adopted; older primary proofs will be preferred
  where sufficient.

## 7. A diagrammatic category containing the cut algebra

The following is an explicit new interface with symmetrizable quiver
Hecke algebras. It supplies genuine morphisms and quotient categories,
rather than assigning a separate normalized vector space to each tree.

### 7.1 The thin polynomial matrix order

Let `Q` be an acyclic quiver on a finite labeled vertex set `V`. At this
step each label is a distinct thin color. Write
`R=C[u_i:i in V]`. For every adjacent unordered pair choose a nonzero
polynomial `Q_ij` (the ramified Euler polynomials are allowed), and for a
nonadjacent pair set `Q_ij=1`.

Let `W` be the set of all linear orders of `V`. For `w,w' in W`, define

\[
 P_{w',w}=\prod_{i\to j\text{ in }Q\atop
                 i<_w j, j<_{w'}i}Q_{ij}.
 \tag{7.1}
\]

For a bundle, `Q_ij` already includes the whole bundle multiplicity.
Define the matrix order

\[
 \mathcal A(Q,Q_\bullet)
   =\bigoplus_{w,w'\in W}P_{w',w}R\,E_{w',w}
   \subseteq\operatorname{Mat}_{W}(R).
 \tag{7.2}
\]

It is an algebra. For each oriented pair, a transition that requires its
factor in `P_(w'',w)` must include that same transition in at least one
of `P_(w'',w')` or `P_(w',w)`. Hence the product of the latter two is
divisible by the former. Associativity follows from matrix multiplication.

This is the thin part of the faithful polynomial representation of the
quiver Hecke algebra. Because no color repeats, each pair of words has a
unique underlying permutation, and its corner is a free rank-one
`R`-module. The definition (7.2) is sufficient here even without invoking
that identification. Its modules and all idempotent quotients are
ordinary algebraic objects over the explicitly given polynomial ring.

### 7.2 The stability quotient and the exact cut-corner theorem

Let `theta(V)=0`. Call a word bad if it has a nonempty proper initial
segment `S` with `theta(S)<0`. Let `J_theta` be the two-sided ideal of
`A` generated by the corresponding diagonal idempotents. Put

`A_theta=A/J_theta`.

Choose a reverse topological order `v` of the acyclic quiver, so every
arrow `i->j` has `j<_v i`.

### Theorem 7.1

There is an equality of explicitly presented algebras

\[
 e_v\mathcal A_\theta e_v
 =\frac{R}{\bigl(\prod_{i\in S,j\notin S}Q_{ij}:\theta(S)<0\bigr)}.
 \tag{7.3}
\]

No genericity of `theta` is needed for this identity. Genericity is
needed only for the finite-dimensional/CM conclusions proved earlier.

**Proof.** Before quotienting, `e_v A e_v=R`. Its intersection with the
bad-idempotent ideal is generated by

`P_(v,w) P_(w,v)` for bad words `w`.

This product contains one `Q_ij` exactly when the relative order of
`i,j` differs between `v` and `w`. If `S` is a bad initial segment of
`w`, then every arrow `i in S -> j outside S` is reversed relative to
`v`. Thus the product is divisible by the corresponding outgoing-cut
product. This gives one ideal inclusion.

Conversely, for any forbidden `S`, take `w` to be `S` in its `v` order,
followed by its complement in its `v` order. The only reversed arrow
pairs are exactly the arrows leaving `S`; pairs internal to either part
and arrows entering `S` retain their relative orders. Therefore this
bad word gives exactly the cut product. This proves the other inclusion.
QED.

All reverse topological orders are connected by adjacent swaps of
nonadjacent vertices, for which `Q_ij=1`. The corresponding corners are
therefore canonically identified. A quiver automorphism acts on all
words and variables and preserves the bad-word ideal; under these
identifications, its action on (7.3) is exactly the natural permutation
action on the cut algebra. Setting the weight-one frame variable to zero
recovers the previously proved finite generic ramified quotient.

### 7.3 Why this changes the gluing problem

The construction retains all order idempotents and their polynomial
morphisms. Different stability quotients are therefore related through
actual quotient and induction/restriction bimodules of one explicit
algebra. Weighted KLR versions also provide change-of-weighting
bimodules. These objects can mix different bracketings and degeneration
strata; they are not forced to preserve each macro-tree summand.

This is the needed type of additional structure after the parent and
valued agent found a rooted example in which one normalized tree-orbit
character has negative double-sign multiplicity `-2` and a second orbit
contributes `+3`. No phase action preserving those two summands separately
can be the answer.

What remains unproved is the precise incoming-only quotient/primitive
functor whose framed output equals the global theta module. The corner
theorem is a concrete presentation and compatibility result, not an
assertion that arbitrary zero-potential Hall theory already gives theta.

## 8. Strong literature audit: useful structures and exact limitations

### 8.1 Jindal--Negut, arXiv:2604.00124v2

Primary abstract and full HTML opened:
<https://arxiv.org/abs/2604.00124>,
<https://arxiv.org/html/2604.00124v2>.
Verified v1: 31 March 2026; v2: 18 June 2026.

Although the abstract says “any quiver”, the working hypotheses in
Section 2 impose symmetric kernel degrees, and Section 3.4 explicitly
restricts to symmetric quivers. The theorem cannot be imported for an
arbitrary acyclic local quiver. It is relevant to our symmetric
graph-cone strata. The explicit polynomial bounds and their recursive
restriction interface are useful, but their proof also uses common
translation of all Chern roots. Our ramified root-power factors do not
have that translation invariance, so the argument does not automatically
ramify. No BPS identification from this paper is assumed in our proof.

### 8.2 Webster, weighted KLR algebras

Primary published PDF:
<https://ems.press/content/serial-article-files/26459?nt=1>;
arXiv record: <https://arxiv.org/abs/1209.2463>.
Read Sections 2.1--2.3, 2.5--2.7, especially the polynomial
representation, basis proof, steadied quotients and Example 2.27.

Example 2.27 contains exactly the root-power Euler factors used here,
with `f_ij=c_ij/gcd(c_ij,c_ji)`. Thus **the polynomial itself is not new**.
The new contribution here is its ramified cut-algebra use and the
independent gain-LSOP/character proof. The paper supplies diagrammatic
algebras for symmetrizable data, polynomial representations and
change-of-weighting bimodules. Its geometric semisimplicity statement is
restricted to symmetric Cartan data; it is not a valued theta theorem.

### 8.3 Rouquier and the citation correction

Primary PDF:
<https://www.math.ucla.edu/~rouquier/papers/repquiv.pdf>
(`arXiv:1112.3619`). Sections 3.2.2--3.2.3 verify the general polynomial
axioms, faithful polynomial representation and PBW basis needed to
identify (7.2) as a thin KLR order.

An initial secondary citation pointed to “Rouquier Section 3.2.4” for
the exact symmetrizable root-power formula. It refers to a different
Rouquier text: Section 3.2.4 of this inspected PDF prints only the
symmetric example. The parent and valued agent were immediately sent
this correction. The verified citation for the exact root-power formula
is Webster, Example 2.27.

### 8.4 Unfurling and Dowling interfaces

Webster's *Unfurling KLR algebras*, arXiv:1603.06311, has a 2026 v4
revised on 11 July. The metadata and primary full HTML were opened.
No new 2026 theorem is used without a further proof audit. The older
weighted-KLR paper already provides the limited spectral-completion
interface relevant here.

Gain-hyperplane intersections are described by phase-labeled balanced
blocks together with a zero block for unbalanced gain cycles. This
suggests generalized Dowling arrangements and their nested-set models as
a way to mix tree strata. Primary search found the 2026 paper
*Kazhdan--Lusztig polynomials of Dowling geometries*, arXiv:2605.04043.
Neither its positivity nor a theta identification has been used. Matroid
IH and the toric full-fan IH in this project must not be conflated.

## 9. Exact computational checks

`computations/valued_polyhedral_mechanism/gain_curve_contraction.py`
uses rational Groebner bases and exact integer Taylor numerators.

* Exhausted all connected signed simple graphs on two, three and four
  labeled vertices: **646** gain assignments. All full gain/raw Hilbert
  numerators agree.
* Verified **2,738** actual contraction quotient ideals in both
  directions by exact polynomial reduction.
* Verified **2,136** nonbridge deletion--contraction Hilbert identities;
  together with the proved maps and the algebraic argument, these check
  every implemented exact sequence in the test family.
* Independently recomputed the nongeneric degree-two character
  `(2,2,2,-2)` and its double-sign multiplicity `-1`.
* An actual Wolfram Language kernel independently confirmed those
  rational functions and the negative multiplicity, and checked **432**
  ramified KLR polynomials (`1<=d_i,d_j<=12`, multiplicity factor1--3)
  for the required weighted degree and polynomial divided difference.
  All 432 passed. The Wolfram semantic-context lookup supplied no
  mathematical result and is not counted as a successful verification.

## 10. Rooted full-cut equivariance: the reversal issue is repaired

The unrooted counterexample in Section2 is real. Nevertheless a fixed
root supplies exactly the additional condition needed to prove full
graded gain-independence for the **rooted all-cut algebra**, including
automorphisms reversing edges. This proof was found immediately before
handoff and sent to the parent and valued agent.

Let `G` be a connected multigraph with a distinguished vertex0 and fix
`w_0=0`. Let a finite-order graph automorphism `g` fix0. Assume the gain
linear forms are permuted up to nonzero scalars by `g`, so there is a
monomial action on the arrow coordinate space for which the gain map is
equivariant. For an arrow orbit `c`, let `lambda_c` be the product of
these scalars around the orbit and put `z_c=lambda_c q^{|c|}`.

The rooted tree-minor argument makes the gain kernel an l.s.o.p. on the
cographic SR ring. Taking its equivariant Koszul character and using
the monomial basis of the SR ring gives

\[
 \operatorname{Tr}(g;R_\zeta^{\rm root};q)
 =\frac{1}{\det(1-qg\mid\mathbb C^{V\setminus\{0\}})}
 \sum_{H}\prod_{c\not\subset H}z_c
                  \prod_{c\subset H}(1-z_c),
 \tag{10.1}
\]

where the sum is over `g`-invariant connected spanning arrow supports
`H`. This follows by writing the SR character as a sum over invariant
faces `J`, multiplying by the arrow determinant, and putting `H=E\J`.

### Theorem 10.1

The right side of (10.1) is independent of all gains and of the matching
of parallel arrow labels. It is the ordinary rooted all-cut graded
character under the same vertex permutation.

**Proof.** A `g`-invariant spanning support `H` is connected if and only
if its quotient graph on vertex orbits is connected. The forward
implication is immediate. Conversely, the component containing the
fixed root is `g`-stable. If a quotient edge meets a vertex orbit already
in that component, all translates of that edge bring its entire other
endpoint orbit into the same component. Induction along quotient paths
then includes every vertex.

Consequently every arrow orbit whose endpoints lie in a single vertex
orbit is irrelevant to this connectivity condition. Summing its absent
and present alternatives gives `z_c+(1-z_c)=1`, so it disappears.

On every remaining arrow orbit, the orbit return fixes the two endpoints
individually; it cannot reverse them because they lie in distinct vertex
orbits. Applying this return to the linear form shows `lambda_c=1`.
Thus every remaining factor is gain-independent. Finally, if several
arrow orbits join the same pair of vertex orbits, their joint absent
weight is

`prod_c q^{|c|}=q^{number of arrows joining those vertex orbits}`,

and their joint present weight is one minus that expression. It depends
only on the total arrow count, not on the cycle decomposition of parallel
labels. This proves the assertion. QED.

This theorem repairs the corresponding rooted full-cut step in the
valued agent's weighted-Jacobian construction. Together with its actual
free phase extension, it proves the full rooted all-cut graded
cycle-character division, without requiring a graph-invariant choice
of orientation. It does not repair unrooted full-fan normalization:
without a fixed root, quotient connectivity need not imply connectivity
of the invariant support.


