# A global Young species, polynomial functor, and finite reddening realization

Research derivation, 2026-11-13. Classical skew-symmetric and
skew-symmetrizable cluster algebras. This note develops the representation
meaning of the finite construction in `valued_global_assembly.md`; it does
not replace that construction by a character oracle.

## 1. Input theorem and what is being constructed

Fix the exchange data `(B,D)`, a positive target charge `S`, and the finite
event flags, bounded Dyck rectangles, and deterministic word schedule of
the global event construction. Before specializing the original
alphabets, its coefficient is a homogeneous polynomial

\[
 P_S(X_0,\ldots,X_n)
   =\sum_{F\in\mathscr S_S}\prod_{\ell\in L(F)}
                          e_{k(\ell)}(X_{i(\ell)}).
 \tag{1.1}
\]

Here `mathscr S_S` is the finite set of undecorated event/Dyck skeletons.
An original axis leaf has an original color `i(ell)` and a positive size
`k(ell)`. For each color `i`, the sum of its leaf sizes is `S_i`. The frame,
when used, is color0. A size-zero choice is the unique empty decoration
and produces no leaf.

**Occurrences are distinguished.** Every event, local word instance,
ordered copy of a local wall power, positive-weight Dyck edge, and child
slot retains its tag. For example, two equal-sized leaves at two different
edges remain two slots. There is no quotient by automorphisms of an
unlabelled tree. Formula (1.1) is exactly the positive sum/product grammar,
not a new expansion extracted from a known theta coefficient.

The input theorem identifies (1.1) with the universal incoming coefficient
in the original independent elementary generators. Its one-frame,
one-letter specialization is the classical theta coefficient. The
present note constructs a finite symmetric-group set, an actual module,
and polynomial functors directly from its skeletons, and proves their
full character formulas.

## 2. A finite colored species defined by leaf blocks

Let `I=(I_0,...,I_n)` be a tuple of finite label sets with
`|I_i|=S_i`. For a skeleton `F`, define

\[
 \mathscr Y_F[I]=
 \left\{(A_\ell)_{\ell\in L(F)}:
  I_i=\bigsqcup_{\ell:i(\ell)=i}A_\ell,\quad
  |A_\ell|=k(\ell)\right\},
 \qquad
 \mathscr Y_S[I]=\bigsqcup_F\mathscr Y_F[I].                 \tag{2.1}
\]

The blocks are assigned to the distinguished leaf occurrences; labels
inside an individual block are unordered. A tuple of label bijections
acts by applying it to every block. This is a functor from the groupoid of
colored finite sets of cardinality `S` to finite sets. No choice of an
ordering on the labels is required.

For standard labels `[S_i]`, write

\[
 G_S=\prod_i\mathfrak S_{S_i},\qquad
 M_S=\mathbb Q[\mathscr Y_S([S])],\qquad
 \varepsilon_S=\boxtimes_i\operatorname{sgn}_{S_i},\qquad
 N_S=\varepsilon_S\otimes M_S.                              \tag{2.2}
\]

For a fixed skeleton, the action is transitive. The stabilizer of a point
is precisely

\[
 H_F=\prod_{\ell\in L(F)}\mathfrak S_{A_\ell}
       \ \subseteq\ G_S.                                  \tag{2.3}
\]

Consequently `mathscr Y_S` is an actual Young permutation set, and

\[
 M_S\cong\bigoplus_F\operatorname{Ind}_{H_F}^{G_S}\mathbf1,
 \qquad
 N_S\cong\bigoplus_F\operatorname{Ind}_{H_F}^{G_S}
                   \bigboxtimes_\ell\operatorname{sgn}_{k(\ell)}.
                                                               \tag{2.4}
\]

These formulas construct modules over `Q`; they are not positivity
statements in a virtual representation ring. The set construction also
gives an integral permutation lattice. The sign twist gives an integral
signed permutation lattice.

## 3. Full cycle characters and Frobenius characteristic

For color `i`, list its leaf sizes in their occurrence order as
`k_{i,1},...,k_{i,r_i}`. Let `g_i` have cycles of lengths
`mu_{i,1},...,mu_{i,c_i}`. A block decomposition is fixed by `g_i` exactly
when each block is a union of its cycles. Hence

\[
 \chi_{M_S}(g)=
 \sum_F\prod_i
 [t_1^{k_{i,1}}\cdots t_{r_i}^{k_{i,r_i}}]
 \prod_{a=1}^{c_i}
       (t_1^{\mu_{i,a}}+\cdots+t_{r_i}^{\mu_{i,a}}).
                                                               \tag{3.1}
\]

The empty-color factor equals1. Equation (3.1) is a finite integer
algorithm for every cycle trace, directly from skeletons. In particular

\[
 \dim M_S=\sum_F\prod_i\frac{S_i!}
                              {\prod_{\ell:i(\ell)=i}k(\ell)!},
 \qquad
 \chi_{N_S}(g)=(-1)^{\sum_i(S_i-c_i)}\chi_{M_S}(g).
                                                               \tag{3.2}
\]

If `omega=product_i omega_i` is the original-color involution sending
`h_j(X_i)` to `e_j(X_i)`, then the complete Frobenius identities are

\[
 \operatorname{ch} M_S
       =\sum_F\prod_\ell h_{k(\ell)}(X_{i(\ell)})
       =\omega P_S,
 \qquad
 \operatorname{ch}N_S=P_S.                                  \tag{3.3}
\]

One can prove this without importing Young's rule: a cycle allocation in
(3.1), divided by the centralizer factor
`z_mu=product_j j^{m_j}m_j!`, is exactly the coefficient of `p_mu` in
`product_ell h_{k(ell)}`, using
`h_k=sum_{mu partition k}p_mu/z_mu`. The sign in (3.2) gives the elementary
version.

### Sign multiplicity and the classical coefficient

Frobenius reciprocity gives

\[
 \operatorname{Hom}_{G_S}(\varepsilon_S,
                 \operatorname{Ind}_{H_F}^{G_S}\mathbf1)
 \cong \operatorname{Hom}_{H_F}(\varepsilon_S|_{H_F},\mathbf1).
                                                               \tag{3.4}
\]

The right side has dimension1 exactly when all leaf sizes are1, and is0
otherwise: `S_k` contains an odd permutation precisely when `k>=2`.
Since `H_F` is a Young subgroup, this is also exactly the condition that
the orbit `mathscr Y_F` is free. It follows that

\[
 P_S(e_1(X_i)=1,\ e_{j>1}(X_i)=0)
   =\dim\operatorname{Hom}_{G_S}(\varepsilon_S,M_S)
   =\#\{\text{free }G_S\text{-orbits in }\mathscr Y_S\}.
                                                               \tag{3.5}
\]

This last equality uses the Young-stabilizer property. It would be false
for arbitrary permutation sets with nontrivial even stabilizers.

With the one-frame data of the event theorem, `S=(1,p)`, therefore

\[
 a_g^B(p)
   =\dim\operatorname{Hom}_{G_{(1,p)}}
                     (\varepsilon_{(1,p)},M_{g,p}).             \tag{3.6}
\]

An explicit basis is available. Put consecutive external labels into the
singleton slots of each surviving skeleton in their fixed occurrence
order, giving a point `y_F`. Its alternating orbit vector
`sum_{sigma in G_S}epsilon_S(sigma)[sigma y_F]` spans the corresponding
sign line. Different skeletons have disjoint supports. No cancellation
between different skeletons is involved in this basis.

## 4. Polynomial functors and strict versus multiset decorations

For finite-dimensional rational vector spaces `V_i`, define

\[
 \mathcal H_S(V_0,\ldots,V_n)
       =\bigoplus_F\bigotimes_{\ell\in L(F)}
                         \operatorname{Sym}^{k(\ell)}V_{i(\ell)},
 \qquad
 \mathcal E_S(V_0,\ldots,V_n)
       =\bigoplus_F\bigotimes_{\ell\in L(F)}
                         \bigwedge^{k(\ell)}V_{i(\ell)}.
                                                               \tag{4.1}
\]

They are actual multihomogeneous polynomial functors, natural under all
linear maps of the `V_i`. Use the fixed occurrence order for tensor
factors. Their `GL(V_0)x...xGL(V_n)` characters are respectively
`omega P_S` and `P_S`. Equivalently, by the induced-module description,

\[
 \mathcal H_S(V)\cong
 M_S\otimes_{\mathbb QG_S}\bigotimes_i V_i^{\otimes S_i},
 \qquad
 \mathcal E_S(V)\cong
 N_S\otimes_{\mathbb QG_S}\bigotimes_i V_i^{\otimes S_i}.
                                                               \tag{4.2}
\]

A left module is regarded as a right module by inversion in (4.2).
With ordered bases of the `V_i`, an exterior-power basis is indexed by
strictly increasing choices of `k` basis letters; a symmetric-power basis
is indexed by weakly increasing choices, equivalently multisets. Thus the
strict-subset and multiset interpretations of `e_k` and `h_k` are genuine
bases of the two functors. Repeated letters are allowed at distinct leaf
slots; only the exterior factor within one leaf imposes distinctness.

In particular

\[
 \dim\mathcal E_S(\mathbb Q^{m_0},\ldots,\mathbb Q^{m_n})
     =\sum_F\prod_\ell\binom{m_{i(\ell)}}{k(\ell)},\qquad
 \dim\mathcal H_S(\mathbb Q^{m_0},\ldots,\mathbb Q^{m_n})
     =\sum_F\prod_\ell
               \binom{m_{i(\ell)}+k(\ell)-1}{k(\ell)}.
                                                               \tag{4.3}
\]

Taking every `m_i=1` in the exterior functor recovers (3.5). More general
Schur multiplicities are also actual nonnegative integers. For a tuple
of partitions `nu_i` of `S_i`, the multiplicity in `N_S` equals

\[
 \sum_F\prod_i K_{\nu_i',\, (k_{i,1},\ldots,k_{i,r_i})},          \tag{4.4}
\]

where `K` counts semistandard tableaux of the displayed shape and
content. This follows from the standard tableau expansion of products
of complete symmetric functions followed by the sign twist. It provides
an explicit tableau-decorated multiplicity object if such a refinement
is desired; the coefficient construction itself does not require it.

## 5. Local substitution is induction, not an unproved plethysm

Let a local tight-grading decoration have distinguished child slots
`1,...,r` of charge contents `T_1,...,T_r`, with total `S`. Suppose a
colored species `Y_a` has already been defined for each slot. Define its
substitution by the colored Cauchy product

\[
 (Y_1\star\cdots\star Y_r)[I]
  =\bigsqcup_{I_i=\bigsqcup_a I_i^{(a)},\ |I_i^{(a)}|=(T_a)_i}
               \prod_a Y_a[I^{(a)}].                           \tag{5.1}
\]

This is a literal operation on finite sets, natural under label
bijections. Its linearization is

\[
 \mathbb Q[Y_1\star\cdots\star Y_r]
 \cong
 \operatorname{Ind}_{\prod_a G_{T_a}}^{G_S}
                   \bigboxtimes_a\mathbb Q[Y_a].                \tag{5.2}
\]

Therefore its Frobenius characteristic is the product of the child
characteristics. The restriction of `epsilon_S` is the product of the
child signs, so the same compatibility holds after the sign twist.

Disjoint unions over local Dyck objects, ray-power copies, word births,
and event choices complete the substitution. All collections are finite
by the strict-charge and word termination theorems. This constructs the
entire global species inductively. Applying (5.1) repeatedly is naturally
isomorphic to the leaf-block construction (2.1): forget the intermediate
label partitions; they are uniquely reconstructed as unions of the leaves
in the corresponding descendant slots. This is an actual bijection,
compatible with label permutations, for a fixed skeleton.

On modules these operations are finite direct sums, outer tensor
products, and induction. Over `Q` they are exact separately in each
module argument. On polynomial functors
they are finite direct sums and tensor products of the previously
constructed coefficient functors. This is the promised explicit Young
module functor for the event grammar. No quotient by an unspecified
automorphism group and no fractional cycle division occurs in (5.1).

## 6. What the whole local Gale comparison does and does not give

For a two-input coefficient of particle content `(ka,kb)`, let `D_val` be
the full attached valued Gale algebra of the proved phase-descent and
wall-identification theorems, over its actual characteristic-zero
coefficient field `K`. This field may contain cyclotomic constants and
generic deformation parameters. Let `Omega` be an algebraically closed
extension of `K`. The full-character identity, including all cycle
types, and the tight-grading normal conversion give

\[
 D_{\rm val}\otimes_K\Omega\ \cong
 \Omega\otimes_{\mathbb Q}\left(
 \bigoplus_{\lambda,\mu}
 \mathbb Q[\mathcal T_{\lambda,\mu}]
 \otimes
 \operatorname{Ind}_{\mathfrak S_\lambda\times\mathfrak S_\mu}
                  ^{\mathfrak S_{ka}\times\mathfrak S_{kb}}
                        \mathbf1\right).                       \tag{6.1}
\]

`mathcal T_{lambda,mu}` consists of the actual ordered tuples of sparse
tight gradings with those positive-edge profiles; the number of copies
is the integral ambient-normal exponent in the local theorem. Equality
of the elementary/complete bases proves (6.1) profile by profile. It is
stronger than equality of the dimensions at the identity.

Equation (6.1) is extension of scalars. It does not restrict a
`K`-vector space to `Q`, an operation that would multiply dimensions by
`[K:Q]` when that degree is finite. Symmetric-group representations are
split over `Q`, so the right side supplies an abstract rational form of
the representation and an abstract `K`-module comparison is available.
No canonical descent of the Gale algebra, its chosen deformation, or its
algebraic points is asserted. The global module `M_S` in Section2 is
defined over `Q` from the outset.

This has two precise consequences.

1. After choosing a Young-set model of the local Gale representation,
   its orbit-profile substitution gives the same global Young-set
   isomorphism class as the Dyck construction. For each local coefficient,
   products of `h_lambda h_mu` form a basis, so the multiplicities of every
   Young orbit type agree. One may choose an equivariant bijection with
   the path Young set and compose it using (5.1).
2. A chosen module intertwiner in (6.1) induces a natural isomorphism of
   its Schur functor with the corresponding sum of tensor products of
   symmetric powers. Applying a sign twist gives the exterior version.

There is an essential limit. A bare `G`-module does not canonically
specify a decomposition into Young permutation modules. Such modules
are usually reducible and have common irreducible constituents. Hence
substituting arbitrary coefficient functors for its formal `e_j` inputs
does not follow from ordinary composition of a bare Gale Schur functor.
The orbit/slot structure supplied by the Dyck Young lift is needed. We
have not constructed a functor from arbitrary Gale-algebra morphisms,
or a canonical bijection between algebraic roots and Dyck paths.

In particular this is not the false operation of dividing each old
unframed toric-IH tree character by local phase orders. The negative
character obstruction recorded in the earlier reports remains valid.
The whole local attached object and positive word composition mix those
terms before the present Young lift is taken.

### 6.1 The complete skew graph/fan module has this Young model

In the skew-symmetric case, let `W_chi` be the module `W` defined in
Section3 of `proofs/COMBINATORIAL_GLOBAL_THETA_THEOREM.md`: sum over
labelled reduced trees of tensor products of the actual local fan
modules, with each local factor assigned arrow parity `E_v mod2` and
the resulting super-interchange signs included in the relabelling
action. Here one forgets the grading but **retains that group action**.
Do not tensor this module by the original leaf sign in its definition.
The full-character theorem in that file and its species-completion proof
identify its ordinary trace with the weighted-cycle character `chi`.

The universal coefficient identity in the present event construction
gives precisely the same character in (3.3). Finite-dimensional rational
representations of a product of symmetric groups are determined by their
complete characters. Hence

\[
       M_{g,p}\cong W_\chi,
       \qquad N_{g,p}\cong\varepsilon_{(1,p)}\otimes W_\chi
                                                        \tag{6.2}
\]

as ungraded representations, after omitting the trivial frame group
`S_1` if desired. In particular the complete graph/fan/PBW assembly has
an actual Young-permutation realization, not merely the same dimension
as a Dyck set. This corollary uses both established complete-character
theorems; there is no claim of a canonical intertwiner between their
different bases.

The statement is about the complete global assembly. It does not assert
that every original fixed-tree summand with its super action has a Young
model, nor that a valued phase quotient can be taken separately on those
summands. The latter obstruction was explicitly found earlier. The local
primitive-center Gale replacement in `GLOBAL_YOUNG_ORBIT_FORMULA.md`
gives a separate geometric source for its local fan factors; it is
compatible with (6.2) without supplying a canonical path/root bijection.

## 7. Dependence on auxiliary choices

For fixed event flags, ordered local rectangles, and word schedule, the
label-set functor (2.1), module (2.2), and polynomial functors (4.1) are
defined directly and naturally. The coefficient-identification theorem
shows that admissible changes of these auxiliary choices, preserving the
specified incoming state or final one-frame theta problem, preserve the
whole polynomial `P_S`, not just its one-letter value.

More precisely the permitted changes are: another numerical realization
of the same finite infinitesimal sign pattern at fixed `(S,Theta)`; another
legal terminating positive word schedule for the same local factor;
and another Bezout rectangle among those whose invariance is proved by
the tight-grading theorem. For the final one-frame problem, one can also
change the positive unframed numbers `Theta(e_i)>0`, subject to
`Theta(S)=0` and rational kernel `Q S`: every proper unframed charge
remains positive and every proper framed charge remains negative, so
the same three-factor extraction applies. For a general unframed state,
moving `Theta` across a sign chamber is not one of these invariances.

This gives a stronger invariance than character equality alone would
give for arbitrary permutation sets. Every orbit here has a Young
stabilizer, and its conjugacy type is determined by the partition of leaf
sizes for each original color. The products `product_i h_{lambda_i}`
are linearly independent. Thus (3.3) implies that two choices have exactly
the same number of orbits of each Young type. Their finite `G_S`-sets are
therefore isomorphic.

The isomorphism class is independent of the auxiliary choices; no
preferred isomorphism between the sets, coherent transport between all
flags, or mutation-compatible natural transformation has been supplied.
In particular, this proof does not yield a Yang--Baxter bijection between
different local word schedules. Establishing such coherent bijections
would be a real further theorem rather than a consequence of equal
characters.

### Local bijections lift through every surrounding event context

There is a precise way to strengthen this isomorphism-class statement.
Suppose a local bijection between two finite sets of decorated path
skeletons is accompanied, for each object, by a bijection of their leaf
slots preserving original colors and block sizes. Transport each label
subset to its corresponding new slot. Equation (2.1) then gives a
natural equivariant bijection of the corresponding Young species. By
(5.1), this bijection may be inserted in any surrounding finite event
context, preserving all external labels. Linearization and the two
polynomial functors carry it to actual natural isomorphisms. Any
coherence relation already satisfied by the bare slot-preserving maps
is inherited by their label-set lifts; no new sign obstruction is
introduced by the common original-color twist.

The independently proved `DYCK_THREE_FACTOR_COHERENCE.md` supplies one
such nontrivial local map: the first multilinear triple component with
equal input normal contents. Its piecewise integer-affine map leaves the
three input decorations and their label sets unchanged. Intermediate and
final normal contents may exceed1. Hence that specific map has the
Young-equivariant lift just described. The result does not yet cover
arbitrary unequal input normal contents or all higher-degree word
coherence relations, and is not used to assert canonical flag
identifications in the preceding paragraphs.

## 8. A reddening certificate gives a finite carrier for the whole element

Here use classical principal coefficients, with

\[
 z_j=y_jx^{Be_j},\qquad \vartheta_g=x^gF_g(z),\qquad F_g(0)=1.
\]

Supply a finite mutation word whose terminal principal `C`-matrix is
`-P`, a negative permutation matrix. This is the effective certificate
we use; intermediate mutations need not all be green. Tropical duality
gives `G^t D C=D`, hence `G=-D^{-1}PD`. Its nonzero entries have absolute
values `D_j/D_{P(j)}` and are positive integers. Their product around
each permutation cycle is1, so all are1. Thus `P` preserves `D` and
`G=-P`. Reindex the terminal cluster variables as `I_i` so that

\[
 I_i=x^{-e_i}F_{I_i}(z).
\]

Each `F_{I_i}` is obtained by the finite ordinary mutation recurrence.
Set

\[
 C_g=\prod_i x_i^{[g_i]_+}I_i^{[-g_i]_+}
       =x^gH_g(z),\qquad
 H_g(z)=\prod_iF_{I_i}(z)^{[-g_i]_+},\qquad
 d_j=\sum_i[-g_i]_+\deg_{z_j}F_{I_i}.                         \tag{8.1}
\]

The standard classical theta-positivity comparison gives

\[
 0\le [z^p]F_g\le[z^p]H_g,
 \qquad \operatorname{supp}F_g\subseteq[0,d]\cap\mathbb Z^n.
                                                               \tag{8.2}
\]

For completeness, this comparison can be proved without a Newton
minimality theorem. All factors of `C_g` are cluster variables and hence
theta elements. Their theta product has nonnegative integral structure
constants. Principal homogeneity forces every full principal label in
the product to be `(g+Bq,q)`. A negative coordinate of `q` would give a
negative frozen exponent in that summand's leading monomial, which
cannot occur in the positive Laurent polynomial `C_g`. Hence `q>=0`.
Its unique constant term forces the coefficient of label `(g,0)` to be1.
Every coefficient of this summand is consequently bounded by the
corresponding coefficient of `C_g`, giving (8.2).

These finite-carrier and basis implications are already present in the
previous negative-frame work and in the classical theory. They are not
claimed as new reddening theorems here.

## 9. The finite charge-graded Hom space for one whole theta element

For each `p` in the explicit box of (8.2), construct the finite event
module `M_{g,p}` using one frame and target `(1,p)`. Form the finite
charge-graded vector space

\[
 \mathcal V_g=\bigoplus_{0\le p\le d}
       \operatorname{Hom}_{G_{(1,p)}}
              (\varepsilon_{(1,p)},M_{g,p}),\qquad
 \deg\mathcal V_{g,p}=p.                                     \tag{9.1}
\]

Equations (3.6) and (8.2) prove the exact Hilbert-polynomial identity

\[
 \operatorname{Hilb}_{\mathbb N^n}(\mathcal V_g;z)=F_g(z),
 \qquad
 \vartheta_g=x^g\operatorname{Hilb}(\mathcal V_g;z).             \tag{9.2}
\]

Every graded piece has the alternating free-orbit basis of Section3, or
equivalently a basis of the all-singleton original-leaf Dyck/event
skeletons. Thus the whole element has one finite basis construction
from the supplied mutation certificate and the integer event/Dyck rules.
It is not necessary to compute theta coefficients to find its truncation.
The finite coefficient states may be memoized in a single union of their
strict-charge event DAGs.

The grading in (9.1) is the original charge grading. No cohomological,
weight, or quantum grading is asserted. Also, (8.2) only bounds the
classical one-letter specialization. Universal alphabet modules at
charges outside the box need not vanish; only their sign multiplicities
vanish. Omitting this distinction would turn a correct classical support
statement into an unjustified universal one.

### 9.1 A sharper box using only tropical mutation

Qin's support-dimension theory gives the smallest coordinate box directly,
without computing the carrier F-polynomials in Section8. The finite
algorithm is as follows. All vectors in this paragraph use the **full**
principal lattice `M=Z^(2n)`, not just the mutable quotient.

Suppose the supplied reddening word is `w=(k_1,...,k_m)` and its terminal
`C=-P`, with `P e_j=e_{sigma(j)}`. Starting at `t`, execute

\[
 v=(\sigma(k_m),\ldots,\sigma(k_1)).                         \tag{9.3}
\]

Its endpoint is an injective predecessor `t_- = t[-1]`. To check the
direction, the principal exchange matrix after `w` is `P^{-1}BP`.
Relabelling the reverse path by `sigma` therefore starts at `B` and ends
at `PBP^{-1}`. The reverse of (9.3), namely `sigma(w)`, goes from this
endpoint to `t`, and its relative principal `C`-matrix is
`P(-P)P^{-1}=-P`. These identities can all be checked by finite integer
matrix mutation. No assumption that `sigma` is an involution is made.

Let `Phi=phi_{t_-,t}` be the tropical degree transformation along (9.3).
At one mutation at `k`, with current extended exchange matrix `E`, its
coordinate rule is

\[
 (\phi_k a)_k=-a_k,\qquad
 (\phi_k a)_i=a_i+[E_{ik}]_+[a_k]_+
                         -[-E_{ik}]_+[-a_k]_+\quad(i\ne k).
                                                               \tag{9.4}
\]

Form the integer matrix `Psi` with columns `Phi(e_j)` for all `2n`
standard basis vectors. This is Qin's linear degree transformation;
it is unimodular. For `gtilde=(g,0)`, set

\[
 \eta(g)=\Psi^{-1}\Phi(\widetilde g),\qquad
 n(g)=\operatorname{pr}_{\rm frozen}
                     (\eta(g)-\widetilde g).                  \tag{9.5}
\]

The required consistency identity and nonnegativity are

\[
 \eta(g)-\widetilde g=\begin{pmatrix}B\\I\end{pmatrix}n(g),
 \qquad n(g)\in\mathbb N^n.                                 \tag{9.6}
\]

They hold by Qin Definition3.4.4, Proposition3.4.8, and the compatible
pointedness and Laurent finiteness of theta functions under the
reddening hypothesis. Equation (9.6) is also an exact arithmetic check
on an implementation. One must not replace `Psi` by the linearization
of `Phi` at an arbitrary chamber, or project away the frozen coordinates
before computing (9.5).

Indeed, Qin's degree/codegree theorem makes `theta_g` bipointed with
degree `gtilde` and codegree `eta(g)`. A Laurent monomial therefore has
full exponent both `gtilde+Btilde p` with `p>=0` and
`eta(g)-Btilde q` with `q>=0`. The full-rank principal matrix gives
`p+q=n(g)`. The pointed and copointed leading coefficients are1. Thus

\[
 \operatorname{supp}F_g\subseteq[0,n(g)],\qquad
 [z^{n(g)}]F_g=1.                                           \tag{9.7}
\]

The box is coordinatewise sharp since its top corner occurs. In
particular `n(g)<=d` for the carrier box of Section8. Replacing `d` by
`n(g)` in (9.1) gives the same whole-theta Hom space with an input bound
computed entirely by integer matrix mutations, tropical max operations,
and a unimodular inverse. Its top graded piece is one-dimensional.

This is an application of the established support-dimension theorem,
not a new proof of that theorem. The new interface is that its finite
tropical box now carries the actual all-singleton Dyck/event bases of
the sign Hom spaces in (9.1), so no unknown interior coefficients enter
the construction of the whole element.

### 9.2 A more general finite certificate

The previous negative-product construction works as well. Suppose
finitely many computed cluster variables `X_s=x^{g_s}F_s(z)` and positive
integers `a_s` satisfy `h=sum_s a_sg_s<0` coordinatewise. Put

\[
 H=\prod_sF_s^{a_s},\qquad
 k=\max_i\left\lceil\frac{\max(0,-g_i)}{-h_i}\right\rceil,
 \qquad d_j=k\deg_{z_j}H.
\]

Then `x^{g-kh}prod_s X_s^{ka_s}=x^gH^k` is the same kind of positive
carrier, and Sections8--9 apply unchanged. The variables need not belong
to one cluster. A negative frame is one sufficient certificate, not a
necessary input to the coefficient species.

## 10. Primary-source audit for the reddening interface

The following sources were opened and checked on 2026-11-13.

* **Fan Qin, Bases for upper cluster algebras and tropical points**, JEMS
  26 (2024), 1255--1312, DOI 10.4171/JEMS/1308, published PDF
  <https://ems.press/content/serial-article-files/47257>. Its seed setup
  allows skew-symmetrizable exchange matrices. Definition2.3.2 calls a
  terminal all-negative `c`-vector word green to red. Proposition2.3.3
  identifies injective reachability with `C=-P` and proves the permutation
  preserves the symmetrizer; Corollary2.3.4 identifies green-to-red words
  with this endpoint. TheoremA.1.5 gives pointed Laurent theta functions
  and the upper-cluster-algebra theta basis for injective-reachable
  seeds. Principal coefficients satisfy the full rank assumption used
  in this paper. The separate weak-genteelness discussion in Section6.3
  and AppendixA.2 is skew-symmetric and is not silently extended here.
  Definition3.3.1, Proposition3.3.11--3.3.12, Definition3.4.4, and
  Proposition3.4.8 are the exact sources of the sharper support algorithm
  in Section9.1. The text extraction of the published PDF drops many
  minus signs; the locally retained arXiv:1902.09507v4 full text was also
  read to verify `t[-1]`, `Psi^{-1}Phi`, and the direction of the
  degree/codegree comparison.
* **Keller, with Demonet appendix, A survey on maximal green sequences**,
  arXiv:1904.09247v7 (1 December2020),
  <https://arxiv.org/pdf/1904.09247>. Proposition2.4 identifies the terminal
  framed quiver of a reddening sequence with the coframed quiver up to
  a permutation fixing frozen vertices. Theorem3.5 states the theta-basis
  consequence with the preceding full-rank hypothesis. This survey's
  quiver discussion is skew-symmetric; the valued endpoint assertion
  above is justified through Qin, not extrapolated from that discussion.
* **Gross--Hacking--Keel--Kontsevich, Canonical bases for cluster
  algebras**, arXiv:1411.1394v2,
  <https://arxiv.org/pdf/1411.1394v2>. Definition8.27 and Proposition8.28
  give the large-cluster-complex implication for principal coefficients
  and its theta basis. The all-coefficient fibers have separate scope
  conditions in that proposition. The published numbering cited by Qin
  is Proposition8.25; it must not be confused with Corollary8.25 of this
  preprint. The basis, Laurent finiteness, and positivity consequences
  are established inputs, not novelty claims of the present work.

The direct connection established here is the finite charge-graded Hom
realization (9.1), with a full-character Young lift available before
specialization. No identification with torsion-class bricks, a global
Jacobian-algebra cohomology space, or a canonical mutation functor has
been proved.

## 11. Remaining mathematical interfaces

Two substantive questions remain beyond this theorem. First, can one
construct local equivariant path bijections coherent under changes of
word schedule and event flags, rather than only prove their existence
from Young-orbit multiplicities? Second, can a global Hall or geometric
construction supply an actual grading whose specialization gives these
modules? The local full Gale comparison alone answers neither question.
They do not obstruct the finite Young species, complete character,
polynomial functor, or whole-element Hom formula proved above.

## 12. Exact computation receipts

`computations/valued_polyhedral_mechanism/young_event_species.py` provides
the finite label-set objects, colored leaf slots, cycle traces, Young
orbit tables, and functor dimensions. Its separate structural check
compares all Young profiles and cycle types through degree16 against
independent power-sum multiplication: **125,411 complete-cycle tests**.
It also passes **33,032 Cauchy-induction cycle tests**, **915 sign
multiplicity checks**, **8,235 symmetric/exterior dimension pairs**, and
**191,832 literal label-point action checks**. These do not use theta
values. Wolfram independently verified the sign-character average for
all139 profiles through degree10, and270 symmetric/exterior character
dimension identities through degree7.

The adapter `skeleton_from_flattened_event` attaches the label-set functor
directly to the literal objects from `flatten_dyck_objects.py`. The check
`young_literal_global_modules.py` promoted all **19,834 actual event/Dyck
objects in the eight previously established universal packets** to Young
module summands, and all **42 complete cycle classes** agree with the
independent weighted-cycle characters. Thus this implementation uses
their genuine distinguished leaf occurrences rather than manufacturing
a set from a prescribed coefficient. The largest checked module has
dimension85,104 and sign Hom dimension6,141; these numbers are validation
receipts, not hypotheses of the general construction.

`tropical_support_certificate.py` implements (9.3)--(9.6) from a supplied
reddening word and independently compares its output on cluster labels
with F-vectors computed by the integer maximum-degree mutation
recurrence. Its JSON receipt records the current number of verified
certificates, arbitrary labels, and cluster-variable checks. A terminal
three-cycle permutation is included to distinguish `sigma` from
`sigma^{-1}` in (9.3).

