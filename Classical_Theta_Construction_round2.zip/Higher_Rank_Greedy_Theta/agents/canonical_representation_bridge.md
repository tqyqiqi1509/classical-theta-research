# Canonical and representation interfaces for the classical theta recursion

Research date: 2026-11-13. This branch studies classical coefficients. Quantum gradings and categories are used only to identify possible sources of finite positive objects; no quantum theta theorem is asserted.

## 1. Completed result: one framing vertex removes the second recursion

The complete proof is in `ONE_FRAMING_COEFFICIENT_THEOREM.md`. For integral $B$, positive integral left symmetrizer $D$, and $g\in\mathbb Z^n$, set

$$
\widehat B=\begin{pmatrix}0&-g^TD\\g&B\end{pmatrix},
\qquad \widehat D=\operatorname{diag}(1,D).
$$

Then the incoming integer recursion and its endpoint extraction satisfy

$$
a^B_g(p)=c^{\widehat B}_{(1,p)}(-e_0).                 \tag{1}
$$

This is a direct recurrence identity, not a positivity argument or a claim that arbitrary quiver-moduli invariants equal theta coefficients. It holds coefficientwise, including cyclic and valued matrices.

The proof uses three exact facts. First, a zero-framing root only reads the original principal submatrix, and $c_q(0)=0$ for $q\ne0$. Second, at root $(1,p)$, an index $(1,q)$ lies in the positive incoming halfspace precisely when
$$
(g+Bp)^TD(p-q)<0.
$$
On the zero face, the prescribed secondary entries are $q_i-p_i\le0$, with at least one strict inequality. Thus no equality face is silently discarded. Third, the zero-framing block of the triangular linear system vanishes; its remaining block is exactly the matrix used in endpoint extraction.

There is a useful consequence at the level of the complete word expansion: every nonzero word begins with the unique framing packet $(0,1)$. Any ordinary first packet would have weight ${0\choose k}=0$. Its later packet weights are
$$
{-g_i-(Bq)_i\choose k}.
$$
The problem is therefore a single incoming tree problem with one distinguished initial leaf.

### Independent verification

`computations/canonical_bridge/framing_identity.py` compares the old two-layer calculation against the new augmented one-layer calculation on 34 independently generated matrices of ranks 2–4, both skew-symmetric and valued.

- 676 coefficient identities passed.
- 3,964 halfspace-sign comparisons passed.
- 341 exact zero-face comparisons passed.
- No positivity was used by this verification.

An actual Wolfram Language computation independently checked the generic rank-three symbolic identities $\widehat D\widehat B+(\widehat D\widehat B)^T=0$, the framing halfspace identity, and the uniform-degree normalization in Section 2. Raw source and output are preserved in `framing_wolfram_receipt.json`. The evaluator emitted an undefined-symbol warning for the deliberately symbolic $L$; all three simplified residuals were zero.

Framed DT/theta interpretations themselves are prior art. In particular, the previous project already contained the augmented pairing and framed HN index correspondence. The contribution here is the complete single-column identity (1), proved from the actual integer recursion, and the first-packet consequence. No general priority claim is made for framing.

## 2. A verified all-rank elementary-positivity interface

Primary source: Burcroff–Lee–Mou, *Positivity of generalized cluster scattering diagrams*, arXiv:2503.03719v1,
<https://arxiv.org/html/2503.03719v1>.

The relevant source locators are Definition 8.2, Theorem 8.11, Definition 8.23, Proposition 8.25, Theorem 1.7(2), and the proof in Section 9.3. The theorem covers formal theta functions for every integral label. Restricting to the finite set $\Theta$ is needed for a basis inside the uncompleted upper algebra, not for coefficientwise formal positivity. The source's initial coefficients are independent generators, and positivity means nonnegative integer polynomials in those generators.

The PNAS announcement is also available:
<https://pmc.ncbi.nlm.nih.gov/articles/PMC12067233/>.
We used the longer arXiv primary text for the actual normalization and scope check.

### 2.1 Matching our input exactly

One must not insert a degree-$L$ polynomial into their degree-one seed while leaving all their seed data unchanged. Their condition is
$$
w_i=\omega(-,d_i e_i)/\ell_i\in M
$$
primitive, and $\ell_i$ divides the corresponding exchange-matrix column.

Fix a coefficient $p$ and choose one uniform integer
$$
L\ge\max(1,p_1,\ldots,p_n).
$$
Use $n$ mutable and $n$ frozen directions and the rectangular generalized exchange matrix
$$
\widetilde B_L=L\begin{pmatrix}B\\I_n\end{pmatrix},
\qquad \ell_i=L.
                                                        \tag{2}
$$
Both the mutable block and the frozen rows are multiplied by $L$. A primitive rescaling of $D$ is a left symmetrizer of the mutable block. Choose the frozen $d_i$'s as a common multiple as in the source's Remark 8.4.

The mutable columns have full rank. More importantly,
$$
w_i=\frac{1}{L}\widetilde B_{L,i}
     =(B e_i,e_i)
$$
is primitive because its frozen part has a unit entry. The wall normal is still $e_i$. Consequently the initial wall automorphism on an exponent whose mutable part is $m$ is exactly the one using
$$
P_i(t)^{-m_i},\qquad
P_i(t)=1+\sum_{k=1}^L u_{i,k}t^k,
\quad t=y_i x^{Be_i},
$$
with the crossing orientation chosen as in our incoming transport. Uniform multiplication of the skew form by $L$ changes no incoming direction or halfspace sign.

This gives the original root step $p\mapsto p+e_i$, with the original matrix $B$, rather than an unintended step $L e_i$. The principal frozen part distinguishes different $p$'s even if $B$ has a kernel.

### 2.2 Consequence for the packet polynomial

Let
$$
T_{g,p}(u)=[y^p x^{g+Bp}]\vartheta_g
$$
for these polynomial initial walls. Give $u_{i,k}$ multidegree $k e_i$. Then
$$
T_{g,p}(u)\in\mathbb N[u_{i,k}]
$$
is multihomogeneous of degree $p$. Only $k\le p_i$ can occur. At each fixed multidegree the formal completion therefore contains only finitely many possible coefficient monomials.

We may now substitute $u_{i,k}=e_k(X_i)$. With at least $p_i$ variables in the alphabet $X_i$, this yields the stable, unique elementary expansion
$$
T_{g,p}(X)=\sum_{\lambda^i\vdash p_i}
 N_{\lambda^1,\ldots,\lambda^n}
 \prod_i e_{\lambda^i}(X_i),\qquad N_{\boldsymbol\lambda}\in\mathbb N.
                                                        \tag{3}
$$
Unused high coefficients may be specialized to zero in the positive coefficient ring or its completion. This is not a map from the entire coefficient group algebra sending an invertible generator to zero.

The same argument can instead be applied to (1), taking the new vertex to have polynomial $1+t_0$ and setting its higher coefficients to zero. Thus an endpoint theorem for arbitrary generalized $g$ is not essential to the framed version.

### 2.3 What the positivity proof was checked to use

The high-rank proof works order by order, with local two-dimensional completions at perpendicular joints and only outgoing additions. Its consistency comparison is against the independently existing incoming-normalized diagram. This is a substantive theorem interface, not an assumption of the desired positivity.

We inspected the stated independent-coefficient setup, primitive-direction and full-rank hypotheses, the all-label formal theta statement, the positive integer power in every broken-line bend, and the local-to-global proof in Section 9.3. The tight-grading proof in earlier sections is cited as the established 2025 theorem, not re-proved here. The rendered v1 contains local typographical slips in the displayed initial function and in the direction of one inclusion in Theorem 8.9; the surrounding definition, the formula at the start of Section 9.3, and the outgoing-completion statement make the intended statements unambiguous. These slips are not used as literal inputs.

Equation (3) gives a valid interface to the cycle-index branch. It does not itself give an intrinsic, wall-free set realizing the coefficients $N_{\boldsymbol\lambda}$. Defining $N$ arbitrary objects after computing $N$ would not meet the user's target.

## 3. Relation to the cycle-index character

The independent replication branch is proving the cycle-index identity and owns its proof. Write
$$
G_p=\prod_i S_{p_i}.
$$
For a cycle type $\boldsymbol\lambda$, that branch defines $\chi_p(\boldsymbol\lambda)$ by the squarefree theta coefficient of the weighted cycle-clone matrix.

If its power-sum identity is used, (3) implies
$$
\operatorname{ch}(\chi_p)=\omega T_{g,p}
=\sum_{\boldsymbol\lambda}N_{\boldsymbol\lambda}
 \prod_i h_{\lambda^i}.
$$
Therefore $\chi_p$ is an honest nonnegative sum of Young permutation characters; the original coefficient is its sign-isotypic multiplicity. This representation-theoretic conclusion is stronger than numerical nonnegativity, but it still leaves the natural realization of the multiplicity spaces to construct.

No module in this branch was defined by taking a vector space of the final computed dimension. The next sections give an explicit algebraic candidate and isolate exactly why its first version fails.

## 4. A concrete finite squarefree shuffle quotient with a natural label action

For this construction first assume $B$ is skew-symmetric. Replicate each ordinary color $i$ into $p_i$ external vertices ((i,a)); retain one framing vertex (0). Between ordinary clones use the original $B_{ij}$, and use the same framing $g_i$ for every clone. Let $\widetilde B$ be this augmented skew matrix and put
$$
A_{uv}=\max(-\widetilde B_{uv},0).
$$
This specifies the shuffle-kernel convention.

Give every vertex dimension one. Thus there are no internal pack-symmetrizations and no same-pack denominator. With variables $z_v$, the product for a split $S\sqcup T=V$ is multiplication by the explicit polynomial
$$
K_{S,T}=\prod_{u\in S,v\in T}(z_v-z_u)^{A_{uv}}.
$$
At stability $\theta_0=-N,\theta_v=1$ for $v\ne0$, where $N=\sum p_i$, the positive proper subsets are exactly the nonempty subsets of $V\setminus\{0\}$. Set
$$
J=\bigl(K_{S,V\setminus S}:\varnothing\ne S\subseteq
 V\setminus\{0\}\bigr),\qquad
R=\mathbb Q[z_v:v\in V]/(J,z_0).                       \tag{4}
$$

This candidate is fully specified by (B,g,p). The group $G_p$ acts by permuting the external clone vertices. It preserves $A,J,z_0$, so it acts naturally on $R$. When $R$ is finite dimensional, all character values can be computed from integer polynomial relations, a Gröbner basis, and variable-permutation matrices.

### 4.1 A genuine trace mechanism in the uncoupled calculation

For a single ordinary color, $B=0$, and $g=-r\le0$, (4) becomes
$$
R=\mathbb Q[z_1,\ldots,z_p]/(z_1^r,\ldots,z_p^r).
$$
Its monomial basis is the set of maps from $p$ labels to $r$ slots. Therefore a permutation with $c$ cycles has trace $r^c$: every cycle must have one common slot. This is exactly the weighted-cycle behavior the general construction needs.

The point of this calculation is a structural one. A finite polynomial quotient with external labels can have the required nonzero cycle traces without introducing them by hand.

### 4.2 The cyclic quotient fails already in framing degree one

The candidate (4) is the ordinary zero-potential shuffle/HN quotient, and it retains incoming information that a cluster diagram need not have. This is an actual failure, not merely an unverified concern.

For
$$
B_r=\begin{pmatrix}0&r&-r\\-r&0&r\\r&-r&0\end{pmatrix},
\quad g=(-1,-1,-1),\quad p=(1,1,1),
$$
direct calculations give:

| $r$ | dimension of (4) | theta coefficient |
|---:|---:|---:|
| 1 | 7 | 4 |
| 2 | 19 | 7 |

Both quotients are zero-dimensional. SymPy computed complete Gröbner bases and all standard monomials. An actual independent Wolfram Language Gröbner calculation returned the same dimensions and bases. See `squarefree_cut_quotient.py`, its JSON result, and `cut_quotient_wolfram_receipt.json`.

Thus the next correction must add a specifically cluster-compatible relation or replace the quotient by a different module. Merely choosing the simple-generated subalgebra, quoting canonical positivity, or suppressing the word “potential” does not establish such a correction. The explicit generators (4), rather than an unspecified moduli space, are now available for comparison with the incoming recurrence.

### 4.3 Two different symmetric groups must not be confused

In a usual shuffle algebra
$$
S_d=\mathbb Q[x_{i,a}]^{\prod_i S_{d_i}},
$$
the internal Weyl-group labels have already been symmetrized away. Replacing a finite quotient $S_d/I$ by
$$
\mathbb Q[x_{i,a}]/I\mathbb Q[x_{i,a}]
$$
simply introduces the coinvariant representation factor: the polynomial ring is equivariantly a free module over its symmetric subring with coinvariant regular representation. After a finite specialization this gives a regular group factor, whose nonidentity traces are zero. It cannot furnish the general required cycle characters by itself. Before a finite specialization, the resulting infinite-dimensional character is not an ordinary finite trace at all.

The external vertex-permutation group in (4) is different. It survives taking all dimension-one shuffle spaces and is the relevant candidate for $G_p$.

## 5. A constraint on the positive flow-tree route

The word branch now has a squarefree positive binary flow-tree model. It is tempting to let $G_p$ merely relabel these binary trees. This cannot be the complete answer.

For an unlabelled rooted binary tree with color-labeled leaves, any nontrivial color-preserving automorphism has a lowest node that exchanges two subtrees with the same total charge. Their skew pairing is zero. A flow tree whose node weights are nonzero therefore has no such automorphism. Consequently a direct relabeling action on such nonzero decorated binary trees, if it preserves the chosen perturbation chamber at all, is free.

But the desired character need not vanish on nonidentity elements. For $B=0,g=-2,p=2$,
$$
T=e_1^2+2e_2,\qquad
\chi(1^2)=4,\quad\chi(2)=2.
$$
The correct slot-function set has fixed points. A positive binary-tree model must therefore be reorganized before it can supply the group action: possible mechanisms are nonbinary slot blocks or a chamber-change bijection composed with relabeling.

The word branch proposed a concrete improvement: commuting equal-charge twigs can be exchanged by a binary rotation; their zero mutual pairing removes the third Jacobi shape and preserves the product of local arrow counts. Proving Coxeter relations and compatibility across higher degeneracies could produce the required action. The present obstruction concerns plain relabeling only, not that more substantial construction.

## 6. What was extracted from the user's canonical-positivity work

Primary manuscript:
Qiyue Tang, *Positivity of Canonical Basis Multiplication in Modified Quantum Groups*, Hexagon2611.00190v2,
<https://hexagonmath.org/pdf/2611.00190v2>.

We first read the earlier local referee report, then directly inspected the current manuscript's center specialization, full evaluation functor, and finite-support separation arguments (Sections 6–8). The reusable mechanism is precise: an exact morphism-ideal calculation gives a fully faithful corner after center augmentation; fullness preserves indecomposability; sufficiently large framing separates finitely many canonical labels. This is stronger than a positive Grothendieck-group identity.

For our problem, this suggests requiring an actual quotient functor, a faithful framed corner, and a comparison that identifies the required theta label. No such comparison with the incoming recursion has been proved here. The Cartan datum extracted from (|B|) also forgets the orientation information used by (g+Bq), so a bare canonical-basis citation cannot replace it.

The v2 proof explicitly includes positive-word generation and lifts idempotents in the pure colimit, addressing the old report's generation concern. This observation is based on the current manuscript, not just the old assessment. We do not re-certify the entire 2026 paper or use its main conclusion as a theta theorem.

Fang–He, arXiv:2609.06676, was located. The primary abstract identifies the thickening construction and restricts the stated general multiplication result to a spherical-parabolic factor. Its current full text could not be retrieved through the available reader; both official HTML and PDF returned DisabledError. Consequently no theorem from that current 2026 paper is imported. The source explicitly supersedes arXiv:2510.12154; the older paper is not silently substituted for the new one.

## 7. Other literature routes and audit outcomes

### 7.1 Polynomial shuffle quotients and positive reordering

The 2026 OpenAI chromatic-positivity manuscript's Section 3 gives a useful explicit model: polynomial shuffle spaces, a destabilizing ideal, an HN decomposition, and an associated graded constructed by separated-center restrictions. We checked the essential local divisibility argument of Lemma 3.5 and the finite-coefficient coproduct construction in Lemma 3.7. Merging two groups raises the shift by their Euler pairing; the coarse filtration forces the center difference to the power needed to cancel a negative kernel exponent. The construction is genuinely algebraic and retains computable finite graded pieces.

However, its quiver is built from an ordered planar input. This does not prove the needed arbitrary cyclic cluster equality. Also its infinite elementary factors have poles at $q=1$; evaluating the whole Hilbert series there is not a definition of a finite classical coefficient. We used the quotient idea to formulate (4), then tested it independently rather than importing the paper's top-level conclusion.

Primary original identifier:
<https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elementary-Positivity-of-Chromatic-Quasisymmetric-Functions-September-24-2026/paper.pdf>.
Readable mirror used for the displayed formulas:
<https://wcook04.github.io/plectis-atlas/papers/Elementary-Positivity-of-Chromatic-Quasisymmetric-Functions-September-24-2026.html>.
The mirror is not the author/publisher. No unverified global result of this 2026 manuscript is used in a theorem here.

### 7.2 Spherical CoHA and potentials

The primary 2025 article *The generic Markov cohomological Hall algebra is not spherically generated* gives a concrete warning that infinite mutability does not force spherical generation or potential-independence. It also discusses a discrete-symmetry invariant sector in a low-degree Markov calculation. This is a possible design hint for a cluster quotient, not a general construction.

Source: <https://pmc.ncbi.nlm.nih.gov/articles/PMC12345600/>.
The direct reader later hit a browser challenge; the earlier primary text and indexed passages supplied the scope. No stronger universal statement was inferred.

A spherical subalgebra generated by simple degrees need not come with the required HN restriction maps. Conversely, killing every nonsimple root degree would also kill the needed outgoing coefficients. Any attractor relation must distinguish an incoming normalization from ordinary root degree.

### 7.3 Finite Gale algebras

Tang, Hexagon2611.00238v1, Section 12, proposes finite polynomial algebras for rank-two coefficient multiplicities. The original formulas were inspected, but the deformation, saturation, and finite-flatness assertions were not fully audited. It remains a candidate for the next branch's independent algebra construction and supplies no theorem in this report.

Source: <https://hexagonmath.org/pdf/2611.00238v1>.

## 8. Route ledger and exact next task

1. **Completed:** the pure one-framing coefficient identity, including zero faces and the unique first packet.
2. **Completed interface:** correct uniform-degree embedding of arbitrary polynomial initial walls into the BLM hypotheses; all-label formal elementary positivity.
3. **Completed construction/test:** an explicit squarefree framed cut ideal with a natural external label action; its elementary cycle trace mechanism works, while its arbitrary-cyclic identification is refuted.
4. **Rejected mechanism:** confusing internal pack symmetry with external clone symmetry.
5. **Rejected mechanism:** plain relabeling of nonzero binary flow trees as the desired nonfree action.
6. **Still viable:** twig-commutation chamber bijections; a cluster-specific quotient of (4); a directly constructed finite algebra whose multiplicity spaces are the elementary coefficients of the packet polynomial.
7. **Not used:** generic equals theta; stability equals cluster for arbitrary potential; canonical positivity equals theta positivity; finite $\Theta$ membership for every formal label.

The next task is to construct the natural $G_p$-module or set from incoming data, with cycle traces equal to the positive weighted flow-tree quantities. The concrete data now available for this are (1), the exact independent-coefficient packet polynomial, the cycle-index theorem, and the explicit failed ideal (4). No further broad positivity citation alone closes this construction.

