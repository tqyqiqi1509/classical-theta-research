# Handoff: incoming-only diagrammatic bridge after gain curves

Agent `/root/gain_fan_extension`, 2026-11-13, ending this round at the
parent's request to make room for a fresh incoming-only bridge agent.
Main proof record: `agents/gain_fan_extension.md`.

## Proved contributions available to use

1. Independently audited the valued agent's generic framed gain-LSOP
   theorem. Its acyclic, generic, weight-one-frame and orientation-
   preserving-group hypotheses suffice; its actual cycle-character
   quotient is valid.
2. For a generic chamber SR complex, or the cographic matroid complex,
   substituting arbitrary nonzero gain forms while retaining every
   vertex variable gives a one-dimensional Cohen--Macaulay cut ring.
   Proof uses `S_K[w]/(z_e-ell_e)`, whose support is the finite union of
   spanning-tree solution lines. This avoids varying-rank kernel issues.
3. All-cut gain rings have genuine forest-contraction quotient maps;
   contraction preserves residual gains and is associative in the gauge
   groupoid. A further unbalanced cycle imposes `(1-zeta_cycle)t_C=0`.
   Weighted power diagonals may be semigroup curves; do not replace them
   silently by their normalizations.
4. For a nonloop nonbridge edge, the all-cut rings have the exact
   deletion--contraction sequence
   `0 -> R(G-e)[-1] --ell_e--> R(G) -> R(G/e) -> 0`.
   Its proof is Tor-independent base change of cographic SR deletion/
   contraction, using the CM curve theorem on all three terms.
5. The ramified acyclic cut algebra is an actual corner of a thin KLR
   matrix order. Objects are all orders `w` of distinct vertex labels;
   `Hom(w,w')=P_(w',w) C[u]`, with `P` the product of Euler polynomials for
   oriented inversions. Kill words with a prefix `S` having `theta(S)<0`.
   For a reverse topological word `v`, the surviving corner is exactly
   `C[u]/(outgoing forbidden-cut products)`. Every bad word contains its
   forbidden-cut factor, and the word `(S,Sc)` in the old relative order
   gives exactly that factor. All reverse topological corners identify
   through nonedge swaps, hence the graph-permutation action is correct.
6. **Latest proof, after the warning below:** rooted all-cut gain rings
   do have full graded equivariant gain-independence, even for edge
   reversals. Section10 of the main report proves this from the
   SR/Koszul connected-support formula. For an automorphism fixing the
   root, invariant support connectivity is equivalent to quotient-graph
   connectivity on vertex orbits. Every gain-dependent arrow scalar
   occurs inside a vertex orbit and cancels from the support sum. This
   closes the reversal gap in the valued agent's rooted full-cut theorem.

## Crucial corrections and failed routes to preserve

* The unrooted **graded character** statement requires a fixed arrow
  linearization; preserving an orientation and gain labels suffices.
  It is false for arbitrary undirected edge reversals: a single edge
  with gain `+1` versus `-1` gives curve traces `1/(1-q)` versus
  `1/(1+q)` under the vertex swap. Full graph-cone symmetry needs its
  scalar arrow linearization/phase groupoid explicitly.
  The rooted exception in item6 has a separate general proof and is
  valid; do not conflate it with the false unrooted assertion.
* Even retaining one centre does not make nongeneric ordinary IH divide
  freely by vertex phases. For K_(2,2), two arrows per edge, all weights2,
  `Tr(IH)/((1-q)prod_cycles[d]_(q^cycle))` has degree-two character
  `(2,2,2,-2)`, with double-sign multiplicity `-1`.
* The parent/valued agent's rooted example is stronger: with
  `D=(1,2), B12=2, B21=-1, g=(-6,2), p=(2,2)`, one complete tree orbit
  has normalized double-sign multiplicity `-2`, cancelled by another
  orbit's `+3`. The desired action must mix tree orbits.
* The gcd-of-original-leaf-weights boundary index is compatible with
  forest phase contraction and telescopes globally. It does not make
  independent local normalized modules possible.

## The next precise bridge

Use the whole original-label polynomial/weighted-KLR category, its
stability idempotent ideals and genuine bimodules, to formulate an
incoming-only quotient or primitive functor. The required functor must
mix tree bracketings and have a positive framed output. It cannot be
implemented by dividing each ordinary IH/tree character separately.

The main unproved step is **aggregation**: a subtree is not automatically
a new KLR simple color with polynomial determined just by the total
pairing. Semicuspidal-module R-matrix denominators generally depend on
more data. Thus it would be invalid to identify a fused subtree with the
single Euler polynomial `Q_(beta,gamma)` without an additional theorem.

An alternative is to stay at original vertex labels throughout and use
charge/steadied quotients and change-of-weighting bimodules, with a
separate positive integration/label comparison. The parent has read the
user's Lusztig positivity source and points to
`agents/canonical_representation_bridge.md`, Section6: exact morphism
ideals, centre augmentation/full-faithful corners, and large framing to
separate finitely many labels. That proof pattern is useful, but the
theta-label comparison remains necessary. Cartan(|B|) loses orientation,
and global zero-potential DT is not automatically cluster theta.

## Verified literature interfaces

* Webster, *Weighted Khovanov--Lauda--Rouquier algebras*,
  arXiv:1209.2463, published Documenta2019. Exact root-power polynomial
  appears in Section2.7 Example2.27. Therefore the polynomial itself is
  old; our gain/cut application is the new part. Sections2.1--2.7 give
  polynomial representations, PBW, steadied quotients and bimodules.
  Geometric semisimplicity is stated for symmetric Cartan data only.
  Primary PDF: https://ems.press/content/serial-article-files/26459?nt=1
* Rouquier1112.3619 Sections3.2.2--3.2.3 verify general polynomial KLR
  axioms and the faithful polynomial representation. An initial
  secondary attribution of the exact symmetrizable formula to its
  Section3.2.4 was corrected: use Webster Example2.27 instead.
* Jindal--Negut2604.00124v2: despite broad abstract wording, Section2
  assumes symmetric kernel degrees and Section3.4 explicitly restricts
  to symmetric quivers. Polynomial perverse-filtration conditions use
  common translation; root-power Euler factors lack that invariance.
  No theorem from it has been adopted for the valued construction.
* Webster unfurling1603.06311 has a 2026v4. Metadata/full HTML opened,
  but no new theorem used without further audit.
* Dowling-lattice/gain-arrangement interfaces were located, but matroid
  IH was never identified with this project's toric fan IH.

## Exact computation files

`computations/valued_polyhedral_mechanism/gain_curve_contraction.py`
and its results JSON:646 signed connected graphs,2738 actual quotient
ideal equalities,2136 nonbridge deletion--contraction identities, all
over exact rational Groebner arithmetic. Also independently recomputes
the K_(2,2) negative multiplicity.

`gain_curve_wolfram.json` records an actual Wolfram kernel result:
same negative multiplicity plus432 weighted-degree/divided-difference
checks on ramified KLR polynomials, all passed. No numerical inference
replaces any proof above.
