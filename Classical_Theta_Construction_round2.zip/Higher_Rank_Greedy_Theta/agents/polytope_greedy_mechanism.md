# Polytope and forest route: exact packet model and the remaining gluing problem

Research branch: `polytope_greedy_mechanism`. Date: 2026-11-13.

This note uses only classical cluster data. No theorem of Li–Pan is used.
The previous run's half-space formula is the starting point, rather than a
claim proved again in this branch. The branch establishes the forest
interpretation below, gives its elementary cancellation, and tests the
first plausible extension. It does **not** claim a cancellation-free model
for all theta coefficients.

## 1. Exact finite forest model for a total-matrix entry

Topologically order an acyclic exchange matrix so that
`A=[-B]_+` is strictly lower triangular. Define finite rooted-tree
polynomials recursively, in decreasing type order, by

\[
H_i=1+T_i,
\qquad T_i=z_i\prod_{j>i}H_j^{A_{ji}}.
\tag{1}
\]

A nonempty tree of type `i` has one root of type `i`. For every `j>i`
the root has `A[j,i]` distinguishable slots, each empty or occupied by a
tree of type `j`. All descendant types strictly increase. Consequently
there are finitely many trees, and `H_i` is precisely the generating
polynomial for an optional tree of type `i`.

For an integer vector `n`, introduce the following root structures.

* If `n_i>=0`, there are `n_i` distinguishable optional root slots of
  type `i`.
* If `n_i=-l<0`, there are `l` distinguishable queues. A queue is an
  arbitrary finite ordered list of nonempty type-`i` trees. Its sign is
  `(-1)^(number of trees in the queue)`.

The multidegree counts **all** tree nodes, not just top roots. At any fixed
multidegree `alpha`, every queue has bounded length, so the signed object
set is finite. Its signed generating series is

\[
\prod_i H_i^{n_i}.
\tag{2}
\]

For the half-space formula, take

\[
\alpha=p-q,\qquad n=-(g+Bq).
\]

Then the signed number of these objects of degree `alpha` is exactly

\[
C[p,q]
=\prod_i\binom{n_i+\sum_{j<i}A_{ij}\alpha_j}{\alpha_i}.
\tag{3}
\]

### Proof of (3)

Extract coefficients in the order `z_1,z_2,...,z_n` from (2). After
extracting `alpha_j` nodes of type `j<i`, their child slots contribute
`A[i,j] alpha_j` additional factors `H_i`. The effective exponent of
`H_i` is therefore

\[
r_i=n_i+\sum_{j<i}A_{ij}\alpha_j.
\]

Its `z_i^{alpha_i}` coefficient is `binom(r_i,alpha_i)`, and the
remaining child factors affect only later types. Multiplying these
independent extraction factors gives (3), including negative exponents
via `(1+T)^{-l}=sum_{k>=0}(-1)^k binom(l+k-1,k)T^k`.

When every `n_i>=0`, this is an unsigned count. There is also a direct
count: after fixing the nodes of types `<i`, there are exactly
`n_i+sum_{j<i}A[i,j]alpha_j` distinct available slots of type `i`, and
one chooses `alpha_i` of them. The identity works for every strictly
lower-triangular nonnegative integer `A`, hence for every acyclic
skew-symmetrizable matrix in the stated convention. The combinatorial
identity does not require an ordinary-quiver interpretation of a valued
matrix.

This is a more structured realization of the signed binomials than
independent abstract subsets and multisets: child slots identify concrete
places where a future gluing or reparenting operation could act.

## 2. A local sign-reversing root cancellation

Fix a type and distinguish one positive optional root slot and one
negative queue of that same type. On all pairs other than the pair with
both entries empty, define an involution:

1. If the positive slot contains a tree, empty the slot and prepend that
   tree to the negative queue.
2. If the positive slot is empty and the queue is nonempty, remove the
   first tree of the queue and put it into the positive slot.

The two operations are inverses. They preserve every node, arrow color,
child slot and multidegree. They change the queue length by one and
therefore reverse the sign. The sole unpaired object has both entries
empty. This proves the cancellation of `H_i H_i^{-1}` directly on
finite objects in every fixed multidegree.

Apply it to available child slots and negative root queues of type `i`
in increasing type order. If `R_i` positive slots and `L_i` negative
queues are available, cancel `min(R_i,L_i)` specified pairs. The
unpaired root structures are ordinary optional slots when `R_i>=L_i`,
and negative queues when `R_i<L_i`. Thus this procedure explains exactly
why the surviving scalar factor is the generalized binomial in (3).

The rule preserves an underlying lattice-chain vertex sequence. Hence it
also preserves the half-space predicates, the binary labels `P_j`, and
the external factor `eta` of the previous run. It can be applied inside
every edge decoration of that formula without changing its value.

**Limitation.** This only cancels opposite root structures already
present at one step. In its fully reduced form it recovers the previous
signed-binomial description. It does not yet match a negative object of
one flattened chain to a positive object of a different chain.

## 3. Why deleting negative capacities is not the missing theorem

An appealing proposal is to keep precisely the ordinary forests after
the cancellation in Section 2: replace `binom(r,k)` by zero when
`k>0` and `r<k`, and retain positive binomial coefficients otherwise.
That proposal does not compute theta coefficients.

The failure is visible already for

\[
B=\begin{pmatrix}0&1\\-1&0\end{pmatrix},
\qquad g=(-2,1),\qquad p=(1,1).
\]

The direct matrix entry is

\[
C[p,0]=\binom21\binom01=0.
\]

On the other hand, the two compatible cluster variables of initial
degrees `(-1,1)` and `(-1,0)` have respective F-polynomials

\[
1+z_1,\qquad 1+z_1+z_1z_2.
\]

Their product is the cluster monomial of degree `g`, hence its theta
polynomial is

\[
F_g=(1+z_1)(1+z_1+z_1z_2)
=1+2z_1+z_1^2+z_1z_2+z_1^2z_2.
\]

Its coefficient at `p` is `1`. It is supplied by the **cross-chain**
terms of the half-space formula, and cannot be recovered by a subset
restriction of the direct forest set whose cardinality is zero.

This example is used to reject a general proposed mechanism, not to
replace the all-rank task by a list of special cases. The same failure is
robust: `polytope_mechanism/forest_packet_probe.py` tested 180 inputs
across five rank-two symmetrizable matrices and found 509 coefficient
differences. Its exact integer output is
`polytope_mechanism/forest_packet_probe.json`. The proof above, rather
than the scan, certifies the failure.

## 4. The precise positive gluing problem after this refinement

For consecutive chain steps with increments `alpha=r-q` and
`beta=p-r`, the virtual framing changes by

\[
n(r)=n(q)-B\alpha.
\tag{4}
\]

Each node of an earlier type creates positive child slots at later
types. Equation (4) also creates negative root demands at earlier types
when a later node has already been selected. These are the slots that
must be treated by **reparenting across the time cut**, rather than by
ordinary forest restriction.

An object-level HN interpretation therefore needs a rule that does all
of the following at once:

* moves a complete rooted tree across a chain cut, and changes the
  intermediate lattice point accordingly;
* supplies or cancels the `-B alpha` root structures required by (4);
* preserves the final multidegree and all arrow multiplicity labels;
* pairs the signs including the binary `eta` factor; and
* has a well-defined inverse, including strict zero-pairing boundaries.

The root/queue involution supplies a concrete primitive move for the
second requirement. The first and fourth requirements are not consequences
of that involution. They are the still-unproved bridge. Merely invoking
the existence of an HN filtration does not construct this combinatorial
gluing rule.

## 5. Polyhedral encoding of the actual decorations

The existing signed unit objects have a literal lattice-polytope model.
For fixed chain and fixed coordinate-step pair, the positive binomial
decoration is

\[
1\le u_1<u_2<\cdots<u_k\le r,
\]

whose integer points are subsets. The negative branch is

\[
1\le u_1\le u_2\le\cdots\le u_k\le l,
\]

whose integer points are multisets. Translating the first by
`v_j=u_j-j` identifies it with an order simplex as well. The product over
steps and types is a bounded integral order polytope. The half-space tests
select the chain skeletons, and `eta` assigns their orientations.

This is an exact finite **signed** polytope count. A positive polytope
model still requires compatible gluing between these order polytopes;
counting only the polytopes with positive signs gives the wrong answer.
The forest refinement in Section 1 records the child-slot identifications
which are absent from bare products of simplices and are likely needed
for any such gluing.

## 6. Literature interfaces and audits

### 6.1 CMMM, valuative independence

Primary source: Cheung–Magee–Mandel–Muller,
*Valuative independence and cluster theta reciprocity*,
https://arxiv.org/html/2505.09585v2 (2026-05-21 revision).

The branch read the theorem statements and proof discussion in Sections
3.3–3.5 and 3.8–3.9 of v1, and verified that the v2 revision and its
contents are available. Theorem 3.8 prevents cancellation of extreme
toric valuations; the monicity statement controls Newton vertices.
Neither identifies interior coefficients. The previous run already
supplied the stronger targeted v2 proof audit used for its Newton
pruning algorithm. This branch does not upgrade that algorithm to a
positive coefficient formula.

### 6.2 Mandel, the relevant meaning of atomicity

Primary source: *Theta bases are atomic*,
https://arxiv.org/pdf/1605.03202, Theorem 1 and its proof on page 2.

The theorem uses the scattering atlas. Its coefficient-extraction proof
chooses a point near the relevant theta label. Ordinary cluster charts
need not provide the same positivity tests. Therefore an integer
feasibility problem using only initial adjacent-seed packets cannot invoke
this theorem to conclude that its atoms are exactly theta functions.
This restriction matters for a proposed greedy minimality proof; no
Li–Pan result is needed for the observation.

### 6.3 Fei, Newton polytopes and saturation

Primary sources:

* *Tropical F-polynomials and General Presentations*,
  https://arxiv.org/html/1911.10513v6.
* *Combinatorics of F-polynomials*,
  https://arxiv.org/html/1909.10151v3.

The first provides generic Newton methods for path algebras. The second's
Theorem 5.2 proves support saturation for rigid representations of acyclic
quivers; Remark 5.4 exhibits the need for rigidity. Neither statement
turns arbitrary theta coefficients into counts of all lattice points of
their Newton polytope. The stabilization/facet method remains a possible
boundary recursion, but no all-interior coefficient recursion follows
from the inspected statements alone.

### 6.4 Forest precedents and related sources

Reineke's forest-cell methods are established, not newly claimed here:

* *Cohomology of noncommutative Hilbert schemes*,
  https://arxiv.org/abs/math/0306185.
* *Framed quiver moduli, cohomology, and quantum groups*,
  https://arxiv.org/abs/math/0411101.

The all-integer signed root-queue formulation in Sections 1–2 is proved
directly here. Its geometric interpretation for nonnegative framings
matches the primary-source interface separately audited by the novelty
branch. Negative framings are formal signed extensions, not ordinary
framed moduli.

The novelty branch also identified Leung–Ma–Young,
*Refined Scattering Diagrams and Theta Functions from Asymptotic Analysis
of Maurer-Cartan Equations*, arXiv:1902.05765, Theorem 4.29. That is an
existing marked-tropical-tree Hall theta description under its stated
nondegeneracy assumptions. It prevents a broad claim to the first acyclic
combinatorial theta description, but is not used to fill the gluing gap.

### 6.5 2026 tight-gradings source

Burcroff–Lee–Mou–Musiker–Reineke,
*Cluster scattering diagrams via quiver moduli and tight gradings*,
https://arxiv.org/abs/2511.14672;
https://doi.org/10.1112/jlms.70642 (published July 2026).

The primary publisher text was inspected. The scope is rank two. Its
footprint and tight-grading model is useful for possible tree reparenting
rules, but it supplies no all-rank cross-chain cancellation theorem. No
2026 theorem from this paper was imported into the results above, so its
full proof has not been certified in this branch.

## 7. Route ledger

1. Newton plus monic vertices: checked the CMMM/Mandel distinction;
   insufficient for interior coefficients. This is background, not the
   new research endpoint.
2. Reineke-style root forests: **proved** an exact finite signed forest
   realization of every acyclic `C[p,q]`, including valued integer data.
3. Positive slot/negative queue cancellation: **proved** a local,
   multidegree-preserving sign-reversing involution.
4. Discard all remaining negative capacities: **refuted**, with an exact
   A2 cluster-monomial identity and an independent integer scan.
5. HN gluing by cross-cut tree reparenting: **open**, with the exact
   framing-change equation (4) and boundary requirements identified.
6. Products of order polytopes: **proved signed realization**; no
   sign-free polytope or unjustified support-saturation claim.

The next useful agent task is a specific cross-cut reparenting or
Lagrange-Good involution satisfying (4), not another recounting of
Newton-polytope limitations.
