# Valued primitive phases and arithmetic incidence: general construction

Date: 2026-11-13. Agent: valued_polyhedral_mechanism.

## Status at 12:32 UTC

The local normalization has a **natural finite abelian-group model**, including
functorial contractions. There is now also a general **ramified cut-algebra
theorem at generic framed stability**, proved in Section 10. It constructs an
actual finite polynomial quotient whose full permutation character, rather
than only its dimension, is the ordinary thin-quiver character divided by the
required product of vertex weights over permutation cycles. Its generators
are explicit binomial Euler factors. The proof uses a gain-incidence linear
system of parameters on the full multigraph Stanley--Reisner ring.

The remaining issue is an equivariant gluing across nongeneric stability
walls/zero-time flow degenerations and compatibility with the incoming-only
theta construction. No complete valued theta module is claimed below.

**12:42 update.** Section 11 upgrades the rooted full-cut case to a literal
finite lattice quotient, equivalently phase orbits of graph break divisors.
It has exactly the required character, proved by coinvariants of a column-
divided graph Laplacian. Section 12 records the essential whole-skeleton
obstruction: even after attaching the weight-one frame, phases must mix
different skeleton orbits. This determines what the remaining global maps
must do, rather than proposing another independent local normalization.

The construction uses only integral edge multiplicities, primitive charge
indices, and a tree. It is compatible with graph automorphisms and, with the
correct gcd weights, with all iterated contractions. Exact computations check
4,272 weighted trees and 97 actual quotient/fiber calculations.

## 1. Primitive charges and the relevant local weight

Let `D B` be integral skew-symmetric and let the positive local child charges
be `beta_1,...,beta_n`. Put

\[
d_i=\gcd_j(D_j\beta_{i,j}),\quad S=\sum_i\beta_i,
\quad d_S=\gcd_j(D_jS_j),\quad h=\gcd_i d_i.
\]

For every child edge put `m_ij=|eta(beta_i,beta_j)|`. Integrality of `B` and
`DB` implies `d_i | m_ij` and `d_j | m_ij`, so

\[
\operatorname{lcm}(d_i,d_j)\mid m_{ij},\qquad h\mid d_S.
\]

For a stable spanning-tree term `T` in the ordinary thin-quiver local
intersection-cohomology calculation, the required normalized term is

\[
  \frac{d_S}{\prod_i d_i}\prod_{e\in T}m_e.\tag{1}
\]

The following object realizes (1) before knowing any theta coefficient.

## 2. The phase quotient is an actual finite set

Choose any orientation of the edges of a finite connected tree `T`. Define

\[
 H_T=\prod_{i\in V(T)}\mathbb Z/d_i,
 \qquad E_T=\prod_{e\in E(T)}\mathbb Z/m_e.
\]

For an oriented edge `e:i->j`, define the homomorphism

\[
 \phi_T:H_T\longrightarrow E_T,\qquad
 (\phi_T(x))_e=\frac{m_e}{d_i}x_i-\frac{m_e}{d_j}x_j
 \pmod {m_e}.
\]

This is well defined because the two displayed quotients are integers.
Set `C_T=coker(phi_T)`, considered either as a finite group or its underlying
finite set. Reversing an edge orientation sends its coordinate to its negative
and induces a canonical isomorphism of the resulting groups.

### Proposition 2.1 — order and freeness

There is a canonical identification

\[
 \ker\phi_T=\mu_h,\qquad
 |C_T|=\frac{h\prod_e m_e}{\prod_i d_i}.
\]

Here it is convenient to identify `Z/d_i` with the subgroup
`(1/d_i)Z/Z` of `Q/Z`. The equation on an edge says exactly that the
two vertex phases agree in `Q/Z`. Connectivity makes all phases equal,
and their common value belongs to
`intersection_i (1/d_i)Z/Z=(1/h)Z/Z`. This proves the kernel assertion.
The order formula follows from the first isomorphism theorem. In particular,
if one vertex has weight one, the vertex phase action on `E_T` is free.

The required root decoration is the canonical quotient group

\[
 R_S=\mu_{d_S}/\mu_h.
\]

Thus define the **primitive rooted phase set**

\[
 \mathcal P_T=C_T\times R_S.\tag{2}
\]

Its cardinality is exactly (1). Both factors are defined by the original
charges, their gcds, and the incidence presentation; no coefficient oracle
appears. In the binary case (2) has

\[
 |\mathcal P_T|=|\eta(\beta,\gamma)|
       \frac{d(\beta+\gamma)}{d(\beta)d(\gamma)},
\]

the primitive Lie-bracket multiplicity already proved in the main work.

### A nonconstant-weight example

Take the path `1--2--3` with vertex weights `(2,3,5)` and edge
multiplicities `(6,15)`. Then

\[
 E_T=\mathbb Z/6\times\mathbb Z/15,
 \quad \phi_T(x,y,z)=(3x-2y,5y-3z).
\]

The image has order 30 and there are three cosets, represented by
`(0,0),(0,1),(0,2)`. This is already a nontrivial arithmetic phase object:
replacing each edge by just `m_e/lcm(d_i,d_j)` ordinary arrows would leave
one arrow on each edge and would lose this factor of three.

## 3. Canonical action of graph permutations

Let `sigma` be any graph automorphism preserving the vertex weights and edge
multiplicities. On `H_T` it permutes the vertex factors. On `E_T` it permutes
the edge factors, with a minus sign whenever the chosen orientation of an
edge is reversed. These actions satisfy

\[
 \sigma_E\phi_T=\phi_T\sigma_H.
\]

Consequently they induce an action on `C_T`, hence on `Q[C_T]` and on
`Q[P_T]`; the root quotient is fixed when total charge is fixed. The group
law is inherited from the signed permutation action, so no choice of coset
representatives enters the definition. For a family of trees preserved by
the group, the direct sum over that family is likewise a natural permutation
module.

This statement does **not** say that the generic-stability family of stable
trees is preserved by every equal-color permutation. That is precisely why
the local phase construction has not yet solved the theta character problem.

## 4. Arithmetic incidence and matroid realization

For `e:i->j` put

\[
 a_e=\frac{m_e}{d_i}e_i-\frac{m_e}{d_j}e_j\in\mathbb Z^V,
 \quad A_T=(a_e)_{e\in T}.
\]

For a tree one has the canonical presentation

\[
 C_T\cong\operatorname{coker}(A_T^t:\mathbb Z^V\to\mathbb Z^E).
 \tag{3}
\]

To see this, start from
`C_T=Z^E/(A_T^t Z^V + diag(m_e)Z^E)`. Removing an edge separates the
tree into two parts. The integral vertex vector having entries `d_i` on
one part and zero on the other has image `+/- m_e` on that edge and zero
on all other edges. Hence every `m_e e_e` already belongs to `im A_T^t`,
which proves (3).

The nonzero maximal minor obtained by deleting vertex row `r` has absolute
value

\[
 \frac{d_r\prod_e m_e}{\prod_i d_i}.
\]

Their gcd is the order in Proposition 2.1. Equivalently it is the order of
the torsion subgroup of `coker A_T`; the canonical object (3), rather than
an arbitrarily identified Smith-normal-form group, should be retained when
permutations matter.

Thus the arithmetic normalization is an actual basis multiplicity of the
representable arithmetic matroid determined by the columns `a_e`. This is
more information than divisibility: it retains the finite cokernels and the
maps between them, which arithmetic multiplicities alone would forget.

## 5. Contraction exact sequence and associativity

Let `F` be any subset of the tree edges. Its connected components are `C`.
Give the contracted vertex corresponding to `C` the weight

\[
 h_C=\gcd_{i\in C}d_i.
\]

The surviving edge multiplicities are unchanged. They remain divisible by
the weights of their new endpoints. Edge-coordinate projection induces a
canonical surjection

\[
 C_T\longrightarrow\prod_C C_{T[C]}.
\]

Its kernel is canonically `C_(T/F)`. More precisely,

\[
 0\longrightarrow C_{T/F}\longrightarrow C_T
  \longrightarrow\prod_C C_{T[C]}\longrightarrow0.\tag{4}
\]

**Proof.** Write the edge-coordinate group as `E_F x E_ext`. A class maps
to zero on the forest quotient precisely when its `F` coordinates can be
killed by a vertex phase. After doing so, the remaining ambiguity is the
subgroup `ker(H_T -> E_F)`. Its phases are constant on each forest component,
and its component factor is exactly `mu_(h_C)`. Its action on surviving
edges is the phase map of the contracted graph. This identifies the kernel
with `E_ext/image(prod_C mu_(h_C))=C_(T/F)` and proves (4).

For nested forests, all maps in (4) come from coordinate projection and
quotienting by subgroups of the same vertex phase group. Iterated
contractions therefore commute canonically. The fibers are torsors for the
kernel group. A direct-product splitting is neither canonical nor needed.
This is the correct form of associativity of the phase decoration.

### Essential limitation of the contraction statement

The contracted weight in (4) is `gcd_(i in C) d_i`, **not automatically**
`d(sum_(i in C) beta_i)`. The latter can be strictly larger. Furthermore a
flow-tree contraction replaces pairings with sums of pairings; those sums
need not admit a positive edgewise decomposition. The quotient
`mu_(d(sum beta_i))/mu_(h_C)` records the extra primitive index but does
not by itself construct its compatibility with all such replacements.
Equating these two contractions would hide the central gluing problem.

## 6. Consequence for local polytope terms

Let a local child quiver be acyclic and let a generic deformation of its
anti-attractor stability have stable simple spanning trees `T`. The standard
thin-quiver torus-fixed-point calculation gives

\[
 \dim IH(X_{\theta_0})=\sum_{T\ {
m stable}}\prod_{e\in T}m_e
\]

when the small-resolution hypothesis proved in
`proofs/local_rank_two_ih_interface.md` applies. Therefore the finite union

\[
 \coprod_{T\ {
m stable}}\mathcal P_T
\]

has the desired valued local dimension. This is a purely combinatorial
positive model for the normalization **in a specified generic chamber**.

The theorem stops here. Generic perturbations usually break the stabilizer
of equal-color children. A chamber-independent equivariant gluing, reducing
to the existing full-multigraph IH action when `D=1`, is still required.

## 7. Global free leaf phases: what is and is not available

On a genuine tree whose vertices are all original leaves plus the weight-one
frame, Proposition 2.1 gives a free action of
`prod_leaves mu_(D_color)` on its full edge-label set. It commutes
semidirectly with equal-color leaf permutations and gives exactly the global
divisor `prod_i D_i^(p_i)`.

However, the known collapsed-flow presentation is assembled from local trees
whose vertices are **charges of subtrees**, rather than original leaves.
A leaf weight need not divide an ancestor pairing, so leaf phase shifts
cannot simply be applied to every ancestor label. Equation (4) supplies
honest gluing for fixed incidence trees; extending it through the aggregate
charge replacements is a concrete remaining step.

## 8. Literature refresh and strong-audit record

The sources below are interfaces, not automatically adopted theta theorems.

### 8.1 Jiarui Fei, Arithmetic Kac Theory for Ramified Species

Primary record: <https://arxiv.org/abs/2611.07549>.
Primary full text: <https://arxiv.org/html/2611.07549v1>.
Verified metadata: sole author Jiarui Fei, submitted 5 November 2026,
v1 at 06:58:06 UTC, 47 pages. Original abs and full text were both opened.

Read relevant introduction and Sections 8.1--8.8, including Theorem 8.6 and
the full proof of its stated equivariant PBW input, Proposition 8.3.
The paper explicitly distinguishes absolute and total indecomposable counts,
and explicitly warns that traces, invariant dimensions, and dimensions differ.
Its own Example 8.8 is the degree-(3,2) species with a degree-six arrow.

Independently derived the rank-(1,1) orbit-count formula from the finite
multiplicative groups, before reading the example:

\[
 (q^6-1)(q-1)/((q^3-1)(q^2-1))=q^2-q+1.
\]

Wolfram independently verifies the identity. It agrees exactly with the
paper. This checks a genuine normalization/positivity distinction, not its
all-rank theorem. All six automorphism traces have now been independently
verified by enumeration of invariant connected edge supports, with exact
finite-field orbit factors. Their invariant-dimension polynomial is
`q^2+q+2`, distinct from the generator trace `q^2-q+1`.

**Audit judgment:** the relevant elementary example and the precise scope of
the trace assertion are verified. The full all-rank BPS/twining theorem is
not used as an input to our construction. In particular, the theorem does
not provide a positive valued theta module or a dimension formula for one.

### 8.2 Mandel--Qin, Bracelets bases are theta bases, Appendix A

Primary full text: <https://arxiv.org/html/2301.11101v3>.
Read the covering hypotheses, Lemmas A.5--A.6, Theorem A.7, Example A.10,
and the folding conditions A.12--A.13.

This is genuinely weaker than Zhou's independent-orbit pairing condition.
But Theorem A.7 gives a consistent **larger** diagram containing the folded
cluster diagram; extra incoming walls may occur. Example A.10 explicitly
exhibits unequal theta functions. Even full unfolding only yields the
agreement asserted in A.13 on the positive/negative cluster complexes.
**Not a proof of an arbitrary valued theta folding.**

### 8.3 Arithmetic matroids and orbit harmonics

Primary interfaces:

- D'Adderio--Moci, *Arithmetic matroids, the Tutte polynomial and toric
  arrangements*, <https://arxiv.org/abs/1105.3220>.
- Fink--Moci, *Matroids over a ring*, accepted-author PDF:
  <https://qmro.qmul.ac.uk/xmlui/bitstream/handle/123456789/13039/Fink%20Matroids%20over%20a%20ring%202016%20Accepted.pdf?sequence=1>.
- Reineke--Rhoades--Tewari, *Zonotopal algebras, orbit harmonics, and
  Donaldson--Thomas invariants of symmetric quivers*,
  <https://arxiv.org/pdf/2207.11861>.

The third paper supplies natural graph-permutation modules via break divisors
and orbit harmonics, but its DT comparison requires **symmetric quivers with
enough loops**. Our local anti-attractor quiver is acyclic and its Euler form
is symmetric only on the stability kernel. No identification is inferred.
The promising reusable feature is the finite arithmetic presentation and its
contraction maps, now proved directly in Sections 2--5 above.

### 8.4 Orbifold/stringy/Ehrhart route: partial and not equivariant enough

- Borisov--Chen--Smith, *The orbifold Chow ring of toric Deligne--Mumford
  stacks*, <https://arxiv.org/abs/math/0309229> and author PDF
  <https://mast.queensu.ca/~ggsmith/Papers/borisovChenSmith.pdf>.
- Karu, *Ehrhart analogue of the h-vector*,
  <https://arxiv.org/pdf/math/0607286>.
- Maxim--Schuermann, *Weighted Ehrhart theory via equivariant toric geometry*,
  <https://arxiv.org/pdf/2405.02900>, verified PDF v2 dated 29 December 2025.

The weighted incidence configuration above gives a toric DM quotient at
generic stability. The finite stabilizer at a tree point has order `|C_T|`;
its inertia sectors give the desired arithmetic Euler weight. This is a
natural geometric realization of the **identity dimension only**.

It cannot replace the existing skew IH module without an additional theorem:
already the full multigraph K_(2,2) with two arrows per pair has local IH
character `(16,8,8,0)`, whereas collapsing to four weighted columns produces
a one-dimensional coarse polytope and loses essential equivariant stalk
information. An untwisted inertia-sector construction has no supplied
mechanism for the last zero trace. The parent independently identified the
same issue. Hence this route is retained as an arithmetic local-system
interface for the **full multigraph fan**, not adopted as the answer.

### 8.5 Other researched interfaces

Hamilton--Hoskins--Jackson, *Affine Non-Reductive GIT and moduli of
representations of quivers with multiplicities*, author PDF
<https://www.math.ru.nl/~vhoskins/Affine_NRGIT.pdf>, was checked in its
application theorem and Section 7 setup. Its main application uses a **common**
truncated-polynomial multiplicity at every vertex, not arbitrary different
`D_i`. It does not directly supply the required valued local model.

The older local project already audited Fei's ramified-quiver cluster
characters (arXiv:2610.09868v2). That work has good-modulation/reachability
hypotheses and leaves a multiplication interface open. It is not a general
positive-theta theorem. No duplicated attempt to treat it as one is made.

## 9. Exact computation record

`computations/valued_polyhedral_mechanism/phase_groups.py` constructs the
image subgroup and actual cosets, and checks contraction fibers.

- All labelled trees on 2--4 vertices, vertex weights 1--4, with bounded
  actual edge-label sets: 4,272 exact kernel/order checks, all passed.
- 97 sampled cases also enumerate the actual quotient sets, enumerate the
  kernel directly, and check every contraction fiber against `C_(T/F)`;
  all passed.
- Explicit `(2,3,5)` path gives three cosets of size 30.
- A further 112 exact permutation group-law checks passed on actual phase
  quotients. The path with weights `(1,2,3)` and multiplicities `(4,6)` gives
  `C_T=Z/4`; its contraction sequence is the nonsplit sequence
  `0 -> Z/2 -> Z/4 -> Z/2 -> 0`. This verifies why a product of anonymous
  cardinalities cannot replace the finite group presentation.
- Actual Wolfram evaluator checked 10,000 gcd/lcm pairs and the signed
  finite-field quotient polynomial. An earlier evaluator expression emitted
  a parser/precedence warning; it was replaced by an explicit corrected
  expression and is not counted as a successful computation.

The theorems in Sections 2--5 are proved algebraically; the calculations
check the implementation and the proposed canonical maps.

## 10. Generic framed ramified cut-algebra theorem

This is a general construction, not a numerical inference from theta
coefficients. It covers arbitrary acyclic thin quivers with a distinguished
weight-one vertex, subject to generic stability. It retains all individual
parallel arrows in its proof.

### 10.1 Input and explicit algebra

Let `Q` be a connected finite acyclic quiver, with vertices
`V={0,1,...,n}`, where `0` is distinguished. Let its multiplicity from `i`
to `j` be `m_ij`. Give its vertices positive weights `d_i`, with `d_0=1`,
and assume

\[
 \ell_{ij}:=\operatorname{lcm}(d_i,d_j)\mid m_{ij}.
\]

Let `theta(V)=0`, with `theta(S) != 0` for every nonempty proper vertex
subset. Suppose the thin stable moduli is nonempty. We use the convention
that every subrepresentation has positive `theta`; thus the forbidden
subsets are those with `theta(S)<0`. For such `S`, let `out(S)` consist of
all directed arrows from `S` to its complement.

Put `h_ij=gcd(d_i,d_j)`, `u_0=0`, and `deg(u_i)=d_i`. Define

\[
 Q_{ij}(u_i,u_j)=
 \left(u_j^{d_i/h_{ij}}-u_i^{d_j/h_{ij}}\right)^{m_{ij}/\ell_{ij}}.
 \tag{10.1}
\]

This is a homogeneous polynomial of weighted degree `m_ij`. Define, over
`Q` or `C`,

\[
 R_{\rm val}(Q,\theta,d)=
 \frac{\mathbb Q[u_1,\ldots,u_n]}
 {\left(\prod_{i\in S,j\notin S}Q_{ij}(u_i,u_j):
              \theta(S)<0\right)}.\tag{10.2}
\]

Zero-multiplicity pairs are omitted. An empty product makes the quotient
zero, consistently with an empty stable locus; the theorem concerns the
nonempty case.

Let `G` be a finite group of quiver automorphisms fixing `0`, preserving
`d` and `theta`. Parallel-arrow indices are matched under these
automorphisms. Then (10.2) has its evident `G` action by permutation of
the variables. The definition is independent of all theta coefficients,
intersection-cohomology dimensions, or character multiplicities.

### Theorem 10.2

The algebra (10.2) is finite dimensional. Let `R_raw` be the ordinary thin
quiver Chow ring with `u_0=0`, presented using the factors
`(w_j-w_i)^{m_ij}` and `deg(w_i)=1`. For every `sigma in G`,

\[
 \operatorname{Tr}(\sigma;R_{\rm raw};q)
 =\operatorname{Tr}(\sigma;R_{\rm val};q)
   \prod_{c\in\operatorname{Cycles}(\sigma|_{V\setminus\{0\}})}
      \left(1+q^{|c|}+\cdots+q^{(d_c-1)|c|}\right).\tag{10.3}
\]

Here `d_c` is the common weight along the cycle. In particular,

\[
 \operatorname{Tr}(\sigma;R_{\rm val})
 =\frac{\operatorname{Tr}(\sigma;R_{\rm raw})}
       {\prod_c d_c}.\tag{10.4}
\]

Thus the cycle normalization is realized by an actual naturally presented
module. It is not justified merely by integrality of the right side.

### 10.3 Gain-incidence lemma

Let `E` be the set of individual arrows, including all parallel copies, and
let

\[
 K=\{J\subseteq E:E\setminus J\text{ is theta-stable}\}.
\]

This is the simplicial complex of the complete smooth normal fan of the
generic thin-quiver flow polytope, allowing ghost vertices. Its facets are
the complements `E\setminus T` of stable spanning trees `T`. Consequently
its Stanley--Reisner ring `S=C[z_e:e in E]/I_K` is Cohen--Macaulay of
dimension `r=|E|-n`. The cut monomials
`prod_(e in out(S)) z_e`, for forbidden `S`, generate `I_K`: a support
fails stability precisely when it has a forbidden vertex subset with every
outgoing arrow zero.

Assign an arbitrary nonzero complex gain `zeta_e` to every arrow. Put

\[
 L_e(w)=w_j-\zeta_e w_i\quad(e:i\longrightarrow j),\qquad w_0=0,
\]

and let `A_zeta:C^E -> C^n` send the arrow basis to the coefficient
vectors of these forms. The matrix on the columns of any spanning tree
is invertible. Indeed, remove a leaf different from `0`; its row contains
just one nonzero entry, equal to `1` or `-zeta_e`. Repeating proves the
determinant is a nonzero signed product of gains. In particular `A_zeta`
is onto, and its kernel has dimension `r`.

On a facet `J=E\setminus T`, the projection
`ker(A_zeta) -> C^J` is an isomorphism: prescribe the `J` coordinates and
solve uniquely for the `T` coordinates using the tree matrix. The
Stanley--Reisner criterion for a linear system of parameters therefore
shows that `ker(A_zeta)` is an l.s.o.p. in `S`. Cohen--Macaulayness makes
it a regular sequence. Hence

\[
 R_{\zeta}=S/(\ker A_\zeta)
  \simeq\frac{\mathbb C[w_1,\ldots,w_n]}
  {\left(\prod_{e\in\operatorname{out}(S)}L_e(w):\theta(S)<0\right)}
 \tag{10.5}
\]

is finite dimensional for **every** assignment of nonzero gains. Possible
unbalanced cycles do not invalidate this statement: the l.s.o.p. test uses
the complementary stable trees, whose determinants never vanish.

### 10.4 Equivariant character, without an assumed flat family

Assume the gains are preserved by `G`, using the fixed matching of
parallel-arrow indices. Then `A_zeta` is equivariant. In the representation
ring of `G`, the exact sequence

\[
 0\longrightarrow\ker A_\zeta\longrightarrow\mathbb C^E
   \longrightarrow\mathbb C^{V\setminus\{0\}}\longrightarrow0
\]

shows that the `G` representation `ker A_zeta` is independent of the
gains. The equivariant Koszul resolution of the regular sequence gives

\[
 \operatorname{Tr}(\sigma;R_\zeta;q)
  =\operatorname{Tr}(\sigma;S;q)
      \det(1-q\sigma\mid\ker A_\zeta).\tag{10.6}
\]

Both terms on the right depend only on the fixed permutation action, not
the gains. Setting every gain equal to one recovers `R_raw`, and proves
equality of their graded characters. Thus no unproved claim about
equivariant trivializations of a family is needed.

### 10.5 Full phase specialization and invariant algebra

For each bundle `i -> j`, choose as its gains every element of
`mu_(ell_ij)`, each repeated `m_ij/ell_ij` times. Match these gain labels
under `G`. Set `u_i=w_i^(d_i)`. Then

\[
 \prod_{\zeta\in\mu_{\ell_{ij}}}(w_j-\zeta w_i)^{m_{ij}/\ell_{ij}}
 =\left(w_j^{\ell_{ij}}-w_i^{\ell_{ij}}\right)^{m_{ij}/\ell_{ij}}
 =Q_{ij}(u_i,u_j).\tag{10.7}
\]

Let `A=prod_(i!=0) mu_(d_i)` act on the `w` variables by scalar
multiplication. This action preserves every cut polynomial, and `G`
normalizes it. Since `C[w]` is free over `C[u]` with the canonical
monomial basis

\[
 W_d=\operatorname{span}\{w_1^{a_1}\cdots w_n^{a_n}:0\le a_i<d_i\},
\]

equation (10.7) gives an actual graded `(A semidirect G)`-module
isomorphism

\[
 R_\zeta\simeq R_{\rm val}\otimes W_d,\qquad
 R_\zeta^A=R_{\rm val}.\tag{10.8}
\]

The phase group acts regularly on the monomial residue characters in
`W_d`. A permutation fixes a monomial in `W_d` exactly when its exponents
are constant on each vertex cycle. Consequently its graded trace is the
product in (10.3). Combining (10.6)--(10.8) proves Theorem 10.2.

The algebra (10.2), its basis reduction, and its permutation action are
defined over `Q`; complex roots of unity only enter the proof. Thus there
is no rational-descent gap in the resulting valued module.

### 10.6 Rooted tree specialization

For a tree with its weight-one distinguished vertex, the complete
intersection

\[
 \mathbb Q[u_i:i\ne0]/(Q_{ij}(u_i,u_j):\{i,j\}\in T)
\]

has length `prod_e m_e / prod_(i!=0) d_i`. Choose the root orientation
only for elimination. The equation for a child is monic of degree
`m_e/d_child` in that child's variable. Eliminating from the leaves
gives a basis with exponents below these bounds and proves regularity
and the length directly. Root-preserving automorphisms act on this
complete intersection before any dimension is taken.

At all gains one it is the ordinary full-multiplicity tree model. At full
phase gains it realizes the primitive arithmetic normalization. This is
consistent with Sections 2--5; it does not identify a generic monomial
basis with a canonical chamber-independent IH basis.

### 10.7 Exact scope and the remaining interface

The theorem handles complete generic chambers, all finite symmetries
preserving the chamber, and nonconstant vertex weights. It is stronger
than a tree-by-tree cardinality argument. It also gives a concrete
candidate for the finite coefficient algebras in a valued minimal-extension
construction.

It does **not** assert that ordinary cut quotients give theta coefficients
for arbitrary cyclic quivers. Earlier computations in
`computations/canonical_bridge/squarefree_cut_quotient_results.json`
already disprove that assertion. Nor does it yet pass from a generic
chamber to the anti-attractor IH primitive space: generic perturbations
may break the required group, and gain cycles can change the ranks of
non-tree subconfigurations. The l.s.o.p. proof controls full generic
quotients but does not automatically supply compatible restriction maps
on the nongeneric full fan.

Two precise continuation interfaces remain under investigation:

1. Construct the finite coefficient system on the full multigraph normal
   fan with ramified cut maps, proving minimal-extension and equivariant
   primitive compatibility.
2. Add a weight-one auxiliary source with a group-invariant generic framed
   stability, apply Theorem 10.2, and recover the local primitive part
   through natural Hall/cut maps compatible with the phase action. A
   formal plethystic subtraction or dimension division alone is insufficient.

### 10.8 Literature verification used in this theorem

Franzen, *Chow Rings of Fine Quiver Moduli are Tautologically Presented*,
<https://arxiv.org/pdf/1307.3066>, verified v2 dated 15 January 2015.
Read Proposition 3.2, Lemma 3.5, Proposition 3.7 and the toric-case proof.
The precise ordinary input is the forbidden outgoing-cut presentation for
generic thin acyclic quiver moduli. The gain-incidence deformation,
phase-invariant quotient (10.2), and cycle-character formula (10.3) are
proved above and are not attributed to Franzen.

## 11. Weighted chip-firing and a literal polyhedral phase set

### 11.1 The full-cut extension of the gain theorem

The proof of Section 10 only uses the following property of `K`: it is a
Cohen--Macaulay complex whose facets are complements of spanning trees of
the graph. In particular it applies to the independence complex of the
cographic matroid. Its nonfaces are generated by graph bonds, so its
specialization is the **full-cut algebra**

\[
 A_{G,d}=\frac{\mathbb Q[u_i:i\ne0]}
 {\left(\prod_{\{i,j\}\in\partial S}Q_{ij}(u_i,u_j):
       \varnothing\ne S\subseteq V\setminus\{0\}\right)}.\tag{11.1}
\]

Here `G` is any finite connected undirected multigraph, `0` is a fixed
root of weight one, `m_ij` is the multiplicity of the edge pair, and
`lcm(d_i,d_j)` divides `m_ij`. Formula (10.1) defines `Q_ij` after choosing
one orientation per pair; its sign has no effect on the ideal. This theorem
requires neither an acyclic orientation nor a stability parameter. It uses
the cographic independence complex, not the matroid of the gain arrangement,
which can be different.

By the same tree-minor and Koszul arguments, (11.1) has the graded character
formula (10.3) relative to the ordinary full-cut algebra `A_G`. We now give
a finite **set** with its ungraded character.

### 11.1a Rooted equivariance, including edge reversals

The orientation-preserving equivariance proof of Section 10 does not by
itself cover an arbitrary automorphism of an undirected graph: reversing
an edge can change the monomial linearization on its gain factors. The
following argument, independently supplied by the `gain_fan_extension`
agent and checked here, fills that gap when the root is fixed.

Fix an automorphism `sigma`. Write `E` for the individual edge set, with
a gain-linear form `ell_e` attached to each edge, and use the natural
monomial action `sigma(e_e)=c_e e_(sigma e)` making the map
`e_e -> ell_e` equivariant. For an edge orbit `c` put
`z_c=lambda_c q^|c|`, where `lambda_c` is the product of its scalars.
Let `W` be the nonroot vertex permutation space. The cographic
Stanley--Reisner support expansion, followed by the regular linear
quotient, gives the exact formula

\[
 \operatorname{Tr}(\sigma;R_\zeta;q)=
 \frac{\displaystyle\sum_{\substack{H\subseteq E\text{ spanning, connected}\\
                                      \sigma H=H}}
       \prod_{c\subseteq E\setminus H}z_c
       \prod_{c\subseteq H}(1-z_c)}
      {\det(1-q\sigma\mid W)}.\tag{11.1a}
\]

To see the formula directly, a fixed monomial support is a union `F` of
edge orbits with connected complement. Its positive-exponent monomials
contribute `prod_(c in F) z_c/(1-z_c)`. Multiplication by
`det(1-q sigma|E)/det(1-q sigma|W)`, the Koszul factor for the kernel
of the gain-incidence map, gives (11.1a). This proves the formula with
all scalar linearizations retained.

A `sigma`-invariant spanning subgraph `H` is connected if and only if its
quotient on vertex orbits is connected. The nontrivial direction uses the
fixed root: its connected component is `sigma`-stable, and a quotient
path from the root orbit inductively puts every vertex of each successive
orbit into that component. Consequently edge orbits internal to one
vertex orbit do not affect connectedness. Summing over their presence or
absence gives `z_c+(1-z_c)=1`, so they disappear from (11.1a).

For an edge orbit joining distinct vertex orbits, return around the orbit
cannot interchange its endpoints. The product scalar is therefore one.
Furthermore, if several edge orbits join the same two vertex orbits,
summing over the nonempty choices gives
`1-prod_c z_c=1-q^m`, where `m` is their total number of individual edges;
choosing none gives `q^m`. The remaining numerator thus depends only on
the multiplicities between vertex orbits. It is independent of all gain
values and all parallel-edge label permutations compatible with the
vertex action.

This proves the full graded gain-character identity for **every**
root-preserving graph automorphism. It also explains why the analogous
unrooted claim is false: without a fixed root, a connected quotient can
come from disconnected components permuted transitively by `sigma`.
No unrooted gain-character invariance is used in Section 11.

### 11.2 Definition from a weighted Laplacian

Let `L` be the ordinary reduced graph Laplacian, with the root row and
column deleted:

\[
 L_{ii}=\sum_{j\in V}m_{ij},\qquad L_{ij}=-m_{ij}\ (i\ne j).
\]

Put `D_*=diag(d_i:i!=0)` and

\[
 M=L D_*^{-1},\qquad
 \operatorname{Jac}_{d}(G,0)=\mathbb Z^{V\setminus\{0\}}/M\mathbb Z^{V\setminus\{0\}}.
 \tag{11.2}
\]

Every column of `L` is divisible by its vertex weight, hence `M` is
integral. Connectedness makes `L` positive definite, so the quotient is
finite. A root-preserving graph automorphism preserving the weights
commutes with `L`, `D_*`, and `M`; thus it acts on this quotient without
choosing a Smith-normal-form basis.

Matrix `M` is also the reduced column Laplacian of the directed multigraph
having `m_ij/d_i` arrows from `i` to `j` (including the sink `0`). Thus
(11.2) is a direct weighted chip-firing presentation. We do not identify
ordinary directed parking functions with recurrent or superstable
configurations without the appropriate directed convention.

An entirely explicit invariant polyhedral representative set is

\[
 \mathcal Z_{G,d}=
 \left\{z\in\mathbb Z^{V\setminus\{0\}}:
           0\le(M^{-1}z)_i<1\text{ for all }i\ne0\right\}.
 \tag{11.3}
\]

Every coset of `M Z^(V\0)` has exactly one representative in this half-open
parallelotope. A permitted permutation preserves the parallelotope, since
it commutes with `M` and permutes the coordinates of `[0,1)^n`. Therefore
(11.3) is a literal finite integer-point set with the natural permutation
action of (11.2).

### Proposition 11.3 — free phases on the ordinary critical group

Let `Jac(G,0)=Z^n/L Z^n`. There is a canonical equivariant short exact
sequence

\[
 0\longrightarrow\prod_{i\ne0}\mathbb Z/d_i
 \xrightarrow{\ \iota\ }\operatorname{Jac}(G,0)
 \longrightarrow\operatorname{Jac}_{d}(G,0)\longrightarrow0,
 \qquad \iota(x)=M x\pmod{L\mathbb Z^n}.\tag{11.4}
\]

Indeed `M D_*=L`, so the displayed map is well defined. If `M x=L y`,
invertibility gives `x=D_*y`; thus its kernel is zero. Quotienting by its
image is exactly (11.2). Translation by this subgroup is free on the
ordinary critical group.

The same action can be phrased on break divisors. The unique break-divisor
representative of a degree-genus divisor class identifies `Break(G)` with
`Pic^genus(G)`. Subtracting `genus*[0]` identifies this torsor equivariantly
with `Jac(G,0)`, because the root is fixed. Hence the finite set in (11.2)
is exactly the set of phase-translation orbits of break divisors. This is
an action on divisor **classes**, followed by their canonical break
representatives; it is not the naive operation of adding chips to a fixed
spanning-tree presentation.

### Proposition 11.4 — full fixed-point formula

Let `sigma` be any permitted permutation. If `C` runs through its cycles
on the nonroot vertices, then

\[
 \left|\operatorname{Jac}_{d}(G,0)^\sigma\right|
 =\frac{\left|\operatorname{Jac}(G,0)^\sigma\right|}
        {\prod_C d_C}.\tag{11.5}
\]

**Proof.** For any endomorphism `sigma-1` of a finite abelian group `J`,
its kernel and cokernel have the same order. Consequently
`|J^sigma|=|J_sigma|`. Taking coinvariants is right exact, while the
coinvariant lattice of the vertex permutation lattice is freely generated
by its vertex cycles. Thus

\[
 (\operatorname{coker}M)_\sigma=\operatorname{coker}\overline M.
\]

In the cycle basis, `bar M_(C,D)=sum_(i in C) M_(i,j)` for any one
`j in D`; this does not depend on the representative. The analogous
formula holds for `bar L`, and therefore

\[
 \overline M=\overline L\operatorname{diag}(d_C^{-1}).
\]

These matrices are nonsingular over `Q`: they are induced by an invertible
equivariant map on the invariant/coinvariant vector space. Taking absolute
determinants proves (11.5). In particular, this is a fixed-point theorem,
not a mistaken claim that every free equivariant finite cover divides
fixed-point numbers by its total degree.

### Corollary 11.5 — positive finite model for the ramified full-cut algebra

As ungraded rational representations of every permitted finite group,

\[
 A_{G,d}\ \cong\ \mathbb Q[\operatorname{Jac}_{d}(G,0)]
 \ \cong\ \mathbb Q[\mathcal Z_{G,d}].\tag{11.6}
\]

The ordinary full-cut algebra has the ungraded representation of
`Q[Break(G)]` by the cocircuit/P-space decomposition and
Reineke--Rhoades--Tewari's Theorem 3.3. Rooting identifies this with
`Q[Jac(G,0)]`. Its character, divided by the cycle factors in (10.4), is
the character of (11.2) by Proposition 11.4, proving (11.6). The equality
of characters proves the representation isomorphism; it does not select a
canonical basis of the graded polynomial algebra.

The ordinary matrix-tree theorem also gives

\[
 |\mathcal Z_{G,d}|=\det M
  =\sum_{T\text{ spanning tree}}\frac{\prod_{e\in T}m_e}{\prod_{i\ne0}d_i}.
 \tag{11.7}
\]

Every summand is the rooted phase-tree count of Section 2. Equations
(11.2)--(11.6) assemble these counts into a chamber-free finite permutation
object, without choosing a spanning-tree bijection. This supplies a concrete
polyhedral and chip-firing interface for the global valued construction.

### Corollary 11.6 — Young positivity and a strict-chamber count

Suppose the full product `Gamma=prod_a S_(V_a)` of symmetric groups on
specified vertex-color classes acts on the rooted graph, preserving the
weights. Then the finite set (11.3) gives an explicit Young permutation
model. Indeed the stabilizer of a lattice point `z` is

\[
 \operatorname{Stab}_\Gamma(z)
 =\prod_a\prod_{t\in\mathbb Z}S_{\{i\in V_a:z_i=t\}}.
 \tag{11.8}
\]

Every orbit module is induced from the trivial representation of this
Young subgroup. Hence the ungraded Frobenius characteristic of
`A_(G,d)` is a nonnegative sum of products of complete symmetric
functions. This is stronger than Schur positivity and follows from the
actual coordinate action, without a character reconstruction.

Choose an order on each color class. The multiplicity of the product
sign representation is exactly

\[
 \#\left\{z\in\mathbb Z^n:
       0\le M^{-1}z<\mathbf1,\quad
       z_{a,1}<z_{a,2}<\cdots<z_{a,|V_a|}\ \text{for each }a\right\}.
 \tag{11.9}
\]

An orbit contributes one sign copy if all its same-color coordinates
are distinct, and contributes zero otherwise; in the former case there
is exactly one point in the indicated strict chamber. The proof only
uses invertibility of the integral matrix `M` and its commutation with
`Gamma`; symmetry or positive definiteness of `M` is unnecessary.
Half-open boundary choices are preserved by coordinate permutations.

### Exact verification for Section 11

`weighted_jacobian.py` completed 6,000 connected weighted graph inputs
with 1--7 nonroot vertices, including 3,776 nonidentity permitted
permutations. All determinant and cycle formulas passed. The first
1,500 inputs were checked independently by Smith normal forms of both
coinvariant presentations, giving 3,000 such checks. On 120 inputs the
actual phase injections, finite coset fibers, fixed points, and canonical
parallelotope representatives were enumerated. The largest ordinary
critical-group order in the test was `594168549120000`.

`fullcut_jacobian_character.py` independently constructed ordinary,
full-gain, and weighted cut quotients by Groebner bases and computed
normal-form permutation traces. All eight graded comparisons passed,
including automorphisms reversing edges in the rooted triangle and the
full `S_3` cycle types of the rooted complete graph on four vertices.
The ungraded traces also agreed with actual weighted-Jacobian fixed
points. The general proofs above, rather than these finite tests,
establish the claims.

### Sources and scope for Section 11

- Reineke--Rhoades--Tewari, <https://arxiv.org/pdf/2207.11861>, Section 2,
  especially (2.2), (2.15), and Theorem 3.3. Its general graph
  orbit-harmonics theorem is used here; its separate symmetric-quiver DT
  comparison is not used.
- An--Baker--Kuperberg--Shokrieh, *Canonical representatives for divisor
  classes on tropical curves and the Matrix--Tree Theorem*,
  <https://arxiv.org/abs/1304.4259>, for the unique break representative.

The weighted quotient, free phase subgroup, cycle determinant identity,
and parallelotope model are proved directly above. Section 11 concerns
full-cut graph modules; it does not assert that the entire theta module is
one full-cut graph module.

## 12. Why the global phase action must mix skeletons

The parent found that dividing an unframed local IH character by vertex
cycle weights can fail to be a character. We tested the stronger possibility
of first assembling an **entire framed skeleton orbit** and only then
dividing by the original leaf weights. That possibility also fails.

Take the genuinely nonconstant primitive symmetrizer and data

\[
 D=(1,2),\quad B=\begin{pmatrix}0&2\\-1&0\end{pmatrix},
 \quad g=(-6,2),\quad p=(2,2).
\]

The raw skew input is `C=DB=[[0,2],[-2,0]]`, `g'=Dg=(-6,4)`.
The group is `S_2 x S_2`; character entries below are ordered as identity,
second-color swap, first-color swap, both swaps. Actual positive-flow
enumeration gives two skeleton orbits:

| Orbit | Raw character | Divided by `(4,2,4,2)` | Irreducible multiplicities |
|---|---|---|---|
| Two paired children attached to the frame | `(32,0,0,8)` | `(8,0,0,4)` | `(3,1,1,3)` |
| Frame attached to one simultaneous four-child node | `(64,32,32,0)` | `(16,16,8,0)` | `(10,2,6,-2)` |
| Sum | `(96,32,32,8)` | `(24,16,8,4)` | `(13,3,7,1)` |

The simultaneous node is `K_(2,2)` with two arrows per pair. Its local
IH character is `(16,8,8,0)`; the root bracket has multiplicity four.
The negative multiplicity in the second row proves that an independent
phase-invariant module on that entire skeleton orbit cannot have the
required normalization. The sum agrees with all four cycle values from the
independent valued incoming recursion.

Therefore the sought phase action or complex must relate the different
skeleton presentations. This is compatible with a global cut, divisor, or
wall-crossing construction, and excludes the particular strategy of
normalizing each completed tree separately. The computation is a test of
a general gluing proposal, not an attempt to replace the general problem
by a rank-two coefficient catalogue.

Reproducible source and exact output:
`computations/valued_polyhedral_mechanism/rooted_orbit_normalization.py`
and `rooted_orbit_normalization_results.json`.

An intermediate message guessed that the same skeleton occurred at
`g=(-3,1)` by scaling only the framing. Direct enumeration disproved that
guess; the incorrect input was immediately withdrawn. The displayed
`g=(-6,2)` input and both complete orbit rows were then independently
enumerated and compared to incoming recursion, as retained in the output.


## 13. A whole attached phase algebra, beyond individual trees

The general construction and proof are now in
`agents/valued_gale_attached_theorem.md`. For two vertex weights, every
primitive positive slope and every multiple, it defines a finite descended
attached algebra by explicit ramified Gale equations and saturations.
It proves its natural phase cover, the full permutation-cycle character
normalization, and Young positivity. The proof compares two adjacent
generic framed cut models and uses an actual core/attached family to
mix all tree presentations before taking phase invariants. It retains
the general determinant `kappa=gcd(d_A*a,d_B*b)`, its extra constant
decoupling sign, and the saturated-lattice unit-base-change argument.

The new computation checked 12,000 primitive-slope inputs at every
subset, totaling 11,304,916 numerical sign/nonvanishing tests, plus
54,334 center/framing identities and 108 actual localized attached
Groebner ideals. All passed. The external Wolfram receipt for the
weighted-Jacobian finite point sets is in
`computations/valued_polyhedral_mechanism/weighted_jacobian_wolfram.json`.

The remaining wall interface is being proved separately from ordinary
framed HN: the attached ordinary algebra with determinant `kappa` should
represent the `kappa`-th power of the corresponding raw two-input wall
function. No arbitrary-rank valued theta theorem is inferred before
that normalization and the incoming-completion interface are checked.

### Literature and route refresh, 13:10 UTC

- Re-read the primary full text of Qiyue Tang, Hexagon2611.00238v1,
  Sections 3--8. The new valued theorem is an independently written
  adaptation of the finite-factor and unit-deformation mechanisms; the
  paper's concluding all-rank assertion is not imported.
- Confirmed An--Baker--Kuperberg--Shokrieh1304.4259v2, Theorem1.3,
  on the primary PDF: uniqueness of integral break representatives is
  exactly the input used in Section11.
- Search for a prior ramified Gale/core-attached theorem did not locate
  a relevant primary result. This is a search outcome, not a novelty
  claim.
- Located Franzen--Reineke1512.03748 / ANT12(2018), whose Theorems6.2
  and8.1 give the established ordinary HN and semistable-cut interface.
  Its primary proof is now being checked for the arbitrary-framing
  normalization.
- The smooth-toric permutation paper2609.06597 is being audited by
  the separate `local_permutation_upgrade` agent. Its scope does not
  automatically supply a finite model for singular IH.

## 14. General many-slope whole-factor descent and local wall powers

The ordinary two-input power interface is now proved in
`agents/valued_gale_wall_identification.md` and independently checked in
`agents/valued_gale_independent_review.md`. It recovers every cycle trace
by all-alphabet Vandermonde alternation, and represents the arbitrary
framing as the ordinary integer power of the ray function. The 1,176
all-cycle comparisons and 1,176 framing-shift comparisons passed.

The construction has now been extended to any finite rank-two charge
list in a pointed cone, not only two input slopes:

- `agents/many_slope_gain_attached_theorem.md` proves uniform properness
  of the attached special scheme over the nonzero gain/target torus.
  Balanced zero-edge components and a DVR valuation argument prevent
  coordinates from escaping or approaching zero. A regular-base square
  complete-intersection argument gives constant full generic character;
  full Artin factors are recovered individually after specialization.
  It avoids the false implication that T-torsion-freeness implies
  flatness over a multiparameter base.
- `agents/many_slope_gale_wall_identification.md` proves the ordinary
  core/attached and HN interface. The frame functional shifts by
  eta(core_charge,-), leaving its value kappa on the output ray fixed.
  Arbitrary unit targets absorb the multitype decoupling constants.
  Full Frobenius characteristic is omega ch D_val=[content]rho_D(f)^kappa,
  with rho_D(p_n(X_t))=p_n(X_t)/d_t.
- A Bezout choice of an ambient integral frame gives
  kappa=gcd_i D_i s_i, directly realizing the primitive ambient wall
  normalization. A sufficiently large tangential shift puts the frame
  and charges in one pointed cone without changing this value.

The parent independently read the many-slope proofs. Its requested
repairs are included: residue points enter the finite completed factor
before Artin-local reasoning is applied; the regular local dimension is
made explicit; and the valuation gap uses the positive balanced core
rather than incorrectly using the full charge when outside coordinates
already have valuation zero. This is a local theorem; the global
incoming-only finite grammar is being constructed separately.

### Independent computation and route refresh, 14:07 UTC

`computations/valued_polyhedral_mechanism/many_slope_gain_checks.py`
computes actual horizontal attached Groebner algebras for three slopes
(1,0),(1,1),(0,1), weights (1,2,1), and mixed gain packets. Six parameter
points, including ordinary and full roots-of-unity gains, all have length
40. The actual phase involution has trace zero. Its invariant quotient
has length20, independently checked as intersection lengths8+2*6.
The external Wolfram resultant receipt is
`computations/valued_polyhedral_mechanism/many_slope_wolfram_receipt.json`.
Coordinate-zero resultant factors were removed explicitly because all
attached coordinates are units. These checks concern the full Artin
algebra, including multiplicities.

The current literature refresh located and read the relevant primary
parts of Fei2610.09868v2. The targeted audit is
`agents/fei_2610_ramified_interface_audit.md`. Its cyclic trace formulas
and order-dependent example are independently checked. Its complete
basis theorem is not imported; the source itself distinguishes its basis
from individual theta elements. No false trace-to-dimension identification
is made.

Novelty boundary: Tang2611.00238 already treats valued positivity by
ambient lattice enlargement. The contribution here is the explicit
finite ramified phase quotient and full permutation character, retaining
original labels and permitting mixing across flow-tree presentations.
It is not a claim of first valued cluster positivity.

## 15. Global Young modules and complete elements under reddening

The subsequent global positive event/Dyck construction is now proved in
`agents/valued_global_assembly.md`, with independent audits in
`agents/valued_event_dag_independent_review.md` and
`agents/tight_grading_normal_audit.md`. The literal original-color
elementary profiles can be promoted to full symmetric-group objects:

`agents/valued_young_functor_reddening.md` defines the finite species by
putting external labels into distinguished original-color leaf blocks.
Each skeleton gives an actual induced Young permutation module. For the
whole universal coefficient `P_S`, its module `M_S` satisfies

    ch M_S = omega P_S,
    a_g(p) = dim Hom_(product S_(p_i))(sign, M_(g,p)).

The second quantity is also the number of free Young orbits. The first
identity retains every cycle type and yields actual symmetric/exterior
polynomial functors. Local substitution is the colored Cauchy product
and induction from the groups of child label sets. Local whole Gale
character comparisons supply noncanonical ungraded representation
isomorphisms after the appropriate extension of coefficient fields;
restriction of scalars is not used. In the skew case the complete
graph/fan module with its corrected super-interchange action has the
same full character, hence is isomorphic to this Young module. No such
claim is made separately for the failed valued treewise phase quotients.

Under a supplied reddening certificate `C=-P`, Qin's established support
dimension gives a sharp finite box using only tropical mutation. If the
word is `w` and `P e_j=e_(sigma(j))`, its predecessor word is
`sigma(reverse w)`. With `Phi` the full principal tropical map along
that word, and `Psi` the integer matrix whose columns are `Phi(e_j)`,

    n(g) = frozen_part(Psi^(-1) Phi(g,0) - (g,0)),

and the mutable part of the same difference equals `B n(g)`. The
coordinate box is `[0,n(g)]`, and its top coefficient is1. Combining
this known theorem with the new coefficient species gives an explicit
finite charge-graded direct sum of sign Hom spaces with Hilbert
polynomial exactly `F_g`. The class
`computations/valued_polyhedral_mechanism/whole_theta_hom_space.py`
constructs all literal basis-object recipes before evaluating any
cardinality. It is a general constructor from `(B,D,g,reddening_word)`.

Actual validation now includes 125,411 full-cycle Young-character
comparisons,33,032 Cauchy-induction cycle checks,19,834 literal global
objects promoted to Young summands and42 independently compared cycle
classes. The tropical support implementation passed103 certificates,
3735 arbitrary labels and3990 cluster-variable F-vector comparisons,
including a three-cycle terminal permutation. The external Wolfram
receipts independently verify the sign and symmetric/exterior
character identities. The whole-element constructor was checked as a
complete polynomial on a cyclic nonconstant-symmetrizer input.

The targeted literature refresh and rejection log is
`agents/representation_reddening_literature_audit.md`. Qin/Keller/GHKK
support and basis facts are explicitly credited. The 2026 JLMS
Burcroff--Lee--Mou--Musiker--Reineke paper was checked at the precise
profile/change-of-lattice interfaces; a missing `1/k!` in one proof line
is recorded without misrepresenting the otherwise correct displayed
binomial theorem. Neither its scalar Euler identities nor its binomial
specializations are substituted for a full-character proof.

Canonical boundary: the finite label-set functor is direct for fixed
flags/schedules, and the Young-set isomorphism class is independent of
the permitted changes. Intrinsic all-degree flag-change maps are not
proved. The new first multilinear triple map with equal input normal
contents in `agents/DYCK_THREE_FACTOR_COHERENCE.md` preserves child label
sets and therefore has a genuine equivariant Young-species lift inside
any larger event context. It is a partial coherence interface, not a
claim that all higher critical relations are solved.
