"""Independent finite-matrix audit and cycle-index reduction experiments.

The folded/lifted transports in audit_matrix are computed with rational Lie
logarithms and matrix exponentials, not the scalar Schur recursion.  The
cycle-index identities compare an elementary-variable polynomial recursion
with classical square-free coefficients in weighted higher-rank matrices.
"""
from pathlib import Path
import sys, json, time
from fractions import Fraction as Q
from itertools import product
from functools import lru_cache
from collections import Counter
from math import factorial, lcm

sys.path.insert(0,str(Path(__file__).parent))
from incoming_recursion import IncomingSchur, ibinom, box, le, sub
from incoming_independent_compute import LieLog


@lru_cache(None)
def partitions(n, maximum=None):
    if n==0:return ((),)
    maximum=n if maximum is None else min(n,maximum)
    return tuple((k,)+tail for k in range(maximum,0,-1)
                 for tail in partitions(n-k,k))


def zpart(lam):
    ans=1
    for k,m in Counter(lam).items():ans*=k**m*factorial(m)
    return ans


def lifted(B,D,g,r):
    labels=[i for i,c in enumerate(r) for _ in range(c)]
    return ([[B[i][j] for j in labels] for i in labels],
            [D[i] for i in labels],tuple(g[i] for i in labels),labels)


def project(v,labels,n):
    return tuple(sum(v[a] for a,i in enumerate(labels) if i==j) for j in range(n))


def inverse(C,J):
    out={(p,p):Q(1) for p in J}
    for p in J:
        for q in J:
            if p==q or not le(q,p):continue
            out[p,q]=-sum(C.get((p,r),0)*out.get((r,q),0)
                          for r in J if r!=p and le(q,r) and le(r,p))
    return out


def theta_from_matrix(C,J,B,D,g):
    out={J[0]:Q(1)}
    for p in J[1:]:
        mp=tuple(g[i]+sum(B[i][j]*p[j] for j in range(len(g))) for i in range(len(g)))
        I=[q for q in J if le(q,p) and (q==p or sum(mp[i]*D[i]*(p[i]-q[i]) for i in range(len(g)))<0)]
        T=inverse(C,I)
        out[p]=-sum(T.get((p,q),0)*out[q] for q in I if q!=p)
    return out


def full_matrix(model,J,g):
    # LieLog computes rectangular submatrices directly.  Asking for each top
    # produces all columns allowed in that box, and overlaps must agree.
    C={}
    for p in J:
        _,Cp=model.expmatrix(p,g)
        for key,v in Cp.items():
            if key in C:assert C[key]==v
            C[key]=v
    return C


def audit_matrix(name,B,D,g,r,p):
    n=len(g); Br=[[r[i]*B[i][j] for j in range(n)] for i in range(n)]
    Dr=[Q(D[i],r[i]) for i in range(n)]; gr=tuple(r[i]*g[i] for i in range(n))
    Bt,Dt,gt,labels=lifted(B,D,g,r)
    J=box(p)
    caps=tuple(p[i] for i in labels)
    Jt=sorted((u for u in product(*(range(v+1) for v in caps)) if le(project(u,labels,n),p)),key=lambda v:(sum(v),v))
    L=LieLog(Br,Dr);Lt=LieLog(Bt,Dt)
    for q in J[1:]:L.add(q)
    for u in Jt[1:]:Lt.add(u)
    C=full_matrix(L,J,gr);Ct=full_matrix(Lt,Jt,gt)
    checks=0; inverse_checks=0
    for q in Jt:
        qb=project(q,labels,n)
        for s in J:
            lhs=sum(Ct.get((u,q),0) for u in Jt if project(u,labels,n)==s)
            assert lhs==C.get((s,qb),0),(name,'full intertwining',s,q,lhs,C.get((s,qb),0))
            checks+=1
    for s in J[1:]:
        ms=tuple(gr[i]+sum(Br[i][j]*s[j] for j in range(n)) for i in range(n))
        I=[q for q in J if le(q,s) and (q==s or sum(ms[i]*Dr[i]*(s[i]-q[i]) for i in range(n))<0)]
        It=[u for u in Jt if project(u,labels,n) in I]
        T=inverse(C,I);Tt=inverse(Ct,It)
        for q in It:
            qb=project(q,labels,n)
            for v in I:
                lhs=sum(Tt.get((u,q),0) for u in It if project(u,labels,n)==v)
                assert lhs==T.get((v,qb),0),(name,'restricted inverse',s,v,q,lhs,T.get((v,qb),0))
                inverse_checks+=1
    A=theta_from_matrix(C,J,Br,Dr,gr)
    At=theta_from_matrix(Ct,Jt,Bt,Dt,gt)
    for s in J:
        assert A[s]==sum(At[u] for u in Jt if project(u,labels,n)==s),(name,'theta fold',s)
    return {'name':name,'B':B,'D':D,'g':g,'r':r,'p':p,'folded_indices':len(J),
            'lifted_indices':len(Jt),'matrix_entries_checked':checks,
            'restricted_inverse_entries_checked':inverse_checks,
            'theta_coefficients_checked':len(J),'all_passed':True}


class EPoly:
    def __init__(self,terms,n):self.t={m:c for m,c in terms.items() if c};self.n=n
    @classmethod
    def scalar(cls,c,n):return cls({((),)*n:c},n)
    def __add__(self,o):
        if isinstance(o,int):o=EPoly.scalar(o,self.n)
        d=self.t.copy()
        for m,c in o.t.items():d[m]=d.get(m,0)+c
        return EPoly(d,self.n)
    __radd__=__add__
    def __neg__(self):return EPoly({m:-c for m,c in self.t.items()},self.n)
    def __sub__(self,o):return self+-o
    def __rsub__(self,o):return o+-self
    def __mul__(self,o):
        if isinstance(o,int):return EPoly({m:c*o for m,c in self.t.items()},self.n)
        d={}
        for a,x in self.t.items():
            for b,y in o.t.items():
                m=tuple(tuple(sorted(a[i]+b[i],reverse=True)) for i in range(self.n))
                d[m]=d.get(m,0)+x*y
        return EPoly(d,self.n)
    __rmul__=__mul__
    def __bool__(self):return bool(self.t)


class GeneralizedSchur(IncomingSchur):
    def _c(self,a,m):
        if not any(a):return EPoly.scalar(1,self.n)
        support=[i for i,x in enumerate(a) if x]
        if len(support)==1:
            i=support[0];out={}
            for lam in partitions(a[i]):
                k=len(lam);mul=factorial(k)
                for count in Counter(lam).values():mul//=factorial(count)
                mon=[()]*self.n;mon[i]=lam
                out[tuple(mon)]=ibinom(-m[i],k)*mul
            return EPoly(out,self.n)
        S=[q for q in box(a) if q!=a and q!=self.zero and self.sign(a,q)>0]
        v={}
        for s in S:
            v[s]=self.c(s,m)-sum(self.c(sub(s,q),self.shift(m,q))*v[q] for q in v if le(q,s))
        return sum((self.c(sub(a,s),self.shift(m,s))*v[s] for s in S),EPoly.scalar(0,self.n))


@lru_cache(None)
def symmetric_character(lam,mu):
    if not mu:return int(not lam)
    k=mu[0];rem=sum(lam)-k
    if rem<0:return 0
    total=0
    outer={(i,j) for i,row in enumerate(lam) for j in range(row)}
    for nu in partitions(rem):
        if len(nu)>len(lam) or any(nu[i]>lam[i] for i in range(len(nu))):continue
        inner={(i,j) for i,row in enumerate(nu) for j in range(row)}
        strip=outer-inner
        if not strip:continue
        if any({(i,j),(i+1,j),(i,j+1),(i+1,j+1)}<=strip for i,j in strip):continue
        seen={next(iter(strip))};front=list(seen)
        while front:
            i,j=front.pop()
            for v in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
                if v in strip and v not in seen:seen.add(v);front.append(v)
        if len(seen)!=len(strip):continue
        height=len({i for i,j in strip})-1
        total+=(-1)**height*symmetric_character(nu,mu[1:])
    return total


def cycle_model(B,D,g,lam):
    atoms=[(i,k) for i,li in enumerate(lam) for k in li]
    C=[[l*B[i][j] for j,l in atoms] for i,k in atoms]
    d=[k*D[i] for i,k in atoms]
    h=tuple(g[i] for i,k in atoms)
    if not atoms:return 1
    S=IncomingSchur(C,d)
    p=(1,)*len(atoms)
    return S.theta_prefix(h,p).get(p,0)


def epower_to_power(lam):
    # elementary monomial e_lam -> power sum basis, in one alphabet.
    out={():Q(1)}
    for k in lam:
        nxt={}
        for nu in partitions(k):
            w=Q((-1)**(k-len(nu)),zpart(nu))
            for old,c in out.items():
                key=tuple(sorted(old+nu,reverse=True))
                nxt[key]=nxt.get(key,Q(0))+c*w
        out=nxt
    return out


def cycle_audit(name,B,D,g,p):
    G=GeneralizedSchur(B,D);F=G.theta_prefix(tuple(g),tuple(p)).get(tuple(p),EPoly.scalar(0,len(g)))
    types=list(product(*(partitions(k) for k in p)))
    traces={lam:cycle_model(B,D,g,lam) for lam in types}
    powers={}
    for epart,c in F.t.items():
        exps=[epower_to_power(lam) for lam in epart]
        for item in product(*(tuple(x.items()) for x in exps)):
            mu=tuple(x[0] for x in item);coef=Q(c)
            for _,d in item:coef*=d
            powers[mu]=powers.get(mu,Q(0))+coef
    for lam in types:
        z=1
        for li in lam:z*=zpart(li)
        target=Q((-1)**(sum(p)-sum(map(len,lam)))*traces[lam],z)
        assert powers.get(lam,Q(0))==target,(name,'polarization',lam,powers.get(lam,0),target)
    ordinary=IncomingSchur(B,D).theta_prefix(tuple(g),tuple(p)).get(tuple(p),0)
    signmult=Q(0)
    for lam in types:
        z=1
        for li in lam:z*=zpart(li)
        signmult+=Q((-1)**(sum(p)-sum(map(len,lam)))*traces[lam],z)
    assert signmult==ordinary,(name,'sign multiplicity',signmult,ordinary)
    irreps={}
    for nus in types:
        mult=Q(0)
        for lam in types:
            z=1;chi=1
            for i,li in enumerate(lam):z*=zpart(li);chi*=symmetric_character(nus[i],li)
            mult+=Q(chi*traces[lam],z)
        irreps[nus]=mult
    return {'name':name,'B':B,'D':D,'g':g,'p':p,'ordinary_theta_coefficient':ordinary,
            'elementary_coefficients':[{'partitions':m,'coefficient':c} for m,c in sorted(F.t.items())],
            'all_elementary_nonnegative':all(c>=0 for c in F.t.values()),
            'cycle_traces':[{'partitions':m,'trace':c} for m,c in traces.items()],
            'irreducible_multiplicities':[{'partitions':m,'multiplicity':str(c)} for m,c in irreps.items()],
            'all_irreducible_nonnegative_integers':all(c.denominator==1 and c>=0 for c in irreps.values()),
            'polarization_identities_checked':len(types),'sign_formula_passed':True}


def main():
    start=time.time()
    matrix_cases=[
      ('zero_degenerate',[[0,0],[0,0]],[1,3],(-2,1),(2,2),(2,1)),
      ('acyclic_valued',[[0,3],[-2,0]],[2,3],(-2,3),(2,1),(2,2)),
      ('cyclic_valued',[[0,3,-2],[-2,0,1],[4,-3,0]],[2,3,1],(-1,0,-1),(2,1,1),(2,1,1)),
      ('cyclic_radical',[[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],(-1,-1,-1),(2,1,1),(2,1,1)),
    ]
    matrix=[]
    for case in matrix_cases:
        matrix.append(audit_matrix(*case));print('matrix',case[0],'PASS',flush=True)
    cycle_cases=[
      ('zero_tensor',[[0,0],[0,0]],[1,2],(-3,-2),(3,2)),
      ('acyclic_negative',[[0,2],[-3,0]],[3,2],(-2,-1),(3,2)),
      ('acyclic_mixed',[[0,2],[-3,0]],[3,2],(-3,2),(3,2)),
      ('a3_cycle',[[0,1,-1],[-1,0,1],[1,-1,0]],[1,1,1],(-1,-1,-1),(2,2,1)),
      ('markov2',[[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],(-1,-1,-1),(2,2,1)),
      ('markov3',[[0,3,-3],[-3,0,3],[3,-3,0]],[1,1,1],(-1,0,0),(3,2,1)),
      ('valued_mixed',[[0,3,-2],[-2,0,1],[4,-3,0]],[2,3,1],(-2,1,0),(2,2,2)),
      ('cycle4',[[0,2,0,-2],[-2,0,2,0],[0,-2,0,2],[2,0,-2,0]],[1,1,1,1],(-1,-1,0,1),(2,1,1,1)),
    ]
    cycles=[]
    target=Path(__file__).with_suffix('.json')
    for case in cycle_cases:
        cycles.append(cycle_audit(*case));print('cycle',case[0],'PASS',flush=True)
        target.write_text(json.dumps({'matrix_audits':matrix,'cycle_audits':cycles,'seconds':time.time()-start},indent=2))
    print('saved',target,'seconds',time.time()-start,flush=True)

if __name__=='__main__':main()
