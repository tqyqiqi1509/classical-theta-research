# A rank-three event-address flip with one framed input

2026-11-13, 16:12--16:18 UTC. Classical skew-symmetrizable setting.

## 1. Statement and exact scope

Let a,b,c be independent positive charges, with a carrying a framing
coordinate equal to one whose symmetrizer entry is one, and b,c
having framing degree zero. The three
inputs are fixed decorated boundary packets. Retain only their first
multilinear component: exactly one occurrence of each input packet.
Equivalently, attach distinct square-zero labels to these three inputs.
There is no positive linear factorization assumption on an arbitrary
input series. An input packet may itself be any specified coefficient
object of any degree; this local construction treats that object as
an opaque boundary decoration.

Set

    S=a+b+c,  p=K(a,b)>0,  q=K(b,c)>0,  r=K(a,c)>0,
    d=w(b),  e=w(c),  f=w(b+c).

Every carrier containing a has normal content one. No coplanarity
of a,b,c is required; they are independent precisely to distinguish
the three parent event planes.

We prove an explicit bijection across the critical face for the
actual two-vertex event trees in this first-multilinear sector.
It transports the parent/child event addresses as well as their
literal Dyck edge positions and normal-copy labels. The three
boundary decorations are retained. It does not assert that the
descendant catalogs of a non-atomic packet remain unchanged when
its boundary covector changes. That additional transport is part
of the still unresolved all-degree/global extension.

## 2. Actual event times, including all p versus q cases

Use the existing event convention eta_T=-K(T,-). Take a coarse real
covector theta with theta(S)=0, and put y=theta(b), z=theta(c). Define

    D=(q+r)y-(p-q)z.

At a root event with complementary input x, its time is
tau=-theta(x)/eta_S(x), and the projected covector is
theta+tau eta_S. Direct substitution gives the following table.

| Branch | Two-vertex history | Root time | Inner time |
|---|---|---|---|
| L1 | ((a,b),c) | z/(q+r) | D/[p(q+r)] |
| L2, only p<q | (b,(a,c)) | -y/(q-p) | D/[r(q-p)] |
| R1 | (a,(b,c)) | (y+z)/(p+r) | -D/[q(p+r)] |
| R2, only p>q | ((a,c),b) | y/(p-q) | -D/[r(p-q)] |

For example, at the L1 root,

    theta_root(b)=y-z(p-q)/(q+r)=D/(q+r),

and eta_(a+b)(b)=-p, giving the stated inner time. At R1,

    theta_root(c)=z-(y+z)(q+r)/(p+r)=-D/(p+r).

The other two formulas follow identically. These are the actual
projection formulas used in `valued_event_flag_grammar.py`, rather
than a Jacobi identity imposed on numerical weights.

Consider a neighborhood of D=0 with z>0. On the face,

    y=(p-q)z/(q+r),       y+z=(p+r)z/(q+r)>0.

If p>q, y stays positive nearby, so L1 is the only legal branch
on D>0 and R1,R2 are exactly the legal branches on D<0.
If p<q, y stays negative nearby, so L1,L2 are exactly the legal
branches on D>0 and R1 is the only legal branch on D<0.
If p=q, the a+c/b outer pairing is zero and that event is absent;
L1 and R1 are the respective legal branches. All root times of
present branches tend to z/(q+r) at the face, and all inner times
tend to zero.

The fresh infinitesimals in the full event flags affect higher
components only. On either strict side, the displayed nonzero
coarse times determine their signs. The target addresses are the
root plane span(S,a), span(S,b), or span(S,c) selected by the branch,
followed by the indicated child plane, with the event projections
and fresh infinitesimals recomputed by the existing formula.
They are not claimed to have numerically identical covector tags.

There are no additional two-vertex histories in this multilinear
three-input sector: a proper composite is one of a+b,a+c,b+c,
and independence makes their three parent planes distinct.

## 3. All normal-copy labels retained

Write

    g=gcd(d,e),       d'=d/g,       e'=e/g,
    ell=q/lcm(d,e),   F=f/g,
    A=p/d,           B=r/e,
    delta=d' ell=q/e, epsilon=e' ell=q/d,
    C=(d'A+e'B)/F=(p+r)/f.

These are positive integers, except that A-epsilon may have either
sign. Integrality uses only divisibility of pairings by input normal
contents and divisibility of f by g; it does not use the earlier
coplanar Smith lemma. In particular, the inner (b,c) factory has
F actual normal copies and ell actual edge residues.

Read the first-coefficient binary factories by the already proved
literal strip-residue formula (`dyck_three_factor_coherence.py`).
The source and target are consequently

    L1 = [A] x [B+delta],
    L2 = [B] x [max(epsilon-A,0)],

    R1 = [ell] x [C] x [F],
    R2 = [B] x [max(A-epsilon,0)].

Here [n]={0,...,n-1}. The first two coordinates on each branch are
inner and outer edge residues. On R1, the final coordinate is the
actual inner normal-copy label; all other factories have one copy.

### Explicit forward map

For L1(i,j), if j<B and i>=epsilon, send it to

    R2(j,i-epsilon).

All remaining points go to R1 by one of two geometric strips.

* For the upper strip of L1, j>=B, set

      (h,u)=divmod(j-B,d'),      z=d'i+u.

* For the lower remaining strip, use its coordinates i,j directly.
  A point L2(i0,j0) is first put into the continuation of that same
  strip by i=A+j0, j=i0. Then set

      (h,u)=divmod(i,e'),        z=d'A+e'j+u.

In either case send the point to

    R1(h, floor(z/F), z mod F).                       (3.1)

Thus the inner normal-copy label is literally a residue of the
weighted strip coordinate. This transfers phase data instead of
discarding it or assuming it is constant.

### Explicit inverse and coverage

For R2(i,j), return L1(j+epsilon,i).
For R1(h,t,c), put z=F t+c. If z<d'A, write

    (i,u)=divmod(z,d')

and return L1(i,B+d'h+u). If z>=d'A, write

    (j,u)=divmod(z-d'A,e'),      i=e'h+u.

Return L1(i,j) if i<A, and L2(j,i-A) otherwise.

For each h in [ell], the upper strip supplies z in [0,d'A),
and the continued lower strip supplies z in [d'A,d'A+e'B).
These intervals are disjoint and fill [0,FC). Euclidean division
by F therefore gives every outer residue and every original
normal-copy label exactly once. The R2 rectangle is the untouched
excess strip. This proves both coverage and inverse identities,
including p=q. The construction is a local weighted rectangle cut
and copy/residue carry; it never ranks a whole coefficient object set.

Finally apply the literal inverse strip formula at both vertices.
This produces the actual positive horizontal/vertical edge positions
and their unchanged input decorations at the new addresses.

## 4. What this advances, and the next exact equation

The earlier framed slot cuts moved a fusion past one wall while
treating the event catalog as fixed. Here the three parent event
planes genuinely exchange legality, and equations in Section 2
identify that exchange. Section 3 matches the actual decorated
first-multilinear factories across it, including unequal weights and
the nonprimitive intermediate b+c. This is a concrete local routing
rule for two nonparallel unframed boundary packets.

It applies with b=j alpha and c=k beta for arbitrary positive j,k
and arbitrary coefficient decorations. It does not yet compare
histories containing several occurrences of those coefficient
packets. Ordered repetitions on one ray have a repeated-frame
realization by `TWO_STACK_DYCK_FORESTS.md`, Section 7.2; the remaining
task is to prove that repeated critical moves descend to those
unlabelled repeated-packet objects and remain compatible with
their descendant event flags.

In particular, the map needed for the full extension is not merely
the displayed bijection tensor A_a x A_b x A_c with fixed sets A_i.
It must compare varying boundary-catalog factors, of the form

    disjoint union over source addresses v
       Factory_v x O_a(theta_(v,a))
                 x O_b(theta_(v,b)) x O_c(theta_(v,c))

against the corresponding target-address union. The local map
constructs Factory_v -> Factory_v', but the theta_(v,i) generally
change. No identity O_i(theta_(v,i))=O_i(theta_(v',i)) is assumed.
This is the concrete equation still missing before iterating the
flip into unrestricted endpoint transport or an associator.

## 5. Computation

`computations/framed_two_packet_event_flip.py` and its JSON record
verify the new formulas directly:

* 4,962 admissible arithmetic parameter tuples;
* 174,744 rectangle points, with exact inverse and full set coverage;
* 4,452 reconstructed literal binary edge factories, all tight;
* 9,924 exact rational event-address sign checks, including p<q,
  p=q and p>q.

The tests use the actual event projections and the existing literal
Dyck edge construction, not a scattering coefficient oracle.

## 6. Primary literature refresh and use decision

The following sources were opened and inspected during this interval.
They are interfaces and scope checks; neither is invoked as a proof
of the new finite-set map.

1. Bergner, Borghi, Dey, Galvez-Carrillo, Hoekstra-Mendoza,
   *2-Segal sets from cuts of rooted trees*, arXiv:2501.10518v1,
   <https://arxiv.org/pdf/2501.10518>. Inspected Proposition 3.12,
   Proposition 3.13, and Section 5, especially Propositions 5.9 and
   5.11. The paper proves a 2-Segal structure for admissible cuts of
   fixed rooted trees. It also demonstrates that forgetting rooted
   structure need not preserve decomposition lifting. Useful lesson:
   a tree encoding alone does not supply our missing unique lifting
   of actual event decompositions. No automatic Hall-associativity
   shortcut was adopted. The local rectangle above is instead one
   explicit lifting step.
2. Cheung--Mandel, *Donaldson--Thomas invariants from tropical disks*,
   arXiv:1902.05393v3, <https://arxiv.org/pdf/1902.05393>. Inspected
   the ribbon/flag setup in Section 1 and the counterexample statement
   and final uncancelled term in Section 5.3, Proposition 5.4. Their
   Hall broken-line construction does not in general satisfy the
   expected endpoint transformation. Consequently a Hall-algebra
   refinement cannot be assumed to give our positive object transport.
   The tropical-tree relation remains relevant, but its multiplicity
   identities do not identify our actual boundary-catalog sets.

Both retrieved versions predate 2026. The first HTML attempts failed;
the primary PDF retrieval succeeded. No unaudited 2026 theorem was
imported. The present route succeeded at the first-multilinear
addressed critical face and remains incomplete at the full varying-
packet boundary equation stated in Section 4.

## 7. Final conceptual advance: disjoint leaf supports isolate descendants

16:19--16:20 UTC. The following conditional mechanism is proved; its
descent from an enlarged leaf lattice to the original cluster lattice
is not proved.

Work in a lattice with independent coordinates for externally labelled
leaves. Suppose the three nonzero child charges a,b,c have pairwise
disjoint coordinate supports. Set E=ann(a,b,c). In a fixed finite
degree cutoff, every scalar sign test in the full descendant catalog
of b is a rational linear function of its boundary covector, plus
terms from its subsequent fresh infinitesimals. Its boundary-linear
part can be written theta_b(v), with v supported inside supp(b).

This uses the same rational-linear catalog induction proved in
`RADIAL_ENDPOINT_LITERAL_CATALOG_REVIEW.md`, now retaining the support
of each representing test vector. A projection along eta_T replaces a test
theta(Y) by theta(Y-lambda X), where X,Y are child charges supported
inside supp(b), and lambda is a rational number depending on the
fixed charges and their pairings. Repeated projections therefore
introduce signed rational combinations, but never add a new support
coordinate. The same applies to differences of event-time tests.

The crucial intersection is

    span(a,b,c) intersect Q^(supp b) = Q b.            (7.1)

If v is not a multiple of b, its restriction to E is nonzero. Since
the cutoff contains finitely many possible catalog tests, one can
choose q0 in E outside their finitely many nonzero hyperplanes,
simultaneously for all three descendants. Then q0(v) is nonzero
and determines each such test under sufficiently small perturbations
to the two sides of the critical face. If v is a multiple of b,
the entire boundary-linear part vanishes for every legitimate
boundary covector theta_b, because theta_b(b)=0 exactly. It kills
the perturbed boundary terms as well, not merely their coarse part.
Only subsequent fresh-infinitesimal terms remain, and these have
the same charge-dependent coefficients under address renaming.

Consequently all three descendant catalogs are literally identical
under charge/address renaming across a sufficiently small generic
critical crossing in this enlarged, disjoint-support setting.
Their Dyck objects and decorations can be retained. Signed rational
test vectors do not obstruct this argument; they are handled by
(7.1). Squarefreeness is not itself needed for (7.1), once disjoint
supports are given.

The unresolved issue has thereby moved to an exact descent problem.
Let pi send independent leaf clones back to their original colors.
Original boundary covectors lie in the image of pi*, which need not
meet the generic locus used above. Introducing independent clone
perturbations changes the event refinement. Moreover the usual
normal content in the clone lattice can differ from w(pi(b)), so
the local factory's normal-copy labels are not automatically those
of the original object. Finally, replacing one initial classical
wall by independent clone walls is not harmless:

    product_i (1+t_i z) != 1+(sum_i t_i) z

even when each t_i^2=0; the mixed products t_i t_j remain.
Thus the standard cloned initial grammar is not established to be
a labelled version of the original grammar. Labelling an already
constructed original object does give the usual free permutation
action on distinct labels, but identifying those labelled objects
with the generic independent-coordinate event grammar is precisely
the missing step. No division by factorials or positive alphabet
factorization is claimed to supply it.

This conditional local literal-transport lemma strengthens the
first-multilinear flip. It does not establish the required equivariant
specialization/packing from clone coordinates and generic clone
flags back to the original normal contents and initial wall data.
