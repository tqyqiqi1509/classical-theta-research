# Handoff: whole original-label KLR category and incoming normalization

Agent `/root/klr_incoming_bridge`, 2026-11-13, ending by parent request to
release a slot for independent review of the valued Gale theorem.

## Completed theorem, with proof and computations

Read `agents/klr_incoming_bridge.md` Sections 1--3. Main new result:

For all original-label words `v,w`, the bad-prefix idempotent ideal in the
thin matrix order has exact corner

`e_v J_theta e_w = P_(v,w) I_(v,w)`.

`I_(v,w)` is the outgoing forbidden-cut ideal of the acyclic graph
`H(v,w)`: retain only edges ordered the same way by `v,w`, and orient each
from later to earlier in `v`. The proof is the binary identity

`p(v,z)+p(z,w)-p(v,w)=1 iff order_v=order_w != order_z`,

followed by both directions of the negative-prefix/cut divisibility
argument. No initial acyclicity or theta genericity is required for this
ideal theorem. The normalized composition coefficient is the product of
exactly those common edges reversed by the intermediate word.

Consequences proved:

- Original weighted dot ring `U=K[u_i]`, root ring `W=K[w_i]`,
  `u_i=w_i^d_i`: the **entire** stability quotient category is
  `W tensor_U A_val`, with all Hom spaces and compositions.
- Phase invariants recover `A_val`; all kernels/images/cokernels of
  matrices defined over `U`, and all descended idempotents, commute with
  this extension. The residue basis gives the actual cycle character
  factor `product_cycle [d]_(q^length)`.
- Under generic theta and one weight-one fixed frame, every Hom is a
  generic acyclic gain cut algebra (or zero). The tree LSOP argument
  therefore gives flat gain deformation of the **whole finite category**,
  not merely one reverse-topological corner.

Exact computational validation:

- Python 526,464 monomial-ideal comparisons, all passed, 7.897 seconds.
- Actual Wolfram Language independent check 5,760 identities, all passed.
- Files `computations/klr_incoming_bridge/`; receipt includes complete WL
  source and raw result. No live computation sessions remain.

## Necessary warning for the valued Gale interface

Read Section 4.1 of the report before combining constructions.

Gale equations `x_i^r product Q=T^b` cannot be inserted as a central
quotient of a fixed steadied cut category: its relevant cut products
already vanish, so `T invertible` may kill it. The valued agent confirmed
the correct scalar construction: Rees-deform the **cut lattice ideal**,
then impose the gain linear section and complete. `B,C` compare to
neighboring cut chambers through their generic fibers, not as identical
ideals.

An honest limited category exists: base change the **unsteadied** thin
matrix order to the finite Gale algebra, then take its central attached
projector on all Hom spaces. This preserves original particle labels,
gives the attached algebra as every diagonal corner, and supports actual
phase descent. But it is not yet a deformation of the full steadied
category. At generic Gale `T`, all crossing Euler factors are units, so
all word objects are Morita equivalent. Killing any bad word then kills
the entire factor. Thus the bad-word quotient cannot be kept unchanged
through the deformation.

## Remaining main mechanism

Need a Rees/nearby-cycle/filtered category with varying projective supports
which compares neighboring generic steadied categories and realizes the
attached primitive functor. It must retain all original dot centers and
prove successive incoming-normalized factor selections are compatible.
Do not fuse a composite subtree to a new simple KLR color using only its
total pairing: semicuspidal denominators need not have that form.

The valued agent's new result is `agents/valued_gale_attached_theorem.md`,
527 lines as communicated. It should be independently strongly audited
next. Its full theorem was not yet read by this agent, except that its
Section 4 Rees construction was communicated and matched directly against
Tang's primary Sections 3--4.

## Sources read or found

Webster weighted KLR 2019 Sections 2.5--2.7 read: steadied quotient is an
exact morphism ideal; unrestricted deformation flatness alone does not
give quotient flatness. Our all-Hom theorem fills that gap in thin generic
framed case. Exact weighted Euler Q is prior art, Example 2.27.

Webster unfurling 1603.06311v4 (2026) Sections 4.2--4.3 opened/inspected for
spectral blocks, not invoked as a theta theorem; many HTML references are
broken. Chen--Mandel--Qin covering theorem checked: finite-dimensional
Jacobian and nice-grading hypotheses prohibit automatic infinite acyclic
universal-cover reduction.

Promising next primary-source interface, **located not yet theorem-read**:

- BLPW *Hypertoric category O*,
  `https://pages.uoregon.edu/njp/toric-O.pdf`.
- *Quantum Cohomology of Hypertoric Varieties*, arXiv:1212.4449.
- *Hypertoric 2-categories O and symplectic duality*, arXiv:2310.06172.

Convolution algebras with projective supports varying among toric
components may provide precisely the Rees category needed, rather than
trying to put a quantum Stanley--Reisner equation into an unchanged
homogeneous cut algebra.
