"""Systematic exact audit of the cycle-character mechanism, not a fit.

Uses the independently coded elementary-coefficient recursion, weighted
square-free classical recursion, and Murnaghan--Nakayama character values.
The audit samples skew and nonscalar symmetrizable input, cyclic and acyclic
supports, mixed labels, and charges with zero coordinates.
"""
from pathlib import Path
from itertools import product
from fractions import Fraction as Q
from math import lcm, factorial
import json, time, random, hashlib, gc
from replication_independent_compute import (
    partitions,zpart,symmetric_character,cycle_audit)


def character_table_audit():
    result=[]
    for n in range(9):
        ps=partitions(n)
        for a in ps:
            for b in ps:
                dot=sum(Q(symmetric_character(a,mu)*symmetric_character(b,mu),zpart(mu)) for mu in ps)
                assert dot==int(a==b),(n,a,b,dot)
            hooks=1
            for i,row in enumerate(a):
                for j in range(row):
                    hooks*=row-j+sum(1 for k in range(i+1,len(a)) if a[k]>j)
            assert symmetric_character(a,(1,)*n)==factorial(n)//hooks
        result.append({'degree':n,'irreducibles':len(ps),'inner_products':len(ps)**2,'passed':True})
    return result


def cases():
    gs=[(-1,-1,-1),(-2,0,1),(1,-2,0),(-3,2,-1),(-1,-2,-3)]
    charges=[(2,2,1),(3,1,1),(2,2,2),(3,2,1)]
    for weights in product(range(1,4),repeat=3):
        a,b,c=weights
        B=[[0,a,-c],[-a,0,b],[c,-b,0]]
        for g in gs:
            for p in charges:
                yield B,[1,1,1],g,p
    rng=random.Random(20261113)
    # Same mechanism, arbitrary orientations and independent symmetrizers.
    for t in range(340):
        n=3 if t<240 else (4 if t<310 else 5)
        D=([1]*n if t%2==0 else [rng.choice((1,2,3)) for _ in range(n)])
        L=lcm(*D);B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                s=rng.randrange(-2,3)
                B[i][j]=s*L//D[i];B[j][i]=-s*L//D[j]
        g=tuple(rng.randrange(-3,3) for _ in range(n))
        if all(x>=0 for x in g):g=(-1,)+g[1:]
        if n==3:p=rng.choice(charges+[(3,0,2),(0,3,2)])
        elif n==4:p=rng.choice([(2,2,1,1),(3,1,1,1),(1,2,0,2)])
        else:p=rng.choice([(2,1,1,1,1),(1,1,2,1,1)])
        yield B,D,g,p


def main():
    start=time.time();orthogonality=character_table_audit()
    target=Path(__file__).with_suffix('.json')
    summaries=[];cycle_checks=0;irrep_checks=0;e_checks=0;nonzero=0;digest=hashlib.sha256()
    for index,(B,D,g,p) in enumerate(cases(),1):
        r=cycle_audit('stress_'+str(index),B,D,g,p)
        assert r['all_elementary_nonnegative'],r
        assert r['all_irreducible_nonnegative_integers'],r
        cycle_checks+=r['polarization_identities_checked']
        irrep_checks+=len(r['irreducible_multiplicities'])
        e_checks+=len(r['elementary_coefficients'])
        nonzero+=bool(r['elementary_coefficients'])
        raw=json.dumps(r,sort_keys=True,separators=(',',':'))
        digest.update(raw.encode())
        summaries.append({'index':index,'B':B,'D':D,'g':g,'p':p,
            'theta':r['ordinary_theta_coefficient'],
            'cycle_types':r['polarization_identities_checked'],
            'max_trace':max(x['trace'] for x in r['cycle_traces']),
            'elementary_terms':len(r['elementary_coefficients']),
            'all_passed':True})
        if index%20==0:
            gc.collect()
            data={'status':'RUNNING','elapsed_seconds':time.time()-start,
                  'character_tables':orthogonality,'cases_completed':index,
                  'cycle_identities':cycle_checks,'irreducible_multiplicities':irrep_checks,
                  'nonzero_elementary_terms':e_checks,'nonzero_cases':nonzero,
                  'full_result_sha256':digest.hexdigest(),'cases':summaries}
            target.write_text(json.dumps(data,indent=2))
        if index%100==0:print(index,'cases',cycle_checks,'cycle identities',round(time.time()-start,2),'s',flush=True)
    data.update(status='PASS',elapsed_seconds=time.time()-start,cases_completed=len(summaries),
                cycle_identities=cycle_checks,irreducible_multiplicities=irrep_checks,
                nonzero_elementary_terms=e_checks,nonzero_cases=nonzero,
                full_result_sha256=digest.hexdigest(),cases=summaries)
    target.write_text(json.dumps(data,indent=2))
    print(json.dumps({k:v for k,v in data.items() if k!='cases'},indent=2),flush=True)


if __name__=='__main__':main()
