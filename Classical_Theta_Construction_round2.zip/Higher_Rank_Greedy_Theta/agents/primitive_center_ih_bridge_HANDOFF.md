# Handoff: the primitive-center / local-IH character bridge is closed

Date: 2026-11-13, 13:49 UTC. No running computations remain in this branch.

## Proven result

For any finite pointed, nonparallel integral rank-two charge list, the
parity-corrected primitive-center Gale fiber in
`proofs/PRIMITIVE_CENTER_GALE_FINITE_MODEL.md` has precisely the ungraded
local fan-IH representation under every equal-charge vertex permutation.
After the graph-defined coordinate Young perturbation it is an actual
finite Young-permutation G-set. No theta coefficient or prescribed
character enters the construction of that set.

Main proof: `agents/primitive_center_ih_bridge.md`.
Independent algebraic half: `proofs/GALE_DEGREE_AND_CYCLE_TORI.md`.

## The decisive formula

For sigma with cycle lengths l_1,...,l_c, let g=gcd(l_i), and fold the
charges to l_i beta_i. Put D_F=dim IH of this folded anti-attractor flow
polytope and E=the original arrow count. Then

    Tr(sigma;IH)=D_F/product_i l_i * C(g,E),

where C=1 if g=1, C=2 if g=2 and E/4 is odd, and C=0 otherwise.

Proof of the IH side:

1. Exact HN trace folding contributes product_i [l_i]_t^-1.
2. Twist by (-1)^E and take the ordinary cumulant over the set of sigma
   cycles. It kills every primitive-block partition with more than one
   block orbit.
3. A single orbit of d blocks exists exactly for d|g and occurs d^(c-1)
   times. Its return permutation has cycle lengths l_i/d and arrow count
   E/d^2. The H(t^d) residue supplies 1/d.
4. Möbius inversion and the homogeneous stable-tree dimension of degree
   c-1 yield sum_(d|g) mu(d)(-1)^(E-E/d^2), exactly C(g,E).

The stable-tree dimension and homogeneity follow by a purely combinatorial
nearby-HN refinement followed by the ordinary logarithm in the squarefree
label algebra. No equivariant small resolution is assumed; Reineke's
older theorem is an independent check only.

Proof of the Gale side:

1. A sigma-fixed configuration merges vertex variables along cycles.
   Its weighted Gale map lands in the connected target torus with
   primitive relation product Q_i^(l_i/g)=1.
2. Raising the i-th target to l_i gives the ordinary folded Gale map.
   This torus isogeny has degree product_i l_i/g.
3. The signed primitive-center target lies in that connected component
   exactly when C(g,E) is nonzero. In that case C=g.
4. The ordinary folded Gale map is finite flat over its nonresonant open
   torus. Its degree equals D_F by the full positive-arrow Rees
   degeneration, after putting every generic branch at positive
   valuation with a sufficiently small target scaling.
5. Coordinatewise Young deformation and its restriction to sigma-fixed
   coordinates show that Tr(sigma;O(Z)) equals the full scheme-fixed
   length, not an invariant-ring dimension. The resulting length is the
   same formula as the IH character.

## Important exact caveats

- The result is ungraded. It makes no graded permutation-basis claim.
- The coordinate algebra is over Q(zeta_k), or after one embedding over
  C. Use dimension over that field. Restriction of scalars to Q would
  wrongly multiply the answer by phi(k). The actual finite G-set has a
  rational permutation module, which recovers the rational fan module.
- The signed target is essential. The coefficient-one untwisted mirror
  action can have the wrong character.
- Nothing here authorizes termwise valued phase division of a flow tree
  or of a singular local IH module. The previously found valued negative
  character examples remain valid. The whole attached valued algebra is
  a different mechanism.
- The output is an explicit algebraic-point set. A universal elementary
  parking-function / Dyck-path / single-polytope integer-point model has
  not been claimed.

## Review and computation

The local-permutation branch independently checked the entire cumulant,
residue, Möbius, and integral-scaling argument. Root independently reviewed
the full proof and compared 135 nonidentity characters with the separate
Laurent-jet engine; all passed. I independently inspected the companion
LP, Rees full-factor, and target-isogeny proofs. Actual Wolfram checked
8,192 Möbius/parity inputs with no failures. All raw receipts are saved.

The next useful task is the parent's global Young-orbit recursion and the
separate valued global composition problem. Re-auditing these same local
signs is unnecessary unless a concrete new issue appears.
