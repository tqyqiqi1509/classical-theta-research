# The special radial endpoint germ preserves literal event objects

Independent review by `valued_coherence_phase_transport`,
2026-11-13 15:32 UTC. This is a narrow positive result for the two-frame
multiplication construction, not an assertion about arbitrary endpoints
in the same chamber.

## 1. Exact hypothesis

Let H be a rational vector. Let epsilon_1,...,epsilon_n be independent
positive lexicographic infinitesimals. Compare

    U=H+epsilon,
    U'=lambda H+epsilon+delta_0 v,

where v is rational, delta_0 is smaller than every epsilon_i, and
lambda has a strictly positive real constant leading term; in
particular it is bounded below by a positive real constant. Lambda
may depend on the epsilon_i through smaller terms. Merely saying
lambda>0 would be insufficient: an infinitesimal lambda can change
the leading flag. All subsequent incoming-side infinitesimals are
smaller than delta_0, in corresponding order in the two constructions.
The canonical construction may insert an unused zero delta_0 column.

For a one-frame target (1,a), the root state is the linear embedding
Xi_a(U)=(-U dot a,U). Use the same charge truncation, event-plane order,
and deterministic structural word schedule for both endpoints.

## 2. Every relevant decision preserves its sign

Along a fixed recursively chosen charge/plane history, every covector
has the form

    A U + sum_j delta_j v_j,                           (2.1)

where A and v_j are rational and are determined by that charge history.
Indeed the event projection is

    theta -> theta-theta(b) eta(S,-)/eta(S,b),

a rational linear map depending only on integer charges. Passing to
an incoming child appends one rational column eta(rho,-). Thus (2.1)
is preserved at every recursion step.

For an arbitrary rational scalar test ell at the state, let L=ell A.
The compared expressions are

    L H+L epsilon+sum_j delta_j ell(v_j),
    lambda L H+L epsilon+delta_0 L v
                    +sum_j delta_j ell(v_j).          (2.2)

If L H is nonzero, its sign is unchanged by the positive leading term
of lambda. If L H=0 and L is nonzero, the first nonzero coefficient
of L epsilon has the same sign in both expressions and dominates all
delta terms. Finally, if L epsilon is identically zero, independence
of the epsilon_i forces L=0 as a rational functional. The extra term
delta_0 L v then vanishes **exactly**, not just to leading order.
The remaining incoming-side coefficients agree one by one.

Therefore every sign and every zero test of the form (2.2) agrees.
This includes positive event time tests, comparisons of event times
if an implementation uses them, and kernel tests after projection.

## 3. Induction gives an actual object bijection

The root charge bounds agree. At a pair of corresponding states,
candidate charges and plane keys depend only on these bounds and K.
Section 2 gives the same surviving event planes. Each corresponding
proper child has the same target charge and is obtained by the same
rational projection and same new incoming column. Induction on total
target degree therefore identifies their whole unpruned event catalogs.

For every matched event, the angular carrier order, birth tags,
normal contents, local Dyck rectangles, and tuple lengths depend only
on the integer charge data. They are identical. At a leaf the original
axis decorations are identical. Induction now gives a bijection that
retains every Dyck grading, occupied tuple slot, child decoration, and
event charge allocation, and simply relabels its covector query by the
corresponding query in the other catalog.

This is an explicit recursive identity on the combinatorial data. It
uses no cardinality comparison and no rank/unrank map. Optional merging
of identical computational memo states is not part of an object's data
and does not affect this statement. One may unfold the finite recursive
catalog when expressing the bijection.

## 4. Applicability to the two-frame coefficient

At a two-frame root event, the child endpoint in the multiplication
note is

    U'=(1+tau)H+epsilon+delta_0 v,

with tau>0 and a positive real leading term, while the canonical
endpoint is U=H+epsilon. The child's v is the rational unframed part
of eta(rho,-). Thus the hypotheses above hold for each child.
Consequently the root-event pair can use the canonical endpoint object
sets by the literal bijection of Section 3. No general flag-change
theorem is required for this particular replacement.

The proof does not apply when epsilon lacks n independent coordinates,
when lambda has zero/negative leading term, or when an endpoint is
changed in a way not annihilated by the full old epsilon kernel.

## 5. Implementation check

Read `valued_global_assembly.md`, Sections 3--5, and
`computations/valued_event_flag_grammar.py`, especially `events` and
`incoming_theta`. Their structural projections and sign decisions
have precisely the rational-linear form used above. The mathematical
object definition retains empty packets, as required for a catalog
independent of coefficient tests.

`computations/radial_endpoint_catalog.py` compares the exact rational
lexicographic signs, event-plane keys, and child recursion for paired
endpoints. It permits epsilon-dependent lambda with positive constant
term and an extra lower delta_0 column. Its `.json` receipt records
the completed computation. This checks the implementation; Sections
2--3 prove the general catalog bijection.

The completed run compared 180 endpoint pairs, 772 corresponding
states, 3,497 exact charge-sign tests, 247 events, and 612 recursive
child edges, with no discrepancy. Root independently confirmed the
general rational-linear argument, including the noninfinitesimal
lambda requirement and the ordered renaming of covector addresses.
