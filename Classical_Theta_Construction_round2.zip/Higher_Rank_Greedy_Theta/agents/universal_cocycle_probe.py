"""Exhaust the formal sign systems for fixed-word Schur coefficients.

The tree recursion only sees signs delta(i,k,j)=h(i,j)-h(i,k)-h(k,j).
Not every Boolean sign assignment is realizable: delta is an exact
two-cocycle. This probe tests whether larger-than-unit coefficients survive
the elementary tetrahedron sign obstruction, and then tests LP feasibility.
LP output is discovery evidence, not an exact proof certificate.
"""
from itertools import combinations
import json,time
from pathlib import Path
import numpy as np
from scipy.optimize import linprog


def run(n=5,lp_cap=1000):
    start=time.time()
    triples=list(combinations(range(n+1),3)); index={t:k for k,t in enumerate(triples)}
    size=1<<len(triples)
    ids=np.arange(size,dtype=np.uint32)
    sign={t:((ids>>k)&1).astype(np.int16) for t,k in index.items()}
    C={(i,i+1):np.ones(size,dtype=np.int16) for i in range(n)}
    for d in range(2,n+1):
        for i in range(n+1-d):
            j=i+d; v={}
            for k in range(i+1,j):
                value=C[i,k].copy()
                for l in range(i+1,k): value-=C[l,k]*v[l]
                v[k]=sign[i,k,j]*value
            C[i,j]=sum(C[k,j]*v[k] for k in range(i+1,j))
    c=C[0,n]
    bad=np.abs(c)>1
    values,counts=np.unique(c,return_counts=True)
    hists=dict(zip(map(int,values),map(int,counts)))
    cocycle_ok=np.ones(size,dtype=bool)
    for i,j,k,l in combinations(range(n+1),4):
        a=sign[i,j,k]; b=sign[i,k,l]; u=sign[i,j,l]; v=sign[j,k,l]
        invalid=((a==b)&(u==v)&(a!=u))
        cocycle_ok&=~invalid
    survivors=ids[bad&cocycle_ok]
    intervals=[(i,j) for i in range(n) for j in range(i+2,n+1)]
    vi={x:i for i,x in enumerate(intervals)}
    M=np.zeros((len(triples),len(intervals)))
    for row,(i,k,j) in enumerate(triples):
        M[row,vi[i,j]]=1
        if (i,k) in vi:M[row,vi[i,k]]-=1
        if (k,j) in vi:M[row,vi[k,j]]-=1
    lp_records=[]
    checked=0
    for code in survivors[:lp_cap]:
        checked+=1
        s=np.array([1 if (int(code)>>j)&1 else -1 for j in range(len(triples))])
        lp=linprog(np.zeros(len(intervals)),A_ub=-s[:,None]*M,
                   b_ub=-np.ones(len(triples)),bounds=[(None,None)]*len(intervals),method='highs')
        if lp.success:
            lp_records.append({'code':int(code),'coefficient':int(c[code]),
                               'intervals':intervals,'heights':lp.x.tolist()})
            break
    out={'n':n,'patterns':size,'histogram':hists,'bad_total':int(sum(bad)),
         'tetrahedron_consistent_bad':len(survivors),'lp_checks':checked,
         'feasible_examples':lp_records,'seconds':time.time()-start}
    target=Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__':run()
