"""Test a natural symmetric-group action by commuting identical leaf twigs.

The candidate model replaces every maximal same-color leaf comb by an
unordered bundle. Each bundle has a common integer slot capacity; permuting
clone labels would act naturally, and sign multiplicities would select
distinct slots. We test the actual required condition: every commuting
class has one positive generic-flow representative, and its admissibility
is preserved by all clone transpositions. This is not coefficient matching.
"""
from functools import lru_cache
from fractions import Fraction
from itertools import combinations
from collections import defaultdict
from pathlib import Path
import sys,random,json,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from universal_flow_tree_probe import FlowPackets,lexsign


def leaves(T):
    if isinstance(T,int):return (T,)
    return leaves(T[0])+leaves(T[1])


def node(A,B):
    return (A,B)if min(leaves(A))<min(leaves(B))else(B,A)


@lru_cache(None)
def trees(S):
    if S&(S-1)==0:return (S.bit_length()-1,)
    out=[];first=S&-S;L=(S-1)&S
    while L:
        R=S^L
        if R and L&first:
            out.extend(node(A,B)for A in trees(L)for B in trees(R))
        L=(L-1)&S
    return tuple(out)


def tree_value(F,T,theta=None):
    if theta is None:theta=F.theta
    if isinstance(T,int):return 1
    A,B=T;L=sum(1<<i for i in leaves(A));R=sum(1<<i for i in leaves(B));S=L|R
    pair=F.pair(L,R)
    if not pair:return 0
    h=tuple(sum(theta[i][j]for i in F.ids[L])for j in range(F.theta_width))
    if lexsign(h)!=(1 if pair>0 else -1):return 0
    theta2=tuple(tuple(theta[i][j]+h[j]*Fraction(
                 sum(F.eta[k][i]for k in F.ids[S]),pair)
                 for j in range(F.theta_width))for i in range(F.r))
    return abs(pair)*tree_value(F,A,theta2)*tree_value(F,B,theta2)


def relabel(T,a,b):
    if isinstance(T,int):return b if T==a else a if T==b else T
    return node(relabel(T[0],a,b),relabel(T[1],a,b))


def bundle_form(T,colors):
    if isinstance(T,int):return ('leaf',T)
    for side in range(2):
        x=T[side]
        if isinstance(x,int):
            c=colors[x];xs=[x];core=T[1-side]
            while not isinstance(core,int):
                hit=None
                for t in range(2):
                    y=core[t]
                    if isinstance(y,int)and colors[y]==c:hit=t;break
                if hit is None:break
                xs.append(core[hit]);core=core[1-hit]
            if len(xs)>1:return ('bundle',c,tuple(sorted(xs)),bundle_form(core,colors))
    children=(bundle_form(T[0],colors),bundle_form(T[1],colors))
    return ('node',)+tuple(sorted(children,key=repr))


def check(B,g,p):
    packets=tuple((i,1)for i,k in enumerate(p)for _ in range(k))
    F=FlowPackets(B,[1]*len(B),g,packets,color_perturb=True)
    colors=tuple(i for i,k in F.packets)
    valid=[];classes=defaultdict(list)
    for T in trees(F.full):
        value=tree_value(F,T)
        if value:
            valid.append((T,value));classes[bundle_form(T,colors)].append((T,value))
    duplicates=[(key,value)for key,value in classes.items()if len(value)>1]
    failures=[]
    for T,value in valid:
        for a,b in combinations(range(1,F.r),2):
            if colors[a]!=colors[b]:continue
            flipped=relabel(T,a,b);key=bundle_form(flipped,colors)
            if key not in classes:
                failures.append({'tree':T,'weight':value,'swap':[a,b],
                    'relabelled_tree':flipped,'bundle_form':key})
                break
        if failures:break
    return {'positive_trees':len(valid),'weighted_total':sum(v for T,v in valid),
            'commuting_classes':len(classes),'duplicate_classes':len(duplicates),
            'failures':failures,'duplicate_examples':duplicates[:1]}


def run():
    start=time.time();rng=random.Random(20261113);records=[]
    for p in [(2,1),(3,1),(2,2),(2,1,1),(2,2,1)]:
        n=len(p);passes=0;fails=0;first=None
        for _ in range(100):
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):B[i][j]=rng.randint(-3,3);B[j][i]=-B[i][j]
            g=tuple(rng.randint(-3,3)for _ in range(n))
            result=check(B,g,p)
            if result['failures']or result['duplicate_classes']:
                fails+=1
                if first is None:first={'B':B,'g':g,'p':p,'result':result}
            else:passes+=1
        records.append({'p':p,'passes':passes,'fails':fails,'first_failure':first})
        print('p',p,'pass',passes,'fail',fails,flush=True)
    out={'seconds':time.time()-start,'records':records}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__':run()
