# Integral divisors and stable-tree decorations for the local Young model

Date: 2026-11-13. Branch: `polyhedral_young_objects`.

## Outcome

This branch did not obtain a universal parking-function or single-polytope
replacement for the primitive-center Gale set. It did obtain two general
integer constructions that explain its entire component/index mechanism:

1. The primitive-center compatibility condition is exactly existence of a
   fixed **integer divisor of one explicitly determined degree**. Its degree
   uses only the input charges and arrow count. The apparent cyclotomic
   condition therefore has a direct integral interpretation.
2. Every nonzero character value has an explicit positive realization by
   nearby stable folded trees, finite half-edge labels, and a finite cyclic
   phase packet. The division by cycle lengths is a free vertex-gauge
   quotient, not division of a virtual character. This construction gives
   fixed-point objects for each permutation; compatibility of these objects
   as the fixed sets of one global G-set is not proved here.

An exact structural test rules out a proposed shortcut through Lenz's
forward-exchange theorem: the relevant stable bases can fail the defining
axiom for **every** edge order. Several stability-window candidates were
also examined and not promoted to theorems. The task ends because the root
branch has obtained a different general route through explicit tight
gradings and needs a fresh independent review of that route.

No Li--Pan conclusion is used. This note concerns classical data throughout.

## 1. Starting definitions and completed reads

The following project proofs were read before using their conclusions:

- `proofs/PRIMITIVE_CENTER_GALE_FINITE_MODEL.md`;
- `proofs/GALE_DEGREE_AND_CYCLE_TORI.md`;
- `agents/primitive_center_ih_bridge.md`;
- `proofs/COMBINATORIAL_GLOBAL_THETA_THEOREM.md`.

Let the nonzero charges beta_v lie in a pointed rank-two lattice cone, with
nondegenerate integral alternating form eta. Put

    S = sum_v beta_v = k alpha,  alpha primitive,
    a_uv = max(eta(beta_u,beta_v),0),
    E = sum_uv a_uv,
    Theta_v = outdeg_v - indeg_v.

Let G permute equal charges. Choose a quadratic refinement q with values
represented by 0 or 1, and an integral f with f(alpha)=1. The already proved
finite model has target

    Q_v = (-1)^(outdeg_v + q(beta_v) - f(beta_v)q(alpha))
          exp(-2 pi i f(beta_v)/k).

For a permutation sigma with cycle lengths l_1,...,l_c, write g=gcd(l_i)
and fold its cycles to charges l_i beta_i. Let D_F be the number of nearby
generic positive-flow spanning trees of that folded graph. The established
character formula is

    chi_L(sigma) = D_F/(product_i l_i) * C(g,E),
    C(g,E) = 1                         if g=1,
             2                         if g=2 and E/4 is odd,
             0                         otherwise.

Our constructions below are defined from graph data before evaluating this
character. They are compared with the proved formula afterwards.

## 2. A canonical integer degree replaces the root-of-unity obstruction

Define the integer candidate

    d_* = (E + sum_v q(beta_v) - k q(alpha))/2 - 1.          (2.1)

The quadratic-refinement identity says

    q(S) = sum_v q(beta_v) + E mod 2,
    q(k alpha) = k q(alpha) mod 2.

Thus the numerator in (2.1) is even. In particular d_* is an actual integer;
it is not rounded from a rational expression. It is also independent of f.

Set

    t_v = (outdeg_v + q(beta_v) - f(beta_v)q(alpha))/2
          - f(beta_v)/k.

Then Q_v=exp(2 pi i t_v), t is constant on charge colors, and

    sum_v t_v = d_*.

Consider the G-set of all integer divisors of degree d_*:

    Div^(d_*)_Z(V) = { D in Z^V : sum_v D_v = d_* }.        (2.2)

This set is infinite; no finite counting claim is made for it. It supplies
the correct affine lattice for any finite-region refinement. Equivalently,
subtract t to obtain the G-invariant affine lattice of total sum zero

    { D-t : D in Z^V, sum D=d_* }.

### Proposition 2.1

For every sigma in G, the following are equivalent:

1. Div^(d_*)_Z(V) has a sigma-fixed point;
2. gcd(l_1,...,l_c) divides d_*;
3. the canonical target Q belongs to the connected fixed target torus;
4. C(g,E) is nonzero.

The first equivalence is the elementary solvability criterion for

    sum_i l_i D_i = d_*,  D_i in Z.

For the second, the primitive target relation is

    product_i Q_i^(l_i/g)
      = exp(2 pi i (sum_i l_i t_i)/g)
      = exp(2 pi i d_*/g).

Here the sum over cycles is the same sum over vertices because t is constant
on each cycle. Thus no lift ambiguity or disconnected-torus assumption is
present.

For completeness, write l_i=g m_i, S/g=k_0 alpha and E=g^2 E_0. Put

    M=sum_i m_i q(beta_i)-k_0 q(alpha).

The quadratic-refinement identity applied to S/g gives M=E_0 mod 2. Hence

    d_*+1 = g(g E_0+M)/2.

If g is odd, d_*=-1 mod g. If g is even,

    d_* = (g/2)(E_0 mod 2)-1 mod g.

Consequently g divides d_* exactly for g=1, or for g=2 and odd E_0.
This is the complete component condition.

The root independently checked this proof and recorded it separately in
`proofs/PRIMITIVE_CENTER_INTEGRAL_DEGREE.md`.

### Why this matters for a direct polyhedral model

The required primitive obstruction can be imposed by a fixed degree in an
ordinary integer-divisor lattice. It need not be imposed by solving a
cyclotomic polynomial or by deleting points according to character values.
Any sought finite divisor region should lie in (2.2), with its ordinary
coordinate permutation action. The unknown part is its finite stability
region, not the congruence underlying the primitive phase.

## 3. The cycle isogeny index also has an entirely integral form

For positive cycle lengths l_i define

    K_l = { a in Z^c : sum_i l_i a_i=0 },
    K_1 = { b in Z^c : sum_i b_i=0 }.

Coordinate scaling diag(l_i) maps K_l into K_1. Its image consists exactly
of the b in K_1 satisfying b_i=0 mod l_i for every i. Reduction modulo the
l_i therefore identifies the quotient with

    { (r_i) in product_i Z/l_i : sum_i r_i=0 mod g }.       (3.1)

The sum in (3.1) is well defined modulo g, and its map to Z/g is surjective.
Thus

    [K_1 : diag(l_i)K_l] = product_i l_i/g.                (3.2)

The affine translates exist precisely under Proposition 2.1's divisibility
condition. Formula (3.2) is the same normalization as the fixed target torus
isogeny, now expressed by a finite integer congruence group.

## 4. Positive fixed-point objects from stable trees and half-edge labels

This gives more than a numerical divisibility check. For the given sigma,
construct the following finite objects without first computing chi_L(sigma).

1. Form the graph on the sigma cycles with a_ij=max(eta(beta_i,beta_j),0)
   base arrows. Give cycle i the folded charge l_i beta_i.
2. Choose a sufficiently small generic rational perturbation of the folded
   anti-attractor stability. Enumerate its positive-flow underlying spanning
   trees. For every tree edge, retain one of its a_ij base arrow labels.
3. At each incident half-edge at i, put a label in Z/l_i. Quotient by the
   simultaneous addition of one element of Z/l_i to all half-edge labels
   at that vertex. This is a free product of vertex-rotation actions.
4. Adjoin one element of Z/g if g divides d_*; if it does not, there are no
   objects.

Every tree vertex has positive degree because the folded graph is connected
and has at least two nonparallel charge vertices. The vertex-rotation action
in Step 3 is therefore free. Fixing one incident half-edge as reference at
each vertex gives a particularly elementary description of the quotient:
there are deg_T(i)-1 freely chosen residues modulo l_i at vertex i.

### Proposition 4.1

The set just constructed has cardinality

    [g | d_*] g
      sum_(stable base trees T) product_(edges ij of T) a_ij
                               product_i l_i^(deg_T(i)-1), (4.1)

and (4.1) equals chi_L(sigma).

Indeed, each folded tree edge has l_i l_j a_ij parallel lifts. Stability
depends on its underlying endpoints, not on these lift labels. Therefore

    D_F = sum_T product_(ij in T)(l_i l_j a_ij).

The product of endpoint factors is product_i l_i^deg_T(i). Free quotient
by product_i Z/l_i removes exactly product_i l_i choices. The final cyclic
packet contributes g precisely when the integer-divisor torsor has a fixed
point. Proposition 2.1 identifies that factor with C(g,E). This proves the
claim from graph operations and finite cyclic labels.

This construction does **not** yet produce the local G-set itself. For that,
one would need compatible restriction and conjugation maps between these
fixed-point object sets for all subgroups, or a single ambient construction
whose fixed sets they are. Equality of fixed-point counts alone does not
provide those maps. No arbitrary number of objects is inserted: each factor
in (4.1) is a tree, a base arrow choice, a finite residue, or a free gauge
quotient. The open issue is their simultaneous realization.

## 5. Exact test of the forward-exchange interface

Primary source: Matthias Lenz, *Zonotopal algebra and forward exchange
matroids*, arXiv:1204.3869v4,
https://arxiv.org/pdf/1204.3869 . Definition 6.1, the conventions for external
activity, and Theorem 7.5 were read directly. The paper uses **maximum**
elements in activity conventions.

For an ordered matroid and a selected basis B, let C be the fundamental
circuit of x outside B. If replacing b in B by x gives an unselected basis,
then forward exchange forbids b from being the maximum element of C.
Conversely, these forbidden-maximum conditions are exactly Definition 6.1:
b must be the last basis element in the flag spanning x, while x must not
be externally active. Thus existence of any valid ground-set order is a
finite constraint problem. It is decided exactly by repeatedly removing a
permissible maximum element. Once a maximum has been chosen, every circuit
containing it is settled and all other constraints remain unchanged.

The implementation `computations/stable_forward_exchange.py` checks both
the graphic matroid (stable trees) and the cographic matroid (their
complements). It enumerates exact integer tree flows and tests **all possible
edge orders by this criterion**, not merely one chosen order.

A short obstruction already occurs at charges

    (1,0),(1,0),(1,1),(0,1),(0,1).

With zero-based edge labels the arrows are

    e0:0->2, e1:0->3, e2:0->4, e3:1->2,
    e4:1->3, e5:1->4, e6:2->3, e7:2->4.

Take Theta'=6 Theta+(-4,1,1,1,1)=(14,19,1,-17,-17). There are 45
spanning trees and 15 stable ones. In the cographic matroid the circuit
{e1,e4,e6} has **every element forbidden as its maximum**. The three
witnesses are:

| Stable tree | Its ordered positive flows | Exchange | Resulting flow vector |
|---|---|---|---|
| {e2,e3,e4,e7} | (14,2,17,3) | e4 to e1 | (17,-3,19,20) |
| {e0,e3,e5,e6} | (14,2,17,17) | e6 to e4 | (14,-15,17,17) |
| {e2,e4,e5,e7} | (14,17,2,1) | e4 to e6 | (14,19,17,-16) |

The exchanged tree edge notation is dual to replacement in the cographic
basis, so the forbidden maxima are respectively e1,e4,e6. Each result is
unstable because one flow is negative. No total ordering can satisfy these
three requirements. The full graphic test also fails for every order; its
constraint certificate is in the JSON.

This rules out automatic application of Lenz's theorem to the desired
stable bases. It says nothing against the theorem itself. It also does not
rule out a different discrete chamber construction.

Independent calculation: the Wolfram Language evaluator formed the 5 by 8
incidence matrix and used LinearSolve on the six displayed trees. It returned
the three positive and three negative flow vectors in the table exactly.
The Python calculation uses cut sums instead, so the two checks do not
mirror one implementation. The calculation log is retained in
`computations/polyhedral_young_wolfram_checks.json`.

## 6. Stability-window routes actually explored

### 6.1 Ordinary break divisors and full Jacobians

The RRT graph-cut/break-divisor theorem applies to an arbitrary connected
loopless graph. However, its number of objects is the number of **all**
spanning trees. The local dimension here is the nearby stable-tree count.
Changing the generic polarization of a full compactified-Jacobian
fundamental domain does not change that all-tree cardinality. Consequently
that theorem alone cannot supply the requested stability restriction.

The degree lattice in Section 2 gives a concrete replacement for the
primitive congruence, but an appropriate finite region remains necessary.
One must not simply call all break divisors stable and reuse their count.

### 6.2 Half-open graphical zonotopes

A direct graph-only candidate was the integer image of the half-open cube,

    Z_half = partial[0,1)^E intersect Z^V.

It has a cut-inequality description:

    D(V)=0,
    D(C) <= out(C)-1   if out(C)>0,
    D(C) <= 0          if out(C)=0.

Necessity is immediate from the strict upper capacities. Sufficiency follows
by choosing one sufficiently small common epsilon>0 and using the bounded
flow cut criterion with capacities 1-epsilon. Thus this candidate is an
actual finite lattice-point construction. It agrees with the desired count
in some small configurations, but not in general: K_3,3 gives 42 points
while its nearby stable-tree count is 18. A primitive-degree congruence on
one side happens to repair that input but fails at the next structural
check. This route was dropped instead of extending an example catalogue.

### 6.3 Balanced-cut cylinders modulo the anticanonical period

The canonical t_v in Section 2 motivates the window candidate

    D in Div^(d_*)_Z(V),
    |D(C)-t(C)| < A(C,C^c)/2 for every proper balanced C,
    modulo the period Z Theta.

In the tested bipartite families the quotient is bounded. For arbitrary
charge data these balanced inequalities need not span the quotient, so
boundedness itself would also require additional conditions. The primitive
phase keeps the displayed balanced boundaries away from the integer lattice.
The coordinate action has Young stabilizers even after the
period quotient: if sigma D-D=m Theta, applying the finite order of sigma
forces m=0. Thus the candidate has the right kind of genuine stabilizers.

It nevertheless has the wrong size in general. For K_4,4 with unit arrows
it gives 320 points, whereas D_F at the identity is 384. The issue is that
conditions on balanced normal slices alone omit the unbalanced stability
strata. This candidate was not asserted to model IH or theta coefficients.

These two failures leave a precise constructive direction: a finite divisor
window must encode the nonbalanced stability filtration as well as the
primitive total degree. They do not justify replacing the main task by
counterexample collection.

## 7. Literature and route record

The primary-source searches were broad before selecting the exact interface
to test. Relevant records, including negative results, are listed here.

| Source | Read/use status | Mathematical assessment for this task |
|---|---|---|
| Lenz, arXiv:1204.3869v4 | Definitions 1.2, 6.1 and Theorem 7.5 read directly | Strong general P/D-space interface; its forward-exchange hypothesis fails for the stable bases, by Section 5. The paper itself is not marked erroneous. |
| Reineke--Rhoades--Tewari, arXiv:2207.11861v2 | Root's full primary-source audit retained; graph theorem and parking discussion checked against publisher text | Correct full graph-cut/break-divisor theorem. Its all-tree count is not the stable-tree count here. No invalid transfer made. |
| Holtz--Ron, arXiv:0708.2632 | Primary abstract and general construction located | Central/internal/external zonotopal spaces alone do not encode the required stability subset; no theorem imported. |
| De Concini--Procesi--Vergne, *Partition function and generalized Dahmen--Micchelli spaces*, arXiv:0805.2907 | Primary author PDF located; chamber-local/discrete interpolation passage read | Gives an appropriate chamber-local language, but a subspace of functions on a shifted zonotope is not automatically functions on a subset. No positive subset theorem inferred. |
| Crowley--Proudfoot, arXiv:2505.05324 | Primary abstract located | Internal zonotopal/reduced Orlik--Terao duality has a different algebra input. Not used to identify local flow IH. |
| Huang--Zhou, arXiv:2011.06114; Huang's 2021 thesis *Toric mirror symmetry and GIT windows* | Primary abstract/author institutional thesis description read | Magic-window lattice points are promising for quasi-symmetric torus actions. The acyclic incidence representation here is not quasi-symmetric on each weight line. No unrestricted window theorem applied. |
| Brodsky, *The Zonotopal Algebra of the Broken Wheel Graph and its Generalization*, EJC 31(1), 2024, P1.49 | Publisher primary abstract read | Provides monomial parking bases for a controlled graph family. It does not furnish the arbitrary stable-graph mechanism. Not pursued as a special-case deliverable. |
| Root/flow/order-polytope and root-polytope parking literature | Primary search records located | Root-polytope normalized volume explains stable-tree dimensions but does not by itself recover the primitive Young action. No dimension-only representation claim made. |
| 2026 toric arc, intrinsic-window/quasi-BPS, and generalized parking papers surfaced by searches | Discovery records only, except root's separate audits | Their theorems were not used. In particular none of these discovery snippets counts as the user's required strong audit of a 2026 result. |

Primary URLs for further continuation:

- https://arxiv.org/pdf/1204.3869
- https://arxiv.org/pdf/2207.11861
- https://arxiv.org/abs/0708.2632
- https://webusers.imj-prg.fr/~michele.vergne/publications/0805.2907_PartitionFunctionAndGeneralizedDahmen-MicchelliSpaces.pdf
- https://arxiv.org/abs/2505.05324
- https://arxiv.org/abs/2011.06114
- https://www.ideals.illinois.edu/items/121038
- https://www.combinatorics.org/ojs/index.php/eljc/article/view/v31i1p49

## 8. Handoff

The positive reusable results are the degree torsor, its lattice index, and
the free half-edge-gauge fixed-point construction. The direct Lenz shortcut
and the two naive window rules have been tested and recorded so that the
next branch need not repeat them.

At handoff, the root reports a different general pure integer construction
through `proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md` and a valued global
event-DAG assembly. That route can produce half-open polyhedral cells by
finite comparison hyperplanes without first solving the single-divisor
window problem. This note makes no claim to have reviewed that new theorem;
the released agent slot is intended for its fresh independent review.
