# Squarefree polytope action: local rectangle maps and canonical toric IH

Branch `/root/squarefree_polytope_action`, begun 2026-11-13 11:04:50 UTC.
Only classical cluster coefficients are targets. No Li Fang/Pan theorem is used.

## Outcome at this checkpoint

**Current sign convention (11:53 UTC):** the global assembler now uses local
arrow-count parity `epsilon_v=|Q_(v,1)| mod 2`. The earlier local Euler parity
recorded in Section 8 was an intermediate candidate and is superseded by the
explicit four-cycle counterexample and tau correction in Section 10. The old
code and outputs are retained for reproducibility. All 114 historical inputs
and their 503 complete cycle types have now been rerun under this convention
and pass. The additional first S4 input passes all ten cycle types.

The direct local rectangle maps give honest bijections across individual
flow-tree chamber walls, but they do **not** give a coherent global clone
permutation action. The precise failure has been localized to simultaneous
rank-two packets. There is a substantially better replacement: a simultaneous
packet has an acyclic thin quiver and an explicit transportation polytope;
its canonical toric intersection cohomology carries the required symmetry
without choosing a chamber basis.

This branch independently computes the complete graded natural IH character
for every `m`-arrow `K_(2,2)` packet. It then assembles the previously difficult
six-leaf example into the **correct global character `(88,40,36,12)`** using
four simultaneous skeletons. This is a verification of a general proposed
mechanism, not a claim that the global equivariant trace theorem is proved.
The remaining theorem is an equivariant/plethystic compatibility assertion for
the entire skeleton construction. It cannot be checked separately at each
packet by replacing a permutation cycle with a weighted leaf.

## 1. The first attempted polytope: union of activation boxes

For `r=-g`, an ordering `pi` of the vertices gives capacities

`h_(pi_k)=r_(pi_k)-sum_(j<k) B_(pi_k,pi_j)`.

Take the union of the integer boxes `product_i [0,h_i)` over all orderings
with positive capacities. This is a finite set defined by the graph, with a
natural action on clone coordinates. It correctly counts the zero matrix
and the balanced oriented triangle with `r=(1,1,1)`, but is not general.

The exact defect is that it only permits **one vertex to activate at a time**.
A flow tree can first bind several vertices into a block and then attach that
block to the frame. For `B=[[0,1],[-1,0]], g=(-2,1)`, no ordering has all positive
capacities, whereas the squarefree theta coefficient is one. The bound block
has positive total frame pairing even though the second individual activation
has capacity zero. A valued cyclic test with all coordinates of `g` negative
also gives 72 box points versus coefficient 81, so changing only the initial
sign of `g` does not repair the model.

Code and all counterexamples: `computations/squarefree_polytope_action/box_parking_probe.*`.
This route was stopped as soon as the general mechanism failed.

## 2. A genuinely local integral Ptolemy bijection

Let three child charges be `A,B,C`, and set

`a=eta(A,B), b=eta(B,C), c=eta(C,A)`.

The three binary resolutions have undecorated multiplicities

`|a(b-c)|, |b(c-a)|, |c(a-b)|`.

The Jacobi relation is exactly the Ptolemy relation for the four integer
points `0,a,b,c`. If their ordered values are `t0<=t1<=t2<=t3`, the rectangle

`[t0,t2) x [t1,t3)`

is bijective, at the level of integer points, to the disjoint union

`([t0,t1) x [t2,t3))  disjoint-union  ([t0,t3) x [t1,t2))`.

An explicit rule is:

* If `x<t1` and `y>=t2`, use the first rectangle and leave `(x,y)` unchanged.
* Otherwise use the second rectangle. Leave `(x,y)` unchanged if `y<t2`;
  if `y>=t2`, replace it by `(y,x)`.

The inverse on the second rectangle leaves `(u,v)` unchanged for `u<t2` and
swaps the coordinates otherwise. Degenerate intervals are handled by ordering
the four labelled endpoints, not merely their numerical values. No global
coefficient is used to manufacture this map.

The implementation enumerates binary trees, propagates the rational flow
covector, computes the exact interval on a line segment where each tree is
stable, groups trees at a crossing by the contracted three-child skeleton,
and applies this rectangle map only to the two affected integer decorations.

### Failure of unrestricted coherence

For

```
eta = [[0,-1,-1,-1],
       [1, 0, a,-a],
       [1,-a, 0, a],
       [1, a,-a, 0]],
```

take the frame coordinate `-3` and move the mutable coordinates around

`(11/10,1,9/10) -> (9/10,11/10,1) -> (1,9/10,11/10) -> first`.

For `a=1,2,3`, respectively, there are 4, 7, 10 decorated tree points.
The closed transport moves four points in each case. The skew Pfaffian is
`-3a`, so these are genuine rank-four examples. Thus arbitrary chamber
transport is not flat for this particular local rectangle rule.

### Restricting to clone permutations

For identical-color leaves, relabel the tree and transport from the permuted
small stability perturbation back to the original one. This produces the
correct action in several nontrivial checks:

* Zero matrix, `g=-2,p=3`: 8 points, each transposition fixes 4, and the braid
  relation holds.
* Rank-two examples with three repeated leaves: braid relations hold.
* Markov weight 2, `g=(-1,-1,-1),p=(2,2,1)`: 133 points, the two transpositions
  fix 79 and 41, and commute.

However, for

```
B=[[0,2,-3],[-2,0,2],[3,-2,0]], g=(-3,3,-2), p=(2,2,1),
```

the two maps are individually involutions with the correct traces 40 and 36
on 88 points, but they fail to commute on 24 points. Every tree was checked
against the color-constant stability space: there are no accidental rational
zero faces in this calculation. Reversing or cyclically negating a decoration
when canonical child order reverses does not cure the failure.

This is precisely why a canonical **module** is needed rather than an
arbitrarily selected chamber basis. The failure does not disprove the toric
IH construction below.

Files: `flow_box_holonomy.py`, `clone_ptolemy_probe.*`,
`relabel_orientation_probe.*` in the branch computation directory.

## 3. The local polytope and a fully combinatorial module

The simultaneous-packet branch proves that the child charges of an actual
color-generic zero-flow event lie in a rational two-plane. Their intersection
with the original positive cone is pointed. If the skew form on the plane is
nonzero, an angular order makes all nonzero arrows go forward; thus the local
quiver is acyclic. Zero skew form yields only commuting pieces. This geometric
claim is owned and fully recorded by that branch.

For an ordinary acyclic thin quiver `Q`, let `partial` be its arrow incidence
matrix and let `theta` be the local anti-attractor stability. The polytope

`P(Q,theta)={u in R_(>=0)^(Q_1): partial u=theta}`

is bounded whenever nonempty. It and its normal fan can be constructed from
finite incidence data and linear inequalities. A vertex/arrow permutation
preserving the quiver and stability acts on the polytope and fan.

For a rational complete fan `Sigma`, its intersection cohomology can be
defined entirely in terms of its cones. Let `A_sigma=Sym(span(sigma)^*)`.
A minimal extension sheaf is constructed recursively from `E_0=Q` by taking
at each cone a minimal free `A_sigma`-cover of the compatible boundary
sections. Explicitly, the generator space is the reduction of the boundary
section module modulo positive-degree linear functions. A finite stabilizer
can be respected by averaging a graded splitting. Global compatible sections,
modulo global positive-degree linear functions, give `IH(Sigma)`.

This is a finite graded linear-algebra/polynomial-module construction from
the fan. Different equivariant choices yield the same representation type.
For rational fans the comparison with geometric IH is classical. The use
of geometry proves the identification; it is not additional input to the
combinatorial module. No theta multiplicity is supplied to this construction.

The small-resolution hypothesis remains important: it is what identifies the
dimension of this canonical module with the sum over nearby binary trees.
The parent branch is auditing Reineke's theorem for exactly this hypothesis.
We do not replace that audit by a general assertion about all quiver moduli.

## 4. Complete calculation for every `m`-arrow `K_(2,2)` packet

Take two source vertices and two sink vertices, with `m>=1` parallel arrows
at every source-sink pair. The anti-attractor stability is proportional to
`(-1,-1,+1,+1)` and the thin dimension vector is `(1,1,1,1)`.

Write the four edge groups as `a,b,c,d`, in matrix order. After normalizing
the row and column sums to one, their total flows satisfy

`sum a=sum d=tau`, `sum b=sum c=1-tau`, `0<=tau<=1`.

Consequently the flow polytope is

`P_m = (Delta_(m-1) x Delta_(m-1)) * (Delta_(m-1) x Delta_(m-1))`.

This statement is an explicit affine parametrization, not a numerical
identification. The group `S_2 x S_2` permutes rows and columns.

### Local IH at the two endpoint strata

On either endpoint, the transverse affine singularity is the cone over
`P^(m-1) x P^(m-1)`. Its local IH has polynomial

`G_m(t)=1+t+...+t^(m-1)`.

Indeed in the relevant lower degrees it is the primitive quotient

`Q[x,y]/(x^m,y^m,x+y)`.

Swapping the two factors sends `x^k` to `(-1)^k x^k`, so its local trace is
`G_m(-t)`, not `G_m(t)`. This sign is forced by the canonical action on IH;
it is invisible in ordinary unsigned counts of a selected resolution basis.

All strata meeting the relative interior of both join factors are smooth.
Thus all local contributions are explicit.

### Equivariant torus-orbit calculation

For a fixed face with supported-arrow set `S`, the torus orbit has character
lattice `ker(partial_S)`. Its compactly supported equivariant E-polynomial is

`det(t I - sigma | ker(partial_S))`.

For an involution, this determinant is computed by the numbers of one- and
two-cycles on supported arrows, vertices, and connected components. Multiply
it by the local IH trace and sum over fixed faces. Equivariant additivity and
purity give the global graded character. This derivation works directly from
the polytope face sets, without a theta or a flow-tree oracle.

The result, for identity, row swap, column swap, and their product, is

```
H_e(t)       = G_m(t)^3 (1+t^m),
H_row(t)     = H_col(t) = (1+t) G_m(t^2)^2,
H_rowcol(t)  = (t-1) G_m(t^2)^2 + 2 G_m(t^2) G_m(-t).
```

For example, the identity formula follows from the two types of faces:

* Both join factors nonempty contribute `(t-1)G_m(t)^4`.
* Exactly one join factor nonempty contributes `2G_m(t)^3`.

Their sum is the displayed `G_m(t)^3(1+t^m)`. The other formulas follow by
requiring the appropriate pairs of arrow-color subsets to agree.

At `t=1` the character is

`(2m^3, 2m^2, 2m^2, 2m*(m mod 2))`.

For `m=2`, the four graded traces are

```
(1,3,4,4,3,1),
(1,1,2,2,1,1),
(1,1,2,2,1,1),
(1,-1,0,0,-1,1),
```

hence the ungraded character is `(16,8,8,0)`.

The independent Python implementation verifies nonnegative integral graded
irreducible multiplicities for `m=1,...,12`. The actual Wolfram plugin
independently reproduces the formulas, the four graded traces for `m=2`, and
all irreducible checks for `m=1,...,8`. Its undefined-symbol warning comes
from declaring `G` before defining it; the displayed exact output is valid.

Files: `toric_k22_family.py`, `toric_k22_family.json`, `toric_ih_wolfram.json`.

## 5. Independent global assembly of the difficult example

Use clone labels `0` for the frame, `1,2` for color one, `3,4` for color two,
and `5` for color three. The simultaneous-packet branch finds four skeletons:

```
A=((0,5),(1,4),(2,3)),              dimension 8,
B=((0,5),(1,3),(2,4)),              dimension 8,
C=((0,5),(1,2,3,4)),                dimension 64,
D=(0,(1,2,(3,4,5))),                dimension 8.
```

These are module constructions, not just four scalar dimensions:

* A and B have three binary factors of dimension two, and a rank-one star
  factor. Either single clone transposition swaps the two skeletons. The
  product transposition fixes each skeleton and swaps two `Q^2` tensor
  factors. The trace on each is `2*2=4`. Together their character is
  `(16,0,0,8)`.
* C has two exterior binary factors `Q^2`, and the canonical `m=2` K22 IH
  module. Its character is four times `(16,8,8,0)`, namely `(64,32,32,0)`.
* D has an exterior `Q^2` and an inner `(Q^2) tensor (Q^2)`. The first-color
  transposition acts trivially, while the second-color transposition swaps
  the latter factors. Its character is `(8,8,4,4)`.

Adding the three contributions gives

`(16,0,0,8)+(64,32,32,0)+(8,8,4,4) = (88,40,36,12)`.

This agrees exactly with the independently computed weighted-cycle values.
The sign-sign multiplicity is `(88-40-36+12)/4=6`.

The double-cycle trace is particularly informative. It does not come from
folding the K22 packet alone: that packet's natural IH trace is zero. The
missing contribution is supplied by permutations of isomorphic subtrees in
A and B. Thus a proof of the general trace theorem must operate on the full
species of skeletons with tensor induction. Adams/plethystic terms cannot
be discarded node by node.

## 6. Literature audit and route review

At approximately 11:22 UTC, the second literature pass concentrated on toric
IH and equivariant fan formulas, after the Ptolemy action failed. It led to a
new general mechanism rather than more isolated examples.

| Source | Text inspected | Decision |
|---|---|---|
| Reineke--Rhoades--Tewari, arXiv:2207.11861v2 | Introduction and main equivariant break-divisor/zonotopal chain | Useful precedent, not applicable as a theorem to our skew quiver. Its DT application assumes symmetric quivers with enough loops. |
| Barthel--Brasselet--Fieseler--Kaup, math/0002181 | Abstract, introduction, minimal-extension and rational-fan comparison setup | Safe classical source for the finite fan-module construction. The old preprint's non-rational vanishing conjectures are not invoked; all our fans are rational. |
| Reineke, arXiv:1511.08316 | Introduction and thin toric/GIT setup; parent handles full Theorem 4.3 audit | Useful small-resolution interface, conditional here on the hypotheses verified elsewhere. |
| Tao Gui, arXiv:2605.15061v1 | Full Theorem 1.1 proof, monomial support decomposition, tensor splitting, equivariant duality proof | Main character formula has a short independent verification. A local normalization error in the printed top-class proof is identified below and repaired. We do not need the later hybrid-fan theorem. |
| Gui--Qin--Shen--Xiong, arXiv:2609.06597 | Official abstract/version record only; official PDF/HTML fetch failed | Potentially useful smooth-projective permutation-representation theorem. Not used because the proof has not been obtained or audited, and our IH fans can be nonsimplicial. |
| arXiv:2606.09054 | Official abstract only | Morse/Y-graph gluing; not the required cluster/finite action interface. Not used. |
| arXiv:2608.11771 | Official abstract only | Jacobi permutations concern elliptic-function combinatorics, not Lie-Jacobi coherence. Not used. |

### Specific 2026 correction: determinant normalization

In arXiv:2605.15061v1, the displayed relation immediately before (the claimed)
`x_sigma1/|det(v_sigma1)| = x_sigma2/|det(v_sigma2)|` is

`det(v_sigma1)*x_sigma1 + det(v_sigma2)*x_sigma2 = 0`,

with the determinants of opposite signs. The valid conclusion is

`|det(v_sigma1)|*x_sigma1 = |det(v_sigma2)|*x_sigma2`,

with multiplication, not division. Replacing the proposed canonical top
class by `|det(v_sigma)|*x_sigma` repairs this step. A finite group preserves
absolute determinant, so the intended conclusion that the top class is
trivial still follows. The main graded character formula then follows from
the completely explicit monomial-support trace computation in the paper.
This is a local proof error with a direct repair, not evidence that its
main theorem is false.

The formula for a complete simplicial fan is

`Tr(sigma,H^*,t)=sum_(sigma-fixed cones rho) det(tI-sigma | V/span(rho))`.

For nonsimplicial fans one must insert the local IH trace. Omitting that
factor would destroy the K22 computation above. Our K22 proof uses the
classical torus stratification and the explicit Segre-cone local factor,
so it does not rely on an unreviewed 2026 nonsimplicial extension.

## 7. Remaining mathematical work

The constructive problem is now specific:

1. Prove the local acyclic anti-attractor small-resolution comparison for
   every actual simultaneous packet, including non-generic semistability.
2. Form the global direct sum over simultaneous skeletons of induced tensor
   products of their finite fan-IH modules.
3. Prove, at the whole-skeleton level, that its permutation-cycle trace is
   the weighted-cycle squarefree theta coefficient. The K22 example shows
   why local primitive folding alone is insufficient.
4. Only after this trace theorem, pass to the sign isotypic part to obtain a
   graph-defined finite vector-space interpretation of an arbitrary theta
   coefficient. A positive set or preferred basis would be a further step.

The parent and sibling branches are pursuing (1)--(3). This report does not
replace these tasks by a declaration that the high-rank greedy goal is solved.

## Primary source links

* https://arxiv.org/pdf/2207.11861
* https://arxiv.org/pdf/math/0002181
* https://arxiv.org/pdf/1511.08316
* https://arxiv.org/html/2605.15061v1
* https://arxiv.org/abs/2609.06597

## 8. General global assembler and the necessary super symmetry

### A graph-defined representation, rather than a coefficient-defined one

The first implementation, now archived as `global_tensor_ih_euler_parity.py`,
constructed the full character
for arbitrary skew-symmetric input of tractable leaf size. Its definition is:

* Enumerate the intrinsic color-generic simultaneous skeletons, using the
  sibling branch's exact zero-flow contraction.
* At every internal vertex `v`, construct the acyclic thin quiver on its
  child charges, its anti-attractor transportation polytope, and the normal
  fan IH module `H_v`.
* Assign this even IH vector space the **uniform parity shift**

  `epsilon_v = chi_Qv(1,1) = number_of_children - number_of_arrows (mod 2)`.

* Take the super tensor product of all `H_v` belonging to a skeleton. The
  clone group permutes skeletons and local factors, using the Koszul symmetry
  for factors that are odd. Finally forget the grading, obtaining an ordinary
  finite-dimensional representation.

The last step means ordinary trace/dimension, not supertrace/superdimension.
Different skeletons need not have the same total parity. This does not prevent
an honest group action on the underlying direct-sum vector space.

The induced action is defined from the graph/fan data. No theta coefficient,
character multiplicity, or desired dimension enters its construction. The
independent integer theta routine is called only after construction to compare
cycle traces.

For a permutation fixing a skeleton, let `O` run over its orbits on internal
vertices. Choose `v in O`, put `k=|O|`, and let `sigma^k_v` be the returning
permutation on the children of `v`. Then the character is

`sum_(fixed skeletons K) product_(node orbits O)
  (-1)^((k-1)epsilon_v) Tr(sigma^k_v | IH_v)`.

This is the standard super tensor-cycle trace formula. The local arrow
permutation maps `(source,target,parallel_index)` to the permuted endpoints
with the same parallel index. Local fan actions are handled by the independent
`equivariant_toric_ih.py` engine in the natural-module branch.

The assembler uses two proved computational shortcuts: a star packet is a
product of projective spaces, so its trace is the product of the edge
multiplicities over child cycles; the K22 family uses Section 4. For an
identity local permutation, the dimension can be computed independently as
the number of vertices of a generically perturbed flow polytope, enumerated
by positive cut flows on simple spanning trees, multiplied by choices of
parallel arrows. Nontrivial remaining permutations use the full exact fan
recursion.

### Why ordinary tensor symmetry is wrong

The first broad test of ordinary tensors found the input

```
B=[[0,-1,2],[1,0,2],[-2,-2,0]], g=(1,-3,0), p=(2,2,1).
```

The ordinary assembly gives cycle traces `(144,80,64,96)`, whereas the
independent weighted-cycle coefficients are `(144,80,64,32)`.

Two fixed crossing skeletons each contribute `+16` to the last entry by
exchanging two isomorphic one-arrow binary packet factors. Such a local
packet has Euler parity `2-1=1`. The Koszul exchange changes each contribution
to `-16`. The four-child K22,1 packet contributes 64, so the corrected result
is `64-16-16=32`.

The previously successful K22,2 example has even binary packet parity and is
unchanged. This is therefore a structurally explained correction that is
forced by an independent input, not a modification made only to preserve the
initial example.

The failed ordinary output is retained in
`global_tensor_ih_ordinary_failure.json`.

### Literature interface for the parity

Efimov, arXiv:1103.2736v2, page 2, explicitly uses cohomological degree
`k+chi_Q(gamma,gamma)`; Theorem 1.2 records primitive parity
`chi_Q(gamma,gamma) mod 2`. This is evidence for the same Euler shift, but his
stated freeness theorem is for symmetric quivers, so it is not cited as a
direct theorem about our arbitrary local quiver. The fresh
`equivariant_dt_proof` branch is checking the canonical PBW/DT maps with the
symmetric-on-zero-slope Euler condition. It reports that the additional
half-Tate/Lie-generator shift changes the IH parity `dim(M)` to
`dim(M)+1 = chi_Q(1,1) mod 2`, exactly as required here.

### Completed and expanded tests

The first general suite completed **63 inputs and 266 full cycle-type
comparisons**, all passing after the Euler-parity correction. It includes
skew rank three and four, arbitrary orientations, mixed-sign labels, repeated
colors of multiplicity two and three, charges with zero coordinates, and
nontrivial simultaneous packets. Nineteen inputs have nonzero modules; zero
inputs still test the boundary/vanishing construction.

A second suite deliberately includes many nonzero modules and forces general
fan calls beyond the K22 family. Its initial three inputs include local K32
and K33 packets, and all their complete cycle types pass. At 11:40 UTC it had
completed 34 inputs and 149 comparisons with no failures, including 23 distinct
cached nontrivial calls to the generic fan-IH routine. Final counts should be
read from `global_tensor_ih_stress.json`, which is updated after every input.

These are mechanism tests. They support, but do not replace, the general
representation-valued trace identity being proved in the parallel branch.

## 9. Additional primary source and second route checkpoint

At 11:37 UTC the parity failure triggered a focused new literature pass.
The useful primary source was Efimov's cohomological Hall algebra paper:
https://arxiv.org/pdf/1103.2736 . Its exact grading convention was read before
using it as an explanatory interface. A 2026 search hit, *BPS Lie algebras,
perverse filtrations, and shuffle algebras*, was noted but not used as a theorem
in this branch. The parent has delegated the needed complete equivariant DT
proof to a fresh agent.

The important change in route was from choosing coherent positive chamber
bases to defining a canonical fan-IH module and then using the correct super
symmetry. This changes the mathematical object that supplies coherence; it
does not merely rename the same missing bijection.

### Scope of the implemented natural-module assembler

The general module assembler in this branch takes **skew-symmetric** `B`.
It deliberately rejects a genuinely valued matrix. The incoming integer
formula and weighted-cycle targets exist for all skew-symmetrizable inputs,
but a species/arithmetic-lattice version of the present fan-IH module has not
been constructed here. The valued extension must not be inferred by feeding
`DB` into this routine: that changes the coefficients.

The second general suite finished at 11:41 UTC with **51 inputs, 237 complete
cycle-type comparisons, and 45 nonzero modules**, all passing. Together with
the first suite this is **114 inputs and 503 cycle-type comparisons**, including
64 nonzero modules. The second suite used 28 distinct cached calls to the
fully general fan-IH character engine. The exact final logs are retained.

## 10. Four-cycles expose the tau twist; current parity is arrow count

The S4 test was deliberately added after the first 114 successful inputs.
It found a further real defect in the Euler-only version, on

`B=[[0,1],[-1,0]], g=(-6,1), p=(4,2)`.

There are 65 simultaneous skeletons. All dimensions and eight of the ten
cycle types agree, but the Euler-only candidate gives

```
cycle type ((2,2),(2)): 36 instead of 124,
cycle type ((4),(2)):  -22 instead of 22.
```

Its sign multiplicity nevertheless happens to be correct (60): these two
errors cancel in the sign inner product. Hence checking only the final theta
coefficient would have missed this defect. The complete cycle character is
a materially stronger verification.

### The exact failing fixed skeletons

The nonzero four-cycle contributions come from

```
(0, (1,3,6), (2,4,5)),
(0, (1,3,5), (2,4,6)).
```

Each has dimension 121. The permutation exchanges two three-leaf stars with
local quiver two single arrows. Each such star has arity 3 and arrow count 2.
The exterior framed star has two arrow multiplicities 11. Euler-only parity
assigns the exchanged stars odd parity and produces `-11` from each.
The correct trace requires `+11` from each.

Full records, including every local skew matrix, are in
`fourcycle_tau_diagnosis.json`. The Euler-only implementation and its failing
output are retained as `global_tensor_ih_euler_parity.py` and
`global_tensor_ih_euler_fourcycle_failure.json`.

### The corrected structural rule

The representation-valued DT/PBW source uses a **tau-twisted symmetry**, not
plain Koszul symmetry for the Euler shift. The proof branch derived that for
two disjoint isomorphic branches containing `s` leaves, the additional tau
sign is `(-1)^s`. In particular the three-leaf stars require the extra minus
sign that cancels their Euler-only exchange sign.

The effective local parity for the ordinary tensor-category presentation is

`epsilon_v = number_of_arrows(Q_v) mod 2`.

This was also derived independently by the `ih_global_independent` branch
from contraction invariance. There is a strong input-level consistency check:

`sum_(internal v) epsilon_v = sum_(unordered atom pairs a,b) |eta_ab| (mod 2)`.

Indeed each pair of leaves occurs exactly once, at its lowest common ancestor,
and the absolute value of a sum is congruent modulo two to the sum of the
absolute values. Thus the total parity is **the same for every skeleton**.
A single global shift makes the whole fixed-input module even before one
forgets grading. Euler-only parity did not have this property: it changed
when an odd-arity packet was contracted.

The current `global_tensor_ih.py` implements this arrow-count parity. It
repairs all ten cycle types of the first S4 example, including `(4),(2)`.
All historical inputs have now been rerun under the new convention rather
than assuming that the previous successes persist. The proof branch has
derived the rule for isomorphic branch exchanges from the canonical
tau-twisted PBW maps; the remaining global comparison is stated explicitly
below. This remains a candidate with exact computational evidence, not a
proved theta identification.

## 11. Final stage result and executable handoff

At 11:53 UTC the complete arrow-parity historical rerun finished: **114
inputs, 503 complete cycle-type comparisons, 64 nonzero modules, all
passing**. This is the sum of the 63-input/266-comparison basic suite and
the 51-input/237-comparison dense suite. The latter includes 28 distinct
cached calls to the fully general fan-IH engine, beyond the star and K22
formulas. The rerun took 431.5 seconds. The additional first S4 input adds
one nonzero input and ten passing cycle types, so the presently completed
current-convention evidence is **115 inputs and 513 cycle types**.

The completed outputs are `global_tensor_ih.json`,
`global_tensor_ih_stress.json`, and the first entry of
`global_tensor_ih_fourcycles.json`. The complete historical rerun log is
`arrow_parity_history_rerun.log`. These overwrite the main filenames with
the current convention; the failed/intermediate conventions remain in
the explicitly named historical and failure files.

### What the implementation constructs

For skew-symmetric input `B,g,p`, label the `p_i` clones and the one frame.
Construct the intrinsic positive-time simultaneous skeletons. At each
internal vertex `v`, form the acyclic event quiver on its child charges
and its anti-attractor flow polytope `P_v`. The proposed finite module is

`V_(B,g,p) = direct_sum_K super_tensor_(v internal in K) IH(P_v)[E_v]`,

where `E_v` is the number of arrows. Clone permutations move skeleton
summands, act naturally on the local fans, and permute factors with the
indicated graded symmetry. This defines a genuine finite representation
without knowing any theta coefficients. All summands have the same total
parity, by the lowest-common-ancestor identity in Section 10.

For a permutation fixing a skeleton, the code partitions its internal
vertices into orbits. An orbit of length `k`, represented by `v`, contributes

`(-1)^((k-1)E_v) Tr(return_permutation | IH(P_v))`.

Multiplying these contributions and summing fixed skeletons gives the
ordinary character of this explicit module. The algorithm never matches
points arbitrarily to prescribed character values. The separate function
`weighted_theta` is called only after construction to compare the result
against the independently established weighted-cycle target.

### Local proof now available; exact global obligation

The fresh proof branch has saved `agents/equivariant_dt_proof.md`.
Its Sections 3--6 prove the equivariance of the canonical local PBW map
and compute the effective interchange sign. With the Davison--Meinhardt
twist `tau(d,e)=chi(d,e)+chi(d,d)chi(e,e)`, the pure Hall-generator Koszul
parity cancels the second term, leaving cross Euler parity `chi(d,e)`.
For two disjoint isomorphic colored branches this is their internal arrow
count modulo two. This supplies the mathematical origin of the correction,
independently of the S4 numerical repair.

The remaining theorem is **global**: iterating those equivariant local
Fock/PBW replacements in the completed colored species algebra must yield
exactly the collapsed-skeleton direct sum above, including cyclic
permutations of repeated parallel branches and all plethystic terms.
Neither scalar flow-tree formulas nor positivity alone prove this.
In particular, packetwise equality to a primitive weighted folded flow
number is false, as the K22,2 double-swap example already shows.

### Running targeted S4 stress test

The larger S4 suite remains running at handoff in exec session **66928**:

`python computations/squarefree_polytope_action/global_tensor_ih_fourcycles.py`

The first input `B=[[0,1],[-1,0]],g=(-6,1),p=(4,2)` is complete. The
second input, `B=[[0,2],[-2,0]],g=(-12,1),p=(4,2)`, requires the larger
K42 packet fan calculation. A final mixed rank-three S4 input is queued
after it. The JSON output is updated after every complete input; none of
the unfinished cases is counted in the totals above. The completed
historical rerun session 39208 has exited successfully and needs no poll.

The next agent can import `one_case`, `trace_skeleton`, and `local_trace`
from `global_tensor_ih.py`; the local event engine is
`computations/natural_incoming_module/equivariant_toric_ih.py`.
The current natural-module implementation is deliberately skew-symmetric
only. A valued/species extension is a separate remaining task.
