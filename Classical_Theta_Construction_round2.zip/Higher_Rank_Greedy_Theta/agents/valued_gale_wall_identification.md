# The arbitrary-framing power and the valued two-input wall

**Stage:** 2026-11-13, 13:24 UTC. This closes the wall-identification
interface of `valued_gale_attached_theorem.md` at the level of the full
Frobenius characteristic. It does not identify a single singular IH stalk
with an attached factor, and it does not assert the arbitrary-rank global
combinatorial construction.

The parameter `v` below records ordinary Chow degree and Euler shifts.
It is used to prove an identity whose conclusion is entirely classical.
No quantum cluster-algebra assertion is required.

## 1. Ordinary two-input data and conventions

Fix `m>=1`, primitive `(a,b)>0`, and positive framing counts `P,Q` with

\[
 Pa-Qb=\kappa>0.\tag{1.1}
\]

For the attached-algebra finiteness theorem already proved we assume
`kappa<=m`. This includes every valued input of that theorem, because
`kappa | lcm(d_A,d_B) | m`. The framing calculation below itself uses
only positivity of `kappa`.

Let `alpha=(alpha_1,...,alpha_s)` and `beta=(beta_1,...,beta_t)` be finite
alphabets. Use one quiver vertex for each alphabet letter, with `m`
arrows from every B-vertex to every A-vertex. For a dimension vector `d`
write `A(d),B(d)` for its two total dimensions. Its Euler form and our
based-monomial skew convention are

\[
 \chi(d,e)=\sum_i d_i e_i-mB(d)A(e),\qquad
 \eta(d,e)=\chi(e,d)-\chi(d,e)
       =m(B(d)A(e)-A(d)B(e)),
\]
\[
 X^dX^e=v^{\eta(d,e)}X^{d+e}.\tag{1.2}
\]

Let `H(U;v)` be the central, slope-`(a,b)` semistable factor of the
ordinary polynomial Hall series, retaining all alphabet tags. Explicitly
its degree-`d` coefficient is
`v^(chi(d,d)) Hilb(B_d;v^2) alpha^(d_A) beta^(d_B)` when the totals are
`k(a,b)`, attached to `U^k`. Here `B_d` is the semistable polynomial
quotient at slope `(a,b)`. This central factor depends on the unframed
quiver and the slope, not on `P,Q`. Its aggregate monomials commute.

### Established input, checked on the primary source

Franzen--Reineke, *Semistable Chow--Hall algebras of quivers and quantized
Donaldson--Thomas invariants*, Algebra & Number Theory 12 (2018),
Theorems 6.2 and 8.1, give the ordered HN factorization and the quotient
by forbidden shuffle products. Their proofs use HN strata and proper
incidence maps. We read the published proofs and use these ordinary
quiver statements, with no symmetric-quiver DT consequence. The
prepublication arXiv1512.03748v2 numbers the HN theorem 6.1 instead.
Primary published PDF:
<https://msp.org/ant/2018/12-5/ant-v12-n5-p01-p.pdf>.

The polynomial shuffle kernel is
`prod_(i,j,r,s)(y_(j,s)-x_(i,r))^(a_ij-delta_ij)`.
Its degree shift is `-chi(d,e)`. Therefore the Euler normalization in
(1.2) turns ordered HN multiplication into multiplication of the displayed
based-monomial series: the equality of exponents is

\[
 \chi(d+e,d+e)+2(i+j-\chi(d,e))
 =\chi(d,d)+2i+\chi(e,e)+2j+\eta(d,e).\tag{1.3}
\]

This verifies the convention rather than importing a sign convention
from a different Hall integration map.

## 2. One frame of arbitrary pairing kappa

Add one frame vertex `0`, `P` arrows from it to every A-color, and `Q`
arrows from every B-color to it. Restrict to frame dimension one, and
write `delta=e_0`, `z=X^delta`.

At the old central stability `theta_0=bA-aB`, refine the slope by

\[
 \mu_\pm(d)=\frac{-\theta_0(d)\pm\epsilon(PA(d)-QB(d))}
                   {A(d)+B(d)+d_0}.\tag{2.1}
\]

At every finite total-degree cutoff take `epsilon>0` small enough that
old unequal slopes keep their order. An unframed central dimension
`k(a,b)` has refined ratio `kappa/(a+b)`. A framed central dimension
`(l(a,b),1)` has ratio `l kappa/(l(a+b)+1)`, strictly smaller. Thus the
positive refinement puts the unframed central factor before the framed
factor; the negative refinement puts it after. There is at most one
framed factor in a product at frame degree one. Ordered HN factorization
gives

\[
 H\,T_{\rm after}=T_{\rm before}\,H.\tag{2.2}
\]

These are exactly the two generic chambers used for the Gale factors
`C_raw` and `B_raw`. A noncentral subset keeps the sign of its nonzero
integer `bA-aB`. A balanced unframed subset `r(a,b)` has pairing
`r kappa>0`, so the positive refinement forbids it, matching the
negative cut character of the core chamber. Subsets containing the frame
are handled by their unframed complements. This checks every forbidden
split, including those coming from repeated alphabet colors.

The Euler form of the framed quiver gives

\[
 \chi_{\rm ext}(d+\delta,d+\delta)
  =\chi(d,d)+1-PA(d)-QB(d),
\]
\[
 \eta_{\rm ext}(\delta,d)=PA(d)-QB(d)=k\kappa.
\]

The free common frame coordinate contributes `v/(1-v^2)` after Euler
normalization. Moving the frame monomial to the left supplies the extra
factor `v^(-PA+QB)`. After removing the common scalar, write
`T_before=z A_before`, `T_after=z A_after`, where their coefficient
Hilbert polynomials carry the factor `v^(chi(d,d)-2PA(d))`. Both `A`
series have constant coefficient one and Laurent-polynomial
coefficients in `v`.

Equation (1.2) gives the important commutation relation

\[
 U z=v^{-2\kappa}z U.\tag{2.3}
\]

Canceling the frame scalar and `z` in (2.2) now yields

\[
 A_{\rm before}(U;v)
 =A_{\rm after}(U;v)
   \frac{H(v^{-2\kappa}U;v)}{H(U;v)}.\tag{2.4}
\]

This is the general-framing formula. There is no additional division by
`kappa`: it enters as the shift of the ray variable.

## 3. The classical power

Use any positive determinant-one framing `pa-qb=1`, which exists by
Bezout, to define

\[
 F_1(U;v)=\frac{H(v^{-2}U;v)}{H(U;v)}.
\]

Its coefficients are Laurent polynomials: apply (2.4) with `kappa=1`
and invert the series `A_after`, whose constant coefficient is one.
Therefore the classical specialization

\[
 f(U)=F_1(U;v)|_{v=1}\tag{3.1}
\]

exists coefficientwise. For every positive integer `kappa`, the identity
of formal series

\[
 \frac{H(v^{-2\kappa}U;v)}{H(U;v)}
 =\prod_{j=0}^{\kappa-1}F_1(v^{-2j}U;v)\tag{3.2}
\]

is an exact telescoping product. Specializing `v=1` gives `f(U)^kappa`.
Thus the arbitrary framing produces a positive integer power of the
same determinant-one wall function. Formula (3.2) is an ordinary product;
no plethystic power and no unrecorded Adams sign is involved.

To identify `f`, consider a monomial of aggregate charge `w=(R,S)` and
put `K_w=m(aS-bR)`. Conjugation by `H` in the convention (1.2) acts as

\[
 X^w\longmapsto X^w\frac{H(v^{-2K_w}U;v)}{H(U;v)}.
\]

The same telescoping identity, or its inverse when `K_w<0`, gives the
classical action `X^w -> X^w f(U)^(K_w)`.
For an arrowless one-letter axis, direct coefficient comparison of

\[
 E_v(t)=\sum_{n\ge0}\frac{v^{n^2}t^n}
                         {\prod_{j=1}^n(1-v^{2j})}
\]

gives `E_v(v^(-2)t)=(1+v^(-1)t)E_v(t)`. Its two alphabet products therefore
specialize to the classical input operations

\[
 (x,y)\longmapsto(x,yP_\alpha(x)^m),\qquad
 (x,y)\longmapsto(xQ_\beta(y)^{-m},y),\tag{3.3}
\]

where `P_alpha(t)=prod_i(1+alpha_i t)` and similarly for `Q_beta`.
The all-A-then-all-B shuffle product has kernel one, hence is the full
polynomial Hall series. HN refactorization is its reversed-axis product
with the interior ray factors. Taking conjugations and the coefficientwise
classical limits identifies `f` with the corresponding formal two-input
ray factor in (3.3). Uniqueness follows degree by degree in the positive
cone; at the first unresolved degree its one ray correction enters
linearly.

All of this concerns the acyclic bipartite two-input quiver. It does not
identify the Hall algebra of an arbitrary cyclic quiver with the cluster
incoming completion.

## 4. Recovering every permutation trace, not one alternation

Fix a finite-alphabet dimension vector `d` with totals `ka,kb`, and let
`W_d=prod_i S_(d_i)` be its Young subgroup inside `G_k=S_(ka)xS_(kb)`.
Let `R` be the ring of particle invariants and `P_all` the full polynomial
ring in particles and the frame coordinate. Write

\[
 \Delta_d=\prod_i\prod_{r<s}(x_{i,s}-x_{i,r}),\qquad
 \zeta(d)=\sum_i\binom{d_i}{2}.
\]

Let `J` be the forbidden thin-cut ideal and `I` the corresponding colored
shuffle ideal. Alternating a multiple of a cut product first within its
two ordered packets gives the two packet Vandermondes. Alternating over
the remaining shuffles, then dividing by `Delta_d`, gives exactly the
colored shuffle kernel: its same-color denominator is the product of
cross-packet differences. Hence

\[
 J\cap P_{\rm all}^{\operatorname{sgn}W_d}=\Delta_d I,
 \qquad
 R/I\xrightarrow{\cdot\Delta_d}
      (P_{\rm all}/J)^{\operatorname{sgn}W_d}.\tag{4.1}
\]

The second map is an isomorphism. Every alternating polynomial is
Vandermonde times an invariant polynomial, and exactness of averaging
allows alternation after quotienting. Normalizing the alternating
projectors changes only nonzero rational scalar factors in their images.

All ordinary cut factors are differences, so subtracting the frame
coordinate and setting it to zero commutes with (4.1). The Hilbert degree
shift is `zeta(d)`. The thin and colored Euler numbers satisfy

\[
 \chi(d,d)-(ka+kb-mk^2ab)=2\zeta(d).\tag{4.2}
\]

Thus the Vandermonde shift exactly cancels the difference in Euler
normalizations. At `v=1`, the before and after coefficients are the
sign-isotypic dimensions of the actual thin Gale factors `B_raw,C_raw`.

For any `G_k`-module `E`, the coefficient of the alphabet monomial with
multiplicity vector `d` in `omega_A omega_B ch(E)` is
`dim Hom_(W_d)(sgn_(W_d),E)`. This follows directly by assigning an
alphabet letter to every permutation cycle in the Frobenius average.
Taking all finite alphabets, of sizes at least `ka,kb` when necessary,
recovers the full symmetric function and hence every cycle trace.
Therefore (2.4)--(3.2) imply the identity in the completed two-alphabet
symmetric-function ring

\[
 \mathcal B_{P,Q}(U)=\mathcal C_{P,Q}(U)
              \;\omega_A\omega_B\bigl(f(U)^\kappa\bigr),\tag{4.3}
\]

where `mathcal B=sum_k ch(B_raw(P,Q,k))U^k` and similarly for `C`.
This statement includes all Young subgroups and is stronger than equality
of the one sign multiplicity obtained from a one-letter alphabet.

## 5. The ordinary attached power theorem

### Theorem 5.1

For every admissible `P,Q` of determinant `kappa<=m` and every `k`,

\[
 \boxed{\quad
 \omega_A\omega_B\operatorname{ch}D_{\rm raw}(P,Q,k)
   =[U^k]f(U)^\kappa.
 \quad}\tag{5.1}
\]

In particular the attached character depends on `P,Q` only through
`kappa`. Equivalently the ordinary attached species of determinant
`kappa` has the character of the `kappa`-fold Cauchy product of the
ordinary determinant-one attached species.

**Proof.** The actual core/attached family already proved gives

\[
 \operatorname{ch}B_{P,Q,k}
 =\sum_{r+l=k}(\operatorname{ch}C_{P,Q,r})
              (\operatorname{ch}D_{P+mrb,Q+mra,l}).
\]

Induct on `k`, quantified over all positive framings with determinant
`kappa`. The shift preserves that determinant. When `r>0`, the attached
degree `l` is smaller and is replaced by the coefficient of
`omega_A omega_B(f^kappa)` by induction. Comparing with (4.3) leaves the
`r=0` term and proves (5.1). The algebra `D` remains the explicit
finite factor defined independently of this induction. QED.

## 6. The valued wall and its actual coefficient module

Return to `d_A,d_B`, `ell|m`, and
`kappa=gcd(d_A a,d_B b)`. Define the rational symmetric-function map

\[
 \rho_D(p_r(\alpha))=p_r(\alpha)/d_A,\qquad
 \rho_D(p_r(\beta))=p_r(\beta)/d_B\quad(r\ge1).\tag{6.1}
\]

Every power sum is divided by the same vertex weight, independently of
its degree. A permutation with `c_A,c_B` cycles consequently contributes
exactly the factor `d_A^(-c_A)d_B^(-c_B)`. The phase theorem therefore
says `ch D_val=rho_D(ch D_raw)`.

The map `rho_D` commutes with `omega_A omega_B`, because both are
diagonal on the power-sum basis. No commutation of `omega` with an Adams
operation is being asserted. Equations (5.1) and (6.1) give

\[
 \boxed{\quad
 \omega_A\omega_B\operatorname{ch}D_{\rm val}(P,Q,k)
   =[U^k]\,\rho_D(f(U))^\kappa.
 \quad}\tag{6.2}
\]

This is the full character formula for an actual finite algebra.

Why is it the valued two-input reordering? In classical Hamiltonian
notation with bracket `K(w,w')=m(RS'-SR')`, which is
`-eta(w,w')` in convention (1.2), the two raw incoming logarithms are

\[
 \sum_{r\ge1}\frac{(-1)^{r+1}p_r(\alpha)}{r^2}X^{re_A},
 \qquad
 \sum_{r\ge1}\frac{(-1)^{r+1}p_r(\beta)}{r^2}X^{re_B}.
\]

Applying `rho_D` divides them by `d_A,d_B`. Their actions become

\[
 (x,y)\longmapsto(x,yP_\alpha(x)^{m/d_A}),\qquad
 (x,y)\longmapsto(xQ_\beta(y)^{-m/d_B},y).\tag{6.3}
\]

The exponents are integers. Formal reordering commutes with this
coefficient-ring map, since every finite truncation is a nilpotent
algebra calculation and its factorization is unique. Its raw-normal ray
function is therefore `rho_D(f)`. Define

\[
 f_{\rm val}(U)=\rho_D(f(U))^\kappa.
\]

The corresponding ray action is explicitly

\[
 x^R y^S\longmapsto x^R y^S
 f_{\rm val}(x^a y^b)^{\,m(aS-bR)/\kappa}.\tag{6.4}
\]

It equals the previous action with exponent `m(aS-bR)` on `rho_D(f)`.
In a principal ambient lattice, this is the normal obtained by dividing
the weighted charge by `kappa`. Its restriction to the two charge
variables need not be a primitive functional on `Z^2`; equation (6.4)
states the normalization without that ambiguity.

Since `D_val` is an actual Young permutation module, (6.2) is a
nonnegative integer combination of elementary-symmetric monomials in the
two input alphabets. This positivity does not follow merely by applying
`rho_D` to a positive elementary expansion; the finite phase algebra is
what proves it.

For the first mixed coefficient `a=b=k=1`, the formula gives
`m*kappa/(d_A*d_B)=m/lcm(d_A,d_B)`, in agreement with the explicit
binary attached complete intersection. This is a normalization check,
not the definition of the coefficient algebra.

## 7. Ambient projection and the remaining global interface

For input charges `beta_A,beta_B` in the original lattice, the integer
`kappa` divides `d(S)` for `S=a beta_A+b beta_B`. The formal normal
`D S/kappa` equals `(d(S)/kappa)` times the primitive ambient normal.
Thus the ambient primitive wall function is `f_val^(d(S)/kappa)`.
This is a positive integer power; no fractional root is required.

The construction now supplies a true valued two-input wall coefficient
module, including every multiple of every primitive positive slope.
It combines the entire attached sector before taking phases, so it can
mix distinct flow-tree presentations. Applying it to a global
many-slope incoming completion still requires an explicit compatible
composition on the original labels. In particular one cannot replace
an existing center algebra by a new simple particle using only its
aggregate charge, and one cannot call a rearranged scattering algorithm
a pure-combinatorial interpretation of the requested graph algorithm
without proving that interface.

## 8. Reproducible full-character checks

The companion computation `gale_framing_power.py` computes generic cut
traces from feasible trees in the quotient by each vertex permutation.
For a generic invariant stability, averaging a feasible flow shows that
a fixed arrow support is feasible exactly when its quotient is feasible.
The Stanley--Reisner/Koszul trace formula then has, at `q=1`, the value

\[
 \frac{\sum_{T\text{ feasible quotient tree}}\prod_{e\in T}M_e}
      {\prod_{c\text{ nonroot vertex cycle}}|c|},\tag{8.1}
\]

where `M_e` is the total individual-arrow multiplicity between its
vertex cycles. In this acyclic graph no arrow can join vertices of the
same permutation orbit. The code solves every tree-flow sign condition
by exact leaf elimination, computes the core/attached induction with all
invariant label subsets, and compares every cycle type with the Cauchy
power of determinant-one data. It also changes the positive framing
without changing its determinant. Numerical output is kept separately
and is not substituted for the proof above.


The completed test ran **1,176** full cycle-type comparisons and **1,176**
independent framing-shift comparisons for total label counts up to six
and `m` up to six. All passed. The `m=1,a=b=1,k=2,P=2,Q=1` character
was `(6,4,4,2)` on `S_2 x S_2`, agreeing with a separate direct branch
calculation by `local_permutation_upgrade`. During code development the
terminal leaf of a tree was initially counted as an additional removed
edge; the nonzero small-character assertion detected this before any
passing result was reported. The leaf count was corrected and the whole
sweep rerun.
