"""Group singleton Schur words by their explicit rooted attachment tree.

For c_{(1,...,1)}(-e_0), the first leaf is 0. Every later singleton has
weight -sum_{earlier u} B[v,u]. Expanding this linear factor chooses one
earlier parent and one signed arrow color. Grouping all chronological
orders of the same rooted tree is a local-pre-Lie candidate for positivity.
This script determines whether tree fibers are already unsigned.
"""
from itertools import permutations,product
from collections import Counter
from pathlib import Path
import random,json,time,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from universal_word_probe import WordExpansion


def attachment_fibers(B):
    W=WordExpansion(B);n=len(B); fibers=Counter(); witness={}
    for tail in permutations(range(1,n)):
        seq=(0,)+tail;word=tuple((i,1) for i in seq);k=W.cword(word)
        if not k:continue
        choices=[tuple(u for u in seq[:j] if B[v][u]) for j,v in enumerate(seq) if j]
        if any(not a for a in choices):continue
        for parents in product(*choices):
            key=[-1]*n
            for v,u in zip(seq[1:],parents):key[v]=u
            key=tuple(key);fibers[key]+=k
            witness.setdefault(key,[]).append((seq,k))
    answer=[]
    for tree,h in fibers.items():
        if not h:continue
        raw=1
        for v,u in enumerate(tree):
            if v:raw*=-B[v][u]
        answer.append({'parent':tree,'order_sum':h,'arrow_product':raw,'term':h*raw,
                       'orders':witness[tree]})
    total=sum(a['term'] for a in answer)
    g=(-1,)+(0,)*(n-1);alpha=(1,)*n
    assert total==W.rec.c(alpha,g),(B,total,W.rec.c(alpha,g))
    return answer,total


def run():
    start=time.time();rng=random.Random(20261113);reports=[];first=[]
    for n in range(3,7):
        hist=Counter();negative=0;count=0;maxh=0
        for case in range(150):
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n): B[i][j]=rng.randint(-4,4);B[j][i]=-B[i][j]
            fibers,total=attachment_fibers(B)
            assert total>=0,(B,total)
            count+=len(fibers)
            for f in fibers:
                hist[f['order_sum']]+=1;maxh=max(maxh,abs(f['order_sum']))
                if f['term']<0:
                    negative+=1
                    if len(first)<8:first.append({'B':B,'total':total,'fiber':f})
        reports.append({'n':n,'matrices':150,'nonzero_fibers':count,'negative_fibers':negative,
                        'order_sum_histogram':dict(hist),'max_abs_order_sum':maxh})
    out={'seconds':time.time()-start,'reports':reports,'first_negative_fibers':first}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))


if __name__=='__main__':run()
