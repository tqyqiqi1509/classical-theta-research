# Independent adversarial audit of the species completion theorem

Date: 2026-11-13. Branch: species_adversarial_audit.

## 1. Verdict and exact scope

I read the complete completion draft and its local rank-two IC, equivariant PBW, intrinsic-partition, and polarization dependencies. The argument can be closed for every integral **skew-symmetric** exchange matrix, coefficient by coefficient, after the corrections below. No assumption of acyclicity of the original quiver, existence of a potential, or existence of a reddening sequence is used.

The resulting statement is an identity of actual finite symmetric-group characters. It identifies the graph/fan module defined independently from the coefficients with the weighted-cycle character. Its sign-isotypic dimension therefore equals the classical theta coefficient.

The decisive points are not the finite examples. They are (i) an equivariant local HN/PBW identity, with the correct arrow parity, (ii) universal substitution as an identity of symmetric sequences, and (iii) degree induction along the incoming half-line. I supply the details that remove the plausible gaps in these three steps.

The verdict does not extend the module construction to a nonconstant symmetrizer. It does not assert finite Laurent support for every formal theta label. It does not recover the user's missing pictured algorithm or construct a basis-preserving bijection with classical Dyck compatible pairs.

## 2. A genuine correction: Theorem D is not canonical

The initial temptation was to cite the ordered Hall-multiplication isomorphism of Davison--Meinhardt as canonical. This is inaccurate. In the proof of Theorem D, Section 6.4, the authors explicitly choose right inverses to restriction maps and compose them with BPS inclusions. The embeddings in Theorem D consequently contain a choice. This must not be hidden under an appeal to functoriality.

There is, however, a rigorous finite-group repair.

### 2.1 A stability generic at every slope

Let the local input charges beta_a lie in a pointed cone of a nondegenerate alternating plane K. Choose a rational linear functional ell strictly positive on that cone. For the target charge S define

    theta_a = -eta(S,beta_a),       kappa_a = ell(beta_a) > 0.

Use slope theta(u)/kappa(u). The real-linear map

    K -> R^2,       x -> (-eta(S,x), ell(x))

is injective: the first coordinate vanishes precisely on the line Q S, and ell(S)>0. Thus two positive free dimension vectors of equal slope have proportional images in K. Their alternating pairing vanishes. The free quiver Euler form is therefore symmetric on every slope lattice. This is the exact genericity hypothesis of Theorem D. All type-preserving automorphisms preserve this stability.

The slope-zero semistability condition is unchanged by the choice of positive denominator kappa. Hence the anti-attractor IC kernel used in the combinatorial construction is unchanged.

### 2.2 Averaging a section, not an isomorphism

Write r_mu for the natural restriction map from the full absolute Hall cohomology in a dimension component to its semistable locus. The proof of Theorem 4.12 supplies a graded right inverse s_mu with r_mu s_mu = id. For a finite stabilizer Gamma_mu, replace this by

    s_mu^Gamma = (1/|Gamma_mu|) sum_{h in Gamma_mu} h s_mu h^{-1}.

Then r_mu s_mu^Gamma = id exactly, because r_mu is equivariant. This operation is valid in every finite cohomological degree; the usual locally finite completion presents no difficulty. Choose such a section for one representative of each dimension-vector orbit and transport it along the group action.

Compose these equivariant sections with the **canonical absolute BPS inclusion** of Corollary 5.9. The Hall multiplication is equivariant, and the Euler-form symmetrizer is preserved by the group. The resulting ordered Hall-PBW morphism is equivariant.

I checked the proof of Theorem 6.12 after its displayed equation (104). Its argument uses the chosen sections only through their right-inverse property. The maps called delta_*, gamma_*, and beta_* are built from tensor products of these sections and the extension correspondences. The associated graded map for the HN filtration is an isomorphism; the proof then concludes that the full map is an isomorphism. No multiplicativity of the section is assumed. Consequently the same proof applies to the averaged sections.

This proves existence of an equivariant ordered Hall-PBW isomorphism. It does **not** assert that this isomorphism is canonical. The desired character identity needs existence, while the graph/fan module itself remains independently and canonically defined up to its stated auxiliary color order. At no point is an arbitrary vector-space isomorphism averaged in the hope of retaining invertibility.

The absolute formulation is especially convenient here because the local quiver is acyclic: the coarse moduli space of all representations of a fixed dimension is a point. It also avoids unnecessary choices from pushing a relative decomposition through another proper map.

### 2.3 Alternative character-only justification

For completeness, the proof of Theorem 4.12, equations (69)--(74), proves purity and vanishing of the connecting maps in the HN stratification triangles. The stratification and all extension-stack morphisms are equivariant. One can group HN strata into finite group orbits and use equivariant exact-sequence additivity to obtain the same character identity. This is another valid route, but the averaged-section argument above makes the dependence on the printed proof particularly explicit.

## 3. The local sign and why a full symmetric untwisting is unnecessary

For a thin local quiver on a label set C, let E_C be its number of arrows. The ordinary IC is even. The physical Hall generator IC tensor H(BC*)_vir has parity chi(C,C). Davison--Meinhardt's canonical symmetry has exponent

    tau(u,v) = chi(u,v) + chi(u,u) chi(v,v).

After including the Koszul symmetry of the physical Hall generators, the effective exchange exponent is chi(u,v).

For two disjoint blocks with the same input-type content, the arrows going from the first block to the second are in bijection, by their types, with the internal arrows of either block. The diagonal Euler term is zero because the blocks are disjoint. Thus

    chi(C,C') = -E_C.

A cycle of k such blocks has sign (-1)^((k-1)E_C). This is precisely the ordinary super-symmetry sign after declaring the local IC kernel to have parity E_C.

There is no extra sign representation on the permutation of the child labels of a **single** IC factor. The affine arrow representation has its complex orientation, and a complex-linear permutation preserves that orientation. A whole-component degree shift is given a trivial action on its shift line. Confusing this with a tensor product of odd leaf lines would incorrectly introduce an operadic suspension.

A full symmetric equivalence between the tau category and the ordinary super category after charge projection is not claimed. In fact it can fail when two distinct type-count vectors project onto the same ray. The character argument is narrower and sufficient:

1. A type-preserving permutation can carry one block to another only if their type counts agree.
2. In a fixed unordered set partition, each cycle of blocks therefore consists of blocks with equal type counts.
3. The exchange sign for that cycle is the arrow-parity sign just derived.
4. Crossings between different cycles can be removed by reordering tensor factors. The symmetry is symmetric on the common slope lattice, so this is conjugation of the action and does not change its trace.

An elementary verification of the last point is useful. For a symmetric parity pairing b on types, the sign assigned to a type-preserving permutation is a group character of the product of symmetric groups. A transposition of two occurrences of type a crosses every intervening other-type occurrence twice, and hence has sign (-1)^{b(a,a)}. Therefore the sign of an arbitrary permutation is the product over its monochromatic cycles of (-1)^{(k-1)b(a,a)}. This proves the cycle formula without an illicit global untwisting.

## 4. Explicit local HN and PBW character identities

Let sigma preserve the input types of a finite thin quiver J. Its normalized full-stack trace, before recording the common arrow parity, is

    A(J,sigma;t) = t^{|J|-E_J} / product_{c in cyc(sigma)} (1-t^{2|c|}).

This follows directly from the permutation action on the polynomial generators of H(B(C*)^J). The affine arrow coordinates contribute the displayed virtual weight shift and no determinant character.

Fix the generic stability of Section 2.1. The equivariant HN identity sums over ordered partitions of J whose blocks are individually sigma-invariant and have strictly decreasing slopes. Its summand is

    t^{sum_{a<b} eta(beta_{J_a},beta_{J_b})}
       product_a S(J_a,sigma|J_a;t),

where S is the semistable-stack trace at the corresponding slope. A nonfixed orbit of HN types has trace zero. The HN extension correspondences supply exactly the displayed quantum-torus exponent. The parity of each normalized summand is the total arrow parity E_J, so it can be removed on both sides of this scalar trace identity.

At slope zero the Euler form is symmetric. For every sigma-invariant unordered set partition P into zero-slope blocks, decompose its blocks into sigma-orbits. If an orbit has length k and representative C, its PBW contribution is

    (-1)^{(k-1)E_C} H(t^k) Omega(C,sigma^k|C;t^k),
    H(t)=t/(1-t^2).

The product over block orbits, summed over P, equals S(J,sigma;t). The one-block term is H(t) Omega(J,sigma;t). Thus this is a genuinely triangular primitive recursion; all other blocks contain fewer labels.

The local BPS/IC theorem identifies

    Omega(C,rho;t) = t^{-dim M_C} Tr(rho | IH_t(M_C)),
    dim M_C = E_C-|C|+1,

with separate parity E_C. The single-vertex kernel is one. A larger entirely parallel input has no stable full-support locus, hence zero primitive kernel. Mixed-slope inputs remain, even when some individual child charge is parallel to the total.

These identities establish equality in the representation ring for **every** tuple of finite type-label sets. They are stronger than a dimension identity and retain the nonprimitive parallel-block terms.

### 4.1 A symbolic check of the delicate parallel-block sign

For the double row/column swap of K_(2,2) with r arrows on each edge, the HN identity gives

    S_sigma(t) = (t^{4-4r}-t^{4+4r})/(1-t^4)^2.

There are two matching partitions, each contributing

    (-1)^r H(t^2) t^{-2(r-1)} (1+t^4+...+t^{4r-4}).

Therefore the primitive trace is

    Omega_sigma(t)
      = t^{3-4r}(1-t^2)(1-t^{4r})(1-(-1)^r t^{2r})^2/(1-t^4)^2.

Its value at t=1 is zero for even r and 2r for odd r, exactly the independently derived fan formula. This is an identity for all positive integers r, not a fit to r=1,2.

I independently reduced the fan expression and this Hall expression to rational functions in q=t^2, w=q^r, and s=(-1)^r. Wolfram returned zero for their difference modulo s^2-1. The raw receipt is stored with this audit. This check challenges the sign normalization; it is not the proof of the general local identity.

## 5. Why arbitrary super-species substitution is legitimate

The collection of local identities over every finite input-type label set is an equality in the completed tensor product of rational symmetric-function rings, with coefficients in weight-graded super representations. It is not merely an equality after evaluating alphabet sizes.

For each input type a, substitute a positive-degree homogeneous incoming species V_a for the free lambda generator p_1(X_a). Thus p_k(X_a) is sent to psi_k(V_a). Rationally the power sums freely specify this substitution. Concretely, it is composition of symmetric sequences: sum over partitions into input blocks, attach the local kernel on the block set, attach V_a to each block, and apply induction/coinvariants. This construction works for arbitrary representations, including odd representations, and does not choose a permutation basis.

The quantum product is

    z^beta * z^gamma = (epsilon t)^{eta(beta,gamma)} z^{beta+gamma},

where epsilon is the odd line and psi_k(epsilon)=(-1)^{k-1}epsilon^k. Since each V_a has the fixed displayed charge beta_a and eta is bilinear, substitution preserves this product. On a single ray the product is commutative, and substitution commutes with plethystic Exp and Log.

Only a class identity is being transported. There is no claim that charge projection transports the full tau-symmetric category to an ordinary super-symmetric category. The distinction in Section 3 is precisely what makes this step sound.

The positivity of the input degree guarantees finite composition at each prescribed original label content. No unknown theta coefficient, prior character multiplicity, or vector-space dimension is used in the definition of the substituted module.

## 6. Charge projection and the local primitive-production formula

Let phi send a free input-type basis vector to its displayed charge. The free alternating form is exactly phi^*eta, not merely an orbit-sum form. Therefore for every free charge gamma,

    phi^*(eta(phi(gamma),-)) = eta_free(gamma,-).

If restriction to the physical stability subspace made a free outgoing wall contain the physical incoming direction, the original wall would contain its free incoming direction by this identity. That contradicts its being outgoing. Hence projection preserves the incoming-only condition. This argument is valid for this strict pullback form; it is not a general theorem about arbitrary unfoldings of valued quivers.

After substitution, the primitive at a local joint with target S is therefore the preexisting incoming primitive V_S plus the sum over partitions with at least two proper blocks of

    K(partition) tensor product_C V_{beta_C}.

The extraction is plethystic Log of the **whole** ray factor. Thus repeated parallel blocks remain in Fock terms, and are not added a second time as new primitive blocks. Entirely parallel partitions have zero IC kernel. Mixed-slope partitions containing a proper block parallel to S are retained and handled by the same complete IC kernel.

Projection may turn the all-one free dimension vector into a divisible physical charge. This causes no problem: free thin IC is computed before projection, while plethystic primitive extraction is performed after projecting the whole ray factor. The positive-degree recursion is on the number of original labels, so every nontrivial child is strictly smaller regardless of divisibility.

## 7. The incoming-half-line induction closes

Fix a target S and a generic original-color covector theta with theta(S)=0. In a fixed finite degree follow

    q(t) = theta + t eta(S,-),       t>=0.

There are finitely many relevant walls and joints. The independent original-color parameters and the plane-projection lemma ensure that each nontrivial event has a nondegenerate two-dimensional charge span. Hyperplanes parallel to the full ray are not counted as isolated crossings.

At a joint q, the incoming value for a child beta is evaluated at q+delta eta(beta,-), where delta is later than all original-color infinitesimals. If a nonzero-bracket split beta=L+R lies in the current joint plane, its time at this incoming point is

    -(q(L)+delta eta(beta,L))/eta(beta,L) = -delta.

It is excluded. If the split lies outside the plane, its original-color leading form is nonzero and the sufficiently late delta does not change its sign. Precisely the strictly positive-time reduced child trees survive.

The local primitive-production formula therefore gives exactly one new root event decorated by its IC kernel, with the surviving reduced child trees below it. Its partition is recovered from its immediate children, so no binary-refinement multiplicity remains.

For a proper child beta parallel to S, eta(beta,-) is a positive multiple of eta(S,-). Its incoming evaluation is on the same side, and the same negative-delta calculation excludes feedback from primitives newly produced at that joint. Parallel splits have zero bracket. This deals with the potentially circular nonprimitive internal case.

Far enough in the incoming direction, every nonaxis primitive is zero by incoming normalization. Axis primitives are the given singleton inputs. Telescoping the finite joint differences and inducting on the number of labels yields exactly the direct sum of super tensor products of the local IC modules on the intrinsic reduced trees.

If eta(S,-)=0, every bracket whose total charge is S vanishes. There is no nonaxis primitive and no permitted root event. This is a base case, not an omitted genericity exception.

Thus the global class is the class of the independently constructed module W. This is the core global mechanism; scalar positivity is not used as a substitute for it.

## 8. Classical limit and the wall/transport sign dictionary

The sign dictionary must be explicit. Let E_beta=z^beta partial_beta, so

    [E_beta,E_gamma] = -eta(beta,gamma) E_{beta+gamma}.

The incoming integer-recursion paper uses the transport logarithm L. The tree paper and the current completion use the wall logarithm I=-L. For an ordinary cluster axis,

    I_i = sum_{k>=1} (-1)^{k-1} p_k(X_i) E_{k e_i}/k^2.

After the symmetric-function involution omega this is +sum p_k E_{k e_i}/k^2. On the quantum side,

    lim_{t->1} (t-t^{-1}) log Exp(H(t)p_1(X_i)z_i)
       = -sum_{k>=1} p_k(X_i) z_i^k/k^2.

The limiting quantum basis has bracket +eta, so identifying it with -E_beta sends this expression to omega I_i, as required. This is the wall input, not the transport input from the polarization note.

Forget epsilon only after all super Fock operations. The forgetful map is a ring homomorphism, although not a lambda-ring homomorphism. It therefore commutes with the finite algebraic scattering completion after that completion has been formed.

At total framing degree one, no higher multicover or product of parallel positive framed roots can contribute. The coefficient of the ray factor is H times its primitive. The one-frame identity identifies the classical coefficient with the coefficient of +E_alpha in the wall logarithm I; equivalently it is the coefficient of -E_alpha in the transport logarithm. The two signs in the framed action cancel exactly.

The resulting Frobenius characteristic is omega T from the independently proved incoming-log polarization. Consequently, for every same-color permutation sigma,

    Tr(sigma | W_(B,g,p)) = a^(B^lambda)_(g^lambda)(1,...,1).

The cycle-index theorem then gives

    a^B_g(p) = dim Hom_{product_i S_{p_i}}(sgn, W_(B,g,p)).

This conclusion uses the independent cycle-index identity but does not use the abstract positivity construction of its representation multiplicities. W itself is defined from the graph and its fans.

## 9. Independence and remaining limitations

Changing the original-color order can change the tree set. The above identification proves equality of the resulting characters, hence existence of an isomorphism of the finite rational representations. It does not provide a canonical tree-by-tree bijection. Same-color relabelings preserve a fixed-order tree set and define the actual action before any identification with theta.

The finite fan-module constructor supplies a combinatorial realization of every local IC factor. Its correctness is a separate audited dependency. The present proof identifies its output with theta; it does not replace that constructor by a precomputed character.

No 2026 theorem and no Li--Pan conclusion was used. The essential external inputs are the pre-2026 general incoming completion theorem, the acyclic local Hall/IC theorem, the canonical same-slope PBW theorem, and the ordinary theory of symmetric-sequence composition. The extension to nonconstant symmetrizers and an explicit Dyck-object bijection remain separate problems.

## Primary text checked in this audit

- Davison--Meinhardt, arXiv:1601.02479v5: Theorems B, C, D; Corollaries 4.11 and 5.9; Theorem 4.12 proof, especially (69)--(74); Theorem 6.12 and its proof. Theorem D's choice of sections was verified directly and corrected above.
- The previously audited Reineke small-resolution and local stability hypotheses were read in full in the local interface note.
- The incoming wall/transport conventions were checked directly against the one-frame and polarization proofs and the independent Lie-log implementation.

All corrections were communicated to the author of the completion draft while this audit was in progress.

## 10. Independent check of the positive orbit/Schur recursion

I also checked proofs/POSITIVE_ORBIT_SCHUR_RECURSION.md after the main completion argument. Its exponent is correct:

    e_C = number_of_leaves(C) + total_arrow_parity(C) mod 2.

Indeed the stabilizer of an unlabelled rooted colored tree is the product, over child isomorphism types C, of H_C wr S_m. The normal subgroup H_C^m acts trivially on the root's local fan module: internal relabeling fixes each child block and its displayed charge. Imposing its leaf-sign character therefore replaces U_C by the actual child multiplicity space Hom_HC(sgn,U_C).

A transposition of two copies of C exchanges ell_C matched leaf pairs and hence has leaf sign (-1)^ell_C. Its super tensor exchange has sign (-1)^q_C because q_C^2=q_C modulo two. Moving this known tensor sign to the desired isotypic condition leaves sgn^(ell_C+q_C) on the ordinary tensor power of the child multiplicity space.

The root local module decomposes into actual Specht multiplicity spaces. Schur--Weyl decomposition of the ordinary child tensor powers, self-duality of rational Specht modules, and tensoring Specht_lambda by sign then give the conjugate shape exactly when e_C=1. This is the stated nonnegative recursion. No additional wreath-product sign or factorial is missing.

The construction is a graph/fan linear-algebra and tableau model. Its local Specht multiplicities are actual intertwiner-space dimensions, so a fixed row-reduction basis followed by semistandard-tableau bases produces objects without using a theta coefficient. A character-average implementation for these *local* multiplicities is an equivalent computational shortcut, not a definition from the unknown final coefficient.
