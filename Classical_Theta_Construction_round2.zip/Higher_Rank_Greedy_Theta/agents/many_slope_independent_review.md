# Independent review and repair of the many-slope combinatorial bridge

Date: 2026-11-13. Reviewer branch: many_slope_independent_review.

## 1. Verdict

The many-slope extension is valid after one explicit normalization repair. It supplies the exact local identities (2.3)--(2.5) used in species_completion_bridge.md by finite supports, graph cut algebras, fan linear algebra, and labeled partitions. In particular, the local identification does not require Davison--Meinhardt PBW, a BPS inclusion, or Reineke's moduli-space IC identification.

The repair is substantive: the first bridge draft wrote a positive HN cross exponent without reversing the decreasing filtration order or changing its support normalization. Tang's source does reverse the order explicitly. For compatibility with the decreasing-order species convention, the correct conversion is
\[
 S_V(\sigma;t)=\operatorname{sgn}(\sigma)F_V(\sigma;t^{-1}).
 \tag{1.1}
\]
I derived the block-cycle conversion directly. No commutation between the sign involution and signed Adams operations is asserted.

I have corrected Section 4 of tang_ii_combinatorial_bridge.md and added its Section 4.1. This review preserves the issue and the reason the correction works. The existing geometric proof remains an independent route, but is no longer needed for the local combinatorial bridge.

This conclusion is about the stated graph/fan construction and its local-to-global interface. It does not assert an elementary Dyck-path description, a recovery of the user's unavailable figure, or a general valued phase module.

## 2. Definitions independent of theta coefficients

Let K be a rational two-dimensional vector space with nondegenerate integral alternating form eta. Let beta_v, v in V, be nonzero charges contained in a pointed cone. Define
\[
 a_{uv}=\max\{\eta(\beta_u,\beta_v),0\},\quad
 \Theta_v=-\eta(S,\beta_v),\quad S=\sum_v\beta_v.
\]
The incidence convention is partial(e_(u->v))=e_u-e_v. Let E_V denote the total number of arrows, counting multiplicities, and m_V=|V|.

The arrow directions admit an angular order, since the positive cone has angular width strictly smaller than a half-plane. Thus the thin directed graph is acyclic. If the charges are not all parallel, its undirected graph is connected: vertices on different rays are adjacent, and vertices on one ray connect through any other ray.

The flow polytope
\[
 P_V=\{f\geq0:\partial f=\Theta\}
\]
contains the all-one arrow flow. It is bounded because a recession vector would be a nonnegative circulation in an acyclic graph. In the nonparallel case its dimension is
\[
 d_V=E_V-m_V+1.
\]
Its normal fan is defined from incidence matrices and supports alone. Write R_V(sigma;q) for the character of its reduced global minimal-extension module.

Boundary conventions are part of the theorem:

- A singleton has R=1 and d=0.
- A set of at least two parallel charges has connected primitive R=0.
- Zero-supply vertices are retained as isolated components whenever a positive-flow support omits all their incident arrows.

The last point matters in the many-slope extension: it was absent in the source's strict source--sink setup. Omitting such isolated vertices would change the component permutation and the denominator in the determinant exact sequence.

A larger parallel set has a point flow polytope, but using the point's cohomology as its connected primitive is wrong. The complete Fock assembly of its singleton primitives already accounts for it.

## 3. Positive-flow cores and every normal cone

A support H is semistable if and only if Theta(U)<=0 for every successor-closed U. This is the elementary flow-feasibility criterion. For sufficiency, a Farkas separating potential can be written, after subtracting its minimum, as a nonnegative combination of upper-level-set indicators. Each such set is successor-closed, contradicting the proposed separator.

Take the union K of the positive supports of all feasible flows in H. Since the arrow set is finite, an average of finitely many witnessing flows is positive on exactly K. Components include isolated vertices. Summing the incidence equations on a component C gives Theta(C)=0. Nondegeneracy and pointedness imply
\[
 \beta_C=c_CS,\qquad c_C>0.
 \tag{3.1}
\]
There are two useful maximality consequences.

First, an unused arrow inside a connected component could be activated by a sufficiently small positive amount and corrected along an undirected path of already positive arrows. Second, a directed cycle in the quotient between components could be activated and corrected within the components in the same way. Both contradict maximality. Thus all internal arrows of H belong to K and the quotient support is acyclic.

Conversely, adding an acyclic quotient support to positive-flow supports on balanced components does not enlarge the core: any induced flow between the balanced components is a nonnegative circulation on an acyclic graph, hence zero.

For two balanced components,
\[
 A(C,D)-A(D,C)=\eta(\beta_C,\beta_D)=0.
 \tag{3.2}
\]
This is the exact reason complete bipartite structure is unnecessary. Contraction produces a doubled directed graph with equal opposite multiplicities, even when no opposite-arrow matching is preserved by the group action.

At the face with positive support K, the normal cone is generated by the classes of coordinates outside K. Relations are
\[
 \operatorname{im}\partial^T\cap\mathbb Q^{E_V\setminus K}.
\]
A vertex potential lies here precisely when it is constant on each component of K. Therefore unused internal arrows give independent orthant coordinates, while cross arrows give exactly the incidence quotient of the symmetric contracted graph. This is an equivariant product
\[
 \text{normal cone}=\text{symmetric graph cone}\times\text{smooth orthant}.
 \tag{3.3}
\]
The quotient normal representation is dual to
\[
 M_K=\ker(\partial:\mathbb Q^K\longrightarrow\mathbb Q^V).
\]
Its dimension is |K|-|V|+|\pi(K)|. This dimension count also checks (3.3), including isolated zero-supply vertices.

Nothing in these arguments uses a moduli interpretation.

## 4. Strong audit of the graph-cone input

The primary 2026 source is Qiyue Tang, Another proof of quantum Laurent positivity, II, Hexagon 2611.00279v1, manuscript dated November 10, posted November 11, 50 pages:

- Record: https://hexagonmath.org/2611.00279v1
- PDF: https://hexagonmath.org/pdf/2611.00279v1
- TeX: https://hexagonmath.org/api/v1/works/2611.00279v1/source?path=another_proof_quantum_positivity_combinatorial.tex

I inspected the complete proof chain in Sections 3--6. I also opened the older primary BBFK paper, arXiv:math/0002181v1, and read the relevant Remark 1.8, Section 5.1 construction, and Theorem 5.3 statement and proof structure. This audit is of the interfaces actually used; it is not a claim to have independently refereed every later section of Tang's paper.

### 4.1 Finite quotient and strict degree bound

For a connected loopless multigraph G with R edges and s vertices, the cographic independence complex consists of edge sets J whose complement remains connected. Its facets are the complements of spanning trees. A cycle-space basis restricts invertibly to every facet: arbitrary non-tree edge flows have a unique correction along the tree. The lexicographic basis-exchange argument in the source gives a shelling.

The shelling filtration has kernels of the form z_Ri Q[z_e:e in B_i], each free over the cycle-parameter ring. The ring is therefore free over that parameter ring, and the parameters form a regular sequence. Reducing yields the cut-product algebra
\[
 A_G=\operatorname{Sym}(\mathbb Q^V/\mathbb Q\mathbf1)/
 \bigl(\prod_{e\in\delta(U)}(x_{h(e)}-x_{t(e)})\bigr).
\]
Its degree is at most R-s+1. This argument is explicit and does not assume an equivariant generic stability parameter.

A generic supply on the doubled graph gives a simple flow polyhedron whose minimizing normal fan subdivides the graph cone. Its reduced piecewise-polynomial ring is A_G. The pure-sheaf direct-summand theorem puts the reduced local minimal-extension module inside this quotient. Hence its degrees are strictly less than
\[
 (2R-s+1)/2.
\]
The contraction description proves the same strict bound on every nonzero face and smooth orthant product.

### 4.2 Canonical action and duality

Uniqueness of normalized sheaf maps does require the strict bound, not merely the existence theorem for minimal extensions. A difference of maps agreeing on the boundary lands in the relative stalk. Source generators have degrees below half the cone dimension; relative generators have complementary degrees above half. Thus the difference is zero.

Tang's averaging argument for duality averages free-cover lifts satisfying a fixed restriction equation, not arbitrary isomorphisms. The complement can be chosen equivariantly on reduction, lifted, and corrected into the restriction kernel. These are exactly the allowed lift and complement operations in BBFK Section 5.1. BBFK Theorem 5.3 applies to the resulting product, giving a perfect pairing.

The equivariant cellular formula uses the orientation representation. For U the quotient normal space, its term is
\[
 (-1)^{\dim U}\det(\sigma|U)\det(1-q\sigma^{-1}|U)
 =\det(q-\sigma|U).
\]
The zero cone gives a single invariant generator in top relative degree. Consequently the evaluation map is equivariant. For a complete fan of dimension d,
\[
 R(\sigma;q)=q^dR(\sigma^{-1};q^{-1})
           =q^dR(\sigma;q^{-1}).
 \tag{4.1}
\]
The second equality holds because these are finite rational representations; a finite group invariant real inner product identifies each representation with its dual.

### 4.3 Independent opposite-arrow permutations

The independent-arrow extension is valid. Over an ordered-pair orbit of length ell with r parallel arrows and return-cycle lengths d_j, the total weight of nonempty invariant supports is
\[
 \prod_j\bigl(1+(q^{\ell d_j}-1)\bigr)-1=q^{\ell r}-1.
\]
Acyclicity depends only on whether the ordered-pair support is empty. The quotient calculation therefore forgets the return permutation legitimately. The actual return action remains in the determinant of the circulation space and in the local fan character.

The cut algebra and local graph-cone character satisfy the same contraction reciprocity. Induction on proper contracted cones and the strict degree bound force equality. The argument establishes a character identity. It does not supply cut-algebra restriction maps between cones.

### 4.4 Audit outcome

No substantive error was found in the graph-cone interface used here. The source's HN ordering is correct: it explicitly reverses the decreasing filtration before displaying a positive cross exponent. The error described next was an omission in the new bridge draft.

No Li--Pan statement is used. No recent symmetric-quiver or valued-shuffle theorem is imported.

## 5. Balanced-partition formula and its cycle sign

Let sigma preserve charge types, with any incidence-compatible arrow action. The positive-flow-core decomposition, the incidence exact sequence, and the graph-cone character theorem give
\[
 \sum_{\substack{\sigma H=H\\H\ {\rm ss}}}
 \frac{\det(q-\sigma|\mathbb Q^H)}
      {\det(q-\sigma|\mathbb Q^V)}
 =
 \sum_{\substack{\sigma\rho=\rho\\\rho\ {\rm balanced}}}
 \epsilon_\rho(\sigma)q^{R_{\rm cr}(\rho)}
 \prod_{C\in\rho/\sigma}
 \frac{R_C(\sigma^{\ell_C}|_C;q^{\ell_C})}
      {q^{\ell_C}-1}.
 \tag{5.1}
\]
All blocks, including singleton zero-supply blocks, are retained. The component exact sequence is
\[
 0\to M_K\to\mathbb Q^K\to\mathbb Q^V
       \to\mathbb Q^{\pi(K)}\to0.
\]
When regrouping cores inside a block orbit, the determinant identity is
\[
 \det(q-\sigma|\bigoplus_{j=0}^{\ell-1}\sigma^jM)
 =\det(q^\ell-\sigma^\ell|M).
\]
Thus the return map is required; replacing it by an identity or by powers of a fixed-block trace is invalid.

Here is a full check of the orientation character. Choose the order of blocks so that each sigma-orbit is contiguous. There are then no cross-orbit orientation reversals. Blocks within one orbit have identical type counts. Between two copies C,D of such a type multiset,
\[
 A(C,D)=\sum_{u,v\in C}\max\{\eta(\beta_u,\beta_v),0\}=E_C.
\]
The orientation character of the block cycle is therefore
\[
 (-1)^{(\ell-1)E_C}.
 \tag{5.2}
\]
This derivation remains valid if different type-count vectors happen to project to the same physical charge ray: a type-preserving permutation cannot exchange those different vectors.

The all-parallel boundary convention in Section 2 is necessary in (5.1). On a disconnected parallel block, the contracted graph remains disconnected for every support, so the connected graph-cut factor is zero. The singleton case is one.

## 6. The normalization error and its repair

The support normalization in the source and initial bridge is
\[
 F_V(\sigma;t)=\operatorname{sgn}(\sigma)t^{m_V-E_V}
 \sum_{\substack{\sigma H=H\\H\ {\rm ss}}}
 \frac{\det(t^2-\sigma|\mathbb Q^H)}
      {\det(t^2-\sigma|\mathbb Q^V)}.
 \tag{6.1}
\]

Take a decreasing HN filtration C_1,...,C_k, so every initial union is successor-closed. If C is earlier than D, arrows C->D must be absent; D->C arrows are unrestricted. The cross factor in (6.1) is
\[
 q^{A(D,C)}t^{-A(C,D)-A(D,C)}
 =t^{-\eta(\beta_C,\beta_D)}.
 \tag{6.2}
\]
A positive exponent is correct only after reversing the order. Tang's source says this explicitly in the proof of its support factorization, TeX lines 1486--1508. The new bridge's first Section 4 omitted the distinction.

The smallest diagnostic is one arrow between two vertices. At the identity,
\[
 F_{\rm all}=\frac{t^3}{(t^2-1)^2},\quad
 F_{\rm ss}=\frac{t}{t^2-1},\quad
 F_{\rm axis}=\frac{t}{t^2-1}.
\]
Then
\[
 F_{\rm all}=F_{\rm ss}+t^{-1}F_{\rm axis}^2.
\]
Using t in place of t^{-1} leaves the nonzero residual -t/(t^2-1). This is a sign error, not a minor wording issue.

Define S by (1.1). The unrestricted sum over supports is t^{2E_V}, and a permutation with c cycles has sign (-1)^{m_V-c}. Direct substitution gives
\[
 A_V(\sigma;t)
 :=\operatorname{sgn}(\sigma)F_{V,{\rm all}}(\sigma;t^{-1})
 =\frac{t^{m_V-E_V}}
 {\prod_{c\in\operatorname{cyc}(\sigma)}(1-t^{2|c|})}.
 \tag{6.3}
\]
Equation (6.2) becomes the positive exponent required in the decreasing-order species identity:
\[
 A_V(\sigma;t)
 =\sum_{\substack{V=C_1\sqcup\cdots\sqcup C_k\\
     \sigma C_i=C_i,\ \mu(C_1)>\cdots>\mu(C_k)}}
 t^{\sum_{i<j}\eta(\beta_{C_i},\beta_{C_j})}
 \prod_i S_{C_i}(\sigma|_{C_i};t).
 \tag{6.4}
\]
This is precisely species_completion_bridge.md equation (2.3).

The transformation is used at the level of explicit coefficient identities. Parameter inversion changes the quantum product; it is not silently treated as an automorphism of a fixed quantum torus.

## 7. All-slope centered stability

Choose a charge-linear kappa positive on the pointed cone. Let
\[
 \mu(C)=\Theta(C)/\kappa(\beta_C).
\]
The maximum-slope successor-closed subset exists and has a unique largest choice: unions of maximizers remain maximizers by additivity and the slope bound on their intersection. Repeating on the complement gives strictly decreasing slopes. The weighted-average argument establishes uniqueness, and hence every charge-preserving automorphism fixes every HN block individually.

For every block C,
\[
 \Theta_v-\mu(C)\kappa(\beta_v)
 =-\frac{\kappa(S)}{\kappa(\beta_C)}
       \eta(\beta_C,\beta_v).
 \tag{7.1}
\]
Indeed this is the rank-two identity
\[
 \eta(S,x)\kappa(c)-\eta(S,c)\kappa(x)
 =\kappa(S)\eta(c,x).
\]
The scaling factor is positive. Therefore the induced semistability condition is the intrinsic anti-attractor condition of the block. Every block in (6.4) is computed by the same family of flow supports and fans. Equal slopes are allowed only within one HN factor; they are handled by its full balanced-partition formula.

This closes the many-slope HN mechanism without an all-slopes moduli genericity hypothesis.

## 8. Explicit block-cycle conversion to the species PBW identity

Apply (1.1) to (5.1), not to a formal plethystic shorthand. The external vertex sign cancels the sign in F. Consider a balanced partition rho and a block orbit of length ell with representative C. Write m=|C|, E=E_C, d=E-m+1, h=sigma^ell|_C.

Total arrow count satisfies
\[
 E_V=\sum_{C\in\rho/\sigma}\ell_C E_C+2R_{\rm cr}(\rho).
\]
After t inversion, the cross powers cancel. The block's factor is
\[
 (-1)^{(\ell-1)E}
 t^{\ell(E-m)}
 \frac{R_C(h;t^{-2\ell})}{t^{-2\ell}-1}.
\]
By the equivariant reciprocity (4.1), this is
\[
 (-1)^{(\ell-1)E}
 \frac{t^{\ell(m-E)}R_C(h;t^{2\ell})}
      {1-t^{2\ell}}.
\]
Set
\[
 H(t)=\frac{t}{1-t^2},\qquad
 \Omega_C(h;t)=t^{-d}R_C(h;t^2).
\]
The factor becomes exactly
\[
 (-1)^{(\ell-1)E_C}
 H(t^\ell)\Omega_C(h;t^\ell).
 \tag{8.1}
\]
For a singleton, d=0. For a non-singleton parallel block, Omega=0.

Thus
\[
 S_V(\sigma;t)=
 \sum_{\substack{\sigma\rho=\rho\\\rho\ {\rm balanced}}}
 \prod_{C\in\rho/\sigma}
 (-1)^{(\ell_C-1)E_C}
 H(t^{\ell_C})\Omega_C(\sigma^{\ell_C}|_C;t^{\ell_C}).
 \tag{8.2}
\]
This is exactly species_completion_bridge.md equation (2.4), and the graph-defined Omega is its (2.5).

The one-block term is H(t)Omega_V. Every other block is strictly smaller. Therefore the primitive extraction is triangular and retains all parallel multiple-cover terms.

There is no extra sign representation on permutations within one local fan factor. Such a sign would already fail the local four-cycle check recorded below.

## 9. Restoring parity and substitution

Give the entire local factor parity E_C modulo two. Under a cycle of ell identical factors the super permutation contributes (-1)^{(ell-1)E_C}, exactly (8.1). At an ordered decomposition,
\[
 E_V-\sum_i E_{C_i}
 \equiv\sum_{i<j}\eta(\beta_{C_i},\beta_{C_j})\pmod2,
\]
so restoring the parity variable epsilon changes the HN multiplication into
\[
 z^\beta*z^\gamma=(\epsilon t)^{\eta(\beta,\gamma)}z^{\beta+\gamma}.
\]
This is the species note's exact product.

These identities hold for every finite set in every input type and every type-preserving permutation. They therefore hold in the rational representation ring of colored symmetric sequences. Substitution of any positive-degree homogeneous incoming species is legitimate. Odd input species need no separate quiver construction: their cyclic signs are the standard signs in symmetric-sequence composition.

This step uses the standard formalism of species composition. It does not infer an equivariant theorem from dimensions, and it does not construct representations by evaluating theta coefficients. Whole parallel rays must be assembled before plethystic primitive extraction.

Consequently Sections 3--6 of species_completion_bridge.md may use (6.4) and (8.2) in place of all local geometric HN/PBW and BPS/IC inputs. The global incoming-half-line induction, strict negative-delta exclusion, charge projection, one-frame extraction, and weighted-cycle identity remain separate proof steps already present in that note.

## 10. Focused independent computations

I did not rerun the previous 15 balanced-partition tests. I targeted the newly discovered normalization issue.

The program computations/many_slope_review_dictionary.py constructs S directly from finite supports. It independently assembles the decreasing HN sum and the block-cycle fan sum. The six inputs are:

1. One arrow, exposing the missing reversal.
2. Four distinct slopes.
3. A proper parallel pair exchanged by a permutation.
4. Two balanced mixed blocks exchanged by a permutation.
5. Three entirely parallel inputs under a three-cycle.
6. Four identical leaves permuted by a four-cycle inside one local star factor.

All six HN residuals and all six primitive-cycle residuals are exactly zero. The program never imports a theta routine. Its companion JSON contains the rational expressions, partitions counted, and residuals.

Wolfram was actually called through the calculation connector. The saved receipt in computations/many_slope_review_wolfram_receipt.json gives
\[
 \{0,\ -t/((t-1)(t+1)),\ 0,\ 0,\ 0\}.
\]
These are, respectively, the correct one-arrow HN residual, the incorrect-sign residual, the transformed HN residual, the general block-cycle exponent difference, and the general parity difference. The code is retained in many_slope_review_normalization.wls.

These computations verify the repaired normalization and its implementation. The general proof is Sections 3--9.

## 11. Novelty boundary and remaining interface

Tang II already supplies graph/fan local modules, the symmetric graph-cone character, a full two-slope primitive formula, Schur-positive reordering, and incoming propagation. The general incoming propagation principle should not be advertised as new here.

The extension proved here directly handles arbitrary finitely many charge slopes in one event plane. Its new explanatory mechanism is that every balanced contraction is symmetric because the component charges are parallel to the total. The centered-stability identity keeps every HN block in the same family. The zero-supply singleton and disconnected-parallel conventions are required for that generalization.

The global intrinsic reduced-tree grammar and its one-frame identification are additional constructions, not statements contained verbatim in the source. Likewise the later orbit/Specht/tableau recursion is an explicit implementation of standard induction and Schur--Weyl theory on that graph-defined module. Its value is a reproducible nonnegative coefficient construction; positivity of theta coefficients itself is established prior work.

One important limit survives this review. The graph-cone theorem identifies reduced characters with cut algebras. It does not identify all sheaf restriction maps with vertex-diagonal substitutions. In particular this theorem alone cannot create the phase-enriched valued gluing sought by the other branches. The many-slope theorem proved here is for integral skew pairings with ordinary finite input labels.

## 12. Review ledger

| Item | Result | Action |
|---|---|---|
| Positive-flow core for many slopes | Correct, including isolated zero-supply vertices | Used |
| Symmetric contracted graph and orthant factors | Correct by incidence relations and eta(beta_C,beta_D)=0 | Used |
| Tang II graph-cone character | Key proof chain independently checked against BBFK | Used |
| Bridge first HN positive exponent | Incomplete/wrong without reversal or normalization change | Repaired in bridge Section 4; counterexample preserved here |
| Source Tang HN exponent | Correct: source explicitly reverses blocks | No correction to source |
| Signed Adams to ordinary super species | Cannot be transferred by claiming involutions commute | Replaced by explicit cycle calculation |
| Multiple parallel block primitive | Must be zero for more than one vertex | Retained |
| Local geometric PBW dependency | Unnecessary after (6.4), (8.2) | Can be removed from the new combinatorial route |
| General valued cut-sheaf restriction | Not supplied by character equality | Not claimed |
| Prior global positivity/propagation | Existing work, including Tang II | Credited, not claimed new |


