# Primitive-center Gale algebras and the full local fan character

Date: 2026-11-13. Branch: `primitive_center_ih_bridge`.
Status: **closed after independent root and local-permutation review**
(13:49 UTC). The companion degree proof is
`proofs/GALE_DEGREE_AND_CYCLE_TORI.md`.
This note proves the missing **full-character** comparison for the
primitive-center construction. It uses the previously proved finite
support/HN/balanced-partition identities. It does not infer a group
representation from the dimension of a small resolution, and it does not
assume a group-invariant generic stability exists.

The local algebra is defined independently in
`proofs/PRIMITIVE_CENTER_GALE_FINITE_MODEL.md`. The finite-flat Gale degree
and fixed-scheme arguments are also developed independently by the
`local_permutation_upgrade` branch. No Li--Pan result is used.

## 1. Data and statement

Let Lambda be a rank-two lattice with a nondegenerate integral alternating
form eta. Let nonzero charges beta_v, v in V, lie in a pointed cone and
span Lambda_Q. Form the connected acyclic multiquiver

    a_uv = max(eta(beta_u,beta_v),0),
    partial(e_(u->v))=e_u-e_v,
    S=sum_v beta_v,
    Theta_v=-eta(S,beta_v)=outdeg_v-indeg_v.

Put P_V={x>=0:partial x=Theta}; it contains the all-one flow. Let L_V
be its reduced global minimal-extension fan module. In this note L_V
always means the **ungraded** module unless a variable is displayed.
Let G be the product of symmetric groups permuting equal charges, with
the standard incidence-compatible permutation of parallel arrows.

Write S=k alpha with alpha primitive in Lambda. Choose integral f with
f(alpha)=1, a quadratic refinement

    q(x+y)=q(x)+q(y)+eta(x,y) mod 2,

and a primitive k-th root zeta. Put

    tau_v=(-1)^(outdeg_v+q(beta_v)-f(beta_v)q(alpha)),
    Q_v=tau_v zeta^(-f(beta_v)).                           (1.1)

On the sum-zero vertex-coordinate space, remove every arrow diagonal and
define

    Gamma_v(u)=product_(e out of v)(u_s-u_t)
                    /product_(e into v)(u_s-u_t),
    Z_V={Gamma_v(u)=Q_v for all v, sum_v u_v=0}.           (1.2)

All scheme structures and all Artin multiplicities are retained.

**Theorem 1.1.** The scheme Z_V is finite and

    O(Z_V) is isomorphic to L_V as ungraded complex G-modules. (1.3)

Consequently L_V is a Young-permutation representation. A finite G-set
realizing it is obtained by the explicit coordinatewise Hermite
perturbation of the graph-defined square polynomial map in the companion
note. The finite set is constructed without an IH character, a theta
coefficient, or a prescribed number of points as input.

The proof below establishes equality at every permutation. Its crucial
calculation is a cycle-folding formula for the fan character, not a
generic-mirror character assertion.

The algebra in (1.2) is taken over the cyclotomic field Q(zeta), or after
a chosen embedding over C. Its length is its dimension over that field;
restriction of scalars to Q would introduce an unwanted field-degree
factor. The finite point set supplied by the Young deformation has its
own rational permutation representation. Equality after complexification
recovers the rational fan representation because symmetric-group Specht
modules are absolutely rational (equivalently by Noether--Deuring).

## 2. The exact local identities used

These are the finite combinatorial identities proved and independently
reviewed in `agents/many_slope_independent_review.md`.

For a label subset C, put E_C=#arrows in its induced quiver. Let

    H(t)=t/(1-t^2),
    Omega_C(sigma;t)=t^(-dim P_C) R_C(sigma;t^2),

where R_C is the graded fan character. A singleton has Omega=1; a
non-singleton all-parallel list has connected primitive Omega=0.

For any positive charge-linear mass, the HN identity uses decreasing
slopes and the positive cross twist. Its unrestricted trace is

    A_C(sigma;t)=t^(|C|-E_C)
                      /product_(cycles D of sigma)(1-t^(2|D|)). (2.1)

The semistable trace at the anti-attractor stability is denoted S_C.
For every charge-preserving permutation sigma,

    S_V(sigma;t)
      =sum_(balanced sigma-invariant partitions rho)
         product_(block orbits represented by C)
         (-1)^((d_C-1)E_C) H(t^d_C)
               Omega_C(sigma^d_C|C;t^d_C).                (2.2)

Here d_C is the block-orbit length, and balanced means Theta(C)=0.
The return permutation is part of the formula. Proper parallel blocks,
including isolated zero-supply singletons, are retained.

The support normalization is S_C(sigma;t)=sgn(sigma)F_C(sigma;t^-1).
This is essential: the unreversed support HN formula has the opposite
cross exponent. No incorrect omega/Adams commutation is used below.

## 3. A pure combinatorial generic-tree dimension lemma

Choose a sufficiently small rational generic perturbation

    Theta'=Theta+epsilon psi,  Theta'(V)=0,
    Theta'(C)!=0 for every nonempty proper C subset V.     (3.1)

Generic means only the displayed finite-subset condition; all signs of
nonzero Theta(C) are preserved. No invariance under G is required.

### Lemma 3.1 — refinement followed by ordinary logarithm

At the identity permutation,

    H(t) Omega_V(id;t)=S_V^(Theta')(id;t).                 (3.2)

**Proof.** Work in the squarefree label algebra
Q(t)[z_v:v in V]/(z_v^2:v in V). Consider the central series supported
only on Theta-balanced subsets. Refining its semistable supports by their
Theta'-HN filtrations gives the product of its refined slope factors.
Every block of such a filtration is Theta-balanced. Indeed, for small
epsilon the sign of a nonzero old slope dominates the perturbation;
the largest refined slope of an old semistable object cannot have old
positive slope and cannot have old negative slope. It therefore has old
slope zero. Its quotient is again old semistable, and induction proves
the assertion for all blocks. This is also the finite-support HN
refinement argument, so it needs no category of representations.

The charges of any two old balanced blocks are parallel to S. Their eta
pairing is zero, so every cross twist is one. The central HN product is
therefore an ordinary commutative product in this squarefree algebra.
Take its ordinary logarithm and extract z_V. A refined factor of slope
mu!=0 cannot contribute: a product of components of that same slope still
has slope mu, whereas Theta'(V)=0. Thus only the zero-slope refined factor
contributes. By (3.1), that factor contains no nonempty proper subset of
V; its logarithm has coefficient S_V^(Theta').

At the identity, (2.2) is the ordinary set-partition exponential of
H(t)Omega. Its logarithm has coefficient H(t)Omega_V. Equating the two
coefficient calculations proves (3.2). QED.

### Lemma 3.2 — residue counts stable spanning trees

Let T(Theta') be the spanning trees whose unique Theta'-flow is strictly
positive, counting each choice among parallel arrows separately. Then

    dim L_V = #T(Theta').                                 (3.3)

**Proof.** With n=|V| and E=E_V, the corrected identity-permutation
support trace is

    S_V^(Theta')(id;t)
       =sum_(Theta'-semistable supports K)
          t^(E+n-2|K|)(1-t^2)^(|K|-n).                   (3.4)

Every semistable support is connected, since a flow component with no
boundary would have total Theta' zero. Thus |K|>=n-1. The supports with
|K|=n-1 are exactly the stable spanning trees; genericity forces every
edge of their unique feasible flow to be positive. The residue of each
such term at t=1 is -1/2. All larger supports are regular there. Since
H has residue -1/2, (3.2) proves (3.3), with positive contribution one per
tree. QED.

### Corollary 3.3 — homogeneous total dimension

If every arrow multiplicity of the anti-attractor quiver is multiplied
by an integer r>0, then

    dim L_(r eta)=r^(n-1) dim L_eta.                      (3.5)

Choose the perturbation for the scaled graph to be r Theta'. The set of
stable underlying tree supports is unchanged, and each tree has exactly
r^(n-1) choices of parallel-arrow lifts. This proves (3.5) without any
graded deformation or equivariant small-resolution assertion.

Reineke arXiv:1511.08316, Theorem 4.3, independently agrees with this
dimension mechanism: the thin dimension vector is indivisible, the
all-arrow representation is stable, and the Euler form is symmetric on
ker Theta. We read the primary statement and proof. It is not needed in
the proof of (3.2)--(3.5).

## 4. Exact cycle folding of semistable traces

Fix sigma in G, with cycles C_1,...,C_c of lengths l_1,...,l_c. Let beta_i
be the common charge along C_i. Fold the cycles to a new labeled list

    beta'_i=l_i beta_i,  i=1,...,c.                       (4.1)

Write Fold for its anti-attractor fan module, and E for the original
arrow count. Its arrow count is also E, since arrows between cycles have
multiplicity l_i l_j max(eta(beta_i,beta_j),0), while a cycle has no
internal arrows. Define the symmetric quantum integer

    [l]_t=(t^l-t^(-l))/(t-t^(-1)).

### Lemma 4.1

    S_V(sigma;t)=S_Fold(id;t)/product_i [l_i]_t.           (4.2)

**Proof.** For the all-support traces, (2.1) gives exactly

    A_V(sigma;t)/A_Fold(id;t)
       =product_i t^(l_i-1)(1-t^2)/(1-t^(2l_i))
       =product_i [l_i]_t^(-1).

A sigma-fixed ordered HN partition consists of unions of whole cycles.
It is therefore the same data as an ordered HN partition of the folded
vertices. Slopes agree when masses are folded additively, and every cross
pairing agrees because of (4.1). Induction on proper blocks gives the
same product of quantum-integer factors in every HN term. Subtracting
those terms proves (4.2). QED.

The same statement holds on every union of cycles, not merely the whole
set. This uniformity is what permits an ordinary logarithm next.

## 5. A cycle cumulant isolates one orbit of primitive blocks

Let g=gcd(l_1,...,l_c). Put

    S_tilde_C(sigma;t)=(-1)^E_C S_C(sigma;t).

On disjoint balanced subsets arrow parity is additive, since every
cross-arrow total is twice an integer. Thus (2.2), after this twist,
becomes a product over block orbits, with an orbit of length d represented
by C contributing

    (-1)^E_C H(t^d) Omega_C(sigma^d|C;t^d).              (5.1)

Define the ordinary cycle cumulant

    K_V(sigma;t)
      =sum_pi (-1)^(|pi|-1)(|pi|-1)!
                 product_(B in pi) S_tilde_(union B)(sigma;t), (5.2)

where pi runs over partitions of the **set of cycles** of sigma whose
unions are balanced. Empty or unbalanced factors contribute zero.

### Lemma 5.1 — the two evaluations of the cumulant

The folding identity implies

    K_V(sigma;t)
       =(-1)^E H(t) Omega_Fold(id;t)/product_i[l_i]_t.     (5.3)

On the other hand,

    K_V(sigma;t)
      =sum_(d|g) d^(c-1) (-1)^(E/d^2)
                H(t^d) Omega_(V/d)(sigma/d;t^d).         (5.4)

Here V/d has one cycle of length l_i/d with charge beta_i for each
original cycle C_i, and sigma/d is its cycle permutation.

**Proof of (5.3).** Apply (4.2) to every factor in (5.2). The product of
the denominators is always product_i[l_i]_t. The remaining expression is
the identity-permutation set-partition cumulant of the folded data. By
(2.2), that cumulant is (-1)^E H Omega_Fold.

**Proof of (5.4).** Expand each semistable factor by (5.1). A fixed
primitive-block partition has, say, r orbits under sigma. The outer
cumulant sums over partitions of these r orbits. Its coefficient is

    sum_(partitions pi of {1,...,r})
                (-1)^(|pi|-1)(|pi|-1)! = [r=1].

Thus only primitive-block partitions on which sigma acts transitively
survive. If there are d blocks, every cycle length l_i is divisible by d.
Conversely, if d|g, assign to each sigma cycle one of d offsets modulo d.
Following sigma then determines its assignment to the d blocks. There
are d^c assignments, and simultaneous cyclic shift of the block labels
identifies exactly d of them. Hence there are d^(c-1) such partitions.

Each block contains l_i/d elements of C_i and therefore has total charge
S/d. It is balanced. The return permutation has cycle lengths l_i/d,
and the internal arrow count is E/d^2. The orbit factor is precisely
(5.1), proving (5.4). This also proves that the exponents in (5.4) are
integers. QED.

This argument includes every block return and every arrow-parity sign.
It is a direct partition calculation, not an assumption about the
commutation of plethystic operations with the sign involution.

## 6. The full fan-character formula

Let D_F=dim L_Fold and product_l=product_i l_i. At t=1, [l_i]_t=l_i and
H(t^d) has residue -1/(2d). Taking -2 times the residue in (5.3)--(5.4)
gives

    (-1)^E D_F/product_l
      =sum_(d|g) d^(c-2) (-1)^(E/d^2)
                              Tr(sigma/d;L_(V/d)).      (6.1)

Möbius inversion for the coefficient d^(c-2) gives

    Tr(sigma;L_V)
      =1/product_l * sum_(d|g) mu(d) d^(2c-2)
           (-1)^(E-E/d^2) dim L_(Fold/d).               (6.2)

The folded graph Fold/d has all arrow multiplicities divided by d^2.
To apply (3.5) entirely within integral graphs, take Fold/g as the base;
Fold/d is obtained from it by multiplying arrows by (g/d)^2. Thus

    dim L_(Fold/d)=D_F/d^(2(c-1)).                        (6.3)

Consequently

    Tr(sigma;L_V)=D_F/product_l * C(g,E),
    C(g,E)=sum_(d|g)mu(d)(-1)^(E-E/d^2).                (6.4)

All quantities in this expression are determined by the input charge
list and sigma. Its apparent fractions are lengths of fixed finite
schemes, as proved below.

### Lemma 6.1 — the cycle factor

Since E is divisible by g^2,

    C(g,E)=1,  if g=1;
           2,  if g=2 and E/4 is odd;
           0,  otherwise.                              (6.5)

For odd g all signs in (6.4) are one, and the sum of mu(d) vanishes
unless g=1. If 4|g the same is true for every squarefree divisor d that
can contribute. Finally write g=2h with h odd. Pair the divisors d and
2d to get

    (1-(-1)^(E/g^2)) sum_(d|h)mu(d).

This is two exactly in the second case of (6.5), and zero otherwise.

## 7. Non-equivariant Gale degree equals D_F

The companion primitive-center note proves that Gamma is finite and flat
over the irreducible open torus obtained by deleting all proper balanced
signed equations. Let its degree be d. The following argument identifies
d with dim L_V and applies just as well to every folded charge list.

Choose a generic one-parameter target curve q_v s^(psi_v) with sum psi=0.
Over the Laurent-series field it has d points counted with full Artin
length. Every arrow-difference valuation of these finitely many factors
is finite. Replace s by T^epsilon and every vertex coordinate u by T u.
Since Gamma_v is homogeneous of degree Theta_v, the target becomes

    q_v T^(Theta_v+epsilon psi_v).

Choose positive rational epsilon sufficiently small that the new stability
is generic and every resulting arrow valuation 1+epsilon nu_e is positive.
The generic cut-lattice Rees construction identifies the **full positive
arrow factor** of this system with a finite flat deformation of the
generic cut quotient. Here every factor is positive, so its rank is d.

For clarity, the needed cut-lattice construction starts from the saturated
graph-cut lattice im partial^T, takes its generic weighted lattice-ideal
degeneration, and imposes the cycle linear forms. The monomial initial
ideal is the outgoing-cut Stanley--Reisner ideal; its facets are stable
tree complements. Their unimodular complementary minors make the cycle
forms a regular parameter system. Completion at the positive-arrow origin
is finite free, and is a true idempotent factor after inverting T.
The constant units q_v twist the saturated lattice ideal and leave its
monomial initial ideal unchanged. The factor statement retains nilpotents.

Thus d is the generic stable-tree count. Lemma 3.2 proves

    deg Gamma=dim L_V.                                  (7.1)

This degree proof is non-equivariant and is used only as a degree proof.
The group character will be recovered by the exact fixed-scheme analysis
in the next section, not by choosing an invariant generic resolution.

## 8. The primitive-center fixed scheme

Continue with sigma, cycles l_i, g, and folded charges from Section 4.
On sigma-fixed vertex coordinates write x_i for their common value along
C_i. The original equations become the weighted map

    Psi_i(x)=product_(j:eta(beta_i,beta_j)>0)
                   (x_i-x_j)^(l_j eta(beta_i,beta_j))
              /product_(j:eta(beta_j,beta_i)>0)
                   (x_j-x_i)^(l_j eta(beta_j,beta_i)),
    sum_i l_i x_i=0.                                   (8.1)

An ordinary mean-zero gauge gives an isomorphic domain by translation.
The image lies in the connected torus

    T_l^0={z: product_i z_i^(l_i/g)=1}.                  (8.2)

The exponent vector in (8.2) is primitive. The relation itself follows
edge by edge, since every mixed exponent cancels after weighting by l_i/g.
The coordinatewise-power map

    pi:T_l^0 -> {z':product_i z'_i=1},  z'_i=z_i^l_i     (8.3)

is an isogeny of degree product_l/g. Indeed its kernel is the kernel of
the surjection product_i mu_(l_i)->mu_g given by
product_i z_i^(l_i/g). Its order is product_l/g. The ordinary folded
Gale map equals pi composed with Psi.

The raised target Q'_i=Q_i^l_i is in the folded nonresonant open torus.
For a proper balanced union of cycles, its product is exactly the
original signed boundary product times zeta^(-h), with 0<h<k. It
therefore avoids the forbidden signed equation. Finiteness of the folded
map, the finite isogeny (8.3), and smooth source/target imply that Psi is
finite flat over the preimage of this open set. That preimage is a
nonempty open subset of the connected torus T_l^0, hence irreducible.
Its degree is therefore constant and equal to

    g D_F/product_l.                                   (8.4)

If Q does not lie in T_l^0, the fixed scheme is empty. If it does, its
length is (8.4).

### The exact component condition

The common divisor g divides k, since S is a multiple of g in Lambda
and alpha is primitive. Put e=E/g^2. From (1.1) and the quadratic
refinement identity for S/g,

    product_i Q_i^(l_i/g)
       =(-1)^(E/g+E/g^2) zeta^(-k/g)
       =(-1)^((g+1)e) zeta^(-k/g).                     (8.5)

For odd g the sign is one, so (8.5) is one exactly when g=1. For even
g a primitive g-th root can equal the sign only when g=2; in that case
it is one exactly when e is odd. Thus

    length Z_V^sigma =D_F/product_l * C(g,E),             (8.6)

with precisely the same C(g,E) as in (6.5).

## 9. Trace equals the scheme-fixed length

It remains to justify using the length in (8.6) as the trace of sigma
on the original finite algebra. This is not automatic for an arbitrary
finite G-algebra, and is not an invariant-ring dimension assertion.

The graph-defined polynomial realization has the same coordinate
permutation representation in source and target:

    F_v(u)=D(u)(Gamma_v(u)/Q_v-mean(Gamma/Q))+mean(u).

The full factors with D invertible and mean(Gamma/Q)=1 are exactly Z_V.
The coordinatewise Hermite perturbation gives a finite flat selected
family with special fiber Z_V and reduced generic fiber. Isotypic
multiplicities in its full coordinate algebra are constant.

Restrict this square map and its perturbation to the sigma-fixed vector
space. The fixed source and fixed target have the same dimension.
The selected special fiber is exactly the scheme-fixed Z_V^sigma and
is zero dimensional. Locally its equations form a system of parameters
in a regular local ring; after adding the deformation parameter and
permuting the regular sequence, that parameter is a nonzerodivisor.
The selected restricted family is therefore finite flat as well.

On the reduced generic fiber, the fixed scheme consists of exactly the
fixed points, each of length one. Hence

    Tr(sigma;O(Z_V))
      =#(generic reduced points fixed by sigma)
      =length Z_V^sigma.                                (9.1)

Combining (6.4), (8.6), and (9.1) proves Theorem 1.1. Equality of all
finite-group characters over characteristic zero gives the asserted
module isomorphism. This concludes the full-character bridge.

## 10. Consequence and exact scope

The singular local fan module now has an independently defined finite
Young-permutation model. The construction is by a graph-defined finite
polynomial system and an effective generic perturbation. It does not
yet give lattice points in a single polytope or an elementary universal
Dyck-path rule. The coefficient-one untwisted mirror action remains an
invalid replacement: the signed primitive-center target is essential.

The theorem is ungraded. It does not assert that each cohomological
degree is a permutation representation. Nor does it assert a root-phase
normalization of each individual valued flow-tree summand. Those are
different statements and earlier counterexamples to them remain valid.

The uniform cycle formula can also accelerate exact character computation:
it replaces a general sigma trace by one folded identity dimension plus
the elementary test (6.5). The local fan modules, finite Gale sets, and
tableau models still have definitions independent of this fast evaluation.

## 11. Source and verification record

- The local support/HN/primitive input is the proved many-slope bridge,
  with its explicit normalization correction and independent review.
- Tang, Hexagon 2611.00238v1, Sections 4 and 6: the generic cut Rees
  full-factor and coordinate Young deformation arguments were inspected
  at proof level. They are reproduced in the companion branch; no
  concluding cluster positivity theorem is imported here.
- Reineke, arXiv:1511.08316v1, Theorems 4.3 and 5.1 and Corollary 4.4:
  primary statement and proof inspected as an independent check of the
  nearby generic dimension mechanism. It supplies no full G-action on a
  chosen resolution and is not used to assert one.
- No theorem about smooth toric cohomology is applied to singular IH.
- Root independently evaluated the cycle formula on 135 nonidentity
  conjugacy classes from eight structural charge families, including
  repeated two-, three-, and four-slope data and large arrow
  multiplicities. Every folded prediction agrees with the separate
  Laurent-jet character calculation. The source and results are in
  `computations/cycle_fold_character_check.py` and its JSON. These checks
  detect sign and divisor errors; the proof is Sections 3--9.
- The local-permutation branch independently checked Sections 3--6,
  including the squarefree HN refinement, the residue sign, the
  d^(c-1) cyclic-partition count, the d^(2c-2) Möbius factor, and the
  integral base graph used for homogeneity. Root independently reviewed
  the entire proof and found no remaining substantive gap.

- The actual Wolfram Language plugin checked the arithmetic simplification
  in (6.5) on all 8,192 pairs 1<=g<=128, 1<=E/g^2<=64 and returned no
  failures. Its exact code and raw output are saved in
  `computations/primitive_center_wolfram_receipt.json`. This is an
  independent arithmetic check; the prime-divisor proof is Lemma 6.1.

Primary URLs:

- https://arxiv.org/html/1511.08316v1
- https://hexagonmath.org/pdf/2611.00238v1
- https://hexagonmath.org/pdf/2611.00279v1
