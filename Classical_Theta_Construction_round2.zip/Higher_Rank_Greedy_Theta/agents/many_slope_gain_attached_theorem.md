# Uniform attached gain descent for arbitrary rank-two charge lists

**Stage:** 2026-11-13, 13:36 UTC. A general mechanism for a finite list of
charges in a pointed rank-two cone, allowing any number of distinct slopes.
This note proves the finite attached family and its full phase-character
descent. The local wall identification is proved separately in
`many_slope_gale_wall_identification.md`, independently of the
arbitrary-rank global incoming-completion problem.

## 1. Input and precise scheme

Let `beta_i` (`i in I`, `|I|=N`) be nonzero vectors in a rational
rank-two vector space, contained in a common pointed cone. Let `eta` be
an alternating form taking integral values on their lattice. The graph
has `|eta(beta_i,beta_j)|` arrows between `i,j`, oriented so that
`eta(beta_i,beta_j)>0` means `i -> j`.

Fix a nonzero rational linear functional `theta`, integral on all the
`beta_i`, with

\[
 \theta(S)=0,\qquad S=\sum_{i\in I}\beta_i.
\]

Let `r` be another rational linear functional, integral on the inputs,
with `r(S)>0`. Add a root `0`, with `r_i=r(beta_i)` arrows `0 -> i`
when `r_i>0`, and `-r_i` arrows `i -> 0` when `r_i<0`. Assume the
resulting rooted graph is acyclic. This holds, for example, when
`r(beta)=eta(f,beta)` and the frame charge `f` and all input charges lie
in one pointed cone. The root coordinate is fixed at `x_0=0`.

For every individual arrow `e:i -> j`, put

\[
 L_e=x_j-z_e x_i,\qquad z_e\ne0.
\]

Root arrows give nonzero scalar multiples of particle coordinates.
Let `A` be a Laurent polynomial ring over `C` in gain parameters and
unit target parameters `c_i`. A prescribed finite group `G` may permute
input vertices of identical type; take parameters constant on its arrow
and vertex orbits. Thus `G` acts on the particle coordinates and fixes
`A`. The parameter torus is connected and contains both the ordinary
all-gains-one point and any specified complete root-of-unity gain packets.

Define the vertex master functions

\[
 \Gamma_i(x)=\frac{\prod_{e:\operatorname{head}(e)=i}L_e}
                  {\prod_{e:\operatorname{tail}(e)=i}L_e}
 \quad(i\ne0).
\]

The generic Gale system is

\[
 \Gamma_i(x)=c_i T^{\theta_i},\qquad
 \theta_i=\theta(\beta_i).\tag{1.1}
\]

It is a square system of `N` equations in `N` particle variables, on the
open set where all particle coordinates and all arrow forms are nonzero.
Negative exponents are permitted; clearing the displayed denominators
and the powers of `T` gives polynomial equations.

Let `R=A[T,x_i^(+/-1):i in I]`. Let `J` be the contraction to `R` of
the ideal of (1.1) from `R[T^(-1),Lambda^(-1)]`, where
`Lambda=prod_e L_e`. Equivalently, saturate the cleared equation ideal
by `T Lambda`. This is the horizontal closure of the generic torus
system, while retaining invertible particle coordinates. Put

\[
 Z=\operatorname{Spec}(R/(J,T)),\qquad
 \widehat B=\varprojlim_n (R/J)/T^n.\tag{1.2}
\]

At a fixed parameter point, perform this construction independently and
write `D_lambda` for its special algebra. It is the attached factor:
all particle coordinates have nonzero limits. We do **not** assume that
saturation commutes with parameter specialization.

## 2. The balanced zero-component lemma

At any point of the special scheme `Z`, form the graph of arrows whose
linear forms vanish. Its connected components among nonroot vertices
are called zero components. Root arrows cannot vanish, since all
particle coordinates are invertible.

For any zero component `C`, all forms on its boundary are units at the
point. Multiplying the vertex equations for `C` cancels the internal
forms. The resulting cut relation belongs to the saturated ideal. At
`T=0`, a nonzero exponent `theta(C)` would set a boundary unit equal to
zero. Therefore

\[
 \theta(C)=0.\tag{2.1}
\]

The total charge `beta_C` is a positive multiple of `S`, since it lies
in the pointed cone and in the same one-dimensional kernel of `theta`.
Consequently

\[
 r(C)>0,\qquad \eta(\beta_C,\beta_D)=0
 \quad\text{for any two zero components }C,D.\tag{2.2}
\]

These conclusions use the actual zero-edge components. With different
vertex weights, grouping only by one common power of the coordinates
would be incorrect: different gain packets can distinguish such phases.

## 3. Uniform properness: every particle remains a unit

### Lemma 3.1

The affine morphism `Z -> Spec A` is proper, hence finite.

**Proof.** Consider a discrete valuation ring over the parameter torus
and a point of `Z` over its fraction field. All gains and target parameters
are units in this DVR. Work with the zero components over that fraction
field. Along a zero edge one coordinate is a unit gain multiple of the
other; hence all coordinates in an original zero component have the
same valuation.

Fix one valuation `nu`. Among original zero components of that valuation,
join any two connected by an arrow whose leading linear form vanishes.
Choose a connected component `C` of this enlarged graph. It is a union
of original balanced zero components, so (2.2) still holds.

For an outside original zero component `D`, every boundary arrow from
`C` to `D` has valuation exactly `min(nu,nu_D)`. If the valuations differ,
this follows because the gains are units. If they agree, cancellation of
the leading form would have joined `D` to `C`, contrary to its definition.
Thus the total signed contribution of the boundary arrows between `C`
and `D` to the valuation of its cut relation is

\[
 \min(\nu,\nu_D)\eta(\beta_D,\beta_C)=0.\tag{3.1}
\]

The internal forms cancel identically. Root arrows contribute
`nu r(C)`. The right side of the balanced cut relation is the unit
`prod_(i in C)c_i`, since `theta(C)=0`. Therefore

\[
 \nu r(C)=0.
\]

By (2.2), `r(C)>0`, so `nu=0`. This applies to every valuation group.
Every particle coordinate and its inverse is therefore integral in the
DVR. Substitution extends the point uniquely to `Z`; all polynomial
relations extend because they vanish over its fraction field. The
valuative criterion proves properness. The morphism is affine and of
finite type, so it is finite. QED.

The argument rules out both escape to infinity and convergence of an
attached coordinate to zero. It works with arbitrary unit gain parameters
and arbitrary unit target parameters, not just roots of unity. It does
not rely on all coordinates in a component having one common value.

## 4. Completion, the actual idempotent factor, and flatness

Finiteness of `Z` supplies finite `A`-module generators for the special
fiber. Lift them and reduce successively modulo powers of `T`.
Completeness shows that `Bhat` is finite over `A[[T]]`. Saturation makes
`T` regular, and Noetherian completion preserves this property. These
facts alone do **not** assert flatness over the many-parameter base.

Extend the uncompleted ring to `A[[T]]`. Its completion map to `Bhat`
is flat. The lifted finite generating set and its coefficients already
belong to the source, so this map is also surjective. A finitely
generated flat quotient has an idempotent kernel. Thus the completed
algebra is an actual direct factor of the scalar-extended algebra.

Acyclicity is used here to identify its generic equations correctly.
Choose an integral vertex potential strictly increasing on every arrow,
and subtract its root value. Multiplying the vertex master relations
with these potential exponents gives

\[
 \prod_e L_e^{h(\operatorname{head}e)-h(\operatorname{tail}e)}
 =c_h T^{\sum_i h_i\theta_i},\tag{4.1}
\]

where every arrow exponent is positive and `c_h` is a unit. This relation
belongs to `J`. After inverting `T`, it forces every arrow form to be a
unit. Therefore the generic ring is exactly the square Gale system
localized at its particle and arrow forms; no extra zero-arrow component
has been introduced by clearing denominators.

Put `S_A=A[[T]][T^(-1)]`. This is a connected regular Noetherian ring.
The algebra `Bhat[T^(-1)]` is a finite direct factor of

\[
 S_A[x_i^{\pm1},\Lambda^{-1}]/(F_1,\ldots,F_N),\tag{4.2}
\]

where `F_i` are the cleared vertex equations. At a local point over a
prime `p` of `S_A`, the ambient polynomial/Laurent local ring is regular
of dimension `N+dim(S_A)_p`. The `N` equations, followed by a regular
parameter system of `(S_A)_p`, form a full system of parameters because
the selected quotient is finite. They are a regular sequence. The base
parameters remain regular after the `F_i`, so the finite selected module
is free over the local base by miracle flatness. Hence

\[
 \widehat B[T^{-1}]\text{ is finite locally free over }S_A.\tag{4.3}
\]

Every `G`-isotypic summand is finite projective of constant rank on this
connected base. This, rather than torsion-freeness over `T`, is the
multivariable character-constancy argument.

## 5. Specializing parameters does not lose an Artin factor

For each parameter point `lambda`, the separately defined completion
in (1.2) is finite free over `C[[T]]` by Lemma 3.1 and `T`-regularity.
Its generic fiber consists exactly of the full finite Artin factors of
the generic Gale system in which every particle has valuation zero.

First take any algebraic residue point of the generic system whose
particle coordinates all have valuation zero. Its coordinates and their
inverses generate a finite integral algebra over a finite extension of
the valuation ring. Evaluation therefore extends to the finite completed
idempotent factor. The point is consequently isolated. This establishes
isolation before invoking an Artin local algebra.

To check the full-factor statement for the universal direct factor,
take the entire Artin local algebra at any such point over a finite
complete valued-field extension. Every particle multiplication operator is a unit-valuation
scalar plus a nilpotent; its inverse has the same property. These
operators are integral over the valuation ring and generate a finite,
complete algebra. All universal saturated relations vanish there: after
inverting `T`, the arrow forms are units, so cancellation used in the
saturation is legitimate. The map from `R/J` consequently extends
continuously to `Bhat`. This retains the entire local algebra, not only
its residue point.

Conversely, in a specialization of `Bhat` the particles and their inverses
satisfy monic equations over `C[[T]]`, since the module remains finite
over that ring (even if a special fiber before inverting `T` has torsion).
After inverting `T`, all of their residue valuations are therefore zero.
The universal idempotent factor selects exactly the attached sectors.
A zero-dimensionality concern is also resolved by this argument: any
algebraic point with unit particle valuations factors through the finite
idempotent algebra and is hence an isolated point of the generic system.

Thus its generic fiber agrees with the generic fiber of the separately
constructed `D_lambda`. Combining this full-factor identification with
(4.3) and the DVR flatness of each separate completion proves:

### Theorem 5.1 — all gains and unit parameters have the same attached character

For every parameter point of the invariant connected torus,
`Tr(g;D_lambda)` is independent of `lambda`, for every `g in G`.
In particular complete root-of-unity packets and the all-gains-one
system have identical ungraded `G`-characters.

There is no assertion that the universal `T=0` fiber is flat over `A`,
or that its direct parameter specialization equals `D_lambda`. Those
stronger statements are unnecessary and are not used.

## 6. Valued phase descent

Assign positive weights `d_i`, constant on input types, satisfying

\[
 d_i\mid r_i,\qquad
 \operatorname{lcm}(d_i,d_j)\mid|\eta(\beta_i,\beta_j)|.\tag{6.1}
\]

For each mixed pair use every `ell_ij`-th root gain equally often,
where `ell_ij=lcm(d_i,d_j)`. Its packet product is

\[
 (x_j^{\ell_{ij}}-x_i^{\ell_{ij}})^{m_{ij}/\ell_{ij}}.
\]

The root arrow products are scalar multiples of `x_i^(|r_i|)`;
choose any compatible nonzero scalar convention. Every vertex master
function is invariant under `A_phase=prod_i mu_(d_i)`. Put `u_i=x_i^(d_i)`.
The descended packet is explicitly

\[
 (u_j^{\ell_{ij}/d_j}-u_i^{\ell_{ij}/d_i})^{m_{ij}/\ell_{ij}}.\tag{6.2}
\]

The same saturated attached construction in the `u_i` defines a finite
algebra `D_val`. Laurent polynomials in the root variables are finite
free over the invariant Laurent polynomials, with bounded monomial basis
`W_d={prod_i x_i^(a_i):0<=a_i<d_i}`. Flat base change commutes with the
fixed-parameter contractions/saturations and completion, giving

\[
 D_{\rm gain}^{A_{\rm phase}}=D_{\rm val},\qquad
 D_{\rm gain}\cong D_{\rm val}\otimes W_d
 \quad\text{as }G\text{-modules}.\tag{6.3}
\]

It is an etale phase torsor on this attached sector, since every root
variable is invertible. A permutation cycle contributes `d_i` bounded
monomials. Therefore Theorem 5.1 gives the all-cycle identity

\[
 \boxed{\qquad
 \operatorname{Tr}(g;D_{\rm val})
 =\frac{\operatorname{Tr}(g;D_{\rm raw})}
        {\prod_{c\in\operatorname{cyc}(g)}d_c}.
 \qquad}\tag{6.4}
\]

This supplies a natural phase module for **any finite rank-two charge
list**, not just two distinct slopes. The phases act before resolving
its tree presentations; the construction is not a tensor product of
independently normalized local IH modules.

If `G` is the product of the symmetric groups of the input types,
`D_val` is a Young permutation module ungraded. Its generic attached
factor is a full finite factor of a square equivariant polynomial map,
after clearing denominators; the particle and arrow units isolate the
same local factor in that polynomial scheme. The Hermite-perturbation
argument of Section 7 of `valued_gale_attached_theorem.md` applies and
gives a finite tuple set with Young stabilizers.

## 7. What remains to identify and compose

The theorem above is a finite algebra and full-character theorem. For
ordinary differences, a general many-slope framed HN calculation should
identify the attached character with the appropriate central ray-factor
power, exactly as in `valued_gale_wall_identification.md`. Its core
subsets are all subsets with charge parallel to `S`; shifting the frame
by such a core preserves `r` on this ray. The unit-parameter constancy
proved above removes the extra constant signs arising in decoupling.
The full-word KLR/Rees construction must retain the original labels when
using this local object in a larger assembly.

Nothing here identifies a global arbitrary skew-symmetrizable cluster
incoming module with the Hall algebra of its possibly cyclic quiver.
The available interface is the local, acyclic rank-two charge list at a
joint. A complete global combinatorial identification needs its own
incoming-only composition proof.
