from incoming_recursion import IncomingRecursion,IncomingSchur,box
import random,json,time
from pathlib import Path
start=time.time();rng=random.Random(32561);entries=0;groups=[]
for B,D,cap in [([[0,2],[-3,0]],[3,2],(4,4)),
                ([[0,3,-3],[-3,0,3],[3,-3,0]],[1,1,1],(3,3,3)),
                ([[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],(3,3,3)),
                ([[0,1,0,0],[-1,0,0,0],[0,0,0,2],[0,0,-2,0]],[1,1,1,1],(2,2,2,2))]:
    R=IncomingRecursion(B,D);S=IncomingSchur(B,D);count=0
    for _ in range(4):
        m=tuple(rng.randrange(-3,4) for _ in D)
        for a in box(cap):
            x,y=R.c(a,m),S.c(a,m)
            assert x==y,(B,D,a,m,x,y)
            count+=1
    g=tuple(-int(i==0) for i in range(len(D)))
    assert R.theta_prefix(g,cap)==S.theta_prefix(g,cap)
    entries+=count
    groups.append({'B':B,'D':D,'cap':cap,'transport_entries':count,
                   'theta_prefix_equal':True})
out={'status':'PASS','transport_entries':entries,'groups':groups,'seconds':time.time()-start}
Path(__file__).with_name('incoming_schur_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k] for k in ['status','transport_entries','seconds']}))
