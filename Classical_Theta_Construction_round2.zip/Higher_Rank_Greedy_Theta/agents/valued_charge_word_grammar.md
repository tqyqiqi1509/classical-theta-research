# Finite valued charge-word grammar from actual two-input Gale objects

Stage: 2026-11-13, 14:14 UTC. This note supplies a deterministic local
rank-two operation for the global incoming event grammar. The construction
retains the charge of every birth, including its ambient divisibility.
Its local tables are finite algebras given by explicit integer equations;
the global combinatorial objects are finite decorated exchange histories.

## 1. Lattice, normal and pair conventions

Let `N=Z^n`, let `D=diag(D_i)` be a positive integral symmetrizer, and let
`K` be the integral alternating form associated with the classical
Hamiltonian convention. In the preceding Gale/Hall notes, `K=-eta`.
Assume that for every positive charge alpha,

\[
 d(\alpha)=\gcd_i D_i\alpha_i
 \quad\hbox{divides }K(\alpha,w)\quad(w\in N).\tag{1.1}
\]

This holds for `K=DB`, up to the fixed overall sign. Charges lie in a
pointed cone; choose an integral linear mass `h` strictly positive on it.
Every factor is a pair `(alpha,F)`, where alpha is its **carrier** and

\[
 F(t)=1+\sum_{j\ge1}A_j t^j.
\]

Its classical action is

\[
 \mathcal K_{\alpha,F}(X^w)
   =X^wF(X^\alpha)^{K(\alpha,w)/d(\alpha)}.\tag{1.2}
\]

A nonprimitive carrier is permitted. If alpha=q alpha_0, then
`d(alpha)=q d(alpha_0)`, and (1.2) has the same normal as the primitive
ray. Its series is still expressed in `X^alpha`. The carrier is not
replaced by alpha_0 during the grammar.

Orient the angular order so that `K(alpha,beta)>0` for an inverted pair
that must be exchanged. The target word order is the opposite order.
With this convention, the positive two-input identity is

\[
 \mathcal K_{\alpha,F}\mathcal K_{\beta,G}
 =\mathcal K_{\beta,G}
   \left(\prod_{(a,b)}^{\rm target\ order}
          \mathcal K_{a\alpha+b\beta,H_{a,b}}\right)
   \mathcal K_{\alpha,F},\tag{1.3}
\]

where a,b are positive coprime integers. Multiplication denotes the
composition convention of the checked two-input wall theorem. This is
the inverse of the negative-to-positive column path-product identity;
the positive generator (1.2) is the inverse of an actual crossing in
that path orientation. In
particular the associated ordinary quiver has arrows from beta to alpha,
so `eta(beta,alpha)=K(alpha,beta)>0`.

## 2. The exact ambient normalization at every birth

Put

\[
 m=K(\alpha,\beta)>0,\quad d=d(\alpha),\quad e=d(\beta),
 \quad\gamma=a\alpha+b\beta,
 \quad\kappa=d(\gamma).
\]

The following three divisibilities are elementary and are used in the
construction, rather than left as a normalization convention:

\[
 \operatorname{lcm}(d,e)\mid m,\qquad
 \gcd(ad,be)\mid\kappa,\qquad \kappa\mid m.\tag{2.1}
\]

The first follows from (1.1) and alternation. For the second, every
weighted coordinate `D_i gamma_i` is a sum of a multiple of ad and a
multiple of be. For the third, kappa divides
`K(gamma,alpha)=-bm` and `K(gamma,beta)=am`; coprimality of a,b gives
the conclusion. In particular `1<=kappa<=m`.

Choose positive integers P,Q satisfying

\[
 P\in d\mathbb Z,\quad Q\in e\mathbb Z,
 \qquad Pa-Qb=\kappa.\tag{2.2}
\]

They exist by the middle divisibility in (2.1). A particular solution can
be shifted by the positive homogeneous solution of the equation, so both
entries can be made positive. To make the grammar deterministic, choose
the solution minimizing `(P+Q,P)` lexicographically.

The actual valued two-input attached algebra for this framing represents
the ray function with the **primitive ambient normal** of gamma. Thus
(1.3) uses kappa itself, not the smaller free-lattice index
`gcd(ad,be)`. The preceding theorem already proves the kappa-th framing
power, and (2.1) verifies its original numerical bound. No extraction of
a fractional power occurs at a birth.

## 3. A finite local table defined by integer equations

Fix a,b,k and the data of Section2. Put `ell=lcm(d,e)` and use ka variables
`u_i` and kb variables `v_j`. Define

\[
 Q_{ij}(u_i,v_j)
  =(u_i^{\ell/d}-v_j^{\ell/e})^{m/\ell}.\tag{3.1}
\]

The polynomial equations are

\[
 u_i^{P/d}\prod_{j=1}^{kb}Q_{ij}=T^b,\qquad
 (-1)^Q v_j^{Q/e}\prod_{i=1}^{ka}Q_{ij}=T^a.\tag{3.2}
\]

Take their ideal, saturate by T, set T=0, and localize the product of all
u and v coordinates. The resulting finite algebra, with its full local
Artin multiplicities, is denoted `D_(a,b;k)`. It has the natural action
of `S_(ka) x S_(kb)` by particle permutations. Equations (3.1)--(3.2),
saturation, localization and polynomial reduction specify the complete
local computation.

The established attached theorem gives three properties:

1. The algebra is finite and its ungraded permutation character is
   independent of the admissible choice in (2.2).
2. It is an actual Young permutation module: its Frobenius characteristic
   has a unique expansion

\[
 \operatorname{ch}D_{(a,b;k)}
  =\sum_{\lambda\vdash ka,\ \mu\vdash kb}
       c^{a,b;k}_{\lambda,\mu}\,h_\lambda(X)h_\mu(Y),
 \qquad c^{a,b;k}_{\lambda,\mu}\in\mathbb Z_{\ge0}.\tag{3.3}
\]

3. After the sign involution omega, (3.3) is exactly the coefficient
   of degree k on the ray gamma in (1.3), with elementary symmetric
   functions as the input coefficients.

These statements are the complete-Frobenius conclusions of
`valued_gale_attached_theorem.md` and
`valued_gale_wall_identification.md`; the many-slope notes supply an
independent extension of the same local mechanism.

For an explicit implementation, choose a monomial basis of the finite
localized quotient by a fixed Groebner order. Reduce permuted basis
monomials to compute every cycle trace. Convert the resulting Frobenius
character to the h-basis. This uses a finite rational linear system; the
existence theorem proves that its outputs (3.3) are nonnegative integers.
Alternatively an equivariant finite perturbation realizes the orbit
classes themselves, each stabilizer being a product of coordinate-equality
Young subgroups. No input to this table is a previously computed theta
coefficient.

Let `C_(lambda,mu)` be a finite orbit-index set of cardinality
`c_(lambda,mu)`. One may use the canonical standard set
`{1,...,c_(lambda,mu)}` when only an explicit finite counting grammar is
needed. The proof of positivity comes from the actual finite algebra,
not from rounding or taking absolute values of an answer.

## 4. Substitution is a direct operation on finite sets

Suppose each coefficient A_j of F and B_j of G is represented by a finite
set `A_j` and `B_j`. Empty sets represent zero. For a partition lambda,
order its parts nonincreasingly and distinguish equal occurrences by
position. Define

\[
 \mathcal A_\lambda=\prod_{r=1}^{\ell(\lambda)}\mathcal A_{\lambda_r},
 \qquad
 \mathcal B_\mu=\prod_{r=1}^{\ell(\mu)}\mathcal B_{\mu_r}.
\]

The k-th output coefficient set is

\[
 \mathcal H_{\gamma,k}
  =\coprod_{\lambda\vdash ka,\ \mu\vdash kb}
       C^{a,b;k}_{\lambda,\mu}
       \times\mathcal A_\lambda\times\mathcal B_\mu.\tag{4.1}
\]

Taking cardinalities gives precisely the e-positive polynomial from
(3.3). All operations are finite disjoint unions and Cartesian products.
Formal coefficient variables can instead be retained as leaf colors;
then (4.1) is a multigraded finite set and counts each coefficient
monomial separately.

Both partitions are nonempty. Every output object therefore contains at
least one coefficient object from each of its two input factors. Its
total charge is

\[
 |\lambda|\alpha+|\mu|\beta
  =k(a\alpha+b\beta)=k\gamma.\tag{4.2}
\]

This is the strict ancestry property used by the global event grammar.
It holds even if some leading input coefficients vanish.

## 5. The deterministic finite word algorithm

Fix a mass cutoff N and discard all coefficient terms of mass greater
than N. Start with a finite ordered list of nontrivial input factors,
each given a distinct instance identifier. Carriers, identifiers and
coefficient sets are retained throughout.

Repeat the following rule until no strict inversion remains:

1. Choose the leftmost adjacent inverted pair of nonparallel carriers
   alpha,beta. Thus `K(alpha,beta)>0` in the convention of Section1.
2. Compute the factors `H_(a,b)` from (4.1) for all positive coprime a,b
   with `h(a alpha+b beta)<=N`, keeping only nonempty factors.
3. Replace the pair by beta, these new factors in target angular order,
   then alpha, as in (1.3). The two old identifiers are unchanged. Give
   each new factor a fresh identifier formed from the parent identifiers,
   the pair (a,b), and this crossing event.

Parallel adjacent factors are left as separate instances. They commute;
no exchange or new factor is associated with such a pair. At the end,
all instances on one physical ray are adjacent and their power series
can be multiplied by the ordinary disjoint-union/Cartesian-product
Cauchy rule. If their carriers have different positive multiples on that
ray, use the corresponding powers of the common ray variable only at
this final multiplication.

### Theorem 5.1: termination

The algorithm terminates after finitely many crossings at every cutoff.

**Proof.** Two fixed factor instances can cross at most once. A permitted
crossing puts their fixed carrier directions in the correct relative
order. Subsequent crossings with other factors leave this relative order
unchanged. They cannot cross again because they are no longer inverted.

Each new carrier satisfies

\[
 h(\gamma)=a h(\alpha)+b h(\beta)
         \ge h(\alpha)+h(\beta)
         >\max\{h(\alpha),h(\beta)\}.\tag{5.1}
\]

Induct on integer mass. Instances of minimum mass can only be initial
ones. Assume there are only finitely many instances of mass less than r.
Every mass-r birth comes from a pair of those instances. Each such pair
crosses at most once and creates only finitely many carriers below the
cutoff. Hence there are only finitely many mass-r instances. This proves
finiteness of all instances of mass at most N. Their pairs cross at most
once, so the number of crossings is finite. QED.

The use of unreduced carriers in (5.1) is essential. Dividing gamma by its
ambient gcd at birth can make its mass smaller than a parent's. The normal
was already normalized in Section2, so such carrier division is both
unnecessary and destructive to this proof.

### Theorem 5.2: evaluation and cutoff compatibility

The cardinality-valued series of the terminal word is the unique ordered
ray factorization of the original product modulo mass greater than N.

Every crossing preserves the truncated product by (1.3) and (4.1).
Termination gives an ordered product. Uniqueness can be proved directly
by taking the first degree where two ordered products differ. All lower
terms cancel; the remaining corrections lie on distinct positive rays
and in distinct monomial degrees, so each correction vanishes. If one
works with automorphisms and the alternating form has a global radical,
retain principal auxiliary variables or the normalized Hamiltonian
symbols before projecting; uniqueness is then checked in that faithful
extension. No equality of an arbitrary cyclic-quiver Hall diagram is
used here.

At a smaller cutoff, deleting the higher-mass factors from any completed
history gives a legal lower-cutoff history, after omitting silent steps.
A crossing with a higher-mass parent creates no lower-mass child by
(5.1). The projected history need not be the identical leftmost schedule,
but uniqueness gives the same lower coefficients. Thus the coefficient
counts are compatible with completion. A canonical bijection between
objects from different schedules is not asserted or needed: this grammar
uses the prescribed leftmost schedule at the chosen target cutoff.

## 6. Why inherited parallel inputs cause no division

An input factor on the target ray is an identifiable original instance.
It is retained during every crossing, like every other input. New factors
on that ray have different identifiers and a birth from two nonparallel
parents. The terminal ray function is the product of its old instances
and its newly born instances. Selecting the latter is a direct selection
of factor instances in the history, followed by multiplication of their
positive coefficient sets. It is not division of a Frobenius character
or subtraction of a local Artin sector.

This is a presentation-level mechanism. It does not claim that the new
factor product is the coordinate ring of the locus in one many-slope
Gale special fiber where all parallel particles lie in mixed components.
That plausible geometric locus fails in the valued case, as checked
below.

## 7. A failed route: isolated-parallel special components

The attempted intrinsic whole-factor extraction was to delete points
having an isolated particle parallel to the output ray. This is valid
in some ordinary situations with independent typed targets, but it is
not a general ramified operation.

The global-assembly agent found the following mechanism-level diagnostic,
which was independently verified here. Take ambient weights D=(2,3),
`eta=6 det`, A=(1,0), B=(0,1), R=A+B, with vertex weights (2,3,1) and
frame values (-2,3,1). The output primitive weight is d(R)=1. Put the
nonparallel AB component on its zero-arrow locus. The full gain packet
is `b^6-a^6`; the phase group mu2 x mu3 acts transitively on its six
relative phases, so choose a=b=c. Put x_R=t c and require that R be an
isolated zero-edge component.

The remaining ramified products are `(x_R^2-a^2)^3` and
`(b^3-x_R^3)^2`. Directly multiplying the vertex master functions gives

\[
 \Gamma_R
  =c\,\frac{t(t-1)(t+1)^3}{(t^2+t+1)^2},\qquad
 \Gamma_{AB}
  =c\,\frac{(t^2+t+1)^2}{(t-1)(t+1)^3}.
\]

Thus independently generic typed targets require

\[
 \frac{t(t-1)^2(t+1)^6}{(t^2+t+1)^4}
  =\frac{c_R}{c_Ac_B}.\tag{7.1}
\]

The left numerator has degree9 and the denominator degree8 and they are
coprime. For generic target ratio there are nine nonzero finite simple
solutions away from the forbidden collisions. The scale c is then
uniquely determined. There is no remaining common phase, since gcd(2,3)=1.

The inherited parallel factor has first coefficient1, and the valued
AB factor has first coefficient `6/(2*3)=1`. Their product therefore
has coefficient1, not9. Literal selection by an isolated parallel zero
component gives the wrong object even at the level of dimension. This
route is closed; it is not repaired by generic targets or by taking
phase invariants after that selection.

## 8. Scope of the result

The grammar is finite, positive, and normalized in the original ambient
lattice. It gives an explicit combinatorial object once the local finite
Gale tables have been computed. Those tables depend only on the integer
pairing, weights and coefficient content, through (3.1)--(3.2).

The separate global incoming event grammar must still specify which
local words occur, with their geometric signs and causal event order,
and identify its one-frame coefficient with the universal incoming
completion. This note supplies the local operation and strict ancestry
needed for that step. It does not manufacture the local coefficients
from a theta routine, and it does not identify the failed isolated-point
locus with a positive quotient.


## 9. Direct tight-grading factory for the same grammar

The local tables in Sections3--4 now have a literal path model, so the
counting definition need not run a Groebner or character calculation.
Use the independently audited conversion in
`agents/tight_grading_normal_audit.md`: set u=m/d, v=m/e,
l=gcd(av,bu), (p,q)=(av/l,bu/l), and
c=d(gamma)/gcd(ad,be). For the j-th base coefficient enumerate tight
gradings at enlarged degree jl on the deterministic Bezout Dyck path,
with vertical values divisible by v and horizontal values divisible by u.
Decorate a vertical value vr by an input A_r object and a horizontal
value us by a B_s object. The n-th output coefficient consists of ordered
c-tuples with total j_1+...+j_c=n.

This replacement uses only bounded integer edge gradings, cyclic subpath
counts, shadows, and finite tuple operations. Every later word operation
and the strict carrier-growth proof are unchanged. The Gale algebras
remain an independent representation-theoretic realization: their full
Young multiplicities equal these tight-grading profile counts. The local
path identity is existing Burcroff--Lee--Mou work; the original-normal
conversion and its integration into the new finite event grammar are
spelled out and independently checked in the audit.
