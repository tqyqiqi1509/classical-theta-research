# 经典theta Laurent展开与最小性 完整整合包

本包按2026年11月14日的收束要求，合并本轮早期原始材料、后期证明记录、最终报告和计算代码。
文件名：Classical_Theta_Laurent_Minimality_total.zip。

## 阅读顺序

1. final_report/01_final_report.md：最终数学结论及未解问题。
2. 01_RUNTIME_AND_RECOVERY.md：核查的运行窗口、中断与恢复情况。
3. final_report/02_research_history.md：后期完整证明、文献审核及成败路线。
4. earlier_materials/PROGRESS_ZH.md和logs/：早期原始研究与日志。
5. computations/index.json：后期35个计算单元的出处和上下文。

## 本次补齐

上一次203252字节的总包只含6个文件，未纳入早期130个原始文件。
本次把这130个文件与6个文件全部展开并入，两个原ZIP保留在archives/，原始内容不改动。
本轮原始提示单独保存，现存Page快照、恢复依据与版本差异放在recovery/。

| 位置 | 内容 |
|---|---|
| final_report/ | 原最终报告包全部6个文件，逐字节保留 |
| earlier_materials/ | 早期阶段包全部130个文件，逐字节保留 |
| computations/ | 后期35个代码单元及索引 |
| inputs/ | 本轮原始提示附件 |
| archives/ | 两个原ZIP和原下载页HTML |
| recovery/ | 来源、文件映射、时间证据、页面快照与diff |
| MANIFEST.json | 全包SHA-256与大小清单 |
| tools/verify_package.py | Python标准库校验脚本 |
| tools/extract_computations_exact.py | 重新提取后期代码的脚本 |

## 状态

原定研究窗口为北京时间2026-11-14 11:01:18至23:01:18，满12小时。
本次已收束。墙钟跨度不等于可精确核定的连续有效计算时长。

本次恢复没有重新审核数学结论。最终报告中的Laurent有限性、一星式和有限呈示等为稿内完整证明；
任意实际强正基的theta最小性及有限性证书完备性仍未证明。
历史材料保留了过时判断、失败诊断和后续修订，不应把中间陈述当作最终结论。
代码单元可能依赖计算插件或前序定义，提取不构成重新执行全部数学计算。

## 校验

解压后运行：python3 tools/verify_package.py

脚本检查MANIFEST.json中的全部文件，并将两个原ZIP的每个文件与展开目录逐字节比较。
两个原归档的SHA-256：

- early_progress_v5.zip：c21b665674ad9c528250400d34bef3a84515092fe0c69833909733040af0677c
- final_report_snapshot.zip：6563fecd4cfd9758c4e4df6ad9e457c35b8c5a3e9cdf6bb256d60dc10ad23e77

原报告README里指向早期包的外部链接保留原样；早期完整材料现在已同时在本包中。
