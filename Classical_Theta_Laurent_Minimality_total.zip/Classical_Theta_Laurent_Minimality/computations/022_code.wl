ClearAll[pn,af,z,y];
pn[bb_,cc_,kk_,uu_]:=pn[bb,cc,kk,uu]=Module[
 {den=Max[-uu,0],aa,ee,p,q,n,a,ep,rows,div,rem},
 If[uu>=0,Return[Expand[(1+z)^kk]]];
 aa=Max[bb den-kk,0];ee=ConstantArray[0,{den+1,aa+1}];ee[[1,1]]=1;
 Do[If[p+q>0,ee[[p+1,q+1]]=If[cc aa q>=bb den p,
 n=Max[aa-bb p,0];Sum[(-1)^(l-1)ee[[p+1,q-l+1]]Binomial[n+l-1,l],{l,1,q}],
 n=Max[den-cc q,0];Sum[(-1)^(l-1)ee[[p-l+1,q+1]]Binomial[n+l-1,l],{l,1,p}]]],
 {p,0,den},{q,0,aa}];
 rows=Table[ep=Sum[ee[[den-a+1,q+1]]z^q,{q,0,aa}];
 If[kk-bb a>=0,Expand[ep(1+z)^(kk-bb a)],
 div=(1+z)^(bb a-kk);rem=PolynomialRemainder[ep,div,z];
 If[rem=!=0,Throw[{"division failure",bb,cc,kk,uu,a,rem}]];
 PolynomialQuotient[ep,div,z]],{a,0,den}];
 Expand[Sum[rows[[a+1]]y^a,{a,0,den}]]];
af[bb_,cc_,k_,u_,r_,s_]:=Coefficient[
 Normal[Series[Coefficient[pn[bb,cc,k,u],y,s](1+z)^(bb s-k),{z,0,r}]],z,r];
checks=0;bad={};plateauBad={};
Do[vals=Table[af[bb,cc,k,u,r,s],{k,0,bb(-u)+r+2}];
 If[r==1,checks+=Length[vals]-2;
 If[Min[Differences[vals,2]]<0,AppendTo[bad,{bb,cc,u,r,s,vals}]]];
 Do[If[vals[[j+r]]==vals[[j]]&&vals[[j]]>0,
 AppendTo[plateauBad,{bb,cc,u,r,s,j-1,vals}]],{j,1,Length[vals]-r}],
 {bb,1,5},{cc,1,5},{u,-8,-1},{r,1,3},{s,1,Min[-u,5]}];
{checks,Length[bad],Length[plateauBad],Take[bad,UpTo[3]],Take[plateauBad,UpTo[3]]}
(* Actual output: {13500,0,0,{},{}}.
   Stronger alternating 3rd differences FAIL:
   vals=Table[af[1,2,k,-6,2,4],{k,0,10}];
   {vals,-Differences[vals,3]}
   -> {{90,48,19,3,1,0,0,0,0,0,0},{0,-1,13,0,1,0,0,0}} *)
