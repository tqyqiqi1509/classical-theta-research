ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=ff[bb,cc,gg1,gg2]=Module[{aa2=-gg2,aa1,ppmax,qqmax,ee,pp,qq,kk},
aa1=bb Max[aa2,0]-gg1;ppmax=Max[aa2,0];qqmax=Max[aa1,0];ee=ConstantArray[0,{ppmax+1,qqmax+1}];ee[[1,1]]=1;
Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]] nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]] nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],{pp,0,ppmax},{qq,0,qqmax}];
Expand[Sum[ee[[pp+1,qq+1]] z1^qq z2^(ppmax-pp),{pp,0,ppmax},{qq,0,qqmax}]]];
SeedRandom[202611140941];
testCases=Table[With[{bb=RandomInteger[{1,5}],gg=RandomInteger[{-6,3},2],pp=RandomInteger[{0,3},2],aa=RandomInteger[{0,4}],rr=RandomInteger[{1,6}]},{bb,gg,pp,aa,rr}],{512}];
checks=0;nonzero=0;terms=0;maxCoefficient=0;failures={};lowFrozenHeads=0;
Do[Module[{bb=ca[[1]],g=ca[[2]],p=ca[[3]],a0=ca[[4]],r=ca[[5]],f,poly,rem,box,base,coef,h,q,bad=False},
f=ff[bb,bb,g[[1]],g[[2]]];
poly=Expand[Total[(Last[#] nn[a0+p.First[#],r] z1^First[#][[1]] z2^First[#][[2]])&/@CoefficientRules[f,{z1,z2}]]];
checks++;
If[poly=!=0,nonzero++;rem=poly;base=g+r p;box=SortBy[Tuples[{Range[0,Exponent[poly,z1]],Range[0,Exponent[poly,z2]]}],{Total,First}];
Do[coef=Coefficient[Coefficient[rem,z1,q[[1]]],z2,q[[2]]];
If[coef<0,AppendTo[failures,{"negative",ca,q,coef}];bad=True;Break[]];
If[coef>0,terms++;maxCoefficient=Max[maxCoefficient,coef];
If[a0+p.q-r<0,lowFrozenHeads++;AppendTo[failures,{"negativeFrozenHead",ca,q,a0+p.q-r}]];
h=base+{-bb q[[2]],bb q[[1]]};rem=Expand[rem-coef z1^q[[1]]z2^q[[2]]ff[bb,bb,h[[1]],h[[2]]]]],{q,box}];
If[!bad&&rem=!=0,AppendTo[failures,{"residual",ca,rem}]]]],{ca,testCases}];
<|"cases"->checks,"nonzero"->nonzero,"positiveThetaTerms"->terms,"maxCoefficient"->maxCoefficient,"negativeFrozenHeads"->lowFrozenHeads,"failures"->Length[failures],"firstFailure"->Take[failures,UpTo[1]]|>
