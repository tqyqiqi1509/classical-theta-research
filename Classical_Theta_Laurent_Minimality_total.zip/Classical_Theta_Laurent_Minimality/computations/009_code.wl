ClearAll[pn, zz, yy];
SeedRandom[2026111402];
pn[bb_, cc_, kk_, uu_] := pn[bb, cc, kk, uu] =
 Module[{den = Max[-uu, 0], aa, ee, p, q, n, a, ep, rows, div, rem},
  If[uu >= 0, Return[Expand[(1 + zz)^kk]]];
  aa = Max[bb den - kk, 0];
  ee = ConstantArray[0, {den + 1, aa + 1}];
  ee[[1, 1]] = 1;
  Do[
   If[p + q > 0,
    ee[[p + 1, q + 1]] =
     If[cc aa q >= bb den p,
      n = Max[aa - bb p, 0];
      Sum[(-1)^(l - 1) ee[[p + 1, q - l + 1]]
        Binomial[n + l - 1, l], {l, 1, q}],
      n = Max[den - cc q, 0];
      Sum[(-1)^(l - 1) ee[[p - l + 1, q + 1]]
        Binomial[n + l - 1, l], {l, 1, p}]
     ]
   ], {p, 0, den}, {q, 0, aa}];
  rows = Table[
    ep = Sum[ee[[den - a + 1, q + 1]] zz^q, {q, 0, aa}];
    If[kk - bb a >= 0,
     Expand[ep (1 + zz)^(kk - bb a)],
     div = (1 + zz)^(bb a - kk);
     rem = PolynomialRemainder[ep, div, zz];
     If[rem =!= 0,
      Throw[{"division failure", bb, cc, kk, uu, a, rem}]];
     PolynomialQuotient[ep, div, zz]
    ], {a, 0, den}];
  Expand[Sum[rows[[a + 1]] yy^a, {a, 0, den}]]
 ];

nonnegCore[f_, cc_, uu_, kk_] :=
 And @@ Table[
   Module[{row = Coefficient[Expand[f], zz, l],
     div = (1 + yy)^Max[-uu - cc l, 0], r, q},
    r = PolynomialRemainder[row, div, yy];
    q = PolynomialQuotient[row, div, yy];
    r === 0 && And @@ (# >= 0 & /@ CoefficientList[q, yy])
   ], {l, 0, kk}];

cases = Table[
   {RandomInteger[{1, 5}], RandomInteger[{1, 5}],
    RandomInteger[{1, 9}], RandomInteger[{0, 36}]}, {160}];
results = Catch[
   Table[
    Module[{bb = ca[[1]], cc = ca[[2]], uu = -ca[[3]],
      kk = ca[[4]], f, up, lo, checks},
     f = pn[bb, cc, kk, uu];
     up = Expand[(1 + zz)^kk (1 + yy)^(-uu) - f];
     lo = If[kk == 0, 0,
       Expand[f - pn[bb, cc, kk - 1, uu]
         - zz pn[bb, cc, kk - 1, uu + cc]]];
     checks = {
       Exponent[f, zz] <= kk,
       Coefficient[f, zz, 0] == (1 + yy)^(-uu) // Expand,
       Coefficient[f, zz, kk] ==
        Expand[(1 + yy)^Max[-uu - cc kk, 0]],
       nonnegCore[f, cc, uu, kk],
       nonnegCore[up, cc, uu, kk],
       nonnegCore[lo, cc, uu, kk]};
     checks[[2]] =
      Expand[Coefficient[f, zz, 0] - (1 + yy)^(-uu)] === 0;
     {ca, And @@ checks, checks}
    ], {ca, cases}]];
If[Length[results] == Length[cases],
 <|"cases" -> Length[cases],
   "wildCases" -> Count[cases, {b_, c_, _, _} /; b c > 4],
   "sourceDegreeRange" -> MinMax[cases[[All, 4]]],
   "allPass" -> And @@ results[[All, 2]],
   "failures" -> Select[results, Not[#[[2]]] &],
   "checks" -> {"binomial divisibility in original chart",
     "degree <= k", "both core endpoints",
     "core coefficient positivity", "core binomial upper bound",
     "core Pascal lower recurrence"}|>, results]
