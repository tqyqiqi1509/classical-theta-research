ClearAll[z,h,s,p,d,j,x1,x2,y1,y2];
s[0]=1;s[1]=z;Do[s[n]=Expand[z s[n-1]-h s[n-2]],{n,2,42}];
p[n_Integer]:=Expand[s[n]-If[n>=4,h^2 s[n-4],0]];
d[n_Integer]:=Expand[p[n]-If[n>=2,h p[n-2],0]];
j[0]=2p[2]+2h;j[1]=p[3]+2h p[1];j[2]=p[4]+h p[2]+h^2;
j[n_Integer]/;n>=3:=p[n+2]+h p[n];
productChecks=Table[Expand[p[m]p[n]-p[m+n]-h p[m+n-2]-h^(n-1)j[m-n]],
 {n,3,18},{m,n,20}];
boundaryChecks={Expand[p[1]^2-p[2]-h],Expand[p[1]p[2]-p[3]-h p[1]],
 Expand[p[1]p[3]-p[4]-h p[2]-h^2],Expand[p[2]^2-p[4]-h p[2]-2h^2],
 Expand[p[2]p[3]-p[5]-h p[3]-2h^2 p[1]],
 Expand[p[2]p[4]-p[6]-h p[4]-h^2 p[2]-h^3]};
bandChecks=Table[Expand[s[n]-Sum[h^(2k)p[n-4k],{k,0,Floor[n/4]}]],{n,0,32}];
principalZ=x1/x2+y2/(x1 x2)+y1 y2 x2/x1;
negativeLaurentCoefficient=Coefficient[Coefficient[
 Expand[(d[4]/.{z->principalZ,h->y1 y2})x1^4 x2^4],x1,4],x2,4];
{Union[Flatten[productChecks]],Union[boundaryChecks],Union[bandChecks],
 d[4],negativeLaurentCoefficient}
(* Actual output {{0},{0},{0},h^2-4h z^2+z^4,-y1^2 y2^2}. *)
