ClearAll[z1,z2,z3,t,jet,mon,getcoef];
vars={z1,z2,z3};
bmat={{0,2,-1},{-2,0,3},{1,-3,0}};
roots={{1,0,0},{0,1,0},{1,0,1},{0,0,1}};
maxdeg=5;
jet[expr_]:=Expand[Normal[Series[expr/.Thread[vars->t vars],{t,0,maxdeg}]]/.t->1];
mon[v_]:=Times@@(vars^v);
f=ConstantArray[1,3];h=ConstantArray[1,3];
Do[u=1+mon[v];s=Thread[vars->vars u^(bmat.v)];
 f=Table[jet[u^v[[i]](f[[i]]/.s)],{i,3}],{v,roots}];
Do[u=1+mon[v];s=Thread[vars->vars u^(-bmat.v)];
 h=Table[jet[u^v[[i]](h[[i]]/.s)],{i,3}],{v,Reverse[roots]}];
alist=Select[Tuples[Range[0,maxdeg],3],Total[#]<=maxdeg&];
getcoef[expr_,a_]:=Fold[Coefficient[#1,vars[[#2]],a[[#2]]]&,expr,Range[3]];
fails={};
Do[power=UnitVector[3,i]+bmat.a;
 candidate=jet[Times@@MapThread[Power,{f,power}]];
 If[getcoef[candidate,a]=!=getcoef[h[[i]],a],
 AppendTo[fails,{i,a,getcoef[candidate,a],getcoef[h[[i]],a]}]],
 {i,3},{a,alist}];
<|"Mechanism"->"Arbitrary four Hamiltonian shears; independent forward and inverse",
 "Dimension"->3,"TotalRootDegree"->maxdeg,
 "CoefficientIdentitiesChecked"->3 Length[alist],"Failures"->fails|>
(* Actual output: CoefficientIdentitiesChecked -> 168, Failures -> {}. *)
