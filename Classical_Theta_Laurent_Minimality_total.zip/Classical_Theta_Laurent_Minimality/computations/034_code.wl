ClearAll[v];
SeedRandom[202611141432];
checks=0; floorChecks=0; nonzero=0; maxRank=0; maxIterations=0; bad={};
Do[
 n=3+Mod[cas,14]; maxRank=Max[maxRank,n];
 aa=ConstantArray[0,{n,n}];
 Do[
  r=RandomChoice[{0,0,0,0,0,0,0,-2,-1,1,2}];
  If[r>0,aa[[i,j]]=r,If[r<0,aa[[j,i]]=-r]],
  {i,n},{j,i+1,n}];
 cert=RandomInteger[{0,18},n]/RandomChoice[{1,2,3}];
 ww=Floor[cert-aa.cert]-RandomInteger[{0,2},n];
 vars=Array[v,n];
 ans=Minimize[{Total[vars],And@@Join[Thread[vars>=0],Thread[(IdentityMatrix[n]-aa).vars>=ww]]},vars,Reals];
 lp=vars/.Last[ans];
 fl=Floor[cert];
 If[!And@@Join[Thread[fl>=0],Thread[fl-aa.fl>=ww]],AppendTo[bad,{"floor",cas}]];
 floorChecks++;
 state=ConstantArray[0,n]; it=0;
 While[True,
  nxt=Map[Max[0,#]&,ww+aa.state];
  If[nxt===state,Break[]];
  state=nxt;it++;
  If[it>Total[fl]+1,AppendTo[bad,{"nontermination",cas}];Break[]]];
 maxIterations=Max[maxIterations,it];
 If[state=!=lp||!And@@(IntegerQ/@lp)||First[ans]=!=Total[state],
  AppendTo[bad,{"LP-recursion",cas,lp,state,ans}]];
 If[Total[state]>0,nonzero++];
 checks++,
 {cas,96}];
infeasible=0;
Do[
 n=3+Mod[cas,10]; aa=ConstantArray[0,{n,n}];
 Do[aa[[i,1+Mod[i,n]]]=RandomInteger[{1,3}],{i,n}];
 Do[If[aa[[i,j]]==0&&aa[[j,i]]==0,aa[[i,j]]=RandomChoice[{0,0,1,2}]],{i,n},{j,i+1,n}];
 ww=RandomInteger[{1,4},n]; vars=Array[v,n];
 ans=Quiet[Minimize[{Total[vars],And@@Join[Thread[vars>=0],Thread[(IdentityMatrix[n]-aa).vars>=ww]]},vars,Reals]];
 If[First[ans]===Infinity,infeasible++,AppendTo[bad,{"infeasible",cas,ans}]],
 {cas,24}];
<|"FeasibleExactLPs"->checks,"FloorCertificateChecks"->floorChecks,
"NonzeroOptimalForestWeights"->nonzero,"MaximumRank"->maxRank,
"MaximumStrictHeightUpdates"->maxIterations,"CorrectlyRejectedLPs"->infeasible,
"Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
