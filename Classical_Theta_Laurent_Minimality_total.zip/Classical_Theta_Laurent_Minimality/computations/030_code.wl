ClearAll[t,u,m,H,U,W,M,trunc,n,c];
n=8; c=2;
trunc[p_]:=Normal@Series[p,{t,0,n}];
H[u_]:=(1+u(1+u)^2)(1+u);
U=Nest[trunc[t H[#]^c]&,0,n];
W=trunc[H[U]];
M=Nest[Function[m,trunc[H[t]+m((W/.t->t m^c)-1)]],1,n];
<|"H"->Expand[H[t]],"Ucoefficients"->CoefficientList[U,t],"Wcoefficients"->CoefficientList[W,t],"Mcoefficients"->CoefficientList[M,t],"Uresidual"->trunc[U-t H[U]^c],"Mresidual"->trunc[M-H[t]-M((W/.t->t M^c)-1)]|>
(* Actual U={0,1,4,26,202,1727,15686,148551,1450536};
W={1,2,11,79,645,5684,52692,506405,5000052};
M={1,4,38,626,12416,268228,6115236,144798127,3526303626};
both residuals 0 through degree8. *)
