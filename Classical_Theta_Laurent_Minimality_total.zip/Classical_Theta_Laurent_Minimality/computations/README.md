# 后期计算单元

35 个 Wolfram／JavaScript 单元从原研究记录逐字提取，索引保留出处、上下文和校验值。

这些单元保留历史原样，含失败诊断；部分依赖计算插件或前序定义，不能把每个单元都视为独立脚本。本次收束没有重新执行数学计算。早期程序和输出位于 earlier_materials/agents 与 earlier_materials/computation。
