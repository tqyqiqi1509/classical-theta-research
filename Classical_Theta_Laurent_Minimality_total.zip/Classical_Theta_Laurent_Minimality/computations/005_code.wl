Module[{matrices=0,labels=0,bad=0,eligible=0,n,m,e,b,tau,invTau,q,u,s,r,rh,g,h,a,nu,j,k,zmat,zvec,threshold,seed=202611140729},
SeedRandom[seed];
Do[n=RandomChoice[{2,3,4,6,8,12,16,24,32}];
m=Table[If[i<j,RandomInteger[{0,5}],0],{i,n},{j,n}];
e=IdentityMatrix[n]-m;b=e-Transpose[e];tau=-Inverse[e].Transpose[e];invTau=Inverse[tau];
zmat=ConstantArray[0,{n,n}];zvec=ConstantArray[0,n];
If[Transpose[tau].e.tau!=e||e.tau!=-Transpose[e],bad++];matrices++;
Do[q=RandomInteger[{1,6},n];u=RandomInteger[{1,9},n];s=RandomInteger[{-5,5},n];a=tau.q;nu=q.e.u;
If[u.e.a!=-nu||q.e.q!=a.e.a,bad++];
If[Min[a]>=0,eligible++;
threshold=1+Max[0,Max[MapThread[Ceiling[(#1+#2-#3)/#4]&,{q,a,s,u}]],
If[nu<0,Floor[(q.e.(s-q))/(-nu)],0],If[nu>0,Floor[((s-a).e.a)/nu],0]];
r=threshold u+s;rh=r-q-a;g=-e.r;h=g+b.q;
If[h!=-e.rh||g+b.r-(-e.rh+b.rh)!=b.a||Min[rh]<0||invTau.a!=q,bad++];
If[nu<0&&q.e.(r-q)>=0,bad++];If[nu>0&&(r-a).e.a>=0,bad++]];
labels++,{k,1,16}],{j,1,256}];
<|"Seed"->seed,"Matrices"->matrices,"Labels"->labels,
"NonnegativeOppositeLabels"->eligible,"Failures"->bad,"AllPass"->(bad==0)|>]
