ClearAll[mul,pow,shift,mut,fc];
SeedRandom[2611141210];dd=6;one=Join[{1},ConstantArray[0,dd]];
mul[a_,b_]:=Table[Sum[a[[j+1]]b[[k-j+1]],{j,0,k}],{k,0,dd}];
pow[a_,m_Integer]:=Module[{q=a-one,u=one,out=one},Do[u=mul[u,q];out=out+Binomial[m,j]u,{j,1,If[m>=0,Min[m,dd],dd]}];out];
shift[a_,m_Integer]:=If[m>dd,ConstantArray[0,dd+1],Join[ConstantArray[0,m],Take[a,dd+1-m]]];
fc[de_,r_,k_]:=If[r==0,Boole[k==0],If[de==0,Binomial[r,k],r Binomial[de k+r,k]/(de k+r)]];
bad={};checks=0;gchecks=0;forestchecks=0;positivechecks=0;maxrank=0;nonconstant=0;
Do[
 n=3+Mod[cas,14];maxrank=Max[maxrank,n];
 bb=ConstantArray[0,{n,n}];
 Do[bb[[i,j]]=RandomChoice[{0,0,0,0,0,0,-2,-1,1,2}];bb[[j,i]]=-bb[[i,j]],{i,n},{j,i+1,n}];
 base=bb;de=Max[Join[Total[Map[Max[#,0]&,base,{2}],{2}],Total[Map[Max[-#,0]&,base,{2}],{2}]]];
 cc=IdentityMatrix[n];gg=IdentityMatrix[n];ff=ConstantArray[one,n];
 Do[
 k=RandomInteger[{1,n}];eps=Sign[First[Select[cc[[All,k]],#!=0&]]];
 If[!And@@Thread[eps cc[[All,k]]>=0],AppendTo[bad,{"sign",cas,st}]];
 pp=one;qq=one;
 Do[pp=mul[pp,pow[ff[[i]],Max[bb[[i,k]],0]]];qq=mul[qq,pow[ff[[i]],Max[-bb[[i,k]],0]]],{i,n}];
 nv=mul[shift[pp,Total[Map[Max[#,0]&,cc[[All,k]]]]]+shift[qq,Total[Map[Max[-#,0]&,cc[[All,k]]]]],pow[ff[[k]],-1]];
 ng=-gg[[All,k]]+Sum[Max[-eps bb[[i,k]],0]gg[[All,i]],{i,n}];
 r=Total[Map[Max[-#,0]&,ng]];cap=Table[fc[de,r,j],{j,0,dd}];
 If[!And@@Thread[nv>=0],AppendTo[bad,{"negative",cas,st}]];positivechecks+=dd+1;
 If[!And@@Thread[nv<=cap],AppendTo[bad,{"majorant",cas,st,base,k,ng,nv,cap}]];checks+=dd+1;
 If[nv=!=one,nonconstant++];
 nc=Table[If[j==k,-cc[[i,j]],cc[[i,j]]+Max[eps bb[[k,j]],0]cc[[i,k]]],{i,n},{j,n}];
 nb=Table[If[i==k||j==k,-bb[[i,j]],bb[[i,j]]+Max[bb[[i,k]],0]Max[bb[[k,j]],0]-Max[-bb[[i,k]],0]Max[-bb[[k,j]],0]],{i,n},{j,n}];
 gg[[All,k]]=ng;ff[[k]]=nv;cc=nc;bb=nb;
 If[Transpose[gg].cc=!=IdentityMatrix[n],AppendTo[bad,{"duality",cas,st}]];gchecks++,
 {st,10}];
 adj=Map[Max[#,0]&,base,{2}];tt=ConstantArray[one,n];
 Do[tt=Table[pp=one;Do[pp=mul[pp,pow[tt[[j]],adj[[i,j]]]],{j,n}];one+shift[pp,1],{i,n}],{dd}];
 cap=Table[fc[de,1,j],{j,0,dd}];
 Do[If[!And@@Thread[tt[[i]]<=cap],AppendTo[bad,{"forest",cas,i}]];forestchecks+=dd+1,{i,n}],
 {cas,128}];
<|"Quivers"->128,"MaximumRank"->maxrank,"RootTruncationDegree"->dd,"MutationSteps"->gchecks,"CoefficientMajorantChecks"->checks,"CoefficientPositivityChecks"->positivechecks,"ForestMajorantChecks"->forestchecks,"NonconstantMutationJets"->nonconstant,"Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
