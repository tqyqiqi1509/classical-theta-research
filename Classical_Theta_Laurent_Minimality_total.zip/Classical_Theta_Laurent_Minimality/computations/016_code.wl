ClearAll[t, s, z, st, hp, trunc];
SeedRandom[2026111409];
rootCap = 4;
cases = Table[
  Module[{n = RandomInteger[{2, 6}], a, f},
    a = Table[
      If[i < j && RandomReal[] < 0.6,
        RandomInteger[{1, 2}], 0],
      {i, n}, {j, n}];
    f = UnitVector[n, RandomInteger[{1, n}]];
    If[Mod[c, 5] == 0,
      f = f + UnitVector[n, RandomInteger[{1, n}]]];
    {a, f}],
  {c, 1, 32}];
counts = 0;
fails = {};
supportZeros = 0;
maximumTerms = 0;
Do[
  Module[
    {a = ca[[1]], f = ca[[2]], n, bb, ee, roots, zz,
     hs, ff, cart, bound, val, num, den, rules, cp, ok},
    n = Length[f];
    bb = a - Transpose[a];
    ee = IdentityMatrix[n] - a;
    cart = Inverse[IdentityMatrix[n] - Transpose[a]];
    bound = cart.f;
    roots = Flatten[
      Table[FrobeniusSolve[ConstantArray[1, n], d],
        {d, 0, rootCap}], 1];
    Clear[st, hp];
    st[d_List] := st[d] =
      t^(d.ee.d)/
        Product[
          Product[1 - t^(2 j), {j, 1, d[[i]]}],
          {i, 1, n}];
    hp[ConstantArray[0, n]] = 1;
    hp[d_List] := hp[d] =
      Cancel[Together[
        st[d] t^(-f.d) -
          Total[
            Table[
              If[v === d, 0,
                hp[v] st[d - v]
                  t^(v.bb.(d - v) + f.(d - v))],
              {v, Tuples[Range[0, #] & /@ d]}]
          ]
      ]];
    zz = Array[z, n];
    hs = ConstantArray[1, n];
    trunc[poly_] :=
      Expand[
        Normal[
          Series[poly /. Thread[zz -> s zz],
            {s, 0, rootCap}]
        ] /. s -> 1];
    Do[
      hs[[i]] = trunc[
        1 + zz[[i]]
          Product[hs[[j]]^a[[i, j]], {j, i + 1, n}]],
      {i, n, 1, -1}];
    ff = trunc[
      Product[hs[[i]]^f[[i]], {i, 1, n}]];
    Do[
      val = hp[d];
      num = Numerator[val];
      den = Denominator[val];
      rules = CoefficientRules[num, {t}];
      cp = Fold[
        Coefficient[#1, #2[[1]], #2[[2]]] &,
        ff, Transpose[{zz, d}]];
      ok =
        Length[CoefficientRules[den, {t}]] == 1 &&
        And @@
          (IntegerQ[Last[#]] && Last[#] >= 0 & /@ rules) &&
        (den /. t -> 1) == 1;
      ok = TrueQ[ok] &&
        TrueQ[(val /. t -> 1) == cp] &&
        (And @@ Thread[d <= bound] || val === 0);
      counts++;
      maximumTerms = Max[maximumTerms, Length[rules]];
      If[Not[And @@ Thread[d <= bound]], supportZeros++];
      If[!ok, AppendTo[fails, {a, f, d, val, cp, bound}]],
      {d, roots}]
  ],
  {ca, cases}];
<|
  "quivers" -> Length[cases],
  "rootHeight" -> rootCap,
  "rankRange" -> MinMax[Length[#[[2]]] & /@ cases],
  "exactQuantumCoefficients" -> counts,
  "outsideCartanBoundZeroChecks" -> supportZeros,
  "largestCoefficientTermCount" -> maximumTerms,
  "allPass" -> (fails === {}),
  "failures" -> Take[fails, UpTo[5]]
|>
