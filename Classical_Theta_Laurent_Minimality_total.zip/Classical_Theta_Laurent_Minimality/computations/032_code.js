function add(A,B,s=0,c=1n){let R=new Map(A);for(let[k,v]of B){let u=k+s,w=(R.get(u)||0n)+c*v;if(w)R.set(u,w);else R.delete(u);}return R;}
function mul(A,B){let R=new Map;for(let[k,v]of A)for(let[l,w]of B){let u=k+l,t=(R.get(u)||0n)+v*w;if(t)R.set(u,t);else R.delete(u);}return R;}
function sh(A,s){return new Map([...A].map(([k,v])=>[k+s,v]));}
function qb(n,k){if(k<0||k>n)return new Map;let A=Array.from({length:k+1},()=>new Map);A[0].set(0,1n);for(let m=1;m<=n;m++){let T=Array.from({length:k+1},()=>new Map);for(let j=0;j<=Math.min(m,k);j++){T[j]=sh(A[j],-j);if(j)T[j]=add(T[j],A[j-1],m-j);}A=T;}return A[k];}
function ipows(r,maxA,D){let H=new Map([['0,0',new Map([[0,1n]])]]);for(let k=0;k<=Math.min(r,D-1);k++)H.set('1,'+k,qb(r,k));let out=[new Map([['0,0',new Map([[0,1n]])]])];for(let a=0;a<maxA;a++){let R=new Map;for(let[qs,A]of out[a]){let[p,q]=qs.split(',').map(Number);for(let[ss,C]of H){let[u,v]=ss.split(',').map(Number);if(p+q+u+v>D)continue;let e=-p+a*u+r*(p*v-q*u),key=(p+u)+','+(q+v);R.set(key,add(R.get(key)||new Map,mul(A,C),e));}}out.push(R);}return out;}
function ctb(r,a,b,D,ip){const E=(aa,bb,p,q)=>sh(ip[aa].get(p+','+q)||new Map,bb*q);let R=new Map([['0,0',new Map([[0,1n]])]]),C=new Map;for(let d=0;d<=D;d++)for(let p=0;p<=d;p++){let q=d-p,S=new Map;for(let[ss,V]of R){let[u,v]=ss.split(',').map(Number);if(u<=p&&v<=q)S=add(S,mul(V,E(a-r*v,b-r*u,p-u,q-v)));}if(!d){C.set('0,0',1n);continue;}let T=new Map;for(let[k,v]of S)if(k<0)T.set(-k,(T.get(-k)||0n)+v);for(let[k,v]of S)if(k>0){let w=(T.get(k)||0n)-v;if(w)T.set(k,w);else T.delete(k);}R.set(p+','+q,T);let s=0n;for(let[k,v]of S)if(k===0)s+=v;else if(k<0)s+=2n*v;C.set(p+','+q,s);}return C;}
function bin(n,k){if(k<0||n<k||n<0)return 0n;k=Math.min(k,n-k);let r=1n;for(let i=1;i<=k;i++)r=r*BigInt(n-k+i)/BigInt(i);return r;}
function greedy(r,a,b,P,Q){let e=Array.from({length:P+1},()=>Array(Q+1).fill(0n));for(let p=0;p<=P;p++)for(let q=0;q<=Q;q++){if(!p){e[p][q]=bin(Math.max(a,0),q);continue;}if(!q){e[p][q]=bin(Math.max(b,0),p);continue;}let A=0n,B=0n,np=Math.max(0,b-r*q),nq=Math.max(0,a-r*p);for(let k=1;k<=p;k++)A+=(k%2?1n:-1n)*e[p-k][q]*bin(np+k-1,k);for(let k=1;k<=q;k++)B+=(k%2?1n:-1n)*e[p][q-k]*bin(nq+k-1,k);e[p][q]=A>B?A:B;}return e;}
const r=3,a=20,b=20,D=4;
const ip=ipows(r,a,D),C=ctb(r,a,b,D,ip),eg=greedy(r,a,r*a-b,D,a);
const output=[];
for(let deg=0;deg<=D;deg++)for(let p=0;p<=deg;p++){const q=deg-p;output.push({root:[p,q],ctb:String(C.get(p+','+q)||0n),theta:String(eg[q][a-p])});}
console.log(JSON.stringify(output,null,2));
// Require a,b>=r*D so every shifted E stays in the same sign chamber.
// CTB correction T_k=S_{-k}-S_k (k>0); v=1 coefficient S_0+2*sum_{k<0}S_k.
// Diagnostic of an actual known basis, not a proof for arbitrary classical strong bases.

