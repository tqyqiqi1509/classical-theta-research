<|"Cases" -> 616,
  "Failures" -> {},
  "GeneralFormula" -> "lim Ad log EE(-t^j z^n) = pairing * ((-1)^(k+1) if j even, 1 if j odd)/k"|>
