Module[{tt=Unique["t"], parities, limits},
 parities=Flatten[
   Table[{j,k,h},{j,-5,5},{k,1,8},{h,0,6}],2];
 limits=Table[
   With[{j=q[[1]],k=q[[2]],h=q[[3]]},
    {q,
     Limit[
      (tt^(k h)-tt^(-k h)) (-1)^(j+k (j+1)) tt^(k (j+1))/
       (k (1-tt^(2k))),tt->1],
     h If[EvenQ[j],(-1)^(k+1),1]/k}],
   {q,parities}];
 <|"Cases"->Length[limits],
   "Failures"->Select[limits,#[[2]]=!=#[[3]]&],
   "GeneralFormula"->"lim Ad log EE(-t^j z^n) = pairing * ((-1)^(k+1) if j even, 1 if j odd)/k"|>
]
