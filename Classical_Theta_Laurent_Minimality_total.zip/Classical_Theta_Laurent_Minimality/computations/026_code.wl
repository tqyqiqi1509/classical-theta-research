ClearAll[makeCover,foldData,negF,topMat,tr];
SeedRandom[2611141132];
makeCover[sz_,cyc_] := Module[{nn=Total[sz],cuts,orbs,mat,gg,vals,i,j,a,b,sgn,perm},
 cuts=Prepend[Accumulate[sz],0];
 orbs=Table[Range[cuts[[i]]+1,cuts[[i+1]]],{i,Length[sz]}];
 mat=ConstantArray[0,{nn,nn}];
 Do[gg=GCD[sz[[i]],sz[[j]]];
 vals=RandomChoice[{0,0,0,1,1,2},gg];
 sgn=If[cyc,RandomChoice[{-1,1}],-1];
 Do[mat[[orbs[[i,a+1]],orbs[[j,b+1]]]]=sgn vals[[1+Mod[b-a,gg]]];
 mat[[orbs[[j,b+1]],orbs[[i,a+1]]]]=-sgn vals[[1+Mod[b-a,gg]]],
 {a,0,sz[[i]]-1},{b,0,sz[[j]]-1}],{i,1,Length[sz]},{j,i+1,Length[sz]}];
 perm=Flatten[RotateLeft /@orbs];
 {mat,orbs,perm}];
foldData[bb_,orbs_]:=Module[{pp,aa,nn=Length[bb],sz=Length/@orbs,bf},
 pp=Table[Boole[MemberQ[orbs[[i]],j]],{i,Length[orbs]},{j,nn}];
 aa=Transpose[pp].DiagonalMatrix[1/sz];
 bf=pp.bb.aa;{pp,aa,bf}];
tr[pp_]:=Normal[Series[pp,{u,0,5}]];
negF[bb_,vv_]:=Module[{fs=ConstantArray[1,Length[bb]],prod},
 Do[prod=1;Do[If[bb[[j,i]]<0,prod=tr[prod fs[[j]]^(-bb[[j,i]])]],{j,1,i-1}];
 fs[[i]]=tr[1+vv[[i]]u prod],{i,Length[bb]}];fs];
topMat[bb_]:=Inverse[IdentityMatrix[Length[bb]]-Map[Max[0,-#]&,UpperTriangularize[bb,1],{2}]];
bad={};fchecks=0;coefchecks=0;poisson=0;topchecks=0;maxRank=0;
Do[
 nn=3+Mod[case,6];sz=RandomChoice[{1,2,3,4},nn];
 {bb,orbs,perm}=makeCover[sz,case>256];
 {pp,aa,bf}=foldData[bb,orbs];maxRank=Max[maxRank,Length[bb]];
 If[pp.bb=!=bf.pp||bb.aa=!=aa.bf||pp.aa=!=IdentityMatrix[nn]||
 bb[[perm,perm]]=!=bb||!And@@(IntegerQ /@Flatten[bf]),
 AppendTo[bad,{"linear",case}]];
 dd=DiagonalMatrix[1/sz];
 If[dd.bf=!=-Transpose[dd.bf],AppendTo[bad,{"symmetrizer",case}]];
 Do[v=RandomInteger[{-4,4},Length[bb]];w=RandomInteger[{-4,4},Length[bb]];
 ord=LCM@@sz;vp=NestList[#[[perm]]&,v,ord-1];wp=NestList[#[[perm]]&,w,ord-1];
 lhs=Total[vp].bb.Total[wp];
 rhs=ord^2 (pp.v).dd.bf.(pp.w);
 If[lhs=!=rhs,AppendTo[bad,{"poisson",case,j}]];poisson++,
 {j,1,8}];
 If[case<=256,
  val=RandomInteger[{1,5},nn];vup=Transpose[pp].val;
  ffup=negF[bb,vup];ffdn=negF[bf,val];
  Do[Do[If[ffup[[b]]=!=ffdn[[i]],AppendTo[bad,{"F",case,i,b}]];
    fchecks++;coefchecks+=6,{b,orbs[[i]]}],{i,nn}];
  cc=topMat[bb];cb=topMat[bf];
  If[pp.cc=!=cb.pp,AppendTo[bad,{"Cartan",case}]];topchecks+=Length[bb] nn;
 ],
 {case,1,512}];
<|"Covers"->512,"AcyclicCoefficientCovers"->256,
 "CyclicLinearCovers"->256,"MaximumCoverRank"->maxRank,
 "TruncatedFIdentities"->fchecks,"UnivariateCoefficientChecks"->coefchecks,
 "OrbitPoissonIdentities"->poisson,"CartanEntryChecks"->topchecks,
 "Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
