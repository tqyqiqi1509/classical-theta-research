Block[{$HistoryLength=0},
 Module[{nmax=96, profiles=384, rng, failures={}, negative=0,
   checked=0, largest=0, conv, a,b,kappa,s,r,m,c,
   lg,f,g,h},
  SeedRandom[271828];
  conv[u_,v_]:=Take[
    ListConvolve[u,v,{1,-1},0],UpTo[nmax+1]];
  Do[
   a=RandomInteger[{0,4},12];
   b=RandomInteger[{0,4},12];
   kappa=RandomInteger[{0,8},12];
   lg=Table[
     Sum[If[Mod[k,m]==0,
       m kappa[[m]] (a[[m]] (-1)^(Quotient[k,m]+1)+b[[m]]),
       0],{m,1,12}],{k,1,nmax}];
   f=ConstantArray[0,nmax+1]; f[[1]]=1;
   Do[f[[k+1]]=Sum[
     lg[[j]] f[[k-j+1]],{j,1,k}]/k,{k,1,nmax}];
   g={1};
   Do[
    c=kappa[[m]] a[[m]];
    If[c>0,
     h=Table[If[Mod[k,m]==0&&k/m<=c,
       Binomial[c,k/m],0],{k,0,Min[nmax,m c]}];
     g=conv[g,h]];
    c=kappa[[m]] b[[m]];
    If[c>0,
     Do[s=m 2^r;
      h=Table[If[Mod[k,s]==0&&k/s<=c,
        Binomial[c,k/s],0],{k,0,Min[nmax,s c]}];
      g=conv[g,h],
      {r,0,Floor[Log[2,nmax/m]]}]],
    {m,1,12}];
   g=PadRight[g,nmax+1]; checked+=Length[f];
   If[f=!=g,AppendTo[failures,rng]];
   negative+=Count[f,_?Negative];
   largest=Max[largest,Max[IntegerLength/@f]],
   {rng,1,profiles}];
  <|"Profiles"->profiles,"DegreeCap"->nmax,
    "ExactCoefficientsChecked"->checked,
    "MismatchProfiles"->failures,"NegativeCoefficients"->negative,
    "MaximumIntegerDigits"->largest,
    "Method1"->"Adams-log recurrence",
    "Method2"->"binary positive binomial factor convolution"|>
 ]]
