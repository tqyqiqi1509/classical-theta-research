ClearAll[acyF,acyFOp,acyJ,markSupp,ff,topF,fg,gg,bb,dd];
SeedRandom[2611141105];
acyF[b_,g_] := Module[{n=Length[g],v=ConstantArray[0,Length[g]]},
 Do[v[[i]]=Max[0,-g[[i]]+Sum[-b[[i,j]]v[[j]],{j,i+1,n}]],
 {i,n,1,-1}];v];
acyFOp[b_,g_] := Module[{n=Length[g],v=ConstantArray[0,Length[g]]},
 Do[v[[i]]=Max[0,-g[[i]]+Sum[b[[i,j]]v[[j]],{j,1,i-1}]],
 {i,1,n}];v];
acyJ[b_,g_] := Module[{n=Length[g],v=ConstantArray[0,Length[g]],
 a=ConstantArray[0,{Length[g],Length[g]}],r},
 Do[r=-g[[i]]+Sum[-b[[i,j]]v[[j]],{j,i+1,n}];
 If[r>0,v[[i]]=r;
 a[[i]]=-UnitVector[n,i]+Sum[-b[[i,j]]a[[j]],{j,i+1,n}]],
 {i,n,1,-1}];IdentityMatrix[n]+b.a];
badA={}; detA={}; acount=0;
Do[
 n=3+Mod[k,18];dd=RandomInteger[{1,5},n];
 bb=ConstantArray[0,{n,n}];
 Do[r=RandomChoice[{0,0,0,1,1,2}];
 bb[[i,j]]=-dd[[j]]r;bb[[j,i]]=dd[[i]]r,
 {i,1,n},{j,i+1,n}];
 Do[gg=RandomInteger[{-30,30},n]/RandomInteger[{1,7}];
 ff=acyF[bb,gg];hh=gg+bb.ff;fo=acyFOp[bb,hh];
 If[fo=!=ff||hh-bb.fo=!=gg,AppendTo[badA,{k,gg,ff,hh,fo}]];
 acount++;
 If[t==1,AppendTo[detA,Det[acyJ[bb,gg]]]],
 {t,1,32}],
 {k,1,256}];
mb={{0,-2,2},{2,0,-2},{-2,2,0}};
base={{0,0,0},{1,0,0},{1,0,1},{1,0,2},{1,1,2},{1,2,2},{2,2,2}};
sb=Table[(RotateRight[#,i-1]& /@base),{i,1,3}];
so=Table[(RotateRight[#[[{1,3,2}]],i-1]& /@base),{i,1,3}];
topF[s_,g_]:=(Max[-#.g]& /@s);
badM={}; detM={}; mc=0; generic=0;
Do[
 gg=RandomInteger[{-1000,1000},3]/RandomInteger[{1,13}];
 fv=topF[so,gg];hh=gg+mb.fv;fo=topF[sb,hh];
 If[fo=!=fv||hh-mb.fo=!=gg,AppendTo[badM,{gg,fv,hh,fo}]];
 vals=((-#.gg)&/@#& /@so);
 ind=FirstPosition[#,Max[#]][[1]]& /@vals;
 If[And@@(Count[#,Max[#]]==1& /@vals),
 generic++;
 aa=Table[-so[[i,ind[[i]]]],{i,1,3}];
 AppendTo[detM,Det[IdentityMatrix[3]+mb.aa]]];
 mc++,
 {10000}];
<|"AcyclicMatrices"->256,"AcyclicLabels"->acount,
 "AcyclicFailures"->Length[badA],"AcyclicJacobianDeterminants"->Union[detA],
 "CyclicKernelLabels"->mc,"CyclicFailures"->Length[badM],
 "CyclicGenericPieces"->generic,"CyclicJacobianDeterminants"->Union[detM],
 "FirstFailure"->Take[Join[badA,badM],UpTo[1]]|>
