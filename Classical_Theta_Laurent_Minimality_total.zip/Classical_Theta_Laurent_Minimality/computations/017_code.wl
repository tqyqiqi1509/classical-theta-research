ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=ff[bb,cc,gg1,gg2]=Module[
{aa2=-gg2,aa1,ppmax,qqmax,ee,pp,qq,kk},
aa1=bb Max[aa2,0]-gg1;ppmax=Max[aa2,0];qqmax=Max[aa1,0];
ee=ConstantArray[0,{ppmax+1,qqmax+1}];ee[[1,1]]=1;
Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]]nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]]nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],
{pp,0,ppmax},{qq,0,qqmax}];
Expand[Sum[ee[[pp+1,qq+1]]z1^qq z2^(ppmax-pp),
{pp,0,ppmax},{qq,0,qqmax}]]];
checks=0;nonzero=0;positiveTerms=0;fails={};maxCoeff=0;maxSupport=0;
Do[Module[{f=ff[bb,cc,g1,g2],poly,base,rr,box,q,coef,h,neg=False},
poly=Expand[D[f,{If[jj==1,z1,z2],ord}]/Factorial[ord]];checks++;
If[poly=!=0,nonzero++;
base={g1,g2}+If[jj==1,{ord,cc ord},{-bb ord,ord}];rr=poly;
box=SortBy[Tuples[{Range[0,Exponent[poly,z1]],Range[0,Exponent[poly,z2]]}],{Total,First}];
Do[coef=Coefficient[Coefficient[rr,z1,q[[1]]],z2,q[[2]]];
If[coef<0,neg=True;AppendTo[fails,{bb,cc,{g1,g2},jj,ord,q,coef}];Break[]];
If[coef>0,positiveTerms++;maxCoeff=Max[maxCoeff,coef];
h=base+{-bb q[[2]],cc q[[1]]};
rr=Expand[rr-coef z1^q[[1]]z2^q[[2]]ff[bb,cc,h[[1]],h[[2]]]]],{q,box}];
If[!neg&&rr=!=0,AppendTo[fails,{"residual",bb,cc,{g1,g2},jj,ord,rr}]];
maxSupport=Max[maxSupport,Length[CoefficientRules[poly,{z1,z2}]]]]],
{bb,1,4},{cc,1,4},{g1,-4,2},{g2,-4,2},{jj,1,2},{ord,1,3}];
<|"bRange"->{1,4},"cRange"->{1,4},"headBox"->{-4,2},"orders"->{1,3},
"exactChecks"->checks,"nonzeroDerivatives"->nonzero,"positiveThetaTerms"->positiveTerms,
"largestThetaCoefficient"->maxCoeff,"largestDerivativeMonomialSupport"->maxSupport,
"failures"->Length[fails],"firstFailure"->Take[fails,UpTo[1]]|>
