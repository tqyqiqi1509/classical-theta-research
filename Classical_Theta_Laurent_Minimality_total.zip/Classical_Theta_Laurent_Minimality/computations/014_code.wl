<|"Profiles" -> 384,
  "DegreeCap" -> 96,
  "ExactCoefficientsChecked" -> 37248,
  "MismatchProfiles" -> {},
  "NegativeCoefficients" -> 0,
  "MaximumIntegerDigits" -> 47,
  "Method1" -> "Adams-log recurrence",
  "Method2" -> "binary positive binomial factor convolution"|>
