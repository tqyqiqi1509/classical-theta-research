<|"cases" -> 160,
  "wildCases" -> 106,
  "sourceDegreeRange" -> {0, 36},
  "allPass" -> True,
  "failures" -> {},
  "checks" -> {"binomial divisibility in original chart",
    "degree <= k", "both core endpoints",
    "core coefficient positivity", "core binomial upper bound",
    "core Pascal lower recurrence"}|>
