Module[
 {cp, vars = {xs, ys, ts, us}, sv = {xs, ys}, tv = {ts, us}, trials = 160,
 supports, weights, h, ftSup = Tuples[{0, 1}, 2], ftW, c, ell, sub, poly,
 direct, pred, rules, alpha, rows1, rows2, rr1, rr2, a, v, w,
 fail = {}, tests = 0, systems = 0, points = 0, termRange = {}, trial, j, i},
 cp[k_, 1] := {{k}};
 cp[k_, l_] := cp[k, l] = Flatten[Table[(Prepend[#, r] &) /@ cp[k-r,l-1],{r,0,k}],1];
 SeedRandom[202611140814];
 Do[
 supports=Table[DeleteDuplicates[Join[{{0,0},UnitVector[2,i]},RandomInteger[{0,2},{2,2}]]],{i,2}];
 weights=Table[Join[{1,1},RandomInteger[{1,4},Length[supports[[i]]]-2]],{i,2}];
 h=Table[Sum[weights[[i,j]] Times@@(sv^supports[[i,j]]),{j,Length[supports[[i]]]}],{i,2}];
 ftW=Join[{1},RandomInteger[{1,3},3]];c=RandomInteger[{0,2},2];ell=RandomInteger[{0,1},{2,2}];
 sub=Table[tv[[j]] Times@@(h^ell[[All,j]]),{j,2}];
 poly=Expand[Times@@(h^c) Sum[ftW[[j]] Times@@(sub^ftSup[[j]]),{j,4}]];
 direct=SortBy[CoefficientRules[poly,vars],First];rules={};
 Do[
 a=ftSup[[j]];alpha=c+ell.a;
 rows1=cp[alpha[[1]],Length[supports[[1]]]];rows2=cp[alpha[[2]],Length[supports[[2]]]];systems++;
 Do[
 v=rr1.supports[[1]]+rr2.supports[[2]];
 w=ftW[[j]] (Factorial[alpha[[1]]]/Times@@(Factorial/@rr1))
 (Factorial[alpha[[2]]]/Times@@(Factorial/@rr2))
 Times@@(weights[[1]]^rr1) Times@@(weights[[2]]^rr2);
 AppendTo[rules,{Join[v,a],w}];points++,{rr1,rows1},{rr2,rows2}],{j,4}];
 pred=SortBy[Normal[GroupBy[rules,First->Last,Total]],First];
 tests+=Length[Union[First/@direct,First/@pred]];AppendTo[termRange,Length[direct]];
 If[direct=!=pred,AppendTo[fail,{trial,supports,weights,c,ell,Take[direct,UpTo[3]],Take[pred,UpTo[3]]}]],
 {trial,trials}];
 <|"RandomPositiveSubstitutions"->trials,"IntegerCountSystems"->systems,
 "EnumeratedNonnegativeSolutions"->points,"CoefficientComparisons"->tests,
 "SupportSizeRange"->{Min[termRange],Max[termRange]},"Failures"->Length[fail],
 "FirstFailure"->Take[fail,UpTo[1]]|>
]
