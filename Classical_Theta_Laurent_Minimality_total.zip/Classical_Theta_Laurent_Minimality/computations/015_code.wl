ClearAll[dimData];
shortCycles={{1,3,5},{2,4,6}};
longCycle={1,4,5,2,3,6};
deriv[cyc_,a_]:=Rest[RotateLeft[cyc,First@FirstPosition[cyc,a]-1]];
bits[path_]:=FromDigits[Mod[path-1,2],2];
rels=Table[With[{sc=First@Select[shortCycles,MemberQ[#,a]&]},
{1+Mod[Ceiling[a/2],3],bits[deriv[sc,a]],bits[deriv[longCycle,a]]}],{a,6}];
idx[start_,len_,num_]:=3(2^len-1)+(start-1)2^len+num+1;
dimData[L_]:=Module[{nn=3(2^L-1),edges,comps,zero,live,meta,cart},
 edges=Flatten[Table[With[{rs=rr[[1]],sbit=rr[[2]],lbit=rr[[3]]},
 Table[With[{v=1+Mod[rs-1-u,3]},
 Table[UndirectedEdge[idx[v,u+2+s,pf 2^(2+s)+sbit 2^s+sf],
 If[u+5+s<L,idx[v,u+5+s,pf 2^(5+s)+lbit 2^s+sf],0]],
 {pf,0,2^u-1},{sf,0,2^s-1}]],{u,0,L-3},{s,0,L-3-u}]],{rr,rels}]];
 comps=ConnectedComponents[Graph[Range[0,nn],edges]];
 live=Select[comps,FreeQ[#,0]&];
 meta=Flatten[Table[Table[ConstantArray[{1+Mod[v-1+l,3],v},2^l],{v,3}],{l,0,L-1}],2];
 cart=ConstantArray[0,{3,3}];
 Do[With[{ij=meta[[First[c]]]},cart[[ij[[1]],ij[[2]]]]++],{c,live}];
 <|"L"->L,"pathColumns"->nn,"relationEdges"->Length[edges],"dimension"->Length[live],"Cartan"->cart|>];
Table[dimData[L],{L,3,12}]
