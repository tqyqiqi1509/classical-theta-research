SeedRandom[261114]; Clear[trial];
trial[r_] := Module[{c,b,la,rr,pp,a,d,k,splitTests,principalTests},
 c=RandomInteger[{-7,7},{r-1,r-1}];c=c-Transpose[c];
 b=ArrayFlatten[{{c,Transpose[{-Total[c,{2}]}]},
                {{Total[c,{2}]},{{0}}}}];
 rr=ConstantArray[1,r];
 la=ArrayFlatten[{{ConstantArray[0,{r,r}],-IdentityMatrix[r]},
                 {IdentityMatrix[r],-b}}];
 pp=Join[b.rr,rr];
 splitTests=Table[k=RandomInteger[{1,12}];
   a=RandomInteger[{0,k},r];d=k rr-a;a.b.d===0,{100}];
 principalTests={b.rr===ConstantArray[0,r],Det[la]===1,
   Take[pp,r]===ConstantArray[0,r],
   pp.la.Join[UnitVector[r,1],ConstantArray[0,r]]===1};
 {And@@splitTests,And@@principalTests}];
res=Flatten[Table[trial[r],{r,3,12},{q,100}],1];
<|"Matrices"->Length[res],"CentralSplitChecks"->100Length[res],
  "AllCentralSplitsZero"->And@@res[[All,1]],
  "AllPrincipalChecks"->And@@res[[All,2]]|>
