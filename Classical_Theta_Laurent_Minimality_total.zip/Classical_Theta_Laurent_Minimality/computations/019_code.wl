ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=
 ff[bb,cc,gg1,gg2]=Module[{aa2=-gg2,aa1,pm,qm,ee,pp,qq,kk},
 aa1=bb Max[aa2,0]-gg1;pm=Max[aa2,0];qm=Max[aa1,0];
 ee=ConstantArray[0,{pm+1,qm+1}];ee[[1,1]]=1;
 Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
  Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]]nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
  Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]]nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],
 {pp,0,pm},{qq,0,qm}];
 Expand[Sum[ee[[pp+1,qq+1]]z1^qq z2^(pm-pp),{pp,0,pm},{qq,0,qm}]]];
SeedRandom[202611141004];fails={};checks=0;terms=0;maxBox=0;
Do[Module[{b=RandomInteger[{1,6}],c=RandomInteger[{1,6}],
 g=RandomInteger[{-7,4},2],p=RandomInteger[{0,4},2],
 f,s,hop,dstar,cstar,pm,sym},
 sym={c,b}/GCD[b,c];f=ff[b,c,g[[1]],g[[2]]];
 s=First/@CoefficientRules[f,{z1,z2}];
 hop=Table[Reverse/@(First/@CoefficientRules[
 If[i==1,ff[c,b,0,-1],ff[c,b,-1,0]],{z1,z2}]),{i,2}];
 dstar=Table[Max[(-(sym g).#)&/@hop[[i]]]/sym[[i]],{i,2}];
 cstar=Coefficient[Coefficient[f,z1,dstar[[1]]],z2,dstar[[2]]];
 pm=Max[(p.#)&/@s];
 If[!MemberQ[s,dstar]||cstar=!=1||AnyTrue[s,Or@@Thread[#>dstar]&]||pm=!=p.dstar,
 AppendTo[fails,{b,c,g,p,dstar,cstar,pm}]];
 checks++;terms+=Length[s];maxBox=Max[maxBox,Times@@(dstar+1)]],{512}];
<|"checks"->checks,"exactSupportTerms"->terms,"largestRootBox"->maxBox,
 "failures"->Length[fails],"firstFailure"->Take[fails,UpTo[1]]|>

