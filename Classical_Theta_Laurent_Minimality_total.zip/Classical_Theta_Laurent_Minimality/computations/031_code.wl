ClearAll[z1,z2,t,pc,pt];
pc=1+20 z1+190 z1^2+1140 z1^3+4845 z1^4+2 z1 z2+94 z1^2 z2+1332 z1^3 z2+10 z1^2 z2^2;
pt=1+20 z1+190 z1^2+1140 z1^3+4845 z1^4+60 z1^2 z2+1060 z1^3 z2;
lr=Expand[Normal[Series[Log[(pc/.{z1->t z1,z2->t z2})/(pt/.{z1->t z1,z2->t z2})],{t,0,4}]]/.t->1];
{lr,Expand[lr-(2 z1 z2-6 z1^2 z2+12 z1^3 z2+8 z1^2 z2^2)]}
(* Actual output: {2*z1*z2-6*z1^2*z2+12*z1^3*z2+8*z1^2*z2^2,0}. *)
