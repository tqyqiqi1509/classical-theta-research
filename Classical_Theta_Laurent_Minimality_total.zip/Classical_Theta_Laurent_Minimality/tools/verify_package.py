#!/usr/bin/env python3
"""Verify the integrated package with Python standard-library tools."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile
root = Path(__file__).resolve().parent.parent
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
for item in manifest["files"]:
    data = (root / item["path"]).read_bytes()
    assert len(data) == item["bytes"], ("size", item["path"])
    assert hashlib.sha256(data).hexdigest() == item["sha256"], ("hash", item["path"])
checked = 0
for archive, directory, expected in [
    ("archives/early_progress_v5.zip", "earlier_materials", 130),
    ("archives/final_report_snapshot.zip", "final_report", 6),
]:
    with zipfile.ZipFile(root / archive) as z:
        assert z.testzip() is None
        files = [i for i in z.infolist() if not i.is_dir()]
        assert len(files) == expected
        for item in files:
            prefix = "Classical_Theta_Laurent_Minimality/"
            assert item.filename.startswith(prefix)
            rel = PurePosixPath(item.filename[len(prefix):])
            assert not rel.is_absolute() and ".." not in rel.parts
            assert z.read(item) == (root / directory / rel).read_bytes(), item.filename
            checked += 1
print(f"Verified {len(manifest['files'])} manifest files and {checked} original-source files.")
