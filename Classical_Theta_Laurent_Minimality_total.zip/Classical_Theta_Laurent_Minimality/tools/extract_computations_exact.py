#!/usr/bin/env python3
"""Extract verbatim historical code cells; this does not execute them."""
from pathlib import Path
import re
root = Path(__file__).resolve().parent.parent
source = (root / "final_report/02_research_history.md").read_text(encoding="utf-8")
output = root / "computations"
output.mkdir(exist_ok=True)
fence = chr(96) * 3
pattern = re.compile(r"^"+fence+r"(wolfram|wl|javascript)[ \t]*\n([\s\S]*?)^"+fence+r"[ \t]*$", re.MULTILINE)
count = 0
for count, match in enumerate(pattern.finditer(source), 1):
    lang, body = match.groups()
    suffix = "js" if lang == "javascript" else "wl"
    path = output / f"{count:03d}_code.{suffix}"
    if path.exists() and path.read_text(encoding="utf-8") != body:
        raise RuntimeError(f"Refusing to overwrite changed cell: {path}")
    path.write_text(body, encoding="utf-8")
print(f"Extracted or verified {count} cells.")
