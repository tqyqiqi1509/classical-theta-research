# A full-dimensional family of nonperiodic infinite-support certificates

Branch: `/root/pump_novelty_finite_interface`. Work began 2026-11-14 03:23 UTC. Classical principal-coefficient cluster theta functions only. No Li–Pan/Li Fang conclusion is used.

## 1. Outcome and exact scope

The main new mathematical output of this branch is an explicit **full-dimensional rational cone of labels**, for each integer m≥4, on which initial-wall broken lines prove infinite support. Unlike the earlier periodic pump, the mutable exponent grows under a nontrivial linear transformation and does not return after a period. The proof is a finite rational certificate: two invariant cones, signs of normal coordinates, and signs of 45 explicitly recorded polynomials. Each polynomial is strictly positive for m>3 because its expansion in t=m−3 has nonnegative integer coefficients and is nonzero. Independent SymPy and Wolfram evaluations verify those exact algebraic identities.

This is not a solution of general Laurent finiteness. The finite-label mechanisms examined below remain old consequences or require an additional theorem. Priority is also qualified: maximal-bend unfolding and rank-two monodromy belong to Mandel/GHK. The precise principal-coefficient label cone and finite certificate have not been located in the original sources checked here; that is a bounded novelty finding, not a global priority guarantee.

The abstract arbitrary-word theorem is being independently written and checked by `/root/growing_bend_mechanism`. The concrete proof below includes the necessary definitions so it can also be read independently.

## 2. Initial-wall unfolding

Let B be skew-symmetric and use the column convention z_i=y_i x^(Be_i). At an initial wall H_i={q_i=0}, suppose the incoming mutable exponent m has m_i<0. Its maximal legal binomial bend has multiplicity −m_i and changes the exponent to

    T_i m,       T_i=I−Be_i e_i^T.

The shear T_i fixes H_i pointwise, has determinant one, and is integral. Consequently a path using only these maximal bends becomes a single straight line when its successive segments are unfolded by inverse products of the T_i. Additional scattering walls may be crossed with the constant term; they do not change this construction.

For a fixed word i_1,…,i_l, put S_0=I, S_j=T_(i_j)…T_(i_1), S=S_l, and let l_j=e_(i_j)^T S_(j−1). If the word is repeated N times, its successive mutable exponents are S_j S^r g. The selected multiplicity in period r at wall j is

    r_(r,j)=−l_j S^r g.

For endpoint Q, the unfolded endpoint is S^(−N)Q. The backward time of the selected crossing is

    s_(r,j)=− l_j S^(r−N)Q / (l_j S^r g).

Thus the prescribed forward word is geometrically valid exactly when its listed backward times are strictly decreasing and positive. Two consecutive crossings in the same period are ordered if

    phi_j(v,w)=l_j(v) l_(j+1)(w)−l_j(w) l_(j+1)(v)>0,

where v=S^r g and w=S^(r−N)Q, provided all the relevant denominators are negative. Across periods the corresponding form is

    psi(v,u)=l_l(v) l_1(u)−l_l(S^(−1)u) l_1(Sv)>0.

Here u=S^(r+1−N)Q. In particular, one does **not** require the backward position cone to contain Q itself; it is enough to put S^(−1)Q in that cone. This endpoint distinction matters.

## 3. A uniform family of cones

Take an arbitrary integer m≥4 and

    B=m [[0,1,−1],[−1,0,1],[1,−1,0]],

with word (1,2,3). The three normal rows and the full shear product are

    L=[l_1;l_2;l_3]=[[1,0,0],[m,1,0],[m²−m,m,1]],

    S=[[ (m−1)(m²−m−1),  m(m−1),       m],
       [−m(m²−m−1),       1−m²,       −m],
       [ m(m−1),          m,           1]].

Set R=S^(−1), H=m²(m−3), and

    g0=(−1,m−1,−1),    v=(−1,1,0),    v1=(S−I)v.

The momentum generator matrix is V=[g0,v,v1]. Define the closed rational cone

    D_m=V R_(≥0)^3.

It has full dimension because det V=−m(m−3)(m−2)≠0. Direct multiplication gives

    Sg0=g0,
    Sv=v+v1,
    Sv1=H v+(H+1)v1.

Thus S preserves D_m. Every entry of LV is strictly negative for m≥4. Hence for every nonzero g∈D_m, every selected multiplicity −l_j S^r g is strictly positive. If g is integral, all these multiplicities are positive integers.

For positions, put Q0=(1,1,1), w0=RQ0,

    w1=(R−I)w0,    w2=(R−I)^2w0,
    W=[w0,w1,w2],  E_m=W R_(≥0)^3.

The determinant is det W=3m^5(m−2)>0. The characteristic polynomial

    det(lambda I−S)=(lambda−1)(lambda²−(H+2)lambda+1)

implies

    Rw0=w0+w1,
    Rw1=w1+w2,
    Rw2=H w1+(H+1)w2.

Therefore R preserves E_m and its interior. Every entry of LW is strictly positive for m≥4.

### 3.1 Exact sign certificate

For j=1,2 form the 3×3 matrices

    P_j=V^T(l_j^T l_(j+1)−l_(j+1)^T l_j)W.

For crossings between periods use

    P_3=V^T(l_3^T l_1−(l_1 S)^T(l_3 R))W.

Every entry of P_1,P_2,P_3 is strictly positive for m≥4. Together with −LV and LW this is a list of 45 strictly positive polynomials. Their exact coefficients after m=t+3 are supplied in `verify_uniform_growing_cones.json`; no floating point test is involved. The accompanying program asserts for each entry that every coefficient is a nonnegative integer and at least one is positive. Since t>0, this proves the required inequalities for the entire parameter range. It also verifies SV=VA and RW=WC exactly, with

    A=[[1,0,0],[0,1,H],[0,1,H+1]],
    C=[[1,0,0],[1,1,H],[0,1,H+1]].

For example, the negative itinerary matrix is

    −LV=[[1,1,m(m²−3m+1)],
         [1,m−1,m(m³−4m²+3m+1)],
         [1,m(m−2),m(m−2)(m³−3m²+1)]].

The low-degree factors are transparent after t=m−3, e.g. m²−3m+1=t²+3t+1 and m³−4m²+3m+1=t³+5t²+6t+1. The data file includes the remaining higher-degree expansions rather than omitting them behind a numerical claim.

### 3.2 A positive endpoint and genericity

The vector w0 lies on the boundary of E_m, and S w0=Q0 is strictly positive. Since S is invertible, for sufficiently small positive epsilon,

    w=w0+epsilon sqrt(2) w1+epsilon² sqrt(3) w2

is in the interior of E_m and Q=S w is strictly positive. This can be made explicit: let A0=max_i |(S w1)_i|, B0=max_i |(S w2)_i|, and take

    epsilon=1/(1+2(A0+B0)).

Then each coordinate of Q differs from the corresponding coordinate of Q0 by less than one. The coordinates of Q are rationally linearly independent: the three coefficients 1, epsilon sqrt(2), epsilon² sqrt(3) are rationally independent and the matrix SW is invertible over Q.

For any fixed integral g and any finite word length, the chosen bend positions depend rationally and linearly on Q and have rank two onto their designated coordinate planes. The adjacent projections are isomorphisms between those planes because the incoming and outgoing selected normal coordinates are nonzero. Meeting a rational joint, or lying within an unintended rational wall, imposes a proper rational linear condition on Q. Rational independence excludes all those conditions simultaneously, including for every N and for the unbounded incoming segment. The argument is the same elementary linear algebra used in the independently audited periodic proof; it does not require a limiting infinite broken line.

## 4. Infinite-support theorem

**Theorem.** For every m≥4 and every nonzero integral g∈D_m, define

    p_N=sum_(r=0)^(N−1) sum_(j=1)^3 (−l_j S^r g)e_j.

Then the classical principal theta function satisfies

    a_g(p_N)≥1       for every N≥1.

Moreover g+Bp_N=S^N g, and all three coordinates of p_(N+1)−p_N are strictly positive. Thus the root degrees p_N are pairwise distinct and theta_g has infinite Laurent support.

**Proof.** Let w=S^(−1)Q be the interior point constructed above. For period r of an N-period word, v=S^r g belongs to D_m and the position argument S^(r−N)Q=R^(N−r−1)w belongs to E_m. The signs of LV and LW make every selected crossing time positive. The positive matrices P_1 and P_2 order crossings within a period. For any crossing between two periods the second position argument u lies in E_m and P_3 gives the strict ordering across that boundary. All selected crossing times are therefore ordered as required. Unfolding and folding constructs a genuine finite broken line; extend its first segment to infinity.

At every designated crossing take the highest term of (1+z_i)^(−m_i), whose coefficient is one. At all other walls take the constant term. The positive representative of the cluster scattering diagram prevents cancellation. The full principal path is obtained by integrating the accumulated frozen components backward from a chosen full endpoint; the reduced wall incidences do not change. For each p_N only finitely many walls are relevant. Hence the contribution is a valid coefficientwise contribution in the full formal theta series. The identity g+Bp_N=S^N g follows by telescoping the individual exponent changes. Strictly increasing positive degrees prove the claim. □

### 4.1 A particularly simple new label family

The label

    g=g0+v=(−2,m,−1)

lies in D_m and gives a nonperiodic word. Its kernel grading is g_1+g_2+g_3=m−3>0, so it is outside im B. It cannot be obtained merely by componentwise domination by any positive multiple of the old same-seed label g0: the third coordinate requires a multiplier ≤1, whereas the second requires a multiplier ≥m/(m−1)>1.

This comparison excludes **that particular older domination corollary**; it does not prove independence from all mutated certificates or all results in the literature.

For m=4, the first three degrees are

    p_1=(2,4,9),
    p_2=(24,60,154),
    p_3=(402,1048,2739).

These numbers are regenerated and checked against g+Bp_N=S^N g in the exact data file; they are illustrative consequences, not the basis of the theorem.

### 4.2 The boundary m=3: quadratic nonperiodic growth

The independent arbitrary-word reviewer observed that the same mechanism also gives a useful boundary statement. At m=3, V loses rank because v1=3g0, but W remains invertible. The cone D_3=cone(g0,v) is two-dimensional. The sign matrices −LV and LW remain nonnegative; every required itinerary row and every row of each time-order matrix has at least one positive entry on the position generators. Thus a nonzero momentum in D_3 and a position in the interior of E_3 still give strict inequalities. Invariance is Sg0=g0 and Sv=v+3g0. No full-dimensional momentum cone is needed for genericity: only the position cone must have an open set of endpoint choices.

For the integral label g=g0+v=(−2,3,−1), one obtains

    S^N g=g+3N g0,
    p_N=(N(3N+1)/2, 3N(N+1)/2, N(3N+5)/2),
    a_g(p_N)≥1.

This boundary family lies in im B, so its nonregularity is not independent of the older zero-grading geometric obstruction. The explicit quadratic degree certificate is the additional content. The abstract reviewer also supplies a finite Boolean support-orbit test for the nonstrict generator conditions; no limiting epsilon argument in the momentum cone is necessary.

## 5. Independent calculation and remaining proof review

`verify_uniform_growing_cones.py` independently checks all displayed matrix identities, the 45 all-parameter positivity witnesses, and actual rational backward flight computations for m=4,…,16 and N=1,2,3,5,10,20. These finite flights calibrate indexing and sign conventions only. The general theorem follows from the exact cone identities.

`uniform_growth_wolfram_receipt.json` records a separate Wolfram evaluation: both matrix identity residuals are zero, the two determinants are as above, and all 45 shifted polynomials have the stated nonnegative/nonzero coefficient property. The arbitrary-word branch is separately auditing the crossing-time formula and certificate conditions.

The full principal lift, positive representative, and joint argument are shared foundational interfaces with the periodic certificate. They must remain in the final proof rather than being replaced by the bare observation that an exponent orbit grows.

## 6. Literature audit and novelty boundary

### Mandel, Classification of Rank 2 Cluster Varieties

Primary original: https://arxiv.org/pdf/1407.6241 ; published version https://sigma-journal.com/2019/042/ . Checked §3.3, §3.4–3.6, Theorems 4.1–4.3, Proposition 4.6, and Remark 2.18. Matrix rank two includes the present 3×3 cyclic matrices. Maximal-bend unfolding, monodromy, and negative/semidefinite infinite winding are prior mechanisms. The paper's surface tropicalization is the image of p*, and its principal coefficient theta series are not its object of study. Remark 2.18 discusses a Cox-ring interpretation but supplies no explicit all-degree theta coefficient certificate for the off-image label cone above. No claim of newly discovering monodromy is justified.

### Mandel, Tropical Theta Functions and Log Calabi–Yau Surfaces

Primary original: https://arxiv.org/pdf/1407.5901 (v2, 2016). Checked introduction, §3.5–3.6 descriptions, §4.3, Remark 4.21, Proposition 5.15, and §6 coefficient extraction. Its main theta/polar-polytope results assume positive surfaces. Remark 4.21 explains the absence of nontrivial tropical functions in negative definite cases and the semidefinite behavior. It does not provide a principal-coefficient all-degree formula for arbitrary off-surface labels. Its valuations and line-bundle sections cannot be transferred to every signed principal label without another argument.

### Akagi–Chen 2603.16326v2 — 2026, limited review

Primary PDF https://arxiv.org/pdf/2603.16326 , version date 2026-06-08. Read the precise statements of Theorems 4.12 and 10.11 and their definitions in the surrounding sections; the full 59-page proof was **not** independently checked. They bound the rank-three cluster-cyclic G-fan by quadratic cones and give a uniform bound under a minimum hypothesis. This could distinguish the known convex hull of cluster g-cones from other regular labels. It is not used in the theorem above or as a regular-theta classification. Status: potentially useful interface, not an accepted new theorem dependency.

### Qin 2407.03186v1 — valid freezing, invalid inverse inference

Primary original https://arxiv.org/html/2407.03186v1 . Proposition 6.19 proves that a sufficiently large positive coordinate shift freezes that coordinate of an **already Laurent-finite** theta function. Its proof first bounds a finite support and then applies positivity. The result cannot be inverted to deduce finiteness of a signed label from its frozen restriction. Theorem 6.18 is presented under injective-reachability and must not be read without that hypothesis.

### Other current leads not used

Chang–Quan Yu Tang 2609.11200 was searched/opened, but its primary full text was unavailable in this branch. Its abstract-level Jacobi-finiteness obstruction was not used. Fei's tropical F-polynomial/Newton literature was queried; no theorem was accepted from abstracts or aggregator pages. CMMM 2505.09585v2 finite-infimum restrictions and GHKK 1411.1394v2 saturation/convex-cluster-cone results were inherited only after root's original-source checks and are not claimed as new here.

## 7. Finite-label routes: what was actually proved or remains missing

1. **Saturation and products of finite theta functions.** GHKK already proves addition and saturation of the finite label set. Turning a finite decomposition r g=sum g_i into a Minkowski support bound is useful computationally but is not a new general mechanism.

2. **Positive derivative inheritance.** From the third-round positive derivative identity and a_g(r)>0, finiteness of theta_g implies finiteness of theta_(g+(I+B)r), with support contained in {p:p+r belongs to Supp F_g}. This is a direct old-result corollary, not a new theorem. The unresolved question is whether products, saturation, derivatives, and mutation generate all finite labels. No proof or counterexample was obtained in this branch.

3. **Inverse freezing.** A proposed criterion tried to bound new walls from a finite frozen theta. Qin's argument needs the original full support before it supplies its shift threshold. Replacing the finite-support inequality by a uniform inequality over all potential roots is the missing step. This route is not proved and is not used.

4. **Relative Hall support.** Read the old package's exact two-sided projective/injective Hall recursion and finite-determinacy lemma. The former is valid for actual finite modules and descends dimension; it is not indexed only by g. The latter explicitly assumes polynomial theta functions and a theta support box. It cannot be used to establish those hypotheses. A relative signed-framing comparison preserving generic parameter support is still required. No such comparison was manufactured from ordinary numerical scattering.

5. **Nonperiodic unfolding.** Began after root identified the gap between periodic kernel cycles and growing mutable exponents. The useful state is a pair of rational cones controlling exponent signs and unfolded crossing times. Initial tests found m=4, g=(−2,4,−1); those tests were then replaced by the all-m cone proof in §§2–4. This is a general mechanism for infinite certificates, not a finite-side solution.

The branch should now be rotated to researchers attacking the remaining finite Laurent and minimality gaps. More low-dimensional samples are not needed to validate the uniform cone theorem.
