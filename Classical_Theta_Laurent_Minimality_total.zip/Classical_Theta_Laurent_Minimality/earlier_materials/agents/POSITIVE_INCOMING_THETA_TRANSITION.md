# 正 incoming 添加到原 theta 的非负转换

日期：2026-11-14，04:38 UTC。范围：经典、主系数、斜对称及斜可对称化丛代数。

**结论已经闭合，但依赖应明确归属。** 由上一轮已审核的一方向正切片，以及本轮的正 incoming 秩扩张识别，可以得到逐项非负的原 theta 展开。证明不是从 Laurent 系数支配逆推出 theta 正性。真正需要补上的步骤是多方向同时切片：中间产生的尚未删除方向的 root 次数必须从下一次切片高度中扣除。这个扣除恰好消去相应的标签修正。

有限的变形 theta 得到有限、正的原 theta 展开，且其中出现的原 theta 全部有限。形式情形得到按主系数次数完备的正转换。**不由此断言两个有限族在同一个多项式系数环上都是基，也不由此给任意标签一个新的无条件停机界。**

## 1. 约定与输入归属

对一个经典交换矩阵 \(B\)，固定初始正腔，记

\[
 z_i=y_i x^{Be_i},\qquad
 \theta^B_h(x,y)=x^hF^B_h(z),\qquad F^B_h(0)=1.
 \tag{1.1}
\]

这里 \(y_i\) 是**主系数冻结变量**，\(z_i\) 是 **root monomial**。在 \(F\) 公式中的 \(z^s\)，转换回 theta 公式后变成 \(y^s\theta_{g+Bs}\)，不能把两种变量混用。

本证明使用的旧输入为

history/round3/Classical_Theta_Construction/agents/positive_shear_fresh_review/FORMAL_SHEAR_AND_POSITIVE_SLICES.md §4，及其独立审核文件。

对矩阵 \(C\)、标签 \(G\)、删除方向 \(i\)，令 \(L=[m]\setminus\{i\}\)。该旧结论为

\[
 [Z_i^k]F^C_G
 =\sum_{v\in\mathbb N^L}b^C_{G;i}(k;v)Z_L^v
 F^{C_{LL}}_{G_L+C_{Li}k+C_{LL}v},
 \qquad b^C_{G;i}(k;v)\in\mathbb N.
 \tag{1.2}
\]

等式在 root 完备环中逐系数成立。其正性依据是正冻结后的每个主系数 sector 在旧 scattering atlas 中都正，再使用 Mandel 的系数检测器；不是仅在初始 Laurent chart 中正。固定 sector 有旧 root 次数下界，所以三角展开及检测器可以按每个有限阶使用，无需先假设 \(F_G^C\) 有限。Qin 的冻结商图与 Mandel 的原子性都是既有文献机制，不能计为本轮发现。

本轮正 incoming 的秩扩张识别见同目录 POSITIVE_INCOMING_DOMINATION.md §§2–3、6。其 restriction、radical quotient 与正 scattering 输入归 Davison–Mandel/GHKK。本文在这个已审核识别之后证明正 theta 转换，并把所有被冻结的幂写出。

## 2. 一般同时切片定理

设 \(C\) 是任意经典斜可对称化交换矩阵，指标分拆为 \(J\sqcup S\)，\(G\in\mathbb Z^{J\sqcup S}\)。对每个 \(r\in\mathbb N^S\)，存在唯一的整数

\[
 d^C_{G;S}(r,q)\ge0,\qquad q\in\mathbb N^J,
\]

使

\[
 \boxed{
 [Z_S^r]F^C_G(Z_J,Z_S)
 =\sum_{q\ge0}d^C_{G;S}(r,q)Z_J^q
 F^{C_{JJ}}_{G_J+C_{JS}r+C_{JJ}q}(Z_J).
 }
 \tag{2.1}
\]

它与删除 \(S\) 的顺序无关；每个固定系数只涉及有限多个求和项。

### 2.1 归纳时的完整次数记账

取 \(i\in S\)，\(T=S\setminus\{i\}\)。先对 \(i\) 使用 (1.2)，把其余方向的 branching offset 写成 \((v,w)\in\mathbb N^J\times\mathbb N^T\)：

\[
 [Z_i^{r_i}]F_G^C
 =\sum_{v,w\ge0}b^C_{G;i}(r_i;(v,w))Z_J^vZ_T^w
 F^{C_{J\cup T,J\cup T}}_{H(v,w)},
 \tag{2.2}
\]

其中

\[
 H(v,w)=G_{J\cup T}+C_{J\cup T,i}r_i
       +C_{J\cup T,J}v+C_{J\cup T,T}w.
 \tag{2.3}
\]

现在从整个右端提取 \(Z_T^{r_T}\)。只有 \(0\le w\le r_T\) 能贡献，而且对内部 \(F_H\) 应当提取的次数是 **\(r_T-w\)**。归纳假设给出

\[
 [Z_T^{r_T-w}]F_H
 =\sum_{u\ge0}d^{C_{\bar i\bar i}}_{H;T}(r_T-w,u)Z_J^u
 F^{C_{JJ}}_{H_J+C_{JT}(r_T-w)+C_{JJ}u}.
 \tag{2.4}
\]

由 (2.3)，最终标签为

\[
\begin{aligned}
 H_J+C_{JT}(r_T-w)+C_{JJ}u
 &=G_J+C_{Ji}r_i+C_{JJ}v+C_{JT}w\\
 &\quad+C_{JT}r_T-C_{JT}w+C_{JJ}u\\
 &=G_J+C_{JS}r+C_{JJ}(v+u).
\end{aligned}
 \tag{2.5}
\]

这给出明确的有限正卷积：

\[
 d^C_{G;S}(r,q)=
 \sum_{\substack{0\le w\le r_T\\0\le v\le q}}
 b^C_{G;i}(r_i;(v,w))
 d^{C_{\bar i\bar i}}_{H(v,w);T}(r_T-w,q-v).
 \tag{2.6}
\]

每个和均有限，每个因子非负，故所得 \(d\ge0\)。这也表明，直接把第二次切片仍取在 \(r_T\) 会产生错误的标签与次数；中间的 \(w\) 不能被丢掉。

### 2.2 唯一性、零次项与可计算性

每个 \(F_h^{C_{JJ}}\) 的常数项都是 1。按总次数及其任一细化序对 \(q\) 作三角消元，(2.1) 的 \(d\) 唯一。因此不同删除次序给出同一组 \(d\)。特别地

\[
 d^C_{G;S}(r,0)=[Z_S^rZ_J^0]F_G^C,
 \qquad d^C_{G;S}(0,q)=\begin{cases}1&q=0,\\0&q\ne0.\end{cases}
 \tag{2.7}
\]

第二式是零 root 次数冻结，不能错误地推广成所有 \(r\) 都只有 \(q=0\)。

对给定 \(r,q\)，由已知 theta 系数的有限计算可以求

\[
 d(r,q)=a_G^C(q,r)
 -\sum_{\substack{v\le q\\v\ne q}}d(r,v)
 a^{C_{JJ}}_{G_J+C_{JS}r+C_{JJ}v}(q-v).
 \tag{2.8}
\]

(2.8) 是一个有效的有限系数算法。其非负性由 (2.6) 证明；单靠三角相减本身不能证明正性。这个算法仍不自行判断还有多少个非零 \(r,q\)。

## 3. 冻结变量的完整幂次

把 \(C_{JJ}=B\)，环境的 mutable 变量记为 \(X=(x,\xi)\)，主系数为 \(Y=(y,\eta)\)。环境 root 单项式满足

\[
 Z_J^p=y^p x^{Bp}\xi^{C_{SJ}p},\qquad
 Z_S^r=\eta^r x^{C_{JS}r}\xi^{C_{SS}r}.
 \tag{3.1}
\]

将 (2.1) 乘回 \(X^G\)，得到冻结 \(S\) 后尚未作任何特化的等式

\[
 \boxed{
 \Theta_G^C(X,Y)=\sum_{r,q}d^C_{G;S}(r,q)\,
 \eta^r y^q\xi^{G_S+C_{SJ}q+C_{SS}r}
 \theta^B_{h(r,q)}\bigl(x;\widehat y\bigr),
 }
 \tag{3.2}
\]

其中

\[
 h(r,q)=G_J+C_{JS}r+Bq,\qquad
 \widehat y_j=y_j\xi^{C_{Sj}}.
 \tag{3.3}
\]

式 (3.2) 中 \(\theta^B(x;\widehat y)\) 的 root 变量正是 \(Z_J\)。既没有遗漏 \(\xi^{C_{SS}r}\)，也没有重复计入 \(Z_J^q\) 的冻结因子。即使某些 \(\xi\) 幂为负，式子也在相应冻结 Laurent 环中成立。

## 4. 应用于添加正 incoming 的秩扩张

先令 \(B\) 斜对称。给定非零的非负整数列 \(a_1,\ldots,a_s\)，记

\[
 U=[a_1\ \cdots\ a_s],\quad A=[I_n\ U],\quad
 \widetilde B=A^TBA,\quad G=A^Tg.
 \tag{4.1}
\]

添加 incoming automorphism

\[
 x^m\longmapsto x^m(1+t_jz^{a_j})^{\pm\langle a_j,m\rangle}
 \tag{4.2}
\]

并取一致 outgoing completion，记其 theta 为 \(\theta_g^{\mathcal D(t)}\)。若 \(a_j\) 非本原，(4.2) 本身规定重数。此处墙函数使用 root 单项式 \(z^{a_j}=y^{a_j}x^{Ba_j}\)。

秩扩张识别是

\[
 F_g^{\mathcal D(t)}(z)=F_G^{\widetilde B}
 \bigl(z_1,\ldots,z_n,t_1z^{a_1},\ldots,t_sz^{a_s}\bigr).
 \tag{4.3}
\]

其有限纤维理由是 \(A\) 每列非零且非负。对于固定旧 root 次数 \(p\)，\(Ap'=p\) 只可能有有限个 \(p'\ge0\)。这一识别来自同目录前述报告中的 saturated restriction 与 radical quotient，不是从投影图形直觉推出。

对 \(\widetilde B\) 同时删除全部附加方向 \(S\)，注意

\[
 \widetilde B_{JJ}=B,\quad \widetilde B_{JS}=BU,\quad G_J=g.
\]

(2.1) 和 (4.3) 立即给出所需公式：

\[
 \boxed{
 F_g^{\mathcal D(t)}(z)
 =\sum_{r\in\mathbb N^s,\ q\in\mathbb N^n}
 d_{g;r,q}\,t^r z^{Ur+q}
 F^B_{g+B(Ur+q)}(z),\qquad d_{g;r,q}\in\mathbb N,
 }
 \tag{4.4}
\]

等价地

\[
 \boxed{
 \theta_g^{\mathcal D(t)}(x,y)
 =\sum_{r,q}d_{g;r,q}\,t^r y^{Ur+q}
 \theta^B_{g+B(Ur+q)}(x,y).
 }
 \tag{4.5}
\]

这里 \(d_{g;r,q}=d^{\widetilde B}_{G;S}(r,q)\)，且 \(d_{g;0,0}=1\)、\(d_{g;0,q}=0\) 对 \(q\ne0\)。因此变形 theta 减去原 theta 在**原 theta 正锥**中，而不止在初始 Laurent 正锥中。

### 4.1 从全冻结公式检查特化

在 (3.2) 中令 \(\xi=1\)、\(\eta_j=t_jy^{a_j}\)。此时 \(Z_J=z\)，\(Z_{n+j}=t_jz^{a_j}\)，环境的前因子 \(X^G\) 变成 \(x^g\)，完整冻结因子恰好变成 \(t^r y^{Ur+q}\)。这逐项给出 (4.5)，不需要设定任何丢失冻结次数的辅助等式。

### 4.2 斜可对称化版本

令 \(D=\operatorname{diag}(d_i)\) 满足 \(DB\) 斜对称。取

\[
 \widetilde D=\operatorname{diag}(D,1,\ldots,1),\quad
 K=\widetilde D^{-1}A^TD,\quad
 \widetilde B=KBA,\quad G=Kg.
 \tag{4.6}
\]

这些数据全为整数，\(K\) 的前 \(n\) 行为 \(I_n\)，\(\widetilde D\widetilde B=A^TDBA\) 斜对称。附加墙的指数相应为 \(\pm\langle a_j,Dm\rangle\)。于是 (4.3)–(4.5) 原样成立。

还有一个有用的全幂次相容性检查：令 \(h=g+B(Ur+q)\)，则

\[
 G_S+\widetilde B_{SJ}q+\widetilde B_{SS}r=K_Sh.
 \tag{4.7}
\]

也就是说，(3.2) 中每个项的完整 mutable leading exponent 仍为 \(Kh\)，属于秩扩张 restriction 使用的饱和子格。附加方向取 \(\delta_j\mid\gcd(Da_j)\) 时只需把 \(\widetilde D\) 的相应对角元改成 \(\delta_j\)；新墙指数除以 \(\delta_j\)。本文计算固定 \(\delta_j=1\)。

## 5. 形式相容性与有限结论

### 5.1 每个系数均是有限和

在 (4.4) 中，要对给定旧 root 次数 \(p\) 有贡献，必须

\[
 Ur+q\le p.
\]

每个 \(a_j\) 非零且非负，因此

\[
 |r|+|q|\le|Ur+q|\le|p|.
 \tag{5.1}
\]

所以只有有限个 \((r,q)\)；每个内部 theta 的系数也在有限 root 阶确定。故 (4.4) 在 \(\mathbb Z[t][[z]]\) 中成立，\(t=0\) 和 \(t=1\) 都可逐系数合法特化。不存在先选一个足够大截断、再未经证明地把它当作全阶的步骤。

设 \(s=Ur+q\)。在 \(t=1\) 时也可写成

\[
 \theta_g^{\mathcal D(1)}
 =\sum_{s\ge0}c_{g;s}y^s\theta^B_{g+Bs},\qquad
 c_{g;s}=\sum_{Ur+q=s}d_{g;r,q}\in\mathbb N,
 \tag{5.2}
\]

其中 \(c_{g;0}=1\)。若 \(B\) 有核，不同 \(s\) 可以给出同一个 mutable 标签 \(g+Bs\)；主系数 \(y^s\) 必须保留，不能据此合并掉主系数次数。

### 5.2 已知变形 theta 有限时的真正有限正展开

假设 \(P=F_g^{\mathcal D(1)}\in\mathbb N[z]\) 已由独立依据证明有限，记 \(T=\operatorname{Supp}P\)。若 \(d_{g;r,q}>0\)，内部 theta 的常数项 1 给出

\[
 Ur+q\in T,
 \qquad Ur+q+\operatorname{Supp}F^B_{g+B(Ur+q)}\subseteq T.
 \tag{5.3}
\]

这是利用 (4.4) 的无抵消性。由于 \(T\) 有限且 \(Ur+q=s\) 的纤维有限，只有有限个非零 \(d_{g;r,q}\)，每个出现的原 theta 都有有限 Laurent 展开。于是 (4.5) 是有限正转换，且在 \(t\) 中也是多项式。

若已知包含 \(T\) 的有限盒 \(0\le p\le H\)，只需检查 \(Ur+q\le H\)；(2.8) 提供明确有限求值步骤。这里的全局盒必须来自实际的有限性证明或完整输入多项式，不能从一次计算没有再出现项来猜测。

在有限情形，正性还给出精确的 Newton 分解

\[
 \operatorname{Newt}P
 =\operatorname{conv}\!\bigcup_{d_{g;r,q}>0}
 \left(Ur+q+\operatorname{Newt}F^B_{g+B(Ur+q)}\right).
 \tag{5.4}
\]

这是正转换的直接结果，不是关于格点饱和、整数分解性或多面体基的新断言。

### 5.3 “换基”应使用的精确含义

所有行在正主系数次数过滤下是恒等加严格高次项，所以在相应完备自由模中给出一个正的、形式可逆的转换矩阵。逆矩阵由过滤级数求出，通常含负系数或无穷项。

有限行结论只说明 \(\theta_g^{\mathcal D(1)}\) 属于原有限 theta 的 \(\mathbb Z[y]\)-正张成。它不自动证明变形后的有限族张成同一个未经完备的 \(\mathbb Z[y]\)-模。比如中央附加法向 \(a\in\ker B\cap\mathbb N^n\) 可使某行变为

\[
 \theta_g^{\mathcal D(1)}=(1+y^a)^k\theta_g^B\quad(k>0).
\]

\((1+y^a)^k\) 不是 \(\mathbb Z[y]\) 的单位。要称两个有限族是同一多项式系数模的两组基，仍须额外证明张成或指定合适局部化。这不影响上面的每行有限正展开、形式正换基以及支持界。

## 6. 精确计算核验

脚本：positive_incoming_theta_transition_check.py。

完整记录：positive_incoming_theta_transition_check.json。

结果：**PASS**。6 组切片测试检查 **182 个同时切片系数**；同时切片的唯一三角展开与两个相反删除次序完全一致。另有 3 组具有独立有限性依据的完整多项式恒等式，共 **59 个正 theta 转换项、419 个带参数 root 单项式恒等式**。

| 完整恒等式 | 附加法向 | 环境完整支持盒 | 正转换项 | 带参数单项式 |
|---|---|---|---:|---:|
| \(B=\left(\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\right),g=(-1,-1)\) | \((1,1)\) | \((1,5,3)\) | 6 | 27 |
| 同上 | \((1,1),(1,2)\) | \((1,13,3,8)\) | 44 | 318 |
| \(B=\left(\begin{smallmatrix}0&1\\-2&0\end{smallmatrix}\right),D=(2,1),g=(-1,-1)\) | \((1,1)\) | \((1,13,5)\) | 9 | 74 |

这些环境矩阵都是无环的，且环境标签 \(G\le0\)。完整环境多项式由有证明的无环有序初始墙二项式乘积算出。每个原 theta 的完整支持使用已知无环负单位正乘积界，再重建整条恒等式。普通 incoming 递归与直接 prescribed-incoming 递归还分别独立核对相应有限前缀。完整性并非由前缀截断猜得。

6 组切片测试另外覆盖非中央法向、两个附加方向、非负与负标签混合、赋值矩阵，以及三顶点有向圈的两个非中央附加法向。循环类只用于验证通用公式的有限系数，不声称已知其全支撑。

确实出现了 \(q\ne0\)，所以核验没有退化成只检验零 offset。例如第一行完整恒等式为

\[
\begin{aligned}
 \theta^{\mathcal D(t)}_{(-1,-1)}
 =&\ \theta^B_{(-1,-1)}
 +2t y_1y_2\theta^B_{(0,-2)}
 +3t y_1^2y_2\theta^B_{(0,-3)}\\
 &+t^2y_1^2y_2^2\theta^B_{(1,-3)}
 +3t^2y_1^3y_2^2\theta^B_{(1,-4)}
 +t^3y_1^4y_2^3\theta^B_{(2,-5)}.
\end{aligned}
\]

也确实出现了中间尚未删除方向的 \(w>0\)：双附加方向测试中先删除最后一个方向时，一方向切片含 \((v,w)=((0,0),1)\) 系数 5 和 \(((1,0),1)\) 系数 8；两种删除顺序仍得到同一最终 \(d\)。JSON 保存这些实际 witnesses。

Wolfram 精确核验保存于 positive_incoming_theta_transition_wolfram.json。它使用赋值、双附加方向矩阵，符号检查 (2.5) 的 \(w\) 消去、(4.7) 的完整冻结指数，以及旧主块不变，全部余项为 0。

## 7. 查新与审阅记录

本次限定审阅真正进入证明的原始来源，避免把归纳推广当作新正性定理。

| 来源 | 本次实际核查位置 | 结论与用途 | 新颖性处理 |
|---|---|---|---|
| [Mandel, arXiv:1605.03202v2](https://arxiv.org/pdf/1605.03202) | Theorem 1 及其证明，PDF pp.1–2 | scattering atlas 的形式正性给非负 theta 系数；系数在标签附近被检测 | 明确旧结果；不是本轮发明 |
| [Qin, arXiv:2407.03186v1](https://arxiv.org/pdf/2407.03186) | Lemma 5.1，§6.4，Proposition 6.19 | 冻结商图正确；6.19 明确先要求 theta 是 Laurent 多项式 | 只用冻结接口；不得由 6.19 逆推出未证有限性 |
| [Davison–Mandel, arXiv:1910.12915v3](https://arxiv.org/pdf/1910.12915) | Lemmas 2.11–2.12；Proposition 3.1；§3.3.5 Theorem 3.16 | restriction/quotient、pointed 完备基、逐阶原子性检测 | 这些机制已有文献优先权；本文仅取经典版本 |
| 上轮 FORMAL_SHEAR_AND_POSITIVE_SLICES.md §4 | 全节，连同独立审核 | 一方向正切片为本次明确前提 | 不能作为本轮新发现重复计数 |

本次无需要引入的 2026 年新文献，也未使用 LiFang/LiPan 的结论。本文新增的是针对当前 positive-incoming 接口的**同时切片记账、完整冻结幂次检查及明确的转换公式**。这些是上述既有机制的可验证推论；未完成广义历史优先权排查前，不应宣传为新的一般 theta 正性定理。

## 8. 路线结果与剩余任务

本次正向路线成功：正 incoming 的有限纤维扩张，加上正冻结切片，升级为旧 theta 正锥中的转换。被消除的实际疑点是反复删除时 \(q_{\rm extra}\) 的去向，以及主系数与 root monomial 的幂次区别。

两条不成立的捷径已排除：初始 Laurent 系数支配不能单独证明 theta 正转换；每一行有限正展开也不能自动证明两有限族是同一个多项式系数模的基。这个提醒不替代正向结果，(4.5) 的正转换已由 (2.6) 证明。

对于最初的一般有限性目标，下一步仍须提供一个可证明有限、并与目标图具有此正 incoming 关系的载体。本文没有用特殊计算替代那个类别层面的输入。若这样的载体已给出，(5.3) 立即把它升级为有限 Laurent 展开、有限正 theta 转换及明确支持界。
