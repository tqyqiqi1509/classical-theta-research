"""Exact postcheck for rational LP dual solutions returned by HiGHS."""
from fractions import Fraction

def certify(res,A,rhs,bounds,objective):
    """Check weak-duality lower bound with exact rational arithmetic.

    Convention: min c*x, A*x<=rhs, lower<=x<=upper.  No floating
    tolerance enters the final algebraic equalities or sign checks.
    """
    def rat(x):return Fraction(float(x)).limit_denominator(1000000)
    station=[Fraction(0) for _ in objective];value=Fraction(0)
    sparse_ineq=[];sparse_lo=[];sparse_hi=[]
    for i,v in enumerate(res.ineqlin.marginals):
        if not v:continue
        q=rat(v)
        if q>0:return {'verified':False,'reason':'wrong inequality-dual sign'}
        row=A.getrow(i)
        for j,a in zip(row.indices,row.data):station[j]+=q*int(a)
        value+=q*int(rhs[i]);sparse_ineq.append([i,str(q)])
    for j,(v,w) in enumerate(zip(res.lower.marginals,res.upper.marginals)):
        a=rat(v);b=rat(w)
        if a<0 or b>0:return {'verified':False,'reason':'wrong bound-dual sign'}
        station[j]+=a+b;lo,hi=bounds[j]
        value+=a*int(lo)+b*int(hi)
        if a:sparse_lo.append([j,str(a)])
        if b:sparse_hi.append([j,str(b)])
    if any(x!=rat(c) for x,c in zip(station,objective)):
        return {'verified':False,'reason':'dual stationarity failed'}
    return {'verified':True,'exact_lower_bound':str(value),'inequality_dual':sparse_ineq,'lower_dual':sparse_lo,'upper_dual':sparse_hi}
