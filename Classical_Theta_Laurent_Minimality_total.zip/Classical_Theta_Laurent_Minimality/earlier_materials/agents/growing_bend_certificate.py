#!/usr/bin/env python3
"""Exact finite certificates for repeated signed maximal initial-wall bends.

No scattering truncation is used as a substitute for the proof.  The validator
checks the rational cone certificate; finite trajectory checks are diagnostics.
All arithmetic in the validator is exact.  Run directly for the uniform cyclic
family, including the parabolic m=3 boundary.
"""
import json
from pathlib import Path
import sympy as sp


def nonnegative(A):
    return all(x.is_Rational and x >= 0 for x in A)


def positive(A):
    return all(x.is_Rational and x > 0 for x in A)


def word_data(B, word, signs=None):
    """Zero-based wall indices, signs = signs of incoming mutable coordinates."""
    B = sp.Matrix(B)
    n = B.rows
    assert B.cols == n and all(x.is_integer for x in B)
    assert all(B[i, i] == 0 for i in range(n))
    assert word
    signs = list(signs or [-1] * len(word))
    assert len(signs) == len(word) and all(s in (-1, 1) for s in signs)
    I, S, R, rows, prefixes = sp.eye(n), sp.eye(n), sp.zeros(n), [], [sp.eye(n)]
    for i, sign in zip(word, signs):
        assert 0 <= i < n
        e = I[:, i]
        row = e.T * S
        rows.append(row)
        R += sign * e * row
        S = (I + sign * B * e * e.T) * S
        prefixes.append(S)
    assert all(sp.expand(x) == 0 for x in B * R - S + I)
    assert sp.expand(S.det()) == 1
    forms = []
    for j in range(len(word) - 1):
        u, v = rows[j], rows[j + 1]
        forms.append(signs[j] * signs[j + 1] * (u.T * v - v.T * u))
    u, v = rows[-1], rows[0]
    cross = signs[-1] * signs[0] * (u.T * v - (v * S).T * (u * S.inv()))
    return dict(B=B, word=list(word), signs=signs, S=S, R=R,
                rows=rows, prefixes=prefixes, forms=forms, cross=cross)


def support_orbit(A, alpha, observables):
    """Prove h A^r alpha > 0 for every r by the finite Boolean support orbit.

    Each observable h is a nonnegative row.  A zero at the first failure gives
    an exact obstruction to this certificate, not a claim of theta finiteness.
    """
    assert nonnegative(A) and nonnegative(alpha)
    assert all(nonnegative(h) for h in observables)
    state = frozenset(i for i, x in enumerate(alpha) if x > 0)
    assert state
    seen, history = {}, []
    while state not in seen:
        seen[state] = len(history)
        history.append(sorted(state))
        for j, h in enumerate(observables):
            assert any(h[i] > 0 for i in state), (
                'strictness failure', len(history) - 1, j, sorted(state))
        state = frozenset(i for i in range(A.rows)
                          if any(A[i, j] > 0 for j in state))
        assert state, 'coefficient orbit vanished'
    return dict(states=history, preperiod=seen[state],
                period=len(history) - seen[state])


def validate_certificate(B, word, V, W, AD, AE, alpha, beta, signs=None,
                         symmetrizer=None):
    """Verify a finite signed-word certificate, allowing boundary momentum g.

    D=cone(V), E=cone(W).  V may have dependent columns. W must have full
    row rank. Required endpoint is Q=S W beta >0, NOT W beta >0.
    The optional symmetrizer verifies the exchange-matrix hypothesis.
    """
    dat = word_data(B, word, signs)
    B, S = dat['B'], dat['S']
    assert all(x.is_Integer for x in B)
    n = B.rows
    V, W, AD, AE, alpha, beta = map(sp.Matrix, (V, W, AD, AE, alpha, beta))
    assert V.rows == W.rows == n and W.rank() == n
    assert AD.shape == (V.cols, V.cols) and AE.shape == (W.cols, W.cols)
    assert alpha.shape == (V.cols, 1) and beta.shape == (W.cols, 1)
    assert nonnegative(AD) and nonnegative(AE)
    assert S * V == V * AD and S.inv() * W == W * AE
    assert nonnegative(alpha) and positive(beta)
    g = V * alpha
    assert any(g) and all(x.is_Integer for x in g)
    Q = S * W * beta
    assert positive(Q)
    if symmetrizer is None:
        assert B + B.T == sp.zeros(n), 'Supply symmetrizer for nonskew-symmetric B'
    else:
        d = sp.Matrix(symmetrizer)
        assert len(d) == n and positive(d)
        D = sp.diag(*d)
        assert D * B + B.T * D == sp.zeros(n)

    observables, table_minima = [], []
    for row, sign in zip(dat['rows'], dat['signs']):
        velocity = sign * row * V
        position = -sign * row * W
        assert nonnegative(velocity)
        assert nonnegative(position) and any(x > 0 for x in position)
        observables.append(velocity)
        table_minima.append(dict(velocity=str(min(velocity)),
                                 position=str(min(position))))
    time_tables = []
    for form in dat['forms'] + [dat['cross']]:
        table = V.T * form * W
        assert nonnegative(table)
        observables.append((table * sp.ones(W.cols, 1)).T)
        time_tables.append(table)
    orbit = support_orbit(AD, alpha, observables)
    dat.update(V=V, W=W, AD=AD, AE=AE, alpha=alpha, beta=beta,
               g=g, Q=Q, support_orbit=orbit, time_tables=time_tables,
               sign_minima=table_minima)
    return dat


def check_finite_trajectory(dat, N):
    """Independent rational flight-time and root-degree diagnostic."""
    assert N >= 1
    B, S, g, Q = (dat[k] for k in ('B', 'S', 'g', 'Q'))
    word, signs, rows = (dat[k] for k in ('word', 'signs', 'rows'))
    n, p, records = B.rows, sp.zeros(B.rows, 1), []
    w = S ** (-N) * Q
    previous_time = None
    for r in range(N):
        v = S ** r * g
        u = S ** r * w
        for j, (i, sign, row) in enumerate(zip(word, signs, rows)):
            incoming = dat['prefixes'][j] * v
            mult = sign * incoming[i]
            assert mult > 0 and mult.is_Integer
            time = -(row * u)[0] / (row * v)[0]
            assert time > 0
            if previous_time is not None:
                assert previous_time > time
            previous_time = time
            before = dat['prefixes'][j] * (u + time * v)
            after = dat['prefixes'][j + 1] * (u + time * v)
            assert before == after and before[i] == 0
            p[i] += mult
            records.append(dict(r=r, j=j, multiplicity=str(mult), time=str(time)))
    assert g + B * p == S ** N * g
    assert p == dat['R'] * sum((S ** r * g for r in range(N)), sp.zeros(n, 1))
    assert sum(p) >= N * len(word)
    return dict(N=N, degree=[str(x) for x in p],
                final_momentum=[str(x) for x in S ** N * g],
                first_time=records[0]['time'], last_time=records[-1]['time'],
                bends=len(records))


def uniform_data(m):
    B = sp.Matrix([[0, m, -m], [-m, 0, m], [m, -m, 0]])
    dat = word_data(B, [0, 1, 2])
    I, S = sp.eye(3), dat['S']
    H = m ** 2 * (m - 3)
    g0, v = sp.Matrix([-1, m - 1, -1]), sp.Matrix([-1, 1, 0])
    V = sp.Matrix.hstack(g0, v, (S - I) * v)
    K = S.inv() - I
    w0 = S.inv() * sp.ones(3, 1)
    W = sp.Matrix.hstack(w0, K * w0, K * K * w0)
    AD = sp.Matrix([[1, 0, 0], [0, 1, H], [0, 1, H + 1]])
    AE = sp.Matrix([[1, 0, 0], [1, 1, H], [0, 1, H + 1]])
    alpha = sp.Matrix([1, 1, 0])
    return dict(B=B, word=[0, 1, 2], V=V, W=W, AD=AD, AE=AE, alpha=alpha)


def symbolic_family_check():
    m, t = sp.symbols('m t', integer=True, nonnegative=True)
    c = uniform_data(m)
    dat = word_data(c['B'], c['word'])
    S, V, W = dat['S'], c['V'], c['W']
    simplify_zero = lambda A: all(sp.expand(x) == 0 for x in A)
    assert simplify_zero(S * V - V * c['AD'])
    assert simplify_zero(S.inv() * W - W * c['AE'])
    assert sp.factor(W.det()) == 3 * m ** 5 * (m - 2)
    tables = []
    for row in dat['rows']:
        tables.extend([-row * V, row * W])
    times = [V.T * F * W for F in dat['forms'] + [dat['cross']]]
    tables.extend(times)
    polynomials = [sp.Poly(sp.expand(x).subs(m, t + 3), t)
                   for table in tables for x in table]
    assert all(all(coef >= 0 for coef in p.all_coeffs()) for p in polynomials)
    # Row sums strictly positive at t=0 imply strictness for all m>=3 when
    # position is interior.  Some individual generator pairs vanish at m=3.
    assert all(all(x > 0 for x in (-row * V).subs(m, 3)) for row in dat['rows'])
    assert all(all(x > 0 for x in (row * W).subs(m, 3)) for row in dat['rows'])
    assert all(all(x > 0 for x in (T * sp.ones(3, 1)).subs(m, 3)) for T in times)
    N = sp.symbols('N', integer=True, nonnegative=True)
    c3, S3 = uniform_data(3), word_data(uniform_data(3)['B'], [0, 1, 2])['S']
    g3 = c3['V'] * c3['alpha']
    g0 = sp.Matrix([-1, 2, -1])
    assert S3 * g0 == g0 and S3 * g3 == g3 + 3 * g0
    pN = sp.Matrix([N * (3 * N + 1) / 2,
                     3 * N * (N + 1) / 2,
                     N * (3 * N + 5) / 2])
    assert sp.simplify(c3['B'] * pN - 3 * N * g0) == sp.zeros(3, 1)
    R3 = word_data(c3['B'], [0, 1, 2])['R']
    assert sp.simplify(pN.subs(N, N + 1) - pN - R3 * (g3 + 3 * N * g0)) == sp.zeros(3, 1)
    return dict(parameter='all integers m>=3', shifted_polynomials=len(polynomials),
                nonnegative_coefficients=True, all_time_row_sums_positive_at_m3=True,
                det_W=str(sp.factor(W.det())),
                det_V=str(sp.factor(V.det())),
                m3_degree=[str(x) for x in pN],
                m3_momentum=[str(x) for x in g3 + 3 * N * g0])


def run():
    result = {'symbolic_family': symbolic_family_check(), 'instances': []}
    for m in (3, 4, 5, 8):
        c = uniform_data(m)
        S = word_data(c['B'], c['word'])['S']
        delta1, delta2 = S * c['W'][:, 1], S * c['W'][:, 2]
        bound = 1 + max(abs(x) for x in delta1) + max(abs(x) for x in delta2)
        epsilon = sp.Rational(1, 4 * bound)
        c['beta'] = sp.Matrix([1, epsilon, epsilon ** 2])
        dat = validate_certificate(**c)
        trajectories = [check_finite_trajectory(dat, N) for N in (1, 2, 4, 8, 16)]
        result['instances'].append(dict(m=m, g=[str(x) for x in dat['g']],
            epsilon=str(epsilon), Q=[str(x) for x in dat['Q']],
            support_orbit=dat['support_orbit'], trajectories=trajectories))
    out = Path(__file__).with_suffix('.json')
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'all exact checks passed',
                      'symbolic_family': result['symbolic_family'],
                      'instances': len(result['instances']),
                      'total_diagnostic_bends': sum(t['bends'] for c in result['instances']
                                                    for t in c['trajectories']),
                      'result': str(out)}, indent=2))


if __name__ == '__main__':
    run()
