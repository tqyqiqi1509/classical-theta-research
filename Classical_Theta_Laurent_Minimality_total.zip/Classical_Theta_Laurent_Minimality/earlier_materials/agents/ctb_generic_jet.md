# Generic finite-jet rigidity: recovery, independent check, and modular handoff

Branch: ctb_generic_jet. Date: 2026-11-14. This branch began with the finite-jet conjecture and then recovered the already completed 2026-10-31 general proof. **The generic CTB/theta rigidity mechanism is prior local work, not a new result of this run.** The current work verifies the relevant source interfaces and gives an executable diagnostic. Classical cluster algebras remain the final subject; quantum degree is an auxiliary proof device.

## 1. Result of the independent check

I found no fatal gap in the principal-coefficient proof of the recovered theorem under its explicit assumptions. The exact assumptions are:

- finite skew-symmetric mutable matrix and a compatible full-column-rank coefficient extension;
- frozen variables inverted;
- an injective-reachable seed, with actual injective cluster variables;
- Qin's formal triangular family, or an actual common triangular basis identified with it;
- actual basis and finite multiplication/theta expansions for the distant-product identity;
- classical multiplication coefficients nonnegative for the classical positive-transition conclusion.

The last condition is additional to common triangularity. Thus the recovered theorem proves the classical CTB-to-theta comparison for a **specified strongly positive CTB in that framework**, including the symmetric-Cartan Lie/word families for which positivity is independently known. It does not prove arbitrary classical strong-positive-basis minimality.

Source file reviewed:

    interfaces_history/Qin_theta_final_total_20261031_072647/
      Qin_theta_research/results/GENERAL_FINITE_WINDOW_THEOREM.md

The present check did not take its three previous “PASS” verdicts as evidence. I independently reconstructed the five-factor quantum phase and checked the external identifications below.

## 2. Exact original-source interfaces

### 2.1 Qin's standard family really is the family in the proof

Primary source: Fan Qin, arXiv:2508.12761v2, dated 30 September 2025.

- Assumption 2.11 defines injective reachability by a permutation of actual cluster variables whose mutable leading degrees are \(-e_i\).
- Section 6.1, the paragraph immediately preceding Lemma 6.2, defines the reduced normalized products
  \[
    I_g=[p*x(s)^{g_+}*x(s[1])^{g_-}],\qquad (g_+)_i(g_-)_i=0.
  \]
- The same paragraph explicitly chooses \(v^{-1}\mathbb Z[v^{-1}]\).
- Lemma 6.2 gives the unique bar-invariant formal family with corrections in that negative-degree ring.
- Definition 6.3 and the paragraph after it identify an actual triangular basis with this formal family.

Therefore the proof is not silently substituting the differently normalized BZ standard basis \(E_a\) for Qin's \(I_g\). That substitution would be unsafe: the BZ convention in the diagnostic program uses positive \(v\)-degree corrections in a different standard family.

Direct original URL:
https://arxiv.org/html/2508.12761v2

### 2.2 The normalized injective variables are negative-chamber monomials

Primary source: Davison–Mandel, arXiv:1910.12915v3, dated 15 June 2021.

- Proposition 4.9(4) identifies scattering transport, followed by the tropical linear torus map, with the actual cluster chart.
- Corollary 4.13 identifies all localized cluster monomials with quantum theta functions and makes them ordinary monomials in their own cluster chamber.
- With injective leading rays \(-e_i\), plus unrestricted frozen directions, the relevant cluster chamber projects to the negative orthant.

For a purely frozen translation \(h\), compatibility gives
\[
  \Lambda(h,\widetilde B d)=0.
\]
Thus normalizing the injective variables to full leading degrees \((-e_i,0)\) introduces no correction-dependent phase. If \(H\) is the full path element from the positive to negative chamber, the correctly normalized variables satisfy
\[
  J_i=\operatorname{Ad}_{H^{-1}}X^{-e_i}.
\]
The full principal \(A\)-torus is essential. A correction degree central in the \(Y\)-torus can still act nontrivially on the \(X\)-torus; quotienting it away would destroy this identity.

Direct original URL:
https://arxiv.org/html/1910.12915v3

### 2.3 Integrality is a separate required step

The rational group coefficients of \(H,F,T\) need not be Laurent polynomials. The actual standard element is, however, a normalized product of two localized cluster monomials. DM Theorem 3.9 and Corollary 4.13 make the transported theta factors integral Laurent coefficientwise. In a fixed positive-degree box their product is a finite convolution.

This supplies the Laurent integrality required before bar-invariance can kill a strictly negative-degree coefficient. The rational function \(1/(v+v^{-1})\) remains a valid counterexample to the same inference without integrality.

No new 2026 paper is used as a theorem input here. The recovered October 2026 proof is rechecked directly; the cited mathematical inputs are fixed older primary versions.

## 3. Independent reconstruction of the degree mechanism

For the principal form, write
\[
 \widetilde B=\binom B I,\quad
 \Lambda=\begin{pmatrix}0&-I\\I&-B\end{pmatrix},\quad
 Y^d=X^{\widetilde B d}.
\]
Let \(g=a-b\), \(a,b\ge0\), \(a_ib_i=0\). Let \(H=TF\), where \(F\) transports the positive chamber to a point in a finite chamber of a generic direction \(\nu\), and \(T\) transports that point to the negative chamber. Then
\[
  \iota_\nu(I_g)=F X^a H^{-1} X^{-b}T.
\]
The leading normalization is trivial for this principal form. For a general compatible form it subtracts the constant phase \(\Lambda(a,-b)\).

Assign root degrees \(d_1,d_2,d_3\) to \(F,H^{-1},T\), respectively. Pairing the five monomials gives exactly
\[
 g\cdot d_1-|g|\cdot d_2-g\cdot d_3
 +d_1^T B d_2+(d_1+d_2)^T B d_3.
\tag{1}
\]
The first and last supports obey
\[
  d_1\ne0\Rightarrow\nu\cdot d_1<0,\qquad
  d_3\ne0\Rightarrow\nu\cdot d_3>0.
\]
For \(g=N\nu+h\), once coordinate signs stabilize, the coefficient of \(N\) in (1) is
\[
 \nu\cdot d_1-|\nu|\cdot d_2-\nu\cdot d_3
 \le -|\nu\cdot(d_1+d_2+d_3)|.
\]
It is strictly negative for every nonzero degree of the fixed generic box. All remaining rational-function degrees and commutation phases are bounded constants over the finite decompositions and fixed offsets.

Qin's negative-\(v\) standard corrections preserve strict negativity. Scattering transport preserves bar. Integral Laurent coefficients that are both strictly negative in degree and bar invariant vanish. This proves the finite-jet statement.

The auxiliary Wolfram check in \`ctb_generic_jet_wolfram.json\` expands the full five-factor phase with a symbolic \(3\times3\) skew matrix and independent vectors; it returns zero difference from (1). The symbolic proof above handles arbitrary rank; the rank-three symbolic computation only checks signs and normalization.

The finite-box restriction belongs to the positive correction algebra and fixed-anchor modules. It is not an ideal quotient of the whole Laurent torus, in which the root monomials are invertible.

## 4. Targeted exact diagnostic

Files:

- \`ctb_generic_jet_probe.py\`
- \`ctb_generic_jet_probe.json\`

These use the previous branch's exact BZ generator and independent acyclic theta prefix routine. They do not infer an all-\(N\) statement from finitely many points.

Take
\[
 B=\begin{pmatrix}0&-3\\3&0\end{pmatrix},\quad
 \nu=(3,-2),\quad W=[0,2]^2.
\]
Every nonzero root in \(W\) pairs nontrivially with \(\nu\). In the classical specialization:

| \(N\) | \(g=N\nu\) | Difference \(L_g-\theta_g\) inside \(W\), in root coordinates |
|---:|---|---|
| 1 | \((3,-2)\) | coefficient \(1\) at \((1,1)\) |
| 2 | \((6,-4)\) | coefficient \(1\) at \((2,2)\) |
| 3 | \((9,-6)\) | zero |
| 4 | \((12,-8)\) | zero |
| 5 | \((15,-10)\) | zero |
| 6 | \((18,-12)\) | zero |

The threshold is genuinely nontrivial; agreement at \(N=1\) is not a valid default. This run has not certified \(N=3\) as a theorem-level minimal threshold.

For the resonant control \(\nu=(1,-1)\), the root \((1,1)\) has pairing zero. At \(N=3\), the difference at \((1,1)\) is 2; at \(N=4\), the differences at \((1,1),(1,2),(2,2)\) are \(2,2,4\). This only illustrates why the generic condition matters; finite data alone do not prove perpetual failure on that ray.

## 5. An independently derived acyclic degree identity

Before the October proof was recovered, I derived the following useful identity from the BZ standard product. It is a check on the mechanism and may help the modular Euler-image project; it is not presently claimed as a new theorem or used in place of the recovered proof.

Order an acyclic skew-symmetrizable matrix so \(B_{ij}\le0\) for \(i<j\). Put \(d_i=[-a_i]_+\), and
\[
 g_i=a_i+\sum_{j>i}(-B_{ij})d_j.
\]
At a root \(p\) in the standard box \(0\le p_i\le d_i\), the coefficient of the normalized monomial in the BZ standard element has the form
\[
 v^{\phi_a(p)}\prod_i {d_i\brack p_i}_{v^{D_i}},
\]
with
\[
 \phi_a(p)
 =\sum_iD_i p_i(g_i+d_i)+
   \sum_{i<j}D_iB_{ij}p_ip_j.
\]
Here if \(a_i\ge0\), the corresponding \(p_i\) is zero, so there is no omitted contribution from the positive initial monomial. Its minimum \(v\)-exponent is exactly
\[
 \boxed{\ g^TDp+q_B(p)\ },\qquad
 q_B(p)=\sum_iD_i p_i^2+\sum_{i<j}D_iB_{ij}p_ip_j.
\tag{2}
\]
This follows by subtracting the Gaussian half-width
\(\sum_iD_ip_i(d_i-p_i)\).

For a quantum strongly positive basis element whose coefficientwise standard bound is independently established, bar symmetry makes (2) a support exclusion whenever it is positive. One must not infer a general high-rank theta-transition bound from this single inequality alone: competitors near the opposite vertex require an additional confinement argument. I stopped that route when the more general prior injective-standard proof was recovered.

## 6. What this does and does not give for the modular \(p\)-KLR bases

The November 8 local report constructs full bases via the graded image of an integral Euler-class multiplication map on products of Grassmannians. Its stated coefficients are
\[
 L^{(p)}_g(v)
 \ \leftrightarrow\
 v^{-D_{\rm inv}-D_{\rm Gr}}
   \operatorname{Hilb}_v\operatorname{Im}(m_F\otimes\mathbb F_p).
\]
Even assuming the entire basis-identification theorem, the October CTB proof does **not** automatically apply to these bases. In particular, if every \(p\)-basis obeyed exactly Qin's same negative-\(v\) standard triangular condition, formal uniqueness would make them all equal to CTB. The reported characteristic-dependent differences show that this condition cannot be silently imported.

The precise promising replacement is:

> For a fixed root box and a generic ray \(g=N\nu+h\), prove that the integral Euler-map ranks in all relevant graded pieces have saturated images, uniformly for large \(N\), or prove directly that the modular basis has the same finite jet as theta.

The first version would give agreement with characteristic zero coefficientwise in that window, after which the already proved CTB jet bridge applies. It is stronger than necessary but concrete: an exact unimodular-minor/pivot construction can prove it, while rank computations over several primes can falsify it.

The first stress test should use **fixed characteristic** and \(N\) increasing through multiples of that characteristic, for example \(B=3\)-Kronecker, \(\nu=(3,-2)\), roots through \((2,2)\) and then \((3,3)\). This distinguishes eventual stabilization from periodic torsion loss. A connected wild rank-three test should follow only to probe a proposed general mechanism, not to accumulate unrelated examples.

There is an alternative categorical target: bound the non-head graded composition factors of the large standard products away from the fixed root window. An \(R\)-matrix degree inequality by itself does not provide such a bound; the old October report already identified that mistake. The needed degree statement must come from the actual Euler image, an explicit graded filtration, or another proved model.

The root agent has already begun exact integral Pieri/Jacobi–Trudi Euler calculations. This branch does not duplicate them. No conclusion about all \(p\)-bases or all strongly positive classical bases is asserted here.

## 7. Route and search record

1. Read the preceding exact CTB code, full first-wave report, and the older all-rank product detector.
2. Ran the designated wild rank-two finite-jet test. It supported eventual agreement but gave small-\(N\) discrepancies, recorded in full.
3. Read BZ 1206.3586v2's standard basis and bar-correction definitions. Derived (2).
4. Searched primary literature for asymptotic CTB/theta rigidity. No independently published general result was located in these narrow searches. This is not a global priority claim.
5. Opened Qiyue Tang's Hexagon2610.00083v2. Its rank-two quantum standard bound and remote-vertex mechanism already address a related problem. I did not use its overall 2026 theorem as a black box.
6. On receiving the actual October 31 local package, stopped developing the same bridge as if new. Read the complete substantive proof chain, checked Qin/DM identities against the fixed original versions, and independently checked the phase.
7. Inspected the November 8 modular Euler formula and isolated the exact missing finite-window saturation/graded composition bound.
8. Refrained from asserting that quantum bar-invariance alone transfers the CTB theorem to an arbitrary classical or modular strong-positive basis.

### Primary URLs

- https://arxiv.org/html/1206.3586v2
- https://arxiv.org/html/2508.12761v2
- https://arxiv.org/html/1910.12915v3
- https://arxiv.org/html/1902.09507v4
- https://hexagonmath.org/pdf/2610.00083v2

The Hexagon source was initially inaccessible by a direct open, then accessible through its indexed source record. This access failure is not mathematical evidence. Its own peer-review/AI-review language is not used as a correctness certificate.

