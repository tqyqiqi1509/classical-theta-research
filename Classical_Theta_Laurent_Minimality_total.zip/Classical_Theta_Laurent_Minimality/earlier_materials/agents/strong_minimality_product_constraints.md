# 普通 cluster atlas 的任意强正基：全局乘法约束分支

分支：`strong_minimality_product_constraints`。实际工作时段：2026-11-14 04:08–04:46 UTC。对象为经典丛代数；旧量子 CTB 程序仅用于产生一个已知真实基的经典有限前缀。

## 1. 本波判断

本分支没有证明任意经典强正基的 theta 最小性，也没有得到满足全部要求的强正基反例。没有把单个 Laurent 正元素、generic character、Schubert character、形式环基或有限可行解称为这种反例。

完成的实质工作是把“只用全局乘法正性”的第一层和后续层约束分开，给出精确式子与可复算的有限系统，并检查了它们能够推出什么、不能推出什么。特别是：

1. 第一非零换基层满足一个带已知 theta 乘法项的次可加不等式。这里的“第一”必须是此前所有换基系数均为零，不能换成“此前系数均非负”。
2. 二阶已经出现由低阶正修正产生的负项；因此首层最大原理不能直接归纳到任意负 theta 系数。
3. 在精确有限系统中，首层及固定真实 CTB 低阶后的下一层都没有发现负 theta 系数。199 个非平凡目标有逐个精确有理对偶证书；这证明的是这些有限线性蕴含。
4. 同时，一个包含 841 个标签、199193 对乘法约束的首层系统有精确整数可行向量，在非共振标签 `(14,-9)` 的修正为 10。故这些有限约束并不迫使远方向修正为零。该向量没有被完成为真实基，也没有被外推到无限标签。
5. 完整远域乘法正性本身仍不足以证明所需符号：一个非中央形式墙自同构给出所有阶乘法常数均正而换基有负项的模型。它改变初始 cluster anchors，因而不能成为原问题的反例。

旧 Oct31 的 CTB 有限 jet 定理与正换基桥已明确保留为旧工作。本分支不重新主张它的创新性，也不把它用于任意不满足 Qin 负 v 三角条件的经典基。

## 2. 约定和不能省略的假设

以下计算以主系数记号写出。设已有 theta 基，且竞争基在所用图册中有完整、唯一的 pointed 参数化及有限展开

\[
 b_g=\theta_g+\sum_{q>0}t_g(q)y^q\theta_{g+Bq}.
\tag{2.1}
\]

这些假设在本分支是明示的接口，不是由“强正”三个字无条件推出的结论。高秩任意强基自动 pointed 的一般定理，本轮未找到。DM §1.4 的原最小性讨论本身就限定 pointed bases。

强正且含全部 cluster monomials，确实推出每个普通 cluster chart 中的 Laurent 正性：乘足够大的该 cluster 单项式清除分母，再比较同一个基中的两种展开。这个旧论证不涉及非 cluster 的 scattering chart。

Mandel 的 atomicity 使用 scattering atlas。它不能直接填补普通 atlas 到 scattering positivity 的缺口。LLRZ 的 wild rank-two 讨论还说明普通普遍正锥与 theta/greedy 正锥不能混同。以上均保留原文条件。

## 3. 全局第一非零层的精确不等式

记 theta 的结构常数为

\[
 \theta_g\theta_h=\sum_{q\ge0}\alpha(g,h;q)y^q\theta_{g+h+Bq},\qquad \alpha(g,h;0)=1.
\]

固定根次数 p，假定对所有标签 g，以及所有 `0<q<p`（分量序）均有 `t_g(q)=0`。令 `c_g=t_g(p)`。在根次数 p 比较乘法，立即得到

\[
 \boxed{\ \beta(g,h;p)=\alpha(g,h;p)+c_g+c_h-c_{g+h}.\ }
\tag{3.1}
\]

其中 beta 是 b 基的结构常数。这是任意秩的代数恒等式：输入在次数 p 的两个修正只与另一个输入的首项相乘；输出低于 p 的项不含尚未出现的修正；输出首项贡献 `c_{g+h}`。没有使用量子 bar。

强正给出必要条件

\[
 c_{g+h}-c_g-c_h\le\alpha(g,h;p).
\tag{3.2}
\]

若在某个远域该 theta 结构常数为零，就只剩次可加性。沿一条射线写成 `c_N` 时，`c_N=-N` 仍满足 `c_N+c_M-c_{N+M}=0`。因此 Fekete 型极限、单射线的增长比较，或重复取同方向乘积都不足以产生符号结论。

真实 cluster anchors 为 `(3.2)` 增加了 `c_g=0` 的标签，还可加入 Laurent 正性和正 carrier 的上界。但必须真正使用这些边界；不能把它们藏在“自然性”或“渐近稳定”中。

## 4. 为什么不能把首层结论直接递推

在已经 monomialized 的局部模型中，取一个根 r，记 `delta=B r`，并写

\[
 b_g=x^g+t_g z x^{g+\delta}+u_gz^2x^{g+2\delta}+O(z^3).
\]

设 `s=g+h`。乘法系数精确为

\[
 C_1=t_g+t_h-t_s,
\]

\[
 \boxed{\ C_2=u_g+u_h+t_gt_h-u_s-C_1t_{s+\delta}.\ }
\tag{4.1}
\]

最后一个标签是 `s+delta`，不是无条件的 s。Wolfram 独立展开核验了次数一、二的两个余项都为零。

即使所有 t 均非负，式 (4.1) 中仍有 `-C_1 t_{s+delta}`。例如形式数值 `t_g=t_h=t_{s+delta}=1,t_s=0` 时，`C_1=2`，且在其他 u 为零时取 `u_s=-1` 可以把 `C_2` 从 -1 调回 0。这不是基的构造，只明确展示高层不等式不对低层正修正单调。

所以“取第一个负 theta 系数，然后像首个非零系数一样处理”是不成立的证明步骤。要继续走全局乘法路线，必须控制这些已出现正修正的反作用，或者找到一个能同时读取整个三角换基而保持正性的全局算子。

## 5. 一个所有阶都通过乘法检查的形式模型，以及它失去的 anchor

设正根 p，`Y=y^p x^{Bp}`，`ell(g)=g·p`。反对称性给出 `ell(Bp)=p^T Bp=0`。在根完成的 Laurent 环内定义

\[
 T(x^g)=x^g(1-Y)^{\ell(g)}.
\tag{5.1}
\]

因为 T 固定 Y，且 ell 可加，T 是可逆的连续代数自同构，逆自同构把指数符号反向。相应的 topological basis `b_g=T(x^g)` 满足

\[
 b_gb_h=b_{g+h}.
\]

所有结构常数都是 0 或 1，而一次修正为 `-ell(g)`。在任意 `ell(nu)>0` 的射线上，它是 `-N ell(nu)`，不是非共振远域零 jet。

这不依赖 `Bp=0`，所以比仅检查中央标量扭曲更能说明：远域乘法完整结合律也不能独自替代 cluster anchors。此模型不能用于原问题，因为对 `p_i>0`，`T(x_i)=x_i(1-Y)^{p_i}` 改变了初始 cluster 单项式；负指数还通常给出无限形式级数，并非普通 cluster 代数的有限元素。没有将这个形式模型宣称为经典强正基反例。

另一个尝试是用正中央系数 `C=1+y^k` 按某个分级整体缩放 theta 元素。即便乘法常数看起来非负，C 在通常的系数 Laurent 环中并非单位；逐标签乘 C 的集合一般不满射，不能成为同一自由模的基。这里不能用形式逆 C 偷换普通代数。

## 6. 有目的的有限全局系统

计算只用一个机制测试种子

\[
 B=\begin{pmatrix}0&-3\\3&0\end{pmatrix}.
\]

没有用多种小型种子堆积经验。目标分别是检验第一非零层，以及保留真实 CTB 已有正低阶修正后的下一层。

### 6.1 首层的约束

标签集为 `[-M,M]^2`，纳入每一对 g,h 只要 `g+h` 仍在集合内。cluster labels 全部固定为零；它们由已知 rank-two imaginary cone 的补集识别。主系数 root degrees 保留，未把它们与 g 标签混在一起。

所有 theta 前缀和乘法常数来自本轮已独立核验的精确散射后端 `ctb_probe.AcyclicTheta`。每次三角消去也检查所得 theta 结构系数非负。

设 `F_g(p)` 为 theta 的初始 Laurent 系数，`I_g=x^{g_+}J^{g_-}` 为实际 injective cluster variables 构成的正 carrier。由完整 pointed 参数化和无消去的正展开，有必要界

\[
 -F_g(p)\le c_g\le F_{I_g}(p)-F_g(p).
\tag{6.1}
\]

上界来自 `I_g` 的正 b 展开在首项的系数恰为一，并非从任意单位三角基自动得到。所有采用的界均在程序中明确编码。

### 6.2 保留 CTB 低层的约束

取已知真实无环 CTB 的经典前缀 L，固定 p 以下的所有层，只让

\[
 b_g=L_g+d_g y^p\theta_{g+Bp}\pmod{\text{盒外项}}.
\]

于是

\[
 \beta_b(g,h;p)=\beta_L(g,h;p)+d_g+d_h-d_{g+h}.
\]

theta 系数目标是 `t_g^L(p)+d_g`。这个系统保留了 L 的真实低层影响，不会把所有正修正人工清零。L 的前缀直接复用旧 Oct31 `injective_engine.py`，其实际 CTB 识别与负 v 规范已经由本轮 `ctb_generic_jet.md` 独立核对。本分支没有再次提出该 CTB 算法或桥为新结果。

### 6.3 结果和精确性

| 基线与 root | 标签数 | 乘法对数 | 非平凡目标数 | 精确有理对偶给出的最小 theta 系数下界 |
|---|---:|---:|---:|---:|
| theta，p=(1,1)，M=14 | 841 | 199193 | 61 | 0 |
| theta，p=(1,2)，M=8 | 289 | 23585 | 39 | 0 |
| theta，p=(2,2)，M=8 | 289 | 23585 | 26 | 0 |
| 实际 CTB，p=(2,2)，M=8 | 289 | 23585 | 27 | 0 |
| 实际 CTB，p=(3,3)，M=10 | 441 | 54841 | 46 | 0 |

合计为 324789 对约束记录、199 个精确对偶目标。这里每个系统的 pair count 单独计数，并非声称这么多独立的新数学实例。

线性规划由 HiGHS 发现候选对偶解，随后转换成有理数，逐项检验：不等式乘子的符号、上下界乘子的符号、精确驻点恒等式和对偶目标值。最后检查没有浮点容差。`strong_lp_certificate.py` 和每个 JSON 内的稀疏对偶乘子保留了可复算证据。

对 theta 基线，零修正本身可行，所以这些下界也给出相应有限系统的精确最优值零。对 CTB 系统，表中只需使用精确下界结论，不把全部可行向量外推为基。

首层 p=(1,1)、M=14 另有逐项整数检查通过的可行向量，满足 `c_(14,-9)=10`。其所有非零坐标完整保存在 JSON。这里 `(14,-9)` 对 `[0,1]^2` 内所有非零根的配对分别为 14、-9、5，均非零。因此即便这个大有限系统没有负解，它也不能直接证明非共振 jet 必为零。

### 6.4 文件

- `strong_first_defect_lp.py`：首个 root 的简化精确结构公式与全部 pair 约束。
- `strong_first_defect_general.py`：一般 root box 的 theta 基线版本。
- `strong_ctb_next_defect.py`：固定真实 CTB 低层的下一层版本。
- `strong_lp_certificate.py`：精确有理对偶后检。
- `strong_first_defect_lp_M14.json`。
- `strong_first_defect_general_M8_p1_2.json`。
- `strong_first_defect_general_M8_p2_2.json`。
- `strong_ctb_next_defect_M8_p2_2.json`。
- `strong_ctb_next_defect_M10_p3_3.json`。
- `strong_minimality_product_constraints_wolfram.json`：两个符号计算回执。

五个主要结果 JSON 合计约 106 KB。M=10 的最初首层探索文件也留存，但不需要把它当作另一项理论证据。

## 7. 文献接口与 2026 强审核

### 7.1 本波可用的原始接口

| 原文 | 实际核查 | 对本问题的用途与边界 |
|---|---|---|
| LLRZ, *Greedy bases in rank 2 quantum cluster algebras*, 2014，[原文](https://pmc.ncbi.nlm.nih.gov/articles/PMC4103316/) | §5 定义、Conjectures 12–14，分母清除论证 | 明确 pointedness 曾是独立问题；强正推出普通 Laurent 正。不能据此断言任意高秩基已 pointed。 |
| Davison–Mandel, *Strong positivity for quantum theta bases*, [原文](https://link.springer.com/article/10.1007/s00222-021-01061-1) | §1.4 的准确目标和 atlas 区分 | 其最小性首先为 Laurent 系数序；theta 非负换基是更强的充分结论。 |
| Mandel, *Theta bases are atomic*, [1605.03202v2](https://arxiv.org/pdf/1605.03202v2) | 全部三页，Theorem 1 与解释 | atomicity 是 scattering atlas 结论；普通 atlas 的缺桥没有被隐藏。 |
| Lê–Thurston–Yu, *Lower and Upper Bounds for Positive Bases of Skein Algebras*, [作者稿](https://letu.math.gatech.edu/Papers/positive%20basis%20of%20skein%20algebra_new.pdf) | Theorem 2.4 及 §4 全证明 | 经典下界使用横截曲线，把 Chebyshev 系数变为互异 primitive 输出曲线的乘法常数。它限定 polynomial-threaded 基族，不是任意 cluster 强基。提供真正的跨方向探针思路，但不能拿其结论补本题缺口。 |
| Rupel–Stella, *Dominance Regions for Rank Two Cluster Algebras*, [原文](https://link.springer.com/article/10.1007/s00026-023-00636-4) | Theorems 1.1–1.2、Remark 1.3 | pointed 变形系数可取任意整数；有限 dominance region 不给符号，也不自动给远 jet 零。只用其 cluster-label/imaginary-cone 识别和已知范围。 |

### 7.2 2026 原文的强审核记录

**Qiyue Tang, Hexagon2609.00143v3，2026-11-06 版本。**

原始页面：[work](https://hexagonmath.org/2609.00143v3)；[五页 PDF](https://hexagonmath.org/pdf/2609.00143v3)。直接 PDF open 曾失败；从 work 页点击后获得全文。已逐页核对标准基规范、正展开角点归一化、对有符号标准展开的坐标极值界、以及到边界的有限 spanning 归纳。给定其 rank-two 定义，未发现这条证明链的缺口。经典 `R=Z` 可直接采用同一有限论证；bar 只用于量子单位归一化。**本波只允许 rank two 的 pointedness 用途。** 高秩标准项一般没有这里共同的分母角点，“任一坐标非正便是 cluster monomial”的归纳边界也不成立，不能推广。

**Dawydiak, arXiv2511.15344，2026 修订/IMRN 发表线索。** 搜索发现 lowest two-sided cell 中正基与渐近 Hecke 代数接口；未取得并强审全部证明。没有将其任何 2026 新结论用于本波证明或程序。

**Hexagon2610.00025v3、2610.00083v2。** 搜索再次定位 rank-two quantum 最小性与 greedy 正展开，属已有本地工作接口。本波不以摘要替代原证明，不把它们的量子结论自动量化为“每个任意经典强基均有量子提升”。

**Fei 的 2026 generic/Schubert 线索。** 继承上一分支的对象区分，不把负 generic 或 Schubert 展开当成完整强正基反例；没有从不可访问的新全文导入结论。

本波没有使用 Li–Pan 的结论。

## 8. 完整路线记录与纠偏

| 路线 | 尝试及所得 | 状态 |
|---|---|---|
| 乘法矩阵/Perron–Frobenius | 将 theta 系数设想为正矩阵渐近核；普通正点值、线性估值只能约束值或支撑面，不能读取内部 theta 系数 | 未找到能保持正性且读取内部系数的真实极限泛函；未补造它 |
| 单射线无穷下降 | 推出首层次可加式；负线性漂移精确满足所有同向约束 | 不能作为缺桥证明，保留反模型 |
| 中央扭曲 | 尝试按 kernel grading 乘 `(1+z)^phi` | 非单位整体缩放一般丢失同一系数环上的基性；不构成反例 |
| 非中央形式墙扭曲 | 公式 (5.1) 给所有阶乘法结构为 0/1 的负过渡模型 | 仅形式模型；cluster anchors 被改变，不能用于原问题 |
| 首层全局最大原理 | 加入所有有限标签对、全部可识别 cluster anchors、Laurent/carrier 界，精确求解 | 得到五个有限系统的证书；没有全标签定理 |
| 首个负系数归纳 | 明确二阶 shifted-label 公式 (4.1) | 发现低阶正修正有负反作用，不能偷换成首个非零层 |
| 固定真实低层再求下一层 | 用旧实际 CTB 的经典前缀构建下一层线性系统 | 两个目标 root 检查完成，没有负解；不继续无目的扩大窗口 |
| 标准基自动 pointed 推广 | 研究 rank-two 角点证明向一般无环迁移 | 高秩公共角点和有限终止边界均缺；停止宣称直接推广 |
| 分母秩作统一下降函数 | 在 B 上三角为 -3、标准分母 `(2,2)`、g=`(4,-2)`，根 `(0,1)` 使 g 变为 `(1,-2)`，对应标准分母 `(5,2)` | 秩由 4 升到 7，否定该直接下降量；未围绕此小例继续堆例 |
| skein 横向探针迁移 | 读 LTY §4 的正系数读取证明 | 需要真实可达 primitive 输出的识别；一般 arbitrary basis 暂无对应物 |
| “普遍正即 theta 正” | 重新核对 Mandel/LLRZ atlas 和 positive-cone 事实 | 关闭错误捷径，不重命名为 theorem |

实际检索族包括：`strongly positive bases minimal theta`，`classical strongly positive basis minimal`，`commutative strongly positive greedy`，`positive basis cluster algebra classification`，`positive basis based ring minimal Lusztig`，`cluster semiring basis asymptotic`，`Le Thurston Yu positive bases lower upper bounds`，`Dominance Regions Rank Two`，`Positivity and tameness`，以及用户 Hexagon 文稿的精确标识查询。约 04:12、04:22、04:32 的跨路线检索和公式修正均已纳入上表；没有把检索无结果解释成全世界不存在相应定理。

## 9. 向主分支交接

本波保留下来的核心一般问题是：如何利用完整强基的跨方向乘法，控制式 (4.1) 及其高阶版本中的低阶正修正反作用。单层次可加性、有限 dominance、普通正点极限、形式墙结合律都尚未提供这个控制。

由于主分支已出现另一个有实质新依据的无环 Ext/整饱和机制，本分支按指示结束并释放槽位，不再增加 root 窗口。当前报告不妨碍主分支将“指定真实 p-KLR/几何强基的正过渡”与“任意经典强基的最小性”分开陈述。后者在本波仍未完成。
