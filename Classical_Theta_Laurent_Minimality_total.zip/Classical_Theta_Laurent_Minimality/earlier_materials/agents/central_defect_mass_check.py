"""Exact local audit of a positive-mass stopping certificate.

The module basis is the closed-surface Jacobian path basis in CMQ 2306.04104,
Lemma 5.1, specialized only for calibration. No syzygy theorem is imported.
Its dual is an injective for the opposite algebra. Incoming theta is computed
independently; only diagonal degrees 0,1,2 enter the mass certificate.
"""
from collections import Counter
from itertools import product
from pathlib import Path
import json, sys
import sympy as s

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / 'computation'))
from incoming_recursion import IncomingSchur

names = ['E'] + [f'A{i}' for i in range(1, 6)] + [f'B{i}' for i in range(1, 6)] + ['Z']
idx = {v:i for i,v in enumerate(names)}
vertices = [0] + [i % 3 for i in range(1, 6)] * 2 + [0]
maps = {a: s.zeros(12) for a in ('a1','a2','b1','b2','c1','c2')}
edges = []
def add(a, src, dst):
    maps[a][idx[dst], idx[src]] = 1
    edges.append((a, idx[src], idx[dst]))

for branch, word in [('A',['a1','b2','c1','a2','b1','c2']),
                     ('B',['a2','b1','c2','a1','b2','c1'])]:
    chain = ['E'] + [f'{branch}{i}' for i in range(1,6)] + ['Z']
    for a, src, dst in zip(word,chain,chain[1:]):
        add(a,src,dst)
add('b1','A1','B5')
add('b2','B1','A5')

cycles = [(1,['a1','b1','c1']), (1,['a2','b2','c2']),
          (-1,['a1','b2','c1','a2','b1','c2'])]
def path_matrix(word):
    out=s.eye(12)
    for a in word:
        out=maps[a]*out
    return out
relations={}
for a in maps:
    rel=s.zeros(12)
    for sign, word in cycles:
        for j,b in enumerate(word):
            if a==b:
                rel += sign*path_matrix(word[j+1:]+word[:j])
    relations[a] = rel == s.zeros(12)
assert all(relations.values())

arrow_weights={'a1':0,'b1':1,'c1':-1,'a2':3,'b2':8,'c2':-11}
basis_weights=[0,0,8,7,10,11,3,4,-7,-7,1,0]
grading_ok=all(basis_weights[v]-basis_weights[u]==arrow_weights[a] for a,u,v in edges)
radical_weights_distinct=all(len({basis_weights[j] for j in range(1,12) if vertices[j]==i})
                             ==sum(vertices[j]==i for j in range(1,12)) for i in range(3))
assert grading_ok and radical_weights_distinct
stack=s.Matrix.vstack(*maps.values())
image=s.Matrix.hstack(*maps.values())
dual_stack=s.Matrix.vstack(*(m.T for m in maps.values()))
dual_image=s.Matrix.hstack(*(m.T for m in maps.values()))
assert stack.rank()==image.rank()==dual_stack.rank()==dual_image.rank()==11
assert stack.nullspace()==[s.eye(12)[:,11]]
assert dual_stack.nullspace()==[s.eye(12)[:,0]]
dual_radical_weights_distinct=all(len({basis_weights[j] for j in range(11) if vertices[j]==i})
                                  ==sum(vertices[j]==i for j in range(11)) for i in range(3))
assert dual_radical_weights_distinct

def fixed_submodule_polynomial(reverse=False):
    out=Counter()
    directed=[(v,u) if reverse else (u,v) for _,u,v in edges]
    for mask in range(1<<12):
        if any((mask>>u)&1 and not((mask>>v)&1) for u,v in directed):
            continue
        d=tuple(sum((mask>>j)&1 for j in range(12) if vertices[j]==i) for i in range(3))
        out[d]+=1
    return out

FP=fixed_submodule_polynomial()
FI=fixed_submodule_polynomial(True)
z=s.symbols('z1:4')
q=s.prod(z)
to_expr=lambda d: s.expand(sum(c*s.prod(z[i]**p[i] for i in range(3)) for p,c in d.items()))
polyP=to_expr(FP); polyI=to_expr(FI)
suffix=(1+q)*(1+z[2]+z[1]*z[2])
assert s.expand(polyP-(1+z[0]*suffix**2-2*q**2+q**4))==0
assert all(FI[p]==FP[tuple(4-pi for pi in p)] for p in FI)

# This exchange convention corresponds to the opposite algebra used for I=D(P).
B=((0,2,-2),(-2,0,2),(2,-2,0))
R=IncomingSchur(B)
theta=R.theta_prefix((-1,0,0),(3,3,3))
diag_theta=[int(theta.get((j,j,j),0)) for j in range(4)]
diag_hall=[int(FI.get((j,j,j),0)) for j in range(4)]
central=[]
for j in range(3):
    central.append(diag_hall[j]-sum(central[i]*diag_theta[j-i] for i in range(j)))
assert central==[1,2,1]
assert sum(central)==4

# Independent of the mass stopping step, record the exact finite quotient.
quotient=s.cancel(polyI/(1+q)**2)
assert s.denom(quotient)==1
prefix_quotient={tuple(p):int(c) for p,c in s.Poly(quotient,*z).terms()
                 if all(pi<=3 for pi in p)}
assert prefix_quotient==dict(theta)

result={
    'scope':'calibration of a general positive-total-mass stopping principle; not a new surface theorem',
    'primary_basis':'CMQ 2306.04104v2 Lemma 5.1',
    'mass_input':'Mandel-Qin 2301.11101v3 Theorem B.4: central factor has nonnegative coefficients of total mass 4',
    'jacobian_relations_verified':relations,
    'torus_grading_verified':grading_ok,
    'radical_weights_separate_basis_at_each_vertex':radical_weights_distinct,
    'dual_radical_weights_separate_basis_at_each_vertex':dual_radical_weights_distinct,
    'projective_socle_basis':['Z'],'injective_socle_basis':['E_dual'],
    'arrow_image_and_stacked_map_ranks':[11,11,11,11],
    'basis_names':names,'basis_vertices':vertices,'basis_weights':basis_weights,
    'arrow_weights':arrow_weights,'edges':[(a,names[u],names[v]) for a,u,v in edges],
    'module_dimension':[4,4,4],
    'fixed_submodule_count_projective':sum(FP.values()),
    'fixed_submodule_count_injective':sum(FI.values()),
    'F_projective':str(polyP),'F_injective':str(polyI),
    'exchange_matrix':[list(r) for r in B],
    'theta_prefix_box':[3,3,3],
    'theta_prefix':[{'degree':list(p),'coefficient':int(c)} for p,c in sorted(theta.items())],
    'diagonal_theta_prefix':diag_theta,
    'diagonal_hall_prefix':diag_hall,
    'central_factor_coefficients_degrees_0_1_2':central,
    'central_factor_mass_exhausted':sum(central)==4,
    'finite_quotient':str(quotient),
    'finite_quotient_matches_independent_theta_prefix':True,
    'logical_status':'All root degrees of central factor are certified by positivity plus proved total mass, not inferred from stabilization.'
}
dest=Path(__file__).with_suffix('.json')
dest.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('jacobian_relations_verified','torus_grading_verified',
    'fixed_submodule_count_injective','diagonal_theta_prefix','diagonal_hall_prefix',
    'central_factor_coefficients_degrees_0_1_2','central_factor_mass_exhausted',
    'finite_quotient_matches_independent_theta_prefix')},indent=2))
