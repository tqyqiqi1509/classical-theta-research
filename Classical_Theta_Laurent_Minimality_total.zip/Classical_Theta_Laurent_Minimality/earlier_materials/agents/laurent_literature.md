# Laurent 有限性：第一波检索、审核与路线记录

记录人 /root/laurent_literature；截止 2026-11-14 03:19 UTC。内部材料，由 root 统一保存。实质产物：同目录 CYCLIC_THREE_PARAMETER_PUMP.md、verify_three_parameter_pump.py、verify_three_parameter_pump.json。

## 1. 任务与历史

已完整读上传提示 /workspace/scratch/e70eea946e9f/upload/提示(10).txt。本次只研究经典 principal theta，不使用 Li–Pan/Li Fang 的结论。已读第三轮 README、MAIN_REPORT（合并输出后段截断，不宣称完整逐行读完主报告），完整读以下三份历史：

- agents/zero_endpoint_q_fresh_review/NOVELTY_REDUCTION_AND_CONVEXITY.md；
- agents/fei_newton_interface/FINITE_LAURENT_ENVELOPE_THEOREM.md；
- agents/support_accessibility_fresh/FINITE_FIRING_DOES_NOT_CERTIFY_THETA.md。

以下不作为新成果：有限词 recession cone 与标签无关；有限 Laurent envelope 依赖 mid=up 或已知有限 theta 展开；真空 firing 不检测全部支持；rank9 非零 im(B) 标签无限；Reading–Stella v4 的前轮核查。

## 2. 本波实质结果

设

\[
B=\begin{pmatrix}0&b&-c\\-b&0&a\\c&-a&0\end{pmatrix},
\quad \kappa=a^2+b^2+c^2-abc\le0,\quad d=\gcd(a,b,c),
\]
\[
g_0=(-a,ab-c,-b)/d,\quad k_0=(a,c,b)/d.
\]

拟证明 \(a_{g_0}(Nk_0)\ge1\) 对所有 \(N\ge0\) 成立。核心是同一正端点的最大弯折词 \((1,2,3)^N\)，不是只给动量环。反向回归保持显式正锥，行列式 1、迹 \(2-\kappa\)。严格区域 \(\kappa<0\) 的标签不在 im(B)，超出过去的 invariant/descent 子空间障碍。证明等待 fresh adversarial 审核。

符号恒等式通过；精确扫描 2,633 个参数三元组、126,384 次所选过墙，没有负时间或回归失配。扫描不代替泛型和正性论证。

**新颖性未认定。** Mandel 的最大弯折/单应机制很接近；候选贡献只应定位为明确标签及全阶系数的可核验证书，特别严格区域的非 im(B) 标签。不能声称首次发现无限 theta 或最大弯折单应。

## 3. 原始文献审核

### GHKK：可信，使用其基础接口

来源 https://arxiv.org/html/1411.1394v2 （2016 v2）。核对 Theorems 1.12–1.13、Definition 3.1、Remark 3.2、Proposition 3.4、Proposition 7.1、Theorem 7.5。

有用：散射正性使单条正 broken line 成为非零系数证书；过墙指数为正，可选常数项；固定阶仅需有限墙；正丛室有限意味着普遍 Laurent。Theta 饱和与加法封闭已知。未见由有限系数前缀判定全部有限性的结论。本波另用纯 \(e_i\) 商解释正代表初始墙局部函数不变，不能偷用“任意原图中的一条正项不会被抵消”。

### CMMM：2026 v2，局部强审后有限使用

来源 https://arxiv.org/html/2505.09585v2 。核对 Theorems 3.8、3.14、3.15、4.12、5.19 与 §5.6.2。

有用：有限 theta 组合的 valuative independence、顶点系数一，以及带前提的 freezing/unfreezing。限制：3.14/4.12 需要已知有限 ambient theta 展开，不能由 regular 无条件替换；互易需要两边有限。§5.6.2 明确保留负无穷值推广的缺口。拿来当一般停机判定会循环。未在已读条款发现新错误，但不宣称全文已验证。三参数泵不依赖此文。

### GHK：可信，旧几何 obstruction

来源 https://arxiv.org/html/1309.2573v2 。核对 Construction 5.3、Example 6.3、§7。

有用：矩阵秩 2 与 log CY surface 的接口、rank9 三组三点构造的来源。其无非平凡 regular functions 障碍不直接给每阶系数；rank9 非零 im(B) 标签无限已由历史材料闭合，不能重复报新。

### Hexagon 2611.00015v1：2026，局部审核

Qiyue Tang，Positive polytopes and the full Fock–Goncharov conjecture，2026-11-02。
来源 https://hexagonmath.org/2611.00015v1 ，PDF https://hexagonmath.org/pdf/2611.00015v1 ，源文件 https://hexagonmath.org/src/2611.00015v1/files 。

核对 Proposition 1.3 的 rank9 invariant/descent 论证及其 GHK 入口。该条款未给每阶正对象族。Theorem 1.1 的 positive-polytope 主张在本子任务中没有完整强审，故不用。版本与身份可核验，不据此保证全文正确。

### Mandel 1407.6241v5：可信，最接近先行机制

来源 https://arxiv.org/pdf/1407.6241 ，SIGMA 15 (2019), 042，https://sigma-journal.com/2019/042/ 。核对 §3.3、§§3.4–3.6、Theorems 4.1–4.2。

其 rank 2 指矩阵秩，覆盖三阶循环矩阵。§3.3 将最大向内弯折对应奇异仿射结构下的直线；负定/半负定类已有无限绕行、双曲/抛物单应。已读段落没找到 principal theta 的具体 \(g_0,k_0\) 系数射线。**重要风险：本轮几何机制可能只是其现象的坐标形式；精确系数强化是否独立新颖尚未证实。**

### Reading–Stella 2603.19391v4：2026，前轮已审，复核限制

来源 https://arxiv.org/html/2603.19391v4 ，版本页 https://arxiv.org/abs/2603.19391 （v4 2026-11-08，SIGMA 22 (2026), 109）。复核 §5.3、Theorems 5.1、5.4、5.7、5.14。

任意 B 的小 canonical algebra / dominance 结构不是 Laurent 正规性判定；部分乘法语句仍以有限 theta 标签为前提；三角过渡矩阵的任意域系数不能擅加非负性。未见已读段落的当前参数族证书；不重复前轮创新报告。没有完整审 arXiv:2603.23429，不凭其 acyclic affine 题目排除交叉。

## 4. 已发起 query 与结果

以下记录第一波实际使用的检索词；结论只依赖上节作者/出版者原文。未命中不构成不存在的证据。

| Query | 用途/结果 |
|---|---|
| "Mandel" "theta functions" "negative" "monodromy" | 找到 rank-2 分类与 tropical theta |
| "theta functions" "Looijenga" "non-affine" series | 非仿射形式 theta 背景；无特定标签判定 |
| "cluster" "theta" "unbounded" "support" | 无直接一般停机判定 |
| "theta functions" "non-positive" "cluster" | 负/非正 surface 背景 |
| "theta" "regular" "semidefinite" cluster | Mandel 半负定分类 |
| "theta" "Laurent" "Looijenga" "negative definite" | 几何 obstruction 接口 |
| "cluster" "regular theta" labels cone | 无核验出的普遍 cone 判定 |
| "theta" "a^2+b^2+c^2" cluster | rank-three mutation/Markov 常数文献 |
| "theta functions" "Markov constant" | 未命中当前精确系数结论 |
| "theta" "(-3,6,-3)" | 未命中当前具体标签；不能据此认定新颖 |

后续入口：

1. Mandel，Tropical Theta Functions and Log Calabi–Yau Surfaces，arXiv:1407.5901，Selecta Math. 22 (2016), 1289–1335，作者页 https://math.ou.edu/~tmandel/ 。本轮尚未逐条审全文，不能标“已排除撞车”。
2. Geometry of Mutation Classes of Rank 3 Quivers，https://link.springer.com/article/10.1007/s40598-019-00101-2 。已见 §4 Markov constant 信息，未审全文，需核其与最大弯折/增长的连接。
3. Fei、Qin 的 Laurent/Newton/泛基入口：本子任务转入核心构造后未完成新一轮全面检索。parent 应与其他代理合并，不能记录为“已排除撞车”。

## 5. 路线记录

| 路线 | 状态 | 依据/处置 |
|---|---|---|
| CMMM 互易把无限支持变有限 valuative 判定 | 未闭合 | 无限组合/负无穷的关键推广未成立，不循环使用 |
| GHK 推 rank9 全部非零 im(B) 标签无限 | 成立但旧 | 历史已写完，作为参考封存 |
| 有限 vacuum firing 推 Laurent 有限 | 错误 | 历史 464 状态反例否定，不沿此推论推进 |
| rank9 对称三块最大弯折泵 | 代数回归成立 | 多墙同时交需要扰动；改用三阶单墙统一构造 |
| 三参数最大弯折周期 | 首波拟证明闭合 | 正锥、共同泛型端点、正代表给全阶正对象 |
| 参数族全部 regular labels 的 cone | 未完成 | 当前只给无穷子族，不冒充分类/总停机算法 |
| 独立新颖性 | 未完成 | Mandel 已有接近机制，需要 fresh 精查系数命题 |

## 6. Fresh 审核任务

先审正代表的初始墙局部函数、各段避 joint 的 rank-two 论证、principal lift；再查精确 \(a_{g_0}(Nk_0)\ge1\) 的优先权。对照 Mandel 时区分矩阵秩 2 的 surface slice、正 grading 的 off-slice 标签、principal 每阶次数。若先行定理直接蕴含，应降级为显式证书而不包装为新理论。不要再靠大量特殊例子替代这个主证明审核。
