"""Search next-layer strong-positivity constraints over the genuine CTB prefix.

All lower correction layers are fixed to the acyclic common triangular basis.
At the selected maximal root p, the unknown change d_g enters every structure
coefficient linearly. Finite feasibility is not a basis existence certificate.
"""
from pathlib import Path
import sys,json,time
from itertools import product
from functools import lru_cache
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
from ctb_probe import AcyclicTheta,box,le,sub
from strong_lp_certificate import certify
BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'interfaces_history/Qin_theta_final_total_20261031_072647/Qin_theta_research/agents/computational_strategy'))
from injective_engine import InjectiveTriangularEngine

def run(M,p,k=3):
    B=((0,-k),(k,0));R=AcyclicTheta(B);roots=box(p);z=(0,0)
    E=InjectiveTriangularEngine(B,[1,2],p,actual_ct_provenance='Acyclic CTB identification as independently checked in ctb_generic_jet.md')
    @lru_cache(None)
    def L(g,cap):
        d={}
        for (q,v),c in E.basis(g,cap).items():d[q]=d.get(q,0)+c
        d={q:c for q,c in d.items() if c}
        assert min(d.values())>0
        return d
    def classic_I(g):
        d={}
        for (q,v),c in E.standard(g,p).items():d[q]=d.get(q,0)+c
        return d
    def mul(f,h):
        out={}
        for a,c in f.items():
            for b,d in h.items():
                s=(a[0]+b[0],a[1]+b[1])
                if le(s,p):out[s]=out.get(s,0)+c*d
        return {q:c for q,c in out.items() if c}
    labels=list(product(range(-M,M+1),repeat=2));idx={g:i for i,g in enumerate(labels)}
    F={g:L(g,p) for g in labels}
    transitions={g:R.decompose(g,F[g]) for g in labels}
    assert all(c>=0 for t in transitions.values() for c in t.values())
    def imaginary(g):
        a,b=g;return a>0 and b<0 and a*a+k*a*b+b*b<=0
    bounds=[]
    for g in labels:
        c=F[g].get(p,0)
        if imaginary(g):bounds.append((-c,classic_I(g).get(p,0)-c))
        else:bounds.append((0,0))
    shifted={s:{q:L(R.shift(s,q),sub(p,q)) for q in roots[:-1]} for s in labels}
    rr=[];cc=[];vv=[];rhs=[]
    for i,g in enumerate(labels):
        for h in labels[i:]:
            s=(g[0]+h[0],g[1]+h[1])
            if s not in idx:continue
            rem=mul(F[g],F[h]);sp=0
            for q in roots:
                val=rem.get(q,0)
                assert val>=0,(g,h,q,val)
                if q==p:sp=val;break
                if val:
                    for r,c in shifted[s][q].items():
                        t=(q[0]+r[0],q[1]+r[1])
                        rem[t]=rem.get(t,0)-val*c
            terms={}
            for q,v in ((s,1),(g,-1),(h,-1)):terms[idx[q]]=terms.get(idx[q],0)+v
            row=len(rhs)
            for col,v in terms.items():
                if v:rr.append(row);cc.append(col);vv.append(v)
            rhs.append(sp)
    A=coo_matrix((vv,(rr,cc)),shape=(len(rhs),len(labels)),dtype=np.int64).tocsr();rhs=np.array(rhs,dtype=np.int64)
    targets=[g for g in labels if bounds[idx[g]][0]+transitions[g].get(p,0)<0]
    answers=[];objective=np.zeros(len(labels))
    for target in targets:
        objective[:]=0;objective[idx[target]]=1
        res=linprog(objective,A_ub=A,b_ub=rhs,bounds=bounds,method='highs')
        assert res.success,res.message
        baseline=transitions[target].get(p,0)
        cert=certify(res,A,rhs,bounds,objective);assert cert['verified'],cert
        answers.append({'g':target,'minimum_d':float(res.fun),'ctb_theta_coefficient':baseline,'minimum_theta_coefficient':float(res.fun)+baseline,'dual_certificate':cert})
        if res.fun+baseline<-.5:
            v=np.rint(res.x).astype(np.int64)
            valid=all(lo<=int(v[i])<=hi for i,(lo,hi) in enumerate(bounds)) and bool(np.all(A.dot(v)<=rhs))
            answers[-1]['integer_witness_valid']=valid
            if valid:answers[-1]['nonzero_witness']=[(g,int(v[i])) for i,g in enumerate(labels) if v[i]]
            if valid:break
    return {'M':M,'k':k,'root':p,'baseline':'actual acyclic CTB, classical specialization','labels':len(labels),'pairs':len(rhs),'targets':len(targets),'tested':len(answers),'minima':answers,'formal_quantum_cache':len(E.cache)}

if __name__=='__main__':
    M=int(sys.argv[1]);p=tuple(map(int,sys.argv[2:4]));start=time.time()
    result=run(M,p);result['seconds']=time.time()-start
    out=Path(__file__).with_name('strong_ctb_next_defect_M%d_p%d_%d.json'%(M,*p));out.write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='minima'}))
    print('negative minima',[{k:v for k,v in x.items() if k!='nonzero_witness'} for x in result['minima'] if x['minimum_theta_coefficient']<-.001])
