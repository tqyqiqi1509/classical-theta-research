"""Exact Berenstein--Zelevinsky triangular basis and classical theta comparison.

Internal research program. Quantum parameter v is auxiliary: outputs specialize v=1.
Reference: BZ arXiv:1206.3586v2, (1.17), (1.22), Theorems 1.1,1.4,1.6.
Requires an acyclic matrix ordered with B[i][j] <= 0 for i < j.
Only principal coefficients and integer arithmetic are used.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import product
from math import comb
import json, time
from pathlib import Path


def ibinom(a,k):
    if k<0:return 0
    if a>=0:return comb(a,k) if k<=a else 0
    return (-1)**k*comb(-a+k-1,k)


def box(cap):
    return sorted(product(*(range(x+1) for x in cap)),key=lambda p:(sum(p),p))


def le(a,b):return all(x<=y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))


def add(f, g, scalar=1):
    r = dict(f)
    for k, c in g.items():
        r[k] = r.get(k, 0) + scalar*c
        if not r[k]: del r[k]
    return r


def bar(f):
    return {e[:-1]+(-e[-1],):c for e,c in f.items()}


def shift_v(f, d):
    return {e[:-1]+(e[-1]+d,):c for e,c in f.items()}


def vpoly_mul(f, q):
    r = {}
    for k,c in q.items(): r = add(r, shift_v(f,k),c)
    return r


class Triangular:
    def __init__(self, B, D=None):
        self.B = tuple(map(tuple,B)); self.n=len(B); self.m=2*self.n
        self.D = tuple(D or [1]*self.n)
        assert all(B[i][j]<=0 for i in range(self.n) for j in range(i+1,self.n))
        assert all(self.D[i]*B[i][j]==-self.D[j]*B[j][i] for i in range(self.n) for j in range(self.n))
        self.L = tuple(tuple(0 if i<self.n and j<self.n else
                             (-self.D[i] if i<self.n and j==i+self.n else
                              self.D[j] if j<self.n and i==j+self.n else
                              -self.D[i-self.n]*B[i-self.n][j-self.n] if i>=self.n and j>=self.n else 0)
                             for j in range(self.m)) for i in range(self.m))
        self.ep=[]; self.em=[]
        for k in range(self.n):
            col=[B[i][k] for i in range(self.n)]+[int(i==k) for i in range(self.n)]
            self.ep.append(tuple(max(x,0)-int(i==k) for i,x in enumerate(col)))
            self.em.append(tuple(max(-x,0)-int(i==k) for i,x in enumerate(col)))
        self.standard=lru_cache(None)(self._standard)
        self.canonical=lru_cache(None)(self._canonical)
        self.corrections=0

    def pairing(self,a,b):
        return sum(a[i]*self.L[i][j]*b[j] for i in range(self.m) for j in range(self.m))

    def mul(self,f,g):
        r=defaultdict(int)
        for a,c in f.items():
            for b,d in g.items():
                e=tuple(a[i]+b[i] for i in range(self.m))+(a[-1]+b[-1]+self.pairing(a,b),)
                r[e]+=c*d
        return {e:c for e,c in r.items() if c}

    def top(self,a):
        d=[max(-a[i],0) for i in range(self.n)]
        return tuple((max(a[i],0) if i<self.n else a[i])+sum(d[j]*self.ep[j][i] for j in range(self.n)) for i in range(self.m))

    def top_inverse(self,e):
        a=[]
        for i in range(self.n):
            a.append(e[i]-sum(max(-a[j],0)*max(self.B[i][j],0) for j in range(i)))
        a.extend(e[self.n+i]-max(-a[i],0) for i in range(self.n))
        assert self.top(tuple(a))==e
        return tuple(a)

    def g(self,a):
        d=[max(-a[i],0) for i in range(self.n)]
        return tuple(a[i]+sum(d[j]*max(-self.B[i][j],0) for j in range(self.n)) for i in range(self.n))

    def _standard(self,a):
        assert len(a)==self.m
        e=tuple(max(a[i],0) if i<self.n else a[i] for i in range(self.m))
        f={e+(0,):1}; leading=e; vpower=0
        for i in range(self.n):
            for _ in range(max(-a[i],0)):
                f=self.mul(f,{self.ep[i]+(0,):1,self.em[i]+(0,):1})
                vpower += self.pairing(leading,self.ep[i])
                leading=tuple(leading[j]+self.ep[i][j] for j in range(self.m))
        f=shift_v(f,-vpower)
        assert leading==self.top(a)
        assert {e[-1]:c for e,c in f.items() if e[:-1]==leading}=={0:1}
        return f

    def _canonical(self,a):
        f=dict(self.standard(a)); anti=add(bar(f),f,-1)
        rank=sum(max(-a[i],0) for i in range(self.n))
        count=0
        while anti:
            count+=1; self.corrections+=1
            if count>100000: raise RuntimeError('canonical correction limit')
            e=max({e[:-1] for e in anti},key=lambda e:(sum(e[self.n:]),e[self.n:],e[:self.n]))
            r={k[-1]:c for k,c in anti.items() if k[:-1]==e}
            assert r.get(0,0)==0
            assert all(r.get(-k,0)==-c for k,c in r.items())
            ap=self.top_inverse(e)
            assert sum(max(-ap[i],0) for i in range(self.n))<rank,(a,ap,r)
            cp=self.canonical(ap)
            assert {k[-1]:c for k,c in cp.items() if k[:-1]==e}=={0:1}
            z={k:c for k,c in r.items() if k>0}
            f=add(f,vpoly_mul(cp,z))
            anti=add(anti,vpoly_mul(cp,r),-1)
        assert bar(f)==f
        return f

    def classical_F(self,a):
        g=self.g(a); p=defaultdict(int)
        for e,c in self.canonical(a).items():
            # Our probe uses a_frozen=0, hence principal degree p=e_frozen.
            q=e[self.n:self.m]
            assert all(x>=0 for x in q),(a,e)
            assert e[:self.n]==tuple(g[i]+sum(self.B[i][j]*q[j] for j in range(self.n)) for i in range(self.n)),(a,g,e)
            p[q]+=c
        return {e:c for e,c in p.items() if c}

    def defining_certificate(self,a):
        """Re-expand C_a-E_a independently in E and check BZ's definition.

        Negative integer coefficients are permitted in v Z[v]. This is
        a defining-property check, not an assumed positivity assertion.
        """
        C=self.canonical(a)
        assert bar(C)==C
        rem=add(C,self.standard(a),-1); out=[]
        rank=sum(max(-a[i],0) for i in range(self.n))
        while rem:
            e=max({k[:-1] for k in rem},key=lambda e:(sum(e[self.n:]),e[self.n:],e[:self.n]))
            ap=self.top_inverse(e)
            q={k[-1]:c for k,c in rem.items() if k[:-1]==e}
            assert all(k>0 for k in q),(a,ap,q)
            assert sum(max(-ap[i],0) for i in range(self.n))<rank
            rem=add(rem,vpoly_mul(self.standard(ap),q),-1)
            out.append({'a_prime':ap,'coefficient_v':sorted(q.items())})
        return out


class AcyclicTheta:
    def __init__(self,B,D=None):
        self.B=tuple(map(tuple,B));self.n=len(B)
        self.D=tuple(D or [1]*self.n);self.zero=(0,)*self.n
        assert all(B[i][j]<=0 for i in range(self.n) for j in range(i+1,self.n))
        self.c=lru_cache(None)(self.ac)
        self.F=lru_cache(None)(self.theta_prefix)

    def shift(self,g,p):
        return tuple(g[i]+sum(self.B[i][j]*p[j] for j in range(self.n)) for i in range(self.n))

    def ac(self,a,m):
        ans=1
        # Reverse BZ topological order gives the parent's incoming product.
        for i in reversed(range(self.n)):
            ans*=ibinom(-m[i]-sum(self.B[i][j]*a[j] for j in range(i+1,self.n)),a[i])
        return ans

    def theta_prefix(self,g,d):
        # Finite endpoint extraction: all matrix entries depend on smaller roots.
        J=box(d);a={self.zero:1}
        for p in J[1:]:
            mp=self.shift(g,p)
            I=[q for q in J if le(q,p) and
               (q==p or sum(mp[i]*self.D[i]*(p[i]-q[i]) for i in range(self.n))<0)]
            t={p:1}
            for q in reversed(I[:-1]):
                t[q]=-sum(t.get(r,0)*self.c(sub(r,q),self.shift(g,q))
                          for r in I if r!=q and le(q,r))
            a[p]=-sum(t[q]*a[q] for q in I if q!=p)
        return {p:c for p,c in a.items() if c}

    def decompose(self,g,F):
        if not F:return {}
        cap=tuple(max(p[i] for p in F) for i in range(self.n)); rem=dict(F); out={}
        for p in box(cap):
            c=rem.get(p,0)
            if not c:continue
            out[p]=c
            h=self.shift(g,p); localcap=tuple(cap[i]-p[i] for i in range(self.n))
            fp=self.F(h,localcap)
            for q,v in fp.items():
                pq=tuple(p[i]+q[i] for i in range(self.n))
                rem[pq]=rem.get(pq,0)-c*v
                if not rem[pq]:rem.pop(pq,None)
        assert not rem
        return out


def fmt(f):return [[list(k),v] for k,v in sorted(f.items())]

def probe(B, dmax=2, maxsum=6, degree_list=None):
    T=Triangular(B); R=AcyclicTheta(B); cases=[]; start=time.time()
    degrees=degree_list if degree_list is not None else sorted(product(range(dmax+1),repeat=len(B)),key=lambda x:(sum(x),x))
    for d in degrees:
        if degree_list is None and (not all(d) or sum(d)>maxsum): continue
        a=tuple(-x for x in d)+(0,)*len(B); g=T.g(a)
        F=T.classical_F(a)
        assert min(F.values())>0
        trans=R.decompose(g,F)
        cap=tuple(max(p[i] for p in F) for i in range(len(B)))
        # source-cap theorem independently bounds every theta on the RHS.
        residual=dict(F)
        for p,c in trans.items():
            h=R.shift(g,p); hc=[0]*len(B)
            for i in reversed(range(len(B))):
                hc[i]=max(0,-h[i]-sum(B[i][j]*hc[j] for j in range(i+1,len(B))))
            ff=R.F(h,tuple(hc))
            for q,v in ff.items():
                pq=tuple(p[i]+q[i] for i in range(len(B)))
                residual[pq]=residual.get(pq,0)-c*v
                if not residual[pq]:residual.pop(pq,None)
        assert not residual,('full-support transition identity failed',B,d,residual)
        cert=T.defining_certificate(a)
        case={'d':d,'g':g,'F':fmt(F),'transition':fmt(trans),'negative_transition':any(c<0 for c in trans.values()),'quantum_terms':len(T.canonical(a)), 'BZ_defining_certificate':cert}
        cases.append(case)
        print(json.dumps({'progress_d':d,'g':g,'transition':fmt(trans),'elapsed':time.time()-start}),flush=True)
        if any(c<0 for c in trans.values()):break
    return {'B':B,'cases':cases,'seconds':time.time()-start,'canonical_cache':str(T.canonical.cache_info()),'correction_count':T.corrections}


if __name__=='__main__':
    start=time.time()
    # First verify auxiliary BZ implementation against affine rank-two polynomials.
    B2=[[0,-2],[2,0]]; T2=Triangular(B2)
    checks=[]
    z=None
    for r in range(1,5):
        a=(-r,-r,0,0); F=T2.classical_F(a); R=AcyclicTheta(B2)
        tr=R.decompose(T2.g(a),F)
        expected={(k,k):1 for k in range(r//2+1)}
        assert tr==expected,(r,tr,expected)
        checks.append({'r':r,'transition':fmt(tr)})
    B=[[0,-2,0],[2,0,-1],[0,1,0]]
    result=probe(B,2,6)
    # Target the missing mechanism: a non-cluster correction, then a wild one.
    # These two choices are deliberate diagnostics, not a broader seed sweep.
    stress=probe(B,degree_list=[(3,3,2),(4,4,2)])
    path=Path(__file__).with_name('ctb_probe_result.json')
    path.write_text(json.dumps({'verification':checks,'rank3':result,'rank3_noncluster_correction':stress,'seconds':time.time()-start},indent=2),encoding='utf-8')
    print(str(path),flush=True)
