"""Targeted finite-jet diagnostic, not a proof of eventual stabilization.
Uses the independently checked BZ generator in ctb_probe.py.
Classic output only; v is auxiliary for the defining BZ correction.
"""
import json,time
from pathlib import Path
from ctb_probe import Triangular,AcyclicTheta,fmt
B=((0,-3),(3,0))
T=Triangular(B);R=AcyclicTheta(B)
def index_from_g(g):
    a=[0]*len(g)
    for i in reversed(range(len(g))):
        a[i]=g[i]-sum(max(-B[i][j],0)*max(-a[j],0) for j in range(i+1,len(g)))
    return tuple(a)+(0,)*len(g)
cases=[]
for name,nu,cap,ns in [
    ('generic',(3,-2),(2,2),range(1,7)),
    ('resonant',(1,-1),(2,2),range(1,5)),
]:
    for N in ns:
        started=time.time();g=tuple(N*x for x in nu);a=index_from_g(g)
        f=T.classical_F(a)
        low={p:c for p,c in f.items() if all(p[i]<=cap[i] for i in range(2))}
        th=R.theta_prefix(g,cap)
        diff={p:low.get(p,0)-th.get(p,0) for p in set(low)|set(th)
              if low.get(p,0)!=th.get(p,0)}
        cases.append({'name':name,'B':B,'nu':nu,'N':N,'g':g,'standard_index':a,
                      'cap':cap,'CTB_prefix':fmt(low),'theta_prefix':fmt(th),
                      'difference':fmt(diff),'quantum_term_count':len(T.canonical(a)),
                      'seconds':time.time()-started})
        print(json.dumps({k:cases[-1][k] for k in ['name','N','g','difference','quantum_term_count','seconds']}),flush=True)
out={'date_utc':'2026-11-14','status':'exact diagnostics only; old 2026-10-31 general theorem supplies proof if its premises hold','cases':cases}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2),encoding='utf-8')

