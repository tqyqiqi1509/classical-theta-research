# A three-parameter certificate of infinite principal theta support

**Status, 2026-11-14:** a complete proposed proof, with symbolic and exact arithmetic verification supplied separately. This first-wave result requires an independent adversarial proof audit before inclusion as a theorem in the final paper. No result of Li–Pan/Li Fang is used. The coefficient statement below is the proposed contribution; maximal bending and monodromy themselves are established ideas in Mandel and GHK.

## 1. Statement and conventions

Let $a,b,c$ be positive integers, and put

\[
B=\begin{pmatrix}0&b&-c\\-b&0&a\\c&-a&0\end{pmatrix},
\qquad \kappa=a^2+b^2+c^2-abc.
\]

We use the **column convention** for the classical principal-coefficient scattering diagram: its three initial walls are $H_i=\{q_i=0\}$, with functions $1+z_i$, where $z_i=y_i x^{Be_i}$. For the theta label $(g,0)$, write its expansion at the initial positive chamber as

\[
\vartheta_g=x^g F_g(z),\qquad F_g(z)=\sum_{p\in\mathbb N^3}a_g(p)z^p.
\]

All statements concern this classical principal-coefficient expansion. They do not assert that an infinite formal series may be specialized at $y=1$.

**Proposed theorem.** Suppose $\kappa\le0$. Set

\[
k=(a,c,b),\qquad g=(-a,ab-c,-b).
\]

Then

\[
\boxed{a_g(Nk)\ge1\quad\text{for every integer }N\ge0.}
\]

Consequently, $\vartheta_g$ is not a Laurent polynomial. In fact $Bk=0$, so the displayed nonzero terms are the distinct monomials

\[
x^g y^{Nk}\quad(N\ge0).
\]

Moreover $k\cdot g=-\kappa$. If $\kappa<0$, then $g\notin\operatorname{im}_{\mathbb R}B=k^\perp$. Thus this certificate does not reduce to a descent obstruction confined to the image of $B$.

**Primitive refinement.** Let $d=\gcd(a,b,c)$, $g_0=g/d$, and $k_0=k/d$. These are integral, and the stronger statement $a_{g_0}(Nk_0)\ge1$ holds for every $N\ge0$. Divide each mutable momentum and each bend charge in the proof by $d$. The geometric path is unchanged, and all travel times are multiplied by $d$. The three local factors now have exponents $a/d,c/d,b/d$, so their maximal terms still have coefficient one. This refinement was independently pointed out by the root agent during cross-checking.

### Scope of the hypothesis

The inequality $\kappa\le0$ is a sufficient hypothesis for this particular periodic bending word. We do not claim it is necessary for nonregularity. Since $abc\ge a^2+b^2+c^2$, we have the strict inequalities

\[
ab>c,\qquad ac>b,\qquad bc>a.
\]

These will ensure that every prescribed segment has positive length. The proof gives a general mechanism for an infinite family of matrices and labels, rather than inferring a theorem from numerical examples.

## 2. The algebraic bend cycle

Set

\[
\begin{aligned}
m_0&=(-a,ab-c,-b),\\
m_1&=(-a,-c,ac-b)=m_0+aBe_1,\\
m_2&=(bc-a,-c,-b)=m_1+cBe_2,\\
m_3&=m_0=m_2+bBe_3.
\end{aligned}
\]

At a selected crossing of $H_1$, the incoming normal coordinate is $-a$. The broken-line rule uses the positive exponent $a$, and permits choosing the term $z_1^a$ in $(1+z_1)^a$. Its coefficient is one, and it changes the mutable exponent from $m_0$ to $m_1$. Similarly, choosing $z_2^c$ on $H_2$ changes $m_1$ to $m_2$, and choosing $z_3^b$ on $H_3$ restores $m_0$.

One complete forward bend word $(1,2,3)$ adds principal charge $k$, preserves the mutable momentum, and multiplies the attached coefficient by one. Its repeated word $(1,2,3)^N$ therefore has the desired algebraic final monomial $x^g y^{Nk}$, **provided the word is geometrically realizable at one fixed positive endpoint**. Establishing that condition, including avoidance of joints, is the main content below.

The first and last coordinates of $m_0$, the first two of $m_1$, and the last two of $m_2$ are nonzero. Also

\[
k\cdot m_j=-\kappa\quad(j=0,1,2).
\]

## 3. Backward construction from a fixed endpoint

Choose once and for all $Q=(Q_1,Q_2,Q_3)$ with strictly positive, rationally linearly independent coordinates. For example, $(1,\sqrt2,\sqrt3)$ has this property. Section 5 proves that this single choice avoids every forbidden rational joint for every $N$.

The velocity of a broken line with mutable exponent $m$, in its forward parameter, is $-m$. We construct the finite part backward. From $Q$, move successively in the directions $m_0,m_2,m_1$, reaching $H_3,H_2,H_1$. The three positive backward travel times are

\[
\begin{aligned}
t_C&=Q_3/b,\\
t_B&=\frac{Q_2+(ab-c)Q_3/b}{c},\\
t_A&=\frac{Q_1}{a}+\frac{bc-a}{ac}Q_2+
       \frac{b^2-\kappa}{ac}Q_3.
\end{aligned}
\]

Let the resulting point on $H_1$ be $q$. Its second coordinate is

\[
q_2=-\frac ca Q_1+\left(1-\frac{bc}{a}\right)Q_2+
\frac{\kappa-b^2}{a}Q_3<0.
\]

Put $u=-q_2>0$ and $h=k\cdot q$. Every backward segment increases $k\cdot q$ by $-\kappa$ times its positive travel time. Therefore

\[
h=k\cdot Q-\kappa(t_A+t_B+t_C)>0.
\]

The point $q$ has the canonical form

\[
q=\left(0,-u,\frac{h+cu}{b}\right),\qquad u>0,\ h>0. \tag{3.1}
\]

It remains to show that any point of this cone can be extended by another full backward cycle.

## 4. An invariant cone for arbitrary repetitions

Start at a point (3.1). Move backward along $m_0$ to $H_3$, then along $m_2$ to $H_2$, and finally along $m_1$ to $H_1$. The travel times are

\[
\begin{aligned}
s_C&=\frac{h+cu}{b^2},\\
s_B&=\frac{(a^2-\kappa)u+(ab-c)h}{b^2c},\\
s_A&=\left(\frac1c-\frac{\kappa}{ab}\right)u+
          \frac{b^2-\kappa}{abc}h.
\end{aligned} \tag{4.1}
\]

Every coefficient in these expressions is nonnegative, and the coefficients needed for strict positivity are positive. Thus all three travel times are strictly positive.

The next point on $H_1$ again has form (3.1), with

\[
\binom{u'}{h'}=R\binom{u}{h},\qquad
R=\begin{pmatrix}
1-\dfrac{c\kappa}{ab}&\dfrac{b^2-\kappa}{ab}\\[5pt]
-\dfrac{\kappa(a^2-\kappa)}{ab}&1-\dfrac{\kappa(ab-c)}{ab}
\end{pmatrix}. \tag{4.2}
\]

The matrix has nonnegative entries and positive diagonal entries. Consequently it preserves the strict cone $u,h>0$. Direct calculation gives

\[
\det R=1,\qquad \operatorname{tr}R=2-\kappa. \tag{4.3}
\]

The total backward travel time is

\[
T=s_A+s_B+s_C=
\frac{a^2-\kappa}{ab}u+\frac{ab-c}{ab}h,
\qquad h'=h-\kappa T. \tag{4.4}
\]

Thus the construction can be repeated any finite number of times. For every $N\ge1$, it gives exactly $3N$ selected bends, all segments of positive length, ending at the same $Q$. Before the earliest selected $H_1$ bend, extend the path indefinitely backward in direction $g=m_0\ne0$, with initial principal charge zero. This produces a proper path with finitely many changes of velocity. Reversing its orientation yields the required forward word $(1,2,3)^N$.

At $\kappa=0$, $R=\begin{psmallmatrix}1&b/a\\0&1\end{psmallmatrix}$: this is the parabolic case. At $\kappa<0$, $R$ has trace greater than two and positive real reciprocal eigenvalues: this is the hyperbolic case. The coefficient certificate uses only cone preservation, not any asymptotic spectral assertion.

## 5. Why these paths are legitimate broken lines

This section addresses three possible gaps: additional scattering walls, joints, and principal coefficients.

### 5.1 Keeping the initial bends in a positive diagram

Use the standard positive representative of the cluster scattering diagram. GHKK Theorems 1.12–1.13 give consistency, the prescribed incoming diagram, and a positive binomial factorization. In a normalization that combines coincident walls, the local wall function on a generic point of $H_i$ is $1+z_i$, unless a nonparallel wall is also present; the latter points are joints and will be avoided.

For completeness, pure $e_i$-degree scattering cannot create a correction to this local function. Quotient the graded scattering Lie algebra by all degrees not proportional to $e_i$. The resulting algebra is abelian, its only input wall is $H_i$, and its completion requires no extra wall. Equivalence preserves its local crossing function. In a positive representative, factors of pure $e_i$-degree cannot cancel; their combined local function is therefore exactly $1+z_i$. This is enough for each selected maximal term in Section 2, even if the representative splits a wall into pieces.

At every additional wall crossed by the path, select the constant term one. This is a valid term in the broken-line crossing rule. No extra bend or principal charge is required. At each of the $3N$ selected initial crossings the chosen term has coefficient one. Positivity ensures that other broken lines cannot cancel this contribution.

### 5.2 A single generic endpoint avoids all joints

The reduced principal scattering diagram lives in $\mathbb R^3$. Every wall is a rational polyhedral cone of dimension two. Its boundary and the intersection of two nonparallel walls lie in rational subspaces of dimension at most one. The diagram is countable because it has finitely many nontrivial walls at each fixed order.

For a fixed selected bend position, the map from $Q$ to that position is rational linear, has rank two, and has image the corresponding coordinate plane. Indeed, projection onto $H_i$ along a fixed rational direction $m$ with $m_i\ne0$ is rational linear. Each projection between two consecutive selected coordinate planes is an isomorphism: its kernel is spanned by its direction, and that direction is transverse to the starting plane. The required transverse coordinates are respectively $-a,-b,-c$. The first projection from $Q$ has rank two, so all compositions retain rank two.

Let $L$ be this rank-two map onto a selected plane $H_i$, and let $m$ be the direction of the adjacent segment. Since $m_i\ne0$, $m\notin H_i$. If that segment meets a rational joint contained in a rational line $W$, then

\[
LQ\in W+\mathbb Rm.
\]

The subspace $W+\mathbb Rm$ has dimension at most two and cannot contain $H_i$: containment would force equality and hence $m\in H_i$. Thus the displayed condition imposes a nonzero rational linear equation on $Q$. The same argument handles the initial unbounded segment. For the final segment, its starting point is $Q$ itself, and meeting a joint similarly imposes $Q\in W+\mathbb Rm_0$, again a proper rational subspace. Hitting a joint at a selected bend is included as travel time zero.

A segment parallel to another wall can lie in that wall only under another proper rational linear condition. All such conditions are avoided by rational linear independence of the coordinates of $Q$. Since the proof applies to every finite word length and every rational joint, the one fixed $Q$ works for all $N$. In particular there is no unproved perturbation step that might alter the prescribed order or destroy a positive length.

### 5.3 The full principal diagram and finite-order interpretation

The full principal diagram is invariant in the frozen-coordinate directions and projects to the reduced three-dimensional diagram. Lift the mutable path by integrating the frozen components of its decorated exponents, beginning with an arbitrarily fixed full endpoint. Wall incidence and joint avoidance depend only on the mutable projection. The initial frozen exponent is zero; after the $j$-th cycle it is $jk$. Hence the lift satisfies the full principal broken-line velocity rule.

For a fixed $N$, the contribution may equally be read in the finite-order diagram modulo total charge greater than $N(a+b+c)$. Only finitely many walls matter at that order. Additional walls of higher order have only their constant term available for the coefficient $Nk$, because all charge increments lie in $\mathbb N^3$. Thus the argument is coefficientwise in the precise formal sense of GHKK Proposition 3.4. It does not assume convergence or a limit of the family of broken lines as $N\to\infty$.

## 6. Finishing the coefficient proof

For every $N\ge1$, Sections 3–5 produce a genuine broken line with initial exponent $(g,0)$, endpoint the same fixed generic positive point, and final monomial $x^g y^{Nk}$ with coefficient one. Every other contribution to this monomial has nonnegative integer coefficient. Therefore $a_g(Nk)\ge1$. For $N=0$, the straight broken line supplies the constant term of $F_g$, equal to one. Since $k\ne0$, the principal degrees $Nk$ are pairwise distinct, proving infinite Laurent support.

## 7. Novelty boundary and sources

This should **not** be advertised as the discovery of maximal-bend monodromy, the Markov invariant, or the existence of nonregular theta functions. The closest prior mechanism found is Mandel's *Classification of Rank 2 Cluster Varieties*, where rank means matrix rank. Its §3.3 identifies maximally bending paths with straight tropical lines, and §§3.4–4.1 discuss developing maps and infinite winding in negative cases. Those results include the three-by-three matrices considered here at the level of rank. Our current candidate contribution is the explicit label/charge certificate $a_g(Nk)\ge1$, with a fixed positive endpoint, for the above entire parameter region; in the strict region it applies outside $\operatorname{im}B$. Whether this precise certificate or a theorem directly implying it already appears elsewhere remains a literature question.

Primary references checked:

- Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, arXiv:1411.1394v2, Theorems 1.12–1.13, Definition 3.1, Remark 3.2, Proposition 3.4, Proposition 7.1. https://arxiv.org/html/1411.1394v2
- Mandel, *Classification of Rank 2 Cluster Varieties*, SIGMA 15 (2019), 042, arXiv:1407.6241v5, §3.3 and Theorems 4.1–4.2. https://arxiv.org/pdf/1407.6241
- GHK, *Birational geometry of cluster algebras*, arXiv:1309.2573v2, §§5–7. Used only for comparison with existing geometric nonregularity obstructions, not in the proof. https://arxiv.org/html/1309.2573v2

## 8. Independent audit requests

The supplied exact run at 2026-11-14 03:19 UTC tested all 2,633 ordered triples with $1\le a,b,c\le16$ and $\kappa\le0$, using 16 cycles each. All 126,384 selected crossings had strictly positive rational travel times, and every computed return point matched (4.2). All symbolic identities passed. These checks validate the implementation of the formulas; they do not independently validate the diagram/genericity argument or establish novelty.

The exact script checks the stated identities and positive-time mechanism, but does not replace these four conceptual checks:

1. Verify the column convention and the mutable/principal projection against the chosen project notation.
2. Check the positive-diagram normalization argument in §5.1, including the pure-degree quotient.
3. Check that §5.2 excludes every forbidden joint, including on the unbounded incoming ray.
4. Compare the precise coefficient statement, not just the return-map formula, with Mandel and cyclic rank-three literature.

Do not downgrade the theorem to experimental evidence solely because complete scattering diagrams are not computed; the proof constructs a positive contribution at every order. Conversely, do not label its novelty established solely because the displayed formula was not found in a keyword search.
