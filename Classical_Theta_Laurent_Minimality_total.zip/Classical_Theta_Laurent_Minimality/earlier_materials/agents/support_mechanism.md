# An explicit infinite-support certificate from a periodic word of initial walls

2026-11-14, first support-mechanism branch. Scope: classical cluster theta functions. This note is independent of the other branch's coordinate derivation. It uses the standard positive broken-line definition, not the earlier Q-algebra identification, not upper=middle, and not a Li–Pan result. The exact numerical checks validate conventions; the infinite-support conclusion follows from the finite invariant-cone proof.

## 1. Concrete cyclic theorem

Let a,b,c be positive integers and set

\[
B=\begin{pmatrix}0&b&-c\\-b&0&a\\c&-a&0\end{pmatrix},\qquad
\kappa=a^2+b^2+c^2-abc.
\]

Suppose \(\kappa\le0\). Let \(d=\gcd(a,b,c)\), and put

\[
g=\frac1d(-a,ab-c,-b),\qquad k=\frac1d(a,c,b).
\]

Then g and k are integral, k is positive and primitive, and \(Bk=0\). For the principal-coefficient expansion

\[
\vartheta_g=x^g\sum_{p\ge0}a_g(p)z^p,\qquad z_i=y_i x^{Be_i},
\]

one has

\[
\boxed{a_g(Nk)\ge1\quad\text{for every integer }N\ge0.}
\]

Consequently \(\vartheta_g\) has infinite Laurent support. This is an explicit unbounded family of nonzero coefficients, rather than an inference from an unbounded outer envelope.

For \(a=b=c=m\ge3\), the statement simplifies to

\[
g=(-1,m-1,-1),\qquad a_g(N,N,N)\ge1\quad(N\ge0).
\]

The same seed has the finite labels \(e_1,e_2,e_3\), whose theta functions are the initial cluster variables. Thus these seeds contain both finite and infinite labels. No matrix-wide Laurent-finiteness certificate can apply to them.

### 1.1 Three maximal bends return the mutable exponent

First use the unscaled vector \(\bar g=(-a,ab-c,-b)\). The three initial walls are the full coordinate hyperplanes, with attached functions \(1+z_1\), \(1+z_2\), \(1+z_3\). Bend successively at these walls, choosing their highest available binomial terms. The mutable exponents after the first and second bends are

\[
m_1=(-a,-c,ac-b),\qquad m_2=(bc-a,-c,-b).
\]

The third bend returns \(m_3=\bar g\). The root increments are respectively \(ae_1,ce_2,be_3\), so one period adds \((a,c,b)\). At each chosen wall the corresponding incoming mutable coordinate is negative, with absolute values a,c,b. Its maximal binomial coefficient is one.

Since \(\kappa\le0\), the inequalities \(bc>a\), \(ac>b\), and \(ab>c\) hold: for example \(abc\ge a^2+b^2+c^2>a^2\).

This exponent calculation alone is insufficient. The rest of the proof checks that arbitrarily many such periods are actual broken lines, with positive segment lengths and a final endpoint in the positive chamber.

### 1.2 Backward flight between the three walls

At the last wall write the projected bend point as \(v_C=(X,Y,0)\). Trace the broken line backward using the preceding exponents. The previous second-wall and first-wall points are

\[
v_B=v_C+\frac{Y}{c}m_2
 =\left(X+\frac{bc-a}{c}Y,0,-\frac bcY\right),
\]

\[
v_A=v_B+\frac{(v_B)_1}{a}m_1
 =\left(0,-\frac ca(v_B)_1,
       -\frac bcY+\frac{ac-b}{a}(v_B)_1\right).
\]

Write \(X_B=(v_B)_1\) and \(Z_A=(v_A)_3\). All these backward segment times are strictly positive provided

\[
Y>0,\qquad X_B>0,\qquad Z_A>0.
\]

Tracing further backward with exponent \(\bar g\) reaches the previous third wall at

\[
v_C'=v_A+\frac{Z_A}{b}\bar g.
\]

Thus \((X',Y')^T=M(X,Y)^T\), where

\[
M=\begin{pmatrix}
\dfrac{b-ac}{b}&\dfrac{a^2+b^2-abc}{b}\\[2mm]
\dfrac{abc-b^2-c^2}{b}&1-\kappa+\dfrac{ac}{b}
\end{pmatrix}.
\]

Direct multiplication gives

\[
\det M=1,\qquad\operatorname{tr}M=2-\kappa.
\]

These formulas include \(\kappa=0\); no hyperbolic eigenvector assumption is used.

### 1.3 A rational invariant cone

In the plane \(z=0\), set

\[
v_0=(0,1),\qquad
v_1=(M-I)v_0
 =\left(\frac{\kappa-c^2}{b},-\kappa+\frac{ac}{b}\right).
\]

They are linearly independent because \(\kappa-c^2<0\). Cayley–Hamilton gives the exact formulas

\[
Mv_0=v_0+v_1,\qquad
Mv_1=-\kappa v_0+(1-\kappa)v_1.
\]

Therefore the full-dimensional rational cone

\[
\mathscr C=\mathbb R_{\ge0}v_0+\mathbb R_{\ge0}v_1
\]

is invariant under M. Its relative interior is invariant as well. When \(\kappa=0\), the matrix in this basis is \(\left(\begin{smallmatrix}1&0\\1&1\end{smallmatrix}\right)\); for \(\kappa<0\) its entries are positive except for none of the two diagonal entries. In particular, no nonzero state is sent to zero.

The three strict flight inequalities hold on every nonzero vector in \(\mathscr C\). Their values on the generators are:

| State | Y | \(X_B\) | \(Z_A\) |
|---|---:|---:|---:|
| \(v_0\) | 1 | \((bc-a)/c\) | \((c^2-\kappa)/a\) |
| \(v_1\) | \(-\kappa+ac/b\) | \(b-\kappa(bc-a)/c\) | \((c^2-\kappa)(1-\kappa)/a\) |

All six entries are strictly positive. Each intermediate coordinate other than the coordinate of its designated wall has the indicated strict sign. Interior states also have X<0 and Y>0 on the third wall, so the chosen bend points are never intersections of two initial coordinate walls.

### 1.4 Exit into the positive chamber

Take

\[
u=v_0+\epsilon v_1,\qquad 0<\epsilon<\frac{a}{bc}.
\]

This is an interior state. The exact identity

\[
a u_Y+(ab-c)u_X=a-\epsilon bc>0
\]

implies that the interval

\[
-\frac{u_X}{a}<s<\frac{u_Y}{ab-c}
\]

is nonempty. For any s in this interval,

\[
Q=(u_X,u_Y,0)-s\bar g
\]

has all three coordinates positive. This supplies the last segment after the last third-wall bend. Starting at u and applying M backward N−1 times constructs the preceding complete periods. After the earliest first-wall bend, continue the incoming ray backward with exponent \(\bar g\). There is no prescribed incoming position, only the prescribed asymptotic exponent, so that ray is allowed.

All flight inequalities are strict and the cone is two-dimensional in the last wall. The pairs (u,s) satisfying the exit inequalities contain an open set. For each fixed N one may perturb (u,s) inside that set so the finite prescribed broken line misses all joints relevant through degree \(N(a,c,b)\). The maps between successive wall hyperplanes are linear isomorphisms on those hyperplanes, because the corresponding wall components of the incoming and outgoing exponents are nonzero. Thus genericity is not lost under an intermediate projection. Every additional wall crossing is taken with its constant term. Only finitely many walls matter for the specified coefficient. This is the usual finite-truncation interpretation of broken lines, not an assertion that a single rational endpoint avoids all joints at all orders.

The initial positive chamber value of each coefficient is independent of the generic endpoint chosen within that chamber. Hence a separate generic endpoint for each N proves nonvanishing of the same coefficient \(a_{\bar g}(N(a,c,b))\).

The full principal exponent also accumulates frozen degree. This causes no obstruction: every initial wall depends only on the mutable projected coordinates. Given the projected broken line and any final frozen endpoint, lift the segments backward using their full exponents \((m,p)\). This produces a full broken line with initial exponent \((\bar g,0)\), final root degree \(N(a,c,b)\), and all the same wall intersections.

Finally divide all three mutable velocities and all bend multiplicities by d. The spatial paths are unchanged after multiplying flight times by d. All multiplicities remain integral, including the label coordinate \((ab-c)/d\). The initial-wall maximal binomial coefficients remain one. This proves the stated primitive version.

## 2. An abstract finite certificate for arbitrary rank

The preceding argument has a reusable finite input format. It is not claimed to be a complete characterization of infinite theta functions.

Fix an integer exchange matrix B and an integral mutable theta label g. Choose a nonempty word of mutable indices \(i_1,\ldots,i_\ell\) and positive integral bend multiplicities \(r_1,\ldots,r_\ell\). Put

\[
m_0=g,\quad m_j=m_{j-1}+r_jBe_{i_j},\quad
\Delta=\sum_{j=1}^{\ell}r_j e_{i_j}.
\]

Require:

1. \(m_\ell=g\), equivalently \(B\Delta=0\).
2. Each selected binomial coefficient is legal: \(0<r_j\le |(m_{j-1})_{i_j}|\). In particular every relevant coordinate is nonzero.
3. The following finite rational invariant-cone and exit data exist.

Let \(H=\{v:v_{i_\ell}=0\}\). Starting at v in H, trace backward with exponent \(m_{\ell-1}\) to wall \(i_{\ell-1}\), then with \(m_{\ell-2}\) to wall \(i_{\ell-2}\), down through wall \(i_1\), and finally with \(g\) to the preceding copy of wall \(i_\ell\). To hit a wall i while tracing backward with exponent m, the operation is

\[
P_{i,m}(v)=v-\frac{v_i}{m_i}m,
\qquad \tau_{i,m}(v)=-\frac{v_i}{m_i}.
\]

The composite is a rational linear map \(P:H\to H\); every intermediate time is an explicit rational linear form on H.

Supply a rational matrix V with n−1 linearly independent columns in H, and a rational matrix A, such that

\[
PV=VA,\qquad A\ge0,\qquad\det A\ne0.
\]

Require each intermediate time form to be strictly positive on every column of V. This makes every nonzero point of the simplicial cone \(V\mathbb R_{\ge0}^{n-1}\) legal and makes its interior invariant. Finally give positive rational t and s with

\[
Q=Vt-sg\in\mathbb R_{>0}^n.
\]

Every part of this certificate can be checked by exact rational arithmetic and strict linear inequalities. The exit condition is a finite strict rational feasibility problem. It also forces \(g_{i_\ell}<0\), because the last-wall coordinate of Vt is zero while that of Q is positive.

### Certificate theorem

Under these finite checks,

\[
a_g(N\Delta)\ge
\left(\prod_{j=1}^{\ell}
\binom{|(m_{j-1})_{i_j}|}{r_j}\right)^N>0
\quad\text{for every }N\ge1.
\]

The proof repeats the backward invariant-cone construction. At a designated wall the crossing orientation chooses the nonnegative power \(|m_i|\) of \(1+z_i\), so the selected binomial factor is positive. All unselected wall crossings use their constant term. Full-dimensionality, nonzero wall components, and strict flight/exit inequalities allow a generic finite-degree perturbation for every N. Root degrees add, and \(\Delta\ne0\). Positivity prevents cancellation. The same reasoning applies to skew-symmetrizable data in the project's initial-wall coordinates; only coordinate hyperplanes and the integral root increments \(Be_i\) are used.

This is a finite infinite-support certificate using only the initial walls. It supplies an enumerable family of certified infinite labels. It does not assert that every infinite label admits such a certificate, and the requirement \(B\Delta=0\) makes this particular periodic-exponent form inapplicable to invertible B. Generalized growing-exponent words would need a separate proof.

## 3. Exact computations

The program `support_mechanism_data/verify_cyclic_pump.py` calls the independent incoming-Schur coefficient routine from round two, through the round-three CLI class. Results:

| a,b,c | Unscaled g | Degree | Exact coefficient |
|---|---|---|---:|
| 3,3,3 | (−3,6,−3) | (3,3,3) | 1 |
| 3,3,3 | (−3,6,−3) | (6,6,6) | 2506 |
| 3,3,4 | (−3,5,−3) | (3,4,3) | 1 |
| 4,4,4 | (−4,12,−4) | (4,4,4) | 1 |

As controls outside the stated range, (2,2,2) and (2,3,3) have positive first tested coefficients too. This illustrates why one or finitely many positive coefficients do not establish infinite support. The theorem relies on the invariant cone and all N.

The earlier single-bend scanner searched actual cluster facets through mutation depth nine for B(a,a,a), g=Be1, a=2,3,4. It found only the initial e2 contribution. That negative exploratory result did not imply finiteness. It redirected attention to repeated multi-bend words. Its code and result are retained as `single_bend_scan.py/json`.

A Wolfram call checked 1000 exact skew-pairing identities relevant to the discarded derivative-only loop route. These random checks are not a proof and are not used in the cyclic theorem.

## 4. Why the earlier pure derivative loop idea was dropped

The prior positive divided-derivative expansion has branches

\[
g\longmapsto g+r+B(r+q),\qquad r,q\ge0.
\]

A nontrivial closed sequence of such branches would give

\[
0=R+B\Delta,\qquad0\le R\le\Delta,\qquad R\ne0.
\]

Multiplying by \(\Delta^TD\) yields

\[
0=\Delta^TDR>0,
\]

because DB is skew and every positive coordinate of R has a positive coordinate of \(\Delta\). Thus a pure derivative return cannot supply a pump. The wall-word construction has different label dynamics: each bend adds only \(Be_i\), without the extra positive derivative shift. This observation was used to change route promptly, not developed as an independent exclusion project.

## 5. Dependencies and novelty status

The only substantive external theorem used for the cyclic certificate is the classical theta/broken-line construction with positive wall functions and coefficient invariance within the initial cluster chamber (GHKK). The initial wall functions and their full hyperplane supports are part of that construction. The proof does not rely on any 2026 result, the prior Q models, the regular-label monoid, a geometric \(\Gamma(X)=k[K]\) obstruction, or a finite-theta-span hypothesis.

The finite-word certificate is a direct constructive use of established broken-line geometry; the novelty candidate is the explicit invariant-cone family and the resulting named unbounded support degrees. Historical priority has not been decided by this branch. The parent literature branches are checking the cyclic/Markov family and related scattering constructions before making any novelty claim.

For \(\kappa<0\), the unscaled vectors satisfy \(\bar g\cdot(a,c,b)=-\kappa>0\). Thus the label is outside im B in the skew-symmetric rank-three case, and this is not merely a re-expression of the earlier im(B) geometric obstruction. For \(\kappa=0\), overlap with existing geometric nonregularity results must still be disclosed, while the explicit coefficient family remains the computational content to compare.
