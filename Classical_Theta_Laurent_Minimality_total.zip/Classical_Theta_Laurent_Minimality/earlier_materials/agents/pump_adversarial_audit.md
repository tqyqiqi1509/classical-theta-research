# Independent audit of the periodic initial-wall support certificate

Date: 2026-11-14. Scope: classical principal-coefficient theta functions. This is a fresh audit of `CYCLIC_THREE_PARAMETER_PUMP.md` and `support_mechanism.md`; it does not assume either draft is correct. No Li–Pan result is used. No 2026 paper is needed for the proof.

## 1. Verdict and exact scope

**The three-parameter coefficient theorem passes this audit.** I found no fatal gap in its wall-crossing signs, positive travel times, genericity, or principal lift. The general finite-word invariant-cone certificate is also sufficient with its stated strict positivity and full-rank hypotheses. Its proof should include the projection-isomorphism argument in §3 below, which makes explicit a step only sketched in the first draft.

The result is:

\[
B=\begin{pmatrix}0&b&-c\\-b&0&a\\c&-a&0\end{pmatrix},\quad
\kappa=a^2+b^2+c^2-abc\le0,\quad d=\gcd(a,b,c),
\]

\[
g_*=d^{-1}(-a,ab-c,-b),\qquad k=d^{-1}(a,c,b)
\quad\Longrightarrow\quad
a_{g_*}(Nk)\ge1\quad(N\ge0).
\tag{1}
\]

Here the expansion is
\(\theta_g=x^g\sum_{p\ge0}a_g(p)z^p\), with
\(z_i=y_i x^{Be_i}\). The conclusion is infinite support in the **principal** Laurent variables. It does not require or justify specializing an infinite series at \(y=1\).

This audit establishes mathematical sufficiency relative to the classical scattering construction. It does **not** establish publication priority. Maximum bending, monodromy, and freezing are existing mechanisms and should not be described as newly discovered here.

Two useful consequences are proved below:

1. The same nonzero ray survives inside any larger matrix containing this principal submatrix, even if the larger matrix is invertible.
2. Every componentwise smaller restricted label inherits the same coefficient lower bounds.

## 2. Checks against the actual broken-line definition

The primary source is GHKK, [arXiv:1411.1394v2](https://arxiv.org/html/1411.1394v2), Definition 3.1, Remark 3.2, Proposition 3.4, Theorem 1.13, Proposition 6.4, and Lemma 8.9. The relevant facts have the following limited uses: decorated velocity is minus the exponent; a crossing uses a nonnegative wall-function power; every fixed charge is a finite calculation; positive diagrams prevent cancellation; and principal walls are invariant in the frozen tropical directions. These are inputs, not new claims of this project.

### 2.1 The sign really is an absolute value

At an initial wall \(q_i=0\), let the incoming mutable exponent be \(m\). Since the forward velocity is \(-m\), the oriented primitive normal in the crossing rule is chosen so that its pairing with \(m\) is positive. In standard initial-wall coordinates, the crossing therefore acts on this decorated monomial by

\[
x^m y^p(1+z_i)^{|m_i|}.
\]

Thus any integer \(0\le r\le |m_i|\) gives the legitimate new exponent
\((m+rBe_i,p+re_i)\) with coefficient \(\binom{|m_i|}{r}\). This remains true for either direction of crossing. No reciprocal binomial series is being used.

For (1), the successive mutable exponents before dividing by \(d\) are

\[
(-a,ab-c,-b),\quad (-a,-c,ac-b),\quad(bc-a,-c,-b),
\]

and then the first one again. The relevant incoming coordinates are \(-a,-c,-b\); hence all three selected terms are legitimate highest terms of coefficient one. Division by \(d\) leaves them integral and changes travel times by a common factor \(d\).

### 2.2 Pure initial-wall factors cannot acquire hidden corrections

At a generic point of \(H_i\), every incident wall normal is proportional to \(e_i\), unless the point is in a nonparallel intersection. Mod out the positive root grading by the ideal spanned by roots whose support is not contained in \(\{i\}\). The remaining Lie algebra is abelian and its input is exactly the single wall \((H_i,1+z_i)\). Consistency and uniqueness of completion imply that its local combined crossing function is \(1+z_i\).

A positive representative cannot hide cancellations between additional pure-root factors. Consequently one may either keep the initial wall itself or combine its coincident pieces; the local function needed above is the same. A wall of mixed root degree cannot coincide generically with \(H_i\), since its normal is not proportional to \(e_i\).

This proves the required local claim without assuming that all outgoing walls are known explicitly.

### 2.3 Crossing other walls without bending is allowed

Every other encountered wall has a function with constant term one. Selecting that term leaves both exponent and coefficient unchanged. It causes no change of velocity. The broken-line definition only imposes a nonconstant-term choice where the path bends; crossing a wall while remaining straight is allowed.

For the coefficient \(Nk\), all relevant root increments have total degree at most \(|Nk|\). One can work in that finite-order diagram. Higher-order factors cannot contribute to this coefficient because root increments are nonnegative. The first unbounded segment is proper because \(g_*\ne0\). There is no requirement to terminate it on another wall or in a prescribed incoming chamber.

### 2.4 Principal lift

The full principal diagram has normals \((n,0)\) and is invariant in the frozen tropical directions. Start with a chosen full endpoint. On every reverse segment, integrate the full decorated exponent \((m,p)\). Its mutable projection is the proposed three-dimensional segment; its frozen displacement is determined uniquely. Wall incidence and joint avoidance are controlled by the mutable projection. The incoming charge is zero and each period increases the final charge by \(k\).

Thus returning mutable momentum does not mean that the full decorated exponent returns. The final monomials \(x^{g_*}y^{Nk}\) are distinct, which is exactly why (1) proves infinite support.

## 3. Genericity, including the infinite incoming ray

Here is a general lemma that closes the genericity step of both drafts.

Let a finite initial-wall word have exponents \(m_0,\ldots,m_\ell=m_0\), wall indices \(i_1,\ldots,i_\ell\), and positive legal increments \(r_j\). At the \(j\)-th wall,

\[
m_j=m_{j-1}+r_jBe_{i_j},\qquad
0<r_j\le |(m_{j-1})_{i_j}|.
\]

Since \(B_{ii}=0\), the normal component is unchanged by the bend:
\((m_j)_{i_j}=(m_{j-1})_{i_j}\ne0\). On a segment between consecutive designated walls, its exponent therefore has nonzero normal component at **both** endpoint walls. Projection along that exponent restricts to a linear isomorphism between the two wall hyperplanes. The same holds for the final-to-first transition because \(m_\ell=m_0\).

It follows that every designated bend point is a rational linear image \(LQ\) of the endpoint, with image the full designated hyperplane \(H\) and rank \(n-1\).

Every joint is contained in a rational subspace \(W\) of dimension at most \(n-2\). If a segment adjacent to \(H\), with exponent \(m\notin H\), meets that joint, then

\[
LQ\in W+\mathbb Rm.
\]

The right-hand subspace has dimension at most \(n-1\) and cannot contain \(H\): otherwise it would equal \(H\), forcing \(m\in H\). Therefore joint incidence imposes a nontrivial rational homogeneous linear equation on \(Q\). Exactly the same argument applies to the entire unbounded incoming ray. A straight segment lying in a wall also imposes a proper rational equation; if its direction lies in that wall, the adjacent full hyperplane cannot lie there as well because the direction is transverse to that adjacent hyperplane.

There are countably many rational walls, joints, and finite word lengths. Consequently an endpoint with rationally linearly independent coordinates avoids all of these bad equations at once. For the three-parameter theorem, the already proved travel inequalities hold for every positive endpoint, so one can take, for example,

\[
Q=(\sqrt2,\sqrt3,\sqrt5).
\]

The first draft's \((1,\sqrt2,\sqrt3)\) is also sufficient for homogeneous rational equations. The all-irrational choice above simply avoids any distraction when comparing with the wording of GHKK Theorem 3.5.

For the general cone certificate, let \(V\) span the last wall and let \(Q_0=Vt-sg\) satisfy the strict exit conditions. The last coordinate gives \(g_{i_\ell}<0\), so \((V,-g)\) is an invertible \(n\times n\) matrix. The allowed endpoints therefore contain a full-dimensional open set. Choose a generic endpoint there. All intermediate times remain positive for every repetition because the invariant cone sends its interior into itself. Thus a single generic endpoint works for every finite repetition; using a different generic endpoint at each order would also suffice.

This verifies the general certificate's lower bound

\[
a_g(N\Delta)\ge
\left(\prod_{j=1}^{\ell}\binom{|(m_{j-1})_{i_j}|}{r_j}\right)^N,
\qquad \Delta=\sum_jr_je_{i_j}.
\tag{2}
\]

The certificate remains only a sufficient test. Its full-dimensional cone and strict flight inequalities are essential to this proof and must not be omitted from an implementation.

## 4. Arbitrary-rank inheritance, including invertible matrices

Let \(B\) be an integer exchange matrix, \(I\) a subset of mutable vertices, and \(C=B_{I,I}\). For an initial label \(g\), and any \(p\in\mathbb N^I\), one has the coefficient identity

\[
\boxed{a^B_g(\iota_Ip)=a^C_{g_I}(p).}
\tag{3}
\]

Here \(\iota_I\) extends a root vector by zero outside \(I\). This is the standard freezing face operation, followed by removal of spectator mutable directions. The freezing theorem itself is **already known**: Qin, [Applications of the freezing operators on cluster algebras, arXiv:2407.03186v1](https://arxiv.org/html/2407.03186v1), Lemma 5.1 and Theorem 5.2.

For clarity, (3) can be checked directly. Discard all root degrees with a nonzero coordinate outside \(I\). This is a Lie-algebra quotient because root degrees only add. The surviving scattering problem has precisely the initial walls indexed by \(I\). Its wall normals and all projected flight rules depend only on \(C\). The off-block entries contribute spectator mutable powers to each root monomial, but do not affect any normal pairing. The initial outside coordinates \(g_{I^c}\) likewise do not enter those pairings. Therefore the scalar coefficients of the surviving roots are exactly the coefficients of the principal problem for \(C\).

An entirely algebraic verification uses the universal incoming recurrence: when the target root is supported on \(I\), every intermediate root is too; both the signs and the shifted pairings only see \(C\) and \(g_I\). Induction on total root degree gives (3).

Applying (3) to (1), for **any** larger matrix with the cyclic principal submatrix above and **any** values of the outside label coordinates,

\[
g_I=g_*\quad\Longrightarrow\quad
a^B_g(N\iota_Ik)\ge1\quad(N\ge0).
\tag{4}
\]

The larger matrix need not have a kernel. The full mutable exponent may drift outside \(I\), even though its \(I\)-projection returns. Thus (4) extends the support mechanism beyond the limitation \(B\Delta=0\) of a globally periodic mutable word.

For a concrete convention check, take

\[
E=\begin{pmatrix}
0&4&-5&2\\-4&0&3&-3\\5&-3&0&1\\-2&3&-1&0
\end{pmatrix},\quad
g=(-3,7,-4,17),\quad\Delta=(3,5,4,0).
\]

The first three vertices have \((a,b,c)=(3,4,5)\), \(\kappa=-10\). The Pfaffian is \(-5\), so \(\det E=25\), and \(E\Delta=(0,0,0,5)\). Nevertheless (4) gives \(a^E_g(N\Delta)\ge1\) for all \(N\). The fourth vertex is coupled to all three others; this is not a direct sum.

## 5. Coefficientwise inheritance under decreasing the label

For every initial nonnegative vector \(u\in\mathbb N^n\),

\[
\boxed{a_g(p)\ge a_{g+u}(p)\quad\text{for every }p\in\mathbb N^n.}
\tag{5}
\]

This is a consequence of the existing positive formal theta multiplication, not a newly invented positivity principle. Here is the complete argument, including formal theta labels outside the regular set.

Since \(\theta_u=x^u\), positive formal multiplication gives

\[
x^u\theta_g=\theta_{g+u}
 +\sum_{r\in\mathbb N^n\setminus\{0\}}c_r y^r\theta_{g+u+Br},
\qquad c_r\ge0.
\]

The principal root grading forces the displayed label form: every pair of broken lines contributes total root increment \(r\ge0\). At \(r=0\), both lines are straight, giving coefficient exactly one. Dividing by \(x^{g+u}\),

\[
F_g=F_{g+u}+\sum_{r>0}c_r z^rF_{g+u+Br}.
\]

All coefficients on the right are nonnegative, proving (5) coefficient by coefficient. No finiteness assumption on \(F_g\) or \(F_{g+u}\) is used.

Combining (4) and (5) gives the larger family

\[
\boxed{g_I\le g_*\text{ componentwise}
\quad\Longrightarrow\quad
a^B_g(N\iota_Ik)\ge1\quad\text{for all }N\ge0.}
\tag{6}
\]

This is a general region of certified infinite labels, with all outside label coordinates arbitrary. It is not a complete classification of finite labels.

## 6. Independent exact verification and route record

The new script `pump_audit_verify.py` reconstructs all selected projections from the matrix and legal bend multiplicities; it does not call either first-wave return-matrix formula. Four parameter choices, including the parabolic boundary and asymmetric strict cases, pass 20 exact rational periods each.

The independent incoming-Schur coefficient calculation gives:

| Matrix/label | Root degree | Exact coefficient |
|---|---|---:|
| \((a,b,c)=(3,4,5),\ g=(-3,7,-4)\) | \((3,5,4)\) | 1 |
| Coupled invertible \(E\) above, \(g=(-3,7,-4,17)\) | \((3,5,4,0)\) | 1 |
| Same rank-three matrix, \(g'=(-4,5,-7)\le g\) | \((3,5,4)\) | 212300 |

The whole computed root face, not only its final coefficient, agrees between rank three and rank four. The whole computed box satisfies coefficientwise dominance for the decreased label. These are checks of conventions and implementation, not the proof of statements for all \(N\).

Audit route record:

- **Tried to invalidate the crossing sign:** rejected as an objection after reading GHKK Remark 3.2; the exponent is a positive absolute value.
- **Tried to invalidate full-dimensional genericity after many projections:** rejected as an objection; legality and zero diagonal imply every adjacent projection is an isomorphism. The missing explanation is supplied in §3.
- **Tried to invalidate the incoming infinite ray:** rejected as an objection; the same proper-rational-subspace argument treats the whole ray, and the incoming exponent is nonzero.
- **Checked hidden pure-axis wall corrections:** the quotient argument proves the needed local combined factor. No assumption about unknown outgoing-wall multiplicities is used.
- **Checked the principal lift:** frozen translation invariance gives it explicitly; mutable periodicity does not collapse the principal charges.
- **Tested higher-rank obstruction:** the initial globally periodic certificate cannot apply to invertible matrices, but freezing gives (4), so this restriction does not block the inherited mechanism.
- **Corrected one arithmetic communication error:** an interim message guessed \(\det E=1\); immediate Pfaffian calculation gives the correct value \(25\). Only the corrected value is used here.
- **Priority boundary:** freezing and formal positivity are old inputs. The exact three-parameter coefficient ray remains the candidate contribution requiring the separate novelty search.

The report intentionally does not turn these successful checks into a claim that the user's full Laurent stopping problem or ordinary-atlas strong-positive minimality problem has been solved.
