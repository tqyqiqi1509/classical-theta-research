"""Exact all-parameter certificate for a nonperiodic initial-wall pump.

The mathematical parameter is an integer m >= 4. We prove the required
polynomial inequalities by expanding at m=t+3 and checking nonnegative integer
coefficients and nonzero polynomials; t>0 then makes every one strict.
This validates a finite cone certificate, not a numerical inference of infinity.
"""
from pathlib import Path
import json
import sympy as sp

m, t = sp.symbols('m t')
I = sp.eye(3)
B = sp.Matrix([[0,m,-m],[-m,0,m],[m,-m,0]])
Ts = [I-B[:,i]*I[i,:] for i in range(3)]
S = Ts[2]*Ts[1]*Ts[0]
R = sp.simplify(S.inv())
L = sp.Matrix([[1,0,0],[m,1,0],[m*m-m,m,1]])
H = m*m*(m-3)
g0 = sp.Matrix([-1,m-1,-1])
v = sp.Matrix([-1,1,0])
V = sp.Matrix.hstack(g0,v,(S-I)*v)
Q0 = sp.ones(3,1)
w0 = R*Q0
W = sp.Matrix.hstack(w0,(R-I)*w0,(R-I)**2*w0)
A = sp.Matrix([[1,0,0],[0,1,H],[0,1,H+1]])
C = sp.Matrix([[1,0,0],[1,1,H],[0,1,H+1]])

def zero_matrix(M):
    return all(sp.expand(x)==0 for x in M)

assert zero_matrix(S*V-V*A)
assert zero_matrix(R*W-W*C)
assert sp.factor(V.det()) == -m*(m-3)*(m-2)
assert sp.factor(W.det()) == 3*m**5*(m-2)

forms = {'negative_itinerary':-L*V,'positive_position':L*W}
for j in range(2):
    lj, lh = L[j,:], L[j+1,:]
    forms[f'within_cycle_{j+1}'] = V.T*(lj.T*lh-lh.T*lj)*W
lj, lh = L[2,:], L[0,:]
forms['between_cycles'] = V.T*(lj.T*lh-(lh*S).T*(lj*R))*W

cert = {}
for name, matrix in forms.items():
    entries=[]
    for x in matrix:
        shifted=sp.Poly(sp.expand(x.subs(m,t+3)),t)
        coefficients=[int(z) for z in reversed(shifted.all_coeffs())]
        assert any(c>0 for c in coefficients), (name,x)
        assert all(c>=0 for c in coefficients), (name,x)
        entries.append({'m_polynomial':str(sp.factor(x)),
                        'coefficients_in_t_ascending':coefficients})
    cert[name]={'shape':list(matrix.shape),'entries':entries}

def exact_instance(M, Nmax=20):
    b=B.subs(m,M); s=S.subs(m,M); r=R.subs(m,M)
    vmat=V.subs(m,M); wmat=W.subs(m,M)
    g=sp.Matrix([-2,M,-1]); q0=sp.ones(3,1)
    qcols=s*wmat
    aa=max(abs(int(x)) for x in qcols[:,1])
    bb=max(abs(int(x)) for x in qcols[:,2])
    eps=sp.Rational(1,1+2*(aa+bb))
    q=qcols*sp.Matrix([1,eps,eps*eps])
    assert all(x>0 for x in q)
    momenta=[g]; degrees=[sp.zeros(3,1)]; charges=[]
    for step in range(3*Nmax):
        i=step%3; old=momenta[-1]; bend=-old[i]
        assert bend>0 and bend.is_Integer
        momenta.append(old+bend*b[:,i])
        degree=degrees[-1].copy();degree[i]+=bend
        degrees.append(degree);charges.append(int(bend))
    tested=[]
    for N in (1,2,3,5,10,Nmax):
        point=q.copy(); times=[]
        for step in range(3*N-1,-1,-1):
            i=step%3; momentum=momenta[step+1]
            flight=-point[i]/momentum[i]
            assert flight>0,(M,N,step,flight)
            point+=flight*momentum;times.append(flight)
        assert momenta[3*N] == s**N*g
        assert momenta[3*N] == g+b*degrees[3*N]
        tested.append({'N':N,'degree':list(map(int,degrees[3*N])),
                       'terminal_momentum':list(map(int,momenta[3*N])),
                       'all_flights_strictly_positive':True})
    return {'m':M,'g':list(map(int,g)), 'epsilon':str(eps),
            'rational_endpoint_for_numerical_check':list(map(str,q)),
            'cases':tested}

out={'scope':'all integer m >= 4, exact symbolic cone certificate',
     'S':str(S),'R':str(R),'momentum_generators_V':str(V),
     'position_generators_W':str(W),'forward_matrix_A':str(A),
     'backward_matrix_C':str(C),
     'det_V':str(sp.factor(V.det())),'det_W':str(sp.factor(W.det())),
     'strict_positive_polynomial_certificates':cert,
     'number_of_positive_polynomials':sum(M.rows*M.cols for M in forms.values()),
     'exact_flight_instances':[exact_instance(M) for M in range(4,17)]}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'all_parameter_identities':'passed',
                  'positive_polynomials':out['number_of_positive_polynomials'],
                  'parameter_instances':len(out['exact_flight_instances']),
                  'N_max':20,'output':str(Path(__file__).with_suffix('.json'))}))
