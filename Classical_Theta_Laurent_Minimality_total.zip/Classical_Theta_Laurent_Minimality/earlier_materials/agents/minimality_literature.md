# 经典 theta 最小性：现有归属、CTB 精确接口与几何缺桥

工作分支：minimality_literature。检索与计算日期：2026-11-14。首波交接时间约 03:20 UTC。

本报告的对象始终是经典丛代数。量子参数只作为唯一确定 Berenstein–Zelevinsky 三角基的辅助变量，最终全部在 v=1 比较。没有使用 Li–Pan 的任何结论。没有把边界、估值或图册变更重新包装为一般最小性定理。

## 1. 当前结论与必须保留的归属

1. **CTB 向 theta 的一般非负换基不是本项目新提出的猜想。** Fan Qin 的 2025 综述 [Q25] Remark 1.1 明确把“每个共同三角基元素在 theta 基上非负展开”列为实例提示的一般现象，条件是初始矩阵反对称。该处没有证明，也没有称其为定理。紧接着的解释性段落语气较确定，引用时必须回到前面的限定语。
2. Mandel 的 atomicity [M16] 是 **scattering atlas** 的结论。普通 cluster atlas 中强正基最小性不能直接援引它。[DM19] §1.4 已明确讨论这个未闭合的接口；其“最小”首先是 Laurent 系数序，不宜不加说明改成全 theta 换基序。
3. **现成的任意秩 CTB→theta 非负定理或负系数反例，本次检索没有找到。** 这个表述只报告检索结果，不是全球不存在性断言。
4. BZ 的有限精确算法与 Qin 的无环比较定理提供了一个可运行入口。我们得到连通野型秩三中 CTB≠theta 的完整公式，并逐项核验定义与支持。此处是机制诊断材料，不主张这些低指标恒等式本身构成新的理论贡献。
5. 几何路线缺的不只是“再用一次纯性”：还没有找到把任意 CTB 对象送到任意 theta 系数提取图册的已知有效函子。Braden 纯性允许任意整移位；Davison–Mandel 的 DT 纯偶性处理墙因子，不处理这个任意 CTB 对象。

## 2. 不可混同的四个命题

设 theta 基存在于所讨论的经典代数中，B 是另一 pointed 基。

| 命题 | 所需信息 | 现有结论与缺口 |
|---|---|---|
| cluster Laurent 正性 | 每个普通种子中 Laurent 系数非负 | 强正且含丛单项式的自然基通常具备；这并不检查非丛图册。 |
| scattering 正性 | 每个一般散射点的形式展开非负 | Mandel 的系数提取立即给 theta 换基非负。最难的是从上一行推出本行。 |
| cluster atomicity | 普通普遍正锥由 theta 原子生成 | 一般失败/不可普遍假设；不能把 rank 2 的 greedy 不可分解性误作全正锥基性。 |
| strongly positive basis | 基内乘法结构常数非负，并含丛单项式 | 这是对一整个基的条件，比单个元素 Laurent 正性强；一般如何强迫 scattering 正性仍未解决。 |

Qin [Q19] 的 compatibly pointed 基分类允许整数变形系数，给有限支撑和单位三角性，不给这些系数的符号。它适合把问题变成有限精确计算，不适合宣称正性自动成立。

## 3. 可复现的连通野型秩三计算

### 3.1 种子、变量与输出约定

取主系数种子

\[
B=\begin{pmatrix}0&-2&0\\2&0&-1\\0&1&0\end{pmatrix},\qquad
\widetilde B=\binom B{I_3}.
\]

图是连通无环的双箭头链，Cartan 图的谱半径为 \(\sqrt5>2\)，因此不是有限/仿射类型，更不是秩二加孤立顶点。

冻结变量记为 \(y_1,y_2,y_3\)，并令

\[
Y_1=y_1x_2^2,\quad Y_2=y_2x_1^{-2}x_3,\quad Y_3=y_3x_2^{-1}.
\]

脚本中数组 `F[p]` 指 \(x^gY^p\) 的系数；`transition[p]` 指
\(y^p\theta_{g+Bp}\) 的系数。主系数次数与 g 标签均保留，故 B 本身不满秩不会混淆项。

用 BZ 指标 \(a=(-d_1,-d_2,-d_3,0,0,0)\) 时

\[
g=(-d_1+2d_2,-d_2+d_3,-d_3).
\]

### 3.2 首个差异：全部 Laurent 展开与全部换基

在 \(d=(2,2,1)\)、\(g=(2,-1,-1)\) 处，计算给出

\[
L_g=\theta_g+y_1y_2y_3\theta_0.
\tag{A}
\]

具体地，

\[
\begin{aligned}
L_g=x_1^2x_2^{-1}x_3^{-1}(&1+Y_3+Y_2+2Y_2Y_3+Y_2^2Y_3\\
&+Y_1Y_2Y_3+2Y_1Y_2^2Y_3+Y_1^2Y_2^2Y_3).
\end{aligned}
\]

\(\theta_g\) 的展开正是删去 \(Y_1Y_2Y_3\) 那一项。因为
\(g+B(1,1,1)=0\)，该项为 \(y_1y_2y_3\)。这是一条完整的有限恒等式，不是某个次数截断的相等。

最小八个 \(d_i\in\{1,2\}\) 的结果如下。

| d | g | 完整展开 |
|---|---|---|
| (1,1,1) | (1,0,-1) | \(L_g=\theta_g\) |
| (1,1,2) | (1,1,-2) | \(L_g=\theta_g\) |
| (1,2,1) | (3,-1,-1) | \(L_g=\theta_g\) |
| (2,1,1) | (0,0,-1) | \(L_g=\theta_g\) |
| (1,2,2) | (3,0,-2) | \(L_g=\theta_g\) |
| (2,1,2) | (0,1,-2) | \(L_g=\theta_g\) |
| (2,2,1) | (2,-1,-1) | \(\theta_g+y_1y_2y_3\) |
| (2,2,2) | (2,0,-2) | \(\theta_g+y_1y_2y_3\theta_{(0,1,-1)}\) |

前两条修正本身是可达的：\(\theta_0=1\)；\(\theta_{(0,1,-1)}=(x_2+y_3)/x_3\) 是一次变异变量。因此没有把这八个结果冒称为非可达系数问题的解决。

### 3.3 有目的的两次机制压力点

只在同一个种子增加两个指定指标，用来让修正标签进入非刚性区域，没有继续铺新种子或随机小例。

\[
L_{(3,-1,-2)}=\theta_{(3,-1,-2)}
+y_1y_2y_3\theta_{(1,0,-1)}.
\tag{B}
\]

这里 \(d=(3,3,2)\)。修正 theta 的分母向量为 \((1,1,1)\)，其 Tits 值
\(1+1+1-2-1=0\)。根据无环丛范畴的分母/刚性对应，它不是丛单项式：正分母各坐标排除了移位投射项，而非零刚性模的 Tits 值是其正的 End 维数。此标准表示论识别仍交给独立审阅者核对约定。

进一步，令 \(z=y_1y_2y_3\)，则 \(d=(4,4,2)\) 给出

\[
L_{(4,-2,-2)}=\theta_{(4,-2,-2)}+z\theta_{(2,-1,-1)}+z^2.
\tag{C}
\]

中间修正标签正是 (A) 的野型标签，其分母向量 \((2,2,1)\) 的 Tits 值为
\(4+4+1-8-2=-1\)。因此 (C) 包含一个野型、非丛单项式的 theta 修正。全部系数仍是 +1。它可用于检查新的一般正过渡方案是否真的控制了非可达修正。

### 3.4 实现与核验

文件：

- `ctb_probe.py`：自含的精确整数程序；BZ 标准基、bar 校正、经典特化、theta 展开、完整换基及支持重建。
- `ctb_probe_result.json`：4 个 Kronecker 校准项、8 个首批项、2 个机制压力点；各项保留全部 Laurent 支撑及 BZ 定义展开证据。
- `ctb_probe_verify.py`：第二个 incoming 后端，用有符号单位三角矩阵分解替代无环闭式公式。
- `ctb_probe_verify_result.json`：135 个 incoming 系数独立比对、零平行余项检查、首个 theta 完整展开及量子 C 元素。

运行：

```bash
python3 ctb_probe.py
python3 ctb_probe_verify.py
```

算法依据 [BZ12] (1.17)、(1.22)、Theorems 1.1/1.4，而非假定某个 Laurent 正式等于 CTB。对每个 C，独立重新展开 \(C_a-E_a\)，核验

\[
\overline{C_a}=C_a,\qquad
C_a-E_a\in\bigoplus_{r(a')<r(a)}v\mathbb Z[v]E_{a'},\qquad
r(a)=\sum_i[-a_i]_+.
\]

唯一性给出 BZ 元素；[Q16] Theorem 1.4.1 将无环反对称情形的 BZ 基与 Qin 三角基识别。v=1 是所需经典元素。**这里 \(v\mathbb Z[v]\) 的整数系数允许负数**，脚本没有把其误作正锥；事实上首例的 E 校正大量为负，正 theta 过渡不能从 KL 校正的表面符号直接读出。

theta 的无环 incoming 公式为

\[
c(a,m)=\prod_{i=3}^{1}\binom{-m_i-\sum_{j>i}B_{ij}a_j}{a_i}.
\]

独立后端不使用该闭式，而是逐次数恢复负/零/正半空间矩阵因子；135 项比对通过，首例完整 theta 展开也通过该后端复算。每个换基项均重新计算自身的完整无环支持上界，然后重建整个 Laurent 多项式，检查零余项；没有以给定盒子的零余项冒充全恒等式。

辅助 Kronecker 校准 r=1,2,3,4 与已知第二/第一类 Chebyshev 过渡一致。开发时曾把主系数根次数写错成偶步长，产生一条断言失败；原因是标签平移每次 \((1,1)\) 已令 r 降 2。已修正为 \(0\le k\le\lfloor r/2\rfloor\)，没有删掉失败记录来伪造第一次即正确。

## 4. 这些数据对一般机制的实际约束

首例新增根点 \((1,1,1)\) 是 theta 原有点 \((0,0,1)\) 与 \((2,2,1)\) 的中点。新增项不改变 Newton 多面体。第二个修正的线段也被原 theta 的 Newton 多面体包含。因此，初始图册中的所有线性估值、支撑函数和顶点系数都可能相同，而 CTB 与 theta 仍不同。

这与 CMMM 的估值独立不矛盾。估值独立说明有限线性组合的最小值没有消去；它不说明每个 theta 分量一定能成为某个初始线性估值的独占最小项。更不读取该分量系数的符号。对 (A) 可直接看初始 Laurent 的 x^0 系数；对 (C) 的野型修正，这个可达简化已不够。

我们的有限三角换基递推

\[
a_p=F_L(p)-\sum_{q<p}a_qF_{\theta_{g+Bq}}(p-q)
\]

仍包含减法。一次增加更多样本不会消除它。可攻击的一般目标应是把这一递推解释为某个有效对象的 Euler 特征、具有正权的层数，或一个可证明非负的组合计数；只是重复检查它在小盒子上非负没有理论推进。

## 5. 几何正过渡路线：已有部分与精确缺口

若 \(L_g\) 对应某种 IC/简单对象 \(\mathcal P_g\)，希望构造对每个提取点 Q 与单项标签 q 的对象

\[
K_{g;q,Q},\qquad
\chi_c(K_{g;q,Q})=[x^q]\,\iota_Q(L_g).
\tag{G}
\]

在 Q 足够接近目标 theta 标签的区域，[GHKK] Proposition 6.4 的证明与 [M16] 立即把右边识别为 theta 换基系数。若 (G) 的 Euler 特征非负，就得到正过渡。这是已知提取技术与一个尚未构造好的几何接口，不能称为新定理。

需要分别补的部分是：

1. **函子识别**：给出 CTB 对象模型、任意散射 Q 对应的稳定性/HN/吸引子对应，以及积分/特征映射同 \(\iota_Q\) 的交换。普通丛图册上的 q-character/丛特征公式不自动给此交换。
2. **有效性**：该函子的像虽在导出范畴存在，Euler 特征会带奇移位符号。必须证明正确归一化后的纯偶性，或更弱而足够的 Euler 非负。
3. **适用范围**：所有需提取的 Q，而不是只有可达心、绿序列所见区域或有限个壁。

Braden [B03] Theorem 2 给 \(IC(X)^{!*}\) 分解为带整数移位的 IC 复形；Remark (4) 给纯性。这没有要求移位都为偶数。Theorem 2 本身不能提供第 2 项。其 Proposition 3 的局部 Euler 保持也不能在没有 (G) 的时候自动变成 theta 系数公式。

Davison–Mandel [DM19] Theorem 1.8、Theorem 6.3 用无势箭图的上同调 DT 分解与纯偶性证明墙因子正性。对象是特定表示栈/稳定性因子，不是任意 CTB IC 元素。§1.4 又明确保留最小性和 theta 对象模型的期望；所以不能把墙的正性重新应用一次便宣称解决 CTB 换基。

Qin [Q25] Theorems 6.7、6.11、6.16 给 CTB/dual canonical 的识别与（准）范畴化，提供输入对象；没有给 (G)。注意 theta 与 CTB 已不同，不可能把它们都认成同一个有限长度范畴中同一正 Grothendieck 基的不同简单对象，再把正分解当成非平凡定理。需要另一个函子或另一个范畴/基。

一个具体下一步是审视 Lusztig restriction 与 HN 半稳定开子集限制的复合：前者对应普通余乘法正性，但后者是否保留所需 parity、其特征是否等于 scattering transport，正是应计算/证明的新内容。本报告没有预设该复合满足这些性质。

## 6. 原始文献审核与可用范围

| 编号与原始来源 | 已核位置 | 审核结论、用途与限制 |
|---|---|---|
| [GHKK] [1411.1394，取到 v2 PDF](https://arxiv.org/pdf/1411.1394) | Proposition 6.4，证明末段 | 已读近标签提取：有限阶墙图中末指数 q 的线不能再弯，给系数读取。它是旧的提取接口；不是 CTB 正性的证明。 |
| [M16] [1605.03202v2](https://arxiv.org/html/1605.03202v2) | 全文，尤其 Theorem 1 | 已核 scattering atlas atomicity 与普通图册的区分；直接原样使用其条件。 |
| [DM19] [1910.12915v3](https://arxiv.org/html/1910.12915v3) | §1.4、Theorems 1.8、6.3 | 已核其最小性仍属期待，DT positivity 只支持墙/已构造 theta。不能迁移给任意 CTB。 |
| [MQ23] [2301.11101v3](https://arxiv.org/html/2301.11101v3) | Propositions 5.26/5.29，Corollary 5.27，Theorems 9.5/9.6 | 局部锥图册提取与大类曲面 atomicity 已有。曲面结论有 once-punctured closed/torus 限制。不得重复作为新例。 |
| [Q19] [1902.09507v4](https://arxiv.org/html/1902.09507v4) | Theorem 1.2.1、Proposition 3.4.8、Theorem 5.1.2 | injective-reachable/full-rank 下有有限单位三角基变形；系数任意整数，不蕴含正性。适合作换基支持有限性的接口。 |
| [Q24] [2407.03186v1](https://arxiv.org/html/2407.03186v1) | §4，Theorem 5.2，Lemma 6.10，Theorem 6.18 | 冻结与 theta、乘法幸存系数兼容已知。只见面不自动见内部；不能给一般正换基。 |
| [Q25] [2508.12761v2](https://arxiv.org/html/2508.12761v2) | Remark 1.1，§6 | **关键查新归属**：CTB 在 theta 上非负展开已由 Qin 明确提出期待；不能新命名为本项目猜想。 |
| [Q21] [2108.09279v2 PDF](https://arxiv.org/pdf/2108.09279) | §3.2–3.5 | bangles/bracelets/bands 的经典关系给 rank-2 和曲面图形机制；不是一般高秩 CTB 定理。用于校准而非创新。 |
| [BZ12] [1206.3586v2](https://arxiv.org/html/1206.3586v2) | (1.17)、(1.22)、Remark 1.3、Theorems 1.1/1.4/1.6 | 完整读所用定义与唯一性，程序严格按此构造。v 正次幂校正不是系数全正。 |
| [Q16] [1606.05604v2 PDF](https://arxiv.org/pdf/1606.05604) | Theorem 1.4.1、§3.2 | 无环反对称 BZ=Qin triangular；不能把其尚有条件的 skew-symmetrizable 扩张一并当成已证。 |
| [Q15] [1501.04085v5 PDF](https://arxiv.org/pdf/1501.04085) | Theorem 1.2.1、§7–9 导言与结构 | 无环/适配词的几何 CTB 来源及系数修正技术。当前未重证整篇范畴化，使用成熟识别而非提出新结论。 |
| [B03] [math/0202251v5 PDF](https://arxiv.org/pdf/math/0202251) | Theorem 2，Remark (4)，Proposition 3 | 已核半单/纯性与整数移位：不足以保证 Euler 正性。提供函子候选，不是缺口完成。 |
| [F19] [1911.10513v6](https://arxiv.org/html/1911.10513v6) | Theorem 5.1、Algorithm 6.5、Conjectures 1.14/6.11 | Fei 已提出 theta、triangular、generic Newton 一致期待；Newton 半空间表示和路径代数算法是旧接口，不解决符号。 |
| [F25] [2503.12700v2](https://arxiv.org/html/2503.12700v2) | Introduction §0.4、§8 | denominator/generic pairing 具有明示假设。不能无条件代换成 theta/CTB 系数公式。 |

### 6.1 2026 文献的强审核记录

| 来源/版本 | 实际检查 | 结论与本轮处理 |
|---|---|---|
| CMMM [2505.09585v2，2026-05-21](https://arxiv.org/html/2505.09585v2) | Theorems 3.5、3.7、3.8 的证明链；3.15 的顶点单线证明；3.10 的 specialization 附加条件 | 对有限 Laurent/有限组合用途，检查了正墙、一般 v、taut 反向唯一性、有限最小值，再用有限多面体连续性延到非一般 v。可用于已限定的估值/顶点结论。**不采用**无限形式和为有限值时的统一连续性作为本轮新增依据。其3.15的直接证明不依赖 Li–Pan；它提到 Li–Pan 的 converse/saturation，本轮不使用。没发现上述有限接口的错误。 |
| Fei [2309.08326v4，2026-11-11](https://arxiv.org/abs/2309.08326)；[PDF](https://arxiv.org/pdf/2309.08326) | Abstract、§7.2 Remark 7.8、Conjecture 8.14 及其条件 | 文中明确 generic span=middle 的一般期待与 unlocalized basis 假设；theta/经典 triangular 的 BK-biperfect 性仍为猜想8.14。不可用作 theta 导子全正或 CTB 换基定理。本轮只记接口，不引用其新结论作证明。 |
| Fei 2608.29125v2，约2026-11-13替换 | 检索找到原始 arXiv 题录和更新摘要，但 abs/html/pdf 直接打开均报 DisabledError；第三方更新页称 Schubert 非齐次区域初始 Laurent 有−1 | **全文未获，不使用定理。**即便摘要成立，Schubert 元素的初始 Laurent 负项也不构成自然强正基的 theta 负过渡，问题对象不同。不得把检索摘要提升为反例。 |
| 2611.00991 generalized quantum 文章 | 仅查新摘要，内容为 generalized/quantum | 超出本轮经典范围；不采用，不占用主证明。 |

## 7. 检索与路线记录

以下记实际尝试过的检索族；用途是不丢失成功与失败路径，非以文献清单替代主问题。

| 次序 | 查询/入口 | 结果与处理 |
|---|---|---|
| 1 | `Mandel theta bases are atomic scattering atlas 1605.03202`；直接读全文 | 找到精确 atlas 边界；关闭“atomic 自动推出普通强正最小性”的错误捷径。 |
| 2 | `Qin theta basis triangular basis different bases positivity coefficients canonical basis`；`"theta basis" "triangular basis" "positive"` | 定位 Qin25 Remark1.1；目标存在明确既有猜想归属。 |
| 3 | `"theta basis" "negative" canonical basis`；`"theta basis" "dual canonical" cluster`；`"cluster" "canonical basis" "theta" "counterexample"` | 未找到可信高秩负过渡；找到旧 rank-2 差异线索，转查 BZ/Qin 原文。 |
| 4 | `"theta basis" "semicanonical" transition`；`"theta" "triangular" "transition" basis positivity` | 没有直接解决主缺口的定理；generic/semicanonical 与强正基不能混同。 |
| 5 | `"strongly positive" "minimal" "theta" basis`；`"theta" "basis" "minimal" Qin positive` | 找到 DM §1.4 的已有最小性讨论及图册缺口。 |
| 6 | `"theta basis" "strongly positive" "minimal" 2026`；`"triangular basis" "theta" "decomposition" 2026`，recency365 | 发现/复核 2026 更新，但未见一般解答；新结果逐篇标记条件，不默认可用。 |
| 7 | `Berenstein Zelevinsky triangular bases acyclic quantum cluster algebras E_a definition`；`Qin compare triangular bases acyclic quantum cluster algebras algorithm theta basis example` | 找到成熟的精确生成器依据，实际实现并产生 (A)–(C)。 |
| 8 | `"theta" "triangular" "quiver varieties" positivity`；`"canonical" "theta functions" "perverse" cluster` | 没找到任意 CTB 提取点函子；转查 DM 与 Braden 条件。 |
| 9 | `Davison Qin theta canonical basis hyperbolic restriction IC positivity`；`"theta basis" "hyperbolic" restriction`；`"canonical basis" "hyperbolic restriction" "quiver"` | Braden 可用为纯性接口；奇移位和 transport 兼容未闭合，不能证明正换基。 |
| 10 | `Jiarui Fei theta functions tropical F polynomials cluster basis`；`Jia-Rui Fei Schur rank generic bases cluster algebras positivity`；作者主页 | 定位 Newton 原猜想、Schur rank 附加假设和2026晶体猜想；均不能填正换基。 |
| 11 | `"Cluster Geometry of Universal Schubert Polynomials I"`，recency30 | 发现 Fei 新版本题录，但全文未获；不采用其摘要中的−1作为本问题反例。 |
| 12 | rank-3 CTB first difference → 可达修正诊断 → 指定非可达修正 → 指定野型修正 | (A)、(B)、(C) 全部正；没有负例可独立重建。停止扩大样本，交新代理核验算法及非可达识别，继续攻几何有效性。 |
| 13 | `"triangular basis" "asymptotic" "theta"`；`"triangular basis" "stability" "greedy" rank 2`；`"theta" "triangular basis" "generic" "limit"` | 未找到现成低 jet 稳定定理，结果多为不相关数值分析。出现2026-06-01题录中 band=CTB 的摘要线索，以及 Qiyue Tang 的 Hexagon2610.00025v3/2609.00145v3；此轮没有获取其全文，不使用摘要作证明，转交后续原文审查。 |

## 8. 给下一代理的可执行任务

独立复核 (C) 最有价值：既要核对 BZ 唯一性条件、主系数次数与 theta 归一化，也要核对中间标签 (2,-1,-1) 的野型非刚性识别。不要只复算最容易的 θ0 修正。若数据正确，则检查候选 CTB→HN/超曲限制函子能否把这个正系数1解释出来，并把解释推广到一般指标；若仅剩重复运行相同换基递推，应回到原始几何文献，不继续铺例。

### 8.1 主代理提出的新稳定性桥（2026-11-14 首波末）

现有 product detector 可把 CTB 正换基降到一个有实质内容的有限 jet 稳定命题。固定目标根次数 p，选择对每个 \(0<\alpha\le p\) 都满足 \(\langle\nu,D\alpha\rangle\ne0\) 的整数方向 \(\nu=K(g+Bp)+u\)，同时保留 product detector 所需符号。问题是能否证明：对有限多个固定偏移 h，N 足够大后，

\[
L_{N\nu+h}\equiv\theta_{N\nu+h}\pmod{\text{根盒 }[0,p]\text{ 之外的项}}.
\tag{J}
\]

需要的偏移包括0及 \(g+Bq\)（\(q\le p\)），各自只需相应余盒。若 (J) 成立，\(L_gL_{N\nu}\) 的强正结构常数与 detector 提取的 \(c_g(p)\) 在该前缀一致；非负性就会从乘法正性传递下来。此时竞争基的低次数混项确实被消去，属于实质桥。

旧 Kronecker 的 \(U_n\ne T_n\) 不直接反驳 (J)：其方向正交于根 \((1,1)\)，恰好违反非共振条件。但有限单位三角性也不证明 (J)。优先在野型 rank 2 的非共振方向，例如 B 上三角为−3、\(\nu=(3,-2)\)、盒 \(p=(2,2)\)，检查随 N 的低 jet；该方向在此盒内没有配对零根。不要把只检查一两个 N 的相等冒充稳定阈值。若数据支持，必须从 BZ bar 校正中隔离随 N 线性增长的 v 次数与有界根位移，证明越过一个显式阈值后校正等同 theta 的有限墙因子正规化。当前未证明这一点，已转交 fresh agent。

本分支没有完成普通 cluster atlas 强正基最小性，也没有证明一般 CTB→theta 正换基。完成的是现有归属纠偏、一个自含精确生成器、含野型修正的可审公式，以及几何路线中不能跳过的两个实质步骤。
