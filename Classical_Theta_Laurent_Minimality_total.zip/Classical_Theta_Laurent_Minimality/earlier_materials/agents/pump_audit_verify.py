"""Independent exact checks for the periodic initial-wall certificate.

This file deliberately reconstructs projections from B and bend multiplicities,
not from either first-wave return-matrix formula.  The coefficient backend is
the earlier incoming-Schur algorithm; it is a convention check, not the proof.
"""
from fractions import Fraction as F
from functools import reduce
from math import gcd
from pathlib import Path
import sys, json, time

BASE=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(BASE/'history/round2/Higher_Rank_Greedy_Theta/agents'))
from incoming_recursion import IncomingSchur

def add(x,y): return tuple(a+b for a,b in zip(x,y))
def sc(a,x): return tuple(a*v for v in x)
def mv(A,x): return tuple(sum(a*b for a,b in zip(row,x)) for row in A)
def project(v,m,i):
    assert m[i]
    t=-v[i]/m[i]
    return add(v,sc(t,m)),t

def check_geometry(a,b,c,periods=20):
    kap=a*a+b*b+c*c-a*b*c
    assert kap<=0
    d=reduce(gcd,(a,b,c))
    B=((0,b,-c),(-b,0,a),(c,-a,0))
    g=tuple(F(x,d) for x in (-a,a*b-c,-b))
    k=(a//d,c//d,b//d)
    states=[g]
    for i,r in enumerate(k):
        assert r==-states[-1][i]
        states.append(add(states[-1],tuple(F(r*row[i]) for row in B)))
    assert states[-1]==g
    assert mv(B,k)==(0,0,0)
    Q=(F(5,4),F(7,3),F(11,5))
    v=Q
    lowest=F(10**9)
    for cycle in range(periods):
        # From last decoration g, undo the third, second, first bend.
        for m,i in ((states[3],2),(states[2],1),(states[1],0)):
            v,t=project(v,m,i)
            assert t>0
            lowest=min(lowest,t)
        u=-v[1]
        h=sum(F(ki)*vi for ki,vi in zip((a,c,b),v))
        assert u>0 and h>0
        # At this point the next backward segment has decoration g.
    return {'abc':(a,b,c),'kappa':kap,'primitive_g':g,'primitive_k':k,
            'cycles':periods,'minimum_selected_time':lowest,'endpoint':Q,
            'last_first_wall_point':v}

def main():
    start=time.time()
    geometry=[check_geometry(*abc) for abc in ((3,3,3),(3,4,5),(5,3,4),(4,4,8))]
    B=((0,4,-5),(-4,0,3),(5,-3,0))
    g=(-3,7,-4);p=(3,5,4)
    R=IncomingSchur(B)
    f=R.theta_prefix(g,p)
    assert f[p]>=1
    # Coupled fourth vertex: this is not a direct-sum embedding.
    E=((0,4,-5,2),(-4,0,3,-3),(5,-3,0,1),(-2,3,-1,0))
    g4=g+(17,);p4=p+(0,)
    S=IncomingSchur(E)
    f4=S.theta_prefix(g4,p4)
    assert {q[:3]:v for q,v in f4.items()}==f
    # Componentwise decrease in the label, fixed degree box.
    gm=(-4,5,-7)
    fm=R.theta_prefix(gm,p)
    assert all(fm.get(q,0)>=v for q,v in f.items())
    out={'status':'PASS','geometry':geometry,
         'nonuniform_coefficient':{'B':B,'g':g,'degree':p,'coefficient':f[p],
                                  'prefix_nonzero_count':len(f)},
         'coupled_rank_four_face':{'B':E,'g':g4,'degree':p4,
                                   'coefficient':f4[p4],'full_face_prefix_equal':True},
         'label_decrease':{'g':gm,'degree':p,'coefficient':fm[p],
                           'prefix_coefficientwise_dominance':True},
         'seconds':time.time()-start}
    path=Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(out,default=str,indent=2))
    print(json.dumps({'status':'PASS','coefficient':f[p],
                      'rank4_coefficient':f4[p4],
                      'decreased_label_coefficient':fm[p],
                      'seconds':out['seconds'],'output':str(path)}))

if __name__=='__main__':main()
