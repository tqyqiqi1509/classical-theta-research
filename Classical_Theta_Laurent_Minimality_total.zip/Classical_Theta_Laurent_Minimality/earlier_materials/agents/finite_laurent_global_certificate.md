# 完整 Laurent 有限性：有效证书分支

负责人：`finite_laurent_global_certificate`。开始检查约 2026-11-14 03:30 UTC；持续更新。只研究经典、主系数散射图；Li Fang／Li–Pan 的结论未使用。

## 1. 连续性与不得重复计作新结果的部分

已读取 round4 主进展与路线日志、round3 主报告的 finite gap、旧 `OFF_LEADING_POSITIVE_CARRIER.md`、`RATIONAL_CARRIER_CERTIFICATES.md`，以及 Nov12 包的 `03_TWO_SIDED_HALL_RECURRENCE.md`、`04_GENERAL_GRASSMANNIAN_CUT.md`。另完整读取 round2 `COERCIVE_GAUGE_FINITE_SUPPORT.md` 与既有 injective-reachable 支撑界。

旧结论包括：GHKK 的有限标签集合 Θ 的加法性、饱和性；已知正 theta 多项式乘积给支持 carrier；off-leading carrier 与有理 leading carrier；injective-reachable 条件下 Qin 的支撑盒；Tang 2611.00015v1 的全局 coercive gauge 及本地 early/late 显式次数界。均不能列成本轮发现。固定 mutation word 的外包络衰退锥与标签无关，也不能包装成真正标签依赖的分类器。

**进一步查新纠正：** Mandel–Qin arXiv:2301.11101v3，Appendix C 开头（PDF p.123），已明确写出：所有 theta 均为 Laurent 多项式，当且仅当各负单位标签 theta 为 Laurent 多项式。原理来自正结构常数，不是本轮新原理。

## 2. 局部 gauge 路线：实际探索与尚未闭合的要求

记主系数弯折矩阵 P=(B;I)，法向嵌入 R=(D;0)，则 RᵀP=DB 为斜对称。弯折增量 Pa_j、弯折时刻 −u_j、初始标签 m、终点 q 满足

    γ(−u_j)=q+u_j m+P Σ_k min(u_j,u_k)a_k,
    Σ_j <Ra_j,q+u_j m>=0.

第二式给旧 coercive-gauge 证明的 late-charge 界。把全局 gauge 简单局部化有两个真实障碍：

1. 若只证明 G 沿留在锥 C 内的 broken line 凸，尚不能断言所有相关路径都留在 C。必须另外证明 confinement；“离开后再进入”不能忽略。
2. 若用全局 min-convex 函数 h_i 的零水平截锥，再以全局凸 G 截成有界集，那么将 h_i≥0 放宽为 h_i≥−1 不改变 recession cone。max(G,−h_i) 便重新产生全局 coercive gauge。这只是旧的矩阵级有限性条件，未产生标签级机制。

试验过一个有限 Farkas 检查。在 G=max ℓ_j 的唯一 active 线性胞腔内，法向 a≥0 的墙经过 x 时要求 x·Ra=0，而 affine-time 凸性要求 ℓ_j(Pa)≤0。令 c=ℓ_jP、q=Rᵀx，条件为

    c·a≤0 for all a≥0 with q·a=0,

等价于存在 λ 使 c_i≤λ q_i。固定 q 的正负号区后，可化为有限线性条件 c_i q_k−c_k q_i≥0（q_i>0>q_k）以及 q_i=0 时 c_i≤0。

**此检查不能直接用于闭胞腔或 gauge 的棱面。** 即使 B=0、秩一、G(x,y)=|x|+|y|，墙 x=0 上的 frozen 斜率也会让上述逐 facet 条件错误拒绝 G；实际 |x| 的单侧导数跳跃可以补偿最高二项式弯折。必须同时检查入射／出射单侧斜率以及真实墙允许的最大弯折幅度。任意高次墙的弯折幅度没有现成有限界。此外，所有 potential normal a≥0 忽略真实墙的支撑锥，比真实要求过强，甚至不能自然覆盖基本非平凡 acyclic 情形。

**状态：未得到新的有限可检 gauge 证书。** 这里的 Farkas 部分是真实有限化接口，但不能替代上述 crease 与 confinement 两个缺口。

## 3. 有限 injective 坐标：比全局 Jacobi-finiteness 更局部的输入

设完成 Jacobian 代数 J 的 nilpotent 模范畴中，S 是一些顶点，I_i=D(e_iJ) 对 i∈S 有限维。无需假定其他 I_j 有限。若已证明本节所需的稳定／cluster theta 比较，则每个 i∈S 给一个有限负单位标签，进而覆盖

    C_S={g∈Z^n : g_i≥0 whenever i∉S}.

对 g∈C_S，令 a_i=[−g_i]_+，则有粗支持盒

    Supp F_g ⊆ {p≥0 : p≤Σ_{i∈S} a_i dim I_i}.

这里的证明分成两层，不能省略其一：

- kernel/image Hall 公式给负单位稳定 theta：θ_st,−e_i=x_i^−1 F_{I_i}。此 Hall 公式由同组 `relative_hall_theta_bridge` 独立证明，不依赖 Fei 2026 的一般 syzygy 定理。
- 需要 θ_cl,−e_i=θ_st,−e_i，或至少下面的正 carrier 比较。不能由 J 有限直接推全图相等。once-punctured torus 就有真实 central defect。

**输入可以有限验证的部分：** 给出 e_i 的路径空间有限 spanning set，以及所有右乘箭头的闭合表和关系归约证书，即可证明 dim I_i 的有限上界。更粗地，若提供有限关系恒等式证明 e_i rad(J)^L=0，则长度 <L 的路径张成 e_iJ，按终点分组计数给 dim I_i 的上界。仅用“有限截断维数似乎稳定”不构成证书。完成代数及非多项式势的关系闭包需另行处理；本方案只把实际提供的有限关系证书作为输入。

该坐标面结论是旧正乘法机制与局部有限 injective 的组合，没有主张新的 Θ 完整生成定理。对一般 signed g，有限 ker(I(a)→I(b)) 与 theta 的识别仍不能由此推出。

## 4. 正中央缺陷：无需全图相等的严格 carrier

设 k∈ker B∩N^n 非零，稳定图相对于 cluster 图仅多一个完整中央墙 k^⊥。令其从负侧到正侧作用为

    x^m ↦ x^m C(y^k)^{−<k,m>}.

此处公式按负单位 crossing 校准符号。主系数 broken line 的 mutable 动量始终为 g+Bp，因此 <k,g+Bp>=<k,g>，且

    <k,γ(t)>=<k,q>−t<k,g>.

终点 q 位于正腔时，若 <k,g><0，路径恰穿该完整中央墙一次；若 <k,g>≥0，不穿。中央弯折不改变 mutable 轨迹，因此

    θ_st,g = C(y^k)^[−<k,g>]_+ θ_cl,g.

多个已知完整中央墙可逐个相乘。若差别只被描述成半墙，不能直接应用；需要先由一致性证明可以集中为上述完整中央墙。

### 4.1 正中央因子直接给有限性

若 C∈1+t Z≥0[[t]]，则对负单位 i 有

    F_{I_i}=C(y^k)^{k_i} F_cl,−e_i ≥ F_cl,−e_i≥0

（系数逐项比较）。因此有限维 I_i 足以推出 θ_cl,−e_i 有限，且支撑受 dim I_i 控制。**无需先证明 C 为多项式，也无需无限除法。** 对其他有独立有限稳定 theta 证书的标签，同样成立。

这里没有假定任意稳定图正性；所用正性是 cluster theta 正性和实际中央因子 C 的正性。中央性本身不能推出后者。

### 4.2 已知先例与精确归属

- Mou，arXiv:1910.13714，Corollary 1.2：once-punctured torus 的 stable/cluster 差别为中央部分；并无任意 Jacobian 代数全都仅差中央墙的定理。
- Mandel–Qin，arXiv:2301.11101v3，Appendix B.2 Lemma B.3，Appendix B.3 Eq.(155)–(157)，Theorem B.4：覆盖限制图与 cluster 图的比值恰为中央因子 P_H，且 P_H∈1+t Z≥0[[t]]。genus≥2 时 P_H=1；torus 时 P_H 是非负整数系数、系数和为4的多项式。
- 该文 Remark B.5 仅说 Min Huang 的计算 indicates P_H=(1+t)^2；**不能作为该精确式已经证明的引用**。
- Chen–Mandel–Qin，arXiv:2306.04104v2，Lemma 5.6、Theorem 1.4、Remark 5.5：明确覆盖限制图与相关稳定图的关系，并处理 principal coefficients。闭曲面一次穿孔中 genus≥2 的相等与 torus 的不相等都已写明。

因此 4.1 是一个有用的抽象有效推论，但不能把已知 surface 有限性或此中央比较机制本身说成新颖结果。

## 5. 正总质量与有限前缀：新的有效停机接口候选

若已知一个非负整数形式级数 R 的总质量 R(1)=M<∞，则只要某个有限已计算集合的系数之和达到 M，其余系数必为0。这是严格的有限停机证书，不能从数值近似总质量代替 M 的证明。

其用法可以是：几何局部化、拓扑 Euler 特征或已证的正覆盖公式提供总质量；incoming recursion 只计算有限前缀。这个接口避免先找到坐标盒，但其真正价值取决于能否对待研究标签取得一个不循环的全局质量上界。

MQ 的 P_H 总质量4可作校准：若独立计算出 c_0=1,c_1=2,c_2=1，则立即严格得到 P_H=(1+t)^2。后续已完成所需独立 Hall 前缀计算，见第10节；此具体式也已在 Fei 2026 的局部计算中出现，不声称新颖性。

## 6. 非中央 positive incoming deformation：当前正向路线

目标：用带额外形式参数的正 incoming scattering family D(u)，使 D(0)=D_cl、D(1)=D_st。若 theta 的每个 root 系数均属于 N[u]，则 θ_st,g≥θ_cl,g。结合有限 injective 或其他有限稳定 theta 证书，可得到不要求全图相等、也不要求差别中央的支撑 carrier。

关键要求是**全输入形式参数的正性**，不是仅在 u=1 时正，也不是每个 Lie bracket 系数正。不能用壁函数逆幂的形式展开作错误正性论证。

已核文献接口：

- Davison–Mandel arXiv:1910.12915v3 Theorem 2.15 为完整 incoming 超平面、正量子 dilogarithm 输入给正 completion；经典化可用，但一般正壁函数不能任意改写成有限正 binomial 因子。
- Burcroff–Lee–Mou arXiv:2503.03719v1 Theorems 9.5/9.9 与 §9.3，给 rank-two 任意输入壁系数的普适正性及 generalized cluster 任意秩正性。此处只借其 classical scattering 机制，不把研究对象改成广义或量子丛代数。
- 普适参数化和 higher-rank 非坐标 incoming 支撑的推广仍需逐项核验；稳定图额外 incoming data 的正性／有限描述也未得到。仅列出条件并不等于解决一般停机。

## 7. 实际计算记录（未将截断误称完整）

使用 `IncomingSchur` 对 B=((0,2,−2),(−2,0,2),(2,−2,0))、root box (3,3,3) 计算：

- g=(−1,0,0)：截断共7项，(p,c) 为 (000,1),(100,1),(110,2),(120,1),(121,2),(122,1),(222,1)。对角 k(1,1,1) 的 k=0,1,2,3 系数为 1,0,1,0。
- g=(−1,−1,0)：截断23项，对角系数 1,2,6,2。
- g=(−1,−1,−1)：截断40项，对角系数 1,7,23,28。

这些数据只用于核对中央因子低阶关系，**不是完整有限性证明**。独立计算文件与 Wolfram 收据将附后。

## 8. 2026 文献使用审核

Fei arXiv:2609.10090v1 的标题与 §2.6 已从官方 arXiv PDF 读取；同组代理负责核对 Proposition 2.4/Corollary 2.5。此分支不使用其一般 syzygy 运输结论，负腔公式改由旧 Hall 理论独立证明。Tang 2611.00015v1 的 gauge 在 round2 已用且已有本地证明，本轮不作为新材料。Ye 2611.00991 为 generalized quantum 范围，搜索遇到但不采用其结果。以上“未采用”只表示相关性或审核边界，不表示断言原文错误。

## 9. 当前实质结论

真正闭合的是“已证中央正缺陷 + 有限 injective”给完整有限支持 carrier 的逻辑接口；其基本数学机制与 surface 先例属于已有文献。后续第10节还闭合了非中央 positive incoming deformation 的普适比较公式，但仍缺与一般实际稳定图的可检接口。局部 gauge 路线未闭合。一般有限 theta 标签的完备判定与 signed finite-kernel theta 识别仍然开放，未用特殊例子或更多前缀冒充一般机制。

## 10. 后续推进：正 incoming 比较公式与质量停机校准均已闭合

### 10.1 一般非中央扩张

详细证明在 `POSITIVE_INCOMING_DOMINATION.md`。给任意非零非负 normal 列 a_j，设 A=[I,a_1,…,a_s]，B′=AᵀBA，g′=Aᵀg。附加的完整 incoming 墙作用为 (1+t_j y^{a_j}) 的相应 normal 次幂。则对每个 old root degree p 有精确公式

    F_deform,g,p(t)=Σ_{p′≥0, Ap′=p} a^{B′}_{Aᵀg}(p′) t^{p′_extra} ∈ N[t].

每个 fiber 有限，因为 A 的列非零、非负、整数。t=0 回到原 cluster theta；t=1 给附加正 incoming 图，因而 coefficientwise 支配原 theta。normal 不必中央、线性独立或 primitive；非primitive 的 normal 次幂须按原式保留。

证明严格使用 Davison–Mandel Lemma 2.12 的 saturated sublattice restriction，再用 Lemma 2.11 的 radical quotient；该文已处理 slice 落在 ambient joints 的问题。没有把普通 folding 或直观路径限制当作定理。可用 Theorem 2.15 的 radical-tag 正性作另一证明。

这是已有 scattering positivity／change-of-monoid 的有效推论，不声称新的正性定理。如果一个稳定图已被独立证明具有这样的 positive incoming presentation，就得到第3节的有限 injective carrier，且无需全图相等。**尚未证明任意稳定图具有该 presentation。** 因此新接口是真实的，但一般 Laurent 完备停机仍未解决。

独立计算 `positive_incoming_check.py/.json` 比较两条不同算法：一条对原 B 的每条 incoming ray 指定带参数壁作用，按强制 Schur complement 递归；另一条计算普通 B′ theta 再按 Ap′ 聚合。45组参数、399个 root 系数恒等式全部通过，包含多个非中央 normal、重合／非primitive normal、循环矩阵与非对称可斜对称化矩阵。全部312个出现的 tag 单项式系数非负，零 tag 专化回原 B。计算只验证一般证明的实现，不是由有限样本推普遍性。

详细证明的第6节补入经典 skew-symmetrizable 版本：令 D′=diag(D,1_s)、B′=(D′)^−1 AᵀDBA、g′=(D′)^−1 AᵀDg，附加墙 normal 指数为<a_j,Dm>；也可选择整除 Da_j 所有坐标的额外 δ_j，以使用 primitive normal。相同 saturated restriction 与 radical quotient 证明适用。

`positive_incoming_wolfram_receipt.json` 用 Wolfram 对符号3×3 B、任意两个附加 normal 验证限制斜形式的64个矩阵项恒等式，坐标变换行列式为1。最初 ArrayFlatten 分块列宽写错导致实现报错，修正为逐行 Join 后全通过；失败原因在收据中保留，未误报成数学反例。

### 10.2 正总质量4的停机校准

`central_defect_mass_check.py/.json` 直接构造 CMQ Lemma5.1 给出的12维闭曲面路径基表示，验证六条 Jacobian cyclic derivative 关系，并构造分离 radical 同顶点基向量的箭头 grading。projective 与其对偶 injective 的 arrow-image / stacked-map 秩均为11，socle 维数1。故所有非零真子模含 socle 且位于 radical；torus-fixed 子模确为坐标子模，枚举4096个子集得到36个 fixed 子模。

Hall 多项式沿 δ=(1,1,1) 的前三项为1,2,2；独立 IncomingSchur 的 cluster theta 前缀为1,0,1。中央商前三项由卷积递推得到1,2,1，正好用尽 MQ 已证的总质量4。因此严格终止，得到 C=(1+t)^2。完整有限商也与独立 incoming 前缀一致。

该校准同时对 Fei 2609.10090 §2.5 Eq.(2.9) 的**局部具体公式**作了强审核：其两条branch共socle、两项suffix排除的计数正确；没有使用其一般 syzygy theorem。该例不再扩展成特殊情形项目，目的只在验证“几何总质量＋有限前缀”的一般证书接口。

## 11. 04:21 UTC 文献与路线复查

- Argüz–Bousseau，*Quivers and curves in higher dimension*，arXiv:2308.07270v2（2025-09-24版本），已开原文，读 Definition1.4、Theorem1.8、Examples1.9–1.11、Theorem1.20 定位。它已明确从正 attractor 输入通过 GHKK 正性传播 DT 正性，故“正 incoming 数据传播正性”的思想本身不可声称新颖。其 Theorem1.8 要求 trivial attractor invariants，不能冒充任意势的正性；Example1.11 还给出非中央非平凡 attractor 的一般三角箭图族。尚未从该文获得“有限 injective + 非中央全正 incoming”新类的完整证书。DT 的符号修正约定及与所用 classical Hall integration 的对应也须核对，不能直接移植一个 Ω≥0 的字面断言。
- Mozgovoy–Pioline，*Attractor invariants, brane tilings and crystals*，arXiv:2012.14358v2，已开原文并读 §3.6 中扰动独立性、acyclic 情形与强连通支持条件的相关陈述。它包含不少清楚标为 conjecture 的 toric attractor 公式。未把数值预测当作已证定理，未转去做排除机制或特殊曲面计算。
- 搜索遇到 Chang–Tang，arXiv:2609.11200，标题 *Obstructions to Jacobi-Finiteness of Quivers with Potentials*。只得二手搜索条目；官方 abs 与 PDF 两次读取均失败。未使用结论，未判真伪。用户已要求不把主目标转成排除机制，所以这里只保留查新线索。
- 原先一次误写的 arXiv:2308.07161 实际是无关纳米机电物理论文，核标题后立即弃用；后经作者／标题搜索取得正确的2308.07270，不以错误标识引用。

路线决定：保留已闭合的非中央正输入比较作为新接口，下一步必须寻找或证明实际 category-level 正 incoming presentation 或 signed finite-kernel theta 识别。继续增加小例子不会补足这个接口，已停止该方向的样本扩充。

## 12. 04:38 UTC：从正系数支配升级为原 theta 正转换

收到新任务后，本分支独立重读旧 round3 的一方向正冻结切片与审核文件；没有把旧切片或 DM 正性计作本轮发现。详细证明已经写入 POSITIVE_INCOMING_THETA_TRANSITION.md。

核心补步是任意指标集 S 的同时切片。当先删 i 时，中间 offset 分成 (v,w)，其中 w 位于尚未删除的 T=S\{i}。下一步必须切在 r_T−w；于是标签中的 C_JT w 与切片修正 −C_JT w 精确抵消，最终标签总是 G_J+C_JS r+C_JJ q。得到有限正卷积 (2.6)，因此删除顺序无关且分支系数非负。

应用于 A=[I,U] 的扩张后，正转换是

    θ_D(t),g = Σ_(r,q≥0) d_(g;r,q) t^r y^(Ur+q) θ_B,g+B(Ur+q),   d≥0.

这里 y 是主系数冻结变量；root monomial 为 z_i=y_i x^(B e_i)。旧比较报告已经加上相应符号说明，避免把 root monomial 与冻结变量混用。完整冻结幂次与 skew-symmetrizable 的 K=D′^−1 AᵀD 版本在新报告 §§3–4 写明。

形式收敛由 Ur+q≤p 时 |r|+|q|≤|p| 保证。若 D(1) 的该 theta 已经独立证明有限，则每个非零 d 的首项 Ur+q 必在有限支持内，所以只有有限个分支，并且其中出现的每个 B-theta 都有限；得到真实有限正转换及支持/Newton 分解。没有把 Laurent 系数支配本身当作 theta 正性的证明。

精确核验 positive_incoming_theta_transition_check.py/.json：6 组、182 个同时切片系数，两种删除顺序完全一致；含非中央、多 extra、valued、循环矩阵。3 组有独立无环有限界的完整多项式恒等式，共59个正 theta 项、419个带 tag 单项式恒等式全通过。存在实际 q_extra>0 的中间分支，故测试没有跳过关键抵消。Wolfram 收据 positive_incoming_theta_transition_wolfram.json 的符号指数余项均为0。

本轮重新核读 Mandel 1605.03202v2 Theorem1、Qin 2407.03186v1 Lemma5.1/Proposition6.19、DM 1910.12915v3 restriction/quotient 及 Theorem3.16。未新增使用2026结论。审阅结果：旧机制可用，6.19 仍要求输入已有限，不能逆推；本报告的贡献是接口推论与精确记账，不宣传为新的普遍 theta 正性定理。

“换基”边界也已写清：完备模中正转换可逆；有限行是在原有限 theta 正锥中的展开，但仅此不足以断言变形有限族是同一 Z[y]-模的基。中央因子可能给非单位对角系数。主目标的剩余难点仍是为一般输入提供真实、可检的有限正载体，而非更多特殊计算。
