"""Independent finite-factorization check for the connected rank-three probe.

The CTB program uses the acyclic closed product for incoming coefficients.
This checker reconstructs those coefficients from signed triangular matrix
factorization, without using that closed product or a historical import.
"""
from functools import lru_cache
from pathlib import Path
import json,time
from ctb_probe import Triangular,AcyclicTheta,ibinom,box,le,sub,fmt


class IncomingFactorization:
    def __init__(self,B):
        self.B=tuple(map(tuple,B));self.n=len(B);self.zero=(0,)*self.n
        self.c=lru_cache(None)(self._c);self.parallel_checks=0
    def shift(self,m,q):
        return tuple(m[i]+sum(self.B[i][j]*q[j] for j in range(self.n)) for i in range(self.n))
    def sign(self,a,b):
        Ba=self.shift(self.zero,a)
        z=sum(Ba[i]*b[i] for i in range(self.n))
        if z:return 1 if z>0 else -1
        r=next(i for i in range(self.n) if a[i])
        for i in range(self.n):
            z=a[r]*b[i]-a[i]*b[r]
            if z:return 1 if z>0 else -1
        return 0
    def _c(self,a,m):
        if not any(a):return 1
        supp=[i for i,x in enumerate(a) if x]
        if len(supp)==1:
            i=supp[0];return ibinom(-m[i],a[i])
        J=box(a);minus={(p,p):1 for p in J};plus=dict(minus)
        intervals=sorted(((p,q) for p in J for q in J if p!=q and le(q,p)),key=lambda pq:(sum(sub(*pq)),pq))
        ans=None
        for p,q in intervals:
            beta=sub(p,q)
            cross=sum(minus.get((p,r),0)*plus.get((r,q),0) for r in J if r!=q and r!=p and le(q,r) and le(r,p))
            if beta==a:
                assert p==a and q==self.zero
                ans=cross;continue
            val=self.c(beta,self.shift(m,q))-cross;s=self.sign(a,beta)
            if s<0:
                if val:minus[p,q]=val
            elif s>0:
                if val:plus[p,q]=val
            else:
                self.parallel_checks+=1
                assert val==0,(a,m,p,q,val)
        assert ans is not None
        return ans


def main():
    start=time.time();B=[[0,-2,0],[2,0,-1],[0,1,0]]
    I=IncomingFactorization(B);A=AcyclicTheta(B);checks=0
    for m in ((2,-1,-1),(2,0,-2),(0,0,0),(-3,2,1),(1,-2,-2)):
        for a in box((2,2,2)):
            assert I.c(a,m)==A.c(a,m),(a,m,I.c(a,m),A.c(a,m))
            checks+=1
    T=Triangular(B);a=(-2,-2,-1,0,0,0);g=T.g(a)
    Ecert=T.defining_certificate(a);F=T.classical_F(a)
    theta=A.F(g,(2,2,1))
    expected=dict(theta);expected[(1,1,1)]=expected.get((1,1,1),0)+1
    assert F==expected
    assert A.decompose(g,F)=={(0,0,0):1,(1,1,1):1}
    # Check theta through a general incoming-factorization backend too.
    G=AcyclicTheta(B);G.c=I.c
    assert G.theta_prefix(g,(2,2,1))==theta
    first={'BZ_index':a,'g':g,'classical_F':fmt(F),'theta_F':fmt(theta),
           'transition':[{'principal_degree':[0,0,0],'theta_g':g,'coefficient':1},
                         {'principal_degree':[1,1,1],'theta_g':[0,0,0],'coefficient':1}],
           'quantum_C':fmt(T.canonical(a)),'BZ_defining_certificate':Ecert}
    result={'status':'PASS','incoming_closed_vs_factorization_entries':checks,
            'parallel_residual_checks':I.parallel_checks,'first_difference':first,
            'seconds':time.time()-start}
    path=Path(__file__).with_name('ctb_probe_verify_result.json')
    path.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','incoming_checks':checks,'seconds':result['seconds'],'output':str(path)}))

if __name__=='__main__':main()
