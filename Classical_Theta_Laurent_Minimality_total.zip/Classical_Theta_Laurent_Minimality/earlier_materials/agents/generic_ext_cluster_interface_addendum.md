# Final cluster-interface audit: signs, principal coefficients, and finite type

Follow-up to generic_ext_saturation_adversarial. Reviewed the entire file proofs/CLASSICAL_MODULAR_TO_THETA_POSITIVITY.md after the parent requested a fresh convention test. This is a new check, not a restatement of the preceding PASS.

**Verdict:** the current convention \(B_{ij}=-m_{ij}\) for an arrow \(i\to j\), \(g=-Er\), and root \(e=\dim U\) is consistent. The A2 mutation check and the general Caldero–Chapoton/DWZ formulas agree. The proof needs explicit bookkeeping sentences for the old negative-principal variables and Grassmannian dual complements. No counterexample or remaining logical obstruction was found in the stated classical theorem, conditional on its expressly named existing basis and old finite-window inputs.

## 1. General convention identity, not only an A2 check

For \(E=I-A\), the stated exchange matrix is

\[
 B=A^T-A=E-E^T.
\]

The Caldero–Chapoton exponent at a submodule dimension e has i-th coordinate

\[
 -\langle e,\alpha_i\rangle-\langle\alpha_i,r-e\rangle.
\]

As a column vector this is

\[
 -E^Te-E(r-e)=-Er+(E-E^T)e=-Er+Be.
 \tag{C}
\]

Thus the submodule generating polynomial belongs exactly to the convention

\[
 X_M=x^{-Er}\sum_e\chi(\operatorname{Gr}_eM)\,y^e x^{Be}.
\]

This fixes the transpose, B sign, head and root simultaneously.

Primary-source confirmation: DWZ II, arXiv:0904.0676v3, equation (1.4) assigns \([b_{ij}]_+\) arrows \(j\to i\); equation (1.6) uses submodule dimensions for the F-polynomial; (1.13) gives \(g_i=\dim\ker\gamma_i-r_i+v_i\). In the acyclic case \(\gamma_i=0\), so this is \(-Er+v\). Equations (2.14)–(2.15) use \(\widehat y_j=y_jx^{Be_j}\), and Theorem 5.1 identifies these representation-theoretic data with the actual cluster F-polynomials and g-vectors. For principal coefficients the tropical denominator is 1, by the constant term 1.

Caldero–Keller, *From triangulated categories to cluster algebras II*, §2.2, gives the exponent in (C) directly. Its multiplication and rigid-object/cluster correspondence explain the finite-type use below. The principal-coefficient refinement uses the just-cited DWZ formulas.

## 2. Independent A2 exchange calculation

Take \(Q:1\to2\), \(B=\left(\begin{smallmatrix}0&-1\\1&0\end{smallmatrix}\right)\), principal lower block I, r=(1,1). Then g=(0,−1) and

\[
 z_1=y_1x_2,\qquad z_2=y_2/x_1.
\]

Mutating first at 1 gives

\[
 x_1'=\frac{1+y_1x_2}{x_1}.
\]

The extended exchange matrix then has second column \((1,0,0,1)^T\). The next mutation gives

\[
 x_2''=\frac{1+y_2x_1'}{x_2}
 =x_2^{-1}\left(1+\frac{y_2}{x_1}
                  +\frac{y_1y_2x_2}{x_1}\right)
 =x^{(0,-1)}(1+z_2+z_1z_2).
\]

The generic representation has precisely the three possible submodule dimensions (0,0), (0,1), (1,1). Euler ranks, the independent BZ triangular implementation, and incoming theta recurrence all return this same F-polynomial and only the leading theta-transition term.

The saved computation independently mutates the full extended exchange matrix using SymPy; it does not obtain the exchange polynomial from the theta or Euler routines. It also symbolically verifies (C) for a general three-vertex acyclic adjacency matrix.

Receipt: computation/generic_ext_cluster_conventions.json.

## 3. The exact old-to-new dictionary: frozen inversion is needed

Let J reverse the vertex order. The old long-R document uses \(B_{\rm old}\) positive above the diagonal, negative principal lower block −I, old ambient vector \(r_{\rm old}\), first multiplicity a, and second multiplicity \(b_{\rm old}=r_{\rm old}-a\).

Its normalized head and expansion are

\[
 X_{\rm old}^{V_{\rm old}r_{\rm old}}
 \sum_a c_a X_{\rm old}^{B_{\rm old}a}Y_{\rm old}^{-a},
 \qquad V_{\rm old}=-I+[-B_{\rm old}]_+.
\]

Set

\[
 B=JB_{\rm old}J,\quad r=Jr_{\rm old},\quad e=Ja,\quad
 x_i=X_{{\rm old},\,\mathrm{rev}(i)},\quad
 y_i=Y_{{\rm old},\,\mathrm{rev}(i)}^{-1}.
 \tag{D}
\]

Then

\[
 JV_{\rm old}J=-I+[-B]_+=-E
\]

and every root factor becomes \(y^ex^{Be}=z^e\). Hence the formula has the precise current head \(x^{-Er}\).

**Reversing vertices alone does not change the old frozen lower block −I to +I.** The inversion in (D), together with the already used frozen head normalization, is the required additional step. Frozen variables are inverted throughout the theorem, so this is an integral frozen lattice operation. Normalized cluster variables may differ by frozen units under this coefficient identification; those units must remain part of the basis normalization.

### The entire Euler class, not just its degree

On each old Grassmannian \(\operatorname{Gr}(b_{\rm old},r_{\rm old})\), use

\[
 U\longmapsto\operatorname{Ann}(U)
\]

to identify it with \(\operatorname{Gr}(a,r_{\rm old}^*)\). The old tautological subbundle corresponds to the dual of the new quotient, and the old quotient corresponds to the dual of the new subbundle.

An old pair i<j becomes the new pair k=rev(j)<l=rev(i). A geometric KLR factor on the old second-i and first-j roots is thereby the current top Euler class of \(\operatorname{Hom}(S_k,Q_l)\), up to the global sign \((-1)^{m_{ij}b_{{\rm old},i}a_j}\). Multiplying these signs gives a unit ±1. Therefore the multiplication operators are related by integral cohomology-ring isomorphisms and a unit, and have identical Smith factors and ranks in every characteristic. Matching Euler degrees alone would not prove this assertion.

These steps should be included in §3 of the integrated proof. They repair an omission in exposition, rather than a failure of the proposed comparison.

## 4. Finite Dynkin components: the all-r Euler corollary has a direct proof

The finite-type clause should not merely define \(\beta_g\) to be a cluster monomial and then assume the infinite-type long-R formula still computes it. The following independent argument fills that interface for every r.

For a Dynkin quiver, Rep_Q(r) has finitely many orbits. Since it is irreducible, one orbit is dense; its representation M is rigid. Thus CEFR's original rigid-module diagonal argument applies for every e≤r:

\[
 \operatorname{Im}m_{F_e}\simeq H^*(\operatorname{Gr}_eM,\mathbb Z)
\]

is primitive and free, and all its cohomology is even. In every prime characteristic,

\[
 \operatorname{rank}m_{F_e}
 =\chi(\operatorname{Gr}_eM).
 \tag{F}
\]

The rigid representation decomposes into pairwise compatible indecomposables. Its principal cluster character, with (C)'s g-vector and DWZ's F-polynomial, is the corresponding cluster monomial. A cluster monomial is the theta element with its g-label. Consequently

\[
 x^{-Er}\sum_e\operatorname{rank}_{\mathbb F_p}(m_{F_e})z^e
 =\theta_{-Er}
\]

for every prime p and every r in a Dynkin component.

Thus the global all-r,e Smith lower bound is valid in finite type, in fact with equality of the rank and the theta coefficient and with every nonzero Smith factor equal to 1. It requires no reduced cc word. If an e-coordinate exceeds r, both the Euler map and the corresponding coefficient are zero.

The completed label \(u-Er\), \(u_ir_i=0\), also has the expected cluster-monomial interpretation: the decorations \(P_i[1]^{u_i}\) are compatible with M because their Ext pairing is measured by r_i. Disconnected components combine by tensor products. Over each field the Euler rank of a tensor product is the product of ranks, which is enough for the stated global lower bound; no unjustified formula for sums of graded Smith-unit counts is needed.

## 5. The rest of the cluster proof: two finite-poset arguments should be stated

I reread the entire integrated proof, including the detector equality and global Smith deduction.

### Root positions in a finite theta expansion

Principal homogeneity gives a finite expansion

\[
 f=\sum_{q\in\mathbb Z^n}c_qy^q\theta_{g+Bq}.
\]

Every summand has its initial root support in \(q+\mathbb N^n\), with coefficient c_q at the leading position q. Because f itself has support in \(\mathbb N^n\), a coordinatewise minimal nonzero q outside that cone would produce an uncancelled forbidden term. More precisely, every element of the finite index set lies above some minimal element; all minimal elements must lie in \(\mathbb N^n\), and hence so do all q. The root-zero coefficient then gives c_0=1.

The identical argument applies to the finite positive basis expansion of a product. Thus its output shifts q are nonnegative, and only q≤p can affect a prescribed target root p. This justifies the finite offset set in the proof of equation (7).

### Finite scattering transport and detector

Principal scattering automorphisms add nonnegative root degrees, so equality through a finite downward-closed root box is preserved under the finite-order chart changes. Both the multiplier and every relevant output basis element need monomial jets; the proof correctly requests both.

For the target exponent \(h=g+Bp\), choose ν in the finite-order sign cone of h and off the additional root and label walls. A hypothetical last bend with outgoing exponent h cannot reach a relevant wall while traced backwards: the wall-normal pairing with ν and with h has the same sign; a zero pairing with h gives a parallel segment. This also covers h=0. The chart coefficient is therefore c_p.

For sufficiently large N, the multiplier has its leading monomial through p, and every output at \(N\nu+g+Bq\), q≤p, has its leading monomial through p−q. This gives the actual basis multiplication coefficient in equation (7). No sign of a transition coefficient has been assumed in this extraction.

### Wording and scope

Replace “the acyclic cluster algebra has its finite theta basis” by “the acyclic cluster algebra has a theta basis in which each algebra element has a finite expansion.” The basis is generally infinite as a set.

The theorem remains conditional on the clearly stated existing standard geometric KLR dictionary and old CTB finite-window/detector theorem. Nothing in this final check extends it to arbitrary KLR parameters or arbitrary strong-positive bases.

The global Smith argument is correct for the entire ungraded Euler map. Its unit count is the minimum over prime ranks, not the sum of unit counts of the graded blocks.

## 6. Sources and retrieval record for this follow-up

- Caldero–Keller, primary author PDF, §2.2 and rigid/cluster correspondence:
  https://webusers.imj-prg.fr/~bernhard.keller/publ/ck2.pdf .
  Useful: the Euler exponent, direct-sum multiplication, and rigid cluster characters.
- DWZ II, arXiv:0904.0676v3, equations (1.4), (1.6), (1.13), (2.14)–(2.15), Proposition 3.2, Theorem 5.1:
  https://arxiv.org/pdf/0904.0676 .
  Useful: exact principal coefficient, g-vector and submodule conventions. No 2026 result is used.
- One exploratory arXiv identifier, 0909.1110, resolved to an unrelated physics paper. It was rejected immediately and contributes no input; the correct DWZ identifier is the one above.
- Exact A2 exchange and symbolic exponent receipt:
  computation/generic_ext_cluster_conventions.json .

The following substantive additions are recommended in the integrated proof: the frozen inversion and annihilator identification in §3, the direct finite-Dynkin Euler argument for §5, and the two finite-poset sentences justifying nonnegative root shifts and the finite output offset set.

