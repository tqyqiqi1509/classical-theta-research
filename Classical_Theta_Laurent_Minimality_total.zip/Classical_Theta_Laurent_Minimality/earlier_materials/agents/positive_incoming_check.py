"""Independent checks of the positive incoming rank-extension formula.

Left: incoming Schur recursion with prescribed non-coordinate incoming ray
automorphisms. Right: ordinary cluster theta recursion for A^T B A.
Only finite coefficient identities are tested; the all-order proof is in
POSITIVE_INCOMING_DOMINATION.md.
"""
from functools import lru_cache
from itertools import product
from pathlib import Path
from collections import defaultdict
import json, sys, time
import sympy as sp
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'computation'))
from incoming_recursion import IncomingSchur, box, sub, le, ibinom

class PrescribedIncoming(IncomingSchur):
    def __init__(self,B,extras,D=None):
        self.extras=[tuple(x) for x in extras]
        self.tags=sp.symbols('u0:'+str(len(extras)))
        super().__init__(B,D)
        self.incoming=lru_cache(None)(self._incoming)

    def _incoming(self,a,m):
        # Coefficient of root a in the complete prescribed incoming
        # automorphism on its ray. This is the forced Schur complement.
        normals=[tuple(int(i==j) for i in range(self.n)) for j in range(self.n)]+self.extras
        tags=[sp.Integer(1)]*self.n+list(self.tags)
        scales=list(self.D)+[1]*len(self.extras)
        on_ray=[]
        for d,u,scale in zip(normals,tags,scales):
            if not le(d,a):
                continue
            if any(a[i]*d[j]!=a[j]*d[i] for i in range(self.n) for j in range(self.n)):
                continue
            cap=min(a[i]//d[i] for i in range(self.n) if d[i])
            on_ray.append((d,u,cap,scale))
        answer=sp.Integer(0)
        for ks in product(*(range(cap+1) for _,_,cap,_ in on_ray)):
            if tuple(sum(k*d[i] for k,(d,_,_,_) in zip(ks,on_ray)) for i in range(self.n))!=a:
                continue
            term=sp.Integer(1)
            for k,(d,u,_,scale) in zip(ks,on_ray):
                top=-sum(d[i]*self.D[i]*m[i] for i in range(self.n))//scale
                term*=ibinom(top,k)*u**k
            answer+=term
        return sp.expand(answer)

    def _c(self,a,m):
        if not any(a):
            return sp.Integer(1)
        S=[q for q in box(a) if q!=a and q!=self.zero and self.sign(a,q)>0]
        v={}
        for s in S:
            v[s]=sp.expand(self.c(s,m)-sum(self.c(sub(s,q),self.shift(m,q))*v[q]
                                           for q in v if le(q,s)))
        return sp.expand(self.incoming(a,m)+sum(self.c(sub(a,s),self.shift(m,s))*v[s] for s in S))

    def theta_prefix(self,g,d):
        return {p:sp.expand(c) for p,c in super().theta_prefix(g,d).items() if sp.expand(c)!=0}

def extend(B,extras,g,D):
    n=len(B)
    A=sp.Matrix.hstack(sp.eye(n),*(sp.Matrix(a) for a in extras))
    De=tuple(D)+tuple(1 for _ in extras)
    ds=sp.diag(*D); des=sp.diag(*De)
    Be=des.inv()*A.T*ds*sp.Matrix(B)*A
    ge=des.inv()*A.T*ds*sp.Matrix(g)
    return A,tuple(tuple(int(Be[i,j]) for j in range(Be.cols)) for i in range(Be.rows)),tuple(map(int,ge)),De

def run_case(B,extras,g,cap,D=None):
    D=tuple(D or [1]*len(B))
    direct=PrescribedIncoming(B,extras,D)
    left=direct.theta_prefix(g,cap)
    A,Be,ge,De=extend(B,extras,g,D)
    ecaps=tuple(min(cap[i]//a[i] for i in range(len(B)) if a[i]) for a in extras)
    expanded=IncomingSchur(Be,De)
    extended=expanded.theta_prefix(ge,tuple(cap)+ecaps)
    right=defaultdict(lambda:sp.Integer(0))
    for p,c in extended.items():
        old=tuple(map(int,A*sp.Matrix(p)))
        if not le(old,cap):
            continue
        right[old]+=c*sp.prod(u**k for u,k in zip(direct.tags,p[len(B):]))
    right={p:sp.expand(c) for p,c in right.items() if sp.expand(c)!=0}
    assert left==right,(B,extras,g,cap,left,right)
    original=IncomingSchur(B,D).theta_prefix(g,cap)
    zero={p:int(c.subs(dict.fromkeys(direct.tags,0))) for p,c in left.items()
          if c.subs(dict.fromkeys(direct.tags,0))!=0}
    assert zero==original
    assert all(c>=0 for f in left.values() for c in sp.Poly(f,*direct.tags).coeffs())
    return {'B':B,'D':D,'extras':extras,'g':g,'cap':cap,'extended_B':Be,'extended_D':De,'extended_g':ge,
            'nonzero_root_terms':len(left),'tag_monomials':sum(len(sp.Poly(c,*direct.tags).terms()) for c in left.values()),
            'positive_parameter_coefficients':True,'rank_extension_identity':True,'zero_tags_recover_original':True,
            'terms':[{'degree':p,'coefficient':str(c)} for p,c in sorted(left.items())]}

if __name__=='__main__':
    start=time.time(); cases=[]
    for weight in (1,2,3):
        B=((0,weight),(-weight,0))
        for extras in (((1,1),),((2,1),),((2,2),)):
            for g in ((-1,-1),(-2,1),(1,-2)):
                cases.append(run_case(B,extras,g,(2,2)))
    B=((0,3,-3),(-3,0,3),(3,-3,0))
    for extras in (((1,1,0),),((1,1,1),),((1,1,0),(0,1,1))):
        for g in ((-1,-1,-1),(1,-2,1)):
            cases.append(run_case(B,extras,g,(1,1,1)))
    for B,D in [(((0,3),(-2,0)),(2,3)),(((0,1),(-3,0)),(3,1))]:
        for extras in (((1,1),),((2,1),)):
            for g in ((-1,-1),(-2,1),(1,-2)):
                cases.append(run_case(B,extras,g,(2,2),D))
    data={'status':'PASS','cases':cases,'case_count':len(cases),
          'root_coefficient_identities':sum(sp.prod(c+1 for c in r['cap']) for r in cases),
          'tag_monomials':sum(r['tag_monomials'] for r in cases),
          'seconds':time.time()-start,
          'scope':'finite algebraic verification of the general rank-extension proof; no finiteness conclusion inferred from samples'}
    data['root_coefficient_identities']=int(data['root_coefficient_identities'])
    Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({k:data[k] for k in ('status','case_count','root_coefficient_identities','tag_monomials','seconds')},indent=2))
