# Positive incoming additions give coefficientwise theta domination

Notation: in this file y^p denotes the abstract root monomial, whose actual
principal realization is x^(Bp)Y^p with frozen coefficients Y. It must not
be read as a frozen coefficient alone. The companion
POSITIVE_INCOMING_THETA_TRANSITION.md instead uses z for root monomials and
y for frozen coefficients, and writes every frozen power explicitly.

Status: proved reduction from existing scattering positivity and restriction
theorems. This is not claimed as a new positivity theorem. Its use as an
effective finite-support certificate still requires an independently verified
finite carrier for the enlarged diagram. All conclusions here are classical.

## 1. Statement with full parameter dependence

Let B be an integral skew-symmetric n×n matrix. Let a_1,…,a_s be nonzero
vectors in N^n. Start with the ordinary principal cluster initial diagram and
adjoin full incoming hyperplanes a_j^⊥, with classical automorphisms

    x^m ↦ x^m (1+t_j y^{a_j})^{±<a_j,m>}.

The sign is the usual oriented crossing sign. If a_j is not primitive, this
formula specifies its multiplicity: equivalently the wall function for the
primitive normal is (1+t_j y^{a_j})^{gcd(a_j)}. Write D(t) for its consistent
outgoing completion. For an initial label g and a positive-chamber endpoint,
write

    θ^{D(t)}_g = x^g Σ_{p≥0} F_{g,p}(t) y^p.

Then every F_{g,p} belongs to Z_{≥0}[t_1,…,t_s], and

    F_{g,p}(0)=a^B_g(p),
    F_{g,p}(1)≥a^B_g(p).

Thus any finite polynomial carrier for θ^{D(1)}_g is also a finite polynomial
carrier for the ordinary cluster theta θ^B_g. The extra normals need not be
central, independent, or primitive. No claim is made that an arbitrary
stability scattering diagram arises from such positive additional inputs.

## 2. Explicit rank extension and the restriction theorem

Set A=[I_n,a_1,…,a_s], r=n+s, B'=AᵀBA and g'=Aᵀg. B' is an ordinary
skew-symmetric exchange matrix. Use the principal exponent lattice

    L'=Z^r⊕Z^r,
    Λ'=[[0,−I_r],[I_r,−B']],
    P'v=(B'v,v).

Consider the saturated sublattice

    E={(Aᵀm,p') : m∈Z^n, p'∈Z^r} ⊂ L'.

It is saturated because A contains I_n. Every positive root direction lies in
E, since B'p'=AᵀBAp'. Therefore the image of the scattering positive cone
under L'_R→L'_R/E_R is {0}, which is strongly convex.

Davison–Mandel, arXiv:1910.12915v3, Lemma 2.12 (PDF pp.20–21), applies to this
saturated inclusion. It gives a consistent restricted diagram with precisely
the restricted incoming data. The apparent problem that E can meet ambient
joints in codimension one is explicitly addressed in that lemma: after
changing to an equivalent representative, the offending wall boundaries can
be glued, because the relevant restricted skew pairings vanish. Thus the
restriction argument does not silently assume a transverse generic slice.

Identify E with L⊕Z^s by

    (Aᵀm,p') ↦ (m,Ap',p'_extra),
    L=Z^n⊕Z^n.

This is an integral isomorphism: p'_base=Ap'−Σ_j a_j p'_{n+j}. Under this
identification Λ'|_E is

    Λ⊕0_s,       Λ=[[0,−I_n],[I_n,−B]],

so the extra coordinates are radical tags. Initial root vectors become
(Pe_i,0) and (Pa_j,e_j^tag), and their hyperplanes are exactly the full
initial hyperplanes specified in Section 1, cylindrical in the tag directions.
Their functions become 1+y_i and 1+t_j y^{a_j}.

The projection E→L is therefore a surjective map pulling Λ back to Λ'|_E.
Davison–Mandel Lemma 2.11 applies to its saturated diagram. This is a genuine
quotient by radical directions, not an unproved folding assertion. Section
5.1 of the same paper is the corresponding change-of-monoid construction.

## 3. Theta functions and specialization

Take q∈R^n_{>0}. Then Aᵀq∈R^r_{>0}, because every a_j is nonzero and
nonnegative. Thus E meets the initial positive chamber. A broken line ending
in E with initial exponent (Aᵀg,0) has every momentum in E. Starting from
the endpoint and following its finitely many segments backwards shows that
its whole path lies in E. Work with the equivalent representative furnished
by Lemma 2.12 and argue at each finite root order; generic endpoints in E
then avoid the restricted joints. The coefficients agree with the ambient
positive-chamber theta coefficients.

Consequently the exact formula is

    F_{g,p}(t)
      = Σ_{p'≥0, Ap'=p} a^{B'}_{Aᵀg}(p') t^{p'_extra}.                 (1)

All terms on the right are nonnegative by ordinary cluster theta positivity.
For fixed p the fiber is finite. Indeed Σ_j p'_j≤Σ_i p_i because every column
of A has positive integral coordinate sum. This also proves that setting all
t_j=1 is legitimate coefficient by coefficient.

Setting all t_j=0 keeps exactly p'_extra=0. Equivalently one specializes the
root-completed diagram by killing every monomial with positive tag degree.
The remaining incoming data are precisely the original cluster data, and
uniqueness of consistent outgoing completion identifies the specialized
diagram with D_B. Specialization commutes with each finite-order broken-line
sum, so the zero-tag coefficient equals a^B_g(p). This proves Section 1.

An alternative proof uses the radical-tag lattice directly: Davison–Mandel
Theorem 2.15 permits arbitrary full incoming hyperplanes with positive
dilogarithm inputs; its classical limit and the same tags give all
coefficients in N[t]. The rank extension above shows why the ordinary
classical cluster positivity theorem already suffices for binomial inputs.

## 4. Finite-support consequence for a verified stability extension

Suppose a nilpotent Jacobian module category has finite-dimensional
injectives I_i for i in a subset S. Assume its classical stability diagram
is proved equivalent to D(1) above. The negative-chamber kernel/image Hall
formula gives

    θ^{st}_{−e_i}=x_i^−1 F_{I_i}.

Then (1) yields

    0≤F^{cl}_{−e_i}≤F_{I_i},                 i∈S.

In particular this identity itself forces the relevant F_{I_i} to be
nonnegative; no general positivity theorem for arbitrary stability diagrams
has been assumed. For any g with g_i≥0 outside S, GHKK positive multiplication
and the leading coefficient one give

    F^{cl}_g ≤ ∏_{i∈S} F_{I_i}^{[−g_i]_+},
    Supp F^{cl}_g ⊆ [0, Σ_{i∈S}[−g_i]_+ dim I_i].                    (2)

The known central-positive-defect criterion is a special comparison mechanism
but (1) also allows noncommuting additional incoming normals. This is a
strict weakening of requiring D_st=D_cl at the level of hypotheses.

What remains unproved is a broad, effectively checkable characterization of
Jacobians whose extra incoming data admit this positive presentation. A finite
list of guessed incoming walls, or a finite truncation of the stability
diagram, is not an equality certificate. The theorem does not settle the
general finite-label problem by itself.

## 5. Literature audit and novelty boundary

Primary sources actually read:

- Davison–Mandel, *Strong positivity for quantum theta bases of quantum
  cluster algebras*, arXiv:1910.12915v3, Lemmas 2.11–2.12, Theorem 2.15,
  §3.3.1, §5.1. The underlying restriction, quotient, change-of-monoid and
  positive scattering mechanisms are theirs / GHKK's.
- GHKK, arXiv:1411.1394v2, Theorem 1.13 and the outgoing-completion uniqueness
  statements. Used only for ordinary classical theta positivity and
  specialization uniqueness.
- Burcroff–Lee–Mou, arXiv:2503.03719v1, Theorem 9.9 and §9.3, supplies a wider
  universal positivity interface for polynomial wall functions. It is not
  needed for the binomial theorem proved here.

No priority claim is made for coefficientwise monotonicity as an abstract
consequence of these results. The useful research interface is the explicit
finite-fiber formula (1) and its application (2) to positive stability
extensions; whether that application produces previously unavailable
certificates requires a concrete, independently proved category-level input.

## 6. Classical skew-symmetrizable extension

Let D=diag(d_i) be a positive integer symmetrizer, so DB is skew-symmetric.
Choose the same A and set

    D'=diag(d_1,…,d_n,1,…,1),
    B'=(D')^−1 Aᵀ D B A,
    g'=(D')^−1 Aᵀ D g.

B' is an integer skew-symmetrizable exchange matrix with principal submatrix
B. Its new incoming normal acts by <a_j,Dm>, so the additional automorphism
is (1+t_j y^{a_j})^{±<a_j,Dm>}. With this normalization (1) remains valid,
with these B' and g'. Its first n label coordinates are exactly g.

To see the same proof, replace Λ and Λ' by

    Λ_D=[[0,−D],[D,−DB]],
    Λ_D'=[[0,−D'],[D',−D'B']],

and replace E by

    E={((D')^−1 AᵀDm,p') : m∈Z^n,p'∈Z^{n+s}}.

The embedding is integral and saturated because its first n coordinates are
m. All root directions are in E. Under (m,p')↦(m,Ap',p'_extra), the restricted
form is Λ_D⊕0. The Lie algebra restriction lemmas apply in the classical
limit, and ordinary skew-symmetrizable cluster positivity supplies the
nonnegative coefficients. Positive q again maps to a positive endpoint.

One may instead choose new diagonal entries δ_j dividing every coordinate
of Da_j. Then B' and g' are still integral and the new exponent is
<a_j,Dm>/δ_j. Taking δ_j=gcd(Da_j) uses the primitive new normal. The
skew-symmetric convention in Sections 1–4 uses δ_j=1, which explains the
specified multiplicity when a_j is nonprimitive.
