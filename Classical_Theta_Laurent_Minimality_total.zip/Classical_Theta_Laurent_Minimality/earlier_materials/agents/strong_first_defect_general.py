"""Multi-root exact first-defect constraints. Not a basis search certificate."""
import json,sys,time
from itertools import product
from pathlib import Path
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
from ctb_probe import AcyclicTheta,box,le,sub
from strong_lp_certificate import certify

def run(M,p,k=3):
    R=AcyclicTheta(((0,-k),(k,0)));roots=box(p);z=(0,0)
    labels=list(product(range(-M,M+1),repeat=2));idx={g:i for i,g in enumerate(labels)}
    def mul(f,h):
        out={}
        for a,c in f.items():
            for b,d in h.items():
                s=(a[0]+b[0],a[1]+b[1])
                if le(s,p):out[s]=out.get(s,0)+c*d
        return {q:c for q,c in out.items() if c}
    injectives=[R.F((-1,0),p),R.F((0,-1),p)]
    powers=[]
    for J in injectives:
        cache=[{z:1}]
        for n in range(M):cache.append(mul(cache[-1],J))
        powers.append(cache)
    F={g:R.F(g,p) for g in labels}
    def imaginary(g):
        a,b=g;return a>0 and b<0 and a*a+k*a*b+b*b<=0
    bounds=[]
    for g in labels:
        c=F[g].get(p,0)
        if imaginary(g):
            I=mul(powers[0][max(-g[0],0)],powers[1][max(-g[1],0)])
            bounds.append((-c,I.get(p,0)-c))
        else:bounds.append((0,0))
    # Precompute only shifted theta coefficients needed by triangular inversion.
    shifted={}
    for s in labels:
        shifted[s]={q:R.F(R.shift(s,q),sub(p,q)) for q in roots[:-1]}
    rr=[];cc=[];vv=[];rhs=[]
    for i,g in enumerate(labels):
        for h in labels[i:]:
            s=(g[0]+h[0],g[1]+h[1])
            if s not in idx:continue
            rem=mul(F[g],F[h]);sp=0
            for q in roots:
                val=rem.get(q,0)
                assert val>=0,(g,h,q,val)
                if q==p:sp=val;break
                if val:
                    for r,c in shifted[s][q].items():
                        t=(q[0]+r[0],q[1]+r[1])
                        rem[t]=rem.get(t,0)-val*c
            terms={}
            for q,v in ((s,1),(g,-1),(h,-1)):terms[idx[q]]=terms.get(idx[q],0)+v
            row=len(rhs)
            for col,v in terms.items():
                if v:rr.append(row);cc.append(col);vv.append(v)
            rhs.append(sp)
    A=coo_matrix((vv,(rr,cc)),shape=(len(rhs),len(labels)),dtype=np.int64).tocsr();rhs=np.array(rhs,dtype=np.int64)
    targets=[g for g in labels if bounds[idx[g]][0]<0]
    answers=[];objective=np.zeros(len(labels))
    for target in targets:
        objective[:]=0;objective[idx[target]]=1
        res=linprog(objective,A_ub=A,b_ub=rhs,bounds=bounds,method='highs')
        assert res.success,res.message
        cert=certify(res,A,rhs,bounds,objective);assert cert['verified'],cert
        answers.append({'g':target,'minimum':float(res.fun),'dual_certificate':cert})
        if res.fun<-.5:
            v=np.rint(res.x).astype(np.int64)
            valid=all(lo<=int(v[i])<=hi for i,(lo,hi) in enumerate(bounds)) and bool(np.all(A.dot(v)<=rhs))
            answers[-1]['integer_witness_valid']=valid
            if valid:answers[-1]['nonzero_witness']=[(g,int(v[i])) for i,g in enumerate(labels) if v[i]]
            # One exact witness falsifies the finite proposed implication.
            if valid:break
    return {'M':M,'k':k,'root':p,'labels':len(labels),'pairs':len(rhs),'targets':len(targets),'tested':len(answers),'minima':answers}

if __name__=='__main__':
    M=int(sys.argv[1]);p=tuple(map(int,sys.argv[2:4]));start=time.time()
    result=run(M,p);result['seconds']=time.time()-start
    out=Path(__file__).with_name('strong_first_defect_general_M%d_p%d_%d.json'%(M,*p));out.write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='minima'}))
    print('negative minima',[{'g':x['g'],'minimum':x['minimum'],'integer_witness_valid':x.get('integer_witness_valid')} for x in result['minima'] if x['minimum']<-.001])
