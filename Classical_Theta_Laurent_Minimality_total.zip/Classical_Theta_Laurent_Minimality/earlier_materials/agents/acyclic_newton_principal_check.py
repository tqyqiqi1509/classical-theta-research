"""Exact convention and valuation test for the principal Newton interface.

This does not prove vertex coverage by cluster cones.  It verifies the general
mutation identities, including frozen coordinates and singular exchange
matrices, and tests the resulting valuation formula on previously computed
complete CTB/theta Laurent polynomials.  No floating point arithmetic is used.
"""
from collections import defaultdict
from itertools import product
from pathlib import Path
import json


def mmutation(A, k):
    return tuple(tuple(-A[i][j] if i == k or j == k else
                       A[i][j]+max(A[i][k], 0)*max(A[k][j], 0)
                       -max(-A[i][k], 0)*max(-A[k][j], 0)
                       for j in range(len(A[0]))) for i in range(len(A)))


def phi(A, g, k):
    return tuple(-g[k] if i == k else g[i]
                 + max(A[i][k], 0)*max(g[k], 0)
                 - max(-A[i][k], 0)*max(-g[k], 0)
                 for i in range(len(g)))


def avalue(A, v, k):
    out=list(v)
    out[k]=-v[k]+min(sum(max(A[i][k], 0)*v[i] for i in range(len(v))),
                      sum(max(-A[i][k], 0)*v[i] for i in range(len(v))))
    return tuple(out)


def rootvalue(A, v):
    return tuple(sum(A[i][j]*v[i] for i in range(len(v)))
                 for j in range(len(A[0])))


def negate(A): return tuple(tuple(-x for x in row) for row in A)
def dot(a,b): return sum(x*y for x,y in zip(a,b))


def words(n, depth):
    yield ()
    frontier=[()]
    for _ in range(depth):
        frontier=[w+(k,) for w in frontier for k in range(n)
                  if not w or w[-1] != k]
        yield from frontier


def paths(B, word):
    n=len(B)
    A=tuple(B)+tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
    path=[A]
    for k in word:
        A=mmutation(A,k)
        path.append(A)
    return path


def opposite_backtransport(path, word, target):
    n=len(target)
    g=tuple(target)
    for i in range(len(word)-1, -1, -1):
        g=phi(negate(path[i+1][:n]),g,word[i])
    return g


def test_case(case, word, path, a, stats):
    n=len(a)
    w=opposite_backtransport(path,word,a)
    # A cluster cone is linear: inverse tropical map of a positive point
    # equals the same positive combination of the cluster g-vector columns.
    gs=[opposite_backtransport(path,word,tuple(int(i==j) for i in range(n)))
        for j in range(n)]
    assert w==tuple(sum(a[j]*gs[j][i] for j in range(n)) for i in range(n))
    initial_w=w
    v=(0,)*n+w
    g=tuple(case['g'])+(0,)*n
    for i,k in enumerate(word):
        A=path[i]
        assert rootvalue(A,v)==w
        if w[k]==0:stats['intermediate_exchange_ties']+=1
        v=avalue(A,v,k)
        w=phi(negate(A[:n]),w,k)
        g=phi(A,g,k)
        assert rootvalue(path[i+1],v)==w
        stats['single_mutation_identities']+=1
    assert w==tuple(a)
    prediction=dot(v,g)
    vals={}
    for char,rows in case['characters'].items():
        vals['p='+char]=min(dot(initial_w,e) for e,c in rows if c)
    vals['theta']=min(dot(initial_w,e) for e,c in case['theta_coefficients'] if c)
    assert all(val==prediction for val in vals.values()),(case['B'],case['r'],word,a,vals,prediction)
    stats['complete_character_valuations']+=len(vals)
    stats['cluster_chamber_witnesses']+=1
    return {'word':word,'positive_terminal_root_weight':a,
            'delta':tuple(-x for x in initial_w),'full_terminal_valuation':v,
            'full_terminal_pointed_degree':g,'support_value':-prediction}


def main():
    root=Path(__file__).resolve().parents[1]
    cases=[]
    for name in ['modular_euler_rank2.json','modular_euler_rank3.json']:
        cases+=json.loads((root/'computation'/name).read_text())['cases']
    grouped=defaultdict(list)
    for case in cases:grouped[tuple(map(tuple,case['B']))].append(case)
    stats=defaultdict(int)
    samples=[]
    for B,cohort in grouped.items():
        n=len(B)
        weights=[tuple(range(1,n+1)),tuple(range(n,0,-1)),(1,)*n]
        for word in words(n,5):
            path=paths(B,word)
            for a in weights:
                for case in cohort:
                    sample=test_case(case,word,path,a,stats)
                    if len(word)==5 and case is cohort[-1] and a==weights[0]:
                        samples.append({'B':B,'r':case['r'],**sample})
    out={'status':'PASS','scope':'exact full-principal valuation convention check; not a proof of normal-cone cluster coverage',
         'input_complete_characters':len(cases),'quivers':len(grouped),
         'mutation_word_max_length':5,'stats':dict(stats),'samples':samples[:30]}
    target=root/'agents'/'acyclic_newton_principal_check.json'
    target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='samples'},indent=2))


if __name__=='__main__': main()
