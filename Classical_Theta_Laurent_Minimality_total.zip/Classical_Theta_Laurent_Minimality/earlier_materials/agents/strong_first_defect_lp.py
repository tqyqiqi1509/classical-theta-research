"""Finite restrictions of the all-label first-defect multiplication inequalities.

This is a diagnostic of a proposed general mechanism, not a construction of a
cluster basis.  Theta coefficients are computed by the existing exact acyclic
scattering routine.  LP answers are rationally rechecked before being recorded.
"""
from itertools import product
from pathlib import Path
import json, sys, time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.optimize import linprog
from ctb_probe import AcyclicTheta
from strong_lp_certificate import certify

def run(M=12, k=3):
    R=AcyclicTheta(((0,-k),(k,0)))
    labels=list(product(range(-M,M+1),repeat=2))
    idx={g:i for i,g in enumerate(labels)}
    def coeff(g):
        f=R.F(g,(1,1))
        return (f.get((1,0),0),f.get((0,1),0),f.get((1,1),0))
    C={g:coeff(g) for g in product(range(-M-k,M+k+1),repeat=2)}
    def imaginary(g):
        a,b=g
        return a>0 and b<0 and a*a+k*a*b+b*b<=0
    bounds=[]
    for g in labels:
        a,b,c=C[g]
        bounds.append((-c,a*b+k*b-c) if imaginary(g) else (0,0))
    rr=[];cc=[];vv=[];rhs=[];pairs=[]
    for i,g in enumerate(labels):
        for h in labels[i:]:
            s=(g[0]+h[0],g[1]+h[1])
            if s not in idx:continue
            ag,bg,cg=C[g];ah,bh,ch=C[h];a,b,c=C[s]
            s1=ag+ah-a;s2=bg+bh-b
            sp=cg+ch+ag*bh+bg*ah-c-s1*C[(s[0],s[1]+k)][1]-s2*C[(s[0]-k,s[1])][0]
            assert sp>=0,(g,h,sp)
            terms={}
            for q,v in ((s,1),(g,-1),(h,-1)):
                terms[idx[q]]=terms.get(idx[q],0)+v
            row=len(rhs)
            for col,v in terms.items():
                if v:rr.append(row);cc.append(col);vv.append(v)
            rhs.append(sp);pairs.append((g,h,sp))
    A=coo_matrix((vv,(rr,cc)),shape=(len(rhs),len(labels))).tocsr()
    objective=np.zeros(len(labels))
    targets=[g for g in labels if bounds[idx[g]][0]<0]
    answers=[]
    for target in targets:
        objective[:]=0;objective[idx[target]]=1
        res=linprog(objective,A_ub=A,b_ub=rhs,bounds=bounds,method='highs')
        assert res.success,res.message
        cert=certify(res,A,rhs,bounds,objective)
        assert cert['verified'],cert
        answers.append({'g':target,'minimum':float(res.fun),'dual_certificate':cert})
        if res.fun<-.5:
            # Integer rounded candidates are checked exactly. LP optimality itself
            # is not promoted to an exact theorem by this check.
            v=np.rint(res.x).astype(np.int64)
            valid=all(lo<=int(v[i])<=hi for i,(lo,hi) in enumerate(bounds)) and bool(np.all(A.dot(v)<=np.array(rhs)))
            answers[-1]['integer_witness_valid']=valid
            if valid:answers[-1]['nonzero_witness']=[(g,int(v[i])) for i,g in enumerate(labels) if v[i]]
    # An independent maximum asks whether the mechanism already kills all
    # nonresonant positive defects. It should not be assumed to do so.
    target=(M,-max(1,2*M//3))
    objective[:]=0;objective[idx[target]]=-1
    res=linprog(objective,A_ub=A,b_ub=rhs,bounds=bounds,method='highs')
    assert res.success,res.message
    maxima={'g':target,'maximum':-float(res.fun)}
    v=np.rint(res.x).astype(np.int64)
    valid=all(lo<=int(v[i])<=hi for i,(lo,hi) in enumerate(bounds)) and bool(np.all(A.dot(v)<=np.array(rhs)))
    maxima['integer_witness_valid']=valid
    if valid:maxima['nonzero_witness']=[(g,int(v[i])) for i,g in enumerate(labels) if v[i]]
    return {'M':M,'k':k,'labels':len(labels),'pairs':len(rhs),'negative_lower_bound_targets':len(targets),'minima':answers,'positive_defect_maximum':maxima}

if __name__=='__main__':
    t=time.time();M=int(sys.argv[1]) if len(sys.argv)>1 else 10
    data=run(M);data['seconds']=time.time()-t
    p=Path(__file__).with_name(f'strong_first_defect_lp_M{M}.json')
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in data.items() if k!='minima'}))
    print('negative minima',[x for x in data['minima'] if x['minimum']<-.0001])
