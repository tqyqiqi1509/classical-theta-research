# Automatic pointedness of classical strongly positive bases in an acyclic principal seed

Research branch: strong_basis_homogeneity_pointedness. Begun 2026-11-14 05:08 UTC.
This is a new proof candidate independently reconstructed by the parent. It is a statement about classical cluster algebras, with an essential principal-coefficient hypothesis. It does not establish arbitrary strong-basis theta positivity.

## 1. Precise statement

Let B be an acyclic skew-symmetrizable exchange matrix. Relabel vertices so B_ij<=0 for i<j. Let R=Z[y_1^{+-1},...,y_n^{+-1}], and let A be the classical cluster algebra with principal extended exchange matrix (B;I). Frozen variables are inverted. A strong positive R-basis means an algebraic R-basis C that contains all mutable cluster monomials, and whose multiplication constants belong to N[y_1^{+-1},...,y_n^{+-1}]. No pointedness or grading assumption is imposed.

For b in C, take its finite Laurent expansion in the chosen initial seed and let m_i(b) be the smallest exponent of y_i occurring. Define

    b^natural = y^(-m(b)) b.

Then the normalized elements form an R-basis, uniquely indexed by g in Z^n, and

    b_g^natural = x^g (1 + sum_(0!=p in N^n) a_(g,p) y^p x^(Bp)),
    a_(g,p) in N,

with finite support. In particular, each is homogeneous for deg(x_i)=e_i, deg(y_i)=-B e_i, the leading coefficient is one, every label occurs exactly once, and no additional normalized basis elements remain.

Moreover let E_g be the acyclic standard monomial with head x^g described below. Its expansion in the normalized basis has coefficients in N[y], and the coefficient of b_g^natural has constant term one. Thus

    E_g - b_g^natural in N[x_1^{+-1},...,x_n^{+-1},y_1,...,y_n].

This last inequality is a genuine explicit finite carrier for every arbitrary strong basis element in this principal setting. It does not say E_g is itself a strongly positive basis.

## 2. Existing standard-monomial input and the exact coefficient convention

For the positive principal framing, the first mutation at i satisfies

    x_i x_i' = y_i product_j x_j^[B_ji]_+ + product_j x_j^[-B_ji]_+.

Put

    E_a = product_i x_i^[a_i]_+ (x_i')^[-a_i]_+,    a in Z^n.

Each E_a is a product of actual cluster variables, although its factors need not belong to one cluster. It is a nonnegative Laurent polynomial in x and a polynomial in y. At y=0,

    E_a(0)=x^(G(a)),
    G_i(a)=a_i + sum_(j>i) (-B_ij)[-a_j]_+.

The map G:Z^n -> Z^n is a bijection: solve for a_n first and then for a_(n-1),...,a_1. Write E_g=E_(G^-1(g)). Thus

    E_g = x^g + terms of strictly positive total y-degree.

The acyclic standard-monomial basis theorem is an existing input: Berenstein-Fomin-Zelevinsky, Cluster Algebras III, arXiv:math/0305434v3, Definition 1.15, Theorem 1.16 and Theorem 1.20 / Corollary 1.21. It says that these standard monomials form an R-basis of A. The primary PDF was read at the displayed results and the relevant standard-monomial proof. No 2026 theorem is needed for this input.

The argument below uses the polynomial lattice

    A_+ := direct_sum_(g in Z^n) Z[y] E_g.

It does not initially assume that this lattice is the cluster algebra defined with noninvertible frozen variables. That distinction is resolved by the intersection lemma, avoiding an unjustified coefficient specialization of a localized theorem.

## 3. Standard-lattice saturation

**Lemma.** Inside R[x_1^{+-1},...,x_n^{+-1}],

    A_+ = A intersect Z[y][x_1^{+-1},...,x_n^{+-1}].

The forward inclusion is immediate. For the reverse inclusion, write an element f of the intersection as a finite sum

    f = sum_g c_g(y) E_g,       c_g in R.

Suppose one monomial y^u in one c_g has a negative coordinate. Choose a strictly positive rational weight w on the y-exponents with w.u<0. Perturb w, while keeping all coordinates positive and w.u<0, to make it distinguish the finitely many distinct coefficient exponents appearing in all c_g. Let u_0 be their unique exponent of smallest w-weight. Its weight is negative.

Every E_g has w-lowest part exactly x^g, because all other y-exponents are nonzero and nonnegative. Therefore the w-lowest part of f is

    y^(u_0) sum_g c_(g,u_0) x^g.

The x^g are distinct Laurent monomials, so this is nonzero. It has negative w-weight, contradicting the fact that f is polynomial in y. Thus all coefficient exponents are nonnegative, proving the lemma.

This is a finite argument: the coefficients c_g and their supports are finite. It does not infer algebraic spanning from an infinite triangular matrix or use completeness to create an infinite inverse.

## 4. Ordinary Laurent positivity from the strong-basis axioms

Fix a cluster t and b in C. Multiply b by a sufficiently large mutable cluster monomial M in t to clear all negative mutable exponents. Then

    M b = sum_(a>=0) f_a(y) x_t^a,

a finite expression over R. On one hand, strong positivity makes Mb an N[y^{+-1}]-linear combination of C. On the other hand, every x_t^a belongs to C. Uniqueness of expansion in the actual R-basis therefore gives f_a(y) in N[y^{+-1}]. Hence every b has nonnegative Laurent coefficients in every ordinary cluster chart.

In particular b^natural is nonnegative and polynomial in the initial y variables, with coordinatewise minimum y-exponent zero. By Section 3 it belongs to A_+.

## 5. Positive expansion of the standard basis over the polynomial ring

Every E_g is a product of cluster variables. Successive multiplication in C expresses E_g as a finite N[y^{+-1}]-linear combination of C, hence of the normalized basis C^natural:

    E_g = sum_b d_(g,b)(y) b^natural,
    d_(g,b) in N[y^{+-1}].

No monomial y^u of any nonzero d_(g,b) can have u_i<0. Indeed, b^natural has at least one term with y_i exponent zero; multiplying that term by y^u produces a term with negative y_i exponent. All summands have nonnegative Laurent coefficients, so this term cannot cancel. That contradicts E_g being polynomial in y.

Consequently every d_(g,b) belongs to N[y]. Each b^natural already belongs to A_+, and these positive polynomial expansions show that C^natural spans A_+ over Z[y]. It is independent because it is still an R-basis after multiplying its elements by units. It is therefore a genuine Z[y]-basis of A_+.

The coordinatewise normalization is crucial: it need not initially imply b^natural(0)!=0. Nonvanishing after specialization follows from the polynomial-basis conclusion just proved, not from an assumed head.

## 6. Specialization forces monomial heads and excludes extra labels

Specializing the free Z[y]-module A_+ at y_1=...=y_n=0 gives a free Z-module with basis E_g(0)=x^g. The embedding of this quotient into Z[x^{+-1}] is an isomorphism of modules because these heads are exactly all Laurent monomials.

Because C^natural is a Z[y]-basis, its specializations also form a Z-basis of this Laurent module. They are nonnegative Laurent polynomials. The formulas in Section 5 say that every Laurent monomial x^g is a nonnegative integer combination of them.

A positive integer combination can equal the single monomial x^g with coefficient one only if one of its nonzero summands is exactly x^g with coefficient one. Thus each x^g itself occurs among the specialized basis vectors. Linear independence excludes any duplicate or any additional vector. Therefore

    C^natural(0)={x^g:g in Z^n},

bijectively. This also excludes zero specializations.

This step is the infinite-basis version of the elementary fact that a nonnegative integral matrix with nonnegative integral inverse must be a permutation matrix. The argument uses actual finite expansions of each vector, not an infinite matrix determinant.

## 7. Homogeneity and full pointedness

For the standard principal grading deg(x_i)=e_i and deg(y_i)=-B e_i, each exchange relation is homogeneous. Hence each E_g is homogeneous of degree g.

In its positive expansion from Section 5, the coefficient d_(g,b_g^natural) has constant term one by Section 6. Thus b_g^natural occurs as an actual nonnegative Laurent summand of the homogeneous E_g. Since no cancellation is possible, all Laurent monomials of b_g^natural have degree g. A term x^v y^p consequently satisfies

    v-Bp=g.

Since p>=0 and b_g^natural(0)=x^g, this proves the full pointed expansion in Section 1. It also proves E_g-b_g^natural is Laurent-nonnegative, because the positive expansion contains b_g^natural with coefficient at least the constant polynomial one.

An alternative argument establishes homogeneity before identifying labels: each normalized basis element must occur in at least one positive E_g expansion since those E_g span the module, and any one monomial coefficient in that expansion forces its homogeneous degree. The preceding order avoids that extra bookkeeping.

## 8. What is deliberately not concluded

- No arbitrary coefficient-free basis is claimed to lift to principal coefficients.
- No arbitrary skew-symmetrizable coefficient system is silently identified with the principal ring; the theorem as stated uses independent y_i and frozen inversion.
- Pointedness is proved in the chosen acyclic principal seed. Pointedness in an arbitrary mutation-equivalent cyclic seed needs a further argument, because its first-neighbor standard monomials need not form an algebraic basis.
- Injective pointed sets are not substituted for the standard basis without an algebraic spanning theorem; some are only topological bases.
- The theorem gives no automatic remote finite-jet equality with theta. Positive deformation terms may still persist in a strong basis; the parent branch's modular proof needs its separate new Ext/saturation mechanism.
- The theorem does not infer theta transition positivity from ordinary Laurent positivity.

## 9. Primary literature and novelty status

Sources opened and checked in this branch:

1. BFZ, Cluster Algebras III, arXiv:math/0305434v3, https://arxiv.org/pdf/math/0305434 : Definition 1.15, Theorems 1.16/1.20, Corollary 1.21, and the role of the coefficient group. These are the standard-basis inputs, not new claims.
2. Qin, Bases for upper cluster algebras and tropical points, arXiv:1902.09507v4, https://arxiv.org/html/1902.09507v4 : the classification imposes tropical pointedness; it does not supply this arbitrary-strong-basis implication. Its finite deformation theorem does not force coefficient signs.
3. LLRZ, Greedy bases in rank 2 quantum cluster algebras, https://pmc.ncbi.nlm.nih.gov/articles/PMC4103316/ : ordinary Laurent positivity by denominator clearing is explicitly old, and automatic pointedness was posed separately.
4. Qiyue Tang, Strongly positive bases in rank-two quantum cluster algebras, Hexagon2609.00143v3: the previous branch audited its coefficient-free rank-two argument. The present proof uses independent principal parameters and a polynomial-lattice specialization; it does not claim to subsume the arbitrary coefficient-free result.

Queries included `strongly positive pointed acyclic`, `positive basis principal coefficients homogeneous`, `strongly positive bases pointed cluster`, `cluster basis specialization pointedness`, and `acyclic cluster algebra standard monomial basis polynomial coefficients y zero degeneration`. No equivalent all-rank principal statement was found in this bounded search. This is not an absolute priority assertion. A separate broad search of positive based-ring degenerations remains worthwhile.

## 10. Route record

The prior branch's infinite-triangular obstruction is real. The new proof avoids it by first identifying an honest polynomial coefficient lattice and proving that the entire normalized strong basis is a basis of that lattice. Specialization then acts on a genuine free module. Ordinary Laurent positivity alone does not imply this: positive expansions of every actual standard monomial in the competing basis are essential.

A tempting extension using an injective pointed set was checked against current literature and not assumed: such sets can be topological rather than algebraic bases. The acyclic first-neighbor standard basis is the appropriate actual finite-expansion input.

## 11. Computation-plugin verification

The Wolfram computation plugin checked all 32 sign orthants of a symbolic five-vertex triangular map G. Every piece has determinant one, and the finite nilpotent inverse sum multiplies to the identity. It also exhaustively examined 19,683 nonnegative 3x3 matrices with entries in {0,1,2}; 2,022 were unimodular, and exactly six had nonnegative inverses, all permutation matrices. These are diagnostics for the two general elementary arguments, not substitutes for their proofs.

Files: computation/strong_pointedness_wolfram.wl and computation/strong_pointedness_wolfram_receipt.json. The first attempt used symbolic Sum with MatrixPower on a singular nilpotent matrix, leading Wolfram to an inappropriate symbolic geometric-sum evaluation. The raw failed receipt is retained as strong_pointedness_wolfram_failed_sum_receipt.json. Replacing this with an explicit finite Table and an explicit identity term gives all True; no mathematical conclusion uses the failed evaluation.
