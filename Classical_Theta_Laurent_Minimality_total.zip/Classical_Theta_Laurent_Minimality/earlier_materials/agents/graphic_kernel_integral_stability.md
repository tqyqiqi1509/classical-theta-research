# Graphic Euler kernels: integral reductions and a finite local-chamber theorem

Research branch opened 2026-11-14, approximately 03:57 UTC. This file records the general mechanism under investigation, the strict results obtained, and the unresolved bridge. It concerns classical specializations of standard geometric modular KLR bases. It does not claim a new theta-positivity theorem at this stage.

## 1. Target and the precise remaining implication

Read in full before this branch: `agents/modular_basis_minimality.md`. The existing characteristic-zero finite-window theorem is in `interfaces_history/Qin_theta_final_total_20261031_072647/Qin_theta_research/results/GENERAL_FINITE_WINDOW_THEOREM.md`.

Fix an acyclic skew-symmetric matrix, ordered so that `B_ij=-m_ij<=0` for `i<j`, a root box `0<=b<=E`, and a nonresonant direction `nu`, meaning `nu.d != 0` for every nonzero `d<=E`. The old CTB theorem proves theta agreement on this fixed box at `g=N nu+h`, for any prescribed finite collection of offsets `h` and sufficiently large `N`.

The desired new ingredient is characteristic-independent Euler-image rank on such a window. It suffices to show that the integral Euler multiplication matrices are saturated once `N` is sufficiently large. A weaker sufficient statement is that their total number of unit Smith factors is at least the theta coefficient: characteristic-zero rank agrees with theta in the old finite-window region, and the inequality then forces every nonzero factor to be a unit.

For a fixed characteristic `p`, the product detector actually needs only one sufficiently far value of `N` with the required finite collection of jets. Uniform eventual saturation for all `N` and all primes is stronger than necessary. An arbitrarily large good sequence depending on `p` would suffice. This relaxation is mathematical, but no such sequence is proved here.

## 2. Integral Euler formulation

Let

\[
H=\bigotimes_i H^*(\operatorname{Gr}(b_i,r_i);\mathbb Z),\qquad
F=\prod_{i<j} e\bigl(\operatorname{Hom}(S_i,Q_j)\bigr)^{m_{ij}}.
\]

Put

\[
g_i=-r_i+\sum_{j>i}m_{ij}r_j,
\quad q_B(b)=\sum_i b_i^2-\sum_{i<j}m_{ij}b_i b_j,
\quad \delta=-g\cdot b-q_B(b).
\]

The Smith factors of multiplication by `F` can be computed from the graded Gram forms

\[
G_{\lambda,\mu}=\int F\prod_i s_{\lambda_i}s_{\mu_i},
\qquad |\lambda|=d,\quad |\mu|=\delta-d.
\]

This uses the integral unimodularity of Grassmannian Poincare duality. The fixed graphic list has one vertex for each of the `sum b_i` Chern roots and has `m_ij` copies of

\[
e_{j,\beta}-e_{i,\alpha}.
\]

Its partition kernel is

\[
\prod_{i<j,\alpha,\beta}(1-x_{j,\beta}/x_{i,\alpha})^{-m_{ij}}
=\sum_\eta P_X(\eta)x^\eta.
\]

The matrix entries are finite Weyl alternants of translates of `P_X`. The integral formula and the ordered-integration justification are established in the preceding branch. The implementations `computation/euler_graphic_kernel.py` and `computation/graphic_kernel_euler.py` are independent implementations of the same identity. No inverse of a nilpotent cohomology class is taken.

An incidence list of a graph is unimodular in its saturated span lattice. Components are handled separately. This fact controls the partition function but does **not** imply that arbitrary finite Gram windows are saturated.

## 3. A strict flag-bundle reduction

### Proposition 3.1

Let `Y=product_i Gr(b_i,r_i)` and let

\[
\pi:\widetilde Y=\prod_i\operatorname{Fl}(1,\ldots,b_i;r_i)\longrightarrow Y
\]

be the product of complete flag bundles of the tautological bundles. For every integral cohomology class `F` on `Y`, the image of multiplication by `F` on `H^*(Y;Z)` is saturated if and only if the image of multiplication by `pi^*F` on `H^*(Ytilde;Z)` is saturated.

More precisely, the complete list of nonzero Smith factors for the latter multiplication is the former list repeated `product_i b_i!` times. In each degree the list is the union of the corresponding base lists, shifted by the fiber Schubert degrees.

### Proof

The integral flag-bundle formula gives a homogeneous Leray–Hirsch basis `u_w`, indexed by the product of the symmetric groups, and an isomorphism of modules

\[
H^*(\widetilde Y;\mathbb Z)
=\bigoplus_w H^*(Y;\mathbb Z)u_w.
\]

Multiplication by `pi^*F` sends `a u_w` to `(F a)u_w`. Hence its matrix in this integral basis is a direct sum of copies of the base multiplication matrix, with the stated degree shifts. The cokernel is the corresponding direct sum of base cokernels. Torsion vanishes on one side exactly when it vanishes on the other. This proves the assertion.

This reduction uses neither a Weyl-group average nor division by a factorial.

### 3.2 Explicit integral retraction

For one color write `S=Z[x_1,...,x_b]`, `A=S^{S_b}`, and `rho=(b-1,b-2,...,0)`. The divided-difference operator

\[
\partial_i f=\frac{f-s_i f}{x_i-x_{i+1}}
\]

preserves integral polynomials. With compatible reduced-word conventions,

\[
\partial_{w_0}(x^\rho f)=f\qquad(f\in A).
\]

Thus `P(f)=partial_w0(x^rho f)` is an integral `A`-linear projection onto `A`. The Grassmannian relations are generated by symmetric complete functions, so the projection descends to the flag extension of the Grassmannian ring. It commutes with multiplication by the symmetric Euler class.

By contrast, `partial_w0(Delta f)=b! f` is not an integral retraction at primes dividing `b!`.

The projection identity was checked symbolically for `b=2,3,4,5` by the Wolfram calculation saved in `computation/graphic_integral_demazure_wolfram.json`. The proof is the standard divided-difference identity; the calculation only checks conventions.

### 3.3 What this does not yet solve

Flag integration still involves a fixed Vandermonde alternant. Therefore flag reduction alone does not turn the Euler Gram form into an unrestricted partition-function evaluation matrix. An arbitrary finite difference of a saturated lattice need not have saturated image. A compatible integral splitting, not only the existence of an integral projection, is still needed at this interface.

## 4. Integral local-chamber interpolation

The next result is a genuinely useful finite-window statement, but it concerns one chamber polynomial and not the full multi-chamber Euler Gram matrix.

### 4.1 Audited primary inputs

**DCPV, Box splines and the equivariant index theorem, J. Inst. Math. Jussieu (2012), Definition 2.19 and Theorem 2.25.**

Primary author PDF: <https://webusers.imj-prg.fr/~michele.vergne/publications/Boxsplines.pdf>.

`DM(X)` is defined as the abelian group of integer-valued lattice functions annihilated by all cocircuit difference operators. For an alcove `c`, let

\[
C=(\epsilon-Z(X))\cap\Lambda,\qquad\epsilon\in c.
\]

The restriction map `DM(X)->Z^C` is an isomorphism: its inverse has the integer-valued cardinal functions supplied by Theorem 2.25. This is an integral interpolation statement. It is stronger than merely having the same rational dimension. The paper sometimes suppresses scalar-extension subscripts; Definition 2.19, the discussion immediately preceding Theorem 2.25, and the explicit integer surjectivity in Remark 2.21 were checked to avoid confusing the integral and complex statements.

**Cavazzani–Moci, Geometric realizations and duality for Dahmen–Micchelli modules and De Concini–Procesi–Vergne modules, arXiv:1303.0902v6, Section 2.4.**

Primary PDF: <https://arxiv.org/pdf/1303.0902> (v6 dated 2015-09-29; published 2016).

For a chamber `Omega`, let `q_Omega` be the partition quasipolynomial, and let `L_Omega` consist of subsets `A` for which the cone generated by `X\A` does not contain the chamber. The paper identifies the local module in both forms

\[
DM_\Omega(X)=\mathbb Z[\Lambda]q_\Omega
=\{f:\Lambda\to\mathbb Z:\nabla_A f=0\ (A\in L_\Omega)\}.
\tag{4.1}
\]

We use the integral local-module identity (4.1), not the conjectural geometric realization in that paper's Section 6. In the graphical unimodular situation `q_Omega` is an integer-valued polynomial of total degree at most `D=|X|-rank(X)`.

The source contains a notational slip describing the action of Laurent generators as differences, although the action defined earlier is translation. The argument below uses the correct translation action and explicitly constructs its integer finite-difference expansion. It does not use the proof of their infinite-rank converse or any claim that an arbitrary product of copies of `Z` is free.

### Lemma 4.2: bounded integral translation generators

Let `q:Lambda->Z` be a polynomial function of total degree at most `D`. Fix any lattice basis `u_1,...,u_s`, and define `T_z q(t)=q(t-z)`. Then the cyclic translation lattice `Z[Lambda]q` is generated over `Z` by

\[
\{T_\beta q:\beta=\sum_i k_i u_i,\ k_i\ge0,\ \sum_i k_i\le D\}.
\tag{4.2}
\]

**Proof.** Write `Delta_i=T_{u_i}-1`. Products `Delta^alpha q` vanish when `|alpha|>D`. For every integer vector `z`, including negative coordinates, the finite Newton identity gives

\[
T_zq=\sum_{|\alpha|\le D}\prod_i\binom{z_i}{\alpha_i}\Delta^\alpha q.
\]

All coefficients are integers. Each `Delta^alpha q` is an integer linear combination of `T_beta q` with `0<=beta_i<=alpha_i`, hence `|beta|<=D`. This proves (4.2). No monomial-coordinate denominators are inverted.

### Theorem 4.3: local-chamber integral Hankel saturation

Assume the integral local-module identity (4.1). Let `X` be unimodular of rank `s` in `Lambda`, put `D=|X|-s`, and choose any shifted-zonotope control set `C` as above. Let `R` be a finite row set containing `C`. Let `T` be any finite column set containing the translation simplex (4.2). Then the integer matrix

\[
M_{a,\beta}=q_\Omega(a-\beta),\qquad a\in R,\ \beta\in T,
\]

has all nonzero Smith factors equal to `1`.

The same conclusion holds after any common integral translation of the argument of `q_Omega`.

**Proof.** The right-hand side of (4.1) is the simultaneous kernel of integer-linear maps into torsion-free groups. It is therefore a saturated sublattice of `DM(X)`. By the cardinal interpolation isomorphism, its restriction to `C` is a saturated sublattice of `Z^C`.

Adding rows outside `C` preserves this primitivity: evaluations at any additional lattice point are integer linear combinations of evaluations on `C`, because the inverse interpolation map is integral. Integral row operations eliminate those extra rows from the graph of the restriction map. By Lemma 4.2, the columns generate exactly the evaluation lattice of `DM_Omega(X)`. This image is saturated, so the Smith factors are all units. An integral translation of `q_Omega` generates the same local module, since its inverse translation is integral. This proves the last assertion.

This theorem guarantees an integral change of rows and columns. It does **not** guarantee that any maximal minor in the original coordinate matrix is `+1` or `-1`.

### Corollary 4.4: actual partition-kernel windows

Suppose a finite set of entries `N nu+a-beta` lies in the region `Omega-Z(X)` where `P_X=q_Omega`. If the row and column sets satisfy Theorem 4.3, the corresponding matrix of actual partition counts has saturated image. For fixed `R,T` and `nu` in the open chamber, this containment holds for every sufficiently large `N`.

All offsets in the criterion depend on the fixed list `X`, not on `N`. The row control set lies in a translate of the fixed zonotope, and the column simplex has radius `D` in a fixed lattice basis.

### 4.5 Exact point at which the global proof is still missing

The complete Euler Gram matrix is not a single fixed local-chamber patch. Its row and column windows grow, cross several translated walls, satisfy nonnegative partition/rectangle constraints, and are coupled by Schur multiplication and the Weyl alternant. The preceding theorem does not show that the integral changes of basis on different chamber patches glue to an integral block decomposition. Nor does it show that the required translations remain inside the relevant degree-preserving Grassmannian windows after all boundary operations.

A sufficient missing result would be a filtration of the actual flag/Euler window whose graded integral pairing blocks are the local modules of Theorem 4.3, with each control set and translation simplex present and with integral transition maps. The DCPV rational-subspace splitting is a candidate mechanism, but this compatibility has not been established here.

## 5. Exact all-prime computation testing the proposed margin

The program `computation/graphic_saturation_margin_probe.py` tests the conjectural criterion

\[
g\cdot d\ne0,\qquad |g\cdot d|>-q_B(d)
\quad(0<d\le b).
\tag{5.1}
\]

It also tests the weaker inequality

\[
\#\{\text{unit Smith factors}\}\ \ge\ a_g^\theta(b).
\tag{5.2}
\]

The computations use exact Smith forms over `ZZ`, not a finite prime scan. Deterministic random seed: `14110403`. Candidate construction sampled 30,000 triples from twenty rank-two and thirty rank-three graph/root scenarios, retained `0<=delta<=10`, and selected 160 cases satisfying (5.1) and 160 boundary/control cases not satisfying it. There were 1,918 strict-margin and 1,329 control candidates before this selection. The completed run took 85.126 seconds.

Results recorded in `computation/graphic_saturation_margin_probe.json`:

| Class | Cases | Cases with a nonunit Smith factor | Violations of (5.2) |
|---|---:|---:|---:|
| Strict margin (5.1) | 160 | 0 | 0 |
| Boundary/control | 160 | 104 | 0 |
| Combined | 320 | 104 | 0 |

In 302 of the 320 cases the unit Smith count equaled the theta coefficient; in 18 it was larger. This is evidence for the structural conditions, not a proof of either (5.1) or (5.2).

The control cases matter: the implementation detects many genuinely nonprimitive images. Thus the strict-margin outcome is not explained by an implementation that always discards torsion.

For any integer matrix, the number of unit Smith factors is the minimum of its ranks over all prime fields. Indeed, if the first nonunit invariant is `d_j`, every later nonzero invariant is divisible by `d_j`; a prime divisor of `d_j` kills all of them, while unit invariants survive in every characteristic. Consequently (5.2) is exactly a uniform lower bound on modular ranks.

### 5.1 Why the original Schur coordinates need Bezout combinations

The parent computation gives a useful warning in the rank-two, three-arrow family `b=(2,3)`, `g=(4N,-3N)`. At `N=6` the degree-zero Gram block is a `192 x 1` column whose smallest positive entry is `14140`, but the gcd of all its entries is `1`. At `N=7` and `N=10` the corresponding minima are `29940` and `302380`, again with gcd `1`.

Therefore saturation cannot be proved by searching for an original Schur entry equal to `1`, or by demanding a unique positive flow for each pivot. Genuine integral differences and Bezout combinations are necessary. Theorem 4.3 has exactly this Smith-form meaning.

### 5.2 Reproducible local-DM mechanism test

`computation/graphic_local_dm_probe.py` independently constructs the full shifted-zonotope control set by exact bounded integral flow, checks its cardinality against the matrix-tree determinant, includes the complete translation simplex from Lemma 4.2, and verifies that every partition-kernel argument has the same signs on all graph cuts. It then computes exact Smith forms. The script records the actual control points, translations, ray, scale, and factors, so its hypothesis checks are reproducible.

This is a direct test of the local theorem's mechanism. Its results do not replace the missing multi-chamber/Schur-window gluing argument.

The completed run contains ten graph/list cases and took 5.221 seconds. All ten have only unit nonzero Smith factors. The largest recorded matrix is `32 x 56`; its control-set cardinality is independently `32`. The lists include `K_{2,4}`, the graph `K_{2,2}` with every edge doubled, the complete acyclic graph on four vertices, and five distinct weighted triangles.

## 6. Literature and route review, including failed interfaces

### 6.1 DCPV finite-difference splitting

De Concini–Procesi–Vergne, *Vector partition functions and generalized Dahmen–Micchelli spaces*, arXiv:0805.2907v2 (2008-08-17), primary <https://arxiv.org/html/0805.2907v2>.

Read Definition 2.4, the integral split exact sequence of Theorem 3.10, Theorem 3.18 and its chamber-minus-zonotope conclusion. Useful: integral convolution splittings and support control, and integer-valued chamber quasipolynomials. Insufficient by itself: no theorem identifies the Smith factors of an arbitrary finite Hankel truncation. In particular, `F(X)` is not translation-invariant; its translation closure is a larger module. The distinction is explicit in Cavazzani–Moci Section 2.5 and must be retained when a growing window is translated.

### 6.2 Integral Kirwan surjectivity

Pomerleano–Teleman, *Integral Kirwan surjectivity*, arXiv:2410.06197v2 (2025-06-10), primary <https://arxiv.org/html/2410.06197v2>.

Read the main theorems and the regularity/stabilizer assumptions. The result supplies an integral splitting for free Hamiltonian reductions; with finite stabilizers their orders must be inverted. The proof is not a naive integral Atiyah–Bott Euler non-zero-divisor argument. No direct application is presently justified: a generic fixed-representation quiver Grassmannian has not been identified with the required free Hamiltonian quotient, and a torsion-free zero locus alone does not imply primitive Euler multiplication in the ambient space.

### 6.3 Zonotopal algebras, orbit harmonics, and symmetric-quiver DT

Reineke–Rhoades–Tewari, arXiv:2207.11861, primary author PDF <https://www.math.toronto.edu/vvtewari/draft_dt.pdf>.

Read the introduction, orbit-harmonic comparison, and sign-isotypic discussion in Section 5.1. The constructions give a useful graph/Weyl-group interface but work over `Q`. A rational isomorphism with a permutation representation does not provide an integral permutation lattice or primitive Euler image. Evaluation of integral polynomials at integral points is not automatically surjective; even the points `0,2` illustrate the possible index. This source is not used as an integral saturation theorem.

### 6.4 Semi-invariants and good filtrations

Derksen–Weyman, *The Combinatorics of Quiver Representations*, AIF 61 (2011), primary author PDF <https://sites.lsa.umich.edu/hderksen/wp-content/uploads/sites/614/2018/05/A.I.a.36.pdf>.

Useful interface: semi-invariant dimensions, Schur sequences, zero-dimensional Schubert/quiver-Grassmannian counts, and multiplicity-one behavior. These dimensions alone do not control Smith forms of Gram matrices of dimensions. A good-filtration statement or characteristic-independent character formula must be connected to an actual perfect integral pairing before it can prove the target rank equality. That connection is absent here.

### 6.5 Strong bounded audit of the 2026 Hexagon paper

*Quantum Laurent positivity for mutation-acyclic cluster algebras*, Hexagon 2609.00124v4, primary <https://hexagonmath.org/pdf/2609.00124v4>.

Read the introduction and scope, Lemma 3.1, the complete proof of Lemma 3.2, and Proposition 3.3. The paper's claimed positivity application concerns characteristic-zero valued-quiver rigid-module cluster characters; it does not state the present all-characteristic nonrigid basis-to-theta theorem.

Lemma 3.2 is a general virtual-character support mechanism. For a root-lattice-injective charge, a virtual KLR character supported only on semicuspidal words is a linear combination of semicuspidal simple characters. Its proof uses ordered semicuspidal factors and a maximal Harder–Narasimhan polygon: restriction to blocks forces surviving polygons to dominate the chosen one, maximality makes them equal, and injectivity of charge recovers the factors. The remaining character-independence step then excludes cancellation.

The argument is sound conditional on the cited semicuspidal factorization/unmixing results and their stated coefficient-field scope. Rigidity is not needed for the abstract support lemma, but it is used by the surrounding strict-prefix and real-root arguments. Consequently it is a potentially useful interface, not a ready-made proof here. One must first construct the virtual KLR character corresponding to our finite Euler/root window and check the charge identification; none of these identifications is supplied just by renaming a cluster root as a KLR root.

Audit status: useful bounded lemma; surrounding rigidity-dependent conclusion not imported; coefficient-field extension not independently established in this branch. No conclusion from Li–Pan/Lifang is used.

### 6.6 Old positive Dyck/tree models

Read `history/round2/Higher_Rank_Greedy_Theta/proofs/BOUNDED_FLAGGED_DYCK_TREES.md` and `.../POSITIVE_ORBIT_SCHUR_RECURSION.md` in full.

The first is a bounded literal object grammar, with fixed flags and an unresolved overlap/associator bijection. The second constructs positive Schur/tableau recursions using local fan representations over `Q`. Neither gives an integral injection into the present Euler-image lattice. Counting theta objects does not by itself produce unit Smith pivots. In particular the rational local intertwiner bases cannot be silently treated as primitive integral lattices.

## 7. Routes deliberately not promoted to theorems

1. **Unimodular graph implies arbitrary finite-window saturation:** false. The already computed three-arrow `b=(2,3)` windows have nonunit factors before `N=6`.
2. **Taking Weyl invariants preserves saturation:** false in general. Use the explicit integral flag extension/retraction and prove compatibility with the relevant image.
3. **Rational orbit-harmonic or spline duality proves Smith-unit factors:** invalid. The integral lattice is essential.
4. **Torsion-free cohomology of a smooth zero locus proves primitive ambient Euler image:** invalid. A degree-`d` hypersurface can have Euler multiplication `d h` with a nonprimitive image.
5. **A count of positive theta objects is an integral minor:** invalid without an actual integral embedding or pairing.
6. **Entrywise chamber quasipolynomiality implies rank stability for growing matrices:** invalid. Matrix dimensions and truncation boundaries also change. Hilbert–Kunz/Lefschetz-type behavior is a warning against this inference.
7. **Frobenius subsequences `N=p^k`:** potentially weaker than uniform saturation. Integer-valued polynomial coefficients have bounded prime-power periods, and Grassmannian generating functions simplify under Frobenius. No conclusion follows without controlling the growing row/column window and the flag/Schur boundary relations.

## 8. Present mathematical outcome

The strict new deductions in this branch are the exact flag-bundle Smith reduction, the integral bounded-translation lemma, and the local-chamber finite-window saturation theorem from the audited integral DM inputs. The structural margin and unit-rank lower bound survived 320 exact tests, including 104 genuinely nonprimitive controls. The general geometric modular-basis-to-theta theorem is still open at the multi-chamber/Schur-window compatibility step.

No priority claim is made for the standard flag-bundle identity, Newton interpolation, or the established integral DM results. Their role here is to expose a precise integral interface for the unresolved minimality theorem. That main theorem, if proved by a compatible window construction, would require its own novelty review.

The next substantive task is to construct that compatibility, preferably using the DCPV rational-subspace filtration and integral cardinal functions. Repeating more rank-two examples or repackaging the existing conditional detector would not solve it.
