# Relative Hall / classical theta bridge: negative chambers and signed framing

Agent: relative_hall_theta_bridge. Research block: 2026-11-14, approximately 03:52–04:10 UTC. Scope: classical cluster algebras, principal coefficients, skew-symmetric quivers with potential. No Li Fang or Li–Pan theorem is used.

## 1. Results and exact status

The finite-support problem and the exact generic-Newton problem must be separated.

**Proved from older Hall/scattering inputs.** Suppose a completed Jacobian algebra \(J\) has finite-dimensional injectives \(I_i\) for the vertices needed below, and its ordinary Euler-integrated stability diagram is equivalent to the classical cluster diagram. If \(g=b-a\), \(a,b\geq0\), then in the initial positive chart
\[
 \vartheta_{-a}=x^{-a}F_{I(a)}(\widehat y),\qquad
 0\leq F_g^\vartheta\leq F_{I(a)}
 \quad\text{coefficientwise},
 \qquad I(a)=\bigoplus_iI_i^{a_i}.
 \tag{1}
\]
Consequently
\[
 \operatorname{supp}F_g^\vartheta
 \subseteq\operatorname{supp}F_{I(a)}
 \subseteq\prod_i[0,\dim I(a)_i]\cap\mathbb Z^n .
 \tag{2}
\]
This gives an actual finite stopping carrier for every such \(g\). Taking \(a=g^-\) is sufficient. A reddening sequence and a reachable negative chamber are not assumptions. In particular, the old dossier's general signed-framing problem is not needed for this coarse bound under its standing diagram-equality assumption.

**Priority/status.** The negative-unit identity and its equivalence to diagram equality are already explicit in Fei 2609.10090v1, Corollary 2.5. The proof here derives the required identity directly by dualizing the elementary kernel/image Hall factorization in Bridgeland's 2017 framework; no 2026 syzygy theorem is imported. The positive-product implication is standard theta positivity. These are useful interfaces and repaired proof dependencies, not claimed as new theorems.

**Closed geometric proof obligation.** For any presentation \(d:I(a)\to I(b)\) with disjoint supports of \(a,b\), the one-dimensional signed framing with the presentation encoded in the potential has, in the nilpotent cocyclic chamber, reduced moduli equal to \(\operatorname{Gr}_e(\ker d)_{\rm red}\). The key argument forcing every outgoing framing map to zero is given below. Williams 1411.3692v3, Proposition 2.19, already contains this construction for a specific family; Fedotov 1010.4761, Theorem 3, supplies the general injective/coframed-Grassmannian correspondence. Thus this closes a local proof obligation but is not advertised as an original framing construction.

**Still unproved.** The identification of theta expansion coefficients with relative framed invariants over the *generic presentation parameter* \(S_g=\operatorname{Hom}(I(a),I(b))\), and the shifted support containment needed for exact generic/theta Newton equality. Stability-diagram positivity for an arbitrary potential is not assumed. In particular, finite negative stability-theta functions alone do not justify the positive-product argument for all stability theta functions when the stability and cluster diagrams differ.

## 2. Conventions and full-formal negative chamber lemma

Let \(B\) be skew-symmetric, with columns giving mutable exponent increments. Put
\[
 P=\binom B{I},\qquad R=\binom I0,\qquad R^TP=B,
 \qquad \widehat y^e=x^{Be}t^e.
\]
For a skew-symmetrizable extension replace \(R\) by \(\binom D0\) and use \(DB\) skew; the Hall realization in this report is stated only for quivers.

Choose an endpoint \(q\) whose mutable part \(Q\) is strictly negative, and an initial exponent \(m=(g,f)\) with \(g\leq0\). Every bend has a nonzero positive charge \(a_j\in\mathbb N^n\); if its time is \(-u_j<0\), then direct integration of piecewise constant velocities gives
\[
 \gamma(-u_j)
   =q+u_jm+P\sum_k\min(u_j,u_k)a_k .
 \tag{3}
\]
At that bend \(\langle Ra_j,\gamma(-u_j)\rangle=0\). Summing these equations yields
\[
 0=\sum_j a_j^T(Q+u_jg)
   +\sum_{j,k}\min(u_j,u_k)a_j^TBa_k
  =\sum_j a_j^T(Q+u_jg).
 \tag{4}
\]
The second sum vanishes by the symmetry of \(\min(u_j,u_k)\) and skew-symmetry of \(B\). Every term in the final sum is strictly negative if any bend occurs. Therefore there are no bends:
\[
 \vartheta_{g,C^-}=x^gt^f,\qquad g\leq0.
 \tag{5}
\]

This is a degree-by-degree argument for all finite broken lines, so it proves an identity of full formal expansions, not an identity truncated at some order. It uses positivity of wall *degrees*, not positivity of wall coefficients. It does not require \(C^-\) to be a cluster chamber. Frozen components of the endpoint and exponent do not affect the inequality. The same argument with reversed inequalities proves the positive-chamber monomial statement.

This is the explicit nonreachability check behind the negative-chamber invocation of the GHKK chamber argument. In particular, no Laurent finiteness is assumed in (3)–(5).

## 3. Direct Hall proof of the injective chamber formula

Use the Hall multiplication convention of Bridgeland, Lemma 9.3: the first factor parametrizes the subobject of a short exact sequence. Let
\[
 H=[\mathfrak M\to\mathfrak M]
\]
be the class of all finite-dimensional nilpotent \(J\)-modules in the completed Hall group.

For finite-dimensional \(I(a)\), let
\[
 H^a=[(M,\phi:M\to I(a))\to\mathfrak M],
 \qquad
 G_{I(a)}=\left[\coprod_e\operatorname{Gr}_e(I(a))\to\mathfrak M\right].
\]
The universal \(J\)-linear adjunction gives
\[
 \operatorname{Hom}_J(M,I(a))
   \cong\bigoplus_i(M_i^*)^{a_i}.
\]
Hence over dimension \(d\), \(H^a_d=t^{2a\cdot d}H_d\) in the motivic notation used by Bridgeland. This is a vector bundle identity on the module stack, not a dimension estimate depending on the isomorphism class.

Factor every \(\phi\) as its kernel followed by its image. The image is canonically a submodule of the fixed injective, so the exact sequence
\[
 0\longrightarrow\ker\phi\longrightarrow M
   \longrightarrow\operatorname{im}\phi\longrightarrow0
\]
gives the completed Hall identity
\[
 H^a=H*G_{I(a)}.
 \tag{6}
\]
As in Bridgeland's corresponding framed identity, stratification by ranks makes the comparison valid in the Hall stack-function relations; no claim that kernel ranks form a vector bundle globally is needed.

Adjoin monomials \(z^m\) with
\[
 H_dz^m=t^{2m\cdot d}z^mH_d.
\]
Then
\[
 z^{-a}H=H^az^{-a}=HG_{I(a)}z^{-a},
 \qquad
 H^{-1}z^{-a}H=G_{I(a)}z^{-a}.
 \tag{7}
\]
The total stability path from the positive chamber to the negative chamber acts by conjugation by \(H\); the reverse acts by conjugation by \(H^{-1}\). This also fixes the sign against the rank-one factor \(x_i\mapsto x_i(1+\widehat y_i)\) for the positive-to-negative crossing.

Ordinary Euler integration of (7), using Bridgeland Theorem 11.1 and its extended-algebra compatibility, gives
\[
 p^{\rm st}_{-\to+}(x^{-a})
   =x^{-a}\sum_e\chi(\operatorname{Gr}_e I(a))\widehat y^e
   =x^{-a}F_{I(a)}(\widehat y).
 \tag{8}
\]
The integral is applied to the regular Grassmannian expression on the right and to the regular-group action on the left, not naively to the all-object stack \(H\). The completed nilpotent setting is the one treated explicitly by Chen–Mandel–Qin; their Lemma 2.3 records the dual projective/Quot version.

Combining (5), theta transport, and (8) proves
\[
 \vartheta^{\rm st}_{-a,C^+}=x^{-a}F_{I(a)}.
 \tag{9}
\]
If \(D_{\rm st}\simeq D_{\rm cl}\), this is the cluster identity in (1). Multiplicativity
\(F_{I(a)}=\prod_iF_{I_i}^{a_i}\) also follows directly from the torus action on Grassmannians of a direct sum, or from the chamber transport being an algebra automorphism.

### What is, and is not, assumed

The old ordinary Hall integration framework must exist for the chosen potential; for polynomial potentials this is Bridgeland's stated setting, and the cited completed-Jacobian nilpotent version is CMQ's setting. The proof is not a claim about arbitrary nonalgebraic critical theories.

Finite dimensionality of \(J\) ensures all its injectives are finite dimensional. Only the particular \(I_i\) with \(a_i>0\) are required for the bound at a fixed label. The equality \(D_{\rm st}=D_{\rm cl}\) is an independent hypothesis. CMQ's once-punctured torus comparison shows it is not automatic from Jacobi finiteness.

## 4. Why the finite carrier follows without a circular argument

Classical cluster theta functions have nonnegative formal Laurent coefficients and nonnegative multiplication structure constants. For \(b\geq0\), \(\vartheta_b=x^b\). In
\[
 \vartheta_b\vartheta_{-a},
\]
the sum label \(g=b-a\) occurs with coefficient one at principal degree zero. Every other contribution to every Laurent coefficient is nonnegative. Therefore the formal coefficientwise inequality is
\[
 x^gF_g^\vartheta
   \leq \vartheta_b\vartheta_{-a}
   =x^{b-a}F_{I(a)}.
 \tag{10}
\]
All statements can first be read modulo any principal degree and then passed to the completion. The right-hand side is already a finite polynomial, so its zero coefficients force every tail coefficient of \(F_g^\vartheta\) to vanish. This is precisely where positivity is used.

Thus a coefficient engine need only compute within the explicit finite carrier (2). It does not first assume finite theta expansions, nor identify any generic cluster character with a theta function. The carrier can be sharpened from the rectangular dimension bound to the actual support or Newton polytope of \(I(a)\), but this still need not equal the generic kernel carrier.

If the hypotheses persist under mutation, the same argument is available in each such seed. The statement of (1)–(2) itself concerns the full formal expansion in the specified seed.

## 5. Signed framing: proof of the previously provisional chamber identification

Work over \(\mathbb C\). Let \(g=b-a\) with \(a,b\geq0\) and disjoint supports, and fix
\(d:I(a)\to I(b)\). For each matrix entry choose a representative which is a linear combination of old paths \(p:j\to i\), corresponding to a map \(I_i\to I_j\).

Add a framing vertex \(\infty\) with dimension one, arrows
\[
 B_{i,r}:i\to\infty\quad(1\leq r\leq a_i),
 \qquad A_{j,s}:\infty\to j\quad(1\leq s\leq b_j),
\]
and the potential obtained by adding the cyclic compositions
\[
 \widetilde W_d
  =W+\sum_{j,s,i,r} B_{i,r}\circ p_{js,ir}\circ A_{j,s}.
 \tag{11}
\]
This notation specifies actual composition \(\infty\to j\to i\to\infty\), independently of path-algebra left/right writing conventions. Disjoint support excludes length-two framing cycles.

For an old dimension vector \(e\), choose a King weight whose old components are strictly positive and whose framing component is \(-\theta\cdot e\), using the convention that a proper subrepresentation has negative weight. A subrepresentation with framing dimension one automatically has negative weight if proper. A subrepresentation with framing dimension zero has positive weight unless it is zero. Thus stability is exactly:
\[
 \text{there is no nonzero old submodule annihilated by all }B_{i,r}.
 \tag{12}
\]

Now impose nilpotency, as appropriate for the completed path algebra. Every composition
\[
 B_{i,r}\,u\,A_{j,s}:\mathbb C\to\mathbb C
\]
along an old path \(u:j\to i\) is an oriented cycle at the one-dimensional framing vertex. It is a nilpotent scalar and therefore zero. Let \(N\) be the old subrepresentation generated by all images of the outgoing maps \(A_{j,s}\). All incoming maps annihilate \(N\). By (12), \(N=0\). Hence
\[
 A_{j,s}=0\quad\text{for all }j,s.
 \tag{13}
\]

This argument precedes use of the old Jacobian relations: \(N\) is first a subrepresentation of the old quiver, which suffices to contradict framed stability. After (13), the old-arrow derivatives of (11) reduce to the old relations \(\partial W=0\). Derivatives with respect to incoming \(B\)'s vanish automatically; derivatives with respect to outgoing \(A\)'s become
\[
 \sum_{i,r}B_{i,r}\circ p_{js,ir}=0.
 \tag{14}
\]
The coframing \(B\) corresponds functorially to a map
\(\iota_B:M\to I(a)\). Its kernel is the largest old submodule annihilated by all coframing maps, so stability is equivalent to injectivity of \(\iota_B\). By adjunction the equations (14) say exactly
\(d\iota_B=0\). Thus the image is a submodule of \(\ker d\).

Conversely, any \(L\subseteq\ker d\) produces a nilpotent stable framed representation by taking \(A=0\) and the coframing induced by \(L\hookrightarrow I(a)\). These maps are algebraic, inverse after taking the free change-of-basis quotient, and preserve the parameter \(d\). Consequently
\[
 \mathcal M^{\rm nilp,cocyc}_{(e,1)}(\widetilde Q,\widetilde W_d)_{\rm red}
   \cong \operatorname{Gr}_e(\ker d)_{\rm red}.
 \tag{15}
\]
The same identification holds relatively on reduced parameter spaces where the constructions are formed. In particular it respects restriction to a dense open in \(S_g\).

**Scheme qualification.** Nilpotent scalars vanish on reduced bases. They need not vanish over an arbitrary nonreduced base. The argument therefore asserts an isomorphism of reduced moduli varieties and an equality of ordinary Euler characteristics; it does not identify critical structures, vanishing-cycle sheaves, or derived moduli.

**Priority check.** Williams Proposition 2.19 uses an incoming and an outgoing framing arrow, a presentation-dependent potential, and the resulting kernel of a map of injectives. Its example has Grassmannians that are points or empty. The proof above supplies the general algebraic mechanism for the dossier, but the underlying framing idea is old. Fedotov's Theorem 3 proves the basic general coframed/injective correspondence.

## 6. Genuine remaining bridge and the useful new interface

The signed-framing chamber series is now rigorously
\[
 x^gF_{\ker d}(\widehat y).
\]
This is not a theta identification. A flat section of a scattering diagram is not selected uniquely by its leading label: different presentations with the same index can give different Grassmannian series.

There is a precise degree-one representation-theoretic interface. With the chosen sign convention the enlarged skew matrix is
\[
 \widetilde B=\begin{pmatrix}B&g\\-g^T&0\end{pmatrix}.
\]
After quotienting Lie degrees with framing component at least two,
\[
 \mathfrak l^{\leq1}=\mathfrak l_0\ltimes\mathfrak l_1,\qquad
 [\mathfrak l_1,\mathfrak l_1]=0.
\]
For old charge \(d\) and framed charge \((e,1)\), the pairing is
\[
 (d,0)^T\widetilde B(e,1)=d^T(Be+g).
 \tag{16}
\]
This matches the original scattering action on \(x^{g+Be}t^e\). The grading and bracket calculation are proved directly; a full theorem identifying incoming framed atoms with theta coefficients still needs a factorization/coefficient-extraction argument.

The required relative theorem must retain dominance over \(S_g\), or equivalent generic restriction, throughout those correspondences. Numerical wall crossing after integrating away \(S_g\) does not do that. A promising formulation uses a Hall module of the family \((\widetilde Q,\widetilde W_d)_{d\in S_g}\), not merely the relative BPS sheaf over the coarse semisimple moduli of one fixed Jacobian algebra.

### New 2026 source interface, audited only in the stated scope

Davison's ICM survey, arXiv:2601.08004, published chapter DOI 10.1137/25M1810234, §4.4 explicitly allows both incoming and outgoing framing arrows and a general extending potential. It describes a CoHA module via proper correspondences of stable framed quotients. This is useful evidence that the signed framing belongs in an established Hall-module framework. It does **not** identify its vectors with classical theta functions.

Its §2.4 relative integrality theorem is relative to the coarse moduli of semisimple modules. For a fixed nilpotent completed Jacobian algebra, semisimplification records the dimension vector and loses presentation data. Therefore that use of “relative” cannot simply be substituted for relativity over \(S_g\). Moreover its vanishing-cycle coefficients cannot be silently replaced by the unweighted Euler coefficients used here. These are concrete mismatches to resolve, not reasons to discard the source.

### Central defects: coordinated with finite_laurent_global_certificate

If the discrepancy from the cluster diagram consists of full central walls with charge \(k\in\mathbb N^n\cap\ker B\), then for every broken-line monomial \(g+Be\),
\[
 k\cdot(g+Be)=k\cdot g,\qquad
 k\cdot\gamma(t)=k\cdot Q-t\,k\cdot g.
\]
For \(Q\in C^+\), a central hyperplane is crossed exactly once if \(k\cdot g<0\), and not crossed if \(k\cdot g\geq0\). A central bend changes only the frozen exponent. Thus its total contribution factors uniformly, with exponent \([-k\cdot g]_+\), calibrated so a negative unit crosses with the positive factor. The sibling branch is proving the general central-factor statement and checking its Mou/CMQ hypotheses.

This observation does not prove that every stability/cluster discrepancy is central. Nor does an arbitrary signed central factor provide positivity. The product proof in §4 remains a cluster-positivity proof, not a general-potential DT-positivity claim.

## 7. Literature audit and route log

| Source / version | Exact part inspected | Finding and permitted use |
|---|---|---|
| Bridgeland, arXiv:1603.00416; Algebraic Geometry 4 (2017) | Intro positive framing; §§8–11; Lemmas 9.1, 9.3; Theorem 10.1; Theorem 11.1 | Theorem 10.1 permits nonnegative boundary framings, despite the introductory strictly positive convention. Its Hall convention and ordinary Euler integration support the dual proof above. General signed theta moduli are explicitly not supplied. |
| Chen–Mandel–Qin, arXiv:2306.04104v2, 2024-11-02 | Intro; Theorem 2.2; Lemma 2.3; Theorem 1.4 | Completed nilpotent projective chamber formula; total chamber product determines consistent diagram; genus at least two punctured-closed equality and torus exception. Useful older nonreachability input. |
| Fei, arXiv:2609.10090v1, 2026-09-09 | Full Proposition 2.4/Corollary 2.5 and their proofs, plus relevant conventions | Explicit full formal identities and no reachability premise. Equality with cluster theta is equivalent to stability=cluster, not unconditional. Reverse formula in the source uses its syzygy chain; this report independently bypasses that dependency. No correctness claim about every theorem of the paper. |
| Williams, arXiv:1411.3692v3, 2015-09-11 | §2.4, Proposition 2.19 and proof | Existing incoming/outgoing presentation-potential kernel construction. Prevents an original-construction claim. Its special Grassmannian geometry is not generalized by citation. |
| Fedotov, arXiv:1010.4761v2, 2010-12-20 | Intro and Theorem 3 with proof | General finite-algebra stable coframing moduli equals submodule Grassmannian of the injective. Good foundational interface. |
| Cheung, arXiv:1906.12299 | Intro and main scope | Cluster-complex/preprojective-preinjective restrictions cannot be removed to cover arbitrary signed \(g\). Not used as a general theorem. |
| Cheung–Mandel, arXiv:1902.05393 | Original abstract / old dossier's source map | Hall-valued broken-line consistency has a known obstruction. No naive Hall-theta lifting used. Full counterexample proof not reread in this block. |
| Davison, arXiv:2601.08004; ICM chapter | Publisher text and arXiv metadata; §§2.4, 3.3, 4.4 | Framed CoHA module with both arrow directions is a useful existing interface. Relative integrality is over a different base; no generic-presentation conclusion imported. |
| Fei, arXiv:2510.01615v4, 2026-11-03 | Primary search/abstract-level lead only | Modified orthogonal projection reportedly preserves generic presentations. Not used; needs full-text theorem and hypotheses audit before a next wave. |
| Fei, arXiv:2610.09868 | Primary search/abstract-level lead only | Ramified/valued QP direction not needed for the present classical skew-symmetric argument. No theorem imported. |
| Hexagon 2611.00013v1 and 2610.00201 | Search discovery only | Existing local-style finite signed-generator arguments reinforce that §4 is not a novelty claim. These texts were not used as mathematical premises. |

### Routes attempted and outcome

1. **Generic kernel finite support directly bounds theta:** not justified by itself. Replaced by the proved injective chamber plus positive-product mechanism under diagram equality.
2. **Negative chamber treated as a seed:** rejected. Equation (4) supplies a direct geometric proof independent of reachability.
3. **Import Fei's reverse AR substitution:** unnecessary dependency. Replaced by the older dual kernel/image Hall identity (6)–(8).
4. **Signed framing nilpotency only asserted:** resolved by taking the submodule generated by outgoing framing images and using one-dimensional nilpotent cycle scalars.
5. **Claim signed framing is new:** rejected by Williams Proposition 2.19 and Fedotov's general correspondence.
6. **Relative BPS integrality automatically retains generic presentation support:** rejected because its base is semisimple coarse moduli, not \(S_g\), and its sheaf weights differ.
7. **All stability theta are positive for arbitrary potential:** not assumed; no theorem supplied. Thus no unconditional all-\(g\) stability finite-support claim.
8. **Central defect deformation:** coordinated with sibling; potentially allows additional label-specific formulas, but only under verified centrality and positivity hypotheses.

## 8. Computation record

The Wolfram computation plugin was used for exact symbolic checks of the two dimension-free identities behind (4) and (16). A symbolic rank-five skew matrix, six arbitrary bend charges and arbitrary symmetric pair weights gave cancellation exactly zero; the block skew-matrix bracket residual was exactly zero. These calculations check signs and assembly. The proofs above are valid in arbitrary rank and number of bends and do not rest on finite testing.

The Wolfram semantic-context call returned an internal error. No result from that failed call was used. The language evaluator succeeded. Receipt: agents/relative_hall_theta_wolfram_receipt.json.

## 9. Primary URLs and precise citation map

- Bridgeland: https://arxiv.org/pdf/1603.00416 ; published https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf . Relevant: Lemma 9.3, Theorem 10.1, Theorem 11.1.
- Chen–Mandel–Qin: https://arxiv.org/html/2306.04104v2 . Relevant: Theorem 2.2, Lemma 2.3, Theorem 1.4.
- Fei: https://arxiv.org/pdf/2609.10090 . Verified PDF says v1, 9 September 2026. Relevant: Proposition 2.4, Corollary 2.5, equations (2.15)–(2.18).
- Williams: https://arxiv.org/pdf/1411.3692 . Verified PDF says v3, 11 September 2015. Relevant: §2.4 and Proposition 2.19.
- Fedotov: https://arxiv.org/pdf/1010.4761 . Relevant: Theorem 3, pp. 9–10 of PDF text.
- Cheung: https://arxiv.org/pdf/1906.12299 .
- Davison: https://arxiv.org/pdf/2601.08004 ; publisher https://epubs.siam.org/doi/full/10.1137/25M1810234 . Relevant: §§2.4 and 4.4, with the base and coefficient caveats above.

Web-tool refs usable after root reopens the URL: Fei turn161view2; Bridgeland turn162view3 and turn166view0; CMQ turn166view2; Williams turn166view1; Fedotov turn162view4; Davison turn175view3 and turn176view0.


## 10. Final handoff addendum: positive central defects do not need arbitrary stability positivity

The sibling branch directly checked Mandel–Qin, arXiv:2301.11101v3, Appendix B.3, equations (155)–(157), and Theorem B.4, together with CMQ Lemma 5.6. Their known central-defect mechanism must receive priority credit. The following abstract formulation records precisely the all-label consequence, not a novelty claim.

Suppose a cylindrical principal scattering diagram \(D_1\) is obtained from \(D_0\) by adjoining full central walls
\[
 (k^\perp,C_k(t^k)),\qquad
 k\in\mathbb N^n\setminus\{0\},\quad Bk=0,
\]
where \(C_k\) is a formal unit. Choose the sign so crossing from the negative side to the positive side acts on \(x^m\) by multiplication by \(C_k^{-k\cdot m}\). For an initial mutable label \(g\) and endpoint in \(C^+\),
\[
 \vartheta^{D_1}_{g}
   =\left(\prod_k C_k^{[-k\cdot g]_+}\right)
      \vartheta^{D_0}_{g}.
 \tag{17}
\]
Indeed \(k\cdot(g+Be)=k\cdot g\) on every segment. Thus \(k\cdot\gamma(t)=k\cdot Q-t\,k\cdot g\), so the relevant central hyperplane is crossed once exactly when \(k\cdot g<0\). Central monomials have mutable increment \(Bk=0\); adding their bends leaves the mutable path and all noncentral wall encounters unchanged. The frozen path is reconstructed uniquely from the fixed endpoint and the chosen monomial terms. Central charge pairings with all old charges vanish, so the inserted factors commute with every noncentral transition. Summing the possible monomial choices produces (17). This argument works in every finite principal truncation and hence in the completion.

The hypotheses “full central walls” and “cylindrical principal diagram” are part of this lemma. One cannot apply it to an arbitrary partial wall or assume that every stability/cluster discrepancy has this form.

Now let \(D_1=D_{\rm st}\), \(D_0=D_{\rm cl}\), assume finite injectives, and assume each \(C_k\) has nonnegative coefficients and constant term one. By the proved negative-unit Hall formula and (17),
\[
 F_{I_i}
   =\left(\prod_k C_k^{k_i}\right)F^\vartheta_{-e_i},
 \qquad
 0\leq F^\vartheta_{-e_i}\leq F_{I_i}.
 \tag{18}
\]
Therefore every needed negative cluster unit is finite, and the cluster-positive product argument gives
\[
 0\leq F_g^\vartheta\leq F_{I(g^-)}
 \tag{19}
\]
without diagram equality and without any general theorem asserting stability-theta positivity.

If there are finitely many central factors, each nontrivial factor is itself forced to be polynomial: choose \(i\) with \(k_i>0\) and use (18), positivity, and the constant terms of all factors. Hence (17) also proves that every stability theta is finite in this setting. The extension to an infinite locally finite collection must first establish finite active support from the unit identities; no infinite-product finiteness assertion is needed here.

This is the appropriate conditional answer to root's concern about arbitrary stability positivity. The remaining general-potential signed-framing theta-extraction problem is untouched.


