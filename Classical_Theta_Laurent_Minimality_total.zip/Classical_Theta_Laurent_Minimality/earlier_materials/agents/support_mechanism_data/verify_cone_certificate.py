"""Exact rational verification of the finite periodic initial-wall certificate.

The symbolic theorem is in ../support_mechanism.md.  This verifier constructs
actual rational certificate data and checks every flight-time and exit test.
It does not infer infinite support from a finite coefficient sample.
"""
from fractions import Fraction as F
from math import gcd
from functools import reduce
from pathlib import Path
import json

def add(x,y):return tuple(a+b for a,b in zip(x,y))
def scale(t,x):return tuple(t*a for a in x)
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def mv(A,x):return tuple(dot(r,x) for r in A)

def backward(v,m,i):
 t=-v[i]/m[i]
 return add(v,scale(t,m)),t

def construct(a,b,c):
 K=a*a+b*b+c*c-a*b*c
 if K>0:raise ValueError('outside theorem')
 d=reduce(gcd,(a,b,c));g=tuple(F(x,d) for x in (-a,a*b-c,-b))
 increments=(a//d,c//d,b//d)
 B=((0,b,-c),(-b,0,a),(c,-a,0))
 m=[g]
 for i,r in enumerate(increments):m.append(add(m[-1],tuple(F(r*row[i]) for row in B)))
 assert m[-1]==g and all(-m[i][i]==increments[i] for i in range(3))
 v0=(F(0),F(1),F(0));v1=(F(K-c*c,b),F(-K)+F(a*c,b),F(0))
 A=((F(1),F(-K)),(F(1),F(1-K)))
 assert A[0][0]*A[1][1]-A[0][1]*A[1][0]==1
 generator_times=[]
 for j,v in enumerate((v0,v1)):
  current=v;times=[]
  for state,i in ((m[2],1),(m[1],0),(m[0],2)):
   current,t=backward(current,state,i);assert t>0;times.append(t)
  target=add(scale(A[0][j],v0),scale(A[1][j],v1))
  assert current==target
  generator_times.append(times)
 eps=F(a,2*b*c);u=add(v0,scale(eps,v1))
 # For primitive g the exit-time interval is multiplied by d.
 lo=-u[0]/(-g[0]);hi=u[1]/g[1];s=(lo+hi)/2
 assert 0<lo<s<hi
 Q=add(u,scale(-s,g));assert all(x>0 for x in Q)
 # Verify multiple periods as a consistency check of the stored matrix data.
 current=u
 for _ in range(8):
  for state,i in ((m[2],1),(m[1],0),(m[0],2)):
   current,t=backward(current,state,i);assert t>0
 return {'abc':[a,b,c],'kappa':K,'g':g,'Delta':increments,'V':[v0,v1],
         'A':A,'generator_backward_times':generator_times,'epsilon':eps,
         'exit_state':u,'exit_time':s,'endpoint':Q}

def encode(x):
 if isinstance(x,F):return str(x)
 raise TypeError(type(x).__name__)

if __name__=='__main__':
 cases=[(3,3,3),(3,3,4),(4,4,4),(3,4,5),(3,5,5),(4,4,8)]
 rows=[construct(*abc) for abc in cases]
 result={'status':'PASS','certificate_count':len(rows),'certificates':rows}
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,default=encode,indent=2))
 print(json.dumps({'status':'PASS','certificate_count':len(rows),'kappas':[r['kappa'] for r in rows]}))
