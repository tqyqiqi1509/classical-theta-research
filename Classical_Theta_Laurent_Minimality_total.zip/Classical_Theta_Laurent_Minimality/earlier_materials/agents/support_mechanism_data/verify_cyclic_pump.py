from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'computation'))
from incoming_recursion import IncomingSchur

out=[]
for a,b,c,ns in [(3,3,3,[1,2]),(3,3,4,[1]),(4,4,4,[1]),(2,2,2,[1]),(2,3,3,[1])]:
 B=[[0,b,-c],[-b,0,a],[c,-a,0]]
 g=(-a,a*b-c,-b);k=(a,c,b)
 calc=IncomingSchur(B);row={'a':a,'b':b,'c':c,'B':B,'g':g,'kernel':k,'kappa':a*a+b*b+c*c-a*b*c,'coefficients':[]}
 for N in ns:
  p=tuple(N*x for x in k);start=time.time();co=calc.theta_prefix(g,p).get(p,0)
  row['coefficients'].append({'N':N,'p':p,'coefficient':co,'seconds':time.time()-start})
  print(a,b,c,N,co,'seconds',row['coefficients'][-1]['seconds'],flush=True)
 out.append(row)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
