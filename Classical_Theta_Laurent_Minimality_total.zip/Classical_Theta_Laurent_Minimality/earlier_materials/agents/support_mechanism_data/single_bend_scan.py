from fractions import Fraction
from itertools import product
import json,time
from pathlib import Path

def mut(M,k):
 r=len(M);n=len(M[0])
 return tuple(tuple(-M[i][j] if i==k or j==k else M[i][j]+max(M[i][k],0)*M[k][j]+M[i][k]*max(-M[k][j],0) for j in range(n)) for i in range(r))

def matmul(A,B):
 return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]

def inverse(A):
 n=len(A);M=[[Fraction(v) for v in row]+[Fraction(i==j) for j in range(n)] for i,row in enumerate(A)]
 for k in range(n):
  j=next(j for j in range(k,n) if M[j][k]);M[k],M[j]=M[j],M[k];v=M[k][k];M[k]=[a/v for a in M[k]]
  for i in range(n):
   if i!=k:
    v=M[i][k];M[i]=[a-v*b for a,b in zip(M[i],M[k])]
 return [row[n:] for row in M]

def check(B,g,E,k):
 n=len(B);C=E[n:];Ginv=[list(row) for row in zip(*C)]
 col=[C[i][k] for i in range(n)]
 assert all(v>=0 for v in col) or all(v<=0 for v in col)
 alpha=tuple(v if max(col)>0 else -v for v in col)
 ag=sum(a*b for a,b in zip(alpha,g))
 if ag>=0:return None
 m=[g[i]+sum(B[i][j]*alpha[j] for j in range(n)) for i in range(n)]
 P=[[Fraction(i==j)-Fraction(m[i]*alpha[j],ag) for j in range(n)] for i in range(n)]
 H=matmul(Ginv,P)
 assert all(v==0 for v in H[k])
 Q=[11,13,17] if n==3 else [11+2*i for i in range(n)]
 qs=[sum(v*w for v,w in zip(row,Q)) for row in H]
 if all(qs[i]>0 for i in range(n) if i!=k):
  return {'alpha':alpha,'wall':k,'capacity':-ag,'all_positive_endpoint':all(v>=0 for i,row in enumerate(H) if i!=k for v in row),'H':[[str(v) for v in row] for row in H]}

def scan(B,g,depth):
 n=len(B);E=tuple(tuple(r) for r in B)+tuple(tuple(int(i==j) for j in range(n)) for i in range(n))
 todo=[(E,())];found={}
 for d in range(depth+1):
  nxt=[]
  for E,word in todo:
   for k in range(n):
    r=check(B,g,E,k)
    if r and r['alpha'] not in found:found[r['alpha']]={**r,'word':word}
    if d<depth and (not word or word[-1]!=k):nxt.append((mut(E,k),word+(k,)))
  todo=nxt
 return list(found.values())

if __name__=='__main__':
 out=[]
 for a in (2,3,4):
  B=((0,a,-a),(-a,0,a),(a,-a,0));g=(0,-a,a)
  rs=scan(B,g,9)
  out.append({'B':B,'g':g,'depth':9,'certificates':rs})
  print(a,len(rs),[(r['alpha'],r['word'],r['all_positive_endpoint']) for r in sorted(rs,key=lambda r:sum(r['alpha']))[-10:]],flush=True)
 Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
