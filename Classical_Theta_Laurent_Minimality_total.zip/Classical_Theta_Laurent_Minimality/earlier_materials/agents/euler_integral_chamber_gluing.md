# Generic bounded-submodule Ext vanishing and integral Euler saturation

Branch opened 2026-11-14 04:25 UTC. The original assignment was the global
Dahmen–Micchelli/Schur-window gluing problem. The argument below bypasses that
gluing by proving a uniform representation-theoretic vanishing statement,
then applying the integral diagonal mechanism of Cerulli Irelli–Esposito–
Franzen–Reineke (CEFR). It concerns finite **acyclic** quivers and classical
specializations of the standard geometric modular KLR families. No statement
about arbitrary strong-positive bases, arbitrary KLR parameters, or cyclic
Jacobians is inferred.

Status: the complete geometric proof, including the sharper criterion in
Section 7.1, has now passed root's independent reconstruction and the fresh
`generic_ext_saturation_adversarial` agent's independent core audit. Its
separate report records the actual-basis/completed-label application. The old CTB generic-window theorem remains a prior-work
input. The underlying AR duality, incidence dimension formula, diagonal
decomposition and integral Poincare duality are standard; priority for the
particular bounded-window application still requires literature checking.

## 1. Notation and a finite, explicit criterion

Let Q be a finite acyclic quiver, topologically ordered. Put

    m_ij = number of arrows i -> j,
    E = I-M,       <a,b> = a^T E b,       q(a)=<a,a>.

Here M=(m_ij) is strictly upper triangular. The matrix

    C=(I-M)^(-1)=I+M+...+M^(n-1)

counts oriented paths. The dimension vector of the indecomposable injective
I_j has i-th coordinate C_ij. Fix a nonnegative bound b. Define

    c_b = C M^T b,
    K_b = max({0} union {-q(v): 0 < v <= c_b}).                     (1)

All inequalities on dimension vectors are componentwise. The maximum in (1)
is a finite integer computation depending only on Q,b. The coarser explicit
bound sum_(i<j) m_ij (c_b)_i (c_b)_j may replace K_b if enumeration is
undesirable.

For a nonnegative dimension vector r impose the following finite condition:

    for every 0 < s <= b,
        either <s,r> < q(s), or <s,r> > K_b.                        (2)

### Main representation-theoretic theorem

Under (2), there is a nonempty Zariski-open subset of Rep_Q(r) such that
every M in that subset satisfies

    Ext^1_Q(U,M)=0
    for every subrepresentation U subset M with dim U <= b.       (3)

Consequently Ext^1_Q(U,M/V)=0 for every such U and every subrepresentation
V subset M. The quotient dimension need not be bounded in this last
consequence.

The proof is uniform in U. It does not apply a theorem for a generic U to
all subobjects, and it does not assume that the large module M is rigid.

## 2. Two elementary generic-incidence facts

For a dimension vector s<=r, the universal incidence variety

    Z_s(r) = {(M,U): M in Rep_Q(r), U in product_i Gr(s_i,r_i),
                       M_a U_i subset U_j for every arrow a:i->j}

is a vector bundle over the product of Grassmannians. The conditions for
one arrow have codimension s_i(r_j-s_j). Hence

    dim Z_s(r) - dim Rep_Q(r) = <s,r-s> = <s,r>-q(s).              (4)

The projection to Rep_Q(r) is proper. If the right-hand side is negative,
its image is a proper closed subset. Thus a general M has no submodule of
dimension s whenever <s,r-s><0.

The same statement for quotients follows by writing a quotient of dimension
v as a submodule of dimension r-v. Thus a general M has no quotient of
dimension v whenever

    <r-v,v> = <r,v>-q(v) < 0.                                    (5)

For fixed r,b,c_b there are only finitely many relevant s and v. Intersect
the complements of all closed loci prohibited by (4) and (5). This gives
one nonempty open set on which both facts hold **for every object of every
relevant dimension**, not merely for a chosen U or V. Dimensions s or v
not bounded above by r are automatically impossible and may be omitted.

## 3. The bounded AR lemma

### Lemma 3.1: bound on Auslander–Reiten translates

For every U with dim U<=b,

    dim tau U <= c_b.                                             (6)

Use the canonical projective resolution

    0 -> direct_sum_(a:i->j) P_j tensor U_i
      -> direct_sum_i P_i tensor U_i -> U -> 0.

Applying D Hom_Q(-,kQ) embeds
tau U = D Ext^1_Q(U,kQ)
into direct_sum_(a:i->j) I_j tensor U_i. Its dimension is bounded by
C M^T b, exactly (6). Projective direct summands of U contribute zero to
tau U and cause no problem.

### Lemma 3.2: a submodule of tau U gives a submodule of U

Suppose U has no projective direct summands. Let 0!=L subset tau U. Then
there are a nonzero submodule S subset U and a projective module P such
that

    0 -> P -> tau^(-1)L -> S -> 0.                               (7)

In particular, for every dimension vector r>=0,

    <r,dim L> = -<dim S,r>-<dim P,r> <= -<dim S,r>.                (8)

**Proof of (7).** The module tau U has no injective direct summand. Neither
does L: an injective summand of L, embedded in tau U, would split there.
Write W=(tau U)/L=W_0 direct_sum I with W_0 having no injective summand and
I injective. On D^b(rep Q), let tau_D be the derived AR translation. Then

    tau_D^(-1)L = tau^(-1)L,
    tau_D^(-1)(tau U)=U,
    tau_D^(-1)W = tau^(-1)W_0 direct_sum P[1],

where P is the projective corresponding to I under the inverse Nakayama
functor. Apply tau_D^(-1) to the triangle L -> tau U -> W -> L[1]. Its
ordinary cohomology long exact sequence gives

    0 -> P -> tau^(-1)L -> U -> tau^(-1)W_0 -> 0.                 (9)

Let S be the middle image. It is nonzero: otherwise tau^(-1)L=P would be
projective, whereas the nonzero module tau^(-1)L has no projective direct
summands by the inverse AR correspondence. This proves (7).

Serre duality on the derived category gives

    <tau^(-1)L,r> = -<r,L>.

Together with (7), and <P_i,r>=r_i>=0 for an indecomposable projective,
this proves (8). This is an equality of Euler forms, not a claim that tau
is exact on arbitrary short exact sequences.

An elementary alternative applies Hom_Q(D(kQ),-) to
0 -> L -> tau U -> W -> 0. The needed projective kernel and the same
five-term sequence follow. The derived proof above keeps the injective
correction P visible and prevents a false assertion that tau^(-1)L is
literally a submodule of U.

## 4. Proof of the main Ext-vanishing theorem

Choose M in the common generic open set of Section 2. Let U subset M with
dim U<=b. Every nonzero submodule S subset U is a submodule of M. By (4),

    <dim S,r> >= q(dim S).

The first alternative of (2) is therefore impossible, so

    <dim S,r> > K_b                                               (10)

for every nonzero S subset U.

Discard the projective direct summands of U; the remaining summand is
still a submodule of M, and only it can contribute to Ext^1(U,M). Suppose
Ext^1(U,M)!=0. AR duality implies the existence of a nonzero actual map

    f:M -> tau U.

It is enough that stable Hom is a quotient of actual Hom: no equality of
the two is assumed. Let L=im f, v=dim L. Then L is a nonzero quotient of M,
and 0<v<=c_b by (6). Lemma 3.2 supplies a nonzero S subset U for which

    <r,v> <= -<dim S,r> < -K_b.

The definition of K_b gives -q(v)<=K_b, so

    <r-v,v> = <r,v>-q(v) < -K_b-q(v) <= 0.

This contradicts the generic quotient exclusion (5). Hence (3) holds.

Finally, the exact sequence 0 -> V -> M -> M/V -> 0 and heredity give a
surjection Ext^1(U,M) -> Ext^1(U,M/V), proving the consequence.

## 5. All bounded quiver Grassmannians have an integral diagonal decomposition

For each e<=b let X_e=product_i Gr(e_i,r_i), and let

    E_e = direct_sum_(a:i->j) Hom(S_i,Q_j).

The representation M defines a section of this globally generated bundle,
whose zero scheme is Y_e=Gr_e(M). We may further shrink the same nonempty
generic open set so that every nonempty Y_e is smooth of its expected
dimension

    delta_e=<e,r-e>.

This also follows from Ext^1(U,M/U)=0, but the generic-section description
records the actual top Chern class:

    [Y_e]=c_top(E_e)=F_e in H^*(X_e;Z).                           (11)

On Y_e x Y_e consider the standard quiver-Hom complex

    H=direct_sum_i Hom(p_2^*S_i,p_1^*Q_i)
      -> K=direct_sum_(a:i->j) Hom(p_2^*S_i,p_1^*Q_j).

At a pair (V,U) its cokernel is Ext^1(U,M/V), which vanishes by Section 4.
Its kernel is therefore a vector bundle of rank delta_e. The canonical
section U -> M -> M/V vanishes scheme-theoretically exactly on the
diagonal. Consequently

    [Delta_Y] = c_delta_e(ker(H->K))
              = [t^delta_e] c_t(H)c_t(K)^(-1).                   (12)

Every coefficient in (12) is an integral polynomial in tautological Chern
classes pulled back from the two factors. The inverse is integral because
its constant term is 1. Thus (12) is a finite integral sum of external
products of tautological classes.

This is precisely CEFR's Theorem 37 diagonal mechanism, whose original
rigidity hypothesis was used to make H->K surjective. Here (3) supplies
that surjectivity uniformly in the bounded family even when M is
nonrigid. No change is needed to their integral diagonal argument.

For completeness, applying the diagonal correspondence to any integral
cohomology class expresses it as an integral combination of the
tautological factors in (12). Odd classes vanish, and torsion classes
vanish because their integral pairings are zero. Hence

    H^odd(Y_e;Z)=0,  H^*(Y_e;Z) is free,
    i^*:H^*(X_e;Z) -> H^*(Y_e;Z) is surjective.                  (13)

The same integral diagonal formula gives property (S) and tautological
generation of the Chow ring by the Ellingsrud–Strømme theorem used in
CEFR. For the Euler saturation conclusion only (13) is needed.

## 6. Primitive Euler images in every degree and every characteristic

Let i:Y_e -> X_e. Integral Poincare duality on the two smooth projective
varieties identifies i_* with the transpose of i^*. Since (13) is an
integral surjection between free abelian groups, its transpose is a split
injection with saturated image. The projection formula and (11) give

    multiplication by F_e = i_* i^*.

Therefore

    Im(m_F_e)=i_*H^*(Y_e;Z)

is saturated in H^*(X_e;Z), degree by degree. Every nonzero Smith invariant
of the integral Euler multiplication matrix is 1. An empty Y_e gives the
zero map and satisfies the same conclusion.

This closes the integral interface left open by the graphic-kernel/DM
approach under the explicit finite criterion (2). It does not infer
primitivity merely from torsion-free cohomology: the crucial extra input
is the actual integral surjectivity in (13).

## 7. Generic rays, finite offsets, and effective thresholds

Let r(N)=N r_0+r_1 be nonnegative for all sufficiently large N. Assume

    <s,r_0> != 0 for all 0<s<=b.                                 (14)

The vector r_0 need not have every coordinate positive. For each s define
ell_s=<s,r_0> and c_s=<s,r_1>. If ell_s>0, require

    N ell_s+c_s > K_b.

If ell_s<0, require

    N ell_s+c_s < q(s).

Each requirement is an explicit strict linear inequality. Taking the
maximum of their integer thresholds, and the threshold at which r(N)>=0,
gives a computable N_0 for which (2) holds for every N>=N_0. A finite
collection of offsets r_1 is handled by another finite maximum. If some
e_i>r_i(N), the corresponding coefficient/Grassmannian is simply absent;
this does not require a positivity assumption on r_0.

In the acyclic cluster convention B_ij=-m_ij for i<j, labels with no
positive initial factor satisfy

    g_i=-r_i+sum_(j>i)m_ij r_j,       <s,r>=-g.s.

Thus a direction nu with nu.s!=0 for all 0<s<=b gives (14). More generally
the completed labels are g=u+Vr, u_i r_i=0. On the support of any occurring
root e, u.e=0, so the same equality holds for every s<=e.

For a streamlined application to the old product detector, one may choose
nu additionally off the finite linear walls of the completed-label
recursion. Then the growing support J is fixed for all finitely many
offsets: r_i(N) grows linearly for i in J and is eventually zero outside J.
Roots using a vertex outside J have zero coefficients in both the modular
and characteristic-zero Euler formulas. Apply Sections 1–6 to Q_J for the
remaining roots. These additional genericity conditions are a finite union
of proper rational hyperplanes and can be avoided in the required open
scattering cone.

For a fixed finite root box, the standard geometric p-KLR basis therefore
agrees with its characteristic-zero specialization in that box eventually
along the chosen generic ray, simultaneously for every prime p. Combining
this with the **old** characteristic-zero CTB/theta generic-window theorem
gives the modular/theta generic-window equality. Its conversion to a
positive transition matrix further uses the old finite multiplication
detector, actual finite theta expansions, and the independently established
strong positivity/cluster compatibility of the standard geometric family.
No arbitrary-parameter or arbitrary-strong-basis conclusion is included.

### 7.1 Sharper finite wall-strip criterion

The coarse translate bound K_b is not necessary once all ambient dimensions
are above a fixed coordinate threshold. This sharper criterion recovers the
margin proposed by the preceding computational branch.

Write p_j=dim P_j=C^T e_j and define

    D_j(b)=max_(0<=s<=b)(-<s,p_j>)
          =sum_i b_i max(-(E C^T)_ij,0).                          (15)

Suppose

    r_j >= D_j(b) for every j,                                   (16)

and for every nonzero s<=b,

    <s,r> < q(s)  OR  <s,r> > -q(s).                            (17)

Then all conclusions (3), (12), (13), and integral Euler saturation hold.
Equivalently, (17) says |<s,r>|>-q(s). If q(s)>0 it imposes **no restriction**:
the two open intervals in (17) cover the real line. Only q(s)<=0 creates
a forbidden closed strip q(s)<=<s,r><=-q(s). In particular an extra
condition <s,r>!=0 is unnecessary for vectors with positive q(s).

**Proof.** Keep the notation of the AR argument, writing
P=direct_sum_j P_j^(h_j). Derived AR translation preserves the Euler
quadratic form, so

    q(v)=q(dim tau^(-1)L)=q(s+dim P).

Furthermore

    <P,r>+q(v)-q(s)
      = sum_j h_j(r_j+<s,p_j>)+q(P)+<P,S> >= 0.                 (18)

The first sum is nonnegative by (15)–(16), q(P)=dim End(P)>=0 because P
is projective, and <P,S>=dim Hom(P,S)>=0. The generic quotient inequality
therefore gives

    0 <= <r-v,v> = -<s,r>-<P,r>-q(v)
                 <= -<s,r>-q(s).

The generic submodule inequality gives <s,r>>=q(s). Thus an Ext obstruction
would force exactly

    q(s) <= <s,r> <= -q(s),

contrary to (17). This proves the sharper criterion.

For the 3-Kronecker diagnostic b=(2,3), (15) gives D(b)=(16,6).
With r=(5N,3N), the coordinate condition holds for N>=4, while (17) holds
exactly for N>=6. Thus the proof supplies the **all-N, all-prime statement
for N>=6** observed in the original Smith computations. No extrapolation
from N=6,...,14 is used in this conclusion.

The coarse criterion (2) is retained because it requires no coordinate
lower bound and therefore directly covers ray coordinates that remain
small. For the cluster application with a fixed growing support J, (15)–
(17) may instead be applied to Q_J and give a much smaller effective bound.

## 8. Computation and constructive diagnostics

`computation/euler_global_window_stress.py` computed the full exact Smith
form in every degree for the fixed 3-Kronecker kernel b=(2,3),
r=(5N,3N), N=8,...,14. All seven complete Euler maps were saturated; total
ranks were 13N. There were 61 computed half-degree blocks; the largest by
entry count was 147 x 109 (16,023 entries), and the largest row count was
1,040 in the degree-zero column at N=14. The full per-degree shapes, ranks
and timings are in the JSON. The total run took approximately 232 seconds. This was
started before the Ext argument and served as a mechanism diagnostic,
not as evidence replacing the general proof.

The stable rank profile 1,2,5,8,11,12,13,... prompted the geometric route:
it is the cumulative sequence of (1,1,3,3,3,1,1), the expected cohomology
profile of the stable (2,3) 3-Kronecker moduli. A projective-bundle
identification was considered but is **not** needed or claimed here.

The Wolfram evaluator independently verified, with a symbolic general
three-vertex acyclic Euler matrix E,

    Phi=-E^(-1)E^T, Psi=-E^(-T)E,
    Phi Psi=I,
    r^T E v + (Psi v)^T E r=0,

and the path-matrix expression c_b=E^(-1)(I-E)^T b. The proof of the AR
identity in Section 3 is categorical and all-rank; the plugin calculation
checks signs and conventions only. The raw receipt is saved separately.

## 9. Literature/route audit and attribution

1. **CEFR, Cell decompositions and algebraicity of cohomology for quiver
   Grassmannians, Advances in Mathematics 379 (2021) 107544.** Primary PDF:
   https://iris.uniroma1.it/bitstream/11573/1472718/1/CerulliIrelli_Celldecompositions_2021.pdf
   Read Theorem 41, the full proof of Theorem 37, and Corollary 43 (PDF
   pp.25–27). Their integral diagonal/Chern-generation theorem is the
   geometric input, not a result being claimed as new. Their earlier
   discussion around the AR sequences on PDF pp.20–21 also explicitly
   keeps the injective/projective correction when applying tau^(-1).

2. **DCPV 0805.2907v2; DCPV Box splines; Cavazzani–Moci 1303.0902v6.**
   The prior branch's local integral DM theorem remains valid and useful.
   The attempt to use deletion–restriction directly on the Weyl
   Vandermonde did not close: those roots are not members of the original
   graphic list. Adding them to the list does not by itself identify the
   required image. No new global DM gluing theorem is asserted.

3. **Schofield generic Hom/Ext and semi-invariants; Huszar 2111.00039.**
   These were searched as possible fixed-object/uniform-family interfaces.
   A generic-pair Schofield theorem alone would not give (3) for every U.
   The final proof instead uses only the elementary universal incidence
   dimension formulas and AR duality. Thus no unaudited fixed-object or
   noncommutative-rank assertion is needed as a premise.

4. The supplied old Coulomb/Ext-degree and presentation-Hecke notes were
   read. Their unresolved bar/loop dictionary and diagonal-point-image
   strictness issues are not repaired merely by a degree estimate. They
   were not imported into Sections 1–7.

5. Searches encountered the 2026 Fei generic-Grassmannian paper and 2026
   specialization papers. No theorem from them is used. The proof above
   is independent of Li–Pan/Lifang results and does not describe itself as
   an improvement of those results.

The elementary AR correction sequence (9), the uniform translate bound (6),
the integral i_*i^* argument, and the sharper criterion have passed the
independent core audit. The full minimality corollary must still retain the
precise actual geometric-basis scope from the parent branch, and its novelty
review must distinguish this new application from the standard ingredients.

### 04:45–04:50 route/literature review

- The planned global DM/Schur gluing is superseded for this acyclic
  application by Sections 1–7; no nonexistent DM gluing lemma has been
  inserted. The successful route was: stable Gram-rank pattern -> quiver
  Grassmannian diagonal -> bounded Ext vanishing -> AR conversion of a
  bounded submodule into a bounded quotient -> generic Euler inequalities.
- Broad primary-search queries combined quiver Grassmannians with
  asymptotic/generic cohomology, bounded submodules, Ext-injectivity,
  diagonal decomposition and Euler-form margins. No explicit existing
  statement of (2) or (15)–(17) was found. This is a bounded search outcome,
  not a certificate of worldwide novelty.
- Yingjin Bi, arXiv:2004.02110, was found as a potential canonical-basis
  comparison. The retrieved abstract concerns rigid Grassmannians and
  their Poincare polynomials. Its full proof was not imported.
- The 2010 Oberwolfach quiver report records a generic 4-Kronecker
  Grassmannian with negative Euler characteristic. This confirms that
  smoothness of a generic zero locus alone is insufficient. The present
  proof uses the explicit forbidden-strip/coordinate hypotheses, not a
  claim that all generic Grassmannians have property (S). This report was
  not needed as a mathematical premise.
- 2026 specialization/flag and Fei generic-Grassmannian search results
  were logged as related but unused; no unreviewed 2026 theorem enters
  the proof. The older CEFR theorem was read in primary full text at the
  precise proof location described above.
- Exact computation has stopped after the complete planned run. Further
  instances are unnecessary for the general proof. The two Wolfram
  receipts verify the Euler/Coxeter conventions and the explicit N>=6
  diagnostic threshold; they do not replace the representation-theoretic
  argument.
