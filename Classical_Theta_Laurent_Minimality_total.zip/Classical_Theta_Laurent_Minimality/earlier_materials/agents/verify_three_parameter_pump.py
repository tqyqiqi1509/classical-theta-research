#!/usr/bin/env python3
"""Exact verification of the three-parameter principal theta pump.

This verifies algebra and geometric travel times. It does NOT compute a complete
scattering diagram and does not independently prove the genericity/positivity
lemmas in CYCLIC_THREE_PARAMETER_PUMP.md.
"""

import argparse
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
import time

import sympy as s


def zero(expr):
    assert s.simplify(expr) == 0, expr


def symbolic_checks():
    a, b, c, u, h = s.symbols("a b c u h", positive=True)
    q1, q2, q3 = s.symbols("Q1 Q2 Q3", positive=True)
    kap = a*a+b*b+c*c-a*b*c
    B = s.Matrix([[0,b,-c],[-b,0,a],[c,-a,0]])
    k = s.Matrix([a,c,b])
    m0 = s.Matrix([-a,a*b-c,-b])
    m1 = m0+a*B[:,0]
    m2 = m1+c*B[:,1]
    m3 = m2+b*B[:,2]
    assert B*k == s.zeros(3,1)
    assert m1 == s.Matrix([-a,-c,a*c-b])
    assert m2 == s.Matrix([b*c-a,-c,-b])
    assert m3 == m0
    for m in [m0,m1,m2]:
        zero(k.dot(m)+kap)

    def back(q):
        ts = []
        for idx,m,cap in [(2,m0,b),(1,m2,c),(0,m1,a)]:
            t = s.factor(q[idx]/cap)
            ts.append(t)
            q = s.simplify(q+t*m)
            zero(q[idx])
        return q,ts

    Q = s.Matrix([q1,q2,q3])
    q,ts = back(Q)
    expected = [q3/b,(q2+(a*b-c)*q3/b)/c,
                q1/a+(b*c-a)*q2/(a*c)+(b*b-kap)*q3/(a*c)]
    for actual,wanted in zip(ts,expected):
        zero(actual-wanted)
    zero(q[1]-(-c*q1/a+(1-b*c/a)*q2+(kap-b*b)*q3/a))
    zero(k.dot(q)-k.dot(Q)+kap*sum(ts))

    q = s.Matrix([0,-u,(h+c*u)/b])
    qp,ts = back(q)
    expected = [(h+c*u)/(b*b),
                ((a*a-kap)*u+(a*b-c)*h)/(b*b*c),
                (1/c-kap/(a*b))*u+(b*b-kap)*h/(a*b*c)]
    for actual,wanted in zip(ts,expected):
        zero(actual-wanted)
    R = s.Matrix([[1-c*kap/(a*b),(b*b-kap)/(a*b)],
                  [-kap*(a*a-kap)/(a*b),1-kap*(a*b-c)/(a*b)]])
    for actual,wanted in zip(s.Matrix([-qp[1],k.dot(qp)]),R*s.Matrix([u,h])):
        zero(actual-wanted)
    zero(R.det()-1)
    zero(s.trace(R)-(2-kap))
    total = (a*a-kap)*u/(a*b)+(a*b-c)*h/(a*b)
    zero(sum(ts)-total)
    zero(k.dot(qp)-h+kap*total)

    # Rational linear maps for the three backward projections.
    projections = [s.eye(3)+m*s.eye(3)[idx,:]/cap
                   for idx,m,cap in [(2,m0,b),(1,m2,c),(0,m1,a)]]
    M = projections[2]*projections[1]*projections[0]
    zero(M.det())
    # Restrict the return map to the first coordinate plane.
    return_matrix = M.extract([1,2],[1,2])
    zero(return_matrix.det()-1)
    zero(s.trace(return_matrix)-(2-kap))
    return {"status":"passed", "return_matrix":str(R),
            "return_determinant":"1", "return_trace":"2-kappa",
            "first_wall_return_matrix":str(s.simplify(return_matrix)),
            "momentum_cycle":[list(map(str,m)) for m in [m0,m1,m2,m3]]}


def dot(x,y):
    return sum(a*b for a,b in zip(x,y))


def exact_case(a,b,c,cycles):
    kap=a*a+b*b+c*c-a*b*c
    assert kap<=0
    assert a*b>c and a*c>b and b*c>a
    k=(a,c,b)
    m0=(-a,a*b-c,-b)
    m1=(-a,-c,a*c-b)
    m2=(b*c-a,-c,-b)
    # Rational endpoint is for geometry checks only. The proof uses generic Q.
    q=(F(1),F(2),F(3))
    R=((1-F(c*kap,a*b), F(b*b-kap,a*b)),
       (F(-kap*(a*a-kap),a*b),1-F(kap*(a*b-c),a*b)))
    assert min(v for row in R for v in row)>=0
    selected=0
    for cycle in range(cycles):
        old=q
        times=[]
        for idx,m,cap in [(2,m0,b),(1,m2,c),(0,m1,a)]:
            t=q[idx]/cap
            assert t>0, (a,b,c,cycle,idx,t)
            q=tuple(x+t*v for x,v in zip(q,m))
            assert q[idx]==0
            times.append(t)
            selected+=1
        u,h=-q[1],dot(k,q)
        assert u>0 and h>0
        assert q==(F(0),-u,(h+c*u)/b)
        assert h==dot(k,old)-kap*sum(times)
        if cycle:
            up,hp=-old[1],dot(k,old)
            assert u==R[0][0]*up+R[0][1]*hp
            assert h==R[1][0]*up+R[1][1]*hp
    return selected, max(len(str(abs(x.numerator))) for x in q)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--bound",type=int,default=16)
    parser.add_argument("--cycles",type=int,default=16)
    parser.add_argument("--output",default=str(Path(__file__).with_suffix(".json")))
    args=parser.parse_args()
    start=time.monotonic()
    report={"symbolic":symbolic_checks(),"integer_box_bound":args.bound,
            "cycles_per_case":args.cycles,"eligible_triples":0,
            "parabolic_triples":[],"exact_selected_crossings":0,
            "max_coordinate_numerator_digits":0,
            "limitations":["No full scattering-diagram enumeration.",
                           "Rational test endpoint checks positivity only; generic joint avoidance is proved in the note.",
                           "This test does not establish literature novelty."]}
    for a,b,c in product(range(1,args.bound+1),repeat=3):
        kap=a*a+b*b+c*c-a*b*c
        if kap>0:
            continue
        selected,digits=exact_case(a,b,c,args.cycles)
        report["eligible_triples"]+=1
        report["exact_selected_crossings"]+=selected
        report["max_coordinate_numerator_digits"]=max(report["max_coordinate_numerator_digits"],digits)
        if kap==0:
            report["parabolic_triples"].append([a,b,c])
    report["elapsed_seconds"]=round(time.monotonic()-start,3)
    report["status"]="all checks passed"
    Path(args.output).write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
