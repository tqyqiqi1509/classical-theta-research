# Modular Euler bases and the ordinary-atlas theta minimum

Branch: modular_basis_minimality. Started 2026-11-14 03:36 UTC. Active research, not a completed minimality theorem.

## Current main conclusion

The standard skew-symmetric geometric-parameter p-KLR families have a substantially firmer basis identity than the old November 8 report makes apparent: McNamara 2112.04109v1, Theorems 1.1 and 18.2, supplies all-characteristic cluster-monomial compatibility. Consequently this standard family does not need the 2026 Tang positive-DT criterion for that input. The all-parameter/symmetrizable extension is a separate claim and is not silently imported.

The missing mathematical step remains a general integral finite-window saturation theorem for the Euler multiplication maps, or another theorem that directly makes the modular family positive in the relevant scattering charts. No amount of positivity in the ordinary cluster charts alone supplies that conclusion.

## Research log (chronological)

- 03:36: Read the old overall report, long-R Grassmannian formula, Qin/KKOP integral-Cartan audit, then the full general-parameter basis proof. Their normal-sequence, localization and seed-adaptation steps are separate inputs; nonnegative computed Euler coefficients alone do not prove a complete cluster basis.
- 03:39: Opened the author PDF and arXiv version of McNamara 2112.04109v1. Theorem 1.1 explicitly includes every dual p-canonical basis. Section 11 explains precisely how its three characteristic-zero KKKO inputs are replaced. This is a positive usable interface. The arXiv HTML has a 2026 rendering date although the version submission and author PDF are from 2021; no new 2026 theorem is inferred.
- 03:41: Read KKOP2306.15181v1 Definition 2.9/Lemma 2.10 and localization Theorem 2.15 directly from the saved primary text. Read KKOP1901.09319v2 Lemma 3.20 directly. Their hypotheses match the stated local categorical steps; no assumption that all arbitrary simple modules are affinizable is needed in the standard case.
- 03:42: Derived the quantum degree bound below. A first proposed weakening of Qin triangularity to uniformly bounded standard-correction degree was rejected after root correctly identified the unshifted diagonal term f=e: a bar-symmetric constant correction can remain. That weakening is not sufficient.
- 03:43: Explored generic quiver Grassmannian zero sections, HN stratification, framed-quiver Chow rings and integral Chern bases. Franzen 1312.1499 provides a real integral unitriangular Chern-to-cell basis for certain noncommutative Hilbert schemes, but no identification with our Euler image has been established. Thus it is an interface, not a proof.
- 03:46: Derived a bounded-order finite-difference model for the first genuinely interacting Euler coefficient (two vertex line Grassmannians). Its relevance is a candidate mechanism for general fixed root degree: fixed-order recurrences may isolate all torsion in simultaneous boundary collisions. This does not yet prove general saturation.
- 03:48: Exact Smith computations found no nonunit invariant in 8,641 graded two-variable Euler blocks satisfying the candidate distant-boundary inequality. Wolfram independently returned determinant 1 for the full m-by-m Pascal block for m=1,...,6. These checks diagnose the lemma, not the general cluster conjecture.

## Primary source interfaces checked

1. Peter J. McNamara, *Cluster Monomials are Dual Canonical*, arXiv:2112.04109v1, https://arxiv.org/abs/2112.04109; author PDF https://petermc.net/maths/papers/clusterpart.pdf. Definition of Q_ij on p.8 is geometric oriented-arrow difference parameters. In the unfolded skew-symmetric case the automorphism order is 1, so there is no excluded prime. Section 11: Proposition 11.1 gives real determinantial modules whose reductions remain simple; Lemma 11.4 preserves R-matrix degrees under its explicit real/simple reduction assumptions; Theorem 11.2 and Corollary 11.5 supply the missing all-characteristic monoidal-categorification inputs. Theorems 1.1 and 18.2 then put every cluster monomial in the dual p-canonical basis. This does not prove the old arbitrary-Q extension.
2. KKOP, arXiv:2306.15181v1, Definition 2.9 and Lemma 2.10: for an almost-affreal sequence, nonzero long R gives simple image, simple head of the forward product and socle of the reverse product, up to grading shift. The old block-reversal PBW identity proves nonvanishing if checked with intertwiners, not an incorrect braid relation for psi across repeated colours. Single-colour nilHecke simples are real and admit the dot-translation affinization.
3. Same paper, (2.4), (2.7)(D), Theorem 2.15: integral Grothendieck algebra, localized simple objects, and the localized quantum unipotent cell. This provides a genuine complete basis after the acyclic doubled-Coxeter frame and labels are identified.
4. KKOP, arXiv:1901.09319v2, Lemma 3.20: q-commuting simple classes imply strongly commuting objects when one factor is real and affinizable. It is essential to supply that factor (determinantial after twist/localization); class q-commutation alone is insufficient.

## General quantum degree estimate

Use B_ij=-m_ij for i<j in an acyclic order, and d_i=1. Write a=r-b. The integral Euler operator has degree 2 D_inv on H=the tensor product of H*(Gr(b_i,r_i)), whose top degree is 2 D_gr, where

D_inv = sum_(i<j) m_ij b_i (r_j-b_j),
D_gr = sum_i b_i(r_i-b_i).

Normalize the graded image by v^(-D_inv-D_gr). Its degrees lie in the interval

[-delta,delta],  delta=D_gr-D_inv.

For g_i=-r_i+sum_(j>i)m_ij r_j and q_B(b)=sum_i b_i^2-sum_(i<j)m_ij b_i b_j, direct expansion gives

delta = -g dot b - q_B(b).

Thus a nonzero coefficient requires g dot b <= -q_B(b), in every characteristic. For a completed basis label g=u+Vr with u_i r_i=0, any supported b has b_i=0 when r_i=0, hence u dot b=0 and the same estimate holds. Bar symmetry follows from the Frobenius pairing. This is an all-rank degree constraint but only a one-chart constraint; it is not a proof of theta minimality.

## Routes not established

- Positive modular decomposition has the direction char0-simple = positive sum of characteristic-p simples. Its inverse need not be positive. Therefore char0 theta positivity cannot simply be transported to characteristic p.
- The same decomposition gives coefficientwise ordinary-chart domination pL_g <= L_g^0, but scattering-chart subtraction has signs. Domination does not itself prove theta positivity.
- Framed quiver moduli can have integral Chern bases; our ambient Euler image still needs an actual geometric identification, and general quiver-Grassmannian purity for rigid representations does not apply to the imaginary families of interest.
- A finite set of characteristic ranks agreeing with theta does not prove saturation over all primes. Saturation is equivalent to every nonzero Smith invariant being 1.
- Generic-ray finite-window equality remains a concrete potential bridge. Its full proof would be new here; the characteristic-zero CTB product-detector theorem is prior local work and must not be recounted as new.

## A proved integral finite-difference mechanism

This is a general matrix lemma (all sizes and all recurrence orders), used to expose the type of missing higher-Schur mechanism; it is not offered as a replacement for the requested general cluster theorem.

Let h_t=binom(m+t-1,m-1) for t>=0 and h_t=0 for t<0. For integers a,b>=1 and s>=0, put

T_(a,b)(s)=(h_(s+i-j))_(0<=i<a,0<=j<b).

**Lemma.** If max(a,b)>=m, every nonzero Smith invariant of T is 1. Its rank is min(a,b,max(m,b-s)).

**Proof.** Every leading m-by-m block has determinant s_(s^m)(1,...,1)=1 by the ordinary Jacobi-Trudi identity: the rectangular partition has m rows, so the associated GL_m representation is det^s. The same fact also follows from m successive finite differences. If a<m<=b, the first m columns of T can be completed by rows to this integral unimodular matrix; hence these a rows form a primitive full-row-rank system. If b<m<=a, use columns instead. If both dimensions are at least m, the m-th column difference expresses each later transformed column as a signed standard unit vector, nonzero precisely when the corresponding zero-to-positive boundary enters the row interval. There are at most max(0,b-s-m) such vectors. Thus rank<=min(a,b,max(m,b-s)). If b-s<=m, the leading m-by-m unit minor attains the bound. If b-s>m, the columns with indices s,...,s+rho-1, where rho=min(a,b-s), and first rho rows form a lower unitriangular minor. This attains the bound. The existence of a unit maximal minor proves all nonzero Smith factors are 1. QED.

**Euler consequence.** For an m-arrow pair, r=(R,S), b=(1,1), work integrally in H=Z[x,y]/(x^R,y^S). Up to signs which do not affect ranks, F=h_(S-1)(x,y)^m. Modulo y^S,

F=sum_(j=0)^(S-1) binom(m+j-1,m-1) x^(m(S-1)-j)y^j.

Writing D=m(S-1) and delta=R+S-2-D, the degree-q matrix has source y-exponents J=[max(0,q-R+1),min(q,S-1)] and target y-exponents K=[max(0,q+D-R+1),min(q+D,S-1)]. It is a consecutive block T_(|K|,|J|)(minK-minJ), with nonnegative offset. By Gorenstein symmetry the two dimensions are dim H_q and dim H_(delta-q). If min(R,S)>=m and delta>=2m-3, at least one is >=m for every 0<=q<=delta. (The upper degree cutoff cannot shorten either dimension below m once its argument is >=m-1, because D>=m-1.) The lemma proves every graded Euler image is saturated. If delta<0, the map is zero. Hence along every positive denominator ray nonresonant for (1,1), this coefficient eventually agrees in all characteristics.

**Actual limitation.** For b with components above 1, Schur antisymmetrization and multiple Chern-root variables must be handled integrally. One must not divide by products of factorials or simply infer that invariants of a saturated map are saturated. The general extension is still open in this branch. The matrix lemma provides a concrete candidate for a multivariable finite-difference/graphic-root interpolation proof.

**Computational checks.** An independent exact SymPy Smith routine verified 8,641 graded Euler blocks with m=2,...,6, 2<=R<=30, 2<=S<=20 and delta>=2m-2. A second check verified 9,900 Toeplitz matrices with m<=8, a,b<=10, offsets 0,...,14 and max(a,b)>=m. Wolfram evaluated the symbolic determinant for m=1,...,6 to (1,1,1,1,1,1). These are checks of the sign, indexing and threshold, not the proof.

## A 2026 source encountered and bounded audit

Filip Jonsson Kling and Samuel Lundqvist, *On maximal rank properties for symmetric polynomials in an equigenerated monomial complete intersection*, arXiv:2601.15978v1, submitted 22 January 2026, https://arxiv.org/abs/2601.15978.

Audit: opened the primary version and read its scope, Theorem 4.3 proof interface and Theorem 4.6. Section 2 explicitly works in characteristic zero; its setting is equigenerated monomial complete intersections. Theorem 4.3 is about banded 0/1 Toeplitz matrices, not our binomial-power kernel. It therefore does not establish modular saturation or the general Euler-image statement. Its Jacobi-Trudi idea is useful background; no theorem from it is used in the proof above. Outcome: useful conceptual interface, insufficient for the main bridge, no mathematical error asserted.

## Fixed graphic-kernel formula for every b (general mechanism)

Here all formulas are integral. The sign convention matches the parent's positive Schur/Pieri implementation. Put x_(i,alpha)=the Chern roots of S_i^*, a_i=r_i-b_i, and use

c_t(Q_i)=product_(alpha=1..b_i)(1-x_(i,alpha)t)^(-1),

so c_k(Q_i)=h_k(x_i), with h_k(x_i)=0 in the Grassmannian ring for k>a_i. For an arrow i->j the top Chern class of Hom(S_i,Q_j) is

E_ij=product_(alpha=1..b_i) sum_(k=0)^a_j x_(i,alpha)^(a_j-k) h_k(x_j).

With m_ij parallel arrows F=product E_ij^m_ij. The geometric KLR convention Q_ij(u,v)=(u-v)^m_ij may introduce a global sign after x=c1(S*); it changes no rank. In the positive Schur convention above no such sign remains.

Introduce the fixed list X of lattice vectors

    e_(j,beta)-e_(i,alpha), repeated m_ij times,

for all i<j, alpha<=b_i, beta<=b_j. It is the incidence list of a finite multigraph on sum b_i vertices; hence it is unimodular relative to its saturated span. Its oriented cone is pointed. Define the integral vector-partition kernel

    K_X(x)=product_(i<j,alpha,beta)(1-x_(j,beta)/x_(i,alpha))^(-m_ij)
          =sum_eta P_X(eta) x^eta.

P_X counts nonnegative flows; a collapsed edge of multiplicity m and total flow k contributes binom(m+k-1,m-1). All factors are expanded in the acyclic orientation i<j.

One may write formally F=product_(i,alpha) x_(i,alpha)^A_i K_X, where A_i=sum_(j>i)m_ij a_j. This must be understood as an **ordered coefficient-extraction identity**, not as inversion of nilpotent Chern classes in the cohomology ring. To justify it, integrate sink colours first. At a sink every term h_k(x_j) with k>a_j vanishes against every polynomial by the Grassmannian relation. After those terms are removed, every surviving outgoing source exponent is nonnegative. Repeat in reverse topological order. Thus all infinite tails disappear before they could require division by a nilpotent class. The pointed flow cone also makes each prescribed total coefficient a finite sum.

The Grassmannian integration formula is

    integral_(Gr(b_i,r_i)) f(x_i)
       =[product_alpha x_(i,alpha)^(r_i-alpha)] f(x_i) Delta_i(x_i),

where Delta_i=product_(alpha<beta)(x_(i,alpha)-x_(i,beta)). For any partitions nu_i with at most b_i parts, use the integral alternant

    s_(nu_i)(x_i) Delta_i(x_i)
      =sum_(sigma_i in S_bi) sgn(sigma_i)
         product_alpha x_(i,alpha)^(nu_(i,sigma_i(alpha))+b_i-sigma_i(alpha)).

Set

    rho_i=r_i-b_i-sum_(j>i)m_ij(r_j-b_j)
         =-g_i-b_i+sum_(j>i)m_ij b_j.

Then the exact general moment is

    integral F product_i s_(nu_i)
      =sum_(sigma_i in S_bi) (product_i sgn(sigma_i)) P_X(eta(sigma,nu)),

    eta_(i,alpha)=rho_i+sigma_i(alpha)-alpha-nu_(i,sigma_i(alpha)).        (GK)

The sum of all eta coordinates is delta-sum_i |nu_i|, so only total Schur degree delta contributes. No averaging or division by b_i! occurs.

For an actual multiplication block, use the unimodular Poincare-dual Schur basis on its target. Its matrix is the Gram form

    G_(lambda,mu)=integral F product_i s_(lambda_i)s_(mu_i),

with total degrees |lambda|=q and |mu|=delta-q. Expand s_lambda s_mu by integral Littlewood-Richardson coefficients, then apply (GK). Consequently the original huge Euler map is replaced by a low-degree Gram matrix with exactly the same Smith invariants. The source/dual-target partitions still obey their original rectangle bounds; omitting those bounds would change the problem.

**All r-dependence is explicit:** (i) the translation rho_i, hence g_i, (ii) the rectangle widths a_i=r_i-b_i, and (iii) the total Gram degree delta=sum_i b_i rho_i. The graph X, its edge multiplicities, the number of root variables, the alternating groups and the recurrence orders depend only on B and the fixed root b. This is the substantive general interface obtained in this branch.

For the live diagnostic B=3-Kronecker, g=(4N,-3N), b=(2,3), one has

    rho_source=7-4N, rho_target=3N-3, delta=N+5.

The kernel is the 2-by-3 contingency-table sum with row margins -eta_source, column margins eta_target, and edge weights binom(3+k-1,2). Only two independent flow summations are required.

### Exact remaining saturation target

For every acyclic skew-symmetric B and finite box E, choose a ray g=N nu+h with nu dot d nonzero for every 0<d<=E, and let r,u be its completed acyclic labels. Prove that for all sufficiently large N, all 0<=b<=E, and every q, the integral Gram matrix G_(r,b,q) above has saturated image. The threshold must be uniform over finitely many fixed offsets h used in the product detector and over all primes. This would imply modular/characteristic-zero equality in the finite window and transfer the already established CTB generic-jet detector to these genuinely different strong-positive bases.

A weaker but sufficient statement can identify theta-indexed primitive summands rather than all image saturation. Neither statement is proved here. In particular graphic unimodularity of X does not by itself prove unimodularity of every Schur-alternated, rectangle-truncated Hankel block.

### Primary difference-equation interface

De Concini–Procesi–Vergne, *Vector partition function and generalized Dahmen–Micchelli spaces*, arXiv:0805.2907v2, https://arxiv.org/html/0805.2907v2. Checked Definition 2.4, Theorem 3.10 (the exact sequence has an explicit integral splitting), and the chamber-minus-zonotope localization in Theorem 3.18. Its integer-valued difference-equation formalism matches K_X exactly. However the paper's coefficient-ring list is Z,Q,R,C, so it must not be cited as an already stated arbitrary-F_p theorem without an integral splitting/base-change argument for the specific module. The unresolved issue is carrying this integral decomposition through our Schur alternants and growing rectangular windows.

### Code

`computation/euler_graphic_kernel.py` implements (GK) with a general acyclic flow recursion and a specialized exact 2-by-3 contingency-table evaluator. Its diagnostic compares moments to the pre-existing independent integral Schur/Pieri Euler implementation. It is a computational interface for the new general formula, not a proof of saturation or minimality.

## First-wave closeout and next-owner handoff

The full general graphic-kernel formula was independently cross-checked before closing this wave: 48 Schur moments across the 3-Kronecker and connected rank-three cases agreed exactly with the prior integral Pieri operator, including all 40 moments of total degree 7 for r=(10,6), b=(2,3). Root independently produced a second implementation and reports matching full Gram ranks in all tested characteristics across 48 parameter sets; those results live separately in `computation/graphic_kernel_euler_calibration.json`.

The productive next task is the general Schur-alternated graphic-kernel saturation problem above. In particular: identify a primitive integral evaluation lattice for the relevant Dahmen–Micchelli chamber piece; prove that the growing source and dual-target partition windows capture it unless a bounded affine hyperplane g dot d=O_E(1) is met; carry this through alternating operators without factorial division. A counterexample to this precise saturation statement would redirect to the weaker theta-indexed primitive-summand formulation, not establish failure of theta minimality by itself.

No general characteristic-p theta-positive transition theorem and no negative theta-transition counterexample has been proved in this wave. The positive results are the primary-source basis interface, the exact all-rank graphic-kernel reduction, and the proved integral finite-difference matrix mechanism. The requested main difficulty has been retained throughout.

Final reproducible diagnostic: `computation/toeplitz_saturation_check.py` checks the proved threshold delta>=2m-3 together with min(R,S)>=m, and records 6,590 Euler blocks plus 9,900 general Toeplitz matrices, with no nonunit factors and exact agreement with the rank formula. The earlier 8,641-block experiment used the different exploratory threshold delta>=2m-2 without the min(R,S) restriction; it is not the count of the saved final diagnostic.
