# Independent adversarial audit: bounded-submodule Ext vanishing, integral Euler saturation, and the modular theta comparison

Audit owner: generic_ext_saturation_adversarial. Opened 2026-11-14 04:40 UTC; substantive review completed 04:56 UTC. This report concerns finite acyclic quivers and classical cluster algebras. It does not claim minimum among all strong-positive bases.

## Verdict and exact scope

**PASS for the new representation-theoretic and integral-geometric mechanism.** I independently reconstructed the AR argument, checked all genericity quantifiers, and checked the integral diagonal-to-Euler step against CEFR §4. The strengthened projective-correction criterion is valid. It improves the original coarse ray argument to an explicit finite criterion, with the possible obstruction confined to intervals determined by nonpositive values of the Tits form.

For the cluster application, the safe scope is the **standard symmetric geometric p-KLR family, principal coefficients, and inverted frozen variables**, transported through the already audited doubled-Coxeter dictionary. The characteristic-zero specialization is the common triangular basis by Qin's older theorem. The October 31 finite-window theorem and its product detector remain prior local inputs, not newly proved here. Within these inputs the modular finite-window comparison and the classical positive transition to theta follow.

The phrase “Euler ranks define a basis” is not used: completeness comes from the actual integral simple-object Grothendieck basis and localization. Finite Dynkin components require a separate argument, because a doubled Coxeter word need not be reduced there.

Priority for the bounded-window theorem and the resulting modular comparison still needs the parent team's broader literature check. No external theorem dated 2026 and no Li–Pan conclusion is used below; the explicitly identified October 31 local theorem remains a prior-work input.

## 1. Conventions and two generic-incidence necessities

Let Q be a finite acyclic quiver, topologically ordered. Let A be its strictly upper triangular adjacency matrix, with A_ij the number of arrows i → j, and put

\[
 E=I-A,\qquad \langle x,y\rangle=x^T E y,\qquad q(x)=\langle x,x\rangle .
\]

The dimension vectors are columns. The path matrix R=E^{-1} is integral. The dimension vector of the indecomposable projective P_j is

\[
 p_j=E^{-T}e_j,
\]

whereas the dimension vector of the indecomposable injective I_j is E^{-1}e_j. In particular

\[
 \langle p_j,r\rangle=r_j .
\]

These projective/injective transposes are essential.

For a fixed dimension s≤r, the universal submodule incidence over Rep_Q(r) is a vector bundle over \(\prod_i\mathrm{Gr}(s_i,r_i)\). Its dimension minus \(\dim\mathrm{Rep}_Q(r)\) is

\[
 \langle s,r-s\rangle=\langle s,r\rangle-q(s).
\]

The projection is proper. If this integer is negative, a generic representation of dimension r has no submodule of dimension s. Likewise, a generic representation can have a quotient of dimension v only if

\[
 \langle r-v,v\rangle=\langle r,v\rangle-q(v)\ge0.
\]

These are **necessary** conditions only; no sufficiency assertion is made.

For fixed bounds on s and v, there are finitely many incidence projections. Removing every forbidden proper closed image gives one nonempty open subset on which both necessities hold for every relevant submodule and quotient. This single-open-set construction is what permits the later universal quantifier over U⊂M.

## 2. The AR mechanism with the projective correction retained

Suppose U⊂M, and \(\operatorname{Ext}^1(U,M)\ne0\). Remove the projective direct summands of U. The remaining direct summand U_0 is still a submodule of M, is bounded by dim U, and retains the nonzero Ext.

AR duality supplies a nonzero actual map

\[
 \phi:M\longrightarrow\tau U_0 .
\]

Even the stable-Hom formulation is enough: a nonzero stable class has an actual representative. Set V=im φ, so V is a nonzero quotient of M and a submodule of τU_0.

Neither τU_0 nor V has an injective direct summand. The first fact is the usual AR correspondence. An injective direct summand of V would embed in τU_0 and split there, contradicting the first fact.

Write

\[
 (\tau U_0)/V=W_0\oplus I
\]

with W_0 having no injective direct summand and I injective. In the hereditary derived category, the inverse derived AR translation sends I to P[1], with P projective, and sends V, τU_0, W_0 to their ordinary inverse AR translates. The ordinary cohomology sequence of the translated triangle is

\[
 0\longrightarrow P\longrightarrow\tau^{-1}V
 \longrightarrow U_0\longrightarrow\tau^{-1}W_0\longrightarrow0 .
 \tag{AR}
\]

Thus, with S the middle image,

\[
 0\longrightarrow P\longrightarrow\tau^{-1}V
 \longrightarrow S\longrightarrow0,\qquad S\subset U_0\subset M.
 \tag{AR'}
\]

**S is nonzero.** Otherwise the nonzero module τ^{-1}V would be projective. But V has no injective direct summand, so its nonzero inverse translate has no projective direct summand.

This is the point at which it would be incorrect to write τ^{-1}V⊂U_0 without the projective kernel. The correction is harmless only after its contribution has been estimated.

Serre duality gives the sign and order

\[
 \langle r,v\rangle
 =-\langle\dim\tau^{-1}V,r\rangle
 =-\langle s,r\rangle-\langle p,r\rangle .
 \tag{1}
\]

Here s=dim S, p=dim P, v=dim V. Since P is projective,

\[
 \langle p,r\rangle=\dim\operatorname{Hom}(P,M)\ge0.
\]

The forward Coxeter matrix is C=−E^{-1}E^T. It preserves the Euler form and q; therefore

\[
 q(v)=q(C^{-1}v)=q(s+p).
 \tag{2}
\]

The symbolic checks in the accompanying Wolfram receipt verify both Euler identities, the full Euler-form isometry, and the projective-column convention for a general three-vertex acyclic matrix.

## 3. A coarse criterion that works for every generic nonresonant ray

Fix b≥0. The canonical projective resolution of U embeds τU into

\[
 \bigoplus_{a:i\to j} I_j^{\oplus\dim U_i}.
\]

Consequently

\[
 \dim\tau U\le c_b:=E^{-1}A^T b\quad\text{whenever }\dim U\le b .
\]

Define

\[
 K_b=\max\bigl(\{0\}\cup\{-q(v):0<v\le c_b\}\bigr).
\]

An empty maximum contributes 0. All these bounds are finite and depend only on Q,b.

**Coarse finite theorem.** If r≥0 satisfies, for every nonzero s≤b,

\[
 \langle s,r\rangle<q(s)
 \quad\text{or}\quad
 \langle s,r\rangle>K_b ,
 \tag{3}
\]

then generic M of dimension r satisfies

\[
 \operatorname{Ext}^1(U,M)=0
 \quad\text{for every }U\subset M,\ \dim U\le b.
 \tag{4}
\]

Proof: work in the single incidence-open set of §1 for s≤b and v≤c_b. If Ext were nonzero, (AR') supplies a nonzero S⊂M. The submodule necessity excludes the first alternative of (3), so η:=〈s,r〉>K_b. But V is a quotient of M, and (1) gives

\[
 0\le\langle r-v,v\rangle
 \le-\eta-q(v)<-K_b-q(v)\le0,
\]

a contradiction.

If r(N)=Nr_0+r_1 is eventually nonnegative and every nonzero s≤b satisfies 〈s,r_0〉≠0, then (3) holds eventually. Positive slopes eventually exceed K_b; negative slopes eventually lie below q(s). One finite maximum gives a threshold for all s and all members of any prescribed finite offset set.

**This argument permits zero coordinates of r_0.** It does not require the coordinate lower bound in the next section. Thus the original general nonresonant-ray statement survives all support-boundary cases.

## 4. Sharpened criterion: only a bounded Tits interval can obstruct

Define the explicit projective-correction bound

\[
 D_j(b)=\max_{0\le s\le b}(-\langle s,p_j\rangle)
       =\sum_i b_i\,[-(E p_j)_i]_+ .
 \tag{5}
\]

Assume r_j≥D_j(b) for every j. Write P as \(\bigoplus_jP_j^{h_j}\). Then

\[
 \begin{aligned}
 \langle p,r\rangle+q(s+p)-q(s)
 &=\sum_jh_j\bigl(r_j+\langle s,p_j\rangle\bigr)
   +q(p)+\langle p,s\rangle\\
 &\ge0 .
 \end{aligned}
 \tag{6}
\]

Every term has a reason for its sign:

- \(r_j+\langle s,p_j\rangle\ge0\) follows from (5) and s≤b.
- \(q(p)=\dim\operatorname{End}(P)\ge0\), because P is projective.
- \(\langle p,s\rangle=\dim\operatorname{Hom}(P,S)\ge0\).

Combining (1), (2), and (6), any hypothetical nonzero Ext gives

\[
 0\le\langle r-v,v\rangle
 =-\langle s,r\rangle-\langle p,r\rangle-q(s+p)
 \le-\langle s,r\rangle-q(s).
\]

The submodule incidence necessity simultaneously gives 〈s,r〉≥q(s). Therefore a hypothetical counterexample must supply

\[
 q(s)\le\langle s,r\rangle\le-q(s).
 \tag{7}
\]

**Sharpened finite theorem.** Under r≥D(b), condition (4) holds whenever, for every nonzero s≤b,

\[
 \langle s,r\rangle<q(s)
 \quad\text{or}\quad
 \langle s,r\rangle>-q(s).
 \tag{8}
\]

For q(s)>0, interval (7) is empty, so (8) imposes no condition. For q(s)=0 it excludes only 〈s,r〉=0. For q(s)<0 it excludes the closed integer interval [q(s),−q(s)].

Strictness matters. A boundary value 〈s,r〉=−q(s) does not yield the required contradiction.

For the 3-Kronecker bound b=(2,3), the projective columns are (1,3)^T and (0,1)^T, so D=(16,6). For r=(5N,3N), the last obstructing root is s=(2,3), with q(s)=−5 and 〈s,r〉=N. The criterion gives N≥6. Wolfram independently checked every bounded root and the coordinate inequalities for N=1,…,7. This calculation checks the signs and threshold arithmetic, and is not a substitute for the general proof.

On strictly positive denominator rays the coordinate lower bound holds eventually; then nonresonance is needed only for the finitely many s with q(s)≤0. For rays with zero coordinates, retain §3 unless the fixed offsets themselves meet the relevant D_j.

## 5. From bounded Ext vanishing to integral Euler saturation

Let e≤b and choose M in the common open set of §3 or §4. For every U,V⊂M with dim U=e, heredity gives a surjection

\[
 \operatorname{Ext}^1(U,M)\twoheadrightarrow
 \operatorname{Ext}^1(U,M/V),
\]

so the latter vanishes. V need not have bounded dimension for this implication; in the diagonal argument it also has dimension e.

Put

\[
 Y=\prod_i\mathrm{Gr}(e_i,r_i),\qquad
 X=\mathrm{Gr}_e(M),\qquad
 \mathcal E=\bigoplus_{a:i\to j}\operatorname{Hom}(S_i,Q_j).
\]

The representation M defines a section of \(\mathcal E\) with zero scheme X. At U, its linearized cokernel is Ext¹(U,M/U)=0. Thus X is empty or smooth of its expected dimension δ=〈e,r−e〉, and

\[
 i_*1=c_{\mathrm{top}}(\mathcal E)=F.
 \tag{9}
\]

On X×X, the usual quiver-Hom differential

\[
 \bigoplus_i\operatorname{Hom}(p_2^*S_i,p_1^*Q_i)
 \longrightarrow
 \bigoplus_{a:i\to j}\operatorname{Hom}(p_2^*S_i,p_1^*Q_j)
\]

is surjective at every point because its cokernel is Ext¹(U,M/V). Its kernel \(\mathcal K\) is a vector bundle of rank δ. The canonical composition U→M→M/V is a section of \(\mathcal K\), and its zero scheme is exactly the diagonal. Therefore

\[
 [\Delta_X]=c_\delta(\mathcal K).
 \tag{10}
\]

Since \(c(\mathcal K)=c(\mathcal H)c(\mathcal K_{\mathrm{target}})^{-1}\), (10) is an integral sum of external products of tautological Chern classes. This is the diagonal mechanism of CEFR §4 with the surjectivity hypothesis supplied by (4). The original rigidity of M is not needed once that surjectivity and smoothness have been established.

Applying the integral diagonal correspondence shows that H*(X,ℤ) is generated by these even tautological classes; odd classes and torsion classes vanish. Equivalently one may use the Ellingsrud–Strømme theorem quoted as CEFR Theorem 41. In particular,

\[
 i^*:H^*(Y,\mathbb Z)\twoheadrightarrow H^*(X,\mathbb Z).
 \tag{11}
\]

Integral Poincaré duality makes i_* the transpose of this surjection between free groups. Hence i_* is an injection with primitive image. The projection formula gives

\[
 m_F=i_*i^*,\qquad
 \operatorname{Im}(m_F)=i_*H^*(X,\mathbb Z).
 \tag{12}
\]

Thus every graded Euler multiplication block has saturated image: **each nonzero Smith invariant equals 1**. Empty X gives F=0 and is included.

The proof does not infer saturation merely from torsion-free cohomology; the crucial additional fact is the integral surjection (11). Nor does it require choosing an integral model of M that remains smooth in every characteristic. The fixed Euler class F is an integral class on a product of Grassmannians; proving primitivity of its integral matrix over ℂ is enough to base-change that matrix to every prime field.

## 6. Completed labels and the apparent support-boundary problem

Use the current convention B_ij=−A_ij for i<j. The completed acyclic labels satisfy

\[
 g_i=u_i-r_i+\sum_{j>i}A_{ij}r_j,\qquad
 u_i,r_i\ge0,\quad u_i r_i=0.
 \tag{13}
\]

Backward recursion gives

\[
 \begin{aligned}
 r_i&=\max\{-g_i+\sum_{j>i}A_{ij}r_j,0\},\\
 u_i&=\max\{g_i-\sum_{j>i}A_{ij}r_j,0\}.
 \end{aligned}
\]

This is a finite piecewise-linear integral bijection. For a finite set of offsets h, choose ν inside the required open detector cone and away from the finitely many walls of this label map. Each recursive linear form has coefficient 1 on g_i, so these walls are proper hyperplanes on each linearity chamber.

For all sufficiently large N, the labels of g=Nν+h then have a fixed active set J, uniformly over those offsets:

- r_i grows with positive linear slope for i∈J;
- r_i=0 identically for i∉J.

There are no unexplained bounded positive r_i on such a generic ray. Root coefficients with e_i>0 for an inactive i are zero. On the induced quiver Q_J, u_i=0 and

\[
 E_J r_J=-g_J,\qquad
 \langle s,r_J\rangle=-s\cdot g_J.
 \tag{14}
\]

Choose ν also off the finite root hyperplanes s·ν=0 needed for the prescribed root box. Then §3 applies on Q_J uniformly to all offsets, or §4 applies there since its r-coordinates grow positively.

This closes the completed-label boundary issue for the generic directions actually used by the product detector. It is not a claim that every direction on a label wall is automatically covered by the same restricted-support argument.

## 7. The actual basis dictionary and its finite-type qualification

### 7.1 The reversed-order and deficit conversion

The November 8 long-R formula uses an opposite source convention, with B_old,ij≥0 for i<j and an “all-second” head. Its small root variable is the deficit a=r−b_old. The Euler contribution on an old arrow is

\[
 (r_i-a_i)a_j.
\]

After reversing vertex order and renaming the old deficit a as the current small root e, this becomes

\[
 e_i(r_j-e_j),
\]

which is the degree of the current Hom(S_i,Q_j) Euler factor. The Grassmannian complements and dual conventions must be changed with the order; a harmless overall sign does not affect any rank. Merely calling the old b_old the current e, without this deficit conversion, would be wrong.

### 7.2 Completeness and all-prime positivity come from categories

For the standard symmetric geometric KLR parameters, McNamara's 2021 Theorems 1.1 and 18.2 give cluster-monomial membership in the actual dual p-canonical basis. In the unfolded case the automorphism order is 1, so there is no excluded prime. Integral Grothendieck groups and exact determinantial localization supply complete simple-object bases and positive product coefficients.

The long-R/Grassmannian formula then computes the Laurent coefficients of those basis elements. Its categorical nonzero-image/head, quotient, localization, and label-completion arguments are prior local inputs checked against the cited older KKOP results. This report does not replace those inputs by the numerical observation that Euler ranks are nonnegative.

For p=0, Qin 2003.13674v3 Theorem 9.5.1 identifies the normalized localized dual canonical basis with the common triangular basis; Corollary 9.5.3 matches the acyclic Berenstein–Zelevinsky basis. These are precisely the characteristic-zero basis identities needed to import the October 31 finite-window theorem.

### 7.3 Doubled Coxeter words

For a connected infinite-type component, Speyer's Theorem 1 says every power of a Coxeter word is reduced. Hence cc is reduced. Berenstein–Rupel Theorem 2.11 and §7.3 explicitly require this hypothesis; it must remain in the application.

The principal framing is not an enlarged Cartan device used to evade nonreducedness. BR §7.1 exhibits the exchange matrices with lower blocks ±I. In the old exact coordinate calculation,

\[
 \phi=\begin{pmatrix}U&V\\0&U\end{pmatrix},\qquad
 \rho=\begin{pmatrix}I&0\\0&U\end{pmatrix},\qquad
 T=\rho^{-1}\phi=
 \begin{pmatrix}U&V\\0&I\end{pmatrix},
\]

where U=−I+[B_old]_+, V=−I+[−B_old]_+. These are integral lattice transformations because U is triangular with diagonal −1. The frozen variables are inverted. The mutable initial variables agree with the BR variables; the frozen lattice change must be tracked when normalizing labels.

For a finite Dynkin component, cc may fail to be reduced, including A1 and A2. Do not invoke the same unipotent-cell argument there. The component is handled directly by its cluster-monomial/theta basis. For the Euler interpretation at arbitrary r, a generic Dynkin representation is rigid, so the CEFR argument gives all-prime saturated Euler images for every e. Their ranks are the quiver-Grassmannian Euler characteristics, which give the rigid cluster character and hence the relevant cluster monomial. Reducible quivers are treated componentwise.

## 8. Consequence for the modular-to-theta transition

Take as prior inputs the October 31 generic finite-window theorem for the common triangular basis, finite theta-span membership for the acyclic ordinary algebra with the specified coefficients, and the product-detector lemma proved there.

Sections 3–6 give, uniformly for every prime p and for every fixed finite root box and finite offset set, equality of the modular and characteristic-zero Euler coefficients along the required generic ray. Therefore the actual p-KLR basis and the common triangular basis have identical finite jets there. The latter jets are the theta jets by the old theorem.

The positive-degree scattering coordinate changes preserve equality of these finite jets. In the detector chart the relevant large labels have monomial jets. Multiplying a fixed modular basis element by a sufficiently distant modular basis element, the desired theta-transition coefficient is exactly one of the actual basis structure constants. That constant is a nonnegative integer, because multiplication in the localized simple-object basis is positive.

Thus the standard geometric modular basis has a classical positive expansion in theta, within the stated principal-coefficient scope. This is a comparison for a concrete, genuinely existing family. It is not the missing theorem for every abstract strong-positive basis.

No new quantum comparison is claimed here. The user requested the classical case, and the classical product detector has no quantum phase-normalization issue.

## 9. A global Smith-unit lower bound after the positive comparison

This consequence is stronger than the distant-ray saturation statement in a different direction, but depends on the positive comparison from §8.

Fix arbitrary r and root e≤r, put g=−Er, and let A_{r,e} be the entire integral multiplication-by-F map on the product of Grassmannian cohomologies, regarded as one ungraded finite free abelian-group homomorphism. Let a_g^θ(e) be the initial-chart theta Laurent coefficient in that root position.

For every prime p, the actual modular basis element has leading theta term θ_g with coefficient 1 and all other theta terms nonnegative. Ordinary theta Laurent positivity gives

\[
 \operatorname{rank}_{\mathbb F_p} A_{r,e}\ge a_g^\theta(e).
 \tag{15}
\]

For any integral matrix A with nonzero Smith factors

\[
 d_1\mid d_2\mid\cdots\mid d_t,\qquad d_i>0,
\]

let u(A)=#{i:d_i=1}. Then

\[
 u(A)=\min_{p\ {\rm prime}}\operatorname{rank}_{\mathbb F_p}A.
 \tag{16}
\]

Indeed, every prime preserves all unit factors. If the first nonunit is d_{u+1}, any prime dividing it divides all later factors, giving rank exactly u. If all factors are units, every prime has rank t.

Combining (15) and (16) yields the global conclusion

\[
 u(A_{r,e})\ge a_g^\theta(e).
 \tag{17}
\]

Equivalently, the Euler image contains a free direct summand of that rank which is primitive in the ambient lattice. The summand need not be canonical or theta-indexed.

**Ungraded qualification.** The unit count in (17) belongs to the Smith form of the entire map. It need not equal the sum of the unit counts of its graded blocks: diag(2,3) has global Smith form diag(1,6), while its two one-dimensional blocks separately have no unit factor. Therefore no graded rank bound follows from (15) alone. In contrast, the distant-ray theorem in §5 proves every graded block wholly saturated, so that theorem is unaffected.

There is also no assertion that the original displayed matrix has a maximal minor equal to ±1. Unimodular changes of integral bases may be required to expose the primitive direct summand.

## 10. Audit record and primary sources

The following are the source interfaces actually used or checked in this audit.

| Source | Check and result |
|---|---|
| CEFR, arXiv:1804.07736v4, §2.1 and §4 | Checked AR conventions and the diagonal proof, especially Theorems 37/41 and Corollary 43. Useful and compatible. The original rigidity assumption is replaced by the separately proved bounded Ext vanishing. |
| Speyer, arXiv:0710.3188, Theorem 1 | Checked infinite irreducible scope. Useful. Does not cover finite components; they are handled separately. |
| Berenstein–Rupel, arXiv:1308.2992, Theorem 2.11, §§7.1/7.3 | Checked the explicit cc-reduced hypothesis and principal ±I framing. Useful. Nonreduced cc is not licensed. |
| McNamara, arXiv:2112.04109, author PDF dated 8 December 2021, Theorems 1.1/18.2 | Checked actual all-prime cluster-monomial statement and integral convention. Useful for standard geometric symmetric parameters. Does not by itself license arbitrary KLR parameters. |
| Qin, arXiv:2003.13674v3, Theorem 9.5.1 and Corollary 9.5.3 | Checked the characteristic-zero common-triangular-basis identity in the primary HTML and available local primary text. Useful. It is a 2023 version, not a new 2026 theorem. |
| October 31 local finite-window theorem | Read the main mechanism and detector/finite-span sections. Used as established prior local input; this report does not claim a new complete audit of all appended historical reviews. |
| November 8 long-R formula and independent H/Feigin review | Read the full relevant files; checked the order/deficit conversion, label recursion, categorical dependence and finite-component qualification. |
| Wolfram computation | Correct Euler identities, Coxeter isometry, projective correction identity and the 3-Kronecker sharp bound passed. The first optional forward-identity diagnostic had been written incorrectly and returned nonzero; the corrected identity is explicitly recorded. The inverse identity passed both calls. |
| Retrieval failures | One WolframContext request returned an internal server error; the evaluator succeeded. The direct versioned Qin PDF fetch failed; the primary HTML and local text were available. No mathematical conclusion rests on the failed fetches. |

Primary links:

- https://arxiv.org/pdf/1804.07736
- https://arxiv.org/pdf/0710.3188
- https://pages.uoregon.edu/arkadiy/feiginchar.pdf
- https://petermc.net/maths/papers/clusterpart.pdf
- https://arxiv.org/html/2003.13674v3

Computation receipt: theta_round4/computation/generic_ext_adversarial_wolfram_receipt.json.

The general proof, rather than finite tests, establishes the Ext vanishing and integral saturation. The parent team's broader novelty search must distinguish this application from CEFR's earlier rigid-representation theorem and from the already established characteristic-zero finite-window result.

