"""Exact, classical tests of simultaneous freezing and positive theta transition.

The proof is in POSITIVE_INCOMING_THETA_TRANSITION.md. These computations
check labels, coefficient bookkeeping, repeated deletion, and complete finite
identities. They are validation, not evidence for a conjectural stopping rule.

For complete tests the enlarged quiver is acyclic and its label is negative.
The full polynomial is then a finite ordered product of initial-wall binomial
operators. This supplies an independently justified finite input, rather than
declaring a computed prefix complete. Lower-rank theta supports are bounded by
the known product of negative-unit theta functions in the acyclic category.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import permutations
from math import comb
from pathlib import Path
import json
import sys
import time

import sympy as sp

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from positive_incoming_check import extend, PrescribedIncoming
sys.path.insert(0, str(HERE.parent / 'computation'))
from incoming_recursion import IncomingSchur, box, sub, le, ibinom


def acyclic_order(B):
    return next((p for p in permutations(range(len(B)))
                 if all(B[p[i]][p[j]] >= 0
                        for i in range(len(B)) for j in range(i + 1, len(B)))), None)


class AcyclicSchur(IncomingSchur):
    """Use the independent acyclic closed form for the total operator."""
    def __init__(self, B, D):
        self.order = acyclic_order(B)
        assert self.order is not None
        super().__init__(B, D)

    def _c(self, a, m):
        ans = 1
        for pos, i in enumerate(self.order):
            top = -m[i] - sum(self.B[i][j] * a[j] for j in self.order[:pos])
            ans *= ibinom(top, a[i])
        return ans


@lru_cache(None)
def negative_theta_full(B, G):
    """Finite binomial expansion, with a proof of the bound, for G <= 0."""
    assert all(v <= 0 for v in G)
    order = acyclic_order(B)
    assert order is not None
    ans = {}
    p = [0] * len(B)

    def rec(pos, coeff):
        if pos == len(B):
            ans[tuple(p)] = coeff
            return
        i = order[pos]
        top = -G[i] - sum(B[i][j] * p[j] for j in order[:pos])
        assert top >= 0
        for p[i] in range(top + 1):
            rec(pos + 1, coeff * comb(top, p[i]))
        p[i] = 0

    rec(0, 1)
    return ans


@lru_cache(None)
def theta_prefix(B, D, G, cap):
    if acyclic_order(B) is not None:
        if all(v <= 0 for v in G):
            return {p: c for p, c in negative_theta_full(B, G).items() if le(p, cap)}
        return AcyclicSchur(B, D).theta_prefix(G, cap)
    return IncomingSchur(B, D).theta_prefix(G, cap)


def carrier_cap(B, G):
    """Known acyclic negative-unit product bound for an arbitrary label."""
    order = acyclic_order(B)
    assert order is not None
    cap = [0] * len(B)
    for pos, i in enumerate(order):
        cap[i] = max(-G[i], 0) - sum(B[i][j] * cap[j] for j in order[:pos])
    return tuple(cap)


@lru_cache(None)
def theta_full(B, D, G):
    return theta_prefix(B, D, G, carrier_cap(B, G))


def inverse_slice(B, D, G, J, S, r, cap, full=None):
    """Simultaneous coefficients from unique pointed triangular inversion."""
    C = tuple(tuple(B[i][j] for j in J) for i in J)
    E = tuple(D[i] for i in J)
    h0 = tuple(G[i] + sum(B[i][j] * k for j, k in zip(S, r)) for i in J)
    ambient_cap = [0] * len(B)
    for i, k in zip(J, cap):
        ambient_cap[i] = k
    for i, k in zip(S, r):
        ambient_cap[i] = k
    F = full if full is not None else theta_prefix(B, D, G, tuple(ambient_cap))
    branches = {}
    lower = {}
    for q in box(cap):
        root = [0] * len(B)
        for i, k in zip(J, q):
            root[i] = k
        for i, k in zip(S, r):
            root[i] = k
        coeff = F.get(tuple(root), 0)
        for v, b in branches.items():
            if le(v, q):
                coeff -= b * lower[v].get(sub(q, v), 0)
        if coeff:
            branches[q] = coeff
            h = tuple(h0[i] + sum(C[i][j] * q[j] for j in range(len(J)))
                      for i in range(len(J)))
            lower[q] = theta_prefix(C, E, h, sub(cap, q))
    return branches


@lru_cache(None)
def iterated_slice(B, D, G, nbase, r, cap, reverse):
    """Repeated single deletion, with residual r_T - w retained exactly."""
    if not r:
        return {(0,) * nbase: 1}
    s = len(r) - 1 if reverse else 0
    i = nbase + s
    keep = tuple(j for j in range(len(B)) if j != i)
    rr = tuple(k for j, k in enumerate(r) if j != s)
    C = tuple(tuple(B[a][b] for b in keep) for a in keep)
    E = tuple(D[a] for a in keep)
    one = inverse_slice(B, D, G, keep, (i,), (r[s],), cap + rr)
    result = defaultdict(int)
    for degree, b in one.items():
        v, w = degree[:nbase], degree[nbase:]
        assert le(w, rr)
        H = tuple(G[a] + B[a][i] * r[s]
                  + sum(B[a][j] * degree[k] for k, j in enumerate(keep))
                  for a in keep)
        child = iterated_slice(C, E, H, nbase, sub(rr, w), sub(cap, v), reverse)
        for u, d in child.items():
            result[tuple(a + c for a, c in zip(v, u))] += b * d
    return {q: d for q, d in result.items() if d}


def run_prefix(B, D, extras, g, base_cap, extra_cap):
    A, C, G, E = extend(B, extras, g, D)
    n = len(B)
    J, S = tuple(range(n)), tuple(range(n, len(C)))
    coefficients = []
    for r in box(extra_cap):
        simultaneous = inverse_slice(C, E, G, J, S, r, base_cap)
        forward = iterated_slice(C, E, G, n, r, base_cap, False)
        reverse = iterated_slice(C, E, G, n, r, base_cap, True)
        assert simultaneous == forward == reverse, (C, G, r, simultaneous, forward, reverse)
        assert all(d >= 0 for d in simultaneous.values())
        if not any(r):
            assert simultaneous == {(0,) * n: 1}
        coefficients.extend({'r': r, 'q': q, 'coefficient': d}
                            for q, d in sorted(simultaneous.items()))
    residual_witnesses = []
    if len(extras) > 1:
        for i in (n, len(C) - 1):
            keep = tuple(j for j in range(len(C)) if j != i)
            restcap = base_cap + tuple(k for j, k in enumerate(extra_cap) if n + j != i)
            one = inverse_slice(C, E, G, keep, (i,), (1,), restcap)
            residual_witnesses.extend({'deleted_index': i, 'remaining_degree': q, 'coefficient': c}
                                      for q, c in one.items() if any(q[n:]))
    return {'B': B, 'D': D, 'extras': extras, 'g': g,
            'base_cap': base_cap, 'extra_cap': extra_cap,
            'enlarged_B': C, 'enlarged_D': E, 'enlarged_g': G,
            'simultaneous_vs_both_deletion_orders': True,
            'all_branch_coefficients_nonnegative': True,
            'tested_coefficients': len(box(base_cap)) * len(box(extra_cap)),
            'nonzero_branch_coefficients': len(coefficients),
            'positive_intermediate_extra_offsets': residual_witnesses,
            'coefficients': coefficients}


def run_complete(B, D, extras, g):
    A, C, G, E = extend(B, extras, g, D)
    n = len(B)
    assert all(v <= 0 for v in G)
    full = negative_theta_full(C, G)
    cap = tuple(max(p[i] for p in full) for i in range(len(C)))
    ordinary_prefix_cap = tuple(min(c, 2 if i < n else 1) for i, c in enumerate(cap))
    independent = IncomingSchur(C, E).theta_prefix(G, ordinary_prefix_cap)
    assert independent == {p: c for p, c in full.items() if le(p, ordinary_prefix_cap)}
    left = defaultdict(int)
    for p, c in full.items():
        old = tuple(map(int, A * sp.Matrix(p)))
        left[(old, p[n:])] += c
    right = defaultdict(int)
    coefficients = []
    lower_labels = set()
    J, S = tuple(range(n)), tuple(range(n, len(C)))
    for r in box(cap[n:]):
        branches = inverse_slice(C, E, G, J, S, r, cap[:n], full)
        for q, d in branches.items():
            assert d > 0
            shift = tuple(q[i] + sum(extras[j][i] * r[j] for j in range(len(extras)))
                          for i in range(n))
            h = tuple(g[i] + sum(B[i][j] * shift[j] for j in range(n))
                      for i in range(n))
            lower_labels.add(h)
            F = theta_full(B, D, h)
            assert all(c > 0 for c in F.values())
            for p, c in F.items():
                root = tuple(a + b for a, b in zip(shift, p))
                right[(root, r)] += d * c
            coefficients.append({'r': r, 'q': q, 'shift': shift, 'label': h,
                                 'coefficient': d, 'lower_theta_support': len(F),
                                 'lower_theta_certified_cap': carrier_cap(B, h)})
    assert dict(left) == dict(right), (B, extras, g, left, right)
    direct = PrescribedIncoming(B, extras, D)
    smallcap = (2,) * n
    directF = direct.theta_prefix(g, smallcap)
    projected = defaultdict(lambda: sp.Integer(0))
    for (root, tag), c in right.items():
        if le(root, smallcap):
            projected[root] += c * sp.prod(t ** v for t, v in zip(direct.tags, tag))
    assert directF == {p: sp.expand(c) for p, c in projected.items() if c}
    return {'B': B, 'D': D, 'extras': extras, 'g': g,
            'enlarged_B': C, 'enlarged_D': E, 'enlarged_g': G,
            'complete_ambient_support_cap': cap,
            'complete_ambient_monomials': len(full),
            'complete_projected_tagged_monomials': len(left),
            'transition_terms': len(coefficients),
            'distinct_original_theta_labels': len(lower_labels),
            'complete_identity': True, 'independent_ordinary_recursion_prefix': True,
            'independent_prescribed_incoming_prefix': True,
            'finite_bound_source': 'acyclic ordered binomial product; negative-unit product bound',
            'coefficients': coefficients}


if __name__ == '__main__':
    start = time.time()
    prefixes = []
    specs = [
        (((0, 1), (-1, 0)), (1, 1), ((1, 1),), (-1, -1), (2, 2), (2,)),
        (((0, 1), (-1, 0)), (1, 1), ((1, 1), (1, 2)), (-1, -1), (2, 2), (1, 1)),
        (((0, 2), (-2, 0)), (1, 1), ((1, 1), (2, 1)), (1, -2), (2, 2), (1, 1)),
        (((0, 1), (-2, 0)), (2, 1), ((1, 1),), (-1, -1), (2, 2), (2,)),
        (((0, 1), (-2, 0)), (2, 1), ((1, 1), (2, 1)), (-1, 1), (1, 2), (1, 1)),
        (((0, 2, -2), (-2, 0, 2), (2, -2, 0)), (1, 1, 1),
         ((1, 1, 0), (0, 1, 1)), (-1, 1, -1), (1, 1, 1), (1, 1)),
    ]
    for spec in specs:
        prefixes.append(run_prefix(*spec))
    complete = []
    for spec in [
        (((0, 1), (-1, 0)), (1, 1), ((1, 1),), (-1, -1)),
        (((0, 1), (-1, 0)), (1, 1), ((1, 1), (1, 2)), (-1, -1)),
        (((0, 1), (-2, 0)), (2, 1), ((1, 1),), (-1, -1)),
    ]:
        complete.append(run_complete(*spec))
    data = {'status': 'PASS', 'prefix_cases': prefixes, 'complete_cases': complete,
            'simultaneous_slice_coefficients_checked': sum(x['tested_coefficients'] for x in prefixes),
            'complete_positive_transition_terms': sum(x['transition_terms'] for x in complete),
            'complete_tagged_monomial_identities': sum(x['complete_projected_tagged_monomials'] for x in complete),
            'seconds': time.time() - start,
            'scope': 'Exact validation of the general proof; no new theorem inferred from these examples.'}
    Path(__file__).with_suffix('.json').write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({k: data[k] for k in ('status', 'simultaneous_slice_coefficients_checked',
                                         'complete_positive_transition_terms',
                                         'complete_tagged_monomial_identities', 'seconds')}, indent=2))
