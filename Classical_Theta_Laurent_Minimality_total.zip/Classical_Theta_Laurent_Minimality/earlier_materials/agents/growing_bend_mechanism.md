# A finite rational certificate for growing maximal-bend words

2026-11-14. Independent general-mechanism branch, coordinated with `pump_novelty_finite_interface.md`. Classical principal-coefficient cluster theta functions only. No Li–Pan conclusion is used. The result below proves an explicit family of nonzero coefficients from finite rational data. It is a sufficient certificate, not a characterization of all infinite theta functions and not a decision procedure for Laurent finiteness.

## 1. Outcome and prior art boundary

The periodic-exponent restriction can be removed. A repeated word of initial walls has an integral linear momentum operator (S), and its accumulated root degree is

\[
p_N=R\sum_{r=0}^{N-1}S^r g,\qquad BR=S-I.
\]

Two invariant rational cones, finitely many bilinear inequalities, and one positive-chamber exit witness ensure that these recurrences are realized by genuine broken lines for every (N). The conclusion is

\[
\boxed{a_g(p_N)\ge1\quad\text{for all }N\ge1.}
\]

Each period increases total root degree by at least the word length, so the (p_N) are distinct even when the mutable exponents repeat. When (Sg\ne g), the theorem also permits growing mutable exponents; it does not impose (B\Delta=0).

Maximal-bend straightening and monodromy are established tools. Mandel, *Classification of Rank 2 Cluster Varieties*, §3.3 explicitly identifies maximally bent lines with straight lines for the canonical affine structure; §§3.4–3.6 develop the developing map, unipotent shear factors, monodromy, and winding. Here “rank 2” is the rank of the exchange matrix, not the number of mutable variables. These ideas are prior art. The candidate added interface here is the arbitrary-rank rational certificate, including flight-time order, a fixed positive-chamber exit, genericity, and an exact nonzero coefficient sequence. Independent broader novelty checking remains necessary before claiming a new theorem in a paper.

Primary references inspected in this branch:

- Mandel, SIGMA 15 (2019), 042, DOI 10.3842/SIGMA.2019.042, [published PDF](https://sigma-journal.com/2019/042/sigma19-042.pdf), especially §3.3, §§3.4–3.6. Useful; statements used are checked against the published text. No 2026 source is used.
- Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, [arXiv:1411.1394v2](https://arxiv.org/pdf/1411.1394), Theorem 1.13, Construction 2.11, Definition 3.1, Remark 3.2, Proposition 3.4, and Theorem 3.5. Used for positive scattering representatives, principal projection, legal local terms, formal finite-order interpretation, and chamber transport.

The proof below supplies the additional certificate argument; it is not attributed to those sources.

## 2. Conventions and signed maximal bends

Let (B\in\mathbb Z^{n\times n}) be a classical exchange matrix. Work in the initial-wall coordinates in which

\[
z_i=y_i x^{Be_i},\qquad
\vartheta_g=x^g\sum_{p\in\mathbb N^n}a_g(p)z^p,
\]

and the incoming wall is (H_i=\{q_i=0\}), with local function (1+z_i). Its available nonnegative binomial power is \(|m_i|\) for incoming mutable exponent (m). These are the project's usual principal-coefficient coordinates; in a differently normalized skew-symmetrizable lattice the normal coordinate must first be converted to this binomial-exponent coordinate.

Choose a nonempty word (i_1,\ldots,i_\ell) and prescribed signs \(\sigma_j\in\{-1,1\}\) for the corresponding incoming mutable coordinates. Define

\[
T_j=I+\sigma_jBe_{i_j}e_{i_j}^{T},\qquad
P_0=I,\quad P_j=T_j\cdots T_1,\quad S=P_\ell,
\]

\[
\lambda_j=e_{i_j}^{T}P_{j-1},\qquad
R=\sum_{j=1}^{\ell}\sigma_j e_{i_j}\lambda_j.
\tag{2.1}
\]

The most relevant specialization is \(\sigma_j=-1\) for every (j), giving the root task's (T_j=I-Be_{i_j}e_{i_j}^{T}).

At period momentum (v), the (j)-th incoming normal coordinate is \(\lambda_jv\). If \(\sigma_j\lambda_jv>0\), its highest binomial term adds

\[
r_j(v)e_{i_j},\qquad r_j(v)=\sigma_j\lambda_jv=|\lambda_jv|,
\]

and replaces (P_{j-1}v) by (P_jv). The highest binomial coefficient is one. Since (B_{ii}=0), each (T_j) fixes (H_{i_j}) pointwise and has determinant one. Telescoping gives

\[
\boxed{BR=S-I.}\tag{2.2}
\]

Thus the full-period recurrences are

\[
m_{r+1}=Sm_r,\qquad p_{r+1}=p_r+Rm_r,
\qquad(m_0,p_0)=(g,0).
\tag{2.3}
\]

No geometric conclusion follows from (2.3) alone. The rest of the certificate supplies that missing implication.

## 3. Unfolding and the exact flight-time conditions

For (N\ge1), fix an endpoint (Q) and put (Q_N=S^{-N}Q). Use backward time (s\ge0), so the unbent line is

\[
z(s)=Q_N+s g.
\]

On the piece following (r) complete periods and (j) bends in the next period, define

\[
\gamma_N(s)=P_jS^rz(s).
\tag{3.1}
\]

Forward time is (t=-s), and the forward velocity is \(-P_jS^rg\), as required. At a prescribed wall, the adjacent formulas agree because the shear fixes that wall pointwise. After all (N) periods, \(\gamma_N(0)=S^NQ_N=Q\).

Set

\[
v_r=S^rg,\qquad u_r=S^{r-N}Q.
\]

The prescribed encounter time is

\[
s_{r,j}=-\frac{\lambda_ju_r}{\lambda_jv_r}.
\tag{3.2}
\]

We need

\[
s_{r,1}>\cdots>s_{r,\ell}>s_{r+1,1}>
\cdots>s_{N-1,\ell}>0.
\tag{3.3}
\]

The sign requirements are

\[
\sigma_j\lambda_jv_r>0,\qquad
-\sigma_j\lambda_ju_r>0.
\tag{3.4}
\]

For consecutive walls inside a period, define

\[
\Phi_j(v,w)=\sigma_j\sigma_{j+1}
\bigl(\lambda_jv\,\lambda_{j+1}w-
\lambda_jw\,\lambda_{j+1}v\bigr),
\quad 1\le j<\ell.
\tag{3.5}
\]

With (3.4), inequality \(\Phi_j(v_r,u_r)>0\) is exactly (s_{r,j}>s_{r,j+1}). This follows by clearing the two positive quantities \(\sigma_j\lambda_jv_r\) and \(\sigma_{j+1}\lambda_{j+1}v_r\).

Across the period boundary, (u_{r+1}=Su_r) and (v_{r+1}=Sv_r). It is useful to use the *next* position variable (w=u_{r+1}), and define

\[
\Psi(v,w)=\sigma_\ell\sigma_1
\bigl(\lambda_\ell v\,\lambda_1w-
\lambda_\ell S^{-1}w\,\lambda_1Sv\bigr).
\tag{3.6}
\]

Then \(\Psi(v_r,u_{r+1})>0\) is exactly (s_{r,\ell}>s_{r+1,1}). This change of variable avoids imposing the unnecessary forward invariance (SE\subseteq E) on the position cone.

### Endpoint correction

The position cone should contain

\[
w_0=S^{-1}Q,
\]

not necessarily (Q). The exit check is therefore

\[
\boxed{Q=Sw_0>0.}\tag{3.7}
\]

Indeed (u_r=S^{-(N-r-1)}w_0), so backward invariance of the position cone suffices for every (N). Requiring (Q\in E) would discard valid certificates. The endpoint condition together with (3.4) forces the last chosen sign to be negative, as it should: the last wall is crossed into a positive last coordinate.

## 4. Finite rational certificate

Supply rational matrices and vectors

\[
V\in\mathbb Q^{n\times d},\quad
W\in\mathbb Q^{n\times e},\quad
A\in\mathbb Q_{\ge0}^{d\times d},\quad
C\in\mathbb Q_{\ge0}^{e\times e},
\]

\[
\alpha\in\mathbb Q_{\ge0}^{d},\quad
\beta\in\mathbb Q_{>0}^{e}.
\]

Let (D=\operatorname{cone}(V)) and (E=\operatorname{cone}(W)). Require:

1. \(\operatorname{rank}W=n\), \(SV=VA\), and \(S^{-1}W=WC\).
2. \(g=V\alpha\in\mathbb Z^n\setminus\{0\}\), and \(Q_0=SW\beta\in\mathbb Q_{>0}^n\).
3. Every row \(\sigma_j\lambda_jV\) is entrywise nonnegative. Every row \(-\sigma_j\lambda_jW\) is entrywise nonnegative and is not the zero row.
4. For each bilinear form (F\in\{\Phi_1,\ldots,\Phi_{\ell-1},\Psi\}), its generator table
   \[
   M_F=(F(V_a,W_b))_{a,b}
   \]
   is entrywise nonnegative.
5. The following finite Boolean support-orbit test succeeds for the listed nonnegative rows (h):
   \[
   h\in\{\sigma_j\lambda_jV:1\le j\le\ell\}
   \ \cup\ 
   \{(M_F\mathbf1)^T:F\}.
   \tag{4.1}
   \]

The support test starts at (J_0=\operatorname{supp}(\alpha)), and repeatedly sets

\[
J_{r+1}=\{a:\exists b\in J_r\text{ with }A_{ab}>0\}.
\tag{4.2}
\]

At each visited support (J_r), check that every row (h) has a positive entry in (J_r). Stop when a support repeats. There are at most (2^d\) possible supports, so this is a finite exact test. Because (A\) is nonnegative,

\[
J_r=\operatorname{supp}(A^r\alpha),
\]

and the test is equivalent to

\[
hA^r\alpha>0\quad\text{for every }r\ge0
\tag{4.3}
\]

for the finitely many rows (4.1). The first failed support is a witness that this particular certificate is insufficient. It is not evidence of Laurent finiteness.

All checks use rational matrix identities, ranks, signs, integrality, and a finite directed-support orbit. The code also verifies skew symmetry, or a supplied positive symmetrizer for a skew-symmetrizable exchange matrix.

### Useful simpler sufficient versions

The support test is automatic if all entries of the rows (4.1) are strictly positive. This allows (g) on a boundary of (D). In particular, an individual table entry (F(V_a,W_b)) is allowed to vanish: it suffices that each row sum of that table be positive, since positions lie in the interior of (E).

Alternatively, require (g\in\operatorname{relint}D), require all velocity rows and all bilinear tables to be nonnegative and nonzero, and choose (Q_0=S w_0>0) with (w_0\in\operatorname{int}E). Then all required inequalities are strict along the orbit. To justify this version: (S\) is invertible and (SD\subseteq D), so it preserves the span of (D) and maps its relative interior into its relative interior. Similarly (S^{-1}\) maps \(\operatorname{int}E\) into \(\operatorname{int}E\). Every relative interior point of a finitely generated cone has a representation with all generator coefficients positive. A nonnegative, nonzero generator table is strictly positive on a pair of such interior points.

The Boolean version is stronger because it also admits boundary momentum orbits that avoid all the relevant zero faces.

## 5. Certificate theorem and proof

**Theorem.** If the finite checks in §4 pass, then with (R,S,g) as above,

\[
a_g\left(R\sum_{r=0}^{N-1}S^rg\right)\ge1
\quad\text{for every }N\ge1.
\tag{5.1}
\]

Consequently the formal principal-coefficient theta expansion has infinite support.

**Proof.** Since (SV=VA), (v_r=S^rg=VA^r\alpha\in D). The support test for the velocity rows gives \(\sigma_j\lambda_jv_r>0\) for every (r,j). These values are positive integers, so every prescribed maximal term is available.

The vector (w_0=W\beta) lies in the interior of (E), because (W) has full row rank and \(\beta>0\). The endpoint (Q_0=Sw_0) is positive. There is an open neighborhood of (Q_0) in

\[
S\operatorname{int}(E)\cap\mathbb R_{>0}^n.
\tag{5.2}
\]

Choose (Q) in this neighborhood, and redefine (w_0=S^{-1}Q\in\operatorname{int}E\). Since (S^{-1}E\subseteq E\) and (S^{-1}\) is an invertible map, it sends the interior of (E) into the interior of (E). Thus every (u_r=S^{-(N-r-1)}w_0) lies in \(\operatorname{int}E\). The nonzero nonnegative position rows give \(-\sigma_j\lambda_ju_r>0\).

For any time-order form (F), the linear functional (w\mapsto F(v_r,w)) is nonnegative on (E). The support test for \((M_F\mathbf1)^T\) gives

\[
F(v_r,W\mathbf1)=(A^r\alpha)^TM_F\mathbf1>0.
\]

It is therefore nonzero on (E), and hence strictly positive at every interior point of (E). Apply this to (u_r) for the internal forms and to (u_{r+1}) for the cross-period form. Equations (3.4) and (3.3) follow.

The unfolded formulas (3.1) consequently define an actual continuous piecewise linear path, with positive flight lengths, an unbounded incoming segment of exponent (g), and endpoint (Q>0). At each designated wall it makes the prescribed maximal bend. The exponent and root-degree identities (2.3) hold. In particular,

\[
g+Bp_N=S^Ng.
\tag{5.3}
\]

It remains to justify genericity and the scattering completion, rather than treating this path as merely a numbers-game trajectory. These points are proved in §6. Once they hold, each selected maximal local term and every unselected constant local term has coefficient one. Positivity of the scattering representative prevents cancellation, so the coefficient of root degree (p_N) is at least one.

Every period has \(\ell\) positive integral root increments. Thus

\[
p_{N+1}-p_N=RS^Ng\in\mathbb N^n\setminus\{0\},
\qquad |p_N|_1\ge N\ell.
\]

The coefficient degrees are distinct and unbounded. This proves (5.1) and infinite support. ∎

## 6. Genericity, extra walls, and the principal lift

Fix (N), (r), and (j). At the designated bend, the position as a function of the endpoint is

\[
Q\longmapsto
P_{j-1}\left(I-\frac{v_r\lambda_j}{\lambda_jv_r}\right)
S^{r-N}Q.
\tag{6.1}
\]

The middle factor has rank (n-1), since \(\lambda_jv_r\ne0\). Its image is \(\ker\lambda_j\), and (P_{j-1}\) carries this hyperplane isomorphically onto (H_{i_j}). Therefore (6.1) is a surjective rational linear map onto the chosen wall. Genericity is not lost at an intermediate bend.

Every straight segment has an endpoint on one of its adjacent designated walls, and its velocity has nonzero normal component there. Let (J) be the rational linear span of a scattering joint, of dimension at most (n-2), and let (m) be that segment's mutable exponent. If the segment meets the joint, its endpoint on the chosen wall must lie in (J+\mathbb Rm\). The chosen wall (H_i) cannot be contained in this space: its dimension is (n-1), while (m\notin H_i\), and \(\dim(J+\mathbb Rm)\le n-1\). Pulling back along the surjection (6.1) gives a proper rational linear exceptional set of endpoints. The same argument covers the unbounded incoming ray and the last segment. Segments contained in an additional wall likewise impose a proper exceptional condition.

At any fixed root-degree truncation, only finitely many walls and joints are relevant. A generic endpoint within the open set (5.2) avoids all these exceptional sets. One may choose a separate endpoint for each (N): all endpoints lie in the initial positive chamber, where the coefficient is independent of this generic choice. Alternatively, countability of the rational exceptional sets permits one common endpoint for all (N); the proof does not need this stronger choice.

Every extra wall crossed by the resulting path is traversed using its constant term, so it produces no additional bend. At an initial wall, the local function in the initial-root direction remains (1+z_i). This can also be seen by passing to the quotient retaining only root degrees proportional to (e_i): the corresponding rank-one Lie algebra has no new scattering commutators. Equivalently, the standard cluster-diagram representative has no extra wall supported in an initial hyperplane, as in GHKK Remark 1.29. Taking a positive representative makes the selected coefficient contribution nonnegative and prevents cancellation.

Finally, principal scattering walls are invariant in the frozen directions (GHKK Construction 2.11). Starting from any frozen endpoint, integrate the full exponent on each segment backwards. Its mutable projection is the path just constructed; its frozen exponent starts at zero and increases by the selected root increments. The lifted broken line thus has initial exponent \((g,0)\) and final exponent \((g+Bp_N,p_N)\). Distinct (p_N) give distinct principal monomials even if (Bp_N) repeats. No analytic summation of infinitely many paths is assumed; each coefficient is justified in its finite formal truncation.

## 7. Mechanism check at the parabolic boundary

The sibling branch supplies a rational cone family for the uniform cyclic matrix

\[
B_m=\begin{pmatrix}0&m&-m\\-m&0&m\\m&-m&0\end{pmatrix},\qquad
m\ge3,
\]

with word (1,2,3), all signs negative. The same general certificate applies to the growing label

\[
g=(-2,m,-1).
\]

Write (H=m^2(m-3)), (g_0=(-1,m-1,-1)^T\), (v=(-1,1,0)^T\), and

\[
V=[g_0,v,(S-I)v],\qquad
w_0=S^{-1}(1,1,1)^T,
\]

\[
W=[w_0,(S^{-1}-I)w_0,(S^{-1}-I)^2w_0].
\]

The invariance matrices are

\[
A=\begin{pmatrix}1&0&0\\0&1&H\\0&1&H+1\end{pmatrix},\qquad
C=\begin{pmatrix}1&0&0\\1&1&H\\0&1&H+1\end{pmatrix}.
\]

One has

\[
\det W=3m^5(m-2)>0,
\qquad \det V=-m(m-3)(m-2).
\]

At (m=3), (V) has rank two and its third column is (3g_0). This is permitted: the momentum cone need not be full dimensional. Some time-order generator entries vanish, but every row sum is positive, while all position signs are strict. Since the positions lie in the interior of (E), all actual flight inequalities remain strict. Requiring strictness on every generator pair would incorrectly discard this boundary case.

For an exact exit witness, let

\[
M=1+\|SW_2\|_\infty+\|SW_3\|_\infty,
\quad\epsilon=\frac1{4M},\quad
\beta=(1,\epsilon,\epsilon^2)^T,
\]

where (W_2,W_3) denote the second and third columns. Then (SW_1=(1,1,1)^T) and the coordinate perturbation has absolute value less than (1/4), so (SW\beta>0).

At (m=3), the entire growth can be written without eigenvectors:

\[
S^Ng=g+3Ng_0,
\]

\[
\boxed{p_N=\left(\frac{N(3N+1)}2,
\frac{3N(N+1)}2,
\frac{N(3N+5)}2\right),\qquad a_{(-2,3,-1)}(p_N)\ge1.}
\]

This is a mechanism check that the new certificate genuinely admits nonperiodic momentum and nonlinear root-degree growth. It is not presented as an independent special-case project. Its label is outside the earlier initial-coordinate domination region (g\le(-1,2,-1)), but no claim is made that it escapes every mutation-transported consequence of older results.

## 8. Exact verification, failed formulations, and limits

Executable: `growing_bend_certificate.py`. Entry point:

```python
validate_certificate(B, word, V, W, AD, AE, alpha, beta,
                     signs=None, symmetrizer=None)
```

Indices in `word` are zero based. `signs=None` means every incoming chosen normal coordinate is negative. `AD` and `AE` are the matrices (A,C\). The exact result record is `growing_bend_certificate.json`.

The run checks the two cone identities symbolically for every (m\ge3). All 45 sign and time-table entries become polynomials with nonnegative coefficients after (m=t+3). The relevant row sums are strictly positive already at (t=0). These are uniform algebraic checks, not a finite numerical extrapolation. Four numerical certificate instances additionally check exact unfolded trajectories through (N=1,2,4,8,16), totaling 372 designated bends. The numerical checks are convention diagnostics; the theorem and symbolic inequalities establish all (N\).

The sibling branch independently checked its two residual matrices, determinant formulas, and 45 shifted polynomials using the Wolfram computation plugin; see `uniform_growth_wolfram_receipt.json`. This branch's implementation is independent SymPy exact arithmetic.

Corrections recorded during exploration:

- **Rejected:** infinite signed momentum play alone implies theta nonfiniteness. It does not control ordered positive flights or the final chamber.
- **Corrected:** require (Q\in E). The right general exit condition is (S^{-1}Q\in\operatorname{int}E), equivalently (Q\in S\operatorname{int}E\).
- **Corrected:** require (SE\subseteq E) for a cross-period inequality. Using (3.6) requires only backward invariance.
- **Corrected:** demand every bilinear generator entry be strictly positive. Nonnegative tables with suitable row visibility suffice; the parabolic (m=3\) case requires this relaxation.
- **Not asserted:** spectral radius greater than one is necessary. The parabolic case has polynomial growth, and the periodic specialization has fixed momentum.
- **Not asserted:** (B\) must be singular. The abstract certificate has no kernel assumption. This branch does not claim an independently constructed invertible example, because further example accumulation is not the current main gap.
- **Not asserted:** every infinite theta label admits such a rational cone certificate, or the search for certificates terminates when none exists.

Necessary conditions *for this particular prescribed maximal word construction* include legal nonzero signed normal coordinates, positive encounter times in the prescribed order, and a genuine positive-chamber exit. The invariant cones and finite generator tests are sufficient methods for proving these conditions simultaneously; they are not claimed necessary for the existence of a broken line or for theta infinite support in general.

This branch closes its assigned infinite-side mechanism and hands resources back to the finite Laurent-support stopping problem. It does not solve that remaining finite-side problem.
