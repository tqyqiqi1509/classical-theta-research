"""Integral Euler-image ranks via a fixed acyclic graphic partition kernel.

Independent of the large-degree Schur multiplication implementation. All
dependence on r lies in coefficient-extraction positions; the kernel depends
only on B and the fixed root b. Derived in agents/modular_basis_minimality.md.
No division by Weyl group orders is used. Coefficients are exact integers.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import permutations,product
from math import comb
from pathlib import Path
import argparse,json,time
from modular_euler_theta_probe import rectangle_parts,schur_action,rank_rational,rank_mod


def parity(perm):
    return (-1)**sum(perm[i]>perm[j] for i in range(len(perm)) for j in range(i+1,len(perm)))


class GraphicEuler:
    def __init__(self,B,r,b):
        self.B=tuple(map(tuple,B));self.r=tuple(r);self.b=tuple(b)
        self.n=len(B);self.size=sum(b)
        assert all(B[i][j]<=0 for i in range(self.n) for j in range(i+1,self.n))
        self.offset=[];z=0
        for bi in b:self.offset.append(z);z+=bi
        self.edges=[[] for _ in range(self.size)]
        for i in range(self.n):
            for j in range(i+1,self.n):
                m=-B[i][j]
                if not m:continue
                for a in range(b[i]):
                    for c in range(b[j]):self.edges[self.offset[i]+a].append((self.offset[j]+c,m))
        self.rho=tuple(r[i]-b[i]-sum(-B[i][j]*(r[j]-b[j]) for j in range(i+1,self.n)) for i in range(self.n))
        self.deficit=sum(b[i]*self.rho[i] for i in range(self.n))
        self.perms=[tuple((p,parity(p)) for p in permutations(range(bi))) for bi in b]
        self.partition=lru_cache(None)(self._partition)
        self.integral=lru_cache(None)(self._integral)
        self.gram=lru_cache(None)(self._gram)

    def _partition(self,eta):
        if sum(eta):return 0
        # Complete bipartite two-row shortcut: exact vector-partition formula.
        if self.n==2 and self.b[0]==2:
            m=-self.B[0][1];cols=eta[2:];rows=tuple(-x for x in eta[:2])
            if min(rows+cols,default=0)<0 or sum(rows)!=sum(cols):return 0
            if m==0:return int(not any(eta))
            weights=[tuple(comb(m+x-1,m-1)*comb(m+c-x-1,m-1) for x in range(c+1)) for c in cols]
            suffix=[sum(cols[i:]) for i in range(len(cols)+1)]
            @lru_cache(None)
            def distribute(j,left):
                if j==len(cols):return int(left==0)
                lo=max(0,left-suffix[j+1]);hi=min(cols[j],left)
                return sum(weights[j][x]*distribute(j+1,left-x) for x in range(lo,hi+1))
            return distribute(0,rows[0])
        # General acyclic graphic kernel. Process vertices in topological order.
        @lru_cache(None)
        def visit(v,incoming):
            if v==self.size:return 1
            need=incoming[0]-eta[v]
            if need<0:return 0
            dests=self.edges[v]
            if not dests:return visit(v+1,incoming[1:]) if need==0 else 0
            tail=list(incoming[1:]);ans=0
            def allocate(j,left,weight):
                nonlocal ans
                if j==len(dests):
                    if left==0:ans+=weight*visit(v+1,tuple(tail))
                    return
                dest,m=dests[j];k=dest-v-1
                choices=(left,) if j==len(dests)-1 else range(left+1)
                for amount in choices:
                    tail[k]+=amount
                    allocate(j+1,left-amount,weight*comb(m+amount-1,m-1))
                    tail[k]-=amount
            allocate(0,need,1)
            return ans
        return visit(0,(0,)*self.size)

    def _integral(self,nu):
        if sum(map(sum,nu))!=self.deficit:return 0
        ans=0
        for pp in product(*self.perms):
            eta=[];sgn=1
            for i,(perm,sign) in enumerate(pp):
                sgn*=sign
                eta.extend(self.rho[i]+perm[a]-a-nu[i][perm[a]] for a in range(self.b[i]))
            ans+=sgn*self.partition(tuple(eta))
        return ans

    def _gram(self,lam,mu):
        expansions=[schur_action(self.r[i],self.b[i],lam[i],mu[i]) for i in range(self.n)]
        ans=0
        for term in product(*expansions):
            nu=tuple(t[0] for t in term);c=1
            for t in term:c*=t[1]
            ans+=c*self.integral(nu)
        return ans

    def states(self):
        delta=self.deficit
        spaces=[tuple(p for p in rectangle_parts(self.b[i],min(self.r[i]-self.b[i],delta)) if sum(p)<=delta) for i in range(self.n)]
        groups=defaultdict(list)
        def generate(i,left,prefix):
            if i==self.n:
                groups[delta-left].append(tuple(prefix));return
            for p in spaces[i]:
                d=sum(p)
                if d>left:break
                generate(i+1,left-d,prefix+[p])
        generate(0,delta,[])
        return groups

    def ranks(self,primes=(2,3,5,7)):
        if self.deficit<0:return {0:0,**{p:0 for p in primes}},[]
        groups=self.states();ans={p:0 for p in (0,)+tuple(primes)};blocks=[]
        for d in range(self.deficit//2+1):
            rows=groups[self.deficit-d];cols=[]
            for lam in groups[d]:
                col={i:self.gram(lam,mu) for i,mu in enumerate(rows)}
                col={i:c for i,c in col.items() if c}
                cols.append(col)
            rr={0:rank_rational(cols),**{p:rank_mod(cols,p) for p in primes}}
            mul=1 if 2*d==self.deficit else 2
            for p,val in rr.items():ans[p]+=mul*val
            blocks.append({'degree':d,'dimensions':[len(rows),len(cols)],'ranks':rr,'mirror_multiplicity':mul,'entries':sum(map(len,cols))})
        return ans,blocks


def main():
    p=argparse.ArgumentParser();p.add_argument('--N',type=int,default=6);p.add_argument('--calibrate',action='store_true')
    args=p.parse_args();start=time.time();records=[]
    if args.calibrate:
        from modular_euler_theta_probe import euler_ranks
        tasks=[([[0,-m],[m,0]],r,b) for m in [1,2,3] for r in [(3,3),(4,3),(5,4)] for b in [(1,1),(2,1),(1,2),(2,2),(2,3)]]
        tasks += [([[0,-2,-1],[2,0,-1],[1,1,0]],(3,3,2),b) for b in [(1,1,1),(1,2,1),(2,1,1)]]
    else:
        tasks=[([[0,-3],[3,0]],(5*args.N,3*args.N),(2,3))]
    for B,r,b in tasks:
        G=GraphicEuler(B,r,b);rr,blocks=G.ranks();rec={'B':B,'r':r,'b':b,'deficit':G.deficit,'ranks':rr,'blocks':blocks,'kernel_cache':str(G.partition.cache_info()),'integral_cache':str(G.integral.cache_info())}
        if args.calibrate:
            expected,size,nnz=euler_ranks(B,r,b)
            rec['independent_schur_match']=rr==expected
            assert rr==expected,(rec,expected)
        records.append(rec)
        print(json.dumps({'r':r,'b':b,'ranks':rr,'seconds':time.time()-start}),flush=True)
    tag='calibration' if args.calibrate else 'N'+str(args.N)
    Path(__file__).with_name('graphic_kernel_euler_'+tag+'.json').write_text(json.dumps({'seconds':time.time()-start,'records':records},indent=2))

if __name__=='__main__':main()
