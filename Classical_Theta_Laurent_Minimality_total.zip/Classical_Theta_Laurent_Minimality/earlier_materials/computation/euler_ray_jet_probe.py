"""Fixed-degree modular Euler ranks along nonresonant and resonant rays.

These compare exact ranks in characteristic zero and several primes. A failure
of eventual equality would obstruct one specific proposed bridge, not by itself
disprove strong theta minimality. No finite set of equalities proves stability.
"""
from pathlib import Path
from itertools import product
import json,time
from modular_euler_theta_probe import euler_ranks_sparse

out=Path(__file__).with_suffix('.json');start=time.time();records=[]
B=[[0,-3],[3,0]]
for nu,cap,values in [((3,-2),(2,2),range(1,13)),((4,-3),(2,3),range(1,7))]:
    generic=all(sum(x*y for x,y in zip(nu,b))!=0 for b in product(*(range(q+1) for q in cap)) if any(b))
    for N in values:
        g=tuple(N*x for x in nu);r=(-g[0]-3*g[1],-g[1]);rows=[]
        for b in product(*(range(min(cap[i],r[i])+1) for i in range(2))):
            rr,size,entries=euler_ranks_sparse(B,r,b)
            rows.append({'b':b,'ranks':rr,'ring_dimension':size,'entries':entries})
        differences=[q for q in rows if any(x!=q['ranks'][0] for x in q['ranks'].values())]
        rec={'nu':nu,'cap':cap,'generic_for_cap':generic,'N':N,'g':g,'r':r,'rows':rows,'differences':differences}
        records.append(rec)
        out.write_text(json.dumps({'elapsed_seconds':time.time()-start,'records':records},indent=2))
        print(json.dumps({'nu':nu,'N':N,'generic':generic,'differences':differences,'seconds':time.time()-start}),flush=True)
