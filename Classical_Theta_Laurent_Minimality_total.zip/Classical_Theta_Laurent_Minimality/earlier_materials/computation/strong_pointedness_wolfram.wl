ClearAll["Global`*"];
m = Table[If[i < j, Symbol["a" <> ToString[i] <> ToString[j]], 0], {i, 5}, {j, 5}];
orthants = Tuples[{0, 1}, 5];
determinants = (Factor[Det[IdentityMatrix[5] - m.DiagonalMatrix[#]]] & /@ orthants);
inverseResiduals = (With[{a = m.DiagonalMatrix[#]}, Simplify[(IdentityMatrix[5] - a).(IdentityMatrix[5] + Total[Table[MatrixPower[a, k], {k, 1, 4}]]) - IdentityMatrix[5]]] & /@ orthants);
positiveCandidates = Select[Partition[#, 3] & /@ Tuples[{0, 1, 2}, 9], Abs[Det[#]] == 1 &];
positiveInverse = Select[positiveCandidates, Min[Flatten[Inverse[#]]] >= 0 &];
<|"Orthants" -> Length[orthants], "UnimodularAll" -> And @@ (# == 1 & /@ determinants), "InverseAll" -> And @@ (Flatten[#] == ConstantArray[0, 25] & /@ inverseResiduals), "Nonnegative3by3Candidates" -> 3^9, "UnimodularCandidates" -> Length[positiveCandidates], "NonnegativeInverseCount" -> Length[positiveInverse], "AllArePermutation" -> And @@ (Sort[Flatten[#]] == Join[ConstantArray[0, 6], ConstantArray[1, 3]] && Total[#] == {1, 1, 1} && Total[Transpose[#]] == {1, 1, 1} & /@ positiveInverse)|>