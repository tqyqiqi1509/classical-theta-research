"""Exact all-prime stress test of the generic-window saturation mechanism.

This extends a fixed kernel into growing Schur windows. It is not a proof
from examples: logs retain every graded block and its nonunit invariants.
"""
from pathlib import Path
import time,json,argparse
from sympy import Matrix,ZZ
from sympy.matrices.normalforms import smith_normal_form
from graphic_kernel_euler import GraphicEuler

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--lo',type=int,default=8);parser.add_argument('--hi',type=int,default=14)
    args=parser.parse_args();start=time.time();records=[];out=Path(__file__).with_suffix('.json')
    for N in range(args.lo,args.hi+1):
        B=[[0,-3],[3,0]];r=(5*N,3*N);b=(2,3)
        G=GraphicEuler(B,r,b);groups=G.states();blocks=[];rank=0;units=0
        for d in range(G.deficit//2+1):
            t=time.time();mat=Matrix([[G.gram(lam,mu) for lam in groups[d]] for mu in groups[G.deficit-d]])
            snf=smith_normal_form(mat,domain=ZZ)
            fs=[abs(int(snf[i,i])) for i in range(min(snf.shape)) if snf[i,i]]
            mult=1 if 2*d==G.deficit else 2;rank+=mult*len(fs);units+=mult*sum(a==1 for a in fs)
            block={'degree':d,'shape':list(mat.shape),'rank':len(fs),'nonunit':[a for a in fs if a>1],'mirror':mult,'seconds':time.time()-t}
            blocks.append(block)
            print(json.dumps({'N':N,**block}),flush=True)
            out.write_text(json.dumps({'seconds':time.time()-start,'complete':records,'in_progress':{'N':N,'blocks':blocks}},indent=2))
        rec={'N':N,'r':r,'b':b,'g':[4*N,-3*N],'deficit':G.deficit,'rank0':rank,'unit_rank':units,'theta':13*N,'blocks':blocks}
        records.append(rec);out.write_text(json.dumps({'seconds':time.time()-start,'complete':records},indent=2))
        print(json.dumps({'N':N,'rank':rank,'units':units,'theta':13*N,'total_seconds':time.time()-start}),flush=True)

if __name__=='__main__':main()
