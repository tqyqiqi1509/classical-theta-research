"""Reproducible exact diagnostic for the integral finite-difference lemma.

The lemma is proved in agents/modular_basis_minimality.md; these checks only
verify indexing, signs, and the proposed Euler boundary threshold.
"""
from math import comb
from pathlib import Path
import json
from sympy import Matrix
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ


def h(m,t):
    return comb(m+t-1,m-1) if t>=0 else 0


def smith_diagonal(A):
    D=smith_normal_form(A,domain=ZZ)
    return [abs(int(D[i,i])) for i in range(min(D.shape)) if D[i,i]]


def main():
    toeplitz=0;euler=0
    for m in range(1,9):
        for a in range(1,11):
            for b in range(1,11):
                if max(a,b)<m:continue
                for s in range(15):
                    d=smith_diagonal(Matrix([[h(m,s+i-j) for j in range(b)] for i in range(a)]))
                    assert all(x==1 for x in d),(m,a,b,s,d)
                    assert len(d)==min(a,b,max(m,b-s)),(m,a,b,s,d)
                    toeplitz+=1
    for m in range(2,7):
        for R in range(2,31):
            for S in range(2,21):
                D=m*(S-1);delta=R+S-2-D
                if delta<2*m-3 or min(R,S)<m:continue
                for q in range(delta+1):
                    J=range(max(0,q-R+1),min(q,S-1)+1)
                    K=range(max(0,q+D-R+1),min(q+D,S-1)+1)
                    d=smith_diagonal(Matrix([[h(m,k-j) for j in J] for k in K]))
                    assert all(x==1 for x in d),(m,R,S,delta,q,d)
                    euler+=1
    result={"toeplitz_matrices_verified":toeplitz,"euler_graded_blocks_verified":euler,
            "nonunit_invariants":0,"rank_formula_agreement":True,
            "wolfram_symbolic_check":{"orders":[1,2,3,4,5,6],"determinants":[1,1,1,1,1,1],
             "command":"Table[FullSimplify[Det[Table[Binomial[m+z+i-j-1,m-1],{i,0,m-1},{j,0,m-1}]], Assumptions->Element[z,Integers] && z>=m],{m,1,6}]"}}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))


if __name__=='__main__':main()
