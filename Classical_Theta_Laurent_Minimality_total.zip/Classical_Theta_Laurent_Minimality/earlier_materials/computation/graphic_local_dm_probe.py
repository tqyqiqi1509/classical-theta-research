"""Exact tests of integral local-DM Hankel saturation, with explicit windows.

The rows are ALL lattice points in epsilon-Z(X), determined by exact
capacitated integral flows after clearing the denominator of epsilon.
The columns are translations beta>=0, |beta|<=D=|X|-rank(X).
Every entry is evaluated by the original directed graphic partition
kernel, at a point proved to lie in the same chamber by all cut signs.
Thus these test a general finite-window mechanism, not just Euler ranks.
"""
from itertools import product,combinations
from math import prod
from pathlib import Path
import json,random,time
from sympy import Matrix,ZZ
from sympy.matrices.normalforms import smith_normal_form
from graphic_kernel_euler import GraphicEuler


def simplex(s,D):
    return [p for p in product(range(D+1),repeat=s) if sum(p)<=D]


def cutsets(n):
    # One representative of each complementary pair is sufficient.
    return [tuple(i for i in range(n) if mask>>i&1) for mask in range(1,1<<(n-1))]


def build_kernel(B,b):
    return GraphicEuler(B,tuple(max(1,x) for x in b),b)


def feasible_bounded_flow(edges,demands,Q):
    n=len(edges);source=n;sink=n+1;size=n+2
    cap=[[0]*size for _ in range(size)]
    for i,ed in enumerate(edges):
        for j,m in ed:cap[i][j]+=m*Q
    required=0
    for i,d in enumerate(demands):
        if d<0:cap[source][i]=-d;required-=d
        else:cap[i][sink]=d
    sent=0
    while sent<required:
        parent=[-1]*size;parent[source]=source;queue=[source]
        for v in queue:
            for w in range(size):
                if cap[v][w] and parent[w]<0:
                    parent[w]=v;queue.append(w)
            if parent[sink]>=0:break
        if parent[sink]<0:return False
        amount=required-sent;w=sink
        while w!=source:
            v=parent[w];amount=min(amount,cap[v][w]);w=v
        w=sink
        while w!=source:
            v=parent[w];cap[v][w]-=amount;cap[w][v]+=amount;w=v
        sent+=amount
    return True


def controls(G):
    n=G.size;s=n-1;Q=2**(n+2)
    eps=[2**i for i in range(s)];eps.append(-sum(eps))
    outgoing=[sum(m for j,m in ed) for ed in G.edges]
    incoming=[0]*n
    for i,ed in enumerate(G.edges):
        for j,m in ed:incoming[j]+=m
    rows=[]
    for first in product(*(range(1-incoming[i],outgoing[i]+1) for i in range(s))):
        eta=tuple(first)+(-sum(first),)
        if not -incoming[-1]<=eta[-1]<outgoing[-1]:continue
        demands=[eps[i]-Q*eta[i] for i in range(n)]
        if not feasible_bounded_flow(G.edges,demands,Q):continue
        rows.append(eta)
    # Matrix tree theorem independently checks the shifted-zonotope cardinality.
    lap=[[0]*n for _ in range(n)]
    for i,ed in enumerate(G.edges):
        for j,m in ed:
            lap[i][i]+=m;lap[j][j]+=m;lap[i][j]-=m;lap[j][i]-=m
    trees=int(Matrix([row[:-1] for row in lap[:-1]]).det())
    assert len(rows)==trees,(len(rows),trees)
    return rows,eps,Q,trees


def choose_ray(G,cuts,rng):
    for _ in range(10000):
        ray=[0]*G.size
        for i,ed in enumerate(G.edges):
            for j,m in ed:
                f=rng.randrange(1,8)
                ray[i]-=f;ray[j]+=f
        if all(sum(ray[i] for i in S) for S in cuts):return tuple(ray)
    raise RuntimeError('No cut-generic interior ray found')


def run(B,b,seed):
    G=build_kernel(B,b);n=G.size;s=n-1
    E=sum(m for ed in G.edges for j,m in ed);D=E-s
    rows,eps,Q,trees=controls(G)
    cols=[tuple(p)+(-sum(p),) for p in simplex(s,D)]
    cuts=cutsets(n);ray=choose_ray(G,cuts,random.Random(seed))
    N=1
    for S in cuts:
        vr=abs(sum(ray[i] for i in S))
        bound=max(abs(sum(a[i]-z[i] for i in S)) for a in rows for z in cols)
        N=max(N,1+bound//vr)
    def value(a,z):
        eta=tuple(N*ray[i]+a[i]-z[i] for i in range(n))
        assert all(sum(eta[i] for i in S)*sum(ray[i] for i in S)>0 for S in cuts)
        return G.partition(eta)
    matrix=Matrix([[value(a,z) for z in cols] for a in rows])
    normal=smith_normal_form(matrix,domain=ZZ)
    factors=[abs(int(normal[i,i])) for i in range(min(normal.shape)) if normal[i,i]]
    return {'B':B,'b':b,'vertices':n,'edges_with_multiplicity':E,'rank_X':s,'polynomial_degree_bound':D,
            'epsilon_numerator':eps,'epsilon_denominator':Q,'control_rows':rows,'translation_columns':cols,
            'spanning_trees':trees,'ray':ray,'scale':N,'shape':list(matrix.shape),'smith_factors':factors,
            'all_nonzero_smith_unit':all(x==1 for x in factors),'partition_cache':str(G.partition.cache_info())}


def main():
    tasks=[([[0,-1],[1,0]],(2,k)) for k in [2,3,4]]
    tasks += [([[0,-2],[2,0]],(2,2))]
    tasks += [([[0,-a,-c],[a,0,-b],[c,b,0]],(1,1,1)) for a,b,c in [(1,1,1),(2,1,1),(2,2,1),(2,2,2),(3,1,2)]]
    tasks += [([[0,-1,-1,-1],[1,0,-1,-1],[1,1,0,-1],[1,1,1,0]],(1,1,1,1))]
    records=[];start=time.time();out=Path(__file__).with_suffix('.json')
    for i,(B,b) in enumerate(tasks):
        rec=run(B,b,14110400+i);records.append(rec)
        out.write_text(json.dumps({'seconds':time.time()-start,'completed':len(records),'planned':len(tasks),'records':records},indent=2))
        print(json.dumps({k:rec[k] for k in ['b','shape','scale','smith_factors','all_nonzero_smith_unit']}),flush=True)
        assert rec['all_nonzero_smith_unit'],rec


if __name__=='__main__':main()
