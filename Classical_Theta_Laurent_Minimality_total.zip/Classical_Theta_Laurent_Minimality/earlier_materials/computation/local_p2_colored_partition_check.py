import json,time,sys
from pathlib import Path
from collections import Counter
from math import comb
sys.path.insert(0,str(Path(__file__).resolve().parent))
from local_p2_algebraicity_probe import theta_total
from incoming_recursion import IncomingSchur

N=int(sys.argv[1]) if len(sys.argv)>1 else 12
started=time.time();states={frozenset()}; counts=Counter({(0,0,0):1}); sizes=[1]
for n in range(1,N+1):
 nxt=set()
 for st in states:
  can={(0,0,0)} if not st else set()
  for v in st:
   for i in range(3):
    w=tuple(v[j]+(i==j) for j in range(3))
    if w not in st: can.add(w)
  for w in can:
   if all(w[i]==0 or tuple(w[j]-(i==j) for j in range(3)) in st for i in range(3)):
    nxt.add(st|{w})
 states=nxt;sizes.append(len(states))
 for st in states:
  colors=[0,0,0]
  for w in st:colors[sum(w)%3]+=1
  counts[tuple(colors)]+=1
inv=[1]+[0]*(N//3)
for k in range(1,N//3+1):
 q=[0]*(N//3+1)
 for j in range(min(3*k,(N//3)//k)+1):q[j*k]=(-1)**j*comb(3*k,j)
 inv=[sum(inv[j]*q[i-j]for j in range(i+1))for i in range(N//3+1)]
B=((0,3,-3),(-3,0,3),(3,-3,0));a=theta_total(IncomingSchur(B),(-1,0,0),N)
errs=[]
for p,c in a.items():
 r=sum(inv[k]*counts[tuple(v-k for v in p)] for k in range(min(p)+1))
 if r!=c:errs.append({'p':p,'theta':c,'reduced':r})
result={'N':N,'B':B,'g':[-1,0,0],'plane_partition_counts':sizes,'inverse_central_coefficients':inv,'root_coefficient_comparisons':len(a),'nonzero_theta_terms':sum(c!=0 for c in a.values()),'mismatches':errs[:20],'status':'PASS'if not errs else'FAIL','seconds':time.time()-started,'scope':'Independent full multidegree calibration of the proposed all-orders geometric identity; finite agreement is not its proof.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
