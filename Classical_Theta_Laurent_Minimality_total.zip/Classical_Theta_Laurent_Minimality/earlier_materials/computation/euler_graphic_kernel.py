"""Integral graphic-kernel moments for the modular Euler image.

Independent of the large-degree Schur multiplication implementation.  The
formula is proved in agents/modular_basis_minimality.md.  It computes exact
intersection pairings, not a theta-minimality certificate.
"""
from functools import lru_cache
from itertools import permutations, product
from math import comb


def permutation_sign(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1,len(p)))


def compositions(total, length):
    if length == 0:
        if total == 0:
            yield ()
        return
    if length == 1:
        yield (total,)
        return
    for x in range(total+1):
        for tail in compositions(total-x,length-1):
            yield (x,)+tail


class GraphicEulerMoments:
    def __init__(self, B, r, b):
        self.B=tuple(map(tuple,B));self.r=tuple(r);self.b=tuple(b)
        self.n=len(r)
        assert all(B[i][j]<=0 for i in range(self.n) for j in range(i+1,self.n))
        assert all(0<=b[i]<=r[i] for i in range(self.n))
        self.vertices=tuple((i,a) for i in range(self.n) for a in range(b[i]))
        self.index={v:k for k,v in enumerate(self.vertices)}
        self.outgoing=tuple(tuple((self.index[j,c],-B[i][j])
                           for j in range(i+1,self.n) for c in range(b[j]) if B[i][j])
                           for i,a in self.vertices)
        self.rho=tuple(r[i]-b[i]-sum(-B[i][j]*(r[j]-b[j]) for j in range(i+1,self.n))
                       for i in range(self.n))
        self.delta=sum(b[i]*self.rho[i] for i in range(self.n))
        self.partition_count=lru_cache(None)(self._partition_count)
        self.schur_moment=lru_cache(None)(self._schur_moment)

    def _partition_count(self, eta):
        if sum(eta):return 0
        # Specialized fixed 2-by-3 contingency-table sum; exact integer weights.
        if self.n==2 and self.b==(2,3):
            m=-self.B[0][1]
            if m==0:return int(not any(eta))
            rows=(-eta[0],-eta[1]);cols=eta[2:]
            if min(rows+cols)<0 or sum(rows)!=sum(cols):return 0
            ans=0
            for t0 in range(max(0,rows[0]-cols[1]-cols[2]),min(cols[0],rows[0])+1):
                for t1 in range(max(0,rows[0]-t0-cols[2]),min(cols[1],rows[0]-t0)+1):
                    t=(t0,t1,rows[0]-t0-t1)
                    term=1
                    for k,c in zip(t,cols):
                        term*=comb(m+k-1,m-1)*comb(m+c-k-1,m-1)
                    ans+=term
            return ans
        count=len(eta)
        @lru_cache(None)
        def process(v, received):
            if v==count:return 1
            total=received[0]-eta[v]
            if total<0:return 0
            edges=self.outgoing[v]
            ans=0
            for flows in compositions(total,len(edges)):
                next_received=list(received[1:]);weight=1
                for flow,(w,m) in zip(flows,edges):
                    next_received[w-v-1]+=flow
                    weight*=comb(m+flow-1,m-1)
                ans+=weight*process(v+1,tuple(next_received))
            return ans
        return process(0,(0,)*count)

    def _schur_moment(self, nus):
        """Integral of F times the product of Schur classes s_(nus_i)."""
        assert len(nus)==self.n
        assert all(len(nus[i])==self.b[i] for i in range(self.n))
        if sum(map(sum,nus))!=self.delta:return 0
        if any(nus[i] and max(nus[i])>self.r[i]-self.b[i] for i in range(self.n)):
            return 0
        ans=0
        for perms in product(*(tuple(permutations(range(bi))) for bi in self.b)):
            sign=1;eta=[]
            for i,perm in enumerate(perms):
                sign*=permutation_sign(perm)
                eta.extend(self.rho[i]+perm[a]-a-nus[i][perm[a]] for a in range(self.b[i]))
            ans+=sign*self.partition_count(tuple(eta))
        return ans


def direct_schur_moment(B,r,b,nus):
    """Independent integral Schur/Pieri implementation for diagnosis only."""
    from modular_euler_theta_probe import edge_action
    n=len(r);cur={tuple(nus):1}
    for i in range(n):
        for j in range(i+1,n):
            for _ in range(-B[i][j]):
                new={}
                for state,c in cur.items():
                    for (x,y),d in edge_action(r[i],b[i],r[j],b[j],state[i],state[j]):
                        key=state[:i]+(x,)+state[i+1:j]+(y,)+state[j+1:]
                        new[key]=new.get(key,0)+c*d
                cur={k:c for k,c in new.items() if c}
    top=tuple((r[i]-b[i],)*b[i] for i in range(n))
    return cur.get(top,0)


if __name__=='__main__':
    from modular_euler_theta_probe import rectangle_parts
    import json
    from pathlib import Path
    cases=[]
    tasks=[([[0,-3],[3,0]],(5,3),(1,1)),
           ([[0,-3],[3,0]],(6,4),(2,2)),
           ([[0,-3],[3,0]],(10,6),(2,3)),
           ([[0,-2,0],[2,0,-1],[0,1,0]],(4,3,2),(1,1,1)),
           ([[0,-1,-1],[1,0,-1],[1,1,0]],(4,4,3),(1,1,1))]
    for B,r,b in tasks:
        G=GraphicEulerMoments(B,r,b);checked=0
        for nus in product(*(rectangle_parts(b[i],r[i]-b[i]) for i in range(len(r)))):
            if sum(map(sum,nus))!=G.delta:continue
            a=G.schur_moment(nus);c=direct_schur_moment(B,r,b,nus)
            assert a==c,(B,r,b,nus,a,c)
            checked+=1
        cases.append({'B':B,'r':r,'b':b,'delta':G.delta,'moments_checked':checked,'agreement':True})
    output={'exact_graphic_kernel_vs_Pieri':cases}
    Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2))
    print(json.dumps(output))
