ClearAll["Global`*"]; SeedRandom[20261114];
rr={3,4,3}; ud={{1,1,1},{2,3,2}}; ar={{1,2},{1,2},{2,3},{1,3}}; ell=2;
grade[i_,a_]:=1+Boole[a>ud[[1,i]]]+Boole[a>ud[[2,i]]];
mm=Table[With[{s=ar[[a,1]],t=ar[[a,2]]},Table[If[grade[t,i]<=grade[s,j],RandomInteger[{-2,2}],0],{i,rr[[t]]},{j,rr[[s]]}]],{a,Length[ar]}];
ua=Table[With[{s=ar[[a,1]],t=ar[[a,2]]},mm[[a,1;;ud[[k,t]],1;;ud[[k,s]]]]],{k,ell},{a,Length[ar]}];
uv=Table[Table[KroneckerDelta[i,j],{i,ud[[2,x]]},{j,ud[[1,x]]}],{x,3}];
run[kind_]:=Module[{nd,na,nv,ff,hh,vv,z0,z1,vars0,vars1,d0,d1,c0,c1,c2,r0,r1},
nd=If[kind=="constant",ConstantArray[rr,ell],Table[rr-ud[[k]],{k,ell}]];
na=If[kind=="constant",ConstantArray[mm,ell],Table[With[{s=ar[[a,1]],t=ar[[a,2]]},mm[[a,ud[[k,t]]+1;;rr[[t]],ud[[k,s]]+1;;rr[[s]]]]],{k,ell},{a,Length[ar]}]];
nv=If[kind=="constant",IdentityMatrix /@ rr,Table[Table[KroneckerDelta[i+ud[[2,x]]-ud[[1,x]],j],{i,nd[[2,x]]},{j,nd[[1,x]]}],{x,3}]];
ff=Table[Array[f[k,x],{nd[[k,x]],ud[[k,x]]}],{k,ell},{x,3}];
hh=Table[With[{s=ar[[a,1]],t=ar[[a,2]]},Array[h[k,a],{nd[[k,t]],ud[[k,s]]}]],{k,ell},{a,Length[ar]}];
vv=Table[Array[v[x],{nd[[2,x]],ud[[1,x]]}],{x,3}];
z0=Join[Flatten[Table[With[{s=ar[[a,1]],t=ar[[a,2]]},na[[k,a]].ff[[k,s]]-ff[[k,t]].ua[[k,a]]],{k,ell},{a,Length[ar]}]],Flatten[Table[nv[[x]].ff[[1,x]]-ff[[2,x]].uv[[x]],{x,3}]]];
z1=Flatten[Table[With[{s=ar[[a,1]],t=ar[[a,2]]},nv[[t]].hh[[1,a]]-hh[[2,a]].uv[[s]]-na[[2,a]].vv[[s]]+vv[[t]].ua[[1,a]]],{a,Length[ar]}]];
vars0=Flatten[ff];vars1=Join[Flatten[hh],Flatten[vv]];
d0=Normal[CoefficientArrays[z0,vars0][[2]]];d1=Normal[CoefficientArrays[z1,vars1][[2]]];
{c0,c1,c2}={Length[vars0],Length[vars1],Length[z1]};{r0,r1}={MatrixRank[d0],MatrixRank[d1]};
<|"target"->kind,"complexDimensions"->{c0,c1,c2},"differentialRanks"->{r0,r1},"HomExt1Ext2"->{c0-r0,c1-r0-r1,c2-r1},"compositionZero"->(d1.d0==ConstantArray[0,{c2,c0}])|>
];
const=run["constant"];quo=run["quotient"];
fend=Table[Array[g[x],{rr[[x]],ud[[2,x]]}],{x,3}];
eqend=Flatten[Table[With[{s=ar[[a,1]],t=ar[[a,2]]},mm[[a]].fend[[s]]-fend[[t]].ua[[2,a]]],{a,Length[ar]}]];
dend=Normal[CoefficientArrays[eqend,Flatten[fend]][[2]]];rq=MatrixRank[dend];
single={Length[Flatten[fend]]-rq,Length[eqend]-rq};
<|"quiverArrows"->ar,"ambientDimension"->rr,"flagDimensions"->ud,"constantTarget"->const,"quotientTarget"->quo,"endpointQHomExt1"->single,"adjunctionVerified"->(Take[const["HomExt1Ext2"],2]==single),"bothExt2Zero"->(Last[const["HomExt1Ext2"]]==0&&Last[quo["HomExt1Ext2"]]==0)|>
