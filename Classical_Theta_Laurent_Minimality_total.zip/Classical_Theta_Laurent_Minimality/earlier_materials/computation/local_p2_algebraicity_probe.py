import sys,json,time
from pathlib import Path
from itertools import product
sys.path.insert(0,str(Path(__file__).resolve().parent))
from incoming_recursion import IncomingSchur,le,sub

def theta_total(R,g,N):
 J=sorted((p for p in product(range(N+1),repeat=R.n) if sum(p)<=N),key=lambda p:(sum(p),p))
 a={R.zero:1}
 for p in J[1:]:
  mp=R.shift(g,p)
  I=[q for q in J if le(q,p) and (q==p or sum(mp[i]*R.D[i]*(p[i]-q[i]) for i in range(R.n))<0)]
  t={p:1}
  for q in reversed(I[:-1]):
   t[q]=-sum(t.get(r,0)*R.c(sub(r,q),R.shift(g,q)) for r in I if r!=q and le(q,r))
  a[p]=-sum(t[q]*a[q] for q in I if q!=p)
 return a

def product_series(N,excluded_mod=0):
 from math import comb
 a=[1]+[0]*N
 for k in range(1,N+1):
  if excluded_mod and k%excluded_mod==0:continue
  b=[0]*(N+1)
  for j in range(N//k+1):b[j*k]=comb(k+j-1,j)
  a=[sum(a[j]*b[i-j] for j in range(i+1)) for i in range(N+1)]
 return a

if __name__=='__main__':
 N=int(sys.argv[1]) if len(sys.argv)>1 else 6
 t=time.time();B=((0,3,-3),(-3,0,3),(3,-3,0));R=IncomingSchur(B)
 a=theta_total(R,(-1,0,0),N)
 h=[sum(c for p,c in a.items() if sum(p)==n) for n in range(N+1)]
 m=product_series(N);red=product_series(N,3)
 data={'N':N,'B':B,'g':[-1,0,0],'theta_total':h,'MacMahon':m,'MacMahon_over_cube_t3':red,'agrees_reduced':h==red,'terms':[[list(p),c]for p,c in a.items()if c],'seconds':time.time()-t}
 Path(__file__).with_suffix('.json').write_text(json.dumps(data,indent=2))
 print(json.dumps({k:v for k,v in data.items()if k!='terms'},indent=2))
