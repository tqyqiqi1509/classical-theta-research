"""Verify full Laurent reconstruction beyond truncated elimination boxes.

Uses the previously established acyclic source bound for each output theta.
This check resolves the concrete possibility of missed tails after elimination.
"""
from pathlib import Path
import json,sys,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agents'))
from ctb_probe import AcyclicTheta

start=time.time();checks=[];families={};cache={}
for name in ['modular_euler_rank2.json','modular_euler_rank3.json']:
    data=json.loads(Path(__file__).with_name(name).read_text())
    for case in data['cases']:
        B=tuple(map(tuple,case['B']));g=tuple(case['g']);n=len(B)
        if B not in families:families[B]=AcyclicTheta(B)
        R=families[B]
        for characteristic,terms in case['characters'].items():
            rem={tuple(p):c for p,c in terms}
            trans=case['theta_transitions'][characteristic]
            for p,c in trans:
                p=tuple(p);h=R.shift(g,p);key=B,h
                if key not in cache:
                    cap=[0]*n
                    for i in reversed(range(n)):
                        cap[i]=max(0,-h[i]-sum(B[i][j]*cap[j] for j in range(i+1,n)))
                    cache[key]=R.F(h,tuple(cap))
                for q,v in cache[key].items():
                    pq=tuple(p[i]+q[i] for i in range(n))
                    rem[pq]=rem.get(pq,0)-c*v
                    if not rem[pq]:del rem[pq]
            assert not rem,{'B':B,'g':g,'characteristic':characteristic,'remainder':rem}
            checks.append({'B':B,'g':g,'characteristic':characteristic,'terms':len(terms),'theta_terms':len(trans),'full_reconstruction':True})
    print(json.dumps({'cohort':name,'full_checks':len(checks),'seconds':time.time()-start}),flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','seconds':time.time()-start,'full_laurent_identities':len(checks),'distinct_output_thetas':len(cache),'checks':checks},indent=2))
