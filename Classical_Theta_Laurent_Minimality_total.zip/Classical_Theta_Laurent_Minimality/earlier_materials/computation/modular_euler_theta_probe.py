"""Exact modular Euler-image characters versus classical theta coefficients.

The Euler-image formula is an INPUT CLAIM from the 2026-11-08 local research
package. This program checks its characteristic-zero agreement with independent
BZ triangular elements and probes all prime reductions for theta positivity.
It does not on its own certify that a modular character family is a cluster basis.

Schur calculus uses only integral Pieri and Jacobi--Trudi rules on products of
Grassmannians. No Li--Pan conclusions are used.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import product, permutations
from math import comb
from pathlib import Path
import argparse, json, sys, time

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'agents'))
from ctb_probe import Triangular, AcyclicTheta, fmt


@lru_cache(None)
def rectangle_parts(height, width):
    def rec(h, cap):
        if h == 0:
            yield ()
        else:
            for a in range(cap+1):
                for tail in rec(h-1, a):
                    yield (a,)+tail
    return tuple(sorted(rec(height,width),key=lambda p:(sum(p),p)))


def trim(p):
    p=list(p)
    while p and p[-1]==0:p.pop()
    return tuple(p)


@lru_cache(None)
def h_action(r,b,k,mu):
    if k<0:return ()
    if k==0:return ((mu,1),)
    if k>r-b:return ()
    # Pieri: nu/mu is a horizontal k-strip, hence interlaces.
    out=[]
    # Horizontal-strip interlacing gives independent bounded increments.
    # Enumerating these directly avoids scanning an entire growing rectangle.
    widths=tuple((r-b if i==0 else mu[i-1])-mu[i] for i in range(b))
    def generate(i,left,prefix):
        if i==b:
            if left==0:out.append((tuple(prefix),1))
            return
        low=max(0,left-sum(widths[i+1:]));high=min(widths[i],left)
        for inc in range(low,high+1):generate(i+1,left-inc,prefix+[mu[i]+inc])
    generate(0,k,[])
    return tuple(out)


@lru_cache(None)
def schur_action(r,b,lam,mu):
    lam=trim(lam)
    if not lam:return ((mu,1),)
    if len(lam)>b or lam[0]>r-b:return ()
    out=defaultdict(int);ell=len(lam)
    for perm in permutations(range(ell)):
        ks=[lam[i]-i+perm[i] for i in range(ell)]
        if any(k<0 for k in ks):continue
        sign=(-1)**sum(perm[i]>perm[j] for i in range(ell) for j in range(i+1,ell))
        cur={mu:sign}
        for k in ks:
            nxt=defaultdict(int)
            for nu,c in cur.items():
                for xi,v in h_action(r,b,k,nu):nxt[xi]+=c*v
            cur={nu:c for nu,c in nxt.items() if c}
            if not cur:break
        for nu,c in cur.items():out[nu]+=c
    ans=tuple((nu,c) for nu,c in sorted(out.items()) if c)
    assert all(c>0 for nu,c in ans),(r,b,lam,mu,ans)
    return ans


@lru_cache(None)
def edge_action(ri,bi,rj,bj,mu,nu):
    """Euler Hom(S_i,Q_j): sum_lambda s_lambda(S_i)s_lambda^c(S_j)."""
    aj=rj-bj;out=defaultdict(int)
    for lam in rectangle_parts(bi,aj):
        comp=tuple(aj-x for x in reversed(lam))
        for x,c in schur_action(ri,bi,trim(lam),mu):
            for y,d in schur_action(rj,bj,trim(comp),nu):out[x,y]+=c*d
    return tuple((k,c) for k,c in sorted(out.items()) if c)


def rank_mod(columns,prime):
    piv={}
    for column in columns:
        row={i:c%prime for i,c in column.items() if c%prime}
        while row:
            pivot=min(row)
            if pivot not in piv:
                inv=pow(row[pivot],-1,prime)
                piv[pivot]={i:(c*inv)%prime for i,c in row.items()}
                break
            factor=row[pivot]
            for i,c in piv[pivot].items():
                x=(row.get(i,0)-factor*c)%prime
                if x:row[i]=x
                elif i in row:del row[i]
    return len(piv)


def rank_rational(columns):
    from fractions import Fraction
    piv={}
    for column in columns:
        row={i:Fraction(c) for i,c in column.items() if c}
        while row:
            pivot=min(row)
            if pivot not in piv:
                c=row[pivot];piv[pivot]={i:x/c for i,x in row.items()};break
            factor=row[pivot]
            for i,c in piv[pivot].items():
                x=row.get(i,0)-factor*c
                if x:row[i]=x
                elif i in row:del row[i]
    return len(piv)


def euler_ranks(B,r,b,primes=(2,3,5,7)):
    n=len(B)
    spaces=[rectangle_parts(b[i],r[i]-b[i]) for i in range(n)]
    states=list(product(*spaces));index={mu:i for i,mu in enumerate(states)}
    edges=[(i,j,-B[i][j]) for i in range(n) for j in range(i+1,n) if B[i][j]]
    total_degree=sum(m*b[i]*(r[j]-b[j]) for i,j,m in edges)
    top_degree=sum(b[i]*(r[i]-b[i]) for i in range(n))
    if total_degree>top_degree:
        return {0:0,**{p:0 for p in primes}},len(states),0
    blocks=defaultdict(list)
    for mu in states:
        in_degree=sum(map(sum,mu))
        if in_degree+total_degree>top_degree:continue
        cur={mu:1}
        for i,j,m in edges:
            for _ in range(m):
                nxt=defaultdict(int)
                for state,c in cur.items():
                    for (x,y),d in edge_action(r[i],b[i],r[j],b[j],state[i],state[j]):
                        new=state[:i]+(x,)+state[i+1:j]+(y,)+state[j+1:]
                        nxt[new]+=c*d
                cur={state:c for state,c in nxt.items() if c}
                if not cur:break
            if not cur:break
        if cur:
            assert all(sum(map(sum,state))==in_degree+total_degree for state in cur)
            blocks[in_degree].append({index[state]:c for state,c in cur.items()})
    ans={0:sum(rank_rational(cols) for cols in blocks.values())}
    ans.update({p:sum(rank_mod(cols,p) for cols in blocks.values()) for p in primes})
    return ans,len(states),sum(sum(len(c) for c in cols) for cols in blocks.values())


def euler_ranks_sparse(B,r,b,primes=(2,3,5,7),rational=True):
    """Same map, only source degrees capable of surviving top cohomology.

    Matrix rows are partition tuples, eliminating the unnecessary full tensor
    basis inventory. This supports genuine ray/stability probes at growing r.
    """
    n=len(B)
    size=1
    for ri,bi in zip(r,b):size*=comb(ri,bi)
    edges=[(i,j,-B[i][j]) for i in range(n) for j in range(i+1,n) if B[i][j]]
    total_degree=sum(m*b[i]*(r[j]-b[j]) for i,j,m in edges)
    top_degree=sum(b[i]*(r[i]-b[i]) for i in range(n))
    if total_degree>top_degree:
        return {0:0,**{p:0 for p in primes}},size,0
    deficit=top_degree-total_degree
    spaces=[tuple(lam for lam in rectangle_parts(b[i],r[i]-b[i]) if sum(lam)<=deficit) for i in range(n)]
    def small_states(i,remaining):
        if i==n:
            yield ()
        else:
            for lam in spaces[i]:
                d=sum(lam)
                if d>remaining:break
                for tail in small_states(i+1,remaining-d):yield (lam,)+tail
    blocks=defaultdict(list)
    for mu in small_states(0,deficit):
        in_degree=sum(map(sum,mu));cur={mu:1}
        for i,j,m in edges:
            for _ in range(m):
                nxt=defaultdict(int)
                for state,c in cur.items():
                    for (x,y),d in edge_action(r[i],b[i],r[j],b[j],state[i],state[j]):
                        new=state[:i]+(x,)+state[i+1:j]+(y,)+state[j+1:]
                        nxt[new]+=c*d
                cur={state:c for state,c in nxt.items() if c}
                if not cur:break
            if not cur:break
        if cur:blocks[in_degree].append(cur)
    ans={0:sum(rank_rational(cols) for cols in blocks.values())} if rational else {}
    ans.update({p:sum(rank_mod(cols,p) for cols in blocks.values()) for p in primes})
    return ans,size,sum(sum(len(c) for c in cols) for cols in blocks.values())


def run_case(B,r,primes=(2,3,5,7),check_bz=True):
    n=len(B);T=Triangular(B);R=AcyclicTheta(B)
    g=tuple(-r[i]+sum(max(-B[i][j],0)*r[j] for j in range(n)) for i in range(n))
    Fs={p:{} for p in (0,)+tuple(primes)};matrix_count=0;max_size=0;entries=0
    for b in product(*(range(v+1) for v in r)):
        ranks,size,nnz=euler_ranks(B,r,b,primes)
        matrix_count+=1;max_size=max(max_size,size);entries+=nnz
        for p,c in ranks.items():
            if c:Fs[p][b]=c
    out={'B':B,'r':r,'g':g,'matrices':matrix_count,'largest_cohomology_dimension':max_size,'nonzero_integer_matrix_entries':entries}
    if check_bz:
        expected=T.classical_F(tuple(-x for x in r)+(0,)*n)
        out['characteristic_zero_BZ_agreement']=Fs[0]==expected
        if Fs[0]!=expected:
            out['discrepancy']=[(p,Fs[0].get(p,0),expected.get(p,0)) for p in sorted(set(Fs[0])|set(expected)) if Fs[0].get(p,0)!=expected.get(p,0)]
            return out
    out['characters']={str(p):fmt(F) for p,F in Fs.items()}
    out['theta_transitions']={str(p):fmt(R.decompose(g,F)) for p,F in Fs.items()}
    out['negative_transitions']={str(p):fmt({q:c for q,c in R.decompose(g,F).items() if c<0}) for p,F in Fs.items()}
    out['theta_coefficients']=fmt(R.theta_prefix(g,r))
    return out


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cohort',choices=['calibrate','connected_rank3','rank2_wild'],default='calibrate')
    parser.add_argument('--output',type=Path,default=Path(__file__).with_suffix('.json'))
    args=parser.parse_args();start=time.time();cases=[]
    if args.cohort=='calibrate':
        tasks=[([[0,-m],[m,0]],(r,r)) for m in [1,2,3] for r in [2,3,4]]
        tasks += [([[0,-2,0],[2,0,-1],[0,1,0]],r) for r in [(2,2,1),(3,3,2),(4,4,2)]]
    elif args.cohort=='rank2_wild':
        tasks=[([[0,-m],[m,0]],r) for m in [3,4,5] for r in product(range(2,7),repeat=2)]
    else:
        tasks=[]
        for a,b,c in [(2,1,0),(3,1,0),(2,2,0),(1,1,1),(2,1,1),(2,2,1),(3,2,1)]:
            B=[[0,-a,-c],[a,0,-b],[c,b,0]]
            for r in product(range(2,5),repeat=3):tasks.append((B,r))
    for B,r in tasks:
        rec=run_case(B,r);cases.append(rec)
        data={'cohort':args.cohort,'elapsed_seconds':time.time()-start,'completed':len(cases),'planned':len(tasks),'cases':cases}
        args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2))
        neg=rec.get('negative_transitions',{})
        print(json.dumps({'completed':len(cases),'B':B,'r':r,'BZ':rec.get('characteristic_zero_BZ_agreement'),'negative':neg,'seconds':time.time()-start}),flush=True)
        if rec.get('characteristic_zero_BZ_agreement') is False or any(neg.values()):
            print('ACTIONABLE_FAILURE_STOP',flush=True);return


if __name__=='__main__':main()
