# Exact computation inputs

`incoming_recursion.py` is copied unchanged from the second research round, `Higher_Rank_Greedy_Theta/agents/incoming_recursion.py`. It is the previously derived integer incoming-Schur coefficient recurrence, not a new fourth-round result. This copy makes the new support checks reproducible without external history paths. Python standard library only.

New BZ/CTB generators and independent theta checks are under `../agents/ctb_probe.py` and `../agents/ctb_probe_verify.py`. The general parameter identity verifier uses SymPy. Wolfram inputs and unedited tool outputs are preserved as JSON receipts.
