"""Adversarial test of a proposed uniform integral-stability criterion.

The criterion under test is |g.d| > -q_B(d), g.d != 0 for all 0<d<=b.
This is a conjectural sufficient condition, not an established theorem.
Also tests the weaker unit-Smith-rank >= theta coefficient inequality.
Exact Smith normal forms see all primes, unlike a finite prime scan.
"""
from pathlib import Path
from itertools import product
import json,random,time,sys
from sympy import Matrix,ZZ
from sympy.matrices.normalforms import smith_normal_form
from graphic_kernel_euler import GraphicEuler
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'agents'))
from ctb_probe import AcyclicTheta


def quality(B,r,b):
    n=len(B);g=tuple(-r[i]+sum(-B[i][j]*r[j] for j in range(i+1,n)) for i in range(n))
    margins=[]
    for d in product(*(range(bi+1) for bi in b)):
        if not any(d):continue
        pairing=sum(x*y for x,y in zip(g,d))
        q=sum(x*x for x in d)+sum(B[i][j]*d[i]*d[j] for i in range(n) for j in range(i+1,n))
        margins.append((abs(pairing)+q,pairing,d))
    strict=all(x>0 and y!=0 for x,y,d in margins)
    qb=sum(x*x for x in b)+sum(B[i][j]*b[i]*b[j] for i in range(n) for j in range(i+1,n))
    delta=-sum(x*y for x,y in zip(g,b))-qb
    return g,strict,delta,min(margins)


def main():
    out=Path(__file__).with_suffix('.json');start=time.time();rng=random.Random(14110403)
    scenarios=[]
    for m in [2,3,4,5]:
        scenarios += [([[0,-m],[m,0]],b) for b in [(1,2),(2,2),(2,3),(3,2),(3,3)]]
    for a,b,c in [(2,1,0),(2,2,0),(3,1,0),(1,1,1),(2,1,1),(2,2,1)]:
        scenarios += [([[0,-a,-c],[a,0,-b],[c,b,0]],root) for root in [(1,1,1),(2,1,1),(1,2,1),(1,1,2),(2,2,1)]]
    candidates={False:[],True:[]};seen=set()
    for _ in range(30000):
        B,b=rng.choice(scenarios);r=tuple(rng.randrange(max(2,x),36) for x in b)
        key=(tuple(map(tuple,B)),r,b)
        if key in seen:continue
        seen.add(key);g,strict,delta,margin=quality(B,r,b)
        if not 0<=delta<=10:continue
        candidates[strict].append((B,r,b,g,delta,margin))
    # Balance hard strict-margin cases with nonstable boundary controls.
    tasks=candidates[True][:160]+candidates[False][:160]
    records=[];Rcache={}
    for B,r,b,g,delta,margin in tasks:
        G=GraphicEuler(B,r,b);groups=G.states();blocks=[];unitrank=0;rank0=0
        for d in range(delta//2+1):
            mat=Matrix([[G.gram(lam,mu) for lam in groups[d]] for mu in groups[delta-d]])
            snf=smith_normal_form(mat,domain=ZZ)
            factors=[abs(int(snf[i,i])) for i in range(min(snf.shape)) if snf[i,i]]
            multiplicity=1 if 2*d==delta else 2
            unitrank+=multiplicity*sum(v==1 for v in factors);rank0+=multiplicity*len(factors)
            blocks.append({'degree':d,'shape':list(mat.shape),'rank':len(factors),'nonunit':[v for v in factors if v>1],'mirror':multiplicity})
        bt=tuple(map(tuple,B))
        if bt not in Rcache:Rcache[bt]=AcyclicTheta(B)
        theta=Rcache[bt].theta_prefix(g,b).get(b,0)
        strict=quality(B,r,b)[1]
        rec={'B':B,'r':r,'b':b,'g':g,'delta':delta,'strict_margin':strict,'minimum_margin':margin,'rank0':rank0,'unit_rank':unitrank,'theta':theta,'blocks':blocks}
        records.append(rec)
        data={'seconds':time.time()-start,'completed':len(records),'planned':len(tasks),'candidate_counts':{str(k):len(v) for k,v in candidates.items()},'records':records}
        out.write_text(json.dumps(data,indent=2))
        print(json.dumps({k:rec[k] for k in ['r','b','g','strict_margin','rank0','unit_rank','theta']}),flush=True)
        if (strict and unitrank<rank0) or unitrank<theta:
            print('ACTIONABLE_FAILURE',flush=True);return

if __name__=='__main__':main()
