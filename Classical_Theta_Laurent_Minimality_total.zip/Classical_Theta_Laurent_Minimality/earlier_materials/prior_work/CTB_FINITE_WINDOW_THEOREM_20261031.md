# 一般有限窗口刚性与正乘法到 theta 正性的桥梁

## 内部审核后的精确结论

本文件合并完整主证明与三次独立数学审核，保留三因子与两因子推导、全局和末次对抗审稿及修复记录。它是本轮内部研究结果，尚未经外部同行评审；不主张文献优先权。各分支正文保留其写作时的状态说明，当前裁定以本节和末次审核为准。

设种子有限秩、mutable 交换矩阵反对称、存在兼容量子形式、injective-reachable，并倒置冻结变量。兼容形式蕴含扩展矩阵满列秩。令 $L_g$ 为 Qin 的形式三角族；实际共同三角基存在时，它与该形式族一致。

**结论 A（不需乘法正性）。** 给定有限正次数窗口及有限偏移集，沿对整个窗口 generic 的充分远整数方向，$L_{N\nu+h}$ 与 $\vartheta_{N\nu+h}$ 在该窗口内精确一致。这是任意有限维的一般机制，不以按秩枚举代替证明。

**结论 B（保留明确额外假设）。** 若 $L$ 为实际基，且乘法结构常数属于 $\mathbb N[v^{\pm1}]$，则其 theta 换基系数属于同一非负环。若仅知道乘法结构常数在 $v=1$ 时为非负整数，已足以推出经典换基非负。

桥梁给出逐个目标系数的精确恒等式：

\[
[L_{N\nu+p}](L_aL_{N\nu})
=v^{\Lambda(p,N\nu)}[\vartheta_p]L_a
\quad(N\text{充分大}).
\]

左边是一个真实乘法系数，不是两个正 Laurent 展开的抽象比较。证明同时控制乘子的窗口和输出基元的窗口；末段 broken-line 论证包含目标位于墙上、零目标和纯冻结目标。

**末次审稿的表述精确化。** 方向和阈值按每个目标分别选择，不主张一个乘子同时提取所有目标。有限窗口是正修正代数 \(K[[Y^{\mathbb N^n}]]\) 及固定首指数模块 \(X^gK[[Y^{\mathbb N^n}]]\) 中的截断；不是整个 Laurent 量子环的普通理想商。跨首指数相加时使用各自的剩余窗口，主证明实际操作均遵守这一规则。

经典特化只作用于最后的整 Laurent 恒等式；不能直接向可能有极点的 \(H,F,T\) 或量子 dilogarithm 中间系数代入 \(v=1\)。

**先行范围。** 秩二远端抽取与无正性刚性已在用户旧第一/第三轮覆盖；量子散射端点系数抽取已见 Mandel–Qin 2301.11101v3 Lemma5.11 和 Davison–Mandel 1910.12915v3 Theorem3.16的证明。本轮独立补全的一般次数估计、实际输出控制和有效阈值与这些先行结论分开，不主张其历史优先权。详见 `PRIOR_ART_AND_SCOPE_ADDENDUM.md`。

**确定性构造与有效性。** 对目标 $p=a+\widetilde BE$，$E\ne0$时可直接取
\[
\nu=\left(1+\sum_iE_i\right)p_{\rm mut}+(1,\ldots,1).
\]
它对整个有限盒generic，并与目标所有非零墙配对同号。整数方向只指定有限截断中的腔；完整散射图表在同一有限腔内另选真正generic的实端点。主证明中的“充分大”可由有限严格线性不等式显式认证，见 `EFFECTIVE_FINITE_CERTIFICATION.md`。CT单项式化阈值与theta几何阈值须按所需偏移和剩余窗口分别标注，不能混为同一最小值。

**无条件可应用的范围。** Qin 对称 Cartan 的 Lie/word 模型已有独立乘法正性定理，因而可以在其精确假设下应用结论 B，包括本轮构造的真正 mutation-cyclic 输入。任意 hypothetical common triangular basis 的乘法正性尚未由本文件证明。

**最宽原猜想仍未标为解决。** CT 定义不含乘法正性。主问题剩余缺口是为一般实际 CT 提供所需正性或一个替代正性机制；不能删掉假设后宣称全称结论。

## 证据层级

主证明和独立审稿分别给出三因子与两因子次数估计；root 另核实际原文接口和任意兼容形式相位。Wolfram 与大规模 exact CT/HN 计算校验约定及有限窗口现象，**不承担全称量词的证明**。初始有误的参数替换、过强支撑猜测、整性遗漏和文献版本编号均留在审计历史中。

---

## Part I. Complete authoring proof

# Generic finite-window rigidity and positive theta transitions

Date: 2026-10-31. Authoring branch: `asymptotic_mechanism`.

**Status:** complete proof candidate with all claimed hypotheses explicit, submitted for a fresh-context adversarial audit. This is an internal research result, not an externally reviewed theorem or a claim of historical priority. The underlying three-factor calculation was obtained independently in this branch and by the root/computational branches before comparison. Their agreement is a consistency check, not a substitute for proof.

## 0. Provenance and exact scope

Before exploring this route I read the complete recovered rank-two proof at `history/old_records/LLRZ16_研究记录.txt`, lines 425–1086. That proof already combines a rank-two quantum degree envelope, remote Newton vertices, fixed-window rigidity, and extraction from a strongly positive multiplication coefficient. None of those rank-two results is claimed as new here.

The new bridge below proves fixed-window rigidity directly from the injective standard family and the **full quantum cluster scattering diagram**, in arbitrary finite rank. It does not use a quiver Grassmannian, an acyclic seed, a Jacobian purity theorem, or a rank-two Newton polygon. In particular, the proof applies to genuinely mutation-cyclic injective-reachable seeds.

There are three distinct conclusions:

**(A) Rigidity.** For a skew-symmetric injective-reachable principal seed, the formal triangular family of Qin Lemma 6.2 agrees with the theta family in every fixed positive-degree window along sufficiently large generic integral rays, uniformly under finitely many fixed translations. If an actual common triangular basis exists, it is that formal family and has this property.

**(Bq) Quantum positivity, with an additional hypothesis.** If an actual common triangular basis has multiplication structure constants in `N[v^{±1}]` and its elements have finite theta expansions, then every such theta expansion has coefficients in `N[v^{±1}]`.

**(Bc) Classical positivity, with a weaker additional hypothesis.** If the same actual quantum common triangular basis has multiplication structure constants whose specializations at `v=1` are nonnegative integers, then its classical specialization has nonnegative integral theta expansions. Quantum strong positivity is not needed for this conclusion.

The additional multiplication-positivity hypothesis is **not part of the definition of a common triangular basis**. Qin 2003.13674v3, Remark 1.2.1, explicitly distinguishes existence arguments from that additional positivity. Qin 2508.12761v2, Theorem 6.11(3), supplies the hypothesis in the stated symmetric-Cartan Lie-theoretic models. Thus (Bq) applies unconditionally there, including the word models certified by the sibling branch. The present proof does not fill an unknown positivity hypothesis for every hypothetical skew-symmetric common triangular basis.

The first proof is in the unitally compatible principal quantum torus. Section 8 gives a direct proof for every compatible full-column-rank coefficient extension, including disconnected mutable matrices with different compatibility multipliers.

## 1. Quantum torus and finite windows

Let `B` be a skew-symmetric `n x n` integer matrix and put

\[
\widetilde B=\binom{B}{I_n},\qquad
\Lambda=\begin{pmatrix}0&-I_n\\ I_n&-B\end{pmatrix}.
\]

Work over `R=Z[v^{±1}]`, and let `K=Q(v)`. Normalized monomials satisfy

\[
X^mX^{m'}=v^{\Lambda(m,m')}X^{m+m'},\qquad
\overline{v}=v^{-1},\quad\overline{X^m}=X^m,
\]

where bar reverses the order of products. Write

\[
Y^d=X^{\widetilde B d}\quad(d\in\mathbb N^n).
\]

For `g in Z^n`, identified with `(g,0)`, the relevant identities are

\[
\Lambda(g,\widetilde Bd)=-g\cdot d,\qquad
Y^dY^e=v^{d^TBe}Y^{d+e},\qquad
\tau_a(Y^d):=X^aY^dX^{-a}=v^{-2a\cdot d}Y^d.
\tag{1.1}
\]

A window is a finite box

\[
W_E=\{d\in\mathbb N^n:0\le d_i\le E_i\}.
\]

All equalities modulo the complement of `W_E` are exact quotient identities. The complement is a monoid ideal: adding a nonnegative vector never brings a discarded degree back into the box. Consequently multiplication, formal inverses with constant coefficient one, scattering transport, and triangular substitution all respect this truncation.

Every coefficient of an element of `1+K[[Y^{N^n\setminus0}]]` is a rational function of `v`. Write `deg_infty(r)` for its degree at infinity, with `deg_infty(0)=-infty`. This degree is finite for a nonzero rational function and obeys

\[
\deg_\infty(rs)=\deg_\infty r+\deg_\infty s,
\qquad
\deg_\infty(r+s)\le\max(\deg_\infty r,\deg_\infty s).
\]

When the coefficient is in `R`, this is its largest Laurent exponent. That distinction will be essential: a bar-invariant **rational function** can have negative degree at infinity, for example `1/(v+v^{-1})`; the corresponding assertion is false for a nonzero Laurent polynomial.

## 2. Two endpoint charts and the injective standard family

Let `C_+` and `C_-` be the positive and negative chambers in the initial scattering coordinates. Injective reachability supplies a reachable cluster whose mutable leading degrees are `-e_i`, up to permutation and frozen translation. Normalize its variables by frozen Laurent monomials so that their full leading degrees are `(-e_i,0)`; call the resulting elements `J_i`.

The normalization has no positive-degree-dependent phase. Indeed, a frozen exponent `h` satisfies

\[
\Lambda(h,\widetilde Bd)=0
\]

by compatibility. Normalized multiplication by `X^h` therefore simply translates all normalized monomial exponents in a pointed expansion.

By the cluster-chart comparison in Davison--Mandel Proposition 4.9 and Corollary 4.13, transport to `C_-` sends

\[
J_i\longmapsto X^{-e_i}.
\]

Let `H` be the full path element from `C_+` to `C_-`, so that transport is `Ad_H`. Then

\[
J_i=\operatorname{Ad}_{H^{-1}}X^{-e_i}.
\tag{2.1}
\]

The element `H` lies in the positive-degree completed quantum group over `K`. It is the full element acting on the principal A-torus. No quotient by the center of the unframed torus is taken. An unframed central `Y^d` can still act nontrivially on `X^{(g,0)}` because the first identity in (1.1) pairs it with `g`.

Since the pure mutable monomials `X^{-e_i}` commute in the chosen principal quantization, the normalized `J_i` commute as well. Thus

\[
J^b=\operatorname{Ad}_{H^{-1}}X^{-b}\qquad(b\in\mathbb N^n).
\]

For `g=a-b`, where `a=g_+`, `b=g_-` have disjoint support, Qin's normalized injective standard element is exactly

\[
I_g=X^aJ^b=X^aH^{-1}X^{-b}H
     =X^g\tau_b(H^{-1})H.
\tag{2.2}
\]

The leading coefficient is one because `Lambda((a,0),(-b,0))=0`. This is the standard family of Qin 2508.12761v2, Section 6.1 and Lemma 6.2, not the differently normalized Berenstein--Zelevinsky standard family.

For a full degree `(g,h_fr)`, apply normalized frozen translation to (2.2). Every coefficient formula below is unchanged, so full frozen degrees can be restored at any stage.

## 3. A finite-chart factorization with support signs

Fix `W_E`. Choose an integral mutable vector `nu` such that

\[
\nu\cdot d\ne0\qquad(0\ne d\in W_E).
\tag{3.1}
\]

Only finitely many walls affect `W_E`. A rational/integral choice satisfying (3.1) can be made in any prescribed nonempty open cone. No assertion that a rational vector avoids all infinitely many walls is needed.

Choose generic straight paths from a positive point to `nu`, then from `nu` to a negative point, working in the finite truncation. Denote their path elements by `F` and `T`. With the convention that the first path acts first,

\[
H=TF,\qquad \iota_\nu=\operatorname{Ad}_F.
\tag{3.2}
\]

Every wall degree `d` crossed on the first path has `nu.d<0`: the linear function `d` is positive at the positive endpoint, so it can vanish on the segment only if its value at `nu` is negative. Similarly, each wall degree crossed on the second segment has `nu.d>0`. Products and inverses stay in their respective strict half-cones. Hence

\[
F=1+\sum_{\nu\cdot d<0}f_dY^d,
\qquad
T=1+\sum_{\nu\cdot d>0}t_dY^d
\quad\pmod{W_E^c}.
\tag{3.3}
\]

The same statement can be phrased as the unique two-sector factorization of the completed group element. The straight-path proof makes the support signs and the multiplication order explicit. It uses only the cluster scattering diagram; no stability/cluster comparison theorem for a potential is required here.

### Integrality and bar preservation

The integrality needed below has a particularly short proof. Each `I_g` is a normalized product of two cluster monomials, `X^a` and `J^b`, with a frozen Laurent factor if necessary. By Davison--Mandel Corollary 4.13 these cluster monomials are theta functions. By their Theorem 3.9, their expansions in every scattering chart have coefficients in `Z[v^{±1}]` (in fact nonnegative coefficients). Multiplication in a fixed finite window is a finite Laurent-polynomial convolution, and normalization multiplies by a Laurent unit. Hence every coefficient of `iota_nu(I_g)` belongs to `Z[v^{±1}]`.

This avoids needing a stronger assertion about arbitrary elements of the completed integral torus. That stronger integrality can also be obtained from Theorem 2.15 and the quantum-binomial wall-action formulas (20)--(23), with integral inverse expansions. It is not an extra hypothesis of the proof.

Bar preservation also follows directly. On the group set `sigma(U)=overline(U)^{-1}`. Because bar is an antiautomorphism, `sigma` is a group automorphism preserving positive degrees. It fixes the initial quantum dilogarithm wall elements. Consistency and uniqueness of scattering completion therefore make every path product fixed by `sigma`, so

\[
\overline F=F^{-1},\qquad
\overline{\operatorname{Ad}_F(z)}=\operatorname{Ad}_F(\overline z).
\tag{3.4}
\]

Alternatively, the bar-preserving statement follows from the bar-invariant wall actions of Davison--Mandel Lemma 3.4 and Theorem 2.15. Neither integrality nor bar preservation is the desired CT-to-theta positivity statement.

## 4. The degree estimate

Combining (2.2) and (3.2) gives an exact three-factor expression:

\[
\begin{aligned}
\iota_\nu(I_g)
 &=F X^g\tau_b(H^{-1})H F^{-1}\\
 &=X^g\tau_{-g}(F)\tau_b(H^{-1})T.
\end{aligned}
\tag{4.1}
\]

This identity is the main new algebraic bridge. Write the coefficient of `Y^{d_2}` in `H^{-1}` as `h^-_{d_2}`. For `d_1+d_2+d_3=e`, the contribution to the normalized monomial `X^{g+Btilde e}` in (4.1) is

\[
f_{d_1}h^-_{d_2}t_{d_3}\,
v^{2g\cdot d_1-2b\cdot d_2-g\cdot e+\beta(d_1,d_2,d_3)},
\tag{4.2}
\]

where

\[
\beta(d_1,d_2,d_3)=d_1^TBd_2+(d_1+d_2)^TBd_3.
\]

The term `-g.e` comes from converting `X^gY^e` to the normalized monomial; it must not be omitted.

Now let

\[
g=N\nu+h,
\]

where `h` ranges over a fixed finite set. For all sufficiently large `N`, the coordinate signs of `g` are fixed by `nu` on nonzero coordinates of `nu`, and

\[
b=g_-=N\nu_-+b_h,
\]

with a vector `b_h` independent of `N`. A zero coordinate of `nu` contributes only a fixed term; under (3.1) every coordinate active in the box is nonzero anyway.

The coefficient of `N` in the exponent in (4.2) is

\[
\begin{aligned}
\sigma
 &=2\nu\cdot d_1-2\nu_-\cdot d_2-\nu\cdot(d_1+d_2+d_3)\\
 &=\nu\cdot d_1-|\nu|\cdot d_2-\nu\cdot d_3.
\end{aligned}
\tag{4.3}
\]

By (3.3), a nonzero `d_1` in a contributing term has `nu.d_1<0`, and a nonzero `d_3` has `nu.d_3>0`. Also `|nu|.d_2 >= |nu.d_2|`. Therefore

\[
\sigma
\le-\bigl(|\nu\cdot d_1|+|\nu\cdot d_2|+|\nu\cdot d_3|\bigr)
\le-|\nu\cdot e|.
\tag{4.4}
\]

For fixed `e`, there are finitely many triples `(d_1,d_2,d_3)`. The rational coefficients `f_{d_1},h^-_{d_2},t_{d_3}`, the bilinear phase `beta`, and the `h`-dependent parts of (4.2) contribute a finite constant independent of `N`. Taking their maximum proves:

**Degree lemma.** For a fixed finite window, the chosen generic direction, and finitely many fixed offsets, there are constants `C_e` and `N_1` such that

\[
\deg_\infty\bigl([X^{N\nu+h+\widetilde Be}]\,
  \iota_\nu(I_{N\nu+h})\bigr)
\le-N|\nu\cdot e|+C_e
\tag{4.5}
\]

for every `N>=N_1`, every listed offset `h`, and every `e in W_E`.

This proves an asymptotic degree estimate. It does **not** prove the experimentally suggested explicit bound involving `q_B(e)`, which is unnecessary for the argument.

Since the transported coefficients are Laurent polynomials by Section 3, (3.1) and (4.5) imply that, after one common finite threshold,

\[
\iota_\nu(I_{N\nu+h})
=X^{N\nu+h}
 +\sum_{0\ne e\in W_E}r_{N,h,e}(v)X^{N\nu+h+\widetilde Be}
 \pmod{W_E^c},
\quad r_{N,h,e}\in v^{-1}\mathbb Z[v^{-1}].
\tag{4.6}
\]

The three-factor phase identity and the elementary real inequality used in (4.4) were independently checked with the Wolfram Language plugin: `degree_identity.wl` returned `{0, False}`, meaning the symbolic identity is zero and the specified inequality has no counterexample. The proof above, rather than this check, carries the all-rank quantifier.

## 5. Qin triangularity and bar force exact window rigidity

Let `L_g` be the formal triangular element from Qin Lemma 6.2. It satisfies

\[
L_g=I_g+\sum_{0\ne f\in\mathbb N^n}c_{g,f}(v)I_{g+\widetilde Bf},
\qquad c_{g,f}\in v^{-1}\mathbb Z[v^{-1}],\qquad \overline{L_g}=L_g.
\tag{5.1}
\]

The full degree on the right includes frozen coordinates. As observed after (2.2), normalized frozen translation does not affect any coefficient estimate.

For a requested initial offset set `H_0`, apply the degree lemma simultaneously to

\[
H=\{h+\widetilde Bf:h\in H_0,\ f\in W_E\}.
\]

This set is finite. When transporting (5.1), a correction with `f` outside `W_E` cannot affect that window. Every coefficient inside the window is a finite sum. Its nonleading terms are either coefficients from (4.6), or products of a coefficient in `v^{-1}Z[v^{-1}]` from (5.1) with a leading coefficient `1` or another coefficient in `v^{-1}Z[v^{-1}]` from (4.6). Hence all nonleading coefficients of `iota_nu(L_{N nu+h})` in `W_E` lie in `v^{-1}Z[v^{-1}]`.

By (3.4) and (5.1), the same coefficients are bar invariant. The only bar-invariant Laurent polynomial in `v^{-1}Z[v^{-1}]` is zero. Thus

\[
\boxed{\iota_\nu(L_{N\nu+h})=X^{N\nu+h}\pmod{W_E^c}}
\tag{5.2}
\]

for all sufficiently large `N`, uniformly over `h in H_0`.

No sign assumption about the coefficients `c_{g,f}`, no strong multiplication, and no geometric realization of `L_g` has been used in this proof. It applies even to the formal family before actual basis existence is established. Actual existence is required for the multiplication conclusion in Section 7.

**Rigidity theorem (principal form).** Let `B` be any finite skew-symmetric integer matrix, equip its principal extension with the unit compatible form (1.1), invert the frozen variables, and assume injective reachability. Let `{L_g}` be the formal triangular family of Qin Lemma 6.2. Fix a finite positive-degree box `W_E`, a finite set of full lattice offsets `H_0`, and an integral mutable vector `nu` satisfying (3.1). Then there is an integer `N_0` such that for every `N>=N_0` and `h in H_0`, the scattering-chart expansion at `nu` of `L_{Nnu+h}` equals its leading monomial throughout `W_E`. The same assertion holds for theta functions, and hence the two formal families agree in that window in every chart. Full column rank is automatic for this principal extension. The proof requires neither actual CT basis existence nor any CT multiplication positivity.

## 6. Theta monomialization in the same fixed chart

The corresponding theta statement is elementary but must be uniform in the same finite window.

Choose a convex open cone `U` in the mutable real coordinate space containing `nu` and avoiding the supporting hyperplanes of every wall relevant to `W_E`. Such a cone exists because the truncated diagram is finite and `nu` satisfies (3.1). Wall supports are invariant under frozen translations, so the corresponding chart region is `U` times the full frozen real space. For a fixed finite set of offsets `h`, the mutable parts of all vectors

\[
N\nu+h+\widetilde Be,\qquad e\in W_E,
\]

lie in `U` once `N` is sufficiently large. The frozen coordinates impose no further wall condition.

Take the theta endpoint `Q=nu`. Suppose a broken line with initial label `N nu+h` has final exponent `N nu+h+Btilde e`, with `e in W_E`. Every bend affecting this coefficient has degree in `W_E`. If a last bend exists, reversing the final segment gives the ray

\[
Q+t(N\nu+h+\widetilde Be),\qquad t\ge0.
\]

Both `Q` and its direction are in the convex cone `U`, so that ray never meets a relevant wall. This contradicts the existence of the last bend. Therefore only the straight line contributes, with correction degree zero and coefficient one. We obtain

\[
\iota_\nu(\vartheta_{N\nu+h})=X^{N\nu+h}\pmod{W_E^c}.
\tag{6.1}
\]

Combining (5.2) and (6.1), and applying inverse transport, proves conclusion (A):

\[
L_{N\nu+h}=\vartheta_{N\nu+h}\pmod{W_E^c}.
\tag{6.2}
\]

Inverse transport preserves the positive-degree filtration, so it cannot reintroduce a discarded term into the window. This establishes exact eventual equality, not a numerical or analytic limit.

## 7. Extraction from an actual multiplication coefficient

Assume now that `L` is an actual basis and that `L_a` has a finite theta expansion

\[
L_a=\sum_p a_{a,p}(v)\vartheta_p.
\tag{7.1}
\]

Pointedness confines contributing labels to `p=a+Btilde e`, `e in N^n`. Here is the finite-support argument, including possible signed coefficients: if an offending label existed, choose one minimal under the positive correction monoid among all offending labels in the finite support. Its leading monomial could not be canceled by another offending label by minimality, and could not be supplied by a label in `a+Btilde N^n`, since positive corrections stay in that cone. This contradicts the pointed support of `L_a`. Full column rank makes the correction monoid sharp and its degrees unambiguous. The same argument later confines the labels in an actual product of pointed basis elements. Fix one target `p=a+Btilde E` and take the box `W_E`.

By the coefficient-isolation argument in Davison--Mandel Theorem 3.16, there is an open chamber of a sufficiently fine finite diagram on which

\[
[X^p]\iota_Q(L_a)=a_{a,p}(v).
\tag{7.2}
\]

The argument is valid for signed finite expansions; positivity is not used to obtain the identity. The following direct last-bend proof also handles targets on walls or with zero mutable part. Choose an integral direction `nu` avoiding all hyperplanes `d^perp` for nonzero `d in W_E`, such that `sign(nu.d)=sign(p_uf.d)` whenever `p_uf.d` is nonzero. A small generic perturbation of `p_uf`, followed by rational approximation and positive integral scaling, gives such a vector. For a broken line whose final exponent is `p`, reverse its final segment: its mutable projection is `nu+t p_uf`, `t>=0`. Pairing this with any relevant wall normal never vanishes, by the chosen signs; if `p_uf.d=0` the pairing is constant and nonzero. Thus a last bend is impossible. Only the straight broken line with label `p` can contribute the monomial `X^p`. This proves (7.2) directly, including the pure-frozen and zero targets. All bends affecting the target have degrees in `W_E` by the pointed-support confinement above.

Apply (5.2) simultaneously to the multiplier and every output offset in

\[
H_0=\{0\}\cup\{a+\widetilde Bf:f\in W_E\}.
\tag{7.3}
\]

Expand the actual product

\[
L_aL_{N\nu}=\sum_r c_{a,N\nu}^{\ r}(v)L_r.
\]

Only labels `r=a+Nnu+Btilde f` with `f in W_E` can contribute to the coefficient of `X^{Nnu+p}` in the chosen chart. All such output basis elements are monomials within the remaining window by (5.2). The multiplier also becomes its leading monomial. Therefore

\[
\begin{aligned}
c_{a,N\nu}^{\ N\nu+p}(v)
 &= [X^{N\nu+p}]\bigl(\iota_\nu(L_a)X^{N\nu}\bigr)\\
 &=v^{\Lambda(p,N\nu)}[X^p]\iota_\nu(L_a)\\
 &=v^{\Lambda(p,N\nu)}a_{a,p}(v).
\end{aligned}
\tag{7.4}
\]

The large label `Nnu` depends on the target coefficient and its fixed window. Every threshold is a maximum over a finite set; no growing window is used.

Equation (7.4) proves (Bq) if the actual multiplication coefficients are in `N[v^{±1}]`. Multiplication by the Laurent unit `v^{Lambda(p,Nnu)}` preserves coefficientwise nonnegativity.

If only the classical specializations of the actual structure constants are nonnegative, specialize the already proved exact identity at `v=1`. Then

\[
a_{a,p}(1)=c_{a,N\nu}^{\ N\nu+p}(1)\in\mathbb N,
\]

which proves (Bc). The coefficients `a_{a,p}` are integral Laurent polynomials because (7.2) extracts them from integral scattering transport. Davison--Mandel Proposition 4.8 identifies specialization of quantum theta functions with the classical theta functions.

This conclusion uses positivity only once: at the actual structure constant in (7.4). In particular it does not infer positive transition from ordinary Laurent positivity of the two bases.

**Positive-transition corollary.** Under the rigidity theorem's hypotheses, suppose the formal family is an actual algebra basis and the element under consideration has a finite theta expansion. If the basis multiplication constants belong to `N[v^{±1}]`, then the coefficients of that theta expansion belong to `N[v^{±1}]`. If instead only their values at `v=1` are nonnegative integers, the classical theta expansion has coefficients in `N`. The same statements hold for arbitrary full-column-rank coefficient extensions and compatible forms by the direct componentwise proof in Section 8. A common triangular basis supplies the required identification with the formal family; its definition does not supply the positivity assumption.

### Finite theta span

There are two ways to discharge the finiteness hypothesis in applications. For elements of the ordinary quantum cluster algebra, Davison--Mandel Proposition 4.14 gives `A_ord subset A_mid`, where the middle algebra is the algebraic finite theta span. For an injective-reachable full-rank upper cluster algebra, Qin 1902.09507v4 Theorem A.1.5 (printed pp. 59--60) states that every theta function is Laurent and the theta family is a basis, explicitly citing **GHKK Proposition 8.25 in the published numbering**. In the locally archived arXiv 1411.1394v2 this statement is **Proposition 8.28**; the difference is a version-numbering issue. The positive and negative cluster chambers give the large-cluster-complex condition used there. For the quantum version, Qin Remark 1.2.5 and Section 6.2 (printed pp. 54--55) explicitly state that the quantum theta functions of Davison--Mandel become a basis for the skew-symmetric injective-reachable quantum upper cluster algebra; the full-rank assumption is maintained. In applications one must name the applicable statement, rather than silently replacing a formal expansion by a finite one.

## 8. Direct extension to arbitrary compatible full-rank seeds

The proof does not require transporting actual basis existence from a principal-coefficient seed. Let `Btilde` be any full-column-rank extension of the same skew-symmetric mutable matrix, let the frozen variables be inverted, and let `Lambda` be a compatible skew form. On each connected mutable component compatibility has a single positive multiplier `delta`, so

    Lambda(g,Btilde d) = -delta g_uf.d,
    Lambda(Btilde d,Btilde e) = delta d^T B e.

The mutable--mutable block of `Lambda` need not vanish. Normalize the injective variables by frozen factors to leading degrees `-e_i`. These variables now q-commute, with the same commutation as the monomials `X^{-e_i}`. Their **normalized** product is

    J^b = Ad_(H^{-1})(X^{-b}).

For `g=a-b`, with `a=g_+`, `b=g_-` in mutable coordinates and an arbitrary frozen factor restored by normalization, the actual injective standard is

    I_g = v^{-Lambda(a,-b)} X^a Ad_(H^{-1})(X^{-b})
        = X^g tau_b(H^{-1}) H.

The first scalar exactly cancels the leading phase in `X^a X^{-b}`. No correction-dependent phase is introduced by a frozen translation, because compatibility gives `Lambda(h_fr,Btilde d)=0`. Thus the three-factor identity (4.1) holds without a principal-coefficient assumption. For a connected matrix every occurrence of a dot product or `d^T B e` in (4.2)--(4.4) is multiplied by the same `delta`. The decay bound becomes

    deg_infty coefficient_e <= -N delta |nu.e| + C_e.

This still tends strictly to minus infinity for every nonzero degree in the fixed generic window. Laurent integrality, bar preservation, and Qin uniqueness work over the original parameter ring `Z[v^{±1}]`; it is unnecessary to assert that every coefficient lies in the smaller subring `Z[v^{±delta}]`.

### Independent two-factor verification

The fresh audit supplies a second direct expression. Write `H=TF`, as before. For normalized products one has

    Ad_F(I_g) = [ Ad_F(X^a) Ad_(T^{-1})(X^{-b}) ].

The first factor has corrections `d` with `nu.d<0`; the second has corrections `e` with `nu.e>0`. Expanding a conjugation directly gives, uniformly in the positive vectors `a,b`,

    deg coefficient_d of Ad_F(X^a) <= delta a.d + C_d,
    deg coefficient_e of Ad_(T^{-1})(X^{-b}) <= delta b.e + C'_e.

For example, a term of the first conjugation is indexed by `u+w=d` and has variable exponent `delta a.(u-w)`, bounded above by `delta a.d`; all remaining phases and rational-function degrees depend only on the fixed finite window. After multiplying the two normalized expansions, the extra phase is

    -delta b.d -delta a.e +delta d^T B e.

Consequently the total degree is at most

    delta(g.d-g.e)+C_(d,e).

For `g=Nnu+h` the support signs force the same strictly negative slope for every nonleading term. Arbitrary mutable--mutable phases have canceled in the leading normalization. This independently reproduces the three-factor estimate without a coefficient-transfer theorem.

### Different multipliers on disconnected components

If the mutable graph has connected components `C_j`, the multipliers `delta_j` may differ. A direct substitution of a weighted pairing into the global sign inequality would be unjustified, since a wall's side is determined by `nu.d`, not by a weighted sum. Instead factor the scattering construction by components.

Correction vectors of distinct components satisfy

    Lambda(Btilde d_i,Btilde d_j)=0  for i != j.

A full leading degree can be decomposed into pieces with mutable support in the respective components, assigning frozen exponents arbitrarily. The correction vectors in one component also pair trivially with the leading degree in every other component. Therefore the component scattering path groups commute; all phases between component expansions equal the constant leading phase, independent of their correction degrees.

After removing that phase, the product of component injective standards is the global standard. Its transported coefficient at a degree `e` is the product of the coefficients at its uniquely determined component degrees `e_j`. Shared frozen variables cause no obstruction, because compatibility kills their pairing with correction vectors. No separate factorization theorem for the common triangular basis or theta basis is needed.

Applying the connected standard-element degree estimate in each component gives the bound

    deg_infty coefficient_e <= -N sum_j delta_j |nu_j.e_j| + C_e.

Genericity on the whole box implies genericity on each component sub-box. Every nonzero `e` therefore has a strictly negative slope. Taking the maximum of the finitely many component thresholds proves global rigidity for the original compatible seed. The actual-basis coefficient extraction in (7.4) is then performed in that same seed, so no actual-basis existence or positivity is transferred from a different coefficient system.

The coefficient-similarity statements of Qin 2407.02480v4 Proposition 4.18 and Qin 2508.12761v2 Theorem 6.10(2) provide an optional independent consistency check. They are no longer required by this proof. Full column rank, inverted frozen variables, skew-symmetry of the mutable matrix, and injective reachability remain explicit. Rank-deficient descent is not asserted here without separate independence and identification arguments.

## 9. Failed attempts, numerical pressure, and remaining review points

1. The initial guess `g.e=0` for every nonleading nonzero transition is false. Existing acyclic computations have nonzero coefficients with `g.e=1` and larger values. It is not used.
2. The stronger numerical support guess `|g.e|<=-q_B(e)` is not proved by this argument and is not needed. The constants in (4.5) are finite but not identified with that quadratic expression.
3. A vector generic only for the requested target degree is not enough for a whole-window claim. The probe `nu=(1,2,-3,5)` has `nu.(1,1,1,0)=0`; its transported standard coefficient at that degree has highest exponent `2` for `N=1,2,5,10,20`. This is an expected boundary case, not a counterexample to (3.1)--(4.6).
4. The same `standard_chart_probe.py` tested three other directions in the genuine cyclic rank-four family. Their nonleading highest exponents became strictly negative and decreased linearly. The computational branch then tested the whole cap-2222 box for the generic direction `(5,5,-4,-4)` and two offsets: the standard-chart maximum degree is `11-N` for the zero offset; it is still `1` at `N=10`, becomes `-1` at `N=12`, and `-9` at `N=20`. The formal CT chart becomes an exact monomial at both `N=12` and `20` for both offsets. This nontrivial threshold is consistent with the finite-constant bound. These checks are finite validation of conventions only.
5. Rational-function degree alone does not imply the bar-vanishing conclusion. Integral Laurent preservation from Section 3 is indispensable.
6. Strong positivity is not an axiom of the common triangular basis. The explicit source gap for the widest original formulation must remain visible even if all of (A)--(Bc) pass audit.

Adversarial review should stress the following six interfaces: the actual injective variables and normalized frozen translation; the full rather than center-quotiented path group; the order `H=TF`; Laurent integrality of transport in both directions; simultaneous input/output windows; and applicability of a finite theta expansion and actual multiplication positivity in the claimed algebra.

## 10. Primary sources read for this proof

- Fan Qin, [An introduction to representation-theoretic canonical bases of cluster algebras, arXiv:2508.12761v2](https://arxiv.org/abs/2508.12761v2), Section 6.1, Lemma 6.2, Definitions 6.3--6.4, Proposition 6.5, Theorems 6.10 and 6.11. The proof uses the precise `v^{-1}Z[v^{-1}]` convention.
- Ben Davison and Travis Mandel, [Strong positivity for quantum theta bases of quantum cluster algebras, arXiv:1910.12915v3](https://arxiv.org/abs/1910.12915v3), Theorem 2.15, quantum-binomial wall actions, Lemma 3.4, Theorem 3.16, Propositions 4.8--4.9, Corollary 4.13, Proposition 4.14. These supply quantum diagram properties and coefficient extraction, not the desired CT transition.
- Fan Qin, [Dual canonical bases and quantum cluster algebras, arXiv:2003.13674v3](https://arxiv.org/abs/2003.13674v3), Remark 1.2.1 and the triangular-family uniqueness/existence interfaces cited by the survey.
- Fan Qin, [Triangular bases for cluster algebras from Lie theory, arXiv:2407.02480v4](https://arxiv.org/abs/2407.02480v4), Definition 4.1 and Proposition 4.18, for the separately stated coefficient-similarity transfer.
- Gross--Hacking--Keel--Kontsevich, [Canonical bases for cluster algebras, arXiv:1411.1394v2](https://arxiv.org/abs/1411.1394v2), Proposition 8.28 in that arXiv version (published numbering 8.25 as cited by Qin); Qin [arXiv:1902.09507v4](https://arxiv.org/abs/1902.09507v4), Theorem A.1.5, Remark 1.2.5, and Section 6.2, for the finite upper theta basis scope when needed.

Two search-engine queries for an already published asymptotic CT/theta bridge did not locate a directly applicable theorem. This limited search result is not a priority claim or a statement that no such result exists.


---

## Part II. Independent adversarial audit

# Independent adversarial audit: the finite-window degree bridge

**Audit timestamp:** 2026-10-31 05:09:17 UTC

**Auditor:** `degree_bridge_redteam`, a fresh-context branch.  
**Candidate reviewed:** `agents/asymptotic_mechanism/GENERAL_ASYMPTOTIC_PROOF.md`.  
**Decision:** the finite-window rigidity argument passes this internal mathematical audit under the hypotheses stated below. The subsequent positivity theorem passes with an explicit, additional multiplication-positivity hypothesis. This is an internal proof review, not external peer review or a claim that the widest original conjecture has been resolved.

## 1. Exact conclusions and remaining scope

Let \((\widetilde B,\Lambda)\) be a finite-rank compatible quantum seed, with skew-symmetric mutable matrix \(B\), all frozen variables inverted, and an injective-reachable seed. Use normalized torus monomials
\[
X^mX^{m'}=v^{\Lambda(m,m')}X^{m+m'},\qquad
\overline v=v^{-1},\quad\overline{X^m}=X^m.
\]
The bar is an anti-automorphism. Compatibility is
\[
\Lambda\widetilde B=-\binom{D}{0},
\qquad D=\operatorname{diag}(\delta_i),\qquad\delta_i>0.
\tag{1}
\]
For skew-symmetric \(B\), the \(\delta_i\) are constant on each mutable connected component. A compatible pair already forces \(\widetilde B\) to have full column rank.

The audited conclusions are:

1. **Formal triangular rigidity.** Qin's formal triangular family, defined from the actual injective standard family, becomes a leading monomial in any prescribed finite positive-degree window, in the chart of a sufficiently generic integral direction, along sufficiently large positive multiples of that direction. The threshold is uniform under any finite collection of fixed label translations.
2. **Theta comparison in the same window.** The corresponding theta functions become the same leading monomials in that chart. Thus the triangular and theta families agree in every fixed window eventually along the chosen ray.
3. **Exact extraction.** For every actual triangular-basis element \(L_a\) and every coefficient \(A_{a,p}(v)\) in its theta expansion, one can choose an integral direction \(\nu\) and an integer \(N_0\) such that
   \[
   [L_{N\nu+p}](L_aL_{N\nu})
   =v^{\Lambda(p,N\nu)}A_{a,p}(v)
   \qquad(N\ge N_0).
   \tag{2}
   \]
4. **Conditional quantum positivity.** If the actual basis has multiplication structure constants in \(\mathbb N[v^{\pm1}]\), then all its theta-expansion coefficients belong to \(\mathbb N[v^{\pm1}]\).
5. **Conditional classical positivity.** It suffices for the actual multiplication structure constants to become nonnegative integers at \(v=1\) to conclude nonnegative integral classical theta expansions. Quantum coefficientwise positivity is stronger than what this classical conclusion requires.

Item 1 does not require an actual basis or any multiplication positivity. Items 3–5 require an actual basis so that a product has actual basis structure constants. Common triangularity alone does not supply the positivity hypothesis in item 4 or 5.

The strongest original arbitrary-common-triangular-basis formulation therefore remains conditional unless multiplication positivity is independently available. Qin's symmetric-Cartan Lie-theoretic results supply that hypothesis in their stated scope. The independently certified cyclic word models can use those results; one must not silently extend them to every hypothetical skew-symmetric common triangular basis.

## 2. Deduplication against earlier materials

Before assessing novelty of the mechanism, I read the recovered rank-two proof in
`history/old_records/LLRZ16_研究记录.txt`, sections corresponding to lines 425–1086. The old proof already contains:

- a rank-two standard-monomial degree envelope;
- fixed-window asymptotic rigidity;
- a common angular scattering chart;
- extraction of a transition coefficient from one strongly positive multiplication coefficient;
- explicit control of both the input and output windows.

Those ideas and the rank-two theorem must not be claimed as new in this run. The new candidate supplies an all-rank degree estimate for Qin's **actual injective standard family**, using the full cluster scattering diagram. It replaces the rank-two Newton-vertex and angular-Gauss arguments. The proof below is an independent two-factor reconstruction; the authoring branch uses a three-factor formula.

The 2026 Hexagon preprint present in the old record is not used as a proof input in this audit. It is relevant only to the deduplication history. No new mathematical inference below depends on an unaudited 2026 source.

## 3. Finite windows and support conventions

Write
\[
Y^d=X^{\widetilde B d},\qquad d\in\mathbb N^n.
\]
A window is a finite box
\[
W_E=\{d\in\mathbb N^n:0\le d_i\le E_i\}.
\]
Its complement is a monoid ideal. Adding a positive degree to a discarded degree cannot return it to \(W_E\). Consequently all products, inverses of series with constant term one, substitutions between pointed families, and scattering transports can be computed in the corresponding finite quotient.

This fact is essential. The argument never computes a growing window and then asserts uniform convergence. Every statement concerns one fixed target window, and its threshold is a maximum of finitely many bounds.

Choose an integral mutable vector \(\nu\) satisfying
\[
\nu\cdot d\ne0\qquad(0\ne d\in W_E).
\tag{3}
\]
Only finitely many hyperplanes are excluded. Such an integral vector can be found inside every nonempty rational open cone, after taking a rational point and scaling it. This does **not** assert that an integral point avoids all walls of the infinite scattering diagram. All chart choices here are understood modulo \(W_E^c\), and an actual generic endpoint in the same finite chamber can be used whenever a full diagram representative is desired.

When several finite windows occur, take their coordinatewise maximum first. The label-offset set must also include every lower standard label needed by Qin's triangular expansion. Enlarging the offset set does not change the finite nature of the argument.

## 4. The actual injective standard family and the full path group

Let \(C_+\) be the initial positive cluster chamber and \(C_-\) the negative chamber supplied by injective reachability. The latter assertion is precise: after permuting the injective cluster variables, their mutable leading degrees are \(-e_i\); their full leading degrees differ from these by frozen translations. The cone generated by those degrees, together with unrestricted frozen directions, projects to the whole negative mutable orthant.

Normalize each injective variable by an appropriate frozen Laurent monomial to obtain \(J_i\) with full leading degree \((-e_i,0)\). If \(h\) is a frozen exponent, compatibility gives
\[
\Lambda(h,\widetilde B d)=0.
\tag{4}
\]
Therefore normalized multiplication by \(X^h\) translates an entire pointed expansion without introducing a correction-degree-dependent phase.

The cluster-chart identification, and the fact that localized cluster monomials are theta functions, give
\[
\operatorname{Ad}_H(J_i)=X^{-e_i},
\tag{5}
\]
where \(H\) is the full cluster-scattering path element from \(C_+\) to \(C_-\).

No center is discarded. A degree central inside the \(Y\)-torus may still pair nontrivially with an \(X^m\) in the full \(A\)-torus. Quotienting it out would invalidate (5) and the degree estimate.

For \(a,b\in\mathbb N^n\), \(g=a-b\), \(a_ib_i=0\), write \(J^b\) for the **normalized** cluster monomial. Then
\[
J^b=\operatorname{Ad}_{H^{-1}}X^{-b}.
\]
For arbitrary \(\Lambda_{\mathrm{mut},\mathrm{mut}}\), the standard element is
\[
I_g=v^{-\Lambda(a,-b)}
 X^a\operatorname{Ad}_{H^{-1}}X^{-b}.
\tag{6}
\]
The displayed scalar normalizes its leading coefficient to one. In the canonical principal quantization \(\Lambda_{\mathrm{mut},\mathrm{mut}}=0\), it is one. In a general quantization it must not simply be omitted.

Equation (6) is Qin's standard family, after the harmless frozen translation restoring the desired full degree. It is not an arbitrary family of positive Laurent polynomials.

## 5. Two half-paths and their support signs

Work in the finite diagram relevant to \(W_E\). Take a generic straight path from a positive point to the chart of \(\nu\), and then a generic straight path from that chart to a negative point. Let the two path elements be \(F,T\), respectively. With the first path applied first,
\[
H=TF,\qquad \iota_\nu=\operatorname{Ad}_F.
\tag{7}
\]

A wall normal \(d\in\mathbb N^n\setminus0\) crossed by the first segment satisfies \(\nu\cdot d<0\): its pairing at the positive endpoint is positive, and a linear function can cross zero on the segment only if its value at the other endpoint is negative. Similarly, a wall crossed by the second segment has \(\nu\cdot d>0\).

Products and formal inverses preserve these strict half-cone supports. Hence, modulo the window,
\[
F=1+\sum_{\nu\cdot d<0}f_d(v)Y^d,\qquad
T^{\pm1}=1+\sum_{\nu\cdot d>0}t_d^{\pm}(v)Y^d.
\tag{8}
\]
The coefficients here may be rational functions and need not be positive. No positivity of a Donaldson–Thomas series is used.

Applying \(\operatorname{Ad}_F\) to (6) and using \(FH^{-1}=T^{-1}\) gives the exact two-factor identity
\[
\iota_\nu(I_g)=
v^{-\Lambda(a,-b)}
 \operatorname{Ad}_F(X^a)
 \operatorname{Ad}_{T^{-1}}(X^{-b}).
\tag{9}
\]
This independently checks the order of the half-paths and the inverse on the second factor.

## 6. The independent all-rank degree estimate

First suppose the mutable matrix is connected, so \(D=\delta I\). Compatibility implies
\[
\Lambda(\widetilde B u,m)=\delta\,u\cdot m_{\mathrm{mut}},
\qquad
\Lambda(\widetilde B u,\widetilde B w)=\delta\,u^TBw.
\tag{10}
\]

Let \(K=1+\sum_{d>0}k_d(v)Y^d\) be any fixed positive-degree series over \(\mathbb Q(v)\), and \(K^{-1}=\sum_{d\ge0}\ell_d(v)Y^d\). The coefficient of \(X^{m+\widetilde B e}\) in \(\operatorname{Ad}_K(X^m)\) is
\[
\sum_{u+w=e}
 k_u(v)\ell_w(v)
 v^{\delta\,m_{\mathrm{mut}}\cdot(u-w)+\delta\,u^TBw}.
\tag{11}
\]
This formula follows by multiplying \(Y^uX^mY^w\); it is valid for arbitrary mutable-mutable block of \(\Lambda\), and arbitrary frozen coordinates in \(m\).

Let \(\deg_\infty\) denote rational degree at \(v=\infty\). For fixed \(e\) and \(m_{\mathrm{mut}}\ge0\), (11) gives
\[
\deg_\infty [X^{m+\widetilde B e}]\operatorname{Ad}_K(X^m)
\le \delta\,m_{\mathrm{mut}}\cdot e+C_{K,e}.
\tag{12}
\]
For \(m_{\mathrm{mut}}=-b\le0\), the same argument gives the upper bound \(\delta\,b\cdot e+C_{K,e}\). The constants depend only on finitely many rational coefficients of \(K,K^{-1}\), \(B,\delta,e\), not on \(m\).

Apply these bounds to the two factors in (9), at correction degrees \(e_1,e_2\). Their product, after normalization by the leading scalar in (9), contributes the additional phase
\[
\begin{aligned}
&\Lambda(a+\widetilde B e_1,-b+\widetilde B e_2)-\Lambda(a,-b)\\
&\qquad=-\delta\,b\cdot e_1-\delta\,a\cdot e_2
       +\delta\,e_1^TBe_2.
\end{aligned}
\tag{13}
\]
In particular, every dependence on the arbitrary mutable-mutable block has canceled.

Combining (12) and (13), the contribution at \(e=e_1+e_2\) has degree at most
\[
\delta\,g_{\mathrm{mut}}\cdot e_1
-\delta\,g_{\mathrm{mut}}\cdot e_2+C_{e_1,e_2}.
\tag{14}
\]
By (8), every nonzero \(e_1\) contributing to the first factor satisfies \(\nu\cdot e_1<0\), and every nonzero \(e_2\) contributing to the second satisfies \(\nu\cdot e_2>0\).

For \(g=N\nu+h\), with \(h\) in a fixed finite set, (14) is therefore bounded above by
\[
-\delta N\bigl(|\nu\cdot e_1|+|\nu\cdot e_2|\bigr)+C'_{e_1,e_2,h}
\le-\delta N|\nu\cdot e|+C'_{e_1,e_2,h}.
\]
There are finitely many decompositions \(e=e_1+e_2\) in the fixed window and finitely many offsets \(h\). Taking their maximum proves
\[
\deg_\infty [X^{N\nu+h+\widetilde B e}]
 \iota_\nu(I_{N\nu+h})
\le-\delta N|\nu\cdot e|+C_e.
\tag{15}
\]
Condition (3) makes this strictly negative for every nonzero \(e\in W_E\) after one finite threshold.

This is a proof for arbitrary finite rank, rather than an extrapolation from ranks \(1,2,3,\ldots\).

### 6.1 Disconnected matrices and different multipliers

It is wrong simply to replace \(\nu\cdot e\) by \(\nu^TDe\) in the geometric sign argument. For example
\[
\nu=(1,-1),\quad e=(1,2),\quad D=\operatorname{diag}(3,1)
\]
satisfy \(\nu\cdot e=-1\), but \(\nu^TDe=1\).

The repair uses the component decomposition. If \(c\ne c'\) are mutable connected components, then
\[
\Lambda(\widetilde B d_c,\widetilde B d_{c'})=0,\qquad
\Lambda(m_c,\widetilde B d_{c'})=0
\tag{16}
\]
whenever \(m_c\) has mutable coordinates supported in \(c\). Frozen entries of \(m_c\) do not affect the second identity, by (4).

The initial scattering Lie algebras of distinct components commute. Their consistent completions can therefore be combined without producing mixed-component wall normals. By uniqueness of consistent scattering completion, one may use this componentwise diagram. The full \(F,T,H\) factor into commuting component elements.

Equation (16) means that the coefficient of a global normalized standard element at degree \(e=(e_c)_c\) is the product of the corresponding component coefficients. Nontrivial leading phases between different mutable components, if the chosen \(\Lambda\) has them, are constant in all correction degrees and are removed by normalized multiplication.

Consequently the global estimate is
\[
\deg_\infty [X^{N\nu+h+\widetilde B e}]
 \iota_\nu(I_{N\nu+h})
\le -N\sum_c\delta_c|\nu_c\cdot e_c|+C_e.
\tag{17}
\]
If \(e\ne0\), at least one component contributes a strictly negative slope under (3), applied also to each component-supported subdegree. This proves the degree lemma in general. No factorization theorem for the actual common triangular basis is needed: the global Qin expansion will be applied next.

## 7. Laurent integrality and bar: the indispensable interface

A rational function can be bar invariant with negative degree at infinity. The example
\[
\frac1{v+v^{-1}}
\]
has both properties and is nonzero. Thus (15) alone cannot imply vanishing.

For the **specific elements needed here**, Laurent integrality follows without any difficult assertion about all rational group elements:

- every \(I_g\) is a normalized product of localized cluster monomials;
- those cluster monomials are theta functions by Davison–Mandel Corollary 4.13;
- every theta function has integral Laurent coefficients in every scattering chart by their Theorem 3.9;
- a coefficient at fixed positive degree in a finite product is a finite sum of products of such Laurent polynomials and Laurent units.

It follows that each coefficient of \(\iota_\nu(I_g)\) is in \(\mathbb Z[v^{\pm1}]\). Equation (15), or (17), therefore places the nonleading coefficients in \(v^{-1}\mathbb Z[v^{-1}]\) eventually.

The path transport commutes with bar. Davison–Mandel Theorem 2.15 supplies bar-invariant wall data and Lemma 3.4 proves that the corresponding adjoint actions preserve bar-invariant normalized monomials. The opposite orientation also preserves bar because it is the inverse of a bar-commuting invertible linear operator. Products of such actions preserve bar.

One can prove preservation of the entire integral completed quantum torus from the quantum-binomial formulas in their equations (20)–(23), together with the odd plethystic factors (28)–(30). That stronger statement is not required for the argument above. In particular, inverse wall actions need not have positive coefficients; only integrality and bar preservation are relevant.

## 8. Qin's formal negative-parameter correction forces rigidity

For Qin's actual injective standard family, the formal triangular element satisfies
\[
L_g=I_g+\sum_{f\in\mathbb N^n\setminus0}
 c_{g,f}(v)\,I_{g+\widetilde B f},
\qquad
c_{g,f}(v)\in v^{-1}\mathbb Z[v^{-1}],
\qquad \overline{L_g}=L_g.
\tag{18}
\]
This is Qin 2508.12761v2, Lemma 6.2; the detailed formal construction and uniqueness appear in 2003.13674v3, Theorem 6.1.3 and Lemma 6.1.4. For an actual triangular basis, identification with this family is not an assumption invented here: it is Lemma 6.2.4 of the latter paper, or the statement immediately after Definition 6.3 in the survey.

Fix the desired initial offset set \(H_0\). Apply the degree lemma to the enlarged finite set
\[
H=\{h+\widetilde Bf:h\in H_0,\ f\in W_E\}.
\]
At a coefficient of correction degree \(e\in W_E\), only terms \(f\le e\) from (18) contribute. This is a finite set, even though the full sum in (18) can be infinite.

After transport, every nonleading coefficient is a sum of:

- a negative-degree Laurent coefficient of the leading standard element; and
- a coefficient \(c_{g,f}\in v^{-1}\mathbb Z[v^{-1}]\), multiplied by either \(1\) or a negative-degree Laurent coefficient of a lower standard element.

Every such sum belongs to \(v^{-1}\mathbb Z[v^{-1}]\). Bar invariance of \(L_g\) and bar preservation of transport make the same coefficient bar invariant. Their intersection is zero. Therefore
\[
\iota_\nu(L_{N\nu+h})=X^{N\nu+h}
 \pmod{W_E^c}
\tag{19}
\]
for all sufficiently large \(N\), uniformly for \(h\in H_0\).

There is no circular use of actual CT multiplication positivity here.

## 9. Theta monomialization and coefficient isolation

### 9.1 Large-label monomialization

Choose a convex open cone \(U\) around the finite-generic direction \(\nu\), avoiding every relevant hyperplane. For all sufficiently large \(N\), every possible final exponent
\[
N\nu+h+\widetilde B e,\qquad h\in H_0,\ e\in W_E,
\]
lies in \(U\).

If a broken line contributing to that window had a last bend, its final segment, traversed backwards from endpoint \(Q=\nu\), would lie on
\[
Q+t(N\nu+h+\widetilde B e),\qquad t\ge0.
\]
This ray stays inside the convex cone \(U\), hence meets no relevant wall. That contradicts a last bend. Only the straight line remains, and
\[
\iota_\nu(\vartheta_{N\nu+h})=X^{N\nu+h}\pmod{W_E^c}.
\tag{20}
\]

Combining (19) and (20), then applying inverse transport, proves fixed-window equality of \(L\) and \(\vartheta\). Inverse transport respects the positive-degree monoid ideal, so discarded terms cannot return.

### 9.2 Direct target-coefficient isolation, including targets on walls

Fix \(p=a+\widetilde B E\). All theta labels that can contribute to its monomial in a pointed expansion lie in the finite interval from \(a\) to \(p\). All relevant wall normals lie in \(W_E\).

Choose a generic integral \(\nu\) satisfying
\[
\operatorname{sgn}(\nu\cdot d)
=\operatorname{sgn}(p_{\mathrm{mut}}\cdot d)
\quad\text{whenever }p_{\mathrm{mut}}\cdot d\ne0,
\quad 0\ne d\in W_E,
\tag{21}
\]
and merely \(\nu\cdot d\ne0\) for the remaining normals. Such choices exist: perturb \(p_{\mathrm{mut}}\) slightly to avoid finitely many hyperplanes, then take a rational point and scale it. The conditions describe a nonempty open cone.

A broken line ending at \(\nu\) with final exponent \(p\) would have its final segment on the reverse ray
\[
\nu+t p,\qquad t\ge0.
\]
For each relevant normal \(d\), the pairing along this ray is
\[
\nu\cdot d+t\,p_{\mathrm{mut}}\cdot d.
\]
By (21), it either keeps a nonzero sign or is a fixed nonzero constant. Hence the ray meets no relevant wall and no last bend is possible. The only contributing broken line is the straight one whose initial label is \(p\).

This proves, for signed expansions as well as positive ones,
\[
[X^p]\iota_\nu(f)=[\vartheta_p]f.
\tag{22}
\]
It also covers \(p_{\mathrm{mut}}=0\), including a purely frozen target and \(p=0\): the ray is parallel to every wall and cannot meet one from a generic endpoint.

This is the local finite-window argument underlying Davison–Mandel Theorem 3.16. It avoids the ambiguous phrase “\(p\) shares an open chamber” when \(p\) lies on a wall.

## 10. Finite expansions, extremal labels, and both product windows

### 10.1 Why finite pointed expansions have no remote leading labels

Suppose \(f\) is supported in \(a+\widetilde B\mathbb N^n\) and has a finite expansion
\[
f=\sum_{r\in S}\lambda_r B_r
\]
in a pointed family \(B_r=X^r+\text{positive-degree terms}\).

Assume some \(r\in S\) lies outside \(a+\widetilde B\mathbb N^n\). Choose such an \(r\) minimal in the positive-cone order among the finite set of outside labels. A term contributing to the monomial \(X^r\) must come from a leading label \(r'\) with \(r-r'\in\widetilde B\mathbb N^n\).

If \(r'\) were inside \(a+\widetilde B\mathbb N^n\), then \(r\) would be inside too. If \(r'\) were outside and distinct from \(r\), it would contradict minimality. Therefore \(X^r\) has coefficient precisely \(\lambda_r\ne0\), contradicting the support of \(f\).

Thus every nonzero expansion label lies in the same pointed cone. This proof handles incomparable labels and cancellation; it does not assume positivity.

### 10.2 Finiteness is available in the stated scope

For ordinary cluster-algebra elements, Davison–Mandel Proposition 4.14 gives inclusion in the finite theta span.

For the full-rank skew-symmetric injective-reachable upper cluster algebra, Qin 1902.09507v4, Remark 1.2.5, explicitly states that the quantum theta functions form a basis of the quantum upper cluster algebra, using Davison–Mandel. His Appendix A, Theorem A.1.5, gives the classical statement from the large-cluster-complex criterion. Theorem 4.3.1 gives the corresponding basis criterion for a compatibly pointed family.

There is a version-numbering issue to preserve in citations: the local GHKK arXiv:1411.1394v2 text labels the large-cluster-complex result **Proposition 8.28**; Qin cites the published result as **Proposition 8.25**. These are not conflicting mathematical claims. This audit initially flagged the differing number and then resolved it by reading both texts.

Thus a finite theta expansion of an actual \(L_a\) is justified in the stated full-rank injective-reachable upper setting. A claim about a different algebra must recheck the finite-span interface.

### 10.3 Exact extraction from multiplication

Fix
\[
L_a=\sum_p A_{a,p}(v)\vartheta_p,
\qquad p=a+\widetilde B E.
\]
Choose \(\nu\) by (21). Use the rigidity theorem simultaneously for the multiplier and all output offsets
\[
H_0=\{0\}\cup\{a+\widetilde B f:f\in W_E\}.
\tag{23}
\]
The degree-lemma offset set must further include all lower standard labels required by (18), as in Section 8. This is still finite.

The actual product has a finite expansion
\[
L_aL_{N\nu}=\sum_r c_{a,N\nu}^{\,r}(v)L_r.
\]
By the extremal-label argument, every output lies in
\[
a+N\nu+\widetilde B\mathbb N^n.
\]
A label can contribute to \(X^{N\nu+p}\) only if it equals
\(a+N\nu+\widetilde B f\) with \(f\le E\). All such output basis elements have been monomialized in their remaining windows by (19). Hence the target monomial coefficient equals the single structure constant at label \(N\nu+p\).

On the input side, a discarded correction of the multiplier has degree outside \(W_E\). Multiplying by the pointed expansion of \(L_a\) only adds nonnegative degrees, so it cannot contribute to the target. Therefore the multiplier may be replaced by \(X^{N\nu}\) for this coefficient.

These two separate arguments give
\[
\begin{aligned}
c_{a,N\nu}^{\,N\nu+p}(v)
&=[X^{N\nu+p}]\bigl(\iota_\nu(L_a)X^{N\nu}\bigr)\\
&=v^{\Lambda(p,N\nu)}[X^p]\iota_\nu(L_a)\\
&=v^{\Lambda(p,N\nu)}A_{a,p}(v),
\end{aligned}
\]
which is (2).

This is the only point where actual multiplication positivity is invoked. Multiplication by the Laurent unit \(v^{\Lambda(p,N\nu)}\) preserves coefficientwise nonnegativity. At \(v=1\), the unit becomes one.

## 11. Computation performed by this audit branch

I used the Wolfram Language computation plugin for an independent test of the arbitrary-quantization phases, rather than reusing the principal quantization from the candidate.

The executable record is:
`arbitrary_quantization_phase_check.wl`.

The unedited returned result is:
`arbitrary_quantization_phase_check_result.json`.

The test used seed 2026103105 and **12,000 exact integer-matrix trials**, 1,000 at each mutable rank \(1\) through \(12\). Each trial independently sampled:

- a block-skew-symmetric mutable matrix \(B\);
- different positive integer compatibility multipliers on its designated components;
- an arbitrary skew mutable-mutable block (not constrained to zero) \(C\);
- arbitrary frozen exponents and nonnegative correction degrees.

For principal coefficients it formed the general compatible skew matrix
\[
\Lambda=
\begin{pmatrix}
C&-D-CB\\
D+BC&-DB-BCB
\end{pmatrix},
\qquad\widetilde B=\binom BI.
\]
It checked skew symmetry, compatibility, the conjugation phase (11), and the normalized product phase (13), with the \(D\)-weighted versions for disconnected matrices.

All 48,000 checked identities passed. The same run verified the rational bar counterexample and the sign failure of the naive different-multiplier replacement.

These tests verify implementation-level signs and phases. They do not establish an infinite-rank or all-rank quantifier; Sections 5–10 supply the proof. The main project has separate actual-basis calculations, which were not treated as a substitute for this proof.

The Wolfram context search returned no relevant mathematical theorem. Its unrelated documentation snippets were not used as mathematical evidence.

## 12. Audit checklist and failed shortcuts

| Interface | Audit result | Reason or repair |
|---|---|---|
| Actual \(J_i\), not a guessed DT variable | Passed | Negative cluster chamber and cluster-monomial/theta identification; full frozen normalization retained |
| Path order \(H=TF\) | Passed | Compose first \(F\), then \(T\); independently recover (9) |
| Full center retained | Required and satisfied | Central in \(Y\) need not be central in the full \(A\)-torus |
| Arbitrary \(\Lambda_{\rm mut,mut}\) | Passed after explicit normalization | Leading scalar in (6) cancels; (13) depends only on compatibility |
| Different \(\delta_c\) | Naive argument fails; component repair passes | Explicit sign counterexample; commuting component scattering and (17) |
| Rational degree plus bar | Fails alone | \(1/(v+v^{-1})\) is a counterexample |
| Required Laurent integrality | Passed | Standard elements are products of cluster theta functions, with Laurent chart coefficients |
| Bar transport | Passed | DM Theorem 2.15 and Lemma 3.4, including inverse orientations |
| Infinite Qin correction | Passed in fixed window | Only \(f\le e\) can contribute |
| Finite generic \(\nu\) | Passed | Exclude finitely many hyperplanes; no global rational genericity claim |
| Theta final-segment argument | Passed | Convex cone excludes any last bend |
| Target on a wall / frozen target | Passed after explicit form (21) | Pairings on the reverse ray keep sign or remain constant |
| Outside output labels and cancellations | Passed | Finite extremal-label argument, Section 10.1 |
| Input window | Passed | Positive degrees cannot return from the discarded monoid ideal |
| Output window | Passed | Include all \(a+\widetilde Bf\), \(f\le E\), before choosing threshold |
| Finite theta expansion | Passed in stated full-rank injective-reachable scope | Qin Remark 1.2.5, Appendix A; DM Proposition 4.14 for ordinary elements |
| CT multiplication positivity | Extra hypothesis remains | Not a CT definition; must cite its independent source for each claimed family |
| Rank-deficient classical descent | Not claimed | Needs a separate basis-identification and coefficient-descent argument |
| Noninverted frozen model | Not claimed directly | This proof uses the localized full-lattice indexing |
| Finite numerical checks imply theorem | Rejected | Computation checks conventions only; proof is algebraic |

## 13. Source audit ledger

All sources used as mathematical inputs below predate 2026. Their arXiv metadata were independently opened in this audit, and the relevant statements were read in local full text.

| Source | Version / statement checked | Useful for | What it does not prove here |
|---|---|---|---|
| Fan Qin, *An introduction to representation-theoretic canonical bases of cluster algebras* | [arXiv:2508.12761v2](https://arxiv.org/abs/2508.12761v2), revised 2025-09-30; §6.1, Lemma 6.2, Defs. 6.3–6.4, Thm. 6.11 | Exact standard family, formal KL correction, actual CT identification, symmetric-Cartan positivity scope | General CT-to-theta positive transition |
| Fan Qin, *Dual canonical bases and quantum cluster algebras* | [arXiv:2003.13674v3](https://arxiv.org/abs/2003.13674v3), revised 2023-05-15; Def. 2.5.1, Thm. 6.1.3, Lemma 6.1.4, equation (6.1), Lemma 6.2.4, Remark 1.2.1 | Injective reachability, formal correction, actual triangular identification; positivity is a separate issue | A universal skew-symmetric strong-positivity theorem from CT axioms alone |
| Ben Davison and Travis Mandel, *Strong positivity for quantum theta bases of quantum cluster algebras* | [arXiv:1910.12915v3](https://arxiv.org/abs/1910.12915v3), revised 2021-06-15; Thm. 2.15, eqs. (20)–(30), Lemma 3.4, Thms. 3.9 and 3.16, Prop. 4.9, Cor. 4.13, Props. 4.8 and 4.14 | Integral/bar scattering interfaces, cluster chart identification, theta coefficient isolation, classical specialization, finite span for ordinary elements | Positivity of the triangular basis or its transition matrix |
| Fan Qin, *Bases for upper cluster algebras and tropical points* | [arXiv:1902.09507v4](https://arxiv.org/abs/1902.09507v4), Remark 1.2.5, Thm. 4.3.1, §6.2, Appendix A.1.5 | Full quantum theta basis in the injective-reachable full-rank upper setting | New asymptotic degree estimate |
| Gross, Hacking, Keel, Kontsevich, *Canonical bases for cluster algebras* | [arXiv:1411.1394v2](https://arxiv.org/abs/1411.1394v2), Prop. 8.28; published numbering quoted by Qin as Prop. 8.25 | Large cluster complex and full theta basis interface | CT multiplication positivity |
| Recovered prior package | `history/old_records/LLRZ16_研究记录.txt`, old proof §§1–11 | Deduplication and exact comparison of mechanisms | Not an externally reviewed source for the new all-rank lemma |

**Final scope decision:** the proof candidate survives this adversarial audit, after making the stated phase, component, finite-support, and source-version details explicit. The strongest unconditional consequence is for actual common triangular bases whose positive multiplication is independently established. The audit does not turn the existence of an arbitrary common triangular basis into that positivity theorem.



---

## Part III. Fresh global adversarial audit and effective refinements

# 全局换基桥梁的再次对抗性审核

审核者：`global_bridge_adversary`。开始：2026-10-31 05:34:27 UTC。本文只记录本分支独立检查、改进与结论，不修改原主证明或旧证书。

## 1. 审核决定

**未找到主桥在其明确假设下的反例或致命逻辑缺口。** 有限窗口刚性、实际乘法系数提取、带独立乘法正性假设的 theta 非负展开，均通过本次内部审核。它不是外部同行评议，也不是最宽原猜想已经解决的宣告。

本次审核得到三个需要纳入最终表述的具体补充：

1. 可以完全显式地选取逐系数提取所需的整方向，避免“先找 generic 方向”的搜索：若 `E≠0`，取 `ν=(1+ΣE_i)p_mut+1` 即可。
2. 标准元负次数阈值、CT 图表单项式阈值、theta 的几何单项式阈值，必须分别标注。当前实例的 CT 阈值 10 与乘法抽取相符；若只使用最强的“所有偏移、整个窗口、所有法向量同锥”条件，旧方向给 theta 充分阈值 23，新方向给 11。采用逐末次折弯的正确剩余窗口，两方向均给充分阈值 7，所以乘法真正需要的窗口在 `N≥10` 亦同时满足 theta 单项式化。没有任何一个较大的保守界构成反例。
3. DM 1910.12915v3 的 Theorem 3.10 展示式首项漏印量子相位；其 Theorem 1.1 同时给出正确相位。本轮主证明保留了相位，因此不受影响。

额外核查确认：任意兼容形式的 mutable–mutable 交叉相位在标准元归一化后确实抵消；断连 mutable 块、不同兼容乘子、共享冻结变量均可按主证明的分量方法处理。不能将这一结论扩到未证明系数变化的秩亏情形。

## 2. 旧材料预查与本次审核范围

先读 `notes/OLD_MATERIAL_REFRESH_0528.md`、`notes/ASYMPTOTIC_ROUTE_PRECHECK.md`，再直接检查第一轮旧记录中秩二定理的开头与最终应用（原记录约425–475、1040–1086行）。旧材料已经有“远端窗口刚性＋大标签乘子提取正结构常数”的秩二框架。本文不主张该思想或秩二结论是新结果。

本次重新检查的对象是：

- `results/GENERAL_FINITE_WINDOW_THEOREM.md` 的完整主证明与已有独立审稿；
- `results/EFFECTIVE_FINITE_CERTIFICATION.md` 及实际阈值代码；
- 原始 Qin 标准元定义、参数/系数变化定理、量子 theta 的整性与有限基范围；
- 原始 word 输入与参数 `u=v_Lie²` 的含义；
- 双侧 framing 反机制的 DWZ 归纳与商空间区别，作为辅助范围审核。

本文使用的数学定理输入都是已取得固定版本的旧文。没有将新发现的 2026 论文加入主证明依赖。

## 3. 从原始代数重新检查标准元与相位

设 `B̃` 满列秩、mutable 部分 `B` 反对称，兼容形式满足

\[
\Lambda\widetilde B=-\binom D0,\qquad D=\operatorname{diag}(\delta_i)>0.
\]

于是

\[
\Lambda(m,\widetilde Bd)=-m_{\rm mut}^{\mathsf T}Dd,
\qquad
\Lambda(\widetilde Bd,\widetilde Be)=d^{\mathsf T}DB e.
\]

由第二式的反对称性得到 `DB=BD`，故 `δ_i` 在每个 mutable 连通分量上常数。冻结向量 `h_fr` 与每个修正向量 `B̃d` 配对为零。因此冻结平移的归一化只改变整条展开的标签，不改变各修正系数。

injective reachability 提供 full leading degree 为 `−e_i+frozen` 的实际簇变量；冻结归一化后记为 `J_i`。它们在负簇腔中的展开为 `X^(−e_i)`。由簇图表与散射图表的识别，若完整路径元为 `H`，则

\[
J_i=\operatorname{Ad}_{H^{-1}}X^{-e_i}.
\]

对 `g=a−b`，`a=g_+`、`b=g_-`，实际标准元是

\[
I_g=v^{-\Lambda(a,-b)}X^a\operatorname{Ad}_{H^{-1}}X^{-b}.
\]

这里的 leading normalization 不能遗漏。任意 mutable–mutable 块并不要求为零。

设 `H=TF`。将标准元运输至中间图表后，直接使用五个量子单项式的乘法，而不是借用上一份审稿的公式：

\[
\iota(I_g)=v^{-\Lambda(a,-b)}F X^a H^{-1}X^{-b}T.
\]

对应 `F`、`H^{-1}`、`T` 的次数分别是 `d_1,d_2,d_3`。归一化总相位恰为

\[
g^{\mathsf T}Dd_1-(a+b)^{\mathsf T}Dd_2-g^{\mathsf T}Dd_3
+d_1^{\mathsf T}DBd_2+(d_1+d_2)^{\mathsf T}DBd_3.
\tag{A}
\]

这与主证明三因子式逐项相等。特别是，`Λ_mut,mut` 的所有额外项均已消失，不能再给次数估计增加随 `N` 增长的未知项。

### 共享冻结变量的独立符号检查

本支构造了一个非 principal 系数模式，而不只重复单位 principal 量子环：令 `B` 是两个符号化 rank-two 反对称块，乘子为 `δ_1,δ_2`；令 `F_0` 为带跨块非零项的四阶整可逆矩阵，并令 `K` 是任意反对称四阶矩阵。取

\[
\widetilde B=\binom B{F_0},\qquad
\Lambda=
\begin{pmatrix}
K&-(D+KB)F_0^{-1}\\
F_0^{-\mathsf T}(D+BK)&-F_0^{-\mathsf T}(DB+BKB)F_0^{-1}
\end{pmatrix}.
\]

这是任意 `K`、两种乘子与共享冻结方向同时存在的测试模型。Wolfram 精确返回：反对称性、兼容性、公式(A)及跨分量修正相位均为零差。对应代码与原始结果为 `global_phase_and_direction.wl`、`wolfram_global_phase_result.json`。工具给出全局符号尚未定义的前端提示，但实际返回的八项代数判断全为预期值；无错误结果被计为通过。

一般证明不是这个四阶算例：若 `m_c` 的 mutable 支撑在分量 `c`、`d_{c'}` 在另一分量，则

\[
\Lambda(m_c,\widetilde Bd_{c'})=0,
\quad
\Lambda(\widetilde Bd_c,\widetilde Bd_{c'})=0.
\]

因此跨分量乘积相位与修正次数无关，恰为归一化所除去的 leading phase。共享冻结向量不改变这两式。初始散射 Lie 子代数也逐分量交换，不产生新的跨分量墙；于是分别应用各分量的正参数 `v^{δ_c}`，然后相乘，得到严格负斜率。将所有墙侧符号直接换成 `ν^TDd` 的做法仍然不合法，主证明没有这样做。

### 全中心不能删除

若正次数群元 `K` 的最低非零次数为 `e`，则其对某个 mutable `X_i` 的伴随作用在该次数产生一个非零倍数

\[
k_e\bigl(v^{\delta_i e_i}-v^{-\delta_i e_i}\bigr),\qquad e_i>0.
\]

所以完整 A 量子环上的作用在正次数群中是忠实的。一个在 Y 子环内部中心化的项，仍会被 mutable `X_i` 发现。有限窗口逐次数归纳保留此性质。使用 unframed Y-adjoint 的中心商会破坏这一接口；本轮完整组算法与主证明均保留它。

## 4. 有限窗口、整性与实际基三处量词

### 4.1 有限窗口确实是商运算

`W_E={0≤d≤E}` 的补集对加上 `N^n` 封闭。群元相乘、逆元展开、bar 修正和散射作用只增加非负次数。因此不存在“先丢弃高次数，再通过后续运算返回目标盒”的路径。只计算 full-support 目标可以作为统计口径，但实际中间运算必须保留整个向下闭合盒；现有算法如此处理。

### 4.2 负有理函数次数不能代替 Laurent 整性

本支重新查了 Qin Lemma 6.2：修正系数确实属于 `v^{-1}Z[v^{-1}]`，而不是相反次数方向。又查 DM Corollary 4.13：局部化簇单项式是 theta 函数；DM Theorem 3.9 给每个散射图表中的整 Laurent 系数。标准元是两个这样的簇单项式的归一化乘积，因此需要的整性是已有定理的直接有限卷积推论。

路径运输保持 bar；这既可从 bar 不变墙作用逐次合成得到，也可用初始 dilogarithm 与一致散射唯一性得到。于是负次数 Laurent 系数与 bar 不变性相容时只能为零。主证明没有对任意有理函数误用这个结论。

### 4.3 实际基与有限展开不能省略

若一个有限 theta 展开中存在不属于 `a+B̃N^n` 的标签，取其中没有更早正修正来源的标签。它的 leading monomial 既不能由 cone 内的标签贡献，也不能由另一个 offending 标签贡献，故无法消掉。这反驳了原元素的 pointed 支撑。完全相同的有限偏序论证适用于实际基乘积的输出标签。

这个论证需要有限代数展开，不能擅自换成一个未限定支撑的无限形式线性组合。对 ordinary cluster algebra，DM Proposition 4.14 提供 finite middle theta span；对本题 injective-reachable、full-rank 的 quantum upper algebra，Qin 1902.09507v4 Remark 1.2.5 与 §6.2 明确给出 quantum theta basis。故原证明所列两种应用接口可用。无需额外假定 `A=U` 才能处理 ordinary algebra 的元素。

## 5. 图表端点与墙上目标

“`ν` generic”应理解为对当前有限窗口相关的全部墙 generic。一个 mixed-sign 整向量仍可能落在无限散射图的更高次数墙上。严格写法是在同一有限腔内选一个真正 generic 的实端点 `Q`；所有本窗口系数不变。原合并稿的独立审稿已说明这一点，建议最终定理也明确保留，避免把 `ι_ν` 误读成无条件存在的全图表。

对于指定目标 `p=a+B̃E`，只要

\[
\nu\cdot d\ne0,
\qquad
\operatorname{sgn}(\nu\cdot d)=\operatorname{sgn}(p_{\rm mut}\cdot d)
\quad\text{当 }p_{\rm mut}\cdot d\ne0,
\]

则足够接近 `ν` 的 `Q` 满足：反向末段 `Q+t p` 永远不遇到可能的末次折弯墙。因为配对在起点和方向上同号，或方向配对为零而起点非零。目标位于墙上不导致例外。

纯冻结目标的 mutable 方向为零，整条反向线与所有相关墙平行；零目标直接给常数 theta 元。两种情形均可提取系数，不需要假设目标位于簇锥或散射腔内部。

### 5.1 一般确定性方向

令 `K=Σ_i E_i`。若 `K>0`，设

\[
\boxed{\nu=(K+1)p_{\rm mut}+(1,\ldots,1).}
\tag{B}
\]

对任意 `0<d≤E`，有 `1≤|d|≤K`，且 `p_mut·d` 是整数。于是：

- 若 `p_mut·d=0`，则 `ν·d=|d|>0`；
- 若 `p_mut·d≥1`，则 `ν·d≥K+1+|d|>0`；
- 若 `p_mut·d≤−1`，则 `ν·d≤−(K+1)+|d|≤−1`。

所以(B)同时保证整个窗口 generic 与目标提取符号条件。它对任意有限秩成立，不依赖有限型、无环性或簇扇稠密性。`E=0` 只涉及 leading coefficient，单独处理即可；可以任取全1方向。纯冻结或零 mutable 目标直接给 `ν=1`。

Wolfram 独立简化了这三类不等式，全部为真。可执行构造保存在 `direction_and_threshold_audit.py`。

## 6. 明确区分三个有效阈值

### 6.1 标准元／CT 阈值

主代码首先将所需 CT 标签偏移 `H0` 扩成标准元偏移

\[
H1=\{h+Bf:h\in H0,\ f\in W_E\}.
\]

对每个非零三因子项，其次数上界为 `Nσ+C`，严格负斜率 `σ<0` 来自半路径支撑。代码使用 `1+floor(C/(−σ))`，加上坐标符号阈值，确实保证严格 `<0`，而非仅 `≤0`。所以其最大值是对所有更大整数 N 有效的证明证书。

本支在实际 B3 例中将方向改为(B)：

\[
a=(2,2,-2,-2),\quad E=(1,2,2,1),\quad p_{\rm mut}=(-2,0,0,2),
\quad\nu=(-13,1,1,15).
\]

重新计算得到 37 个 H0 偏移、261 个 H1 偏移、377 个非零三因子组合及 98,397 个线性不等式，`Ns=N_CT=10`，阈值处最大次数界为 `−1`。它与旧方向的数值阈值相同，但属于一个新方向的独立证书；原证书没有覆盖或删除。

### 6.2 theta 几何充分阈值

对 `L_{Nν+h}` 对应的 theta 元，若最终修正次数为 `e`，末次折弯的正法向量 `d` 必须满足 `0<d≤e`。因而一个直接充分条件是

\[
N|\nu\cdot d|+\operatorname{sgn}(\nu\cdot d)(h+Be)\cdot d>0.
\]

相应整阈值为

\[
N_\theta=
\max\left(1,
1+\left\lfloor
\frac{-\operatorname{sgn}(\nu\cdot d)(h+Be)\cdot d}{|\nu\cdot d|}
\right\rfloor\right),
\tag{C}
\]

其中最大值只遍历实际要求的 `h,e,d`。这是末次折弯论证；它不需要所有无关法向量与每个最终指数都同号。若采用主证明较强的共同凸锥方法，允许把 d 遍历整个指定窗口，仍是正确但较大的充分界。

| 几何检查口径 | 旧 ν=(-7,1,2,9) | 新 ν=(-13,1,1,15) | 每方向不等式数 |
|---|---:|---:|---:|
| 每个 h∈H0 均取整个 W_E，d 亦遍历整个 W_E | 23 | 11 | 46,620 |
| 乘子 W_E、输出 f 的剩余窗口 W_(E−f)，d 遍历该剩余窗口 | 13 | 7 | 5,836 |
| 同一实际剩余窗口，但只检查可能末次法向量 0<d≤e | 7 | 7 | 1,564 |

这些都是充分界，均不声称最小。23/11 使用的是 **H0，不是 H1**。文件 `THETA_CONE_THRESHOLD_AUDIT.json` 含所有偏移、计算式与最坏见证。最强口径旧方向的见证为 `h=(-4,5,3,-4), e=(1,2,0,0), d=(1,2,2,0)`，其 `ν·d=−1`、`(h+Be)·d=22`，所以该强条件确需 N≥23。

### 6.3 对乘法恒等式的影响

原乘法提取证明只使用：固定目标 p 的 theta 系数隔离，以及大乘子与全部相关输出 **CT** 在剩余窗口内变成单项式。因此 `N_CT=10` 已足够，不必先让所有远端 theta 元单项式化。

额外地，由(C)得到真正需要的剩余窗口 `N_θ≤7`，故本例 N≥10 时这些窗口也同时满足 theta 单项式化。不能反过来用这个局部结论宣称每个 H0 偏移的整个 W_E 在 N=10 都满足最强共同锥条件。

新方向的完整冻结相位是 `E·ν=6`，所以相应提取式为

\[
[L_{N\nu+p}](L_aL_{N\nu})
=u^{6N}\bigl(u^6+4u^4+10u^2+16+10u^{-2}+4u^{-4}+u^{-6}\bigr),\qquad N\ge10.
\]

这使用与旧方向相同的目标系数；两方向对 `0<d≤E` 的符号均相同，故有限散射图表一致。旧方向仍是 `u^{8N}`，不可混写。

Wolfram 从有限因子次数表独立重算了 98,397 个不等式、两种 full-H0 几何界和两种末次折弯界，返回 10、23/11、7/7 与新相位6。它核的是有限线性代数证书，不重新证明 CT 存在或散射来源。

## 7. 相似种子、原始 Lie 参数与 DM 局部误植

### 7.1 实际基与正性传递

本支逐段读了 Qin 2407.02480v4 Definition 4.1、Theorem 4.6(1)(2)、Lemma 4.17 和 Proposition 4.18。源文的相似性允许正有理比例 `ρ`，其变换在归一化系数上只做 `q^(1/2)→q^(ρ/2)`，并对基元进行冻结单项式重标。乘法展开按 Theorem 4.6 相容。正参数替换、冻结重标和归一化 Laurent 单位均保持系数非负；下降回原整式环另由 Lemma 4.17 的论证提供。

因此实际 symmetric-Cartan word 基可传到本轮使用的 full-rank principal 模式，不能将其误描述为任意量子冻结变量直接代入1。原始 Lie 兼容乘子是2；principal 乘子2模式中的归一化系数用单位参数写作 `u=v_Lie²`。这不等于原始 Lie 量子环的所有非归一化交换相位都由同一简单代入消去。

### 7.2 DM v3 的首项漏相位

固定来源：https://arxiv.org/abs/1910.12915v3 ，2021-06-15；已同时核 HTML 与 PDF。

- PDF p31 Theorem 3.10 的展示式把首项印成 `ϑ_(p1+p2)`。
- 同文 Theorem 1.1 在式(3)之后正确给出 `α(p1,p2;p1+p2)=t^{ω(p1,p2)}`。
- 量子环定义 `z^a z^b=t^{ω(a,b)}z^(a+b)` 也立即强制该因子。

这是局部展示式漏印，不是否定 theta 强正性。应以正确带相位的版本使用。主证明式(7.4)保留 `v^{Λ(p,Nν)}`，没有继承此误植。PDF局部截图仅用于目视核对，未加入分发包；官方链接、页码与自洽校核足以复核。

## 8. 附带核查双侧 framing 反机制

重新核算 `agents/green_hall_lift/GREEN_HALL_LIFT_OBSTRUCTION.md` §2 的非交换消元：`p(c+b*α*)+q a*α*` 的变量替换是保持顶点与箭头理想过滤的连续右等价，恰可劈去平凡二次对。沿路径推进后终端 β 未入势，故最后二圈的二次部分为零，不能由右等价生成可消去的二次项。这一全 n 障碍的归纳成立。

§3 对“固定两个 framing 线”的说明也是必要的：拆分本身可以保持内部商空间，真正发生变化的是改用全顶点 gauge 时新增的相对标量。单循环的复合 γ 是不变量，分裂路径中的 γ 是半不变量；普通不变量环从 C[γ] 变为 C。该报告没有错误地把固定 framing 与全 gauge 混为一谈。

§4 的 perverse `j_!` 正组合式与 proper 推送后的权 Euler 多项式 `(1−L)^m` 相容：后者不是 exact 的正系数提取函子，故可有符号。经典特化为零，不是负 CT 系数。辅助报告的结论范围通过本次检查；其与主猜想之间未建立的对象字典仍然未建立。

## 9. 最终允许陈述与禁止扩张

允许陈述：在有限秩、skew-symmetric mutable 部分、兼容量子形式、冻结变量可逆、injective-reachable 的框架中，Qin 形式三角族具有任意有限窗口的远端刚性。若它是实际基且其乘法结构常数另已知在 `v=1` 后非负，则经典 theta 换基非负；若量子结构常数系数非负，则量子换基也非负。已认证且有独立乘法正性定理的 symmetric-Cartan word 模型属于该应用范围。

不能陈述：

- 任意假设存在的共同三角基已经有正乘法；
- 任意秩亏、coefficient-free 反对称矩阵已由同一兼容量子证明覆盖；
- FORMAL_ONLY 的随机扩张输入已获得实际基；
- 有限无负扫描证明全称正性；
- 初始基和 theta 各自普通 Laurent 正即推出换基正；
- 一个 mixed vanishing-cycle 或 framing 失败就是原猜想的反例。

## 10. 复现与失败记录

运行 `python3 agents/global_bridge_adversary/direction_and_threshold_audit.py` 可生成确定性方向与三种阈值口径的 JSON。`wolfram_direction_thresholds.wl` 可在 Wolfram 核中直接复核有限证书。原始插件输出保存在 `WOLFRAM_DIRECTION_THRESHOLD_RESULT.json`。

第一次生成该 Wolfram 证书时，新的 JSON 未附矩阵 B，生成器抛出 `KeyError`；随后一个失败的 cat 错误文本被误传入 Wolfram。该次无效输入和原始输出完整保存在 `WOLFRAM_THRESHOLD_ATTEMPT1.json`，不计入验证。修复为保存 B/DT 输入并先检查前置命令成功状态，成功重算结果单独保存。数学算法与旧证书未被该执行错误改变。

本次审核没有找到需要撤回主桥的例子。应将以上明确范围、确定性方向与阈值细分纳入最终整合，保留最宽原猜想的正性缺口。


---

## Part IV. Final independent core audit

# 第30角色：一般有限窗口与正乘法桥的最终独立对抗审核

开始：2026-10-31 06:44:35 UTC。审核者：core_proof_final_adversary。

## 1. 裁定

**PASS WITH EXPLICIT PREMISES。** 本次从量子单项式乘法、有限正锥和最后一段折线分别重建主链，没有找到其明文假设下的反例或致命缺口。结论仍是：

1. 兼容、有限秩、mutable 反对称、冻结可逆、injective-reachable 的种子中，Qin 形式三角族具有固定有限窗口的远端刚性。
2. 若该形式族确为实际代数基，并有实际有限 theta 展开，则每一个指定换基系数可读为某个充分远的实际乘法系数乘一个量子 Laurent 单位。
3. 只有再加入该实际乘法系数的非负性，才得到对应换基非负性。

第三项不是共同三角基定义中的自动性质。此次 PASS 既不是原猜想证明，也不是对整个材料包的外部同行评审。

本审核没有引入2026新文作为核心证明的输入，没有把旧秩二远端抽取、DM/MQ的目标系数提取重新计为本轮新思想。它是另一次独立证据检查，不是另一项独立定理。

## 2. 预查与来源

已读：

- results/PRIOR_ART_AND_SCOPE_ADDENDUM.md；
- results/CLAIM_DEPENDENCIES.md；
- results/GENERAL_FINITE_WINDOW_THEOREM.md 的三部分；
- results/EFFECTIVE_FINITE_CERTIFICATION.md；
- 旧第一轮记录425–470处的完整强正秩二定理入口；
- 旧第三轮记录2419–2475处的无正性刚性及远端乘法范围。

第一轮已用远端乘积处理一般强正秩二基；第三轮已说明实际秩二三角基的刚性步骤不需要乘法正性。本轮一般化的实际增量与先行 theta 抽取必须分开归属。

直接核对的主要一手正文：

| 来源 | 直接阅读位置 | 核实用途 |
|---|---|---|
| Qin 2508.12761v2 | PDF p5；pp29–30 | 原期待明确skew-symmetric；injective-standard、负参数修正及actual CT身份 |
| Qin 1902.09507v4 | PDF p7；pp54–55；pp59–60 | full-rank injective-reachable quantum upper 的theta实际基；经典large-complex接口 |
| Davison–Mandel 1910.12915v3 | PDF pp25–26、29–31、33、41–42、44 | bar墙、积分theta chart、最后一段系数隔离、cluster/scattering chart、ordinary finite theta span |

版本固定PDF的SHA、精确URL和官方abs复查见 SOURCE_AUDIT.json、SOURCE_METADATA_RAW.json。SOURCE_AUDIT 中自动检索到的关键词出现页另列，**不代表逐页都审读**。未声称全文重新证明这些旧文献。

## 3. 最短独立证明链

设 R=Z[v^{±1}]，量子单项式乘法为
\[
X^mX^n=v^{\Lambda(m,n)}X^{m+n}.
\]
兼容性写成
\[
\Lambda\widetilde B=-\binom D0,\qquad D=\operatorname{diag}(\delta_i)>0.
\]

### 3.1 满列秩、冻结平移及连通分量

先明确本审核发现的一处应补的表达范围：窗口补集给出的普通两侧理想位于正修正代数 \(K[[Y^{\mathbb N^n}]]\)，截断一个pointed元素时作用在固定anchor的模块 \(X^gK[[Y^{\mathbb N^n}]]\)。**它不是整个Laurent量子环的普通理想商**；后者的Y单项式可逆，那个字面理想会是整个环。

数学操作仍成立：两个正修正次数相加，故该理想在正修正代数中为双侧理想；量子commutation仅改系数、不改正次数。两个固定anchor模块相乘，落在anchor相加的模块，任一被丢弃的修正仍被丢弃。常数项1的形式逆元、bar、路径伴随作用也只增加修正次数。把 \(g+\widetilde Bf\) 的展开改用g作anchor时，修正次数平移f≥0，应取剩余窗口 \(E-f\)。现有证明恰使用这些操作，且已处理剩余窗口，所以这是**术语精确化，不是反例或需撤回的证明步骤**。

兼容式直接保证 \(\widetilde B\) 满列秩。令 \(Y^d=X^{\widetilde Bd}\)，则
\[
\Lambda(m,\widetilde Bd)=-m_{\rm mut}^{T}Dd,\qquad
\Lambda(\widetilde Bd,\widetilde Be)=d^TDB e.
\]
第二式反对称，故 \(DB=BD\)。所以 \(\delta_i\) 在每个 mutable 连通分量上恒定。若 h 纯冻结，则
\[
\Lambda(h,\widetilde Bd)=0.
\]
冻结归一化因此只平移指数，不给不同修正次数添加不同相位。

不同分量的修正向量彼此配对为零，而且一个分量的leading mutable向量与另一个分量的修正配对也为零。初始散射Lie代数因而按分量交换，完整consistent scattering不制造跨分量Lie括号。这允许标准元按分量计算；共享冻结变量也不改变结论。

这里也不需要 \(\operatorname{im}\widetilde B\) 在M中饱和。所用正次数单子就是 \(\widetilde B\mathbb N^n\)：初始散射项在这个单子中，Lie括号、群乘法和指数只相加次数，所以不会凭空产生分数修正次数。满列秩保证其整数次数标记唯一；不必把它误换成正实锥中的全部整数点。

### 3.2 完整路径元与真正标准元

injective reachability提供负腔；把负簇变量按冻结单位归一化到leading degree \(-e_i\)，记为J_i。cluster/scattering图表比较给
\[
J_i=\operatorname{Ad}_{H^{-1}}X^{-e_i}.
\]
这里H作用在完整A量子环，不能只保留其在Y子环上的作用。由于兼容性，任何非零正次数d都与某个mutable指数非平凡配对，因此所谓Y中心并非完整A作用的核。

对 \(g=a-b\)，\(a=g_+\)、\(b=g_-\)，标准元为
\[
I_g=v^{-\Lambda(a,-b)}X^aH^{-1}X^{-b}H.
\]
额外mutable–mutable相位恰由这个leading归一化消去，不需要假设其块为零。

### 3.3 五因子相位与严格下降

固定窗口 \(W_E=\{0\le d\le E\}\)。在其有限散射图中选整数方向ν，对所有非零窗口次数 \(\nu\cdot d\ne0\)。完整实端点Q另取于同一有限腔，避免把整数ν错当无限图的generic点。

写正腔到Q的路径元为F，Q到负腔为T，则H=TF。F的非零次数满足 \(\nu\cdot d<0\)，T的非零次数满足 \(\nu\cdot d>0\)。这是直线路径与相应墙超平面的符号结论。

运输标准元：
\[
\iota_Q(I_g)=v^{-\Lambda(a,-b)}F X^aH^{-1}X^{-b}T.
\]
给F、H^{-1}、T的次数分别为 \(d_1,d_2,d_3\)。直接把五个单项式两两配对相加，得到
\[
g^TDd_1-(a+b)^TDd_2-g^TDd_3
+d_1^TDBd_2+(d_1+d_2)^TDBd_3.
\tag{1}
\]
这是本审核独立推导的主相位；Wolfram也按十个成对相位相加核验。

在一个连通分量中D=δI。令 \(g=N\nu+h\)，坐标符号稳定后，随N增长的斜率为
\[
\delta\{\nu\cdot d_1-|\nu|\cdot d_2-\nu\cdot d_3\}
\le-\delta|\nu\cdot e|<0,\quad e=d_1+d_2+d_3\ne0.
\]
有理群元系数及固定h的影响只进入有限常数。对断连分量应分别估计再相加：
\[
\deg_\infty\le
-N\sum_j\delta_j|\nu_j\cdot e_j|+C_e.
\tag{2}
\]
不能只把全局墙侧符号偷换成D加权符号。例 \(\nu=(1,-1)\)、\(d=(1,2)\)、D=diag(10,1)给未加权配对−1、加权配对8；它反驳那个裸代数推断，而不是实际散射反例，因为实际支持需满足分量构造。

### 3.4 Laurent整性与bar消去

I_g是两个局部化簇单项式的归一化乘积。DM Cor4.13把它们识别为theta；DM Thm3.9给任意散射chart的整Laurent系数。固定窗口中的乘积是有限卷积。因此，虽然F、H^{-1}、T自身系数可能是有理函数，式(1)所计算的实际标准元chart系数属于R。

Qin Lemma6.2给
\[
L_g=I_g+\sum_{0\ne f\in\mathbb N^n}c_{g,f}I_{g+\widetilde Bf},
\quad c_{g,f}\in v^{-1}\mathbb Z[v^{-1}],\quad \bar L_g=L_g.
\]
对需要的有限偏移集H0，把式(2)同时应用于
\[
H_1=\{h+\widetilde Bf:h\in H_0,\ f\in W_E\}.
\]
窗口补集是非负单子的理想；所以只有f≤e能影响窗口内第e项，虽然完整标准修正可能无限。

充分大的N使所有相关标准元非首chart系数严格负v次数。与c的有限乘积/求和仍严格负次数。路径运输保持bar，因此L的这些系数同时bar不变。R中严格负次数又bar不变的多项式只能为0。于是L在该窗口内精确单项式化。

整性不可删除：\(1/(v+v^{-1})\) 是bar不变且infinity degree为−1的非零有理函数。已保留此负控制，不用“负次数”偷代Laurent证明。

### 3.5 有限actual展开的支撑约束

若pointed元素f支持在 \(a+\widetilde B\mathbb N^n\)，且在pointed基中有有限展开，则所有非零leading labels也在此锥。

证明：否则在有限个锥外labels中取一个对正修正偏序极小的r。任何其他项贡献X^r，必须有 \(r-r'\in\widetilde B\mathbb N^n\)。锥内r'不可能到达锥外r；另一个锥外r'违反极小性。故该leading项不能抵消，与f支持矛盾。满列秩保证这是sharp、无歧义的偏序。

该论证不需要系数非负，但必须是有限实际展开。它同时用于L的theta展开和实际L乘积的输出labels。

对ordinary A，DM Prop4.14给有限theta span；对本题full-rank injective-reachable quantum U，Qin1902 Remark1.2.5与§6.2直接给theta实际基。无需把ordinary A与U默认为相等。

### 3.6 每个目标分别隔离

固定 \(p=a+\widetilde BE\)。E=0时只读leading项；若E≠0，令K=ΣE_i，取
\[
\nu=(K+1)p_{\rm mut}+\mathbf1.
\]
对所有 \(0<d\le E\)，整数 \(p_{\rm mut}\cdot d\) 为0时ν配对为|d|>0；为正时仍正；为负时ν配对至多−1。所以ν窗口generic，并与目标所有非零墙配对同号。

若某条折线最终指数为p，则反向最后一段是 \(Q+tp\)、t≥0。与可能相关墙法向量的配对始终同号，或恒定非零，因此不可能有最后一次折弯。只有label p的直线贡献X^p。纯冻结p同样成立；p=0由θ0=1单独读出。

这一隔离就是既有DM/MQ机制；本审核没有声称它是新发现。

### 3.7 实际乘法身份

把3.4同时用于乘子及全部可能输出偏移
\[
H_0=\{0\}\cup\{a+\widetilde Bf:f\in W_E\}.
\]
实际有限乘积展开中，能贡献目标 \(X^{N\nu+p}\) 的labels只可能为
\(N\nu+a+\widetilde Bf\)，f≤E。所有这些输出在各自剩余窗口单项式化。于是
\[
[L_{N\nu+p}](L_aL_{N\nu})
=v^{\Lambda(p,N\nu)}[\vartheta_p]L_a
\qquad(N\ge N_0).
\tag{3}
\]
式(3)不使用乘法正性；正性只在最后读取左边时加入。v=1时相位变为1，因此仅经典结构常数非负已足够，不需要量子系数逐项非负。

经典化发生在已经证明的R系数恒等式(3)上。**不是**把可能在v=1有极点的H、F或单独dilog系数直接代入v=1。

## 4. 量词与必须保留的限制

- \(\nu,N_0\) 可随目标p及其窗口E改变。不是一个固定远端乘子同时提取任意所有目标。
- H1必须包括相关标准修正后的所有有限偏移；只检查乘子自身不够。
- CT单项式阈值、远端theta单项式阈值、固定目标隔离是不同任务。式(3)只需要前者与固定目标隔离。
- “每个chart相等”指正次数滤过商中的固定窗口相等，不是全局L=theta，也不是所有N统一的全局支持相等。
- signed DT词计算H的算法必须已有实际scattering来源。任意形式词不是凭计算自动成为DT。
- full-rank/integral兼容量子环、冻结可逆、injective-reachability是本证明的明文范围；不能自动下降到秩亏、未量子化或非可达情形。
- 实际基和实际有限展开不可用formal窗口测试替代。formal-positive大样本也不能填上这一门槛。
- 本审核没有得到从共同三角条件本身推出所有远端乘法正性的全新依据；该缺口保持原状，不改名为已完成机制。

## 5. 有效界的核查

坐标符号稳定界Ns之后，每个可能贡献的项都有严格负整数斜率σ和有限整数截距C。于是
\[
N\ge1+\lfloor C/(-\sigma)\rfloor
\]
保证Nσ+C<0。取所有实际所需h、e和分解的有限最大值，再与1和Ns取最大，确实是所有更大整数N都适用的界。该式不要求C非负。

主材料的N_CT=10只声称其指定CT窗口阈值。全文另列的theta共同锥界23/11，以及可能末次法向量界7/7，与它没有矛盾。本审核未重新重复98,397项计数；本次验证的是界公式的严格性、所需对象的逻辑区别，以及式(3)为什么不要求那个更强的theta共同锥条件。

## 6. 实际计算插件：结果、警告和用法

本分支实际调用Wolfram三次：

1. symbolic_audit.wl：五因子相位零差；半锥不等式与严格下降无反例；确定性方向三个符号分支；严格floor界；有理bar负控制；错误加权符号推断的明确反控制。
2. warning_free_bounds.wl：把整数分支改写为非负实参数，重新检查相同必需界。5个精确判断均为True，且无警告。
3. laurent_negative_control.wl：将bar有理反控制约成v/(1+v²)，核分子分母互素、分母与v互素且有正次数，因此它不可能靠乘任何v的幂成为多项式。单纯PolynomialQ为False不足以排除Laurent多项式，所以另补这一步精确检查。

第一次Reduce返回预期结果，但同时产生若干unbounded优化警告。因此没有把它的False结果单独当作可信的自动证明。警告原文完整保留在WOLFRAM_SYMBOLIC_RAW.json；第二次使用无警告的FullSimplify/Resolve，并在3–5节给出手工一般证明。

这些是一般符号身份和量词消元，不是按n=1,2,3扫描，也不扩大主包的独立theta系数统计。

## 7. 最终允许写法

允许写：

> 在上述有限秩兼容injective-reachable框架中，形式三角族具有一般有限窗口远端刚性；当它是实际基时，每个theta换基系数可被准确抽成一个远端实际乘法系数。因此独立成立的量子或经典乘法正性分别推出相应的换基正性。

不允许写：

> 任意共同三角基已经强正，或本轮已经无条件解决Qin的一般期待。

本次没有发现需要撤回已限定主桥的结论。

