# Classical geometric modular bases are theta-positive

Research integration, 2026-11-14. This statement combines a new integral
bounded-window theorem with the **old October 31** CTB window and coefficient
detector. The geometric window proof has been independently reconstructed;
the final basis dictionary passed a fresh primary-source audit on 2026-11-14,
including the frozen inversion and A2 exchange calibration (see the separate
generic_ext_cluster_interface_addendum.md). This file does not claim a
minimum among all conceivable strong positive bases.

## 1. Exact family and statement

Let Q be a finite acyclic quiver without loops, with standard symmetric
geometric KLR parameters. Work with the classical principal-coefficient
cluster algebra, with frozen variables inverted. Write B_ij=-m_ij for i<j
in a topological order, and

    z_i=y_i x^(B e_i),       theta_g=x^g F_g(z).

For a prime ell, let beta_g^(ell) be the normalized classical specialization
of the actual localized geometric KLR simple basis over an algebraically
closed field of characteristic ell. For an irreducible infinite-type
component this is the doubled-Coxeter-word model; reducedness of c^2 is an
essential existing input. Finite-type components use the cluster-monomial
basis, and disconnected components are tensor products. Characteristic zero
is denoted ell=0.

The standard family's complete basis identity, cluster compatibility and
strong positivity are existing inputs, checked against McNamara and KKOP.
They are not consequences of a few positive Euler matrices. No arbitrary
KLR-parameter or valued-species family is included in this statement.

**Theorem, conditional only on the stated existing family dictionary.**
For every g and every prime ell there are finitely many nonzero integers
c_(g,q)^(ell)>=0, q in N^n, such that

    beta_g^(ell)
      = sum_(q>=0) c_(g,q)^(ell) y^q theta_(g+Bq),
    c_(g,0)^(ell)=1.                                           (1)

The proof below makes the comparison for this entire family, in arbitrary
acyclic rank and arbitrary wild type. It does not assert that the modular
bases are all equal to theta, and it does not assert the analogous statement
for an arbitrary classical strong-positive basis.

## 2. The new integer window theorem

Let E=I-M, where M=(m_ij) is strictly upper triangular, and set

    <a,b>=a^T E b,       q(a)=<a,a>.

Fix a root bound e in N^n. For the indecomposable projective P_j put
p_j=dim P_j=E^(-T)e_j and define

    D_j(e)=sum_i e_i max(0,-(E p_j)_i).

For an ambient dimension vector r, the following finite conditions suffice:

    r_j >= D_j(e) for every j;
    for every 0<s<=e,
        <s,r> < q(s) or <s,r> > -q(s).                          (2)

For q(s)>0 the second condition is automatic. Only q(s)<=0 produces an
actual forbidden closed interval [q(s),-q(s)].

Under (2), a common nonempty open set of representations M_r has

    Ext^1_Q(U,M_r)=0 for every U subset M_r with dim U<=e.        (3)

The proof, including the necessary projective correction under inverse AR
translation, is in ../agents/euler_integral_chamber_gluing.md. Its decisive
step is worth retaining here. A nonzero Ext gives a nonzero quotient L of
M_r contained in tau U. There are a projective P and a nonzero S subset U
with 0->P->tau^(-1)L->S->0. Generic submodule and quotient incidences force

    q(s) <= <s,r> <= -q(s),

where the upper inequality uses (2)'s projective-coordinate bound. This is
the prohibited interval. All dimensions of tau U are bounded solely by
Q,e, so one common generic open set suffices for every U.

Heredity upgrades (3) to Ext^1_Q(U,M_r/V)=0 for every V subset M_r. For
each b<=e, CEFR's integral diagonal construction then gives a genuine
surjection

    H^*(product_i Gr(b_i,r_i);Z) -> H^*(Gr_b(M_r);Z).

Both cohomology groups are free, and the target is even. If i denotes the
inclusion and F_b the top Euler class of
direct_sum_(a:i->j) Hom(S_i,Q_j), integral Poincare duality makes i_* a
primitive injection. Consequently

    m_(F_b)=i_*i^*,       Im(m_(F_b)) is saturated,               (4)

in every cohomological degree. In particular every nonzero Smith factor is
one, simultaneously for every prime.

A separate coarse criterion in the same proof handles ambient rays with
small fixed coordinates. If c_e=(I-M)^(-1)M^T e and
K_e=max(0,max_(0<v<=c_e)(-q(v))), it suffices that each 0<s<=e satisfy
<s,r><q(s) or <s,r>>K_e. This yields an explicit common threshold along
every eventually nonnegative r(N)=Nr_0+r_1 with <s,r_0> nonzero throughout
the finite box, including a finite collection of offsets r_1.

## 3. From integer geometry to modular finite jets

The existing long-R / integral nilHecke formula identifies the root-b
coefficient of the normalized simple element with

    rank_(F_ell)(m_(F_b))

on the product of Grassmannian cohomology rings. No division by factorials
or finite-group averaging occurs. The characteristic-zero specialization
is the actual common triangular basis in this acyclic model.

The older file uses the opposite topological order and the complementary
first/second block multiplicity. Reverse the vertex order and rename its
root deficit as b. Its Euler exponent (r_i-a_i)a_j then becomes exactly
b_i(r_j-b_j), and its pointed-label relation becomes

    g_i=-r_i+sum_(j>i) m_ij r_j

when no positive initial factor is present. In particular

    <s,r>=-g dot s.                                             (5)

There is also a frozen-coordinate change: the old long-R formula uses
negative principal framing and has root increment (B_old a,-a). After
reversing vertices set y_i=Y_(rev(i))^(-1), retaining the old head's frozen
normalization. Then x^(B_old a)Y^(-a) becomes exactly z^b in the current
positive-principal convention. Inverting these variables is allowed in the
coefficient ring used here. On the Grassmannians, taking annihilators sends
the old tautological bundle to the dual of the new quotient bundle, and the
old quotient to the dual of the new tautological bundle. Together with
vertex reversal this identifies the old Euler map with the present one up
to signs and integral changes of bases, preserving every Smith invariant
and every characteristic rank. Merely matching its total degree would not
suffice.

For an arbitrary completed label, write g=u+Vr with u,r>=0 and u_i r_i=0.
Choose the direction nu off both the finite root walls and the finitely
many linear walls of this triangular completion. For every fixed finite
set of offsets h and all sufficiently large N, the growing support J of
r(Nnu+h) is fixed. Coordinates outside J are zero; roots using them have
zero coefficients. On J, u=0 and (5) holds for the induced acyclic quiver.
The positive growing coordinates eventually meet the explicit D_j bounds,
and all relevant Euler pairings leave the finite forbidden intervals.

Thus, for any prescribed finite root box and finite offset set,

    beta_(Nnu+h)^(ell) = beta_(Nnu+h)^(0)
        in that box for all sufficiently large N,               (6)

simultaneously for all primes ell. This is the new step. It is stronger
than agreement at finitely many tested primes, or existence of a separate
subsequence depending on ell.

The old October 31 theorem identifies the characteristic-zero side of (6)
with theta in the same window. More precisely, after transport to the
finite scattering chamber of nu, these distant basis elements are their
leading monomials in that window. Its proof uses Qin's triangular
normalization, a strict negative quantum-degree estimate, and bar symmetry;
only its classical consequence is used here.

## 4. A real positive multiplication coefficient detects each transition

Because the acyclic cluster algebra has a theta basis in which each algebra
element has a finite expansion, write

    beta_g^(ell)=sum_q c_q y^q theta_(g+Bq).

This is a finite expansion. Principal homogeneity and pointed triangular
uniqueness imply q>=0 and c_0=1; nonnegativity is not assumed at this point.
More explicitly, in the finite expansion a minimal output root outside N^n
would contribute its leading monomial without cancellation, contradicting
the N^n support of the input. The same triangular argument gives nonnegative
output roots for a product of two pointed basis elements. Consequently a
target root p is affected only by output roots q<=p.

Fix one q=p and put h=g+Bp. Choose an integral direction nu in a sufficiently
small finite-order sign cone of h, avoiding the finitely many additional
walls used above. In the scattering chart at nu, the coefficient of the
full target monomial y^p x^h in beta_g^(ell) is c_p. Indeed a broken line
with that final exponent cannot have a last bend: tracing its last segment
backwards keeps the sign of each relevant wall pairing, while a zero
pairing makes the segment parallel to the wall. This is the existing
Mandel/GHKK coefficient detector, with principal degrees retained.

Now multiply by beta_(Nnu)^(ell). By (6) and the old CTB window theorem,
this multiplier and all output elements needed through root p have no
nonleading terms in that scattering chart, once N is sufficiently large.
The finite offsets include g+Bq for every 0<=q<=p; one common N works.

Consequently the exact classical identity is

    c_p = [y^p beta_(Nnu+g+Bp)^(ell)]
                (beta_g^(ell) beta_(Nnu)^(ell)).                 (7)

The right side is a genuine multiplication coefficient in the fixed
strong-positive modular basis. It is a nonnegative integer. Since p was
arbitrary, every c_p is nonnegative, proving (1).

The argument needs the finite jets of both multiplier and outputs.
Controlling only the multiplier, or invoking ordinary chart positivity in
place of the scattering detector, would leave a gap. It also does not
deduce that every strong-positive basis has (6).

## 5. A global integral lower bound for Laurent coefficients

For the pure module label g(r), positivity of (1) and c_0=1 imply

    rank_(F_ell)(m_(F_b)) >= [z^b]F_(g(r))^theta
    for every prime ell, every r and every b.                   (8)

This applies even when r does not meet the distant-window criterion.
It follows from the global positive transition, rather than applying the
geometric vanishing argument outside its hypotheses.

For a Dynkin component, the Euler identification at every r has a direct
justification independent of any nonreduced doubled word. Rep_Q(r) has a
dense orbit, so its generic representation is rigid. CEFR's original
diagonal argument makes every Euler image saturated, with rank equal to
chi(Gr_b(M_r)). The rigid principal cluster character is the corresponding
cluster monomial and hence theta_(−Er). Its exponent at a submodule b is
−E^T b−E(r−b)=−Er+Bb, and DWZ II (1.6), (1.13), (2.14)–(2.15), Theorem 5.1
give the principal F-polynomial and g-vector conventions. Thus (8) is in
fact an equality on Dynkin components for every r,b and every prime.
Disconnected components combine by tensor products; field ranks multiply.

Let d_1|...|d_k be the nonzero Smith factors of the **whole ungraded**
integer Euler map. If the first nonunit factor is d_j, a prime dividing
d_j divides all later factors. Hence

    min_(ell prime) rank_(F_ell)(m_(F_b))
        = number of unit Smith factors of the whole map.

Together with (8), this gives at least [z^b]F_(g(r))^theta unit Smith
factors. Equivalently, the Euler image contains a primitive direct summand
of at least that rank. No canonical theta-indexed choice of this summand
is asserted.

This count must **not** be replaced by the sum of unit-factor counts in
individual graded blocks. For example diag(2,3) has global Smith factors
(1,6), although neither one-dimensional block has a unit factor. The
distant-window saturation theorem is degreewise and is unaffected by this
distinction; the global bound (8) is stated only in the classical ungraded
form needed here.

## 6. What has and has not been advanced

The new proof is the bounded all-submodule Ext theorem and its integral
Euler saturation consequence. It extends the old CTB comparison to an
entire family of genuinely modular strong-positive bases using a uniform
all-prime window, not a collection of low-rank tests.

The AR machinery, generic incidence dimensions, CEFR diagonal decomposition,
McNamara/KKOP basis construction, and old CTB detector are credited inputs.
Independent prior-art checking is still active. No Li–Pan/Lifang conclusion
is used. General strong-positive minimality and general cyclic finite-label
Laurent stopping remain separate open goals in this research session.
