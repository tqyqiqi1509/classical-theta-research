本补记保留 2026 年 11 月 14 日 05:26 UTC 后的新证明及第八次文献路线复查。研究从 03:01:18 UTC 开始，计划持续至 15:01:18 UTC；只处理经典丛代数。一般 Laurent 有限停机与任意强正基的 theta 最小性仍未全部解决。以下各结论均注明适用范围；不使用 Li–Pan 或 Li Fang 多面体基的结论。

# 任意强正基的多项式归一化与有限修正

设 B 无环、斜可对称，并拓扑排序使 i<j 时 B_ij≤0。系数环为 R=Z[y_1^{±1},…,y_n^{±1}]。C 是普通主系数丛代数 A 的实际强正 R 基，包含全部丛单项式。按每个冻结变量的最小 Laurent 指数归一化后，每个基元素唯一标为 β_g，g∈Z^n，且为齐次、非负、有限的 pointed 元素。这里无需预设 pointedness。旧输入是 BFZ 的无环标准单项式基；本轮证明先建立实际多项式格的交，再对正基做退化，避免将无限三角族误当代数基。

定义 E_a=∏x_i^[a_i]_+(x_i′)^[-a_i]_+。其 y=0 首项为 x^G(a)，其中 G_i(a)=a_i+Σ_(j>i)(−B_ij)[−a_j]_+；G 是倒序可解的整双射。记 E_g=E_(G⁻¹g)，A_+=⊕_g Z[y]E_g。证明 A_+=A∩Z[y][x^{±1}]：在有限标准展开中若有负冻结指数，取一个严格正权重暴露最低负权指数；该层是互异 x^g 的非零和，不能消去。任意强基由清分母与 CM 锚点得到普通 Laurent 正性。归一化 β 坐标最小冻结指数为零；E_g 的正 β 展开不能有负冻结次数，否则产生无可消去的负指数。因此 β 是 A_+ 的实际 Z[y] 基。令 y=0，所有单项式都正展开于非负整基向量，迫使这些向量恰为互异单项式。E_g 的齐次性与正展开进一步给 β_g≤E_g，逐系数成立。

归一化的结构常数也自动属于 N[y]。若乘积中的某系数有负 y_i 次数，将其乘上输出 β 的 y_i 最小项就产生不能消去的负次数。齐次性由此给出：

``math
\beta_g\beta_h=\sum_{q\in\mathbb N^n}m_{g,h;q}y^q\beta_{g+h+Bq},\qquad m_{g,h;q}\in\mathbb N,\quad m_{g,h;0}=1.
```

单独的齐次性结论不需要无环：普通 A 由丛变量生成，每个基元素必出现在某个变量乘积的正基展开中。取该系数的一个冻结单项式，Laurent 无消去迫使相应基元素齐次。这里必须是普通 A，不能假设变量乘积张成任意更大的 U。

令 r(g)=[−G⁻¹(g)]_+，则 E_g=x^g∏(1+z_i)^r_i，z_i=y_i x^(Be_i)。反向顶角映射 H(g)=g+Br(g) 也是整双射：若 a=G⁻¹(g)，H_i(g)=a_i+Σ_(j<i)B_ij[−a_j]_+。任意 β_g 的实际有限标准展开为 E_g+Σ_(q>0)c_q y^qE_(g+Bq)。各项顶角 P(q)=q+r(g+Bq) 互异；即使 B 有核，P(q)=P(q′) 先给 H(g+Bq)=H(g+Bq′)，再由相同 r 得 q=q′。若某顶角超出 [0,r(g)]，用严格正权暴露唯一最大顶角，就与 β_g≤E_g 矛盾。故所有真实修正均满足 P(q)≤r(g)，且 q>0 时 P(q)≠r(g)。

```math
[z^{r(g)}]F_{\beta_g}=1,\qquad
\beta_g=\vartheta_g+\sum_{q\in D_g}t_{g,q}y^q\vartheta_{g+Bq},\qquad
D_g=\{0<q\le r(g):q+r(g+Bq)\le r(g)\}.
```

每个实际修正严格降低 |r|：|r(g+Bq)|≤|r(g)|−|q|。theta 本身是此范围内的强基，所以具有同一顶角；再用 Qin 1902.09507v4 Proposition 3.4.8 得到任意 β 在 t 与 t[−1] 的 compatible pointedness。这尚未给出全部 seed 的兼容性，也没有证明 t_(g,q)≥0。[Qin 原文](https://arxiv.org/html/1902.09507v4)。

# 实际低秩强基与完整正切片

本节使用普通无环箭图，明确限定 B 斜对称。对 S⊂[n]、T=Sᶜ，令 y_j=0，j∈T。实际 Z[y] 基可做基变换，specialized β 仍是基。顶点 j 的不可分解内射 I_j 有 essential socle S_j，且其 reachable cluster character 为 x_j⁻¹F_(I_j)。任意非零子模包含该 socle，所以 y_j=0 后变为 x_j⁻¹。于是 specialized 基同时包含正单位 x_j、x_j⁻¹；两者的非负乘法矩阵互逆，只能置换基。比较首项得到 x_jβ_g|_S=β_(g+e_j)|_S，故相应 F 仅依赖 g_S。

无环 lower-bound presentation 识别该 fiber：外部 x_j 成为单位，外部 x_j′ 由交换关系消去；对 i∈S 做系数换元 Y_i=y_i∏_(j∈T)x_j^B_ji，并将 x_i′ 除以相应外部单位，恰得 B_SS 的主系数交换关系。因此取这些单位轨道得到诱导子箭图上的实际强正基 β^S，保持独立、有限张成、正乘法及全部 CM 锚点。

对每个外部根指数 η∈N^T，不只是 η=0，存在有限唯一的正展开：

```math
[z_T^\eta]F_{\beta_g}(z)=\sum_{s\in\mathbb N^S}m_{g,S;\eta,s}z_S^s F^S_{g_S+B_{ST}\eta+B_{SS}s}(z_S),\qquad m_{g,S;\eta,s}\in\mathbb N.
```

证明是有限的。令 Q_g={q:0≤q≤r(g)}。对每个 q 从后向前递推：T 上置 ρ_i(q)=0，S 上置 ρ_i(q)=[−(g+Bq)_i+Σ_(j>i,j∈S)(−B_ij)ρ_j(q)]_+。取 N_S=0，且对每个 i∈T，N_i≥max_(q∈Q_g){0,−(g+Bq)_i+Σ_(j>i,j∈S)(−B_ij)ρ_j(q)}。于是 r(g+N+Bq)_T=0，对所有 q∈Q_g 同时成立。用初始 CM x^N 乘 β_g：强正乘法的每个输出根 q 必在 Q_g，否则 pointed 首项无消去。各输出整个 F 支撑均在 S，等于 β^S 的 F。约去 x^(g+N)，再取 z_T^η 层，得到公式。乘以 x_S^(g_S+B_STη) 后，这是实际 Z[Y_S] 基展开，因此唯一；B_SS 的核不会抹掉不同冻结幂。

特别地，S={k} 时每层等于 (1+z_k)^L P(z_k)，L=[−g_k−Σ_(j∈T)B_kjη_j]_+，P∈N[z_k]。此秩一正可除性亦可从相邻 Laurent chart 得到，不能单独主张新颖性。全切片正性仍不能通过正逆卷积直接推出全 theta 换基正性；内部修正项是下一主攻点。

# 无环 Newton 多面体一致

设 Q 为任意有限无环箭图，E=I−M、B=E−Eᵀ。取一般表示 M_r，令 g=−Er，P_r 为它的子模维数多面体。在本轮已独立审核的标准对称几何 p-KLR 家族、其 Euler 系数公式及 theta 非负换基定理之下，得到：

```math
\operatorname{Newt}F_g^\vartheta=\operatorname{Newt}F_g^{(p)}=\operatorname{Newt}F_g^{(0)}=\operatorname{Newt}F_g^{\rm gen}=P_r.
```

所有顶点系数均为 1，且 CTB 的完整支持恰为一般 Gr_b(M_r) 非空的维数 b。decorated 标签 g=u−Er、u_ir_i=0 由相容初始 CM 因子扩展。generic character 仅得到 Newton 边界，不声称其全部系数为正。

令 X_b=∏Gr(b_i,r_i)，F_b=c_top(⊕_(a:i→j)Hom(S_i,Q_j))。标准 p 字符系数为乘法 F_b∪− 的模 p 秩。方程丛被表示参数全局生成，泛型非空零簇为 regular；有效非空簇的有理类非零，故 F_b≠0 当且仅当一般 Grassmannian 非空。顶点只有一个约化子模，其 Euler 类为整点类，所有 p 的乘法秩均为 1。正 theta 换基先给 Newt(theta)⊂P_r。

反向包含使用全主系数估值。对 Fei presentation weight δ，设初始权 v=(0,−δ)，根权 w=tilde Bᵀv=−δ。min tropical mutation 给 w′_k=−w_k、w′_j=w_j+[b_kj]_+w_k−b_kj min(0,w_k)，正是 −B 的 g tropical 变换。Fei 的 presentation cluster fan 为 −Σ_g(−B)。因此其严格簇锥中的 δ 可输送到根权全正的 seed；相同 full tropical degree 的 compatibly pointed CTB 与 theta 在该估值下相同。保留所有冻结坐标，不反演 B，故 B 奇异也成立。避开有限交换等权面后，初始单项式变换幺模，带符号 Laurent 式亦无遗漏消去。

Fei 已证明每个泛型顶点法锥包含一个 cluster。本轮补足其简短证明中如何指定该顶点的完成步骤：正支撑 facet 的原始法向为实刚性 E 的权 δ_E；由极小最大化子模 U 的 Euler 正交和 facet 维数，dimU=h dimE。trace evaluation E^h→M 源像同维，故 U≅E^h，N=M/U∈E⊥。facet 等于 h dimE+D Newt_(Q′)(N′)，其中 E⊥≃repQ′，秩下降一；它不是 N 在原范畴的全部子模多面体。

泛型商论证用带基 incidence：其到 rep_r 的投影 dominant，唯一约化顶点子模使一般 M 对应一般 incidence 点；到子模／商模参数的投影在块坐标中也 dominant。因此 N 泛型。perpendicular 等价由固定 progenerator 的 Hom 给出，连同逆函子是表示栈的代数等价，保持泛型开集。

在降秩多面体目标顶点法锥内选 cluster，AHIKM Theorem 4.11 将其提升到含 δ_E 的原 cluster；该商扇定理不需 g-finite。派生投影 L(x)=x−e⟨e,x⟩ 是 E⊥ 包含的左伴随，保留与 E⊥ 的 Euler 配对；Bongartz completion 的投影是该范畴的 progenerator，故商格映射正是权重限制 Dᵀ。取提升后的内部权 η，Tδ_E+η 在 T 充分大时唯一暴露原顶点。其所在完整 cluster cone 上支撑函数线性，因而全锥落入指定顶点法锥。由估值相等，每个泛型顶点必须属于 theta 支撑。缺失支持顶点由 shifted projectives 的 idempotent reduction 补回。

原文归属：[Fei 1911.10513v6](https://arxiv.org/html/1911.10513v6)、[Fei 1909.10151v3](https://arxiv.org/html/1909.10151v3)、[AHIKM 2203.15213v4](https://arxiv.org/html/2203.15213v4)、[Jasso 1302.2709v4](https://arxiv.org/abs/1302.2709v4)。Fei Conjecture 6.11 与 [Qin Remark 2.20](https://arxiv.org/html/2508.12761v2) 已提出相关 Newton 一致性目标。本结果应定位为无环标准几何家族的范围结论，不是新猜想。CMMM 的顶点 monicity 没有被误当作该相等定理。

另有必要支撑条件：theta 的 z^b 系数非零，则 F_b 在整 Schur 基中的系数 gcd 必为 1。因为 theta 系数≤所有 p 的 Euler 乘法秩，而某素数若整除所有 F_b 系数，该秩就是零。没有声称这一条件充分，也没有声称 P_r 全部格点都有 theta 项。

# 正实根面保持整 Smith 因子

对上述正 facet，b=h dimE+D b′ 时，Gr_b(M) 与 Gr_b′(N′) 同构。精确嵌入 E⊥→repQ 在每个顶点是 projective tensor 函子，因此普通 Grassmannian ambient 之间有直和映射 j，tautological bundles 满足 j*[S_i]=h e_i[O]+Σ_jD_ij[S′_j]。D 的像是本原格 ker⟨E,−⟩，故有整数左逆；对总 Chern 类取整数正负幂，恢复全部 c(S′_j)，得到 j* 在各整上同调次数满射。

在 Grassmannian 上取 Euler 配对，矩阵满足 G_k=A_(d−k)ᵀG′_k A_k，各 A 均为整满射。选择分裂适配基后，G_k 整等价于 G′_k 添零行列。ambient 的整 Poincaré 对偶把该配对矩阵识别为 Euler 乘法矩阵。因此每个源次数的全部非零 Smith 因子完全保留；不需要 Grassmannian 自身无挠。于是对 p=0 或任意素数，整个 facet 的几何字符有精确公式：

```math
(F_g^{(p)})_{\mathcal F}=z^{h\dim E}F_{g'}^{(p)}(z^D).
```

这给逐项系数相等，强于顶点结论。theta 对应公式仍在研究：facet 射线有交换等权，必须保留二项式初始交换式，不能套用内部权的单项式证明。

# 循环 Laurent 级数的完整 MacMahon 公式

取 B=((0,3,−3),(−3,0,3),(3,−3,0))，z_i=y_i x^(Be_i)，s=z_0z_1z_2=y_0y_1y_2。令 Z_i(z) 枚举 N³ 的有限 order ideals，每个盒 u 的颜色为 i+u_1+u_2+u_3 模 3；令 M(s)=∏_(k≥1)(1−s^k)^(−k)。全主系数、初始正腔的形式 theta 满足：

```math
\vartheta_{(-e_i,0)}=x_i^{-1}\frac{Z_i(\widehat y)}{M(y_0y_1y_2)^3},\qquad
\vartheta_{(-a,0)}=x^{-a}\frac{\prod_i Z_i(\widehat y)^{a_i}}{M(y_0y_1y_2)^{3|a|}},\quad a\in\mathbb N^3.
```

证明的三个原始输入已逐项审核。[BDLP 2210.10712v3 Theorem 1 与 §5.2](https://arxiv.org/html/2210.10712v3) 给 C³/μ₃ determinant-potential 的 attractor 谱：简单根为 1，kδ 的 unrefined invariant 为 −3，δ=(1,1,1)，其余为零。[Argüz–Bousseau 2308.07270v2 Theorem 1.20](https://arxiv.org/html/2308.07270v2) 说明删去中心墙即 cluster 图。其正约定 Ω⁺=−κΩ，κ(d)=(−1)^χ(d,d)；χ(kδ,kδ)=−6k² 为偶数，中心墙函数恰为 M(s)³。

中心删除公式本身已有 Mandel–Qin 的先例，不主张其为本轮新发现。直接全主系数证明是：若 r∈kerB∩N^n，沿 broken line 的 r·位置导数恒为 −r·g；终点在正腔，故完整超平面 r⊥ 只在 r·g<0 时穿越一次，乘因子 C_r^(−r·g)。中心弯折不改 mutable 速度，且交换所有其它作用，逐度插入／删除成立。根李代数中 α+β 为 radical 时 ω(α,β)=0，因此非中心括号不能偷偷生成中心项；中心商的图一致性提升到忠实主系数表示。

[Mozgovoy–Pioline 2012.14358v2 §3.4 Theorems 3.4、3.5 与 §4.5](https://arxiv.org/html/2012.14358v2) 给一般 quiver 的 framed wall transport 及晶体公式。其 §2.6 只处理 symmetric quiver，不用于此处。晶体固定点符号为 (−1)^(d_i+χ(d,d))；扩充 framing 后的二次 torus untwist 恰好消去它。determinant Jacobi 关系将三方向步长交换，晶体就是按总次数模三上色的平面分拆。

方向与主系数配对独立核实如下：目标 Q 的 ω_Q=−B，故 MP 的 χ−χᵀ=B；cocyclic framing i→* 给 ⟨d,ρ⟩=−d_i。主系数 P=(B;I)，Ω=((0,−I),(I,−B))，有 (Pd)ᵀΩ(Pe)=dᵀBe 及 (Pd)ᵀΩ(−e_i,0)=−d_i。opposite outward framed torus 到该 torus 的同指数映射是反同构，Hall 对偶反转短正合、King 权变号，所以 A_op X^ρ A_op⁻¹ 变为 A_Q⁻¹ X^ρ A_Q。这把正到负的 cyclic 公式变为负到正的 cocyclic theta 传输。不能只校准总次数而忽略颜色交换。

负正交腔中 g≤0 的 theta 是单项式：若有弯折 a_j、时距 u_j>0，将墙方程乘其弯折倍数并相加，交叉项为对称 min(u_j,u_k) 乘斜对称 B，故抵消；剩余 Σa_j·(Q+u_jg)<0 与零矛盾。传输是代数同构，因此所有负标签的 theta 为负单位 theta 的乘积，给上述整个负正交族。

BDLP 证明中的局部表述修正已保留：单个起点 cycle 应解释为中心元的 idempotent 分量；文中 q=1 列表漏一类，可令 n₂=n、n₁=n+a、n₃=n+b，a,b≥0，将实际不等式化为 a²+b²+3ab+2n(a+b)≤1，直接推出 simple 或 δ；θ₁+θ₂+θ₃=0 不是任意 King 权恒等式，sign 选择不需要该一般断言。这些是对所用旧 attractor 输入的独立修补。

令全部 z_i=t，则对 a≠0：

```math
F_{-a}(t,t,t)=\left(\frac{M(t)}{M(t^3)^3}\right)^{|a|}=\prod_{3\nmid k}(1-t^k)^{-|a|k}.
```

该整系数级数收敛半径为 1；其 log 沿 t→1⁻ 至少按 2|a|/(3(1−t)²) 增长，故不是有理函数。Pólya–Carlson 定理给单位圆自然边界，遂非 D-finite，特别非代数。它否定“全部形式 theta 总有一个有限 holonomic 方程”的无条件路线，不妨碍有限标签或特殊已证方程的有效停机。精确主系数校准检查了总根次数≤13 的全部 560 个位置，无差异；总次数≤16 也吻合。计算只校准约定，全阶结论由上面图与 framed 公式证明。

# 第八次文献与路线复查

2026 年 11 月 14 日 05:41 UTC 左右进行。新 Newton 主定理经 fresh reviewer 通过，补齐了泛型商与 AHIKM 商配对；新增整 facet Smith 降秩由 root 独立核查。任意强基的全切片正性完整证明已由代理消息交付，最后写盘因本地执行环境不可用而失败；此补记保存其全文逻辑。

正向有限路线继续。GHK 2015 的 Cox 描述仅给线束类还不够：同类 E+nD 可不断增加截面，必须从完整 theta 标签另取边界极点预算。Keel–White 2412.01774 的正面 Cox theta 机制依赖 affine interior，不能直接用于三箭循环的 −2 boundary cycle。签名 framing 的有限 generic cokernel 与 theta 的严格接口仍未完成，不能把普通 generic character 偷换为 theta。

最新检索出现 Peigen Cao 2602.07929v2 的 Newton／τ-tilting 论文、Fei 2609.32425 的 branching LP 论文以及 Fei–Xue 2607.25201 的 Markov Kronecker 论文。当前只作线索，未强审全文，均不作为新证明输入。Mandel 的 scattering-atlas atomicity 仍不等于普通 cluster-atlas 最小性；CMMM 的顶点 monicity 与 valuative independence 没有被扩大为全内部系数比较。

下一轮主攻：theta 整面初始形式与 perpendicular 坐标的精确对齐；用任意强基全部正切片及完整正乘法读取内部 theta 系数；继续寻找真正对标签有效的有限 Laurent 载体。下一次文献路线复查约 06:01 UTC。

# 任意 exceptional 方向的完整 theta 面约化

2026-11-14 06:01 UTC 阶段结果：以下证明已完成逐式推导，root 初审通过，另已交给新的独立代理复核三个接口。它只处理经典、斜对称、无环主系数丛代数。设 Euler 矩阵为 E，B=E−Eᵀ，V 为 exceptional 模块，v=dim V，δ=Eᵀv。令 V⊥={N:Hom(V,N)=Ext¹(V,N)=0}≃rep Q′，D 的列为这个范畴的简单对象在 Q 中的维数。则任意 theta 的 δ 最大面都有下面的完整系数公式；此算子结论不依赖 Newton 等式。

```math
\operatorname{face}_{\delta}F_g^{\vartheta,Q}(z)
=z^{p_V(g)}F_{g_V}^{\vartheta,Q'}(z^D),\qquad
E'=D^TED,\quad B'=D^TBD.
```

选择最小 co-Bongartz 完成 T=P(Fac V)，补上缺失顶点的 shifted projectives，得到 n 个 summands，位置 k 对应 V。对 module summand T_j，设 H_j=dim T_j、W_j=Eᵀdim T_j；对 P_i[1]，设 H_j=0、W_j=−e_i。W 是 presentation-weight 矩阵，不能替换成通常的 g 矩阵。最小完成的 module summands 全属于 Fac V。Jasso 的约化以及 AHIKM Theorem 4.11(a) 的保序二项 silting 双射，将最大完成送到约化投射生成元，将最小完成送到其移位 [1]。在 Db(Q)/thick(V)≃Db(V⊥) 的左投影 q 下，除 V 外各 summand 逐一对应互异基本 P′_j[1]。Euler 伴随给 ⟨T_j,DN′⟩=⟨qT_j,N′⟩；重排 J=[n]∖{k} 后得到 WᵀD=−I_J，W_k=δ，且 W∈GL_n(Z)。

这个负投射字典也有直接模块解释。若 T_j∈Fac V，universal evaluation 给 0→K_j→V^{dim Hom(V,T_j)}→T_j→0。V exceptional 且 hereditary，使 Hom(V,K_j)=Ext¹(V,K_j)=0；对 N∈V⊥，长正合列又给 Ext¹(K_j,N)=0，所以 K_j 是约化投射且 qT_j=K_j[1]。不可分解、互异、完备由上述 presilting 双射保证。对 outside P_i[1] 必须用 qP_i[1]，不能说原 P_i 本身属于 V⊥。acyclic cluster category 的 tilting graph 连通性保证完成对应可达种子。

取 ν(x_i)=0、ν(y_i)=−δ_i。若 L⊊T_j∈Fac V，则 C=T_j/L 为非零 Fac V 对象，Hom(V,C)≠0 且 Ext¹(V,C)=0。因此 δ·dim C>0，dim T_j 是其子模多面体唯一 δ 最大点。rigid cluster character 的该项系数为 1，故 inν X_{T_j}=x^{−EᵀH_j}y^{H_j}=x^{−W_j}y^{H_j}。shifted projective 也满足此式。因此最终种子全部变量的初始指数矩阵 K 如下，且为整可逆矩阵。不同最终 Laurent 单项式的初始单项式不会碰撞；无需沿某条变异路径对等权交换任意择项。

```math
K=\begin{pmatrix}-W&0\\ H&I\end{pmatrix},\qquad
\widetilde B_0=\binom BI,\qquad
\Lambda_0=\begin{pmatrix}0&-I\\ I&-B\end{pmatrix},\qquad
\widetilde B_0^T\Lambda_0=[I\ \ 0].
```

最终 root variables 的初始项 degree 为零，故唯一写成 z 的整幂；记其指数矩阵 R，则 K·Btilde_t=Btilde_0·R。所有种子坐标初始项均唯一，Poisson bracket 在 associated graded 上给 Λ_t=KᵀΛ_0K。将种子兼容性代入，得到 [I 0]=Rᵀ[I 0]K=[−RᵀW 0]，从而 R=−W^{−T}。配合 WᵀD=−I_J，得 R_J=D。上半块 −WB_t=BR 还给 B_t=RᵀBR，故删 k 后的交换矩阵精确为 DᵀBD=B′。这一组计算保留全部冻结变量，不要求 B 可逆。

```math
\operatorname{in}_\nu\widehat y_{t,j}=z^{D_j}\quad(j\in J),\qquad
\nu(\widehat y_{t,k})=1,\qquad
\nu(\widehat y_{t,j})=0\quad(j\in J).
```

将完整 theta 标签 (g,0) 变换到该种子，写为 (a,b)，mutable 部分 a、原冻结部分 b。Qin 2024 Lemma 5.1、Theorem 5.2 的原始冻结定理逐项保留 root k 次数为零的 broken lines。其余 root 变量由上式代入 z^D；冻结后的 principal specialization 使剩余 F 只依赖 a_J。于是 inν θ_g=x^{−Wa}y^{Ha+b} F^{θ,Q′}_{a_J}(z^D)。principal degree 同为 g，所以前因子唯一写为 x^g z^{Ha+b}。得到 p_V(g)=Ha+b、g_V=a_J，且 p_V(g) 实际是原 F 的出现指数。

对本轮已证的正实根 facet，泛型 M_r 有 V^h⊂M_r、N=M_r/V^h∈V⊥，N′ 泛型、dim N′=r′，该面为 hv+D P_{r′}。Newton 等式与上面的完整面公式先强制平移 p_V(g)=hv：因为 reduced F 常数项为1，p=hv+Db₀，b₀≥0；而顶点 hv 也出现，hv=p+Da₀，a₀≥0；D 单射给 a₀=b₀=0。再把 reduced label 写为 u−E′s，u_i s_i=0；降秩 Newton 等式给 P_s=P_{r′}，取各坐标最大值得 s=r′。真正 facet 满维迫使 r′ 全支撑，故 u=0。最终得到：

```math
\left.F_{-Er}^{\vartheta,Q}(z)\right|_{\mathcal F}
=z^{h v}F_{-E'r'}^{\vartheta,Q'}(z^D).
```

来源归属：[Jasso 1302.2709v4](https://arxiv.org/abs/1302.2709)、[AHIKM 2203.15213v4, Th.4.11](https://arxiv.org/html/2203.15213v4)、[Qin 2407.03186v1, Th.5.2](https://arxiv.org/pdf/2407.03186)、[BMRRT math/0402054, Prop.3.5](https://arxiv.org/abs/math/0402054)。Fei [1909.10151v3, Th.6.8 与 Cor.6.21](https://arxiv.org/pdf/1909.10151) 已有一般表示及 rigid 模块的面公式，不能称为本轮新结果。本轮新增接口是 co-Bongartz 的全主系数单项式坐标、任意 theta 的面约化及与已证 Newton 等式的结合。有限查新未发现完全相同结论，尚不作排他性优先权声明。

计算记录：代理用 Wolfram 在秩 2、3、4、6、8、12、16、24 各作64组、共512组精确整数矩阵检查，随机种子202611140553；半数 B 强制奇异。WᵀR=−I、K Btilde_t=Btilde_0R、Poisson兼容、WᵀD=−I_J、B_t[J,J]=DᵀBD 全部通过。它只检查一般矩阵块及符号，不代替表示论约化证明。路线记录：先前任意路径的等权初始变异留下双有理坐标；最大 Bongartz 完成的方向不统一；最小完成使全部变量初始项单项式，才闭合原始 z^D 字典。

# 强连通块的有向无环粘合与有限 Laurent 载体

此节是已证正初始墙增广总定理的闭包推论。Q 的强连通块为 I₁,…,I_s，块间凝聚图为 DAG；每块势 W_α 已审，整体 W=ΣW_α。假设每块完成 Jacobian A_α 有限维，并且其完整吸引子初始数据已审核为经典丛初始数据的允许正增广。这一假设不能只由块的 theta 有限或未经核验的 BPS 猜想替代。已审的 m=2 Markov 块、无环块及任何满足该输入条件的块可任意 DAG 耦合。

设 C_α,uv=dim e_u A_α e_v，C₀=diag(C_α)，E_out,uv 为块间箭头 v→u 的数目。每条路径唯一分成块内段与块间箭头，最多跨 s−1 次；势关系完全分块。因此完成 Jacobian 的 Cartan 矩阵精确为：

```math
C=\sum_{k=0}^{s-1}(C_0E_{\rm out})^k C_0
=(I-C_0E_{\rm out})^{-1}C_0
=C_0(I-E_{\rm out}C_0)^{-1}.
```

这里的逆都是有限几何级数。Amiot 2009 Proposition 3.8(3) 已证明 Jacobi 有限性对三角扩张封闭，明确作为旧输入。完成与普通代数必须区分：对有限维完成 Jacobian，箭头理想处于 Jacobson 根中，故幂零；若只给普通有限维 Jacobian，其箭头理想未必幂零，应先取 A_ord/(∩_k R^k) 的 nilpotent 商。普通 Cartan 仅能作为该商的逐项上界。

Mozgovoy–Pioline 的强连通支撑定理在 arXiv:2012.14358v2 是 Theorem 3.9，2025 AIF 正式版是 Theorem 3.8。若支撑跨块，取凝聚图非空真后继闭子集 S，M_S 为子表示；有外部箭头进入时吸引子配对严格为正，泛小扰动后仍破坏半稳定；完全断开时两部分配对互反且泛扰动非零，也破坏半稳定。此论证适用所有多重度及 nilpotent 子范畴。支撑只在一块时表示空间、势及吸引子参数等于该块。因此整体吸引子初始数据恰为各块数据的并。

进入全局主系数时应冻结块外顶点，保留其系数箭头，统一令 z_i↦ŷ_i=y_i∏_u x_u^{B_ui}。块内中央向量加入块间箭头后未必全局中央，不能再直接乘除中央因子。若额外初始函数分解为允许的有限正因子 1+c_λ z^{r_λ}，用辅助顶点及 Π=[I,r_λ]、B′=ΠᵀBΠ，取标签 Πᵀg；原 mutable x′_i↦x_i、辅助 x′_λ↦1，y′_i↦y_i、y′_λ↦c_λ y^{r_λ}。相关标签与 root 子代数的配对兼容，非零非负 r_λ 保证逐次有限。不是声称整个扩展环的任意映射都是 Poisson 映射。

在已审相对 Hall 负框架约定中，I_i=D(e_iA)，dim I(a)=Cᵀa。稳定性 theta 的次数受 I(a) 子模维数约束，正初始增广比较给 0≤F^{cl}_{−a}≤F^{st}_{−a}。对任意 g，x^{g_+}θ_{−g_-} 的正 theta 展开包含 θ_g，首项系数1，故得到完整可计算载体：

```math
\operatorname{Supp}F_g^{\vartheta}\subseteq
\{d\in\mathbb N^{Q_0}:0\le d\le C^Tg_-\}.
```

这一结论给该类任意秩 DAG 粘合的全部标签有限展开，不声称盒界为最小 Newton 多面体，也不把有限 theta 属于 middle/upper 自动等同于属于普通 A。来源：[Amiot 2009 原文](https://numdam.org/item/10.5802/aif.2499.pdf)、[Mozgovoy–Pioline v2 原文](https://arxiv.org/pdf/2012.14358v2)。计算：Wolfram 实际检查24个3维块、72×72精确整矩阵，(C₀E_out)^24=0、(I−C₀E_out)C=C₀、C(I−E_outC₀)=C₀全部True，最大整数25位；块内矩阵为稠密非负，并未假设其幂零。完整新颖性仍待进一步检索，定位为总定理闭包及显式界。

# 第九次文献与路线复查

复查时间约06:01 UTC；下一次06:21。研究仍指向一般 Laurent 有限停机与普通 cluster atlas 的任意强基最小性，二者均未宣称完全解决。此次数学推进为任意 exceptional 方向完整 theta 面公式、SCC 任意 DAG 粘合显式有限载体，以及强基精确 CM 因子化带来的有限高度候选归约。新鲜独立代理正在审核面公式；另一新代理检验正有限载体的增广。

| 文献或路线 | 实际核查与结论 | 使用状态 |
|---|---|---|
| Peigen Cao, 2602.07929v2 | root 逐项读 Th.4.11 及 Lemmas4.6–4.10、Bongartz定义：主结论是非初始 CM 的 Newton 唯一性；归约通过零 F-pairing 先得相容，再用负 c 列剥去同指数，逻辑通过。Th.2.27引用in preparation，但原文明确该段不用于后文，不能因此判主定理有缺口。HTML Prop.2.20 的 G 与 C 逆关系疑有漏转置排版，结论不受此局部式影响；不据此声称整文错误。 | 邻近性审核通过；本轮面公式不依赖此2026文献 |
| Davison, 2601.08004v1 §4.4 | root与代理读完整框架段：双向框架箭头、由框架生成的稳定对象、保框架商及适当对应成立；没有给任意带符号标签的 theta 等式或统一维数界。 | 有用背景，未补字典；不作定理输入 |
| Fei–Xue, 2607.25201 | primary HTML、摘要、PDF本次均无法取回。 | 未审核、未使用；不能由搜索摘要采用 |
| Reading–Stella, 2603.19391 新版本 | 新检索发现 mutation of theta functions 与 pointed reduced bases 分类，可能触及本轮分类。 | 待新代理强审，尚不采用 |
| 正 CM 乘积见证有限性 | GHKK intrinsic addition closure 已有；有效有限次数正系数可给支撑界，但不能覆盖已审 Markov 中负中央度的有限 theta。 | 旧机制的有效化，不冒充一般完备判定 |
| 全种子自动 pointedness | 仅由 injective head 覆盖不能排除 Hilbert-hotel ghost；相邻正切片仅给可除性，尚缺新的 Newton 上界。 | 已定位，继续 real-anchor/有限正算子路线 |
| 纯 signed framing / NCCR generic cokernel | 现有文献缺实际一般 theta dictionary；不把泛型 character 当 theta。 | 此分支暂交接，换接口继续 |

本轮保存的页面内容已逐块读回核对。执行环境仍不可用，最新公式先保留在此阶段补记；正式总 ZIP 尚未生成，不把早先进展 ZIP 当最终包。

# 强正基的精确 CM 分解与有限高度系统

以下结论适用于经典、无环、斜对称、冻结可逆的主系数普通 A；调用前述实际 induced-basis/unit-orbit 引理，不自动推广到 valued 情形。写 a=G⁻¹(g)、r=[−a]_+、p=[a]_+，则 g=−Er+p、p_i r_i=0。令 b_r=β_{−Er}。由 β≤E 得 F_g 不含 supp(r) 外的根变量；对 S=supp(r) 应用实际降秩基，F_g=F^S_{g_S}=F^S_{(−Er)_S}=F_{−Er}。所以：

```math
\beta_g=x^p b_r,\qquad
\#\{r\in\mathbb N^n:|r|\le H\}=\binom{n+H}{n}.
```

规范化后的 x_iβ_g 强正展开含首项 β_(g+e_i)，故 F_(g+e_i)≤F_g。递推 r_i(g+Ne_i)=[r_i(g)−N]_+；N≥r_i(g) 后全部 F 不含 z_i，实际降秩基使它精确等于 F_g|_(z_i=0)，并且不再随 N 改变。这是有限步稳定。

每个 r 的候选集 C_r 定义为所有 b=x^(−Er)F(z)，其标准展开为 E_(−Er)+Σ_(q∈D_(−Er))a_q y^q E_(−Er+Bq)，a_q∈Z，且0≤F≤∏(1+z_i)^r_i。它是可实际有限枚举的集合：枚举每个 e∈[0,r] 的整数系数0≤F_e≤∏binom(r_i,e_i)，再按递增根次数，用首项 z^q 系数1的多项式 z^q∏(1+z_i)^{r_i(−Er+Bq)} 消元检查标准展开。不需要对无界 a_q 搜索。

任取每个 r 的一个 b_r∈C_r，再对任意 g=−Er+p、pr=0 定义 β_g=x^p b_r，自动得到实际 Z[y] 基。理由：候选修正满足 q+r(h)≤r，其中 h=−Er+Bq；p 只能支撑在 r_i=0 上，也在 r_i(h)=0 上，故 r(h+p)=r(h)，x^pE_h=E_(h+p)。因此 β_g=E_g+严格降低|r|的有限修正。单位三角逆变换沿非负整数高度有限归纳，实际张成与独立均成立；没有形式无穷逆矩阵漏洞。

这个实际基强正，当且仅当它包含所有 CM，且两类乘法 x_i b_r 与 b_r b_s 的结构常数均在 N[y]。充分性：任意β_gβ_h=x^(p+p′)(b_r b_s)，先正展开 canonical 乘积，再逐次正乘各 x_i；每个输出又为 x^u b_v。由此完全消除了无限多个正指数 p,p′ 的约束。

有限高度闭合也无需先假设正性。若实际乘积首次数为K、根支撑在[0,R]，其β展开非零项 c_q y^qβ_(K+Bq) 的顶角为 q+r(K+Bq)。顶角映射单射来自 H(h)=h+Br(h) 双射；若某顶角越过R，取偏重越界坐标的正权并微扰，唯一最大顶项不能消去。因此所有真实项均满足 q+r(K+Bq)≤R。对 b_r b_s 取R=r+s；对x_i b_r取R=r。

高度 H 系统 X_H 仅有 binom(n+H,n) 个有限候选变量，检查 n·binom(n+H,n) 个 x_i b_r 乘法，以及至多 binom(2n+H,2n) 个 |r|+|s|≤H 的有序 b_r b_s 乘法，所有输出仍在高度 H 内。CM 条件可加入长度≤H的变异词、其指数总和≤H且 canonical 高度≤H的 CM，构成有限列表并随 H 穷尽所有 CM。也可用泛型轨道切映射的符号秩识别有界维数刚性，作为优化而非前提。

各 X_H 为有限集，限制映射相容；其逆极限精确参数化实际的全局强正基。固定一个具有负 theta 系数的候选 c∈C_r：若某层 X_H(c) 为空，就有有限整数不可满足证书；若所有层均非空，König 引理给真正全局强正反例基。这没有提供统一 H 界、统一停机或可计算无限路径，也没有证明最小性。下一主攻必须利用正算子的一般结构取得证明或实际全局构造，不能停在紧致性或有限排除记录上。

计算诊断：Wolfram 在5000组秩2至8、边重0至5的无环斜对称矩阵上核 r(g_r)=r、r(g_r+p)=r（pr=0）、r(g_r+g_s)≤r+s、r(g_r+e_i)≤r，四项无失败。证明依赖上述实际基与顶角论证，计算不代替证明。新颖性正与 Reading–Stella 最新 v4 的 formal reduced basis 分类对照。

# 2026 文献强审补记：两类不能直接使用的泛化

此节只记录影响本研究的精确反例与可安全使用的范围。它不把一般 scattering 反例说成经典丛代数反例，也不把 formal basis 反例说成任意强正基反例。

**CMMM 2505.09585v2，Theorem 3.14 的一般 positive-scattering 版本。** root 与独立代理核对§2.1、§3.5、§3.7的 literal 条件。取 M=Z²、C₁={0}、D₁空图；C₂=N，D₂只有满墙{m₁=0}，normal e₁、方向−e₂、函数 f=(1−yx₂)⁻¹=Σ_(k≥0)(yx₂)^k。该函数属于 Z[x₂][[y]]，每个 y 次数有限，所有系数非负，指数锥 R_≥0(e₂,1) 严格凸，单满墙一致。终点第一坐标正，u=(−e₁,0)、u′=(−e₁+e₂,1) 时，每条 broken line 恰跨墙一次，直接得：

```math
\vartheta_u^{D_2}=\frac{x_1^{-1}}{1-yx_2},\qquad
\vartheta_{u'}^{D_2}=\frac{yx_2x_1^{-1}}{1-yx_2},\qquad
\vartheta_u^{D_1}=x_1^{-1}=\vartheta_u^{D_2}-\vartheta_{u'}^{D_2}.
```

这满足有限 signed theta 组合假设，却不满足其结论。缺口与原文证明相符：w(y)=−1时两个大图 theta 的估值都是−∞，而 Theorem3.8明确要求右端inf有限。此反例不否定标准有限 initial binomial 的 cluster Theorem4.12；它说明该处必须另补依据。有限个已知有限 Laurent theta 的情形可安全使用3.8。Wolfram 实际核有理恒等式True、100阶截断残差0。

同一图按§3.8定义仍 monic：f的Newton是射线，唯一顶点0系数1。令s=yx₂、u_j=u+j(e₂,1)，则 θ_(u₀)−2θ_(u₁)+θ_(u₂)=x₁⁻¹(1−s)。右边一个顶点系数−1，不是该theta展开的任何非零系数1、−2、1。因此Theorem3.15按其一般形式范围也不能直接使用。我们的无环 Newton 定理由实际 Euler 顶点类与正换基证明，并不依赖这一未加条件的泛化。来源：[CMMM v2 原文§3.7–3.8](https://arxiv.org/html/2505.09585v2)。这里没有宣称其有限theta的monicity结论错误。

**Reading–Stella 2603.19391v4 / SIGMA22(2026),109。** 新代理已核正式 PDF p.29–30，而非只看HTML。§5.3的pointed只固定每个seed的 mutable head，允许任意 frozen 单项式。取秩一 B=[0]、principal y、ζ=σ=y、u=1+y、m=0。偶数变异后为1+y；奇数后 y′=y⁻¹，u=y′⁻¹(1+y′)。这满足literal pointed定义，但 θ₀=1使φ(0,k)=0，Theorem5.6(ii)要求 u∈k[[y′]]，显然失败；其(iii)也失败。proof中mutable指数决定frozen指数的断言在ker B存在时不能成立。修复须固定完整tropical degree，或直接以(ii)为定义；修复后有限实际theta展开的分类尚可独立证明。

该文 Corollary3.6 本身只说 theta basis 是Hamel基，可以保留；其前一句把结论扩到任意 reduced basis 不成立。仍在秩一，u_m=(1+y)θ_m满足其收敛 reduced basis 定义，因为 θ_m=Σ_(k≥0)(−y)^k u_m，根次数统一下界0且mutable g-support只有m。但有限 R= k[y±] span为properideal(1+y)A，不能包含1；代入 y=−1、x=1、x′=0亦可见。此族既非实际Hamel基，又不包含所需CM，绝不是本研究强最小性反例。Wolfram核 m=−20,…,20的变异恒等式及51个几何级数残差通过。来源：[正式PDF](https://sigma-journal.com/2026/109/sigma26-109.pdf)、[arXiv v4](https://arxiv.org/html/2603.19391v4)。当前代理继续查修复后的完整次数条件能否真正推进强正性。

# 单位正算子判据：不预设齐次性的自动 pointedness

以下为06:26 UTC收到的新证明，root与新独立代理逐步核验通过。它给前述无环归一化一个不依赖BFZ或无限三角退化的证明，并把代数部分扩到无环斜可对称；此前只在斜对称范围陈述的 coordinate fiber、单位轨道、正切片和精确CM分解因此获得同样扩展。Newton、Grassmannian和Smith几何定理仍保留普通无环箭图范围。

设经典主系数种子t的变量为X_i、扩展交换矩阵为\tilde B_t，R=Z[y^{±1}]，C是实际强正R基并包含全部CM。假设对每个i存在冻结单位乘CM的Y_i，其展开为Y_i=X_i^{-1}(1+Σ_{q>0}a_{i,q}\widehat Y^q)，a_{i,q}≥0，并满足(U)：X_iY_i−1∈N[y^{±1}]C。则C按冻结单项式归一化后自动pointed，每个mutable head g∈Z^n恰出现一次，而且principal齐次性也自动成立。

先证明每个b∈C在种子t中Laurent正。取N≥0清掉mutable分母，X^N b=Σ_{u≥0}r_u(y)X^u。左边是强正乘积，右边各X^u是互异CM基元素；实际基展开唯一性迫使所有r_u∈N[y^{±1}]。

让ν遍历全部2n维严格正根权锥Ω={ν:\tilde B_t^Tν>0}。给自由C模中的每个基向量赋真实Laurent估值ν(b)。在正展开X_i b=Σ_c r_cb c中，任何系数单项式y^α都有ν(y^α)+ν(c)≥ν(X_i)+ν(b)，否则正Laurent项不能消去。故X_i,Y_i给出列有限的非负初始矩阵P_i,Q_i。条件(U)及ν(X_iY_i−1)>0保证其乘法严格提高过滤，于是P_iQ_i=Q_iP_i=I。

非负Laurent单项式半环上的列有限矩阵若互逆，就只能是单项式置换矩阵：单位矩阵每列只有一个系数1的单项式，不能由两个非零正项相消产生。此论证允许无限指标集合。再次清分母，X^N b的自由基初始形式只有一个基元素、系数为一个系数1的冻结单项式；右侧Σr_uX^u的最低层也只能有这一个单项式。因此对每个ν∈Ω，in_ν(b)都恰为系数1的Laurent单项式，包括存在等权可能的非泛型ν。

b的有限Laurent支撑在连通开锥Ω中的唯一极小点不能变化，否则途中必出现两个并列最低点。记共同最低点m_b。对全部支持m，ν(m−m_b)≥0对所有ν∈Ω成立，故m−m_b∈\tilde B_t R_{≥0}^n。主系数根子格饱和（当前C_t整单模），因此m−m_b=\tilde B_t q、q∈N^n。这同时给pointedness和齐次性。

最后取ν(X_i)=0且根权严格正。初始乘法P_i为互相交换的可逆置换，mutable head增加e_i。清分母说明任意基元素经有限次这些置换落到初始CM上；全部基元素处于1的同一个Z^n轨道。head的变化排除非零稳定子，因而每个g恰好出现一次。该证明不把自由基过滤与任意带符号Laurent和的估值过滤错误等同。

# 无环斜可对称的纯变异单位关系

将无环B排序为i<j时B_ij≤0，依次变异source 1,…,n，得到I_i。第i步当前row i非正、C_i=e_i，其余C列不变。因此
x_i I_i=1+y_i∏_{j<i}I_j^{-B_ji}∏_{j>i}x_j^{B_ji}。
非平凡项的mutable变量同处该步种子，故是冻结单项式乘CM，对任意强基自动非负。逐步代入得I_i=x_i^{-1}F_i(z)，F_i=1+z_i∏_{j<i}F_j^{-B_ji}，特别F_i|_{z_i=0}=1。它同时验证(U)和前述单位轨道降秩所需的退化逆元。

此处完全不使用species、内射essential socle或几何模范畴。root用Wolfram实际检查288个valued矩阵，秩2、3、4、6、8、12、16、24、32，共3424次source变异；对角symmetrizer取1至5、边重0至3。当前source行符号、C_i=e_i、交换非平凡分支degree0、末态B=B_0、C=−I、G=−I全部通过。实际回执为<|cases→288,source_mutations→3424,failures→0,all_pass→True|>。该计算检查公式实现；一般证明由上段source关系承担。

# 面约化补充：约化代数心的识别

前述完整theta面约化的独立审核通过，但应补以下环节。V exceptional时L(X)=Cone(V⊗^L RHom(V,X)→X)给到D^b(V^\perp)的左投影，RHom(LX,N)=RHom(X,N)。令T_max为Ext^1(V,−)=0中的Ext-projective generator，即Bongartz最大完成。对N∈V^\perp有Ext^1(T_max,N)=0，所以RHom(qT_max,N)只在零次。因V^\perp hereditary，qT_max是实际投射；T_max生成D^b(Q)，故qT_max是派生商中的投射生成元。AHIKM约化代数的标准心因此就是几何V^\perp，最小完成确实变为全部基本P'_j[1]，W^T D=−I_J的负号与整格识别均成立。

# 所有无环种子的完整头项与精确系数搬运

任意β_g的有限theta展开只有对角θ_g系数1和严格降低height=|r|的修正。若在另一种子t同一实际C重新归一化为各head唯一的pointed族，则β_g的完整头项必为展开中某个theta项的头：有限头项集合的偏序极小点不能被非头项抵消，pointedness又迫使其等于总和的头。故新mutable标签是κ_t(h(g))，其中h(g)=g或height(h(g))<height(g)。头唯一使h单射；非固定点反复迭代不能撞入不动点（否则两原像），从而产生不可能的自然数无限下降。故h=id，完整frozen头也由唯一对角系数1强制为θ_g的头。

在每个无环种子重新使用单位判据，以上假设自动满足，得到任意强正基在所有无环种子full-compatibly pointed。当前C_t是整单模，重新principalize只作冻结Laurent单项式换元与变量单位归一化，保持实际R基和正半环。途中可以经过含环种子，但本结论只对无环终点作断言。

在无环t写κ_t(g)=−E_t r+p，pr=0；取v≥0且supp(v)∩supp(r)=∅，g'=κ_t^{-1}(κ_t(g)+v)。精确CM分解给
x_t^v β_g=σ_t^{φ_t(g)−φ_t(g')}β_{g'}，
theta同式成立。该seed每个实际修正满足q_t+r_t(h_t)≤r_t(g_t)，故v同时兼容全部修正项；乘法不产生额外分支，q_t及整数换基系数原样搬运。满支撑imaginary核心可能始终无这种平移边，不能仅据此宣布最小性。

# 任意环境的无环子图有限提升及饱和系数界

环境B可有环，S诱导子图无环，T=S^c。倒序解a=G_S^{-1}(g_S)、r=[−a]_+，令L_T(r)=Σ_{i∈S}[−B_{Ti}]_+r_i。若g_T≥L_T(r)，实际普通A中的正乘积
P=x_T^{g_T−L_T(r)}∏_{i∈S}x_i^{[a_i]_+}(x_i')^{r_i}
=x^g∏_{i∈S}(1+z_i)^{r_i}
的theta展开包含θ_g、系数1。故0≤F_g≤∏(1+z_i)^{r_i}；F_g有限且T根次数为0。Qin冻结于是给完整等式θ_g^B=x^gF_{g_S}^{B_SS}(z_S)，其中外部系数仍为Y_i=y_i∏_{j∈T}x_j^{B_ji}。这是GHKK正乘积首项与Qin冻结的显式有限证书推论，不冒称全新闭包原理。

更一般，已有有限标签m_i和整数证书kg=Σ_i a_i m_i，k>0,a_i≥0，令H=∏F_{m_i}^{a_i}。正乘法给F_kg≤H；broken line同路径参数缩放Γ_k(t)=Γ(kt)使全指数乘k，逐墙非负Cauchy乘法给[z^{kp}]f^{kN}≥([z^p]f^N)^k。缩放可从全指数恢复，故单射。于是a_g(b)≤[z^{kb}]H，SuppF_g⊂{b:kb∈SuppH}，degF_g≤floor(degH/k)。GHKK原饱和性已用此缩放；此处只提取可执行逐系数界。

Mandel 1503.06183v5 Theorem4.2已给纯经典Frobenius同余θ_pg≡θ_g^p modp，故a_g(b)≡a_pg(pb) modp。若已有上界U(b)及若干素数倍标签的系数，素数乘积>U(b)时CRT唯一恢复a_g(b)。这是旧定理的算法组合，尚未穷尽实现查新。计算插件实际核12800个缩放系数位置与512个秩3至32的无环子图首指数，全部通过。

任意冻结有限theta若有普通A_frozen表达式，可清外部mutable分母使x_T^N f∈A_big，再用A⊂mid和仅针对已知有限theta族的CMMM3.8估值独立性得θ_(g+N)^big=x_T^N f。仅知冻结theta有限、但不属ordinary A时，现有证明不能覆盖。Qin2407 Prop6.19预设环境theta有限；逐固定次数最终消失不能推出一个N消去全部混合尾部，需新的统一载体。

# 第十次文献与路线复查

实际复查06:27–06:35 UTC；下一次06:47。新增数学推进是单位正算子完整证明、无环斜可对称纯变异扩展、所有无环seed精确系数搬运、任意含环环境的无环子块有限阈值。一般ordinary-atlas强最小性与所有标签有限判定仍未关闭。新三位代理分别攻击含环单位项、非ordinary冻结有限提升、imaginary核心的正算子与传播。

| 来源／路线 | 此轮状态与作用 |
|---|---|
| GHKK有限theta闭包、Mandel1503.06183v5 Th4.2 | 饱和缩放与经典Frobenius均属旧机制；提取系数界与CRT接口，不重复主张原理新颖性 |
| Qin JEMS Th5.1.2、5.1.6、Cor5.2.7 | 两种子pointed族成实际基和cluster-character的x^pCC(V_r)形状已有；本轮候选新增是从任意实际强正基强制获得条件与系数搬运 |
| Tang2610.00603v1 theta biperfectness，12页 | 已定位原PDF，root开始逐节核验冻结最高项与局部幂零导子接口；尚未作为新定理输入 |
| Tang2611.00190v2 Lusztig乘法正性，27页 | 已定位最新原PDF，root开始核验可迁移的有限阶段、满评价与不可分解标签机制；不从摘要直接引用 |
| Fei2309.08326v4，2026-11-11 | 新代理定位到最新版；HTML取回失败，正尝试PDF；未使用其新增结论 |
| 全无环seed兼容平移 | 独立审核通过，但满支撑imaginary核可能无边；换攻一般正乘法/局部幂零接口 |
| 冻结U的外部清分母 | 新代理发现fullrank有限upper-bound可能给x_T^N f∈U_big；仍需有限theta展开，尚不当成已得提升 |

# 单向分块的完整形式 theta 定理：外块允许任意有环

06:45 UTC，原证明代理、独立审核代理与root三方核对通过。以下只讨论经典丛代数，不调用Li–Pan、Li Fang或未经审核的2026结论。旧Tang2610.00201v3 Lemma9.9已有外块无环版本；本节的新机制删去该无环条件。

设B为任意斜可对称交换矩阵，D=diag(d_i)>0使DB反对称，顶点分成S⊔T，且B_TS≥0。对任意mutable标签g（冻结标签可任意），有精确充要条件：
F_g^B(z)=F_{g_S}^{B_SS}(z_S) ⇔ g_T≥0。
等式先在完整形式级数意义成立，不要求任一theta有限，不要求U=mid，也不要求任何Jacobi有限性。z_i=y_i∏_j x_j^{B_ji}仍保留T的外部系数箭头。

先证充分性。主系数相容Poisson矩阵可取Λ=[[0,−D],[D,−DB]]，满足[B;I]^TΛ=[D,0]。因此grade n的墙法向量正比Dn，全principal方向为p*(n)=(Bn,n)，mutable投影为Bn；primitive归一化只乘正数。对每面grade n墙建立支撑不变量：n_T^T D_T q_T≤0。初始S墙左边恒0，初始T墙q_i=0，均成立。

使用GHKK1411.1394v2 AppendixC.1 ConstructionC.1的中心多面锥逐阶构造。joint j处所有incident wall log的grades生成正加性幺半群Γ_j；因[g_μ,g_ν]⊂g_(μ+ν)，BCH以及取逆都不产生Γ_j之外的grade（取逆只改系数符号）。故每个新grade α是父grades的非负整数和，在joint上α_T^T D_Tq_T≤0。式(C.4)后的新墙严格取j−R_≥0 p*(α)，不是joint的任意线性span延伸。沿射线的导数为−α_T^T D_T B_TS α_S−α_T^T D_TB_TTα_T=−α_T^T D_TB_TSα_S≤0。故新墙继续满足不变量。平行joint的局部Lie代数阿贝尔，无需添墙；refinement只切分支撑。LemmaC.6/C.7给逐阶一致完成，整个论证无需平移扰动。

对一条broken line，令a∈N^n为当前累计根次数，mutable位置为γ，定义E=a_T^TD_Tγ_T。弯折增量为c n（c>0），则E跳变c n_T^TD_Tγ_T≤0。线段内γ'=−(g+Ba)，所以E'=−a_T^TD_Tg_T−a_T^TD_TB_TS a_S≤0；内部B_TT项因D_TB_TT反对称而为0。初始a=0，E=0。正腔终点Q_T>0若a_T非零则E_end>0，矛盾。因此全过程a_T=0。该论证对每个有限根次数截断成立，进而对完整形式级数成立。

正T根分量构成Lie理想。商掉它后初始图与冻结T的图相同，一致完成唯一性识别零T部分；Qin2407.03186v1 Lemma5.1/Th5.2逐项识别相应broken lines，给完整F等式。B有核无妨，因为保留全部principal root次数。

必要性甚至不需要B_TS≥0。冻结除k外全部根，秩一公式给F_g|_(z_j=0,j≠k)=(1+z_k)^{[−g_k]_+}。如果k∈T且g_k<0，则[z_k]F_g=−g_k>0，不可能等于冻结T的级数。因此在一向条件下，外部正平移N∈N^T的最优阈值精确为N_k≥max(0,−g_k)，并且θ^B_(g+N)=x_T^N θ^(freeze T)_g；小theta无限时形式等式仍成立，小theta有限时给有限提升。

# 任意标签的负支撑可达闭包

为避免箭头约定混淆，本段直接定义有向边i→j当且仅当B_ij>0。对任意g，令S(g)为包含{i:g_i<0}并对这些有向路径取前向可达闭包的最小集合，T=S(g)^c。则g_T≥0且B_TS≥0，因而
F_g^B(z)=F_(g_S(g))^(B_S(g),S(g))(z_S(g))。
这对所有B,g适用，精确定位整个root支撑，并把有限/无限问题等价降到该诱导子图。可通过SCC condensation DAG可达性线性时间求S(g)。对任何可达种子重复此步骤，可形成变异词加闭包的有限或无限证书；没有声称这些证书覆盖全部输入。

查新边界：CMMM2505.09585v2 Th4.12明确需要小theta已是有限个环境theta的线性组合，未提供此一向条件下的组合存在性；本节允许小theta本身无限，所以不是其直接推论。Tang2610.00201v1 Lem9.5 / v3 Lem9.9的幂零外块证明已有，不能说首次发现一向冻结。Fei–Weyman1707.04661v2（2026-10-28）原文刚由新代理取回，相关§3–5正强审，不据检索无命中宣称排他首创。核心已审基础：[GHKK Appendix C](https://arxiv.org/pdf/1411.1394v2)、[Qin freezing](https://arxiv.org/html/2407.03186v1)。

# 含环 Schur 种子的任意强基自动首项

范围：经典skew-symmetric mutation-acyclic普通主系数A。设seed t对应hereditary cluster category的T=⊕T_i，且End_C(T_i)=C对全部i成立。ΣT_i刚性可达，index_T(ΣT_i)=−e_i，故相应normalized cluster variable I_i=x_i^-1F_i(ŷ),F_i(0)=1。2CY给Ext¹(T_i,ΣT_i)=D End(T_i)=C，BMRRT Th7.5使它们成为真正交换对。一条交换三角中项0，另一条中项是共同almost-complete cluster的刚性CM。

CKLP交换图系数无关把交换对提升到principal，得x_iI_i=c_0+c_1M_i，c_0,c_1冻结单项式。若M_i非初始CM，其proper Laurent monomial property使每个项都有一个负mutable指数，不含纯冻结项；若是非平凡初始CM也不含纯冻结项。因此F_i的完整常数1只能来自c_0，迫使c_0=1。M_i=1时两纯冻结项仍有一个为1。于是x_iI_i−1对任何实际强基都正，单位正算子判据适用。结合有限严格高度下降，完整head与theta tropical标签一致。

所有transjective summands满足该Schur条件，故覆盖可能含环的全transjective种子。非Schur情形不能套用：Keller–Plamondon–Qin2301.01059v2 Th4.8虽有CC(Z)CC(ΣZ)=CC(Y)+1，但Y可能非刚性，未证明CC(Y)在任意强基中正。此处不把AR公式当成一般单位条件的证明。原文：[BMRRT Th7.5](https://arxiv.org/pdf/math/0402054)、[CKLP](https://webusers.imj-prg.fr/~bernhard.keller/publ/clusterMonomials.pdf)。

# 任意强正基自动适配局部幂零导子

在无环斜可对称A_+=⊕_g Z[y]β_g上，取实际Z基Bscr={y^aβ_g:a≥0}。定义D_i=x_i∂/∂y_i，保持初始x不变。lower-bound presentation给D_i(x_j)=0，D_i(y_j)=δ_ij x_i，D_i(x_j′)=δ_ij M_i^+，所以D_i保持A_+并局部幂零。未把冻结逆元放进其幂零定义域。

整体opposite extended seed不改变实际交换式。y^aβ_g的opposite完整头为(H(g),a+r(g))，根列−[B;I]，其第i冻结行−e_i^T。最高y_i次数d=a_i+r_i(g)的部分恰是冻结第i个opposite mutable根后的部分。前述实际freezing与单位轨道给这些最高部分的全完整head族线性无关，并且乘x_i精确平移head。因此任何有限带符号组合的最高层不能消去，kerD_i^k由d<k的基元素张成，即goodness。

令g'=H^-1(H(g)+e_i)、a'=a+r(g)−r(g')−e_i。d>0时，导数的最高层为d x_i y_i^-1乘原最高层；单位轨道将它送到唯一head(g',a')。D_i属于实际A_+的有限展开与最高层独立迫使a'≥0，且
D_i(y^aβ_g)=d y^{a'}β_g'+(y_i次数≤d−2的余项)。
head平移单射，所以leading crystal arrow单射。这迁移了Tang2610.00603v1 Prop3.2的抽象机制；新增候选是任意实际强基自动满足其输入，不是重新主张该抽象判据。

从h=H(g)恢复canonical a,r的正序递推为a_i=h_i−Σ_(j<i)B_ij r_j、r_i=[−a_i]_+。故若r_i(g)>0，g'=H^-1(H(g)+e_i)满足r(g')≤r(g)、r_i(g')=r_i(g)−1。令g^(i,k)=H^-1(H(g)+ke_i)，0≤k≤r_i(g)，则最高除幂层为binom(r_i,k)y^{r(g)−r(g^(i,k))−ke_i}β_g^(i,k)。在k=r_i(g)时没有余项：
D_i^(r_i(g)) β_g = y^{r(g)−r(g^(i,r_i))−r_i e_i}β_g^(i,r_i)，
其中D_i^(k)=D_i^k/k!在此格上整。这是实际代数等式。

若实际theta修正β_g=θ_g+Σ_q t_gq y^qθ_h，h=g+Bq，满足q_i+r_i(h)=r_i(g)>0，则比较D_i的最高string层，得到t_gq=t_g'q'，其中h'=H^-1(H(h)+e_i)，q'=q+r(h)−r(h')−r(g)+r(g')。反向根次数s=r(g)−q−r(h)保持不变，而|r(g')|严格下降。重复直到第i最高次数为0，将最高坐标面的修正送到实际低秩基。最低面q_i=0此前已由freezing控制；所有i都q_i>0且q_i+r_i(h)<r_i(g)的严格内部修正仍未解决。

关键限制：good/perfect不等于D_i整体矩阵正。初始Laurent导数正不能替代C正。大x_i^N乘导数后的正性可由正切片得到，但不能取消这个正乘子。新代理继续攻交换对大幂／有限Taylor提取，而不把perfectness当作最小性闭合。Wolfram实际核576个秩2至32的valued矩阵、25614个晶体标签与高阶导数公式，无失败；1152个秩二theta导数展开非负仅作为诊断。

# 第十一次文献与路线复查

复查时间06:47 UTC；下一次07:07。实际数学推进：任意含环外块的一向形式冻结及最优非负阈值、任意标签的负支撑闭包降维、Schur含环种子自动首项、任意强基自动perfect导子与最高面系数搬运。两条主目标仍未全解：混合反馈循环的一般有限停机，以及严格内部theta换基系数的非负性。

| 文献／接口 | 本轮强审与结论 |
|---|---|
| GHKK1411.1394v2 AppC.1 | root及两代理核中心锥ConstructionC.1、C.4与C.6/C.7，支持新墙半空间归纳；作为能量证明的旧基础 |
| Tang2610.00201v3 | 原ordinary冻结提升已是Th9.6/Cor9.8旧结果，撤除新颖性标记；一向外块无环版已在Lem9.9，当前新机制删除无环条件 |
| CMMM2505.09585v2 Th4.12 | root重读明确finite combination前提；新能量不需要此先验，未混同两结论 |
| Tang2610.00603v1 Prop3.2 | root与代理完整核最高层独立＋冻结平移证明，通过；用于迁移到任意强基。全文最终biperfect结论未作为黑箱 |
| Fei2309.08326v4，2026-11-11 | 代理取得77页原PDF，强审§9.2–9.3、Th9.10及AppB.1；条件性系数图证明通过，严格string下降项允许自由参数，不能从perfectness推出正性。其余全篇未审核输入 |
| Fei–Weyman1707.04661v2，2026-10-28 | 新代理已取回原HTML/PDF；相关sink/source lattice-model扩展有rational balancing与localization前提，正在强审，暂不外推 |
| Tang2611.00190v2 Lusztig乘法正性 | root继续逐节读有限Demazure阶段、理想商、伴随比较与满评价；尚未把最终结论用于任意经典强基 |
| Mandel2023 VIT讲义 | 搜到unfreezing/global regular表述，讲义略去部分论文所需finite theta expansion背景；作为查新线索，不据摘要替代完整条件 |

## 有限冻结函数的上丛代数精确阈值

设完整主系数矩阵 B，S⊔T 为顶点分拆，F(z_S) 是有限的冻结 theta 多项式，f=x^g F(z_S)。令 d_k=min_{a∈Supp F}(g_k+B_{kS}a)，k∈T。对任意整数外部平移 N，有

$$x_T^N f\in\mathcal U(B)\quad\Longleftrightarrow\quad N_k+d_k\ge0\quad(k\in T).$$

这里允许任意耦合，所有冻结变量可逆。此为 BFZ 全秩主系数上界定理的有效推论，不将其基本机制标为新结论。

证明：主系数总互素，BFZ Cor1.7、Prop1.8、Cor1.9 给 U 等于初始及全部一次相邻 Laurent 环的交。S 方向的相邻图由冻结函数的正则性保证。k∈T 时，按 x_k 次数写成 Σ_r x_k^r A_r；除共同可逆冻结单项式外，A_r 与 y_k 无关。交换多项式 P_k=y_k A+B，其中 A、B 是其它变量的可逆单项式。代入 x_k=P_k/x_k′ 后，r≥0 无碍；r<0 要求 P_k^{-r} 整除 A_r，但前者 y_k-Laurent 宽度为 -r>0，后者宽度0，在整环上不可能。不同 r 的 x_k′ 次数不同，不能互相抵消。故恰为给出的 Newton 最小次数条件。

若另有 U=mid，则上述同一条件还等价于 x_T^N f=θ^B_{g+N}。证明先用实际有限 theta 展开和根偏序取极小参与首项，排除负根平移，再对每个 k∈T 使用有限参与者版本的赋值独立性，得到全部外根平移及 F 的外根次数为0。冻结 theta 独立性只留下 q=0、系数1。这里明确使用 U=mid 和有限 theta 展开；不调用已发现问题的无限形式一般赋值命题。

## 有统一根盒时的任意耦合冻结阈值

暂述斜对称情形。固定 g_S，假设独立证明了对全部 h_T≥0 有 Supp F_(g_S,h_T)⊂[0,D]。令 g⁰=(g_S,0)，α_i=[-g⁰_i]_+ +Σ_j[-B_ij]_+D_j，L_S=Σ_{i∈S}D_iα_i。若 h_k≥α_k+L_S 对所有 k∈T 成立，则完整 theta 等于冻结 theta。阈值无需再加1。SCC 有限载体定理在其已列明的 Jacobi/attractor 假设下提供 D=Cᵀ(g⁰)_-。

证明：对 0≤p≤D、0<v≤D 且 v_T≠0，有 (h+Bp)·v≥L_SΣ_{k∈T}v_k−L_S≥0。每条折线总根次数≤D，所以各前缀及弯折增量也在盒内。若出现外部弯折，其法向 v 在弯折点满足 v·γ=0；之后每段的 v·γ 导数均非正，不能到达所有坐标正的端点。故没有外部弯折，再用根理想商识别冻结函数。此证明使用已给出的统一盒；不把它改写成无条件一般有限性定理。

共同标量阈值的盒证书可以精确有限优化。对 0≤v≤D、Σ_Tv≥1 定义

$$R(v)=\frac{-g^0\cdot v+\sum_jD_j[-(B^Tv)_j]_+}{\sum_{k\in T}v_k}.$$

取 L=max(0,ceil(max R))，则 h_k≥L 对全部外坐标给出证书。分子凸、分母正仿射，所以最大值可在截断盒的顶点取得。顶点仅有满足 Σ_Tv≥1 的盒角，以及 S 为盒角、T=e_k 的点（D_k≥1）；候选数不超过 2^n+|T|2^|S|，与盒边长数值无关。这是该盒不等式的最优共同阈值，不声称为 theta 实际最优阈值。代理实际 Wolfram：200组秩2–6、12,113法向量的穷举最大值与顶点最大值相同；128组秩8–64、8,192前缀/法向对通过。

## 单向能量机制的独立计算复核

root 于2026-11-14实际调用 Wolfram，固定种子20261114，检查2,000组秩3、4、6、8、12、16、24、32、对称化因子1–5的矩阵，外块可任意含环。D_T B_TT 反对称项消去、段上能量导数非正全部通过；1,810组正根组合及新墙射线半空间保持全部通过，失败0。此计算核符号和组合闭包，不能代替任意次数散射构造的证明。

```wolfram
Module[{cases=0,bad=0,n,s,t,d,k,b,ns,nt,g,ds,cancel,derivative,roots,q,valid,coeff,root,ray,jointTests=0,trial},SeedRandom[20261114];Do[n=RandomChoice[{3,4,6,8,12,16,24,32}];s=Range[RandomInteger[{1,n-1}]];t=Complement[Range[n],s];d=RandomInteger[{1,5},n];k=RandomInteger[{-5,5},{n,n}];k=k-Transpose[k];k[[t,s]]=RandomInteger[{0,7},{Length[t],Length[s]}];k[[s,t]]=-Transpose[k[[t,s]]];b=k.DiagonalMatrix[d];ns=RandomInteger[{0,8},Length[s]];nt=RandomInteger[{0,8},Length[t]];g=RandomInteger[{0,8},Length[t]];ds=DiagonalMatrix[d[[t]]];cancel=nt.ds.b[[t,t]].nt;derivative=-nt.ds.g-nt.ds.b[[t,s]].ns-nt.ds.b[[t,t]].nt;If[cancel!=0||derivative>0,bad++];cases++;q=RandomInteger[{-8,8},n];roots=Table[RandomInteger[{0,5},n],{24}];valid=Select[roots,#[[t]].ds.q[[t]]<=0&];If[Length[valid]>0,coeff=RandomInteger[{1,5},Length[valid]];root=coeff.valid;ray=q-RandomInteger[{0,10}] b.root;If[root[[t]].ds.ray[[t]]>0,bad++];jointTests++],{trial,1,2000}];<|"valuedEnergyCases"->cases,"jointRayClosureCases"->jointTests,"failures"->bad,"allPass"->(bad==0)|>]
```

### 第十二次文献与路线复查

复查窗口07:07 UTC，实际汇总于本段保存时。新增检索涵盖 ordinary-cluster strong-basis minimality、theta 分块/相对散射、AR 交换对、perfect/polite 基与正评价。Davison–Mandel 的 scattering-atlas atomicity仍不替代 ordinary atlas 的本任务。严格内部修正与完整反馈有限性仍是正在正面攻克的两个缺口。

| 文献／路线 | 当前审核结果及使用边界 |
|---|---|
| Buan–Marsh–Reiten 0710.4335 | root取回原22页PDF；引言明确 End_C(T_i)=k 条件并非所有无环等价类种子都成立，不能把Schur种子定理无条件扩张 |
| BMRRT math/0402054；CKLP clusterMonomials | root取回原PDF，代理已核交换对、proper Laurent monomial及系数独立所需段落，继续逐段对照 |
| Kashiwara1204.1776 Remark3.5 | 代理核到任意参数 simples 与 canonical 的非负过渡，projective 对偶方向也属旧结果；撤销任意参数正分解的新颖性候选 |
| Tang2611.00190v2 §§6–8 | 代理核正次数中心特化、满评价与有限支撑同步选framing的承重步骤；该步逻辑通过，但无任意strong基的满评价源，不作黑箱替代 |
| Baumann On Mirković–Vilonen polytopes §§3.3–3.5 | 代理核 polite 条件要求所有方向的分次余乘法；Remark3.13指出biperfect不足。仅作为寻找横截分解算子的接口 |
| Lê–Thurston–Yu1908.05775 | 经典曲线乘法可精确读出Chebyshev修正系数；依赖已锚定多曲线支持，暂未推广到一般箭图 |
| 单向块逐切片递推 | 第二半精确递推出现rank2反向分支问题，撤回；T块统一支撑控制仍在研究相对theta代数机制，不据1600个cluster-variable检查宣布定理 |
| 先乘探针再取同一最高导子 | 局部幂零导子整环次数可加，严格低层修正始终被首次最高层消掉；停止该形式的重复尝试，转低阶正算子与横截乘法读系数 |

## 任意原强正基的正 Rees 多源点延拓

本节独立构造，不引用 Li–Pan/Li Fang 结论，也不假定任意 based ring 可范畴化。设原 B 无环、先取斜对称，已归一化实际强基 C={β_g} 满足 F_g∈N[z]、Supp F_g⊂[0,r(g)]、最高角系数1。若 β_gβ_h=Σ c y^qβ_k，则实际正 Laurent 展开逐项给出 q+r(k)≤r(g)+r(h)。

取 V∈Mat_(m×n)(N)，新增变量 t_a，定义 L_V(β_g)=t^{Vr(g)}β_g(x,y_i∏_a t_a^{-V_ai})。支撑盒保证没有负 t 次数，且

$$L_V(\beta_g)L_V(\beta_h)=\sum c_{g,h}^{q,k}\,y^q t^{V(r(g)+r(h)-q-r(k))}L_V(\beta_k).$$

所以这是实际非负乘法。旧交换式 x_i x_i′=M_i^-+y_iM_i^+ 变成 x_i X_i′=(∏_a t_a^{V_ai})M_i^-+y_iM_i^+。

再加新冻结系数 u_a 与相邻变量 s_a，令 t_as_a=1+u_ax^{v_a}。主矩阵为 [[0,−V],[Vᵀ,B]]，仍无环。令 T_k=∏_a t_a^[k_a]+ s_a^[-k_a]+。则 {T_k L_V(β_g):k∈Z^m,g∈Z^n} 是扩展多项式代数相对于 Z[y,u] 的实际 Hamel 基，并有非负乘法。这里“乘法正基”不宣称包含全部新增丛单项式。

基性证明：旧 BFZ 标准基 E_g 与 β_g 的变换首项1，非首项严格降低旧 |r|，反演逐元素有限。齐次化保留此下降。乘 T_k 后用 t_as_a=1+u_ax^{v_a} 归约；产生的旧正初始单项式 x^{v_a} 与旧标准单项式相乘时，只会消去成对 x_i、x_i′，不会增加旧 x_i′ 总数。故相对于扩展 BFZ 基仍是局部幂零的单位三角变换。乘法先用 Rees 正公式，再用正二项式关系和 x^{v_a} 对旧基的正乘法，均有限终止。

新增导子 D_a=t_a∂_(u_a) 满足 D_a(s_b)=δ_ab x^{v_a}、D_a(L_Vβ_g)=0。全部除幂有 D_a^(j)(s_a^b L_Vβ_g)=binom(b,j)s_a^(b−j)x^(jv_a)L_Vβ_g，展开非负。Taylor 流是 u_a↦u_a+εt_a、s_a↦s_a+εx^{v_a}，所以连同系数单项式的全部混合除幂均保正。令 u=0 后 t_as_a=1，保留所有(g,k)标签；再 t=1 正地映回原 β_g。

必须保留的限制：旧秩一加源点时 w=(t+y)/x，s=(1+ux)/t，新增 A₂ 丛变量 z=(t+y+uxy)/(tx)=sw−u。所构造基含 sw 和1，却不含 z。因此它不属于目标的“含全部 CM”强基类。最高除幂 s_a^bLβ_g↦x^{bv_a}Lβ_g 也可能分裂成多个标签；正导子、保标签特化都不能替代 Tang 满评价中的局部 End 商条件。

另一解冻接口把旧 y_i=uw_i 中的 u 变可变叶点，uu′=v+x_i。突变(u,i)给 x_i″=u′x_i′−w_iM_i^+=(v x_i′+M_i^-)/u。回代到旧冻结 u 可逆代数时这个单个变量确属旧 C 正锥。一般齐次化为 L_iβ_g=(u′)^r_i(g)β_g(y_i=w_iv/u′)=(u′)^r_i(g)exp(−w_iD_i/u′)β_g。同一 Rees 分支乘法正已证；旧 β 与 L_iβ 的混合乘法，以及全部新增 CM 回代正性未证。刚性限制到旧满子箭图只控制零根切片，不能替代内部关联 Grassmannian 的正分解。

### Rees 接口的计算与审核

代理实际 Wolfram 使用247×247精确整数矩阵，验证j=1,…,12的除幂 Kronecker 公式全部为True，矩阵秩228，最高除幂某列支撑19，交换公式余项{0,0,0}。第一次语法错误、第二次k=0未求值报错均不计为通过；以下为最终成功代码。计算只核一般正矩阵模型，不冒充某个完整丛基乘法表。

```wolfram
ClearAll[x,t,u,y,s,w,z];m=12;n=19;mat=Table[Boole[i==j]+2 Boole[i==j+1]+Boole[i==j+2],{i,n},{j,n}];der=KroneckerProduct[Table[If[j==i+1,j-1,0],{i,m+1},{j,m+1}],mat];checks=Table[With[{pow=MatrixPower[der,k]/Factorial[k],target=KroneckerProduct[Table[If[j==i+k,Binomial[j-1,k],0],{i,m+1},{j,m+1}],MatrixPower[mat,k]]},{k,TrueQ[pow==target],Min[Flatten[pow]],Max[Flatten[pow]]}],{k,1,m}];s=(1+u x)/t;w=(t+y)/x;z=(t+y+u x y)/(t x);<|"Dimension"->Dimensions[der],"Rank"->MatrixRank[der],"DividedPowerChecks"->checks,"ExchangeResiduals"->{Factor[s w-u-z],FullSimplify[t D[s,u]-x],FullSimplify[t D[w,u]]},"TopColumnSupport"->Count[MatrixPower[mat,12][[All,1]],_?(#>0&)]|>
```

## 第十三次文献与路线复查（07:25 UTC）

本轮实际新推进：正 Rees 多源点延拓及正除幂已完成；单向能量结合 ordinary 冻结提升与正 theta 乘法，得到任意含环 T 核的一般投影/逐系数上界候选，正在独立核式。主最小性仍未解决。后续继续正面攻任意强基的内部 Laurent 支撑及横截系数读取。

| 文献／路线 | 本轮记录 |
|---|---|
| Tang2610.00201v3 §9.1 | root重读原49页PDF的Th9.6、Cor9.8，经典有限参与者证明逐步可复核；ordinary提升是旧输入，不能标新 |
| CMMM2505.09585v2 Th4.12 | 再核有限组合前提；当前使用所有参与者Laurent有限的安全版本 |
| Fei–Weyman1707.04661v2 | 代理相关§§1、3–5及部分6–7已审：source extension有rational balancing与Uloc=A_e[x_e′]前提，非任意theta块拼接 |
| Mandel1503.06183v5 | 初始log多重覆盖系数交错，不能逐树使用正性；相对theta模的正乘法饱和部分成立，ambient渐近实现曾卡在propagator |
| Chan–Leung–Ma1902.05765 | 新代理核§3.3、Th3.20平方零模MC/theta接口；H_m沿完整单项式指数积分，普通Lie稳定不自动给propagator稳定，暂不调用未证部分 |
| LLRZ14_中文证明、LLRZ16_研究记录 | root读取原文具体有限jet与真实结构常数检测；量子bar次数帽不可v=1迁移。检测框架可借，但经典任意强基有限jet刚性仍需新证明 |
| Rupel–Stella2206.04778v2；QinJEMS | 新代理核全种子pointed允许支配区域自由修正，不能单凭pointed给generic Newton上界 |
| Newton凸包→generic Gr非空 | 撤回：3-Kronecker r=(2,2),q=(1,1)是0与r中点，却generic Gr_q空、Euler=-1。不得以未证支撑饱和导出Euler有限jet帽 |
| Weng2303.03466 | root取回27页原PDF，研究DT的F多项式与三角扩张poset；需核§4以划清投影定理优先权 |
| Fei2610.09868v2 | root已取回87页PDF/HTML，ramified realization、monodromy F与Newton order独立性待强审，不把摘要基定理当输入 |
| 搜索中误碰2610.12583 | 官方题为Global obstruction property，非Fei ramified稿；未使用，已改正正确ID2610.09868 |

## 单向含环块的精确支撑投影与逐系数上界

设 B 任意斜可对称，S⊔T，B_TS≥0。采用完整主系数，z_i=y_i∏_j x_j^{B_ji}，θ^B_g=x^gF^B_g(z)。固定 g_T，假设 θ^{B_TT}_{g_T} 属于核心的普通丛代数 A_T。则存在可从有限普通表达算出的 N∈N^S，使对每个 g_S 同时成立：

$$F^B_{(g_S,g_T)}(z_S,z_T)\le_{\rm coeff}F^{B_{SS}}_{g_S-N}(z_S)F^{B_{TT}}_{g_T}(z_T).$$

S 因子允许无限形式级数，两个内部块都可以任意含环。

证明第一步是已知 ordinary 提升：嵌入冻结 S 后的核心代数，iota(x_j)=x_j，iota(y_j)=y_j∏_{i∈S}x_i^{B_ij}。核心 theta 有有限丛变量表达，所以乘足够大 x_S^N 后进入 ambient A。由 A⊂mid 得到实际有限的有限 theta 展开。冻结函数的有限参与者赋值独立性识别唯一首标签，得到 θ^B_(N,gT)=x_S^N x_T^gT F^T_gT(z_T)。root已重读 Tang2610.00201v3 Th9.6/Cor9.8及CMMM有限前提并逐步核对；此提升机制是旧输入。

第二步使用本轮任意含环外块的能量定理：θ^B_(gS−N,0)=x_S^(gS−N)F^S_(gS−N)(z_S)。两式相乘，GHKK形式theta正乘法中首标签(gS,gT)系数1，其余项非负，便得到逐系数上界。在每个总根次数截断，求和均有限，故即使S因子无限也合法；没有预设ambient有限性。

再由根理想商冻结 S，F^B_(gS,gT)|_(zS=0)=F^T_gT，得到实际集合的精确等式：

$$\pi_T\operatorname{Supp}F^B_{(g_S,g_T)}=\operatorname{Supp}F^T_{g_T}.$$

因此所有T方向支撑函数、根变量赋值、f-vector都只由核心标签gT决定，即使ambient在S方向无限。投影Newton凸包也精确等于Newt F^T_gT。该结论不声称固定aT后的S切片等于某个核心theta；那个更强分离式已被证伪。

有效提升向量：给定 θ^T_gT=Σ_α c_α y_T^{q_α}∏_j X_j^{a_αj}，c_α可有符号，q_α可为整数，a_αj≥0。沿各X_j的同一核心突变词只突变T，记ambient变量为 Xhat_j=x_S^{h_j}iota(X_j)，其中h_j为ambient初始G向量的S部分。则

$$N_i=\max\left(0,\max_\alpha\left[\sum_j a_{\alpha j}(h_j)_i-(B_{ST}q_\alpha)_i\right]\right)$$

清除全部表达中的外部可变分母。N不声称最优；不能未经证明用仅保证U成员的Newton最小阈值替代。给出ordinary成员承诺及有限F时，枚举有限丛变量表达并精确比较可原则上找到该表达。

标签式有限性：若核心 F^S_(gS−N) 也有限，则ambient有限，且其根支撑包含于 Supp F^S_(gS−N)×Supp F^T_gT，每个系数不超过两核心对应系数之积。这给出有限的实际载体，并非观察若干截断稳定。

任意块DAG推论：取块 T₁,…,T_r，使 β>α 时 B_(Tβ,Tα)≥0。假设首块所有theta Laurent有限，其余每块所有theta属于各自普通丛代数；则整体所有标签Laurent有限。由最后块递归计算N、减去前块标签并调用上一结论。特别地，每个SCC核心所有theta属于ordinary A时，任意凝聚DAG拼接都成立。无需Jacobi有限或attractor输入，也不使用ambient U=mid。本证明未推出ambient theta全部属于ordinary A。

有限展开算法：递归得到有限多项式P_α及逐系数上界 F^B_g≤∏P_α。取其根盒0≤a≤D和H=ΣD_i，只构造总根次数≤H的散射图与theta系数。弯折次数非负，所有可能最终根次数均在盒内，故截断足够，盒外零由定理保证。输入是各核心的可计算有限theta及ordinary表达；并未解决任意循环反馈块本身的有限性判定。

### 提升符号的精确计算

代理实际Wolfram检查120组秩3、5、8、12、16、24、D_i∈{1,2,3}、内部任意含环的矩阵；每组8次T内突变，共960步。ambient G_TT=coreG、G_TS=0、G_SS=I全部通过，外G_ST无负项；120次G=D⁻¹C⁻ᵀD对照也全部通过，失败0。以下代码保留以便复算。

```wolfram
Module[{mut,gm,checks=0,bad=0,duals=0,negative=0,n,ns,s,t,nt,d,k,b,em,ec,g,gc,kk,loc,c,gd,trial,step,maxRank=0},mut[a_,j_]:=Table[If[i==j||l==j,-a[[i,l]],a[[i,l]]+Max[0,a[[i,j]]]Max[0,a[[j,l]]]-Max[0,-a[[i,j]]]Max[0,-a[[j,l]]]],{i,Length[a]},{l,Length[a[[1]]]}];gm[gg_,a_,j_]:=Module[{nn=Length[gg],sg,col},sg=If[Min[a[[nn+1;;2nn,j]]]>=0,1,-1];col=-gg[[All,j]]+Sum[Max[0,-sg a[[i,j]]]gg[[All,i]],{i,nn}];Transpose[ReplacePart[Transpose[gg],j->col]]];SeedRandom[2026111407];Do[n=RandomChoice[{3,5,8,12,16,24}];maxRank=Max[maxRank,n];ns=RandomInteger[{1,n-1}];s=Range[ns];t=Range[ns+1,n];nt=Length[t];d=RandomInteger[{1,3},n];k=RandomInteger[{-1,1},{n,n}];k=k-Transpose[k];k[[t,s]]=RandomInteger[{0,2},{nt,ns}];k[[s,t]]=-Transpose[k[[t,s]]];b=k.DiagonalMatrix[d];em=Join[b,IdentityMatrix[n]];ec=Join[b[[t,t]],IdentityMatrix[nt]];g=IdentityMatrix[n];gc=IdentityMatrix[nt];Do[loc=RandomInteger[{1,nt}];kk=t[[loc]];g=gm[g,em,kk];gc=gm[gc,ec,loc];em=mut[em,kk];ec=mut[ec,loc];If[g[[t,t]]!=gc||em[[t,t]]!=ec[[1;;nt]]||g[[t,s]]!=ConstantArray[0,{nt,ns}]||g[[s,s]]!=IdentityMatrix[ns],bad++];If[Min[Flatten[g[[s,t]]]]<0,negative++];checks++,{step,1,8}];c=em[[n+1;;2n]];gd=DiagonalMatrix[1/d].Transpose[Inverse[c]].DiagonalMatrix[d];If[g!=gd,bad++];duals++,{trial,1,120}];<|"Matrices"->120,"MutationChecks"->checks,"WeightedDualityChecks"->duals,"MaximumRank"->maxRank,"BlockFailures"->bad,"NegativeExternalGBlocks"->negative|>]
```

### 尚未闭合的真正扩展

若核心theta仅Laurent有限却不属于ordinary A，上述有限提升尚未证明；不能将U=mid作为默认。已有安全入口是ambient U=mid另获证明后使用精确U阈值。新代理正查CMMM chiral-dual theta reciprocity与一侧凸性：对dual−B可用能量降到T，但CMMM reciprocity的bothfinite条件不能循环用于证明另一侧有限。相对MC模仍存在propagator沿完整单项式方向积分的不变性缺口。

### 与既有三角扩张结果的比较

root已读 Weng2303.03466 §4：Th4.5引CL19给两块reddening词拼接；Prop4.6/Cor4.7给DT特定标签的F多项式代换与poset附接。这里任意指定ordinary核心theta、任意gS的精确支撑投影和逐系数上界，超出该已读DT陈述。Tang旧9.9/9.10要求外部无环；Fei–Weyman相关章节是带balancing/localization假设的generic-character扩张。当前检索未找到相同一般表述，不作绝对首创断言。

# 第十四次文献与路线复查（07:45 UTC）

本轮主线有实质推进：一向分块的混合墙半空间给出负室到正室的两段路径，正在闭合任意经典可对称化矩阵的精确 theta 切片公式。ordinary 核心归属的旧限制有望整体去除。两名独立子代理和 root 已分别检查负室单项式、主系数变换和基本传输论证；完整定理与合法性证明另列于后续节。本轮没有将此替代任意强正基的最小性目标，后者仍在推进。

查新：CMMM 2505.09585v2 已由 root 逐段重读 §4.4 Lemma4.14、§5.3 Lemma5.15–5.16、§5.4 Lemma5.17、Theorem5.19、Proposition5.20、Corollary5.21及§5.6.2。单个测试 theta 全域 Laurent 有限时，文中无限值区域障碍消失，得到单有限测试互反的候选推论；不使用此前已经发现范围有问题的一般Theorem3.14。主系数 P=[B;I],Q=[I;0] 饱和，DB斜对称时 Ω=[[0,D],[-D,DB]]；注意原文的D_C=D^{-1}，不能混同。

新文献：Fei 2610.09868v2 的 §7.3 Th7.11 顶点商唯一性及 §7.4 Th7.13 条件性 Newton 独立论证已分段核查。投影秩格上的唯一顶点商由交、和的模格性推出；Galois稳定后下降、顶点系数为1的局部证明通过。Th7.13另依赖未完整审核的通用呈示域嵌入 Proposition6.12，因此只记录条件性局部通过，不采用整篇基或乘法正性结论。其非顶点系数、甚至边界系数可随order改变，不能据Newton相同推系数相同。原文明确未假定其他系数正性。

发现 Fei 2607.12458 已于2026-11-03更新为v3，题名改为 Flag Varieties of General Quiver Representations: Characteristic Classes and Semi-Invariants，29页。旧v1/v2题名为 Euler Characteristics of Generic Quiver Grassmannians: Semi-Invariants and Localization。当前只核到版本元数据，旧版官方全文读取受限；未使用其结论，已交专门子代理继续找最新primary正文。Library搜索未取得该原文。

相近工作继续比较：Weng2303.03466 §4 的 DT F-polynomial 代换、CL19 reddening词拼接，以及 Tang2610.00201v3 §9 的单向无环扩张；新的形式级数切片若通过，其证明必须明确指出哪些属于旧DT因子化、哪些适用于无reddening且核心theta无限的新范围。尚不作绝对首创断言。

## 强正乘法的两个新接口

同首项 CM 乘积帽：在已证明的初始 full pointedness 下，任意 cluster-monomial 乘积 P 若经冻结单位归一化后的 full 首项为 g、首项系数1，则其实际强基正展开必包含 β_g，系数1。所有参与者的正 Laurent 支撑都在 P 的根锥内；principal 矩阵满列秩排除其他首项经非负根位移返回首项。因此 F_{β_g}≤F_P 逐系数成立，Newt F_{β_g} 包含于所有这类 Newt F_P 的交。给定 CM_j 首项 g_j、权重成本 c_j(δ)=max δ·Supp F_j，可计算上界 inf{Σm_jc_j(δ):m_j∈N,Σm_jg_j=g}。这比单个BFZ盒强，但尚未证明交帽等于generic/theta Newton多面体。

逐标签存在性：若种子t injective-reachable，取负基本头的可达I_i(t)，则 L_h=X(t)^{h_+}I(t)^{h_-} 是强基正元素，t首项为h且系数1。其正C展开中恰有一个参与的冻结平移基元素贡献这个首项，且全部支撑在h的根锥内，所以对每个h至少存在一个t-pointed实际C元素。不能用无限基计数把它升级为穷尽、全种子唯一性或统一热带标签兼容；这一步仍缺有限下降机制。

固定BFZ族换种子后覆盖全格的路线明确失败：B=[[0,-3],[3,0]], t=μ₁t₀，在目标种子U=x₁′,V=x₂中，初始四生成元的mutable首项为(-1,3),(0,1),(1,0),(-3,8)，全部第二坐标非负，所以它们的任意乘积不能覆盖g₂<0。对应互补矩阵[[1,-3],[-3,1]]行列式−8。Wolfram另对100个秩3–6、8步词的正确邻接BFZ矩阵检验，91个非P；随机非P计数本身不证明不满射，严格结论来自上述半空间。此前(T,ΣT)的93/100是另一计算，不能混记。

Newton到Euler的错误推理已纠正：3-Kronecker一般维数r=(2,2)，q=(1,1)位于0与r的线段，故属于Newton凸包；但〈q,r−q〉=−1，incidence维数11<表示空间12，所以generic Gr_q为空。不能把Newton包含、格点或角点自动替成实际Grassmannian非空，更不能隐用未证的支撑饱和。

本轮核查的相关既有来源：Qin JEMS §5.1 保留全种子兼容的额外条件及自由修正参数；Rupel–Stella2206.04778v2 Theorem1.6 的最大pointed支撑通常大于greedy支撑，故全种子pointed+普遍Laurent正不等于强正乘法。Fei1911.10513v6 Lemma6.3 排除的是正支撑值 imaginary facet 法向，不能排除经过原点的零支撑值imaginary面。下一轮重点：完成一般一向切片及其多面体递归；继续以实际强乘法逼出Euler边缘消失或新的横截系数检测。

# 一般单向拼接：完整形式 Laurent 公式与精确多面体递归

本节是本轮新闭合的主结果。root、finite_core_nonordinary_lift 与 one_finite_reciprocity_adversary 分别核对证明。只处理经典丛代数；不假设核心无环、reddening、Jacobi有限、ordinary归属或 U=mid。负基本标签的代换形式在Weng的reddening情形已有先例；本节明确扩至任意形式theta、任意末端标签、可对称化及离散支撑。先前声称任意gS都精确切片的路线仍然错误，本节精确等式严格保留gS≤0。

## 设定与公式

设 DB 斜对称，D 为正整数对角阵，I=S⊔T，B_TS≥0，因此B_ST≤0。用全主系数，z_i=y_i∏_j x_j^{B_ji}，θ_g^B=x^gF_g^B(z)，允许F为N[[z]]中的无限形式级数。写 F^T_gT=Σ_a c^T_gT(a)zT^a，H_i=F^{B_SS}_{−e_i}(zS)。

若gS≤0，则完整形式等式为
$$
F^B_{(g_S,g_T)}
=\sum_{a\in\mathbb N^T}c^T_{g_T}(a)\,z_T^a
F^{B_{SS}}_{g_S+B_{ST}a}(z_S).
$$
等价地，
$$
F^B_{(g_S,g_T)}
=\left(\prod_{i\in S}H_i^{-g_i}\right)
F^{B_{TT}}_{g_T}
\left(z_j\prod_{i\in S}H_i^{-B_{ij}}\right)_{j\in T}.
$$
所有H指数均为非负整数。逐系数为
$$
c^B_g(a_S,a_T)
=c^T_{g_T}(a_T)c^S_{g_S+B_{ST}a_T}(a_S).
$$

## 墙半空间与纯核心传输

对每个grade n墙，未扰动中央完成可选得 nT^T DT qT≤0；墙正交又给 nS^T DS qS≥0。初墙成立；新joint上的grade是旧grade的非负和，性质保持。沿outgoing ray q−sBn，
$$
\frac{d}{ds}n_T^TD_T(q_T-s(Bn)_T)
=-n_T^TD_TB_{TS}n_S\le0,
$$
内部斜对称项为0。因此在qS全负区域只能穿纯T墙，在qT全正区域只能穿纯S墙。对正图可逐阶使用essential support：若一堵正墙违反半空间，则对应旧代表在该generic点没有同根射线墙，而正墙局部作用不能抵消，违反等价。无需假设平移扰动图本身满足中央不等式。

根次数非负，mixed括号不能回到pure grade；纯T/S图就是相应核心图的柱状拉回。纯T的系数嵌入为 y_j^T↦y_j∏_{i∈S}x_i^{B_ij}。joint-minus-ray完成保持柱状性，也可用根Lie理想商与完成唯一性表述。

选择 C−→{qS<0,qT>0}→C+ 的generic路径，第一段固定S全负，第二段固定T全正。于是完整形式传输严格分解
$$
\Phi_B=\Phi_S\circ\Phi_T .
$$
这里负室不需属于原ordinary cluster atlas，也不需reddening词。每一有限根次数截断有有限墙数据，路径可逐阶generic选择。

## 负室单项式及负半锥乘法

P_B=[B;I], Q=[I;0]，J=diag(−I,I) 给整数seed同构 (P_B,−Q)→(P_{−B},Q)：JP_B=P_{−B}, J^TQ=−Q，并保持outgoing方向J(−P_Bn)=−P_{−B}n。改变Q符号同时改变法向和穿墙方向符号，因此初图及其唯一完成的无向墙、墙作用均相同。故 θ^B_{h,−} 反射到 −B 正室的 θ_{−h,+}；h≤0时后者是初始CM，所以 θ^B_{h,−}=x^h。冻结头任意。此为CMMM2505.09585v2 Lemma4.14的直接情形，也可由上述初图论证独立重建。

传输是代数同态，因此对任何核心A和h≤0，
$$
F^A_h=\prod_i(F^A_{-e_i})^{-h_i}.
$$
此结论仅在负半锥使用，不把任意标签的theta幂误认成同标签倍数。

## 任意末端标签的证明

当gS≤0时，转到−B：外S头为−gS≥0，且(−B)_ST≥0。一向energy freezing给反射后的theta无S根次数，反射回来得到
$$
\theta^B_{(g_S,g_T),-}
=x_S^{g_S}\iota_T(\theta^{B_{TT}}_{g_T,-}).
$$
energy证明：反射后累计根次数a，E=aS^TDSγS，bend时增量≤0；线段上 E′=−aS^TDS(−gS)−aS^TDS(−B)_STaT≤0；初值0，正室终点在aS≠0时却严格正，矛盾。

先ΦT送到核心正室，a项为 c_a yT^a xT^{gT+B_TT a}xS^{gS+B_STa}。其中S头≤0，ΦS把它送为相应S核心theta。提出x^g即得切片公式，再用负半锥乘法得到正代换。固定最终(aS,aT)时仅涉及一个T切片及一个S系数，因此无限形式级数合法，不需解析收敛或失控的无限求和换序。gS=0也允许。

## 任意标签的上界与完整离散投影

令uS=min(gS,0)。正乘积 xS^{gS−uS}θ_(uS,gT) 包含θ_(gS,gT)，头系数1。因此
$$
F^B_g\le_{\rm coeff}
\left(\prod_{i\in S}H_i^{-u_i}\right)
F^T_{g_T}\left(z_j\prod_{i\in S}H_i^{-B_{ij}}\right).
$$
右边的T根支撑恰为Supp F^T_gT，因为每个H常数项1。另一方面，令zS=0的根面总是核心T theta。故无任何有限性前提都有
$$
\pi_T\operatorname{Supp}F^B_g
=\operatorname{Supp}F^T_{g_T}.
$$
这是实际离散支撑的等式，不只凸包。核心T无限时，每个gS的ambient theta也无限；核心T有限时，其T方向次数界与gS及连接箭头大小无关。

## 有限性判据与强连通分量

gS≤0时，令 α_i(a)=−g_i−Σ_{j∈T}B_ij a_j≥0。精确判据：F_g^B有限，当且仅当F^T_gT有限，且每个在某个实际a∈SuppF^T_gT上有α_i(a)>0的H_i有限。必要性用正系数与常数项1，充分性用有限正代换。

若S块所有theta有限，则
$$
\Theta_B^{\rm fin}=\mathbb Z^S\times\Theta_T^{\rm fin}.
$$
特别地，整图所有theta有限，当且仅当两块各自所有theta有限。必要性由根面冻结，充分性由上界。

令箭头i→j表示B_ji>0，按凝聚图拓扑顺序分块；块间满足后块行、前块列非负。递归得到：整图全部theta有限，当且仅当每个强连通分量全部theta有限。此前负支撑能量若使用B_ij>0的图方向，则应称本约定下的祖先闭包；强连通分量本身不受整体反向影响。

## 基本证书与实际停止界

任意A所有theta有限等价于全部负基本H_i=F^A_-ei有限；实际上一个严格负标签有限已足够，因为乘初始CM可得到每个负基本label。一般正性给
$$
F^A_g\le_{\rm coeff}\prod_iH_i^{[-g_i]_+}.
$$
此直接正性推论不作新颖性核心。

拼接时，i∈S有H_i^B=H_i^S；j∈T有
$$
H_j^B=H_j^T\left(z_k\prod_{i\in S}(H_i^S)^{-B_{ik}}\right).
$$
因此从核心有限H证书得到全图H的有限算术电路。对g以上式算出各根次数上界D_j；散射完成只需到总根次数ΣD_j，即能算出整个F_g，越界系数由正上界保证为0。不能把“有限阶没有新增项”本身当停止证书；停止来自已证明的全局次数盒。

## 精确 Newton 纤维与顶点

假设实际参与的H_i和F^T_gT有限，gS≤0。记P_i=NewtH_i，P_T=NewtF^T_gT。则
$$
P_B=\{(v,a):a\in P_T,\quad v\in\sum_{i\in S}\alpha_i(a)P_i\}.
$$
α_i仿射且非负，故纤维Minkowski和对底点仿射。若a=Σλ_vv为核心顶点分解，则对应纤维恰为Σλ_v(Σ_iα_i(v)P_i)，证明整个集合凸，并等于核心顶点纤维的凸包。于是完整顶点集合是
$$
\operatorname{Vert}P_B=
\bigcup_{a\in\operatorname{Vert}P_T}
\{(v,a):v\in\operatorname{Vert}(\sum_i\alpha_i(a)P_i)\}.
$$
不需枚举P_T的全部支撑格点。

支持函数的可执行形式为
$$
h_{P_B}(\xi_S,\xi_T)=
\sum_i(-g_i)h_{P_i}(\xi_S)
+h_{P_T}\left(\xi_{T,j}-\sum_iB_{ij}h_{P_i}(\xi_S)\right)_{j\in T}.
$$
任意gS用uS=min(gS,0)得到明确外多面体，同时T投影仍精确。

顶点(a,v)对应共同暴露方向的核心顶点v_i，v=Σ_iα_i(a)v_i。其系数严格为
$$
[z_S^vz_T^a]F_g^B
=[z_T^a]F^T_{g_T}\prod_i([z_S^{v_i}]H_i)^{\alpha_i(a)}.
$$
因此核心相关顶点系数若全为1，拼接后这些theta的顶点系数也全为1。本节不假定任意核心已知单值顶点。

整数支撑的正确接口：每个实际整数a的S离散支撑恰为Σ_i α_i(a)SuppH_i。核心单独无格点洞，并不保证这些混合Minkowski和具有整数分解性质。若F_T支撑饱和，且所有相关混合和满足 Σ_iα_i(a)SuppH_i=(Σ_iα_i(a)P_i)∩Z^S，则拼接支撑饱和。这里只给准确充分条件，未使用Li–Pan/LiFang结论，也未把一般Newton饱和当事实。

## 有限正向shift（额外有限性条件）

若F^T_h有限，且gS=0代换实际用到的H_i均有限，则G=F^B_(0,h)有限。设其根支撑盒0≤a≤K，可由上述Newton支持函数直接算出。令g0=(0,h)，
$$
C=\sum_j d_jK_j\left(|g^0_j|+\sum_k|B_{jk}|K_k\right),\quad
L=1+\left\lfloor C/\min_{i\in S}d_i\right\rfloor,\quad N=L\mathbf1_S.
$$
正CM乘法给F_(N,h)≤G，故所有broken line及前缀次数≤K。若在nS≠0墙上bend，则primitive n≤K；对之后任意前缀a′≤K有〈g0+N+Ba′,Dn〉>0。其后每段速度配对严格负，从该墙出发不能再到正室，矛盾。所以无S bend，
$$
\theta^B_{(N,h)}=x_S^Nx_T^hF^T_h(z_T).
$$
这是已有有限支撑shift机制的显式多坐标实现，需比较Qin2407.03186 Proposition6.19，不能把shift本身报新。若S相关H允许无限，本节尚未证明任何有限coretheta都存在此lift；但精确T投影及形式上界仍无条件成立。

## 单有限测试互反：独立可用的推论

CMMM 5.17、5.20、5.21的一个直接推论：测试θ_b,+本身有限时，对任意整m，
$$
\operatorname{val}_{\Omega m}\theta_{b,+}
=\operatorname{val}_{\Omega^Tb}\theta_{m,-}\in\mathbb R.
$$
证明不循环用both-finite定理。φ(p)=θ_b,p^trop(Ωp)=θ_b,+^trop(Ωp)全域有限有限PL。取p∈m+C+足够近m及同时最小、Ω^T-taut测试线，末指数b+；A=〈m,Ω^Tb+〉且D_pφ=Ω^Tb+。每条竞争Γ:(m,p)由5.21满足A≤〈mΓ,Ω^Tb+〉，直线给反向，故中间估值已经有限且等A。再沿测试taut线用5.15、5.16有限阶统一性、5.17负版传至C−，得结论。有理方向乘公共分母转为整标签后除回即可。

主系数Ω=[[0,D],[-D,DB]]，CMMM文内D_C=D^{-1}，额外形式参数记t。项t^a x^{g+Ba}y^a中principal y^a已区分根次数，所以t=1不隐去无限次数。此推论是旧引理的直接应用；本节的拼接主定理无需它。

## 相关工作与原创性边界

Weng2303.03466v1 Definition3.11、Theorem4.5、Proposition4.6及Corollary4.7已完整实读：两核心reddening词下的DT负基本F代换与本节同形，不报新；其一般形式扩展、任意gT、无reddening、可对称化、离散投影与SCC全有限等价，是本轮需独立陈述的范围。Tang2610.00201v3 Lemma9.9/Theorem9.10要求外部无环，Proposition12.2已有Markov+单点实例，不重报。查新暂未找到与本节全部范围相同的原文陈述，不作绝对首创断言。主来源：https://arxiv.org/pdf/2303.03466；https://arxiv.org/html/2505.09585v2；https://hexagonmath.org/pdf/2610.00201v3 。

## 独立计算检查

root实际用principal F-mutation验证：120组两侧都含有向A3三角形的valued单向拼接，rank6–18，每个三角形D取1/2/3，连接箭头取任意相容倍数。两个素数域共240次整图计算，与核心代换独立比对；7520 mutation步、2820个标量等式、0失败、0分母跳过。这里整图F由mutation递推得到，不是把右边原样重新代入自验。有限域检查只检验公式及实现，不替代形式证明。另有agent的500个rank2–24矩阵、4000项Ω/J坐标恒等式全部通过；60组随机正多项式实际Expand的2400个Newton方向比较全部通过（项数3–268），该随机多项式测试不冒充theta。

```wolfram
Module[
{mut,run,tri,makeCore,primes={1000000007,1000000009},trials=120,
validated=0,skipped=0,failed={},checks=0,steps=0,nS,nT,n,bS,bT,dS,dT,ds,
cross,b,ws,wt,w,z,p,hs,ht,ha,zz,expected,trial,sr,tr,ar,r,k},
mut[a_,kk_]:=Module[{v=a[[All,kk]],w0=a[[kk,All]],out},
out=a+Outer[Times,Map[Max[#,0]&,v],Map[Max[#,0]&,w0]]
-Outer[Times,Map[Max[-#,0]&,v],Map[Max[-#,0]&,w0]];
out[[All,kk]]=-v;out[[kk,All]]=-w0;out];
run[bb_,yy_,ww_,pp_]:=Module[{nn=Length[bb],em,ff,aa,cc,term1,term2,kk,out,labels},
em=Join[bb,IdentityMatrix[nn]];ff=ConstantArray[1,nn];
Do[
If[ff[[kk]]==0,Return[$Failed]];
aa=em[[1;;nn,kk]];cc=em[[nn+1;;2nn,kk]];
term1=Mod[Times@@MapThread[PowerMod[#1,Max[0,#2],pp]&,{yy,cc}]*
Times@@MapThread[PowerMod[#1,Max[0,#2],pp]&,{ff,aa}],pp];
term2=Mod[Times@@MapThread[PowerMod[#1,Max[0,-#2],pp]&,{yy,cc}]*
Times@@MapThread[PowerMod[#1,Max[0,-#2],pp]&,{ff,aa}],pp];
ff[[kk]]=Mod[(term1+term2)PowerMod[ff[[kk]],-1,pp],pp];
em=mut[em,kk];steps++,{kk,ww}];
cc=em[[nn+1;;2nn]];
If[Sort[Flatten[cc]]!=Sort[Flatten[-IdentityMatrix[nn]]]||
Total[cc]!=ConstantArray[-1,nn]||Total[Transpose[cc]]!=ConstantArray[-1,nn],Return[{"NotRed",cc}]];
out=ConstantArray[0,nn];
Do[labels=First@FirstPosition[cc[[All,kk]],-1];out[[labels]]=ff[[kk]],{kk,nn}];
out];
tri={{0,-1,1},{1,0,-1},{-1,1,0}};
makeCore[count_]:=Module[{bb=ConstantArray[0,{3count,3count}],dd={},word={}},
Do[bb[[3j-2;;3j,3j-2;;3j]]=tri;
dd=Join[dd,ConstantArray[RandomChoice[{1,2,3}],3]];
word=Join[word,3(j-1)+{1,2,3,1}],{j,count}];{bb,dd,word}];
SeedRandom[202611140751];
Do[
sr=makeCore[RandomChoice[{1,2,3}]];tr=makeCore[RandomChoice[{1,2,3}]];
{bS,dS,ws}=sr;{bT,dT,wt}=tr;nS=Length[bS];nT=Length[bT];n=nS+nT;
b=ArrayFlatten[{{bS,ConstantArray[0,{nS,nT}]},{ConstantArray[0,{nT,nS}],bT}}];
Do[k=RandomChoice[{0,0,0,1,2}];
b[[i,nS+j]]=-k dT[[j]]/GCD[dS[[i]],dT[[j]]];
b[[nS+j,i]]=k dS[[i]]/GCD[dS[[i]],dT[[j]]],{i,nS},{j,nT}];
ds=DiagonalMatrix[Join[dS,dT]];
If[ds.b+Transpose[ds.b]!=ConstantArray[0,{n,n}],AppendTo[failed,{"Symmetrizer",trial}]];
w=Join[ws,nS+wt];z=RandomInteger[{2,101},n];
Do[
hs=run[bS,Take[z,nS],ws,p];
ha=run[b,z,w,p];
If[hs===$Failed||ha===$Failed,skipped++;Continue[]];
If[!VectorQ[hs,IntegerQ]||!VectorQ[ha,IntegerQ],AppendTo[failed,{"Red",trial,p,hs,ha}];Continue[]];
zz=Table[Mod[z[[nS+j]]Times@@Table[PowerMod[hs[[i]],-b[[i,nS+j]],p],{i,nS}],p],{j,nT}];
ht=run[bT,zz,wt,p];
If[ht===$Failed,skipped++;Continue[]];
If[!VectorQ[ht,IntegerQ],AppendTo[failed,{"CoreRed",trial,p,ht}];Continue[]];
expected=Join[hs,ht];checks+=n;validated++;
If[ha!=expected,AppendTo[failed,{"Formula",trial,p,b,z,ha,expected}]],
{p,primes}],{trial,trials}];
<|"RandomOneWayCouplings"->trials,"Ranks"->{6,9,12,15,18},
"ExactPrimeFieldEvaluations"->validated,"ScalarEqualities"->checks,
"MutationSteps"->steps,"ZeroDenominatorSkips"->skipped,
"FailureCount"->Length[failed],"FirstFailure"->Take[failed,UpTo[1]]|>
]
```

计算原回执：RandomOneWayCouplings=120；ExactPrimeFieldEvaluations=240；ScalarEqualities=2820；MutationSteps=7520；ZeroDenominatorSkips=0；FailureCount=0。

# 第十五次文献与路线复查（08:05 UTC）

一般单向拼接已完成三方独立证明审查，完整形式级数、逐系数式、离散投影、SCC全有限等价与Newton纤维已保存。root独立mutation计算也已通过。接下来不把剩余时间转为包装：新代理分别攻实际强基的rank1 source/sink模分解、正算子/不变锥检测，以及一般多面体纤维的整数分解性质。

新颖性复查：Weng的负基本DT代换形状归还旧结果；MQ与Zhou的曲面主系数有限性归还旧结果。扩展应用现在有任意高秩的非ordinary、无reddening核心，证明见下节。继续检索GHKK、Qin、Fei及几何表示论；未发现与无reddening完整形式切片及全离散投影同范围的已读陈述，仍不作绝对首创保证。

2026强审核补充：Fei2607.12458v3官方HTML/PDF已取得。root及子代理读§1–2 incidence/regular-zero-locus和Cor2.3，局部证明通过；§7.5是带符号半不变量维数表达，不能建立正coaction，§8.2的负Euler族也禁止默加generic character正性。Goertzen–Williamson2604.18894v1《Kazhdan–Lusztig basis and Optimization》已开启强审：§4给特定Specht模的最大不变锥机制，§6的普遍canonical极大性主要是猜想/有限实验；其unique max/min cone字面需固定朝向，因为C与−C同时不变，已交代理核原引用。没有把这个新文献当作cluster定理。

最小性路线纠偏：source突变虽将g_i变为−g_i，却同时把source变sink，不能由负S代换直接声称覆盖全部标签。D_i 在多项式归一化 A⁺ 上局部幂零，并已证任意实际强基对它 good/perfect 及最高除幂层单项；D_i 对该基整体展开非负仍未证明。此前阶段摘要将 perfectness 误写成算子正性，08:16 UTC 经两代理交叉核查撤回。冻结单位逆幂的导数还会带负号，因此不能把两种子的导子未经识别拼成同一个正 SL2 作用。共同finite jet单位确能在structure-constant detector中约掉，但无缩放的整数jet收敛实际等价于最终相等；仅改成“比值趋1”不降低核心难度。以上不作为已解决主目标。

## 非ordinary、无reddening的广泛有限核心

MQ2301.11101v3 §5.8明确 Θ^mid=ρ(Θ^{prin,mid})，而principal有限标签对全部冻结方向平移不变。Theorem5.24及AppendixB给任意可三角剖分曲面Θ^mid=M，所以这是原始principal全标签有限，不只是y=1后有限。root已重读定义、5.24和B3–B4。

闭单穿孔亏格g≥1曲面有n=6g−3个可变顶点。以degx_i=1,degy_i=0分次，闭曲面列和0使degz_i=0；负基本theta的度数为−1。普通可达弧变量均有度数1（曲面交换/端点分次），所以ordinary代数只含非负分次，θ_-ei不属于ordinary。该族没有reddening；也可由其可达变量正分次与reddening终端负基本头矛盾看出。任意多个此类循环核心作DAG耦合，确实超出ordinary lifting、两块reddening和外部无环三个旧范围。

曲面有限证书可以避开中心因子的精确求值。选连通二重无分支闭曲面覆盖；覆盖有两个穿孔，存在reddening。枚举mutation词直至找到对应负基本变量，计算有限F并按覆盖轨道合并根变量，得G_i。MQ AppendixB式(160)给
$$
G_i=H_iP_H,\qquad P_H\in1+s\mathbb N[[s]],
$$
因此 H_i≤coeff G_i。亏格≥2中心修正为1；环面不需要采用P_H=(1+s)^2的精确值。MQ拓扑覆盖folding与Zhou四穿孔球箭图的更强folding条件不同，不能混用。

Zhou1901.04166v3 Theorem3.7的强folding有限性已审；§5.1给12步词[1,3,2,4,6,5,1,6,4,3,2,5]及原始Markov负基本H：1+w_i+2w_iw_{i+2}+w_iw_{i+2}²+2w_iw_{i+1}w_{i+2}²+w_iw_{i+1}²w_{i+2}²+w_i²w_{i+1}²w_{i+2}²，系数和9。这是Weng Example1.3的旧输入。它有真实格点洞，例如(1,1,1)在0与(2,2,2)中间却无项；不能把theta的Newton凸包当全部支撑。

## 正证书的DAG传播与矩阵停止界

一般地只需每个核心负基本H_j有已证明的有限正上界G_j，尤其G_j=H_jR_j、R_j∈1+zN[[z]]即足够。按块I₁,…,I_k使后块行/前块列非负，设E_ij=−B_ij≥0（i在前块、j在后块），其他位置0。递归
$$
\mathcal G_j=
G^{(\beta)}_j\left(
z_\ell\prod_{i\in I_1\cup\cdots\cup I_{\beta-1}}\mathcal G_i^{E_{i\ell}}
\right)_{\ell\in I_\beta}.
$$
正代换单调性给ambient H_j≤coeff 𝒢_j。可保留算术电路而不展开。

令A^(β)_{rj}=deg_{z_r}G_j^(β)，A为其块对角矩阵。度数矩阵D满足D≤A+DEA。EA严格块上三角，所以
$$
D\le L=A(I-EA)^{-1}=\sum_{\ell=0}^{k-1}A(EA)^\ell.
$$
于是任意g有
$$
\operatorname{Supp}F_g\subset[0,Lg_-],\qquad
N(g)=\mathbf1^TLg_-
$$
为明确总根次数截断高度。只需已验证核心证书，不需ordinary、U=mid、Jacobi有限或reddening。Markov旧显式H可取每块A=2J₃作为现成输入；不将这个特例重复报新。

## 双端Euler有限窗消失：独立条件定理

设无环反对称Q，E=I−M上单位三角，B=E−E^T，τ=−E^{-1}E^T，〈a,b〉=a^TEb。则Eτ=−E^T，τ^TEτ=E，〈u,τq〉=−〈q,u〉。在全部负标准参数区g(r)=−Er，对侧头H(g)=−E^Tr。

设族b_g有有限theta展开 b_g=θ_g+Σ_{q>0}t_gq y^qθ_{g+Bq}，且 q+r(g+Bq)≤r(g)。取r=Nu+a，u严格正，a属于固定有限偏移集。假设b族与theta族都满足实际两端支撑消失：固定e若〈e,u〉<0，则[z^e]F=0对大N成立；固定f若〈u,f〉<0，则[z^{r−f}]F=0对大N成立。这里不要求t或b的系数非负。

结论：任意固定有限根窗中的q，若τq非非负则t_gq最终0；若τq≥0且〈q,u〉≠0也最终0，对有限偏移一致。u可避开有限个Euler超平面。

证明关键：固定q、大N时 r(g+Bq)=r−q−τq，故双端盒条件迫τq≥0，对侧缺口s=τq。反向也必须排除远端污染：固定小s时 H(h)=H(g)−Bs；由于H^{-1}在相应大射线附近的线性区可用，
$$
q=-(E^T)^{-1}Es=\tau^{-1}s .
$$
这不对B求逆，B奇异也成立。

若〈q,u〉<0，按|q|在F_b=F_θ+Σt_q z^qF_{θ,h}中取[z^q]。左边与首项为0；较小q′若贡献非零，其差e=q−q′必满足〈e,u〉≥0，所以〈q′,u〉<0，由归纳消失，余下t_q=0。若〈q,u〉>0，对反转多项式 z^rF(z^{-1})按|s|作同样归纳；〈u,s〉=−〈q,u〉<0。有限窗口在两端分别归纳，无需无限闭包。

实际泛Grassmannian支撑可提供两端输入。incidence Z_{e,r}在∏Gr(e_i,r_i)上为向量丛，维数差为〈e,r−e〉。若generic Gr_e非空，则投影占优，所以此数非负。r=Nu+a给下端阈值
$$
N>\frac{\langle e,a-e\rangle}{-\langle e,u\rangle}
$$
（负斜率时）；上端r−f给
$$
N>\frac{\langle a-f,f\rangle}{-\langle u,f\rangle}.
$$
取有限相关偏移和窗口的最大值，再加保持线性区的坐标阈值即可。该条件定理可用于已知实际泛支撑的character族，即使Euler或monodromy系数有符号；任意实际强基C尚未取得此支撑输入，所以它不构成一般theta最小性的完成。

Euler窗口Wolfram原计算：256个rank2–32无环Euler矩阵，4096组标签，3790组τq非负；验证运输、Euler变号及精确整数阈值，Failures=0。它验证代数公式，不验证任意C的支撑假设。

```wolfram
Module[{matrices=0,labels=0,bad=0,eligible=0,n,m,e,b,tau,invTau,q,u,s,r,rh,g,h,a,nu,j,k,zmat,zvec,threshold,seed=202611140729},
SeedRandom[seed];
Do[n=RandomChoice[{2,3,4,6,8,12,16,24,32}];
m=Table[If[i<j,RandomInteger[{0,5}],0],{i,n},{j,n}];
e=IdentityMatrix[n]-m;b=e-Transpose[e];tau=-Inverse[e].Transpose[e];invTau=Inverse[tau];
zmat=ConstantArray[0,{n,n}];zvec=ConstantArray[0,n];
If[Transpose[tau].e.tau!=e||e.tau!=-Transpose[e],bad++];matrices++;
Do[q=RandomInteger[{1,6},n];u=RandomInteger[{1,9},n];s=RandomInteger[{-5,5},n];a=tau.q;nu=q.e.u;
If[u.e.a!=-nu||q.e.q!=a.e.a,bad++];
If[Min[a]>=0,eligible++;
threshold=1+Max[0,Max[MapThread[Ceiling[(#1+#2-#3)/#4]&,{q,a,s,u}]],
If[nu<0,Floor[(q.e.(s-q))/(-nu)],0],If[nu>0,Floor[((s-a).e.a)/nu],0]];
r=threshold u+s;rh=r-q-a;g=-e.r;h=g+b.q;
If[h!=-e.rh||g+b.r-(-e.rh+b.rh)!=b.a||Min[rh]<0||invTau.a!=q,bad++];
If[nu<0&&q.e.(r-q)>=0,bad++];If[nu>0&&(r-a).e.a>=0,bad++]];
labels++,{k,1,16}],{j,1,256}];
<|"Seed"->seed,"Matrices"->matrices,"Labels"->labels,
"NonnegativeOppositeLabels"->eligible,"Failures"->bad,"AllPass"->(bad==0)|>]
```

参考与审核定位：MQ https://arxiv.org/html/2301.11101v3 §5.8、5.24、AppendixB；Zhou https://arxiv.org/html/1901.04166v3 §3.3、5.1；Fei https://arxiv.org/html/2607.12458v3 §1–2、7.5；Goertzen–Williamson https://arxiv.org/html/2604.18894v1 §4、6（新接口仍在审）。所有2026结果只按已审段落使用。

# 一向 theta 纤维的精确系数与整数结构

设 g_S≤0、C=−B_ST≥0，r=−g_S。有限核心写为 H_i(z)=Σ_{s∈S_i}h_{i,s}z^s、F^T_{g_T}(w)=Σ_{a∈S_T}c_T(a)w^a，实际系数均为正整数。令 P_i=conv S_i、Q=conv S_T、α_i(a)=r_i+Σ_j C_ij a_j。此前主定理给出 F_g=Σ_a c_T(a)z_T^a∏_iH_i^{α_i(a)}，其 Newton 多面体为 P={(v,a):a∈Q，v∈Σ_iα_i(a)P_i}。以下严格区分实际支撑饱和与多面体 IDP，不使用 Li–Pan／Li Fang 结论。

## 精确加权整数分解

给每个实际核心单项式 s∈S_i 建列 A_(i,s)=(s,e_i)。则
\[
[z_S^v z_T^a]F_g=c_T(a)\sum_{\substack{n_{i,s}\ge0\\\sum_s n_{i,s}=\alpha_i(a)\\\sum_{i,s}n_{i,s}s=v}}\prod_i\left(\frac{\alpha_i(a)!}{\prod_s n_{i,s}!}\prod_s h_{i,s}^{n_{i,s}}\right).
\]
证明直接逐因子应用多项式定理；每个 n_(i,s)≤α_i(a)，求和有限，全部项正。因此 (v,a) 属实际支撑，当且仅当 a∈S_T 且 (v,α(a))∈NA。固定核心后矩阵 A 不变，查询单个 Laurent 系数只需有界非负整数求解，无需先展开整个环境多项式；不声称一般多项式时间。

负头族的有限递推为 F_(r+e_i)=H_i F_r，即 c_(r+e_i)(v,a)=Σ_s h_(i,s)c_r(v−s,a)。其形式生成函数为 Σ_(r≥0)F_r t^r=F^T_(g_T)(z_j∏_i H_i^C_ij)/∏_i(1−t_iH_i)。这些结论由一向公式直接得到，不依赖支撑饱和。

## 联合 Cayley 与混合整数分解

族 (P_i) 的混合整数分解性质指，对所有 b∈N^m，(Σ_i b_iP_i)∩Z^d=Σ_i b_i(P_i∩Z^d)。它等价于联合 Cayley 多面体 𝒞=conv⋃_i(P_i×{e_i}) 为 IDP：k𝒞 在计数坐标 b、Σb_i=k 的切片恰为 (Σb_iP_i)×{b}，而 𝒞 的格点计数坐标必为某个 e_i。采用仿射张成空间中的环境整数格。此为标准 Cayley trick，见 Tsuchiya arXiv:1804.10538v4 Lemma3.1、Th1.3；不单独主张新颖性。

一般仿射纤维定理：Q、P_i 为格多面体，α_i(a)=c_i+L_i a 为在 Q 上非负的整数仿射函数。若 (P_i) 有混合整数分解，则 P_α={(v,a):a∈Q，v∈Σ_iα_i(a)P_i} 为 IDP 当且仅当 Q 为 IDP。证明正向：给 (v,a)∈kP_α，先以 Q 的 IDP 写 a=Σ_j a_j；混合分解将 v 写成第 i 类共 Σ_jα_i(a_j) 个 P_i 格点，再按每批 α_i(a_j) 项分组。反向：给 a∈kQ 的格点，权数 kc_i+L_i a 为非负整数；任选 P_i 格点即可构造整数提升 (v,a)∈kP_α，分解后投影即得 Q 的 IDP。反向无需 Cayley 假设，也无需 0∈P_i。

若每个实际 S_i=P_i∩Z^d 且联合 Cayley 为 IDP，则完整 F_g 的支撑饱和，当且仅当核心 S_T=Q∩Z^t。证明由实际支撑半群判据与混合整数分解得到。这里不要求 Q 为 IDP：degree-one 支撑与所有倍数上的整数分解是不同结论。

## 环境整数格上的有限证书

设 K=cone(A)，L=span_R(K)∩Z^(d+m)，Γ=NA。计数坐标保证 K pointed。则 Γ=K∩L，当且仅当 K∩L 的 Hilbert basis 每个元素都在 Γ；这是有限判定，每个成员资格由计数行给出有界整数问题。它又等价于所有实际核心支撑饱和且联合 Cayley 为 IDP。若软件仅在 G=group(A) 中检验 normality，则只证 Γ=K∩G，会遗漏 L\G 的同余缺失；必须先核生成格或直接指定环境格。Hemmecke–Takemura–Yoshida arXiv:math/0607599v3 Th2.1 给 (K∩G)\Γ 为有限个平移有限生成幺半群之并的算法。其格是 G，应用时须另保留 L/G 条件。无洞不是精确系数算法的前提。

## 无环扩张块与任意有限底部核心

若 S 无环，按 i<j 时 M_ij=−B_ij≥0 排序，定义 K_i=1+z_i∏_(h<i)K_h^M_hi。逐次一向拼接给 H_i=K_i。对任意实际核心指数 a 和外侧指数 v，有完整公式
\[
[z_S^v z_T^a]F_g=c_T(a)\prod_{i=1}^{m}\binom{r_i+\sum_{j\in T}C_{ij}a_j+\sum_{j>i}M_{ij}v_j}{v_i}.
\]
从 K_m 向 K_1 展开，每次选定 z_i^v_i 时对更早 K_h 增加 M_hi v_i 次幂，故二项式上指标正好如此。约定下指标越界时为零；不需要展开所有纤维。

因此实际支撑恰为 a∈S_T、0≤v_i≤r_i+Σ_(j∈T)C_ij a_j+Σ_(j>i)M_ij v_j 的全部整数点；Newton 多面体由同样实数不等式并 a∈Q 给出。每条实际 T 纤维均被填满，洞恰好是所有缺失 T 格点上整条格纤维。

为核实混合整数分解，令 R(b)={v≥0:v_i≤b_i+Σ_(j>i)M_ijv_j}。有 R(b+b′)=R(b)+R(b′)，整数 b,b′ 时格点也精确相加。逆包含从最后一坐标向前分配：已分好后续坐标时，两侧可用上界 A_i、B_i 相加至少 v_i，取 v_i^(1)=min(v_i,A_i)、v_i^(2)=v_i−v_i^(1) 即可，实数及整数均成立。故 R(b)=Σ_i b_iR(e_i)。联合 Cayley 以 b∈标准单纯形及上述三角不等式描述，是单纯形上的逐层整数 chimney。

从任意 Q 开始依次加入 v_m,…,v_1，每一步是整数 chimney {(x,t):x∈Q′，0≤t≤u(x)}，u 为非负整数仿射函数；恒为零的步骤略过。在此扩张下，四项分别等价于底部 Q 的对应性质：实际支撑饱和、IDP、存在正则幺模三角剖分、存在正则幺模 flag 三角剖分。前两项由上述公式证明；后两项用 Haase–Paffenholz–Piechnik–Santos arXiv:1405.1687v3 Th2.8 的完整 pulling refinement 逐层提升。反向因 v=0 是 P 的格面且等于 Q，限制三角剖分保留性质。必须采用能保持正则性的 pulling refinement，不把原文简略表述扩大为任意抽象 refinement 都正则。

## 另一种共同坐标系证书

若同一格基中每个 P_i 的所有边均平行于 e_p 或 e_p−e_q，则将 P_i 提升为 {(v,h_i−Σ_pv_p)} 后，得到同一格中的 integral generalized permutahedra。St. Dizier–Yong《Generalized Permutahedra and Schubert Calculus》Th2.3 的格点 Minkowski 等式，反复应用后投影，给全部混合整数分解。实际 S_i=P_i∩Z 仍需另核。不能由各 P_i 分别有正则幺模剖分推出联合 Cayley 有相同性质。

## 旧文献边界与实际计算

Reineke arXiv:math/0411101v1 Th4.10 的迭代 Grassmann 丛与 Th5.2(4) 的高斯二项式乘积，其 q=1 特化已覆盖普通无环负头的纯无环系数公式。Fei arXiv:1909.10151v3 Th5.2 已证明无环刚性表示 F 支撑饱和。HPPS Cor2.9 的 Nakajima 多面体正则幺模 flag 剖分也是旧结果。本轮保留的接口是任意有限核心上的完整系数、实际支撑与几何性质传递，并与无 reddening 假设的一向主定理一并查新。

子智能体实际 Wolfram：160组一般正多项式替换，640个整数计数系统，枚举24,188个非负解，比较12,857个系数，支撑大小4–302，失败0。随机输入只检验独立代数展开与整数分解实现，不宣称每个随机核心来自 theta。以下完整代码来自实际运行。

```wolfram
Module[
 {cp, vars = {xs, ys, ts, us}, sv = {xs, ys}, tv = {ts, us}, trials = 160,
 supports, weights, h, ftSup = Tuples[{0, 1}, 2], ftW, c, ell, sub, poly,
 direct, pred, rules, alpha, rows1, rows2, rr1, rr2, a, v, w,
 fail = {}, tests = 0, systems = 0, points = 0, termRange = {}, trial, j, i},
 cp[k_, 1] := {{k}};
 cp[k_, l_] := cp[k, l] = Flatten[Table[(Prepend[#, r] &) /@ cp[k-r,l-1],{r,0,k}],1];
 SeedRandom[202611140814];
 Do[
 supports=Table[DeleteDuplicates[Join[{{0,0},UnitVector[2,i]},RandomInteger[{0,2},{2,2}]]],{i,2}];
 weights=Table[Join[{1,1},RandomInteger[{1,4},Length[supports[[i]]]-2]],{i,2}];
 h=Table[Sum[weights[[i,j]] Times@@(sv^supports[[i,j]]),{j,Length[supports[[i]]]}],{i,2}];
 ftW=Join[{1},RandomInteger[{1,3},3]];c=RandomInteger[{0,2},2];ell=RandomInteger[{0,1},{2,2}];
 sub=Table[tv[[j]] Times@@(h^ell[[All,j]]),{j,2}];
 poly=Expand[Times@@(h^c) Sum[ftW[[j]] Times@@(sub^ftSup[[j]]),{j,4}]];
 direct=SortBy[CoefficientRules[poly,vars],First];rules={};
 Do[
 a=ftSup[[j]];alpha=c+ell.a;
 rows1=cp[alpha[[1]],Length[supports[[1]]]];rows2=cp[alpha[[2]],Length[supports[[2]]]];systems++;
 Do[
 v=rr1.supports[[1]]+rr2.supports[[2]];
 w=ftW[[j]] (Factorial[alpha[[1]]]/Times@@(Factorial/@rr1))
 (Factorial[alpha[[2]]]/Times@@(Factorial/@rr2))
 Times@@(weights[[1]]^rr1) Times@@(weights[[2]]^rr2);
 AppendTo[rules,{Join[v,a],w}];points++,{rr1,rows1},{rr2,rows2}],{j,4}];
 pred=SortBy[Normal[GroupBy[rules,First->Last,Total]],First];
 tests+=Length[Union[First/@direct,First/@pred]];AppendTo[termRange,Length[direct]];
 If[direct=!=pred,AppendTo[fail,{trial,supports,weights,c,ell,Take[direct,UpTo[3]],Take[pred,UpTo[3]]}]],
 {trial,trials}];
 <|"RandomPositiveSubstitutions"->trials,"IntegerCountSystems"->systems,
 "EnumeratedNonnegativeSolutions"->points,"CoefficientComparisons"->tests,
 "SupportSizeRange"->{Min[termRange],Max[termRange]},"Failures"->Length[fail],
 "FirstFailure"->Take[fail,UpTo[1]]|>
]
```

文献路线补记：Tsuchiya、HPPS、Reineke、Fei、Hemmecke–Takemura–Yoshida、St. Dizier–Yong 的上列承重段落均由代理核读，root 又读前五类的相关原文与 St. Dizier–Yong Th2.3。Backman–Liu arXiv:2309.10229v2 Def2.4、Cor3.6–3.7 为单个广义 permutahedron 的接口，未据此推联合结论；Engström–Kahle–Sullivant arXiv:1102.2601 的 toric fiber product 假设未核完，未用。2026 arXiv:2606.13960《The Gröbner Version of White’s Conjecture is False》与2609.18331《Regular dyadic triangulations of delta-matroid polytopes》仅检索命中，未强审、未采用。“各核心分别饱和即可”“共同光滑扇即可”“所有theta支撑饱和”均不作为结论。

# 第十六次文献与路线复查（08:25 UTC 窗口）

本轮实际推进：一向 Laurent 恒等式的负块乘法常数已独立证明原样等于核心常数，且环境 q_S>0 结构项全为零；无环 source block 的任意实际强基限制可以精确归约核心；纤维系数的有界整数求和、Cayley条件及无环 chimney 传递已保存。新的主攻为 source 正标签的实际 core 值多项式与整除，以及反馈核心中 Jacobi-finite 输入的有限上界，不以查新记录代替主攻。下一次复查窗口08:45 UTC。

| 文献／路线 | 本轮核读与处理 |
|---|---|
| Weng2303.03466v1；Fei2610.09868v2 §3.6 | 旧DT替换／good ramified三角扩展均有两块reddening条件。负块基代数只列为本轮更一般拼接定理的乘法加强，不拆成独立新颖性主张 |
| CMMM2505.09585v2 §2.2 | 形式theta乘法、逐次数完成、零根结构系数可用；不使用一般无限signed组合的赋值独立论断 |
| Qin JEMS1308 §6.3 | generic Jacobi-finite weak genteelness 是 conjectural 范围，不能直接作为任意反馈核心有限性证明 |
| Tang Hexagon2610.00083v1 §3、2610.00025v3 §3 | 代理核大量标签刚性仍依赖量子bar＋负v次数上界；后半有限矩阵提取可经典化，前半不能由v=1移植。v2搜索可见而本次PDF取回失败，不冒称已核v2 |
| LLZ1208.2391v3 §2；1303.5806v1 Th1.3 | root核row-divisibility递推与wild ordinary-UP非greedy正元素；前者给新source整除接口，后者不是实际强基反例 |
| Goertzen–Williamson2604.18894v1 §4、§6 | 2026强审：rank-one不变锥探针需实际非交换正作用；一般canonical锥最大性未证，不能拿小秩计算作一般结论 |
| Mejstrik–Protasov2505.01229v1 §3 | Def4/Th2的极值锥只有up-to-sign含义，必须固定共同Perron朝向；已纠正GW裸表述的使用边界 |
| Davison1903.00659v4／AG2024 | 新代理发现正式§3/Th3.8有symmetric条件，不能据宽泛摘要给任意2-acyclic QP吸引子正性；转查局部稳定类别输入 |
| Reading–Stella2603.19391；SIGMA22(2026)109 | 已有v4的pointed与实际Hamel区分审核；11月8日出版版本新命中，代理只对照新增有限性接口 |
| Tang2611.00006v1 MV–theta | 仍仅部分读取，未强审，不采用结论 |
| aiXiv／Hexagon／Zenodo定向检索 | Hexagon量子最小性稿再次命中；本轮其他定向检索未取到可用的新一般经典最小性定理。这个检索结果不构成无先例证明 |

## 导子与双向作用路线的明确修正

08:16 UTC 两代理实读原始证明，发现阶段摘要误将 good/perfect 写成 D_i 对任意 C 的整体正性。原始 D 节已明确禁止此推断；review15错误一句已改正。现在仅保留 D_i=x_i∂_(y_i) 在 A⁺ 上局部幂零、good/perfect、最高除幂单项以及大 x_i^N 乘导数后的正性。正乘子不能取消。本轮下列条件引理与一般表示论族不作为实际cluster反例。

一般嵌套 SL2 族：V=V(n)⊕V(n−2k)，1≤k≤⌊n/2⌋，a≥0；取 Ev_j=jv_(j−1)、Fv_j=(n−j)v_(j+1)，短串 w 同归一化。令 b_j=v_j−a w_(j−k)（k≤j≤n−k），其余 b_j=v_j，并保留全部 w_r。这是权齐次整基，向原字符串基过渡含−a。内部 E b_j=j b_(j−1)+ka w_(j−k−1)，F b_j=(n−j)b_(j+1)+ka w_(j−k+1)；进入重叠区的边界额外项也正。主箭头与两端保持，所有低项字符串度至少降低k，故biperfect。

除幂也正：有效 w 指标处 E^(q)b_j=binom(j,q)b_(j−q)+a[binom(j,q)−χ(j)binom(j−k,q)]w_(j−k−q)，F^(q)b_j=binom(n−j,q)b_(j+q)+a[binom(n−j,q)−χ(j)binom(n−j−k,q)]w_(j−k+q)，χ为重叠区指示函数。有效w指标保证第一个二项系数对应重叠目标，括号非负。故即使全部双向除幂正且固定长短串两端，仍允许任意负短串修正。缺少乘法结构，不能据此否定cluster最小性。

代理实际矩阵共轭核243族（n2至18，所有k，a1至3），6,084个除幂矩阵均非负整，全部243个过渡矩阵有负项。第一次远端内核对奇异矩阵 MatrixPower[_,0] 报错，改为仅检q≥1；q0直接单位阵，错误运行未计入通过数。完整代码：

```wolfram
Module[{make,total=0,powers=0,bad={},neg=0,e,f,t,ti,en,fn,mats,good,n,k,a,r},
 make[n_,k_,a_]:=Module[{m=n-2k,d=2n-2k+2,e,f,t},
 e=ConstantArray[0,{d,d}];f=e;t=IdentityMatrix[d];
 Do[If[j>0,e[[j,j+1]]=j];If[j<n,f[[j+2,j+1]]=n-j],{j,0,n}];
 Do[If[j>0,e[[n+1+j,n+2+j]]=j];If[j<m,f[[n+3+j,n+2+j]]=m-j],{j,0,m}];
 Do[t[[n+2+j-k,j+1]]=-a,{j,k,n-k}];{e,f,t}];
 Do[{e,f,t}=make[n,k,a];ti=Inverse[t];en=ti.e.t;fn=ti.f.t;
 mats=Join[Table[MatrixPower[en,r]/r!,{r,1,n}],Table[MatrixPower[fn,r]/r!,{r,1,n}]];
 good=And@@(And@@(IntegerQ[#]&&#>=0&/@Flatten[#])&/@mats);
 If[!good,AppendTo[bad,{n,k,a}]];total++;powers+=Length[mats];If[Min[Flatten[t]]<0,neg++],
 {n,2,18},{k,1,Floor[n/2]},{a,1,3}];
 <|"families"->total,"dividedPowerMatrices"->powers,"negativeTransitionFamilies"->neg,"failures"->bad|>]
```

条件 Weyl 引理：若共同适当锥上确有D正、乘I正、D²I=0，且可对正核元K=DI作正局部化，则s=I/K满足Ds=1，H=sD正，在kerD^(N+1)上谱为0,…,N，N^−ℓH^ℓ极限为s^ND^N/N!。它仍只取最高层；N−H正性未得。若适当乘法正锥同时含u,u^-1，正导子必D(u)=0，因为D(u^-1)=−u^-2D(u)。此点阻止未识别冻结归一化的两个导子合并。

Pieri→face→单位回移的结果：真实冻结单位回移可保正，good过滤的associated graded也相容，但只看最高层。为了内部谱而删低Laurent项，不是已知C正投影：低头基元有高Laurent尾，截去低部分后可能出现负C系数。ordinary Laurent系数抽取后乘固定CM虽给rank-one正算子，却与CM乘法一起保留整个ordinary-UP锥，不能把该锥压成更小theta锥。此路线已停止重复，刷新为source实际core值整除与Jacobi有限性机制。

# 一向拼接的负块基代数与全部乘法常数

令 C=−B_ST≥0，I_i=x_i^-1 H_i(z_S)=θ^B_(-e_i,0)，核心T的冻结变量另记η_j。先在多项式冻结系数完成中定义 Ψ(x_j)=x_j、Ψ(η_j)=y_j∏_i I_i^C_ij。由于 Ψ(η_j x_T^B_TT[:,j])=z_j∏_iH_i^C_ij，前述Laurent主定理等价于 θ^B_(-r,u)=I^r Ψ(θ^T_u)，r∈N^S，u任意。允许任意含环块及无限形式theta。

若核心乘法 θ^T_u θ^T_v=Σ_(q≥0)c^T_(u,v)(q)η^qθ^T_(u+v+B_TTq)，则完整环境恒等式为
\[
\vartheta^B_{(-r,u)}\vartheta^B_{(-s,v)}=\sum_{q\ge0}c^T_{u,v}(q)y_T^q\vartheta^B_{(-r-s-Cq,\,u+v+B_{TT}q)}.
\]
证明：将核心乘法应用Ψ，再乘I^(r+s)；Ψ(η^q)=y_T^qI^Cq，恰吸收进负S标签。Cq≥0保证输出留在半空间，全主系数首项三角独立性保证这就是环境theta展开。因此全部核心结构常数原样搬运，环境q_S>0结构项全为零；S内部只影响函数值，不改变该区域乘法常数。

形式处理在 Z[x^±]⟦y⟧ 中进行。H_i常数1，η_j的像含y_j，所以替换不降低冻结次数，每固定总次数仅有限项。不能先倒置全部y再称y-adic完成，因为相应理想已含单位。证明完成后，才对有限based algebra的环境冻结变量作局部化。这里仅用CMMM2505.09585v2 §2.2的标准形式theta乘法及零根规则，不用一般无限signed组合的赋值独立论断。

## 多项式系数下的准确基变换

令Γ_T为核心Laurent有限theta标签，A_T⁺=⊕_(u∈Γ_T) Z[η_T]θ^T_u。设R₀=Z[y_S,y_T]，R=R₀[U_i:i∈S]，通过η_j↦y_jU^C[:,j]作基变换。则
\[
R\otimes_{\mathbb Z[\eta_T]}A_T^+\cong M_-^B:=\bigoplus_{r\in\mathbb N^S,u\in\Gamma_T}R_0\vartheta^B_{(-r,u)},\qquad U^r\otimes\vartheta_u\mapsto\vartheta^B_{(-r,u)}.
\]
映射由U_i↦I_i、Ψ给出，乘法封闭已由上式证明。单射取有限关系中最低总冻结次数：每个theta只贡献x_S^-r x_T^u，不同(r,u)的mutable单项式独立，不能相消。故指定基被精确保留。

即便I_i无限形式，M_-仍是完成中的实际Hamel基代数，只要输入核心乘法有限；若所有I_i有限，则它进入环境Laurent有限middle algebra。不据此声称进入ordinary A。可只对环境y倒置；若在核心先倒置η_j，会迫使若干U_i乘积可逆，得到更大的代数，不与本负标签代数混同。

## 正商与平坦族

令U_i=1、y_S=1即可正地收回核心θ基；多项式系数版本也可y_S=0。令U=0时，耦合非零列的η_j置0，零列仍η_j=y_j。若每个T列都相连，则 M_-/(I_i)≅R₀[Γ_T]；Γ_T=Z^T时即R₀[x_T^±]。这些由基变换直接推出。

取整数w_i>0，将η_j替换成y_j t^(w·C[:,j])U^C[:,j]。所得族作为R₀[t]模自由、故平坦，基乘法系数为c_q y_T^q t^(w·Cq)。t=1还原M_-；倒置t后e_(r,u)↦t^(-w·r)θ^B_(-r,u)给同构。全T列相连时t=0只余q0，得到R₀[N^S×Γ_T]；Γ_T全格时为R₀[U_S,x_T^±]。未给有限生成输入，不称有限型代数簇退化。这些是同一拼接机制的结构推论，不单列独立新颖性大定理。

## 实际强基的系数搬运接口

若核心实际β^T_u=Σ_q t_u(q)η^q θ^T_(u+B_TTq)，则负块提升I^rΨβ^T_u=Σ_q t_u(q)y_T^q θ^B_(-r−Cq,u+B_TTq)。因此核心theta换基非负，当且仅当其负块提升非负，逐系数不变。兄弟独立证明全无环任意实际强基的负sourceblock区域确实为此提升，非人为正数组；其详细证明随后保存。仍不能由I^Nf正取消I^N，也不能由共同toric特殊纤维推出高阶换基正。

## 独立实际突变验证

代理以72个valued一向拼接验证：S含1–4个有向A3三角环，T含1–3个A2块，秩5–18，核心对称化因子1–3，跨箭头按gcd满足DB反对称。两个素数域1000000007、1000000009；环境变量完全从2n×n主系数突变生成，S用每块(1,2,3,1)，T再突变三次取得全部A2变量；核心A2 theta乘法另用完整三角消元。共2,304次实际突变、1,944个g-head检查、1,152个乘法恒等式，其中943非单项，13,434个结构项，最大系数81，失败0、零分母0。未用H替换公式生成环境输入。

```wolfram
Module[
 {fc,dec,ev,mut,n,ns,nt,ks,kt,ds,dt,d,b0,xv,yv,state,post,iv,tv,
 tri={{0,-1,1},{1,0,-1},{-1,1,0}},a2={{0,-1},{1,0}},
 primes={1000000007,1000000009},prime,rankList={},fail={},mutations=0,
 headChecks=0,productChecks=0,structureTerms=0,maxCoeff=1,r,s,gg,hh,
 terms,lists,comb,q,coef,lhs,rhs,gnew,ir,cross,i,j,k,l,t,one,trial,
 field,v1,v2,v3,idx,pairs=8,trials=72,coreNontrivial=0},
 fc[{aa_,bb_}]:=fc[{aa,bb}]=Expand[Which[
 aa>=0&&bb>=0,1,aa<=0&&bb>=0,(1+u)^(-aa),
 aa<=0&&bb<=0,(1+u)^(-aa)(1+v+u v)^(-bb),
 aa>=0&&bb<=-aa,(1+v)^aa(1+v+u v)^(-aa-bb),True,(1+v)^(-bb)]];
 dec[aa_List,bb_List]:=dec[aa,bb]=Module[{pol=Expand[fc[aa]fc[bb]],out={},rules,qq,co,count=0},
 While[pol=!=0&&count<500,rules=SortBy[CoefficientRules[pol,{u,v}],{Total[First[#]],First[#]}&];
 qq=First[First[rules]];co=Last[First[rules]];AppendTo[out,{qq,co}];
 pol=Expand[pol-co u^qq[[1]]v^qq[[2]]fc[aa+bb+{-qq[[2]],qq[[1]]}]];count++];
 If[pol=!=0||Min[out[[All,2]]]<0,AppendTo[fail,{"CoreDecomposition",aa,bb}]];out];
 ev[{aa_,bb_},vv_List,pp_]:=Mod[Which[
 aa>=0&&bb>=0,PowerMod[vv[[1]],aa,pp]PowerMod[vv[[2]],bb,pp],
 aa<=0&&bb>=0,PowerMod[vv[[3]],-aa,pp]PowerMod[vv[[2]],bb,pp],
 aa<=0&&bb<=0,PowerMod[vv[[3]],-aa,pp]PowerMod[vv[[4]],-bb,pp],
 aa>=0&&bb<=-aa,PowerMod[vv[[5]],aa,pp]PowerMod[vv[[4]],-aa-bb,pp],
 True,PowerMod[vv[[1]],aa+bb,pp]PowerMod[vv[[5]],-bb,pp]],pp];
 mut[{bb_,xx_,ggm_},kk_,pp_,yy_,init_]:=Module[{nn=Length[xx],all,plus,minus,xx2=xx,bnew,gg2=ggm},
 all=Join[xx,yy];If[xx[[kk]]==0,AppendTo[fail,{"ZeroDenominator",trial,kk}];Return[{bb,xx,ggm}]];
 plus=Mod[Times@@MapThread[PowerMod[#1,Max[#2,0],pp]&,{all,bb[[All,kk]]}],pp];
 minus=Mod[Times@@MapThread[PowerMod[#1,Max[-#2,0],pp]&,{all,bb[[All,kk]]}],pp];
 xx2[[kk]]=Mod[(plus+minus)PowerMod[xx[[kk]],-1,pp],pp];
 gg2[[All,kk]]=-ggm[[All,kk]]+ggm.(Max[#,0]&/@bb[[1;;nn,kk]])-init.(Max[#,0]&/@bb[[nn+1;;2nn,kk]]);
 bnew=Table[If[ii==kk||jj==kk,-bb[[ii,jj]],bb[[ii,jj]]+Max[bb[[ii,kk]],0]Max[bb[[kk,jj]],0]-Max[-bb[[ii,kk]],0]Max[-bb[[kk,jj]],0]],{ii,2nn},{jj,nn}];
 mutations++;{bnew,xx2,gg2}];
 SeedRandom[202611140822];
 Do[ks=1+Mod[trial-1,4];kt=1+Mod[Quotient[trial-1,4],3];ns=3ks;nt=2kt;n=ns+nt;AppendTo[rankList,n];
 ds=RandomInteger[{1,3},ks];dt=RandomInteger[{1,3},kt];
 d=Join[Flatten[ConstantArray[#,3]&/@ds],Flatten[ConstantArray[#,2]&/@dt]];
 b0=ConstantArray[0,{n,n}];
 Do[b0[[3l-2;;3l,3l-2;;3l]]=tri,{l,ks}];
 Do[b0[[ns+2l-1;;ns+2l,ns+2l-1;;ns+2l]]=a2,{l,kt}];
 Do[k=RandomInteger[{0,2}];b0[[i,j]]=-(d[[j]]/GCD[d[[i]],d[[j]]])k;b0[[j,i]]=(d[[i]]/GCD[d[[i]],d[[j]]])k,{i,ns},{j,ns+1,n}];
 cross=-b0[[1;;ns,ns+1;;n]];
 Do[prime=primes[[field]];xv=RandomInteger[{1,prime-1},n];yv=RandomInteger[{1,prime-1},n];
 state={Join[b0,IdentityMatrix[n]],xv,IdentityMatrix[n]};
 Do[Do[state=mut[state,3l-3+k,prime,yv,b0],{k,{1,2,3,1}}],{l,ks}];post=state;
 iv=Table[idx=Select[Range[ns],post[[3,All,#]]==-UnitVector[n,i]&];headChecks++;
 If[Length[idx]=!=1,AppendTo[fail,{"NegativeHead",trial,field,i,idx}];1,post[[2,First[idx]]]],{i,ns}];
 tv=Table[state=post;i=ns+2l-1;j=i+1;state=mut[state,i,prime,yv,b0];v1=state[[2,i]];
 If[state[[3,All,i]]=!=-UnitVector[n,i],AppendTo[fail,{"CoreHeadA",trial,field,l}]];headChecks++;
 state=mut[state,j,prime,yv,b0];v2=state[[2,j]];
 If[state[[3,All,j]]=!=-UnitVector[n,j],AppendTo[fail,{"CoreHeadC",trial,field,l}]];headChecks++;
 state=mut[state,i,prime,yv,b0];v3=state[[2,i]];
 If[state[[3,All,i]]=!=UnitVector[n,i]-UnitVector[n,j],AppendTo[fail,{"CoreHeadB",trial,field,l}]];headChecks++;
 {xv[[i]],xv[[j]],v1,v2,v3},{l,kt}];
 Do[r=RandomInteger[{0,3},ns];s=RandomInteger[{0,3},ns];gg=RandomInteger[{-3,3},{kt,2}];hh=RandomInteger[{-3,3},{kt,2}];
 lists=MapThread[dec,{gg,hh}];
 terms=Table[{Flatten[comb[[All,1]]],Times@@comb[[All,2]]},{comb,Tuples[lists]}];
 If[Length[terms]>1,coreNontrivial++];structureTerms+=Length[terms];maxCoeff=Max[maxCoeff,Max[terms[[All,2]]]];
 lhs=Mod[Times@@MapThread[PowerMod[#1,#2,prime]&,{iv,r+s}] Times@@Table[ev[gg[[l]],tv[[l]],prime]ev[hh[[l]],tv[[l]],prime],{l,kt}],prime];
 rhs=Mod[Total[Table[q=one[[1]];coef=one[[2]];gnew=Flatten[gg+hh]+b0[[ns+1;;n,ns+1;;n]].q;ir=r+s+cross.q;
 coef Times@@MapThread[PowerMod[#1,#2,prime]&,{yv[[ns+1;;n]],q}]
 Times@@MapThread[PowerMod[#1,#2,prime]&,{iv,ir}]
 Times@@Table[ev[gnew[[2l-1;;2l]],tv[[l]],prime],{l,kt}],{one,terms}]],prime];
 productChecks++;If[lhs=!=rhs,AppendTo[fail,{"Product",trial,field,t,lhs,rhs,gg,hh}]],{t,pairs}],{field,2}],{trial,trials}];
 <|"ValuedTriangularQuivers"->trials,"Ranks"->Sort[DeleteDuplicates[rankList]],"FiniteFields"->primes,
 "ActualClusterMutations"->mutations,"PrincipalHeadChecks"->headChecks,"ProductChecks"->productChecks,
 "NontrivialProducts"->coreNontrivial,"TransportedStructureTerms"->structureTerms,
 "MaximumStructureCoefficient"->maxCoeff,"Failures"->Length[fail],"FirstFailure"->Take[fail,UpTo[1]]|>]
```

查新边界：Weng2303.03466v1 Th4.5/Prop4.6/Cor4.7的负基本F替换已存在，条件为两块reddening；Fei2610.09868v2 §3.6的ramified goodness三角扩展亦有相同两块reddening输入。当前全部结构常数搬运作为无此条件的一向形式主定理的乘法加强，仍不作绝对优先权声明。CMMM曲面amalgamation接口虽相关，本次未看到其直接陈述该负标签基代数公式；关键词搜索不是无先例证明。

# 第十七次文献与路线复查（08:45 UTC 窗口）

本轮继续一般机制。最小性主线为实际强正基的源顶点有限多项式、核心正序 Pascal 下界和 Laurent 整除；不使用未证的 D_i 在任意强正基上全矩阵非负。Laurent 主线为齐次势函数的 BPS 正性、吸引子初值重构及有限 Jacobi 模空间上界。当前后者仍是待完成接口，尚未记为无条件有限性定理。

原文复核通过：Argüz–Bousseau, The flow tree formula for Donaldson–Thomas invariants of quivers with potentials, arXiv:2102.11200v2（2022），§3.2，Propositions 3.6、3.8、3.9。它们分别给吸引子投影的双射、由初值唯一重构一致散射图、含吸引子点的同法向墙上的该次数值独立性。所需 Lie 条件是斜形式配对为零时括号为零；不要求斜形式非退化。本文可用该旧结果核对 full-hyperplane completion 与 DT 图的等价性；不把其重构结论计作我们的新结果。原文：https://arxiv.org/pdf/2102.11200 。一次误输 arXiv:2002.10810 命中无关的包裹柜文章，已剔除，未作输入。

原文复核通过并限制用途：Cheung–Mandel, Donaldson–Thomas invariants from tropical disks, Selecta Math. 2020, Theorem 3.5，只对 Abelian walls 保证 completion 存在；文章明确纠正旧版本更广的存在性说法。其 Hall broken lines 不能直接提供一致 theta 的反例警告必须保留。Davison–Mandel, arXiv:1910.12915v3, Theorem 2.13 后确有把 incoming cones 补成 full affine hyperplanes 的说明，但该说明本身不够保证补墙过程系数非负。我们采用吸引子初值与独立正 completion 对比，避免把此处的等价变换误作正性证明。原文：https://d-nb.info/121828675X/34 ；https://arxiv.org/pdf/1910.12915 。

2026 查新记录：重新检出 Tang 的 strongly positive / quantum greedy / minimality 系列；先前审核显示其中有限 jet 刚性使用量子 bar 和 v 次数约束，不能自动用于任意经典基。检出 Fei 2026-11-11 universal Schubert、compatible gradings on dg models 等条目，本轮仅有检索摘要，未审核、未使用。直接检索“Jacobi-finite theta homogeneous”等在第二搜索引擎大量误中 Jacobi forms，记录为低相关检索，不据此断言无既有结果；继续用第一搜索引擎及作者原文补查。源块因子化与 Qin 2407.03186 §6.15–6.17 的 freezing/localization 思路相接；单独的冻结因子化不宣称原创。实际强正基内生的 Pascal 余项及全族乘法约束仍在查新和证明。

## 非正指数在负象限的无折点引理

设 D 是主系数散射图（可取斜可对称 B，D_0 B 斜对称，D_0 为正对角整矩阵），各墙次数 n 位于 N^+。固定可变坐标严格负的端点 Q_-，初始可变指数 g≤0。任一折线在某段的累计根次数记为 d≥0，因此该段可变指数为 g+B d，速度为 −(g+B d)。定义 φ(t)=d(t)^T D_0 γ_mut(t)。在折点，d 跳为 d+k n，而所在墙满足 n^T D_0 γ_mut=0，故 φ 连续。在每个线段上 φ′=−d^T D_0 g−d^T D_0 B d=−d^T D_0 g≥0。第一段 d=0，φ=0。若终段 d≠0，则 φ(0)=d^T D_0 Q_-<0，矛盾。因此 d恒为0，折线不能弯折。直线 γ(t)=Q_-−t g 全部处于负象限，确实存在。冻结坐标不影响该计算；主系数根次数保留 d，排除了 B 的核造成的歧义。

结论：θ_{g,Q_-}=x^g（g≤0），无需负象限可达，也无需 genteel 假设；由一致性运到正端点，θ_g=∏_i θ_{−e_i}^{−g_i}。该引理作为既有形式一向拼接证明的独立简化，不将“任意正图的负象限”偷换为普通丛 atlas 的所有正性，也不由此推出任意强正基最小性。对未来 BPS 上界路线，负基本 theta 可由负至正路径积计算；路径积与有限 framed 模空间的识别仍须单独核对符号、完成及 properness。

# 源块下降与实际正多项式

本节证明无环主系数经典丛代数中，任意实际强正基在负源块半空间上的精确核下降，以及正源头部分的核值正多项式结构。结论包括核序双界、全乘法的端点约束、Pascal 余项的严格支撑和原 Laurent 性的高阶整除接口。一般 theta 最小性仍需要进一步的正补全机制。

## 设定与已证输入

B 是无环斜可对称整数交换矩阵，A 是普通主系数丛代数，系数环为 R=Z[y_1^{±1},…,y_n^{±1}]。C 是实际强正 R 基，包含全部丛单项式。本节使用前文已证的归一化结论：C 的归一化元素 β_g 构成 A_+ 的实际 Z[y] 基；在每个无环种子中，它们有兼容的完整 mutable/frozen 头、非负有限 root 多项式和 BFZ 箱界。

```math
\beta_g=x^gF_g(z),\quad z_j=y_jx^{Be_j},\quad F_g\in\mathbb N[z],\quad F_g(0)=1,
\qquad
\beta_g\beta_h=\sum_{q\ge0}m_{g,h;q}y^q\beta_{g+h+Bq},
\quad m_{g,h;q}\in\mathbb N.
```

这里不假定 D_i=x_i∂_{y_i} 的整个 C 矩阵非负，也不假定完整 Taylor 展开或 coaction 在 C 上正。下述正性都直接来自实际基的正乘法。

## 斜可对称根零纤维与实际核基

拓扑排序使 i<j 时 B_ij≤0。从左到右各突变一次，每一步都是全图 source，当前主系数 C 列仍为 e_j。所得同一末尾 cluster 的变量满足直接交换递归：

```math
I_j=x_j^{-1}K_j(z),\qquad
K_j=1+z_j\prod_{h<j}K_h^{-B_{hj}}.
```

对任意外部集合 E，令 y_j=0，j∈E。每个外部 K_j 的非平凡项都含 z_j，所以 K_j→1、I_j→x_j^{-1}；其他 K_h 仍非平凡不影响此结论。这不需要 species 或内射模的解释。

实际 Z[y] 基可对这些变量做基变换。纤维基的正锥同时包含 x_j 和 x_j^{-1}，两者非负、列有限的乘法矩阵互逆，故必为置换矩阵。理由是矩阵积的对角项为1、非对角项为0，所有项均非负，且 N[y_core] 的正单位只有1。比较完整 pointed 头可得：

```math
x_j\bigl(\beta_g|_{\mathrm{core}}\bigr)
=\beta_{g+e_j}|_{\mathrm{core}},
\qquad j\in E.
```

因此 F_g|_{z_E=0} 只依赖 g_core。无环 lower-bound presentation 中，外部 x_j 已可逆，外部 x_j′ 可消去。对核内 i，把 x_i′ 除以 ∏_{j∈E}x_j^{[-B_ji]_+}，并令 Y_i=y_i∏_{j∈E}x_j^{B_ji}，交换关系恰为 B_core 的主系数关系。取外部单位轨道，得到实际 Z[Y] 强正核基 C^core，保持独立、有限张成、强正乘法及全部核丛单项式。不同冻结幂始终保留，因此 B_core 有核也不会使标签混并。

## 任意源块的精确代换

设顶点分解 S⊔T，且 B_TS≥0，因而 B_ST≤0。令 H_i=K_i^{B_SS} 是 S 子矩阵的 sourceword 多项式。对 g_S≤0，有：

```math
F^B_{\beta,(g_S,g_T)}(z)
=
\prod_{i\in S}H_i(z_S)^{-g_i}\,
F^T_{\beta,g_T}
\left(
z_j\prod_{i\in S}H_i(z_S)^{-B_{ij}}
:\ j\in T
\right).
\tag{SB}
```

证明如下。按 S 的拓扑序突变，令 R=diag(−I_S,I_T)。直接交换矩阵突变给 B′=RBR、C′=R。每一步当前被突变的 g_i≤0，完整 tropical 头中其他 mutable/frozen 坐标不变，所以新完整头是 (Rg,0)。末尾 S 成为 terminal block，且 g′_S=−g_S≥0。倒序 BFZ 递推立即给 r′_S=0，故新 root 多项式没有 S 根。

实际核基引理于是给 β_g=I_S^{-g_S}x_T^{g_T}F^T_{g_T}(z′_T)。对 j∈T：

```math
z'_j
=
y_jx_T^{B_{TT}e_j}
\prod_{i\in S}I_i^{-B_{ij}}
=
z_j\prod_{i\in S}H_i^{-B_{ij}}.
```

代入 I_i=x_i^{-1}H_i 得到 (SB)。新旧核基相同：把所得等式置原 z_S=0，此时 H_i→1，再用旧根零纤维的唯一性。证明没有假定 C 的切片等于 theta 切片。

若核中有有限 theta 展开，系数暂可带符号，则：

```math
\beta^T_u=\vartheta^T_u+
\sum_{q>0}t_{u,q}Y^q\vartheta^T_{u+B_{TT}q}
\quad\Longrightarrow\quad
\beta^B_g=\vartheta^B_g+
\sum_{q>0}t_{u,q}y_T^q
\vartheta^B_{(g_S+B_{ST}q,\ u+B_{TT}q)}.
\tag{ST}
```

这是 (SB) 与 theta 的同一代换逐项比较。因 B_ST≤0，所有修正仍在 g_S≤0 的合法半区。核 theta 非负展开因此逐系数原样提升，且不产生 S 根修正。两个负 S 头元素的乘法也有同样的核结构常数提升。

这里要求全 Q 无环；theta 在某些循环核上的代换式不能自行把 arbitrary C 的结论推广到循环 Q。块删除等价于按 S 拓扑序连续做 rank1 负 source 删除，块式统一了嵌套代换和系数公式。

## 单源的实际正多项式

现在 S={i}，采用以下统一变量：

```math
B=
\begin{pmatrix}
0&-p\\
b&B_T
\end{pmatrix},
\quad p_j,b_j\ge0,
\qquad
t=x_i,\quad M=x_T^b,\quad
I=\vartheta_{-e_i}=\frac{1+y_iM}{t},
\qquad
Y_j=y_jI^{p_j}.
```

核代数 A_T^+ 使用 x_T,Y；负半区恰为 β_(−r,u)=I^rβ^T_u(Y)，r≥0。对 k≥0，定义 P_(k,u)=I^kβ_(k,u)。若把 I^kβ 的实际强正乘法写出，所有输出源头都是 −p·c≤0，因此：

```math
I^k\beta_{(k,u)}
=
\sum_{a,c\ge0}d_{a,c}y_i^ay_T^c
\beta_{(-p\cdot c,\ u+ba+B_Tc)}
\quad\Longrightarrow\quad
P_{k,u}
=
\sum_{a,c\ge0}d_{a,c}y_i^aY^c
\beta^T_{u+ba+B_Tc},
\quad d_{a,c}\ge0.
\tag{P0}
```

所以 P_(k,u) 属于 A_T^+[y_i]，且在实际核基上系数非负。这里是直接计算正乘积，不是从乘积正性取消 I。

定义 f≤_T h，表示 h−f 是核基在 N[y_i,Y] 上的非负组合。则：

```math
0\le_T P_{k,u}\le_T(1+y_iM)^k\beta^T_u,
\qquad
\deg_{y_i}P_{k,u}\le k.
\tag{PU}
```

证明：t^kβ_(0,u) 的强正展开首项是 β_(k,u)。乘 I^k 后，其余每个输出也按 (P0) 或负半区公式变成核正项，而左边是 (1+y_iM)^kβ^T_u。

两个端点完全固定：

```math
[y_i^0]P_{k,u}=\beta^T_u,
\qquad
[y_i^k]P_{k,u}=\beta^T_{u+kb}.
\tag{PE}
```

底端是原 y_i=0 的根纤维。顶端用 source mutation：旧完整头 (k,u;0) 变成 (−k,u+kb;k e_i)，z′_i=(y_iM)^{-1}、z′_T=Y_jx_T^{B_Te_j}。于是 β_(k,u)=y_i^kI^{-k}x_T^{u+kb}F′_(−k,u+kb)(z′_i,z′_T)。最高 y_i 项来自 z′_i^0 的核 face；两种子核基相同已由 (SB) 证明。特别地：

```math
P_{1,u}=\beta^T_u+y_i\beta^T_{u+b}.
```

## 全乘法与两端结构常数

约定 d≤0 时 P_(d,w)=β^T_w。若 k,l≥0，且实际乘法为：

```math
\beta_{(k,u)}\beta_{(l,v)}
=
\sum_{a,c\ge0}m_{a,c}y_i^ay_T^c
\beta_{(k+l-p\cdot c,\ u+v+ba+B_Tc)},
```

则乘 I^(k+l) 后精确得到：

```math
P_{k,u}P_{l,v}
=
\sum_{a,c\ge0}m_{a,c}y_i^aY^c
P_{[k+l-p\cdot c]_+,\ u+v+ba+B_Tc},
\qquad m_{a,c}\ge0.
\tag{PM}
```

最高项无消去，所以 m_(a,c)≠0 时 a≤min(p·c,k+l)。比较 y_i^0 与 y_i^(k+l)，并用实际核基展开唯一性，得到：

```math
m_{0,c}=m^T_{u,v;c},
\qquad
m_{\min(p\cdot c,k+l),c}
=
m^T_{u+kb,v+lb;c}.
\tag{ME}
```

当 p·c=0 时，相应两组核结构常数必须相等；这是同一恒等式推出的约束，不是额外假设。

## Pascal 余项的严格支撑

对 k≥1，写真实乘法 Iβ_(k,u)。其输出头为 (k−1−p·c,u+ba+B_Tc)。冻结全部 T 根后，rank1 正头基是 t^(k−1)x_T^w，故 c=0 的项恰为 β_(k−1,u)+y_iβ_(k−1,u+b)，系数各1。乘 I^(k−1) 后，每个 c>0 项都变成核正项：

```math
n_{a,c}y_i^aY^c
P_{[k-1-p\cdot c]_+,\ u+ba+B_Tc}.
```

底端 (PE) 使 c>0 的 a=0 系数全零。次数先给 a≤min(p·c+1,k)。若达到此上界，该项的最高系数是 Y^cβ^T_(u+kb+B_Tc)；但 P 顶端只有 β^T_(u+kb)。核基展开唯一且无消去，故 c>0 的这个极端系数也为零。因此：

```math
\begin{aligned}
P_{k,u}={}&P_{k-1,u}+y_iP_{k-1,u+b}\\
&+\sum_{\substack{c>0\\1\le a\le\min(p\cdot c,k-1)}}
n_{a,c}y_i^aY^c
P_{[k-1-p\cdot c]_+,\ u+ba+B_Tc},
\qquad n_{a,c}\in\mathbb N.
\end{aligned}
\tag{Pascal}
```

有效余项满足 p·c≥1，所以余项的源次数至多 k−2。逐步迭代得全 k 的核序双界：

```math
\sum_{j=0}^k\binom{k}{j}y_i^j\beta^T_{u+jb}
\le_T P_{k,u}
\le_T(1+y_iM)^k\beta^T_u.
\tag{PB}
```

同理由 tβ_(k,u) 的首项可得 (1+y_iM)P_(k,u)−P_(k+1,u)≥_T0。这些是实际正乘法导出的离散约束；没有使用导数矩阵的全正性。

## 原 Laurent 性的高阶整除接口

令 z=y_iM，并按核初始 Laurent 单项式展开：

```math
P_{k,u}
=
x_T^u\sum_{c\ge0}Y^cx_T^{B_Tc}p_c(z).
```

则 p_c∈N[z]、次数≤k；常数是核 F_u 的 c 系数，最高系数是核 F_(u+kb) 的 c 系数，且 p_c≤[z_T^c]F^T_u·(1+z)^k。原 F 多项式的 c 切片为：

```math
[z_T^c]F_{\beta_{(k,u)}}(z,z_T)
=
p_c(z)(1+z)^{p\cdot c-k}.
```

因此 p_c 可被 (1+z)^[k−p·c]_+ 整除，商仍非负。固定根窗口、k 变大时，这是高阶整除约束。Pascal 下界本身一般不满足这些整除，因而整除确实会强迫新增内部系数；不过尚未证明该补全机制给出所有任意强正基的 theta 最小性或共同有限 jet。

## 有限下降证书与文献界面

有限 source/sink 反射字可与负源块 g_S≤0 删除、非负终端块删除交替，到已知 theta 最小性的实际核后由 (ST) 传回。删除次数不超过秩；给定有限字的验证必终止。固定字的 tropical 变换分段整线性，符号条件给有限个有理多面锥，因此可一次描述整批整数标签。这里不声称无界反射搜索必终止，也不声称覆盖 sincere imaginary 区域。空核终止与可见丛单项式高度重叠。

[Qin 2407.03186v1](https://arxiv.org/html/2407.03186v1) 的 Proposition 6.5、Lemma 6.15 和 Theorem 6.17 已包含 positivity 下的局部支持、factorization 以及 freezing 与 localization 的对应机制。因此源半区因子化不作为孤立的全新原理。本节从实际强正基的根零正单位退化验证相应假设，给出明确块代换和全乘法提升。Fujita–Qin 2601.00687v2 的 simple character freezing 只作为接口认识，未作为 arbitrary C 的证明输入。Qiyue Tang 2610.00025v3 与 2610.00083v1 的 generic large-label 刚性使用量子 bar 与 v-degree 容量；该步骤不能在 v=1 后用于任意经典 C。

## Wolfram 独立校准

2026 年 11 月 14 日 08:18 UTC，以 240 个随机无环斜可对称主系数种子检查源块坐标，秩为2至35。完整 extended mutation 的五项检查全部通过：B′=RBR、C′=R、全基头 (Rg,0)、T 根三角修正的完整头运输，以及 g_S+B_STq≤0。计算没有把坐标检查当成实际核基的证明。

2026 年 11 月 14 日 08:40 UTC，以下代码由经典 rank2 greedy 递推独立重建 theta Laurent 系数，再作实际分式变换得到 P。160组参数 b,c∈{1,…,5}、k∈{0,…,36} 中，106组满足 bc>4。这里的106是 wild 交换参数计数，不表示所有相应标签都在 imaginary 区域。所有原 chart 整除、次数、两端、核基正性、核序二项式上界、核序 Pascal 余项检查均通过。

代码中的 zz 表示 y_i x_T^b，yy 表示核主系数 Y，pn 返回 P/x_T^u。核行除式 (1+Y)^[-u−cℓ]_+ 检查的是实际 rank1 核基系数，超出原 Laurent 系数的逐项检查。有限计算用于校准方向与归一化，不代替一般证明。

```wolfram
ClearAll[pn, zz, yy];
SeedRandom[2026111402];
pn[bb_, cc_, kk_, uu_] := pn[bb, cc, kk, uu] =
 Module[{den = Max[-uu, 0], aa, ee, p, q, n, a, ep, rows, div, rem},
  If[uu >= 0, Return[Expand[(1 + zz)^kk]]];
  aa = Max[bb den - kk, 0];
  ee = ConstantArray[0, {den + 1, aa + 1}];
  ee[[1, 1]] = 1;
  Do[
   If[p + q > 0,
    ee[[p + 1, q + 1]] =
     If[cc aa q >= bb den p,
      n = Max[aa - bb p, 0];
      Sum[(-1)^(l - 1) ee[[p + 1, q - l + 1]]
        Binomial[n + l - 1, l], {l, 1, q}],
      n = Max[den - cc q, 0];
      Sum[(-1)^(l - 1) ee[[p - l + 1, q + 1]]
        Binomial[n + l - 1, l], {l, 1, p}]
     ]
   ], {p, 0, den}, {q, 0, aa}];
  rows = Table[
    ep = Sum[ee[[den - a + 1, q + 1]] zz^q, {q, 0, aa}];
    If[kk - bb a >= 0,
     Expand[ep (1 + zz)^(kk - bb a)],
     div = (1 + zz)^(bb a - kk);
     rem = PolynomialRemainder[ep, div, zz];
     If[rem =!= 0,
      Throw[{"division failure", bb, cc, kk, uu, a, rem}]];
     PolynomialQuotient[ep, div, zz]
    ], {a, 0, den}];
  Expand[Sum[rows[[a + 1]] yy^a, {a, 0, den}]]
 ];

nonnegCore[f_, cc_, uu_, kk_] :=
 And @@ Table[
   Module[{row = Coefficient[Expand[f], zz, l],
     div = (1 + yy)^Max[-uu - cc l, 0], r, q},
    r = PolynomialRemainder[row, div, yy];
    q = PolynomialQuotient[row, div, yy];
    r === 0 && And @@ (# >= 0 & /@ CoefficientList[q, yy])
   ], {l, 0, kk}];

cases = Table[
   {RandomInteger[{1, 5}], RandomInteger[{1, 5}],
    RandomInteger[{1, 9}], RandomInteger[{0, 36}]}, {160}];
results = Catch[
   Table[
    Module[{bb = ca[[1]], cc = ca[[2]], uu = -ca[[3]],
      kk = ca[[4]], f, up, lo, checks},
     f = pn[bb, cc, kk, uu];
     up = Expand[(1 + zz)^kk (1 + yy)^(-uu) - f];
     lo = If[kk == 0, 0,
       Expand[f - pn[bb, cc, kk - 1, uu]
         - zz pn[bb, cc, kk - 1, uu + cc]]];
     checks = {
       Exponent[f, zz] <= kk,
       Coefficient[f, zz, 0] == (1 + yy)^(-uu) // Expand,
       Coefficient[f, zz, kk] ==
        Expand[(1 + yy)^Max[-uu - cc kk, 0]],
       nonnegCore[f, cc, uu, kk],
       nonnegCore[up, cc, uu, kk],
       nonnegCore[lo, cc, uu, kk]};
     checks[[2]] =
      Expand[Coefficient[f, zz, 0] - (1 + yy)^(-uu)] === 0;
     {ca, And @@ checks, checks}
    ], {ca, cases}]];
If[Length[results] == Length[cases],
 <|"cases" -> Length[cases],
   "wildCases" -> Count[cases, {b_, c_, _, _} /; b c > 4],
   "sourceDegreeRange" -> MinMax[cases[[All, 4]]],
   "allPass" -> And @@ results[[All, 2]],
   "failures" -> Select[results, Not[#[[2]]] &],
   "checks" -> {"binomial divisibility in original chart",
     "degree <= k", "both core endpoints",
     "core coefficient positivity", "core binomial upper bound",
     "core Pascal lower recurrence"}|>, results]
```

Wolfram 原始输出如下，调用耗时8.4秒：

```wolfram
<|"cases" -> 160,
  "wildCases" -> 106,
  "sourceDegreeRange" -> {0, 36},
  "allPass" -> True,
  "failures" -> {},
  "checks" -> {"binomial divisibility in original chart",
    "degree <= k", "both core endpoints",
    "core coefficient positivity", "core binomial upper bound",
    "core Pascal lower recurrence"}|>
```

# 有限 Jacobi 列证书与 theta Laurent 停止界

本节记录 2026 年 11 月 14 日完成的主证明及独立压力检查。主要结论只针对斜对称交换矩阵、普通有限箭图、经典主系数 theta 函数。它把有限 Jacobi 模的可计算列界转化为 theta Laurent 展开的有限停止界，取消此前条件稿中的“额外 incoming 因子可正删除”假设。证明使用实际的上同调 Harder–Narasimhan 分解和正散射图，既不假设 weak genteelness，也不把稳定散射图等同于簇散射图。

有限截断平台的迭代闭包论证是完备 Nakayama 型标准机制；Fei 2026 年论文 Lemma 1.5、Proposition 1.8 也明确使用了它。本节自含重述该证书，不为平台判据或所选单列版本单独主张优先权。需要继续外部查新的核心是：unsigned 上同调辅助散射图、中心颜色删除、有限 framed HN 上界与 theta Laurent 停止界的组合。这里不使用 Li–Pan、Li Fang 或相关多面体基文章的结论。

## 1. 约定和主定理

固定 r 阶斜对称整数矩阵 B。原箭图 Q 的方向约定为：箭头 i→j 的数目为 [B_{ji}]₊。因此 B_{ij} 等于反向箭图 Qᶠ=Qᵒᵖ 中 i→j 的箭头数减去 j→i 的箭头数。所有路径代数及表示均在复数域上讨论；Q 没有环或二圈。

设 W 是 Q 上的形式势，所有项的长度至少为 3。令 m 为箭理想，令 I(W) 为循环偏导生成的闭双边理想，定义完成 Jacobi 代数：

```math
J=\widehat{\mathbb C Q}/I(W),\qquad
I(W)=\overline{(\partial_aW:a\in Q_1)}.
```

给定顶点集合 S，假设每个 i∈S 的右模 e_iJ 有限维。等价地，原箭图的内射模 I_i=D(e_iJ) 有限维，其中 D 是复向量空间对偶。定义内射 Cartan 列：

```math
D_{ji}=\dim_{\mathbb C}(e_iJe_j)=\dim_{\mathbb C}(I_i)_j
\quad(i\in S).
```

若使用通常的投射 Cartan 矩阵 C_{ji}=dim(e_jJe_i)，则这里的矩阵 D=Cᵀ。以下公式始终按上述 D 的定义书写，不混用两个方向。

主系数单项式记为 Yᵈ=yᵈx^{Bd}。对每个 g∈Zʳ，取初始冻结次数为零的 theta 函数，并写成其初始图表的形式展开：

```math
\vartheta_g=x^gF_g(Y),\qquad
F_g\in\mathbb N[[Y_1,\ldots,Y_r]],\qquad F_g(0)=1.
```

符号 A≼B 表示每个 Y 单项式的系数均满足 A 的系数不超过 B 的对应系数。

**定理（有限 Jacobi 列给出 theta 停止界）。** 令 f=g₋=[−g]₊，并假设 supp(f)⊂S。存在一个由有限循环 framed Jacobi 模的 unsigned 消失上同调构造的多项式 H_f∈N[Y]，使得：

```math
F_g\preceq F_{-f}\preceq H_f.
```

而且，记 I(f)=⊕_{i∈S}I_i^{f_i}，则：

```math
\operatorname{supp}H_f
 \subseteq
 \{\dim U:U\subseteq I(f)\}
 \subseteq
 \{d\in\mathbb Z_{\ge0}^{r}:0\le d\le Df\}.
```

因此：

```math
\deg_{Y_j}F_g\le(Dg_-)_{j},\qquad
\operatorname{Newt}(F_g)
 \subseteq
 \operatorname{conv}\{\dim U:U\subseteq I(g_-)\}.
```

特别地，如果整个完成 Jacobi 代数 J 有限维，则所有 g∈Zʳ 的主系数 theta 形式展开都是 Laurent 多项式。在 Davison–Mandel Theorem 1.2(2) 的 theta 正则性定理下，这些函数属于上簇代数。此处不由此进一步断言它们张成整个上簇代数，也不把一般形式完备基误称为 Hamel 基。

这个结论不要求 W 非退化、不要求正齐次势、不要求纯性、不要求 reddening sequence，也不要求稳定图与簇图 weakly genteel。W 在本证明中的作用是提供一个有限模上界；簇 theta 函数本身只由交换数据决定。

H_f 的定义不是普通 Euler 特征的 Quiver Grassmannian 多项式。它来自实际消失上同调在遗忘到有理分次向量空间之后的各次数维数之和。因而这里没有声称任意模的 Euler 多项式为正，也没有用 unsigned Poincaré 多项式去实现一般的剪切关系。

## 2. 可停止的有限截断证书与形式势的有限替代

定义 q_i(L) 为长度小于 L 的路径截断在第 i 个右行的商维数：

```math
q_i(L)=\dim_{\mathbb C}
 e_i\bigl[\widehat{\mathbb C Q}/(I(W)+\mathfrak m^L)\bigr].
```

自然映射给出 q_i(L+1)≥q_i(L)。若精确计算得到：

```math
q_i(L+1)=q_i(L),
```

则长度恰为 L 的该右行商为零，即：

```math
e_i\mathfrak m^L\subseteq e_i I(W)+e_i\mathfrak m^{L+1}.
```

右乘 m，并反复代入，得到对每个 K≥L 均有 e_i mᴸ⊂e_iI(W)+e_i mᴷ。闭性于是给出 e_i mᴸ⊂e_iI(W)。故 e_iJ 已等于其长度小于 L 的截断，所有端点分块的维数直接给出 D 的第 i 列。

这一推导适用于所选右行，不必先证明整个 J 有限。若 e_iJ 有限，非降整数序列 q_i(L) 有界，必出现平台；因此该过程在有限列上必然停机。对于无限列，本证明不提供保证停机的否定判定算法。

**截断阶的精确校准。** 检验 q_i(L) 和 q_i(L+1)，只需要 W 的长度不超过 L+1 的项。因为长度至少 L+2 的势项的循环偏导落在 m^{L+1}，在这两个截断商中均消失。令：

```math
W'=W_{\le L+1}.
```

原形式势 W 与多项式势 W′ 给出相同的两个截断。若 W 的第 i 行满足平台，则 W′ 的第 i 行满足同样平台，且两个完成 Jacobi 代数的该有限右模都等于同一个长度小于 L 的截断模。因此二者有相同的 Q 模结构及相同的 Cartan 列，而不仅是总维数相同。

多个所选顶点可取它们平台高度的最大值；已经有限的行在更高截断仍保持平台。由此可以同时选取一个多项式势 W′，保留所有需要的有限行。随后所有消失上同调均只对 W′ 构造，不需要定义形式势的消失上同调，也不需要证明形式势替换前后该上同调不变。

有限计算的实现是精确线性代数：按路径起点、终点分块列出所有长度小于 L+1 的路径，以全部截断左、右路径倍数 u(∂ₐW′)v 作为关系列，计算各块商维数。必须包含所有相关双边路径倍数，不能只取循环偏导本身的张成。系数应在能进行精确运算的特征零域中表示；浮点秩不能作为证书。

这一步替代了较早考虑的形式有限确定性路线。Hua–Zhou 的有限确定性定理仍是有效背景，但主证明不再依赖它。对单独选定有限列的版本，上述有限 jet 替代尤其直接。

## 3. 主系数作用、反向箭图和方向校准

转到 Qᶠ=Qᵒᵖ，取多项式势 Wᶠ=(W′)ᵒᵖ，令 Jᶠ 为其完成 Jacobi 代数。原箭图的有限内射 I_i 对偶为 Qᶠ 的有限投射 P_iᶠ=Jᶠe_i，其维数列恰为 D_i。循环源 framing 将由这些投射表示。

主系数指数格取 M⊕N，使用如下反对称形式：

```math
\Lambda=
\begin{pmatrix}
0&-I\\
I&-B
\end{pmatrix},
\qquad
Y^n=X^{(Bn,n)}.
```

直接矩阵计算给出：

```math
\Lambda(Y^a,Y^b)=a^{\mathsf T}Bb,\qquad
\Lambda(Y^n,x^g)=n\cdot g,\qquad
\widetilde B^{\mathsf T}\Lambda=[I,0],
\quad
\widetilde B=\binom BI.
```

因此即使 Bn=0，Yⁿ 仍保留冻结指数 n，其对 xᵍ 的作用由 n·g 检测，不能把根基方向删除。完整主系数格正是保留该作用的必要部分。

在 Qᶠ 加入源顶点 ∞，并添 f_i 条 ∞→i 的箭，得到 Qᶠ_f。其指数格嵌入主系数格：

```math
e_i\longmapsto(Be_i,e_i),\qquad
e_\infty\longmapsto(-f,0).
```

两边的配对均满足 B_{Q_f}(n,e∞)=−f·n，故嵌入保持量子环乘法。特别地：

```math
x_\infty\longmapsto x^{-f},\qquad
X^{(d,1)}\longmapsto X^{(Bd-f,d)}.
```

作为方向校准，原箭图 Q:1→2 时：

```math
B=\begin{pmatrix}0&-1\\1&0\end{pmatrix},\qquad
\dim I_1=(1,0),\quad\dim I_2=(1,1).
```

相应 H₁=1+Y₁，H₂=1+Y₂+Y₁Y₂，与 θ_{−e₁}、θ_{−e₂} 的方向一致。原箭图的投射 P₁ 会给出 1+Y₁+Y₁Y₂，不能代入本定理的同一列。这一小检验只用于固定约定；一般证明不依赖该例。

## 4. unsigned 上同调构造：先得到正的辅助图

这里使用 Davison–Meinhardt 的实际上同调 HN 分解及 integrality 同构，而不是对 Hall 代数中的一般剪切等式施加 unsigned 维数函数。所需输入是 [Davison–Meinhardt 1601.02479，Theorems A、B 与 Corollary 4.13](https://arxiv.org/pdf/1601.02479)，并取其中允许的 nilpotent Serre 子范畴。

从 monodromic mixed Hodge structures 到普通 mixed Hodge structures 的 forg 不具有所需的张量性质；此处用的是遗忘到有理向量空间的 rforg。它的正合对称幺半性质见 [Davison，Algebraic Geometry 11 (2024)，§2.2，pp. 765–766](https://api.algebraicgeometry.nl/Article/20756/2024-6-023.pdf)。对上同调分次定义：

```math
\chi_t(V)=\sum_k\dim_{\mathbb Q}(V^k)\,t^k.
```

采用 DM 的虚拟 Tate 归一化，半 Tate 对象对应 t，归一化 B Gₘ 因子对应：

```math
u=\frac{t}{1-t^2}.
```

分次对称代数中的奇偶规则必须保留。量子环使用 XᵅXᵝ=t^{B(α,β)}X^{α+β}，其中 DM 的反对称 Euler 形式为 B(α,β)=χ(β,α)−χ(α,β)。在本节的反向箭图约定下，它与前述 B 一致。

记 E 为带分次奇偶规则的量子指数。一个完全固定符号的约定是：

```math
\log\mathbb E(-t^jz^n)
 =
 \sum_{k\ge1}
 \frac{(-1)^{j+k(j+1)}t^{k(j+1)}}
 {k(1-t^{2k})}\,z^{kn}.
```

特别地 E(−zⁿ)=Ψ_t(zⁿ)，而简单对象的总 stack 因子为 E(+zⁿ)。这些约定将在后面的 framing 恒等式及 t→1 校准中同时使用。

对 generic stability 的一条射线，实际 integrality 同构给出该射线总因子：

```math
A_{\theta,0}
 =
 \mathbb E\!\left(\sum_{n\parallel\nu}\Omega_n(t)Y^n\right),
\qquad
\Omega_n(t)\in\mathbb N[t^{\pm1}].
```

这里 Ω_n 是经过 rforg 后的实际 BPS 上同调维数多项式。有限型代数几何保证固定 n 的分次有限；不需要纯性，也没有把带符号 Euler 特征“改成”全正系数的形式操作。无环顶点的纯顶点子范畴只有向量空间，因此 Ω_{e_i}=1、Ω_{ke_i}=0（k>1）。

实际 HN 同构给出总元素 A 的各稳定扇区分解。固定根高度 K 时，只有有限多个维数向量及子维数向量参与半稳定条件，故分解在有限超平面分层的扇区内局部常值。通常的群分解与一致散射图对应于是给出一个一致图 D_ss。对任意 generic stability，其局部墙因子都来自上述实际 BPS 对象。

我们需要的正输入方向由反射加取逆得到。对每条墙定义：

```math
\mathfrak D_{\mathrm{aux}}
 =
 \{(-\mathfrak d,A_{\mathfrak d}^{-1}):
       (\mathfrak d,A_{\mathfrak d})\in\mathfrak D_{\mathrm{ss}}\}.
```

这一步直接用路径乘积验证：若 γ 从负象限走向正象限，则 −γ 以同样参数顺序从正象限走向负象限；每次 crossing 的法向符号反转，而墙元素同时取逆，故：

```math
\operatorname{PP}_{\mathrm{aux}}(\gamma)
 =
 \operatorname{PP}_{\mathrm{ss}}(-\gamma)
 =
 A.
```

同样的逐 crossing 等式适用于任意一般路径，因此闭路乘积为 1，一致性得到保留。这里不把 DM Corollary 2.10 误引为同一反对称空间中的反射定理；该推论原文涉及反斜形式空间。当前反射构造的依据就是上面的直接等式。

辅助图在 Bn 附近的 incoming 数据来自原稳定图在 −Bn 附近的数据，可能称为原图的 repeller 数据。因为上同调非负性对所有 generic stability 成立，不需要把两个 attractor 的命名混同。辅助 incoming 因子因此为 E(−Ω_n(t)Yⁿ)，简单 incoming 因子恰为 Ψ_t(Y_i)。

此辅助图一般不同于通常的 refined DT 图，也一般多于簇图的简单 incoming 数据。这里得到的是一个正上界图；并没有从此推出任意势的通常 refined DT 不变量都正，也没有绕过 DM 对簇图量子正性的证明。

## 5. 从 attractor germs 到正 full-plane 输入

此处使用 [Argüz–Bousseau 2102.11200，§3.2，Propositions 3.6、3.8、3.9](https://arxiv.org/pdf/2102.11200)。这些命题在有限正分次且零配对次数彼此交换的 Lie 代数中，将一致散射图与各次数的 attractor 初始数据相对应。我们的根高度截断满足这些条件，再取截断逆极限即可。

固定高度 K。对每个原始法向射线，将辅助图在相应 attractor 附近的 incoming germ 作为整个法向超平面的输入；同一射线的各次数因子彼此交换。这样得到有限个 full-plane 输入，其 KS 完成记为 D_fp。

需要证明 D_fp 与 D_aux 的一致性等价类相同，而不能仅凭“有相同 incoming 名称”就断言相同。先设 Bn≠0，再考虑法向 n 的次数数据。D_fp 的该次数 outgoing 墙按定义不包含 Bn；截断内只有有限多条，所以可在 Bn 附近取法向超平面内的一般点，避开这些 outgoing 墙，并避开所有不平行的输入超平面。此处法向 n 的因子恰是所指定的 incoming germ。AB 的 attractor 数据判定与唯一性因而识别 D_fp 和 D_aux；对每个 K 成立，所以在完成中等价。 此处 AB 的反对称形式取 −nᵀBm，attractor 的列坐标为 Bn。Bn=0 必须由随后给出的中央射线投影论证处理，不能以附近一般点论证替代。

根基方向 Bn=0 需单独核对。该次数与所有根次数交换。若 α+β=kn，则：

```math
\langle\alpha,\beta\rangle
 =
 \langle\alpha,kn-\alpha\rangle
 =
 0.
```

因此 BCH 中任何以该总次数结束的二叉嵌套括号，在最后一步均为零，不会生成新的该次数 outgoing 因子。相应 full-plane 中心输入必须保留；它仍通过主系数格作用于 xᵍ。不能先商掉 B 的核，再试图恢复其对 theta 的影响。

由此，辅助图确实等价于具有非负 BPS Laurent 多项式输入的 full-plane KS 完成。所用的是严格的 attractor 数据重建，未使用未经证明的“任意 incoming 锥可直接替换为全超平面”规则。

## 6. 中心颜色证明额外 incoming 因子的正删除

应用 [Davison–Mandel 1910.12915v3，Theorem 2.15 与 §3、§5](https://arxiv.org/html/1910.12915v3)。该定理允许 full-plane 输入 E(−p(t)zᵛ)，其中 p(t) 的 Laurent 系数非负，并给出正完成及正 broken-line 系数。

为把“删除额外 incoming 因子”变成真正可验证的系数比较，再固定根高度 K。对每一个非简单输入因子赋予独立中心颜色 u_j；所有简单输入不着色。将指数格扩张为：

```math
\widetilde L=L\oplus\mathbb Z^J,\qquad
\widetilde\omega=\pi^*\omega,\qquad
\widetilde v_j=(v_j,e_j).
```

颜色方向处于反对称形式的核。输入墙是原超平面与整个颜色实空间的乘积。KS 完成同样可以取乘积墙：接头及新射线的构造在颜色方向保留整个空间；唯一性识别所得完成。

给定终点及一条投影 broken line，其颜色速度由截至各段所积累的带色次数确定，所以存在唯一的颜色轨迹提升。反过来每条带色 broken line 投影为原 broken line。DM 正性定理因此给出系数位于 N[t^{±1},u₁,…,u_J] 的带色 theta 展开。

将所有 u_j 置零时，每个额外 incoming 因子及由其生成的带正颜色次数项都消失；只剩简单 incoming 图，其唯一完成就是通常的簇散射图。将所有 u_j 置一时，则恢复辅助图。固定根次数内，颜色总次数有根高度的界，故两种代入在完成中都合法。于是逐系数有：

```math
F_g^{\mathrm{cl}}\preceq F_g^{\mathrm{aux}}.
```

这里的上标 cl 表示通常的经典簇 theta 展开；比较在 t=1 后进行。颜色论证实际保留了非负 Laurent t 系数，但本研究只使用经典结论。

若某个 Ω_n 同时含奇、偶上同调次数，仍保持 E(−Ω_nYⁿ) 的完整量子指数形式。其奇次数项可用 DM 的二进制正因子分解处理。若 n=kν 不是原始法向，则墙对 xᵍ 的作用指数包含 n·g=k(ν·g)；改写为原始法向墙函数时必须保留这个 k。不能仅按 Ω_n 的系数遗漏该倍数。第 11 节的真实计算正是针对这些符号和奇偶负担进行独立校准。

## 7. framed HN 给出真正的有限多项式

固定 f≥0，且其支撑包含在已认证有限列中。对源 framing 箭图 Qᶠ_f，仍取 nilpotent Serre 子范畴，并将势 Wᶠ 视为不含 framing 箭的势。记 A_f 为其总上同调级数；只保留 framing 维数为 0 或 1 的部分。

首先令所有原顶点的斜率为 0，∞ 的斜率为 −1。任意 framed 模的整个 unframed 部分是子模，HN 商为 S∞。实际上同调 HN 同构给出：

```math
A_f\equiv A\,\mathbb E(x_\infty)
\pmod{\text{framing degree}\ge2}.
```

再令 ∞ 的斜率为 +1，原顶点仍为 0。维数为 (d,1) 的对象斜率为 1/(1+|d|)。若其存在包含 framing 顶点的真子模，那个子模有更大的斜率；反过来，不包含 framing 的子模斜率为 0。因此该对象稳定当且仅当它由 ∞ 生成，即为 cyclic framed 模。HN 分解的正斜率部分是这个循环生成子模，剩余商是 unframed 模。

以 DM 的虚拟 Tate 及稳定 BPS 归一化，记相应有限 BPS 上同调为 𝓗_{f,d}，并定义 h_{f,d}(t)=χ_t(rforg 𝓗_{f,d})。这一归一化的精确定义是：稳定循环 stack 的实际上同调对象分解为 𝓗_{f,d} 与归一化 H(BGₘ) 的张量积；后者的特征为 u=t/(1−t²)。这是实际对象的张量分解，不是对一个有符号级数作形式除法。因此：

```math
h_{f,d}(t)\in\mathbb N[t^{\pm1}],\qquad h_{f,0}(t)=1,
```

并且第二种 HN 分解给出：

```math
A_f\equiv
 \left(1+u\sum_d h_{f,d}(t)X^{(d,1)}\right)A
 \pmod{\text{framing degree}\ge2}.
```

这里没有隐藏的非平凡 Gₘ gerbe。若在 ∞ 固定一个基，循环 locus 上的 G_d 作用自由：一个保持所有箭及 framing 向量的自同构在生成元上恒等，故在整个模上恒等。原群 G_d×Gₘ 经 (g,λ)↦(λ⁻¹g,λ) 改写后，第二个因子作用平凡，所以稳定 stack 是粗模空间 Z_{f,d} 与 BGₘ 的乘积。势从 Z_{f,d} 拉回，故消失循环和归一化也有上述实际张量分解。

比较两种 HN 等式的 framing 一次项，并约去共同的非零标量 u，得到精确恒等式：

```math
\operatorname{Ad}_{A}(x_\infty)
 =
 \sum_d h_{f,d}(t)X^{(d,1)}.
```

这一步是主证明的承重接口：在两个实际 HN 同构之后取 unsigned 维数；从未把 unsigned χ_t 当作对一般剪切等式可加的 motivic realization。

**有限支撑与闭性。** 每个 nilpotent 循环 Jacobi 模都是有限投射：

```math
P^\flat(f)=\bigoplus_{i\in S}(J^\flat e_i)^{f_i}
```

的商，反之每个这样的商给出该 framing 下的 nilpotent 循环 Jacobi 模。因此 Z_{f,d} 是有限模 Pᶠ(f) 的商模 Grassmannian；在各顶点的普通 Grassmannian 乘积中，箭兼容性为闭条件，故 Z_{f,d} 是射影的。于是 d≤Df，且对偶后 d 是 I(f) 的子模维数。

这里明确控制的是 nilpotent critical 循环 locus。对固定总维数，nilpotence 可用有界长度路径的消失表达为闭条件；有限投射商的描述进一步给出全局射影参数空间，所以不会因选取局部 critical 邻域而漏掉逃逸分支。并不声称未限制 nilpotence 的整个仿射 critical locus 都射影。

消失循环的支撑位于 critical locus，固定 d 的相应代数几何上同调有限；超出 d≤Df 的模空间为空。故上面的和只含有限多个 d，每个系数是有限 Laurent t 多项式。

通过第 3 节的主系数嵌入并作 t=1 专门化，得到：

```math
\operatorname{Ad}_{A}(x^{-f})
 =
 x^{-f}H_f(Y),\qquad
H_f(Y)=\sum_d h_{f,d}(1)Y^d\in\mathbb N[Y].
```

此处左侧的 t=1 记法指上述已证 Laurent 系数作用的经典极限。A 本身含量子分母，不应逐项把 t 代为 1；合法专门化的是其 adjoint 作用及右侧有限 Laurent 系数。

## 8. 负象限无折点引理与普通 theta 的比较

对任意前述中心散射图，令 broken line 的累积根次数为 d≥0。初始为 d=0；每次折点增加一个非负倍数的墙法向。若初始 mutable 指数为 g，则当前 mutable 指数与速度为：

```math
m=g+Bd,\qquad
\gamma'(t)=-(g+Bd).
```

定义沿 mutable 投影的能量 E(t)=dᵀγ(t)。在法向 n 的墙上，n·γ=0，故 d 增加 kn 时 E 连续。每个直线段上：

```math
E'(t)=-d^{\mathsf T}g-d^{\mathsf T}Bd=-d^{\mathsf T}g.
```

如果 g≤0，则 E 非降，而且初始为 0。若终点 Q₋ 的所有 mutable 坐标严格为负，而最终 d≠0，则 E(Q₋)=dᵀQ₋<0，矛盾。因而到达 Q₋ 的 broken line 不发生真正折点：

```math
\vartheta_g(Q_-)=x^g\qquad(g\le0).
```

此论证在每个根高度截断成立，因此也适用于完成 theta 级数。它保留 B 的核，不要求 B 可逆。

由路径不变性以及第 4 节已经校准的 PP_aux(负→正)=A，第 7 节的 framed 恒等式正是：

```math
F_{-f}^{\mathrm{aux}}=H_f.
```

再由中心颜色正删除：

```math
F_{-f}^{\mathrm{cl}}\preceq H_f.
```

对一般 g，写 g=g₊−f。普通簇 theta 的正结构常数定理给出：x^{g₊}θ_{−f} 的 theta 展开包含 θ_g，系数为 1，其余项的初始 Laurent 展开系数非负。准确引用是 [Davison–Mandel，Theorem 1.1](https://arxiv.org/html/1910.12915v3) 的首项系数与正性；使用完整主系数指数，其他项具有正根次数，不能通过冻结单位把它们与首项混淆。

将等式除以 xᵍ，得到：

```math
F_g^{\mathrm{cl}}\preceq F_{-f}^{\mathrm{cl}}\preceq H_f.
```

这证明了主定理。最后由同文 Theorem 1.2(1) 识别经典专门化为 GHKK theta。簇量子 theta 的各系数已知属于 N[t^{±1}]，所以经典专门化的有限支撑也排除了量子支撑在这些次数外的非零项；据此可直接适用 Theorem 1.2(2)，将这里已经有限的 theta 识别为上簇代数元素。这是 theta 函数的专门定理；一般 Laurent 函数仅在一个图表有限，并不能得到同一结论。

## 9. 可复用的基本多项式与 Minkowski 支撑界

对每个已认证有限列，令 H_i=H_{e_i}。同一个路径作用 Ad_A 是代数自同构，而初始 x_i 在主系数量子环中彼此交换。在经典专门化后：

```math
\operatorname{Ad}_A(x^{-f})
 =
 \prod_i\operatorname{Ad}_A(x^{-e_i})^{f_i}
 =
 x^{-f}\prod_i H_i(Y)^{f_i}.
```

与第 7 节的 framed 表达比较，得出严格等式：

```math
H_f=\prod_{i\in S}H_i^{f_i}.
```

所以每个初始图表只需要有限组基本多项式 H_i，就能对所有负支撑落在 S 的标签复用逐项系数界：

```math
F_g\preceq\prod_{i\in S}H_i^{[-g_i]_+}.
```

这也解释了单个任意大 framing 的 H_f 与基本 framing 乘积之间的关系；二者在经典层面确实相等。量子层面的系数乘法应保留相应排序及 t 次数，本节不把经典乘积公式未经调整地搬到量子系数环。

记一个有限模 V 的子维数集合及其多面体为：

```math
S(V)=\{\dim U:U\subseteq V\},\qquad
P(V)=\operatorname{conv}S(V).
```

直和具有标准且精确的离散 Minkowski 机制。若 U⊂V⊕W，则有短正合列：

```math
0\longrightarrow U\cap V
 \longrightarrow U
 \longrightarrow \pi_W(U)
 \longrightarrow0.
```

因此 dim U∈S(V)+S(W)。反过来，任意 U_V⊂V、U_W⊂W 的直和实现维数之和，故：

```math
S(V\oplus W)=S(V)+S(W),\qquad
P(V\oplus W)=P(V)+P(W).
```

应用于 I(f)，得到对所有标签共用的有限集合和有限组多面体：

```math
\operatorname{supp}F_g
 \subseteq
 \sum_{i\in S}[-g_i]_+\,S(I_i),
\qquad
\operatorname{Newt}(F_g)
 \subseteq
 \sum_{i\in S}[-g_i]_+\,P(I_i).
```

右侧首先是有限模可实现维数的候选集合，而不是 theta 的精确支撑。这里不要求每个候选维数的 Euler 特征非零，不宣称 theta 充满所有候选格点，也不由此断言多面体具有 IDP。这一接口从有限模和 theta 正上界独立推出，未借用任何多面体基文章的结论。

## 10. 适用范围、原文定位与查新差异

主定理的当前严格范围是普通箭图的斜对称主系数情形。这里使用上同调 DT 作为证明工具，最后结论及所有上界均为经典 t=1 结论。

负象限能量引理本身可以推广：若 D₀ 是正对角对称化矩阵且 D₀B 反对称，墙法向按 D₀n 约定，则取 E=dᵀD₀γ，仍有 E′=−dᵀD₀g≥0。这个独立组合引理不等于已经建立 valued species 的整条 Jacobi/Hodge 主证明；后者需要另外核实其范畴输入。

对于几何系数，给主系数 y_i 作正 Laurent 单项式代换，必然保留本节已经得到的有限表达式以及相应非负系数比较。把所得表达式进一步识别为目标几何系数模式的 theta 函数，须使用并检查既有 change-of-coefficients 定理，不能只凭“代入后仍有限”就完成识别。mutable pointedness 也不能单独固定冻结单位。

以下定位记录本次实际使用的原文输入及其边界。表中“通过”只指列明的具体接口，不能解读为对整篇文章所有结论的背书。

| 原文 | 定位 | 本节使用或审查结论 |
|---|---|---|
| Davison–Meinhardt, [1601.02479v5](https://arxiv.org/pdf/1601.02479) | Theorems A、B；Corollary 4.13，约 p.43 | 通过：实际上同调 integrality/HN 与 Serre 限制。关键是实际同构，不能退化为一般 scissors 关系。 |
| Davison, [Algebraic Geometry 11 (2024)](https://api.algebraicgeometry.nl/Article/20756/2024-6-023.pdf) | §2.2，pp.765–766 | 通过：rforg 的正合对称幺半性质。forg 不可替代。该文 Theorem 3.8 的对称箭图假设不被移除，本节不用它证明一般箭图的正性。 |
| Argüz–Bousseau, [2102.11200v2](https://arxiv.org/pdf/2102.11200) | §3.2，Propositions 3.6、3.8、3.9 | 通过：有限分次下 attractor 初始数据与一致图的重建和唯一性；本节逐根高度应用。 |
| Davison–Mandel, [1910.12915v3](https://arxiv.org/html/1910.12915v3) | Theorem 2.15；§3、§5；Theorems 1.1、1.2 | 通过：正完成、带色 broken lines、普通 theta 正结构常数、经典识别以及有限 theta 的上簇正则性。 |
| Qin, [Bases for upper cluster algebras and tropical points](https://arxiv.org/pdf/1902.09507) | §6.3 | 任意 generic Jacobi-finite 情形的 weak genteelness 不能当成已证定理。本节不依赖该猜想，也不需要先证明稳定图等于簇图。 |
| GHKK, [Canonical bases for cluster algebras](https://arxiv.org/abs/1411.1394) | Theorem 0.3、Theorem 1.17、Proposition 8.28 等相关构造与有限性条件 | 作为 theta 理论背景。大簇复形等条件下的有限性不能直接改写为“有有限 Jacobi 势即全标签有限”；本节给出的是模列上界机制。 |
| Chen–Mandel–Qin, [2306.04104v2](https://arxiv.org/html/2306.04104v2) | Theorems 1.3、1.4 与引言方向说明 | 覆盖/稳定图识别路线有其假设和例外，未替代本节正上界路线；方向比较必须留意 opposite quiver。 |
| Davison–Maulik–Schürmann–Szendrői, [1307.3379](https://arxiv.org/abs/1307.3379) | Corollary 3.2；Remarks 4.24–4.25 | 已探索的齐次势/纯性分支有用，但当前主证明改用 rforg 与实际 HN，不再需要该额外齐次输入。 |

**2026 年新文的定点强审。** [Fei, Ramified quivers with potentials, monodromy characters, and cluster bases I, 2610.09868v2](https://arxiv.org/html/2610.09868v2) 的相关结果逐项记录如下。

| 精确定位 | 审核结果 | 对本节新颖性及使用方式的影响 |
|---|---|---|
| Lemma 1.5；Proposition 1.8 | 通过所列有限截断机制：闭理想下的逐次代入及全部双边路径倍数判据。 | 本节平台判据是标准机制，不作原创主张；所选行版本同样不单独主张优先权。 |
| 形式势截断的证明段，当前 HTML 行 1532 起 | 已见同样的 d≥r+1 有限 jet 与导数尾项论证。 | 多项式势替代本身亦不作为原创；本节用它保留指定有限行。 |
| §8.3，式 (8.6)–(8.7)；Theorem 8.4 | 逐字核对：theta 有限性先由 seed reachability 与 GHKK Proposition 8.28 得出；Theorem 8.4 仍明确假设 seed reachability、good modulation、Jacobi-finite nondegenerate potential 及 full initial order。 | 不提供当前主定理所需的“无 reachability 的有限 Jacobi 列⇒theta 停止界”。本节不调用该定理。旧记录中的 §8.2 节号在这里校正为 §8.3。 |
| Corollary 8.6 后的比较段 | 原文区分所张成代数的识别与逐个基元素的识别。 | 不把 monodromy characters 与 theta 基逐项等同，也不从前者的 Laurent 性偷换得到后者的有限性。 |

这些定点段落足以排除将已有平台算法重新包装为新结果，但尚不能代替对全部最新文献的外部查新。当前潜在新贡献是以下完整接口：实际 unsigned 上同调因子给出正辅助图；严格 attractor 重建与中心颜色给出簇 theta 的正删除比较；有限循环 framing 给出可计算 Cartan 停止界，并得到 H_f=∏H_i^{f_i} 及共用模多面体上界。新颖性判断仍应围绕这一组合定理进行，不能围绕已知 Nakayama 引理或一般直和 Minkowski 公式进行。

CMMM 的系数专门化工作与 Qin 的基判据仍需按各自原定理的假设用于后续识别。本节明确停留在已经证明的 principal 表达式，不把这些文献的线性无关或拓扑基结论扩大成任意系数下的无条件 Hamel 基断言。

## 11. Wolfram 精确计算：符号、奇偶和非原始次数

以下两次计算在本轮研究中实际调用 Wolfram 计算工具执行，均为精确整数或有理函数运算。它们校准一般代数结构，不替代上面的证明，也不以特殊箭图穷举充当一般机制。

### 11.1 adjoint 经典符号的 616 个精确极限

对 j∈{−5,…,5}、k∈{1,…,8}、κ∈{0,…,6}，检验：

```math
\lim_{t\to1}
\frac{(t^{k\kappa}-t^{-k\kappa})
 (-1)^{j+k(j+1)}t^{k(j+1)}}
 {k(1-t^{2k})}
 =
 \frac{\kappa}{k}
 \begin{cases}
 (-1)^{k+1},&j\text{ 为偶数},\\
 1,&j\text{ 为奇数}.
 \end{cases}
```

因而偶次数对应正二项式因子，奇次数对应 (1−z)⁻¹ 的正级数；后者有二进制分解 ∏_{r≥0}(1+z^{2ʳ})。完整代码：

```wolfram
Module[{tt=Unique["t"], parities, limits},
 parities=Flatten[
   Table[{j,k,h},{j,-5,5},{k,1,8},{h,0,6}],2];
 limits=Table[
   With[{j=q[[1]],k=q[[2]],h=q[[3]]},
    {q,
     Limit[
      (tt^(k h)-tt^(-k h)) (-1)^(j+k (j+1)) tt^(k (j+1))/
       (k (1-tt^(2k))),tt->1],
     h If[EvenQ[j],(-1)^(k+1),1]/k}],
   {q,parities}];
 <|"Cases"->Length[limits],
   "Failures"->Select[limits,#[[2]]=!=#[[3]]&],
   "GeneralFormula"->"lim Ad log EE(-t^j z^n) = pairing * ((-1)^(k+1) if j even, 1 if j odd)/k"|>
]
```

实际返回结果，耗时约 8.9 秒：

```wolfram
<|"Cases" -> 616,
  "Failures" -> {},
  "GeneralFormula" -> "lim Ad log EE(-t^j z^n) = pairing * ((-1)^(k+1) if j even, 1 if j odd)/k"|>
```

κ=0 的中间表达式曾触发 Power::infy 提示；最终每个 Limit 均返回与理论公式一致的精确结果，失败列表为空。这一提示保留在计算记录中，不把它隐藏成没有任何诊断输出的运行。

### 11.2 混合奇偶与多重次数的 37,248 个系数

每组输入取 m=1,…,12 的独立非负整数 a_m、b_m、κ_m，分别控制偶、奇 BPS 次数与作用倍数。比较两个完全不同的系数生成方法：一边由 Adams 对数递推恢复系数，另一边由正二项式及奇项的二进制因子直接卷积。固定随机种子，运行 384 组，次数截断为 96。

```wolfram
Block[{$HistoryLength=0},
 Module[{nmax=96, profiles=384, rng, failures={}, negative=0,
   checked=0, largest=0, conv, a,b,kappa,s,r,m,c,
   lg,f,g,h},
  SeedRandom[271828];
  conv[u_,v_]:=Take[
    ListConvolve[u,v,{1,-1},0],UpTo[nmax+1]];
  Do[
   a=RandomInteger[{0,4},12];
   b=RandomInteger[{0,4},12];
   kappa=RandomInteger[{0,8},12];
   lg=Table[
     Sum[If[Mod[k,m]==0,
       m kappa[[m]] (a[[m]] (-1)^(Quotient[k,m]+1)+b[[m]]),
       0],{m,1,12}],{k,1,nmax}];
   f=ConstantArray[0,nmax+1]; f[[1]]=1;
   Do[f[[k+1]]=Sum[
     lg[[j]] f[[k-j+1]],{j,1,k}]/k,{k,1,nmax}];
   g={1};
   Do[
    c=kappa[[m]] a[[m]];
    If[c>0,
     h=Table[If[Mod[k,m]==0&&k/m<=c,
       Binomial[c,k/m],0],{k,0,Min[nmax,m c]}];
     g=conv[g,h]];
    c=kappa[[m]] b[[m]];
    If[c>0,
     Do[s=m 2^r;
      h=Table[If[Mod[k,s]==0&&k/s<=c,
        Binomial[c,k/s],0],{k,0,Min[nmax,s c]}];
      g=conv[g,h],
      {r,0,Floor[Log[2,nmax/m]]}]],
    {m,1,12}];
   g=PadRight[g,nmax+1]; checked+=Length[f];
   If[f=!=g,AppendTo[failures,rng]];
   negative+=Count[f,_?Negative];
   largest=Max[largest,Max[IntegerLength/@f]],
   {rng,1,profiles}];
  <|"Profiles"->profiles,"DegreeCap"->nmax,
    "ExactCoefficientsChecked"->checked,
    "MismatchProfiles"->failures,"NegativeCoefficients"->negative,
    "MaximumIntegerDigits"->largest,
    "Method1"->"Adams-log recurrence",
    "Method2"->"binary positive binomial factor convolution"|>
 ]]
```

实际返回结果，耗时约 16.4 秒：

```wolfram
<|"Profiles" -> 384,
  "DegreeCap" -> 96,
  "ExactCoefficientsChecked" -> 37248,
  "MismatchProfiles" -> {},
  "NegativeCoefficients" -> 0,
  "MaximumIntegerDigits" -> 47,
  "Method1" -> "Adams-log recurrence",
  "Method2" -> "binary positive binomial factor convolution"|>
```

独立压力检查另对实际 framed 量子递推进行随机无环箭图校准，并由主线程保存其完整代码。非齐次 Markov 势的大规模路径关系证书也由主线程单独保存。本节不将其他线程尚未附在这里的运行细节冒充为本段代码的输出。

## 12. 路线记录和当前证明状态

| 路线或问题 | 处理结果 | 当前作用 |
|---|---|---|
| 直接把 generic Jacobi-finite 当作 weakly genteel | 不可用；原文一般情形仍有猜想边界。 | 已改为正辅助图上界，不再等待图相等。 |
| 先假设额外 attractor 因子可正删除 | 原条件稿不足。 | 本节用 AB 重建与中心颜色给出证明。 |
| 正齐次势、纯性、临界适当性 | 曾形成有条件分支。 | unsigned 实际 HN 取消齐次与纯性假设；nilpotent framed critical 支撑用有限 Quot 全局控制。 |
| 对普通 Hall 剪切式取 unsigned Poincaré 多项式 | 不合法。 | 仅对实际上同调同构应用正合对称幺半 rforg。 |
| 用 forg 代替 rforg | 张量性质不符。 | 已纠正，原文定位保留。 |
| 原图投射 Cartan 与内射 Cartan 混用 | 会在 A₂ 方向校准即出错。 | 本节固定 D_{ji}=dim(e_iJe_j)，反向箭图源 framing。 |
| 把 DM Corollary 2.10 直接说成同空间反射 | 逐字引用不准确。 | 反射与取逆由 crossing sign 的直接等式证明。 |
| 根基次数及冻结单位 | 商掉 B 的核会丢失作用。 | 始终使用完整主系数格，中心 full-plane 输入保留。 |
| 形式势的 finite determinacy | 可用，但不必要。 | 所选行平台加有限 jet 替代即可；机制已有文献，未主张优先权。 |
| 一般 f 需要重新计算所有大 framing | 无此必要。 | 由同一 Ad_A 得 H_f=∏H_i^{f_i}，子模候选集也满足精确 Minkowski 直和公式。 |

本节的证明链已在当前研究轮次中完成并经独立线程逐项压力检查；其外部优先权与更广泛反例搜索继续由后续新线程承担。它解决的是有限 Jacobi 列所覆盖标签的 Laurent 停止与系数、支撑上界，不把这一结果自动扩大为任意强正基的最小性定理。

# 第十八次文献与路线复查（09:05 UTC 窗口）

本轮完成有限 Jacobi 列到经典 theta Laurent 停止界的证明链，并由独立线程重新逐步检验。齐次势、纯性、genteel 与种子可达性均不在最终主定理的假设中。真正新候选是正辅助散射图的严格着色删除与有限 framed 上同调的连接；不是把既有有限截断、HN 分解或无符号 Poincaré 字符重新命名。

| 文献／路线 | 精确核查 | 采用状态 |
|---|---|---|
| Fei 2610.09868v2，Lemma 1.5、Proposition 1.8 | 完备 Nakayama 迭代及有限截断平台已有原文；同文后段也使用有限 jet 替换形式势。自含证明可保留，但不列原创。 | 作为旧标准机制定位；不依赖其2026新主定理 |
| Fei 2610.09868v2，§8.3、式(8.6)–(8.7)、Theorem 8.4 | theta Laurent 有限性先使用 seed reachability 与 GHKK Proposition 8.28。旧摘要误写§8.2，现已纠正。 | 查重通过，未覆盖本轮无可达性 majorant |
| Davison–Meinhardt 1601.02479v5，Theorem A、Corollary 4.13 | 实际分次上同调对象同构，允许 arbitrary polynomial W 与 nilpotent Serre 子类。 | 主证明旧输入；不对 scissors 等式擅取 unsigned 维数 |
| Davison，Algebraic Geometry 11 (2024)，§2.2 | rforg 为正合对称幺半；普通 forg 不是。文章后续 symmetric-Q 定理不被移用于一般 Q。 | 精确使用§2.2 |
| Davison 2502.05009v1，§1、Remarks 1.1–1.2 | 已用 naive cohomological Poincaré series、DM Theorems A/B 的 HN／BPS 分解；因此 unsigned 字符本身不是新发明。 | 新找到的直接旧接口；不把 Markov CoHA 全部认作 spherical |
| Qin 1902.09507v4，§6.3 | injective-reachable 给图相等；generic Jacobi-finite 的 weak-genteel 仍另列猜想。 | 本轮用正上界，未声称两图相等 |
| Fei 1911.10513v6，Remark 6.10、Conjecture 6.11 | nondegenerate Jacobi-finite 背景下仍额外假定 theta Laurent polynomial；Newton 等式的对象是 generic presentation。 | 本轮整个 I(g_−) 的包围多面体不等于证明其 generic Newton 等式 |
| Hua–Zhou 1803.06128v5、Hua–Keller 1909.13517 | finite determinacy 的旧机制可用，但最终证明不需要形式 vanishing-cycle 不变性。 | 不进入主依赖链 |
| Lusztig 2609.01321v2 的取得镜像 | 官方同版本全文本次无法取回。镜像§0.5按实数非负值定义的锥对正实数缩放封闭，§0.8又描述非零加法原子，按字面定义与 f=f/2+f/2 矛盾；A₁中的(t−1)²也阻止把正点值直接认成非负基系数。 | 取得镜像版本标为定义冲突、未采用；不据此概括作者全部工作有误 |
| Tang hexagon:2610.00603v1，Proposition 3.2 | 原文只给 good/perfect 及最高次数导数主项，没有证明完整导数矩阵正性。 | 用于区分后续 Hasse 正性候选的新范围 |
| 任意实际强正基 C 的 D_i 正性 | 仍未证明；源扩张的 theta 特例不自动给任意 C 可扩张。 | 保留为最小性主缺口，不取消已知反面检验 |

主源链接：[Fei 2610.09868v2](https://arxiv.org/html/2610.09868v2)；[Davison 2502.05009v1](https://arxiv.org/html/2502.05009v1)；[DM 1601.02479v5](https://arxiv.org/pdf/1601.02479v5)；[Davison AG 2024](https://api.algebraicgeometry.nl/Article/20756/2024-6-023.pdf)；[Qin 1902.09507v4](https://arxiv.org/pdf/1902.09507v4)；[Fei 1911.10513v6](https://arxiv.org/pdf/1911.10513v6)；[Tang biperfectness](https://hexagonmath.org/pdf/2610.00603v1)。2026 条目在本表仅作查重和适用范围核查，不被未经核验证明地加入主定理。

## 根线程：非齐次势的精确有限截断

取三顶点每边两箭头 a₁,a₂；b₁,b₂；c₁,c₂，势 W=a₁b₁c₁+a₂b₂c₂−a₁b₂c₁a₂b₁c₂。每个完整导数是二次路径减五次路径。对所有左右路径倍数作截断，二项关系用连通分量给出 exact quotient basis；没有将导数的不同齐次部分分开置零，也没有使用浮点秩或有限域偶然秩。以下是实际运行的完整源码。

```wolfram
ClearAll[dimData];
shortCycles={{1,3,5},{2,4,6}};
longCycle={1,4,5,2,3,6};
deriv[cyc_,a_]:=Rest[RotateLeft[cyc,First@FirstPosition[cyc,a]-1]];
bits[path_]:=FromDigits[Mod[path-1,2],2];
rels=Table[With[{sc=First@Select[shortCycles,MemberQ[#,a]&]},
{1+Mod[Ceiling[a/2],3],bits[deriv[sc,a]],bits[deriv[longCycle,a]]}],{a,6}];
idx[start_,len_,num_]:=3(2^len-1)+(start-1)2^len+num+1;
dimData[L_]:=Module[{nn=3(2^L-1),edges,comps,zero,live,meta,cart},
 edges=Flatten[Table[With[{rs=rr[[1]],sbit=rr[[2]],lbit=rr[[3]]},
 Table[With[{v=1+Mod[rs-1-u,3]},
 Table[UndirectedEdge[idx[v,u+2+s,pf 2^(2+s)+sbit 2^s+sf],
 If[u+5+s<L,idx[v,u+5+s,pf 2^(5+s)+lbit 2^s+sf],0]],
 {pf,0,2^u-1},{sf,0,2^s-1}]],{u,0,L-3},{s,0,L-3-u}]],{rr,rels}]];
 comps=ConnectedComponents[Graph[Range[0,nn],edges]];
 live=Select[comps,FreeQ[#,0]&];
 meta=Flatten[Table[Table[ConstantArray[{1+Mod[v-1+l,3],v},2^l],{v,3}],{l,0,L-1}],2];
 cart=ConstantArray[0,{3,3}];
 Do[With[{ij=meta[[First[c]]]},cart[[ij[[1]],ij[[2]]]]++],{c,live}];
 <|"L"->L,"pathColumns"->nn,"relationEdges"->Length[edges],"dimension"->Length[live],"Cartan"->cart|>];
Table[dimData[L],{L,3,12}]
```

实际结果：L=3,…,12 的维数依次为 15,21,27,33,36,36,36,36,36,36；L=7/8 已出现平台，Cartan 精确为 4J₃。最大 L=12 使用 12,285 个路径列、55,302 条关系边。原工具给出 Global symbol L 的静态预解析 warning，但所有数值输出完整、无运行失败；该 warning 与数学秩检验失败不同。一般证明使用任意有限平台，后续多层运行只作这次非齐次程序的校准，不作为一般性证明。

```text
Symbol::undefined2: Warning: Global symbols "L, L, L, L, L, L, L, L, L" are undefined.
General::messages: Messages were generated which may indicate errors.

Out[1]= {<|"L" -> 3, "pathColumns" -> 21, "relationEdges" -> 6, "dimension" -> 15, "Cartan" -> {{1, 2, 2}, {2, 1, 2}, {2, 2, 1}}|>, <|"L" -> 4, "pathColumns" -> 45, "relationEdges" -> 30, "dimension" -> 21, "Cartan" -> {{3, 2, 2}, {2, 3, 2}, {2, 2, 3}}|>, <|"L" -> 5, "pathColumns" -> 93, "relationEdges" -> 102, "dimension" -> 27, "Cartan" -> {{3, 2, 4}, {4, 3, 2}, {2, 4, 3}}|>, <|"L" -> 6, "pathColumns" -> 189, "relationEdges" -> 294, "dimension" -> 33, "Cartan" -> {{3, 4, 4}, {4, 3, 4}, {4, 4, 3}}|>, <|"L" -> 7, "pathColumns" -> 381, "relationEdges" -> 774, "dimension" -> 36, "Cartan" -> {{4, 4, 4}, {4, 4, 4}, {4, 4, 4}}|>, <|"L" -> 8, "pathColumns" -> 765, "relationEdges" -> 1926, "dimension" -> 36, "Cartan" -> {{4, 4, 4}, {4, 4, 4}, {4, 4, 4}}|>, <|"L" -> 9, "pathColumns" -> 1533, "relationEdges" -> 4614, "dimension" -> 36, "Cartan" -> {{4, 4, 4}, {4, 4, 4}, {4, 4, 4}}|>, <|"L" -> 10, "pathColumns" -> 3069, "relationEdges" -> 10758, "dimension" -> 36, "Cartan" -> {{4, 4, 4}, {4, 4, 4}, {4, 4, 4}}|>, <|"L" -> 11, "pathColumns" -> 6141, "relationEdges" -> 24582, "dimension" -> 36, "Cartan" -> {{4, 4, 4}, {4, 4, 4}, {4, 4, 4}}|>, <|"L" -> 12, "pathColumns" -> 12285, "relationEdges" -> 55302, "dimension" -> 36, "Cartan" -> {{4, 4, 4}, {4, 4, 4}, {4, 4, 4}}|>}
```

## 独立线程：framed HN 方向、归一化与有限载体校准

独立审稿重新核对了 twelve-step 主证明链，结论是“按已修正约定未发现剩余缺口，优先权继续深查”。特别修复：同空间反射取逆由 PP_aux(γ)=PP_ss(−γ) 直接证明，不能逐字误引 DM Corollary 2.10；保留 full-principal radical 作用；稳定 framed stack 的 BGₘ 拆分只在实际同构上使用；最终只需 F_g^cl≤F_−g₋^cl≤H_g₋，不额外假设任意辅助 theta 的乘法正性。算法不对无限列声称必停机。

以下代码从 representation-stack 的 A_d(t) 独立解量子共轭递推，再与无环 projective F 的另一递推比较，未用 theta 答案反填。32 个随机箭图，rank 2–6、箭重 1–2、总 root height≤4，共 2,897 个 exact coefficient，其中 2,466 个在 Cartan box 外，全部严格为零；全部 Laurent 正且 t=1 与另一递推相同。初版的 Cancel/Together 和 ReplaceAll 括号错误已纠正，所列是完整重跑通过版本。

```wolfram
ClearAll[t, s, z, st, hp, trunc];
SeedRandom[2026111409];
rootCap = 4;
cases = Table[
  Module[{n = RandomInteger[{2, 6}], a, f},
    a = Table[
      If[i < j && RandomReal[] < 0.6,
        RandomInteger[{1, 2}], 0],
      {i, n}, {j, n}];
    f = UnitVector[n, RandomInteger[{1, n}]];
    If[Mod[c, 5] == 0,
      f = f + UnitVector[n, RandomInteger[{1, n}]]];
    {a, f}],
  {c, 1, 32}];
counts = 0;
fails = {};
supportZeros = 0;
maximumTerms = 0;
Do[
  Module[
    {a = ca[[1]], f = ca[[2]], n, bb, ee, roots, zz,
     hs, ff, cart, bound, val, num, den, rules, cp, ok},
    n = Length[f];
    bb = a - Transpose[a];
    ee = IdentityMatrix[n] - a;
    cart = Inverse[IdentityMatrix[n] - Transpose[a]];
    bound = cart.f;
    roots = Flatten[
      Table[FrobeniusSolve[ConstantArray[1, n], d],
        {d, 0, rootCap}], 1];
    Clear[st, hp];
    st[d_List] := st[d] =
      t^(d.ee.d)/
        Product[
          Product[1 - t^(2 j), {j, 1, d[[i]]}],
          {i, 1, n}];
    hp[ConstantArray[0, n]] = 1;
    hp[d_List] := hp[d] =
      Cancel[Together[
        st[d] t^(-f.d) -
          Total[
            Table[
              If[v === d, 0,
                hp[v] st[d - v]
                  t^(v.bb.(d - v) + f.(d - v))],
              {v, Tuples[Range[0, #] & /@ d]}]
          ]
      ]];
    zz = Array[z, n];
    hs = ConstantArray[1, n];
    trunc[poly_] :=
      Expand[
        Normal[
          Series[poly /. Thread[zz -> s zz],
            {s, 0, rootCap}]
        ] /. s -> 1];
    Do[
      hs[[i]] = trunc[
        1 + zz[[i]]
          Product[hs[[j]]^a[[i, j]], {j, i + 1, n}]],
      {i, n, 1, -1}];
    ff = trunc[
      Product[hs[[i]]^f[[i]], {i, 1, n}]];
    Do[
      val = hp[d];
      num = Numerator[val];
      den = Denominator[val];
      rules = CoefficientRules[num, {t}];
      cp = Fold[
        Coefficient[#1, #2[[1]], #2[[2]]] &,
        ff, Transpose[{zz, d}]];
      ok =
        Length[CoefficientRules[den, {t}]] == 1 &&
        And @@
          (IntegerQ[Last[#]] && Last[#] >= 0 & /@ rules) &&
        (den /. t -> 1) == 1;
      ok = TrueQ[ok] &&
        TrueQ[(val /. t -> 1) == cp] &&
        (And @@ Thread[d <= bound] || val === 0);
      counts++;
      maximumTerms = Max[maximumTerms, Length[rules]];
      If[Not[And @@ Thread[d <= bound]], supportZeros++];
      If[!ok, AppendTo[fails, {a, f, d, val, cp, bound}]],
      {d, roots}]
  ],
  {ca, cases}];
<|
  "quivers" -> Length[cases],
  "rootHeight" -> rootCap,
  "rankRange" -> MinMax[Length[#[[2]]] & /@ cases],
  "exactQuantumCoefficients" -> counts,
  "outsideCartanBoundZeroChecks" -> supportZeros,
  "largestCoefficientTermCount" -> maximumTerms,
  "allPass" -> (fails === {}),
  "failures" -> Take[fails, UpTo[5]]
|>
```

```text
<|"quivers" -> 32, "rootHeight" -> 4, "rankRange" -> {2,6}, "exactQuantumCoefficients" -> 2897, "outsideCartanBoundZeroChecks" -> 2466, "largestCoefficientTermCount" -> 7, "allPass" -> True, "failures" -> {}|>
```

当前下一条一般机制是 classical theta 的全阶系数 Hasse 正性：源顶点代换、正乘法切片和大源标签的有限高度稳定化。固定根预算可以不预设 Laurent 有限；新独立代理已被分派审查。它和任意实际强基最小性之间尚有真实差距，不能用新性质的数量遮盖该差距。

# 经典 theta 的全阶系数 Hasse 正性：完整形式版本

本节记录 2026-11-14 09:20–09:50 UTC 完成的证明。只讨论经典丛代数。主证明、独立反向审核均通过；冰箭图推广另由新独立代理继续强审。这里不声称任意强正基保持该算子，也不以此宣布 theta 对任意强正基的最小性。

## 主系数定理

令 $B$ 为任意斜可对称交换矩阵，$D=\operatorname{diag}(d_i)$ 为正整数对称化子。取主系数初始变量 $x_i,y_i$，并令 $z_i=y_i x^{Be_i}$。在根次数完成中写

$$\theta_g=x^gF_g(z),\qquad F_g(z)=\sum_{a\in\mathbb N^n}c_g(a)z^a,\qquad c_g(a)\in\mathbb N,\quad c_g(0)=1.$$

定义整除幂 Hasse 算子

$$D_j^{[r]}=\frac{x_j^r}{r!}\frac{\partial^r}{\partial y_j^r},\qquad r\ge0.$$

则存在唯一的非负整数 $a_{g,j,r}(q)$，使得

$$D_j^{[r]}\theta_g=\sum_{q\in\mathbb N^n}a_{g,j,r}(q)y^q\theta_{g+r(e_j+Be_j)+Bq}.$$

右侧按根次数局部有限。定理不要求无环性、reddening、Jacobi 有限性、genteel 性或预先知道 $\theta_g$ 是 Laurent 多项式。若输入 theta 有限，则右侧只有有限个非零项，且所有实际出现的 theta 也有限。

令 $\Theta_{\mathrm{fin}}$ 为有限 theta 的标签集。未倒置主系数的代数

$$A_\theta^+=\bigoplus_{g\in\Theta_{\mathrm{fin}}}\mathbb Z[y]\theta_g$$

及其 $\mathbb N[y]$ 正锥被这些 Hasse 算子保持。$D_j=x_j\partial_{y_j}$ 两两交换，且在 $A_\theta^+$ 上局部幂零。因此

$$f(x;y+s x)=\sum_{\nu\in\mathbb N^n}s^\nu D^{[\nu]}f$$

定义整数上的正 $\mathbb G_a^n$ 作用。对无限形式 theta，代换在 $(y,s)$-adic 完成中理解。不能把 $s$ 当作固定非零常数后仍声称代换在原来的 $y$-adic 拓扑中连续。

系数倒置后的整个 mid 代数不享有这一正性或局部幂零断言。例如 $D_j(y_j^{-1})=-x_jy_j^{-2}$。这一边界是定理的一部分。

## 证明一：正源扩张恒等式

加一个源顶点 $s$，令源变量为 $t$，新主系数为 $\eta$，扩张矩阵为

$$B^{\mathrm{ext}}=\begin{pmatrix}0&-p\\ b&B\end{pmatrix},\qquad p,b\ge0.$$

取合法的斜可对称扩张，即 $d_s p_j=d_jb_j$。记 $M=x^b$，$Y_j=y_jt^{-p_j}$。前面已经证明的单向块形式 gluing 适用于任意核心标签 $g$，给出

$$\theta^{\mathrm{ext}}_{(0,g)}
=\theta_g\bigl(x;Y_j(1+\eta M)^{p_j}\bigr).$$

扩张 theta 的强正乘法产生根次数局部有限展开

$$t^N\theta^{\mathrm{ext}}_{(0,g)}
=\sum_{a,c}m^N_{a,c}\eta^a y^c
\theta^{\mathrm{ext}}_{(N-p\cdot c,\ g+ba+Bc)},\qquad m^N_{a,c}\in\mathbb N.$$

这里标签由主次数确定；特别是源坐标为 $N-p\cdot c$，不能把它统一替换为 $N$ 后直接引用稳定化。

## 证明二：不预设有限性的有限根预算稳定化

固定根预算 $L$。设扩张 broken line 的总根次数不超过 $L$，累计根为 $d(v)\ge0$，$|d(v)|\le L$。其终点 $Q$ 位于正室，源标签为 $N$、核心标签为 $h$。对任何可能含源的实际整数弯折根 $\delta$，有 $\delta_s\ge1$，$|\delta|\le L$。必须使用实际弯折根；在斜可对称情形不能不经缩放就混用 primitive normal。

令 $D^{\mathrm{ext}}=\operatorname{diag}(d_s,D)$，$d_{\max}=\max_i d_i$，$C=\max|D^{\mathrm{ext}}B^{\mathrm{ext}}|$。沿任一线段，

$$\delta^TD^{\mathrm{ext}}\bigl((N,h)+B^{\mathrm{ext}}d(v)\bigr)
\ge d_sN-Ld_{\max}\|h\|_\infty-L^2C.$$

若右侧严格正，则由

$$\gamma(\tau)=Q+\int_\tau^0\bigl((N,h)+B^{\mathrm{ext}}d(v)\bigr)\,dv$$

可得 $\delta^TD^{\mathrm{ext}}\gamma(\tau)>0$。因此该线不可能在含源的墙上弯折。剩下的墙是纯核心墙；它们的柱状提升、broken line 的投影与唯一提升都保持系数。于是

$$\theta^{\mathrm{ext}}_{(N,h)}
\equiv t^N\theta_h(x;Y)\pmod{\text{根次数}>L}.$$

要取源次数 $r$，并在后续除以 $Y_j^r$ 后保留核心根高度至 $K$，可以统一使用 $L=K+2r$。仅需考虑 $a+|c|\le L$ 的输出；令

$$H=\max_{a+|c|\le L}\|g+ba+Bc\|_\infty.$$

选择

$$N>L\|p\|_\infty+\frac{Ld_{\max}H+L^2C}{d_s}$$

即可同时控制所有输出标签 $N-p\cdot c$。这个上界只依赖固定窗口中的有限数据，避免了先选择 $N$、再由依赖 $N$ 的输出集合反选 $N$ 的循环。

## 证明三：取源系数、正除法与唯一性

稳定化后，将 $y^c=t^{p\cdot c}Y^c$ 代回并除去 $t^N$，在任意固定根窗口得到

$$\theta_g\bigl(x;Y_j(1+\eta M)^{p_j}\bigr)
=\sum_{a,c}m^N_{a,c}\eta^aY^c\theta_{g+ba+Bc}(x;Y).$$

取 $\eta^r$，得到加权 Euler 算子

$$H_r=M^r\binom{E_p}{r},\qquad E_p=\sum_jp_jY_j\partial_{Y_j}$$

对 theta 的非负展开。现在取 pendant 扩张 $p=b=e_j$，并取 $d_s=d_j$。此时 $M=x_j$，且

$$H_r=Y_j^rD_j^{[r]}.$$

左侧整体被 $Y_j^r$ 整除。右侧每个 $Y^c\theta_h$ 都有系数为一的首项 $Y^cx^h$，全部 Laurent 系数非负。因此任何实际出现的输出必须满足 $c_j\ge r$；否则其首项不可能抵消。令 $q=c-re_j$ 并除以 $Y_j^r$，便得到定理中的标签公式和非负系数。

固定总主次数 $m$ 时，

$$Y^q\theta_{m+Bq}=x^mz^qF_{m+Bq}(z)$$

相对于根总次数是单位三角族。故每一个有限窗口的展开系数唯一，并且不同 $K,N$ 得到的系数相容。这证明完整形式展开，而非只证明每个截断各有某个正表达式。

若输入有限，则左侧只有有限 Laurent 支撑。右侧非负且每项有不同根次数首项，所以非零输出个数有限。任何一个无限 theta 输出又会带入无限支撑，不能抵消，因此每个输出也有限。Leibniz 公式及 $x_j$ 为丛单项式将结论扩展到 $A_\theta^+$。

## 精确 Laurent 支撑、系数不等式与边界

对任意多指标 $\nu$，

$$D^{[\nu]}\theta_g=
x^{g+\nu+B\nu}
\sum_{a\ge\nu}c_g(a)\left(\prod_j\binom{a_j}{\nu_j}\right)z^{a-\nu}.$$

因此其根支撑准确等于

$$\{a-\nu:a\in\operatorname{Supp}F_g,\ a\ge\nu\}.$$

这不是只对 Newton 顶点的包含关系。每个正 theta 输出 $y^q\theta_h$ 的平移支撑 $q+\operatorname{Supp}F_h$ 都包含于上述精确截取支撑中。

单根面有 $c_g(re_j)=\binom{[-g_j]_+}{r}$。于是对 $0\le r\le[-g_j]_+$，置 $h=g+r(e_j+Be_j)$，比较首输出的 Laurent 系数得

$$\binom{a_j+r}{r}c_g(a+re_j)
\ge \binom{[-g_j]_+}{r}c_h(a),\qquad a\ge0.$$

只沿该首输出反复点火所得的无限支撑障碍已被相邻种子的二项式正整除机制蕴含，不能作为新的 Laurent 判据。完整 theta 展开的非首项正性仍需另行研究，不能用首项推论替代最小性。

## 独立 Wolfram 全展开核验

独立代理从 LLZ greedy 递推生成精确秩二 $F$-多项式，不使用待证源公式生成答案。秩二 greedy=theta 用 Cheung–Gross–Muller–Musiker–Rupel–Stella–Williams, arXiv:1508.01404。$B=\left(\begin{smallmatrix}0&-b\\c&0\end{smallmatrix}\right)$ 可逆，所以主次数确定齐次提升。

实际核验 $b,c=1,\ldots,4$，$g_1,g_2=-4,\ldots,2$，方向 $j=1,2$，阶数 $r=1,2,3$。共 4,704 个完整展开；2,664 个导数非零；4,835 个正 theta 项；最大 theta 系数 2,240；最大导数单项式支撑 60；负系数和非零最终余式均为 0。以下保留实际执行代码。

```wolfram
ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=ff[bb,cc,gg1,gg2]=Module[
{aa2=-gg2,aa1,ppmax,qqmax,ee,pp,qq,kk},
aa1=bb Max[aa2,0]-gg1;ppmax=Max[aa2,0];qqmax=Max[aa1,0];
ee=ConstantArray[0,{ppmax+1,qqmax+1}];ee[[1,1]]=1;
Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]]nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]]nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],
{pp,0,ppmax},{qq,0,qqmax}];
Expand[Sum[ee[[pp+1,qq+1]]z1^qq z2^(ppmax-pp),
{pp,0,ppmax},{qq,0,qqmax}]]];
checks=0;nonzero=0;positiveTerms=0;fails={};maxCoeff=0;maxSupport=0;
Do[Module[{f=ff[bb,cc,g1,g2],poly,base,rr,box,q,coef,h,neg=False},
poly=Expand[D[f,{If[jj==1,z1,z2],ord}]/Factorial[ord]];checks++;
If[poly=!=0,nonzero++;
base={g1,g2}+If[jj==1,{ord,cc ord},{-bb ord,ord}];rr=poly;
box=SortBy[Tuples[{Range[0,Exponent[poly,z1]],Range[0,Exponent[poly,z2]]}],{Total,First}];
Do[coef=Coefficient[Coefficient[rr,z1,q[[1]]],z2,q[[2]]];
If[coef<0,neg=True;AppendTo[fails,{bb,cc,{g1,g2},jj,ord,q,coef}];Break[]];
If[coef>0,positiveTerms++;maxCoeff=Max[maxCoeff,coef];
h=base+{-bb q[[2]],cc q[[1]]};
rr=Expand[rr-coef z1^q[[1]]z2^q[[2]]ff[bb,cc,h[[1]],h[[2]]]]],{q,box}];
If[!neg&&rr=!=0,AppendTo[fails,{"residual",bb,cc,{g1,g2},jj,ord,rr}]];
maxSupport=Max[maxSupport,Length[CoefficientRules[poly,{z1,z2}]]]]],
{bb,1,4},{cc,1,4},{g1,-4,2},{g2,-4,2},{jj,1,2},{ord,1,3}];
<|"bRange"->{1,4},"cRange"->{1,4},"headBox"->{-4,2},"orders"->{1,3},
"exactChecks"->checks,"nonzeroDerivatives"->nonzero,"positiveThetaTerms"->positiveTerms,
"largestThetaCoefficient"->maxCoeff,"largestDerivativeMonomialSupport"->maxSupport,
"failures"->Length[fails],"firstFailure"->Take[fails,UpTo[1]]|>
```

# 直接冰箭图版本：优化冻结变量的全阶正导数

令 $\widetilde B$ 为满列秩、可变部分斜对称的 ice 交换矩阵。固定一个冻结变量 $f$，假设其行

$$p_j=\widetilde B_{f,j}\ge0.$$

记 $M_f=\prod_{j\text{ mutable}}x_j^{p_j}$，$\widetilde p$ 为仅在可变坐标上等于 $p$ 的全标签向量。theta 标签包括冻结坐标。写

$$\theta_g=X^g\sum_{d\ge0}c_g(d)z^d,\qquad z=X^{\widetilde B},\qquad a_0=g_f.$$

因为 $p\ge0$ 且首项系数为一，$\theta_g$ 关于 $f$ 为多项式当且仅当 $a_0\ge0$。定义

$$\delta_f^{[r]}=\frac{M_f^r}{r!}\partial_f^r.$$

则对 $a_0\ge0$ 的 theta，有形式根局部有限正展开

$$\delta_f^{[r]}\theta_g
=\sum_{c\ge0}A_{g,r}(c)\,
\theta_{g+r\widetilde p+\widetilde Bc-re_f},
\qquad A_{g,r}(c)\in\mathbb N,$$

且每个实际出现的输出满足 $a_0+p\cdot c-r\ge0$。有限输入产生有限个有限输出。有限、$f$-多项式 theta 的整数线性包络为子代数，正锥被 $f\mapsto f+sM_f$ 保持。

这里直接在 ice 散射图上证明；没有调用未经证明的 theta 系数分离公式，也没有把任意系数 theta 当作 Fomin–Zelevinsky 变量分离公式的自动推论。当前定理只声明该斜对称 ice 版本；对负冻结行和一般 valued ice 的推广均不默许。

## 直接证明

加一个可变源 $s$、变量 $t$，使 $B_{s,j}=-p_j$、$B_{j,s}=p_j$；旧冻结顶点到新源的矩阵项取零。再加新冻结 $\eta$，其在源列为一、其他列为零。新增 $\eta$ 行先迫使任意列关系的新源系数为零，再由旧满列秩得扩张仍满列秩。

令 $I=(1+\eta M_f)/t$。源标签必须取 $-a_0$。单向块 gluing 给出

$$L_g:=\theta^{\mathrm{ext}}_{(-a_0,g)}
=I^{a_0}X^g\sum_dc_g(d)(zI^p)^d
=\theta_g\left(f\mapsto\frac f t(1+\eta M_f)\right).$$

强正乘法为

$$t^NL_g=\sum_{a,c}m^N_{a,c}\eta^a
\theta^{\mathrm{ext}}_{(K,h)},\qquad m^N_{a,c}\in\mathbb N,$$

其中

$$K=N-a_0-p\cdot c,\qquad
h=g+a\widetilde p+\widetilde Bc,\qquad
h_f=a_0+p\cdot c,\qquad K+h_f=N.$$

应用前面的有限根稳定化。须保留冻结变量重新标度造成的幂：

$$\theta^{\mathrm{ext}}_{(K,h)}
=t^{K+h_f}\theta_h(f/t)$$

在指定根预算内成立；错误的 $t^K\theta_h(f/t)$ 会破坏后面的证明。

置 $F=f/t$，这是 Laurent 环中的可逆单项式坐标变换。除去 $t^N$ 后，

$$\theta_g(F(1+\eta M_f))
=\sum_{a,c}m^N_{a,c}\eta^a
\theta_{g+a\widetilde p+\widetilde Bc}(F).$$

固定 $\eta$ 次数 $r$ 与核心根预算 $K_0$ 时，只需总根预算 $L=r+K_0$；除以 $F^r$ 只改变冻结头，不另增加根次数。稳定化阈值对有限的 $(a,c)$ 统一选取，方法与主系数证明相同。

取 $\eta^r$ 得

$$M_f^rF^r\partial_F^{[r]}\theta_g
=\sum_c m^N_{r,c}\theta_{g+r\widetilde p+\widetilde Bc}(F).$$

左边被 $F^r$ 整除。右边每项最低 $F$ 次数正好是其头 $a_0+p\cdot c$，其余系数非负，故实际出现时必有 $a_0+p\cdot c\ge r$。除以 $F^r$ 等于将冻结标签减去 $re_f$，证明正展开。单位三角性保证各预算相容；有限性由无抵消得到。

若多个冻结行都非负，则相应 $M_f$ 只含可变变量，各 $\delta_f$ 两两交换，得到多参数正加法群作用。

## 加权半空间截取的精确公式

直接微分给出

$$\delta_f^{[r]}\theta_g
=X^{g+r\widetilde p-re_f}
\sum_dc_g(d)\binom{a_0+p\cdot d}{r}z^d.$$

所以该输出的根支撑准确等于

$$\{d\in\operatorname{Supp}F_g:a_0+p\cdot d\ge r\}.$$

这给一个一般的正 theta 分解机制：把根支撑按任意非负冻结行的整值半空间截去低层，再以二项式系数赋权，可分解为 theta 支撑的平移并。每个实际输出满足

$$c+\operatorname{Supp}F_{g+r\widetilde p+\widetilde Bc-re_f}
\subseteq
\{d\in\operatorname{Supp}F_g:a_0+p\cdot d\ge r\}.$$

它不保证这些平移支撑互不相交，也不自动推出整数分解性质、支撑饱和或任意强正基最小性。

## 根线程独立计算

根线程实际调用 Wolfram，用 LLZ 完整递推而非待证公式生成 theta。随机种子固定；512 个精确案例，斜对称秩二参数 $b=1,\ldots,5$，头坐标 $-6,\ldots,3$，冻结行各分量 $0,\ldots,3$，$a_0=0,\ldots,4$，Hasse 阶数 $1,\ldots,6$。取 ice 行 $[B;I;p]$，比较每个 theta 输出对应的冻结头 $a_0+p\cdot c-r$。

实际结果：397 个非零输出；5,011 个正 theta 项；最大系数 6,284,387,978,064；负冻结头 0；负 theta 系数 0；全部最终余式为 0；总失败 0。运行约 8.9 秒。以下是实际执行代码。

```wolfram
ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=ff[bb,cc,gg1,gg2]=Module[{aa2=-gg2,aa1,ppmax,qqmax,ee,pp,qq,kk},
aa1=bb Max[aa2,0]-gg1;ppmax=Max[aa2,0];qqmax=Max[aa1,0];ee=ConstantArray[0,{ppmax+1,qqmax+1}];ee[[1,1]]=1;
Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]] nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]] nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],{pp,0,ppmax},{qq,0,qqmax}];
Expand[Sum[ee[[pp+1,qq+1]] z1^qq z2^(ppmax-pp),{pp,0,ppmax},{qq,0,qqmax}]]];
SeedRandom[202611140941];
testCases=Table[With[{bb=RandomInteger[{1,5}],gg=RandomInteger[{-6,3},2],pp=RandomInteger[{0,3},2],aa=RandomInteger[{0,4}],rr=RandomInteger[{1,6}]},{bb,gg,pp,aa,rr}],{512}];
checks=0;nonzero=0;terms=0;maxCoefficient=0;failures={};lowFrozenHeads=0;
Do[Module[{bb=ca[[1]],g=ca[[2]],p=ca[[3]],a0=ca[[4]],r=ca[[5]],f,poly,rem,box,base,coef,h,q,bad=False},
f=ff[bb,bb,g[[1]],g[[2]]];
poly=Expand[Total[(Last[#] nn[a0+p.First[#],r] z1^First[#][[1]] z2^First[#][[2]])&/@CoefficientRules[f,{z1,z2}]]];
checks++;
If[poly=!=0,nonzero++;rem=poly;base=g+r p;box=SortBy[Tuples[{Range[0,Exponent[poly,z1]],Range[0,Exponent[poly,z2]]}],{Total,First}];
Do[coef=Coefficient[Coefficient[rem,z1,q[[1]]],z2,q[[2]]];
If[coef<0,AppendTo[failures,{"negative",ca,q,coef}];bad=True;Break[]];
If[coef>0,terms++;maxCoefficient=Max[maxCoefficient,coef];
If[a0+p.q-r<0,lowFrozenHeads++;AppendTo[failures,{"negativeFrozenHead",ca,q,a0+p.q-r}]];
h=base+{-bb q[[2]],bb q[[1]]};rem=Expand[rem-coef z1^q[[1]]z2^q[[2]]ff[bb,bb,h[[1]],h[[2]]]]],{q,box}];
If[!bad&&rem=!=0,AppendTo[failures,{"residual",ca,rem}]]]],{ca,testCases}];
<|"cases"->checks,"nonzero"->nonzero,"positiveThetaTerms"->terms,"maxCoefficient"->maxCoefficient,"negativeFrozenHeads"->lowFrozenHeads,"failures"->Length[failures],"firstFailure"->Take[failures,UpTo[1]]|>
```

# 第十九、二十次文献与路线复查：09:25、09:45 UTC 窗口

本轮分别处理新文献与旧结果覆盖范围；不能将读到一个摘要等同于采用定理。原文核对及失败路线都保留，后续最终总包应合并去重。

| 文献 | 本轮实际核对 | 采用或排除 |
|---|---|---|
| Fan Qin, Applications of the freezing operators on cluster algebras, arXiv:2407.03186v1, §§6.3–6.4 | Property (S)、Lemma 6.15、Prop. 6.16、Theorem 6.17、Prop. 6.19 及证明 | 大标签稳定化、冻结/局部化归属旧工作。6.17 需要指定基与冻结因子性质；6.19 明确假设输入 theta Laurent 有限。本文只使用同一几何估计的有限根预算形式，不把它单独当新定理。 |
| Jia-Rui Fei, Crystal structures of upper cluster algebras, arXiv:2309.08326v4, §8.1, Prop. 8.1 | 优化冻结变量的导子与局部幂零接口 | 导子及局部幂零本身旧。待比较的是对整个 theta 基、每一 Hasse 阶、包括无限形式 theta 的非负矩阵。 |
| Qiyue Tang, hexagon:2610.00603v1, Prop. 3.2 | good/perfect 基的最高非零导数控制 | 已有最高层性质不等于所有中间导数完整基展开正性；不混用。 |
| Reading–Stella, Mutation of theta functions, SIGMA 22 (2026), 109, published 2026-11-08 | 原 PDF pp.33–35，Theorems 5.14、5.19、5.20 及证明 | 强审后采用其精确参数化边界。5.14 假设元素位于 small canonical，系数可有符号，索引集合为所有变异约束的交；不能读成普遍正性或任意 strong basis 的 theta 最小性。 |
| Qiyue Tang, hexagon:2610.00025v3 | 量子秩二有限 jet 论证 | 关键依赖负量子次数及 bar 对称；不能将参数置一后视为经典任意强基证明。 |
| Ben Davison, arXiv:2502.05009v1, Remarks 1.1–1.2 | naive Poincaré series 的既有角色 | 无符号上同调正性作为独立思想不是新发现；有限 Jacobi theta 定理的候选新点是其与颜色删除、有限 framed majorant 的完整连接。 |
| Lee–Li–Zelevinsky, arXiv:1208.2391v3, §2 Lemma 2.1 | 相邻种子展开的负二项式变换与非负性 | 合法点火支撑增长已被相邻正整除包含；关闭其作为新 Laurent 障碍的申报。 |
| Lê–Thurston–Yu, arXiv:1908.05775, Theorem 2.4 | 经典 skein 中以单交叉曲线乘法读出 Chebyshev 展开系数的接口 | 活动代理继续检查可否提炼一般 cluster 乘法探针。现阶段只对 polynomial-threaded 基成立，不能当所有 strong basis 定理。 |

主要原文链接：

- https://arxiv.org/html/2407.03186v1

- https://arxiv.org/abs/2309.08326

- https://hexagonmath.org/pdf/2610.00603v1

- https://sigma-journal.com/2026/109/sigma26-109.pdf

- https://hexagonmath.org/pdf/2610.00025v3

- https://arxiv.org/abs/2502.05009

- https://arxiv.org/abs/1208.2391

- https://arxiv.org/abs/1908.05775

## 合法点火路线的关闭记录

令 $A=I+B$，合法字每一步在当前头 $h_j<0$ 时把头变为 $h+Ae_j$。若总次数为 $\alpha$，各步负头的乘积为 $P(w)$，Hasse 正性推出

$$\alpha!c_g(\alpha)\ge P(w)>0.$$

但是，对于假设有限且在普通相邻种子 Laurent 正的候选，固定其余根次数后已经有

$$C(T)=(1+T)^NQ(T),\qquad Q(T)\in\mathbb N[T],\quad
N=[-g_j-(B\alpha)_j]_+.$$

由二项式系数比可得合法时

$$(\alpha_j+1)c_g(\alpha+e_j)\ge
[-g_j-\alpha_j-(B\alpha)_j]c_g(\alpha),$$

迭代正好恢复同一阶乘下界。无限合法字由此排除有限 Laurent 性，但这不是新的 Hasse 特有障碍。反向逻辑不成立，例如 $N=1,C(T)=1+2T$ 满足首条下界却不被 $1+T$ 整除。

独立实际 Wolfram 核验 1,225 个秩二标签/矩阵组合、27,185 个根格点、16,995 个合法状态、16,101 条相邻 slice 不等式，失败为 0。循环三点矩阵校准 $m=4,\ldots,20$ 全通过。其作用只是核对符号与关闭路线，不追加特殊家族结果。

完整 Hasse 非首项若 $a_{g,j}(q)>0$，则有限输入强迫对应输出 theta 有限。这是有效推论；尚缺一般有用非首项的结构定理和标签跳转规律。仅把它做搜索程序不构成一般 Laurent 判定突破。

## 活动路线与尚存缺口

一般 Laurent 有限性已有“有限 Jacobi 列—无符号 framed majorant—正删除”的充分条件，以及单向块有限性传递。它们不构成任意交换矩阵的统一充要判据。任意实际强正基的最小性仍开放于本项目：实际基的丛单项式乘法支撑上界能排除若干普遍 Laurent 正反例，但尚未证明它们分离全部负 theta 修正。两个代理分别继续研究正源扩张的必要凸性，以及所有阶正乘法矩阵对有符号基变换的约束。未把这些条件当作已证结论。

09:26 UTC 再次尝试原生执行器，仍返回 no usable execution environment；因此本轮完整证明及计算代码先在本阶段页保存。最终 ZIP 尚未制作，待执行器恢复后合并旧的第 5 版阶段 ZIP 与此页，按用户指定名称提交。研究继续至 15:01:18 UTC；不以保存阶段文档代替继续研究。

# 单枚有限 theta 的唯一最大 F-单项式与反向公式

本节记录 10:05–10:25 UTC 窗口形成的一般结论。第一代理提出证明，第二代理逐项敌对核对 CMMM 原文后通过，root 另核其 Theorem 5.19 证明中式 (31) 后的极限步骤。结论只针对经典主系数、斜对称化种子。它是从 CMMM 的已有 tautness 与 reciprocity 技术推出的推论；不把 reciprocity、顶点首一性或丛变量的最大单项式性质申报为新结果。

## 定理与精确公式

设 \(B\) 为整数斜对称化矩阵，\(D=\operatorname{diag}(d_1,\ldots,d_n)\) 为正整数对角矩阵，\(DB\) 斜对称。写
\[
\theta_g^B=x^gF_g^B(z),\qquad z_i=y_i x^{Be_i}.
\]
只假设这一枚 \(\theta_g^B\) Laurent 有限。反向种子的基本形式 theta 级数记为
\[
H_i^{\mathrm{op}}=F_{-e_i}^{(-B)}.
\]
则
\[
L_i(g)=\max_{a\in\operatorname{Supp}H_i^{\mathrm{op}}}(-(Dg)\cdot a)
\]
有限，而且
\[
\boxed{f_i(g)=L_i(g)/d_i\in\mathbb N.}
\]
向量 \(f(g)\) 是 \(F_g\) 支撑的唯一分量最大点：
\[
\operatorname{Supp}F_g\subseteq[0,f(g)],\qquad
f(g)\in\operatorname{Supp}F_g,\qquad [z^{f(g)}]F_g=1.
\]
因此对所有非负实权 \(w\)，
\[
\max_{a\in\operatorname{Supp}F_g}w\cdot a=w\cdot f(g).
\]
这里反向 \(H_i^{\mathrm{op}}\) 可以整体无限，只断言其在指定方向 \(-Dg\) 上有有限最大值。

## 证明：先补足有限性，再用双边 reciprocity

取完整主系数格，令
\[
P=\binom BI,\quad Q=\binom I0,\quad
\Lambda=\begin{pmatrix}0&D\\-D&DB\end{pmatrix}.
\]
有 \(\Lambda P=QD\)、\(\Lambda^TP=-QD\)。按 CMMM 的 rational \(\Lambda\)-structure 约定选相应有限指数格即可；这里 \(Q^\bullet=QD\)，其对角参数对应 \(D^{-1}\)。所有赋值均在完整格上计算，不能丢掉冻结坐标。

令 \(b=(g,0)\)、\(m_0=(1,\ldots,1;0)\)。输入有限使
\[
A=\operatorname{val}_{\Lambda m_0}(\theta_{b,+})
\]
为有限数。取正室中足够靠近 \(m_0\) 的一般点 \(q\)，并选择与 \(m_0\) 相邻的同一赋值线性域。CMMM Lemma 5.17 的非一般点版本给出一条从 \(b\) 到 \(q\)、同时实现此最小值且 \(\Lambda^T\)-taut 的 broken line \(\beta\)。若终指数为 \(u\)，则
\[
A=u\cdot\Lambda m_0=m_0\cdot\Lambda^Tu.
\]
由于 \(m_0,q\) 均在正室，\(\theta_{m_0,q}=X^{m_0}\)，所以
\[
\operatorname{val}_{\Lambda^Tu}(\theta_{m_0,q})=A
\]
是等式。沿 \(\beta\) 反向使用 Lemma 5.15 的 taut constancy；Lemma 5.16 给出一个不依赖沿线参数的有限根截断，保证取 \(t\to-\infty\) 时实现最小值的项不会逃向无限阶；随后用 Lemma 5.17 的负室版本（Remark 5.18），得到
\[
\operatorname{val}_{\Lambda^Tb}(\theta_{m_0,-})=A.
\]
此步骤正对应 CMMM Theorem 5.19 证明的 1692–1696 行；原证明还明确讨论可能为 \(-\infty\) 的情形，因此此处没有预设负室赋值有限。原证明前一步只得不等式，是因为一般 \(m_1\) 的局部 theta 可有多个项；这里正室单项式使该处成为等式。不能把此特殊论证误写成删除 CMMM 一般双边有限条件。

散射输运保乘法，所以
\[
\theta_{m_0,-}=\prod_i\theta_{(e_i,0),-}.
\]
各因子非零且系数非负。乘积赋值有限，强制每个因子的同方向赋值有限：若某因子无下界，固定其他因子各取一项就使乘积无下界。

完整格映射 \(T=\operatorname{diag}(-I,I)\) 将主系数 \((-B;I)\) 变为 \((P,-Q)\)，在变量上为 \(x_i^{\rm op}\mapsto x_i^{-1}\)、\(y_i^{\rm op}\mapsto y_i\)。CMMM Lemma 4.14 及线性格映射相容性于是给出
\[
\theta^B_{(e_i,0),-}=x_iH_i^{\mathrm{op}}(z).
\]
因 \(\Lambda^Tb=(0,Dg)\)，上述有限赋值恰为 \(-L_i(g)\)。

现在对任意 \(p\in\mathbb N^n\)，\(\theta_{(p,0),-}\) 是这些基本因子的乘积，其相关赋值已经有限。输入 \(\theta_{b,+}\) 有限保证另一侧有限，这时才合法应用 CMMM Theorem 5.19：
\[
\max_{a\in\operatorname{Supp}F_g}(Dp)\cdot a
=\sum_i p_iL_i(g).
\]
取 \(p=e_i\) 得各坐标最大值。取 \(p=(1,\ldots,1)\)，正权总和达到各坐标最大值之和，迫使同一个支撑点同时达到全部坐标最大值。这就是 \(f(g)\)。它为 Newton 顶点；CMMM Theorem 3.15 的 monic 性给其系数为 \(1\)。

主要原始来源：[CMMM, arXiv:2505.09585v2](https://arxiv.org/html/2505.09585v2)，特别是 Lemmas 5.15–5.17、Remark 5.18、Theorem 5.19 的完整证明、Lemma 4.14、Theorem 3.15。此为 2026 版本，已逐条强审而非仅据摘要使用。

## 反向有限性、Jacobi 界与最高导数

若 \(B\) 的所有 theta 有限，应用定理于 \(g=-e_j\)，得
\[
\max_{a\in\operatorname{Supp}H_i^{\mathrm{op}}}a_j
=\frac{d_i}{d_j}f_i(-e_j)<\infty.
\]
对每个坐标均有界，故每个 \(H_i^{\mathrm{op}}\) 有限。利用正乘积 \(x^{h_+}\prod_i(\theta_{-e_i}^{(-B)})^{[-h_i]_+}\) 的首 theta 项，可推出反向所有 theta 有限。因此
\[
\boxed{\text{all theta finite for }B\iff\text{all theta finite for }-B.}
\]
Mandel–Qin《Bracelets bases are theta bases》Appendix C.2 在构造 DT 逆变换时另列负室全部有限的假设；本结论在经典主系数范围补足该假设。DT 变换的原构造是旧工作；本结论不证明 DT 必定置换 theta 基。

在有限 Jacobi 列定理的斜对称情形，若 \(\mathsf D_{ji}=\dim e_iJe_j\)，反代数矩阵为 \(\mathsf D^T\)。代入反向基本支撑盒便得
\[
f(g)\le\mathsf D g_-.
\]
新的精确停止界 \(\sum_i f_i(g)\) 可小于此前的粗界 \(\mathbf1^T\mathsf Dg_-\)。它确定最小坐标盒，并不声称整个 theta Newton 多面体等于一般表示 Newton 多面体。

对前节冰 Hasse 算子，若冻结行 \(p_j>0\) 对每个可变 \(j\) 都成立，最高冻结次数 \(R=a_0+p\cdot f(g_{\rm mut})\) 只有一个根指数达到；故最高 Hasse 导数恰为系数 \(1\) 的单项式。结合其 theta 正性，该单项式为初始局部化丛单项式。若 \(p\) 有零坐标，最高面仍可保留核心方向；“最高导数总是一枚 theta”尚未证明。局部星形散射图只包含零坐标核心，但尚未证明图外 taut 段只能产生一个局部初始标签。

## 最大单项式的精确计算核验

第一代理实际调用 Wolfram 两次：斜对称 512 个随机标签、完整支撑 18,631 项；斜对称化 \(b,c\in[1,6]\) 独立取值的 512 个随机标签、完整支撑 17,949 项。最大根盒 400 个格点；反向公式、支撑内最大点、系数 \(1\)、随机非负权支撑函数全部无失败。以下是可复算的斜对称化代码；约定 \(B=\left(\begin{smallmatrix}0&-b\\c&0\end{smallmatrix}\right)\)。

```wolfram
ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=
 ff[bb,cc,gg1,gg2]=Module[{aa2=-gg2,aa1,pm,qm,ee,pp,qq,kk},
 aa1=bb Max[aa2,0]-gg1;pm=Max[aa2,0];qm=Max[aa1,0];
 ee=ConstantArray[0,{pm+1,qm+1}];ee[[1,1]]=1;
 Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
  Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]]nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
  Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]]nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],
 {pp,0,pm},{qq,0,qm}];
 Expand[Sum[ee[[pp+1,qq+1]]z1^qq z2^(pm-pp),{pp,0,pm},{qq,0,qm}]]];
SeedRandom[202611141004];fails={};checks=0;terms=0;maxBox=0;
Do[Module[{b=RandomInteger[{1,6}],c=RandomInteger[{1,6}],
 g=RandomInteger[{-7,4},2],p=RandomInteger[{0,4},2],
 f,s,hop,dstar,cstar,pm,sym},
 sym={c,b}/GCD[b,c];f=ff[b,c,g[[1]],g[[2]]];
 s=First/@CoefficientRules[f,{z1,z2}];
 hop=Table[Reverse/@(First/@CoefficientRules[
 If[i==1,ff[c,b,0,-1],ff[c,b,-1,0]],{z1,z2}]),{i,2}];
 dstar=Table[Max[(-(sym g).#)&/@hop[[i]]]/sym[[i]],{i,2}];
 cstar=Coefficient[Coefficient[f,z1,dstar[[1]]],z2,dstar[[2]]];
 pm=Max[(p.#)&/@s];
 If[!MemberQ[s,dstar]||cstar=!=1||AnyTrue[s,Or@@Thread[#>dstar]&]||pm=!=p.dstar,
 AppendTo[fails,{b,c,g,p,dstar,cstar,pm}]];
 checks++;terms+=Length[s];maxBox=Max[maxBox,Times@@(dstar+1)]],{512}];
<|"checks"->checks,"exactSupportTerms"->terms,"largestRootBox"->maxBox,
 "failures"->Length[fails],"firstFailure"->Take[fails,UpTo[1]]|>

```

另有 root 的 512 个冰 Hasse 最高阶独立核验：将上一节完整加权代码的阶数换为 \(r=a_0+\max(p\cdot\operatorname{Supp}F)\)。512 例均非零，均恰输出一枚 theta，系数全为 1。此计算包含有零坐标的 \(p\)，只作为候选诊断，不能代替该一般情形尚缺的证明。

# 从精确最大次数构造正多面体与有限降次算法

本节给出直接可计算的构造，不借用 Li Fang、Li–Pan 或其修改稿任何结论。裸结论“全体 theta 有限推出正多面体/有限生成”已被 Tang 2611.00015v1 声明；本轮保留的是由反向有限基本多项式出发的显式权函数、严格降次量和独立证明，不能把同范围旧声明包装成首次发现。

假设 \(B\) 的全部 theta Laurent 有限。前节反向有限性保证 \(f_i(g)\) 是有限多有理线性式的最大值，从而是齐次凸分段线性函数；对整标签取非负整数值。\(H_i^{\rm op}\) 包含 \(0,e_i\)，故
\[
f_i(g)\ge[-g_i]_+.
\]
若 \(y^q\theta_k\) 在 \(\theta_g\theta_h\) 中非零，则
\[
k=g+h+Bq,\qquad q+f(k)\le f(g)+f(h)
\]
逐分量成立。理由是正 Laurent 展开给出完整支撑包含
\[
q+\operatorname{Supp}F_k
\subseteq\operatorname{Supp}F_g+\operatorname{Supp}F_h.
\]

记 \(s_j=\sum_i B_{ij}\)，选择整数
\[
L>\max\{1,\;1+\max_j s_j\},\qquad
\eta=\min_j(L-s_j)>1.
\]
定义
\[
\delta(g)=\sum_i g_i+L\sum_i f_i(g).
\]
它为整值齐次凸分段线性函数，并且
\[
\delta(g)\ge\|g\|_1,
\]
因为正坐标贡献为自身，负坐标至少贡献 \((L-1)|g_i|\)。对上述非零结构项，
\[
\boxed{\delta(k)\le\delta(g)+\delta(h)-\eta|q|_1.}
\]
因此非零根修正严格降低 \(\delta\)。

## 完整主系数格上的有界正多面体

完整标签写成 \((g,a)\)，对应 \(y^a\theta_g\)，允许 \(a\in\mathbb Z^n\)。令
\[
w(g,a)=\delta(g)+\|a\|_1,\qquad
\Xi=\{(g,a):w(g,a)\le1\}.
\]
\(w\) 是有限有理线性式的最大值，正定、连续、齐次；故 \(\Xi\) 是有界、满维、有理多面体，\(0\) 在其内部。乘法输出标签为 \((k,a+b+q)\)，三角不等式与上式给
\[
w(k,a+b+q)
\le w(g,a)+w(h,b)-(\eta-1)|q|_1.
\]
由齐次性，这正证明 \(\Xi\) 在 GHKK 的结构常数意义下 positive。该证明不需要另用 broken-line 凹性或 Tang §4.1。

## Hilbert 基生成与递归终止

取 \(\delta\) 的有限有理线性域锥扇。每个锥均无直线，因为 \(\delta\) 对非零向量严格正；取每个锥整数点半群的 Hilbert 基，所有这些有限集合之并记为 \(G\)。对任意 \(g\) 选择包含它的锥，写 \(g=\sum_r h_r\)、\(h_r\in G\)，且同一锥上线性性给
\[
\delta(g)=\sum_r\delta(h_r).
\]
乘积有首项系数 \(1\)：
\[
\prod_r\theta_{h_r}=\theta_g+\sum_{q>0}c_qy^q\theta_{g+Bq}.
\]
每个修正项的 \(\delta\) 严格小于 \(\delta(g)\)。按非负整数 \(\delta\) 归纳，得到
\[
\boxed{\bigoplus_g\mathbb Z[y]\theta_g
\text{ 由有限集合 }\{\theta_h:h\in G\}\text{ 生成。}}
\]
递归每步至少降一，深度不超过初始 \(\delta(g)\)。这是一种环生成/计算算法，含减法；不能误称每枚 theta 都是生成元的非负多项式。逆冻结系数后也得到相应有限生成结论。本节本身不证明 normality 或 middle=upper。

## 实际 Wolfram 乘法核验

root 对 512 组随机斜对称化秩二乘积作完整 theta 三角消去，得到 1,640 个输出项，其中 1,128 个根非零项，最大根高度 6。逐项验证支撑盒不等式、\(\delta\) 严格下降及完整冻结坐标的绝对值权不等式，失败为 0。采用 \(B=(\begin{smallmatrix}0&-b\\c&0\end{smallmatrix})\)、\(L=c+2\)，因此 \(\eta=2\)。完整代码如下。

```wolfram
ClearAll[z1,z2,ff,nn];
nn[a_Integer,k_Integer]:=If[0<=k<=a,Binomial[a,k],0];
ff[bb_Integer,cc_Integer,gg1_Integer,gg2_Integer]:=ff[bb,cc,gg1,gg2]=Module[{aa2=-gg2,aa1,ppmax,qqmax,ee,pp,qq,kk},
aa1=bb Max[aa2,0]-gg1;ppmax=Max[aa2,0];qqmax=Max[aa1,0];ee=ConstantArray[0,{ppmax+1,qqmax+1}];ee[[1,1]]=1;
Do[If[pp+qq>0,ee[[pp+1,qq+1]]=Max[
Sum[(-1)^(kk-1)ee[[pp-kk+1,qq+1]] nn[aa2-cc qq+kk-1,kk],{kk,1,pp}],
Sum[(-1)^(kk-1)ee[[pp+1,qq-kk+1]] nn[aa1-bb pp+kk-1,kk],{kk,1,qq}]]],{pp,0,ppmax},{qq,0,qqmax}];
Expand[Sum[ee[[pp+1,qq+1]] z1^qq z2^(ppmax-pp),{pp,0,ppmax},{qq,0,qqmax}]]];

ClearAll[top,del];
top[bb_,cc_,gg_List]:=top[bb,cc,gg]={Exponent[ff[bb,cc,gg[[1]],gg[[2]]],z1],Exponent[ff[bb,cc,gg[[1]],gg[[2]]],z2]};
del[bb_,cc_,gg_List]:=Total[gg]+(cc+2)Total[top[bb,cc,gg]];
SeedRandom[202611141022];
cases=512;products=0;thetaTerms=0;strictTerms=0;maxRoot=0;failures={};
Do[Module[{bb=RandomInteger[{1,4}],cc=RandomInteger[{1,4}],g=RandomInteger[{-3,3},2],h=RandomInteger[{-3,3},2],a=RandomInteger[{-5,5},2],ab=RandomInteger[{-5,5},2],poly,rem,box,q,coef,k,cap,dr,dg,dh,wgap,head=0},
poly=Expand[ff[bb,cc,g[[1]],g[[2]]]ff[bb,cc,h[[1]],h[[2]]]];
rem=poly;cap=top[bb,cc,g]+top[bb,cc,h];dg=del[bb,cc,g];dh=del[bb,cc,h];
box=SortBy[Tuples[{Range[0,Exponent[poly,z1]],Range[0,Exponent[poly,z2]]}],{Total,First}];
Do[coef=Coefficient[Coefficient[rem,z1,q[[1]]],z2,q[[2]]];
If[coef<0,AppendTo[failures,{"negativeProduct",bb,cc,g,h,q,coef}];Break[]];
If[coef>0,
thetaTerms++;k=g+h+{-bb q[[2]],cc q[[1]]};dr=del[bb,cc,k];
If[q=={0,0},head=coef,strictTerms++];
maxRoot=Max[maxRoot,Total[q]];
If[Or@@Thread[q+top[bb,cc,k]>cap],AppendTo[failures,{"box",bb,cc,g,h,q}]];
If[dr>dg+dh-2Total[q],AppendTo[failures,{"degree",bb,cc,g,h,q,dr,dg+dh}]];
wgap=dg+dh+Total[Abs[a]]+Total[Abs[ab]]-dr-Total[Abs[a+ab+q]];
If[wgap<Total[q],AppendTo[failures,{"fullPolytope",bb,cc,g,h,q,wgap}]];
rem=Expand[rem-coef z1^q[[1]]z2^q[[2]]ff[bb,cc,k[[1]],k[[2]]]]],{q,box}];
If[rem=!=0,AppendTo[failures,{"residual",bb,cc,g,h,rem}]];
If[head=!=1,AppendTo[failures,{"head",bb,cc,g,h,head}]];
products++],{cases}];
<|"products"->products,"thetaTerms"->thetaTerms,"strictLowerTerms"->strictTerms,"largestRootHeight"->maxRoot,"failures"->Length[failures],"firstFailure"->Take[failures,UpTo[1]]|>

```

实际输出：products=512，thetaTerms=1640，strictLowerTerms=1128，largestRootHeight=6，failures=0。计算只核验一般公式实现及符号，不替代上述任意秩证明。

# 任意无环实际强正基的顶点删除与根支集归约

本节针对任意 acyclic skew-symmetrizable 主系数矩阵，沿用此前已经证明的实际基标准化与多项式格等式
\[
\mathcal A_C^+=\bigoplus_{g\in\mathbb Z^n}\mathbb Z[y]\beta_g
=\mathcal A_{\mathbb Z[y]},\quad \beta_g\bmod(y)=x^g,
\]
且全部乘法结构常数属于 \(\mathbb N[y]\)、\(C\) 包含全部标准化丛单项式。并非从任意有限形式系数数组开始。

## 任意顶点的正矩阵分解

按源拓扑序各突变一次，记得到的共同最终簇为 \(z_i=\theta_{-e_i}=\beta_{-e_i}\)。每个顶点有
\[
x_iz_i=1+y_iW_i,\quad
W_i=\prod_{B_{ji}>0}x_j^{B_{ji}}\prod_{B_{ji}<0}z_j^{-B_{ji}}.
\]
\(W_i\) 属于突变 \(i\) 前的中间簇，是固定 CM；源突变不产生两步新箭头，故 valued 情形也成立。

令 \(X_i,Z_i,U_i\) 为在实际基 \(C\) 中乘以 \(x_i,z_i,W_i\) 的列有限非负矩阵，\(S_i(\beta_g)=\beta_{g+e_i}\)。交换式给
\[
X_iZ_i=Z_iX_i=I+y_iU_i.
\]
将 \(y_i=0\)，非负矩阵与其非负逆只能是正单项式置换；正多项式单位只能是 1，模全体 \(y\) 的首项固定置换。因此
\[
\boxed{X_i=S_i+y_iA_i,\quad Z_i=S_i^{-1}+y_iB_i,\quad A_i,B_i\ge0.}
\]
也可逐根系数证明：\(q_i=0,q\ne0\) 时右侧系数为零，左侧含仅 \(X_i\) 或仅 \(Z_i\) 发生该修正的非负路径，故两者均为零。由此还得
\[
U_i=A_iS_i^{-1}+S_iB_i+y_iA_iB_i
=S_i^{-1}A_i+B_iS_i+y_iB_iA_i.
\]
这些等式不自动推出分支单调性或任意 \(C\) 的 Hasse 正性。

## 实际商基及 BFZ 识别

置 \(y_i=0\) 后
\[
x_i\bar\beta_g=\bar\beta_{g+e_i},\quad
z_i\bar\beta_g=\bar\beta_{g-e_i},\quad x_iz_i=1.
\]
所以商中确有 Hamel 分解
\[
\mathcal A_C^+/(y_i)
=\bigoplus_{g_i=0}\mathbb Z[y_{j\ne i},x_i^{\pm1}]\bar\beta_g,
\]
所有结构常数仍非负。由 acyclic BFZ lower-bound presentation，\(x_i\) 已可逆，交换关系在 \(y_i=0\) 后可消去 \(x_i'\)；其余关系恰为删除可变顶点 \(i\)、冻结 \(x_i\) 后的关系。对 \(j\ne i\)，系数可重标度为
\[
\widetilde y_j=y_jx_i^{B_{ij}},\qquad
\widetilde x'_j=x_i^{-[-B_{ij}]_+}x'_j.
\]
因此这是删除后代数的实际强正基，包含其全部 CM。可迭代删除任意顶点，不要求原先是源或汇。

若根 \(q_i=0\)，则 \(F_{\beta_g}\) 的 \(q\) 系数不依赖 \(g_i\)。更一般，theta 变基系数 \(t_{g,q}\) 的问题精确降到诱导子矩阵 \(B_{\operatorname{supp}q}\)。若该子矩阵有限型，剩余 CM 已成基，故
\[
\boxed{B_{\operatorname{supp}q}\text{ 有限型}\Longrightarrow t_{g,q}=0.}
\]
这是真正一般的根支集刚性；不解决支集本身为 wild 型的根。

## 首层零边与全阶缺口

若 \(q\) 为所有标签上全局第一个非零变基层，则
\[
m^C_{x_i,g}(q)=m^\theta_{x_i,g}(q)+t_{g,q}-t_{g+e_i,q},
\]
负向 \(z_i\) 类似。theta 结构系数为零的有向边因此使 \(t_{g,q}\) 不增；若每个标签可沿这种边走到 CM，便得首层 \(t_{g,q}\ge0\)。一般可达性仍未证明，且此判据不能直接迭代到任意首负层：低层正修正产生卷积项，不能删掉后假设仍强正。

计算诊断保留：wild rank 2 的四个根层零边图均到达 CM；加权符号候选在 1,536+450 个完整结构系数中无失败。移位加强版有 79 个反例，已弃用。这些不作为一般定理采用。

更强的实际基反例否定了“只剥除第一正 theta 层”的操作。Kronecker band 基由 CM 与 \(S_n(z,H)\) 构成，
\[
S_0=1,\ S_1=z,\ S_n=zS_{n-1}-HS_{n-2},\quad H=y_1y_2,
\]
其 theta 方向为 \(T_n=S_n-HS_{n-2}\)。仅替换 \(S_2\) 为 \(T_2\) 而保留其余 \(S_n\)，有
\[
T_2^2=S_4-HT_2+H^2,
\]
出现负结构系数。即使全局只去掉第一 theta 层，令 \(D_n=S_n-HT_{n-2}\)，仍有
\[
zD_3=D_4+HD_2-H^2.
\]
这些恒等式已实际 Wolfram 核验。它们只否定证明操作，不否定 theta 最小性。可继续研究减去 \(R\cdot C\) 的受控全阶基调整，但保 strong 的一般条件尚未取得。

# 第二十一、二十二次文献与路线复查：10:05、10:25 UTC 窗口

| 文献或路线 | 实际核读及结论 | 当前处理 |
|---|---|---|
| CMMM arXiv:2505.09585v2 | root与两代理核 taut constancy、有限阶极限、移动基点、负室版本、格映射、monic。原 theorem 双边 finite 条件保留；正室单项式给本节所需另一边有限性 | 强审通过；使用其技术推出精确最大项与反向有限性 |
| Mandel–Qin arXiv:2301.11101v3 Appendix C.1–C.2 | 正室全部有限与 DT 逆所需负室全部有限在原文另列 | 旧 DT 构造不报新；本轮经典主系数反向等价补足其假设，不宣称 DT 保 theta |
| Tang hexagon:2611.00015v1, Positive polytopes and the full Fock–Goncharov conjecture | 已取得完整20页。root重建§3早/晚bend界、§4局部wall正逆块及§5有限生成；新代理专审§5.2–8：symplectic、遗漏除子分类、cylindrical特殊化及最低项唯一 | 正在强审；不得先当 middle=upper 的输入。裸正多面体/有限生成声明已存在，标明重叠 |
| Tang hexagon:2610.00083v2 §§2–5及§6 | 实际强基的量子下界依赖负量子次数容量与bar；§6负量子系数在参数1为4 | 不作经典最小性证明；可借角向有限矩阵组织 |
| Davison–Mandel §1.4；Mandel1503.06183v5 Th2.16 | 前者仍需 ordinary strong→scattering positivity 桥；后者给 trace 非退化而非任意C的正对偶探针 | 缺口真实，继续全阶 CM 探针，不重复裸 trace |
| BGL, Bases of tensor products and geometric Satake correspondence, §7.2 Prop7.3 | 核到同一标签例中 semicanonical=MV+2项、canonical=MV+1项 | 有用局部比较，不能升级成所有strong基最小性；Tang MV=theta稿本轮仍未完整取回，不使用 |
| Fei1911.10513v6 Remark6.10、Conj6.11 | 有限 theta 假设及 generic Newton 猜想仍分开 | 本轮最小坐标盒不冒充 whole generic Newton 等式 |
| aiXiv、Hexagon、Zenodo本轮新检索 | 命中 mutation-acyclic quantum、LPA positive bases、stated skein polygons quantum、tail-orbit reconstruction及log-concavity稿 | 量子/LPA外范围不移用；仅摘要或未完整取得者不作定理输入；没有命中不等于证明无先例 |

下一活动方向为：完成 Tang 2611.00015v1 的缺失除子论证强审，以判断有限 Jacobi theorem 能否进一步连接 fullFG；另一代理继续任意实际强基的全阶 CM 探针/受控正矩阵调整。研究主目标未完成，尤其任意强正基 theta 最小性仍未证明。阶段保存只为防丢失，不取代继续研究。

## 第23次文献与路线复查（2026-11-14 10:45–10:55 UTC）

本轮仍以一般 Laurent 有限性和任意实际强正基的最小性为主。完成了 Tang 2611.00015v1 §§5–8 的独立逐步审核，并用另一代理重新审查本轮有限 Jacobi 推导中的 Hall/HN、attractor 数据和退化核方向。没有把文献复查当作主结果，也没有把以下旧接口重新命名为新定理。最小性尚未证明。

### 已有正多面体论文的接口：强审通过，明确为旧输入

文献为 Qiyue Tang, [Positive polytopes and the full Fock–Goncharov conjecture, hexagon:2611.00015v1](https://hexagonmath.org/abs/2611.00015)，实际 PDF 共20页。审核使用实际 PDF 与语义文本交叉核对；主线程读 §§3–9，另一代理独立重建 §§5–8。以下是本轮确认可用的接口，不是本轮新颖性申报：

在特征零的 classical principal 设置中，若所有整数标签的 theta 都是 Laurent 多项式，并有有界、吸收的正有理多面体，则 middle 代数有限生成、正规，其初始与相邻种子环面漏掉的集合没有素除子，因而 middle=upper；所有标签均有限时得到相应 fullFG 结论。

这不推出 ordinary cluster algebra 等于 upper，也不推出 theta 相对任意实际强正基最小。结合本轮已证明的显式 δ 正多面体构造，可将“所有 theta 有限”送入这个旧接口；结合有限 Jacobi 列定理，当整个 completed Jacobian algebra 有限维时，得到 theta 为 upper 的基这一后果。此组合的旧桥梁、旧半群有限生成方法和本轮 Laurent 输入分开署明。

审核步骤与有效范围：

1. §5.1 的有限生成来自分片线性锥的 Hilbert 基以及固定次数内有限、严格下降的消元；中央纤维是正规 CM 的射影 toric 对，边界约化、log canonical 且 K+D 平凡。应用 GHKK Theorem 8.42 时核对了平坦性、边界商平坦性和 H¹ 消失，并未暗加 enough global monomials。底空间的收缩作用将零点附近的好性质传至所需纤维。

2. §5.2 的 Poisson 支撑控制利用输出标签附近只有直线贡献，将括号系数支撑置于正乘法系数支撑中。顶阶 Poisson 外积是平凡线丛的全局截面，初始环面上非零，故在光滑内部处处非零。

3. 假设存在所有相邻环面均漏掉的素除子，其 character valuation 为 a=ka₀，支持至少含两个 mutable 坐标。由 symplectic 体积约束取原始 H=zᵇ，b=Pn₀、n₀≥0，并有剩余 H=c≠0。中心余维与体积阶不等式强制余维二及 v(H−c)=1；V=Z/(H−c)^k 的剩余超越性给出 v(ΣZʳfᵣ)=minᵣ{kr+ord_{H=c}fᵣ}。这里没有使用“正系数在复数点不可能抵消”这一错误命题。

4. §7 的切向散射图沿 b 柱面化，所有过墙根有一致线性正下界 s(n)≥Cℓ|n|。当 ks>1 时 associated graded 恒等；ks=1 时 F↦F+αZ，V↦V/(1+αV)，因而仍可逆。统一估值增长确保正、逆运输的 v-adic 收敛及其与 root 完成的相容。凸 gauge 给出固定模 Zb 纤维的有限根预算，故漂移 broken line 的整个纤维稳定后才作 H=c 代入。由所有项的负 Z 次数与非负除子估值，导出切向 theta 在 H=c 上为零。

5. §8 反证上述消失：正性 θᵤᴷ−θᴷᵤ≥0 将有理 broken line 的最小值化为有界有限子水平问题。局部剪切 S=I+aν，ν(a)=ν(b)=0，满足 S⁻¹=I−aν、Sb=b。严格审核了对一个 correction 的小有理扰动及逆推所有后续折点的公式。一般 w∈b⊥ 避开所有可出现的有理超平面后，最小值迫使每个正权因子选常数、每个负权因子选最高项；反向比较两条最小路径使其 corrections 相同，因此最低投影系数为 aHʳ、a>0，在 H=c≠0 处不能消失。

6. 因此没有缺失素除子。正规性与 Krull 交集得到 upper=middle；§9 的有限 theta 展开线性方程再作特征零基域下降。没有据此宣称整系数、任意特征或 ordinary A=U 的额外结论。

语义解析曾把 ΛP=R 误识为 ΛP=B，把 H^{-ℓ}θ_{m_ℓ,q_ℓ} 误识为固定 m_*；实际 PDF 两处均正确。它们是解析伪差错，未标为原论文错误。

独立代理对上述剪切、保柱面、后缀扰动及有限最小顶点做512组秩3–8精确计算，107169个有限选择、2048次剪切逆检查、2048次固定 b 检查和512次扰动等式均无失败。首次脚本把向量与矩阵的 FoldList 方向写反导致511次失败；改为 FoldList[#2.#1&, …] 后为0。该项明确归为脚本错误，计算仅检验公式，不替代几何证明。

### 有限 Jacobi 证明的再次独立审查及核方向澄清

另一代理重新审查了实际 mixed-Hodge HN 恒等式、unsigned realization、形式势的有限 jet、repeller BPS 的一般点正性、正全平面完成以及 AB 唯一性。现有证明未发现需要补入 nondegenerate、genteel 或 reddening 假设的缺口。其适用范围仍是本节前面列明的 classical principal skew-symmetric 情形、有限无圈无二环箭图与 completed Jacobian；偏斜可对称的一般 Jacobi 版本尚未由此证明。

有一个必须写清的退化方向：原 root lattice 中若 Br=0，则 Pr=(0,r) 虽非零，却仍落在所有原 root 墙的交点。principal Poisson 矩阵可逆并不能把这个交点变为一般点。正确论证如下。

固定有限根次数截断及原始正射线 R=Z_{>0}r。令 g_R=⊕_{k>0}g_{kr}，q_R 为按次数投影到这条射线。若 a+b=kr，则

aᵀBb=aᵀB(kr−a)=0。

所以 q_R 消灭所有 Lie 括号，而且 g_R 中央；因此 q_R 是到中央阿贝尔 Lie 代数的同态，Q_R(exp X)=exp(q_RX) 是群同态。AB 中 r 的正、负部分均为0，π_r 正是这个中央投影。AB Proposition 3.9 明确允许 attractor 点位于 joint，并使所有经过该点的 fine wall 具有相同的 r 分量。于是可以在任一 r-generic 点读出真实 BPS 因子，而这个射线因子沿整个 r⊥ 常值。BCH 不会凭空制造 kr 次的 outgoing 项，因为最后一个括号已经为0。原证明中“在 Bn 附近取一般点”仅对 Bn≠0 使用；这里另行处理 Bn=0，保持所有中央 incoming 数据。

这只是把已有核方向证明写成可核对的群投影，不是新的主要定理。反对称形式采用 −nᵀBm，使 AB attractor 的列向量与 Bn 一致。principal 扩张保留中央因子对 xᵍ 的非平凡作用，不能将 ker B 商掉。

参考原文：[Argüz–Bousseau, arXiv:2102.11200v2, §3.2，特别是 Proposition 3.9](https://arxiv.org/html/2102.11200v2)；[Davison–Mandel, arXiv:1910.12915，Theorem 2.15 及正散射完成](https://arxiv.org/abs/1910.12915)。

核方向精确计算代码如下。实际结果为1000个秩3–12矩阵、100000次中央拆分，全零括号、principal 非退化及非平凡作用检查全部通过。

```wolfram
SeedRandom[261114]; Clear[trial];
trial[r_] := Module[{c,b,la,rr,pp,a,d,k,splitTests,principalTests},
 c=RandomInteger[{-7,7},{r-1,r-1}];c=c-Transpose[c];
 b=ArrayFlatten[{{c,Transpose[{-Total[c,{2}]}]},
                {{Total[c,{2}]},{{0}}}}];
 rr=ConstantArray[1,r];
 la=ArrayFlatten[{{ConstantArray[0,{r,r}],-IdentityMatrix[r]},
                 {IdentityMatrix[r],-b}}];
 pp=Join[b.rr,rr];
 splitTests=Table[k=RandomInteger[{1,12}];
   a=RandomInteger[{0,k},r];d=k rr-a;a.b.d===0,{100}];
 principalTests={b.rr===ConstantArray[0,r],Det[la]===1,
   Take[pp,r]===ConstantArray[0,r],
   pp.la.Join[UnitVector[r,1],ConstantArray[0,r]]===1};
 {And@@splitTests,And@@principalTests}];
res=Flatten[Table[trial[r],{r,3,12},{q,100}],1];
<|"Matrices"->Length[res],"CentralSplitChecks"->100Length[res],
  "AllCentralSplitsZero"->And@@res[[All,1]],
  "AllPrincipalChecks"->And@@res[[All,2]]|>
```

### 本轮新增/重核文献记录

| 文献 | 审核范围、结论及当前用途 |
|---|---|
| Tang 2611.00015v1 | §§3–9与实际PDF完整核对，独立重建缺失除子关键链；本轮通过，作为作者既有接口使用，不宣称新颖。 |
| AB 2102.11200v2；DM 1910.12915 | 重读 attractor joint 的明确条款与正全平面完成；核方向投影补足表述，保留输入数据。 |
| Qin 2407.03186，§6.3、Theorems 6.16–6.19 | Property S 在一般基处是条件，在 theta 处另证。无环 actual strong C 的 S 由本轮早先 BFZ 上界直接推出，因此不再报一个新主定理；actual Hamel 冻结与切片正性保留为有用推论。 |
| Wen Chang–QuanYu Tang, Obstructions to Jacobi-Finiteness of Quivers with Potentials, arXiv:2609.11200v1 | 读实际正文，检查 completed 非齐次 matrix Golod–Shafarevich/Vinberg 路径；只作相容性检查，不用其不有限性结论作为 Laurent 定理输入。QuanYu Tang 不是 Qiyue Tang。其 d≥4 条件不得用于 d=3。 |
| Zheng Hua–Guisong Zhou, Finite determinacy and rigidity of quiver potentials, arXiv:2610.35466v1 | 新检索到并开始读正文；trace-finite 与 finite determinacy 的等价不能代换成本轮所需有限 Jacobian 列。尚未完整强审，不作新定理输入。 |
| Jiarui Fei 2610.09868v2 | 本轮再核摘要的 good Jacobi-finite nondegenerate realization、reachability 与 middle=upper 条件；不将“给出 middle 基”误写为无条件 fullFG。有限 jet 平台检查的旧来源已明确标记。 |
| Qiyue Tang 2611.00190v2, Positivity of Canonical Basis Multiplication in Modified Quantum Groups | 检索到当前27页v2；full evaluation 机制实际用 KLR 项目对象与单枚 canonical/0 的映像性质。不能仅凭任意 C 强正性套用，后续只提取可证明的接口。 |
| 分析方向：正线性化、orthogonal polynomial hypergroup 文献 | 可借鉴大幂、矩阵元及正泛函方法，但任意 C 未给 involution、正交迹或 Hilbert 内积；未作输入，不偷加假设。 |

活动主线：一名新代理研究 opposite basic support 的有限方向条件是否反推单个 theta 有限；另一名新代理研究任意实际强正基的全 C 大幂正探针。源扩张线程收束已完成证明后换新上下文，继续处理全阶最小性缺口。

## 源扩张线程收束：一般系数下降及实际冻结（11:00 UTC前完成）

本节保存一般机制的完整推导；不将已知 BFZ 上界的直接推论另列为新主定理。任意强正基的 theta 最小性仍未解决。

### 实际源扩张继承基的 Bernstein 控制

沿用前文实际源扩张的严格前提。核心 B_T 无环，扩张 B_ext=[[0,−p],[b,B_T]]，p,b≥0，由可对称化有 p_i>0 当且仅当 b_i>0。设 t=x_s、η=y_s、M=x_T^b、I=(1+ηM)/t，核心冻结参数 Y_j=y_j I^{p_j}。实际扩张强基继承核心基 β_u；令 P_{k,u}=I^kβ_{(k,u)}，k≥0。前文已经证明 P 的核心正展开、η 次数至多 k、端点 β_u 与 β_{u+kb}，以及

Σ_{j=0}^k binom(k,j)η^jβ_{u+jb} ≤ P_{k,u} ≤ (1+ηM)^kβ_u。

这里不能把“存在实际扩张”删掉，不能假设任意核心 C 可添加源点而仍包含全部新 CM。

固定核心根 c，记 r=p·c，A=F_u[c]，a_j=F_{u+jb}[c]。令 z=ηM，P 的该根行为 p_k(z)。正上下界给

p_k(0)=A，deg p_k≤k，[z^k]p_k=a_k，binom(k,j)a_j≤[z^j]p_k≤A binom(k,j)。

转回源种子，该行等于 p_k(z)(1+z)^{r-k}，仍须为非负系数多项式。因此 k≥r 时

Q_k(z)=p_k(z)/(1+z)^{k-r}∈N[z]，deg Q_k≤r，Q_k(0)=A，[z^r]Q_k=a_k，Q_k(1)≤2^rA。

故 Q_k 取值于与 k 无关的有限整数多项式集合。对 0<ℓ<r 还有 [z^ℓ]Q_k≤A r^r/(ℓ^ℓ(r−ℓ)^{r−ℓ})，因为可在所有正实 z 上最小化 A(1+z)^r/z^ℓ。下界成为

binom(k,j)a_j≤Σ_{ℓ=0}^r binom(k−r,j−ℓ)[z^ℓ]Q_k。

若 r=1，Q_k=A+a_kz，故 a_j≤(1−j/k)a_0+(j/k)a_k。对每个平移起点取 k=2，得到 a_j−2a_{j+1}+a_{j+2}≥0，即完整离散凸性。

严格下降还需最终消失。用无环 BFZ 参数 a_i(g)=g_i−Σ_{j>i}(−B_ij)[−a_j(g)]_+，沿 g=u+Nb 后向递归可知 a_i(g) 非减，且 b_i>0 时趋向正无穷。若 r>0，某 c_i>0 且 b_i>0，标准帽的 z_i 次数最终为0，故 a_N=0 对充分大 N 成立。

现证明一般 r>0 时 F_{u+rb}[c]≤A−1（A>0）。反设 a_r=A，则 [z^r](A(1+z)^k−p_k)=0 对所有大 k 成立。令 H_k=A(1+z)^r−Q_k，则 (1+z)^{k-r}H_k 逐系数非负。大 k 时 H_k 常数项0，最高 z^r 项为A，且 H_k 只有有限个候选。任一候选的首个非零系数必正，否则乘 (1+z)^{k-r} 后首个非零项仍负；于是 [z^r](1+z)^N H 是 N 的首项正的非零多项式。有限候选可取统一阈值，此系数最终严格正，与其为0矛盾。

由 Mβ_v 的正乘法首项还得到 F_{v+b}[c]≤F_v[c]。反复应用严格下降即有有效界

F_{u+rA b}[c]=0，A=F_u[c]，r=p·c>0。

不能加强为任意 r 的 (−1)^{r+1}Δ^{r+1}a_j≥0；精确计算已有反例。代理执行13500项 r=1 二阶差分检查与 r=1,2,3 的正平台检查，失败0；更强高阶断言在10608项中有214个失败参数行，最小值−162。原始可复算代码：

```wolfram
ClearAll[pn,af,z,y];
pn[bb_,cc_,kk_,uu_]:=pn[bb,cc,kk,uu]=Module[
 {den=Max[-uu,0],aa,ee,p,q,n,a,ep,rows,div,rem},
 If[uu>=0,Return[Expand[(1+z)^kk]]];
 aa=Max[bb den-kk,0];ee=ConstantArray[0,{den+1,aa+1}];ee[[1,1]]=1;
 Do[If[p+q>0,ee[[p+1,q+1]]=If[cc aa q>=bb den p,
 n=Max[aa-bb p,0];Sum[(-1)^(l-1)ee[[p+1,q-l+1]]Binomial[n+l-1,l],{l,1,q}],
 n=Max[den-cc q,0];Sum[(-1)^(l-1)ee[[p-l+1,q+1]]Binomial[n+l-1,l],{l,1,p}]]],
 {p,0,den},{q,0,aa}];
 rows=Table[ep=Sum[ee[[den-a+1,q+1]]z^q,{q,0,aa}];
 If[kk-bb a>=0,Expand[ep(1+z)^(kk-bb a)],
 div=(1+z)^(bb a-kk);rem=PolynomialRemainder[ep,div,z];
 If[rem=!=0,Throw[{"division failure",bb,cc,kk,uu,a,rem}]];
 PolynomialQuotient[ep,div,z]],{a,0,den}];
 Expand[Sum[rows[[a+1]]y^a,{a,0,den}]]];
af[bb_,cc_,k_,u_,r_,s_]:=Coefficient[
 Normal[Series[Coefficient[pn[bb,cc,k,u],y,s](1+z)^(bb s-k),{z,0,r}]],z,r];
checks=0;bad={};plateauBad={};
Do[vals=Table[af[bb,cc,k,u,r,s],{k,0,bb(-u)+r+2}];
 If[r==1,checks+=Length[vals]-2;
 If[Min[Differences[vals,2]]<0,AppendTo[bad,{bb,cc,u,r,s,vals}]]];
 Do[If[vals[[j+r]]==vals[[j]]&&vals[[j]]>0,
 AppendTo[plateauBad,{bb,cc,u,r,s,j-1,vals}]],{j,1,Length[vals]-r}],
 {bb,1,5},{cc,1,5},{u,-8,-1},{r,1,3},{s,1,Min[-u,5]}];
{checks,Length[bad],Length[plateauBad],Take[bad,UpTo[3]],Take[plateauBad,UpTo[3]]}
(* Actual output: {13500,0,0,{},{}}.
   Stronger alternating 3rd differences FAIL:
   vals=Table[af[1,2,k,-6,2,4],{k,0,10}];
   {vals,-Differences[vals,3]}
   -> {{90,48,19,3,1,0,0,0,0,0,0},{0,-1,13,0,1,0,0,0}} *)
```

### 任意无环 actual strong C 的定量冻结与全部切片

前文 y_i=0 面因子化 fr_i(β_{g+e_i})=x_i fr_i(β_g) 已证。BFZ 参数满足 a_j(g+Ne_i)=a_j(g)（j>i），a_i(g+Ne_i)=a_i(g)+N。因此 N≥[−a_i(g)]_+ 时标准帽不含 z_i，故

β_{g+Ne_i}=x_i^N fr_i(β_g)。

这直接给 Property S；其裸稳定性不另报新。令 T 为其余顶点，barβ_u=fr_i(β_{(0,u)})，则 fr_i(β_{(k,u)})=x_i^k barβ_u，足够大的 N 满足 β_{(N,u)}=x_i^N barβ_u。BFZ 生成元关系给 A[x_i^{-1}]=A(冻结i)，无须将 U 与 A 混同。

Hamel 独立性：任一有限关系 Σ_{u,k}c_{u,k}(y)x_i^k barβ_u=0，选一个足够大 N，使所有出现的 x_i^{N+k}barβ_u 同时等于互异原基元 β_{(N+k,u)}。原 C 的实际独立性迫使全部系数0。这一步不循环假设冻结基存在。

有限张成及正性：x_i^Nβ_g=Σ_q c_N(q)y^qβ_{g+Ne_i+Bq}，c_N≥0。每个正输出的首项必须在左侧固定 F_g 支撑中，故所有 q∈Supp F_g，不依赖 N。取 N 同时使这有限多个输出稳定，除 x_i^N 得

β_g=Σ_{q∈Supp F_g}c_N(q)y^q x_i^{g_i+(Bq)_i}barβ_{g_T+(Bq)_T}。

所以 barβ 是冻结代数的实际基，每一原基元在其中有有限正展开。两 barβ 的乘法也可同时乘足够大 x_i^N 回到原 C；输出根集由固定 Laurent 乘积支撑控制，再统一稳定。两侧不含 y_i 且展开正，结构系数因而不含正 y_i 次数。冻结代数的 CM 避免突变 i，与足够大的 x_i^N 相乘后仍为原 CM，故被此基继承。

最后按 q_i=r 分组，得到 [y_i^r]β_g∈N[y_T,x_i^{±1}]barC 对全部 r≥0 成立。逐顶点迭代给任意冻结集合的多重根切片正性。这个结论是一般 Laurent 结构，不能以秩一冻结后的原子性偷换野生秩二或更高秩的全阶 theta 最小性。

### 已失败的首层剥离：保存完整实际基论证以免再次循环

这只是检验证明操作，不是最小性反例。仿射 Kronecker 中 S_0=1、S_1=z、S_n=zS_{n−1}−HS_{n−2}，T_n=S_n−HS_{n−2}（n≥2），T_0=1。定义 P_n=S_n−H²S_{n−4}（负指标S为0），则 n≥2 时 P_n=T_n+HT_{n−2}。全部 CM 加 P_n 为实际有限幺三角基。

全乘法正性可自含核验。m≥n≥3 时，d=m−n，

P_mP_n=P_{m+n}+HP_{m+n−2}+H^{n−1}J_d，

其中 J_d=P_{d+2}+HP_d（d≥3），J_2=P_4+HP_2+H²，J_1=P_3+2HP_1，J_0=2P_2+2H。边界为 P_1²=P_2+H；P_1P_2=P_3+HP_1；P_1P_3=P_4+HP_2+H²；P_1P_n=P_{n+1}+HP_{n−1}（n≥4）；P_2²=P_4+HP_2+2H²；P_2P_3=P_5+HP_3+2H²P_1；P_2P_4=P_6+HP_4+H²P_2+H³；P_2P_n=P_{n+2}+HP_n+H²P_{n−2}（n≥5）。

在 H=1 的无系数代数，T_nx_m=x_{m+n}+x_{m−n}，所以 P_n 乘任意丛变量为正和。S_n=Σ_{j=0}^{⌊n/4⌋}P_{n−4j}。任意变量乘积用 x_mx_{m+2k}=x_{m+k}²+Σ_{j=0}^{k−1}S_{2j} 及 x_mx_{m+2k+1}=x_{m+k}x_{m+k+1}+Σ_{j=0}^{k−1}S_{2j+1} 直化。按“变量因子数、所有指标平方和”字典序下降：中项保持因子数并降平方和，S 项转 P 后与一个剩余变量相乘使总因子数下降。终止于相邻变量的 CM，因而覆盖全部 CM×CM 与 CM×P，而非只验有限窗口。

主系数取 B=[[0,−2],[2,0]]、H=y_1y_2，z=x_1/x_2+y_2/(x_1x_2)+Hx_2/x_1。与主系数 theta 基的有限变换及逆只用非负 H 次数，因此乘法系数在 Z[y_1,y_2]。B 可逆和齐次性使每个固定输入输出系数只能为单一 y 单项式乘整数；令 y=1 得其整数非负，故主系数也是 actual strong basis。

若令 R(P_n)=HP_{n−2}、R(CM)=0，试图以 D=(I−R)P 删除当前基的首修正层，则 D_4=T_4−H²。z 中中间项的 mutable 总次数负，另两项总次数0；T_4(a+H/a)=a⁴+H⁴/a⁴ 无常数项，所以 D_4 的 mutable 常数项为 −H²。无系数更直接有 D_4x_m=x_{m+4}+x_{m−4}−x_m，三个都是保留的 CM。因此当前 C 低项剥离同样不保持正性。

一般公式是 μ_{I−R}=μ−δR+(I−R)^{-1}N_R，其中 δR=μ(R⊗I)+μ(I⊗R)−Rμ，N_R=μ(R⊗R)−RδR。μ−δR≥0、N_R≥0 是充分条件，却不由 XiZi=I+yiUi 自动推出。关联 Nijenhuis 理论只提供 N_R=0 等代数条件，不提供目标基锥不等式。本路线已终止，不再追加特殊反例。

```wolfram
ClearAll[z,h,s,p,d,j,x1,x2,y1,y2];
s[0]=1;s[1]=z;Do[s[n]=Expand[z s[n-1]-h s[n-2]],{n,2,42}];
p[n_Integer]:=Expand[s[n]-If[n>=4,h^2 s[n-4],0]];
d[n_Integer]:=Expand[p[n]-If[n>=2,h p[n-2],0]];
j[0]=2p[2]+2h;j[1]=p[3]+2h p[1];j[2]=p[4]+h p[2]+h^2;
j[n_Integer]/;n>=3:=p[n+2]+h p[n];
productChecks=Table[Expand[p[m]p[n]-p[m+n]-h p[m+n-2]-h^(n-1)j[m-n]],
 {n,3,18},{m,n,20}];
boundaryChecks={Expand[p[1]^2-p[2]-h],Expand[p[1]p[2]-p[3]-h p[1]],
 Expand[p[1]p[3]-p[4]-h p[2]-h^2],Expand[p[2]^2-p[4]-h p[2]-2h^2],
 Expand[p[2]p[3]-p[5]-h p[3]-2h^2 p[1]],
 Expand[p[2]p[4]-p[6]-h p[4]-h^2 p[2]-h^3]};
bandChecks=Table[Expand[s[n]-Sum[h^(2k)p[n-4k],{k,0,Floor[n/4]}]],{n,0,32}];
principalZ=x1/x2+y2/(x1 x2)+y1 y2 x2/x1;
negativeLaurentCoefficient=Coefficient[Coefficient[
 Expand[(d[4]/.{z->principalZ,h->y1 y2})x1^4 x2^4],x1,4],x2,4];
{Union[Flatten[productChecks]],Union[boundaryChecks],Union[bandChecks],
 d[4],negativeLaurentCoefficient}
(* Actual output {{0},{0},{0},h^2-4h z^2+z^4,-y1^2 y2^2}. *)
```

## 第24次文献与路线复查：最高项双射与反向基本系数的有限恢复（11:05–11:16 UTC）

本轮取得两条直接服务 Laurent 展开的机制：最高单项式标签的显式可逆变换，以及由同向负基本 theta 的系数恢复反向基本 theta 的无行列式反演公式。后一公式本身在形式完成中成立，不需要先验 Laurent 有限；结合前面的有限性与最小盒定理后，得到明确的有限计算算法。全阶任意强正基最小性仍是活动缺口。

### 最高单项式标签是双射；不使用 DT 置换 theta 猜想

设 B 可斜对称，D=diag(d_i)>0，DB 反对称，并假设所有 principal theta 都 Laurent 有限。前文已经从单枚有限 theta 的 CMMM 互易性推得反向 −B 的所有 theta 也有限。记 F_i=F^B_{−e_i}，H_i=F^{−B}_{−e_i}，以及 f_B(g) 为 θ_g^B 的唯一共同最高 F 指数。已有精确公式

f_{B,i}(g)=d_i^{-1} max_{a∈Supp H_i}(−Dg)·a。

定义 κ_B(g)=g+Bf_B(g)。则

κ_{−B}∘κ_B=id，κ_B∘κ_{−B}=id，f_{−B}(κ_B(g))=f_B(g)。

所以 κ_B 是 R^n 上齐次分片线性的同胚，在整数格上是双射，每个满维线性片块为行列式1的整单模变换。

证明使用 [Mandel–Qin 2301.11101v3 Appendix C](https://arxiv.org/html/2301.11101v3) 的正有理 DT 及其明确逆公式，全部有限的正、反向基本 theta 使两者均合法。对 −B 图写 z_j=y_j x^{−Be_j}，则

DT_{−B}(x_i)=x_i^{-1}H_i(z)，DT_{−B}(y_j)=y_j^{-1}，

DT_{−B}^{−1}(x_i)=x_i^{-1}F_i(z^{-1})，DT_{−B}^{−1}(y_j)=y_j^{-1}。

在初始赋值 (val x,val y)=(0,Dg) 处，val H_i=−d_i f_{B,i}(g)。正 Laurent 表达保证 tropicalization 不发生消去，正有理逆又保证其 tropical 映射互逆。第一次映射后 u′=−Df_B(g)、v′=−Dg；−B 的根赋值为 v′−Bᵀu′=−D(g+Bf_B(g))。再代入逆映射的 x_i 坐标，返回0给出

0=d_i f_{B,i}(g)−d_i f_{−B,i}(κ_B(g))。

这逐坐标证明 f 关系；没有除以 B，所以 B 的核不造成缺口。将 f 关系代入 κ_{−B} 即得逆公式，互换 B、−B 得另一边。整数格上 f_B 整值；在任意满维有理线性片块取足够深的整数点及其各单位平移，可知 f_B 的线性矩阵为整数。逆映射同理，故片块单模；κ_B 在正正交象限为恒等，整个 PL 同胚保持定向，故行列式为+1。

包括冻结头时，完整首项到最高项的对应为

Φ_B(g,a)=(κ_B(g),a+f_B(g))，

其逆为 Φ_B^{-1}(h,b)=(κ_{−B}(h),b−f_{−B}(h))。

这只证明最高项、支撑次数及标签的对应。它不声称 F 多项式逐系数反演等于另一 theta，不声称 DT 保持 upper 或置换全部 theta，也不把 Mandel–Qin Conjecture C.6 当定理。Qin 1902.09507v4 §3.4 的 support dimension/bipointed 机制明确在 injective-reachable 背景下；该旧理论在可达情形提供同类解释，本节的输入是全部 Laurent 有限。

精确计算：256个秩3–20、不同正 symmetrizer 的无环矩阵，共8192个有理标签；另用 Zhou 1901.04166v3 §5.1 的已知七项基本多项式核对含非零核的 cyclic Markov 数据10000个标签。f 互易、κ 互逆全部无失败；256个无环片块及9983个一般 cyclic 片块的行列式均为1。Markov 是公式符号与核方向的压力检查，不是用特殊情形替代一般证明。首次脚本将同名 ff 同时用作列表和函数，导致 cyclic 段未求值；修正为 topF 后得到以下结果，首次异常明确归为脚本变量错误。

```wolfram
ClearAll[acyF,acyFOp,acyJ,markSupp,ff,topF,fg,gg,bb,dd];
SeedRandom[2611141105];
acyF[b_,g_] := Module[{n=Length[g],v=ConstantArray[0,Length[g]]},
 Do[v[[i]]=Max[0,-g[[i]]+Sum[-b[[i,j]]v[[j]],{j,i+1,n}]],
 {i,n,1,-1}];v];
acyFOp[b_,g_] := Module[{n=Length[g],v=ConstantArray[0,Length[g]]},
 Do[v[[i]]=Max[0,-g[[i]]+Sum[b[[i,j]]v[[j]],{j,1,i-1}]],
 {i,1,n}];v];
acyJ[b_,g_] := Module[{n=Length[g],v=ConstantArray[0,Length[g]],
 a=ConstantArray[0,{Length[g],Length[g]}],r},
 Do[r=-g[[i]]+Sum[-b[[i,j]]v[[j]],{j,i+1,n}];
 If[r>0,v[[i]]=r;
 a[[i]]=-UnitVector[n,i]+Sum[-b[[i,j]]a[[j]],{j,i+1,n}]],
 {i,n,1,-1}];IdentityMatrix[n]+b.a];
badA={}; detA={}; acount=0;
Do[
 n=3+Mod[k,18];dd=RandomInteger[{1,5},n];
 bb=ConstantArray[0,{n,n}];
 Do[r=RandomChoice[{0,0,0,1,1,2}];
 bb[[i,j]]=-dd[[j]]r;bb[[j,i]]=dd[[i]]r,
 {i,1,n},{j,i+1,n}];
 Do[gg=RandomInteger[{-30,30},n]/RandomInteger[{1,7}];
 ff=acyF[bb,gg];hh=gg+bb.ff;fo=acyFOp[bb,hh];
 If[fo=!=ff||hh-bb.fo=!=gg,AppendTo[badA,{k,gg,ff,hh,fo}]];
 acount++;
 If[t==1,AppendTo[detA,Det[acyJ[bb,gg]]]],
 {t,1,32}],
 {k,1,256}];
mb={{0,-2,2},{2,0,-2},{-2,2,0}};
base={{0,0,0},{1,0,0},{1,0,1},{1,0,2},{1,1,2},{1,2,2},{2,2,2}};
sb=Table[(RotateRight[#,i-1]& /@base),{i,1,3}];
so=Table[(RotateRight[#[[{1,3,2}]],i-1]& /@base),{i,1,3}];
topF[s_,g_]:=(Max[-#.g]& /@s);
badM={}; detM={}; mc=0; generic=0;
Do[
 gg=RandomInteger[{-1000,1000},3]/RandomInteger[{1,13}];
 fv=topF[so,gg];hh=gg+mb.fv;fo=topF[sb,hh];
 If[fo=!=fv||hh-mb.fo=!=gg,AppendTo[badM,{gg,fv,hh,fo}]];
 vals=((-#.gg)&/@#& /@so);
 ind=FirstPosition[#,Max[#]][[1]]& /@vals;
 If[And@@(Count[#,Max[#]]==1& /@vals),
 generic++;
 aa=Table[-so[[i,ind[[i]]]],{i,1,3}];
 AppendTo[detM,Det[IdentityMatrix[3]+mb.aa]]];
 mc++,
 {10000}];
<|"AcyclicMatrices"->256,"AcyclicLabels"->acount,
 "AcyclicFailures"->Length[badA],"AcyclicJacobianDeterminants"->Union[detA],
 "CyclicKernelLabels"->mc,"CyclicFailures"->Length[badM],
 "CyclicGenericPieces"->generic,"CyclicJacobianDeterminants"->Union[detM],
 "FirstFailure"->Take[Join[badA,badM],UpTo[1]]|>
```

实际输出：AcyclicMatrices=256，AcyclicLabels=8192，AcyclicFailures=0，AcyclicJacobianDeterminants={1}；CyclicKernelLabels=10000，CyclicFailures=0，CyclicGenericPieces=9983，CyclicJacobianDeterminants={1}，FirstFailure={}。

### 形式基本 theta 的无行列式系数反演

这一节完全不要求 F_i 或 H_i 是多项式；只需它们在 Z[[z_1,…,z_n]] 中、常数项1。仍令 F_i=F^B_{−e_i}，H_i=F^{−B}_{−e_i}。对任意 p∈Z^n、a∈N^n，有

[w^a] ∏_i H_i(w)^{p_i}
=
[z^a] ∏_k F_k(z)^{p_k+(Ba)_k}。

尤其

[w^a]H_i(w)=[z^a]∏_k F_k(z)^{δ_{ki}+(Ba)_k}。

负幂一律指常数项1的 root 完成中的整数幂。这是经典形式留数／Lagrange–Good 反演的应用，旧反演原理不属于本轮新颖性。

完整证明：设 p_path 为 B 图从负室至正室的路径同构。负室单项式性质给 p_path(x_i^{-1})=x_i^{-1}F_i(z)，所以 p_path(x_i)=x_i/F_i，且 p_path(y_j)=y_j。反向图反射给 p_path^{-1}(x_i)=x_iH_i(z)。定义

T_j(z)=p_path(z_j)=z_j∏_k F_k(z)^{-B_{kj}}。

于是 T=z+高阶，为 root 完成上的形式自同构；由 p_path∘p_path^{-1}=id，得到 H_i(T(z))=F_i(z)。

为处理换元行列式，使用非退化 principal 对数 Poisson 矩阵 Λ_B=[[0,D],[-D,DB]]。令 E_{ij}=z_j∂logF_i/∂z_j，其常数项为0。各墙作用为 Hamiltonian，故路径同构的对数 Jacobian

J_p=[[I−EBᵀ,−E],[0,I]]

满足 J_pΛ_BJ_pᵀ=Λ_B。Pfaffian 恒等式给 det J_p=1；这也可逐有限根截断证明再取极限。T 的对数 Jacobian 为 J_T=I−BᵀE，Sylvester 恒等式给 det J_T=det(I−EBᵀ)=1。B 本身可退化，不影响 principal Λ 的非退化性。

形式常数项换元为 CT_w G(w)=CT_z G(T(z))det J_T。对单项式 G=w^b，b=0 给1；b≠0 选 b_j≠0，把 w^b∧_k dlog w_k 写成形式全微分，拉回后的留数为0。对有统一逐坐标下界的一般 Laurent 形式级数，可能贡献常数项的 b≤0 只有有限个，故可逐有限 root jet 线性推广。这里不涉及解析收敛，也不把两个不同完成中的无穷和重排。

取 G=w^{-a}∏H_i(w)^{p_i}，代入 H(T)=F 及 det J_T=1，即得所述系数公式。为了计算右侧，足够在有限环 Z[z]/(z_j^{a_j+1}:1≤j≤n) 中运算。若 F=1+U，F^r 在该系数中只需 Σ_{ℓ=0}^{|a|}binom(r,ℓ)U^ℓ；这对任何整数 r 均成立，所以公式给出完全有限的整数算法。

当 p≥0 时，左侧非负，故右侧这些可能包含负幂的系数自动非负。这是对本批基本 theta 的一整族精确系数恒等式，不能据此把任意正多项式族都认成 cluster theta。

代理独立正向和反向复合四个 Hamiltonian shear，至总根次数5检查168条系数恒等式，无失败。此为一般形式机制的算式核验，不是 Laurent 有限性逆命题的计算证明：

```wolfram
ClearAll[z1,z2,z3,t,jet,mon,getcoef];
vars={z1,z2,z3};
bmat={{0,2,-1},{-2,0,3},{1,-3,0}};
roots={{1,0,0},{0,1,0},{1,0,1},{0,0,1}};
maxdeg=5;
jet[expr_]:=Expand[Normal[Series[expr/.Thread[vars->t vars],{t,0,maxdeg}]]/.t->1];
mon[v_]:=Times@@(vars^v);
f=ConstantArray[1,3];h=ConstantArray[1,3];
Do[u=1+mon[v];s=Thread[vars->vars u^(bmat.v)];
 f=Table[jet[u^v[[i]](f[[i]]/.s)],{i,3}],{v,roots}];
Do[u=1+mon[v];s=Thread[vars->vars u^(-bmat.v)];
 h=Table[jet[u^v[[i]](h[[i]]/.s)],{i,3}],{v,Reverse[roots]}];
alist=Select[Tuples[Range[0,maxdeg],3],Total[#]<=maxdeg&];
getcoef[expr_,a_]:=Fold[Coefficient[#1,vars[[#2]],a[[#2]]]&,expr,Range[3]];
fails={};
Do[power=UnitVector[3,i]+bmat.a;
 candidate=jet[Times@@MapThread[Power,{f,power}]];
 If[getcoef[candidate,a]=!=getcoef[h[[i]],a],
 AppendTo[fails,{i,a,getcoef[candidate,a],getcoef[h[[i]],a]}]],
 {i,3},{a,alist}];
<|"Mechanism"->"Arbitrary four Hamiltonian shears; independent forward and inverse",
 "Dimension"->3,"TotalRootDegree"->maxdeg,
 "CoefficientIdentitiesChecked"->3 Length[alist],"Failures"->fails|>
(* Actual output: CoefficientIdentitiesChecked -> 168, Failures -> {}. *)
```

### 由同向基本多项式得到任意标签的最优根次数截断

假定已用前文的 Jacobi 列证书、单向拼接等合法机制证明同向 F_i 全部有限。令 C_B 的第 i 列为 F_i 的各坐标次数，即 (C_B)_{ri}=deg_{z_r}F_i。单枚有限 theta 的互易公式在 g=−e_j 处给出

C_{−B}=D^{-1}C_BᵀD。

因此不必先枚举反向散射图，就知道每个 H_i 的精确最小坐标盒 [0,C_{−B}e_i]。在该有限盒中逐 a 用上一节反演式计算 H_i，盒外全为0。随后对任意整数 g，计算

f_{B,i}(g)=d_i^{-1} max_{a∈Supp H_i}(−Dg)·a。

这些整数组成 θ_g 的精确最小坐标盒；其共同最高角 f_B(g) 的系数为1。因而

K(g)=Σ_i f_{B,i}(g)

既是充分的散射根次数截断，也是 θ_g 的实际最大总根次数。要得到整个 Laurent 展开，只需完成 cluster scattering diagram 到 K(g) 阶并枚举同阶 broken lines。每次非平凡折弯严格增加非负根次数，故弯折次数至多 K(g)，每阶墙和单项式选择均有限。整个流程的停止依据在计算之前给出，不以“暂时未发现新项”作为有限性证明。

这一算法的基础输入是实际 F_i 或前文保证其计算可停机的有限载体。它不是对任意矩阵无条件先验停机的宣称，也不把一般标签的 theta 等同于任意混号乘积 ∏F_i^{-g_i}。

### 查新、失败与活动路线记录

| 来源／路线 | 此轮结果与使用范围 |
|---|---|
| Qin 1902.09507v4 §§3.3–3.4、A.2 | root重读support dimension和opposite图；前者有injective-reachable假设，后者反射机制可用。不把已有bipointed理论报新。 |
| Mandel–Qin 2301.11101v3 Appendix C | root核DT正有理式、逆式及C.6的猜想状态；本轮只用可逐坐标验证的逆式。 |
| Weng 2303.03466v1 §§1、3、4 | 主线程和代理重读相邻种子、满子箭图置零、三角扩张公式；未在这些一般性质及全文检索中发现上述无det系数恢复。旧DT可达范围和Markov折叠例分开记录。 |
| I. J. Good，1960 | Cambridge原始出版记录确认题名、56(4):367–380及DOI10.1017/S0305004100034666。反演与留数旧原理明确引用；本轮给自含形式证明。 |
| Plamondon 2011 thesis §5.6.1 | 原文Theorem5.6.2给nondegenerate Jacobi-finite的generic map，完整基断言另需GLS背景，并明确generic character不总正；未覆盖本轮无可达性正theta有限界。 |
| Rietsch 2509.25163 / ICM2026；Chung-Halpern–Rietsch2606.16983 | 读取前者总正Toeplitz与渐近比值接口，后者仅定位原文。actual C只给作用矩阵条目正，不给所有子式正，未移用Edrei/Schubert结论。 |
| Hua–Zhou2610.35466v1 | 原文§4的finite determinacy重核：trace-finite控制循环类，不代替有限Jacobi列；不进入本轮主证明。 |
| Tang2611.00006v1 MV–theta §6 | 搜索取到opposition片段，但全文再取回失败；该片段明确用injective-reachability。未把全文作为输入，也不声称其错误。 |
| Laurent有限性逆命题 | 联合opposite支持有限方向域的内部已得统一根惩罚、局部有限PL与Poisson单模片块；尚未得到θ_g自身的统一根预算。不同完成中的形式逆不能直接重排。 |
| 任意actual strong C最小性 | 两代理继续一般正模/有限jet正提取，已识别共同因子条件足够但未从strong推出。有限截断传递正商会丢失根层；继续研究保留过滤的正评价，不把障碍本身当交付目标。 |

本轮新颖性结论仍是有边界的：精确最高项双射、同向到反向基本系数恢复及其最优截断组合，在本轮读到的GHKK/CMMM/Qin/Mandel–Qin/Weng原文中未发现同范围陈述；不以搜索无命中证明绝对首创。下一轮重点仍是 Laurent 逆向判据和任意强基的正坐标提取。

# 第二十五次文献与路线复查（11:22—11:34 UTC）

本次复查直接面向两个未解主缺口。Mandel 的 scattering-atlas 原子性和 Davison–Mandel 的最小性讨论仍不能推出任意 ordinary-atlas 实际强正基的最小性。Tang 2610.00083v2 的量子证明继续保留量子/经典边界，不以 v=1 特化替代任意经典基的量子提升。新搜索未找到可以直接填补该缺口的现成定理。

Laurent 线再次检查 Qin 1902.09507v4 附录 A.2 和 Mandel–Qin 2301.11101v3 附录 C。前者翻转整个扩展交换矩阵；后者的 Conjecture C.6 仍明确是 DT 置换 theta 函数的猜想。因此 κ_B 的最高项互逆不能升级成系数逐项反转或 theta 置换。本轮终于取得 Tang 2611.00006v1 原文，并核读 §6.1：其同函数域的 opposite-theta 等式明确使用 full rank、injective-reachability 及 KQW 的 twist-preservation。该局部论证范围清楚；未把整篇 MV–theta 等式当作已审核输入。

有限性逆向仍开放。反向基本支撑函数在 g 的邻域有界时，可得到反向暴露面有限以及局部分段线性、Poisson 单模性；这尚不保证目标 theta 的所有尾项有限。新尝试是给 CMMM 的 bend transfer 构造单调能量和有限终止量，用反向支撑的强制界代替原方向预设有限性。尚未得到所需不变量。

任意强基线有两个仍在推进的机制：有限 root jet 的正坐标探针，以及乘法算子的移位平均。移位平均在二阶出现真实相关项，不能当作普通迹处理；实际 C 只有 BFZ 多项式增长界，尚无合法的一致有界平移平均。新接口是：任意 Q-chart 中，初始 cluster monomials 的非平凡 roots 位于 Q·r<0，而 injective-cluster monomials 的非平凡 roots 位于 Q·r>0。正在用这对半空间约束处理正/负方向递推和高阶交叉项，未声称最小性已证明。

本段在第二十六次复核后暂停使用：Mandel–Qin A.7 的正包含末句与其 A.10 的墙函数例子之间出现实质相容性问题。一般覆盖有限性下降及本轮显式系数派生暂不作已证输入；详见末尾纠正。

本次原文：Mandel–Qin, https://arxiv.org/html/2301.11101v3 ，§A.2–A.3、A.7–A.9、附录 C；Zhou, https://arxiv.org/html/1901.04166v3 ，§§3.1–3.3；Qin, https://arxiv.org/html/1902.09507v4 ，§A.2；Tang, https://hexagonmath.org/pdf/2611.00006v1 ，只审核 §6.1；Fei, https://arxiv.org/html/2610.09868v2 ，核对 split quiver、有限列与 goodness 的定义和使用边界。Fei 的整个 87 页主结果未在本轮获得新增全篇审核，不据摘要去掉 reachability。

# 对称覆盖的基本 F 系数上界候选（11:50 复核发现正包含缺口，待修复）

设 \(\widetilde B\) 是有限秩斜对称矩阵，有限群 G 通过顶点置换保持它；轨道为 \(O_1,\ldots,O_n\)，\(m_i=|O_i|\)。令 \(\pi:\mathbb Z^{\widetilde n}\to\mathbb Z^n\) 把同轨道坐标相加，\(A=\pi^T\operatorname{diag}(m_i^{-1})\)。折叠矩阵 B 由 \(\pi\widetilde B=B\pi\) 定义；于是 \(\widetilde BA=AB\)、\(\pi A=I\)，且 \(D_0B\) 斜对称，其中 \(D_0=\operatorname{diag}(m_i^{-1})\)。乘共同分母便得到整数对称化子。这里采用主系数变量 x,y，\(z_j=y_jx^{Be_j}\)。

写 \(\rho\) 为多项式替换 \(\widetilde z_a\mapsto z_i\;(a\in O_i)\)。对任意 \(b\in O_i\)，候选系数上界为

```math
0\le F^{B}_{-e_i}(z)\le \rho\bigl(F^{\widetilde B}_{-e_b}(\widetilde z)\bigr).
```

两边即使是无穷正形式级数，也逐系数比较。该式允许折叠图存在额外 incoming walls，不假设折叠图恰等于丛散射图。Mandel–Qin A.7 提供正包含 \(\mathfrak D_B\subset\overline{\mathfrak D_{\widetilde B}}\)。

证明的代数部分避免对单条折叠断线强行取分数指数提升。对两个 G-不变 Laurent 多项式，\(\rho\) 保持 Poisson 括号：对轨道和展开括号，再将轨道平均写成 Aπ，即得目标兼容矩阵 \(\Lambda_B=A_2^T\Lambda_{\widetilde B}A_2\)，其中 A_2=diag(A,A)。同样，G-不变散射路径乘积在不变子代数上的作用与投影可交换。这只在不变子代数使用；不声称任意单项式上的 \(\rho\) 都是 Poisson 映射。

取负室到正室的路径乘积 P，以及不变单项式 \(X_i=\prod_{b\in O_i}\widetilde x_b^{-1}\)。投影为 \(x_i^{-m_i}\)。若辅助折叠图的负基本函数写为 \(x_i^{-1}H_i\)，则路径兼容给

```math
H_i(z)^{m_i}
 =\prod_{b\in O_i}\rho\bigl(F^{\widetilde B}_{-e_b}(\widetilde z)\bigr).
```

交换矩阵的 G-对称性使各个 \(F^{\widetilde B}_{-e_b}\) 互为变量置换，所以右边是任一因子 \(P_i\) 的 \(m_i\) 次幂。H_i 与 P_i 常数项均为一；在有理系数 root 完成中取形式对数，得到 H_i=P_i。正散射图包含及在额外墙选择常数项一，再给 \(F^B_{-e_i}\le H_i\)。这也是上述系数界的全部来源。

# 覆盖上的有限 Jacobi 列下降候选（依赖上节未闭合步骤，暂不可使用）

在 \(\widetilde Q\) 上选任意势 W；不要求 W 为 G-不变。假设所需轨道 i 中各选择一个顶点 b_i，使 \(I_{b_i}=D(e_{b_i}J)\) 有限。此前已证明的非带值 Jacobi 列定理给 \(F^{\widetilde B}_{-e_{b_i}}\le H_{b_i}\)，其中 H 是实际 framed 上同调的非负有限支撑多项式，支撑包含于 I 的子模维数集合。故对任意 g，只要 g_i<0 的这些列有限，就有

```math
0\le F^B_g
 \le\prod_i\left(\rho H_{b_i}\right)^{[-g_i]_+},
\qquad
\operatorname{Supp}F^B_g
 \subseteq \sum_i[-g_i]_+\,\pi\operatorname{Supp}H_{b_i}.
```

相应矩阵上界与停止界为

```math
K_{ji}=\sum_{a\in O_j}\dim e_{b_i}J e_a,
\qquad
\operatorname{Supp}F^B_g\subseteq[0,K g_-],
\qquad
N(g)=\mathbf1^T K g_-.
```

K 的列来自实际选定的有限列，不从对称化子猜测转置。不同代表顶点 b_i 可给不同上界，因为 W 无需对称；每个有效选择都给一个独立界。如果整个 J 有限，则所有折叠 theta 都有限，随后适用前面的精确最高角算法以缩紧 N(g)。这是一条一般覆盖机制，不局限于无环、曲面或可达种子。

定性新颖性边界：『覆盖全 theta 有限则折叠全 theta 有限』已经是 Mandel–Qin A.8 的内容。本轮候选增量是基本 F 的逐系数支配、任意非对称势的有限列输入，以及明确的轨道求和矩阵 K。Ramified realization 若能独立验证其 split quiver 和有限列，可直接接入；这里不引用尚未完整复审的 ramified basis 结论。

# 512 个覆盖的精确计算

计算插件 Wolfram 实际完成 512 个群对称覆盖：256 个无环覆盖用于负基本 F 的五阶 root 截断比较，256 个含循环可能的覆盖只检验线性/Poisson 投影恒等式。秩最高 28。得到 3,447 个 F 恒等式、20,682 个一元化系数检查、4,096 个轨道 Poisson 恒等式、20,802 个 Cartan 条目检查，失败均为零。一元化使用 z_i=v_i u，因此不能冒称已经独立核对所有多元系数。循环组不被用于宣称存在 Jacobi 有限势。

```wl
ClearAll[makeCover,foldData,negF,topMat,tr];
SeedRandom[2611141132];
makeCover[sz_,cyc_] := Module[{nn=Total[sz],cuts,orbs,mat,gg,vals,i,j,a,b,sgn,perm},
 cuts=Prepend[Accumulate[sz],0];
 orbs=Table[Range[cuts[[i]]+1,cuts[[i+1]]],{i,Length[sz]}];
 mat=ConstantArray[0,{nn,nn}];
 Do[gg=GCD[sz[[i]],sz[[j]]];
 vals=RandomChoice[{0,0,0,1,1,2},gg];
 sgn=If[cyc,RandomChoice[{-1,1}],-1];
 Do[mat[[orbs[[i,a+1]],orbs[[j,b+1]]]]=sgn vals[[1+Mod[b-a,gg]]];
 mat[[orbs[[j,b+1]],orbs[[i,a+1]]]]=-sgn vals[[1+Mod[b-a,gg]]],
 {a,0,sz[[i]]-1},{b,0,sz[[j]]-1}],{i,1,Length[sz]},{j,i+1,Length[sz]}];
 perm=Flatten[RotateLeft /@orbs];
 {mat,orbs,perm}];
foldData[bb_,orbs_]:=Module[{pp,aa,nn=Length[bb],sz=Length/@orbs,bf},
 pp=Table[Boole[MemberQ[orbs[[i]],j]],{i,Length[orbs]},{j,nn}];
 aa=Transpose[pp].DiagonalMatrix[1/sz];
 bf=pp.bb.aa;{pp,aa,bf}];
tr[pp_]:=Normal[Series[pp,{u,0,5}]];
negF[bb_,vv_]:=Module[{fs=ConstantArray[1,Length[bb]],prod},
 Do[prod=1;Do[If[bb[[j,i]]<0,prod=tr[prod fs[[j]]^(-bb[[j,i]])]],{j,1,i-1}];
 fs[[i]]=tr[1+vv[[i]]u prod],{i,Length[bb]}];fs];
topMat[bb_]:=Inverse[IdentityMatrix[Length[bb]]-Map[Max[0,-#]&,UpperTriangularize[bb,1],{2}]];
bad={};fchecks=0;coefchecks=0;poisson=0;topchecks=0;maxRank=0;
Do[
 nn=3+Mod[case,6];sz=RandomChoice[{1,2,3,4},nn];
 {bb,orbs,perm}=makeCover[sz,case>256];
 {pp,aa,bf}=foldData[bb,orbs];maxRank=Max[maxRank,Length[bb]];
 If[pp.bb=!=bf.pp||bb.aa=!=aa.bf||pp.aa=!=IdentityMatrix[nn]||
 bb[[perm,perm]]=!=bb||!And@@(IntegerQ /@Flatten[bf]),
 AppendTo[bad,{"linear",case}]];
 dd=DiagonalMatrix[1/sz];
 If[dd.bf=!=-Transpose[dd.bf],AppendTo[bad,{"symmetrizer",case}]];
 Do[v=RandomInteger[{-4,4},Length[bb]];w=RandomInteger[{-4,4},Length[bb]];
 ord=LCM@@sz;vp=NestList[#[[perm]]&,v,ord-1];wp=NestList[#[[perm]]&,w,ord-1];
 lhs=Total[vp].bb.Total[wp];
 rhs=ord^2 (pp.v).dd.bf.(pp.w);
 If[lhs=!=rhs,AppendTo[bad,{"poisson",case,j}]];poisson++,
 {j,1,8}];
 If[case<=256,
  val=RandomInteger[{1,5},nn];vup=Transpose[pp].val;
  ffup=negF[bb,vup];ffdn=negF[bf,val];
  Do[Do[If[ffup[[b]]=!=ffdn[[i]],AppendTo[bad,{"F",case,i,b}]];
    fchecks++;coefchecks+=6,{b,orbs[[i]]}],{i,nn}];
  cc=topMat[bb];cb=topMat[bf];
  If[pp.cc=!=cb.pp,AppendTo[bad,{"Cartan",case}]];topchecks+=Length[bb] nn;
 ],
 {case,1,512}];
<|"Covers"->512,"AcyclicCoefficientCovers"->256,
 "CyclicLinearCovers"->256,"MaximumCoverRank"->maxRank,
 "TruncatedFIdentities"->fchecks,"UnivariateCoefficientChecks"->coefchecks,
 "OrbitPoissonIdentities"->poisson,"CartanEntryChecks"->topchecks,
 "Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
```

```text
Covers=512; AcyclicCoefficientCovers=256; CyclicLinearCovers=256;
MaximumCoverRank=28; TruncatedFIdentities=3447;
UnivariateCoefficientChecks=20682; OrbitPoissonIdentities=4096;
CartanEntryChecks=20802; Failures=0.
```

# 第二十六次文献与路线复查（11:41—11:53 UTC）

本轮继续处理一般有限性逆向和任意实际强正基的 theta 最小性。新增两条可完整证明的接口：有限标签锥闭包中的有限性判据，以及实际强正基乘法的逐根次数统一列界。二者均保留明确未解部分；未把条件结论写成一般主定理。

查新与原文核对：CMMM arXiv:2505.09585v2 的 Lemma 3.20、Lemma 3.1/Corollary 3.2 与 §5.6；GHKK arXiv:1411.1394v2 Theorem 7.5(3) 的加法封闭及饱和性证明。Mou arXiv:1910.13714v1 的 mutation/stability chamber 论证没有直接提供本任务所需任意强基结论。Burcroff–Lee–Mou–Musiker–Reineke arXiv:2511.14672 / JLMS 114(2), e70642 (2026) 的现读范围是摘要及引言，其主要接口是 rank-two wall coefficients，未作为一般结论输入。

Fei《Syzygy Transformations of Cluster Characters and Geometric Twists》arXiv:2609.10090v1 是 κ/Good 路线的直接竞争文献；当前多个 arXiv 原文入口失败，Library 只检到此前 monodromy 备忘录中的引文。AI overview 不能当原文证据。已登记『直接竞争，待全文强审，未采用』，不据其摘要宣布本轮新颖性或引用其 AR 公式。Lusztig 2609.01321 的检索也只给摘要与二手转录，原文 v2 暂未取得；不作证明输入。

Library 本轮重新检索 strong-positive/minimality、finite-locus/Newton、Lusztig/Tang 交叉资源，找到既有 rank-two 审核稿与 monodromy 研究备忘录；没有找到可取消 classical/quantum 边界或任意强基缺口的新定理。Li–Pan 原稿与修改稿再次命中检索，但依用户指示完全不调用其结论。

# 有限标签的支撑域闭包定理

固定主系数经典斜可对称 B，D=diag(d_i)>0，DB=-B^TD。令 H_i=F^{-B}_{-e_i}∈1+(z)N[[z]]，S_i=Supp H_i⊂N^n，L_i(g)=sup_{a∈S_i}(-Dg)·a，𝒟=∩_i dom L_i。设 Θ_Z={g∈Z^n:θ_g^B 是 Laurent 多项式}，Θ_Q={g∈Q^n:存在正整数 N 使 Ng∈Θ_Z}，K=closure(Θ_Q)。

GHKK Theorem 7.5(3) 给 Θ_Z 饱和且对加法封闭，正室 cluster monomials 给 N^n⊂Θ_Z。因此 Θ_Q 是含 Q^n_{≥0} 的有理凸锥，Θ_Q∩Z^n=Θ_Z，K 是闭凸锥。这里不是给非整数标签虚构 ordinary theta，而是使用 CMMM 的有理 broken-line 族。

命题：
\[
\Theta_{\mathbb Q}=K\cap\mathcal D\cap\mathbb Q^n,\qquad
\Theta_{\mathbb Z}=K\cap\mathcal D\cap\mathbb Z^n.
\]
定义 ν_i(g)=val_{Λ(e_i,0)}(Θ_{(g,0),+})，Λ=[[0,D],[-D,DB]]。最终指数为 (g+Ba,a)，故该 valuation 为 -d_i a_i。CMMM 的有理缩放与 ordinary/rational 比较给 ν_i(Ng)=Nν_i(g)，且 g∈Θ_Q 当且仅当所有 ν_i(g)>-∞。

证明：已审 single-finite top theorem 给 Θ_Q⊂𝒟 且在 Θ_Q 上 ν_i(g)=-L_i(g)。反之取 g∈K∩𝒟∩Q^n，选 h_k∈Θ_Q 满足 ||h_k-g||∞<1/k，令 q_k=h_k+(1/k)1。加法封闭给 q_k∈Θ_Q，同时 q_k≥g，q_k→g。由于 S_i⊂N^n，有 L_i(q_k)≤L_i(g)<∞。CMMM Lemma 3.20 的上半连续方向为 ν_i(g)≥limsup ν_i(q_k)，所以 ν_i(g)≥-L_i(g)>-∞。清分母后，θ_{Ng} 的全部根支撑落在有限整数盒 0≤a_i≤N L_i(g)/d_i 中。因此 g∈Θ_Q；整数情形再用饱和性。证毕。

此命题闭合了 K 中所有满足支撑有界条件的边界标签，不要求 g∈int𝒟。逐坐标上逼近提供统一支撑盒，不是逐阶界冒充全局界。一般逆向仍缺 𝒟⊂K。CMMM Lemma 3.20 的证明把局部集合称为 open cone；其用途只需小开邻域，按开邻域读即可，不把这一措辞问题夸大为主定理错误。

# 支撑域内部的统一有限截断与局部 Poisson 映射

若 g∈int𝒟，取 ε>0 使 g-ε1∈𝒟，置 C_i=L_i(g-ε1)。当 ||h-g||∞≤ε/2 时，
\[
-Dh\cdot a\le C_i-\frac{\varepsilon}{2}\sum_jd_ja_j\qquad(a\in S_i).
\]
由于 0∈S_i，极大支撑点必满足 Σ_jd_ja_j≤2C_i/ε。因此这个邻域中所有 L_i 同时由有限 root jet 决定；不需要预先知道 θ_h 有限。

在 generic 线性片上，各 L_i 有唯一暴露支撑点 a_i。以 a_i^T 为行组成 A，则 L(g)=-ADg，f(g)=-D^{-1}ADg，κ(g)=g+Bf(g)，本片线性矩阵 K_0=I-BD^{-1}AD。暴露点的系数一来自 CMMM 3.15；上面的 coercivity 保证这里只使用真正的有限暴露面。

对 opposite 形式 DT，z=yx^{-B}，DT_{-B}(x_i)=x_i^{-1}H_i(z)，DT_{-B}(y_i)=y_i^{-1}。在 (val x,val y)=(0,Dg) 的开 weight 片，领先单项式矩阵
\[
J=\begin{pmatrix}-I-AB^T&A\\0&-I\end{pmatrix},\quad
\Lambda_-=\begin{pmatrix}0&D\\-D&-DB\end{pmatrix}.
\]
由 Poisson 性及严格有限领先支撑，JΛ_-J^T=Λ_-，分块得到
\[
AD-DA^T+ADB A^T=0.
\]

Λ_- 非退化，取 Pfaffian 得 det J=1。又 DK_0D^{-1}=I+B^TA，Sylvester 恒等式给 det K_0=1。因而局部片在 D^{-1}Z^n 上单模；在一般 converse 未证前不据此宣称它保持通常 Z^n。若已知全部 theta 有限，前面已证的整数最高角性质另给通常格上的单模性。

进一步设 S=BD^{-1}，则 S^T=-S，K_0=I-SAD，直接展开
\[
K_0SK_0^T-S=S(DA^T-AD-ADB A^T)S=0.
\]
且 κ(g)-g∈im B=im S。因此各线性片保持退化 Poisson 双向量，并沿同一仿射 symplectic leaf 移动。这不能自行推出全局 properness、injectivity，或把另一 Novikov completion 的逆分支认成原 root completion 的 opposite F 分支。

下列一般符号矩阵检验已通过 Wolfram 实际执行；四阶无数值特化用于核对符号，所有秩的证明是上面的分块代数。

```wl
n=4;
smat=Table[If[i<j,ss[i,j],If[i>j,-ss[j,i],0]],{i,n},{j,n}];
dmat=DiagonalMatrix[Array[dd,n]];
bmat=Inverse[dmat].smat;
hmat=Array[hh,{n,n}];
id=IdentityMatrix[n]; zz=ConstantArray[0,{n,n}];
lmat=ArrayFlatten[{{zz,dmat},{-dmat,-dmat.bmat}}];
amat=-id-hmat.Transpose[bmat];
jmat=ArrayFlatten[{{amat,hmat},{zz,-id}}];
res=Map[Together,jmat.lmat.Transpose[jmat]-lmat,{2}];
target=hmat.dmat-dmat.Transpose[hmat]+hmat.dmat.bmat.Transpose[hmat];
kmat=id-bmat.Inverse[dmat].hmat.dmat;
poisson=bmat.Inverse[dmat];
bivec=Map[Together,kmat.poisson.Transpose[kmat]-poisson+poisson.target.poisson,{2}];
<|"TopBlockIdentity"->(Map[Together,res[[1;;n,1;;n]]-target,{2}]===zz),
"AllOtherBlocksVanish"->(res[[n+1;;2n,All]]===ConstantArray[0,{n,2n}]&&res[[1;;n,n+1;;2n]]===zz),
"WeightedRootConjugacy"->(Map[Together,dmat.kmat.Inverse[dmat]-(id+Transpose[bmat].hmat),{2}]===zz),
"DeterminantBridge"->Together[Det[kmat]-Det[jmat]],
"PoissonBivectorIdentity"->(bivec===zz)|>
```

结果依次为 True、True、True、0、True；不是有限性逆向的计算证明。

# 任意实际强正基的统一正乘法列界

范围：已具有全 Z^n 标签、主系数齐次 pointed 归一化的实际 strong-positive Hamel 基 C={β_g}，乘法
\[
β_dβ_h=\sum_{q\ge0}c_{d,h}(q)y^qβ_{d+h+Bq},\quad
c_{d,h}(q)\in\mathbb N,\ c_{d,h}(0)=1.
\]
无环主系数任务中的前置 pointed 定理提供这一范围。每个实际乘积有限；不能把任意形式 triangular family 当作这种 C。

定理：每个固定 d∈Z^n、q∈N^n 都存在有限常数 K_C(d,q)，使对所有 h，
\[
0\le c_{d,h}(q)\le K_C(d,q).
\]
这不预设散射正性、可范畴化或平移均值。

纯正路径证明：记 a_d(s)=c_{d,-d}(s)，则
\[
β_dβ_{-d}=1+\sum_{s>0}a_d(s)y^sβ_{Bs}.
\]
在正则作用 M_{-d}M_d 的列 h、根次数 q>0 中，先由 M_d 走 root q、再由 M_{-d} 走 leading shift 的一条正路径贡献 c_{d,h}(q)。另一方面按上式计算整个条目给
\[
c_{d,h}(q)\le\sum_{0<s\le q}a_d(s)c_{Bs,h}(q-s).
\]
即使 Bq=0，单位算子的 y^q 系数仍为零，不会多出常数项。

令 K_C(d,0)=1，按总根次数同时对所有 d 递归
\[
K_C(d,q)=\sum_{0<s\le q}a_d(s)K_C(Bs,q-s).
\]
每项次数严格下降、每次只涉及有限 s，因此给出有限界。归纳不要求所有 d 共享同一个常数；固定 (d,q) 只访问一个有限递归树。

在任意固定 formal chart Q 写 P_h=x^{-h}Φ_Q(β_h)∈1+(z)Z[[z]]，R_{h,d}=P_{h+d}/P_h。实际乘法等式是
\[
P_d=\sum_{s\ge0}c_{d,h}(s)z^sR_{h,d+Bs}.
\]
比较 q 系数，
\[
R_{h,d}(q)=p_d(q)-c_{d,h}(q)
-\sum_{0<s<q}c_{d,h}(s)R_{h,d+Bs}(q-s).
\]
利用上述列界与低次数归纳，所有固定 d,q 的 |R_{h,d}(q)| 也在全部 h 上统一有界。整数性意味着每个有限位移、有限 jet 的相对配置只有有限种。

这是比 BFZ 多项式增长更强的相对界，可构造相对 cocycle 的紧配置空间。它并不保证 P_h 本身有界：例如形式比值 (1+u)^{ℓ(d)} 可以具有非零线性漂移；这里只用它提示量词区别，不把该形式族当实际强基反例。最小性仍需控制漂移或给出合法的正归一化。

# 半空间零预算与真实有限探针：条件桥梁

对 finite root order D 选择 Q，使 0<|q|≤D 时 Q·q≠0。初始 CM 在 Q-chart 的非平凡根支撑位于 Q·q<0；injective-cluster CM 的非平凡根支撑位于 Q·q>0。沿从正室或负室到 Q 的直路径逐墙作用即可证明：相关墙法向同号，所有所选根是这些法向的非负组合。

若深 Q 区存在 Følner 有限盒 F_N，并且每个 |q|≤D 的真实绝对系数满足 sup_N |F_N|^{-1}Σ_{h∈F_N}|[z^q]P_h|<∞，则经验平移配置有一个可积、平移不变的概率极限。证明先对每个整数坐标用 Markov 界取得紧性，对可数位置作对角抽取；Følner 对称差控制有界 cylinder functions，截断绝对值函数给极限可积性。不直接对未知无界序列套用均值。

按总根次数归纳：低层配置若已平移不变，可除去其共同低阶单位作分析。实际乘法的本层交叉项全部抵消，得 c_{g,h}(q)=p_g(q)+u_q(h)-u_q(h+g)。Q·q>0 时取所有初始 x_i，Q·q<0 时取所有 injective z_i；相应 p_{±e_i}(q)=0，故差非负。平移不变与可积性给差的期望零，进而差几乎处处零。归纳到 D 后，对所有 g 有 p_g(q)=c_{g,h}(q)≥0。

任意预定有限头窗口的共同 jet 事件涉及有限个离散整数坐标，极限概率一使真实有限盒中存在满足该事件的平移。于是得到可用于有限阶 theta 系数提取的实际共同因子块。统一绝对有界时另有纯有限证明：每层零预算给坐标单调的整数函数，有限振幅迫使任意大盒中出现指定大小的共同平台；逐层缩盒即可。

准确剩余缺口：已证 relative jets 有界，不等于上述 absolute average L1 有界。两侧 CM 清分母公式本身只重述两个普通簇的 Laurent 正性；不能独立推出 scattering 正性。有限传递正模上的幂零根作用又会被 Perron–Frobenius 简单商杀掉，故需要保留 filtered 根层。

# 对折叠候选的实质纠正（11:50 UTC）

新代理对 Mandel–Qin A.7 与 A.10 做交叉核对，root 已亲读原文。A.10 的三顶点循环轨道折为 rank one，辅助图负基本函数因子为 1+z+z²，而丛图因子为 1+z。因此
\[
\frac{1+z+z^2}{1+z}=1+z^2-z^3+z^4-\cdots.
\]
同一 rank-one 墙上的作用可交换，这个商不能由通常意义的非负额外墙作用给出。

因此，上一节候选证明中『由 A.7 正子图包含，额外墙取常数项一得到系数支配』这一步暂停使用。候选不等式在该例仍成立，例子反驳的是所用正分解理由，而非已经反驳候选不等式。A.7 原文的 positivity-preserving inclusion 末句与 A.10 的相容性仍须按作者精确定义核对；不据此否定整篇论文。上一轮任意覆盖的 Jacobi 列下降与停止矩阵 K 都依赖该步骤，现统一改为『待修复，不作为已证输入』。

保留有效部分：轨道平均的 Poisson 代数恒等式、辅助图负室单项式机制、512 覆盖计算本身。下一步检验加法式 incoming wall coefficients 支配是否有独立比较定理，或以独立 species/Hall 机制重建下降。完整 admissible unfolding 若只能调用已知 exact folding，则如实保留其旧结果边界。

相关原文：https://arxiv.org/html/2301.11101v3 ，A.7 行3519–3528、A.8 行3531–3539、A.10 行3548–3580。检索作者主页与版本记录只见 v2 曾修改附录 A，未找到针对这里的更正。此前非带值 Jacobi 列定理的 DM/CoHA 路径与此 MQ 下降步骤分别记录；此次缺口不能被隐藏在旧定理引用中。

# 第二十七次路线复查：森林系数上界、正域解析互逆与强基返回支撑（2026-11-14 12:10 UTC）

本窗口继续解决一般机制。新增三条可独立检验的接口：零势 framed Hilbert 概形给全部形式 theta 的指数系数上界；正系数 Pringsheim 障碍将形式逆提升为整个正实收敛域的解析互逆，并得到支撑有限域内部的 κ 互逆；无环任意实际强正基的返回状态有严格支撑消失。森林上界的 HN—unsigned 接口于12:25完成独立复核；完整 full-category 证明见第二十八次复查。一般 Laurent 有限性逆命题与任意强正基的 theta 最小性仍未闭合。

## A. 零势森林上界：主张与几何证明链

只取经典主系数、有限无自环且无二循环的斜对称箭图 Q，允许任意有向长环。写 θ_g=x^g F_g(z)、z_i=y_i x^{Be_i}，g∈Z^n，f=g_-，r=Σ_i f_i。令 Δ 同时上界 Q 的所有入度与出度。拟证明
\[
0\le F_g(z)\le_{\rm coeff}\prod_i T_i(z)^{f_i},\qquad
T_i=1+z_i\prod_{a:i\to j\ {\rm in}\ Q^{op}}T_j.
\]
右边为唯一常数项为 1 的多色树形式解。第二个较粗但方向无歧义的结论为
\[
\sum_{|a|=k}[z^a]F_g\le[t^k]T_\Delta(t)^r,\qquad T_\Delta=1+tT_\Delta^\Delta.
\]
这里上界的是全部形式系数，不预设 θ_g 为 Laurent 多项式。

第一步沿用本轮先前已建立的实际 cohomological HN 支配（待新代理独立复核其 unsigned 实现）：任意势 W 的有限根截断内有 0≤F_g≤F_{-f}≤H_f^W。H_f^W 是 source-framed Q^op 的 nilpotent cyclic Hilbert fiber 上，光滑 ambient 的 IC 经 monodromic vanishing cycles 后的总上同调维数生成函数。正性比较使用实际分次向量空间与张量直和分解，不把有符号 Euler characteristic 当无符号维数。

取 W=0。此时 monodromic φ_0 的常数对象（按约定附 shift/Tate）给普通上同调总维数；不是把 singular fiber 自身的 intersection cohomology 当作输入。令 X=Hilb_{d,f}(Q^op)，其点是由 f 个指定 framing 向量循环生成的表示。Engel–Reineke, arXiv:0706.4306, Proposition 3.6 给 X 光滑，且忘却 framing 的 p:X→Rep_d(Q^op)//G_d 为射影态射。

令 C* 同时缩放所有原箭头，固定 framing 箭头。基底不变量由有向圈 trace 生成，所有非恒定生成元具有严格正权，因此基底收缩至原点。p 的 properness 使每个 x∈X 的 t→0 轨道有极限；固定点集是 p^{-1}(0) 的闭子集，因此 proper。故 X 是 smooth semiprojective。其 core 恰为 p^{-1}(0)：在 proper fiber 中 t→∞ 的轨道总有极限；反之若基底有非零正权坐标，它在 t→∞ 发散，不能有极限。零纤维表示即 nilpotent 表示：其 semisimplification 是各顶点简单表示的直和。

Hausel–Rodriguez-Villegas, arXiv:1309.4914v1, Theorem 1.3.1 给 H*(X;Z)≅H*(core;Z)，Corollary 1.3.6 更给 deformation retract。这一节用于任意 smooth semiprojective variety，不要求 X 另为 hyperkähler。Engel–Reineke Corollary 7.7 给任意 Q 的 X 以有色 rooted forests 为指标的 affine paving；因此其奇上同调为零，总维数恰为对应森林数。于是 H_f^{W=0}=∏_iT_i^{f_i}。

组合计数：每个根有固定颜色，每种箭头占一个固定子节点槽。将每个顶点的至多 Δ 个箭头槽嵌入 Δ 个有序槽，即将有色森林单射至 Δ-ary ordered forests。空树允许出现，故单树满足 T=1+tT^Δ，r 个指定根的森林满足 T^r。由一变量 Lagrange 反演，对 r>0，
\[
[t^k]T^r=\frac r{\Delta k+r}\binom{\Delta k+r}{k}.
\]
Δ=0 时即 binom(r,k)，Δ=1 时即 binom(k+r−1,k)；r=0 时 F_g=1。树与反演原理均为旧知识，本轮需查重的是 theta 的一般比较用途。

分析推论（HN 支配已由第二十八次复查的 full-category 证明闭合）：Δ≥2 时取 R_Δ=(Δ−1)^{Δ−1}/Δ^Δ。全部 F_g 在 |z_i|<R_Δ 收敛；实际上固定 g 在闭多圆盘 |z_i|≤R_Δ 绝对、一致收敛，且 |F_g(z)|≤(Δ/(Δ−1))^r，因为 T(R_Δ)=Δ/(Δ−1)。Δ=1 时半径 1，Δ=0 时上界是多项式。可以只取 Q^op 最大出度获得更紧界；在 F^B 与 F^{-B} 同时使用时，取双向最大值统一处理。不能据此宣称 θ_g 支撑有限，也不能宣称此粗 theta 界 sharp。

原始来源已由 root 实际核读：[Engel–Reineke, Smooth models of quiver moduli](https://www.math.uni-bielefeld.de/~sek/sem/stability/STABLESmoothReineke.pdf)，Proposition 3.6、Corollary 7.7、§7 树森林定义；[Hausel–Rodriguez-Villegas](https://arxiv.org/html/1309.4914v1)，§§1.1–1.3、Theorem 1.3.1、Corollary 1.3.6。Reineke [Punctual noncommutative Hilbert schemes](https://arxiv.org/abs/2510.25940) 为 2025 arXiv、2026期刊出版，已核 §5 的 free-loop 情形，但不作为这里任意 Q 的依据；其 IH 数量级不能替代普通上同调。

## B. 实际 Wolfram 大规模验证与失败记录

四个独立种子 2611141210–2611141213，每批128个随机斜对称箭图，总计512个，秩3–16；每图10次随机变异，F-polynomial 以总根次数6截断，所有 y_i=t。总计5,120次变异、35,840项系数上界比较、35,840项非负性检查、33,768项有色森林上界比较、5,120次 G^T C=I 检查；失败0。非恒定变异 jets 合计4,275。计算检验递推、符号与组合上界，不代替一般 HN 或几何证明。

首次 degree8 / 64 图调用返回 Wolfram 内部错误，未取得结果，不能计入成功计算。随后先运行 degree6 / 8 图 pilot，560项上界、420项森林检查失败0；再按下列同一程序用四个种子各跑128图。以下保留实际成功程序及四批原回执。

```wolfram
ClearAll[mul,pow,shift,mut,fc];
SeedRandom[2611141210];dd=6;one=Join[{1},ConstantArray[0,dd]];
mul[a_,b_]:=Table[Sum[a[[j+1]]b[[k-j+1]],{j,0,k}],{k,0,dd}];
pow[a_,m_Integer]:=Module[{q=a-one,u=one,out=one},Do[u=mul[u,q];out=out+Binomial[m,j]u,{j,1,If[m>=0,Min[m,dd],dd]}];out];
shift[a_,m_Integer]:=If[m>dd,ConstantArray[0,dd+1],Join[ConstantArray[0,m],Take[a,dd+1-m]]];
fc[de_,r_,k_]:=If[r==0,Boole[k==0],If[de==0,Binomial[r,k],r Binomial[de k+r,k]/(de k+r)]];
bad={};checks=0;gchecks=0;forestchecks=0;positivechecks=0;maxrank=0;nonconstant=0;
Do[
 n=3+Mod[cas,14];maxrank=Max[maxrank,n];
 bb=ConstantArray[0,{n,n}];
 Do[bb[[i,j]]=RandomChoice[{0,0,0,0,0,0,-2,-1,1,2}];bb[[j,i]]=-bb[[i,j]],{i,n},{j,i+1,n}];
 base=bb;de=Max[Join[Total[Map[Max[#,0]&,base,{2}],{2}],Total[Map[Max[-#,0]&,base,{2}],{2}]]];
 cc=IdentityMatrix[n];gg=IdentityMatrix[n];ff=ConstantArray[one,n];
 Do[
 k=RandomInteger[{1,n}];eps=Sign[First[Select[cc[[All,k]],#!=0&]]];
 If[!And@@Thread[eps cc[[All,k]]>=0],AppendTo[bad,{"sign",cas,st}]];
 pp=one;qq=one;
 Do[pp=mul[pp,pow[ff[[i]],Max[bb[[i,k]],0]]];qq=mul[qq,pow[ff[[i]],Max[-bb[[i,k]],0]]],{i,n}];
 nv=mul[shift[pp,Total[Map[Max[#,0]&,cc[[All,k]]]]]+shift[qq,Total[Map[Max[-#,0]&,cc[[All,k]]]]],pow[ff[[k]],-1]];
 ng=-gg[[All,k]]+Sum[Max[-eps bb[[i,k]],0]gg[[All,i]],{i,n}];
 r=Total[Map[Max[-#,0]&,ng]];cap=Table[fc[de,r,j],{j,0,dd}];
 If[!And@@Thread[nv>=0],AppendTo[bad,{"negative",cas,st}]];positivechecks+=dd+1;
 If[!And@@Thread[nv<=cap],AppendTo[bad,{"majorant",cas,st,base,k,ng,nv,cap}]];checks+=dd+1;
 If[nv=!=one,nonconstant++];
 nc=Table[If[j==k,-cc[[i,j]],cc[[i,j]]+Max[eps bb[[k,j]],0]cc[[i,k]]],{i,n},{j,n}];
 nb=Table[If[i==k||j==k,-bb[[i,j]],bb[[i,j]]+Max[bb[[i,k]],0]Max[bb[[k,j]],0]-Max[-bb[[i,k]],0]Max[-bb[[k,j]],0]],{i,n},{j,n}];
 gg[[All,k]]=ng;ff[[k]]=nv;cc=nc;bb=nb;
 If[Transpose[gg].cc=!=IdentityMatrix[n],AppendTo[bad,{"duality",cas,st}]];gchecks++,
 {st,10}];
 adj=Map[Max[#,0]&,base,{2}];tt=ConstantArray[one,n];
 Do[tt=Table[pp=one;Do[pp=mul[pp,pow[tt[[j]],adj[[i,j]]]],{j,n}];one+shift[pp,1],{i,n}],{dd}];
 cap=Table[fc[de,1,j],{j,0,dd}];
 Do[If[!And@@Thread[tt[[i]]<=cap],AppendTo[bad,{"forest",cas,i}]];forestchecks+=dd+1,{i,n}],
 {cas,128}];
<|"Quivers"->128,"MaximumRank"->maxrank,"RootTruncationDegree"->dd,"MutationSteps"->gchecks,"CoefficientMajorantChecks"->checks,"CoefficientPositivityChecks"->positivechecks,"ForestMajorantChecks"->forestchecks,"NonconstantMutationJets"->nonconstant,"Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
```

```text
seed 2611141210
Out[1]= <|"Quivers" -> 128, "MaximumRank" -> 16, "RootTruncationDegree" -> 6, "MutationSteps" -> 1280, "CoefficientMajorantChecks" -> 8960, "CoefficientPositivityChecks" -> 8960, "ForestMajorantChecks" -> 8442, "NonconstantMutationJets" -> 1086, "Failures" -> 0, "FirstFailure" -> {}|>

seed 2611141211
Out[1]= <|"Quivers" -> 128, "MaximumRank" -> 16, "RootTruncationDegree" -> 6, "MutationSteps" -> 1280, "CoefficientMajorantChecks" -> 8960, "CoefficientPositivityChecks" -> 8960, "ForestMajorantChecks" -> 8442, "NonconstantMutationJets" -> 1077, "Failures" -> 0, "FirstFailure" -> {}|>

seed 2611141212
Out[1]= <|"Quivers" -> 128, "MaximumRank" -> 16, "RootTruncationDegree" -> 6, "MutationSteps" -> 1280, "CoefficientMajorantChecks" -> 8960, "CoefficientPositivityChecks" -> 8960, "ForestMajorantChecks" -> 8442, "NonconstantMutationJets" -> 1058, "Failures" -> 0, "FirstFailure" -> {}|>

seed 2611141213
Out[1]= <|"Quivers" -> 128, "MaximumRank" -> 16, "RootTruncationDegree" -> 6, "MutationSteps" -> 1280, "CoefficientMajorantChecks" -> 8960, "CoefficientPositivityChecks" -> 8960, "ForestMajorantChecks" -> 8442, "NonconstantMutationJets" -> 1054, "Failures" -> 0, "FirstFailure" -> {}|>
```

## C. 正系数形式逆的全正域解析匹配（证明完整）

设 F_i,H_i∈1+(z)R_{\ge0}[[z]] 都在某正多圆盘收敛。定义
\[
T_j(z)=z_j\prod_iF_i(z)^{-B_{ij}},\qquad
S_j(w)=w_j\prod_iH_i(w)^{B_{ij}}.
\]
假设形式恒等式 H(T)=F、F(S)=H，且两者 log-Jacobian determinant 恒等于1。令 Ω_F、Ω_H 为各自全部分量绝对收敛域在 R_{>0}^n 中的公共内部。则 S:Ω_H→Ω_F、T:Ω_F→Ω_H 是互逆实解析微分同胚，上述复合恒等式在整个域成立。这里 B 只需整数，定理本身不要求有理函数或 cluster 来源。

证明1：非负系数使 Ω_F、Ω_H 向坐标下方封闭且对数凸，故路径连通。各分量在正域严格正；每个正点附近取无零复邻域，整数正负幂均全纯。log-Jacobian 的形式恒等式先在小多圆盘成立，再沿连通域由解析恒等定理成立，故实际 Jacobian 处处非零。

证明2（Pringsheim 障碍）：非负系数幂级数在正实全坐标边界点 r 不可有与域内相符的全复邻域解析延拓。可令 φ(t)=f(tr)：t<1 位于原域，若半径>1，则某 t_0r（t_0>1）收敛，从坐标下方封闭性推出 r 是内部，矛盾；所以 φ 的半径是1，而 r 的复邻域延拓将使 φ 在 t=1 解析，违反一变量 Pringsheim。后一事实可用 ρ<1 处非负 Taylor 系数、Tonelli 与 binomial theorem 自证。此处只需严格正坐标，未借零坐标边界的额外论断。

证明3：在 Ω_H 中取从充分小正点到任意目标的路径 w(t)。起点有 S(w(t))∈Ω_F 且 F(S(w(t)))=H(w(t))。如首次离开 Ω_F 于 t_*，则 w_*=w(t_*)仍在 Ω_H，z_*=S(w_*)为全坐标正实边界点。S 在 w_* 的 Jacobian 非零，故有局部全纯逆 R；H_i∘R 给每个 F_i 在 z_* 的全复邻域延拓，并在相邻域内开集与原 F_i 相符。至少一分量的收敛域以 z_* 为边界，违反前步。因此 S(Ω_H)⊂Ω_F，复合恒等式沿连通域成立。对称证明 T(Ω_F)⊂Ω_H，直接代入即 T∘S=id、S∘T=id。证毕。

Pringsheim 是旧定理，不申报新颖性。root 实际读 [Harold P. Boas, Lecture notes on multidimensional complex analysis](https://haroldpboas.gitlab.io/courses/650-2019c/notes.pdf)，文件标明 2020-01-06 draft，§2.5 Lemma1（印刷p23）及证明。其给原始多变量参考 Scott–Sokal, J. Stat. Phys.118 (2005), Proposition2.11, p1170；该原文由代理继续核读。

## D. 支撑有限域内部的 κ 互逆（证明完整；收敛前提单独列明）

记 h_{H,i}(w)=inf_{a∈SuppH_i}w·a，𝒞_H=int{w:∀i,h_{H,i}(w)>−∞}，𝒞_F 类似。令
\[
\sigma_H(w)=w+B^T h_H(w),\qquad
\sigma_F(v)=v-B^T h_F(v).
\]
在 C 的假设及局部分片 determinant=1 的条件下，σ_H:𝒞_H→𝒞_F 与 σ_F:𝒞_F→𝒞_H 互为局部有限 PL homeomorphism，且 h_F(σ_H(w))=h_H(w)。

严格尾界：小多圆盘收敛给 c_a≤M R^{−|a|}。对 w∈𝒞_H，取 δ>0 使 w−δ1 仍在有限域，则 w·a≥c_i+δ|a|。于是 H_i(t^w) 对足够小 t>0 收敛，最小值 h_{H,i}(w) 由有限 exposed face 达到，并有 H_i(t^w)=t^{h_{H,i}(w)}(A_i+o(1))，A_i>0。这允许 w 的坐标为负，也允许多个最小根。局部统一的同类估计同时给 h_H 的局部有限 PL 性。

先证像在有限域：设 v=σ_H(w)。有 S_H(t^w)=t^v(c+o(1))、c_j>0。由 C，F_i(S_H(t^w))=H_i(t^w)。对任意固定 a∈SuppF_i，非负系数给 c_{i,a}S_H(t^w)^a≤H_i(t^w)。取 t→0 得 a·v≥h_{H,i}(w)，故 h_{F,i}(v)>−∞。此处只得到 finite domain，不直接偷换成 interior。

开映射步骤：generic 片上，若 A 的各行为 H_i 的唯一最小根，则 σ_H 的矩阵 J_ν=I+B^T A，det J_ν=1（本轮先前已由 formal Poisson 及 generic leading orders 证明）。任取 w_0，取小球只遇有限个闭包含 w_0 的片，各片有 σ_H(w)−σ_H(w_0)=J_ν(w−w_0)。令 c=min_ν s_min(J_ν)>0，则球面像避开以 σ_H(w_0) 为心、半径 cr 的小球。在该像球中取一个来自某片内部的 regular 值，Brouwer degree 是有限多个原像的 Jacobian 正号之和，严格正；degree 在整个小像球恒定，故小像球被覆盖。因此 σ_H 为开映射，结合前步得到 σ_H(𝒞_H)⊂𝒞_F。

最后 v∈𝒞_F 允许对 F_i(t^v(c+o(1))) 使用有限 exposed face 与严格尾估计，得到其 t-valuation 恰为 h_{F,i}(v)。解析恒等式遂给 h_F(v)=h_H(w)，代回即 σ_Fσ_H=id。对称得另一复合为id，证明完成。

翻回主系数记号：H_i=F_{-e_i}^{-B}，F_i=F_{-e_i}^{B}，D 为 DB 斜对称的正对角矩阵。对 w=Dg，有 h_H(Dg)=−D f_B(g)、σ_H(Dg)=D(g+Bf_B(g))。因此
\[
\kappa_B:\operatorname{int}\mathcal D_B\longleftrightarrow
\operatorname{int}\mathcal D_{-B}:\kappa_{-B}
\]
互逆，且 f_{-B}(κ_B(g))=f_B(g)。这不要求 all-theta-finite、不要求 DT permutes theta。斜对称情形可由 A 的森林界提供收敛前提；一般斜可对称情形暂保留已审收敛前提，不使用有缺口的折叠比较来自动取消它。

## E. 任意标签的形式 transport 恒等式

令 𝒫 为 negative→positive 的全主系数 path automorphism。𝒫(x_i)=x_i/F_i(z)，𝒫^{-1}(x_i)=x_iH_i(z)，𝒫^{-1}(z)=S_H(z)。broken-line transport 与反射 x↦x^{-1}、B↦−B、标签g↦−g 给
\[
F_{-g}^{-B}(z)=H(z)^g F_g^B(S_H(z)),\qquad
F_g^B(z)=F(z)^{-g}F_{-g}^{-B}(T_F(z)).
\]
g≤0 时 negative chamber 无 bend，因此 F_g^B=∏_iF_i^{-g_i}。任意 g 则由 leading product 与强正性得 F_g≤∏F_i^{(g_-)_i}，所以 basics 的收敛域也是全部 F_g 的共同收敛域。恒等式不等价于 DT 保持 theta 标签，也不能把 g 同时作为标签和 valuation weight 后直接推出 Laurent 有限性。

## F. 折叠审查后保留的精确正式结论

G 保持斜对称 cover 矩阵 B̃，轨道 O_i 大小 m_i。π为轨道和，D_0=diag(1/m_i)，A=π^TD_0，E=Aπ是群平均。定义 B 使 πB̃=Bπ。全主系数 π_2=diag(π,π)、A_2=diag(A,A)，Λ̃=[[0,I],[-I,B̃]]、Λ̄=A_2^TΛ̃A_2=[[0,D_0],[-D_0,D_0B]]。对任何 G-invariant Hamiltonian H 及任意 Laurent monomial X^v，
\[
\rho\{H,X^v\}_{\widetilde\Lambda}
=\{\rho H,\rho X^v\}_{\overline\Lambda}.
\]
只要求 H invariant，不要求 v invariant；ρ 不是整个代数的 Poisson homomorphism。

证明取轨道和 H_u=Σ_{u'∈Gu}X^{u'}，s=|Gu|，则 Σu'=sE_2u。群不变性给 Λ̃(E_2u,v)=Λ̃(E_2u,E_2v)，于是左边系数 ΣΛ̃(u',v)=sΛ̄(π_2u,π_2v)，恰为右边。对任意中间级数都成立，故可逐次迭代并取 exp(adH)。consistent diagram 的整条负室到正室 path element 是 invariant，遂得到所有 monomials 的 path-action intertwining。

负室无 bend 的直接证明：根增量 d_j∈N^n\\{0}、弯折时间−a_j<0、初始g≤0、终点Q<0。弯折点
q_j=Q+a_jg+BΣ_l min(a_j,a_l)d_l。
墙条件 d_j^TD_0q_j=0；对j求和，双和因D_0B斜对称消失，余下
0=(Σd_j)^TD_0Q+Σa_jd_j^TD_0g<0，
矛盾。因此辅助限制图的负室同样只有直线。

由 action intertwining 与无 bend，辅助图的 negative basics 满足精确恒等式
\[
\overline F_{-e_i}=\rho(F_{-e_b}^{\widetilde B}),\quad b∈O_i.
\]
无需分数lift、m_i次根或对数提取。进一步 g≤0 时 \overline F_g=∏_i(\overline F_{-e_i})^{-g_i}。这是对 MQ restriction 接口的正式澄清；一般 cluster F_{-e_i}^B≤\overline F_{-e_i} 仍未证明。

MQ A.10 的障碍保留：辅助 rank-one factor 1+z+z² 与 cluster factor 1+z 的比为 1+z²−z³+z⁴−⋯。rank-one 全部 wall actions 交换，所以它不能来自 usual-positive extra walls 的乘积。此事否定了先前 positive-subdiagram deletion 的证明用途，不否定 consistency，也未构成系数不等式本身的反例。

Burcroff–Lee–Mou 的确提供可用的 additive comparison：[Positivity of generalized cluster scattering diagrams, arXiv:2503.03719v1](https://arxiv.org/html/2503.03719v1)，§§8.1、9.2–9.3、Theorems8.11/9.9；[PNAS2025短文](https://pmc.ncbi.nlm.nih.gov/articles/PMC12067233/)。固定允许的初始几何下，wall 和 broken-line 系数是初始 exchange coefficients 的非负多项式，故参数逐项增大给 theta 逐项增大。高秩初始图为 coordinate full hyperplanes；rank2容许可数条 full lines。任意 MQ restriction 的额外 incoming 支撑与 primitive-normal functions 是否满足该模型，尚未证明；§9.3 A3/A4 不自动由folding保持。故仅保留条件接口，不宣称一般folding已修好。

折叠代理实际 Wolfram 验证：40个cover，秩12–28，包含C12/C15/C8不等轨道和非交换S3轨道1,2,3,6（一次及两次）；240矩阵恒等式、320整行Hamiltonian恒等式、1,280非不变monomial测试全部失败0。错误的“ρ全域Poisson”命题在1,274/1,280次测试中失败。这是对正确作用引理和必要限定的验证。

## G. 任意实际强正基的返回状态支撑消失

本小节固定无环 B 的拓扑排序 b_{ij}≥0（i<j），与前文反号排序对应。C={β_g:g∈Z^n} 是实际强正 Hamel 基，包含 ordinary atlas 的全部 cluster monomials，且按本轮此前结果每个β_g有非负归一化初始 F-polynomial P_g。令 opposite seed 的 injective cluster variables 为 I_i=β_{-e_i}；其 normalized H_i∈N[z_i,…,z_n]、常数项1，sink序列 n,…,1 的递推为 H_i=1+z_i∏_{j>i}H_j^{-b_{ji}}。

对任意g，E_g=∏x_i^{[g_i]_+}∏I_i^{[-g_i]_+} 强正展开到C，唯一根次数0项是β_g，系数1。ordinary Laurent positivity遂给
\[
0\le P_g\le_{\rm coeff}\prod_iH_i^{[-g_i]_+}.
\]
若0≠r∈N^n，k=min Supp(r)，则对j≤k，
(Br)_j=Σ_{l≥k}b_{jl}r_l≥0。
所以E_{Br}只使用i>k的I_i，其F-polynomial完全不含z_1,…,z_k。因P_{Br}非负且受其逐项支配，
\[
P_{Br}\ \text{不含 }z_1,\ldots,z_k,\qquad [z^r]P_{Br}=0.
\]
这是任意实际C的结论，不是只对theta或标准基的陈述。当前正在检查它与正返回核的合成是否能控制绝对jets，而非仅相对比值。

## H. 本轮查新与路线去留

| 来源或路线 | 已核内容 | 当前处理 |
|---|---|---|
| Engel–Reineke0706.4306、HRV1309.4914 | 任意Q的forest paving与实际core cohomology | 作为森林上界的旧几何输入；不报几何结果新颖 |
| Reineke2510.25940，2026期刊发表 | 核到loop-case nilpotent paving与ordinary/IH区别 | 不替代任意Q输入；保留审核记录 |
| Boas2020、Scott–Sokal2005 | 正系数正边界奇点障碍 | 用于解析逆分支；原Pringsheim不报新 |
| BLM2503.03719v1、PNAS2025 | 参数多项式正性及允许初始几何 | 条件性修补folding；未证明任意restriction满足 |
| GHKK/Mandel/Library中的 convergence 搜索 | 多处指formal投影或Laurent有限，不是分析收敛 | 明确区分；没有搜到同一定理不算优先权证明 |
| Hasse shift | 给K边界 ℓ_j+(B^Tℓ)_j≥0；ℓ≥0且ℓB=0的separator仍相容 | 单独不闭合D⊂K，不重复同一论证 |
| 新analytic κ机制 | interior互逆已证明，边界closure仍需K | 继续结合CMMM局部coercivity与taut finite-jet极限探索 |
| 返回状态支撑消失 | actual C标准单项式上界给无环一般证明 | 继续作用于return-kernel/drift主缺口 |

# 第二十八次路线复查：森林主控闭合、斜可对称比较桥与强基共同无零点域（2026-11-14 12:35 UTC）

本轮完成一般机制推进。森林主控已由独立代理及主线程核对承重原文，采用更短的 full-module-category 证明；斜可对称比较桥刚完成构造，另换新代理独立审核；任意实际强正基的正返回核给出共同无零点域和唯一渐近对数剖面。一般 Laurent 有限性逆命题与任意强基 theta 最小性仍未闭合，不把解析收敛当作有限支撑。

## A. 已闭合的斜对称森林主控：完整 full-category 证明

设 Q 有限、无自环、无二循环，允许有向长环，B 斜对称，主系数形式 theta 为 θ_g=x^gF_g(z)，z_i=y_i x^{Be_i}。令 f=[−g]_+、r=Σf_i，在 Q^op 上定义唯一常数项1的树级数
\[
T_i=1+z_i\prod_{a:i\to j}T_j.
\]
则逐系数
\[
0\le F_g\le F_{-f}\le H_f=\prod_iT_i^{f_i}.
\]
第一步由 x^{g_+}θ_{−f} 的强正 theta 展开、唯一零根项 θ_g 及全主系数指数得到。这里所有 theta 均可为无限形式级数。

取 W=0 及 FULL 有限维 CQ^op-mod。Davison–Mandel [1910.12915v3](https://arxiv.org/html/1910.12915v3) §6.2 式(79)的 χ_{K,t}=Σ_j dim H^j t^j X^d 没有 Euler 符号；Theorem6.3、式(82)是实际分次向量空间 HN 同构，任意稳定条件适用；Theorem6.6、式(85)是实际 super-Sym 同构，奇次数的 exterior 规则通过§2.4.3式(31)–(33)进入 E。Proposition6.14、Theorem6.15遂给正 BPS 多项式 Ω_d(t)∈N[t^{±1}]。这些结果容许 Q 有有向环；§6.3 Corollary6.20 的无环条件仅用于更强 Lefschetz 性质。

在 L=M⊕N 上取 Ω=[[0,−I],[I,−B]]、P=(B;I)。有 P^TΩP=B，(Pn)^TΩ(g,0)=n·g，所以 Bn=0 的根仍有实际作用。HN 扇区分解给一致图 D_ss；将每墙反射且取逆，D_aux={(-𝔡,A_𝔡^{-1})} 仍一致，因为 crossing 法向与取逆同时反转。其 negative→positive 总乘积为总 stack 元素 A；incoming germs 为 E(−Ω_d(t)Y^d) 的正输入。无 loops 保证简单根因子恰为 Ψ_t(Y_i)。

固定根高度 K，使用 [Argüz–Bousseau2102.11200v2](https://arxiv.org/html/2102.11200v2) §3.2 Propositions3.6、3.8、3.9（印刷20–21页），将 attractor germs 延为 full hyperplanes 后作 KS 完成。Bn≠0 时同法向 outgoing 墙不含 attractor Bn，有限高度可在其邻域避开这些墙，故完成具有同一 attractor 数据；Proposition3.8 的唯一性识别两图。Bn=0 时 Proposition3.9 并未排除 attractor0；所有锥墙包含0，给该中央射线全超平面上同一数据。亦可投影到 kn 度：若 α+β=kn，则 α^TBβ=0，因此 BCH 括号不能新造该中央次数。重建先在 root-dual 空间完成，再提升到忠实 principal 格，不能用商化 B 的版本漏掉根基。

给每个非简单 incoming 因子中心颜色 u_j，扩格 L⊕Z^J，形式取 Ω 的投影拉回。墙和 KS 完成都可柱状扩充为 𝔡×R^J；方向(v,e_j)的 incoming 判断与原v相同。DM Theorem2.15、Lemma3.8、Theorems3.9/3.10 给带色 theta 系数 N[t^{±1},u]。对一条投影 broken line 和所选带色单项式，颜色轨迹由累积色次数及终点唯一积分提升。固定根度颜色有界，故 u=0、1 的特化合法。u=0 只余简单输入，即 cluster 图；u=1 恢复辅助图，因而 F_{−f}^{cluster}≤F_{−f}^{aux}。

辅助图负室的 θ_{(-f,0)} 恰为 x^{-f}，包括某些 f_i=0 的边界。取终点 Q=(q,0)、所有 q_i<0，当前指数 m=(−f+Bd,d)、d≥0。沿每条直段及 bend，Ω(γ,m)守恒；若末段 d_final≠0，则初始冻结位置 y_initial=∫d(s)ds≥0，守恒量初值 −f·y_initial≤0，终值 −q·d_final>0，矛盾。因此只有直线。DM Theorem3.2 的 transport 给 θ_{−f,+}^{aux}=Ad_A(x^{-f})。

为识别 Ad_A，令 X_{d,f}=Hilb_{d,f}(Q^op) 为带 f_i 个有序 framing 向量、且这些向量循环生成的光滑拟射影模空间。加源顶点∞及 f_i 条∞→i，只在 framing 次数0或1工作。原顶点斜率0、∞斜率−1时，实际 HN 给 A^{fr}≡A E(x_∞) mod(fr≥2)。∞斜率+1时，含 framing 的稳定对象正是 cyclic 对象：含∞的真子对象有更大斜率，不含∞者斜率0。因此另一次实际 HN 给
\[
A^{fr}\equiv\left(1+u\sum_d h_{d,f}(t)X^{(d,1)}\right)A,\qquad u=t/(1-t^2).
\]

上述 h_{d,f} 有实际无符号几何含义。D_d=dim_C X_{d,f} 时，
\[
h_{d,f}(t)=t^{-D_d}\sum_j\dim H^j(X_{d,f},\mathbb Q)t^j\in N[t^{±1}],
\quad h_{d,f}(1)=\dim H^*(X_{d,f}).
\]
cyclic locus 上 G_d 作用自由；G_d×G_m 经(g,λ)↦(λ^{-1}g,λ)后第二因子平凡，所以 stable stack 真正同构 X_{d,f}×BG_m，不是待证明的 gerbe。其虚拟维数 D_d−1 恰给公共因子 u。比较 framing-degree1，在实际张量 HN 等式中消去此公共因子，得 Ad_A(x_∞)=Σ_d h_{d,f}(t)X^{(d,1)}。

配对保持的映射 e_i↦(Be_i,e_i)、e_∞↦(−f,0) 给经典式
\[
Ad_A(x^{-f})=x^{-f}H_f(z),\qquad
H_f=\sum_d \dim H^*(X_{d,f})z^d.
\]
只对已经为 Laurent t 多项式的 adjoint 系数取 t=1，不能对含量子分母的 stack 元素 A 本身逐项取 t=1。r>0 时该格映射为嵌入；r=0 时直接 H_0=F_g=1。

[Engel–Reineke0706.4306](https://www.math.uni-bielefeld.de/~sek/sem/stability/STABLESmoothReineke.pdf) Corollary7.7 对任意有限 Q 给 X_{d,f} 的 affine paving，胞腔由有色路径森林标号。每个 affine cell 给 compactly supported cohomology 的一个偶次数维数；X 光滑，Poincaré duality 使 ordinary 总 Betti 数相同。每个有序 framing 向量对应一个可空根树，非空颜色i根占权z_i，并对每条 i→j 箭附一个可空子树，平行箭区分。因此 H_f=∏T_i^{f_i}。这个 full-category 主证明不依赖 semiprojective core、φ_0 或奇异 nilpotent fibre 的 IH；前一版本 core 链保留作交叉核验。

给各顶点出箭分配至多 Δ 个有序槽（Δ≥max outdeg Q^op），得到有色森林到 r 根有序 Δ 叉森林的单射。T_Δ=1+tT_Δ^Δ，r>0 时
\[
[t^k]T_\Delta^r=\frac r{\Delta k+r}\binom{\Delta k+r}{k}.
\]
Δ≥2 时 R=(Δ−1)^{Δ−1}/Δ^Δ、τ=Δ/(Δ−1)，且 T_Δ(R)=τ。故固定g的 F_g 在共同闭多圆盘 |z_i|≤R 绝对一致收敛，|F_g|≤τ^r；ρ=max|z_i|<R 时
\[
|F_g-F_g^{\le K}|\le(\rho/R)^{K+1}\tau^r.
\]
Δ=1给开多圆盘半径1；Δ=0为多项式；r=0为1。

更精确的森林系数渐近为
\[
[t^k]T_\Delta^r\sim
\frac{r\Delta^{r-1/2}}{\sqrt{2\pi}(\Delta-1)^{r+1/2}}
R^{-k}k^{-3/2}.
\]
这一常数来自 Lagrange 系数和 Stirling，不声称是 theta 系数的最优增长率或最优半径。与 [KS2005.10651v3](https://arxiv.org/html/2005.10651v3) §3.8 区分：其 Def3.8.1/Prop3.8.2、Remark3.8.3(c)把解析稳定数据与统一指数界分开；当前定理只处理 cluster theta 的该共同域，不解决其一般全部扇区问题。Bridgeland1611.03697及Barbieri–Stoppa1512.01176的相关解析构造含增长/收敛输入，未见直接覆盖本森林界。未搜索到同一陈述不等于证明优先权。

## B. 斜可对称比较桥：已构造，正在新代理独立审核

令 D=diag(d_i)>0 整数左 symmetrizer，C=DB 斜对称。候选桥为同 root 变量下
\[
F_g^B(z)\le_{\rm coeff} F_{Dg}^{C}(z).
\]
主线程已独立核算以下完整接口，另开全新代理作反向审核。此处不使用有问题的 MQ positive-subdiagram deletion。

取完整 principal 指数格及其对偶，W_B=[[BD^{-1},−D^{-1}],[D^{-1},0]]，w_i=(Be_i,e_i)。在 [BLM2503.03719v1](https://arxiv.org/html/2503.03719v1) Defs8.1/8.2 取 d_new=(d_i²;d_i)、ℓ_i=d_i，则 W_B d_new=[[BD,−I],[D,0]] 整数，W_B(d_i²e_i)/d_i=w_i primitive，principal 冻结块保证 injectivity。若 c=gcd_i d_i>1，为满足Def8.1的 gcd=1，改用 cW_B 与 d_new=(d_i²/c;d_i/c)；矩阵乘积、primitive方向及初始图均不变。

同一 universal 初始图为 (e_i^⊥,1+Σ_{k=1}^{d_i}p_{i,k}z_i^k)。下参数 p_{i,1}=1、其余0给普通B图；上参数 p_{i,k}=binom(d_i,k)给(1+z_i)^{d_i}。BLM Theorem8.11 的 N[p] 墙系数及 Definition8.23 的正整数幂 broken lines 给 theta 参数正性。特化合法性不能省略：赋 wt(p_{i,k})=ke_i，KS 和 broken lines 保持参数权重=根次数；固定根a只容许 Σ_k kα_{i,k}=a_i 的有限参数单项式，故实际系数为有限 N[p] 多项式，参数取整数在 root-adic 完成中合法。于是下 theta 逐项≤上 theta。

φ=diag(D,I) 是完整指数格有限指数嵌入，φW_Bφ^T=[[C,−I],[I,0]]，φ(Ba,a)=(Ca,a)，φ(g,0)=(Dg,0)。C墙 primitive normal(a,0) 拉回为(Da,0)；k_a=gcd_i(d_i a_i) 后，源primitive normal=(Da/k_a,0)，源wall function须取(φ^{-1}f)^{k_a}。这是正整数幂，实际作用指数 k_a(Da/k_a)·m=a·Dm 相同。方向 W_B(Da/k_a,0)=(Ba,a)/k_a，incoming/outgoing保持；全部 C 根单项式都在φ格像中。初始a=e_i给(1+z_i)^{d_i}。一致完成唯一性及逐段φ映射的速度、指数、转折幂对应，识别上theta为F_{Dg}^C。中央Ba=0的冻结根仍保留。

若此桥通过独立审核，结合A即得全部经典 skew-symmetrizable 种子的
\[
F_g^B\le\prod_iT_i^{d_i[-g_i]_+},\qquad r_D(g)=\sum_i d_i[-g_i]_+,
\]
T_i使用Q_{DB}^{op}。全部显式半径、闭多圆盘和尾误差将把r替为r_D(g)。这还把前一轮正收敛域互逆及 intD 上 κ 互逆从斜对称扩到一般斜可对称；相关 Poisson 权重D必须沿用前文，不能直接丢掉。

实际 Wolfram 扩大验证：448个随机斜可对称种子，秩3–16，di取1、2、3、4、6、12；4,480次变异，31,360个总根次数≤6的系数上界检查，31,360个非负系数检查，4,480次 GᵀDC=D 检查，28,238个森林系数检查，全部失败0。非恒定变异jets为3,550。这只检查公式与约定，不替代一般证明。四批seed为2611141230（64例）、2611141231–1233（各128例）。

## C. 实际强正基的统一无零点域与唯一渐近剖面

取无环主系数B，C={β_h}为包含全部普通丛单项式的实际强正 Hamel 基，依前文归一化 β_h=x^hP_h(z)。令 H_i=P_{−e_i} 为固定 opposite CM 的 F-polynomial，H(t)=∏H_i(t,…,t)，L=||B||_{1→1}。对任意级数 A(f)(t)=Σ_q|[z^q]f|t^{|q|}。以下所有 ≼ 均为一变量总次数 majorant，不能误读为逐个多重指数的绝对不等式。

实际 return equation 为 P_dP_{−d}=1+Σ_{s>0}a_d(s)z^sP_{Bs}，a_d(s)∈N。CM正包络给 P_dP_{−d}≼∏H_i(z)^{|d_i|}，所以 a_d(s)≤[z^s]∏H_i^{|d_i|}。由已证正返回核 c_{d,h}(q)≤K_d(q)、K_d(0)=1、K_d(q)=Σ_{0<s≤q}a_d(s)K_{Bs}(q−s)，定义
\[
U=tH(U)^L,\quad U(0)=0,\qquad W=H(U).
\]
IFT给 U 在0附近解析，正迭代给非负系数。对总次数N、同时对全部d归纳，利用 ||Bs||_1≤L|s|，得
\[
K_d^\Delta(t)\preceq W(t)^{||d||_1}.
\]
每次递归剩余次数<N，所以未暗中假设对无穷多d的一致解析性。

令 R_{h,d}=P_{h+d}/P_h（先在形式环）。乘法的精确等式是
\[
R_{h,d}=P_d-\sum_{s>0}c_{d,h}(s)z^sR_{h,d+Bs}.
\]
任意R_{h,v}沿整数坐标路径精确分解为||v||_1个平移后的±e_i生成比值。定义 M(0)=1 为
\[
M=H(t)+M\bigl(W(tM^L)-1\bigr).
\]
在(0,1)对M的隐函数导数为1，故M解析；每个W非恒定项含t，因此递归系数非负且良定义。同时对所有h、±e_i和次数N归纳，路径长度≤1+L|s|，给
\[
A(R_{h,\pm e_i})\preceq M,\qquad A(R_{h,d})\preceq M^{||d||_1}.
\]

选ρ在M收敛半径内且M(ρ)−1<1。每个生成比值在|z_i|<ρ解析且|R−1|<1，因而无零点。沿0→h的有限坐标路径乘积给一个无零点解析函数，其Taylor级数就是实际多项式P_h；由恒等定理相等。因此所有实际强正基的全部P_h共享同一个复数无零点多圆盘。这个ρ仅依赖B及固定CM多项式H_i，与C、h均无关。定义
\[
J(t)=-\log(2-M(t))=\sum_{k\ge1}(M-1)^k/k.
\]
则 A(log R_{h,±e_i})≼J，A(logP_{h+d}−logP_h)≼||d||_1J，log分支在0取0。

实正小z上，P_gP_h≥P_{g+h}且P_h≥1。故u_h=logP_h非负、对标签次可加，Fekete给
\[
p_C(g,z)=\lim_{N\to\infty}\frac1N\log P_{Ng}(z)
=\inf_N\frac1N\log P_{Ng}(z).
\]
无零点域中的log函数由J统一局部有界；Montel给收敛子列。任意两个极限在实正开盒相同，逐变量恒等定理说明该实盒为全纯唯一集，所以整个序列局部一致收敛，全部Taylor系数也收敛。

对整数标签，p_C(kg)=kp_C(g)、p_C(g+h)≤p_C(g)+p_C(h)，J给标签Lipschitz界。先延至Q^n再延至R^n；对实正z，它对Q为正齐次凸函数，对z为全纯函数，且
\[
N^{-1}\log P_{\lfloor NQ\rfloor}(z)\longrightarrow p_C(Q,z)
\]
在Q紧集及较小复多圆盘上局部一致。CM射线上β_{Ng}=β_g^N，所以p_C(g,z)=logP_g(z)，全实CM锥由连续性确定。不同基的剖面共享同一凸性、Lipschitz与CM边界约束；未声称实际基所实现的剖面集合对凸组合封闭。

当前直接缺口是 p_C=p_theta，尚未证明。若该等式成立，则所有固定log-jets的相对theta差在O(N)大小的深散射室盒中均为o(N)。逐层先固定低阶差后，CM正乘法给整数单调增量；telescoping使有非零增量的边数为o(N^n)，对任意固定窗口用并集界得到实际平移块上所有增量同时为0。这样的真实平台可用于有限阶theta系数提取。这条条件路线控制相对theta差，避免要求本来可能线性增长的绝对P_h系数有界。

对话中的 bangle/power 基 self-loop 举例已撤回：该基不是强正基，不能作 actual-C 反例。Thurston1310.1959v2 Example4.13 的环带乘积出现 L^3−L。band/triangular 基可给替代，但主系数实际强正性的引用及精确归一化继续核对；未完成前不据此否定一般返回核消失命题。前一节返回状态 [z^r]P_{Br}=0 的一般证明不受影响。

## D. 文献与路线复查记录

[Scott–Sokal, The repulsive lattice gas, the independent-set polynomial, and the Lovász local lemma](https://people.maths.ox.ac.uk/scott/Papers/lovasz.pdf)，2005，Proposition2.11 原始证明已由root读到（预印本18–19页）：非负Taylor级数在正实连接邻域可解析延拓时，其绝对收敛范围受正边界控制。本轮已用于正域解析互逆，不把旧Pringsheim原则报新。Boas讲义实际稿日期为2020-01-06，路径中2019并非稿件日期。

| 来源或路线 | 本窗口核查与处理 |
|---|---|
| DM1910.12915v3、AB2102.11200v2、ER0706.4306 | unsigned HN、中央attractor、full-framed stack及森林paving承重链全部核过；森林比较使用此完整链 |
| KS2005.10651v3 §3.8 | 解析稳定数据与统一指数增长区分清楚；不宣称解决其一般问题 |
| BLM2503.03719v1 §§8.1、8.3、9.3 | root实读fixed data、primitive normal、参数正性，正用于新symmetrizer桥；旧MQ折叠错误不回填 |
| Nakanishi–Rupel1504.06758；Cheung–Kelley–Musiker；Mou2024 | companion与广义theta可能覆盖部分格变换，已交新代理精查，保留新颖性待核 |
| Tang2611.00238v1，2026-11-09稿 | root取回41页原PDF并读引言，研究原交换系数正性；全文强审未完成，不用其结论 |
| DM§1.4、LLRZ2014§5 | 任意强正基最小性相关猜想有明确先例，不能把目标本身报新；本轮新增的是实际Hamel归一化、返回核及解析机制 |
| Reading–Stella2603.19391v4／SIGMA22(2026)109 | 11月8日期刊版本此前已审，不重复当新文；mutable-only pointed与full frozen degree须区分 |
| 正域/κ内部互逆 | skew-symmetric收敛输入已闭合；一般skew-symmetrizable待新桥独审，不从内部互逆推出D⊂K |
| μ_g初项格映射 | canonical theta代理正在用strict coercivity补taut有限最小值；additive/saturated image到满格尚未证明 |
| 任意强正基profile | U/W/M共同无零点与唯一极限已完成推导；profile相等仍为主缺口 |

## E. 可重复计算代码：斜可对称森林主控与解析majorant

```wolfram
ClearAll[mul,pow,shift,mut,fc];
SeedRandom[2611141230];dd=6;one=Join[{1},ConstantArray[0,dd]];
mul[a_,b_]:=Table[Sum[a[[j+1]]b[[k-j+1]],{j,0,k}],{k,0,dd}];
pow[a_,m_Integer]:=Module[{q=a-one,u=one,out=one},Do[u=mul[u,q];out=out+Binomial[m,j]u,{j,1,If[m>=0,Min[m,dd],dd]}];out];
shift[a_,m_Integer]:=If[m>dd,ConstantArray[0,dd+1],Join[ConstantArray[0,m],Take[a,dd+1-m]]];
fc[de_,r_,k_]:=If[r==0,Boole[k==0],If[de==0,Binomial[r,k],r Binomial[de k+r,k]/(de k+r)]];
bad={};checks=0;gchecks=0;forestchecks=0;positivechecks=0;maxrank=0;nonconstant=0;
Do[
 n=3+Mod[cas,8];maxrank=Max[maxrank,n];
 dv=RandomChoice[{1,2,3,6},n];dm=DiagonalMatrix[dv];bb=ConstantArray[0,{n,n}];
 Do[vv=RandomChoice[{0,0,0,0,0,0,-1,1}] LCM[dv[[i]],dv[[j]]];bb[[i,j]]=vv/dv[[i]];bb[[j,i]]=-vv/dv[[j]],{i,n},{j,i+1,n}];
 base=bb;symbase=dm.base;de=Max[Join[Total[Map[Max[#,0]&,symbase,{2}],{2}],Total[Map[Max[-#,0]&,symbase,{2}],{2}]]];
 cc=IdentityMatrix[n];gg=IdentityMatrix[n];ff=ConstantArray[one,n];
 Do[
 k=RandomInteger[{1,n}];eps=Sign[First[Select[cc[[All,k]],#!=0&]]];
 If[!And@@Thread[eps cc[[All,k]]>=0],AppendTo[bad,{"sign",cas,st}]];
 pp=one;qq=one;
 Do[pp=mul[pp,pow[ff[[i]],Max[bb[[i,k]],0]]];qq=mul[qq,pow[ff[[i]],Max[-bb[[i,k]],0]]],{i,n}];
 nv=mul[shift[pp,Total[Map[Max[#,0]&,cc[[All,k]]]]]+shift[qq,Total[Map[Max[-#,0]&,cc[[All,k]]]]],pow[ff[[k]],-1]];
 ng=-gg[[All,k]]+Sum[Max[-eps bb[[i,k]],0]gg[[All,i]],{i,n}];
 r=dv.Map[Max[-#,0]&,ng];cap=Table[fc[de,r,j],{j,0,dd}];
 If[!And@@Thread[nv>=0],AppendTo[bad,{"negative",cas,st}]];positivechecks+=dd+1;
 If[!And@@Thread[nv<=cap],AppendTo[bad,{"majorant",cas,st,base,k,ng,nv,cap}]];checks+=dd+1;
 If[nv=!=one,nonconstant++];
 nc=Table[If[j==k,-cc[[i,j]],cc[[i,j]]+Max[eps bb[[k,j]],0]cc[[i,k]]],{i,n},{j,n}];
 nb=Table[If[i==k||j==k,-bb[[i,j]],bb[[i,j]]+Max[bb[[i,k]],0]Max[bb[[k,j]],0]-Max[-bb[[i,k]],0]Max[-bb[[k,j]],0]],{i,n},{j,n}];
 gg[[All,k]]=ng;ff[[k]]=nv;cc=nc;bb=nb;
 If[Transpose[gg].dm.cc=!=dm,AppendTo[bad,{"duality",cas,st}]];gchecks++,
 {st,10}];
 adj=Map[Max[#,0]&,symbase,{2}];tt=ConstantArray[one,n];
 Do[tt=Table[pp=one;Do[pp=mul[pp,pow[tt[[j]],adj[[i,j]]]],{j,n}];one+shift[pp,1],{i,n}],{dd}];
 cap=Table[fc[de,1,j],{j,0,dd}];
 Do[If[!And@@Thread[tt[[i]]<=cap],AppendTo[bad,{"forest",cas,i}]];forestchecks+=dd+1,{i,n}],
 {cas,64}];
<|"SkewSymmetrizableSeeds"->64,"MaximumRank"->maxrank,"RootTruncationDegree"->dd,"MutationSteps"->gchecks,"CoefficientMajorantChecks"->checks,"CoefficientPositivityChecks"->positivechecks,"ForestMajorantChecks"->forestchecks,"NonconstantMutationJets"->nonconstant,"Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
```

上段为第一批64例。其余三批把SeedRandom改为2611141231、2611141232、2611141233；n=3+Mod[cas,14]；dv=RandomChoice[{1,2,3,4,6,12},n]；cas上限及报告例数改128。其余代码逐字相同。三批各1,280变异、8,960majorant系数、8,442forest系数检查，失败0；非恒定jets依次1,036、1,038、997。

```wolfram
ClearAll[t,u,m,H,U,W,M,trunc,n,c];
n=8; c=2;
trunc[p_]:=Normal@Series[p,{t,0,n}];
H[u_]:=(1+u(1+u)^2)(1+u);
U=Nest[trunc[t H[#]^c]&,0,n];
W=trunc[H[U]];
M=Nest[Function[m,trunc[H[t]+m((W/.t->t m^c)-1)]],1,n];
<|"H"->Expand[H[t]],"Ucoefficients"->CoefficientList[U,t],"Wcoefficients"->CoefficientList[W,t],"Mcoefficients"->CoefficientList[M,t],"Uresidual"->trunc[U-t H[U]^c],"Mresidual"->trunc[M-H[t]-M((W/.t->t M^c)-1)]|>
(* Actual U={0,1,4,26,202,1727,15686,148551,1450536};
W={1,2,11,79,645,5684,52692,506405,5000052};
M={1,4,38,626,12416,268228,6115236,144798127,3526303626};
both residuals 0 through degree8. *)
```

# 第二十九次路线复查：全部经典种子的解析展开与有限 Jacobi 行停止证书（2026-11-14 12:55 UTC）

第二十八次的 symmetrizer 比较桥现已通过另一名全新代理独立审核。其参数正性可使用更早的 Mou2024；比较桥定位为旧正性和 companion 格变换的组合应用。森林主控、共同解析域和可核验 Laurent 停止证书因此适用于一般经典斜可对称主系数种子。本节保留精确输入和新颖性边界；全称 D⊂K 与任意实际强正基最小性仍未证明。

## A. 斜可对称比较桥的最终审查及更早输入

对任意正整数左 symmetrizer D，gcd规范使用 c=gcd_i d_i、ω=cW_B、d_new=(d_i²/c;d_i/c)，保证固定整数总gcd=1。BLM 原始多项式参数证明和 φ=diag(D,I)、k_a=gcd_i(d_i a_i) 的完整法向对应均已核过。因此
\[
F_g^B(z)\preceq F_{Dg}^{DB}(z)
\]
为本轮已闭合的比较应用；root变量保持不变，没有 z_i↦z_i^{d_i}。

更早输入为 [Mou, Scattering diagrams for generalized cluster algebras, 2110.02416v2](https://arxiv.org/pdf/2110.02416)，2024版本。Theorem6.31（印刷41–42页）可取墙函数 (1+tX^m)^c，c为正整数，并明确 m=Σa_iw_i、t=∏t_{is}^{u_{is}}、Σ_su_{is}=a_i。Definitions8.5/8.6、Theorem8.7定义任意标签形式theta，bend幂为正整数。故取 f_i=∏_{s=1}^{d_i}(1+t_{is}z_i)，从(t_i1=1,其余0)到(全部1)已给所需参数单调。无需把2025 BLM更强的原交换系数正性说成此桥的首次必要门槛。

使用Mou正文全mutable写法时，先在2n方向上取 r=(d_i;1)、w_i=(Be_i,e_i)、w_{n+i}=(-e_i,0)，保留全部参数次数。先令附加方向参数为0，这在参数完备环是合法商映射，杀掉所有附加root项；再对剩余每个固定root实施0/1特化，因上述齐次性该系数只含有限参数单项式。不能先丢掉附加次数，把(-e_i,0)当作原正root增量；也不能直接引用Mou Lemma6.20，因为其明写的标量特化为非零。

查新归属：NR1504.06758 的 companion 特化，以及 [Cheung–Kelley–Musiker2110.08157v3](https://arxiv.org/pdf/2110.08157) §6（印刷51–56页）的固定格、法向尺度和c/g/F比例关系，都是明确先例。已读章节未见任意形式theta的上述不等式被单独陈述；本轮不据此宣布首创。新的应用范围应放在与森林上界、显式收敛和有限列证书的组合上。

## B. 多变量精确森林系数与可调收敛证书

令 C=DB，A_ij为Q_C^op中i→j箭数，f=Dg_-。则F_g^B≼∏T_i^{f_i}，T_i=1+z_i∏T_j^{Aij}。任取τ_i>1，令
\[
r_i=\frac{\tau_i-1}{\prod_j\tau_j^{A_{ij}}}.
\]
从1作树高度迭代，在z=r处单调且≤τ，故T_i(r)≤τ_i。由正系数求和，F_g在闭多圆盘|z_i|≤r_i绝对一致收敛，|F_g|≤∏τ_i^{f_i}。对q=max_i|z_i|/r_i<1，
\[
|F_g-F_g^{\le K}|\le q^{K+1}\prod_i\tau_i^{f_i}.
\]
无需在边界使用隐函数定理。标量Δ界是一个方便的统一选择，而非最优半径。

对root a，记N_j=f_j+(A^Ta)_j，C_f(a)=[z^a]∏T_i^{f_i}。置U_i=T_i−1，应用旧的多变量Lagrange–Good反演：
\[
C_f(a)=[u^a]\prod_j(1+u_j)^{N_j}
\det\!\left(I-A\operatorname{diag}\frac{u_j}{1+u_j}\right).
\]
在N_j>0的坐标上可写成
\[
C_f(a)=\prod_j\binom{N_j}{a_j}
\det\!\left(I-A\operatorname{diag}\frac{a_j}{N_j}\right).
\]
若N_j=a_j=0，对角比值取0；若某N_j=0<a_j，整个系数为0。以系数提取式为统一定义，避免对负上/下标二项式作不必要的约定。

对应的principal-minor展开为Σ_S(−1)^{|S|}det(A_SS)∏_{j∈S}[u_j^{a_j}]u_j(1+u_j)^{N_j−1}∏_{j∉S}binom(N_j,a_j)。固定每种颜色的父顶点BFS编号，每种颜色j有N_j个候选根/子槽，选择a_j个占用槽可唯一重建有效森林，故
\[
0\le[z^a]F_g^B\le C_f(a)\le\prod_j\binom{f_j+(A^Ta)_j}{a_j}.
\]
尤其a_j>f_j+(A^Ta)_j即该theta系数为0。树计数及Good是旧组合原理；这里只报告它们用于已证明theta支配后的显式界。

## C. 有限 Jacobi 行的有限阶可核验证书

此节接入前文已证明的斜对称有限Jacobi列theta上界，不另假设genteel或reddening。令A_C=widehat{kQ_C}、m为箭理想、I(W)=closure⟨∂_aW⟩。对每个i∈supp(g_-)可分别选择W^(i)、N_i。证书是在有限路径商A_C/m^{N_i+1}中验证
\[
e_i m^{N_i}\subseteq e_i I(W^{(i)})+e_i m^{N_i+1}.
\]
只需W的长度≤N_i+1部分。有限关系矩阵须列出所有u∂_a(W_{≤N_i+1})v的完整非齐次截断；不能把非齐次关系的各次数部分拆成独立零关系。

因为e_iI是右理想，右乘m并迭代代入给e_i m^{N_i}⊂e_iI+e_i m^L，对所有L>N_i成立。e_iI=I∩e_iA_C闭，因此e_i m^{N_i}⊂e_iI。等价地，e_i m^{N_i}由有限条长度N_i路径生成，其商M满足Mm=M，而m⊂Jac(A_C)，非交换Nakayama给M=0。底层代数原理已有精确先例：[Hua–Zhou1803.06128v5](https://arxiv.org/pdf/1803.06128)，Lemma2.14（印刷12页）及Proposition3.14（19页）；不将这个引理报新。

由长度<N_i的路径与有限关系矩阵端点分块可精确算
\[
K_{ji}=\dim_k e_iJ(W^{(i)})e_j.
\]
允许不同i使用不同势，只是避免实际寻找共同势的计算便利。斜对称基本列上界及正乘法给
\[
F_g^B\preceq F_{Dg}^{C}
\preceq\prod_i(F_{-e_i}^{C})^{d_i[-g_i]_+}
\preceq\prod_iH_i^{d_i[-g_i]_+}.
\]
因此
\[
\operatorname{Supp}F_g^B\subseteq[0,KDg_-],\qquad
|a|\le\mathbf1^TKDg_-.
\]
获得证书后，散射与broken-line计算截断至这个总root次数便得到完整Laurent展开。该证书并未证明覆盖每个有限theta。

势尾部的稳定性明确：若W与W'在长度≤N_i+1相同，则循环导数之差落m^{N_i+1}，证书矩阵相同，两者均有e_i m^{N_i}=0于Jacobi商。长度<N_i的商维数也相同。这是旧高jet/完备Nakayama机制在本停止证书中的直接应用，不依赖2026稿件。

root补充的存在性说明（附自含论证，待下一代理交叉核验）：若某形式势使dim e_iJ=d<∞，取L=d，则有限商e_iA_C/(e_iI+e_i m^{L+1})维数为d。其关系矩阵中一个给出维数≤d的非零minor定义有限jet参数空间的非空Zariski开集。在此开集，若截断模的m^d层非零，之前d次包含都严格（m在截断环中幂零），模维数至少d+1，矛盾。因此m^d层为0，再用Nakayama得到完整行有限。矩阵系数为势系数的整数多项式，非零minor有整数参数取值，故存在整数系数有限多项式势证书。有限多个顶点的这些开条件在共同足够高jet空间可同时满足。于是逐个顶点选势没有增加存在性覆盖范围；枚举整数势、N及有限矩阵可半判定此证书类别，但不是全部有限theta的判定算法。

## D. 全部斜可对称种子的正域与κ内部互逆

第二十七次C/D解析桥所需基本theta的正收敛已由A闭合，所以现在适用于所有经典斜可对称B。权重约定必须保持前文：
\[
L_i(g)=\sup_{a\in Supp H_i}(-Dg)\cdot a,\quad
f(g)=D^{-1}L(g),\quad \kappa_B(g)=g+Bf(g).
\]
取t↓0、w=t^{Dg}，则H_i(w)∼t^{−L_i(g)}。因B^T=−DBD^{-1}，
\[
\log_t S_H(w)=Dg-B^TL=D\kappa_B(g).
\]
反向T的指数为Dκ+B^TL=Dg。由已证Pringsheim域互逆及strict coercivity，κ_B与κ_{−B}在各自支撑有限域的内部互逆，局部有限PL且各片det=1。这里不从内部互逆推出g对应theta已有限。

generic片A的第i行为H_i唯一暴露root，L=−ADg、C_0=D^{-1}AD、K_0=I−BC_0。代理另得到任意label的候选初项兼容：令a为F_m^{−B}在g的领先root、b为F_{−m}^B在κg的领先root、μ_g^H(m)=m−Ba，则
\[
b=a+C_0\mu_g^H(m),\qquad
\mu_{\kappa g}^{F}(-m)=-K_0\mu_g^H(m).
\]
其推导使用任意label transport、共同正收敛及局部有限极小面；目前作为待独立审核的新接口保存。领先像的加法封闭、饱和性到满格的最后一步尚未建立；只用2n个基本领先向量的正锥已不够，不能把det=1当P-matrix性质。

## E. 最小性主线的实际基检验与一次必要纠正

新profile代理对actual θ与Qin CTB作fixed-root比较，先按量子injective标准基的bar-unitriangular递归计算CTB，再仅以v=1检查经典候选profile；不把任意经典C假定可量子提升。原文定位为 [Qin1501.04085v5](https://arxiv.org/pdf/1501.04085) §5.4式(19)、Definition5.4.1，以及Definition6.3.1、Lemma6.3.2。3-Kronecker g=(-20,20)，root总次数≤4时
\[
P_C=1+20z_1+190z_1^2+1140z_1^3+4845z_1^4
+2z_1z_2+94z_1^2z_2+1332z_1^3z_2+10z_1^2z_2^2,
\]
\[
P_\theta=1+20z_1+190z_1^2+1140z_1^3+4845z_1^4
+60z_1^2z_2+1060z_1^3z_2.
\]
Wolfram独立检得log(P_C/P_theta)=2z1z2−6z1²z2+12z1³z2+8z1²z2²到该次数。N=12,20,40,60所得差相同；若干非墙斜率固定jets直接相同。这支持profile相等的研究方向，但不能推出任意C或全阶结论。

band返回环纠正现已核定。取B=[[0,2],[-2,0]]，r=(1,1)，d=Br=(2,−2)，δ=(-1,1)，a=x1、b=x2、c=(1+y2a²)/b、Z=b/a+y1/(ab)+y1y2a/b。band S2=Z²−y1y2=θ_{2δ}+y1y2，D_0=a²c²=β_d。实际恒等式为
\[
D_0S_2=1+2y_2a^2+y_2^2a^4+2y_1c^2+y_1^2c^4+y_1y_2D_0.
\]
故a_d(r)=1，但P_d=(1+z2)²有[z1z2]P_d=0。coefficient-free band强正由[Thurston1310.1959v2 Example4.13](https://arxiv.org/pdf/1310.1959)及SL2二阶递推给出；principal基由与theta的有限单位三角变换得实际Hamel性。B可逆使homogeneous乘法每个输出的冻结幂唯一，故coefficient-free正系数唯一提升为principal正系数。bangle幂基有L³−L负结构项，先前该例已撤回。此例只防止错误删除正返回环，不否定最小性。

| 文献／路线 | 本次审核结论与后续 |
|---|---|
| Mou2110.02416v2；NR1504.06758；CKM2110.08157v3 | 因子正性与companion格缩放有旧先例；已将本桥归为组合应用 |
| BLM2503.03719v1 | 更强原始参数正性仍有效，但不是本特殊桥的首次必要输入 |
| Hua–Zhou1803.06128v5 | root实读Lemma2.14；有限jet平台和Nakayama是旧代数输入 |
| Tang hexagon2611.00238v1 §§9–12 | 独审读到mutation-word末端CM先已Laurent有限，§12.3才给辅助赋值box；不覆盖任意formaltheta有限证书。未把全篇当输入 |
| Fei2609.32425与hexagon2611.00328/2611.00284 | 新检索为LP/branching方向，部分摘要或片段；不越出经典scope借其基定理 |
| Fang–He2609.06676 | 新检索摘要明确乘法部分有spherical parabolic前提；未据摘要给任意经典强基正探针 |
| Library LLRZ14/16旧稿 | 再命中量子bar容量；不以v=1替代经典未知刚性 |
| profile equality | actual θ/CTB样本支持，但双向finite Hamel与CM边界未强制唯一；新代理主攻bulk正算子 |
| tensor/Schur容量 | C⊗N和乘法正，但系数加法coproduct与λ正性不自动给出；另一新代理转攻CM Frobenius配有限整数帽 |
| 一般Laurent逆命题 | canonical代理研究初项像与一阶framing；D⊂K仍未闭合 |

```wolfram
ClearAll[z1,z2,t,pc,pt];
pc=1+20 z1+190 z1^2+1140 z1^3+4845 z1^4+2 z1 z2+94 z1^2 z2+1332 z1^3 z2+10 z1^2 z2^2;
pt=1+20 z1+190 z1^2+1140 z1^3+4845 z1^4+60 z1^2 z2+1060 z1^3 z2;
lr=Expand[Normal[Series[Log[(pc/.{z1->t z1,z2->t z2})/(pt/.{z1->t z1,z2->t z2})],{t,0,4}]]/.t->1];
{lr,Expand[lr-(2 z1 z2-6 z1^2 z2+12 z1^3 z2+8 z1^2 z2^2)]}
(* Actual output: {2*z1*z2-6*z1^2*z2+12*z1^3*z2+8*z1^2*z2^2,0}. *)
```

# 第三十次文献与路线复查：2026-11-14 13:17 UTC

仍以一般 Laurent 有限性和任意实际经典强正基最小性为主线。主问题未闭合。当前换上新的 classical_profile_symplectic 代理，直接检查经典渐近坐标的辛约束；原 Frobenius 与张量极化代理完成本轮并退出，有限性和 profile 两组继续运行。

## 条件最小性桥：相对 log 的次线性增长足以逐阶提取

**法向约定补充。** 本节及下一节的 Q·q、p·q 均表示与根 q 对应的墙法向 ν(q) 的配对。斜对称标准约定 ν(q)=q；斜可对称约定可取 ν(q)=Dq（原始化只再除正整数）。正对角缩放不改变逐坐标单调及连接正／负 CM 锥的论证。最后 bend 的同号选择也统一使用 p·ν(q)、Q·ν(q)。

设 C 是本页实际无环主系数强正基，已具有统一固定平移 log-ratio jet 界。额外假设对每个有限 D、紧集 K⊂R^n，一致有 sup_{h∈NK∩Z^n}|[z^q](log P_h−log F_h^θ)|=o(N)，|q|≤D。此条件由 p_C=p_θ 推出，但目前尚未证明。以下在该条件下证明全部 C→θ 换基系数非负。

固定 D 和 generic Q，使 Q·q≠0 (0<|q|≤D)。取 D 截断散射室中的闭轴平行小盒 Ω，其闭包仍在室内，F_N=NΩ∩Z^n。有限固定 padding 在 N 大时仍留在该室。记初始室至 Q 的路径积 Φ_Q，Φ_Q(x^hP_h)=x^hS_h，A_h=Φ_Q(x^h)/x^h，Ψ_i=Φ_Q(z_i)。于是 S_h=A_hP_h(Ψ)，A_{h+d}/A_h=A_d。h 深在室内时 θ_h^Q≡x^h mod (z)^{D+1}，故 log S_h≡(log P_h−log F_h^θ)(Ψ)。令 u_q(h)=[z^q]log S_h，则 u_q=o(N) 一致，且每个固定 d 有 |u_q(h+d)−u_q(h)|≤K_{q,d}。S_h 是整系数 formal series。

零预算 CM 的选取：从初始正室到 Q 的直线经过的墙 normal n 满足 Q·n<0，所以各 x_i 的 Q-chart 非平凡根支撑只在 Q·q<0。从 opposite 负室到 Q 同理，各 I_i=β_{−e_i} 的非平凡根支撑只在 Q·q>0。因而 Q·q>0 选 d=e_i，Q·q<0 选 d=−e_i，均有 P_d^Q(q)=0。固定截断可轻微扰动路径避 joints；CM 本身在全部散射图正。

严格 density 归纳：对任意有限 W⊂Z^n，证明 F_N 中 S_{h+w}≡S_h mod (z)^{k+1} 对全部 w∈W 成立的 h 占 density 1。k=0 显然。已知 k−1，固定 |q|=k 及上述 d，乘法涉及 E_d={0}∪{d+Bs:|s|≤k}。除 o(N^n) 个 bad h 外，全部相关 S 有共同 <k jet U_h。Q-chart 真实乘法 P_d^Q S_h=Σ_s c_{d,h}(s)z^s S_{h+d+Bs} 除去共同低阶 unit 后，在 q 次给 c_{d,h}(q)=u_q(h)−u_q(h+d)≥0。该差是整数，因为低 logjets 相同时，k 次 log 差等于 k 次 series 差。整盒按坐标 telescoping 的总和为 O(N^{n−1})o(N)=o(N^n)；bad 边每条有统一 O(1) 界，总贡献 o(N^n)。故非零 good 边数也是 o(N^n)。对有限 q、坐标、W 的有限路径取有限并集，推进到 k。此论证不从平台再抽宏观盒，避免尺度丢失。

取 W 包含 0 及 g+Bs (|s|≤D)，选一个真实 good h。所有对应 S 有共同 ≤D unit U。由 P_g^Q S_h=Σ_s c_{g,h}(s)z^s S_{h+g+Bs}，模 >(D) 取消 U，得到 P_g^Q≡Σ_{|s|≤D}c_{g,h}(s)z^s，故 β_g 的每个散射展开系数非负。这里结构常数的 y^s 在路径积下固定；归一化后的 z^s 来自 label shift Bs，不是错误地把 Φ_Q(z^s) 当成 z^s。

直接隔离 θ 换基系数：实际有限换基 β_g=Σ_s a_g(s)y^s θ_{g+Bs}。给定 s_0，设 p=g+Bs_0，D=|s_0|，选 generic Q 很靠近 p，使对所有 0<|n|≤D 且 p·n≠0，Q·n 与 p·n 同号；p·n=0 的 n 也避开 Q·n=0。若有进入目标 x^p y^{s_0} 的 broken line 存在最后一次 bend，弯折点 R 满足 R·n=0，末段速度 −p，故 Q·n=−t p·n，与同号选择冲突；p·n=0 时也冲突。因此只有 straight line 贡献，a_g(s_0)=[z^{s_0}]P_g^Q≥0。p=0 同样处理。结论是条件定理，不能删去相对 log 的 o(N) 假设。

## 首个 profile 差异层的非负性：新增必要约束

若 p_C−p_θ 的 <D 次 jets 已全为零，固定 |q|=D，记 f_q(Q)=[z^q](p_C−p_θ)。那么 f_q 在 Q·q>0 上逐坐标非增，在 Q·q<0 上逐坐标非减，且 f_q≥0。证明：在一个不交 D 截断墙的小轴盒 Ω=[a_i,b_i]×V 内，u_q(h)/N→f_q(h/N) 一致。低阶 density 归纳给 bad 边 o(N^n)，good 边由零预算 CM 给 u_q(h)−u_q(h+e_i)≥0（正半空间）；bad 边有 O(1) 界。telescoping 除以 N^n 后得 ∫_V(f_q(a_i,v)−f_q(b_i,v))dv≥0。缩 V 得逐坐标单调；负半空间用 −e_i。首个非零 degree 在切于恒等的 Ψ 下不变，故跨有限截断墙可用连续性拼接。正半空间加足够坐标正向量到初始 CM 锥；负半空间减到 opposite CM 锥，端点 f_q=0，于是 f_q≥0，q^⊥ 由连续性。

此约束排除了简单的负凸谷，但尚不迫使 f_q=0；非负 tent 仍须由额外代数约束排除。仅用 ordinary CM 值形成最大凸延拓也不能夹逼：wild rank-two 的 CM 方向有 imaginary gap，而 θ 的低阶 logjet 仍在 gap 内沿新散射墙折弯。新代理检查 log-symplectic/Hamiltonian 约束是否来自实际 C，而非外加量子化。

## Frobenius 路线的精确停止点

真实 CM d 满足 M_d^p=M_{pd}，且模 p、总根截断 D<p，有 P_h≡Σ_{|q|≤D}c_{pd,h}(q)z^qP_{pd+h+Bq}。零根项为 P_{pd+h}，并不等于 P_h；pd+h 未必是 CM。统一帽只固定 d,q，不提供 sup_p K_C(pd,q)。p 次路径在总根 q 处的单次非零步贡献是 Σ_{j=0}^{p−1}c_{d,h+jd}(q)；整除可以来自许多值为 1 的项之和。真实秩一纤维 xI=1+y 中，xI^k=I^{k−1}+yI^{k−1} 的单步系数恒为1，而 x^pI^k=(1+y)^pI^{k−p} 的中间二项系数被 p 整除。因此不能由路径总和整除推单个固定系数整除。

固定小 q 的 p 次路径终点 h+pd+Bq 不是起点，循环旋转不保起点且边权依赖标签。有限矩阵 Tr(A^p)≡Tr(A)^p 把 y^q 推到 y^{pq}，在固定根截断中自动消失，若保留则次数随 p 增长。压缩 (P_HM_dP_H)^p 不等于 P_HM_d^pP_H；把标签模 p 周期化还需 c_{d,h+pν}(q)=c_{d,h}(q) 的真实兼容性，当前没有。故此接口已充分测试并停用，未否定最小性主张。

## 张量与外幂容量的实际诊断

C^{⊗m}、S_m 的置换和乘法映射 μ_m 都自动正；y→Σy^{(a)} 的正余乘法及 Schur/外幂投影不自动正。在本页已证的实际 Kronecker 中间强正基 P_n=T_n+HT_{n−2} 中，以 z=u+v,H=uv，则 P_4=u^4+u^3v+uv^3+v^4，自然辅助特征标环中的 λ²(P_4)=H P_6−H²P_4+2H³P_2，有负系数 −H²。Wolfram 直接展开差为0。这里只否定“强乘法和张量置换自动给该 λ 正性”，不声称 λ 天然延拓到整个丛代数，更不是 θ 最小性的反例。

## 本轮查新与采用范围

| 来源 | 本轮核查与作用 |
|---|---|
| de la Salle, arXiv:1604.01578（2016）Theorem 1、Lemma 2 | root 亲读全文3页；整值次线性函数的有限格多面体化是旧 Thurston 机制。非对称版本可直接用同一紧凸体暴露点论证。新应用的 P(g) 不等于已知 θ_g Newton 多面体。 |
| CMMM, arXiv:2505.09585v2（2026）§5.3–5.6 | 再次核 Claim5.7/Theorem5.19 的“双边有限”前提，Lemma5.16 已有有限截断控制；不能将其当单边有限性逆命题。 |
| Hua–Zhou, arXiv:2610.35466v1（2026-10-26） | root 核 Theorem1.1 范围与 Proposition6.7 逐步论证。§6.7 用固定 weighted-homogeneous 参数空间、有限关系矩阵 maximal rank 开条件与 Noetherian 性得统一有限维上界。该证明可用，但不是任意非齐次行有限证书的新输入；trace-finite 不能替代 Jacobi 行有限（文中Question1.3也保留区别）。未认证全篇其它主定理。 |
| arXiv:2609.11200（2026） | 命中 Jacobi-finiteness obstruction 摘要，HTML/PDF 本轮取回失败；未作任何结论输入，也未转向做排除机制。 |
| KS, arXiv:2005.10651v3（2022）§3.8 | root 重读：exponential bound⇒analytic 的接口有前提，Question3.8.4仍区分 analytic 与 uniform exponential。未发现可直接替代本轮显式森林系数界的无条件定理。 |
| DM1910.12915 / Mandel2017 / Qin JEMS2024 | 新检索核普通 atlas 与 scattering atlas 区别、最小性仍需新增机制；不把atomicity或pointed分类作为已解。 |
| Library | 重命中 theta_lef_universal_proof.pdf 的 cyclic/Schur 限制、旧 Tang rank2 源矩阵、用户修改稿 F-poly202608(4).pdf。修改稿仍只作思路参考，不采用任何基定理或最小性结论。 |
| 主要未决 | D⊂K；p_C=p_θ 或其它足够提取机制；任意 C 的含环普通seed去ghost；ordinary支配⇒全部散射Newton比较。 |

## 实际 CTB 与 θ 校准的完整复现代码

以下代码复现此前已记录的 r=3、g=(-20,20)、总根次数4的实际 CTB/θ 比较。它是已知实际基的诊断，不能把量子 bar 归一化自动推广到任意经典 C。

```javascript
function add(A,B,s=0,c=1n){let R=new Map(A);for(let[k,v]of B){let u=k+s,w=(R.get(u)||0n)+c*v;if(w)R.set(u,w);else R.delete(u);}return R;}
function mul(A,B){let R=new Map;for(let[k,v]of A)for(let[l,w]of B){let u=k+l,t=(R.get(u)||0n)+v*w;if(t)R.set(u,t);else R.delete(u);}return R;}
function sh(A,s){return new Map([...A].map(([k,v])=>[k+s,v]));}
function qb(n,k){if(k<0||k>n)return new Map;let A=Array.from({length:k+1},()=>new Map);A[0].set(0,1n);for(let m=1;m<=n;m++){let T=Array.from({length:k+1},()=>new Map);for(let j=0;j<=Math.min(m,k);j++){T[j]=sh(A[j],-j);if(j)T[j]=add(T[j],A[j-1],m-j);}A=T;}return A[k];}
function ipows(r,maxA,D){let H=new Map([['0,0',new Map([[0,1n]])]]);for(let k=0;k<=Math.min(r,D-1);k++)H.set('1,'+k,qb(r,k));let out=[new Map([['0,0',new Map([[0,1n]])]])];for(let a=0;a<maxA;a++){let R=new Map;for(let[qs,A]of out[a]){let[p,q]=qs.split(',').map(Number);for(let[ss,C]of H){let[u,v]=ss.split(',').map(Number);if(p+q+u+v>D)continue;let e=-p+a*u+r*(p*v-q*u),key=(p+u)+','+(q+v);R.set(key,add(R.get(key)||new Map,mul(A,C),e));}}out.push(R);}return out;}
function ctb(r,a,b,D,ip){const E=(aa,bb,p,q)=>sh(ip[aa].get(p+','+q)||new Map,bb*q);let R=new Map([['0,0',new Map([[0,1n]])]]),C=new Map;for(let d=0;d<=D;d++)for(let p=0;p<=d;p++){let q=d-p,S=new Map;for(let[ss,V]of R){let[u,v]=ss.split(',').map(Number);if(u<=p&&v<=q)S=add(S,mul(V,E(a-r*v,b-r*u,p-u,q-v)));}if(!d){C.set('0,0',1n);continue;}let T=new Map;for(let[k,v]of S)if(k<0)T.set(-k,(T.get(-k)||0n)+v);for(let[k,v]of S)if(k>0){let w=(T.get(k)||0n)-v;if(w)T.set(k,w);else T.delete(k);}R.set(p+','+q,T);let s=0n;for(let[k,v]of S)if(k===0)s+=v;else if(k<0)s+=2n*v;C.set(p+','+q,s);}return C;}
function bin(n,k){if(k<0||n<k||n<0)return 0n;k=Math.min(k,n-k);let r=1n;for(let i=1;i<=k;i++)r=r*BigInt(n-k+i)/BigInt(i);return r;}
function greedy(r,a,b,P,Q){let e=Array.from({length:P+1},()=>Array(Q+1).fill(0n));for(let p=0;p<=P;p++)for(let q=0;q<=Q;q++){if(!p){e[p][q]=bin(Math.max(a,0),q);continue;}if(!q){e[p][q]=bin(Math.max(b,0),p);continue;}let A=0n,B=0n,np=Math.max(0,b-r*q),nq=Math.max(0,a-r*p);for(let k=1;k<=p;k++)A+=(k%2?1n:-1n)*e[p-k][q]*bin(np+k-1,k);for(let k=1;k<=q;k++)B+=(k%2?1n:-1n)*e[p][q-k]*bin(nq+k-1,k);e[p][q]=A>B?A:B;}return e;}
const r=3,a=20,b=20,D=4;
const ip=ipows(r,a,D),C=ctb(r,a,b,D,ip),eg=greedy(r,a,r*a-b,D,a);
const output=[];
for(let deg=0;deg<=D;deg++)for(let p=0;p<=deg;p++){const q=deg-p;output.push({root:[p,q],ctb:String(C.get(p+','+q)||0n),theta:String(eg[q][a-p])});}
console.log(JSON.stringify(output,null,2));
// Require a,b>=r*D so every shifted E stays in the same sign chamber.
// CTB correction T_k=S_{-k}-S_k (k>0); v=1 coefficient S_0+2*sum_{k<0}S_k.
// Diagnostic of an actual known basis, not a proof for arbitrary classical strong bases.

```

# 第三十一次文献与路线复查：有限梯度多面体与首差异层（2026-11-14 13:37 UTC）

本次继续两条一般机制：Laurent 方向考察单侧有限赋值能否控制对偶 theta 的全部分支；最小性方向考察实际强正基的首个 profile 差异是否被所有普通簇单项式算子消灭。以下有限多面体尚不能称作目标 theta 的 Newton 多面体。未使用 Li–Pan 或 Li Fang 的结论。

## 单侧赋值的有限格多面体：完整陈述

为避免 B 与 −B 混淆，暂以 C 记正在计算 F 的斜可对称交换矩阵，D=diag(d_i)>0 且 DC 斜对称。令整数 g∈int 𝒟_{−C}，其中本节的 𝒟_{−C} 精确定义为所有 L_i(g):=sup_{a∈Supp F^C_{−e_i}}(−Dg)·a 同时有限的域。定义 ℓ_g(m):=sup_{a∈Supp F_m^C}(−Dg)·a。要用于原目标 θ_g^B 时，取 C=−B。此前基本 majorant 与内部点严格 coercivity 保证每个 ℓ_g(m) 有限、最大值取得，且取到最大值的支撑有限。

正乘法中根次数零项给 F^C_{m+n}≤F^C_m F^C_n；CMMM v2 Corollary 2.9 的齐次性给 ℓ_g(km)=kℓ_g(m)。故 ℓ_g 唯一延拓到 Q^n，次线性，并满足 |ℓ_g(m)−ℓ_g(m′)|≤Σ_i L_i(g)|m_i−m′_i|。这里 ℓ_g(e_i)=0、ℓ_g(−e_i)=L_i(g)。再连续延拓至 R^n。由于 g,D 整，ℓ_g(Z^n)⊂Z。

由 Thurston 的整值支撑函数机制（de la Salle, arXiv:1604.01578），ℓ_g=h_{P_g}，其中 P_g 是有限格多面体。非对称情形的直接证明如下：取紧凸体的暴露点 p，暴露方向 u，取整数 x_k=ku+O(1)，并令 p_k 在 x_k 处取支撑最大值，则 p_k→p，且 0≤h(x_k)−x_k·p≤O(1)·(p_k−p)→0。对 x_k+e_i 同理，整数 h(x_k+e_i)−h(x_k)→p_i，故 p_i∈Z。紧体内格点有限；暴露点凸包稠密生成该紧凸体，故它是格多面体。这是旧凸几何工具，不能主张工具本身新。

由正、负正交锥上的显式值，P_g⊂∏_i[−L_i(g),0]，并含顶点 0 与 −L(g)；退化坐标或整个退化多面体不影响结论。这是标签变量 m 的多面体，尚未与 θ_g 的指数多面体识别。

## 完整 principal 字典与有限 cotangent carrier

令 P=(C;I)、Q=(I;0)、Λ=[[0,D],[−D,DC]]，则 ΛP=QD。取 q₀=(−g,0)、v=Λq₀=(0,+Dg)。完整标签 u=(m,c) 的赋值为 ρ_g(u)=val_v θ_u=−ℓ_g(m)+c·Dg。注意 q₀ 的负号及冻结梯度 +Dg；相反号版本已撤回，不得复用。

固定 P_g 的一个顶点 p，在其开 normal cone 中取整数 m。此处 ρ_g 的局部梯度为 (−p,+Dg)。沿 CMMM v2 Theorem 5.19 式(31)的第一段 straight transport，选充分靠近 q₀ 的 generic endpoint p_end∈q₀+C⁺，可取得一条既 val_v-minimizing、又 Λᵀ-taut 的有理 broken line Γ。这里只使用本侧在 v 邻域有限及有限最小面，不使用待证的对侧 theta 有限性。

记 T_Γ 为 Γ 各非零 bend 的线性 shear 之积。CMMM Lemma 3.20 证明给同一有限 bend 列表的局部有理分支：改变初标签 u′ 时，终指数为 T_Γu′。所以 v·T_Γu′≥ρ_g(u′)，且在 u 取等号；ρ_g 在这个全维邻域内本来是线性的，故 T_Γᵀv=(−p,+Dg)。root 已亲读 Lemma 3.20 lines789–791核对这一局部延拓，并非假设所有标签共用同一无限截断。

解 Λq=(−p,+Dg)，得到 a=−D⁻¹p，q=(−g+Ca,a)=q₀+Pa。因此所有顶点产生有限集合 𝒬_g={q₀+Pa:p∈Vert(P_g)}⊂q₀+P[0,D⁻¹L(g)]。此处 carrier 只记录伴随极值分支的逆传输指数。

更精确地，primitive root n 的墙写为 f(z^n)，primitive normal ν=QD n/d(n)，d(n)=gcd_i(d_i n_i)。非零 Λᵀ-taut bend 是负→正且取最高有限次数 K，T=I−K Pnνᵀ。若当前逆赋值为 Λq，val_v-taut 的最大 bend 条件给 ν(q)≥0，并有 TᵀΛq=Λ(q+Kν(q)Pn)。由于 q₀、ν 整，逐步根增量 Kν(q)n 属 N^n。最终 a=−D⁻¹p，故沿该支路全部中间根指数位于 [0,a]，真正改变 q 的步骤数及其 primitive root 总次数均由 |a| 控制。特别 p∈D Z^n；取 p=−L，得到 D⁻¹L(g)∈N^n，而未预先假设目标 θ_g 有限。agent 用一般 DB 斜对称 rank3 符号矩阵在 Wolfram 独立核 ΛP=QD、更新式与 det(T)=1，残差均零。

不可越过的边界：这不是完整 wall-action 的预算。Γ 正→负时可能取零 bend，此时 T=I 但 ν(q)<0，整墙仍会非平凡作用于 x^q。只有 ν(q)=0 才会固定该单项式；即便固定一个极端项，也可能作用于其它低层分支。因此尚未证明 𝒬_g 或其凸包包含目标 θ_{q₀,−} 的全部指数支撑，D⊂K 仍未闭合。

## 从正结构常数得到 min-convex：不偷用 full FG

若完整冻结标签的结构常数 α(u,w;r)>0，则 ρ_g(r)≥ρ_g(u)+ρ_g(w)：正 summand coefficientwise 包含于乘积，且相关最小值有限并取得。增加一个中心冻结坐标 t，令 S={(u,t):t≤ρ_g(u)}。ρ_g 有限、有理分片线性且齐次，故 S 闭；上述不等式使 S 成为正集。将 CMN arXiv:1912.13052v2 Theorem6.1 的有限 balanced-broken-line 论证应用于此中心扩张，得到 S 的 broken-line 凸性。任取 broken-line segment，将 t 沿端点 ρ 值作仿射插值，便得 ρ_g 的 Jensen 不等式，等价于 GHKK min-convex 导数条件。

这一 decreasing→Jensen→min-convex 思路与 Frías-Medina–Magee arXiv:2407.02427v2 Propositions37–38/Corollary39 重合，不能单独主张新颖。该文全局采用 full Fock–Goncharov 前提（§2.1、§5开头）；本处只重建有限组合步骤。其§5双极/对偶理论不得用来反向证明 full FG 或本题有限性。另需严格区分 ρ_g 的标签变量与固定 θ 的赋值点变量，不能不经互易便交换。

## 有限 Jacobian 行：独立复核与查新纠正

设 J=k<<Q>>/I(W)，Q 有限，I(W) 为闭 Jacobian 理想，m 为箭头理想。若 dim_k e_iJ=d，则 e_iJm^d=0。理由是 e_iJm^k 由有限条长度 k 路径生成；m⊂Jac(J)，任意相邻 filtration plateau 经 Nakayama 迫使该尾部为零，故非零层严格下降。

在 V_i=e_i kQ/m^{d+1} 中，将所有截断的 u(∂_aW)v 作关系矩阵列；它只依赖循环长度≤d+1 的 potential jet。原点矩阵有非零 minor，保证附近 dim(e_iJ/e_iJm^{d+1})≤d。若 e_iJm^d≠0，则从第0层到第d层全非零，截断维数≥d+1，矛盾。因此同一 principal open cylinder 上实际行维数≤d，且 m^d 杀掉该行。必须用完整非齐次关系列，不能拆成齐次分量。

完成与闭理想不可省：未完成的 k[x]/(x−x²) 中 m=m²≠0，而小 m-adic 截断只见一维，故仅靠这种截断不能推未完成代数有限。对有限顶点，各行非空开条件拉到共同有限 jet 空间后相交；在特征零、关系系数定义于整数的普通箭图情形，非零子式乘积有整数取值不为零的点。因此分别选势函数不扩大‘每行都有有限势证书’的存在类，但可减小实际行界。

查新纠正：root 新亲读 Fei arXiv:2610.09868v2（2026-10-10）Lemma1.5、Proposition1.8、Proposition4.2 的完整相关证明。Prop4.2 已有整个 completed Jacobian algebra 的有限 jet 开性；1.8已有截断停机与闭理想提升。本轮行版本是同一机制的直接扩展及 Laurent 证书应用，不能把有限 jet 开性本身列为原创。所核三步正确；该文87页其它定理未经本轮全篇认证，其基定理仍有 good realization、Jacobi-finite、reachability 等前提，不可替代任意实际强正基的最小性。

## 实际强正基的 Poisson 首差异接口

在完整 principal 对数坐标 u=log x、v=log y、w=v+Bᵀu 中取 Λ=[[0,−D],[D,−DB]]。若相邻比率极限诱导固定 y 的映射 u′=u+a_Q(w)、v′=v，记 E_ij=∂a_i/∂w_j，则 Poisson 缺陷的 mutable block 为 ED−DEᵀ+EDBEᵀ。独立 Wolfram 符号核验通过。若低于根次数 |q| 的 profile 差异已消失，首差异 f_q(Q) 满足 a_i(q)=∂_{Q_i}f_q，则该次数 Poisson 条件强迫 ∇f_q(Dq)ᵀ−(Dq)(∇f_q)ᵀ=0，即 ∇f_q∥Dq。配合已有普通 CM 锚及齐次性有望迫使 f_q=0。

目前尚未证明任意实际 C 的这个极限映射保 Poisson；a 是 Q 梯度只给另一组变量的生成函数关系，不能替代上述固定 y 条件。必须用实际 C 的所有普通簇单项式算子，而非未经证明的量子提升、bar 归一化或 bracket 支撑正性。

诊断已用实际代数验证：rank2 injective standard monomials E_g=∏x_i^[g_i]+ I_i^[-g_i]+ 可以构成强正 Hamel 基并含初始/opposite 两簇 CM，其关系 x₁I₁=1+y₁I₂^r、x₂I₂=1+y₂x₁^r 给终止正重写；但它不含全部普通 CM。例如 x₁′=I₁x₂^r−Σ_{k=1}^r binom(r,k)y₁y₂^k x₁^{rk−1}。在 Q=(−a,b) 首差异 f_(1,1)=r min(a,b)>0，固定 y 的 Poisson 缺陷非零。此模型只说明初始/opposite 锚、Hamel 性、正乘法与统一无零点域不足；它不满足总目标的全部 CM 假设，不是最小性反例。接下来继续使用全体 ordinary CM 的零预算方向与正结构常数。

## 本次来源与路线结论

| 来源/路线 | 本次核查结论 |
|---|---|
| CMMM 2505.09585v2, Lemma3.20 与 Theorem5.19 式(31) | 局部有限 bend 分支和单侧 straight transport 可用；完整 reciprocity 仍有双边有限前提。 |
| de la Salle 1604.01578 | 整值次线性→有限格多面体是旧机制；保存独立非对称证明。 |
| CMN 1912.13052v2; FM–Magee 2407.02427v2 | decreasing/min-convex 可借有限组合论证；fullFG 下的双极定理不作当前桥。FM Prop70 的分离半空间与 Lemma71 的非共线分离步骤在本轮局部削弱设定下未获依据，不据此判全篇错误。 |
| Fei 2610.09868v2, §§1.3,1.5,4.1 | 已强核相关有限截断、闭理想提升和开性证明；确认此机制重合。其§12仍将一般乘法公式列为问题，不能推出任意强正基最小性。 |
| Tang Hexagon2610.00025v3 | root 重读主定理范围与开头；量子 bar/degree 裁剪承重，经典任意 C 不自动拥有它。 |
| 广搜 Qin/Mandel/Fei/2026 theta finite pairing | 仍未找到替代 D⊂K 或 p_C=p_θ 的可直接使用定理；普通 atlas 与 scattering atlas 继续区分。 |
| 继续攻击 | 整个有限梯度 carrier 的全分支屏障；所有普通 CM 的首差异约束；实际 C 的 Poisson 低阶桥。 |

# 第三十二次文献与路线复查：2026-11-14 13:57–14:01 UTC

本次仍聚焦一般有限 Laurent 支持与任意实际强正基的最小性。新增三条攻击接口：有限梯度多面体的逐墙局部不等式、正乘法的 Markov/半超群矩阵、有限两项 presentation 的双向 framing。以下所有未闭合步骤明确保留，不以计算或特殊诊断替代证明。

## Poisson 路线的精确终点与额外漏洞修正

在主系数坐标 u=log x、v=log y、w=v+B^T u 下，取 Λ=[[0,−D],[D,−DB]]。若候选变换为 u′=u+a_Q(w)、v′=v，E_ij=∂a_i/∂w_j，则直接矩阵乘法给出
JΛJ^T−Λ=[[ED−DE^T+EDBE^T,0],[0,0]]。
在第一个根次数 q 上，若 a_i(q)=∂_{Q_i} f_q，则线性缺陷是
∇f_q(Dq)^T−(Dq)(∇f_q)^T。
因此若能由实际强正 C 推出这一弱一阶 Poisson 条件，就有 ∇f_q∥Dq。结合连续性与普通 CM 的正负端锚点，可迫使 f_q=0。更弱的体积条件只给 ∇f_q·Bq=0。**C 的强正乘法尚未推出这两个条件中的任何一个。**

另一个必须保留的分析区别：N^{-1}log P_floor(NQ) 的局部一致收敛与固定步长差分的一致有界，不推出 P_(h+e_i)/P_h 的逐点极限；微观差分仍可能振荡。只能从盒平均获得弱梯度。在首差异层 Poisson 条件为线性，弱版本已够用，但仍须新的代数依据。Q 方向的生成函数梯度关系、Euler 平坦性、交换差分与 Jacobi 恒等式都不能自动补出固定 y 的 Poisson 性。

实际 E 诊断（不是目标反例）：B=[[0,r],[-r,0]]，
I_2=(1+z_2)/x_2，I_1=(1+z_1(1+z_2)^r)/x_1，
E_g=x^{g_+}I^{g_-}。
由 x_1 I_1=1+y_1 I_2^r、x_2 I_2=1+y_2 x_1^r 及互素首项 Gröbner 归约，E 是正 Hamel 基并含初始与对侧 CM；但不含全部普通 atlas CM，因为
x′_1=I_1x_2^r−Σ_{k=1}^r binom(r,k)y_1y_2^k x_1^{rk−1}。
它已有 f_(1,1)(−a,b)=r min(a,b)>0，r=2 时 Poisson 缺陷为 −2z_1z_2(1+z_2)/H_1。故“所有普通 CM”条件仍是承重条件，不能被初始/对侧 CM 代替。

## 有限梯度 carrier 的局部墙不等式

设 ρ 是连续凹分片线性函数，在墙 ν^⊥ 两侧的梯度为 v_−、v_+，连续性给 v_+−v_−=aν。记 b=v_±·Pn；两值相等。墙函数 f(z^n) 的最大根次数为 K，broken-line min-convex 导数条件给
a≤min(0,Kb)。
若 K=∞ 且 b<0，则无有限 a 能满足全部 bend。写 v_±=Λq_±、ΛPn=d(n)ν，可得 b=−d(n)ν(q_±)，q_+−q_−=(a/d(n))Pn；特别当 ν(q)>0 时，
q_−−q_+≥Kν(q)Pn。
这给出局部整个 Newton 线段的梯度跳跃预算。尚缺：某一目标 broken line 首次离开有限 carrier 时的分离法向，不一定落在它正在穿过的墙上，所以不能直接调用上述 active-face 不等式。

另一直接估计的符号已校准：沿目标 broken line 使用 ρ_h，只得到
Dκ(h)·a ≥ −ℓ_h(−g)+g·L(h)，
它是下界，不能误写成支持上界。主 ℓ_g 法扇上进一步按词典序取次权重面仍在研究；边界可新增主权重并列格点，次权重函数可能向上跳，不能未经证明当成全局连续 PL。

## 正乘法、表示 framing 与新文献接口

固定正 y 的实际 C 乘法可归一化为随机的交换半超群。C 正角色由初始 x_i>0 的取值确定；上面的 E 诊断与目标拥有相同正角色空间，因此纯角色/Choquet 分解无法读出所需轮廓。标准多项式 hypergroup 的三项 Favard 递推、对合与正交性都不是任意 C 的已知结构。继续检查乘全部普通 CM 的正矩阵与 Green/Martin 核，目标为有限 theta 支持的系数分离。

新 presentation 候选：有限路径代数模 M=coker(d:P_1→P_0)，向 Q 加顶点 ∞、生成箭 a 与关系箭 b，取 W†=W+Σ bda。dim∞=1 且由 ∞ 生成的临界表示由 a 在 Q 内生成，∂_b W†=da 强制其内部部分为 M 的商，故若 M 在 CQ 上有限，则有维数支持界。最小 presentation 可去除常数 contractible 对以维持势长≥3。尚未证明 signed framing 下的原 θ_g 是这个 cyclic DT 系列的正一次 framing summand；普通 cluster character=theta 不能作为替代假设。

| 文献/版本 | 强核范围与结论 | 用途状态 |
|---|---|---|
| Fei, Crystal Structure of Upper Cluster Algebras, arXiv:2309.08326v4, 2026-11-11 | root 阅读§1.1、§2.1、Remark7.8：mutable-Jacobi-finite 为站立条件；需 projective/injective 时另有 full finite 条件。generic span=mid 仍为期望，单个 generic 与 theta 不必一致。 | 不能补一般 theta=generic 或有限 presentation 桥。 |
| Reading–Stella, SIGMA22(2026),109, online2026-11-08 | root 阅读最终 PDF 的 Th5.14、Remark5.15及 Th5.1范围。small canonical formal algebra、pointed reduced 分类与实际有限 theta 的假设分别保留。 | 不推出任意实际强正基最小性。 |
| Tang, Hexagon2611.00190v1, Lusztig positivity；本地审稿稿 | root 阅读主文开头及本地审稿§8接口。有限支持分离加 full evaluation 保 indecomposable 的机制值得借鉴；量子群范畴结构不自动存在于 C。旧审稿 G1 有修补讨论，未把整篇重新认证。 | 仅作为乘法系数分离思路。 |
| Tang, Hexagon2611.00015v1§3 | 子代理读全文，提出局部 bounded positive Σ 且 g 在 coneΣ 内部可控制相应 θ 的候选。root 本次重取 PDF 失败；尚不能把它当已独立核毕输入。特别注意不是同号 arXiv 条目。 | 继续核局部假设与 ρ 构造 Σ 的缺口。 |
| Kahler–Szwarc2212.11229；Kahler–Obermaier2603.17983 | 检索到正交多项式 hypergroup；通用条件尚不覆盖 C。 | 无定理输入。 |
| Geiss–Hartung–Labardini–Schröer2610.18805 | 这一轮 abstract/html/pdf 重取均失败，未获得可核全文。 | 不据摘要推结论。 |
| Zenodo19580721 tail-orbit/scattering稿 | record/PDF 本轮不可取或超时。 | 不使用。 |
| Bridgeland, Algebraic Geometry4(2017),523–561, §10 | 公开 PDF 明确只处理正 framing 的相应 theta；一般标签另留未来研究。 | 双向 presentation framing 需要独立证明。 |

本轮纠错：Davison–Mandel《Strong positivity for quantum theta bases of quantum cluster algebras》的 arXiv 编号是 1910.12915；误试的 1910.12984 不是这篇文献。检索失败不算文献内容的审核。下一轮继续全分支 carrier、CM 乘法分离和一标记 framing 桥。

# 主缺口突破：倒数时间变换给一般 Laurent 有限性判据（2026-11-14 14:12 UTC）

本节是对前文『D⊂K 未闭合』状态的实质更新。以下证明由 canonical 代理提出 projective reversal、root 补 elementary positive-weight transport、hypergroup 代理独立逐步复算。只处理经典丛代数。原先的有限梯度 carrier、解析内部互逆与 min-convex 方法仍保留为独立性质，但不再承担这一步有限性证明。一般强正基的 theta 最小性尚未闭合。

## 定理 P：基本对侧支撑函数的有限值足以控制全部 Laurent 支撑

设 B∈M_n(Z)，D=diag(d_i)>0 为整数正对角矩阵，DB 斜对称。以主系数根变量 z 写 θ_g^B=x^g F_g^B(z)，并令
H_i(z)=F_{−e_i}^{−B}(z)，
L_i(g)=sup{(−Dg)·a : a∈Supp H_i}∈[0,+∞]。
若 g∈Z^n 且每个 L_i(g)<∞，则 θ_g^B 是有限 Laurent 多项式，并且
Supp F_g^B ⊂ {a∈N^n : d_i a_i≤L_i(g), 1≤i≤n}。
本判据包含支撑有限域的边界；不要求 g 在其内部，不要求 analytic convergence、Jacobi-finite、reddening、DT permutation 或 all-theta-finite。

本轮此前已证明的 single-finite top theorem 给出反方向：若 θ_g^B 有限，则各 L_i(g) 有限、f_i(g)=L_i(g)/d_i 是整数，f(g) 是最高根项且其系数为1。因此结合本节得到精确充要判据及精确盒上界。这里的 L_i 来自可能无限的 H_i；没有把“值有限”冒充可由任意有限截断自动识别的证书。后续有限 presentation 判据提供另一种可验证的充分证书。

## 证明：全分支反转、清分母与有限阶运输

1. 反射字典。置 C=−B，完整主系数指数格 M=Z^n⊕Z^n，
Pn=(Cn,n)，Qn=(n,0)，
Λ=[[0,D],[−D,DC]]。
则 Λ^T=−Λ，ΛP=QD，P^TΛ=−DQ^T。正根 n 的 primitive normal 为 ν_n=QD n/d(n)，d(n)=gcd_i(d_i n_i)。反射 R(m,c)=(−m,c) 把 B 图的正室送到 C 图的负室，并把 (g+Ba,a) 送到 q_0+Pa，其中 q_0=(−g,0)。令 v=Λq_0=(0,Dg)。只须控制 C 图中 θ_(q_0,−) 的全部根 a。

2. 取任意项。给定 a∈Supp F_g^B，在 C 图的负室选一般终点 p=(p_mut,0)，其中每个 p_i<0，取一条贡献该项的整数 broken line γ。记真正折弯时刻 t_j=−u_j<0，根增量 Pa_j，Σ_j a_j=a。每一段写 γ(t)=b_j−tq_j。初始指数 q_0、最终指数 q_0+Pa，初始段截距为
b=p+PΣ_j u_j a_j。

3. 有理有限记录。固定所有整数装饰指数、选中墙、选中非零单项式。反向重建折点时只除以固定非零 normal pairing，所以各时刻和折点对终点是有理线性函数。墙的相对内部、横截性、严格时间顺序和最后折点在 t<0 都是有限开条件。因此可将 p 在负室任意小扰成有理点而保留这一记录及最终根 a，此时所有 u_j 有理。此处只构造有理有限记录，不声称这个有理点避开全无限图的所有高阶 joint。完整主系数图在冻结方向为柱面，故可保持 p_frozen=0。

4. 倒数时间变换。令 τ=1/t<0，
δ(τ)=−τ γ(1/τ)。
在 γ=b_j−tq_j 的一段上，δ=q_j−τb_j，所以 δ 的初始指数为 p、终点为 q_0、最终指数为 b。其折点 δ(1/t_j)=−γ(t_j)/t_j 是原折点的正数倍，仍在同一中央锥墙上。
原折弯 q_+−q_−=Pa_j，且 b_+=b_−−u_j Pa_j；反向折弯为 b_−−b_+=u_j Pa_j。墙方程给
ν(b_+)=−u_j ν(q_+)=−u_j ν(q_−)，
故 normal pairing 的绝对值也恰乘 u_j。这个公式对任意被选中的非极端 monomial 都成立，不只对 taut 或最高次折弯成立。

5. 真实整数单项式见证。选正整数 N，使 Np 为整数且每个 Nu_j 为正整数。令 δ_N=Nδ，则各段指数、根增量均为整数。若原 monomial 在 f_j^{|ν(q_−)|} 中有正系数，把这一选择重复 Nu_j 次，便在 f_j^{Nu_j|ν(q_−)|}=f_j^{|ν(Nb_+)|} 中得到根 Nu_j a_j 的正项。这正是 δ_N 所需的折弯。因此不是只得一条无装饰的热带折线，而是每一弯都具有实际正单项式见证。

6. 终点从墙上移开。固定 δ_N 的全部整数指数与非零选择，把终点从 Nq_0 微扰到 E=Nq_0+εh，其中 h 位于正室，ε>0 充分小。有限记录的开放性保证所有选中弯折仍合法、最终指数仍为 Nb。可在该非空开集内选择一般 h：固定段遇到任意 codimension≥2 joint 或落在墙超平面上，只给终点的适当仿射子空间；可数并由 Baire 避开。额外穿过的墙选择常数1。先清分母，再扰终点，因此不会重新破坏装饰指数的整数性。

7. 从正室运输的权重下界。取一般直线
η(s)=εh+sNq_0，0≤s≤1。
其起点 εh 在正室。若它真正穿过正根 n 的墙，则 ν_n(q_0)<0；若 ν_n(q_0)≥0，则从正侧出发不可能跨过该超平面。因此每个被穿墙的非恒定修正 kPn 都严格增加 v 权重：
v·(kPn)=−k d(n)ν_n(q_0)>0。
墙自同构及其逆的形式展开可能带符号，但所有非恒定修正均有正根次数且严格升此权重。故在每个有限根次数商中，运输不能创造低于输入下界的项。取消项不损害下界。目标单项式 Nb 只依赖有限根次数，因而这一系数级论证足以处理无限初始 theta 和无限 scattering 图，不交换未控制的极限。

8. 初始下界只用强正性。标准 theta 乘法的首项系数1与正结构常数给
F_{m+n}^C≤F_m^C F_n^C
的逐系数不等式。因为 Np_i<0，
F_{Np}^C≤∏_i H_i^{−Np_i}。
各 H_i 的每个根项对 v 的权重至少为 −L_i(g)，且 x^{Np} 的 v 权重为0。于是 θ_(Np,+) 每项权重至少
−NΣ_i(−p_i)L_i(g)。
第7步运输把此下界保留到 E；第6步的实际 broken line 给出最终项 Nb，故
N b·Λq_0 ≥ −NΣ_i(−p_i)L_i(g)。
这里只需要上述不等式，不需要把负室当作普通 cluster chamber，也不需要假设 C 无环。

9. 斜对称守恒。沿 γ，γ(t)^TΛq_j 在每段恒定；在折点 x 上也不变，因为
x^TΛPa_j=x^TQD a_j=0。
比较初始与最终段得
b^TΛq_0=p^TΛ(q_0+Pa)=p_mut^TD a，
其中用了 p_frozen=q_(0,frozen)=0。取消 N 后，
Σ_i(−p_i)d_i a_i ≤ Σ_i(−p_i)L_i(g)。

10. 先取 p_i∈[−2,−1]，即得 Σ_i d_i a_i≤2Σ_i L_i(g)，统一控制任意贡献的根 a，故支持有限。欲得精确坐标盒，对固定 a 利用 theta 在负室内终点独立，再在任意负室小开集重复第3–9步；连续性把不等式延伸到所有 p_i<0。令 p→−e_i，得到 d_i a_i≤L_i(g)。固定根次数只有有限条贡献记录，所以有限支持同时给有限 Laurent 和有限 broken-line 计数。再用 GHKK 的 seed-chamber 传播，得到每个普通种子内的 Laurent 有限性。证毕。

## 独立复核、计算与文献界限

hypergroup 代理独立复核了：清分母后的真实 monomial 选择；终点微扰的 rank 与开放条件；ΛP、v·Pn 与直线穿墙符号；按有限输出根次数运输下界。root 独立核 GHKK Definition3.1/Remark3.2：真正 broken-line 弯折始终用墙函数的正整数幂，这正允许复制所选 monomial。CMMM v2 的 full reciprocity 仍以双方有限值为前提，本节没有引用其未证的单侧扩张。

原 canonical 代理一度判断倒数时间变换可能直接给所有标签的 extended reciprocity，此判断已收回：变换把目标的实际 endpoint 变成另一条线的初始标签，本证明特用负室 endpoint 与全体基本 H_i 的同时下界。一般任意标签 reciprocal pairing 还需额外运输，不在本定理之内。2026来源的核查范围没有因此扩大。

实际 Wolfram 运算：随机中央墙有理几何记录 4,658 组，秩2–16、每组最多7个非零折弯，共53,693个局部/全局等式检查，失败0。它核的是反转、截距与 skew 守恒等式，不核实际 cluster 墙存在性，也不代替上述证明。初版脚本把空向量和写成标量0，产生 unevaluated Dot，4,658组结论只来自修正后的代码；该编程错误与数学反例严格区分。

```wolfram
SeedRandom[261114]; sumv[x_,n_]:=If[Length[x]==0,ConstantArray[0,n],Total[x]]; count=0; bad={}; checks=0; Do[n=RandomInteger[{2,16}]; k=RandomInteger[{1,Min[n,7]}]; c=RandomInteger[{-3,3},{n,n}]; c=c-Transpose[c]; aa=RandomInteger[{0,3},{k,n}]; If[MatrixRank[aa]<k,Continue[]]; q=RandomInteger[{-4,4},n]; uu=Reverse[Sort[RandomSample[Range[1,6 k],k]]]/7; qq=Table[q+c.sumv[Take[aa,j-1],n],{j,k}]; If[MemberQ[MapThread[Dot,{aa,qq}],0],Continue[]]; rhs=Table[-uu[[j]] aa[[j]].q-Sum[Min[uu[[j]],uu[[h]]] aa[[j]].c.aa[[h]],{h,k}],{j,k}]; pp=LinearSolve[aa,rhs]; bb=Table[pp+c.sumv[Table[uu[[h]] aa[[h]],{h,j,k}],n],{j,k+1}]; local=And@@Table[bb[[j]]-bb[[j+1]]==uu[[j]] c.aa[[j]] && aa[[j]].bb[[j]]==-uu[[j]] aa[[j]].qq[[j]],{j,k}]; global=pp.Total[aa]+q.Total[MapThread[Times,{uu,aa}]]==0; If[!TrueQ[local&&global],AppendTo[bad,{n,k,local,global}]]; count++;checks+=3k+1,{it,1,5000}]; <|"RandomRecords"->count,"ScalarIdentitiesChecked"->checks,"Failures"->Length[bad],"FirstFailures"->Take[bad,UpTo[3]],"Scope"->"Rational central-wall kinematics; not a test of wall existence or theta finiteness","Correction"->"Empty vector sum explicitly returns dimension-n zero; prior script used scalar zero and produced unevaluated Dot"|>
```

| 本次直接查新 | 处理 |
|---|---|
| GHKK arXiv1411.1394v2，Def3.1/Rem3.2、Th3.5、Prop7.1 | 使用真实正幂 bend、形式运输与普通种子传播；这些是旧输入。 |
| CMMM arXiv2505.09585v2，Th5.19、§5.6.2 | root 重读最新全文：仍明确双方有限值及 infinite-locus 障碍。本节证明只处理指定基本 theta 的同时有限值，不称为一般 reciprocity。 |
| Tang Hexagon2611.00015v1§3 | root 已通过成功 ref 亲读 Lem3.1/Prop3.2 的 gauge、early-charge、skew cancellation 全段；局部 positive-polytope 版本是该旧机制的局部化。新证明不依赖先构造 positive polytope。 |
| projective/time-reversal/bounded-support 搜索 | 当前 primary 检索未发现完全相同的倒数时间+正权运输判据；这只是“尚未发现同结论”的查新状态，不是排他性新颖证明。 |
| Li Fang / Li–Pan | 不使用其任何结论；本节从中央正 scattering 的定义独立出发。 |

后续：完成有限 presentation 的实际有限证书与一星系数恒等式；继续 arbitrary actual strong C 的 CM 乘法分离。最小性目标并未由本节自动解决。

# 第三十三次文献与路线复查：有限余核的有效 Laurent 证书（2026-11-14 14:20 UTC）

本节记录第二条已闭合的一般 Laurent 路线：一项明确的有限维余核证书，可替代整个 Jacobian 代数有限或相关 projective 行有限。完整证明由 presentation 代理与 root 分别检查，并与上一节的精确支撑函数判据区分：这里给的是可由有限关系矩阵验证的充分条件，并不保证每个有限 theta 都有此证书。

## 统一箭图与路径约定

本节为便于写右模 presentation，使用 R_C：当 C_ij>0 时画箭 i→j，并从左向右乘路径。故 e_i R_C e_j 由从 i 到 j 的路径张成。这与此前 Q_C 的“C_ji>0 时 i→j、路径从右向左乘”约定互为箭头反向的记法；本节 R_C=Q_C^op 作为有向图，恰是此前 source framing 所用的反向图。两种写法必须同时反转箭头和路径乘法，不能只改其中之一。取 J 的右模 P_i=e_iJ。

## 引理 S：一次新增顶点系数恒等式

给定斜对称整数 C 与 g∈Z^n，令
C†=[[C,g],[−g^T,0]]，s=z_∞。
则在经典主系数形式幂级数中，
[s]F_{−e∞}^{C†}(z,s)=F_g^C(z)。
g=0 时新增顶点孤立，F_{−e∞}=1+s，显然成立。以下给一般证明，不假设任何 theta 已 Laurent 有限。

固定旧变量总次数≤K、s²=0。完整 principal 空间记 P†n=(C†n,n)，ε∞为新增 mutable 单位向量。取旧正室一般终点的固定提升 Q_fix（新增 mutable 坐标0），并令 Q_L=Q_fix+Lε∞，L>0。它们在同一初始正室内，故 theta 展开相同。截断内墙、非零弯折记录与选择均有限。

对[s]的贡献折线，初始指数为−ε∞。旧墙法向(a,0)与此指数配对0，所以第一次非零弯折必有新增 charge，且其根恰为 n0=(a0,1)。之后所有非零弯折都是旧墙。第一次弯折后指数为
m1=−ε∞+P†n0。

固定后续旧墙记录。因为旧法向的∞分量为0，从端点反向重建的所有旧弯折时刻由旧坐标与指数决定，不依赖L。第一次弯折点故可写为
R_L=R0+Lε∞+T m1，
其中R0固定。墙方程n0·R_L=0与n0·P†n0=0给
T=L+n0·R0，
所以R_L/L→P†n0。
若a0≠0，该墙不是初始墙，而是outgoing闭锥，不包含其正修正方向P†n0。若任意大L仍有R_L在墙上，闭性与锥性便强迫P†n0在墙上，矛盾。有限截断内统一取大L，可排除所有a0≠0。此论证不用假设后续∞速度始终为正。

因此首次弯折只能在初始∞墙取一次s项，系数为1。忘掉新增 mutable 与新增 principal 坐标，其后折线的初始指数为g；新增次数0的图由完成唯一性等于原C图的柱状提升，故旧弯折的法向配对、选项和系数完全相同。反过来，每条旧g折线由上述墙方程唯一确定首次∞弯折，L足够大时该弯折在所有旧弯折之前，因而可唯一加上最初竖直段。得到有限阶保系数双射，令K任意，即得S。

## 定理 M：按标签的有限余核证书

设W为R_C上的形式势，J=k<<R_C>>/closure(∂W)，char k=0。设α,β∈N^n满足α_iβ_i=0，并有连续右模表示
P_β --δ--> P_α → M →0，
其中P_γ=⊕_i(e_iJ)^{γ_i}，M有限维。令g=β−α、m=dimvec M。
在本轮已核定的unsigned framed majorant输入U下，
Supp F_g^C⊂[0,m]，deg F_g^C≤Σ_i m_i。
无需δ单射、kernel有限、M刚性、E=0、reachable、W非退化、genteel或reddening。

输入U的精确形式：对任意二无环箭图、势和顶点i，负基向量F_{−ei}逐系数不超过实际 unsigned cohomological framed series H_i。它的维数向量d项，只有当存在该维数的幂零 cyclic Jacobian表示时才可能非零。必须先在光滑的cyclic表示空间对TrW取vanishing cycles，再限制到幂零locus；不能先把TrW限制到幂零locus（那会恒为0）。输入U的DM/AB/rforg证明见前文第二十八次复查。

证明。将P_α的生成元编号k，位于i_k；P_β的生成元编号ℓ，位于j_ℓ。δ矩阵项取路径提升r_{kℓ}∈e_{i_k}k<<R_C>>e_{j_ℓ}。支撑不交保证i_k≠j_ℓ，故每个非零矩阵项只有正长度路径。
加顶点∞与箭
a_k:∞→i_k，b_ℓ:j_ℓ→∞，
并置W†=W+Σ_{k,ℓ}a_k r_{kℓ} b_ℓ。
扩大图仍二无环，新循环长度≥3，交换矩阵就是C†，新增列g=β−α。

考察dim V∞=1、由V∞生成的幂零临界表示。任何经过∞的正长度循环在V∞上是幂零标量，故为0。从生成向量出发曾返回∞的路径也为0，因此V_i由只经过一次起始a_k、随后仅走旧箭的向量v∞a_k p张成。每个v∞a_k p b_ℓ是经过∞的正长度循环，故为0，于是全部回箭b_ℓ=0。

对旧箭c，∂_cW†−∂_cW的每一项含某个b_ℓ，因此底层V|_Q满足原Jacobian关系。对回箭求导则有∂_{b_ℓ}W†=Σ_k a_k r_{kℓ}，恰使生成元像满足δ的关系。cyclic性给满射M→V|_Q，因而dimvec V|_Q≤m。由U和S，[s]H∞的z^a项在a≰m时为空支撑，故F_g的对应非负系数为0。

这里回箭为0的论证只需代数闭域闭点。非约化基上的一维幂零标量未必为0，所以不宣称整个临界概形与Quot_J(M,a)同构，也不把vanishing-cycle维数替换成普通Quot或Grassmannian的Euler特征。无闭点的有限型临界locus为空，已足够推出其上同调为0。

## 有限关系矩阵、非齐次势与停机范围

令R=k<<R_C>>、𝔪为箭理想，P_R=⊕(e_iR)^{α_i}，L为δ各列及其右路径倍数、全部Jacobian关系在P_R中生成的闭右子模。若有限截断验证
P_R𝔪^N ⊂ L+P_R𝔪^{N+1}，
则右乘𝔪反复代入再用闭性，得到P_R𝔪^N⊂L。于是余核已等于有限截断，精确维数向量可由终点分块关系矩阵算出。关系矩阵只需W至N+1次、δ至N次。非齐次关系须保留完整截断列，不能拆成独立齐次零关系。

简便充分停机条件：q_N=dim(P_R/(L+P_R𝔪^{N+1}))≤N。截断余核上的𝔪幂零，维数q_N的模至多有q_N个非零Loewy层，故
P_R𝔪^{q_N}⊂L+P_R𝔪^{N+1}⊂L+P_R𝔪^{q_N+1}，
闭性提升给实际尾部为0。若原M有限，足够大N必通过。将W、δ替成相同有限jet的多项式，关系矩阵不变，闭性提升使新旧余核具有相同截断模结构与维数向量；因此U可应用于多项式势，避免形式函数代数化问题。

有限余核条件的finite-jet开性是Fei 2610.09868v2 Proposition4.2及闭理想提升机制的模版本，不计作新开性定理。固定一个最大秩非零minor，附近截断余核维数≤原维数≤N，仍通过停机条件；各顶点分块minor可保持逐分量维数界。参数矩阵由整系数多项式给出，若复系数witness存在，同一α、β也有有理系数多项式witness。因此可枚举(W,δ,N)并精确验秩；找到了证书就停机，不能保证没有证书时停机。

一般斜可对称B：取C=DB与本轮已证F_g^B≤F_{Dg}^C。若存在
P_{(Dg)_+}→P_{(Dg)_-}→M→0，dim M<∞，
便有Supp F_g^B⊂[0,dimvec M]，完整散射计算只需根总次数≤dim M。这使原有限行证书成为β=0的特例，允许相关projective及整个J无限维。

适用边界：一般minimal presentation的两端可能共享顶点，只有真正可逆的contractible块可以消去，不能形式抵消所有公共projective。未证明每个g都存在两端支撑不交的有限余核。未证明该证书的存在类严格大于“允许随标签选任意势”的旧有限行存在类。未识别generic character与theta，也未证明generic span=mid或A=U。

## 本轮文献与新颖性校正

| 来源 | 已核内容及界限 |
|---|---|
| CMN1912.13052v2 Lem5.3、Prop5.4 | root亲读式5.2及清分母合法弯折。时间比例缩放属于既有平衡折线机制，前一节不将其本身宣称独创。 |
| Tang Hexagon2611.00015v1 §§2–4 | root与fresh adversarial代理亲读：有限记录剪切+Baire、rational扰动、正权运输均有旧先例。新候选仅为“基本Hi同时有限→包含边界的精确盒”这一组合判据。其旧Prop3.2要求吸收的positive polytope gauge。 |
| Bridgeland AG4(2017) §10 Th10.1 | 正projective framing，未覆盖任意signed g；S用outgoing排除独立证明。 |
| Mandel1503.06183v5 的 marked-tree/grafting；Leung–Ma–Young1902.05765v2 §3.3.2、Th3.20 的 square-zero theta 识别 | wall树与marked-theta树及grafting为旧机制；可核对S。未据此直接声称S已有同样明述或S绝对新。 |
| Fei2610.09868v2 Lem1.5、Prop1.8、Prop4.2 | 形式尾部提升、finite-jet秩开性已存在，模版本沿用这一机制。 |
| Fei2309.08326v4 Remark7.8 | generic span=mid仍是期待，individual generic与theta不必一致；M不依赖这类等式。 |
| 新增顶点/one-point-extension定向检索 | 命中通常projective framing、rigid one-point extensions和簇变量F多项式；未找到直接覆盖M且无需rigidity/nondegenerate的同条原文定理。保持“尚未发现”而非排他新颖宣告。 |

## 最小性路线：正角色与 CM 矩阵的区别

固定正评价后可把C乘法归一化为随机交换卷积。取支撑于共有±e_i的适应概率μ：leading coefficient1使每个标签都由μ的某次卷积到达。若h为极小正μ-harmonic函数，则对每个d，T_dh仍harmonic，且μ^k(d)>0给T_dh≤h/μ^k(d)，极小性迫使T_dh=χ(d)h；因此极小正harmonics是正ring characters。归一化harmonic空间的逐坐标Harnack界给紧性，结合共有初始变量与Stone–Weierstrass可得角色积分的唯一性。这是交换正卷积/Deny型机制的应用，不能当成theta最小性证明。

C、theta乃至前文不含全部CM的E诊断可具有相同角色参数空间；所以即使最小Martin边界集合相同，也没有得到p_C=p_θ。仍缺的是CM乘法矩阵如何分离有限theta支撑，或其核嵌入的额外控制。已登记一个binomial tent修改在2q次CM×CM系数出现−1的有限诊断，但不转向积累特殊例；继续寻找任意C的高阶耦合机制。

# 第三十四次推进：有限标签域的边界、κ 互逆和精确 Newton 多面体（2026-11-14 14:31 UTC）

本节以前一节一般 Laurent 有限性充要判据为输入。它不是将原有有限性假设重新命名：任意整数标签 g 的有限性现在等价于 n 个固定基本对向级数 H_i 的方向支撑值同时有限。下列结论覆盖有理边界；不推断整个实边界连续、整个有限域闭合或所有 theta 有限。

## 有限标签域及其闭包

令 \(H_i=F_{-e_i}^{-B}\)，\(L_i^B(g)=\sup_{a\in\operatorname{Supp}H_i}(-Dg)\cdot a\)，
\[
D_B=\{g\in\mathbb R^n:L_i^B(g)<\infty\ \forall i\},\qquad
f_B=D^{-1}L^B,\qquad \kappa_B(g)=g+Bf_B(g).
\]
已证判据给 \(\Theta_{\mathbb Z}=D_B\cap\mathbb Z^n\) 和 \(\Theta_{\mathbb Q}=D_B\cap\mathbb Q^n\)，有理标签以清分母定义。\(D_B\) 是凸锥、对坐标增加封闭，含非负正交锥。对 \(g\in D_B\)，\(g+\varepsilon\mathbf1\in\operatorname{int}D_B\)：足够小的邻域内每个点都逐坐标大于 g，故所有支撑值仍有统一上界。对任意有理点序列 \(q_j\ge g,\ q_j\to g\)，单调性及下半连续性给 \(L_i(q_j)\to L_i(g)\)。因而
\[
K_B:=\overline{\Theta_{\mathbb Q}}=\overline{D_B},\qquad
D_B\subset K_B,\qquad \operatorname{int}K_B=\operatorname{int}D_B.
\]
不由此断言 \(D_B=K_B\) 或 \(K_B\) 有限多面体化。

## κ 在全部整数／有理有限标签上的互逆

输入：(I) 已证实内部定理 \(\kappa_B:\operatorname{int}D_B\leftrightarrow\operatorname{int}D_{-B}\)，逆为 \(\kappa_{-B}\)，并保持 f；(II) 新有限性判据与共同最高根项定理；(III) CMMM 2505.09585v2 Theorem 3.8 的有限两项 theta 线性组合赋值独立性。此处只用有限 Newton 多项式情形，不涉及无限支撑的极小项问题。

**实边界单边包含。** 取 \(g_\varepsilon=g+\varepsilon\mathbf1\)，则 \(f_B(g_\varepsilon)\to u=f_B(g)\)，因为每个支撑线性函数逐点收敛且上确界单调恢复。令 \(h=\kappa_B(g)\)，内部互逆及下半连续性给
\[
f_{-B}(h)\le\liminf_{\varepsilon\downarrow0}f_{-B}(\kappa_B(g_\varepsilon))=u.
\]
所以 \(\kappa_B(D_B)\subset D_{-B}\)。暂时只有不等式。

**整数单射。** 若 \(\kappa_B(g)=\kappa_B(g')\)，置 \(u=f_B(g),u'=f_B(g')\)。两枚完整 principal theta \(y^{u'}\vartheta_g\) 与 \(y^u\vartheta_{g'}\) 具有同一个唯一最高完整指数 \((\kappa_B(g),u+u')\)，系数均 1。共变向量 \(v=(0,-\mathbf1)\) 唯一选出这一项。相减取消最低赋值项，违反 (III)，除非完整 theta 标签相同。因此 g=g'。本论证不要求 B 可逆；也可用最高系数交叉相乘，避免依赖 monic。

**整数降链。** 交替定义 \(g_{j+1}=\kappa_{(-1)^j B}(g_j)\)，\(u_j=f_{(-1)^jB}(g_j)\)。单边包含和最高根项整性保证 \(u_{j+1}\le u_j\in\mathbb N^n\)。故该降链最终稳定。稳定处有 \(g_{j+2}=g_j\)，单射将二周期逐次向前拉回，得 \(g_2=g_0\)。于是 \(u_0\ge u_1\ge u_2=u_0\)，所以全部相等。交换 B 与 −B 得
\[
\kappa_{-B}\kappa_B=\mathrm{id},\quad
\kappa_B\kappa_{-B}=\mathrm{id},\quad
f_{-B}\kappa_B=f_B.
\]
对有理点清分母并利用齐次性，得到
\[
\kappa_B:D_B\cap\mathbb Q^n\xrightarrow{\sim}D_{-B}\cap\mathbb Q^n,\qquad
\kappa_B^{-1}=\kappa_{-B}.
\]
不得从 \(B(u_0-u_1)=0\) 擅自消去 B；真正起作用的是降链及单射。全部实边界的等式与连续性尚未证明。

## 精确 Newton 多面体：有限 carrier 的实际含义

固定 \(g\in D_B\cap\mathbb Z^n\)，置 \(N_g=\operatorname{Newt}(F_g^B)\)。对整数 u 定义
\[
\ell_g(u)=\sup_{a\in\operatorname{Supp}F_u^{-B}}(-Dg)\cdot a.
\]
由强正性首项乘积界 \(F_u^{-B}\le\prod_iH_i^{[-u_i]_+}\)，
\[
0\le\ell_g(u)\le\sum_i[-u_i]_+L_i(g)<\infty.
\]
在 B 完整 principal 格使用 \(\Lambda_B=\begin{pmatrix}0&D\\-D&DB\end{pmatrix}\)。对整数 m，
\[
\operatorname{val}_{\Lambda_B(m,0)}\vartheta_{(g,0),+}^B=-h_{N_g}(Dm),
\qquad
\operatorname{val}_{\Lambda_B^T(g,0)}\vartheta_{(m,0),-}^B=-\ell_g(-m).
\]
第一项因新有限性判据有限，第二项由上述乘积界有限；CMMM Theorem 5.19 的双方 finite-value 假设在这里逐项满足。互易性于是给
\[
\ell_g(u)=h_{N_g}(-Du)=h_{-DN_g}(u).
\]
对有理 u 用齐次性，对实 u 用已有次线性连续延拓。因此以 \(\ell_g\) 为支撑函数的旧有限 carrier 精确是
\[
\boxed{P_g=-D\,\operatorname{Newt}(F_g^B)}.
\]
对有理 g，令 \(N_g=N^{-1}\operatorname{Newt}(F_{Ng}^B)\)，其与清分母 N 无关，由 \(\ell_{Ng}=N\ell_g\) 直接得出。特别地，对正整数 N，
\[
\operatorname{Newt}(F_{Ng}^B)=N\,\operatorname{Newt}(F_g^B).
\]
这只断言 Newton 多面体沿有理射线齐次，不断言 \(\vartheta_{Ng}=\vartheta_g^N\)，也不断言支撑格点饱和。

完整 cotangent carrier 也得到实际解释：在 C=−B 图，\(q_0=(-g,0),P_C=(C;I)\)，
\[
\rho_g(m,c)=-\ell_g(m)+c\cdot Dg
=\min_{a\in N_g}\{m\cdot Da+c\cdot Dg\}.
\]
其梯度凸包为 \(\{(Da,Dg):a\in N_g\}=\Lambda_C(q_0+P_CN_g)\)。本节必须放在有限性证明之后，不能反用它证明有限性而形成循环。

## 射影反转证明的有限墙因子修订

若同一墙位置包含平行墙族，或无限细化使整个墙函数不能在邻域内保持不变，不要求无限墙资料局部恒定。固定某个正根指数下的已选非零单项式，取它所需的有限个墙因子作为正性见证；反转、清分母后分别重复这些有限见证 \(Nu_j\) 次。其余平行墙因子均选常数 1。随后有限记录的可逆 shear 和 Baire 回避只作用于这一有限正性见证。固定目标 root degree 后，新增高阶墙不改变该系数。本修订消除了把有限阶稳定性误写成无限阶局部稳定性的风险。

## 新颖性记录与仍开放的最小性接口

旧输入须明确归属：CMN 1912.13052v2 Lemma 5.3 的时间缩放／平衡折线；Tang Hexagon 2611.00015v1 §2 的有限记录可逆 shear 与 Baire 回避、§4 的正权逐阶传输；CMMM 2505.09585v2 的 skew momentum、双方有限互易、有限 Newton 顶点 monicity。新候选是这些机制结合得到基本 H_i 同时方向有限的充要判据及尖锐盒界，不能将射影反转、正权传输或 monicity 本身申报为全新。

一星恒等式的方块矩阵 [[C,g],[-g^T,0]] 在本节仅取 C 斜对称；任意斜可对称 B 先用 C=DB 及 F_g^B≤F_{Dg}^{DB} 的既有比较。若另写带权扩张，应为 [[B,g],[-g^TD,0]]、对称化 diag(D,1)，不得漏 D。Leung–Ma–Young 1902.05765v2 Theorem 3.20 与 Mandel 1503.06183v5 的 square-zero/marked-leaf 机制是旧机制。Tang Hexagon 2610.00201v3 §12.4 Proposition 12.2 有 Markov 核的特殊附点公式，须注明是已知特例；不覆盖一般混合符号一星系数式。

最小性仍未闭合。固定正评价下、对 ±e_i 均给正质量的 CM 随机游走，其归一化 Martin 核为正调和函数。其 Choquet 表示落在紧的正角色层面上，任意固定两个 theta 的比值具有正上下界，所以统一非退化的 Green 核不能趋于单项 delta 系数检测器。若让游走律或评价退化，必须另证高阶 jet 控制；目前没有。对 Newton 顶点乘法分离，Newt(fM)=Newt(f)+Newt(M) 保持原内部指数的凸包包含关系，不能把任意内部项变成顶点；减去已识别正 theta 项也不保证保留 C 正锥。不能把这两条受阻路线误称为已证最小性。

# 14:39 专题推进与文献复查：有限 LP 证书、精确盒截断和正乘法核（2026-11-14 UTC）

## 森林权的有限 LP 证书

取 \(C=-DB\)，\(A_{ij}=[C_{ij}]_+\)，\(w=-Dg\)。已审主控为 \(H_i=F_{-e_i}^{-B}\preceq T_i^{d_i}\)，\(T_i=1+z_i\prod_jT_j^{A_{ij}}\)。若
\[
v\ge0,\qquad (I-A)v\ge w
\]
有有理解，则有限树的权按树高归纳被 v 控制，因此 \(L_i(g)\le d_iv_i\)，新判据给 \(\operatorname{Supp}F_g^B\subset[0,\lfloor v\rfloor]\)。H_i 与 T_i 无须本身有限。

对任意非负整数矩阵 A 及整数权 w，令 \(t_i\) 为颜色 i 的全部有限可空根树的最大权上确界。LP 可行当且仅当所有 t_i 有限。充分性由上述归纳；必要性中，整数权有界就达到最大，各子槽独立选最大树，故
\[
t_i=\max\{0,w_i+\sum_jA_{ij}t_j\}.
\]
任意实可行 v 的逐坐标 floor 仍可行，因为
\(\lfloor v_i\rfloor\ge\lfloor w_i+\sum_jA_{ij}v_j\rfloor\ge w_i+\sum_jA_{ij}\lfloor v_j\rfloor\)。
高度递推 \(t^{(0)}=0,\ t^{(r+1)}=\max(0,w+At^{(r)})\) 单调，且被 \(\lfloor v\rfloor\) 控制。每次未稳定至少使整数坐标总和增加 1，所以至多 \(\sum_i\lfloor v_i\rfloor\) 次严格更新后稳定。稳定值是全体有限树的最大权，逐坐标不超过任何可行解；因此精确 LP \(\min\sum_i v_i\) 的唯一最优解就是整数 t。

证书不要求相信 LP 求解器：只提交整数 \(t\ge0,(I-A)t\ge-Dg\) 即可核验上界。若要证森林最优性，另附从 0 到 t 的有限高度递推，或每种颜色一棵达到 t_i 的有限树。单独 fixed-point 等式不保证是最小解，零权循环可能有多个固定点。实际 \(f_B(g)\) 可以严格小于森林 t。

标准 Farkas 对偶给预计算证书锥
\[
E_A=\{g:\exists t\ge0,\ (I-A)t\ge-Dg\}
=\{g:g^TD\lambda\ge0\ \forall\lambda\ge0,\ A^T\lambda\ge\lambda\}.
\]
E_A 是闭有理多面锥且 \(E_A\subset D_B\)。对偶见证只认证森林 LP 不可行，不认证实际 theta 无限。LP、树语法和 Farkas 原理是旧方法；本轮候选增量是其与一般 theta 主控及新有限性判据的连接。

## 有限支撑证书到完整 Laurent 多项式的精确算法

输入 B,D,g 及经过全阶证明核验的有理上界 \(M_i\ge L_i(g)\ge0\)。来源可为 LP、有限呈示或其他合法证书，H_i 允许无限。置 \(m_i=\lfloor M_i/d_i\rfloor\)，\(K=\sum_i m_i\)。新判据先保证全支撑在盒 [0,m] 中。

保留独立根记账变量 t，取有限维单项式商
\[
\mathbb Q[t_1,\dots,t_n]/(t_1^{m_1+1},\dots,t_n^{m_n+1}).
\]
所有墙修正的根指数只增加非负整数，跑出盒的项不可能回到盒；故这个理想对所用 Lie bracket 及墙作用稳定。可直接在该商内做有限阶 KS 完成和折线记录枚举。非零折弯至多 K 次；每个有限阶只有有限墙，候选完整指数为 \((g+Ba,a)\)，a≤m。在有限截断内可算法选取避开有限坏超平面的有理正室端点。

所得是完整 F_g，不仅是 jet，因为全阶盒界已事先证明。较粗总次数≤K 截断也可用；盒商最多 \(\prod_i(m_i+1)\) 个根位置。完成后取支撑的逐坐标最大值 f，最高项定理保证它们同时由同一个系数 1 的点达到，并恢复
\[
L_i(g)=d_i f_i(g).
\]
因此粗但真实的上界证书，加一次有限目标计算，便可恢复可能无限的对向 H_i 的精确方向最大值；不必完整展开 H_i。

枚举各种有限证书形成 sound 半判定程序，但未证明某个预设证书语法覆盖全部有限 theta。有限 jet 中未见越界、若干阶稳定、或看到了候选最高项，都不能替代全阶上界证书。

## LP 通用实现诊断：实际计算插件输出

96 组随机有理可行证书、24 组带有回路不可行见证，秩最高 16。检查 floor、精确 Minimize、整数最优解与高度递推一致性。实际 Wolfram 运行 5.9 秒：FeasibleExactLPs=96；FloorCertificateChecks=96；NonzeroOptimalForestWeights=93；MaximumRank=16；MaximumStrictHeightUpdates=3；CorrectlyRejectedLPs=24；Failures=0；FirstFailure={}。这是一般公式与实现诊断，不替代证明。

```wolfram
ClearAll[v];
SeedRandom[202611141432];
checks=0; floorChecks=0; nonzero=0; maxRank=0; maxIterations=0; bad={};
Do[
 n=3+Mod[cas,14]; maxRank=Max[maxRank,n];
 aa=ConstantArray[0,{n,n}];
 Do[
  r=RandomChoice[{0,0,0,0,0,0,0,-2,-1,1,2}];
  If[r>0,aa[[i,j]]=r,If[r<0,aa[[j,i]]=-r]],
  {i,n},{j,i+1,n}];
 cert=RandomInteger[{0,18},n]/RandomChoice[{1,2,3}];
 ww=Floor[cert-aa.cert]-RandomInteger[{0,2},n];
 vars=Array[v,n];
 ans=Minimize[{Total[vars],And@@Join[Thread[vars>=0],Thread[(IdentityMatrix[n]-aa).vars>=ww]]},vars,Reals];
 lp=vars/.Last[ans];
 fl=Floor[cert];
 If[!And@@Join[Thread[fl>=0],Thread[fl-aa.fl>=ww]],AppendTo[bad,{"floor",cas}]];
 floorChecks++;
 state=ConstantArray[0,n]; it=0;
 While[True,
  nxt=Map[Max[0,#]&,ww+aa.state];
  If[nxt===state,Break[]];
  state=nxt;it++;
  If[it>Total[fl]+1,AppendTo[bad,{"nontermination",cas}];Break[]]];
 maxIterations=Max[maxIterations,it];
 If[state=!=lp||!And@@(IntegerQ/@lp)||First[ans]=!=Total[state],
  AppendTo[bad,{"LP-recursion",cas,lp,state,ans}]];
 If[Total[state]>0,nonzero++];
 checks++,
 {cas,96}];
infeasible=0;
Do[
 n=3+Mod[cas,10]; aa=ConstantArray[0,{n,n}];
 Do[aa[[i,1+Mod[i,n]]]=RandomInteger[{1,3}],{i,n}];
 Do[If[aa[[i,j]]==0&&aa[[j,i]]==0,aa[[i,j]]=RandomChoice[{0,0,1,2}]],{i,n},{j,i+1,n}];
 ww=RandomInteger[{1,4},n]; vars=Array[v,n];
 ans=Quiet[Minimize[{Total[vars],And@@Join[Thread[vars>=0],Thread[(IdentityMatrix[n]-aa).vars>=ww]]},vars,Reals]];
 If[First[ans]===Infinity,infeasible++,AppendTo[bad,{"infeasible",cas,ans}]],
 {cas,24}];
<|"FeasibleExactLPs"->checks,"FloorCertificateChecks"->floorChecks,
"NonzeroOptimalForestWeights"->nonzero,"MaximumRank"->maxRank,
"MaximumStrictHeightUpdates"->maxIterations,"CorrectlyRejectedLPs"->infeasible,
"Failures"->Length[bad],"FirstFailure"->Take[bad,UpTo[1]]|>
```

## 无 involution 的 Choquet 引理：完整证明

固定 frozen 正值 y=s 和初始正点 x=p。令 \(\phi_g=\beta_g(p,s)>0\)，\(b_g=\beta_g/\phi_g\)。若 \(\beta_g\beta_h=\sum_k n_{gh}^k(s)\beta_k\)，则
\[
b_gb_h=\sum_kP(g,h;k)b_k,\quad
P(g,h;k)=\frac{n_{gh}^k(s)\phi_k}{\phi_g\phi_h}\ge0,\quad\sum_kP(g,h;k)=1.
\]
每行有限，卷积交换且结合；这里只得到 stochastic semihypergroup，不声明通常 hypergroup 的 involution 公理。

取**有限支持**概率 \(\mu\)，在全部 \(\pm e_i\) 上有正质量，其他 CM 也只加有限个。定义 \(T_df(h)=\sum_kP(d,h;k)f(k)\)。leading coefficient 1 保证任意标签可由 \(\pm e_i\) 的乘法正路径达到，任意 h 到 k 也有 leading 路径，故 \(T_\mu\) 不可约。

对 \(\lambda>0\)，设非空
\(K_\lambda=\{h\ge0:T_\mu h=\lambda h,\ h(0)=1\}\)。
从 0 到 g 及反向的路径分别给每个 h(g) 的统一有限上界与严格正下界。因 \(T_\mu\) 每行有限，方程逐点闭，K_λ 是可度量紧凸集。

若 h 极端，对任意 d 选 r 使 \(a=\mu^{*r}(d)>0\)。交换性给 \(T_dh\) 仍为 λ 特征函数，且 \(aT_dh\le T_\mu^rh=\lambda^rh\)。极端性因此使 \(T_dh=\chi(d)h\)，在 0 取值知 χ(d)=h(d)。结合乘法公式，χ 是严格正代数角色。

角色 \(\psi(\beta_g)=\phi_g\chi(g)\) 在初始 x_i 上严格正，延拓至初始 Laurent 局部化，唯一等于某个 x=t>0 的评价。反之 C 的初始 Laurent 非负使每个正评价严格正。因此极端点位于
\[
h_t(g)=\frac{\beta_g(t,s)}{\beta_g(p,s)},\quad
S_{\mu,\lambda}=\{t>0:\sum_d\mu(d)\beta_d(t,s)/\beta_d(p,s)=\lambda\}.
\]
S 紧：初始 x_i 项给 t_i 上界，而 \(I_i=x_i^{-1}H_i\ge t_i^{-1}\) 给下界。

每个 \(h_t\) 确实极端：将它按 Choquet 表成极端角色的概率混合，乘法与有限 linearization 给每个 χ(d) 的方差为 0。可数标签及初始变量分离点迫使测度集中在 t。一般 h 因此有表示
\[
h(g)=\int_S\frac{\beta_g(t,s)}{\beta_g(p,s)}\,d\nu(t).
\]
唯一性由 Stone–Weierstrass：坐标函数实线性张成含 1、乘法封闭且分离点的代数。λ=1 时常数 1 所张非负调和射线极端，写 \(1=h+(1-h)\) 可知所有有界实 μ 调和函数为常数。

证明没有使用 *、Haar 测度、正交性或范畴化。若 μ 仅取共有初始／对向 CM，S 的参数空间独立于 C；但 \(t\mapsto(h_t(g))_g\) 的坐标嵌入依赖 β_g，所以没有得到剖面相等。

## 正评价混合的阻断与有限 budget detector

固定非退化 μ 的 Green/Martin 极限（存在时）属于上述正调和函数，故成为紧 S 上的正评价混合。任意固定两个正 theta 在 S 上有严格正的比值下界，无法在一个取值正规化为 1 时让其他项都趋 0。

更一般，若正 Laurent 多项式 \(F_0,\dots,F_r\) 满足
\[
\operatorname{Newt}(F_0)\subset\operatorname{conv}\bigcup_{i\ge1}\operatorname{Newt}(F_i),
\]
则 \(F_0(t)\le C\sum_{i\ge1}F_i(t)\) 对所有 t>0 成立。逐个将 F_0 的指数写成其他支撑指数的凸组合，weighted AM–GM 给单项式不等式，再乘系数求和即可。所有正评价混合、非负正规化及存在的退化极限都保留此不等式。因此只保留正角色数据的路线原则上无法读取这类内部负 theta 系数。这不排除先取形式 frozen 系数或固定时间的系数核。

另一条**充分**最小性条件：将 frozen powers 并入整数基标签，给任意有限 theta-support S 和 λ∈S，若存在 ordinary CM 乘积 W_j（或非负有限和）、C 整数基坐标泛函 ℓ_j（或非负有限和）以及 r_j>0，使
\[
r_j^{-1}\ell_j(W_je^\theta_\mu)\longrightarrow\delta_{\lambda\mu}\quad(\mu\in S),
\]
则对任意 \(\beta=\sum_{\mu\in S}a_\mu e^\theta_\mu\in C\)，强正性给
\(a_\lambda=\lim_jr_j^{-1}\ell_j(W_j\beta)\ge0\)。
Hamel 有限性使有限和与极限交换合法。这个 detector 与剖面相等是两条充分路线，不宣称逻辑等价。

已知 CM 行耦合 \(a_\theta(W)=a_C(W)T\)、乘法 intertwining 及 CM 列为恒等，但尚未证明产生所需正分离。普通有限维线性分离允许负权，不能直接使用。若继续核路线，应保留 \(L_{N,k}(f)=[e_k^C](fM_N)\) 的有限 word budget，并让 k 沿移动支撑边界取值；尚缺一般 sharp frontier/ratio 定理。

Newton 乘法的 Minkowski 加法不能使已有内部支撑的每个平移变成顶点，κ 在局部线性区间内也保留凸内部关系。减去已读出的正 theta 顶点项不保证保留 C 正锥，故不能据此逐层剥离。

## 本轮查新与出处修正

14:32–14:39 以最近 30/180/365 天过滤广查 arXiv、Hexagon 的 theta 有限性、finite presentation、strongly-positive minimality，并回读 primary。未发现已读原文直接覆盖一般 H_i 同时有限判据。重新命中 Reading–Stella affine imaginary 结构、Mandel ordinary/scattering atlas 区分、Tang rank-two detector；后者仅检验其一般机制接口，不转入特殊例子计算。

出处修正已同步前节：square-zero extension H⊕A[-1]、§3.3.2 与 Th3.20 属于 Leung–Ma–Young1902.05765v2；Mandel1503.06183v5 提供 marked-tree/grafting 相关框架。Frías-Medina–Magee2407.02427v2 作者名已核正。Davison–Meinhardt1601.02479v5 的 graded-cohom HN／integrality 及 Davison AG11(2024) §2.2 rforg 经新代理重读，无需额外 purity；nilpotent Serre restriction 仍按原文条件。

一星式 fresh audit：完整 principal 修正 P†n 不会因 mutable 投影为零而变为零；墙若沿纯 frozen 方向柱状，则不能是排除该方向的 outgoing 墙。取 GHKK 正且逐墙 outgoing 代表，保持有限实际墙因子见证。有限呈示只用闭点 b=0，不升级为非约化 Quot scheme 同构。新独立复查目前未发现实质漏洞。

# 14:50 一般机制补充：森林证书与有限呈示的真实关系；最小性条件桥独立复核

## 最小有限森林解的正支撑必无环，n+1 轮即可判定

设 \(t=\max(0,w+At)\) 为已证的最小有限树权解，\(S=\{i:t_i>0\}\)。对 i∈S，选达到 t_i 的有限树的最小高度 h_i。根必非空，且每个 A_ij 子槽必须达到 t_j，否则总权严格小于 t_i。故对 A_ij>0 且 t_j>0，有 \(h_i\ge h_j+1\)。S 上不可能有有向环。

给所有零权子槽取空树，正权最优树高度至多 |S|≤n。因此从 0 做高度递推，若存在任何有限可行势，就必有
\[
t^{(n)}=t^{(n+1)}=t.
\]
反之这两个向量相等即给整数势证书。于是只需 n+1 轮整数矩阵向量乘法和逐坐标 max，就能精确判定**森林证书**可行性；不再必须调用 LP 求解器。不可行仍不表示实际 theta 无限。这是标准树语法／Bellman–Ford 型机制的有效实现，不作为新的散射存在定理。

## 森林证书实际属于定理 M 的零势子类

先设 B 斜对称，按 B_ij>0 画 R_B 的箭 i→j，并用右模 \(P_i=e_i k\langle\!\langle R_B\rangle\!\rangle\)、左至右路径乘法。A=[−B]_+，R_B 邻接为 A^T，因此顶点 i 的入箭源维数和为 (At)_i。置 w=−g，r=g+(I−A)t≥0，则 \(r_it_i=0\)。

取 M_i=k^{t_i}，为每条箭选有理线性映射，使每个合并入箭矩阵满秩到 \(\min((At)_i,t_i)\)。按终点分组，这些条件可同时实现。M 的支撑 S 无环，所以 M 幂零。W=0 的连续路径呈示为
\[
\bigoplus_{a:i\to j}M_i\otimes P_j\longrightarrow
\bigoplus_iM_i\otimes P_i\longrightarrow M\to0,
\]
a 分量的关系为 \(m\otimes a-M(a)m\otimes e_j\)。反复代入沿路径的关系，把任意项化为 M 中的取值；长路径因幂零而归零，闭子模商正是 M。这只需余核结论，不假设完成路径代数整体 hereditary。

消去常数矩阵的真正可逆块；完成代数中 I+正长度矩阵有连续逆。余下呈示 multiplicity 为
\[
\alpha_{0i}=\max(t_i-(At)_i,0),\quad
\beta_{0i}=\max((At)_i-t_i,0).
\]
固定点式给 \(\alpha_0=g_-\)，\(\beta_0+r=g_+\)。向 domain 添加零映射的 P_r，得到真正两端支撑不交的
\[
P_{g_+}\longrightarrow P_{g_-}\longrightarrow M\to0,\qquad \dimvec M=t.
\]
形式消元矩阵可由前述有限 jet 模证书截成有理多项式矩阵而保留有限余核。一般 B 对 C=DB、标签 Dg 同做。

因此森林 LP 是定理 M 的显式可判定 W=0 子类。并且其根支撑只在无环 S 上，root-face freezing 给 \(F_g^B=F_{g_S}^{B_{SS}}\)（根变量仍作原嵌入）。应定位为无环冻结机制的有效权阈值实现，不声称它带来一个独立的新一般有限性类别。主新候选仍是 P 与一般 S/M。

## 呈示证书完备性的真实强度

在固定二无环箭图 Q 上，下列条件等价：
(1) 每个 i 分别存在势 W_i，使 \(e_iJ(W_i)\) 有限维；
(2) 存在一个共同势 W，使 J(W) 有限维。

(2)⇒(1) 显然。对反向，各有限 row 有一个有限次数 N_i 的关系矩阵秩证书；取 M 足够大，把所有势放在次数≤M 的循环势仿射空间 V_M 中。每个 row 证书由非零 minor 给非空 Zariski 开集 U_i，且闭理想提升保证该开集上的实际完成 row 有限。V_M 不可约，有限个非空开集交非空；可选有理多项式 W。此处使用的是 Fei 的既有有限 jet 开性机制，不另称新开性定理。

对标签 −e_i，定理 M 的支撑不交条件迫使 \(\alpha=e_i,\beta=0\)，所以其见证就是有限 projective \(M=P_i\)。如果断言每个有限 theta 都有 M 证书，那么在全部 theta 有限的类中，上述引理将迫使存在 Jacobi-finite 势。当前没有证明这一完备性，也不额外推断所得势非退化。这个必要后果说明不能把一个 sound 的证书枚举程序写成普遍停机算法。

## n+1 轮与呈示方向：计算插件实际核验

128 组，秩 3–20，包含一般含环权、有理可行势、无环大权和显式不可行循环。实际 6.3 秒输出：ExactLPComparisons=128；FeasibleCases=75；InfeasibleCases=53；MaximumRank=20；MaximumStabilizationDepth=11；LargestFiniteTreeWeight=21623；PositiveSupportDAGChecks=75；PresentationMultiplicityChecks=75；Failures=0。核查 A_S 幂零及 α0=g_-、β0+r=g_+ 的方向。没有将此有限样本计算当作一般证明。

```wolfram
ClearAll[v];
SeedRandom[202611141451];
bad={};feasible=0;infeasible=0;maxRank=0;maxDepth=0;maxWeight=0;dagChecks=0;presentationChecks=0;
Do[
 n=3+Mod[cas,18];maxRank=Max[maxRank,n];
 aa=ConstantArray[0,{n,n}];mode=Mod[cas,4];
 If[mode==2,
  Do[aa[[i,j]]=RandomChoice[{0,0,1,2}],{i,n},{j,i+1,n}],
  Do[r=RandomChoice[{0,0,0,0,0,-2,-1,1,2}];
   If[r>0,aa[[i,j]]=r,If[r<0,aa[[j,i]]=-r]],{i,n},{j,i+1,n}]];
 If[mode==3,
  aa=ConstantArray[0,{n,n}];
  Do[aa[[i,1+Mod[i,n]]]=RandomInteger[{1,3}],{i,n}]];
 ww=Which[
  mode==1,cert=RandomInteger[{0,15},n]/RandomChoice[{1,2,3}];Floor[cert-aa.cert]-RandomInteger[{0,2},n],
  mode==3,RandomInteger[{1,5},n],
  True,RandomInteger[{-5,5},n]];
 seq=NestList[Map[Max[0,#]&,ww+aa.#]&,ConstantArray[0,n],n+1];
 stable=seq[[n+1]]===seq[[n+2]];
 vars=Array[v,n];
 ans=Quiet[Minimize[{Total[vars],And@@Join[Thread[vars>=0],Thread[(IdentityMatrix[n]-aa).vars>=ww]]},vars,Reals]];
 lpFinite=First[ans]=!=Infinity;
 If[stable=!=lpFinite,AppendTo[bad,{"finiteness",cas,stable,ans}]];
 If[stable,
  feasible++;tt=seq[[n+1]];lp=vars/.Last[ans];
  If[tt=!=lp,AppendTo[bad,{"value",cas,tt,lp}]];
  depth=First[FirstPosition[MapThread[SameQ,{Most[seq],Rest[seq]}],True]]-1;
  maxDepth=Max[maxDepth,depth];maxWeight=Max[maxWeight,Max[tt]];
  ss=Flatten[Position[tt,_?(#>0&)]];
  If[Length[ss]>0&&MatrixPower[aa[[ss,ss]],Length[ss]]=!=ConstantArray[0,{Length[ss],Length[ss]}],AppendTo[bad,{"positive-support-cycle",cas}]];
  dagChecks++;
  gg=-ww;rr=gg+tt-aa.tt;
  al=Map[Max[0,#]&,tt-aa.tt];be=Map[Max[0,#]&,aa.tt-tt];
  If[al=!=Map[Max[0,-#]&,gg]||be+rr=!=Map[Max[0,#]&,gg]||rr tt=!=ConstantArray[0,n],AppendTo[bad,{"presentation",cas}]];
  presentationChecks++,
  infeasible++],
 {cas,128}];
<|"ExactLPComparisons"->128,"FeasibleCases"->feasible,"InfeasibleCases"->infeasible,
"MaximumRank"->maxRank,"MaximumStabilizationDepth"->maxDepth,
"LargestFiniteTreeWeight"->maxWeight,"PositiveSupportDAGChecks"->dagChecks,
"PresentationMultiplicityChecks"->presentationChecks,"Failures"->Length[bad],
"FirstFailure"->Take[bad,UpTo[1]]|>
```

## 条件最小性桥的独立审查修订

fresh adversarial 代理重新逐项阅读“相对 log jets 一致 o(N) ⇒ Følner 平台 ⇒ 散射正性 ⇒ 有限 theta 系数非负”的完整证明。目前未发现相邻比值逐点收敛、绝对 jets 有界或无限和换序的偷渡。适用前提必须保留：无环 principal；实际整系数 pointed 强正 Hamel 基；固定平移 log-ratio jets 统一有界；宏观紧盒上相对 log jets 一致 o(N)。

深室的统一性可显式补全：取 \(\Omega\Subset\Omega'\)，闭包均落在端点 Q 对所有 \(0<|n|\le D\) 的同一法向超平面 cell，且与这些超平面有正距 δ。令
\(M_D=\max_{|a|\le D,0<|n|\le D}|Ba\cdot\nu(n)|\)。
Nδ>M_D 时，F_N 及固定 padding 内的每个末指数 h+Ba 对相关法向均与 Q 同号。最后折弯却强迫 \(Q\cdot\nu(n)=-u(h+Ba)\cdot\nu(n)\)，u>0，矛盾。故 theta 的 D-jet 在该盒内一致为单项式；不要求 h 位于整个无限图的完整室。

在第 k 阶归纳中，低 jets 共用一个 U 后，交叉项全部抵消，得到
\(c_{d,h}(q)=P_d^Q(q)+u_q(h)-u_q(h+d)\)。
选择零预算探针后第一项为 0。若 \(\sup|u_q|\le\varepsilon_N N\)、bad 边比例≤δ_N、所有固定差分绝对值≤K，则沿坐标 telescoping 给
\[
\#\{\text{good 边且 }\Delta_d u_q\ne0\}
\le C\varepsilon_NN^n+K\delta_NN^n=o(N^n).
\]
这里 good 边差分是非负整数；u_q 本身无须整数。有限 q 和有限平移路径取并集得到共同有限窗口平台。整数性及 bad 边 O(1) 均是承重前提，不可删去。

原图表的局部一致复解析剖面收敛经 Cauchy 给 jets=o(N)。散射代换只取固定有限 jet，是固定有限线性组合；不必假设整个散射映射解析。末端系数隔离也只涉及有限 s≤s0 的项，最后折弯的 u>0 同号矛盾确保只剩指定标签的直线项。这个局部识别机制属于 CMMM／GHKK 的旧输入。

宽泛 detector 条件若允许任意非负 C 坐标和，则 CM 正乘法并不扩大有限支撑上的正泛函锥；W=1 已给整个锥。因此它只是充分性的重述，不应记作攻破难度的新结果。真正未知仍是剖面相等，或某个可构造的显式单坐标、有限 CM 步数的边界核定理。

## 最新原文接口与未闭合之处

Tang Hexagon2610.00025v3 已由 root 与代理重读 §§2–5：Lemma4.3 和 Theorem5.1 的有限折线／结构常数检测模板可作经典使用；但实际基的大平移平坦性由 Lemma3.1 的量子 degree capacity 及 bar 不变性驱动，v=1 后这一步不能沿用。它没有给当前任意经典强正基补出剖面相等。Cheung1906.12299v1 的相应 Grassmannian 公式另有无环／cluster-complex 假设，也未拿来代替一般 M。

所有路线按成败记录：P/S/M 的本轮证明链与边界推论维持；LP 有效但归入 M／无环冻结子类；一般证书完备性未证；最小性条件桥经独立审查维持，但上游剖面相等仍未完成。继续研究集中于这个主缺口。

# 14:59 最后一般接口与整格核对（2026-11-14 UTC）

## 一星势的有界临界闭点与呈示证书等价

固定斜对称 C、整数 g 及 \(C^\dagger=\begin{pmatrix}C&g\\-g^T&0\end{pmatrix}\)。以下两种存在性等价：
(1) 存在旧势 W 及支撑不交的有限余核呈示 \(P_{g_+}\to P_{g_-}\to M\to0\)；
(2) 存在一星势 Ω，使所有新顶点维数 1 的幂零 cyclic 临界闭点，其旧部分维数有统一上界。

按循环经过新顶点的次数分解 Ω。零次部分为 W；一次部分可唯一写成 \(\sum a_kr_{k\ell}b_\ell\)；至少两次部分含至少两条返回箭 b。任何新顶点维数 1 的幂零 cyclic 表示都有 b=0：从新顶点生成任意旧顶点向量，再接 b 得到新顶点上的正长度圈，必为幂零标量而等于零。

因此旧箭偏导只剩 ∂W；∂b 只剩 \(\sum a_kr_{k\ell}\)；多次经过新顶点的部分求导后仍有 b，全部归零。这样的闭点恰对应
\(M=\operatorname{coker}(P_{g_+}\xrightarrow{r}P_{g_-})\)
的带指定满射的有限维连续幂零商。这里保持生成元；不是忘记商映射后的任意模同构类，更不是概形或 vanishing-cycle 同构。

完成路径代数及其闭 Jacobian 商线性紧。连续有限 projective 和之间的映射像闭：若 w 在像的闭包，则各 \(\delta^{-1}(w+U_N)\) 为具有有限交性质的非空闭仿射子空间，线性紧性给交点。因此 M 是分离完成商。若 M 无限维，则有限截断 \(M/M\mathfrak m^N\) 的维数必无界；否则非降整数维数最终稳定，完成分离性迫使尾部为零，M 有限。每个截断都给上述 cyclic 临界闭点，故 (2)⇒(1)。反向正是有限 M 的商维数有界。

形式势只在每个有限维幂零表示中读取有限 jet，不假设存在全局解析 TrΩ 或形式 vanishing cycles。得到有限 M 后，可用已审 finite-jet 呈示证书换成多项式 W,r。删去多次经过新顶点的项只保持这些闭点与维数范围，不声称保持 vanishing cycles。

一星恒等式将目标 theta 有限变成 canonical 一星基本 theta 的 s 一次切片有限；U 给“存在上述有界 category ⇒ canonical 切片有限”。尚缺的逆向是从 canonical 切片有限构造某个势使全部临界闭点有界。正支配不允许把 canonical 系数消失倒推为整个模空间为空，不能用该等价偷补证书完备性。

## 主判据最后整格检查

在对向 C=−B 的完整 principal 格，\(P=(C;I)\)，
\(\Lambda=\begin{pmatrix}0&D\\-D&DC\end{pmatrix}\)，
\(\det\Lambda=(\det D)^2\ne0\)，\(P^T\Lambda P=0\)。
因此 B 有核不会使配对退化。对任意非零正根 n，即使 D 非本原，令
\[
d(n)=\gcd_i(d_i n_i),\qquad
\nu_n=(Dn,0)/d(n).
\]
则 ν_n 为整本原法向，\(\Lambda Pn=d(n)\nu_n\)，所有实际墙幂仍为整数。整个证明不要求 Λ 是 unimodular 整格同构，更不要求 B 可逆。

清分母 N 只对单个有限正性记录选择。p 逼近负坐标轴时，对每个固定目标项分别选适当实泛端点，再在保持其有限墙因子见证的邻域取有理 p。无需全图 generic 的有理点，也无需一个 N 同时用于所有 p。最高根 f 的整性来自有限支撑盒坐标最大值；κ 的降链证明没有消去 B 的核。

## 末轮文献及路线结论

14:57–15:00 再查最近 30／365 天 primary 候选。H-based quivers 一类新结果涉及广义丛代数及已有有限 Jacobian 假设，不并入当前经典主结论。新命中的 Hua–Zhou2610.35466 有限决定性候选只核官方来源与范围；没有在最后时刻把未完成证明审核的新结果作为输入。Geiss–Hartung–Labardini–Schröer2610.18805 正文获取仍不足，未采用其结论。

最后核的数学状态：P 的一般充要判据、S/M 的独立证明链、尖锐盒及有理边界 κ 互逆保留；LP 属于零势呈示／无环冻结的有效实现；最小性已证统一解析控制及条件 Følner 桥，但 p_C=p_theta 仍开放。对宽泛 detector、正谱 Green 与 quantum capacity 的失败连接已明确记录，没有将其重述计为总目标已完成。

## 最后原文核验记录（2026-11-14 15:00 UTC）

Hua–Zhou，arXiv2610.35466v1（2026-10-26）已取得官方 PDF/HTML；root 与代理亲读 Theorem4.8 的证明及 Question1.3。其定理针对已给势 Φ 的 trace-finite 与 finite determinacy，Corollary4.9 只有 Jacobi-finite⇒finite-determined；没有从 finite theta 构造势的存在结论。原文仍将 trace-finite 与 Jacobi-finite 相关存在性列为问题。没有完成其全部前置命题的强审，也没有将它加入 P/S/M 的承重输入。官方来源：https://arxiv.org/html/2610.35466v1 。

最后三个独立复核均结束：一般 P 的整数格／有核 B／非本原 D；无环条件 Følner 桥；一星势有界临界闭点与有限余核呈示等价。各自结论及具体量词修订已保留。最小性上游剖面相等未闭合，有限证书相对于所有 finite theta 的完备性未闭合。