#!/usr/bin/env python3
"""Extract verbatim computation cells from the bundled research history.
No network access or third-party dependencies. Run from any working directory.
Output is placed in a sibling computations/ directory.
Some cells are recorded outputs or failed diagnostics; inspect index.json.
"""
from pathlib import Path
import json
import re

root = Path(__file__).resolve().parent.parent
source = (root / "02_research_history.md").read_text(encoding="utf-8")
output = root / "computations"
output.mkdir(exist_ok=True)
index = []
for number, match in enumerate(re.finditer(r"```(wolfram|wl|javascript)\n([\s\S]*?)``", source), 1):
    language, body = match.group(1), match.group(2)
    suffix = "js" if language == "javascript" else "wl"
    name = f"{number:03d}_code.{suffix}"
    target = output / name
    if target.exists() and target.read_text(encoding="utf-8") != body:
        raise RuntimeError(f"Refusing to overwrite a changed file: {target}")
    target.write_text(body, encoding="utf-8")
    index.append({
        "file": name,
        "language": language,
        "source_character_offset": match.start(),
        "preceding_context": source[max(0, match.start() - 500):match.start()],
    })
(output / "index.json").write_text(
    json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(f"Extracted {len(index)} verbatim cells to {output}")
