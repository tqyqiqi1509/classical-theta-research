# Classical_Theta_Laurent_Minimality_total

研究：经典 theta 的 Laurent 展开、有限支撑、多面体与强正最小性。
用户：Qiyue Tang。研究窗口：2026-11-14 03:01:18–15:01:18 UTC。

阅读顺序：
1. 01_final_report.md：整理后的结论、证明机制、新颖性边界和仍开放的主问题。
2. 02_research_history.md：逐轮证明、文献审核、路线与失败记录；后续修订覆盖前期尚未闭合的状态。
3. 03_sources.csv：核心文献标识、版本、URL、使用层级。
4. tools/extract_computations.py：用 Python 标准库从完整研究记录逐字提取代码块与上下文索引。原始代码和实际输出均已内嵌于 02_research_history.md；失败版本同样保留。

本包只讨论经典丛代数。没有使用 Li Fang／Li–Pan 的结论。任意强正基的 theta 最小性仍开放；不要将条件桥或计算通过写成总命题已证。

05:23 UTC 前已保存的原始阶段附件（130 文件）独立保留，未在本包中重复复制：
https://chatgpt.com/library?file_id=libfile_fde3_f-e9b172d19e108191bc889ba82014daa9_48bd88a843808191b2f169295ad46038&account_id=personal
本包包含本轮整理后的完整结论及后续全部证明记录和代码；不声称内嵌了上述早期附件的逐文件副本。

研究记录在线位置：
https://chatgpt.com/space/page_18f50d2b68588191aa098db20dac4e25

具体 SHA-256 和 ZIP 文件清单见下载页。