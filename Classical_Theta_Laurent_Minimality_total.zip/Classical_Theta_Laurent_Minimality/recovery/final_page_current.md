# 经典 theta 的 Laurent 展开、有限支撑与强正最小性

![Classical\_Theta\_Laurent\_Minimality\_total.zip 下载](visualize:fde1_bGliZmlsZV9sQkNZa0FhXzJhNnpfZWJTSkJQM3hB_FileDrive_48bd88a843808191b2f169295ad46038)

研究窗口：2026-11-14 03:01:18–15:01:18 UTC。范围：经典、主系数丛代数；有限性主结果允许任意整斜可对称交换矩阵。最小性研究以无环主系数情形中的任意实际强正 Hamel 基为对象，要求包含全部普通 cluster atlas 的 cluster monomial。

本报告的结论层级：Laurent 有限性主证明、一星恒等式、有限呈示证书及其推论已在本轮形成完整证明，并经分工复核；任意强正基的 theta 最小性仍未证明。这里的“已证”指本轮研究稿中证明链已闭合，不代表已获外部同行评审。所有新颖性判断均是截至本次检索未发现直接覆盖的结论，不作为绝对优先权断言。

## 1. 核心结果：用 n 个固定对向级数判定任意标签的有限性

取 \(B\in M_n(\mathbb Z)\)，\(D=\operatorname{diag}(d_i)>0\)，使 \(DB\) 斜对称。写
\[
\vartheta_g^B=x^gF_g^B(z),\qquad z^a=x^{Ba}y^a,\qquad
F_g^B\in1+(z)\mathbb N[[z]].
\]
固定 n 个对向基本级数
\[
H_i=F_{-e_i}^{-B},\qquad
L_i(g)=\sup_{a\in\operatorname{Supp}H_i}(-Dg)\cdot a.
\]
则对于每个整数标签 g，
\[
\boxed{\vartheta_g^B\text{ 的固定种子 Laurent 展开有限}
\iff L_i(g)<\infty\quad(1\le i\le n).}
\]
当这些量有限时，
\[
f_i(g)=L_i(g)/d_i\in\mathbb N,\qquad
\operatorname{Supp}F_g^B\subseteq\prod_i[0,f_i(g)].
\]
向量 f(g) 本身是实际支撑点，且其系数为 1，所以这不是任意外包盒：每个方向的坐标上界同时达到。

此定理不预设 g 在有限标签域的内部，不预设 Jacobi 有限、reddening、全部 theta 有限或某个 DT 映射置换 theta。尤其涵盖方向权重位于边界的情况。但 \(L_i(g)<\infty\) 仍是无限级数支撑条件，定理本身不是任意输入均停机的判定程序。

### 证明的实质

必要性和共同最高点利用 CMMM 的单项式端点情形、有限喷射稳定性及双方有限互易。不能直接把“双方取值有限”的互易定理用于一个尚不知有限的方向。研究稿先用单项式端点补出另一侧有限性，再使用完整互易。

充分性是本轮关键。对目标 theta 的任意一个实际折线支撑项，反射到对向图，对固定有限折线记录做射影反转 \(\delta(\tau)=-\tau\gamma(1/\tau)\)。选有理记录并统一清分母后，反转后的每次折弯由原正墙单项式的整数次重复产生；不要求原折弯为极端项。有限记录的可逆 shear 和 Baire 回避把端点移至合法泛点。逐根次数的正权墙穿越保持统一赋值下界。最后，斜动量守恒将此下界变成原目标根指数 A 的不等式
\[
\sum_i(-p_i)d_iA_i\le\sum_i(-p_i)L_i(g),\qquad p_i<0.
\]
先取 p 于负盒获得总次数界，再令 p 逼近各负坐标轴，得到尖锐坐标盒。

射影反转、动量、正权传输本身都有旧来源；候选新结果是它们合并产生上述一般充要判据及边界盒界。完整证明及平行墙有限因子修订见研究记录最后三次推进。

## 2. 真正可计算的有限性证书

### 2.1 森林线性规划证书

使用本轮已证明的经典 theta 正系数森林主控，取 \(C=-DB\)，\(A_{ij}=[C_{ij}]_+\)，并定义
\[
T_i=1+z_i\prod_jT_j^{A_{ij}},\qquad H_i\preceq T_i^{d_i}.
\]
令 \(w=-Dg\)。若存在有理向量 v 满足
\[
v\ge0,\qquad v\ge w+Av,
\]
则每棵有限有色树的 w 权不超过对应 v_i；从而
\[
L_i(g)\le d_iv_i,\qquad
\operatorname{Supp}F_g^B\subseteq[0,\lfloor v\rfloor].
\]
这将有限性化为一份有限线性不等式证书。原森林级数和 H_i 均可以无限。

对森林语法本身，以上 LP 可行性与所有最大树权有限等价。最小非负可行向量 t 为整数，等于从 0 开始递推
\[
t^{(r+1)}=\max(0,w+At^{(r)})
\]
得到的稳定值。给定可行 v 后，至多 \(\sum_i\lfloor v_i\rfloor\) 次严格更新就会稳定。进一步利用最小解正支撑无环，可加强为：只做 n+1 轮递推，比较第 n 与第 n+1 轮，就能精确判定这份森林证书是否可行。LP 的唯一最小总和解就是 t。LP 不可行只说明这套森林证书失效，不说明实际 theta 无限。

这段 LP 理论是标准树语法／单调递推原理的应用；其用途在于与 theta 主控及有限性判据连接。最后复核证明，这类证书还能构造成定理 M 的零势有限呈示，且其正支撑无环；因此它属于无环冻结机制的有效实现，不作为一个独立的新有限性类别。知道支撑盒后，用有限根次数的散射计算至 \(K=\sum_i t_i\)，即可得到完整 \(F_g\)，后续系数确为零。

### 2.2 一星系数恒等式

令 C 斜对称、g 为任意整数向量，添加一个顶点：
\[
C^\dagger=\begin{pmatrix}C&g\\-g^T&0\end{pmatrix}.
\]
记新根变量 s，则
\[
\boxed{[s]F_{-e_\infty}^{C^\dagger}(z,s)=F_g^C(z).}
\]
证明在 s²=0 及固定旧根次数下，把终点沿新顶点方向移远。首个非平凡折弯如果有旧根分量，其位置沿对应修正向量趋于无穷，与 outgoing 墙不包含该方向矛盾。因此首弯只能发生在新顶点初始墙，系数为 1；随后投影恰好是旧图的 g 折线。反向插入这一初始段给出有限阶双射。

必须在完整 principal 空间使用 \(P^\dagger n=(C^\dagger n,n)\)，不能因 mutable 投影为零而错误排除墙。并且选用保持逐墙 outgoing 性质的正散射图代表，不能任意合并为全超平面。

### 2.3 有限呈示证书

在与 C 一致的箭图与路径乘法约定下，令 J 为完成 Jacobi 代数。若有有限余核的呈示
\[
P_\beta\longrightarrow P_\alpha\longrightarrow M\longrightarrow0,
\qquad \alpha_i\beta_i=0,\qquad \dim M<\infty,\qquad g=\beta-\alpha,
\]
则
\[
\boxed{\operatorname{Supp}F_g^C\subseteq[0,\dimvec M].}
\]
不要求首映射单射、核有限、M 刚性或可达；不将稳定性散射图与 cluster 散射图直接认同。

做法是把呈示装入一星势函数：从新顶点加生成箭，回新顶点加关系箭。新顶点维数 1 的 nilpotent cyclic 表示中，所有正长度返回圈是零标量，因此关系回箭为零，旧部分是 M 的商。无符号 vanishing-cycle 上同调主控与一星系数式遂给支撑盒。只需闭点支撑为空时上同调为零；没有声称非约化基上的 scheme-level Quot 同构。

对形式势函数使用有限 jet 证书：在适当次数 N，有限维线性代数证明 \(P\mathfrak m^N\subset L+P\mathfrak m^{N+1}\)，再由闭性得 \(P\mathfrak m^N\subset L\)。必须保留非齐次关系整体，不可拆开齐次分量增加虚假关系。该证书可枚举，但尚未证明所有有限 theta 都由这种呈示见证。其完备性相当强：标签 −e_i 的见证必须是有限 projective；各 i 分别存在这样的势，再由有限 jet 开性即可推出一个共同的 Jacobi-finite 势。一般斜可对称 B 通过 \(F_g^B\preceq F_{Dg}^{DB}\) 传回。

## 3. 多面体结构：获得精确对象，但不宣称饱和

设 \(D_B=\{g:L_i(g)<\infty\ \forall i\}\)，则
\[
\Theta_{\mathbb Z}=D_B\cap\mathbb Z^n,\quad
\Theta_{\mathbb Q}=D_B\cap\mathbb Q^n,\quad
\overline{\Theta_{\mathbb Q}}=\overline{D_B}.
\]
D_B 是含非负正交锥、对坐标增加封闭的凸锥，但不据此认为它闭合或有有限条面的描述。

定义 \(\kappa_B(g)=g+Bf_B(g)\)。已证
\[
\kappa_B:D_B\cap\mathbb Q^n\longleftrightarrow D_{-B}\cap\mathbb Q^n,
\qquad \kappa_B^{-1}=\kappa_{-B},
\qquad f_{-B}\kappa_B=f_B.
\]
这包含全部有理边界。证明先取得实边界上的单边不等式，再以共同最高项和赋值独立性证明整数单射，最后用非负整数降链迫使二周期并清分母。不能因 B 可能有核而从 \(B(u-v)=0\) 直接推出 u=v。整个实边界的连续性与互逆性尚未建立。

对整数有限标签 g，令
\[
\ell_g(u)=\sup_{a\in\operatorname{Supp}F_u^{-B}}(-Dg)\cdot a.
\]
正乘积主控保证这个量对每个整数 u 有限。有限性判据成立后，合法使用 CMMM 的双方有限互易得到
\[
\ell_g(u)=h_{\operatorname{Newt}F_g^B}(-Du),\qquad
P_g=-D\,\operatorname{Newt}F_g^B.
\]
此前抽象构造的有限多面体 P_g 因此精确成为目标 Newton 多面体的线性像。并有
\[
\operatorname{Newt}(F_{Ng}^B)=N\operatorname{Newt}(F_g^B)\quad(N\in\mathbb Z_{>0}).
\]
这不等于 theta 的乘法幂恒等式，也不意味着 Newton 多面体的所有格点都有非零系数。没有采用 Li Fang／Li–Pan 的任何结论。

## 4. Laurent 展开的分析控制

令 \(C=DB\)，按研究记录的箭图约定取森林邻接矩阵 A。对任意标签 g，已证
\[
F_g^B\preceq\prod_iT_i^{d_i[-g_i]_+},
\qquad T_i=1+z_i\prod_jT_j^{A_{ij}}.
\]
这一路使用正上同调维数及 framing/HN 主控，避免把带符号 Euler 特征的取消误当成逐系数正界。对含中心根的 attractor 因子另作了检查。

若 \(\Delta=\max_i\sum_jA_{ij}\)，\(r=\sum_i d_i[-g_i]_+\)，则总次数由 \(T=1+tT^\Delta\) 的 \(T^r\) 主控。对 \(\Delta\ge2,r>0\)，
\[
[t^k]T^r=\frac{r}{\Delta k+r}\binom{\Delta k+r}{k},\quad
R=\frac{(\Delta-1)^{\Delta-1}}{\Delta^\Delta},\quad
\tau=\frac{\Delta}{\Delta-1}.
\]
因此在 \(|z_i|\le R\) 绝对收敛且 \(|F_g|\le\tau^r\)；对 \(\rho<R\)，截去总次数 K 后的尾项不超过
\[
(\rho/R)^{K+1}\tau^r.
\]
还有各向异性的 \(\tau_i\) 证书。它们给出一般可控 Laurent 级数展开与误差；不把绝对收敛误写为有限支撑，也不把主控半径称为最优半径。

## 5. 最小性：有实质推进，但总命题仍开放

目标是：任意实际强正 Hamel 基 \(\mathcal C\)，只要包含全部普通 atlas 的 cluster monomial，其每个基元都应在 theta 基中正展开。不能用“对所有散射室正”的 atomicity 代替这个目标，不能假定 \(\mathcal C\) 可量子化、可范畴化或具有 Lusztig 型正内积。

本轮已证：在无环主系数情形，可将实际基元统一写为
\[
\beta_g=x^gP_g,\qquad P_g\in1+(z)\mathbb N[z],
\]
并建立乘法的统一 return-kernel 递推、解析主控、所有标签共同的复零点自由邻域，以及局部一致极限
\[
p_{\mathcal C}(Q,z)=\lim_{N\to\infty}\frac1N\log P_{\lfloor NQ\rfloor}(z).
\]
该剖面对 Q 齐次，在正实 z 上凸。不是仅证明某个特殊基或某个特殊方向。

还证明了完整的条件桥：如果 \(p_{\mathcal C}=p_\theta\)，或相应有限 log-jet 差异在深盒上一致 o(N)，则 Følner 盒上的整数非负差分、零密度坏边与局部平台可以读取每个有限 theta 展开系数，从而推出所需最小性。这个条件桥的后半段已经闭合。

**仍未证明的是剖面相等，或另行建立足够强的 CM 乘法正分离。** 全部 CM 锚点及两端 monic 首项只控制外围，仍可能留下 imaginary 区域中的内部差异。交换性、差分平坦性、Jacobi 恒等式不自动给出需要的 Poisson 相容性。不能从缩放极限存在推出相邻比值逐点收敛。

正角色／Choquet 路线也有精确限度：正调和函数是正评价的混合，但它们不能分离被其他 Newton 多面体凸包包住的内部 theta 项；weighted AM–GM 给出全局正函数不等式，退化极限仍保留。固定非退化 Green 核另有 Harnack 阻断。可能有用的接口必须保留有限乘法步数和移动支撑边界上的系数信息，不能先取把信息压缩为正评价的 Martin 极限。这里尚无一般证明。

## 6. 查新结论：哪些是旧机制，哪些是候选增量

| 文献 | 经核实的相关内容 | 本轮的区别或使用方式 |
|---|---|---|
| GHKK, 1411.1394v2 | theta、正散射、EGM／large cluster complex 下的有限性与基 | 全部采用为基础；不把 theta 构造或已知 reddening 有限性称为新 |
| CMMM, 2505.09585v2，2026-05-21 | 赋值独立、Newton 顶点 monicity、双方有限 theta reciprocity | 必须逐项满足 finite-value 假设；新候选是固定 H_i 判据和边界尖锐盒 |
| CMN, 1912.13052v2 | broken-line convexity、平衡折线与时间缩放 | 射影反转的旧几何接口；不声称这个操作首次出现 |
| Mandel, 1503.06183v5；Leung–Ma–Young, 1902.05765v2 | marked trees、square-zero 模块和 theta 识别 | 一星机制有旧来源；一般方块矩阵系数式及有限呈示后果尚未查到直接陈述 |
| Fei, 1911.10513v6 | generic Newton 多面体、表示论配对；Remark 6.10 先假设 Jacobi 有限且 theta Laurent | 不可借其假设证明本轮的任意标签有限性；其 generic/triangular/theta Newton 一致性仍应按原文层级使用 |
| Fei, 2610.09868v2；2309.08326v4 | 2026 版本的有限 jet／泛表示等接口 | 强审后仅用原文实际证明内容；finite-jet openness 是旧机制，不重报 |
| Qin, 1902.09507v4，JEMS 2024 | injective-reachable 的基与 pointed／bipointed 分类 | 已知有限性及形状约束；没有自动给任意强正基的内部系数正性 |
| Reading–Stella, 2603.19391v4／SIGMA 2026,109 | mutation、dominance、small canonical algebra 的 theta 结构 | 允许 formal theta，不覆盖本轮基本 H_i 判据 |
| Tang, Hexagon 2611.00015v1 | 有限记录、Baire、正权传输、多面体有限性接口 | 本轮的明确旧输入；仅逐阶使用需要的初等部分 |
| Tang, Hexagon 2610.00201v3 | mutation-word 证书、特殊 Markov 附点公式 | 已知一星特例必须注明；不覆盖一般混合符号方块恒等式 |
| Li Fang／Li–Pan 原文及修改材料 | 用户指出严重错误风险 | 仅保留独立构造多面体的目标，不使用其任何结论，不称为直接改进 |

2026 文献逐项保留版本、有效接口、假设、未覆盖之处及未取用原因。无法取得或未完成正文核验的材料不进入证明输入。完整检索和失败路线都保留在研究记录中。

## 7. 实际计算与证明的分工

计算插件实际执行了跨秩、跨对称化系数的大批量检查，并保留代码及输出：

- 512 个斜对称箭图，秩 3–16，每个 10 次变异：5,120 次 \(G^TC=I\) 检查；35,840 次支撑界、35,840 次正性、33,768 次森林界检查；4,275 个非平凡 jet；未报告失败。

- 448 个斜可对称样本，\(d_i\in\{1,2,3,4,6,12\}\)，秩 3–16：4,480 次 \(G^TDC=D\) 检查；31,360 次支撑界、31,360 次正性、28,238 次森林界检查；3,550 个非平凡 jet；未报告失败。

- 4,658 组有理中心墙记录，秩 2–16、至多 7 次折弯：53,693 个射影反转／动量恒等式检查，未报告失败。它们只检查运动学恒等式，不把随机记录当成实际散射图中的折线。

- 代码曾有空列表 Total 被当作标量而留下未计算 Dot 的错误；保留失败版本及修正，未把这些异常计成数学反例。

这些计算用于发现符号、方向、jet 和候选机制错误；一般性结论仍由证明承担。没有以堆积特殊例子替代主目标。

## 8. 结论与后续真正难点

目前最有价值的候选新结果是一般有限性充要判据、边界尖锐盒、一星系数式与有限呈示证书；它们已经把 Laurent 支撑控制、多面体识别和实际有限截断连接起来。

尚需继续解决的主问题是任意强正 Hamel 基的 theta 最小性：应证明其乘法极限剖面与 theta 一致，或直接构造能检测内部有限 theta 系数的正乘法核。另一个算法问题是现有 LP／呈示证书是否能扩展到覆盖整个有限标签域。不能以当前有限证书覆盖一些标签代替这一一般停机问题。

完整研究记录保留中途判断及后续修正；同一问题以最后一次完整证明或纠错为准。最终包不复制下载文献全文，以减少体积；提供精确文献标识与公开链接。

## 最后补充与完整研究记录

128 组秩 3–20 的精确 LP 与 n+1 轮递推比较，75 组可行、53 组不可行；另核 75 次正支撑无环及呈示方向，最大有限树权 21,623，未报告失败。最小性条件桥已完成一次新的独立逐项审查，仍明确保留上游剖面相等为条件。

[完整证明、计算代码、文献审核与失败路线](https://chatgpt.com/space/page_18f50d2b68588191aa098db20dac4e25)。总 ZIP 下载入口置于本页顶部。
