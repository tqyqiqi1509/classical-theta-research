# A finite symmetric-group model for effective coefficient rays

2026-11-13. A direct consequence of the actual active-copy construction in
STRUCTURE_RAY_POSITIVE_COPIES.md. This is a representation-theoretic
refinement of that construction, not a separate construction of theta
functions and not a solution of the mutable-label cycle-cancellation problem.

Fix a root target p, the input rays and the explicit starting integer N0
from that theorem. The same argument applies to a single theta coefficient
at any prescribed finite scattering endpoint. All auxiliary wall paths and
finite positive wall alphabets are fixed once. Let d=|p|.

## 1. The actual functor of finite color sets

For any finite set A, define W_p(A) by the positive transport recipe with
one extra group of |nu_a dot g_i| slots, at each relevant wall of input i,
for every color in A. Keep the fixed base slots, local-star decoration,
and the complete target-p history. Groups are indexed by colors; within a
group the slots have their fixed order. No ordering of the colors is needed
for this definition because a single wall factor is a commutative product.

An injection A→B relabels the groups and inserts only empty groups at colors
outside the image. Every earlier root increment is unchanged, so every
later base-slot count, relevance decision, and wall alphabet is unchanged.
This defines an injective map W_p(A)→W_p(B), functorial under composition.
In particular S_k acts on W_p([k]) by literal permutation of copy colors.

The action leaves the base decorations unchanged. It permutes groups
simultaneously at every wall and in every input, never independently at
different walls. Its cardinality is

    |W_p([k])| = c_p(N0+k).

The support of a history is its set of active colors. It is uniquely
determined, and has size at most d. Thus every object is generated on a
set of at most d colors, with an exact, rather than merely eventual,
decomposition after the stated shift.

## 2. Induced finite-set decomposition

Let V_(p,j)⊆W_p([j]) be the subset using every color. It is an actual
S_j-set. For every k≥0 there is a natural equivariant bijection

    W_p([k]) = disjoint_union_(0≤j≤d)
                  Inj([j],[k]) ×_(S_j) V_(p,j).                 (1)

The map inserts the active history on the image of the injection and uses
empty groups elsewhere. Conversely take the uniquely determined active
subset. Choosing any labeling of that subset gives a pair on the right,
and different labelings give precisely its S_j-equivalence class. This
proves (1) without selecting objects by a known coefficient cardinality.

After linearization over any field, this gives an explicitly induced
FI-module. Over characteristic zero, its degree is at most d. General
facts about induced FI-sets and representation stability are established
theory; the cluster-specific point is the effective construction and its
bound N0,d for these theta coefficient families.

## 3. All stabilizers are Young subgroups

For one complete history, the profile of a color records, at every wall
of every input, the full ordered tuple of decorations in that color's slots.
Every wall alphabet and the ordered base decorations remain part of the
history. Two colors can be interchanged while fixing the object exactly
when their profiles are identical. Therefore

    Stab_(S_j)(v) = product_(profiles τ) S_(m_τ),               (2)

where m_τ is the number of colors with profile τ. The stabilizer in S_k
also has the factor S_(k−j) permuting unused colors. These are literal
Young subgroups on the color classes, not just abstractly conjugate groups
introduced to fit a character.

Let O_(p,j) be the actual orbit set V_(p,j)/S_j, and let α(O) be the
partition of j given by the multiplicities of the profiles in an orbit.
The ungraded Frobenius characteristic is consequently

    ch C[W_p([k])]
      = sum_(j≤min(d,k)) sum_(O∈O_(p,j)) h_(k−j) h_(α(O)).     (3)

Here h_α denotes the product of complete symmetric functions, and h_0=1.
Thus the lift is explicitly h-positive, and in particular Schur-positive.
This statement does not assert Schur positivity for the intrinsic
complete-symmetric theta elements studied elsewhere in this run; that
different, stronger assertion is false. The group here permutes the newly
introduced large-label copy colors at a fixed coefficient window.

## 4. A positive character polynomial and actual fixed sets

Let X_r(σ) count r-cycles of σ∈S_k. For a partition λ of j write
m_r(λ) for its number of r-parts. Then (1) gives

    Tr(σ | C[W_p([k])])
      = sum_(j≤d) sum_(λ⊢j)
           |V_(p,j)^(σ_λ)| product_(r≥1) binom(X_r(σ),m_r(λ)). (4)

Indeed, a σ-fixed history has a σ-stable active set. Choose exactly
m_r(λ) of the r-cycles for each r; the restriction to that set has type λ,
and the remaining choice is an actually fixed full-support history.
Every coefficient in (4) is a nonnegative integer count. The weighted
degree of this character polynomial is at most d, with weight r on X_r.

There is also a direct fixed-history algorithm. Along a permutation cycle
of length r, all copy groups must carry the same profile. A nonempty
decoration of root weight a then consumes total weight ra. Its original
decoration is retained once; the base exponent is computed from the full
accumulated weight, including r. Running the finite history recursion with
these cycle blocks calculates (4) without enumerating all k colors.

## 5. Scope and novelty

The construction depends on the fixed endpoint path, wall alphabets, and
the explicit shift N0. No path-independent or seed-independent permutation
module is asserted. Its dimension is intrinsic, but a comparison of the
actions produced by different positive paths would need additional work.
There is also no claim that the group S_k here is the product of symmetric
groups permuting equal mutable packets in the raw flow-tree formula.
Those are different actions, with different fixed-cycle requirements.

Primary prior comparison:
Eric Ramos, David Speyer, Graham White, *FI-sets with relations*,
arXiv:1804.04238v2; Algebraic Combinatorics 3 (2020), 1079–1098,
https://arxiv.org/abs/1804.04238 and
https://alco.centre-mersenne.org/item/10.5802/alco.128.pdf .
Their induced FI-set framework and eventual orbit decomposition are prior
art. Here (1)–(4) are proved directly from the specific copy histories.
Targeted searches for cluster theta coefficients with FI-sets, FI-modules,
or representation stability did not locate this application; this absence
does not prove priority. The useful new content, if prioritized, belongs
with the effective positive-copy theorem rather than a renamed general
theorem of representation stability.
