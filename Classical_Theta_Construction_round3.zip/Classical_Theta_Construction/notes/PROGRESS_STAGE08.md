# 第八阶段进展：统一渐近与正导数

保存时间：2026-11-13 23:50 UTC 左右。实际研究从 17:09:08 UTC 开始，
九小时终点为次日 02:09:08 UTC。本阶段不是最终结论或提前结束。

## 本阶段完成的主要数学推进

1. **所有标签的共同解析域。** 同一法向上所有折弯的总速度变差，控制了
   总壁幂；再按 primitive normal 分组做正卷积，得到与整数标签无关的
   指数 majorant。首次非平凡折弯还直接给出 `n<=Md²/4` 的必要条件。
   因而在一个共同小域内，`F_(ng)/H_g^n=1+O(exp(-c sqrt n))`，对所有
   整数 g 一致成立。实际大标签极限与所构造的凸体支撑函数在该域相等。
   独立审核与根代理复核均通过。
2. **真实乘法的渐近几何。** principal 根度零的未移位 theta 分量，其
   概率按支撑函数的次可加缺陷指数衰减；缺陷为零恰对应同一闭法锥。
   同锥时有定量 total variation 卷积近似。B 有核时仍严格区分 frozen
   根度，未把 mutable 标签碰撞错误合并。
3. **统计与 Newton 接口。** 复杂邻域上的 unit-prefactor 估计给出均值、
   协方差、固定阶累积量和高斯极限。另证协方差核等于稳定支持空间的
   正交补，在整个小正域内不变。该支持空间也等于负因子对数的根空间。
   若 F_g 有限，渐近重心属于 `Newt(F_g)∩V_g` 在 V_g 中的相对内部。
   这些推导已由根代理逐项复核；普通概率工具不列为本轮创新。
4. **theta 正的系数平移与混合除幂。** 通过 source leaf 扩张、一次变异、
   正冻结及系数提取，证明有限 theta 在 `y_i -> y_i+t x_i` 下有非负
   整数 theta 展开。所有混合 `(x_i ∂/∂y_i)` 除幂均正。新的独立审核
   已通过有限版本；形式完成的扩展正在另文补齐。
5. **残余支持约束。** 若 `a_g(r)>0`，令 `h=g+(I+B)r`，则
   `binom(p+r,r)a_g(p+r)>=a_g(r)a_h(p)`，从而
   `r+Supp(F_h)⊂Supp(F_g)`。每个有限支持的坐标极大点满足 `h>=0`。
   这是一条直接联系同一 F_g 的新约束，但尚不足以给一般停止条件。

## 计算与查新

- 变差机制：120,000 个候选输入，595 条精确可接受路径，1,461 个法向
  预算检查；Wolfram 独立重建 84 条路径、204 个预算，均通过。
- 根代理混合导数检查：400 个秩 2–4 斜对称化输入，3,200 项精确比较。
  Wolfram 独立实现另外验证 800 项系数比较及 90 个叶扩张变异矩阵。
  原始分支另有大规模导子展开探测。计算只验证一般机制，不替代证明。
- Qin 的冻结商、正移位消除支持和局部化是既有结果；不把这些本身算新。
  Mandel 的系数检测必须使用 scattering atlas。Fei v4 的 theta
  BK-biperfectness 在正文仍为猜想，未被当作定理。
- 2026 Chen–Huang–Sun 论文 Lemma 2.20 的坐标对数凹到联合对数凹等价
  有明确反例；根代理已在出版社正文核实。其 Remark 2.21 限定后文使用
  坐标定义，故不据此否定整篇论文的坐标版定理。该文未作为本轮前提。

## 仍在攻的主缺口

一般 regular theta 标签的无外部支持界有限输出；真正高秩 Dyck/greedy
局部对象规则；完整支持空间与稳定支持空间的识别。简单 vacuum firing
图已经显示不能覆盖全部支持，必须保留正导子展开的非零 frozen 项。
theta 的最小强正性和三角基展开正性尚未证明。下一步继续这些一般机制。

## 阅读入口

- `agents/ray_pressure_mechanism/UNIFORM_SELF_ENDPOINT_MAJORANT.md`
- `agents/ray_pressure_mechanism/MULTIPLICATION_ENTROPY_AND_FAN.md`
- `agents/uniform_consequences_fresh/COVARIANCE_KERNEL_RIGIDITY.md`
- `agents/uniform_consequences_fresh/NEGATIVE_FACTOR_ROOT_SPAN.md`
- `agents/support_accessibility_fresh/FREEZING_POSITIVE_SHEAR_DRAFT.md`
- `agents/positive_shear_fresh_review/INDEPENDENT_POSITIVE_SHEAR_REVIEW.md`
- `agents/support_accessibility_fresh/DERIVATIVE_RESIDUAL_SUPPORT.md`

本包保留各阶段推导和失败路线的时间顺序记录。旧阶段的 OPEN 状态是当时
状态；以上文字说明本阶段已闭合的部分。新颖性判断始终是与已读文献的
具体比较，不是穷尽文献后的优先权保证。
