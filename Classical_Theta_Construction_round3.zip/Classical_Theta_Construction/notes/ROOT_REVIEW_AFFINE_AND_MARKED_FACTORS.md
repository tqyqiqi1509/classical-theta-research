# Root review: affine prefactors and separated marked factors

2026-11-14, 00:30 UTC. These are mathematical reviews during the active
nine-hour run, not substitutes for the remaining general construction task.

## Analytic affine rays

Read the complete proof in
`../agents/affine_ray_zero_system/AFFINE_RAY_ANALYTIC_PREFACTOR.md`.
Independently checked the complex-label Lipschitz input against Section 3
of `../agents/analytic_convex_body/ANALYTIC_STABLE_LOG_BODY.md`: the argument
uses complex absolute values and finite piecewise-linear slopes before
positive-real convexity is invoked, so it does hold on the complex ball.

For the finite-degree threshold, skew-symmetry gives
`a^T D B s = a^T D B(s-a)` and hence the bound
`A(h)d + M d^2/4`, with no denominator smaller than one for integral
labels and integral D. The strict integer cutoff is correctly
`ceil(d_*)-1`. The radial Cauchy argument bounds whole homogeneous
components, and introduces no erroneous multiindex factor. Bounded
normalized logarithms give a locally uniform analytic limit and
zero-freeness, rather than merely pointwise limits of positive functions.
The growing-offset error has the stated exponent
`min(1/2,1-alpha)`; fixed-offset cumulants follow by local Cauchy estimates.

The formal affine identity and the local-star construction were already
available and are explicitly not claimed as new. The increment is the
common analytic domain, identified prefactor, and effective full-tail
control uniform in the integral first direction.

Read `LOCAL_STAR_INHERITANCE_AND_TWO_SCALES.md` completely. At finite root
order, a generic crossing germ in a true local star is a crossing germ
near the original point, with exactly the same combined wall function.
Thus the uniform wall bound is inherited without multiplying unrelated
pieces of a hyperplane. The crossing-variation estimate, positive ambient
grading and packet reconstruction use no new cluster presentation.
The directional derivative follows from coefficient stabilization and
the complex Lipschitz bound. The two-scale exponent is
`min(alpha/2,1-alpha)` after combining the affine error and the local ray
error. No ordinary second derivative across a wall is inferred.

Result: PASS with the explicit uniform-domain restrictions. This review
does not claim a global positive-torus asymptotic or Laurent finiteness.

Read the complete `ANALYTIC_LOCALIZATION_OF_MULTIPLICATION.md` and checked
the old structure-constant stabilization against Section 5 of
`../agents/stable_adversarial/TRANSVERSE_RAY_THEOREM.md`. The old three
thresholds do cover every output because its remaining root box is
translated by q; the numerator is indexed by q+s in the original box.
For the analytic comparison the new proof separately checks the stronger
whole-degree threshold for every varying output label h+k+Bq.

Tonelli is applicable to both positive formal products on the common
analytic domain. The limiting tail is bounded using the local product at
2W, with no estimate that grows with the output label. The low-degree
relative errors are summed against a probability measure, so no spurious
root-count factor is needed. The elementary total-variation inequality
then controls the full law. Result: PASS, uniformly in integral g for
fixed offsets and on the stated small positive domain. This is a new
quantitative consequence, whereas the local-star algebra itself is old.

## Separated marked coefficient factor

Read all sections of
`../agents/support_accessibility_fresh/SEPARATED_MARKED_Q_FACTOR.md`.
The marked coefficient uses the initial positive endpoint, not the
coefficient-detector endpoint for a derivative branch. Its length is
`binom(p+r,r) a_g(p+r)`. The inner/outer polynomial equations correctly
produce the label `h=g+(I+B)r`; the extra `r` comes from the leaf factor.
The exact inner identity is `P_i=-c_i/S_i` on the inner factor. Individual
root matching, which could fail at equal valuations, is never used.

The outer-origin issue at `h_i=0` is real. Generic bounded polynomial
target perturbations remove that issue without saturating an extra
coordinate or a same-color discriminant. Outer Artin factors are retained
through powers of their maximal ideals, rather than being reduced to
their support. On the separated domain the inner window and outer
displacement bounds put all generators strictly inside their affinoid
bounds. The monic factorization chart is regular, and the correct number
of remainder equations plus finiteness gives a complete intersection.
This supplies finite flatness of the unit homotopy.

Two details requested during review have been added: compressed inner
families are finite locally free by the characteristic-zero Young
projector and the relative confluent-remainder identification; and the
selected isolated factor descends to finite algebraic data before the
two-scale valuation is replaced by a sufficiently separated single
weight. No substitution into an arbitrary infinite Hensel series is used.

Saturated lattice intersection gives an actual module injection after
specialization. It gives neither a canonical tensor-product isomorphism
nor an original-fiber idempotent. The resulting product-length lower
bound was already implied by positive derivative branching. The new
content is its realization by a separated model factor and closure.

Result: PASS subject to the already reviewed global Q and finite-flat
coefficient-family theorems. This is an algebraic-geometric realization;
it is not yet a pure nonnegative enumeration by elementary markings.
