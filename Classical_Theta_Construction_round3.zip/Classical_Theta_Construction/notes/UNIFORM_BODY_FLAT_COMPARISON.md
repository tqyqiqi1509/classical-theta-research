# Uniform stretched-exponential comparison of the two theta bodies

2026-11-13. Root derivation, submitted for independent review.

This is a consequence of the analytic stable-log body, the actual local scaling pairing, and the fixed-integral-label flat estimate. It addresses a genuine uniformity gap: a bound with a constant depending on one integral label does not by itself control a whole convex body or all real labels.

## 1. Inputs and explicit constants

Fix a classical integral exchange matrix B of size r, a positive integral diagonal symmetrizer D, and a strictly positive vector v. Write

    z=epsilon v, S=sum_i v_i,
    C=max(1,max_ij |B_ij|), M=max_ij |D_i B_ij|, M'=max(1,M).

Let q_* and K be the one-segment analytic path constants. Set

    R_0=q_* /(2 e C S),
    rho_0=min(R_0/2,1/(4 C S)),
    A_0=max(1,2S,2K/R_0),
    alpha=log 2,
    c_0=alpha^2/(12 A_0 M'),
    H=r! (max_i D_i)^(r-1).

The transport coefficients U_i(g;s v) are analytic for |s|<=R_0 and uniformly bounded by K for every real label. Their degree-N truncations satisfy

    |L_(epsilon v)(g)-L_N(g;epsilon v)|
       <= ||g||_1 eta_N(epsilon),
    eta_N(epsilon)=K (epsilon/R_0)^(N+1)/(1-epsilon/R_0).

Both L_z and Phi_z are finite continuous sublinear functions. Their bodies are denoted K_z^tr and K_z^sc. The established lower comparison says K_z^tr subseteq K_z^sc.

For a nonzero integral u, the fixed-label theorem has A_u<=A_0||u||_1. It therefore gives the safe normalized estimate

    0 <= [Phi_(epsilon v)(u)-L_(epsilon v)(u)]/||u||_1
      <= 3 exp(-c_0/(epsilon ||u||_1)),                  (1.1)

provided epsilon<=rho_0/2 and epsilon||u||_1<=c_0/alpha. Dropping the factor 1/||u||_1 in front is safe because a nonzero integral vector has norm at least one.

## 2. A finite arrangement with bounded integral rays

Take the hyperplanes

    (Da) dot g=0,  a in N^r, 0<|a|<=N,

and adjoin every coordinate hyperplane. Every closed full-dimensional arrangement cone is pointed and lies in one closed orthant. The finite stable logarithm L_N is linear on each such cone, including its closure.

Every extreme ray has a nonzero primitive integral generator u satisfying

    ||u||_1 <= H N^(r-1).                              (2.1)

Indeed a one-dimensional extreme ray is the common kernel of r-1 independent integral hyperplane normals. The coordinate normals and the vectors Da have entries at most D_max N in absolute value. A vector of signed maximal minors generates the kernel; each coordinate is at most (r-1)! (D_max N)^(r-1). Passing to the primitive generator can only reduce the norm. For r=1 the empty-minor convention gives the same bound.

For any g in such a cone, choose a nonnegative conic decomposition

    g=sum_j t_j u_j.

Because all u_j lie in the same orthant,

    sum_j t_j ||u_j||_1=||g||_1.                        (2.2)

This equality is why the coordinate hyperplanes were included. A general conic decomposition with cancellations would not supply the required uniform estimate.

## 3. The uniform comparison at a finite cutoff

Subadditivity of Phi and linearity of L_N on the chosen cone imply

    Phi(g)-L(g)
      <= sum_j t_j [Phi(u_j)-L(u_j)]
            +sum_j t_j [L(u_j)-L_N(u_j)]
            +L_N(g)-L(g).

Using (2.2) and the tail estimate gives, for ||g||_1<=1,

    0 <= Phi_(epsilon v)(g)-L_(epsilon v)(g)
      <= 3 exp(-c_0/(H epsilon N^(r-1)))
                   +2 eta_N(epsilon),                 (3.1)

as long as epsilon<=rho_0/2 and H epsilon N^(r-1)<=c_0/alpha. Boundary labels cause no problem: choose any adjacent full-dimensional cone, and use continuity and the same linear restriction of L_N.

The dual-norm support-function characterization of Hausdorff distance now gives the identical bound for

    d_H,infinity(K_(epsilon v)^tr,K_(epsilon v)^sc).

## 4. An optimized explicit stretched-exponential bound

Put

    ell=log(R_0/epsilon),
    x=(c_0/(H epsilon ell))^(1/r),
    N=floor(x).

Assume

    0<epsilon<=rho_0/2,    x>=1.                        (4.1)

These are explicit conditions and hold for all sufficiently small epsilon. In particular ell>=log 4>alpha. Since N<=x,

    c_0/(H epsilon N^(r-1)) >= x ell >= alpha,

so the integral-label threshold in (3.1) is automatically satisfied. Also N+1>x and epsilon/R_0<=1/4. Consequently

    2 eta_N(epsilon) <=4K exp(-x ell).

Thus

\[
\boxed{
\begin{aligned}
0&\leq \Phi_{\epsilon v}(g)-L_{\epsilon v}(g)
 \leq \|g\|_1(3+4K)\exp\!\left[-
 \left(\frac{c_0}{H}\right)^{1/r}
 \epsilon^{-1/r}\bigl(\log(R_0/\epsilon)\bigr)^{(r-1)/r}
 \right],\\
d_{H,\infty}(K_{\epsilon v}^{\mathrm{tr}},K_{\epsilon v}^{\mathrm{sc}})
&\leq (3+4K)\exp\!\left[-
 \left(\frac{c_0}{H}\right)^{1/r}
 \epsilon^{-1/r}\bigl(\log(R_0/\epsilon)\bigr)^{(r-1)/r}
 \right].
\end{aligned}
}                                                        \tag{4.2}
\]

The first estimate now holds simultaneously for **every real label**. In particular the two bodies are closer than every algebraic power of epsilon along the fixed positive coefficient ray.

An elementary sufficient condition for x>=1 is epsilon<=c_0^2/(H^2 R_0), since sqrt(t) log(1/t)<=2/e<1 on 0<t<=1. This conservative condition may be used instead of solving (4.1).

## 5. Consequences and limits

The finite-theta-data polytope Q_N(z) from the analytic-body theorem already approximates K_z^tr with error eta_N. Combining that approximation with (3.1) or (4.2) gives a certified uniform approximation of the **actual label-scaling body** near the coefficient-zero boundary. It uses a finite coefficient calculation and explicit error terms; it does not exchange an unbounded label limit with an infinite coefficient sum.

The degree-one approximation is the concrete box

    Q_1(z)=product_i [-z_i,0],

because the degree-one stable logarithm is sum_i [-g_i]_+ z_i. Thus the full transport body has this box as its first-order shape, with O(epsilon^2) Hausdorff error along z=epsilon v. The scaling body has the same first-order shape, and in fact differs from the transport body by the much smaller bound (4.2).

Neither an exact equality K^tr=K^sc nor a complete identification of the scaling body's normal fan follows from an arbitrarily flat estimate. Likewise this result does not establish finite Laurent support. The new content here is the uniform passage from integral-label asymptotics to real-label convex geometry with an effective error.

No Li--Pan statement is an input. The historical scaling-pairing idea belongs to Fock--Goncharov; the known convex-support-function and minor bounds are ordinary tools, not separate novelty claims.
