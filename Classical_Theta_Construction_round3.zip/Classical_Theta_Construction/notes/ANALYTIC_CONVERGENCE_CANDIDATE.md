# Candidate analytic consequence of the global free-orbit model

Status at 2026-11-13 21:36 UTC: proof derived below; novelty and independent review pending. This is not yet promoted as a new theorem.

Let r be the rank, b=max_ij |B_ij|, C=max(1,b), and G=max_i |g_i|. For degree p with n=sum p_i>0, the independent primitive clone equation has incoming degree

    A_i=[g_i]_+ + sum_j [B_ij]_+ p_j,

and outgoing degree

    E_i=[-g_i]_+ + sum_j [-B_ij]_+ p_j.

A same-color separable Morse perturbation P_i(x) of degree <=p_i-1, added to the primitive rational equation and cleared by its outgoing denominator, gives polynomial rows of total degree

    d_i <= max(A_i, E_i+p_i-1) <= G+C n.

The perturbation is over an algebraic extension of Q((T)); its selected positive factor is finite, reduced, and Young-equivariant. The theta coefficient is its number of free Young orbits. Bezout's bound on the number of isolated affine solutions, even when other components exist, therefore implies

    a_g(p) <= (G+C n)^n / product_i p_i!.

No division of all orbits is asserted: nonfree orbits can only increase the total solution count, so the inequality is valid.

For t_i=|y_i|,

    sum_|p|=n a_g(p) t^p
      <= (G+C n)^n (sum_i t_i)^n/n!
      <= exp(G/C) (e C sum_i t_i)^n.

Consequently every formal classical theta F-series converges absolutely on

    sum_i |y_i| < 1/(e C),

with a domain independent of the label g and of the choice of symmetrizer D. On a smaller closed ball q=e C sum|y_i|<1,

    |F_g(y)| <= 1 + exp(G/C) q/(1-q).

This would be a genuine analytic consequence of the global model, rather than a Laurent-finiteness statement. A convergent series can still have infinite support. The factorial gain comes specifically from free Young orbits; raw Bezout alone gives only a superexponential bound.

## Checks required before use

- Verify that the chosen same-color polynomial perturbation can be both generic for the free-orbit model and of degree <=p_i-1 after clearing denominators. The current assembly proves this by Hermite interpolation.
- Verify the isolated-component version of Bezout, without assuming the whole algebraic system is zero-dimensional.
- Audit literature for existing analytic theta/scattering convergence and explicit uniform domains. Do not claim novelty from this elementary estimate before that comparison.
- The stronger endpoint/multiplication bound should be proved separately if used; finite sums over degree splittings have no hidden negative terms.
