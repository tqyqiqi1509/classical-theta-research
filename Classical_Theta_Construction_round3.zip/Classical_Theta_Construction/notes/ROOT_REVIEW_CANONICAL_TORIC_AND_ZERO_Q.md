# Root review: canonical toric faces and zero-endpoint Q mutation

2026-11-14, 01:40–01:54 UTC. Classical q=1 throughout.

## Canonical toric face map

Read the entire `agents/face_graded_algebra/UNIFORM_TORIC_INITIAL_MAP_AND_MINIMAL_STRUCTURE_CONSTANTS.md`.

Checks: endpoint coordinate theta labels reduce to e_j or zero; thus each coordinate has a single coefficient-one initial monomial. A monomial field isomorphism gives a unimodular full matrix. Perturbing a boundary weight into the endpoint chamber preserves these finitely many unique initial terms. The strict pullback and root matrices give the weighted opposite-pattern G-block. For singular B the invertible square extension is essential: changing the unused root valuations changes the coordinate weight only by a functional annihilating E_0, hence changes none of the initial comparisons for an original cluster variable. The Fujiwara–Gyoda principal-extension identities then determine the frozen block F without cancelling B.

The full principal/spectator split is a lattice isomorphism because ordinary R=C_T(B) is unimodular. Keeping c=R^{-1}a_frozen is essential; mutable labels alone would merge distinct outputs when Q_red is singular. Positive ambient multiplication and independence in this full split prove product-specific lifting of each lower output. There is no argument that every lower finite label has a finite ambient lift; the note correctly does not claim it.

Status: proof accepted relative to the separately proved canonical face theorem and standard primary-source inputs. Novelty: F/C/G identities and abstract freezing multiplication already exist. The explicit canonical original-chart map is the further deduction recorded here.

## Nested faces

Read `ITERATED_FACE_COMPATIBILITY.md` completely. The nonnegative S_U restricted block transforms by the lower C-recurrence; this uses sign coherence and does not assert an arbitrary full-C product identity. Bongartz completion commutativity and the reduced cone identification give S_V=S_U S_rel. Finite lexicographic initial forms give p_V=p_U+S_U p_rel. The weighted shifted-label formulas compose. Status: accepted.

## Zero-endpoint mutation

Read the complete construction before and after the finite-chamber repair, and the full independent `INDEPENDENT_ZERO_ENDPOINT_Q_REVIEW.md`.

The necessary repair was substantive: independent deep windows do not suffice for their union; all deep factors must have one common rank. For fixed degrees there are finitely many collision/flow-tree sign forms, so generic endpoints mu_0+t(M+eta nu) remain in one chamber. Annulus comparisons give the same rank c for all small t. Nested finite Artin domains of the same rank are equal. This proves full positive-core finiteness, including over residue-one coupled-unit homotopies.

Monic preparation depends only on unchanged Q_j because C_kk=0. Hence the complement and the correction unit are genuine functions on the new ambient coefficient domain. Separating perturbations preserve length and make complete separation available on an actual generic finite fiber, without illegally saturating nonedges or same-color discriminants in the original algebra. Monic division defines the reverse quotient before imposing its remainder; the new equation kills that remainder. The resulting old factor is an open-and-closed full Artin factor of the new coupled algebra. Two independently constructed length inequalities prove equality.

Status: mathematical mechanism accepted after the repairs, relative to the independently reviewed generic-window and finite collision-count inputs. Code and historical novelty comparison continue separately. No unconditional completeness of the finite-word support search is claimed.

## Final direct-convexity review and novelty reduction

At 02:00 UTC root read the entire `NOVELTY_REDUCTION_AND_CONVEXITY.md`, after independently reading GHKK8.2,8.14,8.15. The exact C-intertwining identity, the principal-separation formula, the detector active-form argument, and the g-independent recession calculation all check out. The face agent independently reached the same conclusion. The support inequalities and their boundedness constructor are therefore an explicit existing-mechanism consequence; they are no longer presented as a Q-specific new support theorem. A successful word set works for all labels of that matrix, with reusable fixed normals and dual bounds. The full-Artin coefficient-algebra mutation remains a distinct algebraic realization, with its priority comparison still explicitly delimited.
