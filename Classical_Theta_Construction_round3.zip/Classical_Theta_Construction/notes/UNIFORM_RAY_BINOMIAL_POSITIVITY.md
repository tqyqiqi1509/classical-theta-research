# Fixed-matrix ray coefficients have an effective positive binomial expansion

2026-11-13, UTC. Classical cluster algebras, principal coefficients.
This is a new candidate consequence for independent review. It keeps B fixed;
the previous replication theorem changed both B and the label. Its novelty is
still being checked, and the elementary active-color regrouping is not claimed
as a new combinatorial principle.

## Statement

Fix an integral skew-symmetrizable exchange matrix B, a positive integral
symmetrizer D, labels g,h in Z^r, and a finite downward-closed root set J.
Write theta_m=x^m F_m(z), z_i=y_i x^(Be_i), and

    T_J(g;h)=max({0} union
      { |(h+Bs)^T D a| / |g^T D a| :
          s in J, 0<a<=s, g^T D a != 0 }).

Choose any integer n0>T_J(g;h). For every p in J there are actual finite
sets W_(p,j), 0<=j<=|p|, such that for every integer k>=0,

    [z^p]F_((n0+k)g+h) = sum_(j=0)^|p| |W_(p,j)| binom(k,j).       (1)

In particular, every forward difference of every order is nonnegative
throughout this range:

    Delta^j_n [z^p] F_(ng+h) >=0,    n>=n0.                       (2)

The statement allows nonregular formal theta labels and nonzero zero-root
groups. It concerns a prescribed finite root prefix; it does not assert finite
support of the entire theta function.

## 1. The fixed finite positive transport

Factor the incoming total element with respect to lambda_g(a)=g^TDa:

    C=A_- Z_g A_+.

The effective translated-ray theorem gives, for every n>T_J(g;h),

    theta_(ng+h)=A_-(x^(ng) eta_h^g) mod I_J.                     (3)

Here eta_h^g is the theta function of the local star diagram at g, with
nonnegative integral coefficients. Its existence and interpretation as a
local-star theta function are standard; the effective threshold in (3) is the
additional finite statement used here.

Choose a small generic perturbation g+epsilon u, with u strictly positive,
such that every root with lambda_g=0 is positive at this starting point and
all other root signs are unchanged. A generic line in the positive u direction
from this point eventually enters the positive orthant. It crosses precisely
walls with lambda_g(a)<0, each from the negative to the positive side. Its
finite path-ordered product modulo J is A_-. Joints can be avoided by generic
rational choices within the same sign refinement. This uses the signed-factor
classification of the scattering diagram; it is not a choice of an arbitrary
path with possibly inverse positive wall factors.

Keep every crossed wall in this order and its actual positive coefficient
alphabet. For the classical cluster diagram the alphabets can be supplied by
the earlier tight-grading/two-page-tree construction. No alphabet is defined
merely as a set of a prescribed coefficient cardinality.

## 2. Why every local exponent is nonnegative at the stated threshold

Let a be the primitive positive root direction of a crossed wall. Set
delta_a=gcd_i(D_i a_i) and nu_a=Da/delta_a. At an intermediate root state q,
the wall applies its positive function f_a with exponent

    E(n,q)=-nu_a dot (ng+h+Bq)=n A_a+B_(a,q),
    A_a=-nu_a dot g >0.                                          (4)

Both A_a and B_(a,q) are integers. If a nonconstant term at this wall survives
the root truncation, then q+la is in J for some l>=1. Downward closure gives
s=q+a in J and a<=s. Skew symmetry gives

    (h+Bq)^TDa=(h+B(q+a))^TDa.

Thus the definition of T_J(g;h), applied to s=q+a, gives E(n0,q)>=0.
This is the necessary endpoint argument: one must not use a<=q, which may
be false. If no nonconstant term can survive, that wall is irrelevant at this
state, even when its formal untruncated exponent is negative.

## 3. Actual active-copy objects

At each relevant wall, split the E(n0+k,q) ordered slots into:

* E(n0,q) base slots;
* k additional groups, each with A_a ordered slots, with group colors [k].

Choose a term of f_a in each slot. Empty terms have weight zero; nonempty
terms carry actual wall-alphabet objects and their root weights. The choices
update the root state before the next wall. The local-star starting object is
retained unchanged. Since E(n0,q) depends only on the earlier root increments,
it is unchanged by an order-preserving relabeling of the active colors.

Call a color active if at least one of its slots, at any wall, is nonempty.
The same color set [k] is used at all walls; it is not chosen separately at
each wall. Every active color consumes at least one unit of total root degree,
so at target p there are at most |p| active colors.

Define W_(p,j) by running this finite slot process with color set [j] and
requiring every color to be active somewhere. These are concrete bounded
objects independent of k. For any object with k available colors, take the
union S of all active colors and relabel S increasingly by [j]. Conversely,
an increasing j-subset S of [k] relabels a W_(p,j) object and fills all other
colored slots with the empty term. This is a literal inverse pair of maps,
preserving every root increment, local-star object, and wall decoration.
It proves (1), without rank/unrank of theta coefficient sets.

Taking differences of binomial polynomials proves (2), or one can interpret
each difference by marking newly available active colors.

## 4. Consequences with explicit finite bounds

The coefficients in (1) are exactly

    |W_(p,j)|=Delta^j [z^p]F_((n0+k)g+h) evaluated at k=0.

Thus |p|+1 finite theta coefficient evaluations determine the entire ray
polynomial on n>=n0, including a manifestly nonnegative expansion.

Its support has an explicit stabilization point. For d=|p|,

    [z^p]F_(ng+h) is eventually nonzero
      iff [z^p]F_((n0+d)g+h)>0.                                 (5)

If it is nonzero there, it is positive for every n>=n0+d. Indeed every
binom(d,j), 0<=j<=d, is positive, so the value in (5) sees every possible
nonzero active-color coefficient. The first occurrence after n0 is exactly
the least j with W_(p,j) nonempty.

For h=0 and J contained in |p|<=d, the uniform choice

    n0=floor(M d^2/4)+1,   M=max_(i,j)|D_i B_ij|,

works for every integral g. The quadratic bound follows by replacing Bs
with B(s-a) in the numerator and using |a|(|s|-|a|)<=d^2/4. This is a bound
for a finite coefficient window, not for the full Laurent support.

## 5. Exact computation and remaining review

`computation/ray_absolute_monotonicity.py` tests 160 fixed matrices and shifted
rays in ranks 2–5, including nonscalar symmetrizers. At the exact threshold it
checks 24,570 integer forward differences and 3,430 degree cutoffs. Every
difference is nonnegative and every excessive-order difference is zero.
This is a verification of the stated mechanism, not a proof by examples.

The finite positive path and local-star action have been separately checked
by the stable-Hall agent. A fresh adversarial review is still requested.
Novelty comparisons must include Qin freezing stabilization, fixed-stratum
polynomiality, and the earlier simultaneous-matrix replication theorem.
