# A binomial coefficient bound and a graph-dependent analytic domain

2026-11-13, updated 22:59 UTC. Classical skew-symmetric and skew-symmetrizable data.
Status: root proof with two independent PASS reviews. This note uses the proved
finite Q-remainder model; it does not multiply one-color factorization ranks.

## 1. Statement

Let `B` be the exchange matrix, `g` an integral theta label, and `p>=0` a
coefficient degree. An endpoint is chosen rank-generic and cut-generic; its
coordinates may have either sign. Write

\[
 A_i=[g_i]_++\sum_j[B_{ij}]_+p_j,\qquad
 E_i=[-g_i]_++\sum_j[-B_{ij}]_+p_j,\qquad d_i=\max(A_i,E_i).
\]

Then the endpoint coefficient satisfies

\[
 \boxed{0\le a_{g,U}(p)\le\prod_i\binom{d_i}{p_i}.}                 \tag{1}
\]

The convention is `binom(d,p)=0` for `p>d`, with inactive factors equal to
one. In particular a necessary support condition is `p_i<=d_i` for every
active color. This is weaker than the unproved positive-endpoint conjecture
with `E_i` in place of `d_i`; the latter fails for signed endpoints.

## 2. The finite Q model and weighted degrees

Put
\[
 Q_i(z)=z^{p_i}+\sum_{l=1}^{p_i}c_{i,l}z^{p_i-l}.
\]
The polynomial rows over `K=overline(Q((T)))` are
\[
 F_i(z)=T^{[a_i]_+}z^{[g_i]_+}\prod_jQ_j(z)^{[B_{ij}]_+}
 -\epsilon_iT^{[-a_i]_+}z^{[-g_i]_+}
                 \prod_jQ_j(z)^{[-B_{ij}]_+},
 \quad \epsilon_i=(-1)^{E_i}.
\]
All relevant `a_i` are nonzero. Thus the leading coefficient of `F_i` is a
nonzero field constant, and `deg_z F_i=d_i`, for every choice of the `c`.
Consequently `Q_i|F_i` is impossible when `p_i>d_i`.

For `p_i<=d_i`, write
\[
 \operatorname{rem}(F_i,Q_i)=\sum_{k=0}^{p_i-1}R_{i,k}(c)z^k.
\]
Give `z` weight one and `c_{i,l}` weight `l`. The monic polynomial `Q_i` is
weighted homogeneous of degree `p_i`. The two terms of `F_i` are weighted
homogeneous of degrees `A_i` and `E_i`, respectively. Monic division by a
weighted homogeneous polynomial preserves weighted degree at every step.
It follows that
\[
 \deg_w R_{i,k}\le d_i-k.                                  \tag{2}
\]
There are exactly `n=sum_i p_i` equations in `n` coefficient variables.

The previously proved Q theorem identifies `a_{g,U}(p)` with the length of
the selected positive factor of these equations. Here is a completely
algebraic verification that this is an isolated full factor, not an
arbitrary Artin quotient. Set
\[
 C=\mathbb Q[T,c]/(J:(TS)^\infty),\qquad A=\widehat C^{\,(T)}.
\]
The Q theorem gives finite-dimensional `C/TC` and T-torsion-freeness.
Lifts of a basis of `C/TC` generate A over `Q[[T]]` by successive complete
reduction; A is therefore finite free over this DVR. The Noetherian ring
`C'=Q[[T]] tensor_(Q[T]) C` has completion A, so `C'->A` is flat. It is
also surjective: the basis lifts and their arbitrary `Q[[T]]`-linear
combinations already belong to C'. Its finitely generated kernel is
therefore an idempotent ideal, and A is a direct factor of C'. After
inverting T, the saturated boundary product S is a unit on this finite
factor: multiplication by S remains injective after flat completion and
is thus bijective over the finite-dimensional generic algebra. Hence
`A[1/T]` is a full Artin direct factor of `K[c,S^-1]/J`. Since S is nonzero
at its points, these are exactly the local rings of the original
unsaturated remainder system. All nonreduced multiplicities are retained.
The entire polynomial zero scheme need not be finite.

## 3. Weighted Bezout, preserving all scheme multiplicities

The following elementary device supplies the needed weighted bound.
For polynomial equations `f_j(c)` with variable weights `w_l>=1` and
weighted degree bounds `delta_j`, make the substitution
\[
 c_l=u_l^{w_l}.
\]
The map of affine spaces is finite flat of rank `prod_l w_l`: the polynomial
ring upstairs is free over the downstairs polynomial ring, with basis
`prod u_l^{e_l}`, `0<=e_l<w_l`. Each pulled-back equation has ordinary
total degree at most `delta_j`. A selected isolated scheme of length `L`
pulls back to an isolated scheme of length exactly `L prod_l w_l`, even
when some coordinates vanish and even when the scheme is nonreduced.

The isolated-component affine Bezout inequality, including multiplicities,
therefore gives
\[
 L\prod_lw_l\le\prod_j\delta_j.                         \tag{3}
\]
One may prove the form of Bezout in (3) by a generic perturbation to a
projective complete intersection: the sum of the local isolated
intersection multiplicities cannot exceed the full intersection degree.
The equations form a local complete intersection at an isolated point,
since a height-`n` ideal with `n` generators in the regular ambient local
ring is a parameter ideal. No reduced-point assumption is used.

Apply (3) to (2). The covering rank is `prod_i p_i!`, whereas the product
of row bounds is
\[
 \prod_i\prod_{k=0}^{p_i-1}(d_i-k).
\]
Division gives (1). In particular this proof does not depend on the
polynomial-row Morse deformation originally considered for this bound.
The cover is a counting proof, not an asserted theta-preserving mutation.

## 4. A scalar analytic radius determined by the exchange graph

Let `C=|B|` entrywise, `G=||g||_infinity`, and
\[
 \kappa_B=\max\{t^TCt:t_i\ge0,\ \sum_i t_i=1\}.             \tag{4}
\]
The diagonal of `C` is zero. Symmetrizability is unnecessary for the
elementary optimization (4); only its symmetric part contributes.
For `n=|p|>0`, put `t_i=p_i/n`. From (1), the factorial estimate for
binomial coefficients, and weighted AM--GM,
\[
\begin{aligned}
 a_{g,U}(p)
 &\le\frac{\prod_i(G+\sum_jC_{ij}p_j)^{p_i}}{\prod_i p_i!}\\
 &\le\frac{(G+n\,t^TCt)^n}{\prod_i p_i!}
 \le\frac{(G+\kappa_B n)^n}{\prod_i p_i!}.                 \tag{5}
\end{aligned}
\]
Zero bases cause no difficulty: if an active factor is zero the entire
coefficient is zero; otherwise apply AM--GM to the positive active factors.

Writing `s=sum |y_i|`, the multinomial theorem now gives
\[
 \sum_p a_{g,U}(p)|y|^p
 \le\sum_{n\ge0}\frac{(G+\kappa_B n)^n}{n!}s^n.           \tag{6}
\]
Thus every formal theta F-series in every generic endpoint converges
absolutely and locally uniformly on the common domain
\[
 \boxed{\sum_i|y_i|<\frac1{e\kappa_B}}                    \tag{7}
\]
when `B!=0`. For `B=0`, `kappa_B=0` and (6) is the entire majorant `exp(Gs)`.
This is a common domain, not a claim of optimal radius or finite support.

The scalar tree identity, valid for any real `kappa>=0`, states that if
`t=s exp(kappa t)` is its small nonnegative solution, the right side of
(6) equals
\[
 \frac{\exp(Gt)}{1-\kappa_Bt}.                            \tag{8}
\]
This follows either by Lagrange inversion or by rooted-tree and cycle
expansion. It is an old generating-function identity used for a new bound.

## 5. Clique-number corollary

Let `Gamma` be the undirected support graph of `B`, let `omega` be its
clique number, and put `b=max |B_ij|`. For nonzero `B`, `omega>=2`.
Since `C<=b A_Gamma` entrywise, the classical Motzkin--Straus theorem gives
\[
 \kappa_B\le b\left(1-\frac1\omega\right).                \tag{9}
\]
Here the adjacency quadratic form counts each undirected edge twice.
The original paper's Theorem 1 uses a sum over unordered edges and hence
has the extra factor `1/2`; (9) uses the doubled adjacency form correctly.
Consequently
\[
 \sum_i|y_i|<\frac1{e b(1-1/\omega)}                     \tag{10}
\]
is an explicit common domain. For triangle-free support, `omega=2`, giving
radius `2/(e b)`. This includes arbitrary cyclic and valued matrices with
triangle-free support, not just rank two or acyclic seeds.

Primary source checked: T. S. Motzkin and E. G. Straus, *Maxima for Graphs
and a New Proof of a Theorem of Turan*, Canadian Journal of Mathematics 17
(1965), 533--540, Theorem 1, DOI 10.4153/CJM-1965-053-6.
The graph optimization theorem itself is not claimed to be new.

## 6. An anisotropic combinatorial majorant without self-color edges

The first bound in (5) has a standard functional-digraph generating series.
Let `G_i=|g_i|` and let the formal tree series solve
\[
 T_j=y_j\exp\left(\sum_i C_{ij}T_i\right).
\]
Then
\[
 \sum_{p\ge0}\frac{\prod_i(G_i+\sum_jC_{ij}p_j)^{p_i}}
                         {\prod_i p_i!}y^p
 =\frac{\exp(\sum_iG_iT_i)}{\det(I-\operatorname{diag}(T)C)}.       \tag{11}
\]
A colored vertex chooses one of `G_i` terminals or an edge to another
color. The zero diagonal of `C` forbids every same-color arrow. Components
are terminal-rooted trees or directed cycles of length at least two with
incoming rooted trees. This proves (11) by the exponential formula and
explains its positive coefficients. It is only a majorant, not an exact
new set counted by theta coefficients.

Any positive vector `t` with `rho(diag(t)C)<1` supplies the explicit
anisotropic region
\[
 |y_j|\le t_j\exp(-\sum_iC_{ij}t_i),
\]
on which iteration is bounded by `t` and (11) is finite.

## 7. Novelty and dependencies

The new proposed increment is the binomial bound from the exact cyclic
Q-remainder algebra and its graph-dependent common theta domain. Weighted
Bezout, Motzkin--Straus, and the tree/cycle generating identity are standard
inputs; none are claimed as new. The Q coefficient model and its equality
with theta coefficients remain essential dependencies. This note does not
convert algebra length into an elementary greedy selection rule and does
not produce a finite Laurent stopping algorithm for arbitrary labels.

The exact reviews are
`../agents/q_support_round2/WEIGHTED_Q_BEZOUT_REVIEW.md` and
`../agents/weighted_bezout_review/INDEPENDENT_REVIEW.md`. Both pass the
weighted bound and the isolated-factor bridge. The latter also checks
the graph-density and clique corollaries. Its
`ENTROPY_CONVERGENCE_DOMAIN.md` supplies a larger, logarithmically convex
sufficient domain from the exact binomial entropy function.

Primary isolated/weighted Bezout source checked by root and reviewer:
Pinaki Mondal, *How many zeroes?*, author's introduction, Theorems I.2 and
I.4, with the preceding multiplicity convention,
https://pinakimondal.org/wp-content/uploads/2021/12/p1_to_16.pdf .

Independent computation: 1500 signed/unsigned theta inputs, 24100
coefficients including 9594 nonzero coefficients, obey (1); 628 inputs
have signed endpoints. Separately, 240 symbolic remainder systems
(607 nonzero remainders) verify the weighted-degree/power-cover formula,
and 12 all-repeated-root algebras verify binomial length and ramified
cover multiplicity. The latter 240/607 calculations were independently
recomputed by the Wolfram plugin. These computations test the implementation
of the general argument; the proofs establish its unrestricted statement.
