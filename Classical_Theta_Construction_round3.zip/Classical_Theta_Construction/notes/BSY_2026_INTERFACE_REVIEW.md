# Backman–Santos–Yuen 2026: reviewed interface for the tree route

Read on 2026-11-13 by root. Primary publisher version:
https://link.springer.com/article/10.1007/s00454-026-00834-w
Published 2026-03-18, Discrete & Computational Geometry 75, 969–994.

## What was actually checked

Read Theorem A and its proof chain: generic oriented matroid programs,
Lemma 2.9, Proposition 2.10, Lemma 3.1, Propositions 3.2–3.3,
Lemma 3.4, Theorem 3.6 and the final proof. Read the explanation of
the active-bijection connection and Section 5 on Lawrence triangulations.
The cited general oriented-matroid programming theorem and Santos's
extension/lifting amalgamation lemma were treated as established inputs;
this is not a new review of the oriented-matroid monograph in full.

The principal bijection sends a basis to the orientation determined by
its fundamental circuits and cocircuits, using signatures of a generic
lifting and extension. The proof identifies its inverse as the unique
optimal basis of the associated generic oriented matroid program.
The examined main proof chain has no confirmed substantive error.

## Two local exposition corrections

1. Remark 2.7 illustrates a maximization problem with inequalities
   a_i x<=b_i and c=-sum lambda_i a_i, lambda_i>=0, then displays
   c x<=-sum lambda_i b_i. The displayed implication reverses the
   inequality: the assumptions imply >=. For example a=1,b=0,c=-1,
   feasible x=-1 gives c x=1>0. This concerns the informal LP illustration,
   not the subsequent proof via the standard signed OMP duality theorem.
2. In the proof of Proposition 3.2, the object on support B union {f}
   called a signed cocircuit must be a signed circuit. The proposition
   statement, Lemma 2.2, and the ensuing orthogonality argument make the
   intended correction unambiguous.

Neither correction is being presented as a counterexample to Theorem A.

## Relevance and limits for our theta construction

For representable/cographic configurations, the corresponding geometric
bijection is already in Backman–Baker–Yuen (2019). Section 5 explicitly
attributes the fact that every Lawrence triangulation has exactly one
simplex above each underlying matroid basis to Santos's earlier results.
Thus the unoriented-tree normal form, once the local configuration has
been identified as Lawrence (with any simplex-join factor retained),
must be compared with these existing bijections. We do not claim a new
general Lawrence-triangulation principle.

Remark 3.7 explicitly cautions that an efficient purely combinatorial
inverse remains difficult even for graphs: finding it amounts to solving
the oriented matroid program. Consequently this paper does not itself
supply the missing inverse from arbitrary tight Dyck boundary trees,
nor does it show that nested child boundary covectors are preserved.

Current use: a checked conceptual and algorithmic interface for the
realizable flow/Lawrence stage. No assertion from this source is used to
declare the all-degree theta object associator solved.
