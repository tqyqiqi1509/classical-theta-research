# CMMM 2026 input: finite-span audit and the remaining infinite-span issue

Source: Cheung–Magee–Mandel–Muller, arXiv:2505.09585v2, dated 21 May 2026.
Primary text: https://arxiv.org/html/2505.09585v2 . Local official PDF/text are
in `agents/fei_newton_interface/sources/`.

This note records an actual proof-chain reading for the exact use in the
finite Laurent envelope construction. It does not certify the entire paper.

## The chain used

1. Section 2.1 imposes a strictly convex full principal root cone. With
   principal coefficients the root map is p -> (Bp,p), hence injective,
   even when the mutable matrix is singular. Classical positive cluster
   scattering diagrams satisfy the required positivity hypothesis.
2. Lemma 2.9 proves homogeneous tropical scaling using two separate positive
   constructions: the leading theta summand in a power, and literal scaling
   of broken lines. No Newton saturation or Li–Pan result enters.
3. Lemma 3.1 and Corollary 3.2 relate rational broken-line exponents to
   rescaled integral ones, using that positivity prevents cancellation.
4. Theorem 3.5: a non-taut minimizing bend can be perturbed, with later bend
   maps retained, to decrease the final valuation while keeping a generic
   endpoint. Working first at a finite root cutoff keeps the relevant wall
   incidences fixed. Generic taut bends are extremal and determine the
   backwards path uniquely. The proof does not use monicity or Li–Pan.
5. Theorem 3.7: two finite minima for a generic valuation cannot have the
   same value unless the initial theta labels coincide. A generic valuation
   separates integral final exponents, and backwards tautness then recovers
   the initial label.
6. For a FINITE linear combination of FINITE Laurent theta functions, the
   minimum exists for every valuation. Generic valuations have one
   minimizing theta summand, so it cannot cancel. Continuity of finitely
   many polytope support functions extends equality to every real valuation.
   This proves the finite case of Theorem 3.8 used by the envelope method.

Thus, if a finite pointed upper-cluster candidate is separately known to
have a finite theta expansion and its degree-zero coefficient is nonzero,
pointed triangularity gives a nonzero theta_g summand, and
Newt(theta_g) is contained in Newt(candidate). Negative coefficients in the
candidate do not invalidate this argument. No theorem identifying theta
with a representation character is required.

## Important stronger statement that does not remove the hypothesis

Theorem 3.8 itself permits formal infinite theta sums, provided that the
infimum of the summand valuations is finite. The theorem is therefore
stronger than the finite statement we use. However, the fact that the sum
is a finite Laurent polynomial does NOT establish this finiteness condition
for an unknown infinite theta expansion. Its valuations might have an
unbounded negative tail before cancellation.

Section 2.3, Warning 2.7 explicitly explains why valuations of arbitrary
signed formal series are not ordinary multiplicative valuations in this
situation. Section 3.10 gives upper semicontinuity in the label; it does
not supply the missing uniform lower bound for all summands of such an
expansion. Consequently this reading has NOT removed middle=upper, or a
local finite-theta-span certificate, from the signed-envelope algorithm.

Lemma 2.10 has a separate rational/interior hypothesis for attainment of a
formal infimum. No use of that subtle infinite-series boundary issue is
needed for the finite application: all relevant theta polynomials already
have finite supports.

## Novelty consequences

Theorem 3.8, Newton dilation in Lemma 2.9, local-star limits in Section 2.5,
and the monic-vertex conclusion in Section 3.8 are prior results, not new
theorems of the present investigation. The candidate increment in the
envelope method is the search for an arbitrary signed pointed finite
regular witness when no support bound is supplied. Fei's 2026 minuscule-LP
paper already combines known Newton bounds, divisibility and valuative
independence for recognition; that comparison must remain explicit.

Reading completed by the root during the 18:09–18:29 UTC research cycle.
No defect was found in the finite proof chain used above. Other claims,
including theta reciprocity on infinite loci, are not adopted here.
