# Root independent review of the stable fluctuation space

2026-11-13 23:50 UTC. Root read the complete proofs in
`agents/uniform_consequences_fresh/COVARIANCE_KERNEL_RIGIDITY.md` and
`NEGATIVE_FACTOR_ROOT_SPAN.md`, separately from the author's summary.

Verdict: **PASS** for the stated common-domain assertions.

The mixed-cumulant proof uses only fixed-order moments. Their polynomial
growth follows from the moment-cumulant formula and the complex Cauchy
bounds. The exponentially small variance in a kernel direction makes every
centered moment containing that direction superpolynomially small by
Cauchy–Schwarz. The cumulant partition expansion preserves that smallness.
Thus all mixed derivatives of order at least two vanish. The Euler
derivative, not a logarithmic coordinate at zero, is the holomorphic
quantity used to remove the residual constant. The connected positive
domain justifies analytic continuation.

The support space is rational; finitely many integer normal vectors detect
its complement. The second-moment bound therefore gives an actual
exponentially small off-subspace probability. Positive definiteness on the
remaining subspace and the inverse function theorem justify the relative
interior conclusion for `Newt(F_g) intersect V_g`. Full Newton-span equality
is not required and has not been inferred.

The negative-factor root-span identity follows from the minimal total
degree outside the proposed span. All logarithmic negative-factor roots
pair strictly negatively with g; the linear root action cannot vanish.
No nonlinear product of lower roots can contribute outside their span.
The proof remains valid for infinite formal series, degree by degree, and
does not assume that H itself has nonnegative coefficients. Zero-group
roots, used elsewhere to describe exposed faces, are not confused with
these strictly negative-factor roots.

Root also opened and read the primary publisher text of Chen–Huang–Sun,
DOI 10.1017/nmj.2026.10110, Definition 2.17, Lemma 2.20 and Remark 2.21.
The recorded `a_ij=2^(ij)` counterexample does refute the asserted general
equivalence in Lemma 2.20. The restriction on what this error says about
the later coordinatewise results is correct. No theorem in the new
construction depends on that paper.
