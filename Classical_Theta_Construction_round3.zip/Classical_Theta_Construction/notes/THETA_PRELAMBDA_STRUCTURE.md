# A positive pre-lambda structure from dilation of theta labels

Status: root-derived corollary of the new Gauss/Möbius/complete-symmetric result. The elementary pre-lambda formalism is standard; no novelty claim is made for that formalism itself. Only classical cluster algebras are considered.

## 1. Precise algebra

Work in the integral principal-coefficient middle algebra R with its full theta basis, including the frozen monomial labels. Each element is a finite integer linear combination of regular theta elements. Write R_+ for its nonnegative theta cone. The regular label set is closed under positive integer dilation, an established GHKK input.

For n>=1 define an additive operator

    Psi_n(theta_u)=theta_(n u).

These maps are intrinsic because dilation is well-defined on the integral tropical labels; the piecewise-linear mutation maps are positively homogeneous. They commute and satisfy Psi_m Psi_n=Psi_(mn). They are not asserted to preserve multiplication.

Define

    sigma_T(f)=exp(sum_(n>=1) Psi_n(f) T^n/n).

The new complete-symmetric theta theorem proves sigma_T(theta_u) belongs to 1+T R_+[[T]]. For a finite integer combination f=sum a_u theta_u,

    sigma_T(f)=product_u sigma_T(theta_u)^(a_u).

Integer powers of a unit integral series, including negative powers, are integral. Hence sigma_T(f) belongs to 1+T R[[T]], and

    sigma_T(f+h)=sigma_T(f)sigma_T(h),
    sigma_0(f)=1, sigma_1(f)=f, sigma_T(1)=(1-T)^(-1).

Thus this is a pre-lambda structure in the complete-symmetric convention. Equivalently lambda_T(f)=sigma_(-T)(f)^(-1) is the exterior convention. Its Adams operations, defined by the logarithmic derivative, are exactly Psi_n.

For f in R_+, all coefficients sigma_N(f) lie in R_+, since the product above has only nonnegative powers of series with nonnegative theta coefficients and multiplication in R_+ is positive. This positivity is a substantive consequence of the new complete-symmetric theorem, not a general property of arbitrary pre-lambda structures.

## 2. What this does not prove

This is not claimed to be a special lambda ring. The failure of multiplicativity of Psi is already visible in a rank-one exchange relation x*x'=1+y. The cluster monomials x^n,(x')^n and frozen monomial y^n give

    Psi_n(x*x')=1+y^n,
    Psi_n(x)Psi_n(x')=(1+y)^n.

For n>1 these differ in characteristic zero. Consequently one cannot apply the usual special-lambda plethysm identities without an additional argument. The separate negative third exterior coefficient from SCHUR_BOUNDARY.md shows that exterior/Schur positivity must not be inferred from the complete-symmetric positivity either.

The chart operation psi_n(Z^m)=Z^(nm) used in the Möbius proof and the intrinsic additive operator Psi_n are different. Their coincidence modulo a prime is a congruence, not equality as operations.

## 3. Newton compatibility on the positive cone

For regular g, write H_(N,g)=[T^N]sigma_T(theta_g). The cycle-index formula and theta multiplication positivity give

    theta_(Ng) <=_theta H_(N,g) <=_theta theta_g^N,

where <=_theta means that the difference has a nonnegative integral theta expansion. For the lower bound, each product indexed by a partition of N contains theta_(Ng) with coefficient one, and the cycle-index weights sum to one. For the upper bound, each theta_(kg) <=_theta theta_g^k and the cone is closed under multiplication. Integrality of H makes the resulting differences integral.

It follows in every seed that

    Newt(H_(N,g)) = N Newt(theta_g).

Here the dilation identity Newt(theta_(Ng))=N Newt(theta_g) is already a known consequence of strong positivity and scaled broken lines. It is explicitly Lemma 2.9 of Cheung–Magee–Mandel–Muller, arXiv:2505.09585v2, in valuation form. The root inspected its complete short proof directly; it does not use Li–Pan. We do not advertise Newton dilation as new.

More generally, if f is a nonzero finite positive theta combination, then

    Newt(sigma_N(f)) = N Newt(f).

Indeed the term f^N/N! in the cycle-index expansion supplies the inclusion from below by positivity. Every monomial of every Psi_k(f) lies in k Newt(f), by the same known dilation identity and positivity of f. Each partition product therefore lies in N Newt(f), giving the reverse inclusion.

This conclusion says the new positive complete-symmetric operations preserve the expected scaled Newton shape. It does not say the shape determines the coefficients, or that the H-family forms a basis.

## 4. Literature boundary

- Ordinary pre-lambda/Adams formalism is standard. A primary reference is D. Grinberg's author notes, https://darijgrinberg.gitlab.io/algebra/lambda.pdf ; its terminology calls pre-lambda rings lambda rings, so conventions must be checked when citing it.
- The ordinary Witt transform and necklace mechanism are Moree, https://arxiv.org/html/math/0311194v2 . The new theta ghost sequence is not generally the sequence of powers of a single element.
- Newton dilation was directly checked in CMMM Lemma 2.9: https://arxiv.org/pdf/2505.09585v2 . It is used only for the displayed Newton corollary, not for integrality of sigma.
- Focused searches for cluster theta plus pre-lambda, lambda ring, Adams operations and symmetric powers found no exact earlier general formulation in this run. This is a limited search result, not an absolute priority assertion.

The construction is safest stated on the principal integral middle algebra. A coefficient-specialized identity remains positive, but an intrinsic pre-lambda operation on a quotient also requires the specialization kernel to be preserved by every Psi_n; this has not been silently assumed.
