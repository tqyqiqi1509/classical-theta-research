# The exact collision-tree lattice determinant

2026-11-13. This is an elementary linear-algebra input to the active global
Gale construction. It is not by itself a theta coefficient theorem or a
proof of invariant-target flatness.

Let eta be any integral skew matrix on a finite labeled vertex set V, with
a distinguished framing vertex 0. For a nonempty subset S define the column

    (v_S)_j = sum_(i in S) eta_(ij) if j in S, and 0 otherwise.

Take a rooted full binary tree with leaves V. Its N-1 internal vertices
are identified with their leaf clusters S. Form the square matrix M_T whose
columns are the v_S, with the row of vertex 0 deleted. If the two children
of S have leaf sets L_S and R_S, then

    |det M_T| = product_S |eta(L_S,R_S)|.                 (1)

In particular there is no hidden index or extra packet gcd in this raw
collision lattice. Any primitive or cycle normalization must be handled
separately.

## Proof

Split the root as V=L disjoint-union R, choosing 0 in L. Choose an anchor
r in R. Replace the r-coordinate row by the sum of all R-coordinate rows.
This is a unimodular row operation. Every column coming from an internal
cluster strictly below the root has zero entry in this new row: its support
lies entirely in L or R, and each v_S has coordinate sum zero. The root
column has entry

    sum_(j in R) eta(V,j) = eta(L,R).

After expanding the determinant in this row, the remaining matrix is block
diagonal: the left child's collision matrix with row 0 deleted and the
right child's matrix with row r deleted. Induction on the number of leaves
proves (1), with the empty determinant and empty product both equal to one.

## Independent exact computation

The Wolfram computation in computation/gale_collision_determinant.wl checked
2,000 independently sampled integral skew matrices of sizes 2 through 9
with independently sampled binary hierarchies. All absolute determinant
identities passed, including 367 zero determinants. For four leaves and
the split {1,2}|{3,4}, writing upper entries (a,b,c,d,e,f), it also returned
the symbolic determinant -a f(b+c+d+e), agreeing with the three vertex
pairings. The complete plugin response is saved beside the script.

## Geometric role and prior interfaces

In a binary coordinate-collision chart, the valuations of edge differences
are sums of positive cluster depths. The tropical Gale equations are
theta=-sum_S t_S v_S. If M_T is invertible, (1) counts the solutions of its
binomial initial system. Characteristic zero makes that binomial system
reduced; a direct Hensel argument then gives one lift per solution when all
depths are strictly positive. The branch is writing the completeness proof.

The general framework is prior work: Feichtner–Sturmfels,
Matroid polytopes, nested sets and Bergman fans, math/0411260, and
Sturmfels–Tevelev, Elimination theory for tropical varieties, 0704.3471.
The latter's Theorem 1.1 is a multiplicity pushforward for an already
generically finite morphism. It must not be cited as a proof that the
clone-invariant positive factor is finite or flat under specialization.
