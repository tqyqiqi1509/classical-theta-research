# Several independent label parameters: mixed binomial positivity

2026-11-13. A derived extension of STRUCTURE_RAY_POSITIVE_COPIES.md.
Only classical principal-coefficient theta functions are used. This concerns
a prescribed finite root window, not finite Laurent support of every label.
The extension below follows from the same positive-slot proof; historical
priority for this specific application is not asserted.

## Statement

Let J be a finite downward-closed root set and let B,D have the conventions
of the one-parameter theorem. Take input labels indexed by l=1,...,s and
independent nonnegative parameters k_1,...,k_r. Choose integral vectors
g_(l,j), h_l and put g_l=sum_j g_(l,j), G_j=sum_l g_(l,j),
G=sum_j G_j, H=sum_l h_l.

Assume the following finite, directly checkable sign compatibility:

* For each l and each nonzero a in J, the numbers g_(l,j)^T D a, as j
  varies, are all nonnegative or all nonpositive.
* For each nonzero a in J, the numbers G_j^T D a are likewise all of one
  weak sign.

Equivalently each displayed family lies in one closed chamber of the full
finite root hyperplane arrangement. This stronger arrangement condition is
intentional: lying in one effective scattering cone alone has not been
proved sufficient for the slot construction used here.

Choose the positive integer

    N0 > max(T_J(G;H), max_l T_J(g_l;h_l)),

with the explicit T from the one-parameter theorem, and define

    m_l(k) = h_l + N0 g_l + sum_j k_j g_(l,j),
    m(k)   = H   + N0 G   + sum_j k_j G_j.

Write

    product_l theta_(m_l(k))
       = sum_p c_p(k) y^p theta_(m(k)+Bp).

There are actual finite catalogs V_(p,beta), independent of k, such that

    c_p(k) = sum_(beta>=0, |beta|<=|p|)
                |V_(p,beta)| product_j binom(k_j,beta_j).       (1)

Thus every mixed forward difference is nonnegative throughout the
nonnegative parameter orthant. The total polynomial degree is at most |p|.
The finite nonnegative array in (1) is recovered by ordinary mixed finite
differences at the stated base point; it is not defined by those differences.

For h_l=0 and J contained in total degree at most d, the same universal
N0=floor(M d^2/4)+1, M=max|D_i B_ij|, works independently of the number of
inputs or independent directions.

## Why the old proof extends

For each a, sign compatibility implies

    g_l^T D a=0 iff every g_(l,j)^T D a=0.

When this pairing is nonzero, every nonnegative parameter increment has
the same sign as the base pairing. Therefore the effective sign estimate
at N0 remains valid for every k, for every intermediate root in J.
The finite incoming factorization has exactly the same negative and zero
groups as the direction g_l. Every variable monomial is fixed by that zero
group. Consequently the same local-star starting decoration works for all
k, including points on zero-root faces; no commuting assumption on the
zero group is needed.

Choose the refined starting chamber near g_l and the endpoint chamber for
the coefficient p exactly as in the one-parameter proof. The second sign
condition keeps the endpoint chamber fixed as k varies, modulo [0,p].
On each chosen straight transport path, every crossed root a has nonzero
g_l-pairing and fixed crossing sign sigma_a. The exponent at current root
q is

    E(k,q) = E(0,q) + sum_j k_j sigma_a nu_a dot g_(l,j),

where nu_a is the primitive integral normal. All slopes are nonnegative
integers. Every relevant base exponent is nonnegative by N0. As before,
discard a wall at a state if no nonconstant choice can survive the cutoff
before assigning slots; its unused exponent need not be nonnegative.

Keep the base slots. For parameter j add k_j named groups, each with
sigma_a nu_a dot g_(l,j) slots, at every crossing of every factor. Use one
common set [k_j] for that parameter across the entire object. Distinct
parameters have distinct color sorts. Local-star decorations and actual
positive wall alphabets do not depend on k.

A color is active when at least one of its slots contributes a nonzero
root. All active colors together consume at least their number of root
units. Hence their count |beta| is at most |p|. Delete the inactive colors
separately in each sort and relabel increasingly. Its inverse inserts any
chosen beta_j-subset of [k_j] in each sort, filling the other groups with
empty slots. Earlier root states, all base counts, and every wall alphabet
are unchanged. These literal inverse maps prove (1).

The arbitrary-endpoint coefficient extractor and its local-star proof are
the already reviewed parts of the one-parameter theorem. No new extraction
identity or full-support assertion is required here.

## Consequences that are stronger than one-dimensional monotonicity

For j!=j',

    c(k+e_j+e_j') - c(k+e_j) - c(k+e_j') + c(k) >= 0,

and the analogous inequality holds for every higher mixed difference.
The underlying injections of finite sets are obtained simply by adding
empty available groups; the positivity is therefore effective at N0.
Restriction to a diagonal k_1=...=k_r recovers a one-parameter assertion,
but positivity only on such diagonals would not prove these mixed claims.

Permuting active colors independently gives an auxiliary FI^r-set and a
permutation representation of product_j S_(k_j). This uses label-copy
colors, not the mutable-packet Young action sought in the separate global
Gale problem. It is path-dependent and is not claimed to be canonical
under seed mutation.

## Exact verification

The independent incoming-prefix engine and triangular theta multiplication
were used on 72 skew-symmetric or skew-symmetrizable inputs of ranks 2–4,
including cyclic matrices, transverse offsets, and opposite input families.
There were 17,976 exact mixed-difference checks, of which 12,344 tested the
predicted zero above the total-degree bound. All passed; 2,796 tested
differences were positive. The test does not use the positive-slot formula
as its coefficient oracle. Code and compact exact results are in
computation/multiparameter_binomial.py and its results JSON.
