# Explicit analytic majorants for all classical theta series

2026-11-13. Main coefficient estimate independently reviewed in `agents/qq_remainder_review/BEZOUT_CONVERGENCE_REVIEW.md` (PASS). The novelty audit is separate; this note does not claim that exponential estimates, functional-digraph generating functions, or analytic wall crossing are new in isolation.

## 1. Statement

Let B be any classical integral skew-symmetrizable matrix, with a positive integral symmetrizer D. In a chosen principal seed write

\[
\vartheta_{g,U}=x^g F_{g,U}(z),\qquad
z_j=y_j\prod_i x_i^{B_{ij}},\qquad
F_{g,U}(z)=\sum_{p\in\mathbb N^r}a_{g,U}(p)z^p.
\]

The endpoint U is generic for the relevant finite scattering orders; the positive initial chamber is a special case. No regularity or finite-Laurent assumption is placed on the integral label g.

For an active color i put

\[
A_i=[g_i]_++\sum_j[B_{ij}]_+p_j,\qquad
E_i=[-g_i]_++\sum_j[-B_{ij}]_+p_j,\qquad
d_i=\max(A_i,E_i+p_i-1).
\]

Then

\[
\boxed{\quad 0\le a_{g,U}(p)\le
\frac{\prod_{i:p_i>0}d_i^{p_i}}{\prod_i p_i!}.\quad}       \tag{1}
\]

If a displayed degree is zero, the selected factor has no isolated points and the bound is interpreted accordingly. Inactive factors are one. The constant coefficient is one.

Set

\[
C=\max(1,\max_{i,j}|B_{ij}|),\qquad G=\max_i|g_i|.
\]

A convenient weaker bound, valid for n=|p|>0, is

\[
a_{g,U}(p)\le\frac{(G+Cn)^n}{\prod_i p_i!}.             \tag{2}
\]

Therefore **every formal theta series**, for every label and endpoint, is absolutely and locally normally convergent in the same explicit domain

\[
\boxed{\qquad \sum_i|z_i|<\frac1{eC}.\qquad}             \tag{3}
\]

For q=eC sum_i|z_i|<1,

\[
|F_{g,U}(z)|\le 1+e^{G/C}\frac q{1-q}.                 \tag{4}
\]

The domain is independent of g, U, and the size or common rescaling of D. It is not claimed optimal or invariant under every seed mutation. In the original principal variables it is a neighborhood of the coefficient-zero torus:

\[
\{(x,y):x\in(\mathbb C^*)^r,
\ \sum_j|y_j x^{B e_j}|<1/(eC)\}.
\]

## 2. Why the global model gives the factorial estimate

For each fixed p choose rank-generic and cut-generic rational original-color parameters in the endpoint's finite chamber. The global cyclic factor theorem identifies a_g,U(p) with the total-sign multiplicity of a finite Young-equivariant factor of the primitive graph equations. A same-color separable perturbation

\[
\Gamma_{i,a}^{\rm pr}-T^{-a_i}+T^N P_i(x_{i,a})=0,
\qquad \deg P_i\le p_i-1,
\]

can be chosen generic and bounded, with N>max_i(-a_i). The uniform valuation window retains the whole chosen factor during this perturbation.

The degree p_i-1 is enough: on a coincidence stratum with d distinct values and s repeated blocks, the required value and derivative conditions number d+s<=p_i. Hermite interpolation provides these variations; generic smoothness handles the remaining stratum directions. The reduced selected factor has point stabilizers that are products of symmetric groups on equal-coordinate blocks. Its sign multiplicity is thus exactly its number of free Young orbits, each of cardinality product_i p_i!.

After clearing the outgoing denominators, a row of color i has total coordinate degree at most d_i. The frame is fixed at zero. The T powers are coefficients and do not increase this degree. Every selected reduced point is an isolated simple zero of the cleared affine system, because the actual-arrow denominators are invertible there and the selected analytic neighborhood is finite.

Bézout bounds the number of isolated simple affine zeros by product_i d_i^{p_i}, even if other positive-dimensional or boundary components are present. One proof is to perturb the homogenized equations to a general complete intersection of the same row degrees: isolated simple points persist, and the complete intersection has the product degree. Dividing the number of free points by the Young group order proves (1). No division of nonfree orbit counts is asserted.

For an active color,

\[
d_i\le |g_i|+\sum_j|B_{ij}|p_j+p_i-1\le G+Cn.
\]

This proves (2). For fixed n, the multinomial theorem gives

\[
\sum_{|p|=n}a_{g,U}(p)|z|^p
\le\frac{(G+Cn)^n}{n!}\left(\sum_i|z_i|\right)^n
\le e^{G/C}\left(eC\sum_i|z_i|\right)^n.
\]

Summing establishes (3)--(4). The proof works coefficient by coefficient with different auxiliary generic parameters: the same degree bound applies to all of them. It does not require a single algebraic parameter choice simultaneously generic at every infinite order.

## 3. Anisotropic majorant from colored functional digraphs

Let

\[
G_i=|g_i|,\qquad C_{ii}=1,\qquad C_{ij}=|B_{ij}|\quad(i\ne j).
\]

The stronger degree estimate gives the coefficientwise majorant

\[
F_{g,U}(z)\preceq
\mathcal M_G(z):=
\sum_{p\ge0}\frac{\prod_{i:p_i>0}
(G_i+\sum_j C_{ij}p_j-1)^{p_i}}{\prod_i p_i!}z^p.       \tag{5}
\]

The coefficients are nonnegative. On a labeled set with p_i vertices of color i, each vertex chooses one external terminal of its allowed G_i types, or one other vertex of color j together with one of C_ij arrow colors. It cannot choose itself. These independent choices give exactly the numerator in (5).

Let T have zero constant term and solve

\[
T_j=z_j\exp\!\left(\sum_i C_{ij}T_i\right).             \tag{6}
\]

Decomposition into rooted trees ending at external terminals, and directed cycles of length at least two decorated by rooted trees, gives

\[
\mathcal M_G(z)=
\frac{\exp\!\left(\sum_i(G_i-1)T_i\right)}
     {\det(I-\operatorname{diag}(T)C)}.                 \tag{7}
\]

Its manifestly positive form is

\[
\exp\!\left(\sum_iG_iT_i+
\sum_{k\ge2}\frac{\operatorname{tr}((\operatorname{diag}(T)C)^k)}k\right).
\]

Allowing self loops gives the slightly weaker, simpler majorant with numerator exp(sum_i G_i T_i). These are standard exponential-formula / Lagrange--Good identities, used here as a majorant rather than claimed as exact theta combinatorics.

An explicit computable anisotropic region follows. Choose v_i>0 with

\[
\rho(\operatorname{diag}(v)C)<1,
\qquad
|z_j|<v_j\exp\!\left(-\sum_i C_{ij}v_i\right).
                                                               \tag{8}
\]

The positive fixed-point iteration in (6) is bounded by v; its derivative is bounded by diag(v) C^T, whose spectral radius agrees with the displayed matrix. A weighted sup norm obtained from the positive inverse of I-diag(v) C^T gives contraction. Hence T and (7) converge on this polydisc and bound every theta series. This retains the actual arrow-size matrix and can be more useful for sparse or unbalanced graphs than the scalar ball.

A sharper scalar expression is also available. If s=sum_i|z_i|<1/(eC), let t be the small positive solution of t=s exp(Ct). Then the weaker majorant in (2) sums exactly to

\[
\sum_{n\ge0}\frac{(G+Cn)^n}{n!}s^n
=\frac{e^{Gt}}{1-Ct}.
\]

## 4. Multiplication and analytic identities

For k labels let m_p be the coefficient of y^p theta_{g_1+...+g_k+Bp} in their product. The arbitrary-endpoint coefficient formula computes m_p by a nonnegative finite convolution at an endpoint chosen near D(g_1+...+g_k+Bp). The bound above is endpoint-independent, so

\[
\sum_p m_p |z|^p
\le\prod_{l=1}^k
\left(1+e^{\|g_l\|_\infty/C}\frac q{1-q}\right),
\qquad q=eC\sum_i|z_i|<1.                             \tag{9}
\]

The formal multiplication identity is an actual normally convergent identity on the same domain. Indeed every coefficient of every series is nonnegative. At |z|, Tonelli identifies the full output expansion with the finite product of the input evaluations, which is finite by (3). This gives absolute convergence for complex z; replacing a compact set by a slightly larger positive polydisc gives local normal convergence. No shrinking by a factor k is needed, and no unsupported bound on the size of the output label is used.

Detailed wall-function consequences and the polygonal-path analytic comparison are developed independently in the dyck_flow_round2 branch. They should be quoted only in their stated smaller domains.

## 5. Exact checks and scope

The proof is general; finite computations were used to challenge its interfaces.

- `computation/analytic_majorant_probe.py`: 240 random skew-symmetrizable inputs of ranks 2--4; 2,070 nonzero coefficient checks against the sharper d_i bound, including 481 signed-endpoint coefficients. The oracle is the prior incoming recurrence, not the Q ideal. All passed.
- `computation/functional_graph_majorant.wl`: Wolfram independently verified 21 exact multivariate coefficients through total degree five for a nonsymmetric two-color C. The determinant orientation and transpose in (6) agree.
- The global factor and sign identification were independently reviewed before this consequence was derived. The Morse degree and Bézout argument received a separate review.

Analytic convergence does not imply finite Laurent support. This result does not supply a stopping certificate for a promised regular label. It also does not identify arbitrary quiver-with-potential DT invariants with cluster coefficients; any such transfer needs its own scattering-diagram comparison hypothesis.

## 6. Literature comparison to retain

- Kontsevich--Soibelman, arXiv:2005.10651v3, §3.8: analytic stability data and a uniform exponential bound are distinguished; Proposition 3.8.2 deduces analytic sector products from a uniform convergence assumption. Our graph bound is a concrete input of that kind for the classical cluster construction, not a replacement for their general theory.
- Weist, arXiv:1203.2740, Theorem 3.11 and Corollary 3.13: factorial denominators and spanning-tree bounds already give exponential estimates for Kronecker moduli. The factorial principle itself is old.
- Burcroff--Lee--Mou--Musiker--Reineke, arXiv:2511.14672, §9.3: precise rank-two exponential asymptotics and continuity of the directional growth rate are stronger conjectural questions. The present upper bound does not establish those asymptotics.
- Lagrange--Good inversion / functional-digraph exponential formulas are classical; the new candidate application is the uniform all-label, all-endpoint cluster bound supplied by the cyclic global factor.

The complete search record and own-work comparisons are maintained by global_gale_novelty. Absence from a search is not an absolute proof of priority.
