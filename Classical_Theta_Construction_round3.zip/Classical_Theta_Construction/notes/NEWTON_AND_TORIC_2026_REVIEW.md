# Focused 2026 primary-source review, 2026-11-13 20:10 UTC

These are statement-level audits for this classical theta project. A useful
source or a plausible proof is not silently treated as a proof of a stronger
theta identification. Li–Pan conclusions are not inputs.

## 1. Gui–Qin–Shen–Xiong, permutation cohomology

Primary: https://arxiv.org/html/2609.06597v1 and
https://arxiv.org/pdf/2609.06597v1 , submitted 6 September 2026.
Title: *Permutation representations on cohomology of toric varieties*.

Read the full introduction, Sections 2 and 3, including the actual proof of
the smooth-projective case. The mechanism is a G-invariant integral support
function, its Rees-type group ring, the Stanley–Reisner special fiber, a
regular-sequence argument for local flatness, and an étale isolation of the
finite flat branch. At a nonzero parameter the local factors are Jacobian
algebras of a G-invariant Laurent potential. Their tangent representations
are real lattice representations, so the cited equivariant Morse theorem
produces permutation representations.

The inspected algebraic steps are sound: completeness and smoothness give
the stated face-ring presentation; the linear parameters form a regular
sequence; flatness is local near the finite special fiber, not incorrectly
asserted for the whole global family. Uniqueness of the finite flat branch
uses connectedness and the fact that an extra finite flat component cannot
have an empty special fiber. The paper itself correctly records examples
where the global generic Jacobian dimension is larger.

The 1985 Roberts invariant-Morse theorem and Montaldi comparison have not
yet been checked in their primary texts by this branch. Therefore this is
a restricted audit of the displayed proof, not an independent verification
of every external analytic input. No theorem from this source is needed in
our direct tight-grading character calculation.

Use: essential novelty comparison. One must not claim that the existence of
some ungraded permutation realization of smooth projective toric cohomology
is new here. The finite set in that proof comes from critical points after
analytic deformation; it does not give the specific tight-Dyck set or an
explicit graph-only bijection. The current branch seeks that explicit model.

## 2. Fei, ramified monodromy characters

Primary: https://arxiv.org/abs/2610.09868 , current v2 revised 10 October
2026; local PDF and text are `sources/fei_ramified_2610.09868v2.*`.

Read Theorems 7.11 and 7.13, Corollaries 7.12–7.15, the basis interface in
Section 8, and the one-arrow calculation and basis comparison in Section 9.2.
The Newton argument is usable in its stated representation setting: a
generic exposing functional gives a unique extremal quotient by modularity
of the submodule lattice; Galois invariance forces balanced sheet ranks,
and the vertex trace is one. Algebraically generic presentations arising
from different full orders have the same quotient dimension vectors after
faithfully flat field extension. This proves order independence of their
Newton polytopes, with fixed Jacobian algebra and presentation weight.

No error was found in those Newton steps. The full ramified mutation and
realizability theory is not independently audited here and is not a proof
input. Section 8 identifies spanned algebras under reachability; it expressly
does not identify individual monodromy characters with theta functions.
Section 9.2 makes this distinction concrete: the order-selected nonrigid
ray gives powers Z^r, whereas the classical theta/greedy ray uses normalized
Chebyshev polynomials. Thus the Newton invariance theorem does not settle
Qin's general theta-versus-good-basis polytope question by itself.

Use: useful representation-theoretic direction and a warning against an
unproved identification. Not used as a universal finite theta algorithm.

## 3. Cao, Newton uniqueness

Primary: https://arxiv.org/html/2602.07929v2 , 11 February 2026.
Title: *Newton polytopes in cluster algebras and tau-tilting theory*.

Read the definitions, Section 4.1, and the entire proof chain of
Proposition 4.7, Lemmas 4.8–4.10 and Theorem 4.11. Equal F-polytopes first
force compatibility through the established F-invariant. A left Bongartz
completion then supplies a red coordinate whose multiplicity is recovered
by a tropical F-evaluation; remove that factor and induct. The empty-support
case is the trivial base case. No substantive error was found in this chain.

Use: a genuine prior Newton recognition theorem, but its conclusion concerns
cluster monomials in noninitial variables. Neither arbitrary theta-element
recognition nor coefficient reconstruction from a Newton polytope follows.
The general theta project does not import either stronger assertion.

## 4. Prior own positive-polytope result

Primary: https://hexagonmath.org/2611.00015v1 , Qiyue Tang,
*Positive polytopes and the full Fock–Goncharov conjecture*.
Its abstract and metadata were rechecked. It concerns bounded positive
polytopes with the origin in their interior and full Fock–Goncharov.
That is not the same as an ordinary polytope whose normal fan realizes a
finite root cutoff of the scattering fan. Its full proof was not reread
in this cycle, and it is not used as a new theorem input here.

## Route consequences

Continue the actual tight-grading/toric cohomology character construction;
do not substitute ordinary stable-tree permutation actions, whose characters
are different. Continue repeated-label cancellation using the newly proved
flagged-tree transport. Pursue promised-regular-label finite certificates
without assuming a generic-character or monodromy-character identity.
