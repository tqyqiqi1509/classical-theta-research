# The label domain of a finite Laurent algorithm

This note prevents an impossible output promise; it is not the main research goal and does not replace the search for an effective construction on regular labels.

Let B_a be the skew-symmetric matrix of a cyclic three-vertex quiver with a arrows on each edge, a>=3. Each column has coordinate sum zero. Matherne–Muller, *Computing Upper Cluster Algebras*, Proposition 6.2.2, prove

    U_(a,a,a) = Z[x1,x2,x3,M] /
      (x1*x2*x3*M - x1^a - x2^a - x3^a),
    M=(x1^a+x2^a+x3^a)/(x1*x2*x3).

Primary source inspected: https://jpmather.math.ncsu.edu/documents/computingupper.pdf, Proposition 6.2.2. This is an established input, not a new theorem of this run.

Give x_i degree 1 and M degree a-3. All generators have nonnegative degree, so U has no nonzero homogeneous component of negative degree.

For principal coefficients, a theta expansion labelled by g has terms

    x^g y^p x^(B_a p),    p>=0.

After setting all y_i=1, every term has total x-degree sum(g_i), because the column sums of B_a are zero. If g belonged to the regular finite theta set, this specialization would be a finite universally Laurent element, hence an element of U_(a,a,a). Its nonnegative coefficients and leading coefficient 1 ensure that it is nonzero. Therefore

    sum(g_i)<0  ==>  g does not belong to the regular theta set.

For example g=-e1 cannot be promised a finite regular theta polynomial. This argument concerns the whole half-space in an infinite family of classical skew-symmetric seeds. It does not refute a finite-output algorithm whose input is explicitly restricted to the regular theta index set Theta.

The remaining constructive task is substantive: given a regular theta label, obtain a finite, checkable stopping witness without presupposing its coefficients or its unknown Newton polytope. The old package already solves this with additional reddening/predecessor or coercive-gauge data. The present run seeks a broader mechanism.

Technical convention: the argument uses finiteness and regularity in all seed charts, so it makes no unsupported claim that an arbitrary finite initial-chart truncation is itself a regular theta element.
