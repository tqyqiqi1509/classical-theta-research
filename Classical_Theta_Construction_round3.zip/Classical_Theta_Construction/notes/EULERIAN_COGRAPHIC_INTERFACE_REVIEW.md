# Eulerian cographic polytopes: usable interface and normalization correction

Reviewed 2026-11-13, UTC, for the cyclic residual-normalization construction.

## Source and exact scope

Lilla Tóthmérész, *A geometric proof for the root-independence of the greedoid
polynomial of Eulerian branching greedoids*, arXiv:2204.12419v3 (11 Apr 2024),
Journal of Combinatorial Theory, Series A 206 (2024), 105891.

- https://arxiv.org/html/2204.12419v3
- https://arxiv.org/pdf/2204.12419v3
- Published PDF: https://real.mtak.hu/206434/1/1-s2.0-S009731652400030X-main1.pdf
- DOI: https://doi.org/10.1016/j.jcta.2024.105891

Read the relevant regular oriented matroid preliminaries, the height-one
co-Eulerian criterion, total-unimodularity argument, and all of the two-lemma
proof of the arborescence triangulation. The published PDF was checked against
the arXiv PDF where a normalization problem appeared. HTML theorem numbering
is different: PDF Theorem 4.1 is rendered as HTML Theorem 4.21.

## Usable prior mechanism

For an Eulerian directed graph, a totally unimodular cographic configuration
has its columns in an integral height-one hyperplane. Complements of spanning
arborescences rooted at a fixed vertex give a unimodular triangulation of its
root polytope (PDF Theorem 4.1). The proof supplies a burning order and a
fundamental-cut pivot that preserves a given point of the polytope and moves
strictly down that order until it reaches an arborescence complement. The
separation and common-face arguments are combinatorial cut/circuit arguments.

This is directly relevant to the residual stable-tree alphabets: after a
limiting positive forest is contracted, the quotient graph is Eulerian. Its
arborescences can serve as a concrete reference triangulation for the already
constructed half-open Ehrhart cancellation maps. The height-one geometry and
arborescence triangulation are prior work, not discoveries of this session.
The source does not itself give the theta/Dyck correspondence or the cyclic
flow-tree plethystic cancellation being developed here.

## Confirmed normalization error in the displayed main formula

The paper defines the greedoid polynomial as the h-polynomial of the dual
complex, and also as the external-activity enumerator. With those definitions,
the displayed exponent in Theorem 1.1 is incorrect in general. The paper writes

    lambda_G(t) = t^(|V|-1) h*_Q(t^-1).

The cographic matroid has rank |E|-|V|+1, so its height-one root polytope has
dimension |E|-|V|. Applying the paper's own equation (2.2) to its triangulation
instead gives

    lambda_G(t) = t^(|E|-|V|+1) h*_Q(t^-1).

The first proof of Theorem 1.1 repeats the erroneous dimension |V|-2. This
is present in both the arXiv v3 and published PDF, not only in extracted HTML.

An exact minimal witness is the directed three-cycle. For any fixed root there
is exactly one outward spanning arborescence. Its sole excluded arrow is
externally active, so lambda(t)=t. The cographic matrix is [1 1 1], its root
polytope is a single lattice point, and h*=1. The printed main formula gives
t^2, whereas the corrected exponent gives t.

The line in Section 2.2.2 that states external passivity = r - external
activity, with r the cardinality of a greedoid basis, has the same bookkeeping
problem: it must be |E|-r - external activity. The next displayed equation in
that section already uses |E|-r correctly.

These corrections do not contradict the root-independence conclusion or the
triangulation theorem used here. We do not quote the incorrectly normalized
formula as an input. The cyclic transport needs only the independently checked
geometric triangulation statement and the actual lattice-point maps.

## Minor proof wording

In the coverage pivot, a boundary point can give epsilon=0. The claim that the
new coefficient of the exchanged arrow becomes positive then needs to be
weakened to nonnegative. The pivot still changes the spanning tree strictly
down the burning order, keeps the point in the new simplex, and terminates.
This wording issue does not invalidate the coverage argument.

## Disposition

Useful, with the precise normalization correction above. No conclusion beyond
the read and checked interface is being adopted. It is a 2024 primary source;
the same proof-first review rule is used here as for the requested 2026 sources.
