# Effective positive binomial expansions for dilated multiplication coefficients

2026-11-13. Classical principal-coefficient theta functions, fixed exchange
matrix. The proof has completed a fresh independent internal review; see
`../agents/cyclic_transport_review/STRUCTURE_RAY_INDEPENDENT_REVIEW.md`.
Historical priority remains subject to literature comparison.
It extends the fixed-matrix coefficient-ray argument to arbitrary endpoints
and then to multiplication. Qualitative eventual positivity of differences
alone is not claimed as a new phenomenon: a nonzero eventually nonnegative
polynomial has that property after some unspecified threshold.

## 1. Statement

Let B be integral skew-symmetrizable, D a positive integral symmetrizer,
and J a finite downward-closed set of nonnegative roots containing zero.
Write theta_m=x^m F_m(z), z_i=y_i x^(Be_i). For g,h in Z^r define

    T_J(g;h) = max( {0} union
      { |(h+Bs)^T D a| / |g^T D a| :
          s in J, 0<a<=s, g^T D a != 0 } ).

Fix any finite number of input rays m_i(n)=n g_i+h_i. Put

    G=sum_i g_i, H=sum_i h_i,
    N0 > max( T_J(G;H), max_i T_J(g_i;h_i) ),

with N0 a positive integer. Define principal-root multiplication coefficients
by

    product_i theta_(n g_i+h_i)
       = sum_(p>=0) c_p(n) y^p theta_(nG+H+Bp).

Then, for every p in J and k>=0, there are actual finite sets V_(p,j),
independent of k, such that

    c_p(N0+k) = sum_(j=0)^|p| |V_(p,j)| binom(k,j).        (1)

In particular all forward differences are nonnegative from the stated N0,
the degree is at most |p|, and eventual nonvanishing is detected by the single
value c_p(N0+|p|)>0. For unshifted rays, if J lies in total degree <=d, the
uniform choice N0=floor(M d^2/4)+1, M=max|D_i B_ij|, works for every number
of inputs and every collection of integral directions.

The statement concerns a finite principal-root window. It does not require
regular theta labels or claim finite support of the full product.

## 2. Stable large-label transport to an arbitrary chamber

Here chamber and path mean those of the finite diagram modulo J. Fix a
generic endpoint Q. Let theta_(Q,m) denote the theta expression at Q.
Choose a point q near g so that all nonzero root signs at g are unchanged,
and a root with g^TDa=0 has at q the same sign as at Q. In ordinary label
coordinates one may use q=g+epsilon Q, after converting covectors by D.
Choose epsilon>0 sufficiently small and make Q generic enough that the
straight segment from q to Q avoids joints; the finite forbidden conditions
allow such choices. Perturbing within the endpoint chamber does not change
the expression.

Here is the exact factorization argument. Write the incoming factorization
as C=A_g^- Z_g A_g^+, and set u=D^{-1}Q when Q is a root covector. If
Z_(g,u)^- is the negative u-factor of the zero-root group Z_g, the finite
sign refinement at q=g+epsilon u gives

    A_q^- = A_g^- Z_(g,u)^-.

The standard chart relation is theta_positive=A_q^- theta_q. Combining
this with the already proved effective translated-ray factorization gives

    theta_(q,ng+h)
       = (Z_(g,u)^-)^-1 (A_g^-)^-1 A_g^-(x^(ng) eta_h^g)
       = x^(ng) (Z_(g,u)^-)^-1 eta_h^g.

The zero-root operators fix x^(ng), so the last factor is independent of n;
the zero-root group itself need not be commutative. It is precisely the
local-star theta expression in direction u. Thus, for n>T_J(g;h),

    theta_(q,ng+h) = x^(ng) eta_(q,h)^g.                 (2)

The finite coefficients of eta are the usual positive theta coefficients
of the local star at g. They are independent of n. This follows equally by
factoring the zero-root group into the refinement selected by q: its roots
annihilate x^(ng), so all n-dependence is carried by that monomial. For h=0,
eta=1. This is the same stable-ray mechanism as in the positive endpoint
chart, with the zero-group refinement retained rather than suppressed.

Every wall crossed by the straight segment has g^TDa nonzero. Indeed a
zero-root sign was chosen to agree at both ends. A nonzero root hyperplane
is crossed at most once, and the crossing direction has the sign of its
initial value g^TDa. If nu=Da/gcd(D_i a_i) is the primitive integral normal,
the positive wall function is therefore used with exponent

    E(n,q') = n |nu dot g| + epsilon_a nu dot (h+Bq'),    (3)

where epsilon_a is the fixed crossing sign chosen so that the first term
is positive, and q' is the current root state. Formula (3) does not assume
that every crossing is from the negative side to the positive side.

If a nonconstant term at this wall can survive J, then q'+la lies in J for
some l>=1, hence s=q'+a lies in J. Skew symmetry gives
(h+Bq')^TDa=(h+Bs)^TDa. The stated threshold implies E(N0,q')>=0.
If no nonconstant term can survive the cutoff at a given state, ignore that
wall at that state before introducing slots. Its irrelevant untruncated
exponent need not be nonnegative, but only the constant term contributes.
Every relevant exponent has an ordered-slot realization with

    E(N0+k,q') = E(N0,q') + k |nu dot g|.

The active-copy argument now applies to arbitrary Q, exactly as for the
positive chart: keep base slots, add k identically colored groups at every
wall, and use the same colors across all crossings. Actual wall alphabets
are supplied by the earlier tight-grading construction. The local-star
starting object is an additional fixed positive decoration. No coefficient
cardinality is used to invent an alphabet.

## 3. A single endpoint recovers a multiplication coefficient

For a fixed target p, let R_n=nG+H+Bp. The principal theta dual-coefficient
identity states that, for a generic small positive independent perturbation,

    Q_n = D R_n + epsilon,
    c_p(n) = [x^(nG+H) z^p] product_i theta_(Q_n,ng_i+h_i).  (4)

In this display Q_n is a root covector, rather than the label coordinates
used in Section 2. The conversion is only multiplication by D.

For clarity, the underlying duality says

    [y^p x^R] (y^s theta_(D R+epsilon,r))
                  = delta_((r,s),(R,p)).

If x^R can occur, its extra root is a=p-s and R=r+Ba. For a>0 the framed
incoming calculation at D(r+Ba)+epsilon has no positive-time event: every
nonzero event pairing gives time -1 plus an infinitesimal. The target is
nonaxis, so its coefficient is zero. For a=0 the leading coefficient is one.
This is proved already in the previous package's
TWO_FRAME_INDEPENDENT_REVIEW.md, Section 6, and is used here as an established
input, not claimed anew.

The endpoint chamber in (4) is independent of n>=N0 modulo J. For a root
a<=p with G^TDa nonzero, its leading sign dominates because
N0>T_J(G;H), applied to s=p. For G^TDa=0 the sign is determined by the
fixed lower term (H+Bp)^TDa and then the fixed positive perturbation.
The proof can be localized to [0,p]; one need not claim this particular
threshold fixes irrelevant roots of a larger J that are not <=p.

Choose one fixed generic representative Q_p of this chamber. Apply Section
2 to each factor, with its own starting local-star object and path to Q_p.
All root contributions in (4) are nonnegative.

## 4. The finite sets V and the inverse maps

At every wall in every input factor split the exponent into base slots and
k groups of |nu dot g_i| slots. Use a single global color set [k] for all
factors. A complete object is a tuple of local-star objects and their finite
wall-slot histories whose combined root increment is p. A color is active
if at least one of its slots is nonempty anywhere in that tuple.

Each active color consumes a nonzero root increment, so there are at most
|p| active colors. V_(p,j) is the explicit catalog obtained with color set
[j] and every color active. For an object over [k], collect its active
j-subset and relabel it increasingly by [j]. Conversely, choose any j-subset
of [k], insert the V object on those colors, and make all other colored slots
empty. Earlier increments and therefore all base slot counts are unchanged.
These maps are literal inverses, proving (1).

The same construction handles more than two inputs without iterating theta
multiplication or introducing intermediate output rays. The endpoint
extraction (4) is applied directly to their product.

## 5. Uniform bound and substantive content

For h_i=0, a<=s gives

    |(Bs)^TDa| = |(B(s-a))^TDa|
                 <= M |a| (|s|-|a|) <= M d^2/4.

Nonzero denominators g^TDa are nonzero integers. This proves the uniform
quadratic bound for all input and output directions. With offsets one may
instead use the explicit displayed maximum; a coarser bound is obtained
by adding d max_i|D_i h_i| for each relevant offset h_i or H.

The added content over eventual polynomiality is the common explicit
threshold, the nonnegative Newton coefficients already at that threshold,
the active-color catalogs, and the exact eventual-support test. Fixed B and
simultaneously dilated input labels must be distinguished from the previous
simultaneous-matrix replication theorem.

## 6. Computation and completed internal review

The script computation/structure_ray_binomial.py expands products by
independent triangular subtraction in the positive-chart theta basis. It
tests generic, opposite and coincident directions, arbitrary bounded offsets,
cyclic matrices and nonscalar symmetrizers in ranks 2--5. Thus it does not
use the endpoint-copy theorem as an oracle. Exact results are saved beside
the script. This verification does not replace the proof. The independent
review subsequently checked the exact local-star factorization, the
target-specific endpoint chamber cutoff, all activity relabeling maps,
and the uniform threshold. It found no remaining mathematical gap in
those interfaces.
