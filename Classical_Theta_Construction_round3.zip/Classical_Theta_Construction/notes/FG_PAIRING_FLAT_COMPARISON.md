# Exponentially flat comparison of the analytic stable logarithm and ray growth

2026-11-13. Root derivation. The analytic stable-log construction is being written independently in `agents/analytic_convex_body/`; the local Fock--Goncharov scaling-pairing interface and literature comparison are being written in `agents/analytic_convex_novelty/`. This note separates the genuine real limit from coefficientwise stabilization.

## 1. Two functions, not an unproved identification

For sufficiently small positive z, define

\[
L_z(g)=\log H_g(z),\qquad
\Phi_z(g)=\lim_{n\to\infty}\frac1n\log F_{ng}(z).
\]

The first function uses the convergent stable transport series. The second is the real label-scaling limit. Strong positive multiplication gives

    F_(n+m)g(z) <= F_ng(z) F_mg(z),

and every F_ng(z)>=1. Fekete therefore proves existence of Phi, with

    Phi_z(g)=inf_n log F_ng(z)/n.

The common analytic majorant makes the limit finite. Homogeneity on the rational label lattice, subadditivity, and a uniform label-norm bound give a unique continuous sublinear extension to all real g. This is a local realization of the old additive canonical-pairing question, not a claim that the question or the Fekete principle is new.

The coarse negative factor A_g^- transports from the endpoint Dg to the positive chamber. At an ordinary generic nearby endpoint U, theta_pos,ng=A_U^-(theta_U,ng). All wall maps preserve positive real coordinates. The uniform path domain keeps the transported principal variables inside the common theta convergence domain. The endpoint theta series is nonnegative with constant coefficient one. Consequently

    F_ng(z) >= (x^-g A_U^-(x^g))(z)^n.

As U approaches Dg through the positive zero-root germ, the scalar factor converges to H_g(z): each finite root order stabilizes and the analytic path tail is uniform. Thus

\[
F_{ng}(z)\ge H_g(z)^n,
\qquad L_z(g)\le\Phi_z(g).                            \tag{1}
\]

There is no need to claim a full endpoint theta-series limit at the boundary. The scalar transport limit is sufficient.

## 2. Explicit flat remainder along a positive coefficient ray

Fix an integral nonzero g and a positive vector v, and write z=epsilon v, S=sum_i v_i. Let

    C=max(1,max|B_ij|), G=||g||_infinity,
    M=max_ij |D_i B_ij|, M'=max(1,M).

The earlier stable-ray theorem gives

    F_ng = H_g^n modulo total degree >d
    whenever n>M d^2.

Use any explicit analytic path radius R>0 and bound M_H for the radial stable logarithm:

    log H_g(s v) analytic for |s|<=R,
    sup_|s|<=R |log H_g(sv)| <= M_H,
    log H_g(0)=0.

Such data are supplied by the one-segment path theorem: if q_0,K are its domain and displacement constants, one may take

    R=q_0/(2 e C S),          M_H=||g||_1 K.

For rho<=R/2, radial Cauchy estimates give

    |log H_g(sv)| <= 2 M_H rho/R,       |s|<=rho.

The scalar functional-digraph majorant gives, for rho<=1/(4CS),

    |F_ng(sv)| <= 2 exp(2 n G S rho).

Indeed the small solution t=rho S exp(Ct) satisfies t<=2rho S and 1-Ct>=1/2. Define

    A=max(1,2GS,2M_H/R),
    rho_0=min(R/2,1/(4CS)).

Then for every n and rho<=rho_0,

    |F_ng(sv)-H_g(sv)^n| <= 3 exp(A n rho),   |s|<=rho.

Take d>=1, n=M d^2+1, and rho=2epsilon<=rho_0. The difference vanishes to order d+1. The maximum principle applied after dividing by s^(d+1) gives

    |F_ng(epsilon v)-H_g(epsilon v)^n|
       <= 3 exp(2 A n epsilon) 2^(-d-1).

Also H_g(epsilon v)^n>=exp(-A n epsilon). Combining this bound with (1), log(1+t)<=t, and the infimum formula for Phi yields

    0 <= Phi_(epsilon v)(g)-L_(epsilon v)(g)
      <= (3/n) exp(3 A n epsilon) 2^(-d-1).

Now choose

    d=floor(log(2)/(6 A M' epsilon)),

and restrict

    0<epsilon<=epsilon_0
      :=min(rho_0/2, log(2)/(12 A M')).

Then d>=1 and the preceding exponent is at most

    -(log(2))^2/(12 A M' epsilon).

Therefore the explicit conclusion is

\[
\boxed{\quad
0\le\Phi_{\epsilon v}(g)-L_{\epsilon v}(g)
\le 3\exp\!\left(-\frac{c_g(v)}\epsilon\right),
\qquad
c_g(v)=\frac{(\log2)^2}{12 A M'}>0.
\quad}                                                   \tag{2}
\]

The constants are intentionally conservative. For g=0 both functions vanish. The proof also works when B=0, though in that case direct formulas give equality.

## 3. What (2) says and what it does not

The actual positive ray-growth pairing and the convergent stable logarithm have the same expansion to every algebraic order as epsilon tends to zero along a fixed positive coefficient ray. The possible difference is exponentially flat. This is substantially stronger than simply noting equality of every eventually stabilized coefficient, because it compares two actual real-valued functions with a quantified error.

It still does not prove equality. A nonzero exponentially flat function can have every power-series coefficient equal to zero. If one later proves that Phi is real analytic at the coefficient-zero boundary, (2) and analyticity would imply Phi=L locally. No such analyticity is assumed here. Convexity on the positive domain alone does not justify it.

Likewise the argument does not prove finite Laurent support. It gives a new quantitative bridge between the coefficientwise large-label theorem and the old real scaling-pairing question.
