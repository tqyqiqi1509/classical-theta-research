# November 2026 literature comparison: mutation, pointed bases, and Newton parameters

Reviewed 2026-11-13, 20:58–21:09 UTC. Classical cluster algebras only.

## Reading–Stella, Mutation of Theta Functions

Primary version: arXiv:2603.19391v4, 8 November 2026; SIGMA 22 (2026), 109.
<https://arxiv.org/html/2603.19391v4>
<https://sigma-journal.com/2026/109/>

The introduction, coefficient hypotheses, and the full statements and proofs in
Sections 5.3–5.5 were read directly. The mutation theorem itself was not
reproved in this review; it is equivalent, after translating conventions, to
the older GHKK mutation law. No result in our new construction is being
deduced from an unaudited assertion in this 2026 paper.

### What the paper actually supplies

* The ambient object is the **small canonical algebra**, allowing formal theta
  functions for arbitrary exchange matrices. This is not a theorem that every
  lattice label gives a finite Laurent polynomial.
* Signed-nondegenerating coefficients are assumed. Having principal
  coefficients in some seed is a sufficient condition.
* Theorems 5.6 and 5.14 characterize pointed elements and pointed reduced bases
  using all-seed sets `N_m`. The proofs transport leading exponents and frozen
  monomials, then apply uniqueness for reduced expansions. The change-of-basis
  coefficients are arbitrary field elements; these theorems do not prove
  nonnegative expansion in the theta basis or theta minimality among strongly
  positive bases.
* Theorem 5.7 restricts product labels when all input labels lie in one cone
  of the **mutation fan**. Its proof uses linearity of the tropical mutation
  maps and the frozen correction maps on those cones. It is stronger than
  the ordinary dominance-region restriction of Theorem 5.4.
* Theorem 5.22 constructs a ray basis when the rational part of the mutation
  fan is simplicial and integral. Its elements are products of theta functions
  on primitive rays. This is different from our fixed-matrix study of the
  individual functions `theta_(n g)` and their effective finite differences.

### Strong-audit outcome for the parts read

The elementary arguments in Sections 5.3–5.5 are consistent with their stated
hypotheses. The induction for the frozen correction, the dependence of
`nu_k^(m)` on frozen data, and the reduced-basis triangularity are explicit.
No error was found in those arguments. This is a restricted verification of
the interfaces read, not a certification of all 38 pages.

The paper does not duplicate the explicit cutoff, positive slot catalog,
degree bound, or mixed forward-difference statement in our fixed-`B` ray and
multi-parameter results. It does prevent us from describing ordinary pointed
triangularity or same-mutation-cone dominance as new. It also leaves the
general finite-Laurent stopping problem open in precisely the sense relevant
to the present project.

Its companion paper, *Theta functions in acyclic affine type*,
arXiv:2603.23429v1 (24 March 2026), was located at the primary record:
<https://arxiv.org/abs/2603.23429>.
Only the record/abstract was read in this cycle. Its imaginary-wall and tube
subalgebra results are therefore **not imported as proof inputs**. They
concern an acyclic affine family, not an arbitrary cyclic core.

## Tang, Newton log-concavity, Hexagon 2611.00056v1

Primary record and PDF:
<https://hexagonmath.org/2611.00056v1>
<https://hexagonmath.org/pdf/2611.00056v1>

The introduction and Theorem 1.2, the Newton product kernel and its proof in
Section 2, and the opening of Section 3 were read directly. The theorem
studies Newton coefficients as the **exchange parameter** varies in rank
two. Multiplication counts pairs of subsets by the size of their union;
integer binomial selection is another closure operation. These are prior
results and prior mechanisms, not discoveries of this run.

The present positive-copy construction uses that same elementary
subset-union mechanism, so no novelty is claimed for the Newton kernel or
for positivity under such closure operations. The distinct work is the
cluster-specific reduction at a fixed exchange matrix, the explicit
stabilization threshold, the degree bound in the output root degree, and
the common-color catalog for multiplication coefficients. The full
log-concavity theorem is not needed here and has not been adopted as a
premise. No new log-concavity claim is inferred from binomial positivity.

## General analytic interface newly needed for the graph construction

The exact standard facts were checked in author sources:

* Temkin, *Introduction to Berkovich analytic spaces* (2010), Definition
  3.4.9, Remark 3.4.10, Fact 3.4.11(iv): strict relative affinoid generators
  give relative interior; a map between affinoids with empty relative
  boundary is finite.
  <https://berkovich-2010.imj-prg.fr/lecture-notes/Temkin-lecture-notes.pdf>
* Achinger, *Introduction to Non-Archimedean Geometry* (2020), Definitions
  8.7.1 and 8.7.3 and Theorem 8.7.8 give the alternative route through
  relative compactness and Kiehl's finiteness theorem.
  <https://achinger.impan.pl/rigid/notes-dec10.pdf>
* Stacks Project, Lemma 10.128.1, tag 00R4: regular base, Cohen–Macaulay
  source, and the local dimension equality imply flatness. Statement and
  proof were read.
  <https://stacks.math.columbia.edu/tag/00R4>

These standard facts do not supply the new valuation bound. That bound is
proved separately from charged collision hierarchies; only then can these
analytic facts be applied.
