# Diagnostic for linear stabilization and uniform zero-freeness

2026-11-13. This is a challenge of a general proposed mechanism, not a new theorem about special rank-two bases.

`computation/ray_stabilization_mechanism.py` uses the exact LLZ recurrence (1208.2391v3, Definition 1.3 / Proposition 1.6) to produce complete finite theta F-polynomials for six affine, wild symmetric, and valued families, at 15 scales from 1 through 32. The stable degree-14 reference is computed independently from the incoming halfspace recursion at the proved quadratic scale M*14^2+1. Small-label coefficients are cross-checked by that independent recursion (114 nonzero checks).

The first mismatch of the normalized radial logarithm is consistent with growth proportional to the label scale in these inputs. This does not show that a linear threshold holds in arbitrary rank, nor that it holds at all scales even for these families. The general proof is being sought through broken-line multiplicity constraints or a genuine connected framing decomposition.

The Wolfram computation in `ray_uniform_zero_free_probe.wl` numerically computes all complex roots of 24 complete radial polynomials, including degrees up to 96. It found no roots tending visibly to zero at the sampled scales; the smallest modulus among these samples is approximately 0.21610. These are numerical diagnostics with reported residuals, not rigorous zero-free certificates and not proof of a common domain as the label scale tends to infinity. The complete tool response is retained in the companion JSON.

## Corrected implementation issue

The first provisional normalized-log run accidentally converted the empty rational sum at degree one to a floating value by Python `/`. This produced spurious low-degree mismatches and was discarded immediately. The code now initializes every coefficient and empty sum as `Fraction`, and the final JSON contains exact rational coefficients only. No conclusion or count from the provisional mismatches is retained as evidence.

The experiment is now complete for its stated purpose. Repeating it at more special inputs without a new general mechanism would not address the main research gap.
