"""Challenge a general linear-stabilization / uniform-zero-free mechanism.

The exact LLZ recurrence is used only as an independent diagnostic, not as
a new rank-two result.  Source: arXiv:1208.2391v3, Def. 1.3 / Prop. 1.6.
The stable reference is computed from the independent incoming halfspace
algorithm with the proven quadratic cutoff, not fitted from sample labels.
"""
from pathlib import Path
from fractions import Fraction
from math import comb, gcd, log
from functools import lru_cache
import json, time


def ibinom(a,k):
    if k<0:return 0
    if a>=0:return comb(a,k) if k<=a else 0
    return (-1)**k*comb(-a+k-1,k)


def llz_F(b,c,g):
    a1=-g[0];a2=c*max(a1,0)-g[1]
    m1=max(a1,0);m2=max(a2,0);co={(0,0):1}
    for d in range(1,m1+m2+1):
        for p in range(max(0,d-m1),min(m2,d)+1):
            q=d-p;value=0
            if a2-c*q>0:
                value=max(value,sum((-1)**(k-1)*comb(a2-c*q+k-1,k)*co.get((p-k,q),0)
                                    for k in range(1,p+1)))
            if a1-b*p>0:
                value=max(value,sum((-1)**(k-1)*comb(a1-b*p+k-1,k)*co.get((p,q-k),0)
                                    for k in range(1,q+1)))
            if value:co[p,q]=value
    return {(m1-q,p):v for (p,q),v in co.items()}


def incoming_total(b,c,g,d):
    div=gcd(b,c);D=(c//div,b//div)
    J=sorted(((i,j) for i in range(d+1) for j in range(d+1-i)),key=lambda p:(sum(p),p))
    def le(p,q):return p[0]<=q[0] and p[1]<=q[1]
    @lru_cache(None)
    def C(p,q):
        return ibinom(-g[0]-b*q[1],p[0]-q[0])*ibinom(-g[1]+c*p[0],p[1]-q[1])
    F={(0,0):1}
    for p in J[1:]:
        mp=(g[0]+b*p[1],g[1]-c*p[0])
        I=[q for q in J if le(q,p) and (q==p or
                  mp[0]*D[0]*(p[0]-q[0])+mp[1]*D[1]*(p[1]-q[1])<0)]
        inverse={p:1}
        for q in reversed(I[:-1]):
            z=-sum(v*C(r,q) for r,v in inverse.items() if le(q,r))
            if z:inverse[q]=z
        F[p]=-sum(v*F.get(q,0) for q,v in inverse.items() if q!=p)
    return {p:v for p,v in F.items() if v}


def radial(F,d=None):
    if d is None:d=max(map(sum,F),default=0)
    out=[0]*(d+1)
    for p,v in F.items():
        if sum(p)<=d:out[sum(p)]+=v
    return out


def series_log(f,d):
    f=f+[0]*max(0,d+1-len(f));ell=[Fraction(0)]*(d+1)
    assert f[0]==1
    for k in range(1,d+1):
        ell[k]=Fraction(f[k])-sum((j*ell[j]*f[k-j] for j in range(1,k)),Fraction(0))/k
    return ell


def run(d=14):
    started=time.time();records=[];sample_polys=[];checks=0
    # Affine, wild symmetric and valued inputs challenge the same mechanism.
    for b,c,a1,a2 in [(2,2,1,1),(3,3,1,1),(3,3,1,2),
                       (2,3,1,1),(2,3,1,2),(3,2,2,1)]:
        g=(-a1,c*a1-a2);M=b*c//gcd(b,c);N=M*d*d+1
        reference=incoming_total(b,c,tuple(N*x for x in g),d)
        stable=[z/N for z in series_log(radial(reference,d),d)]
        rows=[]
        for n in list(range(1,13))+[16,24,32]:
            F=llz_F(b,c,tuple(n*x for x in g));fr=radial(F)
            if n<=3:
                oracle=incoming_total(b,c,tuple(n*x for x in g),min(6,d))
                assert {p:v for p,v in F.items() if sum(p)<=min(6,d)}==oracle
                checks+=len(oracle)
            ell=[z/n for z in series_log(fr,d)]
            mismatch=[j for j in range(1,d+1) if ell[j]!=stable[j]]
            # These real values are diagnostics, never equality certificates.
            values={str(e):log(sum(v*e**k for k,v in enumerate(fr)))/n
                    for e in [0.001,0.01,0.03]}
            rows.append(dict(n=n,terms=len(F),degree=len(fr)-1,
                             first_radial_log_mismatch=mismatch[0] if mismatch else None,
                             comparison_cutoff=d,normalized_log_values=values))
            if n in [1,4,12,32]:
                sample_polys.append(dict(b=b,c=c,g=g,n=n,coefficients=fr))
        records.append(dict(b=b,c=c,g=g,stable_reference_label_scale=N,
                            stable_log_coefficients=[str(v) for v in stable],rows=rows))
        print(json.dumps(dict(b=b,c=c,g=g,rows=len(rows),seconds=time.time()-started)),flush=True)
    out=dict(status='completed diagnostic; not a general theorem',degree_cutoff=d,
             independent_coefficient_checks=checks,records=records,
             polynomial_samples=sample_polys,seconds=time.time()-started,
             source='https://arxiv.org/pdf/1208.2391',
             limitation='No finite experiment proves linear stabilization, zero-freeness, or Phi=L.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['records','polynomial_samples']}),flush=True)


if __name__=='__main__':run()
