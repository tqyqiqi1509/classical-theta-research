"""Exact arbitrary-endpoint check for the positive-copy proof.

Endpoint expressions are computed by signed factorization of the incoming
matrix followed by triangular transport; multiplication coefficients are
computed separately in the positive chart. This tests the two specific
interfaces used in STRUCTURE_RAY_POSITIVE_COPIES.md.
"""
from pathlib import Path
from fractions import Fraction
from itertools import product
import random, json, time
from stable_root_probe import IncomingSchur, box, le, sub, mul, power
from transverse_probe import add, inv, threshold
from structure_ray_binomial import exact_bound

ROOT = Path(__file__).resolve().parents[1]


def endpoint(R, label, covector, cap):
    J = box(cap)
    minus = {(p, p): 1 for p in J}
    nonnegative = dict(minus)
    for degree in J[1:]:
        lam = sum(a * b for a, b in zip(covector, degree))
        # A positive infinitesimal resolves any vanishing positive root.
        target = minus if lam < 0 else nonnegative
        for q in J:
            p = add(q, degree)
            if not le(p, cap):
                continue
            cross = sum(minus.get((p, r), 0) * nonnegative.get((r, q), 0)
                        for r in J if r != p and r != q and le(q, r) and le(r, p))
            value = R.c(degree, R.shift(label, q)) - cross
            if value:
                target[p, q] = value
    positive = R.theta_prefix(label, cap)
    answer = {}
    for p in J:
        value = positive.get(p, 0) - sum(minus.get((p, q), 0) * a
                                        for q, a in answer.items() if le(q, p))
        if value:
            answer[p] = value
    return answer


def many_structure(R, labels, cap):
    residual = {R.zero: 1}
    total = tuple(sum(g[i] for g in labels) for i in range(R.n))
    for label in labels:
        residual = mul(residual, R.theta_prefix(label, cap), cap)
    answer = {}
    for q in box(cap):
        c = residual.get(q, 0)
        if not c:
            continue
        answer[q] = c
        for s, a in R.theta_prefix(R.shift(total, q), sub(cap, q)).items():
            p = add(q, s)
            residual[p] = residual.get(p, 0) - c * a
    assert not any(residual.values())
    return answer


def run(trials=80):
    rng = random.Random(1131943)
    start = time.time()
    ray_checks = endpoint_dual_checks = difference_checks = 0
    examples = []
    for trial in range(trials):
        rank = 2 if trial < 20 else 3 if trial < 55 else 4
        D = [rng.randint(1, 3) for _ in range(rank)]
        B = [[0] * rank for _ in D]
        for i in range(rank):
            for j in range(i + 1, rank):
                b = rng.randint(-3, 3)
                B[i][j] = D[j] * b
                B[j][i] = -D[i] * b
        R = IncomingSchur(B, D)
        cap = (3, 2) if rank == 2 else (2, 1, 1) if rank == 3 else (1,) * rank
        J = box(cap); d = sum(cap)
        g = tuple(rng.randint(-3, 3) for _ in D)
        h = tuple(rng.randint(-3, 3) for _ in D)
        Q = tuple(rng.randint(-5, 5) for _ in D)
        N0 = threshold(R, g, h, cap)
        vals = [endpoint(R, tuple((N0 + k) * g[i] + h[i] for i in range(rank)), Q, cap)
                for k in range(d + 2)]
        ratio = mul(vals[1], inv(vals[0], cap), cap)
        for k, actual in enumerate(vals):
            expected = mul(vals[0], power(ratio, k, cap), cap)
            assert actual == expected, ('endpoint ray law', B, D, g, h, Q, N0, k)
            assert all(v >= 0 for v in actual.values())
            ray_checks += len(J)
        for p in J:
            row = [v.get(p, 0) for v in vals]
            for order in range(d + 2):
                assert row[0] >= 0, ('endpoint difference', B, D, g, h, Q, N0, p, order, row[0])
                assert order <= sum(p) or row[0] == 0
                difference_checks += 1
                row = [row[i + 1] - row[i] for i in range(len(row) - 1)]

        count = 3 + trial % 2
        directions = [tuple(rng.randint(-3, 3) for _ in D) for _ in range(count)]
        offsets = [tuple(rng.randint(-2, 2) for _ in D) for _ in range(count)]
        if trial % 3 == 0:
            directions[-1] = tuple(-sum(g[i] for g in directions[:-1]) for i in range(rank))
        N = exact_bound(R, directions, offsets, cap)
        structures = []
        for k in range(d + 2):
            labels = [tuple((N + k) * g[i] + h[i] for i in range(rank))
                      for g, h in zip(directions, offsets)]
            c = many_structure(R, labels, cap)
            structures.append(c)
            if k in (0, 1):
                total = tuple(sum(g[i] for g in labels) for i in range(rank))
                out = R.shift(total, cap)
                covector = tuple(D[i] * out[i] for i in range(rank))
                f = {R.zero: 1}
                for label in labels:
                    f = mul(f, endpoint(R, label, covector, cap), cap)
                assert f.get(cap, 0) == c.get(cap, 0), ('endpoint duality', B, D, labels, cap, f, c)
                endpoint_dual_checks += 1
        for p in J:
            row = [c.get(p, 0) for c in structures]
            for order in range(d + 2):
                assert row[0] >= 0, ('many-input difference', B, D, directions, offsets, N, p, order, row[0])
                assert order <= sum(p) or row[0] == 0
                difference_checks += 1
                row = [row[i + 1] - row[i] for i in range(len(row) - 1)]
        if trial % 10 == 9:
            print(json.dumps(dict(completed=trial + 1, seconds=round(time.time() - start, 2))), flush=True)
    out = dict(status='PASS', inputs=trials, exact_endpoint_ray_coefficient_checks=ray_checks,
               exact_dual_endpoint_checks=endpoint_dual_checks,
               exact_forward_difference_checks=difference_checks, seconds=time.time()-start)
    (ROOT / 'computation/arbitrary_endpoint_ray_results.json').write_text(json.dumps(out, indent=2))
    print(json.dumps(out), flush=True)


if __name__ == '__main__':
    run()
