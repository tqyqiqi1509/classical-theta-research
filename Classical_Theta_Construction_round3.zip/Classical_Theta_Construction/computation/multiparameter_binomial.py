"""Independent triangular theta multiplication check for mixed differences."""
from pathlib import Path
from math import comb
import json, random, time
from incoming_recursion import IncomingSchur, box
from transverse_probe import structure, threshold

ROOT = Path(__file__).resolve().parents[1]

def add(a,b): return tuple(x+y for x,y in zip(a,b))
def pair(a,b,D): return sum(x*y*d for x,y,d in zip(a,b,D))
def compatible(a,b,J,D):
    return all(pair(a,p,D)*pair(b,p,D)>=0 for p in J)

def run(trials=72):
    rng=random.Random(202611132050); started=time.time()
    checks=degree_checks=positive=0; examples=[]
    for trial in range(trials):
        n=2 if trial<24 else 3 if trial<56 else 4
        cap=(2,2) if n==2 else (2,1,1) if n==3 else (1,)*4
        J=box(cap); d=sum(cap)
        D=[rng.randint(1,3) for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                a=rng.randint(-3,3); B[i][j]=D[j]*a; B[j][i]=-D[i]*a
        while True:
            u1=tuple(rng.randint(-7,7) for _ in range(n))
            v1=tuple(-x for x in u1) if trial%3==0 else tuple(rng.randint(-7,7) for _ in range(n))
            du=tuple(rng.randint(-3,3) for _ in range(n))
            dv=tuple(-x for x in du) if trial%3==0 else tuple(rng.randint(-3,3) for _ in range(n))
            u2=tuple(11*x+y for x,y in zip(u1,du))
            v2=tuple(11*x+y for x,y in zip(v1,dv))
            if compatible(u1,u2,J,D) and compatible(v1,v2,J,D) and compatible(add(u1,v1),add(u2,v2),J,D): break
        hu=tuple(rng.randint(-3,3) for _ in range(n)); hv=tuple(rng.randint(-3,3) for _ in range(n))
        R=IncomingSchur(B,D); u=add(u1,u2); v=add(v1,v2)
        N0=max(threshold(R,u,hu,cap),threshold(R,v,hv,cap),threshold(R,add(u,v),add(hu,hv),cap))
        vals={}
        for k in range(d+2):
            for l in range(d+2-k):
                a=tuple(hu[i]+N0*u[i]+k*u1[i]+l*u2[i] for i in range(n))
                b=tuple(hv[i]+N0*v[i]+k*v1[i]+l*v2[i] for i in range(n))
                vals[k,l]=structure(R,a,b,cap)
        candidate=None
        for p in J:
            newton=[]
            for i in range(d+2):
                for j in range(d+2-i):
                    value=sum((-1)**(i+j-k-l)*comb(i,k)*comb(j,l)*vals[k,l].get(p,0)
                              for k in range(i+1) for l in range(j+1))
                    checks+=1; positive+=value>0
                    if i+j>sum(p): degree_checks+=1
                    if value<0 or i+j>sum(p) and value:
                        result=dict(status='FAIL',B=B,D=D,cap=cap,u1=u1,u2=u2,v1=v1,v2=v2,hu=hu,hv=hv,N0=N0,p=p,order=[i,j],value=value)
                        (ROOT/'computation/multiparameter_binomial_results.json').write_text(json.dumps(result,indent=2))
                        print(json.dumps(result),flush=True); return
                    if value: newton.append([i,j,value])
            if any(i and j for i,j,c in newton): candidate=dict(p=p,positive_newton_terms=newton)
        if candidate and len(examples)<8:
            examples.append(dict(B=B,D=D,cap=cap,u1=u1,u2=u2,v1=v1,v2=v2,hu=hu,hv=hv,N0=N0,**candidate))
        R.c.cache_clear(); R.sign.cache_clear()
        if trial%12==11: print(json.dumps(dict(completed=trial+1,checks=checks,seconds=round(time.time()-started,2))),flush=True)
    result=dict(status='PASS',inputs=trials,exact_mixed_difference_checks=checks,total_degree_zero_checks=degree_checks,positive_mixed_values=positive,examples=examples,seconds=time.time()-started)
    (ROOT/'computation/multiparameter_binomial_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result),flush=True)

if __name__=='__main__': run()
