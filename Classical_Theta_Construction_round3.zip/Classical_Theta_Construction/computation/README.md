# 可直接运行的经典 theta 计算

这里的入口是 `theta_cli.py`。它使用显式有限整数递推，不需要预先输入散射图、
折线列表、潜势或 Hall 代数。计算只针对经典主系数情形；约定

\[
\vartheta_g=x^gF_g(z),\qquad z_i=y_i x^{Be_i},\qquad DB=-(DB)^T.
\]

除可选的 `envelope` 模式需要 `python-flint` 外，只需 Python 3.10 或更新版本。
所有索引从 0 开始。不给 D 时会自动求正整数斜对称化矩阵。

## 指定一个精确系数

```bash
python computation/theta_cli.py --json '{"mode":"coefficient","B":[[0,2,-2],[-2,0,2],[2,-2,0]],"g":[-1,-1,-1],"p":[2,2,2]}'
```

输出该系数为 23。这不是完整 Laurent 多项式的声明。

## 完整 Laurent 多项式：有证明的停止条件

```bash
python computation/theta_cli.py --json '{"mode":"complete","B":[[0,3],[-2,0]],"g":[-2,2]}'
```

程序逐个删除源点，更新核心标签，给出每个变量的严格次数界；如果删除完毕，
或者剩余任意循环核心的标签已经非负，就返回完整多项式及停止证书。
这覆盖所有无环初始矩阵，并允许其后接任意循环核心。
若该方法不能给出界，程序明确返回“没有停止证书”，不推断无限性。

每一项同时输出根次数、mutable 指数、frozen 指数和整数系数。
完整结果另外通过所有相邻种子的 Laurent 整除检查。

## 循环输入的有限变异词停止证书

```bash
python agents/support_accessibility_fresh/zero_endpoint_support_certificate.py --input agents/support_accessibility_fresh/zero_endpoint_cyclic_example.json --complete
```

此入口另外需要 SymPy。输入 B、g 和有限组原顶点变异词，程序自动包括全部
前缀，构造热带次数非负约束；有界时给出每个上界的精确非负对偶证书，随后
计算整个有限区域内的系数。指定样本返回 18 项完整 Laurent 多项式。所有
96 个对偶上界恒等式已有独立 Wolfram 核验。一般输入同样可运行；成功只
取决于输入词集是否给出有界域，未成功时不判断 theta 无限。

代码及完整说明在 `agents/support_accessibility_fresh/ZERO_ENDPOINT_CERTIFICATE_RUN.md`。
空词集不给支持上界；精确有理后端可能较慢，算法不声称多项式时间。
固定词集的有界性实际上与 g 无关：一次成功给出该 B 全部标签可复用的
充分构造条件。这不是逐个正则标签的完备判定法。支持不等式已直接归约到
GHKK 的热带凸性与系数检测机制，程序的实用性不作为新颖性证明。

## 全混合除幂导子

```bash
python computation/theta_cli.py --json '{"mode":"derivative","B":[[0,2],[-2,0]],"g":[-2,2],"r":[1,0],"cap":[2,2]}'
```

计算

\[
\prod_i\frac{x_i^{r_i}}{r_i!}\partial_{y_i}^{r_i}\vartheta_g
=\sum_q d_{g;r,q}y^q\vartheta_{g+(I+B)r+Bq}.
\]

`cap` 限定输出分支 q 的有限盒；所有返回的分支系数都是精确值。
它不宣称盒外没有分支。

## 乘法及降秩切片

```bash
python computation/theta_cli.py --json '{"mode":"product","B":[[0,2],[-2,0]],"labels":[[-1,1],[-1,1]],"cap":[2,2]}'
python computation/theta_cli.py --json '{"mode":"slice","B":[[0,0,-2],[0,0,1],[2,-1,0]],"g":[1,-3,-1],"index":0,"degree":1,"cap":[1,1]}'
```

`slice` 返回固定一个根变量次数后，在剩余子矩阵 theta 基中的非负展开。
其 `cap` 长度为秩减一，按剩余索引的升序排列。

## 有有限 theta 展开前提的 Newton 包络搜索

```bash
python computation/theta_cli.py --json '{"mode":"envelope","B":[[0,1,-1],[-1,0,1],[1,-1,0]],"g":[-1,0,0],"max_radius":3,"proved_finite_theta_span":true}'
```

这一模式需要已经证明 middle=upper，或者另有候选函数的有限 theta 展开证书。
`proved_finite_theta_span` 是使用者提供的数学前提，程序不会替你证明它。
满足该前提时，相邻 Laurent 整除的任意有符号解给出 theta 的 Newton 包络，
随后有限系数规则得到完整答案。搜索达到资源上限仍未成功是“不确定”。

## Q 原点代数：独立于整数递推的第二个入口

`agents/support_accessibility_fresh/universal_unit_coefficient.py` 直接构造本轮
T 一次幂的符号单位余式代数，用 SymPy 完成实际边界饱和，再由有限 Macaulay
矩阵求原点长度。它支持 `theta_coefficient(B,g,p)` 和
`derivative_branch(B,g,r,q)`，详见同目录 `UNIVERSAL_UNIT_RUN.md`。
这里的符号计算可能很慢；已完成计算与主动中断的计算分别记在运行记录中。

## Newton 面的整数归一化入口

`agents/newton_faces_fresh_final/normalize_bongartz_face.py` 只用 Python 标准库。
输入 B、g、最大面法向 w 和一条经检验的优化路径，输出 p、S、低秩交换矩阵
和标签 h，使面多项式为 z^p F_h(z^S)。可选输入低秩项或顶点时，必须使用
返回的规范化低秩种子。原终点种子的低秩多面体应使用同目录的
`initial_face_transform.py` 正有理电路接口，不能混用两种输入。

## 文件与资源限制

规范面矩阵还可预计算：`agents/face_graded_algebra/canonical_face_toric.py`
使用 C/F 矩阵输出完整初始单项式映射，对每个完整标签返回锚点和低秩标签，
并提供最小乘法输出的双向标签变换。完整 frozen 指数始终保留。

也可以用 `--input request.json --output answer.json`。
默认根盒最多 20000 个格点；可显式提高 `--max-states`。
该限制只是计算资源限制，和数学上的有限性无关。算法是准确的有限算法，
没有宣称多项式时间复杂度。

`portable_cli_checks.json` 保存了 64 个独立交换关系核对，以及循环、斜对称化、
正切片、乘法和条件包络接口的回归记录。大规模独立核对保留在各研究分支的
Python、Wolfram 与 JSON 文件中；证明并不由这些样本替代。
