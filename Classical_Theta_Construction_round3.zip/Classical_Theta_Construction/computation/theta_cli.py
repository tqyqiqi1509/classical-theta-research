"""Portable exact calculations for classical principal-coefficient theta functions.

Python 3.10+, standard library.  The adjacent-Laurent envelope mode additionally
uses python-flint and an explicitly supplied mathematical finite-span premise.
Every bounded prefix is labelled as such; zero tails are never guessed.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
from functools import lru_cache, reduce
from itertools import product
import json
from math import comb, gcd, lcm, prod
from pathlib import Path
import sys

from incoming_recursion import IncomingSchur, box, le, sub


def integer_vector(value, n, name, nonnegative=False):
    if (not isinstance(value, list) or len(value) != n
            or any(type(v) is not int for v in value)):
        raise ValueError(f'{name} must be an integer vector of length {n}.')
    if nonnegative and any(v < 0 for v in value):
        raise ValueError(f'{name} must be nonnegative.')
    return tuple(value)


def symmetrizer(B):
    """Find an integral positive symmetrizer, or reject the input."""
    n = len(B)
    values = [None] * n
    for start in range(n):
        if values[start] is not None:
            continue
        values[start] = Fraction(1)
        todo = [start]
        while todo:
            i = todo.pop()
            for j in range(n):
                if not B[i][j]:
                    if B[j][i]:
                        raise ValueError('B has asymmetric zero entries.')
                    continue
                if B[i][j] * B[j][i] >= 0:
                    raise ValueError('Opposite nonzero entries must have opposite signs.')
                candidate = -values[i] * Fraction(B[i][j], B[j][i])
                if values[j] is None:
                    values[j] = candidate
                    todo.append(j)
                elif values[j] != candidate:
                    raise ValueError('B is not skew-symmetrizable.')
    denominator = lcm(*(v.denominator for v in values))
    integers = [int(v * denominator) for v in values]
    divisor = reduce(gcd, integers)
    return tuple(v // divisor for v in integers)


class Calculator:
    def __init__(self, request, max_states=20000):
        B = request.get('B')
        if (not isinstance(B, list) or not B
                or any(not isinstance(row, list) or len(row) != len(B) for row in B)
                or any(type(v) is not int for row in B for v in row)):
            raise ValueError('B must be a nonempty square integer matrix.')
        self.n = len(B)
        if any(B[i][i] != 0 for i in range(self.n)):
            raise ValueError('B must have zero diagonal.')
        self.B = tuple(map(tuple, B))
        self.D = (integer_vector(request['D'], self.n, 'D')
                  if 'D' in request else symmetrizer(B))
        if any(v <= 0 for v in self.D) or any(
                self.D[i] * B[i][j] != -self.D[j] * B[j][i]
                for i in range(self.n) for j in range(self.n)):
            raise ValueError('D must be positive integral and DB skew-symmetric.')
        self.R = IncomingSchur(self.B, self.D)
        self.max_states = max_states
        self.zero = (0,) * self.n

    def guard(self, cap):
        states = prod(v + 1 for v in cap)
        if states > self.max_states:
            raise ValueError(f'Request needs {states} root-box states; resource limit is '
                             f'{self.max_states}. Increase --max-states explicitly. '
                             'This resource limit says nothing about Laurent finiteness.')

    @lru_cache(maxsize=None)
    def prefix(self, g, cap):
        self.guard(cap)
        answer = self.R.theta_prefix(g, cap)
        if any(type(v) is not int or v < 0 for v in answer.values()):
            raise ArithmeticError('A theta coefficient failed the nonnegative-integer check.')
        return answer

    def coefficient(self, g, p):
        return self.prefix(g, p).get(p, 0)

    def shift(self, g, p):
        return self.R.shift(g, p)

    def terms(self, g, F):
        return [{'root_degree': list(p), 'coefficient': a,
                 'mutable_exponents': list(self.shift(g, p)),
                 'frozen_exponents': list(p)}
                for p, a in sorted(F.items(), key=lambda item: (sum(item[0]), item[0]))]

    def source_certificate(self, g):
        remaining = list(range(self.n))
        current = list(g)
        cap = [None] * self.n
        steps = []
        while remaining:
            if all(current[i] >= 0 for i in remaining):
                for i in remaining:
                    cap[i] = 0
                return {'complete': True, 'support_box': cap, 'steps': steps,
                        'terminal_core': remaining,
                        'terminal_label': [current[i] for i in remaining],
                        'reason': 'The remaining core label is nonnegative.'}
            k = next((i for i in remaining
                      if all(self.B[i][j] >= 0 for j in remaining)), None)
            if k is None:
                return {'complete': False, 'partial_caps': cap, 'steps': steps,
                        'unresolved_core': remaining,
                        'core_label': [current[i] for i in remaining],
                        'reason': 'Source peeling leaves a cyclic core with a negative label. '
                                  'This is not evidence of infinite support.'}
            t = max(-current[k], 0)
            cap[k] = t
            remaining.remove(k)
            before = [current[i] for i in remaining]
            for j in remaining:
                current[j] += self.B[j][k] * t
            steps.append({'source': k, 'exact_degree': t, 'remaining': remaining[:],
                          'label_before': before,
                          'label_after': [current[i] for i in remaining]})
        return {'complete': True, 'support_box': cap, 'steps': steps,
                'terminal_core': [], 'terminal_label': [],
                'reason': 'All vertices were removed as sources.'}

    def adjacent_laurent_check(self, g, F, cap):
        for i in range(self.n):
            others = [j for j in range(self.n) if j != i]
            for values in product(*(range(cap[j] + 1) for j in others)):
                p = [0] * self.n
                for j, v in zip(others, values):
                    p[j] = v
                needed = max(0, -g[i] - sum(self.B[i][j] * p[j] for j in others))
                for s in range(min(needed, cap[i] + 1)):
                    total = 0
                    for u in range(s, cap[i] + 1):
                        p[i] = u
                        total += (-1) ** (u - s) * comb(u, s) * F.get(tuple(p), 0)
                    if total:
                        raise ArithmeticError('Complete result fails an adjacent Laurent condition.')
        return True

    def derivative_branches(self, g, r, cap):
        large = tuple(r[i] + cap[i] for i in range(self.n))
        original = self.prefix(g, large)
        h = tuple(self.shift(g, r)[i] + r[i] for i in range(self.n))
        result = {}
        for q in box(cap):
            degree = tuple(q[i] + r[i] for i in range(self.n))
            value = prod(comb(degree[i], r[i]) for i in range(self.n)) * original.get(degree, 0)
            for s, b in result.items():
                if le(s, q):
                    value -= b * self.coefficient(self.shift(h, s), sub(q, s))
            if value < 0:
                raise ArithmeticError('A positive-shear branch is negative.')
            if value:
                result[q] = value
        return h, result

    def product_branches(self, labels, cap):
        convolution = {self.zero: 1}
        for g in labels:
            following = {}
            for p, a in convolution.items():
                for q, b in self.prefix(g, cap).items():
                    s = tuple(p[i] + q[i] for i in range(self.n))
                    if le(s, cap):
                        following[s] = following.get(s, 0) + a * b
            convolution = following
        h = tuple(sum(g[i] for g in labels) for i in range(self.n))
        result = {}
        for q in box(cap):
            value = convolution.get(q, 0)
            for s, b in result.items():
                if le(s, q):
                    value -= b * self.coefficient(self.shift(h, s), sub(q, s))
            if value < 0:
                raise ArithmeticError('A theta product coefficient is negative.')
            if value:
                result[q] = value
        return h, result

    def slice_branches(self, g, i, k, cap):
        if self.n < 2 or type(i) is not int or not 0 <= i < self.n or type(k) is not int or k < 0:
            raise ValueError('slice requires rank >= 2, 0 <= index < rank, and degree >= 0.')
        J = [j for j in range(self.n) if j != i]
        subcalc = Calculator({'B': [[self.B[j][l] for l in J] for j in J],
                              'D': [self.D[j] for j in J]}, self.max_states)
        h = tuple(g[j] + self.B[j][i] * k for j in J)
        large = [k if j == i else cap[J.index(j)] for j in range(self.n)]
        original = self.prefix(g, tuple(large))
        result = {}
        for q in box(cap):
            p = [k if j == i else q[J.index(j)] for j in range(self.n)]
            value = original.get(tuple(p), 0)
            for s, b in result.items():
                if le(s, q):
                    value -= b * subcalc.coefficient(subcalc.shift(h, s), sub(q, s))
            if value < 0:
                raise ArithmeticError('A positive slice branch is negative.')
            if value:
                result[q] = value
        return J, h, result, subcalc


def run(request, max_states=20000):
    calc = Calculator(request, max_states)
    n = calc.n
    mode = request.get('mode', 'coefficient')
    base = {'mode': mode, 'B': calc.B, 'D': calc.D,
            'convention': 'theta_g=x^g sum_p a_g(p) z^p; z_i=y_i x^(B e_i)',
            'arithmetic': 'exact integers'}
    if mode == 'product':
        if not isinstance(request.get('labels'), list) or not request['labels']:
            raise ValueError('product needs a nonempty labels list.')
        labels = [integer_vector(g, n, 'label') for g in request['labels']]
        cap = integer_vector(request['cap'], n, 'cap', True)
        h, branches = calc.product_branches(labels, cap)
        return {**base, 'status': 'exact structure constants within the specified root box',
                'cap': cap, 'labels': labels,
                'branches': [{'q': q, 'coefficient': c, 'frozen_multiplier': q,
                              'theta_label': calc.shift(h, q)} for q, c in branches.items()]}
    g = integer_vector(request.get('g'), n, 'g')
    base['g'] = g
    if mode == 'coefficient':
        p = integer_vector(request['p'], n, 'p', True)
        return {**base, 'status': 'exact prescribed coefficient', 'p': p,
                'coefficient': calc.coefficient(g, p)}
    if mode == 'prefix':
        cap = integer_vector(request['cap'], n, 'cap', True)
        return {**base, 'status': 'truncated root box; no assertion of complete support',
                'cap': cap, 'terms': calc.terms(g, calc.prefix(g, cap))}
    if mode == 'complete':
        certificate = calc.source_certificate(g)
        if not certificate['complete']:
            return {**base, 'status': 'no stopping certificate from this method',
                    'certificate': certificate}
        cap = tuple(certificate['support_box'])
        F = calc.prefix(g, cap)
        calc.adjacent_laurent_check(g, F, cap)
        return {**base, 'status': 'complete Laurent polynomial', 'certificate': certificate,
                'adjacent_laurent_check': 'PASS', 'terms': calc.terms(g, F)}
    if mode == 'derivative':
        r = integer_vector(request['r'], n, 'r', True)
        cap = integer_vector(request['cap'], n, 'cap', True)
        h, branches = calc.derivative_branches(g, r, cap)
        return {**base, 'status': 'exact divided-derivative branches in the specified root box',
                'r': r, 'cap': cap,
                'operator': 'product_i x_i^r_i partial_y_i^r_i / r_i!',
                'branches': [{'q': q, 'coefficient': c, 'frozen_multiplier': q,
                              'theta_label': calc.shift(h, q)} for q, c in branches.items()]}
    if mode == 'slice':
        cap = integer_vector(request['cap'], n - 1, 'cap', True)
        J, h, branches, subcalc = calc.slice_branches(g, request['index'], request['degree'], cap)
        return {**base, 'status': 'exact positive lower-rank slice branches in the specified box',
                'remaining_indices': J, 'index': request['index'], 'degree': request['degree'],
                'cap': cap, 'core_B': subcalc.B,
                'branches': [{'q': q, 'coefficient': c, 'root_multiplier': q,
                              'theta_label': subcalc.shift(h, q)} for q, c in branches.items()]}
    if mode == 'envelope':
        if request.get('proved_finite_theta_span') is not True:
            raise ValueError('Envelope mode requires proved_finite_theta_span=true, representing '
                             'a previously proved middle=upper theorem or a finite theta expansion '
                             'certificate. The calculator does not prove this premise.')
        from finite_envelope import construct_theta
        radius = request.get('max_radius', 4)
        if type(radius) is not int or radius < 0:
            raise ValueError('max_radius must be a nonnegative integer.')
        calc.guard((radius,) * n)
        return {**base, **construct_theta([list(row) for row in calc.B], list(calc.D), list(g),
                                         max_radius=radius, finite_theta_span=True)}
    raise ValueError('Unknown mode: ' + str(mode))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--input', type=Path, help='JSON request file')
    group.add_argument('--json', help='JSON request string')
    parser.add_argument('--output', type=Path, help='Write JSON result to this path')
    parser.add_argument('--max-states', type=int, default=20000)
    args = parser.parse_args()
    try:
        request = json.loads(args.input.read_text() if args.input else args.json)
        answer = run(request, args.max_states)
        payload = json.dumps(answer, ensure_ascii=False, indent=2) + '\n'
        if args.output:
            args.output.write_text(payload)
        else:
            print(payload, end='')
    except (ValueError, KeyError, ArithmeticError, ImportError) as error:
        print(json.dumps({'status': 'not completed', 'reason': str(error)}, ensure_ascii=False),
              file=sys.stderr)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
