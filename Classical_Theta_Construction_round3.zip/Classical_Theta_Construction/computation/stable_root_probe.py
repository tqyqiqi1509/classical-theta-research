"""Independently compute the coarse negative factor and test ray stabilization."""
from pathlib import Path
import sys,json,random,time
from fractions import Fraction
from itertools import product
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
sys.path.insert(0,str(OLD))
from incoming_recursion import IncomingSchur,box,le,sub

def mul(a,b,cap):
    out={}
    for p,v in a.items():
        for q,w in b.items():
            t=tuple(x+y for x,y in zip(p,q))
            if le(t,cap):out[t]=out.get(t,0)+v*w
    return {p:v for p,v in out.items() if v}

def power(a,n,cap):
    r={(0,)*len(cap):1}
    while n:
        if n&1:r=mul(r,a,cap)
        a=mul(a,a,cap);n//=2
    return r

def stable_root(B,D,g,cap):
    R=IncomingSchur(B,D);J=box(cap);z=(0,)*len(g)
    neg={(a,a):1 for a in J}; nonneg=dict(neg)
    for deg in J[1:]:
        for q in J:
            p=tuple(a+b for a,b in zip(q,deg))
            if not le(p,cap):continue
            v=R.c(deg,R.shift(g,q))-sum(neg.get((p,r),0)*nonneg.get((r,q),0)
                    for r in J if r!=p and r!=q and le(q,r) and le(r,p))
            if v:
                target=neg if sum(g[i]*D[i]*deg[i] for i in range(len(g)))<0 else nonneg
                target[p,q]=v
    H={p:neg[p,z] for p in J if neg.get((p,z),0)}
    bound=Fraction(0)
    for s in J:
        Bs=R.shift(z,s)
        for alpha in J[1:]:
            denominator=sum(g[i]*D[i]*alpha[i] for i in range(len(g)))
            if denominator:
                v=abs(Fraction(sum(Bs[i]*D[i]*alpha[i] for i in range(len(g))),denominator))
                bound=max(bound,v)
    threshold=bound.numerator//bound.denominator+1
    return H,threshold,R

def run(trials=60):
    rng=random.Random(1441);start=time.time();checks=0;examples=[];maxthreshold=0
    data=[([[0,2],[-2,0]],[1,1],[-1,1],(4,4))]
    for k in range(trials):
        n=2 if k<15 else 3 if k<45 else 4
        D=[rng.randint(1,3) for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                v=rng.randint(-3,3);B[i][j]=D[j]*v;B[j][i]=-D[i]*v
        g=[rng.randint(-3,3) for _ in range(n)]
        cap=(3,2) if n==2 else (2,1,1) if n==3 else (1,1,1,1)
        data.append((B,D,g,cap))
    for idx,(B,D,g,cap) in enumerate(data):
        H,T,R=stable_root(B,D,g,cap);maxthreshold=max(maxthreshold,T)
        for n in [T,T+1,2*T+3]:
            theta=R.theta_prefix(tuple(n*v for v in g),cap)
            pred=power(H,n,cap)
            if theta!=pred:
                out={'status':'FAIL','B':B,'D':D,'g':g,'cap':cap,'n':n,'threshold':T,
                    'H':[[list(p),str(c)] for p,c in H.items()],
                    'differences':[[p,theta.get(p,0),pred.get(p,0)] for p in box(cap) if theta.get(p,0)!=pred.get(p,0)]}
                (ROOT/'computation/stable_root_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out));return
            checks+=len(box(cap))
        if idx<4 or any(v<0 for v in H.values()) and len(examples)<8:
            examples.append({'B':B,'D':D,'g':g,'cap':cap,'threshold':T,
                             'stable_root_terms':[[list(p),v] for p,v in H.items()]})
    out={'status':'PASS','inputs':len(data),'coefficient_checks':checks,'largest_threshold':maxthreshold,
         'examples':examples,'seconds':time.time()-start}
    (ROOT/'computation/stable_root_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

if __name__=='__main__':run()
