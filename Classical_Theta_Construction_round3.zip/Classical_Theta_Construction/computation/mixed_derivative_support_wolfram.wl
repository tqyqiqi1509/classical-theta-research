ClearAll[bx,leq,sgn,cc,tf,at];
bx[a_List]:=SortBy[Tuples[Range[0,#]&/@a],{Total,Identity}];
leq[a_List,b_List]:=And@@Thread[a<=b];
at[a_Association,p_List]:=Lookup[a,ToString[p,InputForm],0];
sgn[b_List,d_List,a_List,q_List]:=Module[{v,j,vals},
 v=(b.a).(d*q);If[v!=0,Return[Sign[v]]];
 j=First@FirstPosition[a,_?(#>0&)];
 vals=Select[Table[a[[j]]q[[i]]-a[[i]]q[[j]],{i,Length[a]}],#!=0&];
 If[vals=={},0,Sign[First[vals]]]];
cc[b_List,d_List,a_List,m_List]:=cc[b,d,a,m]=Module[{s,ss,v=<||>,ans=0,i},
 If[Total[a]==0,Return[1]];
 s=Flatten@Position[a,_?(#>0&)];
 If[Length[s]==1,i=First[s];Return[Binomial[-m[[i]],a[[i]]]]];
 ss=Select[bx[a],#!=a&&Total[#]>0&&sgn[b,d,a,#]>0&];
 Do[AssociateTo[v,ToString[t,InputForm]->(cc[b,d,t,m]-Total[
 Table[If[leq[q,t]&&q!=t,cc[b,d,t-q,m+b.q] at[v,q],0],{q,ss}]] )],{t,ss}];
 Total[Table[cc[b,d,a-t,m+b.t] at[v,t],{t,ss}]]];
tf[b_List,d_List,g_List,cap_List]:=Module[{j=bx[cap],f=<||>,ii,t,mp,qq},
 AssociateTo[f,ToString[ConstantArray[0,Length[g]],InputForm]->1];
 Do[mp=g+b.p;ii=Select[j,leq[#,p]&&(#==p||mp.(d*(p-#))<0)&];
 t=<|ToString[p,InputForm]->1|>;
 Do[AssociateTo[t,ToString[q,InputForm]->(-Total[
 Table[If[u!=q&&leq[q,u],at[t,u] cc[b,d,u-q,g+b.q],0],{u,ii}]])],
 {q,Reverse[Most[ii]]}];
 AssociateTo[f,ToString[p,InputForm]->(-Total[Table[at[t,q]at[f,q],{q,Most[ii]}]])],
 {p,Rest[j]}];f];
SeedRandom[2611132341];
Module[{checks=0,nonzero=0,fail={},b,d,g,r,p,cap,f,h,fh,lhs,rhs,k,n,val,
 leafChecks=0,e,em,aa,uu,vv,idx,old,delta},
 Do[n=spec[[1]];Do[
 d=RandomInteger[{1,3},n];b=ConstantArray[0,{n,n}];
 Do[val=RandomInteger[{-2,2}]LCM[d[[i]],d[[j]]];
 b[[i,j]]=val/d[[i]];b[[j,i]]=-val/d[[j]],{i,n},{j,i+1,n}];
 g=RandomInteger[{-3,3},n];r=ConstantArray[0,n];
 Do[r[[RandomInteger[{1,n}]]]++,{2}];cap=r+ConstantArray[1,n];
 f=tf[b,d,g,cap];h=g+r+b.r;fh=If[at[f,r]>0,tf[b,d,h,ConstantArray[1,n]],<||>];
 Do[lhs=Times@@MapThread[Binomial,{p+r,r}] at[f,p+r];rhs=at[f,r]at[fh,p];
 checks++;If[lhs!=0||rhs!=0,nonzero++];If[lhs<rhs,AppendTo[fail,{b,d,g,r,p,lhs,rhs}]],
 {p,bx[ConstantArray[1,n]]}];
 aa=n+1;uu=n+2;vv=n+3;idx=RandomInteger[{1,n}];
 e=ConstantArray[0,{n+3,n+1}];e[[1;;n,1;;n]]=b;
 e[[aa,idx]]=1;e[[idx,aa]]=-1;e[[uu,aa]]=1;e[[vv,aa]]=-1;
 em=Table[If[i==aa||j==aa,-e[[i,j]],e[[i,j]]+
 (Abs[e[[i,aa]]]e[[aa,j]]+e[[i,aa]]Abs[e[[aa,j]]])/2],{i,n+3},{j,n+1}];
 leafChecks++;If[!(em[[1;;n,1;;n]]===b&&em[[uu,1;;n]]===UnitVector[n,idx]&&
 em[[vv,1;;n]]===ConstantArray[0,n]&&em[[aa,1;;n]]===-UnitVector[n,idx]&&
 DiagonalMatrix[Append[d,d[[idx]]]].e[[1;;n+1,1;;n+1]]===
 -Transpose[DiagonalMatrix[Append[d,d[[idx]]]].e[[1;;n+1,1;;n+1]]]),
 AppendTo[fail,{"leaf",n,idx,e,em}]],
 {spec[[2]]}],{spec,{{2,40},{3,30},{4,15},{5,5}}}];
 <|"status"->If[fail=={},"PASS","FAIL"],"coefficientChecks"->checks,
 "nonzeroChecks"->nonzero,"leafMutationChecks"->leafChecks,
 "failures"->fail|>]

