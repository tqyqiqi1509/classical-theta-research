"""Independent exact comparison of signed-endpoint Q quotients and transport.

The construction reads only B,D,g,p and signed integer endpoint exponents.
The signed incoming-factor transport is used solely as a separate oracle.
"""
from pathlib import Path
import json, time
from quiver_polynomial_staircase import polynomial_coefficient_algebra
from incoming_recursion import IncomingSchur
from arbitrary_endpoint_ray import endpoint


def run():
    cases=[
      ([[0]],[1],[3],[2],[-1]),
      ([[0]],[1],[-3],[2],[-1]),
      ([[0,1],[-1,0]],[1,1],[-2,1],[1,1],[-1,2]),
      ([[0,1],[-1,0]],[1,1],[-2,1],[1,1],[2,-1]),
      ([[0,1],[-1,0]],[1,1],[1,-2],[2,1],[-1,3]),
      ([[0,2],[-2,0]],[1,1],[-1,-1],[1,1],[-1,3]),
      ([[0,3],[-2,0]],[2,3],[-2,1],[2,1],[-1,3]),
      ([[0,3],[-2,0]],[2,3],[1,-2],[1,2],[4,-1]),
      ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-1,-1],[1,1,1],[-1,2,4]),
      ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-2,0],[2,1,1],[1,-3,8]),
    ]
    out=[]
    for B,D,g,p,a in cases:
        try:
            row=polynomial_coefficient_algebra(B,D,g,p,row_exponents=a)
        except AssertionError as exc:
            out.append({'B':B,'D':D,'g':g,'p':p,'a':a,'status':'skipped_nongeneric','reason':str(exc)})
            continue
        expected=endpoint(IncomingSchur(B,D),tuple(g),tuple(D[i]*a[i] for i in range(len(B))),tuple(p)).get(tuple(p),0)
        row.update(a=a,independent_transport_coefficient=expected,passed=row['coefficient']==expected)
        out.append(row)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
        print(json.dumps({k:row[k] for k in ('g','p','a','coefficient','independent_transport_coefficient','passed','seconds')}),flush=True)
        assert row['passed'],row
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':run()
