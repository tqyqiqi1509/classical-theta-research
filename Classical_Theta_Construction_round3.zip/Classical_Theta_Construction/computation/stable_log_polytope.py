"""Exact finite scattering polytopes from stable theta logarithms.

Floating point LP is only a search device. Every feasibility decision has an
exact rational primal or Farkas certificate. All algebra, slopes, jump tests,
and convexity tests use Fraction. This checks a general mechanism, not just
finite type cluster fans. No representation-theoretic module is an input.
"""
from pathlib import Path
import sys, json, time, random, argparse
from fractions import Fraction as Q
from itertools import product
from math import gcd, lcm
import numpy as np
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
sys.path.insert(0,str(OLD))
from incoming_recursion import IncomingSchur,le,sub

def dot(x,y): return sum(a*b for a,b in zip(x,y))
def add(x,y): return tuple(a+b for a,b in zip(x,y))
def primitive(a):
    d=gcd(*a)
    return tuple(x//d for x in a)

def roots(n,N):
    return sorted((a for a in product(range(N+1),repeat=n) if sum(a)<=N),key=lambda a:(sum(a),a))

def rationalize(v):
    return tuple(Q(float(x)).limit_denominator(10**7) for x in v)

def feasible(A,n,stats):
    """Decide A*x>=1, with an exact certificate for either answer."""
    if not A:return (1,)*n
    r=linprog(np.zeros(n),A_ub=-np.array(A,dtype=float),b_ub=-np.ones(len(A)),
              bounds=[(None,None)]*n,method='highs')
    if r.success:
        v=rationalize(r.x)
        if all(dot(a,v)>=1 for a in A):
            den=lcm(*(x.denominator for x in v));stats['primal_certificates']+=1
            return tuple(int(x*den) for x in v)
        raise AssertionError(('uncertified primal',A,r.x))
    # Farkas: a nonzero nonnegative combination of the rows equals zero.
    f=linprog(np.zeros(len(A)),A_eq=np.array(list(zip(*A))+[tuple([1]*len(A))],dtype=float),
              b_eq=np.array([0]*n+[1],dtype=float),bounds=[(0,None)]*len(A),method='highs')
    assert f.success,('LP failure, no certificate',A,r.message,f.message)
    y=rationalize(f.x)
    assert min(y)>=0 and sum(y)==1 and all(sum(y[i]*A[i][j] for i in range(len(A)))==0 for j in range(n)),('uncertified Farkas',A,y)
    stats['farkas_certificates']+=1
    return None

def chambers(normals,n):
    stats={'primal_certificates':0,'farkas_certificates':0}
    C={(): (1,)*n}
    for a in normals:
        out={}
        for signs,g in C.items():
            base=[tuple(s*x for x in b) for s,b in zip(signs,normals)]
            for s in [-1,1]:
                v=feasible(base+[tuple(s*x for x in a)],n,stats)
                if v is not None:out[signs+(s,)]=v
        C=out
    return C,stats

def multiply(a,b,Jset):
    ans={}
    for p,v in a.items():
        for q,w in b.items():
            t=add(p,q)
            if t in Jset:ans[t]=ans.get(t,Q(0))+v*w
    return {p:v for p,v in ans.items() if v}

def logarithm(F,J,N):
    zero=J[0];f=dict(F);f.pop(zero,None);out={};power=f;Jset=set(J)
    for k in range(1,N+1):
        for p,v in power.items():out[p]=out.get(p,Q(0))+Q((-1)**(k-1),k)*v
        power=multiply(power,f,Jset)
        if not power:break
    return {p:v for p,v in out.items() if v}

class LogPolytope:
    def __init__(self,B,D,N):
        self.B=B;self.D=D;self.N=N;self.n=len(D);self.J=roots(self.n,N)
        self.Jset=set(self.J);self.zero=(0,)*self.n
        self.normal_roots=sorted(set(primitive(a) for a in self.J[1:]),key=lambda a:(sum(a),a))
        self.normals=[tuple(d*x for d,x in zip(D,a)) for a in self.normal_roots]
        self.R=IncomingSchur(B,D)
        self.intervals=[]
        for beta in self.J[1:]:
            for q in self.J:
                p=add(q,beta)
                if p not in self.Jset:continue
                mids=[r for r in self.J if r!=p and r!=q and le(q,r) and le(r,p)]
                self.intervals.append((p,q,beta,mids))
        self.C=[]
        for i in range(self.n):
            e=tuple(int(j==i) for j in range(self.n))
            self.C.append({(p,q):self.R.c(beta,self.R.shift(e,q)) for p,q,beta,_ in self.intervals})

    def gradient_series(self,g):
        ans=[]
        for Ci in self.C:
            neg={(a,a):1 for a in self.J};pos=dict(neg)
            for p,q,beta,mids in self.intervals:
                v=Ci[p,q]-sum(neg.get((p,r),0)*pos.get((r,q),0) for r in mids)
                if v:
                    if dot(g,tuple(d*x for d,x in zip(self.D,beta)))<0:neg[p,q]=v
                    else:pos[p,q]=v
            H={p:neg[p,self.zero] for p in self.J if neg.get((p,self.zero),0)}
            ans.append(logarithm(H,self.J,self.N))
        return ans

    def specialize(self,U,w=None):
        w=w or [1]*self.n
        degree=max(dot(w,p) for p in self.J)
        ans=[]
        for Ui in U:
            v=[Q(0)]*(degree+1)
            for p,c in Ui.items():v[dot(w,p)]+=c
            ans.append(v)
        return ans

def evaluate(v,t):
    ans=Q(0)
    for c in reversed(v):ans=ans*t+c
    return ans

def check(B,D,N,full_convexity=True):
    start=time.time();P=LogPolytope(B,D,N)
    C,lpstats=chambers(P.normals,P.n)
    U={s:P.gradient_series(g) for s,g in C.items()}
    V={s:P.specialize(u) for s,u in U.items()}
    jumps=[];t=Q(1,2);trivial=0;raw_checks=0
    for s,g in C.items():
        for j,a in enumerate(P.normals):
            if s[j]>0:continue
            splus=s[:j]+(1,)+s[j+1:]
            if splus not in C:continue
            i=next(i for i,x in enumerate(a) if x)
            # slope_minus - slope_plus = a * q(t).
            q=[Q(x-y,a[i]) for x,y in zip(V[s][i],V[splus][i])]
            for k in range(P.n):
                assert [x-y for x,y in zip(V[s][k],V[splus][k])]==[a[k]*x for x in q],('not parallel',B,D,N,s,j)
            # Also check full multivariate jump parallelism before specialization.
            for p in P.J[1:]:
                z=Q(U[s][i].get(p,0)-U[splus][i].get(p,0),a[i])
                assert all(U[s][k].get(p,0)-U[splus][k].get(p,0)==a[k]*z for k in range(P.n))
                raw_checks+=1
            nz=[k for k,x in enumerate(q) if x]
            if not nz:trivial+=1;continue
            first=nz[0]
            assert q[first]<0,('wrong leading jump sign',B,D,N,s,j,q)
            tail=sum(abs(x) for x in q[first+1:])
            if tail:t=min(t,(-q[first])/(2*tail))
            jumps.append((s,j,q))
    slopes={s:tuple(evaluate(v,t) for v in vv) for s,vv in V.items()}
    for _,_,q in jumps:assert evaluate(q,t)<0
    vertices=sorted(set(slopes.values()))
    # A convex homogeneous PL function equals max of its chamber gradients.
    # Full all-chamber checks supply a separate global numerical certificate.
    convex_checks=0
    if full_convexity:
        for s,g in C.items():
            hg=dot(slopes[s],g)
            for v in vertices:
                assert hg>=dot(v,g),('global nonconvex',B,D,N,s,g,hg,v)
                convex_checks+=1
    # Validate a sample of linear log functions by stabilized theta prefixes.
    theta_checks=0
    for s,g in list(C.items())[::max(1,len(C)//8)]:
        M=max(abs(D[i]*B[i][j]) for i in range(P.n) for j in range(P.n))
        scale=M*N*N+1
        cap=(N,)*P.n
        # The existing engine computes a box; low ranks/degree only here.
        if P.n<=3 and N<=3:
            F=P.R.theta_prefix(tuple(scale*x for x in g),cap)
            F={p:v for p,v in F.items() if p in P.Jset}
            L=logarithm(F,P.J,N)
            for p in P.J[1:]:
                rhs=sum(g[i]*U[s][i].get(p,0) for i in range(P.n))
                assert L.get(p,0)==scale*rhs,('theta stable log mismatch',B,D,N,g,p,L.get(p,0),scale*rhs)
                theta_checks+=1
    return {'B':B,'D':D,'degree':N,'arrangement_hyperplanes':len(P.normals),
            'arrangement_chambers':len(C),'polytope_vertices':len(vertices),
            'nontrivial_facets':len(jumps),'trivial_arrangement_facets':trivial,
            'multivariate_parallel_checks':raw_checks,'global_convexity_checks':convex_checks,
            'theta_log_checks':theta_checks,'t':str(t),'lp_certificates':lpstats,
            'vertices':[[str(x) for x in v] for v in vertices],
            'sample_jumps':[{'normal':P.normals[j],'polynomial':[str(x) for x in q]} for _,j,q in jumps[:10]],
            'seconds':time.time()-start}

def run(quick=False):
    data=[([[0,1],[-1,0]],[1,1],4),([[0,2],[-2,0]],[1,1],5),
          ([[0,3],[-2,0]],[2,3],4),([[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],3),
          ([[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],3)]
    if not quick:
        rng=random.Random(1926)
        for n,N in [(3,3)]*6+[(4,2)]*5+[(5,2)]*2:
            D=[rng.randint(1,3) for _ in range(n)];B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    a=rng.randint(-3,3);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
            data.append((B,D,N))
    result={'status':'RUNNING','cases':[]}
    path=ROOT/'computation/stable_log_polytope_results.json'
    for B,D,N in data:
        ans=check(B,D,N);result['cases'].append(ans)
        path.write_text(json.dumps(result,indent=2))
        print(json.dumps({k:v for k,v in ans.items() if k not in ['vertices','sample_jumps']}),flush=True)
    result['status']='PASS';result['summary']={k:sum(x[k] for x in result['cases']) for k in ['arrangement_chambers','polytope_vertices','nontrivial_facets','multivariate_parallel_checks','global_convexity_checks','theta_log_checks']}
    path.write_text(json.dumps(result,indent=2));print(json.dumps(result['summary']),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--quick',action='store_true');args=parser.parse_args();run(args.quick)
