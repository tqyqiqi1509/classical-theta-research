"""Cross-check complete Laurent output against independent F-mutation.

The reference F-polynomials use only principal-coefficient exchange mutation,
not the incoming-prefix or envelope algorithms. Initial seeds here are acyclic,
so the middle-equals-upper premise of the envelope method is established.
"""
from pathlib import Path
import sys, json, time
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'agents/fei_newton_interface'))
from finite_envelope import construct_theta

def mutate_matrix(E,k):
    m=len(E);n=len(E[0]);A=[row[:] for row in E]
    for i in range(m):
        for j in range(n):
            if i==k or j==k:A[i][j]=-E[i][j]
            else:A[i][j]=E[i][j]+max(E[i][k],0)*max(E[k][j],0)-max(-E[i][k],0)*max(-E[k][j],0)
    return A

def reference(B,word):
    n=len(B);ys=sp.symbols('y0:'+str(n));F=[sp.Integer(1)]*n
    E=[row[:] for row in B]+[[int(i==j) for j in range(n)] for i in range(n)]
    G=[[int(i==j) for j in range(n)] for i in range(n)]
    for k in word:
        pos=sp.prod(ys[i]**max(E[n+i][k],0) for i in range(n))*sp.prod(F[i]**max(E[i][k],0) for i in range(n))
        neg=sp.prod(ys[i]**max(-E[n+i][k],0) for i in range(n))*sp.prod(F[i]**max(-E[i][k],0) for i in range(n))
        newF=sp.cancel((pos+neg)/F[k])
        P=sp.Poly(newF,*ys,domain=sp.ZZ)
        col=[-G[i][k]+sum(max(E[j][k],0)*G[i][j] for j in range(n))
             -sum(B[i][j]*max(E[n+j][k],0) for j in range(n)) for i in range(n)]
        F[k]=P.as_expr()
        for i in range(n):G[i][k]=col[i]
        E=mutate_matrix(E,k)
    k=word[-1]
    return tuple(G[i][k] for i in range(n)),{p:int(c) for p,c in sp.Poly(F[k],*ys).terms()}

def run():
    cases=[
        ([[0,3],[-3,0]],[1,1],[0,1]),
        ([[0,3],[-2,0]],[2,3],[1,0]),
        ([[0,2],[-2,0]],[1,1],[0,1,0,1]),
        ([[0,1,0],[-1,0,1],[0,-1,0]],[1,1,1],[2,1,0]),
        ([[0,1,0],[-1,0,1],[0,-1,0]],[1,1,1],[0,2,1,0]),
        ([[0,1,1],[-1,0,1],[-1,-1,0]],[1,1,1],[2,1]),
        ([[0,2,1],[-1,0,1],[-1,-2,0]],[1,2,1],[2,1,0]),
        ([[0,1,0,0],[-1,0,1,0],[0,-1,0,1],[0,0,-1,0]],[1,1,1,1],[3,2,1,0]),
        ([[0,1,1,0],[-1,0,0,1],[-1,0,0,1],[0,-1,-1,0]],[1,1,1,1],[3,2,1]),
    ]
    outputs=[];start=time.time()
    for B,D,word in cases:
        g,expected=reference(B,word)
        cap=max(max(p) for p in expected)
        answer=construct_theta(B,D,g,max_radius=cap+1,finite_theta_span=True)
        if answer.get('status') not in ['complete','complete_laurent','complete_theta','complete under stated premise']:
            print(json.dumps({'inspect_return_keys':list(answer),'status':answer.get('status')}),flush=True)
        actual={tuple(p):int(c) for p,c in answer['theta_terms']}
        assert actual==expected,(B,D,word,g,expected,actual)
        row={'B':B,'D':D,'mutation_word_zero_based':word,'g':g,'nonzero_terms':len(actual),
             'certified_support_box':answer.get('certified_support_box'),'reference':'exact principal F-polynomial exchange mutation','status':'PASS'}
        outputs.append(row);print(json.dumps(row),flush=True)
    result={'status':'PASS','independent_mutation_cases':len(outputs),'seconds':time.time()-start,'results':outputs}
    (ROOT/'computation/mutation_envelope_crosscheck.json').write_text(json.dumps(result,indent=2))

if __name__=='__main__':run()
