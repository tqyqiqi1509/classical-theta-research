ClearAll[gx,gy,gz,gt,gu]; Module[{r=2,f,gb,j,j0,vars,leads,box,standard},
vars={gx,gy,gz};
f={gt (gx-gz)^r+gx (gy-gx)^r,gt^2 (gy-gx)^r+gy (gz-gy)^r,gt^4 (gz-gy)^r+gz (gx-gz)^r,gx gy gz+gt^7,gu gt gx gy gz (gy-gx)(gz-gy)(gx-gz)-1};
gb=GroebnerBasis[f,{gu,gx,gy,gz,gt},MonomialOrder->Lexicographic];
j=Select[gb,FreeQ[#,gu]&]; j0=GroebnerBasis[j/.gt->0,vars,MonomialOrder->DegreeReverseLexicographic];
leads=(Exponent[First[MonomialList[#,vars,DegreeReverseLexicographic]],vars]&)/@j0;
box=Tuples[Range[0,5],3];
standard=Select[box,Function[e,AllTrue[leads,Function[l,Not[And@@Thread[l<=e]]]]]];
<|"specialFiberBasis"->j0,"leadingExponents"->leads,"standardExponents"->standard,"length"->Length[standard],"expectedIndependentTheta"->7,"pass"->(Length[standard]==7)|>]
