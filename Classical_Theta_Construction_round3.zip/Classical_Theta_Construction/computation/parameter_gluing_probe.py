"""Exact tests of a proposed gluing theorem; counterexamples are retained.

One-parameter slices test the GENERAL parameter-gluing claim, not new type
classifications. The coefficient engine is the prior symbolic recurrence.
"""
from pathlib import Path
import sys, json, random, time
from itertools import product
import sympy as s

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
sys.path.insert(0,str(OLD))
from polyhedral_parameter_formula import FrozenChamber
from incoming_recursion import box, le

t=s.Symbol('t')

def walls(B,g,D,cap):
    J=box(cap); out={}
    for a in J[1:]:
        Ba=[sum(B[i][j]*a[j] for j in range(len(cap))) for i in range(len(cap))]
        for q in J:
            if not le(q,a): continue
            h=s.expand(sum(Ba[i]*D[i]*q[i] for i in range(len(cap))))
            e=s.expand(sum((g[i]+Ba[i])*D[i]*(a[i]-q[i]) for i in range(len(cap))))
            for kind,f in [('H',h),('E',e)]:
                f=s.Poly(f,t)
                if f.degree()==1:
                    z=-f.nth(0)/f.nth(1)
                    if -4<z<4: out.setdefault(z,[]).append([kind,a,q,str(f.as_expr())])
    return out

def run(seed=20261114,trials=60):
    rng=random.Random(seed); records=[]; checks=0; derivative_fail=0
    start=time.time()
    for test in range(trials):
        n=2 if test<20 else 3
        cap=(3,2) if n==2 else (2,1,1)
        D=[1]*n if test%3 else ([2,3] if n==2 else [1,2,3])
        B=[[s.Integer(0) for j in range(n)] for i in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                value=rng.randint(-3,3)+(rng.randint(-2,2)*t if test%2 else 0)
                B[i][j]=D[j]*value; B[j][i]=-D[i]*value
        g=[rng.randint(-4,4)+rng.randint(-3,3)*t for i in range(n)]
        ww=walls(B,g,D,cap); zz=sorted(ww)
        ends=[s.Integer(-4)]+zz+[s.Integer(4)]
        polynomials=[]
        for l,r in zip(ends,ends[1:]):
            sample=(l+r)/2
            B0=[[v.subs(t,sample) if hasattr(v,'subs') else v for v in row] for row in B]
            g0=[v.subs(t,sample) if hasattr(v,'subs') else v for v in g]
            polynomials.append(FrozenChamber(B,g,B0,g0,D).theta_prefix(cap))
        for i,z in enumerate(zz):
            B0=[[v.subs(t,z) if hasattr(v,'subs') else v for v in row] for row in B]
            g0=[v.subs(t,z) if hasattr(v,'subs') else v for v in g]
            boundary=FrozenChamber(B,g,B0,g0,D).theta_prefix(cap)
            for p in box(cap):
                a=polynomials[i][p]; b=polynomials[i+1][p]; c=boundary[p]
                values=[s.expand(f).subs(t,z) for f in [a,b,c]]
                checks+=1
                if len(set(values))>1:
                    rec={'trial':test,'B':[[str(v) for v in row] for row in B],
                         'D':D,'g':list(map(str,g)),'p':p,'wall':str(z),'wall_forms':ww[z],
                         'left':str(s.factor(a)),'right':str(s.factor(b)),
                         'on_wall':str(s.factor(c)),'values':list(map(str,values)),
                         'checks_before_failure':checks}
                    records.append(rec)
                    result={'status':'COUNTEREXAMPLE','records':records,'seconds':time.time()-start}
                    (ROOT/'computation/parameter_gluing_results.json').write_text(json.dumps(result,indent=2))
                    print(json.dumps(result),flush=True)
                    return result
                if s.diff(a-b,t).subs(t,z)!=0: derivative_fail+=1
        print(json.dumps({'trial':test,'walls':len(zz),'checks':checks,
                          'nonsmooth_derivatives':derivative_fail,'seconds':time.time()-start}),flush=True)
    result={'status':'NO_COUNTEREXAMPLE_IN_THIS_TEST','trials':trials,'coefficient_wall_checks':checks,
            'nonsmooth_derivatives':derivative_fail,'seconds':time.time()-start}
    (ROOT/'computation/parameter_gluing_results.json').write_text(json.dumps(result,indent=2))
    return result

if __name__=='__main__': run()
