"""Exact challenge of the proposed factorial Bezout theta majorant.

The test oracle is the earlier integer incoming recurrence, not the Gale/Q
construction. Both positive and signed endpoints are included.
"""
from pathlib import Path
from math import factorial
from fractions import Fraction
import json, random, time
from incoming_recursion import IncomingSchur
from arbitrary_endpoint_ray import endpoint


def run(trials=240):
    rng=random.Random(2611132140);start=time.time()
    checks=positive=endpoint_checks=0;largest=Fraction(0);witness=None
    for it in range(trials):
        r=2 if it<100 else 3 if it<210 else 4
        D=[rng.randint(1,3) for _ in range(r)]
        B=[[0]*r for _ in range(r)]
        for i in range(r):
            for j in range(i+1,r):
                v=rng.randint(-2,2)
                B[i][j]=D[j]*v;B[j][i]=-D[i]*v
        g=tuple(rng.randint(-5,5) for _ in range(r))
        cap=(3,3) if r==2 else (2,2,2) if r==3 else (1,1,1,1)
        engine=IncomingSchur(B,D)
        series=[engine.theta_prefix(g,cap)]
        if it%3==0:
            signed=tuple(D[i]*((-1)**i)*(sum(cap)+1)**i for i in range(r))
            series.append(endpoint(engine,g,signed,cap))
        for si,F in enumerate(series):
            for p,a in F.items():
                if not any(p):continue
                n=sum(p)
                incoming=[max(g[i],0)+sum(max(B[i][j],0)*p[j] for j in range(r)) for i in range(r)]
                outgoing=[max(-g[i],0)+sum(max(-B[i][j],0)*p[j] for j in range(r)) for i in range(r)]
                numerator=denominator=1
                for i in range(r):
                    if p[i]:
                        degree=max(incoming[i],outgoing[i]+p[i]-1)
                        numerator*=degree**p[i]
                        denominator*=factorial(p[i])
                assert a*denominator<=numerator,dict(B=B,D=D,g=g,p=p,a=a,bound=[numerator,denominator])
                checks+=1;positive+=a>0;endpoint_checks+=si==1
                ratio=Fraction(a*denominator,numerator) if numerator else Fraction(0)
                if ratio>largest:
                    largest=ratio;witness=dict(B=B,D=D,g=g,p=p,a=a,bound=[numerator,denominator])
        if (it+1)%20==0:print(json.dumps(dict(completed=it+1,coefficient_checks=checks,seconds=time.time()-start)),flush=True)
    result=dict(status='PASS',inputs=trials,nonzero_coefficient_checks=checks,positive=positive,
                signed_endpoint_checks=endpoint_checks,largest_ratio=str(largest),witness=witness,
                seconds=time.time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)

if __name__=='__main__':run()
