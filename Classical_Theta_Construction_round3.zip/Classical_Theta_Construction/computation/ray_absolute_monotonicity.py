"""Exact probes for uniform eventual binomial positivity at fixed B.

This scales labels, unlike the previous replication theorem which changes B.
Every forward difference is evaluated with integers, not fitted numerically.
"""
from pathlib import Path
import sys,random,json,time
from fractions import Fraction
from itertools import product
from math import comb
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
sys.path.insert(0,str(OLD))
from incoming_recursion import IncomingSchur,box,le
from stable_root_probe import mul,power

def threshold(R,g,h,cap):
    T=Fraction(0)
    for s in box(cap):
        m=R.shift(h,s)
        for a in box(s)[1:]:
            den=sum(g[i]*R.D[i]*a[i] for i in range(R.n))
            if den:
                T=max(T,abs(Fraction(sum(m[i]*R.D[i]*a[i] for i in range(R.n)),den)))
    return T.numerator//T.denominator+1

def run(trials=160):
    rng=random.Random(11619);start=time.time();results=[];checks=0;nonzero=0;degree_checks=0
    for trial in range(trials):
        n=2 if trial<35 else 3 if trial<90 else 4 if trial<135 else 5
        D=[rng.randint(1,3) for _ in range(n)];B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                b=rng.randint(-3,3);B[i][j]=D[j]*b;B[j][i]=-D[i]*b
        cap=(3,3) if n==2 else (2,2,1) if n==3 else (2,1,1,1) if n==4 else (1,)*5
        g=tuple(rng.randint(-4,4) for _ in range(n));h=tuple(rng.randint(-3,3) for _ in range(n))
        if trial%4==0:h=(0,)*n
        R=IncomingSchur(B,D);N0=threshold(R,g,h,cap);d=sum(cap);J=box(cap)
        values=[R.theta_prefix(tuple((N0+k)*g[i]+h[i] for i in range(n)),cap) for k in range(d+2)]
        coeffs=[]
        for p in J:
            v=[F.get(p,0) for F in values]
            row=[]
            for j in range(d+2):
                q=v[0];checks+=1;nonzero+=bool(q)
                assert q>=0,('negative difference',B,D,g,h,cap,N0,p,j,q)
                if j>sum(p):assert q==0,('degree',B,D,g,h,cap,N0,p,j,q)
                if j==sum(p)+1:degree_checks+=1
                row.append(q);v=[v[i+1]-v[i] for i in range(len(v)-1)]
            coeffs.append([p,row])
        if trial<6:
            results.append({'B':B,'D':D,'g':g,'h':h,'cap':cap,'threshold_integer':N0,
                            'target':cap,'binomial_coefficients':next(v for p,v in coeffs if p==cap)})
        if trial%20==19:print(json.dumps({'completed':trial+1,'exact_differences':checks,'seconds':time.time()-start}),flush=True)
    out={'status':'PASS','inputs':trials,'exact_forward_difference_checks':checks,
         'positive_differences':nonzero,'exact_degree_checks':degree_checks,'examples':results,
         'seconds':time.time()-start}
    (ROOT/'computation/ray_absolute_monotonicity_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out),flush=True)

if __name__=='__main__':run()
