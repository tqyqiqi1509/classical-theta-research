"""Direct framed-graph coefficient algebra, independent of scattering.

Construction inputs are B, D, g and a nonnegative coefficient degree p.
It builds primitive graph-Gale rows, saturates by T times the actual arrow
product, takes the finite T=0 fiber, and generates its alternating part by
the within-color Vandermonde and elementary symmetric multiplications.

The returned exponent tuples are the standard monomials of a cyclic
invariant quotient, found by the usual linear-algebra/FGLM algorithm.
No theta coefficient, flow count, scattering wall or desired dimension is
used in the construction. IncomingSchur is imported only by the test runner.
"""
from __future__ import annotations

from functools import lru_cache
from fractions import Fraction
from itertools import product, combinations
from math import gcd, lcm
from pathlib import Path
import heapq
import json
import time
import sympy as s


@lru_cache(None)
def hierarchies(mask):
    """All unordered rooted binary hierarchies with these labelled leaves."""
    if mask & (mask - 1) == 0:
        return (mask,)
    first = mask & -mask
    out = []
    left = (mask - 1) & mask
    while left:
        right = mask ^ left
        if right and left & first:
            for a in hierarchies(left):
                for b in hierarchies(right):
                    out.append((a, b))
        left = (left - 1) & mask
    return tuple(out)


def clusters(tree):
    if isinstance(tree, int):
        return tree, []
    a, ac = clusters(tree[0])
    b, bc = clusters(tree[1])
    return a | b, ac + bc + [a | b]


def primitive_integer_vector(v):
    vals = [s.Rational(x) for x in v]
    den = lcm(*(int(x.q) for x in vals)) if vals else 1
    nums = [int(x * den) for x in vals]
    common = 0
    for x in nums:
        common = gcd(common, abs(x))
    if not common:
        return None
    nums = [x // common for x in nums]
    if next(x for x in nums if x) < 0:
        nums = [-x for x in nums]
    return tuple(nums)


def graph_data(B, D, g, p):
    n = len(B)
    assert len(D) == len(g) == len(p) == n
    assert all(D[i] > 0 and p[i] >= 0 for i in range(n))
    assert all(D[i] * B[i][j] == -D[j] * B[j][i]
               for i in range(n) for j in range(n))
    colors = (-1,) + tuple(i for i in range(n) for _ in range(p[i]))
    eta = [[0 for _ in colors] for _ in colors]
    for u in range(len(colors)):
        for v in range(u + 1, len(colors)):
            i, j = colors[u], colors[v]
            a = D[j] * g[j] if u == 0 else -D[i] * B[i][j]
            eta[u][v], eta[v][u] = a, -a
    return colors, tuple(map(tuple, eta))


def color_generic_weights(eta, colors, D):
    """Exact finite rank certificate for a generic original-color covector.

    For each hierarchy H, avoid every nonzero pullback to the color space
    of a left-nullspace equation of M_H. Thus any hierarchy whose image
    contains the selected theta contains the entire color subspace.
    The independent recession lemma then applies. No LP floating arithmetic.
    """
    active = tuple(sorted(set(colors[1:])))
    rank = len(active)
    if not rank:
        return (), {"hierarchies": 0, "excluded_forms": [], "z": 2}
    pos = {c: i for i, c in enumerate(active)}
    nv = len(colors)
    U = s.zeros(nv - 1, rank)
    for v, c in enumerate(colors[1:]):
        U[v, pos[c]] = D[c]
    forms = set()
    count = 0
    for H in hierarchies((1 << nv) - 1):
        _, nodes = clusters(H)
        M = s.Matrix([[sum(eta[j][i] for j in range(nv) if S >> j & 1)
                       if S >> i & 1 else 0 for S in nodes]
                      for i in range(1, nv)])
        for row in M.T.nullspace():
            f = primitive_integer_vector(list((row.T * U)))
            if f is not None:
                forms.add(f)
        count += 1
    z = 2
    while any(sum(a * z ** i for i, a in enumerate(f)) == 0 for f in forms):
        z += 1
    aa = {c: z ** pos[c] for c in active}
    weights = tuple(aa[c] for c in colors[1:])
    return weights, {"hierarchies": count, "excluded_forms": sorted(forms),
                     "active_colors": active, "z": z,
                     "primitive_row_valuations": weights}


def monomial(exp, variables):
    return s.prod(x ** k for x, k in zip(variables, exp))


def standard_basis(gb):
    if list(gb) == [1]:
        return ()
    if not gb.is_zero_dimensional:
        raise ArithmeticError("The saturated T=0 fiber is not finite")
    leads = [q.LM(order=gb.order).exponents for q in gb.polys]
    bounds = [min(e[i] for e in leads if e[i] and sum(bool(z) for z in e) == 1)
              for i in range(len(gb.gens))]
    return tuple(sorted((e for e in product(*(range(b) for b in bounds))
                         if not any(all(a <= b for a, b in zip(l, e)) for l in leads)),
                        key=lambda e: (sum(e), e)))


def alternating_staircase(gb, colors):
    """Compute (R/I)^sgn = Delta * R^G using exact rational linear algebra."""
    basis = standard_basis(gb)
    if not basis:
        return {"length": 0, "coefficient": 0, "staircase": [], "leading_relations": [[0]]}
    xs = gb.gens
    index = {e: i for i, e in enumerate(basis)}
    dim = len(basis)

    def vector(poly):
        rem = gb.reduce(s.expand(poly))[1]
        out = [s.Rational(0)] * dim
        for e, a in s.Poly(rem, *xs).terms():
            if a:
                out[index[e]] = a
        return tuple(out)

    invariants = []
    inv_names = []
    Delta = s.Integer(1)
    for c in sorted(set(colors[1:])):
        xx = [xs[v-1] for v in range(1, len(colors)) if colors[v] == c]
        Delta *= s.prod(b-a for a, b in combinations(xx, 2))
        for k in range(1, len(xx) + 1):
            invariants.append(sum(s.prod(q) for q in combinations(xx, k)))
            inv_names.append(f"e_{c+1}_{k}")
    actions = [tuple(vector(E * monomial(e, xs)) for e in basis) for E in invariants]

    def act(j, v):
        out = [s.Rational(0)] * dim
        for k, a in enumerate(v):
            if a:
                col = actions[j][k]
                for i, b in enumerate(col):
                    if b:
                        out[i] += a*b
        return tuple(out)

    r = len(invariants)
    zero = (0,) * r
    vectors = {zero: vector(Delta)}
    heap = [(0, zero)]
    enqueued = {zero}
    accepted = []
    forbidden = []
    echelon = []
    while heap:
        _, exp = heapq.heappop(heap)
        if any(all(a <= b for a, b in zip(l, exp)) for l in forbidden):
            continue
        raw = vectors[exp]
        v = list(raw)
        for pivot, row in echelon:
            if v[pivot]:
                a = v[pivot]
                v = [x-a*y for x, y in zip(v, row)]
        pivot = next((i for i, a in enumerate(v) if a), None)
        if pivot is None:
            forbidden.append(exp)
            continue
        a = v[pivot]
        row = tuple(x/a for x in v)
        echelon.append((pivot, row))
        echelon.sort(key=lambda x: x[0])
        accepted.append(exp)
        for j in range(r):
            child = tuple(a + int(i == j) for i, a in enumerate(exp))
            if child not in enqueued:
                enqueued.add(child)
                vectors[child] = act(j, raw)
                heapq.heappush(heap, (sum(child), child))
    return {"length": dim, "coefficient": len(accepted),
            "invariant_variables": inv_names, "staircase": accepted,
            "leading_relations": forbidden, "coordinate_standard_basis": basis,
            "vandermonde": str(s.expand(Delta))}


def coefficient_algebra(B, D, g, p, extra_cut_relations=True):
    start = time.time()
    if not any(p):
        return {"B": B, "D": D, "g": g, "p": p,
                "coefficient": 1, "length": 1, "staircase": [()], "seconds": 0}
    colors, eta = graph_data(B, D, g, p)
    weights, certificate = color_generic_weights(eta, colors, D)
    nv = len(colors)
    xs = s.symbols(f"x1:{nv}")
    T, u = s.symbols('T u')
    coords = (s.Integer(0),) + xs
    nums = [s.Integer(1)] * nv
    dens = [s.Integer(1)] * nv
    arrows = []
    for i in range(nv):
        for j in range(i+1, nv):
            a = eta[i][j]
            if not a:
                continue
            tail, head = (i, j) if a > 0 else (j, i)
            L = coords[head] - coords[tail]
            m = abs(a)
            dt = 1 if tail == 0 else D[colors[tail]]
            dh = 1 if head == 0 else D[colors[head]]
            assert m % dt == m % dh == 0
            dens[tail] *= L ** (m//dt)
            nums[head] *= L ** (m//dh)
            arrows.append((tail, head, m, L))
    polys = [s.expand(T**weights[v-1] * nums[v] - dens[v]) for v in range(1, nv)]
    if extra_cut_relations:
        for mask in range(1, 1 << (nv-1)):
            incl = {v for v in range(1, nv) if mask >> (v-1) & 1}
            raw_num = s.prod(L**m for tail, head, m, L in arrows if head in incl and tail not in incl)
            raw_den = s.prod(L**m for tail, head, m, L in arrows if tail in incl and head not in incl)
            w = sum(D[colors[v]] * weights[v-1] for v in incl)
            polys.append(s.expand(T**w * raw_num - raw_den))
    Lambda = s.prod(L for _, _, _, L in arrows)
    gb = s.groebner(polys + [u*T*Lambda-1], u, *xs, T, order='lex')
    saturated = [q.as_expr() for q in gb.polys if not q.as_expr().has(u)]
    special = [q.subs(T, 0) for q in saturated]
    gb0 = s.groebner([q for q in special if q != 0], *xs, order='grevlex')
    result = alternating_staircase(gb0, colors)
    result.update({"B": B, "D": D, "g": g, "p": p, "colors": colors,
                   "weights_certificate": certificate,
                   "special_groebner_basis": [str(q.as_expr()) for q in gb0.polys],
                   "saturated_generators": len(saturated),
                   "seconds": time.time()-start})
    return result


def run_checks():
    from incoming_recursion import IncomingSchur
    cases = [
        ([[0]], [1], [-3], [2]),
        ([[0]], [2], [-3], [2]),
        ([[0,1],[-1,0]], [1,1], [-2,-1], [1,1]),
        ([[0,1],[-1,0]], [1,1], [-2,1], [2,1]),
        ([[0,2],[-2,0]], [1,1], [-1,-1], [1,1]),
        ([[0,-1,1],[1,0,-1],[-1,1,0]], [1,1,1], [-1,-1,-1], [1,1,1]),
        ([[0,-1,1],[1,0,-1],[-1,1,0]], [1,1,1], [-1,-2,0], [2,1,1]),
    ]
    results = []
    for B,D,g,p in cases:
        out = coefficient_algebra(B,D,g,p)
        oracle = IncomingSchur(B,D).theta_prefix(tuple(g),tuple(p)).get(tuple(p),0)
        out['independent_incoming_coefficient'] = oracle
        out['pass'] = out['coefficient'] == oracle
        results.append(out)
        Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps({k:out[k] for k in ('p','D','length','coefficient','independent_incoming_coefficient','pass','seconds')}),flush=True)
        assert out['pass'], out
    return results


if __name__ == '__main__':
    run_checks()
