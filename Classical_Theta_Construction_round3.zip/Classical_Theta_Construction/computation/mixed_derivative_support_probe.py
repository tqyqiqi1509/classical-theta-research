"""Exact general-mechanism probe for the proposed positive coefficient shear.

Checks binom(p+r,r)*a_g(p+r) >= a_g(r)*a_{g+(I+B)r}(p).
This is a test of a theorem candidate, not a finite-support stopping test.
The independent incoming-normalized oracle computes all entries exactly.
"""
from pathlib import Path
from math import comb, lcm
import json, random, time
from incoming_recursion import IncomingSchur, box


def run():
    rng = random.Random(202611132337)
    started = time.time()
    cases = checks = nonzero = 0
    receipts = []
    for rank, count in [(2, 160), (3, 160), (4, 80)]:
        for trial in range(count):
            diagonal = [rng.randint(1, 3) for _ in range(rank)]
            matrix = [[0] * rank for _ in range(rank)]
            for i in range(rank):
                for j in range(i + 1, rank):
                    value = rng.randint(-2, 2) * lcm(diagonal[i], diagonal[j])
                    matrix[i][j] = value // diagonal[i]
                    matrix[j][i] = -value // diagonal[j]
            label = tuple(rng.randint(-4, 4) for _ in range(rank))
            R = IncomingSchur(matrix, diagonal)
            r = [0] * rank
            for _ in range(rng.randint(1, 2)):
                r[rng.randrange(rank)] += 1
            r = tuple(r)
            pcap = (1,) * rank
            cap = tuple(a + b for a, b in zip(r, pcap))
            F = R.theta_prefix(label, cap)
            leading = F.get(r, 0)
            shifted = tuple(label[i] + r[i] + sum(matrix[i][j] * r[j]
                                                for j in range(rank))
                            for i in range(rank))
            H = R.theta_prefix(shifted, pcap) if leading else {}
            for p in box(pcap):
                pr = tuple(a + b for a, b in zip(p, r))
                binomial = 1
                for a, b in zip(p, r):
                    binomial *= comb(a + b, b)
                left = binomial * F.get(pr, 0)
                right = leading * H.get(p, 0)
                checks += 1
                nonzero += bool(left or right)
                record = dict(B=matrix, D=diagonal, g=label, r=r,
                              p=p, h=shifted, left=left, right=right)
                if left < right:
                    result = dict(status='FAIL', cases=cases, checks=checks,
                                  counterexample=record,
                                  seconds=time.time()-started)
                    Path(__file__).with_suffix('.json').write_text(
                        json.dumps(result, indent=2))
                    print(json.dumps(result), flush=True)
                    return
                if leading and (left != right or len(receipts) < 20) and len(receipts) < 100:
                    receipts.append(record)
            cases += 1
            R.c.cache_clear()
            R.sign.cache_clear()
            if cases % 40 == 0:
                print(json.dumps(dict(cases=cases, checks=checks,
                                      seconds=round(time.time()-started, 2))), flush=True)
    result = dict(status='PASS', cases=cases, checks=checks,
                  nonzero_checks=nonzero, receipts=receipts,
                  seconds=time.time()-started,
                  scope='Exact finite prefixes; no support completeness claim.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2))
    print(json.dumps({k:v for k,v in result.items() if k != 'receipts'}), flush=True)


if __name__ == '__main__':
    run()
