"""Create a compact research checkpoint without downloaded source caches."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SUFFIXES = {'.md', '.py', '.json', '.jsonl', '.wl', '.txt', '.csv'}
DEPENDENCIES = [
    'DYCK_THREE_FACTOR_COHERENCE.md',
    'TWO_FRAME_INDEPENDENT_REVIEW.md',
    'TWO_STACK_DYCK_FORESTS.md',
    'incoming_recursion.py',
    'universal_tree_positive.md',
    'ONE_FRAMING_COEFFICIENT_THEOREM.md',
    'incoming_independent_audit.md',
]

def build(name: str) -> dict:
    files = []
    for directory in ('agents', 'computation', 'notes', 'logs'):
        for path in (ROOT / directory).rglob('*'):
            if (path.is_file() and path.suffix in SUFFIXES
                    and not {'sources', '__pycache__'}.intersection(path.parts)
                    and not path.name.endswith('.tmp')
                    and path.name != 'ghk_birational.txt'):
                files.append(path)
    files.extend(ROOT.glob('*.md'))
    old = ROOT / 'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
    files.extend(old / item for item in DEPENDENCIES)
    destination = ROOT / 'deliverables' / name
    destination.parent.mkdir(exist_ok=True)
    manifest = []
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(set(files)):
            content = path.read_bytes()
            relative = str(path.relative_to(ROOT))
            archive.writestr('Classical_Theta_Construction/' + relative, content)
            manifest.append({'path': relative, 'bytes': len(content),
                             'sha256': hashlib.sha256(content).hexdigest()})
        archive.writestr('Classical_Theta_Construction/MANIFEST.json',
                         json.dumps(manifest, indent=2, ensure_ascii=False))
    with zipfile.ZipFile(destination) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f'Corrupt zip member: {bad}')
    return {'path': str(destination), 'files': len(manifest) + 1,
            'bytes': destination.stat().st_size,
            'created_utc': dt.datetime.now(dt.timezone.utc).isoformat()}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('name')
    args = parser.parse_args()
    print(json.dumps(build(args.name), ensure_ascii=False))
