"""Candidate certificate-free incoming-normalized integer theta prefixes.

Only integer binomial coefficients, finite boxes, signs and triangular products
are used. This is an independent implementation for adversarial verification.
"""
from functools import lru_cache
from itertools import product
from math import comb


def ibinom(a, k):
    if k < 0:
        return 0
    if a >= 0:
        return comb(a, k) if k <= a else 0
    return (-1)**k * comb(-a+k-1, k)


def sub(a, b):
    return tuple(x-y for x,y in zip(a,b))


def le(a,b):
    return all(x<=y for x,y in zip(a,b))


def box(a):
    return sorted(product(*(range(x+1) for x in a)),key=lambda p:(sum(p),p))


class IncomingRecursion:
    def __init__(self,B,D=None,tie_order=None):
        self.B=tuple(map(tuple,B))
        self.n=len(B)
        self.D=tuple(D or [1]*self.n)
        assert all(self.D[i]*B[i][j]==-self.D[j]*B[j][i]
                   for i in range(self.n) for j in range(self.n))
        self.zero=(0,)*self.n
        self.tie_order=tuple(tie_order or range(self.n))
        self.zero_residual_checks=0
        self.c = lru_cache(maxsize=None)(self._c)
        self.sign = lru_cache(maxsize=None)(self._sign)

    def shift(self,m,q):
        return tuple(m[i]+sum(self.B[i][j]*q[j] for j in range(self.n))
                     for i in range(self.n))

    def _sign(self,a,b):
        """Lexicographic infinitesimal perturbation of B a inside a^perp.

        The first functional is <B a,D b>. On its kernel use the ordered
        coordinates a_r*b_i-a_i*b_r, which are linear in b and vanish
        simultaneously exactly on Q*a. Positive factors D do not affect
        this lexicographic sign. A finite box admits an ordinary rational
        functional with precisely these signs.
        """
        Ba=self.shift(self.zero,a)
        first=sum(Ba[i]*self.D[i]*b[i] for i in range(self.n))
        if first:
            return 1 if first>0 else -1
        r=next(i for i in range(self.n) if a[i])
        for i in self.tie_order:
            if i==r: continue
            z=a[r]*b[i]-a[i]*b[r]
            if z:
                return 1 if z>0 else -1
        return 0

    def _c(self,a,m):
        if not any(a): return 1
        support=[i for i,x in enumerate(a) if x]
        if len(support)==1:
            i=support[0]
            return ibinom(-m[i],a[i])
        J=box(a)
        pos={p:i for i,p in enumerate(J)}
        minus={(p,p):1 for p in J}
        plus={(p,p):1 for p in J}
        intervals=sorted(((p,q) for p in J for q in J if p!=q and le(q,p)),
                         key=lambda pq:(sum(sub(*pq)),pq))
        answer=None
        for p,q in intervals:
            beta=sub(p,q)
            cross=sum(minus.get((p,r),0)*plus.get((r,q),0)
                      for r in J if r!=q and r!=p and le(q,r) and le(r,p))
            if beta==a:
                assert p==a and q==self.zero
                answer=cross
                continue
            val=self.c(beta,self.shift(m,q))-cross
            s=self.sign(a,beta)
            if s<0:
                if val: minus[p,q]=val
            elif s>0:
                if val: plus[p,q]=val
            else:
                self.zero_residual_checks+=1
                assert val==0,('nonzero parallel residual',self.B,self.D,a,m,p,q,val)
        assert answer is not None
        return answer

    def theta_prefix(self,g,d):
        J=box(d)
        a={self.zero:1}
        for p in J[1:]:
            mp=self.shift(g,p)
            I=[q for q in J if le(q,p) and
               (q==p or sum(mp[i]*self.D[i]*(p[i]-q[i]) for i in range(self.n))<0)]
            # Last row of inverse of C[I,I], descending in q.
            t={p:1}
            for q in reversed(I[:-1]):
                t[q]=-sum(t.get(r,0)*self.c(sub(r,q),self.shift(g,q))
                          for r in I if r!=q and le(q,r))
            a[p]=-sum(t[q]*a[q] for q in I if q!=p)
        return {p:c for p,c in a.items() if c}


class IncomingSchur(IncomingRecursion):
    """Equivalent recursion using just one halfspace principal submatrix.

    This avoids constructing signed factors. Every recursive c-call has a
    strictly smaller root interval, including those used in the inverse.
    """
    def _c(self,a,m):
        if not any(a): return 1
        support=[i for i,x in enumerate(a) if x]
        if len(support)==1:
            i=support[0]
            return ibinom(-m[i],a[i])
        S=[q for q in box(a) if q!=a and q!=self.zero and self.sign(a,q)>0]
        v={}
        for s in S:
            v[s]=self.c(s,m)-sum(self.c(sub(s,q),self.shift(m,q))*v[q]
                                 for q in v if le(q,s))
        return sum(self.c(sub(a,s),self.shift(m,s))*v[s] for s in S)


def acyclic_c(B,a,m):
    answer=1
    for i in range(len(B)):
        top=-m[i]-sum(B[i][j]*a[j] for j in range(i))
        answer*=ibinom(top,a[i])
    return answer


if __name__=='__main__':
    import json, random, time
    start=time.time()
    rng=random.Random(251113)
    tests=[]
    for B,D,cap in [([[0,1],[-1,0]],[1,1],(4,4)),
                    ([[0,2],[-2,0]],[1,1],(4,4)),
                    ([[0,3],[-2,0]],[2,3],(4,4)),
                    ([[0,1,2],[-1,0,1],[-2,-1,0]],[1,1,1],(2,2,2)),
                    ([[0,2,1],[-1,0,1],[-1,-2,0]],[1,2,1],(2,2,2))]:
        R=IncomingRecursion(B,D)
        count=0
        for _ in range(4):
            m=tuple(rng.randrange(-4,5) for _ in D)
            for a in box(cap):
                x=R.c(a,m)
                y=acyclic_c(B,a,m)
                assert x==y,(B,D,a,m,x,y)
                count+=1
        tests.append({'B':B,'D':D,'cap':cap,'entries':count,
                      'zero_parallel_residual_checks':R.zero_residual_checks,
                      'cache':str(R.c.cache_info())})
    R=IncomingRecursion([[0,2],[-2,0]])
    kronecker=[]
    for m in range(1,7):
        g=(-m,m)
        F=R.theta_prefix(g,(m,m))
        kronecker.append({'m':m,'g':g,'terms':[[list(p),v] for p,v in F.items()],
                          'min_coefficient':min(F.values())})
    print(json.dumps({'status':'PASS','tests':tests,'kronecker':kronecker,
                      'seconds':time.time()-start},ensure_ascii=False,indent=2))
