"""Exact tests for translated-ray stabilization and the transverse product.

Independent comparison through the prior incoming-prefix engine. These finite
tests are not the general proof and do not assume a cluster realization of the
zero-root subsystem.
"""
from pathlib import Path
import json, random, time
from fractions import Fraction
from stable_root_probe import IncomingSchur, box, le, sub, mul, power, stable_root

ROOT=Path(__file__).resolve().parents[1]

def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(n,a):return tuple(n*x for x in a)

def inv(F,cap):
    J=box(cap);z=(0,)*len(cap);out={z:1}
    assert F.get(z)==1
    for p in J[1:]:
        v=-sum(c*out.get(sub(p,q),0) for q,c in F.items() if q!=z and le(q,p))
        if v:out[p]=v
    return out

def threshold(R,g,h,cap):
    bound=Fraction(0)
    for s in box(cap):
        v=R.shift(h,s)
        for a in box(s)[1:]:
            den=sum(g[i]*R.D[i]*a[i] for i in range(R.n))
            if den:bound=max(bound,abs(Fraction(sum(v[i]*R.D[i]*a[i] for i in range(R.n)),den)))
    return bound.numerator//bound.denominator+1

def structure(R,u,v,cap):
    J=box(cap);z=(0,)*len(cap)
    residual=mul(R.theta_prefix(u,cap),R.theta_prefix(v,cap),cap)
    out={}
    for q in J:
        c=residual.get(q,0)
        if not c:continue
        out[q]=c
        label=R.shift(add(u,v),q)
        for r,w in R.theta_prefix(label,sub(cap,q)).items():
            p=add(q,r);residual[p]=residual.get(p,0)-c*w
    assert not any(residual.values())
    return out

def run(trials=36):
    rng=random.Random(617142);started=time.time();checks=0;prodchecks=0;examples=[]
    for index in range(trials):
        rank=2+index//12
        D=[rng.randint(1,3) for _ in range(rank)]
        B=[[0]*rank for _ in range(rank)]
        for i in range(rank):
            for j in range(i+1,rank):
                b=rng.choice([-3,-2,-1,1,2,3]);B[i][j]=D[j]*b;B[j][i]=-D[i]*b
        # Ensure genuinely resonant positive roots, including nontrivial D.
        g=tuple([-D[1],D[0]]+[rng.choice([-2,0,0,2]) for _ in range(rank-2)])
        h=tuple(rng.randint(-3,3) for _ in D)
        k=tuple(rng.randint(-3,3) for _ in D)
        cap=(3,3) if rank==2 else (2,2,1) if rank==3 else (1,1,1,1)
        H,oldT,R=stable_root(B,D,g,cap)
        T=max(oldT,threshold(R,g,h,cap),threshold(R,g,k,cap))
        for q in box(cap):
            T=max(T,threshold(R,g,R.shift(add(h,k),q),cap))
        base=R.theta_prefix(add(scale(T,g),h),cap)
        offset=mul(base,inv(power(H,T,cap),cap),cap)
        for n in [T+1,T+7,2*T+3]:
            actual=R.theta_prefix(add(scale(n,g),h),cap)
            predicted=mul(power(H,n,cap),offset,cap)
            assert actual==predicted,('translated ray',B,D,g,h,cap,T,n,actual,predicted)
            checks+=len(box(cap))
        S=structure(R,add(scale(T,g),h),add(scale(T,g),k),cap)
        S2=structure(R,add(scale(T+2,g),h),add(scale(2*T+5,g),k),cap)
        assert S==S2,('product stability',B,D,g,h,k,cap,T,S,S2)
        assert all(sum(g[i]*D[i]*q[i] for i in range(rank))==0 for q in S),('nonzero transverse weight',B,D,g,h,k,S)
        prodchecks+=len(box(cap))
        if len(S)>1 and len(examples)<6:
            examples.append({'B':B,'D':D,'g':g,'h':h,'k':k,'cap':cap,'T':T,
                             'stable_structure':[[list(q),c] for q,c in S.items()]})
        print(json.dumps({'completed':index+1,'rank':rank,'T':T,'elapsed_s':round(time.time()-started,3)}),flush=True)
    result={'status':'PASS','inputs':trials,'translated_coefficient_checks':checks,
            'stable_product_coefficient_checks':prodchecks,'examples':examples,'seconds':time.time()-started}
    (ROOT/'computation/transverse_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))

if __name__=='__main__':run()
