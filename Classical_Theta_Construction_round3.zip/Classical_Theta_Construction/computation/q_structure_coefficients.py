"""Direct tensor-sum Q algebras for classical theta structure constants.

Parameters are chosen in a finite generic neighborhood of D*(g+h+Bp).
The comparison computes structure constants independently by triangular
expansion in the positive chart. No known dimension enters the Q ideals.
"""
from functools import lru_cache
from fractions import Fraction
from itertools import product
from math import gcd
from pathlib import Path
import json, time
from quiver_polynomial_staircase import polynomial_coefficient_algebra
from graph_gale_staircase import graph_data, color_generic_weights
from incoming_recursion import IncomingSchur, box, sub
from transverse_probe import structure


def generic_dual_endpoint(B,D,labels,p):
    r=len(B)
    h=tuple(sum(g[i] for g in labels)+sum(B[i][j]*p[j] for j in range(r)) for i in range(r))
    forms=set()
    for g in labels:
        for q in box(tuple(p))[1:]:
            colors,eta=graph_data(B,D,g,q)
            _,cert=color_generic_weights(eta,colors,D)
            for f in cert['excluded_forms']:
                full=[0]*r
                for j,c in enumerate(cert['active_colors']):full[c]=f[j]
                forms.add(tuple(full))
    z=2
    while True:
        e=tuple(z**i for i in range(r))
        if all(sum(f[i]*e[i] for i in range(r)) for f in forms if sum(f[i]*h[i] for i in range(r))==0):break
        z+=1
    bound=Fraction(sum(D[i]*p[i]*e[i] for i in range(r)))
    for f in forms:
        leading=sum(f[i]*h[i] for i in range(r))
        if leading:bound=max(bound,abs(Fraction(sum(f[i]*e[i] for i in range(r)),leading)))
    L=bound.numerator//bound.denominator+1
    a=tuple(L*h[i]+e[i] for i in range(r))
    d=0
    for x in a:d=gcd(d,abs(x))
    if d:a=tuple(x//d for x in a)
    assert all(sum(f[i]*a[i] for i in range(r)) for f in forms)
    for q in box(tuple(p))[1:]:
        v=sum(D[i]*h[i]*q[i] for i in range(r))
        w=sum(D[i]*a[i]*q[i] for i in range(r))
        assert w and (v==0 or v*w>0)
    return a,dict(output_label=h,z=z,L=L,primitive_exponents=a,excluded_form_count=len(forms))


def coefficient(B,D,g,h,p):
    started=time.time();p=tuple(p)
    a,cert=generic_dual_endpoint(B,D,[g,h],p)
    summands=[];answer=0
    for q in box(p):
        v=sub(p,q)
        qalg=polynomial_coefficient_algebra(B,D,g,q,row_exponents=a)
        valg=polynomial_coefficient_algebra(B,D,h,v,row_exponents=a)
        term=qalg['coefficient']*valg['coefficient']
        answer+=term
        summands.append(dict(degrees=[q,v],dimensions=[qalg['coefficient'],valg['coefficient']],dimension=term))
    return dict(B=B,D=D,labels=[g,h],p=p,endpoint_certificate=cert,
                summands=summands,coefficient=answer,seconds=time.time()-started)


def run():
    cases=[
       ([[0]],[1],[-2],[3],[1]),
       ([[0]],[1],[-2],[3],[2]),
       ([[0,1],[-1,0]],[1,1],[-1,0],[0,-1],[1,1]),
       ([[0,1],[-1,0]],[1,1],[-2,1],[1,-2],[1,1]),
       ([[0,2],[-2,0]],[1,1],[-1,1],[1,-1],[1,1]),
       ([[0,3],[-2,0]],[2,3],[-1,1],[1,-1],[1,1]),
       ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-1,0],[0,1,-1],[1,1,1]),
       ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-1,-1],[1,1,1],[1,1,1]),
    ]
    rows=[]
    for B,D,g,h,p in cases:
        row=coefficient(B,D,g,h,p)
        row['independent_positive_chart_coefficient']=structure(IncomingSchur(B,D),tuple(g),tuple(h),tuple(p)).get(tuple(p),0)
        row['passed']=row['coefficient']==row['independent_positive_chart_coefficient']
        rows.append(row)
        Path(__file__).with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
        print(json.dumps({k:row[k] for k in ('labels','p','coefficient','independent_positive_chart_coefficient','passed','seconds')}),flush=True)
        assert row['passed'],row

if __name__=='__main__':run()
