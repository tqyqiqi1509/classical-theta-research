ClearAll[w,u,v,tr,tt,cc,gg,hh,checks];
cc={{1,2},{3,1}}; gg={2,1};
tr[f_]:=Normal[Series[f,{w,0,5}]];
tt={0,0};
Do[tt=tr/@MapThread[#1*w*Exp[#2]&,{{u,v},Transpose[cc].tt}],{6}];
hh=tr[Exp[gg.tt]/Det[IdentityMatrix[2]-DiagonalMatrix[tt].cc]];
checks=Flatten[Table[With[{p={i,j}},
  Coefficient[Coefficient[Coefficient[hh,w,i+j],u,i],v,j]==
    Product[(gg+cc.p)[[k]]^p[[k]]/Factorial[p[[k]]],{k,2}]],
  {i,0,5},{j,0,5-i}]];
<|"Status"->If[And@@checks,"PASS","FAIL"],
  "ExactCoefficientChecks"->Length[checks],"C"->cc,"G"->gg,
  "Degrees"->5,"SampleDegreeThree"->Coefficient[hh,w,3]|>
