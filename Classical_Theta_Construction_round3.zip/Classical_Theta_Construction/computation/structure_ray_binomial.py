"""Probe simultaneous label dilation of classical theta structure constants.

Uses an independent triangular multiplication expansion, not the proposed
positive endpoint-copy construction. All computations are exact integers.
"""
from pathlib import Path
from fractions import Fraction
import random, json, time
from incoming_recursion import IncomingSchur, box
from transverse_probe import structure, threshold

ROOT = Path(__file__).resolve().parents[1]


def exact_bound(R, directions, offsets, cap):
    total_g = tuple(sum(g[i] for g in directions) for i in range(R.n))
    total_h = tuple(sum(h[i] for h in offsets) for i in range(R.n))
    # The last term controls the output endpoint signs for every p <= cap.
    return max(threshold(R, g, h, cap)
               for g, h in list(zip(directions, offsets)) + [(total_g, total_h)])


def run(trials=180):
    rng = random.Random(1131937)
    start = time.time()
    difference_checks = degree_checks = positive_differences = 0
    examples = []
    for trial in range(trials):
        rank = 2 if trial < 45 else 3 if trial < 115 else 4 if trial < 160 else 5
        D = [rng.randint(1, 3) for _ in range(rank)]
        B = [[0] * rank for _ in range(rank)]
        for i in range(rank):
            for j in range(i + 1, rank):
                b = rng.randint(-3, 3)
                B[i][j] = D[j] * b
                B[j][i] = -D[i] * b
        R = IncomingSchur(B, D)
        cap = (3, 3) if rank == 2 else (2, 2, 1) if rank == 3 else (2, 1, 1, 1) if rank == 4 else (1,) * 5
        g = tuple(rng.randint(-4, 4) for _ in D)
        h = tuple(rng.randint(-4, 4) for _ in D)
        if trial % 6 == 0:
            h = tuple(-v for v in g)  # maximally resonant output direction
        elif trial % 6 == 1:
            h = g  # includes transverse cancellation and constant products
        a = tuple(rng.randint(-3, 3) for _ in D)
        b = tuple(rng.randint(-3, 3) for _ in D)
        if trial % 3 == 0:
            a = b = (0,) * rank
        N0 = exact_bound(R, [g, h], [a, b], cap)
        d = sum(cap)
        values = []
        for k in range(d + 2):
            n = N0 + k
            u = tuple(n * g[i] + a[i] for i in range(rank))
            v = tuple(n * h[i] + b[i] for i in range(rank))
            values.append(structure(R, u, v, cap))
        best = None
        for p in box(cap):
            row = [v.get(p, 0) for v in values]
            differences = []
            for j in range(d + 2):
                x = row[0]
                difference_checks += 1
                positive_differences += x > 0
                if x < 0 or j > sum(p) and x:
                    result = dict(status='FAIL', B=B, D=D, g=g, h=h,
                                  a=a, b=b, cap=cap, N0=N0, p=p, order=j,
                                  difference=x, values=[v.get(p, 0) for v in values])
                    (ROOT / 'computation/structure_ray_binomial_results.json').write_text(json.dumps(result, indent=2))
                    print(json.dumps(result), flush=True)
                    return
                if j == sum(p) + 1:
                    degree_checks += 1
                differences.append(x)
                row = [row[i + 1] - row[i] for i in range(len(row) - 1)]
            if any(differences[1:]):
                best = dict(p=p, binomial_coefficients=differences[:sum(p) + 1],
                            values=[v.get(p, 0) for v in values])
        if best and len(examples) < 12:
            examples.append(dict(B=B, D=D, g=g, h=h, a=a, b=b, cap=cap,
                                 N0=N0, **best))
        if trial % 20 == 19:
            print(json.dumps(dict(completed=trial + 1, checks=difference_checks,
                                  seconds=round(time.time() - start, 2))), flush=True)
    result = dict(status='PASS', inputs=trials,
                  exact_forward_difference_checks=difference_checks,
                  positive_differences=positive_differences,
                  exact_degree_checks=degree_checks, examples=examples,
                  seconds=time.time() - start)
    (ROOT / 'computation/structure_ray_binomial_results.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    run()
