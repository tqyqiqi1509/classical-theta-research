Clear[T,v,z,c1,c2,c3];
q={c1,c2,c3};
bb={{0,2,-2},{-2,0,2},{2,-2,0}};
gg={-1,-1,-1}; ll={2,3,5};
rr=Table[Expand[(T z^Max[gg[[i]],0]
  Product[(z+q[[j]])^Max[bb[[i,j]],0],{j,3}]
  -ll[[i]] (-1)^(Max[-gg[[i]],0]+Sum[Max[-bb[[i,j]],0],{j,3}])
  z^Max[-gg[[i]],0] Product[(z+q[[j]])^Max[-bb[[i,j]],0],{j,3}])
  /.z->-q[[i]]],{i,3}];
ss=c1 c2 c3 (c2-c1)(c3-c1)(c3-c2);
gb=GroebnerBasis[Append[rr,1-v T ss],{v,T,c1,c2,c3},
  MonomialOrder->Lexicographic];
sat=Select[gb,FreeQ[#,v]&];
special=GroebnerBasis[sat/.T->0,{c1,c2,c3},
  MonomialOrder->DegreeReverseLexicographic];
mon={1,c1,c2,c3,c1 c3,c2 c3,c3^2};
nilpotent=And@@(Last[PolynomialReduce[#^3,special,{c1,c2,c3},
  MonomialOrder->DegreeReverseLexicographic]]===0&/@{c1,c2,c3});
{rr,Length[gb],special,Length[mon],nilpotent}
