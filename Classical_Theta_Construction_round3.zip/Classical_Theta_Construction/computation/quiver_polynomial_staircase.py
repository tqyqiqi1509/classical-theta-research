"""Compressed graph-Gale coefficient algebra using monic Q-polynomials.

For each color i, introduce a monic Q_i of degree p_i. Divide the primitive
vertex polynomial by Q_i and impose all remainder coefficients. Saturate by
T and the actual edge resultants/frame constants, then specialize T=0.

This is the invariant Vandermonde-colon quotient of graph_gale_staircase.py,
proved by the Vandermonde adjugate and the alternating projection. In
particular, DO NOT saturate by the discriminants of the Q_i: repeated-root
scheme multiplicities are part of the finite coefficient algebra.
"""
from pathlib import Path
import json
import time
import sympy as s
from graph_gale_staircase import graph_data, color_generic_weights, standard_basis


def polynomial_coefficient_algebra(B,D,g,p,row_exponents=None):
    begin=time.time()
    if not any(p):
        return {'B':B,'D':D,'g':g,'p':p,'coefficient':1,'staircase':[()], 'seconds':0}
    colors,eta=graph_data(B,D,g,p)
    weights,certificate=color_generic_weights(eta,colors,D)
    if row_exponents is None:
        a={c:w for c,w in zip(colors[1:],weights)}
    else:
        assert len(row_exponents)==len(B)
        assert all(int(w)==w for w in row_exponents)
        a=dict(enumerate(map(int,row_exponents)))
        active=certificate['active_colors']
        assert all(sum(f[j]*a[c] for j,c in enumerate(active))
                   for f in certificate['excluded_forms']), 'nongeneric endpoint'
        # Cut genericity is separate from the rank criterion. All frame-free
        # proper cuts are nonzero positive charge vectors bounded by p.
        from itertools import product
        assert all(sum(D[i]*a[i]*q[i] for i in range(len(B)))
                   for q in product(*(range(v+1) for v in p)) if any(q)), 'zero cut'
        certificate['chosen_signed_row_exponents']=list(row_exponents)
    z,T,u=s.symbols('z T u')
    variables=[];Q=[]
    for i,n in enumerate(p):
        ci=s.symbols(f'c{i+1}_1:{n+1}') if n else ()
        variables.extend(ci)
        Q.append(z**n+sum(c*z**(n-k-1) for k,c in enumerate(ci)))
    equations=[];vertex_polynomials=[]
    for i,n in enumerate(p):
        if not n:continue
        incoming=z**max(g[i],0)*s.prod(Q[j]**max(B[i][j],0) for j in range(len(B)))
        outdegree=max(-g[i],0)+sum(max(-B[i][j],0)*p[j] for j in range(len(B)))
        outgoing=(-1)**outdegree*z**max(-g[i],0)*s.prod(Q[j]**max(-B[i][j],0) for j in range(len(B)))
        F=s.expand(T**max(a[i],0)*incoming-T**max(-a[i],0)*outgoing)
        remainder=s.rem(F,Q[i],z)
        equations.extend(s.Poly(remainder,z).all_coeffs())
        vertex_polynomials.append(str(F))
    boundary=s.Integer(1)
    for i,n in enumerate(p):
        if n and g[i]:boundary*=Q[i].subs(z,0)
        for j in range(i+1,len(B)):
            if n and p[j] and B[i][j]:boundary*=s.resultant(Q[i],Q[j],z)
    saturation=s.groebner(equations+[u*T*boundary-1],u,*variables,T,order='lex')
    sat=[f.as_expr() for f in saturation.polys if not f.as_expr().has(u)]
    special=[f.subs(T,0) for f in sat]
    gb0=s.groebner([f for f in special if f!=0],*variables,order='grevlex')
    stair=standard_basis(gb0)
    return {'B':B,'D':D,'g':g,'p':p,'coefficient':len(stair),
            'variables':[str(x) for x in variables],
            'Q_polynomials':[str(f) for f in Q],
            'vertex_polynomials':vertex_polynomials,
            'remainder_equations':[str(f) for f in equations],
            'boundary_resultants':str(boundary),
            'generic_weight_certificate':certificate,
            'saturated_generators':len(sat),
            'special_groebner_basis':[str(f.as_expr()) for f in gb0.polys],
            'staircase':stair,'seconds':time.time()-begin}


def run():
    from incoming_recursion import IncomingSchur
    cases=[
      ([[0]],[1],[-3],[2]),
      ([[0]],[2],[-3],[2]),
      ([[0,1],[-1,0]],[1,1],[-2,-1],[1,1]),
      ([[0,1],[-1,0]],[1,1],[-2,1],[2,1]),
      ([[0,2],[-2,0]],[1,1],[-1,-1],[1,1]),
      ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-1,-1],[1,1,1]),
      ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-2,0],[2,1,1]),
      ([[0,3],[-2,0]],[2,3],[-2,1],[2,1]),
      ([[0,3],[-2,0]],[4,6],[-2,1],[2,1]),
    ]
    results=[]
    for B,D,g,p in cases:
        out=polynomial_coefficient_algebra(B,D,g,p)
        out['independent_incoming_coefficient']=IncomingSchur(B,D).theta_prefix(tuple(g),tuple(p)).get(tuple(p),0)
        out['pass']=out['coefficient']==out['independent_incoming_coefficient']
        results.append(out)
        Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps({k:out[k] for k in ('p','D','coefficient','independent_incoming_coefficient','pass','seconds')}),flush=True)
        assert out['pass'],out


if __name__=='__main__':run()
