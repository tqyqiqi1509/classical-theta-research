SeedRandom[20261113];
ClearAll[splitTree, etaSum, clusterColumn];
splitTree[s_List] := If[Length[s] == 1, {s, {}, {}},
 Module[{q = RandomSample[s], k, l, r, left, right},
 k = RandomInteger[{1, Length[s] - 1}];
 l = Take[q, k]; r = Drop[q, k];
 left = splitTree[l]; right = splitTree[r];
 {s, Join[left[[2]], right[[2]], {s}],
 Join[left[[3]], right[[3]], {{l, r}}]}]];
etaSum[a_, l_, r_] := Total[Flatten[a[[l, r]]]];
clusterColumn[a_, s_] := Table[If[MemberQ[s,j], Total[a[[s,j]]], 0], {j,Length[a]}];
checks = Flatten[Table[Table[
 Module[{raw, a, tree, cols, det, rhs},
 raw = RandomInteger[{-7,7},{n,n}]; a = raw - Transpose[raw];
 tree = splitTree[Range[n]];
 cols = Transpose[clusterColumn[a,#]& /@ tree[[2]]];
 det = Det[Rest[cols]];
 rhs = Times @@ (etaSum[a,#[[1]],#[[2]]]& /@ tree[[3]]);
 {n, Abs[det] == Abs[rhs], det == 0}],
 {250}],{n,2,9}],1];
a4 = {{0,a,b,c},{-a,0,d,e},{-b,-d,0,f},{-c,-e,-f,0}};
m4 = Transpose[clusterColumn[a4,#]& /@ {{1,2},{3,4},{1,2,3,4}}];
<|"checks"->Length[checks],"allPassed"->And@@checks[[All,2]],
"zeroDeterminants"->Count[checks[[All,3]],True],
"symbolicFourVertexDeterminant"->Factor[Det[Rest[m4]]],
"expectedAbsoluteProduct"->a f (b+c+d+e)|>
