ClearAll[t, valuation];
valuation[a_Integer, p_Integer] := If[a == 0, Infinity, IntegerExponent[a, p]];
f = 1 + 2 t + 3 t^2 + 5 t^3;
rows = Flatten[Table[
  a = p^s b;
  left = Coefficient[Expand[f^(p a)], t, p j];
  right = Coefficient[Expand[f^a], t, j];
  {p,s,b,j,Mod[left-right,p^(s+1)]},
  {p,{2,3,5}},{s,0,2},{b,1,3},{j,0,9}],3];
bad = Select[rows, Last[#] != 0 &];
derivRows = Flatten[Table[
 a=p^s b; c=Coefficient[Expand[f^a],t,j];
 {p,s,b,j,If[c==0,True,valuation[c,p]+valuation[j,p]>=valuation[a,p]]},
 {p,{2,3,5}},{s,0,3},{b,1,3},{j,1,12}],3];
derivBad=Select[derivRows,Last[#]=!=True&];
<|"GaussLocalChecks"->Length[rows],"GaussFailures"->bad,
 "DivisibilityChecks"->Length[derivRows],"DivisibilityFailures"->derivBad,
 "TestPolynomial"->f|>
