# Research cycle 2 — review at 2026-11-13 17:49 UTC

The research remains active. The nine-hour requested endpoint has not been reached. This cycle continued mathematical construction and literature work; it did not switch to preparing a final package.

## Results strengthened during this cycle

1. A fresh review accepted the finite-order continuous-gluing and stable-ray mechanisms after adding the necessary restriction to [0,p] for each target row. The same review proved translated-ray stabilization and a positive transverse formal theta family. Its exact structure constants are the eventual fixed-degree structure constants of translated large labels. No assertion that the transverse object is itself a cluster algebra is made.
2. The original Möbius proof was strengthened from a C_h word action plus arithmetic division to an actual C_N action. A prefix orbit of length r=N/d carries its next word by a/d slots when the prefix phase wraps. All subgroup fixed points are precisely repeated words, and lexicographic representatives make repetition maps equivariant. This gives positive prime-power congruences and primitive free-orbit counts directly. A further fresh review is still requested.
3. Stable supports admit an atom semigroup. An elementary formal-series argument, applied to the new stable theta root, identifies the exact eventual degree in the label multiplier as maximum atom-factorization length. The leading coefficient is a weighted integer-factorization-polytope count. The monoid may be infinitely generated; the finite-cutoff statement is effective. Its general formal-series idea has antecedents in eventual positivity, so it is not advertised as a new theorem of analysis.
4. Complete-symmetric theta elements yield an intrinsic positive pre-lambda structure with additive label-dilation operations. These operations are generally not multiplicative, already in a rank-one exchange relation. No special lambda ring or Schur positivity is claimed.

## New finite-output interface

The previous package already had a binomial moment matrix for adjacent Laurentness. The real missing step was an effective root support bound. A new interface uses finite theta-span membership and valuative independence: any signed pointed solution to the finite divisibility equations supplies a Newton envelope for theta_g. Under the established hypothesis mid=up, enumerating boxes and solving exact rational linear equations terminates for every regular theta label. A found witness also certifies regularity; failure below a radius does not certify nonregularity.

A second mechanism requires no mid=up theorem or valuative-independence input: enumerate positive cluster-variable products and test all their finitely many possible theta outputs. A positive occurrence of theta_g gives a sparse coefficientwise carrier. For theta_g actually belonging to the cluster algebra, a finite cluster-product expression guarantees that some product in the enumeration contains it. The full principal label, including frozen translations, is indispensable.

Both mechanisms are general constructions. They do not claim a useful uniform complexity bound. The binomial-kernel program is now connected to the existing finite coefficient engine and returns complete Laurent expansions under its stated structural hypothesis.

## Primary literature inspected and resulting novelty corrections

- Qiyue Tang, Hexagon 2610.00083v2, Strongly positive bases and quantum greedy expansions: the root and intrinsic-greedy agent inspected Proposition 4.3 and Section 5. Rank-two generic large-label chart stabilization, with a finite directional threshold, already occurs here. The present candidate increment is arbitrary rank, resonant directions and the transverse stabilization theorem. Section 3 relies on quantum bar-degree bounds; it does not automatically apply to arbitrary classical strongly positive bases after setting v=1.
- Moree, math/0311194v2: ordinary necklace/Witt positivity is prior art, even for the original C_h construction on each skeleton. The new candidate is the carry action on theta decorations and its consequences, not necklace inversion.
- Gossow, 2410.05678v2, Sections 3–6: the abstract notion of a divisor-compatible cyclic family (Lyndon structure) and its Gauss/CSP implications are prior art. The source does not provide this cluster application. No quantum interpretation is imposed on an auxiliary word statistic.
- CMMM, 2505.09585v2: root inspected Lemma 2.9 in full, which already gives Newton dilation by label multiples. It is not new. The finite valuative-independence chain in Sections 2–3 was independently scrutinized for the signed-envelope application; no Li–Pan-dependent input is used. Theorem 3.8 is used only for finite regular theta expansions.
- Fei, 1909.10151v3: the face/stabilization proof is being read in detail. It concerns a given finite-dimensional representation and cannot by itself supply an unknown theta representation or stopping bound.
- Fei, Hexagon 2611.00328v1, Corollary 9.3 and Section 5.1: close prior interface between known bounded Newton support, valuative independence and Laurent divisibility. This is a 2026 LP/minuscule manuscript, so it is used for novelty comparison only. Its cited companion manuscript has not been located publicly. The current proposed finite algorithm differs by generating the unknown support bound from any signed pointed solution rather than assuming the bound or a one-dimensional kernel first.
- Leung–Ma–Young 1902.05765: the early MPIM and later IMRN author drafts have a substantive change in their theta-construction section. The obsolete strong monomial-near-ray formulation is not adopted. See the detailed version record in the stable reviewer directory.

## Checks and failed extensions retained

- Translated rays: 36 inputs, 1,800 coefficient comparisons and 600 structure-coefficient comparisons; all passed. The latter include genuinely nonzero transverse corrections, not only empty cases.
- Carry cyclic sets: 10,660 decorations enumerated, all subgroup fixed sets and divisor maps verified. Wolfram independently checked a mixed-orbit 420-point example. These tests use explicit word permutations rather than the prior theta engine.
- The stable zero-weight slice is not automatically a full exposed Newton face. A positive-weight coefficient was found and retained as a precise correction to that interpretation.
- General Schur positivity fails in a uniform wild rank-two family, proved independently from the greedy recurrence. The positive complete-symmetric statement remains intact.
- The full scheduling-independent combinatorial associator remains a hard active task. Hall Harder–Narasimhan uniqueness does not automatically descend through Euler-characteristic integration to a bijection of tight-Dyck objects; the missing boundary-covector transport is being attacked directly.

## Next work

Finish fresh audits of the finite-output and cyclic-set constructions, independently compare the complete Laurent program with mutation-computed F-polynomials, continue the intrinsic greedy/associator route, and search for exact predecessors of the arithmetic and translated-ray results. Keep successful and unsuccessful mechanisms in the log, without replacing the main problem by example collection.
