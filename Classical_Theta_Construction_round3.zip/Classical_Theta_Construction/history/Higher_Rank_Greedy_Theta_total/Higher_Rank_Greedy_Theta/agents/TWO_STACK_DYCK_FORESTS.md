# Tight gradings as two-stack boundary trees

Research date: 2026-11-13. This note gives an intrinsic graph definition
of the actual local objects, in every degree. No scattering coefficient,
enumeration index, or set with a prescribed cardinality enters the
definition. It also states exactly which information remains necessary
for a genuine insertion/coherence construction.

## 0. Prior interface and what is proved here

Burcroff--Lee--Mou's local coefficient formula uses compatible, shadowed
gradings on maximal Dyck paths. The user's earlier work, Qiyue Tang,
*Algebraicity of rank-two scattering wall functions*,
<https://hexagonmath.org/pdf/2610.00645v1>, Sections 2--3, already uses
protected stack matching and a single-root interval. Its Lemma 2.2
identifies legality with compatibility, and Proposition 3.2 identifies
the single-root frame. Those are prior interfaces, not novelty claims
of this note. The relevant primary text has been inspected; none of its
later algebraicity or differential-equation claims is needed here.

Here the compatibility criterion is rederived as **acyclicity of two
canonical cyclic matchings**. This works for an arbitrary cyclic NE
word, arbitrary nonnegative weights, and weak inequalities for the two
totals. Tightness is a root-color condition. In the actual determinant-
one maximal Dyck frame this reduces to one nontrivial tree, including
the minimal rectangles where a total equals its service count. The
proofs below are self-contained. This tree is a boundary-embedded
matching tree; it is not asserted to be a quiver stable tree, an arbitrary
plane tree, or an established associative normal form.

## 1. Two canonical cyclic LIFO matchings

Let C be a cyclic word with W horizontal letters E and H vertical
letters N, with W,H>0. Its positions are the vertices of a graph. Give
each position v a nonnegative integer grade omega(v), and suppose

    q = sum_(E positions) omega <= H,
    p = sum_(N positions) omega <= W.                 (1.1)

For the horizontal matching, traverse the word forwards. At an E
position h, push omega(h) tokens carrying the vertex name h. At an N
position, pop one token if possible and join its producer to this N
position. Save the N positions met with an empty stack. At the end,
use these saved positions in their original forward order to pop the
remaining tokens. Condition (1.1) guarantees that all tokens are popped.
Any remaining saved positions are free services. Orient every edge
from its producer E to its service N.

For the vertical matching, traverse the same word backwards. Each N
position v pushes omega(v) tokens; each E position pops one. Finish
the cyclic matching by the same saved-prefix rule, now in the reverse
traversal order. Orient every resulting edge from N to E.

These are cyclic parenthesis matchings. Equivalently, repeatedly cancel
an open token with the next closing token with no intervening uncancelled
token. The usual nested-pair rule shows that they do not depend on the
arbitrary starting cut. One can also cut after a free service, if there
is one. If the producer and service counts are equal, a cut at a minimum
of the cumulative parenthesis height makes all matching intervals
ordinary nonwrapping intervals. This proves cut-independence in the
equality case as well.

Write G(omega) for the union of the two directed matchings. Each vertex
has indegree at most one: it is a unit service in just one matching.
Its outdegree is exactly its original grade. The graph is bipartite and
has p+q edges. Opposite directed edges between the same two vertices
are retained; they constitute a two-cycle, not one undirected edge.

## 2. Matching intervals are exactly shadow intervals

A positive horizontal vertex h starts a first-return interval: the
first following N at which the number of N positions equals the sum
of E grades since h. A positive vertical vertex has the reversed
definition. These returns exist within one cycle under (1.1), including
equality: the initial increment is positive, the complete-cycle increment
is nonpositive, and every negative step has size one.

In a stack, the last token of h is popped precisely at the end of its
first-return interval. Later producers opened inside that interval
empty before this last token is popped. Thus every service inside h's
interval has a producer inside the same interval. Every service matched
directly to h belongs to its shadow. The reversed statements hold for
vertical shadows. Two useful consequences are:

1. The union of all horizontal shadows is exactly the set of N vertices
   with a parent in G. The union of all vertical shadows is exactly the
   set of E vertices with a parent.
2. If I=[h,v] is an initial part of h's forward shadow interval, every
   N in I has its horizontal parent in I. If the same I is a final part
   of v's backward shadow interval, every E in I has its vertical parent
   in I.

The second consequence concerns every service vertex in the interval,
including zero-grade vertices. It is stronger than just following the
two positive endpoints.

## 3. Compatibility is exactly acyclicity

**Theorem 3.1.** Under (1.1), the literal compatible-grading condition
holds if and only if G(omega) is acyclic. Since indegrees are at most
one, this is also equivalent to its underlying multigraph being a forest.

The shadow form of the literal condition says that there are no positive
h of color E and positive v of color N for which

    v belongs to sh(h) and h belongs to sh(v).        (3.1)

Indeed, a strict horizontal compatibility witness occurs exactly when
the first horizontal return is before v; a strict vertical witness
occurs exactly when the first backward return is after h. Neither exists
precisely in (3.1). This uses the strict endpoint exclusions in the
original definition; in particular adjacent E_1 N_1 is incompatible.

Suppose first that (3.1) occurs. The cyclic interval I=[h,v] lies inside
both corresponding shadow intervals. By Section 2, every N in I has
its horizontal parent in I and every E in I has its vertical parent in
I. Thus every vertex of this finite nonempty interval has an internal
parent. Repeatedly following parents produces a directed cycle.

Conversely suppose the grading is compatible. Choose a cyclic cut for
which all horizontal shadow intervals are nonwrapping. If q<H, cut at
a free N service. If q=H, cut at a minimum of the balanced cumulative
height. These choices were justified in Section 1. Consider two successive
edges of a putative directed cycle,

    h -> v -> h',          h,h' horizontal.

The first edge implies h<v in the resulting linear order and v in
sh(h). Compatibility implies h is not in sh(v). The backward interval
of v therefore cannot cross h; if it crossed the cut it would in
particular contain h. Its horizontal service h' satisfies h<h'<v.
Consequently horizontal vertices would strictly increase at every
two-edge step around the cycle, which is impossible. This proves
acyclicity.

Finally, in a graph with indegree at most one, an undirected cycle would
have as many edges as vertices on that cycle. Every cycle vertex must
then have exactly one incoming cycle edge, giving a directed cycle.
This includes the retained two-edge multicycle. The two notions of
acyclicity are therefore equivalent here.

## 4. Tightness is the color of nontrivial roots

In a directed forest with indegrees at most one, each component has
one root and all edges point away from it. A zero-grade vertex has
outdegree zero; if it is also a root, it is isolated.

By Section 2, the inclusion of all positive E vertices in vertical
shadows is exactly the assertion that every positive E vertex has a
parent. This holds precisely when every nontrivial component is rooted
at N. The other shadow inclusion is equivalent to all nontrivial
components being rooted at E. Therefore:

**Theorem 4.1.** The grading is compatible and shadowed if and only if
G(omega) is a forest and all its nontrivial components have roots of
one common color. Isolated zero-grade vertices of either color are
allowed. With the prescribed totals and determinant condition of the
local factory, this is exactly tightness.

The total number of roots is

    W+H-p-q.                                         (4.1)

If p=W and q=H, every vertex has a parent. The finite nonempty graph
has a cycle, so there are no compatible gradings. This handles the
double equality without appealing to an unavailable free service.
If p=q=0, all vertices are isolated, and both shadow inclusions hold
vacuously. A zero vertex with a parent is a leaf, not an isolated vertex.

## 5. The actual determinant-one frame has a single nontrivial tree

Let A,B be positive coprime integers, k>=1, and let C be the maximal
lower Dyck path in a rectangle satisfying

    AH-BW=1,       W>=kA,       H>=kB,
    p=kA,          q=kB.                              (5.1)

The sign-reversed version is obtained by interchanging the colors and
the traversal direction. We prove the positive sign explicitly.

For a path vertex at (x,y), put rho(x,y)=Hx-Wy. Horizontal starts have
ranks in [0,W), vertical starts in [W,W+H). Since gcd(W,H)=1, each
integer rank in [0,W+H) occurs exactly once among the edge starts.

First tightness must use the inclusion of positive E vertices in
vertical shadows. To see this, suppose instead that all positive N
vertices lie in horizontal shadows. A maximal horizontal shadow interval
has m_i+1 horizontal and n_i vertical vertices. Its horizontal total is
n_i. Compatibility forces every vertical matching edge from a vertex
in this interval to land inside it and to avoid its horizontal root:
otherwise the root and that vertical vertex have mutual shadows. Hence
its vertical total is at most m_i. Maximal intervals are disjoint, so
sum n_i=q and sum m_i>=p. Comparing the ranks of its first horizontal
and last vertical starts gives

    delta_i=n_i W-m_i H>0.

It follows that pH-qW=(p-sum m_i)H-sum delta_i<0, contradicting
pH-qW=k>0. Thus the required inclusion is the other one.

Now consider maximal vertical shadow intervals. Write their counts as
n_i horizontal and m_i+1 vertical vertices. Their total vertical grade
is n_i. The same compatibility argument gives horizontal total at most
m_i in each interval. Since all positive horizontal vertices are covered,

    sum n_i=p,       sum m_i>=q.

Their first horizontal start has rank below W, and the root vertical
start has rank at least W. Therefore

    delta_i=n_i H-m_i W>0,
    k=sum delta_i+(sum m_i-q)W.                       (5.2)

Since W>=kA>=k and sum delta_i>=1, (5.2) forces

    sum m_i=q,       sum delta_i=k.

Using AH-BW=1 gives

    A delta_i-n_i = W(B n_i-A m_i).

Both A delta_i and n_i are positive and at most p<=W. Their difference
has absolute value strictly less than W, even when p=W. Therefore

    n_i=A delta_i,       m_i=B delta_i.               (5.3)

Write the rank of the root vertical start as W+ell_i. Comparing ranks
with the first horizontal start yields 0<=ell_i<delta_i. On the periodic
Dyck path, translate that root start backwards by ell_i(A,B). Its rank
is W. Every integer lattice point of rank W is a vertical start of the
periodic path, since it differs from the unique such start by a multiple
of (W,H). Formula (5.3) and ell_i<delta_i put this start inside the same
maximal interval. Consequently every maximal interval contains the
unique cyclic vertical start of rank W. Disjointness forces there to be
exactly one maximal interval.

That interval contains p horizontal and q+1 vertical vertices. Every
positive vertex belongs to it. All vertical matching edges remain
inside it by definition; all horizontal matching edges remain inside
and avoid its vertical root by compatibility. The induced graph is a
forest with p+q+1 vertices and p+q edges, hence it is one tree. Every
vertex outside it is isolated and zero-grade. Its root is vertical and
has rank

    W+ell,             0<=ell<k.                     (5.4)

This proves the single-tree statement in the smallest allowed rectangle
as well as in any enlarged rectangle satisfying (5.1). It recovers the
earlier single-root interface while making the graph and equality cases
explicit. In the minimal rectangle, writing W=kA+r0, H=kB+s0 gives
0<=r0<A, 1<=s0<=B, As0-Br0=1. There are r0+s0 total roots, exactly
one nontrivial, and r0+s0-1 isolated vertices. The number of isolated
vertices is independent of k.

## 6. Literal inverse, linear construction, and positive core

A two-stack boundary forest is the following finite object: the fixed
cyclic NE vertex word, a nonnegative grade on each vertex, and the two
canonical matchings of Section 1, required to be acyclic and to have
nontrivial roots of one color. Equivalently one may give the directed
graph and require that each matching is the canonical cyclic LIFO
matching for its outdegrees. Reading outdegrees recovers the grading;
rebuilding the two stacks recovers exactly the graph. Thus this is a
literal bijective encoding, with no cardinality-defined auxiliary sets.

The matching constraints are essential. An arbitrary rooted bipartite
tree on abstract vertices need not embed in the prescribed Christoffel
boundary with those two canonical matchings. Forgetting this boundary
condition is not an inverse construction.

### 6.1 A direct tree definition with no grading or shadow predicate

For the determinant-one data (5.1), the local objects can be defined
directly by elementary graph conditions. For each ell in [0,k), locate
the vertical start of rank W+ell. Let I_ell be the forward path interval
from the horizontal start obtained by subtracting (p,q) from this point
to that vertical edge, inclusive. The starting rank is W+ell-k, in
[0,W), so it is indeed a horizontal start. This interval has exactly
p horizontal and q+1 vertical vertices; its last vertex is the root.

The interval is defined on the periodic path before reducing vertex
indices modulo W+H. Since p+q+1<=W+H, it contains no repeated vertex.
It is allowed to cross the original beginning of the Dyck word. Its own
linear order, starting at the specified horizontal vertex and ending
at the root, is the order used below. Thus no arbitrary cut or extra
cyclic rotation is part of the object. Equality p=W is allowed; the
positive determinant implies q<H. The vertices outside this interval
will be isolated and carry no data.

Choose a rooted bipartite spanning tree on these vertices, orienting
edges away from the root, subject to the following conditions:

1. For every edge, its horizontal endpoint is earlier than its vertical
   endpoint in the linear order of I_ell.
2. Draw an edge on the first page when its parent is horizontal and on
   the second page when its parent is vertical. Edges on the same page
   do not cross. Explicitly, there are no four strictly ordered vertices
   a<b<c<d with same-page edges {a,c} and {b,d}. Shared endpoints are
   allowed.
3. A horizontal outdegree is divisible by the prescribed input factor u;
   a vertical outdegree is divisible by v. A positive vertex of outdegree
   u j or v j carries an actual element of the corresponding input
   coefficient set. Zero-outdegree vertices have no such decoration.

No shadow or coefficient value appears in this definition. Put zero
grades on the vertices outside I_ell and set the grade of a tree vertex
equal to its outdegree. Its horizontal total is q, because every N
vertex other than the root has exactly one H parent. Its vertical total
is p, because every H vertex has exactly one N parent.

A rooted tree is specified by its ordinary edges and root; equivalently
every nonroot has one parent, the root has none, and the graph is
connected and acyclic. There is no additional label or ordering on
tokens at a common producer. Its children are already ordered by their
boundary positions. Shared endpoints therefore introduce no factorial
multiplicity. A vertex of outdegree zero inside the interval is a tree
leaf; one outside the interval is isolated.

**Proposition 6.2.** This direct tree construction is in literal
bijection with the decorated tight gradings of the local factory.

For sufficiency it remains only to show that the two tree pages are the
canonical matchings. Consider the horizontal page in forward order.
At a service N, suppose its assigned parent h were not the most recently
opened producer with an unused token. Such a more recent producer h'
has h<h'<N and must use its remaining token at a later service N'.
The endpoints h<h'<N<N' give a forbidden crossing. Thus every service
uses the latest open producer. All N vertices except the final root
are served, and the final root is free. This is exactly the first stack
matching. Applying the same argument in reverse order proves the
second matching. The graph is already a tree and its root is vertical,
so Theorem 4.1 proves tightness. Necessity follows from Section 5 and
the noncrossing property of each LIFO matching. Reading outdegrees and
then rebuilding the matchings are inverse operations and retain every
input decoration.

Both linear stacks finish empty on this window. For the horizontal
stack the root is the final unused N service. For the reverse vertical
stack all H services in the window are used. Adding the outside
zero-grade isolated vertices therefore creates only unused services,
and cannot change either matching. This also proves the assertion when
the chosen window wraps around the original word or occupies the whole
word. The crossing argument compares distinct producers h<h'; several
edges at one producer share an endpoint and are matched in boundary
order, so its strict four-endpoint test remains valid at all ties.

For a normal power c, use the prescribed ordered c-tuple of these trees,
with degrees summing to the requested degree; degree zero contributes
the empty tree. Thus even the full valued local factory has a direct
finite graph definition. The root window and two pages are essential
geometric boundary data, not an additional scattering-theoretic input.

For the valued operation on carriers alpha,beta with m=K(alpha,beta)>0,
put u=m/d(alpha), v=m/d(beta). For a coprime output pair (s,t) and
coefficient degree j>0, the direct tree parameters are

    ell=gcd(sv,tu),  A=sv/ell, B=tu/ell,
    k=j ell,        p=jsv,    q=jtu.

The number of ordered normal copies remains exactly

    c=d(s alpha+t beta)/gcd(s d(alpha),t d(beta)).

The unreduced output carrier s alpha+t beta is retained. Degree-zero
slots contain the unique empty object. A positive vertical vertex of
outdegree v r is decorated by the alpha input coefficient of degree r;
a positive horizontal vertex of outdegree u r uses the beta input.
Every normal-copy slot and input decoration is preserved; no phase
quotient or primitive-carrier reduction is performed.

Because p+q<=W+H, the expanded token count is linear in the boundary
length L=W+H. Building the two matchings takes O(L) time and memory.
A parent-pointer cycle check and the root-color check also take O(L).
Thus the local predicate can be implemented without constructing every
shadow interval or testing every positive horizontal/vertical pair.

For the determinant-one tree, delete all zero-grade leaves. Its remaining
positive vertices form a connected rooted bipartite tree: every vertex
strictly between a positive vertex and the root has a child and so has
positive grade. If a positive vertex v has grade a_v and c_v positive
children, it has exactly a_v-c_v zero children. The original stack order
orders its children; its c_v positive children therefore occupy an
increasing c_v-subset of [1,a_v]. Recording these child slots compresses
the local arity information. Boundary positions and the two stack rules
must still be retained to reconstruct the original grading. They are
the precise additional constraints on the product of these elementary
slot simplexes; they cannot yet be discarded in favor of free tree
grafting.

## 7. Insertion/coherence status

This all-degree tree encoding resolves compatibility intrinsically.
It does not by itself establish an associative multi-input operation.
In a nested Dyck birth, replacing a decorated positive vertex by its
inner tree changes the normal arity and the surrounding Christoffel
boundary. A valid insertion must specify the induced boundary slot
order and verify both canonical matchings after the replacement.
The first ABC rectangle maps solve the one-pair component, including
unequal normal contents; see `valued_coherence_phase_transport.md`.
The singleton-side cyclic-word and framed-spine constructions are now
proved in `SINGLETON_CYCLIC_PHASE_AND_ATOM_SPLITTING.md` and
`FRAMED_SPINE_FUSION_TRANSPORT.md`. An unrestricted all-degree triple
map remains a separate requirement, rather than a consequence of the
word "tree".

### 7.1 Padding preserves the actual tree window word

Fix coprime A,B, degree j, and root residue ell in [0,j). In any
determinant-one frame AH-BW=1 with W>=jA,H>=jB, the active interval
of Section 6.1 has the same NE word. Thus the intrinsic tree itself,
its directed edges, outdegrees and decorations give a literal bijection
between this interval in the smallest frame and in every larger frame.

Here is a direct proof. The starting rank is W-j+ell. At relative
coordinates (x,y), the normalized rank is

    1+Bx/A-y+(x/A+ell-j)/W.

For the horizontal start in column x, 0<=x<jA, its relative height is

    y(x)=1+floor(Bx/A+(x/A+ell-j)/W).

If Bx/A is nonintegral, its fractional part is at least 1/A away
from either next integer boundary, and the correction cannot cross a
boundary because W>=jA. If it is integral, the floor changes by -1
or 0 according only to the sign of the integer x/A+ell-j. This sign
does not depend on W. The possible endpoint correction -1 gives the
same floor as every smaller negative correction. Hence all y(x) and
the final vertical edge are independent of padding. This proves the
literal word identity, not merely equality of coefficient counts.

### 7.2 A single shadowed repeated frame realizes every positive power

There is also an all-degree common path model for a positive wall
power. Fix A,B,k and a positive integer M. Choose a sufficiently wide
determinant-one frame (W0,H0), for example with

    W0>=kA, H0>=kB,
    L0=W0+H0>2k(A+B)+2.

Use the maximal path in the rectangle (M W0,M H0), whose word is
exactly M repetitions of the base word. Consider compatible, shadowed
gradings with vertical total p=kA and horizontal total q=kB. These
are not called tight in the determinant-one sense when M>1.

**Proposition 7.3.** These actual shadowed gradings are in literal
bijection with ordered M-tuples of tight trees in the usual minimal
frames, whose degrees sum to k. Divisibility and every coefficient
decoration are retained.

To prove this, the determinant sign first forces all positive H
vertices to lie in vertical shadows, by the argument in Section 5.
For each maximal vertical interval write its counts as n_i horizontal
and m_i+1 vertical vertices. Use the normalized rank H0 x-W0 y on
the periodic path, and put delta_i=n_i H0-m_i W0. Then delta_i>0,

    k=sum delta_i+(sum m_i-q)W0.

As W0>=k and the positive sum is nonzero, sum m_i=q and
sum delta_i=k. The determinant-one identity and the same bounded-
multiple argument as in Section 5 imply

    n_i=A delta_i,       m_i=B delta_i.

Every interval saturates its horizontal-grade bound, since the sums
do. Its two-stack graph is therefore a tree of degree k_i=delta_i.
Its root has normalized rank W0+ell_i with 0<=ell_i<k_i, and the
interval contains a vertical vertex of normalized rank W0. The
repeated path has precisely M such distinguished vertices, one per
period. Their distance is L0, larger than any component interval, so
each component contains exactly one. Disjoint intervals have different
distinguished vertices. These ordered anchors assign the components
to the M tuple slots; unused slots are empty. Section 7.1 moves each
tree, unchanged, to its minimal degree-k_i frame.

Conversely lift the tree in slot i to the window around the i-th
anchor in the repeated path. Every window stays within distance
k(A+B)+1 of its anchor. The chosen L0 makes distinct windows disjoint.
Put zeros elsewhere. Both canonical matchings are the disjoint union
of the component matchings, so the result is a forest whose nontrivial
roots are all vertical. Theorem 4.1 proves compatibility and shadowedness.
The constructions are inverse. They preserve the actual normal slots,
vertex outdegrees, input coefficient objects and external labels.

This supplies a literal path realization of the established positive
power coefficient identity. It does not claim that every smaller
one-bending frame has already been related to this repeated frame,
or that two different unframed wall directions can be rerouted by it.

### 7.3 What a binary-to-flat associator still needs

The genuine local fusion transport of `FRAMED_SPINE_FUSION_TRANSPORT.md`
removes the local phase and mixed-sign obstacles: a framed spine is an
ordinary F-slot word, and moving its marked fusion through one fixed
unframed packet is a positive cut and regrouping of those slots. The
growth-compatible ABC rectangle commutes with increasing the fusion
parameter. These local maps have been independently checked here.

The remaining positive substitution map would have the form

    disjoint union_(a+t=v)
       C_(g1,g2)(a) x O(g1+g2+B a,t;U)
      -> disjoint union_(r+s=v) O(g1,r;U) x O(g2,s;U).

Its charge contraction is exact: e0+e1+a has normal content one and
the unframed pairing row -D(g1+g2+B a). What is not yet proved is
routing the local slot cuts through the actual causal catalogs when
two nonparallel unframed packets meet, while reaching the canonical
inner endpoint D(g1+g2+B a)+epsilon. That endpoint is generally not
covered by the radial-germ lemma.

If an actual natural substitution map of this form is constructed,
every binary multiplication tree can be expanded from its root into
the flat all-arity object set at one common final endpoint. Independent
subtree expansions commute. Calling that explicit flattening F_T,
the comparison F_R^(-1)F_L between two bracketings automatically
satisfies the pentagon by cancellation through the common normal form.
This is a sufficient construction principle, not a bijection obtained
from equal cardinalities. Neither the single-wall slot cut nor the
repeated-frame decomposition alone supplies the missing global routing.

## 8. Verification and route record

Implementation: `computations/two_stack_shadow_forests.py`. It constructs
actual parent edges and checks cycles and root colors. The independent
reference is the literal cyclic-subpath compatibility definition in
`tight_grading_two_input.py`; shadow unions, saturation, and the
single-tree corollary are also compared. Exact results are recorded in
the adjacent JSON file. These checks validate the implementation of the
general proof rather than establish a special-case coefficient claim.

* 15:03--15:12: derived and proved the two-stack acyclicity criterion;
  111,022 bounded gradings agreed with the literal compatibility test.
* 15:12--15:19: inspected the primary protected-stack prior interface,
  proved the saturated cases and determinant-one single-tree corollary,
  and implemented the linear criterion.
* 15:19: the completed structural check passed on 167,728 gradings from
  25 maximal paths and 99 other NE words. It included 126,811 gradings
  with at least one saturated total and 40,917 with both totals saturated;
  the single-tree corollary was checked on 488 relevant tight gradings.
* 15:30--15:34: converted the matching encoding into the direct two-page
  tree definition in Section 6.1. The no-crossing argument proves its
  literal inverse, without calling an interval compatibility predicate.
* `computations/intrinsic_two_page_trees.py` implements the direct graph
  definition without shadow predicates. It enumerated 848 pure graph
  candidates and accepted 99 trees across 26 root windows, including
  five wrapped windows. Every decoder/encoder round trip agreed with
  the literal local factory, including 467 valued-divisibility filters.
* 15:57--16:01: proved padding invariance and the repeated-frame power
  decomposition. A direct check compared 2,484 padded window words.
  `computations/repeated_frame_tight_power.py` separately compared every
  literal shadowed grading against the lifted ordered tuples on four
  repeated frames: 5,136 candidates, 15 objects, exact set equality.
  These are implementation checks of Sections 7.1--7.2, not their proof.
* Positive-core slot compression is exact with retained boundary data;
  unrestricted tree substitution is not yet proved. No assertion about
  stable quiver trees or a general Tamari/crystal associator is made.

### Further primary interface checked, but not used as a theorem

Châtel--Pons, <https://arxiv.org/pdf/1212.0751>, Definition 2.5 and
Proposition 2.6, gives interval-posets for Tamari intervals. Rognerud,
<https://arxiv.org/pdf/1801.04097>, Definition 4.4, singles out modern
interval-posets by excluding predecessors on both sides of one vertex.
Their primary texts were inspected at 15:40. Full first-return intervals
of the present two-stack objects suggest a colored modern interval-poset
interface, but its exact image and closure under the required charge-
changing graftings were not used or asserted here. In particular, the
existing Tamari operad cannot by itself certify the theta associator.
