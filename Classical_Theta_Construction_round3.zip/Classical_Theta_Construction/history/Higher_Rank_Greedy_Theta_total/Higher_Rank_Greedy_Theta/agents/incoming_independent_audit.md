# Independent audit of the incoming-normalized integer recursion

**Scope.** Classical cluster algebras with principal coefficients, arbitrary
integral skew-symmetrizable exchange matrix `B`, positive integral diagonal
symmetrizer `D`, arbitrary initial exponent `g`, and a prescribed finite
downward-closed set of nonnegative root degrees. This is an independent audit
of `agents/incoming_recursion.py`, not of the entire inherited package.

**Verdict.** The new recursion is mathematically justified by the incoming
parameterization of the completed cluster group and the prior final-exponent
extraction argument. I found no mathematical error in the core recursion.
It computes every requested finite prefix of every classical formal theta
function, without a negative frame, negative product, or covering certificate.
It does not provide a bound on the complete support, a nonnegative counting
model, or an entirely scattering-free correctness proof. Its main theoretical
input is established, and should be credited rather than claimed anew.

## 1. What was actually read and checked

I read the full candidate program and the inherited
`NEGATIVE_FRAME_INTEGER_THETA_THEOREM.md` and halfspace extraction mechanism.
I independently read GHKK, *Canonical bases for cluster algebras*,
arXiv:1411.1394v2, Section 1.2, specifically the definitions of the total
element, equations (1.18) and (1.19), Proposition 1.20, Theorem 1.21 and its
proof, as well as the incoming convention in Definition 1.11 and the principal
injectivity discussion. Primary source:
https://arxiv.org/pdf/1411.1394v2

The two most important source facts are these:

1. The map from the completed group element to its primitive incoming ray
   components is a bijection, at every finite order and in the completion
   (Proposition 1.20, printed p.27).
2. Near the incoming point on a specified root hyperplane, its generic middle
   factor is exactly that incoming component (Theorem 1.21(1), printed pp.27–29).
   For the cluster diagram the component is the initial rank-one factor on
   coordinate rays and the identity on every other primitive ray.

These facts do not assume reachability of the negative chamber by mutations.
The existence and uniqueness of the completed cluster group element are
already in GHKK/KS. The proposed program makes its action explicit using
integer recursions on finite incidence matrices.

## 2. Lattice and symmetrizer normalization

Write root monomials as

\[
z_j=y_jx^{Be_j}.
\]

Let \(D=\operatorname{diag}(D_1,\ldots,D_n)\), with \(DB\) skew-symmetric.
To match the GHKK fixed data precisely, put

\[
L=\operatorname{lcm}(D_1,\ldots,D_n),\qquad
d_i=L/D_i,\qquad
\epsilon=B^{\mathsf T},\qquad
\{e_i,e_j\}=D_jB_{ji}/L.
\]

This alternating rational form has
\(\epsilon_{ij}=\{e_i,e_j\}d_j\). In the mutable basis
\(f_i=d_i^{-1}e_i^*\) of \(M^\circ\), the vector
\(p^*(\alpha)=\{\alpha,\cdot\}\) has coordinates \(B\alpha\).
Its pairing with a charge \(\beta\), for a mutable coordinate vector \(u\),
is \(\beta^{\mathsf T}Du/L\). Thus all hyperplane signs used by the
program are correct. The scalar \(L>0\) is irrelevant to the signs.

The primitive normal in the initial wall action gives exponent \(m_i\),
not \(D_im_i\). Hence the initial negative-to-positive action on the
coordinate ray is exactly

\[
x^m\longmapsto x^m(1+z_i)^{-m_i},
\]

and the axis coefficient \(\binom{-m_i}{k}\) is correctly normalized.
One must not insert an extra factor \(D_i\) into this binomial exponent.

For principal coefficients the full incoming point is
\((B\alpha,\alpha)\). The map \(\alpha\mapsto(B\alpha,\alpha)\) is
injective even when \(B\alpha=0\). This is the correct way to apply GHKK;
applying its injectivity hypothesis only to the mutable matrix would be wrong.

## 3. The infinitesimal sign rule is realizable

For a nonzero root \(\alpha\), choose a pivot \(r\) with \(\alpha_r>0\).
The program takes the lexicographic sign of

\[
\left((B\alpha)^{\mathsf T}D\beta,
\ \alpha_r\beta_{i_1}-\alpha_{i_1}\beta_r,
\ldots,
\alpha_r\beta_{i_{n-1}}-\alpha_{i_{n-1}}\beta_r\right).
\tag{3.1}
\]

For each \(i\ne r\), define the rational vector

\[
\delta^{(i)}_k=
\frac{\alpha_r\mathbf1_{k=i}-\alpha_i\mathbf1_{k=r}}{D_k}.
\]

Then \(\alpha^{\mathsf T}D\delta^{(i)}=0\) and
\((\delta^{(i)})^{\mathsf T}D\beta=
\alpha_r\beta_i-\alpha_i\beta_r\).
On any prescribed finite root set, the signs in (3.1) are therefore realized
by an ordinary rational vector

\[
u=B\alpha+\varepsilon\delta^{(i_1)}
 +\varepsilon^2\delta^{(i_2)}+\cdots,
\]

for all sufficiently small positive rational \(\varepsilon\).
All its coordinates remain in \(\alpha^{\perp_D}\).
The signs vanish precisely when \(\beta\in\mathbb Q\alpha\), since all
displayed two-by-two minors vanish precisely in that case.

This proof also handles zero entries of \(\alpha\), disconnected matrices,
nonprimitive \(\alpha\), and \(B\alpha=0\). A different pivot or tie order
amounts to a different sufficiently close generic point in the same incoming
neighborhood, and gives the same middle factor.

## 4. Why the factorization order is correct

GHKK denotes the positive-to-negative total element by \(P_{+,-}\).
At a generic point on a root hyperplane, its convention is

\[
P_{+,-}=G_+G_0G_-.
\]

The program instead represents
\(\Phi=P_{-,+}=P_{+,-}^{-1}\). Consequently

\[
\Phi=G_-^{-1}G_0^{-1}G_+^{-1}.
\tag{4.1}
\]

This is exactly negative–middle–positive, the order used in the program.
For a root not on a coordinate ray, the incoming component is the identity,
so the middle factor of (4.1) is the identity. There is no unaccounted inverse
or sign in the proposed recurrence. Replacing \(B\alpha\) by
\(-B\alpha\) would use the outgoing side and would generally be wrong.

## 5. A complete induction for the scalar coefficients

Let \(c(\alpha,m)\) be defined by

\[
\Phi(x^m)=x^m\sum_{\alpha\ge0}c(\alpha,m)z^\alpha.
\]

On the finite basis \(v_q=x^mz^q\), the true coefficient matrix is

\[
C^{(m)}_{p,q}=c(p-q,m+Bq),\qquad q\le p.
\tag{5.1}
\]

This shift by \(Bq\) is essential: the \(z_i\) are not fixed by the total
substitution. The implementation includes it everywhere it is needed.

Induct simultaneously over all integral \(m\), using total root degree.
For \(\alpha=0\), set \(c(0,m)=1\). On a coordinate ray, positivity of
root increments prevents contributions from other root directions, so

\[
c(ke_i,m)=\binom{-m_i}{k}.
\]

Now suppose \(\alpha\) has at least two nonzero coordinates. Use the sign
functional of Section 3 on the finite box \([0,\alpha]\). By Section 4,
the true matrix factors as

\[
C^{(m)}=LR,
\]

where the off-diagonal entries of \(L\) have strictly negative increment
sign and those of \(R\) have strictly positive increment sign.
For a proper nonzero interval \(\beta=p-q\), all data in (5.1) are known
by induction. Set

\[
K_{p,q}=\sum_{q<r<p}L_{p,r}R_{r,q},\qquad
E_{p,q}=c(\beta,m+Bq)-K_{p,q}.
\]

If the sign of \(\beta\) is negative, assign \(L_{p,q}=E_{p,q}\) and
\(R_{p,q}=0\). If it is positive, do the reverse. When it is zero,
\(E_{p,q}=0\) because the middle factor is the identity. The induction
identifies all of these entries with the true factors.

The only interval with difference exactly \(\alpha\) is
\((p,q)=(\alpha,0)\). Its sign is zero, so both direct factor entries
vanish and

\[
\boxed{c(\alpha,m)=
\sum_{0<r<\alpha}L_{\alpha,r}R_{r,0}.}
\tag{5.2}
\]

Every summand on the right is already known. This establishes existence,
termination for each requested coefficient, integrality, and equality with
the true total action, using no division in the recursive calculation.
It also proves that the assertions about parallel residuals are mathematical
consequences, not extra hypotheses supplied to the algorithm.

The proof does not presume that an arbitrary matrix assembled by the
algorithm is an automorphism. Instead it compares it, by induction, with the
known completed group element. That avoids a potential circularity.

## 6. Theta extraction and its exact scope

For a requested coefficient \(p\), write \(m_p=g+Bp\) and

\[
I_p=\{p\}\cup\{q<p:m_p^{\mathsf T}D(p-q)<0\}.
\]

Use (5.1) to form the finite submatrix on \(I_p\), and let \(t^{(p)}\)
be the last row of its inverse. The same row-support argument in the inherited
halfspace proof gives

\[
a_0=1,\qquad
a_p=-\sum_{q\in I_p\setminus\{p\}}t^{(p)}_qa_q.
\tag{6.1}
\]

For completeness, choose the endpoint mutable direction
\(u=M(g+Bp)+\mathbf1\), with \(M\) larger than
\((\max_iD_i)|p|\). For every possible positive bend charge \(\beta\le p\),
the backward final ray from that endpoint has constant nonzero sign against
the hyperplane normal: the nonzero pairing with \(g+Bp\) has the same sign
as the endpoint pairing, and a zero pairing gives a parallel ray. Hence no
last nontrivial bend can produce the terminal full exponent \((g+Bp,p)\).
The unbent term has frozen exponent zero, so it contributes only at \(p=0\).
This proves the coefficient equation (6.1), including \(Bp=0\) and
\(g+Bp=0\).

A finite root prefix cannot contain an infinite sequence of positive bends:
the total increment bounds their number. Thus this argument applies directly
to formal theta functions; it never needs full support finiteness.

**What has become unconditional:** given \(B,D,g,p\), the coefficient of
\(x^{g+Bp}y^p\) is computable by the stated finite integer recursions.
Any prescribed finite downward-closed prefix is computable and compatible
with enlargement of the prefix.

**What has not become unconditional:** termination of a procedure that keeps
enlarging the prefix until it has found the entire polynomial; existence of a
finite polynomial for every label; a basis of the upper algebra indexed by
all labels; or a positive finite-object model.

## 7. Independent computation, using a different implementation

I wrote `agents/incoming_independent_compute.py`. It first reconstructs
rational coefficients \(\ell_\alpha\) of the Lie logarithm

\[
\log\Phi=\sum_{\alpha>0}\ell_\alpha
 z^\alpha\partial_{D\alpha}.
\]

It computes their action by finite matrix exponentials over exact rational
numbers. On the coordinate rays it uses
\(\ell_{ke_i}=(-1)^k/(k^2D_i)\); on a mixed root it solves the incoming
middle coefficient equation at \(m=\mathbf1\), where division by
\(\alpha^{\mathsf T}D\mathbf1\) is valid. It then exponentiates the same
Lie logarithm at other exponents \(m\). This differs materially from the
candidate's scalar recursion, which never constructs a logarithm or an
exponential and never divides.

The independent implementation also takes the last nonzero pivot rather than
the first, and reverses the auxiliary tie order.

The completed run compared **2,016 exact total-action coefficients**, with
zero mismatches, across these input regimes:

| Input | Max total root degree | Coefficients compared |
|---|---:|---:|
| Zero rank-three matrix, unequal diagonal symmetrizer | 5 | 220 |
| Valued rank two with entries 3 and −2 | 7 | 140 |
| Oriented rank-three cycle of weight 1 | 5 | 220 |
| Markov oriented cycle of weight 2 | 6 | 332 |
| Oriented cycle of weight 3 | 6 | 332 |
| Genuinely valued oriented rank-three cycle | 5 | 220 |
| Weighted oriented rank-four cycle | 4 | 276 |
| Disconnected valued rank-four matrix | 4 | 276 |

All rational Lie-log denominators cancelled in the compared action entries,
as predicted. Exact results and runtimes are saved in
`agents/incoming_independent_compute_results.json`; the full command output is
in `agents/incoming_independent_compute_run.log`.
These checks support the normalization and implementation. The general claim
rests on Sections 2–6, not on the finite test set.

## 8. Presentation corrections and novelty boundary

The prototype has intentionally light input validation. A user-facing program
should reject nonintegral entries, nonpositive diagonal entries, malformed
matrix dimensions, negative requested roots, and invalid tie-order sequences.
These are software checks, not missing hypotheses in the mathematical proof.

The honest mathematical description is:

> An explicit division-free integer realization of the incoming-parameter
> inversion for the classical cluster group, followed by finite halfspace
> extraction of arbitrary formal theta coefficients.

This does remove all negative-frame, negative-product, and folding input
conditions from coefficient computation. It also avoids wall construction,
wall-support enumeration, and broken-line enumeration at runtime.

Nevertheless the incoming parameterization and its uniqueness are standard
KS/GHKK machinery. The program is an algebraic realization of that machinery,
not an independent new proof of the existence of theta functions. Its
subtractions and matrix-chain inversions leave the positive greedy-counting
problem unresolved. It should not be presented as a cancellation-free
high-rank Dyck-path model, nor as a solution of all-label finite basis
existence. Those would require additional substantive arguments.

No Li–Pan polytope-basis conclusion, 2026 positivity claim, quantum theorem,
or uncomputed theta coefficient is used in this audit.

## 9. Independent audit of the Schur compression

The final refinement from the construction branch also passes. For a mixed
root \(\alpha\), use the same incoming sign functional \(\lambda\), with
\(\lambda(\alpha)=0\), and put

\[
S=\{q:0<q<\alpha,\ \lambda(q)>0\}.
\]

All comparisons remain componentwise. Then the coefficient can be defined
without constructing either sign factor:

\[
\boxed{C_{\alpha,0}=
 C_{\alpha,S}\,C_{S,S}^{-1}\,C_{S,0}.}
\tag{9.1}
\]

Every matrix entry on the right has strictly smaller root degree than
\(\alpha\); the submatrix is unitriangular, so its inverse is a finite
integer chain sum.

Here is a direct check of the potentially delicate truncation. Write
\(C=AB\), with \(A\) strictly negative off the diagonal and \(B\)
strictly positive off the diagonal. If \(p\in S\) and \(A_{p,r}\ne0\),
then either \(r=p\), or
\(\lambda(r)>\lambda(p)>0\). Thus any intermediate index contributing
to the indicated rows remains in \(S\). For the final row \(\alpha\),
nontrivial \(A_{\alpha,r}\) also forces \(\lambda(r)>0\). Its diagonal
term multiplies \(B_{\alpha,q}=0\) when \(q\in S\), and
\(B_{\alpha,0}=0\). These observations give all four identities

\[
C_{S,S}=A_{S,S}B_{S,S},\quad
C_{\alpha,S}=A_{\alpha,S}B_{S,S},\quad
C_{S,0}=A_{S,S}B_{S,0},\quad
C_{\alpha,0}=A_{\alpha,S}B_{S,0}.
\]

Substitution proves (9.1). Notice that \(S\) need not be downward closed;
the displayed support argument is what justifies this particular restriction.
Arbitrary restriction of unitriangular products would not be valid.

The lexicographic infinitesimal signs are realized by an ordinary linear
functional on the finite box, as shown in Section 3. Consequently the
strict inequalities used here are valid even when the leading pairing
\((B\alpha)^{\mathsf T}Dq\) vanishes.

Formula (9.1) converts the construction to scalar binomial inputs, integer
halfspace tests, and finite chains. Its runtime description contains no
matrix sign factorization, scattering wall, or broken line. The correctness
proof still uses the established incoming parameterization, and its signed
chains are not a positive greedy-object model. These distinctions should
remain explicit.

The independent rational Lie-log computation was rerun after this refinement.
All **2,016** comparison entries also agree directly with `IncomingSchur`,
not just with the earlier sign-factorization implementation. The result JSON
records this additional match count for each input regime.
