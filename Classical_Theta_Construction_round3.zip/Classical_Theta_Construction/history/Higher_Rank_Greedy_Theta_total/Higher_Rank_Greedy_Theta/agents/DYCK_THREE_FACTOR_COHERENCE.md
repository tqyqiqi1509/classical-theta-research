# Three-factor coherence: an explicit Dyck move and the general interface

Research interval begun 2026-11-13 14:33 UTC. This note is a continuation
of the general coefficient theorem, not a substitute for it. It studies
whether different legal schedules can be compared on actual objects.

## 0. Results and precise status

There are three substantive results here.

1. For **every valued two-input first coefficient**, an actual tight
   grading with one positive edge of each orientation has an explicit
   residue coordinate. Both the coordinate and its inverse are obtained
   from the two positive edge positions. No enumeration or coefficient
   value enters the map.
2. For the first multilinear overlap of three factors whose input normal
   contents are equal, there is an explicit local bijection between the
   two sorting histories. It is a composition of the residue maps, a
   structural carry for intermediate normal copies, and three affine
   rectangle pieces. Intermediate and final carriers may be nonprimitive.
   The bijection preserves all three input decorations and is therefore
   natural and Young-equivariant after labeling.
3. The first remaining requirements for general schedule/flag coherence
   can be stated as specific natural-isomorphism equations. The unequal-
   content first ABC component was subsequently solved in
   `valued_coherence_phase_transport.md`: a Smith-lattice lemma and
   weighted strip carry give an explicit inverse map on actual gradings.
   Its proof and formulas have been independently reviewed. The old
   root-copy obstruction in Section 5 rules out only keeping that old
   coordinate fixed and is superseded as an existence obstruction.
   In higher degrees, the missing general triple map acts on genuinely
   multi-edge tight gradings. Numerical equality and Young-set isomorphism
   classes do not furnish these maps.

No arbitrary ordering/rank/unrank of equinumerous sets is used. The
rectangle coordinates below are read from actual shadow endpoints and
the prescribed normal tuple indices. Full all-degree coherence and
independence of the path of local bijections are **not proved** here.

## 1. The exact three-factor ambiguity

A word-sorting overlap occurs inside a single nondegenerate rank-two
plane. Write its three carriers in the inverted order a,b,c, so

    p=K(a,b)>0,     q=K(b,c)>0,     r=K(a,c)>0.

Thus this first ambiguity is not an ambient rank-three problem. Ambient
rank three enters when the event flags themselves are changed; see
Section 8.

Mark the three input first coefficients by independent commuting symbols
A,B,C with A^2=B^2=C^2=0. This isolates the first component in which both
overlapping exchanges can matter. Put

    d_x=w(x),       M(x,y)=K(x,y) w(x+y)/(w(x)w(y))

for an inverted pair. The first two-input coefficient has M(x,y) actual
objects per pair of input decorations.

Start by exchanging a,b, then finish sorting inside this three-input
block. The connected ABC birth has the following two possible histories:

    L1: ((a,b),c),
    L2: (b,(a,c)), present only when q>p.

Starting by exchanging b,c gives

    R1: (a,(b,c)),
    R2: ((a,c),b), present only when p>q.

To see why there are no other connected histories in this component,
each birth must combine disjoint nonempty subsets of {A,B,C}. A pair
birth followed by a remaining singleton exhausts the possibilities, and
the sign of K(b,a+c)=q-p decides the remaining inversion. Later exchanges
with an already ABC-labeled factor repeat a label and vanish in this
multilinear quotient.

The common normal factor cancels the intermediate contents:

    |L1| = w(a+b+c)/(d_a d_b d_c) * p(r+q),
    |L2| = w(a+b+c)/(d_a d_b d_c) * r(q-p),   q>p,
    |R1| = w(a+b+c)/(d_a d_b d_c) * q(p+r),
    |R2| = w(a+b+c)/(d_a d_b d_c) * r(p-q),   p>q.

Consequently the necessary first triple equation is

    p(r+q)+r(q-p)_+ = q(p+r)+r(p-q)_+
                     = pq+r max(p,q).                  (1.1)

This is the positive chamber form of the familiar Jacobi relation,
not a newly discovered numerical identity. What needs a combinatorial
construction is the correspondence between its actual Dyck objects.

If p=q, a+c is parallel to b. The full outgoing packet also contains the
common forest consisting of the inherited b object and the (a,c) birth.
This common part is retained identically. Formula (1.1) concerns the
connected ABC birth; it does not divide out this inherited contribution.

## 2. A residue coordinate for every first binary Dyck grading

Let m=K(alpha,beta)>0, d=w(alpha), e=w(beta), kappa=w(alpha+beta).
Use the exact local factory's parameters

    u=m/d,       v=m/e,       ell=gcd(u,v),
    A=v/ell,    B=u/ell,      copies=kappa/gcd(d,e).

Let (W,H) be the chosen minimal rectangle, so

    A H-B W=1,       W>=v,       H>=u,
    v H-u W=ell,    gcd(W,H)=1.                         (2.1)

In the first coefficient, each nonzero local grading has exactly one
positive horizontal edge, of weight u, and one positive vertical edge,
of weight v. Index the horizontal edges h_i, 1<=i<=W, and the vertical
edges v_j, 1<=j<=H. Put

    y_i=floor(H(i-1)/W).

Read v_j cyclically after h_i by its unique lifted index J with
y_i<J<=y_i+H. The two shadow memberships are

    v_j in sh(h_i)  iff J<=y_i+u,
    h_i in sh(v_j)  iff J<=floor(H(i+v-1)/W).           (2.2)

The second upper bound is at least the first. Compatibility prohibits
both memberships, whereas tightness requires at least one. Hence a
tight pair exists at h_i exactly when the two upper bounds differ by
one. From (2.1), this is equivalent to

    R_i := H(i-1) mod W >= W-ell.                      (2.3)

In that case the unique vertical edge is

    j = (floor(H(i-1)/W)+u) mod H + 1.                 (2.4)

Since multiplication by H permutes the residue classes modulo W, the
geometric strip residue

    s=R_i-(W-ell)                                     (2.5)

runs exactly once through 0,...,ell-1. Conversely, from s solve

    i-1 = H^(-1)(W-ell+s) mod W

and then use (2.4). This is a closed modular formula in edge positions.
It does not sort the set of gradings and does not ask its cardinality.

Finally, at total degree one exactly one of the positive normal copies
is nonempty. Therefore the full first-coefficient object is exactly

    (k,s; first input decoration, second input decoration),
    0<=k<kappa/gcd(d,e),  0<=s<ell.                    (2.6)

The coordinate k is the already prescribed ordered tuple slot, not a
new coefficient label. This proves the edge-level residue lemma in the
full valued setting.

## 3. Normal carries for three equal-content inputs

Assume now

    w(a)=w(b)=w(c)=d.

Divide all local contents and pairings by this common d. This leaves
u,v,ell and every tuple count in Section 2 unchanged. In the rest of
this section the rescaled input contents are one and p,q,r denote the
rescaled pairings. Write

    k_ab=w(a+b)/d, k_ac=w(a+c)/d, k_bc=w(b+c)/d,
    k_S=w(a+b+c)/d.

No one of these numbers is required to be one.

For a history with inner pair x,y and remaining singleton z, the inner
binary object has coordinates

    (k_inner,s_inner),  0<=k_inner<k_xy,
                       0<=s_inner<K(x,y).

The outer object has coordinates

    (k_root,s_outer), 0<=k_root<k_S,
                      0<=s_outer<K(x+y,z)/k_xy,

with the analogous orientation when z is the first input. The division
is integral because k_xy divides K(x+y,z).

Use the following structural carry:

    i=s_inner,
    j=k_xy*s_outer+k_inner,
    k=k_root.                                         (3.1)

Thus the inner normal-copy slot becomes the residue within the next
intersection label. Its inverse is

    k_inner=j mod k_xy,        s_outer=floor(j/k_xy).

This is why intermediate nonprimitive carriers create no problem in
this first triple move. Simply discarding their normal copies would
lose the residue in (3.1).

After this carry, the four possible history spaces, before attaching
the untouched A,B,C decorations, are

    L1: [0,p) x [0,r+q) x [0,k_S),
    L2: [0,r) x [0,q-p) x [0,k_S),  q>p,
    R1: [0,q) x [0,p+r) x [0,k_S),
    R2: [0,r) x [0,p-q) x [0,k_S),  p>q.

Every interval here consists of integers. These boxes are obtained
directly from the edge residue and ordered tuple coordinates.

## 4. The explicit local piecewise unimodular move

Keep k and the three original decorations unchanged. On L1(i,j) set

    if j<q:                  send to R1(j,i);
    if j>=q and i<q:         send to R1(i,p+j-q);
    if j>=q and i>=q:        send to R2(j-q,i-q).        (4.1)

The last case can occur only if p>q. If L2 is present, set

    L2(i,j) -> R1(p+j,p+i).                              (4.2)

The inverse is equally local:

    R1(i,j), j<p:            L1(j,i);
    R1(i,j), j>=p, i<p:      L1(i,q+j-p);
    R1(i,j), j>=p, i>=p:     L2(j-p,i-p);
    R2(i,j):                 L1(q+j,q+i).              (4.3)

Each piece is a coordinate interchange or an integer translation.
Its linear part has determinant +1 or -1. The half-open pieces are
disjoint, include all boundary integer points exactly once, and cover
both sides. For q>=p, this cuts the right rectangle into a q-by-p
bottom rectangle and two adjacent rectangles of heights r and widths
p,q-p. For p>=q the inverse description applies.

To transform an actual Dyck history, apply (2.5) to its two gradings,
perform (3.1), apply (4.1)/(4.2), reverse (3.1) for the destination
history, and recover the new edge positions using (2.3)/(2.4).
This gives a complete edge-level algorithm and its inverse.

The three decorations A,B,C stay attached to their original identities,
even when their binary parenthesization changes. The procedure does not
read their contents. Therefore it is natural under arbitrary independent
bijections of the three input coefficient sets. If their original-color
ground-set blocks are labeled, those blocks remain unchanged. Induction
over the label allocations then gives a Young-equivariant bijection.

This proves the **first multilinear critical diamond for equal input
normal contents**, with unrestricted positive pairings and unrestricted
intermediate/final normal contents. It is a local coherence generator,
not an all-degree theorem.

## 5. The old root-copy constraint and its resolution

The residue lemma in Section 2 still applies without equal contents.
However the two histories now have different outer tuple lengths:

    left root copies  = w(S)/gcd(w(a+b),w(c)),
    right root copies = w(S)/gcd(w(a),w(b+c)).           (5.1)

These need not agree. Thus a construction that preserves the root-copy
coordinate, as (4.1) does, cannot handle general valued data.

This is demonstrated by a whole family, not a numerical coincidence.
Take coprime A,B with A even and B odd,

    D=diag(A,B),   exchange matrix [[0,B],[-A,0]],
    a=(1,0), b=(1,1), c=(0,1).

Then the input contents are A,1,B, the pairings are p=q=r=AB, and

    w(a+b)=1,   w(b+c)=2,   w(a+b+c)=2.

The left history has two outer normal copies and the right one has one.
The actual coefficient-object rectangles have sizes

    B x 4A                 and                 2A x 2B,

with equal total size 4AB. This disproves only the proposed
root-copy-preserving extension; it does not disprove a valued bijection.
Any such bijection must mix outer tuple slots with other residue data.

**Resolved interface, 15:12 UTC.** The independent construction in
`valued_coherence_phase_transport.md` uses the lattice generated by the
three carriers. If h is the gcd of their normal contents, its Smith
invariants imply K(x,y)h/(w(x)w(y)) is integral for every pair in this
lattice. After division by h, let the input contents be A,B,C and write
p=ABP, q=BCQ, r=ACR with P,Q,R positive integers. The actual first-pair
coordinates (s,k) are changed by

    t=floor(s/g),       phase=g*k+(s mod g),

where g is the gcd of the two input contents. This is a carry between
an actual edge residue and an existing ordered normal-copy slot.
The common triple phase has size w(S)/h. The remaining boxes are

    L1: [P] x [AR+BQ],       R1: [Q] x [BP+CR],
    L2: [R] x [CQ-AP],       R2: [R] x [AP-CQ],

with only the positive extra box present. A weighted strip subdivision
and Euclidean division give an explicit forward and inverse bijection.
The three original input decorations remain untouched. In particular
the old root-copy indices can mix; the new common phase is preserved.
The full formulas, Smith proof, and actual-edge inverse checks are in
the cited companion note. This solves the general first ABC component,
not the unrestricted all-degree triple equation.

## 6. What an all-degree triple move must do

Let T_(a,b) denote the actual local tight-grading polynomial functor on
finite-set coefficient series. For an inverted triple a,b,c, choose
the two finite normalizations that first exchange ab or bc and then
sort the resulting block by a fixed rule. Denote their outgoing packet
functors on a ray rho by N_L,rho and N_R,rho.

The missing general interface is a family of graded natural bijections

    Phi_(a,b,c),rho:
       N_L,rho(A,B,C)  ->  N_R,rho(A,B,C),              (6.1)

for arbitrary finite-set input series, compatible with truncation,
input-decoration substitution, and multiplication of parallel packets.
The first component of (6.1) is exactly Section 1. Section 4 and the
resolved weighted construction in Section 5 supply its ABC component
for all input normal contents. Degrees such as A^2 B C still require
a map on multi-edge gradings, not just the one-pair residue coordinate.

The subsequent note `TWO_STACK_DYCK_FORESTS.md` gives a general literal
encoding of every such local grading as two canonical cyclic LIFO
matchings. Compatibility is exactly acyclicity and shadowedness is a
root-color condition. In the determinant-one frame there is one
nontrivial boundary-embedded tree. This supplies an all-degree intrinsic
object language but does not by itself construct (6.1).

Polarizing the initial coefficients does not bypass this difficulty.
The packet 1+(x_1+...+x_N)z differs from product_i(1+x_i z) in higher
degrees. Replacing the former by the latter creates extra incoming
coefficients. Conversely, logarithmic expansion introduces signs and
denominators. Thus a positive atomic-tree model cannot be asserted merely
from multilinear Jacobi identities.

## 7. A general presentation by critical overlaps

At a fixed cutoff the structural word rewriting terminates. Its only
branchings from two simultaneously legal moves are:

* disjoint adjacent pairs, giving the natural square that interchanges
  independent Cartesian constructions;
* overlapping pairs ab and bc in one consecutive triple, giving (6.1).

This is an exhaustive statement because every rule has a two-letter
left side. Inserted higher charges do not introduce another branching
shape; they only create more instances of these two kinds.

Suppose (6.1) is available for every triple and is natural under input
substitution. Then any two complete sorting schedules admit a bijection
of their output coefficient sets: compare the first moves, use a
disjoint square or a triple diamond, and continue by well-founded
induction on the terminating reduction graph. Naturality transports
the bijection through all later decorations. Sorting a triple as a
block is legitimate even when neighboring letters remain unsorted.
Parallel output factors are combined by the ordinary finite-set Cauchy
product.

This gives the needed presentation of the **remaining construction
problem**: a natural all-degree triple diamond is sufficient to compare
arbitrary schedules. It does not fabricate that diamond from equality
of counts. To obtain a canonical comparison independent of the path
of diamonds, relations among these local maps must also be established;
four-input overlaps are the next coherence constraints. Squier-style
critical-branching theory is a useful organizational framework, but its
confluence hypothesis cannot be replaced by coefficient equality.

## 8. Changing event flags is an additional rank-three interface

For a fixed target S, two candidate event times coincide when

    Theta(b)/eta(S,b) = Theta(c)/eta(S,c),

or equivalently

    Theta(eta(S,c)b-eta(S,b)c)=0.                       (8.1)

At a generic such crossing, the event covector annihilates
span_Q(S,b,c), a three-dimensional space. Thus changing an auxiliary
flag produces a local rank-three zero group, whereas a sorting overlap
within one event is rank two. These must not be conflated.

The finite-group proof already gives equality of the resulting packet
functions. A flag-independent object atlas additionally needs a
combinatorial comparison of the two finite sequences of rank-two
constructions inside this three-space, together with compatibility with
the child-state comparisons. Tropical four-valent-vertex resolutions
explain the Jacobi multiplicities, but do not yet provide this positive
Dyck-data map. Equation (8.1) gives a concrete parameter wall on which
to seek the required subdivision move.

## 9. Primary literature and what each interface actually supplies

The following sources were opened in primary versions during this
round. Their roles are deliberately distinguished from the proofs above.

| Primary source | Relevant interface | Decision for this mechanism |
|---|---|---|
| Burcroff--Lee--Mou, arXiv:2503.03719v1, Definitions 3.14, 3.17, 5.1--5.4, Theorem 1.2. https://arxiv.org/html/2503.03719v1 | Actual local tight gradings and their weights. | Used for the existing local factory; Sections 2--4 give their own edge-coordinate argument. |
| Burcroff--Lee--Mou--Musiker--Reineke, arXiv:2511.14672v1, Sections 5, 7, 9. https://arxiv.org/pdf/2511.14672v1 | Partial tilings, mutation/retraction bijections. General tight-grading/stable-tree matching is posed as an unresolved direction. | Useful operations; does not supply (6.1). In particular, a partial tiling cannot simply be declared to be a tree. |
| Burcroff--Lee, arXiv:2404.14369. https://arxiv.org/abs/2404.14369 | Weighted compatible-pair/broken-line bijections in finite and affine skew-symmetric rank two, with further restricted cases. | Useful local encodings; its stated scope does not cover arbitrary tight-grading word overlaps. |
| Mandel, arXiv:1503.06183v5, Section 3.4 and equation (49). https://arxiv.org/pdf/1503.06183 | Tropical degenerations express changes by iterated Lie brackets and the Jacobi relation. | Explains (1.1) and the rank-three interface; weighted equality alone is not a positive decorated-set bijection. |
| Knutson--Tao--Woodward, arXiv:math/0306274. https://arxiv.org/abs/math/0306274 | An explicit octahedron-rule associativity bijection for hives. | A model for polyhedral local moves; no identification of the present tight constraints with hive constraints is known here. |
| Henriques--Kamnitzer, arXiv:math/0408114v3, Sections 1, 6.a. https://arxiv.org/pdf/math/0408114 | Hive/crystal associators and commutors; the general commutor fails Yang--Baxter. | Rules out importing a generic Young/crystal swap as the desired braid map. Associativity and swapping are separate issues. |
| Reading, arXiv:1806.05094 / Algebraic Combinatorics 3 (2020), Section 4. https://alco.centre-mersenne.org/articles/10.5802/alco.107/ | Cambrian construction for acyclic finite type. | Gives geometric coherence on the cluster fan; it does not control arbitrary added rays or full input packet series. |
| Reading--Speyer, arXiv:math/0606201. https://arxiv.org/abs/math/0606201 | Cambrian fans and generalized associahedra. | Explains why tree rotations are natural in finite type, but does not identify our growing word with a fixed Coxeter reduced-word complex. |
| Guiraud--Malbos, arXiv:1402.2587; Alleaume--Malbos, arXiv:1612.09193. https://arxiv.org/abs/1402.2587 ; https://arxiv.org/abs/1612.09193 | Coherent presentations organized by critical branchings. | Supports the framework of Section 7 only after actual confluence maps have been constructed. |
| Frieden, arXiv:1710.07243. https://arxiv.org/abs/1710.07243 | Birational refactorization and tropical combinatorial R for rectangular tableaux. | An instructive strategy: unique factorization plus a subtraction-free coordinate map. No such coordinates on arbitrary tight gradings are supplied by this paper. |

### 9.1 Strong audit of the new November 2026 interface

Source: Burcroff--Lee--Mou, *Bijecting m-Tamari intervals, trees, and tight
gradings*, arXiv:2611.10154v1, submitted 6 November 2026.
Primary metadata, HTML and the 13-page PDF were inspected:

https://arxiv.org/abs/2611.10154

https://arxiv.org/html/2611.10154v1

The metadata explicitly calls this an extended abstract. Theorem 4.6
gives a preorder/auxiliary-vertex map between pointed leafy trees and
central tight gradings; Remark 4.8 describes an inverse by parenthesis
words. The grading values are restricted to 0 and m+2 on the indicated
central path. Theorem 2.6 connects the unpointed trees with Tamari
intervals. The PDF compilation date differs from the submission date;
this is recorded without treating it as a mathematical error.

**Audit decision:** useful contour-word idea, but not an all-slope,
arbitrary-weight, three-input coherence theorem. No conclusion from
this 2026 paper is used to prove Sections 2--4 or the main theta theorem.
Extending its tree map would require proving compatibility with the
local substitutions in (6.1), not merely matching another enumeration.

## 10. Computation and route record

The new implementation is `computations/dyck_three_factor_coherence.py`.
It stores the actual positive horizontal/vertical edge positions and
normal-copy slots; it never calls an incoming coefficient oracle.

Completed exact checks:

* 576 independent (u,v) parameter pairs for the edge-residue formula;
* 1,336 reconstructed actual tight gradings;
* 2,509 independently enumerated edge pairs for surjectivity against
  the literal shadow test;
* 32,768 parameter triples, with 20,722,944 forward/inverse rectangle
  checks;
* 2,300 triples of actual primitive planar carriers, producing 38,865
  complete edge-object inverse checks; 2,017 triples have a nonprimitive
  intermediate carrier and 886 a nonprimitive final carrier.

The actual Wolfram Language kernel separately returned True for the
symbolic piecewise identity (1.1), no counterexample to the three
polyhedral pieces, and all 5,625,216 strip-floor comparisons through
width 256. Exact code and output are in
`computations/dyck_three_factor_coherence.wl` and
`computations/dyck_three_factor_wolfram_result.json`.

These checks validate the explicit maps, not the unresolved all-degree
claim. The general proofs are the shadow inequalities (2.2), the carry
(3.1), and the mutually inverse pieces (4.1)--(4.3).

Route record:

* 14:33--14:38: primary search, distinction between rank-two word
  overlaps and rank-three flag changes; derivation of (1.1).
* 14:38--14:46: residue lemma and actual rectangle move; investigation of
  phase torsors and the unequal-content obstruction; 2026 Tamari scope
  checked against primary text.
* 14:46--14:52: actual Wolfram computation, implementation and inverse
  checks; renewed primary search on tropical Jacobi, Cambrian fans,
  rewriting coherence and geometric R matrices.
* Outcome retained: the explicit first critical generator and the
  precise interfaces (5.1), (6.1), (8.1). Rejected shortcuts are arbitrary
  rank/unrank, generic crystal commutors, an unsupported stable-tree
  identification, and replacing an input sum packet by a binomial product.
* 15:03--15:19: the first ABC generator was extended by the phase
  transport agent to all normal contents and independently reviewed.
  The old root-copy-preserving restriction is explicitly superseded.
  The two-stack forest equivalence and determinant-one single-tree
  corollary were proved in the companion note, with the earlier Tang
  protected-matching interface attributed and the equality cases checked.
