# Independent proof review: arbitrary endpoints and two-frame multiplication

Date: 2026-11-13, review begun 15:24 UTC. This is a proof review of the
root/assembly two-frame construction. It uses the already established
finite incoming-factor theorem and positive-chamber one-frame identity.
The arbitrary-endpoint extension and the two-frame event classification
are proved below with explicit signs. No numerical comparison is used
to establish the theorem.

## 1. Conventions and a framed module with the correct sign

Let DB be skew-symmetric and write K(a,b)=a^TDBb and eta=-K. In the
faithful principal-coefficient Lie algebra use the positive-normal
generators

    E_a = z^a partial_(Da),       [E_a,E_b]=K(a,b)E_(a+b).

Here partial_(Da)(x^m)=(Da dot m)x^m. The positive-normal packet T_a(F)
has first logarithmic term f E_a/d(a) when F=1+f z^a+... . A
negative-to-positive transport contains its inverse, so its logarithmic
term is -f E_a/d(a). Packet coefficients themselves are positive and
are not inverted.

Adjoin one frame f with symmetrizer 1 and couplings

    K(f,e_i)=-D_i g_i,       K(e_i,f)=D_i g_i.

Truncate at frame degree one and at any finite original-charge box.
The subspace M spanned by E_(1,q) is an abelian ideal: brackets of two
framed roots have frame degree two and vanish. There is a natural module
identification

    J(-E_(1,q)) = x^g z^q.                            (1.1)

The minus sign is required. The first-order action of -E_(1,q) on
x^(-e_f) has positive coefficient, since the frame derivative pairs
with -e_f as -1. Moreover

    Khat((0,a),(1,q))=a^T D(g+Bq),

which is exactly the action coefficient of E_a on x^g z^q. Therefore

    J(Ad(A)M)=A(J(M))                                 (1.2)

for every unframed group element A. This verifies the adjoint/action
convention without suppressing a sign or normal-content factor.

## 2. The arbitrary-endpoint single-frame lemma

Let C be the original total incoming transport and C_hat its one-frame
extension. Projection onto frame degree zero is C. Since M is an
abelian ideal, there is a unique factorization

    C_hat=exp(M_pos) C.                               (2.1)

The previously proved positive-chamber one-frame identity gives

    J(M_pos)=theta_(pos,g)

through every prescribed charge cutoff. Indeed C fixes x^(-e_f), and
at frame degree one the exponential contributes exactly its linear
module term. Thus this use of the old identity does not assume the
new arbitrary-endpoint claim.

Let U be a generic covector on the original lattice. Factor

    C=C_(U,-) C_(U,+).

There is no nonzero original zero-sign root. Set

    M_U=Ad(C_(U,-)^(-1)) M_pos.                       (2.2)

Moving the left factor past the exponential in (2.1) gives, with no
change in multiplication convention,

    C_hat=C_(U,-) exp(M_U) C_(U,+).                   (2.3)

Fix q>=0 and use the framed covector

    Theta(f)=-U(q),       Theta|original=U.

Decompose M_U as the sum of its negative, zero, and positive Theta
components. They commute. Hence (2.3) becomes

    (C_(U,-) exp(M_U,-)) exp(M_U,0)
                              (exp(M_U,+) C_(U,+)).  (2.4)

Each parenthesized factor belongs to its asserted sign subgroup. The
unique finite Lie-group three-factor decomposition identifies exp(M_U,0)
as the framed zero factor. Genericity makes its only framed root in
the target box (1,q). Its primitive normal content is one. By (1.1),
(1.2), and the coordinate transport from the positive chamber to U,

    J(M_U)=C_(U,-)^(-1)theta_(pos,g)=theta_(U,g).

It follows that the positive coefficient of the zero-ray packet at
(1,q) is exactly

    [x^g z^q] theta_(U,g).                            (2.5)

This proves the arbitrary-endpoint extension. It is coefficientwise,
valid in every finite downward-closed cutoff, and retains all original
principal coefficient degrees. It makes no Laurent-finiteness assertion.

## 3. Two frames and an explicit finite incoming state

Given g_1,g_2 in Z^n and p>=0, put

    h=g_1+g_2+Bp,       v=Dh,       S=(1,1,p).

Use two frame coordinates 0,1, both of symmetrizer one. The alternating
form is

    Ktilde(0,1)=L,
    Ktilde(0,e_i)=-D_i(g_1)_i,
    Ktilde(1,e_i)=-D_i(g_2)_i,
    Ktilde(e_i,e_j)=(DB)_ij.                          (3.1)

This comes from an integral skew-symmetrizable exchange matrix: the
frame-to-original entries are multiples of D_i in the required row.
Let epsilon_i be independent successively small positive infinitesimals
and set

    U=v+epsilon,
    Theta(0)=-T-p dot U,       Theta(1)=T,
    Theta|original=U.                                (3.2)

Choose positive integers L,T sufficiently large. With the infinitesimals
ordered so that epsilon dot p<1, take for example

    L >= 1+|g_1^T Dp|+sum_i p_i |v_i|,
    T = 2+sum_i p_i |v_i|.

These choices make every pairing used below positive and T greater than
the absolute values of U(b) for 0<=b<=p. No infinite parameter or
condition T>L is needed. The covector Theta has
rational kernel Q S: independent epsilon coefficients first force the
original coordinates to be the frame-0 coordinate times p, and then
the nonzero T term forces the two frame coordinates to agree.
The rational-kernel assertion concerns the formal lexicographic
covector. At a fixed cutoff it may be replaced by small rational numbers
preserving all required finite signs and zero relations, as in the main
event theorem; no assertion of that exact global kernel is made for a
single rational-valued functional in higher dimension.

## 4. Exhaustive root-event classification

Along the prescribed incoming path

    Theta(t)=Theta+t eta(S,-),       t>=0,

the original-coordinate functional is

    U(t)=(1+t)v+epsilon.                             (4.1)

A nonzero unframed root (0,0,r) has this value on r, whose sign is
constant for t>=0. A proper root with both frames, (1,1,r)<S, has the
negative of the same value on p-r, again with constant sign. Thus
neither kind creates a positive-time event.

Every remaining root is of one of the complementary types

    alpha_a=(1,0,a),       beta_b=(0,1,b),       a+b=p.

Their pairing is

    m_a=Ktilde(alpha_a,beta_b)=L+kappa(a),
    kappa(a)=a^T Dg_2-g_1^T Db+a^TDBb
            =a dot v-g_1^T Dp.                       (4.2)

It is positive by the stated L bound. Their Theta values are respectively
-T-U(b) and T+U(b), and their eta(S,-) values are m_a and -m_a. Thus
they meet at the positive time

    tau_a=(T+U(b))/m_a.                              (4.3)

These are all events. Their two-plane contains no other nonzero proper
positive root in the box: for a point lambda alpha_a+mu beta_b, its two
frame coordinates are lambda,mu, so the box and integrality force each
to be 0 or 1. The only nonzero possibilities are alpha_a,beta_b,S.
Different a give different two-planes. Formal genericity of Theta gives
distinct times for those planes.

At the event the original-coordinate endpoint is U(tau_a), with an
additional arbitrarily smaller child perturbation when extracting the
two incoming packets. All these endpoints are in the same chamber as
U for the relevant finite arrangement: (4.1) has the sign of v(r) when
that is nonzero, and otherwise the sign of epsilon(r). The child
perturbation is smaller than every nonzero value at the cutoff.

Consequently the arbitrary-endpoint lemma identifies the cardinalities
of the two actual incoming coefficient sets A_a^(L),B_b^(L) as

    |A_a^(L)|=[x^(g_1)z^a]theta_(U,g_1),
    |B_b^(L)|=[x^(g_2)z^b]theta_(U,g_2).             (4.4)

They are computed by the finite event grammar, restricted to their
one-frame boxes and their actual joint/child covectors. The other frame
and L disappear from the restricted alternating form, but L can still
affect the chosen flags. The chamber argument alone proves only that
their cardinalities are independent of L and T. Separately define
A_a^U,B_b^U by running the
one-frame grammar at the fixed original endpoint U, with root covectors
(-U(a),U) and (-U(b),U). Formula (2.5) proves that these fixed-endpoint
sets have the same respective cardinalities. The special radial-germ
argument in Section 5.1 below supplies a stronger literal comparison;
that conclusion does not follow from chamber constancy alone.

## 5. The local first coefficient and the global affine formula

The contents of alpha_a,beta_b,S are all one because each has a frame
coordinate equal to one. At frame bounds (1,1), the local two-input
exchange can use only the first coefficient of each parent. Its born
S coefficient is exactly

    m_a |A_a^(L)| |B_b^(L)|.

At the object level, the first Dyck residue lemma gives the actual set

    [0,m_a) x A_a^(L) x B_b^(L),                     (5.1)

where the integer is read from the positive edge positions on the
minimal (m_a,m_a+1) path. It is not an auxiliary set defined by a desired
coefficient. The inverse reconstructs those edge positions.

The target S is nonaxis, so its incoming factor is one. Products of two
nonconstant born S factors exceed the box. The global event formula
therefore gives the exact identity, for every sufficiently large L,

    F_S(L)=sum_(a+b=p) (L+kappa(a)) |A_a^U| |B_b^U|. (5.2)

This is affine in L even though the auxiliary event order may depend
on L. Equation (5.2) proves that dependence explicitly. Taking its
coefficient of L gives

    [L]F_S(L)=sum_(a+b=p)|A_a^U| |B_b^U|.            (5.3)

There are two actual positive models. At the fixed endpoint U define

    M_(g_1,g_2;p)=disjoint union_(a+b=p) A_a^U x B_b^U. (5.4)

It is independent of L and has a finite combinatorial definition. For
one fixed admissible L, forgetting the geometric strip coordinate in
(5.1) instead gives

    M^erase_L=disjoint union_(a+b=p) A_a^(L) x B_b^(L).

Both sets have cardinality (5.3); neither definition takes a desired
coefficient as an input. The second is literally obtained from the
two-frame birth objects. The first uses a fixed endpoint throughout.

### 5.1 The special radial germs give an actual comparison

The subsequent independent proof in
`RADIAL_ENDPOINT_LITERAL_CATALOG_REVIEW.md` was also checked here.
It upgrades the preceding count statement for precisely the endpoint
changes occurring in the two-frame construction. Compare

    U=H+epsilon,
    U'=lambda H+epsilon+delta_0 v,

where H,v are rational, delta_0 is below all the independent epsilon_i,
and lambda has a positive nonzero real leading term. Here H=Dh and
lambda=1+tau_a, whose leading term is greater than one by the T bound.

Along a fixed charge history every event projection is rational linear
in its input covector; passing to a child adds a new rational direction
times a fresh smaller infinitesimal. A scalar test therefore has the
form L(U)+sum_j delta_j c_j with rational L,c_j. If L(H) is nonzero,
the positive leading term of lambda preserves its sign. If L(H)=0
but L is nonzero, independence of all epsilon_i makes L(epsilon)
nonzero, with the same first nonzero sign in both constructions.
Finally, if L(epsilon)=0 identically, then L=0; in particular the
extra delta_0 L(v) is exactly zero. Later child columns agree in order.

Every sign, equality, and event-time comparison is consequently the
same. Induction identifies the complete unpruned charge catalogs and
the same local rectangles, copy slots and birth tags. Keeping all
decorations and only renaming covector addresses is a literal bijection.
One may pad the fixed-U construction by the unused delta_0 column.
Unfolding memoized states removes any irrelevant implementation choices.

Thus, in this special situation, the actual two-frame object set is

    disjoint union_(a+b=p)
      [0,L+kappa(a)) x A_a^U x B_b^U.                (5.5)

Increasing L by one gives an injection retaining the residue and the
child data, with complement one copy of (5.4). The proof requires the
full independent endpoint flag and a noninfinitesimal positive lambda;
it is not a general same-chamber flag-change or all-schedule theorem.

## 6. Identification with the theta structure constant

### 6.1 The finite event rule itself gives the dual coefficient functional

There is a direct algebraic proof of the required triangularity. For a
single theta input g and a nonnegative charge a, let h=g+Ba and use
U=Dh+epsilon. At the framed target R=(1,a), the root covector is

    Xi=(-U(a),U)=eta(R,-)+(-epsilon(a),epsilon).       (6.1)

Indeed eta(R,-) has original part D(g+Ba)=Dh, and its frame component
is -a^TDg=-a^TDh, since a^TDBa=0. For every candidate root b with
eta(R,b) nonzero, the event parameter is

    tau=-Xi(b)/eta(R,b)
        =-1-((-epsilon(a),epsilon)(b))/eta(R,b).

Its leading value is -1, so it is negative. Thus there are no positive
events. If a>0, the target is nonaxis and its incoming packet is one,
whose coefficient of R is zero. If a=0, it is the initial frame axis
and that coefficient is one. The arbitrary-endpoint lemma proves

    [x^g z^a]theta_(U,g)=delta_(a,0)
       whenever U=D(g+Ba)+epsilon.                   (6.2)

In the principal lattice, a monomial y^p x^h can occur in
y^s theta_r only if a=p-s>=0 and h=r+Ba. Applying (6.2) forces a=0,
r=h and s=p. Consequently at U=Dh+epsilon the monomial coefficient
functional is exactly dual to the principal theta basis:

    [y^p x^h](y^s theta_(U,r))=delta_((r,s),(h,p)).    (6.3)

This proof uses the finite incoming event rule and the one-frame
identification, and needs no new broken-line argument. It also proves
the equality-face and h=0 cases. The established theta multiplication
then gives the structure constant directly from (5.3).

### 6.2 Established theta interpretation and scope

The relevant primary reference is Gross--Hacking--Keel--Kontsevich,
*Canonical bases for cluster algebras*, Definition-Lemma 6.2 and
Proposition 6.4(3), including its proof, in the author-hosted version:

<https://paulhacking.github.io/canonicalbases.pdf>

Definition-Lemma 6.2 counts two broken lines with a common generic
endpoint and specified sum of final exponents. Proposition 6.4(3)
identifies this count with the theta structure constant when the endpoint
is sufficiently close to the output exponent. At each finite order,
the endpoint and the output must lie in the closure of one chamber.
The proof gives the exact triangularity needed here: a broken line with
final exponent equal to that output cannot bend, because its last ray
meets no wall capable of changing that exponent. Thus its monomial
coefficient isolates exactly the corresponding theta coefficient.

Our original-coordinate endpoint is U/D=h+D^(-1)epsilon. In the full
principal lattice lift it near (h,p). Frozen directions are lineality
directions of the walls. The coefficient of y^p x^h in
theta_(U,g_1)theta_(U,g_2) is exactly the sum (5.3). Therefore

    |M_(g_1,g_2;p)|
       =alpha((g_1,0),(g_2,0),(h,p)),
    h=g_1+g_2+Bp.                                   (6.4)

Equivalently this is the coefficient of y^p theta_h in the principal-
coefficient theta multiplication. The frozen degree p is essential:
different p may have the same mutable h when B has a kernel, and they
must not be conflated. The case h=0 is valid; the relevant straight
broken line has constant mutable projection and cannot cross a wall.

This statement is coefficientwise for formal theta functions. For
indices in the middle theta basis, GHKK Theorem 7.5 supplies finite
basis multiplication. The present proof does not assert that every
formal theta function is Laurent polynomial or that every unrestricted
sum over p is finite.

For the fixed-U pair model, commutativity has an actual natural
bijection: (a,b,A,B) maps to (b,a,B,A), with the two original theta
inputs exchanged. The endpoint U depends only on their sum and p.
This literal flip is distinct from an all-degree associator or a
comparison of unrelated event flags; no such stronger map is inferred.

## 7. Review outcome

The arbitrary-endpoint extension and two-frame formula pass the
independent algebraic review. The indispensable checks were the negative
framed basis in (1.1), the adjoint order in (2.2), exhaustive event
classification, primitive frame contents, independence of the child
packets from L, and retention of the complete principal output (h,p).
All are proved above. No claim of schedule-independent canonical
bijections follows from this multiplication formula; that remains a
different all-degree coherence question.
