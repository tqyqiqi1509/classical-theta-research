# One framing vertex absorbs the theta extraction

Date: 2026-11-13. Status: proved directly from the incoming Schur recursion.
Independent reproducible check: computations/canonical_bridge/framing_identity.py,
676 coefficients and 3,964 sign comparisons, including 341 exact zero faces, all pass.
The proof does not assume a representation-theoretic identification and does
not appeal to positivity. It converts the two layers of the present algorithm
into one and gives an exact target for a framed positive model.

## Statement

Let `B` be an integral exchange matrix, let `D=diag(D_i)>0` be integral with
`DB` skew-symmetric, and let `g in Z^n`. Add a new first vertex `0` and set

```
Bhat = [[0, -g^T D],
        [g,       B]],       Dhat = diag(1,D).
```

Then `Dhat Bhat` is integral and skew-symmetric. Let `c^B_alpha(m)` denote
the universal incoming-normalized integer coefficients of
`INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`, and let `a^B_g(p)` denote
the coefficients obtained by its endpoint extraction. For every `p>=0`,

```
                    a^B_g(p) = c^Bhat_(1,p)(-e_0).        (F)
```

Thus, after the already established theta identification, every formal
classical theta coefficient is the coefficient with framing degree exactly
one in a single transport column of an explicitly framed exchange matrix.
The input contains no potential, mutation word, moduli space or wall list.

The assertion is coefficientwise; it does not imply that either full
transport series or the original theta series is finite.

## 1. Support locality needed in the proof

For any exchange matrix and root `alpha`, `c_alpha(m)` only depends on the
principal submatrix on `supp(alpha)`, the restricted symmetrizer, and the
coordinates `m_i` on that support. This follows by induction on `|alpha|`:
all roots and indices in the Schur recursion are supported there, every
pairing reads only that principal submatrix, and axis leaves use only their
own coordinate of `m`.

In particular,

```
c^Bhat_(0,beta)(m_0,m) = c^B_beta(m).
```

Also `c^B_beta(0)=0` for every nonzero beta. For an axis this is
`binom(0,k)=0`. In the Schur recurrence every entry of the input column
`b_s=c_s(0)` is zero by induction; hence the output is zero.

## 2. The framing sign calculation, including zero faces

Fix a nonzero original root `p`, and apply the incoming Schur recurrence
to `alpha=(1,p)` with pivot `r=0`. A proper box index has framing degree
zero or one. For `s=(1,q)`, `q<p`, the first sign functional is

```
(Bhat alpha)^T Dhat s
    = -g^T D p + (g+Bp)^T D q
    = -(g+Bp)^T D(p-q).
```

Here `(Bp)^T Dp=0` was used. Write

```
h(p,q)=(g+Bp)^T D(p-q).
```

If `h(p,q)=0`, the secondary entries of the prescribed lexicographic sign
are `q_i-p_i`. All are nonpositive, and at least one is negative because
`q<p`. Therefore

```
sigma_(1,p)((1,q))>0  iff  h(p,q)<0.                     (S)
```

No generic perturbation ambiguity remains at a zero face. This is why
putting the framing vertex first is useful. Other allowed tie orders give
the same c-coefficients by the established uniqueness theorem, but are not
needed for this direct proof.

## 3. The zero-framing block disappears

The input monomial weight is `m=-e_0`. In the Schur system `Ev=b`, every
index `s=(0,q)` has

```
b_s=c^Bhat_(0,q)(-e_0)=c^B_q(0)=0.
```

All predecessors of a zero-framing index also have framing degree zero.
Ascending substitution therefore gives `v_(0,q)=0` at every such index.
This is a block-triangular argument; it is not a cancellation assumption.

Let

```
T_p={q:0<=q<p, h(p,q)<0}=I_p\{p}.
```

By (S), these are exactly the positive-halfspace indices with framing
degree one. Define `f_q=c^Bhat_(1,q)(-e_0)`. On this remaining block the
matrix and final row are, by support locality,

```
E[s,q] = c^B_(s-q)(g+Bq),
r[q]   = c^B_(p-q)(g+Bq),
b[q]   = f_q,                         q,s in T_p.
```

Indeed the original part of `-e_0+Bhat(1,q)` is exactly `g+Bq`; its
framing coordinate is irrelevant to an unframed root interval. Hence

```
f_p = r E^(-1) (f_q)_(q in T_p).                          (R)
```

If `T_p` is empty, the value is zero. At `p=0`, the axis initial value is
`f_0=binom(1,1)=1`.

## 4. Comparison with endpoint extraction

In increasing degree order, the restriction of `C^g` to `I_p=T_p union {p}`
has the block form

```
              [ E  0 ]
              [ r  1 ].
```

The last row of its inverse is `(-r E^(-1),1)`. Consequently the endpoint
recurrence in the main theorem is exactly

```
a_g(p)=r E^(-1)(a_g(q))_(q in T_p),      a_g(0)=1.
```

Induction on `|p|` now identifies this recurrence with (R), proving (F).
All matrices are finite and integral; the only inverse is unitriangular.

## 5. Consequence for the word and tree model

Expand the framed incoming recursion completely into axis packets. The
total framing content is one, so every leaf word has exactly one packet
of color 0, with multiplicity one. If any ordinary packet precedes it,
the first packet has binomial weight `binom(0,k)=0`. Thus every nonzero
leaf word begins with the framing packet `(0,1)`.

Its weight is one. Every subsequent packet `(i,k)` at original prefix `q`
has weight

```
                  binom(-g_i-(Bq)_i,k).
```

Therefore the positive-combinatorial problem can be stated using a single
family of ordered incoming trees with one distinguished initial leaf.
There is no additional independent endpoint segmentation to cancel.
This is an actual simplification of the object set, rather than just the
identity between the endpoint pairing and an augmented skew form in the
previous round's `FRAMED_HN_INTERFACE.md`.

Residual signs are still present in the tree coefficients and in generalized
binomial weights. The theorem does not declare these trees a positive model.
Its role is to put all those signs into one recursion and expose the
framing-degree-one locus as a candidate for a finite quotient or a local
sign-reversing involution.

## 6. Relation to representation-theoretic framing

The augmented matrix is exactly the integral framed skew form already
motivated by the endpoint inequalities. In the skew-symmetric case it
defines an ordinary quiver with one framing vertex, with arrows to or
from vertex i according to the sign of g_i. In the skew-symmetrizable case
the displayed Dhat provides the valued version without a division.

For mixed signs of g, this framing can introduce oriented cycles even
when B is acyclic. Thus a theorem on ordinary acyclic framed quiver moduli
cannot automatically supply positivity for all g. Nor does a canonical
basis theorem for a symmetric Cartan matrix identify these coefficients
with its multiplication coefficients. The exact identification still
needed is now the framed-column identity (F), not an unspecified
comparison with theta functions.

## 7. Initial exact verification

Four inputs were checked independently by calling the two-layer theta
routine and the framed one-layer c-routine: A2 with g=(-2,1), the cyclic
2-arrow matrix with g=(-1,0,0), a valued acyclic matrix with D=(1,2,1),
and a cyclic 3-arrow matrix with g=(1,-1,2). All 97 coefficient comparisons
agreed. These calculations verify implementation and conventions; the
proof is Sections 1--4.
