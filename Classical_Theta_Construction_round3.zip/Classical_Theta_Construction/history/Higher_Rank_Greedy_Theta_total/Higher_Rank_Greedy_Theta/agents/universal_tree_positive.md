# Positive vertices, cycle packets, and the remaining local quotient problem

Date: 2026-11-13. Branch: `universal_tree_positive`. All cluster statements here are classical. Both integral skew-symmetric and integral skew-symmetrizable matrices are included. No conclusion of Li–Pan is used.

## 0. Result and precise status

The useful general reduction from this branch is the following. Add the one framing vertex from `ONE_FRAMING_COEFFICIENT_THEOREM.md`. The coefficient of interest is then a primitive framed wall coefficient. Applying the general scattering version of the Argüz–Bousseau flow-tree theorem, with the normalization proved below, gives

\[
 a_g^B(p)=\sum_{\lambda^i\vdash p_i}
 \frac{(-1)^{|p|-\sum_i\ell(\lambda^i)}}{\prod_i z_{\lambda^i}}
 T_{\lambda^1,\ldots,\lambda^n},
 \qquad z_\lambda=\prod_{k\ge1}k^{m_k(\lambda)}m_k(\lambda)! .\tag{0.1}
\]

Every \(T_{\boldsymbol\lambda}\) is an explicitly defined **nonnegative integer count of binary flow trees with positive integer vertex colors**. The definition uses only \((B,D,g,p)\), integer pairings, rational linear operations, and lexicographic signs. It does not query a theta coefficient. The entire remaining sign is the sign of a same-color permutation cycle type. This is a material simplification of the original alternating Schur trees: all internal vertex signs have disappeared.

The identity is an application and normalization of an existing flow-tree theorem, not a new proof of that theorem or a priority claim for attractor trees. The one-frame identification is proved separately by the representation-interface branch. The additional primitive-ray comparison and integral local normalization are proved here. The weighted-cycle replication identity then identifies these positive tree counts with the candidate character values.

**The unsigned model requested by the user is not completed.** In particular, (0.1) still has cycle signs and denominators. A natural action of \(\prod_iS_{p_i}\), or an equivalent intrinsic local cycle-cancellation rule, has not been constructed. Several concrete proposed quotients fail; their exact counterexamples are retained so that the next branch can attack the necessary noncommuting moves rather than repeat them.

The calculation concerns each finite formal coefficient. It does not assert finite Laurent support for every label of every cluster algebra.

## 1. The one-frame column and its primitive ray

Let \(B\in M_n(\mathbb Z)\), let \(D=\operatorname{diag}(D_i)\) be positive integral with \(DB\) skew-symmetric, and let \(g\in\mathbb Z^n\). Put

\[
 \widehat B=\begin{pmatrix}0&-g^TD\\g&B\end{pmatrix},
 \qquad \widehat D=\operatorname{diag}(1,D),
 \qquad \alpha=(1,p).
\]

The established recurrence identity is

\[
 a_g^B(p)=c^{\widehat B}_\alpha(-e_0).\tag{1.1}
\]

For completeness, the proof mechanism is especially short. A zero-framing root reads only the original principal submatrix, so \(c_{(0,q)}(-e_0)=c_q(0)=0\) for \(q\ne0\). At a framed proper index \((1,q)<(1,p)\), the first incoming sign is

\[
 (\widehat B\alpha)^T\widehat D(1,q)
 =-(g+Bp)^TD(p-q).
\]

If this vanishes, the pivot-0 secondary signs are \(q_i-p_i\), all nonpositive and at least one negative. Thus precisely the endpoint indices with strict negative endpoint pairing survive. The zero-framing block of the Schur linear system has zero right-hand side and therefore vanishes. The remaining block is the endpoint inverse block, with entries \(c_{s-q}^B(g+Bq)\). Its Schur complement is exactly the theta endpoint recurrence. The initial framed axis value is one. This proves (1.1), including equality faces; details are in the separate theorem file.

Here is the further bridge to one wall logarithm. Work modulo roots outside the finite box \([0,\alpha]\). Choose

\[
 \vartheta=(-|p|,1,\ldots,1)
\]

or, more generally, positive mutable numbers \(\mu_i\) and \(\vartheta_0=-\sum_i\mu_ip_i\). Then

\[
 \vartheta(0,q)>0\quad(q\ne0),\qquad
 \vartheta(1,q)<0\quad(q<p),\qquad
 \vartheta(\alpha)=0.\tag{1.2}
\]

Thus \(\alpha\) is the only nonzero zero-slope root in the box. Factor the total incoming transport by this covector as

\[
 C=U^-U^0U^+,
\]

where the three factors use negative, zero, and positive slope root spaces. The right factor \(U^+\) has only zero-framing roots; all its derivations fix \(x_0^{-1}\). The middle factor has only root \(\alpha\) in this truncation. The left factor has only framed proper roots. It cannot contribute degree \(\alpha\) by itself: a single such root is not \(\alpha\), and two have framing degree two. It also cannot change a term already of degree \(\alpha\) without increasing its framing degree. Consequently

\[
 [z^\alpha]Cx_0^{-1}=[z^\alpha]U^0x_0^{-1}.\tag{1.3}
\]

Since \(\alpha_0=1\), it is primitive. No nontrivial multiple or repeated exponential term can contribute its degree.

### 1.1 Sign convention: the wall logarithm is the negative transport logarithm

This point must not be suppressed. Define

\[
 d(\gamma)=\gcd_j(\widehat D_j\gamma_j),\quad
 u_\gamma=\widehat D\gamma/d(\gamma),\quad
 X_\gamma=z^\gamma\partial_{u_\gamma}.
\]

Our incoming transport crosses an initial wall by its inverse:

\[
 x^m\longmapsto x^m(1+z_i)^{-m_i}.
\]

The initial wall logarithm, before taking that inverse, is

\[
 I_i=\sum_{k\ge1}\frac{(-1)^{k-1}}{k}X_{ke_i}.
\]

Use the same crossing orientation at the middle wall, so \(U^0=\exp(-I_\vartheta)\). Since \(d(\alpha)=1\), the coefficient of \(z^\alpha x_0^{-1}\) in \(X_\alpha x_0^{-1}\) is \(-1\). The negative logarithm and this negative action cancel. Equations (1.1)–(1.3) therefore give

\[
 \boxed{a_g^B(p)=[X_\alpha]I_\vartheta.}\tag{1.4}
\]

Equivalently, it is the coefficient of \(-X_\alpha\) in \(\log U^0\). Writing it as the coefficient of positive \(X_\alpha\) in \(\log U^0\) would introduce a sign error.

This argument is coefficientwise and uses the abstract root-graded scattering algebra. It does not identify an arbitrary quiver stability diagram with the cluster scattering diagram and requires no potential or red-to-green sequence.

## 2. A positive integer tree for each colored cycle type

Fix partitions \(\lambda^i\vdash p_i\). Make a set of individually labeled packet leaves: one leaf of charge \(e_0\), and one leaf of charge \(ke_i\) for each part \(k\) of \(\lambda^i\). Identical charges still have distinct packet labels during the tree construction. Let \(J\) be this finite set. For a subset \(S\subseteq J\), write \(\gamma_S\) for its total charge. Put

\[
 \eta(\gamma,\delta)=-\gamma^T\widehat D\widehat B\delta.
\]

We consider rooted, nonplanar, full binary trees with precisely these labeled leaves. The empty mutable packet set has the single frame leaf, with weight one.

### 2.1 Exact lexicographic flow rule

Lift \(\vartheta\) to the free lattice on packet leaves. A mutable packet of charge \(ke_i\) first has weight \(k\), and the frame has the negative sum of all mutable weights. Add independent positive infinitesimals to the mutable packet weights, and again make the frame weight the negative sum. They can be represented by finite coefficient vectors and lexicographic comparison, with no floating-point approximation.

For instance, if mutable leaves are indexed \(j=1,\ldots,r\), use

\[
 \theta_j=k_j+\epsilon^j,
 \qquad\theta_0=-\sum_j\theta_j.
\]

An optional earlier level of infinitesimals depending only on original colors gives a generic point on the original color lattice before the final packet perturbation. This option is implemented separately in the code; it is useful for studying simultaneous events.

At a vertex whose leaf set is \(S=L\sqcup R\), with inherited covector \(\theta\), compute

\[
 a=\eta(\gamma_L,\gamma_R),\qquad h=\theta(L).
\]

If \(a=0\), the entire tree has zero Lie contribution and is discarded before dividing. Otherwise the vertex is admitted exactly when

\[
 \operatorname{sgn}(h)=\operatorname{sgn}(a).\tag{2.1}
\]

Pass to both children the covector

\[
 \theta'=\theta+\frac{h}{a}\eta(\gamma_S,-).\tag{2.2}
\]

Its sum on each child is zero. The same rule is then applied recursively. Swapping the names \(L,R\) changes both signs, and changes neither admissibility nor the new covector, so no plane ordering is introduced.

There are finitely many candidate trees and all relevant tests are rational linear forms in the initial leaf weights. Each test for a nonzero-bracket tree is nonzero as a linear form: vary the initial weights only inside the current vertex, with total variation zero there and nonzero variation on one child. Every ancestor sees zero total variation in its relevant descendant and hence its earlier projections are unchanged. The current test changes. Independent lexicographic packet perturbations therefore avoid every such zero simultaneously.

Zero original brackets need not be assigned a flow denominator: their nested Lie contribution is already zero. This is also how the fixed-skew specialization of the general flow-tree theorem is evaluated here. Alternatively, retain a generic skew perturbation in the theorem and set these zero Lie contributions to zero before specializing. The nonzero original brackets have well-defined limits. Small perturbations stay in the same finite-degree framed wall chamber by the strict inequalities (1.2).

### 2.2 Positive primitive vertex multiplicity

Color an admitted vertex \((L,R)\) by an integer in

\[
 \left\{1,\ldots,
 b(\gamma_L,\gamma_R)\right\},
 \qquad
 b(\gamma,\delta)=
 |\eta(\gamma,\delta)|\frac{d(\gamma+\delta)}{d(\gamma)d(\delta)}.
 \tag{2.3}
\]

The number in (2.3) is always a nonnegative integer, including the valued case. Indeed \(\eta(\gamma,\delta)\) is divisible by both \(d(\gamma)\) and \(d(\delta)\). Their least common multiple divides it, while their greatest common divisor divides \(d(\gamma+\delta)\). Their product therefore divides the numerator in (2.3).

Let \(T_{\boldsymbol\lambda}\) count all such admitted, vertex-colored trees. This is a finite, nonnegative integer definition. No output coefficient is used to define any color set.

It is often faster to compute using raw weights \(|\eta|\) and divide once. The factors \(d(\gamma)\) telescope over a tree, and the framed root has degree one. Hence

\[
 \prod_v b_v=
 \frac{\prod_v|\eta_v|}{\prod_{\text{mutable packets }ke_i}D_i k}.
 \tag{2.4}
\]

The quotient is integral separately for every tree, not just after summing trees.

### 2.3 Derivation of the cycle formula

The commutator in the primitive basis is

\[
 [X_\gamma,X_\delta]
 =-\eta(\gamma,\delta)
 \frac{d(\gamma+\delta)}{d(\gamma)d(\delta)}X_{\gamma+\delta}.
\]

The general Argüz–Bousseau scattering formula uses at each vertex the factor
\(-\tfrac12(\operatorname{sgn}(h)+\operatorname{sgn}(\eta))\)
times this bracket. It is zero when the signs disagree and gives exactly (2.3) when they agree. Thus every internal contribution is positive. The initial packet \(ke_i\) contributes \((-1)^{k-1}/k\). Repeated identical packets contribute the usual factorial denominator from polarization. Multiplying these leaf contributions gives precisely

\[
 \prod_i\frac{(-1)^{p_i-\ell(\lambda^i)}}{z_{\lambda^i}}.
\]

Equation (1.4) then proves (0.1). The external result used is the general scattering formula, Theorems 4.22 and 4.24 of Argüz–Bousseau, not the later specialization to DT invariants of quivers with potential.

When every \(p_i\) is zero or one, the formula itself is already an unsigned integer tree count. For arbitrary multiplicities, the correct unresolved issue is now cycle cancellation, not internal Schur signs.

## 3. Relation to weighted cycle clones

The independent replication branch proves that the cycle character candidate is the squarefree coefficient for

\[
 (B_{\boldsymbol\lambda})_{(i,k),(j,l)}=lB_{ij},
 \qquad(D_{\boldsymbol\lambda})_{(i,k)}=kD_i,
 \qquad(g_{\boldsymbol\lambda})_{(i,k)}=g_i.
\]

Its framed skew pairing between two packet vertices is exactly \(-klD_iB_{ij}\), and the pairing with the frame is also the packet pairing above. The primitive degrees at packet leaves are \(kD_i\), and at the framed root they are one. Thus its squarefree positive flow-tree formula is the same \(T_{\boldsymbol\lambda}\). In the notation of that branch,

\[
 T_{\boldsymbol\lambda}=\chi_p(\boldsymbol\lambda),\qquad
 a_g(p)=\langle\chi_p,\operatorname{sgn}\rangle_{\prod_iS_{p_i}}.
 \tag{3.1}
\]

This explains exactly why a natural finite group action would solve the remaining cancellation problem. The generalized positivity result audited by the other branch gives an abstract positive sum of Young permutation characters. It does not specify an intrinsic tree quotient, and it is not used here to define objects.

An independent numerical convention check uses the cyclic Markov matrix with all three cyclic arrow multiplicities two, \(g=(-1,-1,-1)\), \(p=(2,2,1)\). The four cycle values from this tree code are

| Colored cycle type | Raw tree weight | Product of leaf primitive degrees | \(T_{\boldsymbol\lambda}\) |
|---|---:|---:|---:|
| \((2;2;1)\) | 92 | 4 | 23 |
| \((2;11;1)\) | 158 | 2 | 79 |
| \((11;2;1)\) | 82 | 2 | 41 |
| \((11;11;1)\) | 133 | 1 | 133 |

These are the four independently obtained replication traces. Their signed average is \((23-79-41+133)/4=9\).

## 4. Why the original word normal form cannot be the whole answer

Expand a Schur tree into its chronological axis-packet word
\(w=((i_1,k_1),\ldots,(i_s,k_s))\). All its parenthesizations have the same scalar leaf product

\[
 W_m(w)=\prod_j
 \binom{-(m+B\sum_{h<j}k_he_{i_h})_{i_j}}{k_j}.
\]

Let \(K_B(w)\) be the sum of their internal signs. This coefficient is independent of \(m\), and the word expansion is exact. The implementation `universal_word_probe.py` agrees with the integer Schur recursion in 804 coefficient comparisons across six skew and valued matrix families.

The lex tie rule can be encoded by one infinitesimally perturbed skew form. For a word, interval heights

\[
 H(i,j)=\sum_{i\le a<b<j}\omega(\gamma_a,\gamma_b)
\]

turn every cut test into \(H(i,j)-H(i,k)-H(k,j)\). These satisfy the tetrahedron cocycle identity. This suggested a signed normal form with \(K\in\{0,\pm1\}\); it is false even without ties.

For

\[
 B=\begin{pmatrix}
 0&-5&4&2&0\\
 5&0&-1&-4&6\\
 -4&1&0&1&-4\\
 -2&4&-1&0&-1\\
 0&-6&4&1&0
 \end{pmatrix},
 \qquad w=((0,1),(1,1),(2,1),(3,1),(4,1)),
\]

one obtains \(K_B(w)=-2\), with every interval cut pairing nonzero. The exact integer counterexample is in `universal_cocycle_counterexample.json`.

This was found by exhaustively enumerating all \(2^{20}=1,048,576\) Boolean cut patterns at word length five. Of these, 10,680 have \(|K|>1\), and 67 survive the elementary tetrahedron sign constraints. The first linear-feasibility candidate gives the displayed integer matrix, after which the actual Schur word coefficient is verified exactly. Only one LP call was needed; the final counterexample does not rely on floating-point certification.

The relevant prior framework is Mozgovoy's operadic inversion and attractor-tree formula. A fixed change of stability has a Joyce sign symbol in \(\{0,\pm1\}\), but our root-dependent cut tests are not a fixed pair of stability functions. That result therefore cannot prove the false \(0,\pm1\) claim. The counterexample redirects the problem toward cross-word merging rather than a unique signed object in each word.

### 4.1 Keeping a rooted attachment tree fixed also fails

For squarefree framed words, expanding each later singleton capacity as a sum over earlier leaves attaches that leaf to one earlier parent. It is tempting to cancel chronological orders while fixing the resulting rooted attachment tree. This leaves negative fibers.

Already

\[
 \widehat B=\begin{pmatrix}0&-3&4\\3&0&-2\\-4&2&0\end{pmatrix}
\]

has framed coefficient two at root \((1,1,1)\), while the attachment path \(0\to1\to2\) contributes \(-6\), and \(0\to2\to1\) contributes \(+8\). The positive combination is \(2(4-3)=2\). Thus a viable local model must allow a root-edge reattachment or the corresponding bracket/slot merging. The flow-tree regrouping does exactly this at the Lie-algebra level.

The script `universal_attachment_tree_probe.py` checked 600 exact random matrices of sizes three through six, always comparing the full sum against the Schur coefficient. Negative fixed-tree fibers occurred at every size. They are recorded as mechanisms to avoid, not as a separate special-case research goal.

## 5. A real local cancellation, and the exact place it stops

### 5.1 Equal-charge twig bundles

If two equal-charge twigs \(a,b\) attach consecutively to a core subtree \(C\), then \(\eta(a,b)=0\). The local rotation

\[
 ((a,C),b)\longleftrightarrow((b,C),a)
\]

preserves the product of local vertex multiplicities. In raw coordinates let \(x=\eta(a,C)\), \(y=\eta(b,C)\), \(t_a=\theta(a)/x\), \(t_b=\theta(b)/y\). The first shape is admitted when \(t_a>t_b>0\); the other uses the reversed strict order. For equal charges, swapping their infinitesimal weights swaps these two orders and gives the same inherited data on the core. Local arrow colors follow their twigs.

For a whole bundle of \(k\) identical twigs sharing a common capacity \(r\), this reduces the cycle sum to

\[
 \sum_{\lambda\vdash k}\frac{(-1)^{k-\ell(\lambda)}r^{\ell(\lambda)}}{z_\lambda}
 =\binom rk.
\]

There is an explicit local involution before division by \(k!\): objects are a slot map \(f:[k]\to[r]\) and a permutation \(\sigma\) whose cycles each have constant \(f\). If a slot has repeated labels, choose the lexicographically first pair \(a<b\) in a common slot and replace \(\sigma\) by \((ab)\sigma\). This joins or splits two cycles, reverses the sign, preserves the slot map, and is an involution because the selected pair is unchanged. Fixed points have injective \(f\) and \(\sigma=1\). Quotienting their free label action gives the \(r\)-slot subsets. This is a genuine local rule, not coefficient rank matching.

The unresolved question is how to extend a slot-bundle description across interacting, noncommuting subtrees.

### 5.2 Leaf-twig quotient: explicit failure

The script `universal_twig_action_probe.py` groups maximal equal-color leaf combs into unordered bundles, looks for positive representatives, and tests external clone transpositions. Among 500 tested matrices, 499 passed these necessary checks and one failed. The failing input is

\[
 B=\begin{pmatrix}0&2&-3\\-2&0&2\\3&-2&0\end{pmatrix},
 \quad g=(-3,3,-2),\quad p=(2,2,1).
 \tag{5.1}
\]

Label the frame by 0, the two first-color leaves by 1,2, the second-color leaves by 3,4, and the third-color leaf by 5. The positive tree

\[
 (((0,5),(1,4)),(2,3))
\]

has raw weight eight. Swapping clones 1 and 2 produces a bundle class without a positive representative. The equal-charge composite branches \((1,4)\) and \((2,3)\) show why a leaf-only rule is too small.

### 5.3 Even all commuting-subtree rotations fail

The stronger script `universal_commuting_action_probe.py` uses every nonzero-bracket binary tree and every local rotation

\[
 ((A,C),B)\longleftrightarrow((B,C),A)
 \quad\text{with}\quad\eta(\gamma_A,\gamma_B)=0.
\]

It forms the full graph components, not just one-step neighborhoods. Every rotation preserves the local weight. Random probes can be misleading: all 375 random cases in this run passed. Nevertheless the same explicit input (5.1) fails the stronger test.

There are 504 nonzero-bracket binary trees, 564 directed rotation-edge entries, and four positive trees with total weight 88. Each positive tree lies in a different commuting component. The positive tree

\[
 ((0,5),(1,((2,3),4)))
\]

has weight 64. Swapping 1 and 2 gives

\[
 ((0,5),(((1,3),4),2)),
\]

whose entire commuting-rotation component, of size four, has no positive representative. This disproves this proposed quotient action. It does not disprove a natural symmetric-group action after a richer local reorganization.

### 5.4 Distinguish zero-length contraction from the failed quotient

The parent proposed retaining a generic stability depending only on original colors, with no final leaf-distinct perturbation, and contracting all zero-flow-length edges into nonbinary vertices. This has **not** been tested or disproved by the preceding experiment.

The failed equivalence relation uses \(\eta(A,B)=0\). A zero-length event instead has a vanishing inherited flow test \(h=0\), and can have \(\eta(A,B)\ne0\). Its contraction can therefore collect the noncommuting binary refinements that the failed quotient cannot connect. In the uncoupled case, simultaneous identical twigs indeed collapse to the slot-map model with its nonfree symmetric-group action. A general version would require an intrinsic decoration of every simultaneous vertex, together with coherent chamber transport between its binary refinements.

The code supports a hierarchy of color perturbations followed by leaf perturbations, but no nonbinary simultaneous-event decoration is presently implemented. The input and trees in Section 5.3 are a useful first challenge for that next mechanism.

### 5.5 Concrete next move: colored Jacobi rectangles

For three charges write \(a=\eta(A,B)\), \(b=\eta(A,C)\), \(c=\eta(B,C)\). The local Jacobi identity is the exact signed integer identity

\[
 a(b+c)-b(a-c)-c(a+b)=0.
\]

The three binary shapes carry signed rectangular color sets of these sizes. One can expand a net slot interval, such as \(b+c\), into the two signed slot intervals, cancel opposite slots by their local order, and pair equal two-edge color products through the Jacobi identity. An involution-principle path through these local pairings is a plausible way to transport colors when more than commuting rotations are needed.

No global theorem is claimed for this proposal. In particular, preserving an integer weight locally is not enough: transport must be coherent around associahedral pentagons and around braid relations for clone swaps. Establishing that coherence, or replacing the binary refinements by a direct nonbinary decoration, is the concrete remaining difficulty.

## 6. Literature review and audit decisions

### 6.1 Mozgovoy: useful algebraic precursor; no positive model supplied

Sergey Mozgovoy, *Operadic approach to wall-crossing*, arXiv:2101.07636; J. Algebra 596 (2022), 53–88. Primary text: <https://arxiv.org/pdf/2101.07636>. Author slides: <https://www.maths.tcd.ie/~mozgovoy/talks/Paris-29.03.21.pdf>.

Read the free-operad tree construction, HN inversion, and the attractor-tree results in Sections 2–3. These establish that plethystic inversion by rooted trees is prior art. The present Schur tree is a concrete integer operator implementation of that mechanism. The fixed-stability Joyce sign product does not handle the changing root-dependent stability here. Status: useful framework, no imported positivity conclusion, and no novelty claim for tree inversion.

### 6.2 Argüz–Bousseau: the theorem actually used

Hülya Argüz and Pierrick Bousseau, *The flow tree formula for Donaldson–Thomas invariants of quivers with potentials*, arXiv:2102.11200v2, 15 September 2022; Compositio Mathematica 158 (2022), 2206–2249. Primary text: <https://arxiv.org/pdf/2102.11200>.

Read the discrete flow, the vertex sign and bracket formulas (2.23)–(2.24), the polarization factor, and the proofs/interfaces of Theorems 4.22 and 4.24. The general scattering statement is sufficient for Section 2; the quiver-with-potential specialization in Section 5 is unnecessary. The local sign and primitive normalization have been checked directly above and against an independent integer recursion. Degenerate original brackets are suppressed before a denominator is formed. Status: established external theorem used with explicit conventions; the theta/framing identification is separately proved, not assumed from DT terminology.

### 6.3 OpenAI chromatic paper, 2026: direct packet recipe rejected for this task

Parent supplied the original repository commit `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb` at <https://github.com/openai/math> and the readable manuscript mirror <https://wcook04.github.io/plectis-atlas/papers/Elementary-Positivity-of-Chromatic-Quasisymmetric-Functions-September-24-2026.html>.

Read Sections 6.1–6.3. Packet decorations there are indexed by already-positive section coefficients. Section 6.2 identifies two single-packet sets by finite rank and later identifies jump tuples by rank again. This is not the input-defined local involution required here, even though it avoids redistribution by the final target coefficient. We therefore do not import this construction as our solution. The source-side versus target-side packet bookkeeping may be a useful organizational idea. The paper's positivity proof was not fully audited, and no assertion that the paper is false is made.

### 6.4 Burcroff–Lee–Mou, November 2026: relevant new interface, proofs not yet in this version

Amanda Burcroff, Kyungyong Lee, and Lang Mou, *Bijecting m-Tamari intervals, trees, and tight gradings*, arXiv:2611.10154v1, submitted 6 November 2026. Primary text: <https://arxiv.org/html/2611.10154v1>; PDF: <https://arxiv.org/pdf/2611.10154>. Official related seminar: <https://www.math.harvard.edu/event/leafy-trees-wall-crossing-and-m-tamari-intervals/>.

Read the complete extended abstract, including the explicit forward maps and proposed inverse. The manuscript itself says proofs will appear in a later full version. Its claimed leafy-tree/Tamari/tight-grading bijections are therefore not accepted here as independently proved input. The supplied rule concerns central rank-two skew-symmetric walls, not arbitrary high-rank vertices. A minor HTML/PDF numbering and cover-date discrepancy is recorded; neither version is silently substituted for the other. Status: useful ideas, restricted scope, no theorem imported into Sections 1–5.

One elementary part can be verified independently and suggests a genuine local construction. For an ordered rooted tree, require every descendant subtree to have positive surplus \(\#\text{leaves}-m\#\text{internal vertices}\). If \(A\) counts such trees and \(G\) their ordered forests by internal count \(t\) and surplus \(u\), then the combinatorial specification directly gives

\[
 A=u+t u^{-m}\left(G-\sum_{j=0}^mG_ju^j\right),
 \qquad G=(1-A)^{-1}.
\]

Eliminating \(A\) proves

\[
 tG^2-\left(u^m(1-u)+t\sum_{j=0}^mG_ju^j\right)G+u^m=0.
\]

This derivation does not rely on the stated bijections. It suggests looking for a charge-surplus specification at the simultaneous vertices of Section 5.4. A general multicolor surplus and its compatibility with the framed flow remain to be found; the rank-two rule alone does not supply them.

### 6.5 Further interfaces kept separate from proved inputs

Reineke–Rhoades–Tewari, arXiv:2207.11861, supplies a natural automorphism action on graphical break divisors and a central zonotopal algebra in a symmetric-quiver setting; the replication branch read its primary proof. It suggests stable object sets with nontrivial stabilizers, which binary trees alone lack. No transfer of that theorem to the present oriented/valued flow is asserted. The root has assigned the polytope branch to examine this interface.

The generalized scattering positivity theorem, arXiv:2503.03719, and the 2026 quiver-moduli/tight-gradings paper, arXiv:2511.14672, are owned by the other audit branches. Their conclusions are not silently used in the local constructions here.

## 7. Reproducible computation and route log

All scripts use exact integers and `fractions.Fraction` for their actual coefficients and signs. `IncomingSchur` is a comparison oracle only; it is not used by the flow construction. The LP in the cut-pattern search finds a candidate, followed by a complete exact integer check.

| File | Purpose and saved outcome |
|---|---|
| `universal_word_probe.py/.json` | Complete packet-word expansion; 804 numeric coefficient comparisons; all passed. |
| `universal_cocycle_probe.py/.json` | Exhausted 1,048,576 length-five cut patterns; located a realizable coefficient of −2. |
| `universal_cocycle_counterexample.json` | Exact integer matrix and exact Schur verification of that counterexample. |
| `universal_attachment_tree_probe.py/.json` | 600 matrices; exact full sums agree, but fixed attachment-tree fibers can be negative. |
| `universal_flow_tree_probe.py/.json` | Independent rational flow algorithm; 108 full coefficients across skew and valued inputs agree with Schur. |
| `universal_flow_tree_trace_checks.json` | Independent Markov cycle traces 23, 79, 41, 133 and their signed average. |
| `universal_twig_action_probe.py/.json` | 500 matrices; leaf-twig quotient fails on the explicit cyclic input. |
| `universal_commuting_action_probe.py/.json` | Full commuting rotation components; explicit weight-64 failure, despite 375 passing random inputs. |
| `universal_tree_wolfram_audit.json` | Actual Wolfram evaluation of the three-leaf sign formula over 729 integer triples. |

The Wolfram calculation gives 585 zeros, 30 values −1, and 114 values +1 for the length-three sign expression. It is an independent plugin check of that small algebraic formula, not evidence for the false all-length normal-form claim.

Run the flow comparison with `python agents/universal_flow_tree_probe.py`. Other scripts have corresponding runnable entry points. Their output JSON files are compact and contain the decisive data, avoiding a large archive of every generated tree.

The substantive route sequence was: common-weight words → cocycle normal-form candidate → exact counterexample → attachment-tree regrouping → negative fibers → one-frame primitive wall → positive flow vertices → weighted-cycle character → same-slot cycle involution → commuting twig quotient → exact noncommuting obstruction. Every abandoned mechanism has a concrete reason above. The next proposed step changes the mechanism by allowing simultaneous nonbinary events or colored Jacobi transport; it is not another restatement of the original coefficient problem.

## 8. Handoff target

The next branch should begin with the explicit input (5.1), construct its color-generic simultaneous flow events, and seek a natural decoration of each contracted vertex. A successful construction must satisfy three requirements together: expand to the integer tree weights (2.3), make clone relabeling coherent without selecting objects by the final coefficient, and make a cycle of length \(k\) act as the weighted packet \(ke_i\). The same-slot involution already supplies the local terminal rule once those three requirements hold.

No additional range audit or special-family extension is needed to formulate that problem. The precise missing step is a local, coherent noncommuting reorganization of the positive flow trees.
