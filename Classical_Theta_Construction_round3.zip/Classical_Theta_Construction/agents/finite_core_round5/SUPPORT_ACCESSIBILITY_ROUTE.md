# General finite-output route: support accessibility

Started 2026-11-13, 20:10 UTC. Status: **conjectural premise, exact conditional algorithm**.

Write $\theta_g=x^g F_g(z)$, with $F_g\in\mathbb N[[z_1,\ldots,z_n]]$ and constant coefficient one. Existing incoming-recursion machinery computes every requested coefficient exactly from a finite box.

## The actual missing premise

**Directed unit accessibility:** every nonzero $p\in\operatorname{supp}F_g$ has an index $i$ with $p_i>0$ and $p-e_i\in\operatorname{supp}F_g$.

This is much weaker than coordinatewise downward closure or Newton saturation. Neither stronger assertion is being presumed. A still weaker sufficient premise is that the total degrees occurring in the support form an initial interval.

## Conditional finite-output theorem

Under directed unit accessibility, start at $0$ and repeatedly query the coefficient of each unit successor of a discovered supported exponent. Enqueue those with nonzero coefficient. When every successor of every discovered exponent has been queried and no unprocessed supported exponent remains, output the discovered polynomial.

Every supported exponent is reached by reversing its predecessor chain. Thus the empty frontier proves completeness, and the procedure terminates whenever $F_g$ has finite support. It needs no external Newton bound, no certificate that an upper-cluster witness is in the finite theta span, and no hypothesis $\mathrm{mid}=\mathrm{up}$.

Under just total-degree no-gaps, compute successive homogeneous layers. The first zero layer certifies termination. Again this conclusion is conditional until no-gaps is proved.

## Exact computation directed at the premise

- `support_accessibility_probe.py`: 600 random skew-symmetrizable inputs, ranks 2–5, symmetrizers 1–3, substantial arrow multiplicities; 12,008 supported-root predecessor checks, all passed. Seed 2611132013.
- `support_accessibility_deep.py`: 1,200 deeper sparse-label inputs (800 rank 3, 300 rank 4, 100 rank 5), mixing skew-symmetric and valued data; 7,462 checks, all passed. Seed 2611132020.
- These are exact integer computations from the general incoming-recursion implementation. Finite boxes are adequate for a *counterexample* to accessibility because every predecessor of an exponent in the box is also in the box. Passing does not prove the conjecture and does not certify that any tested series is globally finite.

A proposed stronger maximum principle was decisively rejected: requiring the predecessor direction to have negative endpoint exponent $g_i+(Bp)_i<0$ fails. One exact input is $B=((0,9,2),(-6,0,8),(-2,-12,0))$, $D=(2,3,2)$, $g=(-4,5,3)$, $p=(1,0,1)$, with coefficient 2. Its supported predecessor is $(1,0,0)$, but the corresponding third endpoint exponent is positive. Recorded in `negative_accessibility_results.json`. This changes the proof search: a sign-local endpoint rule is unavailable; any proof must transport/prune globally.

## General proof interfaces and their precise gaps

1. **Cocyclic framed representations.** Their nonempty dimension support is accessible by removing mutable simple quotients while retaining the framing socle. But arbitrary cluster theta functions have not been identified with these moduli: weak genteelness and Euler/cohomology nonvanishing are genuine obstacles. Do not import this as a theorem about all theta functions.
2. **Positive binomial strings under mutation.** Positivity in two adjacent seeds decomposes each one-variable slice into positive consecutive binomial strings. A gap cannot be crossed by a single such string. The missing claim is preservation of component separation under *subsequent* mutations, and directed accessibility is stronger than mere connectedness. No proof yet.
3. **Raw stable trees and coherent flagged transport.** At a positive mutable / negative frame stability, ordinary stable trees are rooted arborescences and admit leaf pruning. The axis-flow-selected subcatalog is not obviously hereditary. Repeated-label primitive-phase descent and coherent choice under deletion are the remaining interfaces, not permission to use all stable trees.
4. **Infinite valuative independence.** CMMM Theorem 3.8 requires a finite infimum of the valuations of all summands. A finite resulting Laurent polynomial can arise only after signed infinite cancellations in the unproved scenario, so its finiteness alone does not establish this hypothesis. This does not currently remove the finite-span assumption in the signed witness method.

## Literature checks through 20:23 UTC

- Cheung, *Theta functions and quiver Grassmannians*, arXiv:1906.12299 (2019), primary abstract read. Useful Hall/Grassmannian interface, not a general theta character identification.
- Bridgeland, *Scattering diagrams, Hall algebras and stability conditions*, Algebraic Geometry 4 (2017), primary https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf , §10 explicitly describes **some** theta functions through framed moduli; general case is not established there.
- Mandel, *Donaldson–Thomas invariants from tropical disks*, primary PDF https://d-nb.info/121828675X/34 . It explicitly warns that Hall algebra broken lines need not give consistent Hall theta functions. This rules out an unqualified lift of every classical broken line to a hereditary Hall object.
- Qin, primary https://ems.press/content/serial-article-files/47257 , Definitions A.2.1–A.2.2 distinguish genteelness from weak genteelness. The older primary https://archive.ymsc.tsinghua.edu.cn/pacm_download/276/11900-main.pdf states the generic finite-dimensional Jacobian case as a conjecture. This is a boundary, not an all-quiver theorem used here.
- Pilaud–Reading–Schroll, *Posets for F-polynomials in cluster algebras from surfaces*, primary author PDF https://www.ub.edu/comb/vincentpilaud/documents/publications/PilaudReadingSchroll_clusterFormulas.pdf , Theorem 1.1 and Corollary 1.2 read. Unit-label order ideals give accessibility in their model; self-folded cases allow weights $\hat y_i/\hat y_j$. Therefore even a positive order-ideal model requires attention to the grading before it can give unit accessibility. Useful interface; no special-case theorem is counted as progress on the general target.
- Search hits from arXiv Troller concerning 2026 weighted row counterexamples are secondary, not trusted or used. They concern specialized coefficient weights and do not by themselves refute principal-root total-degree no-gaps.


## Correction after comparison with the older project

The proposed spherical-shuffle cyclic-module route was implemented independently, but the balanced Markov dimension discrepancy (10 versus theta 7) and the attractor-ideal repair target were already present in `history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/natural_incoming_module.md`, §7. It is **not new**. The route was stopped immediately when the parent pointed out this overlap. The present exact code additionally finds a support discrepancy for $B=((0,-1,2),(1,0,1),(-2,-1,0))$, $g=(0,-2,3)$, $p=(1,1,1)$: the spherical quotient has dimension one, while the theta coefficient is zero. This does not solve the target and should not be counted as a main result.

Likewise, the local unit-component positive-binomial lemma and the full-atlas component construction were already proved in `history/classical_high_rank_greedy_total/work/agent_polytope/PACKET_COMPONENTS_AND_MASS.md`. Its §4 demonstrates component merging under mutation through persistent central coefficients, and shows why full-atlas connectivity gives no initial mass/degree bound. The older `agent_interior/PACKET_COMPONENTS.md` records the associated least-point and rematching gaps. These should be read before restarting that proof route.

The **theta-specific** assertion that its initial principal-root support is unit-accessible (or merely has no total-degree gaps) remains the precise unproved premise. Neither the old local packet theorem nor the new numerical checks establishes it.

## Strong review of the new spherical reference

Gaiotto–Grygoryev–Li, *Categories of Line Defects and Cohomological Hall Algebras*, arXiv:2406.07134v3, header 2 February 2026; publication JHEP 07 (2026), 048. Primary text https://arxiv.org/html/2406.07134v3 read at §§1.2, 2.6, 4.1–4.4. The intrinsic spherical shuffle algebra and bimodule definitions are concrete, but the text explicitly assumes that the spherical algebra equals the CoHA for some infinitely mutable potential (§2.6), and labels the resulting framed PBW properties conjectural (§4.2). Consequently the factorization in §4.4 is not an unconditional theorem for arbitrary framed seeds. It cannot be used to identify the cyclic quotient with all cluster theta functions. No theorem from this 2026 source was imported.

The exact test uses polynomial ideals in squarefree root degree. Every ordering of the mutable symbols and one frame gives the product of $(x_i-x_j)^{a_{ij}}$ over arrows respecting that ordering, with the frame variable set to zero. Let $M$ be the ideal generated by all such words, and $N$ the subideal generated by words with nonempty suffix after the frame. The quotient $M/N$ models the squarefree part of the spherical bimodule modulo its right augmentation. Groebner leading-ideal differences give its dimension, using finite colon bounds, not empirical Hilbert stabilization. The recorded `monomial_basis` is a basis of the associated graded leading-ideal quotient; it should not be read as asserting that each bare monomial lies in the original ideal $M$.

Wolfram's actual context tool was called for this interface. Its mathematical search supplied no new cluster-theoretic fact. No separate Wolfram computation was pursued after recognizing the duplicate route; exact integer/Groebner computations were run locally, and the root's other branches already use the computation plugin.

## Hand-off status

Established in this round: independent source-face and associated-graded review; independent primitive-phase orbit review; exact conditional finite-output algorithms under accessibility/no-gaps. Tested but unproved: general theta support accessibility. No unconditional general stopping certificate was obtained, and no empirical truncation is declared complete.
