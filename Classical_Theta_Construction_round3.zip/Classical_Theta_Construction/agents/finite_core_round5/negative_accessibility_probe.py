"""General finite-support stopping route: test directed unit accessibility.

If every nonzero supported root has a supported predecessor p-e_i, then a
vanishing complete outer boundary is a certificate of complete support.
These exact probes test the premise, not a collection of special formulas.
"""
from pathlib import Path
import sys, random, json, time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from stable_root_probe import IncomingSchur

def run(trials=600):
    rng=random.Random(2611132024)
    start=time.time(); checks=0; fails=[]; cases=[]
    for trial in range(trials):
        n=2 if trial<100 else 3 if trial<400 else 4 if trial<560 else 5
        D=[rng.randint(1,3) for _ in range(n)]
        B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                a=rng.randint(-4,4)
                B[i][j]=D[j]*a;B[j][i]=-D[i]*a
        cap=(5,5) if n==2 else (3,3,3) if n==3 else (2,2,2,2) if n==4 else (1,)*n
        g=tuple(rng.randint(-5,5) for _ in range(n))
        R=IncomingSchur(B,D)
        F=R.theta_prefix(g,cap)
        bad=[]
        for p in F:
            if not any(p):continue
            checks+=1
            m=R.shift(g,p)
            pred=[tuple(p[j]-(j==i) for j in range(n)) for i in range(n) if p[i] and m[i]<0]
            if not any(q in F for q in pred):
                bad.append(dict(p=p,coefficient=F[p],predecessors=pred))
        if bad:
            fails.append(dict(B=B,D=D,g=g,cap=cap,bad=bad,
                              terms=[[p,c] for p,c in F.items()]))
            print(json.dumps({'failure':fails[-1]}),flush=True)
            # A counterexample settles the proposed route. Keep its exact
            # support and stop rather than compiling irrelevant examples.
            break
        if trial%25==24:
            print(json.dumps(dict(completed=trial+1,checks=checks,seconds=time.time()-start)),flush=True)
    out=dict(status='FAIL' if fails else 'PASS',inputs=trial+1,
             predecessor_checks=checks,fails=fails,seconds=time.time()-start)
    (Path(__file__).parent/'negative_accessibility_results.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(out),flush=True)

if __name__=='__main__':run()
