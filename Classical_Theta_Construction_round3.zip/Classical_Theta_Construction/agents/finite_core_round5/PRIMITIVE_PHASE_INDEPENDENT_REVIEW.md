# Independent review: primitive phases on the flagged-tree universe

Reviewed 2026-11-13, approximately 20:23–20:27 UTC.

Primary internal target: `../phase_descent_round1/PRIMITIVE_PHASE_ORBIT_THEOREM.md`. Dependency reviewed at the object-definition and involution steps: `../cyclic_transport_review/CYCLIC_FLAGGED_TREE_TRANSPORT.md`, §§4–5. Implementation read: `../phase_descent_round1/phase_orbit_matching.py`.

## Verdict

The new primitive-phase orbit construction is valid on the stated finite universe. No proof gap was found in its free action, orbit matching, equivariant lift, canonical gauge, or parameter transport. This validates only the primitive packet descent; the alternating permutation-cycle formula is still present and does not become an unsigned theta coefficient catalog by this argument.

## Checks

### Divisibility and the action

For packets $k e_i$ and $\ell e_j$, the arrow multiplicity is $k\ell|D_iB_{ij}|$. It is divisible by $d_u=kD_i$ and $d_v=\ell D_j$ because $D_iB_{ij}=-D_jB_{ji}$. For a frame–packet edge its multiplicity is $kD_i|g_i|$, again divisible by $kD_i$, while the frame degree is one. Thus every translation in the action is integral and the displayed rule is an honest product-cyclic-group action.

### Invariance of the actual universe

A signed state is an actual original-arrow spanning tree with a laminar family of connected supports. The phase action fixes vertices, supports, directions, and endpoint pairs, changing only a parallel-arrow color. Stability and fixed residual-reference tests are tests on the unique tree flow, hence on endpoint incidence and orientation. They are invariant. The arrow orders and Box transport may affect the original involution, but equivariance of that involution is neither asserted nor needed.

This point uses the actual flagged-tree universe in §§4–5 of the dependency. It would not be justified merely by saying that an abstract signed count is divisible.

### Freeness

A spanning tree contains at most one arrow on each unordered pair. Consequently a group element fixing a state must fix the color of every individual tree edge. The color congruence is equivalent to $s_u/d_u=s_v/d_v$ in $\mathbb Q/\mathbb Z$. Tree connectedness transports the zero framing fraction to every vertex, so the stabilizer is trivial. Directed cycles outside the chosen spanning tree do not affect this argument.

### Hall matching and its lift

The original involution injects all states of any collection of negative orbits into the states of their neighboring positive orbits. All orbit sizes are exactly $|G|$, so Hall's condition follows. Every graph edge is witnessed by an actual original involution pair. Given a matched pair and one witness, the equivariant lift is unique because the action is free. Different matched orbit pairs are disjoint, so the lift defines a sign-reversing involution on their union and fixes the unmatched positive orbits.

### Alternating paths

At an original positive fixed point, the new involution either fixes it or moves it to a negative state, and the original involution moves that state to a positive one. Repetition is a path in a finite degree-at-most-two two-colored graph. It cannot enter a cycle from its endpoint. It ends at a new positive fixed point, and reversal is the inverse. This establishes the transferred free action on the raw axis-flow objects, not merely a cardinality comparison.

### Canonical phase gauge

With the tree rooted at the frame and the parent phase fixed, varying the child's phase adds all multiples of $m/d_v$ modulo $m$ to the incident tree-edge color. Exactly one choice sends it into $\{0,\ldots,m/d_v-1\}$. Induction away from the frame gives a unique representative of the whole orbit. The implementation's `base` and `sign` formula agrees with both arrow orientations.

### Parameter transport and normalization

The signed universe and phase action are fixed within the framed cut chamber. Keeping one reference matching $M_*$ therefore gives bijections $A_\theta$ to one fixed free $G$-set. The maps $A_\psi^{-1}A_\theta$ are equivariant for the *transported* actions and satisfy the cocycle identity literally. This does not assert equivariance for a naive fixed-binary-tree color shift.

At a binary node the normal factors telescope; the framed root degree is one. Hence the quotient by $\prod_vd_v$ equals the previous primitive normalization. This identity identifies the already constructed catalog and is not an input to its construction.

## Boundary retained

The construction does not provide the clone-permuting Young action needed to remove the remaining signs and $z_\lambda$ denominators. Young orbits are not uniformly sized, and reference data can move. Extending the free-phase Hall argument to that situation requires a new argument.

The use of Hall's theorem and the involution principle is standard. The potentially new content is the actual free action and the orbit-incidence application to this flagged universe; historical priority is not claimed by this proof review.
