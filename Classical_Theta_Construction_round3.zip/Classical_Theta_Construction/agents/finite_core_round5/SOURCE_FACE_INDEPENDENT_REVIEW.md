# Independent source-face and associated-graded review

Reviewed 2026-11-13, 20:08–20:13 UTC. Files reviewed in full:
`../source_face_round4/SOURCE_FACE_AND_CORE_RETRACTION.md` and
`../source_face_round4/SOURCE_ASSOCIATED_GRADED.md`.

## Verdict

The source-face proof and the associated-graded proof pass the following independent algebraic checks. The finite-support equivalence is an exact reduction to an arbitrary cyclic core; it does not solve the residual finite-support recognition problem in that core.

1. **Formal mutation is used at the correct endpoint.** At a source, termwise GHKK mutation gives the transformed root charge $a'_k=t-a_k$ with $t=[-g_k]_+$. Root nonnegativity comes from the mutated theta expansion at the actual endpoint. No uncontrolled substitution of an infinite series into a rational expression, and no false claim that the mutated endpoint is entirely positive, is needed.
2. **Freezing is legitimate despite the negative $k$ endpoint.** On the zero-$k$-root slice the remaining walls have zero $k$ charge. The remaining endpoint coordinates are positive, so this slice is the ordinary core theta function with label $b=g_J+B_{Jk}t$.
3. **The carrier label has the required correction.** The one-step mutated variable is $\theta_{-e_k-B_{Jk}}=x^{-e_k-B_{Jk}}(1+z_k)$, not $\theta_{-e_k}$. This yields the exact binomial majorant without changing its leading coefficient.
4. **Iteration fixes the final core label.** The recursive source-block capacities and the final core label are determined by $g$ before the binomial majorants are multiplied. Thus the simultaneous box bound and the exact top face use one fixed core theta, not differing core labels for different slices.
5. **No leading cancellation in the associated graded.** For the basis $y^h\theta_g$, the leading indices are $(u,v,h_J,b)$ with $u=h_k+t$, $v=g_k-\sum_jB_{kj}h_j$. Their inverse is $g_k=v+B_{kJ}h_J$, $t=[-g_k]_+$, $g_J=b-B_{Jk}t$, $h_k=u-t$. This proves bijectivity and hence independence of the leading terms.
6. **The extended Rees basis is valid with negative degrees.** If a basis vector $b$ has integral filtration degree $d_b$, then $T^{d_b}b$ generates a free $\mathbb Z[T]$ summand in the extended Rees module. Negative $d_b$ do not create a relation. This does not imply finite generation of the algebra.

The result $\operatorname{gr}M_B\simeq M_C[X^{\pm1},U^{\pm1}]$ is therefore supported in the stated setting of inverted principal frozen coefficients. No stronger assertion about uninverted coefficient rings was checked or used.
