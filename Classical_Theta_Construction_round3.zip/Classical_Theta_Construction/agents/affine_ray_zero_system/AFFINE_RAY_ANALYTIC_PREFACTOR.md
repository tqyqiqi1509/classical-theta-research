# Analytic affine-ray prefactors, with an effective uniform error

2026-11-14 UTC. Classical cluster scattering, first skew-symmetric and then
integrally skew-symmetrized. No Laurent-finiteness assumption is imposed.

## Status and precise increment

The formal affine-ray identity and its local-star interpretation are already
proved in this project in
`../stable_adversarial/TRANSVERSE_RAY_THEOREM.md` and audited against prior work
in `../stable_hall_interface/NOVELTY_LOCAL_STAR.md`. They are inputs here, not
new discoveries. Local stars and sign-factor reconstruction are established
scattering constructions (Bridgeland §3; Cheung--Magee--Mandel--Muller §2.5).

The additional result proved below is convergence of the **whole analytic
series on a common complex neighborhood**, with a computable nontrivial
prefactor and an effective error uniform in the integral ray direction. It
also handles offsets growing as any fixed sublinear power of the ray length.
The proof needs both the new all-label self-germ estimate and the older exact
fixed-degree affine stabilization; bounded discrepancy alone would not
identify, or even establish convergence to, a prefactor.

## 1. Notation and analytic inputs

Let $B$ be integral, $D=\operatorname{diag}(D_i)$ positive integral, and

\[
 DB=-(DB)^T,\qquad z_i=y_ix^{Be_i},\qquad
 \vartheta_m=x^mF_m(z),\quad F_m(0)=1.
\]

Write $|a|=\sum_i a_i$ for a positive root degree. Factor the incoming
total scattering automorphism by the sign of
$\lambda_g(a)=a^TDg$:

\[
 C=A_g^-Z_gA_g^+,\qquad
 H_g=x^{-g}A_g^-(x^g),\qquad L_z(g)=\log H_g(z).
\]

All logarithms are the branch with constant term zero. There is a radius
$\rho_0>0$, depending only on $B,D,r$, on which the following two inputs
hold simultaneously.

1. **Complex label Lipschitz bound.** For real labels $u,v$,
   \[
   |L_z(u)-L_z(v)|\le K\|u-v\|_1,
   \quad \|z\|_1<\rho_0,
   \tag{1.1}
   \]
   where $K=K_{\rm path}$ is the uniform one-segment coordinate-log bound.
   Also $L_z(tu)=tL_z(u)$ for $t\ge0$. This is the complex analytic
   piecewise-linear limit in `../analytic_convex_body/ANALYTIC_STABLE_LOG_BODY.md`;
   it does not use an order or convexity on complex numbers.

2. **All-label zero-free bound.** Every $F_m$ and $H_m$, for integral $m$,
   is holomorphic and nonzero on this same ball, and
   \[
   |\log F_m(z)-L_z(m)|\le C(q(z)),\qquad
   C(q)=\log\frac{1-q}{1-2q},
   \tag{1.2}
   \]
   where $q(z)=S B_*\|z\|_1<1/2$,
   $S=\exp(rbK)$, $b=\max|B_{ij}|$. The explicit $B_*$ and a sufficient
   radius are given in
   `../ray_pressure_mechanism/UNIFORM_SELF_ENDPOINT_MAJORANT.md`.

It suffices to take any $\rho_0$ strictly smaller than both the common
one-segment path radius and $1/(2SB_*)$. Every bound below is on closed
balls strictly inside this radius. Taking a smaller radius does not depend
on $g$, $h$, or $n$.

## 2. The actual local object and the formal prefactor

The local star at $g$ is formed from the **actual supports through $g$**:

\[
 \mathfrak D_g=
 \{(W+\mathbb Rg,f,a):(W,f,a)\in\mathfrak D,\ g\in W\}.
 \tag{2.1}
\]

This is degreewise: in each finite root quotient, a sufficiently small
perturbation of $g$ crosses just the walls containing $g$. Extending
the supports along $g$ then gives the germ. Merely retaining every
hyperplane whose normal annihilates $g$ would give the wrong construction.
The total group element of this local diagram is $Z_g$.

Let $P_g=\{a\in\mathbb N^r:a^TDg=0\}$. The local theta at the original
positive endpoint direction is

\[
 \eta_h^g=x^hE_h^g(z),\qquad
 E_h^g=\sum_{a\in P_g}b_h^g(a)z^a,\quad b_h^g(0)=1.
\]

The zero-root Lie algebra may be noncommutative, and $P_g$ need not be free.
No new cluster seed is asserted. The formal prefactor is

\[
 \boxed{R_{g,h}=x^{-h}A_g^-\eta_h^g.}                 \tag{2.2}
\]

It is integral with constant term one; its coefficients need not be
nonnegative. The zero group fixes $x^{ng}$, but is not central in the
whole scattering group.

For computation, write

\[
 A_g^-(x_i)=x_i\exp U_{g,i}(z),\qquad
 W_{g,j}(z)=z_j\exp\left(\sum_iB_{ij}U_{g,i}(z)\right).
\]

Then, as a formal identity and hence as an identity of analytic germs once
convergence has been proved,

\[
 \boxed{R_{g,h}(z)=
 \exp\!\left(\sum_i h_iU_{g,i}(z)\right)
 E_h^g(W_g(z)).}                                    \tag{2.3}
\]

The local-star factor is exactly the extra information at a wall or joint.
In particular $R_{g,0}=1$, $R_{g,h+tg}=H_g^tR_{g,h}$ for integral $t$,
and if $Z_g=1$, then $R_{g,h}=\exp(h\cdot U_g)$.

The pre-existing formal affine theorem says, for every finite downward
root set $J$,

\[
 F_{ng+h}\equiv H_g^nR_{g,h}\pmod{I_J}
 \quad\text{whenever }n>T_J(g;h),                    \tag{2.4}
\]

where

\[
 T_J(g;h)=\max\left(\{0\}\cup
 \left\{\frac{|(h+Bs)^TDa|}{|g^TDa|}:
 s\in J, 0<a\le s, g^TDa\ne0\right\}\right).
 \tag{2.5}
\]

It follows from sign-factor refinement at the final exponent, not from an
assumed global straightening of all broken lines. Its proof works in the
smaller quotient $[0,s]$ for each target coefficient $s$; this point is
essential for the threshold (2.5).

## 3. A direction-independent total-degree threshold

Put

\[
 M=\max_{i,j}|D_iB_{ij}|,\qquad
 A(h)=\max_i D_i|h_i|.
\]

For $J_d=\{s:|s|\le d\}$,

\[
 \boxed{T_{J_d}(g;h)\le A(h)d+\frac M4d^2.}          \tag{3.1}
\]

Indeed, the nonzero denominator in (2.5) is an integer of absolute value
at least one. Skew-symmetry of $DB$ gives

\[
 a^TDBs=a^TDB(s-a),\qquad
 |a^TDBs|\le M|a||s-a|\le M|s|^2/4.
\]

The $h$ contribution is at most $A(h)|a|\le A(h)d$. This proves (3.1)
for every integral $g$, with no primitive or generic condition.

Let $d_n=d_n(h)$ be the largest nonnegative integer satisfying

\[
 n>A(h)d_n+Md_n^2/4.                                \tag{3.2}
\]

If $M>0$, the strict real upper endpoint is

\[
 d_*(n,h)=\frac{2(\sqrt{A(h)^2+Mn}-A(h))}{M}
         =\frac{2n}{\sqrt{A(h)^2+Mn}+A(h)},           \tag{3.3}
\]

so $d_n=\lceil d_*\rceil-1$. If $M=0<A(h)$, use

$d_n=\lceil n/A(h)\rceil-1$. If $M=A(h)=0$, stabilization holds in
every degree for every $n>0$, and the errors below are zero. A simpler
uniform but weaker choice replaces $M$ by $\max(1,M)$.

## 4. Analytic affine-ray theorem

**Theorem.** The formal series $R_{g,h}$ converges and is zero-free on

$\|z\|_1<\rho_0$, for every integral $g,h$. Fix

$0<\rho<\rho'<\rho_0$, put

\[
 t=\rho/\rho',\qquad
 A'_h=K\|h\|_1+C(SB_*\rho').
\]

Then

\[
 \boxed{
 \sup_{\|z\|_1\le\rho}
 \left|\log F_{ng+h}(z)-nL_z(g)-\log R_{g,h}(z)\right|
 \le\frac{2A'_h}{1-t}\,t^{d_n+1}.}
 \tag{4.1}
\]

Moreover $ |\log R_{g,h}(z)|\le A'_h$ on $\|z\|_1\le\rho'$.
All constants and the threshold are independent of the integral direction

$g$. For fixed $h$ and $M>0$, this implies

\[
 \boxed{F_{ng+h}(z)=H_g(z)^nR_{g,h}(z)
             \left(1+O_{h,\rho,\rho'}(e^{-c\sqrt n})\right)}
 \tag{4.2}
\]

uniformly on the smaller closed complex ball. The constant $c>0$ may be
chosen independently of $g$.

### Proof

Define $Q_n=F_{ng+h}/H_g^n$, with its normalized holomorphic logarithm.
By (1.1), (1.2), and homogeneity,

\[
 \begin{aligned}
 |\log Q_n|
 &\le |L(ng+h)-L(ng)|+|\log F_{ng+h}-L(ng+h)|\\
 &\le K\|h\|_1+C(SB_*\rho')=A'_h.
 \end{aligned}                                      \tag{4.3}
\]

Thus the logarithms, their exponentials, and their inverse exponentials
are uniformly bounded on the same complex ball. This is the step for
which a bound on real positive evaluations alone would not suffice.

By (2.4) and (3.1), the Taylor polynomials of $\log Q_n$ through total
degree $d_n$ are those of the formal $\log R_{g,h}$. For two sufficiently
large $n,m$, the difference $\log Q_n-\log Q_m$ vanishes through any
prescribed total degree $d$. For a point $z$ with $\|z\|_1\le\rho$,
restrict this holomorphic difference to the radial complex line through

$z$, using the circle where its argument has norm $\rho'$. Its
homogeneous term of degree $j$ has absolute value at most

$2A'_h t^j$, by one-variable Cauchy. Hence

\[
 |\log Q_n(z)-\log Q_m(z)|
 \le 2A'_h\sum_{j>d}t^j=\frac{2A'_h}{1-t}t^{d+1}.
 \tag{4.4}
\]

There is no count of multiindices in this estimate: it bounds each
complete homogeneous component along the chosen radial line.

Consequently $\log Q_n$ is locally uniformly Cauchy and has a holomorphic
limit whose Taylor series is exactly the already-defined $\log R_{g,h}$.
The limit satisfies the same bound (4.3). Exponentiation proves convergence
and zero-freeness of $R_{g,h}$. Sending $m\to\infty$ in (4.4), with

$d=d_n$, proves (4.1). Finally

$|e^u-1|\le e^{|u|}|u|$ converts the logarithmic bound to (4.2).
QED.

### Effective computation of the prefactor

Given desired absolute logarithmic error $\epsilon$, choose $d$ with

\[
 \frac{2A'_h}{1-t}t^{d+1}\le\epsilon,
\]

then choose any integer $n>A(h)d+Md^2/4$. The incoming finite root
recurrence computes $F_{ng+h}$ and $H_g$ through total degree $d$,
and their quotient gives the exact prefix of $R_{g,h}$. Alternatively
factor $C$ into $A_g^-Z_gA_g^+$, compute $\eta_h^g$ in the zero
monoid, and apply (2.2). The former procedure avoids constructing local
wall supports; the latter retains their actual meaning through (2.1).

This is a certified approximation of a convergent series. It is not an
algorithm that outputs a finite Laurent polynomial for every theta label.

## 5. Mesoscopic offsets

Let $h=h_n$ be integral with $\|h_n\|_1\le C_1n^\alpha$, where

$0\le\alpha<1$. Equations (3.2)--(3.3) imply

\[
 d_n\ge c_1 n^{\min(1/2,1-\alpha)}-1,
\]

with constants depending only on $B,D,C_1,\alpha$. For example, use the
denominator bound in (3.3)

$\sqrt{A^2+Mn}+A\le2A+\sqrt{Mn}$.
Since $A'_{h_n}=O(1+n^\alpha)$,

\[
 \boxed{
 \log F_{ng+h_n}-nL(g)-\log R_{g,h_n}
 =O\!\left((1+n^\alpha)
 e^{-c_2 n^{\min(1/2,1-\alpha)}}\right).}
 \tag{5.1}
\]

This compares with the varying prefactor $R_{g,h_n}$; it does not assert
that these prefactors themselves converge. The error is still relative
after exponentiation. The statement is uniform over all integral $g$
and all offsets in this window.

## 6. Finite offset corrections to coefficient statistics

Fix positive $z$ inside the common domain. Positivity of the theta
coefficients defines a probability distribution on root degrees $a$
by weights proportional to $[z^a]F_{ng+h}\,z^a$. Its logarithmic
moment-generating function is

\[
 \log\frac{F_{ng+h}(z_1e^{t_1},\ldots,z_re^{t_r})}{F_{ng+h}(z)}.
\]

On a sufficiently small complex neighborhood of $t=0$, (4.1) yields

\[
 \begin{aligned}
 &=n\bigl(L_{ze^t}(g)-L_z(g)\bigr)\\
 &\quad+\log R_{g,h}(ze^t)-\log R_{g,h}(z)
       +O(e^{-c\sqrt n}).
 \end{aligned}                                      \tag{6.1}
\]

Cauchy estimates on a slightly smaller neighborhood give the same error
for every fixed derivative order. In particular the mean root vector is

\[
 \mathbb E[a_i]
 =n\,z_i\partial_{z_i}L_z(g)
  +z_i\partial_{z_i}\log R_{g,h}(z)
  +O(e^{-c\sqrt n}),                                \tag{6.2}
\]

and the covariance entries are

\[
 \operatorname{Cov}(a_i,a_j)
 =n\,(z_i\partial_{z_i})(z_j\partial_{z_j})L_z(g)
 +(z_i\partial_{z_i})(z_j\partial_{z_j})\log R_{g,h}(z)
 +O(e^{-c\sqrt n}).                                 \tag{6.3}
\]

Thus the entire finite shift correction is explicitly supplied by the
transported local-star theta. Although $R_{g,h}(z)>0$ for these real
evaluations, its Taylor coefficients can be signed. Consequently its
logarithmic Hessian is not asserted to be positive semidefinite by itself.

For fixed offsets $h,k$, the same proof also gives

\[
 \frac{F_{ng+h}}{F_{ng+k}}
 =\frac{R_{g,h}}{R_{g,k}}(1+O(e^{-c\sqrt n})),\qquad
 \frac{F_{(n+1)g+h}}{F_{ng+h}}
 =H_g(1+O(e^{-c\sqrt n})).                           \tag{6.4}
\]

## 7. Scope and attribution

The local-star object and its positivity are not novel. Qin's freezing
translation theorem is stronger in its cluster-coordinate direction when
the starting theta is already Laurent finite: it gives eventual exact
whole-Laurent identities. The result here treats arbitrary integral
directions on a common small analytic domain, including nontrivial zero
groups, without requiring global Laurent finiteness, and quantifies both
the full tail and the offset correction.

The proof is short **after** the uniform self-germ estimate and the exact
fixed-root affine theorem; the substantive difficulty is concentrated in
those two inputs. No priority claim follows from the fact that no matching
statement has yet been found. See `NOVELTY_AND_ROUTE_LOG.md` for source
checks and computations.
