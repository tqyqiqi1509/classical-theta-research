# Full analytic localization of theta multiplication along a ray

2026-11-14 UTC. Classical integral skew-symmetrizable cluster scattering.
This combines the affine analytic prefactor theorem, inherited local-star
estimates, and the pre-existing exact finite-degree structure-constant
stabilization. It controls a complete positive weighted multiplication law,
not merely a prescribed finite prefix.

## 1. Statement

Use

\[
 \vartheta_u=x^uF_u(z),\qquad
 \vartheta_u\vartheta_v
 =\sum_{q\in\mathbb N^r}c_{u,v}(q)y^q\vartheta_{u+v+Bq},
 \quad c_{u,v}(q)\in\mathbb N. \tag{1.1}
\]

Fix offsets $h,k\in\mathbb Z^r$. For arbitrary $g\in\mathbb Z^r$ and
$n,m\ge1$, at a sufficiently small positive real point $z$, define

\[
 \boxed{\pi_{n,m}^{g;h,k}(q)=
 \frac{c_{ng+h,\,mg+k}(q)z^qF_{(n+m)g+h+k+Bq}(z)}
 {F_{ng+h}(z)F_{mg+k}(z)}.} \tag{1.2}
\]

This is a probability distribution on $\mathbb N^r$.
For the actual local star $\mathfrak D_g$, write

\[
 \eta_h^g=x^hE_h^g,\qquad
 \eta_h^g\eta_k^g
 =\sum_{q\in P_g}d_{h,k}^g(q)y^q\eta_{h+k+Bq}^g,
 \quad P_g=\{q:q^TDg=0\},\quad d_{h,k}^g(q)\in\mathbb N.
 \tag{1.3}
\]

Set $w=W_g(z)$, the analytic root-variable transport associated with
$A_g^-$. A second probability distribution is

\[
 \boxed{\pi_\infty^{g;h,k}(q)=
 \begin{cases}
 \displaystyle\frac{d_{h,k}^g(q)w^qE_{h+k+Bq}^g(w)}
 {E_h^g(w)E_k^g(w)},&q\in P_g,\\[6pt]
 0,&q\notin P_g.
 \end{cases}} \tag{1.4}
\]

**Theorem.** On a positive radius depending only on $B,D,r$, for fixed
$z,h,k$ there are $C,c>0$ such that

\[
 \boxed{\|\pi_{n,m}^{g;h,k}-\pi_\infty^{g;h,k}\|_{\rm TV}
       \le C e^{-c\sqrt{\min(n,m)}}.} \tag{1.5}
\]

The constants are independent of integral $g$ and of $n,m$. No relation
between the two growth rates is required. In particular

\[
 \boxed{\sum_{q^TDg\ne0}c_{ng+h,\,mg+k}(q)
 z^qF_{(n+m)g+h+k+Bq}(z)
 \le C e^{-c\sqrt{\min(n,m)}}F_{ng+h}(z)F_{mg+k}(z).}
 \tag{1.6}
\]

This is the entire positive weight of outputs outside the zero group.
It does not claim that all those structure constants eventually vanish
simultaneously.

## 2. Convergence and the limiting tail

All coefficients in (1.1), including the root coefficients of every
output $F$, are nonnegative. The formal identity and Tonelli's theorem
give

\[
 F_u(z)F_v(z)=\sum_qc_{u,v}(q)z^qF_{u+v+Bq}(z)<\infty. \tag{2.1}
\]

The finite value on the left follows from the common analytic theorem,
without Laurent finiteness. The same reasoning applies to the local-star
identity. Thus both distributions have total mass one.

Shrink the common radius so $2S\|z\|_1<\rho_0$, where
$\|W_g(z)\|_1\le S\|z\|_1$, $S=e^{rbK}$, and $\rho_0$ is the common
local-star zero-free radius. Coordinate transports preserve positive
points, so $w_i>0$. Positivity and the local product identity at $2w$ give

\[
 \begin{aligned}
 \sum_{|q|>d}d_{h,k}^g(q)w^qE_{h+k+Bq}^g(w)
 &\le2^{-(d+1)}\sum_qd_{h,k}^g(q)(2w)^qE_{h+k+Bq}^g(2w)\\
 &=2^{-(d+1)}E_h^g(2w)E_k^g(2w).
 \end{aligned} \tag{2.2}
\]

The denominator of (1.4) is at least one. The inherited all-label
estimate bounds $E_h^g(2w)E_k^g(2w)$ uniformly in $g$ for fixed $h,k$.
Therefore

\[
 \boxed{\sum_{|q|>d}\pi_\infty^{g;h,k}(q)
 \le C_*2^{-(d+1)}.} \tag{2.3}
\]

For example one can take
$C_*=\exp(K(\|h\|_1+\|k\|_1)+2C(\bar q))$, where
$C(q)=\log((1-q)/(1-2q))$ and
$2SB_*\|w\|_1\le\bar q<1/2$. A further common shrink of the original
radius ensures this sufficient condition. No estimate for the varying
output label $h+k+Bq$ is needed for the tail.

## 3. One cutoff for all inputs and outputs

Put

\[
 N=\min(n,m),\quad M=\max|D_iB_{ij}|,\quad M'=\max(1,M),
 \quad A(a)=\max_iD_i|a_i|,\quad
 d=\left\lfloor\frac{\sqrt N}{4\sqrt{M'}}\right\rfloor .
 \tag{3.1}
\]

For sufficiently large $N$, depending only on $B,D,h,k$,

\[
 \max\{A(h),A(k),A(h+k)\}d\le N/4. \tag{3.2}
\]

The exact finite-prefix theorem has the bound
$T_{J_d}(g;a)\le A(a)d+Md^2/4$, $J_d=\{s:|s|\le d\}$.
Since $Md^2/4\le N/64$, all three structure-stabilization hypotheses hold:

\[
 n>T_{J_d}(g;h),\quad m>T_{J_d}(g;k),\quad
 n+m>T_{J_d}(g;h+k).
\]

Consequently, for every $|q|\le d$,

\[
 c_{ng+h,\,mg+k}(q)=
 \begin{cases}d_{h,k}^g(q),&q\in P_g,\\0,&q\notin P_g.\end{cases}
 \tag{3.3}
\]

For the output offset $a_q=h+k+Bq$, skew-symmetrized entries give
$A(a_q)\le A(h+k)+M|q|$. Therefore, simultaneously for every $|q|\le d$,

\[
 A(a_q)d+Md^2/4
 \le A(h+k)d+\frac{5M}{4}d^2
 \le\frac N4+\frac{5N}{64}<n+m. \tag{3.4}
\]

Thus the affine analytic theorem applies through the **same** degree $d$
to all inputs and all low-degree output labels. Controlling only the input
thresholds would not be enough.

## 4. Relative comparison on the entire low-degree set

Choose nested radii $\|z\|_1\le\rho<\rho'<\rho_0$ and put $t=\rho/\rho'<1$.
The affine theorem states

\[
 \log F_{\nu g+\ell}-\nu L(g)-\log R_{g,\ell}
 =\epsilon_{\nu,\ell},\qquad
 |\epsilon_{\nu,\ell}|\le
 \frac{2(K\|\ell\|_1+C_0)}{1-t}t^{d+1}, \tag{4.1}
\]

whenever the degree-$d$ threshold holds; $C_0$ is the common discrepancy
bound at radius $\rho'$.

For $|q|\le d$, $\|h+k+Bq\|_1\le\|h+k\|_1+rb\,d$,
where here $b=\max|B_{ij}|$. Hence

\[
 |\epsilon_{n+m,a_q}-\epsilon_{n,h}-\epsilon_{m,k}|
 \le C_1(1+d)t^{d+1}=:\varepsilon_N, \tag{4.2}
\]

uniformly in $g$ and in this entire set of output degrees.

The prefactor formula $R_{g,a}=\exp(a\cdot U_g)E_a^g(W_g)$ gives the exact
identity

\[
 \frac{d_{h,k}^g(q)z^qR_{g,h+k+Bq}}{R_{g,h}R_{g,k}}
 =\frac{d_{h,k}^g(q)w^qE_{h+k+Bq}^g(w)}{E_h^g(w)E_k^g(w)}
 =\pi_\infty^{g;h,k}(q). \tag{4.3}
\]

The extra factor $z^q\exp((Bq)\cdot U_g)$ is exactly $W_g(z)^q$.
This explains why the limit uses the transported point.

By (3.3), (4.1), and (4.3), when $\pi_\infty(q)>0$ and $|q|\le d$,

\[
 \left|\log\frac{\pi_{n,m}(q)}{\pi_\infty(q)}\right|
 \le\varepsilon_N.
\]

When the limiting probability is zero, the actual one is zero as well
by (3.3). It follows that

\[
 \sum_{|q|\le d}|\pi_{n,m}(q)-\pi_\infty(q)|
 \le e^{\varepsilon_N}-1. \tag{4.4}
\]

No factor counting root degrees appears, because the relative error is
summed against a probability mass at most one.

## 5. Total variation and the final rate

For probability distributions $p,r$ and a subset $A$, write
$\delta_A=\sum_A|p-r|$. Then

\[
 \|p-r\|_{\rm TV}\le\delta_A+r(A^c). \tag{5.1}
\]

Indeed $p(A^c)\le r(A^c)+\delta_A$, and the complementary absolute
difference is at most $p(A^c)+r(A^c)$.

Use $A=\{|q|\le d\}$, (2.3), and (4.4):

\[
 \boxed{\|\pi_{n,m}-\pi_\infty\|_{\rm TV}
 \le e^{C_1(1+d)t^{d+1}}-1+C_*2^{-(d+1)}.} \tag{5.2}
\]

For large $N$ this is at most
$C_2(1+\sqrt N)e^{-c_2\sqrt N}$. Absorb the polynomial into a slightly
smaller exponent to obtain (1.5). Enlarge $C$ to cover bounded $N$.
The limiting support is $P_g$, so total variation bounds the actual
mass of its complement, proving (1.6). QED.

## 6. Scope

The standard local-star algebra is the limiting positive multiplication
law for large parallel theta labels, with the entire high-degree tail
included. When $Z_g=1$ the limit is the point mass at $q=0$; at a wall
or joint the full local-star multiplication survives.

The small positive seed-variable domain is essential to this proof.
This is not a global Newton-support bound, a whole-Laurent finiteness
theorem, or literal exact multiplication by one theta in arbitrary
directions. The local object is old; the quantitative whole-series
localization and its uniform error are what is proved here.
