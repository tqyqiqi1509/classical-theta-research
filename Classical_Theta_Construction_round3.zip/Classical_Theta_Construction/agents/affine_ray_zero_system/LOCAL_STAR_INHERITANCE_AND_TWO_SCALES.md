# Local-star inheritance and two-scale theta asymptotics

2026-11-14 UTC. Companion to `AFFINE_RAY_ANALYTIC_PREFACTOR.md`.
This note proves the inheritance mechanism explicitly rather than assuming
that a local star is a cluster scattering diagram for another seed.

## 1. A class closed under the operation actually needed

Begin with the positive classical cluster scattering diagram for $B,D$.
A **local descendant** is a diagram obtained by finitely many local-star
operations

\[
 (W,f,a)\longmapsto (W+\mathbb Rp,f,a),\qquad p\in W,
 \tag{1.1}
\]

retaining only walls whose actual support contains the specified point.
All operations and identifications are in finite root quotients before
passing to the inverse limit. These diagrams carry the same positive
ambient root grading $\mathbb N^r$, the same shift $q\mapsto Bq$, and
the same skew pairing $a^TDBb$. Their supported submonoids can be proper
and nonfree. The ambient rank is retained in all estimates.

The original positive endpoint direction \(Q_+\), with all coordinates
positive, lies on no positive-root hyperplane and is still a valid chamber
direction for every descendant. Define its theta family by ordinary
positive broken lines ending in that chamber. The leading coefficient is
one: selecting the constant term at every crossing gives the unique
unbent contribution, and every nonconstant selection has strictly positive
ambient root degree. The zero label has theta equal to one since no first
nonconstant bend can have a nonzero exponent. These are statements about a
positive consistent scattering diagram, not about a seed or a basis of an
upper cluster algebra.

For the first descendant the total oriented automorphism is \(Z_g\), with
the same convention \(C=A_g^-Z_gA_g^+\) as before. For further descendants,
the same sign-factor reconstruction gives successive middle factors.
One may perform extraction and sign decomposition directly in those
groups, using the inherited root grading. No free generating set for the
zero monoid, exchange matrix on a Hilbert basis, or new cluster chamber is
introduced.

**Inheritance lemma.** Every such descendant has:

1. Consistency and positive wall functions.
2. The identical coordinate wall bound
   \[
   f^{u_a^{\max}}\le_{\rm coeff}
   U_a=1+\sum_{k\ge1}\beta_{ka}z^{ka},\qquad
   \beta_b=\frac{(1+C|b|)^{|b|}}{\prod_i b_i!},
   \tag{1.2}
   \]
   for each **combined local wall germ** of primitive positive normal $a$,
   with $u_a=Da/\gcd(D_i a_i)$.
3. The same uniform constants $K,q_*,B_*$ for finite-segment analytic
   transports and the self-endpoint broken-line majorant, respectively.
   In particular every descendant has the same common zero-free radius
   $\rho_0$ for all its integral-label theta series.

### Proof of the geometric inheritance

Fix a finite root quotient. There are only finitely many relevant walls.
For a polyhedral cone $W\ni p$, a point $u\in W+\mathbb Rp$ is
equivalent to $p+\epsilon u\in W$ for all sufficiently small positive

$\epsilon$. In one direction write $u=w+tp$ and observe

$p+\epsilon u=(1+\epsilon t)p+\epsilon w\in W$. Conversely,

$p+\epsilon u\in W$ implies

$u=\epsilon^{-1}(p+\epsilon u)-\epsilon^{-1}p\in W+\mathbb Rp$.
The sufficiently small $\epsilon$ can be chosen simultaneously for the
finite collection at hand and for each crossing germ of a generic path.

Consequently a combined wall germ at $u$ in the local star is exactly a
combined wall germ at $p+\epsilon u$ in the original diagram, to the
chosen finite root order. It is not a product of unrelated wall functions
from unrelated points of a normal hyperplane. This proves (1.2) to every
finite order, and thus for the completed series. A small loop in the
local star similarly lifts to a small loop near $p$, proving consistency.
Positivity is inherited from these same local products. Induction gives
the result for every finite sequence of local stars.

### Proof that the analytic constants are unchanged

The finite-segment transport proof in
`../dyck_flow_round2/ANALYTIC_PATH_ORDERED_PRODUCTS.md` uses only (1.2),
the common matrix $B$, and the fact that a straight segment crosses a
fixed root hyperplane at most once. It does not use an incoming cluster
wall presentation. The same proof therefore gives the same $K,q_*$.

For the self-endpoint estimate, use a broken line with label $m$,
velocity $-(m+Bq)$, and endpoint germ

$\alpha m+\epsilon D^{-1}v$, $v>0$. The proof in
`../ray_pressure_mechanism/UNIFORM_SELF_ENDPOINT_MAJORANT.md` uses:

* the positive increment $q\in\mathbb N^r$;
* the slope-variation inequality
  $V_a\le M|a|d$, where $M=\max|D_iB_{ij}|$;
* the same-sign initial and final normal positions;
* the inherited coefficient bound (1.2);
* at most one broken line for each ordered packet sequence to a generic
  endpoint, followed by the ambient $\mathbb N^r$ packet count.

All five assertions remain valid. A restricted root submonoid only
removes packet sequences; no claim that all possible sequences remain
admissible is needed. Cone support restrictions are still tested in the
unique-backward-reconstruction argument. The proof therefore gives

\[
 [s^d]G^{\mathfrak E}_{m,\rm self}(sw)\le B_*^d,
 \qquad w\ge0,\quad\sum_iw_i=1,                    \tag{1.3}
\]

for every descendant $\mathfrak E$, with the very same $B_*$.

For completeness, the remaining numerical steps use only ambient lattice
arithmetic: \(u_a^{\max}\ge D_{\min}|a|/(r\delta_a)\), the total
normal exponent budget \(\sum E_j\le2M|a|d/\delta_a\), and hence the
integer ceiling budget \(\sum\lceil E_j/u_a^{\max}\rceil\le Td\).
The number of ordered vector packets of total degree \(d\) is at most
\((2r)^d\), and the positive product \(\prod_a U_a\) is bounded using
\(\sum_{b>0}\beta_bz^b\). A descendant retains a subset of the same
primitive ambient roots, so these numerical bounds have identical or
smaller left sides. These steps exhaust the quantitative inputs of the
self-germ proof.

The complex label Lipschitz bound also survives: finite-degree sign
charts glue because a change across a root hyperplane fixes \(x^m\)
when \(a^TDm=0\); their coordinate logarithms have the inherited bound
\(K\). Summable degree tails give the same global Lipschitz bound in the
label, exactly as in the original proof. The self-germ is transported
to the inherited positive chamber with these same one-segment maps.
Thus applying the affine theorem inside a descendant uses proved
analytic hypotheses, rather than an unproved assumption that its total
middle factor arose from a seed.

For the exact ray $m=kh$, a first nontrivial bend has primitive normal

$a$ with $a^TDh\ne0$. The nonzero integer has absolute value at least
one. The same variation argument gives

\[
 k\le M|a|(d-|a|)\le Md^2/4.                        \tag{1.4}
\]

Thus self-germ sparsity is inherited as well. Its analytic transport,
all-label zero-freeness, bounded log discrepancy, and ray asymptotics
follow with the same constants and domain. No coordinate system on a
Hilbert basis of the smaller monoid has been introduced. QED.

## 2. The local pressure is the directional derivative of the original one

Fix an integral $g$. Its local star has total group element $Z_g$.
Factor this element by the sign of $a^TDh$ on its root monoid:

\[
 Z_g=B_{g,h}^-Z_{g,h}B_{g,h}^+,
\]

and define its stable ray factor and log by

\[
 J^{\rm loc}_{g,h}(z)=x^{-h}B_{g,h}^-(x^h),\qquad
 L^{\rm loc}_{g,z}(h)=\log J^{\rm loc}_{g,h}(z).
\]

Let $U_g,W_g$ be the original coarse coordinate factors, as in the
affine-prefactor note. On a common sufficiently small domain, define

\[
 \mathcal J_{g,h}(z)
 =\exp(h\cdot U_g(z))J^{\rm loc}_{g,h}(W_g(z)).
 \tag{2.1}
\]

**Proposition.** The one-sided label derivative exists as a holomorphic
function of $z$, and

\[
 \boxed{D_hL_z(g):=\lim_{t\downarrow0}
 \frac{L_z(g+th)-L_z(g)}t
 =h\cdot U_g(z)+L^{\rm loc}_{g,W_g(z)}(h)
 =\log\mathcal J_{g,h}(z).}                          \tag{2.2}
\]

### Proof

In any finite root quotient, for all sufficiently small $t>0$, the
negative sign factor at $g+th$ is $A_g^-B_{g,h}^-$. The second factor
fixes $x^g$, so the formal Taylor coefficients of

$(L(g+th)-L(g))/t$ eventually equal those of the right side of (2.2).
This uses the exponential action on real labels, equivalently the
linear pairing of every root derivation with the label; no integrality
of $t$ is required in the analytic logarithm.

The complex label Lipschitz estimate bounds the whole difference
quotient by $K\|h\|_1$, independently of $t>0$. Radial Cauchy estimates,
as in the affine theorem, turn coefficient stabilization and this bound
into local uniform convergence. Thus the limit exists holomorphically
and agrees with the formal expression. The products on the right are
analytic on the domain where $\|W_g(z)\|_1<\rho_0$; the uniform bound

$\|W_g(z)\|_1\le S\|z\|_1$, $S=e^{rbK}$, supplies one such
domain independent of $g,h$. QED.

On the positive real locus $L_z$ is the support function of the analytic
convex body proved earlier. Formula (2.2) consequently identifies the
support function of its exposed face in direction $g$ with a translate
of the pressure of the genuine local-star theta family. This is the
geometric reason for the second asymptotic scale below.

## 3. The prefactor itself has a ray law

Take $z$ in a closed ball on which $W_g(z)$ stays in a strictly smaller
closed ball of the common local-star ray domain. Inheritance and (1.4)
give, uniformly in integral $g,h$,

\[
 E_{kh}^g(W_g(z))
 =J^{\rm loc}_{g,h}(W_g(z))^k
       (1+O(e^{-c\sqrt k})).                         \tag{3.1}
\]

Combining this with the exact prefactor identity gives

\[
 \boxed{R_{g,kh}(z)
   =\exp(kD_hL_z(g))(1+O(e^{-c\sqrt k})).}           \tag{3.2}
\]

In particular

\[
 \lim_{k\to\infty}\frac1k\log R_{g,kh}(z)=D_hL_z(g).
 \tag{3.3}
\]

For a fixed $h$, the finite prefactor $R_{g,h}$ cannot in general be
replaced by $\exp(D_hL(g))$. Formula (3.2) says exactly when this further
replacement becomes asymptotically valid.

## 4. Two separated label scales

Let $g,h\in\mathbb Z^r$, $n,k\ge1$. Put $a_k=A(kh)=kA(h)$, and let

$d(n,kh)$ be the largest integer satisfying

\[
 n>a_kd+Md^2/4.
\]

On a fixed sufficiently small closed complex ball, for constants

$C,c>0$ depending on $B,D,h$ and the chosen nested radii,

\[
 \boxed{
 \log F_{ng+kh}-nL(g)-kD_hL(g)
 =O\!\left(e^{-c\sqrt k}+(k+1)e^{-c d(n,kh)}\right).}
 \tag{4.1}
\]

The estimate is uniform in the integral first direction $g$. It is the
sum of the affine approximation error from the companion theorem and
the inherited local-star ray error (3.2).

For $k=\lfloor n^\alpha\rfloor$, $0<\alpha<1$, this yields

\[
 \boxed{
 F_{ng+\lfloor n^\alpha\rfloor h}
 =\exp\!\left(nL(g)+\lfloor n^\alpha\rfloor D_hL(g)\right)
 \left(1+O\!\left((1+n^\alpha)
  e^{-c n^{\min(\alpha/2,1-\alpha)}}\right)\right).}
 \tag{4.2}
\]

There is no claim of ordinary twice differentiability of $L$ across
walls. The second term is the one-sided directional derivative, which is
the support function of an exposed face and may itself be nonlinear in

$h$. The formula remains meaningful at higher-codimension joints.

## 5. A fixed residual offset and iterated true stars

One may retain a fixed integral residual label $\ell$. Form the actual
second local star $(\mathfrak D_g)_h$, taking supports containing $h$
inside the first local diagram. Let $\eta_\ell^{g,h}$ be its theta family
at the inherited positive endpoint. Its total group is $Z_{g,h}$.

Define

\[
 S_{g,h,\ell}=x^{-\ell}A_g^-B_{g,h}^-\eta_\ell^{g,h}.
 \tag{5.1}
\]

Apply the affine theorem first within $\mathfrak D_g$, and then in the
original diagram, using $kh+\ell$ as its offset. On a further uniformly
shrunk common domain,

\[
 \boxed{
 F_{ng+kh+\ell}
 =H_g^n\,\mathcal J_{g,h}^{\,k}\,S_{g,h,\ell}
   \left(1+O\!\left(e^{-c\sqrt k}
       +(k+1)e^{-c d(n,kh+\ell)}\right)\right).}
 \tag{5.2}
\]

Constants may depend on fixed $h,\ell$; the first direction $g$ remains
uniform. Both occurrences of local star in (5.1) are support-sensitive.
Merely imposing two linear orthogonality equations on all roots would
discard the essential geometry and is not this construction.

## 6. What is, and is not, being claimed

The local-star construction and coarse-to-fine sign factorization are
standard. The quantitative conclusion is that the new uniform analytic
majorant survives every true local star, making exposed-face pressure and
finite residual theta factors visible in a uniform analytic asymptotic.
No cluster realization of a zero group, generic-basis identification,
Laurent finiteness, or extension to quantum cluster algebras is used.

These are general consequences of the one inherited wall bound and the
crossing-variation mechanism. Finite examples check normalization and the
nontrivial residual factor; they are not the proof of (1.3) or (4.2).
