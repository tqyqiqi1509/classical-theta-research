# Affine rays: source comparison, routes, and calculations

2026-11-14 UTC. Classical cluster algebras only. No Li--Pan conclusion is
used. This records the mathematical routes of this delegated branch; the
parent maintains the overall nine-hour log.

## 1. The proposed formal theorem was already proved internally

Reading ../stable_adversarial/TRANSVERSE_RAY_THEOREM.md found the complete
fixed-root-cutoff identity $F_{ng+h}=H_g^nR_{g,h}$, its explicit threshold,
and the simultaneous stabilization of transverse structure constants.
The source audit in ../stable_hall_interface/NOVELTY_LOCAL_STAR.md already
identifies its zero-direction family with the standard local star.

**Decision:** do not rediscover or rename those facts. The new work below
concerns convergence of the whole analytic series and quantitative error.

## 2. Primary sources read and precise overlap

| Source | Passage checked | Decision |
|---|---|---|
| [Bridgeland 1603.00416v4](https://arxiv.org/abs/1603.00416v4) | §3.1--3.5, Lemmas 3.1--3.2 and Propositions 3.3--3.4, including proofs | Signed group factorization and reconstruction from the total transport are old. His group order must be converted to our convention. |
| [CMMM 2505.09585v2](https://arxiv.org/html/2505.09585v2) | §2.5 in full, especially Lemma 2.11 and proof | The actual local star uses supports containing the point; its limiting-chart interpretation is old. |
| [Qin 2407.03186v1](https://arxiv.org/html/2407.03186v1) | Lemma 6.15, Proposition 6.16, Proposition 6.19, including finite-support domination and half-space proof | Known finite theta functions have eventual exact freezing translation in cluster-coordinate directions. This is stronger than finite-prefix stabilization in that setting. |
| [Reading--Stella 2603.19391v4](https://arxiv.org/abs/2603.19391v4) | Primary metadata, version history, abstract; revised 8 November 2026 | Relevant mutation and structure-constant lead; no theorem imported without full proof audit. |
| [Reading--Stella 2603.23429v1](https://arxiv.org/abs/2603.23429v1) | Primary metadata and abstract | Relevant acyclic-affine imaginary-wall algebra. Not used to prove any general analytic claim. |

### Strong check on the 2026 source actually used

CMMM v2 is dated 21 May 2026, despite its 2505 identifier. Only the local-star
chart lemma is imported. Its complete proof was checked: fix a finite root
truncation, move close to the point, and cross only walls containing it.
The present argument independently proves the cone equivalence
$u\in W+\mathbb Rp$ iff $p+\epsilon u\in W$ for all sufficiently small
positive $\epsilon$. It also handles the combined local wall germs.
This elementary interface passes the check. The much larger valuative
independence and reciprocity theorems are not needed as unreviewed inputs.

Qin's source is a 2024 preprint; a 2026 journal issue does not change the
priority of its mathematical statement.

## 3. Final targeted novelty check

Before closing the branch, a further search targeted quantitative affine
rays and local-star multiplication, and checked the following primary
passages directly.

| Source | Checked interface | Comparison with the new result |
|---|---|---|
| [Fock--Goncharov, math/0311245v7](https://arxiv.org/html/math/0311245v7) | Equation (76), Conjecture 4.5, Theorem 4.6 and Lemma 4.7 | The logarithmic scaling pairing is explicitly old. These passages do not give the transported affine prefactor or a total-variation estimate for the full multiplication law. No claim of a new pressure definition is made. |
| [BLMMR, 2511.14672v1](https://arxiv.org/html/2511.14672v1) | §9.3, exact formula in Conjecture 9.2, neighboring algebraicity discussion | This is growth of rank-two wall coefficients along slopes, including a continuous directional-limit conjecture. It is a different limit from large theta labels at a fixed small positive point. Our estimates neither settle nor restate that conjecture. |
| Qin and Reading--Stella above | Rechecked scope against the full analytic multiplication claim | Freezing and special affine structure-constant descriptions do not, in the passages inspected, supply the arbitrary-direction common-domain analytic tail. Reading--Stella full proofs remain outside this branch's imported inputs. |

BLMMR's official arXiv record dates v1 to 18 November 2025, while the
current HTML body displays a 2026 date. Only the actual stated rank-two
scope and conjecture were used in this comparison; no result is promoted
on the strength of the rendering date.

Searches used both engines with combinations of cluster theta, affine
ray, local star, analytic convergence, prefactor, stabilization,
multiplication, Fock--Goncharov scaling, and BLMMR growth. Unrelated
Jacobi/partial-theta hits were discarded. No matching quantitative
affine/local-star multiplication theorem was found in the inspected
primary passages. This is bounded search evidence, not proof of priority.

## 4. Completed route A: analytic affine prefactor

The exact finite-degree identity alone supplies no analytic tail.
The new all-label zero-free bound and complex label-Lipschitz estimate give

\[
 |\log F_{ng+h}-nL(g)|\le K\|h\|_1+C(q).
\]

The formal cutoff is bounded uniformly in integral $g$:

\[
 T_d(g;h)\le A(h)d+Md^2/4.
\]

Coefficient stabilization plus the uniform complex bound makes the
normalized logarithms Cauchy on smaller complex balls, with explicit error
$2A'_ht^{d_n+1}/(1-t)$. This proves whole-series convergence to the
nonzero analytic $R_{g,h}=x^{-h}A_g^-\eta_h^g$, relative error
$e^{-c\sqrt n}$, mesoscopic offsets $O(n^\alpha)$ for $\alpha<1$, and
finite offset corrections to every fixed-order coefficient cumulant.

File: AFFINE_RAY_ANALYTIC_PREFACTOR.md.
Parent independently reviewed the complete argument and its inputs: PASS.

## 5. Completed route B: inheritance and two scales

The shortcut of treating the zero group as a cluster seed was rejected.
Instead actual local wall germs occur in the original diagram at nearby
points, degree by degree. This preserves the coordinate wall bound.
The normal-variation budget, primitive-normal ceiling, ordered-packet
count and unique backward reconstruction use only the original ambient
root grading and matrix. Hence every true iterated local star inherits
the same analytic constants.

It follows that

\[
 R_{g,kh}=\exp(kD_hL(g))(1+O(e^{-c\sqrt k})),
\]

and, for $0<\alpha<1$,

\[
 F_{ng+\lfloor n^\alpha\rfloor h}
 =\exp(nL(g)+\lfloor n^\alpha\rfloor D_hL(g))
 \left(1+O((1+n^\alpha)
 e^{-c n^{\min(\alpha/2,1-\alpha)}})\right).
\]

A fixed residual label is represented by the actual iterated local-star
theta. The second pressure is the support function of the exposed face
of the previously established analytic convex body.

File: LOCAL_STAR_INHERITANCE_AND_TWO_SCALES.md.
Parent independently reviewed support-sensitive inheritance: PASS.

## 6. Completed route C: the full positive multiplication law

Weight each structure-constant output by its positive theta value:

\[
 \pi_{n,m}(q)=
 \frac{c_{ng+h,mg+k}(q)z^qF_{(n+m)g+h+k+Bq}}
 {F_{ng+h}F_{mg+k}}.
\]

Formal positivity and Tonelli give total mass one. The limiting law is
the local-star theta multiplication evaluated at $W_g(z)$. With
$N=\min(n,m)$, choose $d=\lfloor\sqrt N/(4\sqrt{M'})\rfloor$.
The affine estimate controls all output offsets $h+k+Bq$ with $|q|\le d$
simultaneously. Local positivity at $2W_g(z)$ gives the remaining tail.

\[
 \|\pi_{n,m}-\pi_\infty\|_{\rm TV}
 \le e^{C_1(1+d)t^{d+1}}-1+C_*2^{-(d+1)}
 =O(e^{-c\sqrt N}).
\]

Thus the entire weight of outputs outside the zero group vanishes at
that rate, uniformly in integral $g$. This is stronger than a prescribed
finite-prefix statement.

File: ANALYTIC_LOCALIZATION_OF_MULTIPLICATION.md.
Parent independently read the full proof and reported PASS.

## 7. Calculation record

For arbitrary positive integer parameters $b,c$, label $h=(u,v)$, and

\[
 B=\begin{pmatrix}0&b\\-c&0\end{pmatrix},\quad
 D=\operatorname{diag}(c,b),\quad g=(-b,c),
\]

SymPy and Wolfram independently factorized the full $9\times9$ incoming
matrix through rectangle $(2,2)$ over the symbolic parameter ring. Both
obtained, with $\lambda=cu+bv$,

\[
 [z_1z_2]x^{-h}Z_gx^h=-\lambda,\qquad
 [(z_1z_2)^2]x^{-h}Z_gx^h
 =\lambda(\lambda+1-2(b-1)(c-1))/2,
\]

and checked the full factorization residual to be zero. For $\lambda<0$
these are actual local-theta coefficients, showing that the residual
factor generally cannot be dropped. No novelty claim for these rank-two
wall coefficients is made.

Files: symbolic_zero_factor_check.py; symbolic_zero_factor.wl;
symbolic_zero_factor.json.

Wolfram also verified the general strict-threshold endpoint
$2(\sqrt{A^2+Mn}-A)/M=2n/(\sqrt{A^2+Mn}+A)$.
The initial Wolfram context request failed with an internal MCP error.
Subsequent evaluator requests succeeded. One run retained a preliminary
undefined-symbol warning for its iterator J; its final factorization
residual was True/0, independently reproduced by SymPy.

The separate exact checker constructs $Z_g$ and extracts its theta
directly before comparing against large affine labels. Five skew, valued,
cyclic and noncommutative-zero-group configurations passed three affine
labels and two local-ray labels each; all 604 threshold pairs passed.

Files: check_affine_prefactors.py; affine_prefactor_exact_results.json.
These are normalization checks, not substitutes for arbitrary-rank proofs.

## 8. Limits retained

This branch does not provide arbitrary whole-Laurent support, a new seed
on a zero monoid, generic-basis identification, quantum results, or a
global extension of the small positive/complex domain. Formal local-star
ontology and fixed-prefix affine stabilization are old inputs. The new
increment is analytic realization with an explicit residual and full
quantitative multiplication localization.
