"""Exact finite-prefix checks for true zero-factor affine prefactors.

The new analytic theorem is proved separately.  This calculation checks its
normalization and identifies nontrivial local-star factors without geometry
guesses.  All arithmetic is integral and every factor comes from the same
incoming total automorphism.  No positivity of the transported R is assumed.
"""
from pathlib import Path
import sys, json, time
from fractions import Fraction

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "computation"))
from stable_root_probe import IncomingSchur, box, le, sub, mul, power
from transverse_probe import inv, threshold


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scale(k, a):
    return tuple(k * x for x in a)


def dot_D(a, b, D):
    return sum(x * y * d for x, y, d in zip(a, b, D))


def split_matrix(mat, J, left_degree):
    """Unique graded split with prescribed left/right degree Lie sets.

    This is used only for sign subalgebras, so the existence supplied by
    scattering factorization is applicable.  It is not used for arbitrary
    partitions of the root set.
    """
    cap = J[-1]
    left = {(q, q): 1 for q in J}
    right = dict(left)
    for deg in J[1:]:
        for q in J:
            p = add(q, deg)
            if not le(p, cap):
                continue
            residual = mat.get((p, q), 0) - sum(
                left.get((p, r), 0) * right.get((r, q), 0)
                for r in J if r != p and r != q and le(q, r) and le(r, p)
            )
            if residual:
                (left if left_degree(deg) else right)[p, q] = residual
    return left, right


def matrices(engine, g, label, cap):
    J = box(cap)
    C = {
        (p, q): engine.c(sub(p, q), engine.shift(label, q))
        for p in J for q in J if le(q, p)
    }
    A, nonneg = split_matrix(C, J, lambda a: dot_D(a, g, engine.D) < 0)
    Z, plus = split_matrix(nonneg, J, lambda a: dot_D(a, g, engine.D) == 0)
    # Positive and negative root support are necessary invariant checks.
    assert all(p == q or dot_D(sub(p, q), g, engine.D) < 0
               for (p, q), c in A.items() if c)
    assert all(dot_D(sub(p, q), g, engine.D) == 0
               for (p, q), c in Z.items() if c)
    return A, Z, plus


def apply(mat, vector, J):
    return {
        p: value
        for p in J
        if (value := sum(mat.get((p, q), 0) * c for q, c in vector.items()))
    }


def zero_theta(engine, g, h, cap):
    """Last-exponent extraction using only the Z_g matrix, not large n."""
    J = box(cap)
    zero = engine.zero
    A, Z, _ = matrices(engine, g, h, cap)
    eta = {zero: 1}
    for p in J[1:]:
        if dot_D(p, g, engine.D):
            continue
        final_label = engine.shift(h, p)
        I = [q for q in J if le(q, p) and dot_D(q, g, engine.D) == 0
             and (q == p or dot_D(sub(p, q), final_label, engine.D) < 0)]
        t = {p: 1}
        for q in reversed(I[:-1]):
            t[q] = -sum(t.get(r, 0) * Z.get((r, q), 0)
                        for r in I if r != q and le(q, r))
        value = -sum(t[q] * eta.get(q, 0) for q in I if q != p)
        if value:
            eta[p] = value
    return eta, apply(A, eta, J), {p: A[p, zero] for p in J if A.get((p, zero))}


def record(poly):
    return [[list(p), int(v)] for p, v in sorted(poly.items(), key=lambda x: (sum(x[0]), x[0]))]


def run():
    start = time.time()
    data = [
        ("A2_joint", [[0, 1], [-1, 0]], [1, 1], (-1, 1), (-1, 0), (4, 4)),
        ("Kronecker_joint", [[0, 2], [-2, 0]], [1, 1], (-1, 1), (-1, 0), (4, 4)),
        ("rank3_noncommuting_zero", [[0, 2, 1], [-2, 0, 1], [-1, -1, 0]],
         [1, 1, 1], (-1, 1, 0), (-1, 0, -1), (2, 2, 2)),
        ("valued_rank3_zero", [[0, 3, 1], [-2, 0, 2], [-1, -3, 0]],
         [2, 3, 2], (-3, 2, 0), (-1, 0, -1), (2, 2, 1)),
        ("cyclic_rank3_zero", [[0, 2, -1], [-2, 0, 2], [1, -2, 0]],
         [1, 1, 1], (-1, 1, 0), (-1, 0, -1), (2, 2, 1)),
    ]
    records = []
    for name, B, D, g, h, cap in data:
        engine = IncomingSchur(B, D)
        J = box(cap)
        zero = engine.zero
        A_g, Z_g, _ = matrices(engine, g, g, cap)
        H = {p: A_g[p, zero] for p in J if A_g.get((p, zero))}
        eta, Rgh, ordinary_transport = zero_theta(engine, g, h, cap)
        # This computation of R uses a genuine extracted Z_g theta and
        # therefore is independent of quotienting one chosen large label.
        n0 = max(threshold(engine, g, h, cap), threshold(engine, g, zero, cap))
        checks = []
        for n in (n0, n0 + 1, 2*n0 + 3):
            F = engine.theta_prefix(add(scale(n, g), h), cap)
            assert F == mul(power(H, n, cap), Rgh, cap), (name, n)
            quotient = mul(F, inv(power(H, n, cap), cap), cap)
            assert quotient == Rgh, (name, "quotient", n)
            checks.append(n)
        # Check the universal quadratic threshold against every actual
        # final-exponent/root pair in the finite box.
        M = max(abs(D[i]*B[i][j]) for i in range(len(g)) for j in range(len(g)))
        Ah = max(abs(D[i]*h[i]) for i in range(len(g)))
        bounds = 0
        for s in J:
            for a in box(s)[1:]:
                den = dot_D(a, g, D)
                if den:
                    actual = abs(Fraction(dot_D(a, engine.shift(h, s), D), den))
                    universal = Fraction(4*Ah*sum(s) + M*sum(s)**2, 4)
                    assert actual <= universal, (name, "threshold", s, a)
                    bounds += 1
        correction = {
            p: Rgh.get(p, 0) - ordinary_transport.get(p, 0)
            for p in J if Rgh.get(p, 0) != ordinary_transport.get(p, 0)
        }
        # Two-scale factor within the zero group: negative in the h sign.
        _, Z_h, _ = matrices(engine, g, h, cap)
        Bminus, _ = split_matrix(Z_h, J, lambda a: dot_D(a, h, D) < 0)
        local_J = {p: Bminus[p, zero] for p in J if Bminus.get((p, zero))}
        # Full first-direction transport of x^h local_J.
        A_h, _, _ = matrices(engine, g, h, cap)
        global_J = apply(A_h, local_J, J)
        k0 = max(1, threshold(engine, h, zero, cap))
        for k in (k0, k0 + 2):
            eta_k, Rgkh, _ = zero_theta(engine, g, scale(k, h), cap)
            assert eta_k == power(local_J, k, cap), (name, "local ray", k)
            assert Rgkh == power(global_J, k, cap), (name, "transported local ray", k)
        rec = {
            "name": name, "B": B, "D": D, "g": g, "h": h, "cap": cap,
            "n_checks": checks, "k_checks": [k0, k0+2],
            "threshold_pair_checks": bounds,
            "H": record(H), "local_eta": record(eta), "R": record(Rgh),
            "R_minus_plain_transport": record(correction),
            "local_J": record(local_J), "global_J": record(global_J),
            "seconds": round(time.time() - start, 3),
        }
        records.append(rec)
        print(json.dumps({"completed": name, "local_terms": len(eta),
                          "correction_terms": len(correction),
                          "elapsed": round(time.time()-start, 3)}), flush=True)
    result = {"status": "PASS", "scope": "exact finite-prefix normalization, not analytic proof",
              "cases": records, "elapsed_seconds": time.time()-start}
    (Path(__file__).parent / "affine_prefactor_exact_results.json").write_text(json.dumps(result, indent=2))
    print(json.dumps({"status": "PASS", "cases": len(records),
                      "threshold_pairs": sum(r["threshold_pair_checks"] for r in records),
                      "elapsed_seconds": time.time()-start}), flush=True)


if __name__ == "__main__":
    run()
