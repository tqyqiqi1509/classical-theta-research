"""General-parameter symbolic check, independently repeated in Wolfram.

B=[[0,b],[-c,0]], D=(c,b), b,c positive integers.
The coarse direction is g=(-b,c); zero roots have equal coordinates.
No numerical exchange entries or label values are specialized.
"""
from pathlib import Path
import json
import sympy as s
from check_affine_prefactors import box, le, sub, split_matrix

b, c, u, v = s.symbols("b c u v")
J = box((2, 2))


def binomial_polynomial(a, k):
    return s.prod(a-j for j in range(k))/s.factorial(k)


def incoming(a, label):
    return s.expand(binomial_polynomial(-label[0], a[0]) *
                    binomial_polynomial(-label[1]+c*a[0], a[1]))


C = {
    (p, q): incoming(sub(p, q), (u+b*q[1], v-c*q[0]))
    for p in J for q in J if le(q, p)
}
A, nonnegative = split_matrix(C, J, lambda a: a[0] > a[1])
Z, P = split_matrix(nonnegative, J, lambda a: a[0] == a[1])
zero = (0, 0)
lam = c*u+b*v
expected = {
    (1, 1): -lam,
    (2, 2): lam*(lam-2*b*c+2*b+2*c-1)/2,
}
for p, value in expected.items():
    assert s.expand(Z[p, zero]-value) == 0
for p in J:
    for q in J:
        if le(q, p):
            product = sum(A.get((p, a), 0)*Z.get((a, b0), 0)*P.get((b0, q), 0)
                          for a in J for b0 in J)
            assert s.expand(C.get((p, q), 0)-product) == 0

out = {
    "status": "PASS",
    "parameters": "b,c positive integers; u,v arbitrary integral labels",
    "matrix": "B=[[0,b],[-c,0]], D=(c,b), g=(-b,c)",
    "cutoff": [2, 2],
    "lambda": str(lam),
    "Z_coefficients": {str(p): str(s.factor(Z[p, zero])) for p in expected},
    "full_9_by_9_factorization_residual": 0,
    "Wolfram_independent_output": [
        "-(c*u)-b*v",
        "((c*u+b*v)*(-1+2*b+2*c-2*b*c+c*u+b*v))/2",
        True,
        0,
    ],
    "Wolfram_warning": "Symbol::undefined2 warning for J before evaluation; final symbolic matrix residual was True/0",
}
Path(__file__).with_name("symbolic_zero_factor.json").write_text(json.dumps(out, indent=2))
print(json.dumps(out, indent=2))
