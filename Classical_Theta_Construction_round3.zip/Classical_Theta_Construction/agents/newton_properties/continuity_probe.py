import sys,json,random,time
from fractions import Fraction as Q
from itertools import product
from pathlib import Path
import sympy as sp
OLD=Path('/workspace/scratch/0e6dfa966050/theta_20261114/history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents')
sys.path.insert(0,str(OLD))
from polyhedral_parameter_formula import FrozenChamber
from incoming_recursion import box,le,sub

def run(B,cap,D=None,count=20):
    n=len(B);D=D or [1]*n
    g=sp.symbols('g0:'+str(n)); J=box(cap); rng=random.Random(7123)
    hyper=[]
    for s in J:
        for q in J:
            if s==q or not le(q,s):continue
            v=tuple(D[i]*(s[i]-q[i]) for i in range(n))
            c=sum(v[i]*sum(B[i][j]*s[j] for j in range(n)) for i in range(n))
            hyper.append((v,c))
    hyper=list(dict.fromkeys(hyper))
    result=[]
    for it in range(count):
        v,c=rng.choice(hyper);r=next(i for i,x in enumerate(v) if x)
        gp=[Q(rng.randint(-100,100),rng.choice([7,11,13])) for i in range(n)]
        gp[r]=(-c-sum(v[i]*gp[i] for i in range(n) if i!=r))/v[r]
        eps=Q(1,100000)
        for w,b in hyper:
            val=b+sum(w[i]*gp[i] for i in range(n))
            if val and w[r]:eps=min(eps,abs(val)/(2*abs(w[r])))
        plus=gp.copy();minus=gp.copy();plus[r]+=eps;minus[r]-=eps
        Fs=[FrozenChamber(B,g,B,h,D).theta_prefix(cap) for h in [plus,minus,gp]]
        expr=(-c-sum(v[i]*g[i] for i in range(n) if i!=r))/sp.Integer(v[r])
        fails=[]
        for p in J:
            vals=[sp.factor(f[p].subs(g[r],expr)) for f in Fs]
            # If simultaneous distinct boundary hyperplanes occur, evaluate point too.
            numerical=[sp.factor(z.subs(dict(zip(g,gp)))) for z in vals]
            if len(set(numerical))>1:
                fails.append({'p':p,'values':list(map(str,numerical)),
                              'polynomials':list(map(str,[f[p] for f in Fs]))})
        row={'B':B,'D':D,'cap':cap,'hyperplane':[v,c],'sample':list(map(str,gp)),'failures':fails}
        result.append(row)
        print(json.dumps({'trial':it,'n':n,'failures':len(fails)}),flush=True)
        if fails: break
    return result

if __name__=='__main__':
    begin=time.time();results=[]
    for B,cap,D,count in [
        ([[0,2],[-2,0]],(3,2),None,25),
        ([[0,3],[-2,0]],(3,2),[2,3],25),
        ([[0,2,-2],[-2,0,2],[2,-2,0]],(2,1,1),None,25),
        ([[0,2,1],[-1,0,1],[-1,-2,0]],(2,1,1),[1,2,1],25),
    ]:
        results+=run(B,cap,D,count)
        if any(x['failures'] for x in results):break
    out={'seconds':time.time()-begin,'results':results}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
    print(json.dumps({'trials':len(results),'failures':sum(bool(x['failures']) for x in results),'seconds':out['seconds']}))
