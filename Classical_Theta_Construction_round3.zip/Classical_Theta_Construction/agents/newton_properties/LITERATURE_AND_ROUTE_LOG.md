# Newton / parameter branch: literature and route log

Date: 2026-11-14, Asia/Shanghai.

## Primary sources inspected

1. Cheung--Magee--Mandel--Muller, *Valuative independence and cluster theta
   reciprocity*, arXiv:2505.09585v2, 21 May 2026.
   <https://arxiv.org/html/2505.09585v2>
   Sections 3.5, 3.8 and 3.9 were read. Theorem 3.15 already gives
   monicity at Newton vertices; Corollaries 3.17--3.18 already give
   tropical atomicity in their stated settings. These are not new results
   of the present project. No Li--Pan result referenced in that paper is
   imported. The complete 56-page chain was not re-proved by this branch.

2. Reading--Stella, *Mutation of Theta Functions*, SIGMA 22 (2026), 109,
   arXiv:2603.19391v4, 8 November 2026.
   <https://arxiv.org/html/2603.19391v4>
   <https://sigma-journal.com/2026/109/>
   The primary record, publication version, Theorems 5.4, 5.6, 5.7 and
   pointed reduced basis discussion were inspected. Their setting includes
   a small canonical algebra for arbitrary exchange matrices. It does
   not automatically provide Laurent finiteness of every label. The
   dominance-region restriction is useful prior art for multiplication
   constraints. No unreviewed theorem from this 2026 paper is used in
   the new algebraic arguments.

3. Mandel, *Theta bases are atomic*, Compositio Math. 153 (2017),
   1217--1219; arXiv:1605.03202v2.
   <https://arxiv.org/abs/1605.03202>
   The theorem uses the scattering atlas. It must not be turned into
   minimality among all bases positive only in ordinary cluster charts.
   This confirms the previous run's caution; no new atomicity claim is
   made here.

4. Qin, *An introduction to representation-theoretic canonical bases of
   cluster algebras*, arXiv:2508.12761v2.
   <https://arxiv.org/html/2508.12761v2>
   Sections 2.4--2.5 were inspected for injective reachability and Newton
   comparisons. The Newton equality for theta versus other pointed bases
   is presented as a conjectural interface, not a usable theorem.

5. Fei, *Combinatorics of F-polynomials*, arXiv:1909.10151v3.
   <https://arxiv.org/html/1909.10151v3>
   Stabilization/face methods and the stated rigid acyclic saturation
   scope were inspected. These do not identify arbitrary theta interior
   coefficients from the Newton polytope.

6. Fei, *Tropical F-polynomials and General Presentations*,
   arXiv:1911.10513v6.
   <https://arxiv.org/html/1911.10513v6>
   Generic Newton methods provide relevant representation-theoretic
   background. No generic-basis-equals-theta assertion is imported.

## Routes

* Newton-vertex monicity / tropical uniqueness: useful but already known;
  not pursued as a new theorem.
* General face theta reduction: plausible, but a direct statement would
  still require controlled degeneration of scattering data and risks
  duplicating the existing extension theorem. No theorem claimed.
* Fixed-degree label polynomiality: initially considered, then recognized
  as already proved in the previous package. Not repackaged as new.
* Boundary gluing of those polynomials: the previous package explicitly
  left it open. The finite zero-Lie-character and final-row-annihilation
  argument now supplies a general proof for independent review.
* Stable large-ray series: independently checked the root agent's
  proposed common-negative-factor mechanism. The proof, integrality by
  consecutive quotients, eventual no-low-degree multiplication
  corrections, and wall-recovery identity are in
  STABLE_RAY_AND_WALL_RECOVERY.md.
* Universal large-label leading terms: checked by two proofs and written
  in LARGE_LABEL_ASYMPTOTICS.md. Exchange data enters only lower powers
  of the scaling variable at each fixed root coefficient.
* Linear improvement of the coarse stability threshold: the generic
  cancellation argument in LARGE_LABEL_ASYMPTOTICS.md shows that a mere
  norm estimate cannot improve its quadratic root-cutoff dependence.
  The true optimal correction rate remains open.

## Exact computation

continuity_probe.py used the previous run's FrozenChamber implementation
to compare exact rational boundary values from both incident sign
chambers with the strict boundary value. One hundred tests passed. The
root agent subsequently ran independent symbolic crossing and stable-ray
checks, so this branch did not repeat larger computational sweeps.

Searches for existing joint continuous coefficient gluing, formal stable
ray roots, and coefficientwise asymptotic multiplicativity did not locate
an exact matching statement in the inspected primary literature. This is
not a proof of novelty. The parent novelty branch is conducting a broader
comparison and should control any priority claim.

All new proofs here are supplied for independent review, not marked as
having passed an external verifier.
