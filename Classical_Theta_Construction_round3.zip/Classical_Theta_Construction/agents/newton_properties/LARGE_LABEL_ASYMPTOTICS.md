# Large-label coefficient asymptotics

Date: 2026-11-14, Asia/Shanghai.

Status: proofs supplied for independent review. The coefficient statement
has a proof from the stable-ray theorem alone. The arbitrary-two-label
structure-constant statement below uses continuous joint parameter
gluing as well. No external audit is claimed.

## 1. Universal leading term

Fix classical skew-symmetrizable B,D, an integral label g and a root
degree p. Set N=|p|. Then, through positive integers n,

    n^{-N} a_{ng}^B(p)
       -> product_i [-g_i]_+^{p_i}/product_i p_i!.    (1.1)

Equivalently, coefficientwise as formal power series,

    F_{ng}^B(z/n)
       -> exp(sum_i [-g_i]_+ z_i).                  (1.2)

Each fixed coefficient has error O(1/n). This is a formal coefficientwise
limit and does not assert analytic convergence in a common open domain.

### Proof from the stable series

Let L_g=log H_g. The stable-ray theorem gives, in every prescribed finite
root set J and for every n>T_J,

    F_{ng}=exp(n L_g) mod I_J.

Since L_g has no constant term, the coefficient at p is exactly

    a_{ng}^B(p)
       =sum_{k=0}^{N} n^k/k! [z^p]L_g^k.           (1.3)

The one-variable restriction to color i is the isolated-vertex formula
(1+z_i)^{[-ng_i]_+}. Consequently

    [z_i]L_g=[-g_i]_+.

To contribute to [z^p]L_g^N, all N factors must have root degree one.
The multinomial theorem gives

    [z^p]L_g^N=N! product_i[-g_i]_+^{p_i}/p!.

This proves (1.1), the O(1/n) remainder, and (1.2). In particular the
exchange matrix only affects lower powers of n in the eventual
polynomial (1.3).

The leading term may vanish. This does not mean that the coefficient is
eventually zero; it may have strictly smaller polynomial degree. For
example a positive component of g can receive contributions propagated
from negative components by nontrivial exchange data.

## 2. Homogeneous-component argument

The joint parameter arrangement of the previous coefficient formula is
central in (B,g). Its branch polynomials have degree <=N. Continuous
gluing on a conical boundary implies continuous gluing of each
homogeneous component separately: restrict the boundary identity to all
positive dilates of a point and compare powers of the dilation variable.
Write these global continuous homogeneous functions as f_d, 0<=d<=N.

Then exactly

    a_{ng}^B(p)=sum_{d=0}^N n^d f_d(B/n,g).          (2.1)

A finite continuous piecewise-polynomial function is locally bounded
and locally Lipschitz. Taking n to infinity gives f_N(0,g). At B=0 the
coefficient is product_i binom([-g_i]_+,p_i), whose top homogeneous term
is the right-hand side of (1.1).

This provides a separate route to the same coefficient asymptotic and
extends without change to multiplication coefficients.

## 3. Structure constants for two arbitrary labels

Fix integral g,h and write

    theta_{ng}theta_{nh}
       =sum_{p>=0} c^B_{ng,nh}(p)y^p
                              theta_{n(g+h)+Bp}.

Put

    delta_i=[-g_i]_+ +[-h_i]_+ -[-g_i-h_i]_+.

Every delta_i is nonnegative. Then

    n^{-|p|} c^B_{ng,nh}(p)
         -> product_i delta_i^{p_i}/p_i!,           (3.1)

again with coefficientwise O(1/n) error. Thus the generating series for
the structure degrees, evaluated at z/n, tends coefficientwise to
exp(sum_i delta_i z_i).

To prove this, use the continuous homogeneous-component argument of
Section 2 for the joint variables (B,g,h). The degree bound and
continuous gluing for structure coefficients follow from their finite
unitriangular convolution recurrence. At B=0,

    theta_g=x^g product_i(1+y_i)^{[-g_i]_+},

so the structure coefficient is exactly

    c^0_{g,h}(p)=product_i binom(delta_i,p_i).

Its top homogeneous part yields (3.1).

For h=g, every delta_i=0. The stable-ray theorem is much stronger than
this vanishing leading asymptotic: for each nonzero p, the entire
coefficient c^B_{mg,ng}(p) is exactly zero once m,n exceed its explicit
finite-prefix threshold.

## 4. Exact eventual polynomial and a usable threshold

For fixed B,g,p the old sign tests have the form

    n g^tD(s-q)+(Bs)^tD(s-q).

The finitely many nonzero slopes stabilize for

    n>max |(Bs)^tD(s-q)|/|g^tD(s-q)|,

over nonzero denominators and all 0<=q<s<=p. Zero slopes remain
constant. Therefore eventual polynomiality is exact, with the same
explicit threshold used by the stable-ray proof. Equation (1.3) further
identifies the whole eventual polynomial through one fixed formal
logarithm, rather than independently interpolating each coefficient.

## 5. Limitation of the coarse threshold

The elementary threshold cannot in general be bounded linearly in the
root cutoff merely from a<=s. Suppose a_0>=0 satisfies g^tDa_0=0 and
b>=0 satisfies Omega_B(b,a_0)!=0. Choose d>=0 with g^tDd!=0. Set

    a=k a_0+d,     s=a+k b.

The denominator |g^tDa| is constant while the numerator
|(Bs)^tDa| is quadratic in k. For example, with

    D=I, B=[[0,1],[-1,0]], g=(1,-1),
    a=(k,k+1), s=(k,2k+1),

the ratio is k^2 although |s|=3k+1. This is a limitation of the sufficient
sign-stability bound, not evidence that actual multiplication corrections
must occur at square-root degree. Improving the true correction bound
requires using which terms actually contribute, beyond a norm estimate.
