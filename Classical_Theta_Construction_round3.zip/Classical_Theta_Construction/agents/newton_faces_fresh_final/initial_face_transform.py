"""Exact optimized-path transform from a lower theta polytope to a full face.

Input JSON: B, g, w, sequence (ZERO-BASED), lower_vertices.
Optional lower_terms: [{"exponent": [...], "coefficient": positive_integer}, ...].
The lower vertices/terms must describe the theta for final B[J,J], m[J].
This program does not discover that lower theta from its label.

Dependency: SymPy; its rational simplex solver is used for exact feasibility.
No floating-point polyhedral decision is made. See the companion theorem.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from math import gcd, lcm
import json
import sys

from sympy import Integer, Poly, cancel, prod, symbols
from sympy.solvers.simplex import InfeasibleLPError, linprog


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scale(c, a):
    return tuple(c * x for x in a)


def symmetrizer(B):
    n = len(B)
    if not n or any(len(r) != n for r in B):
        raise ValueError("B must be a nonempty square matrix")
    if any(not isinstance(x, int) for r in B for x in r):
        raise ValueError("B must be integral")
    if any(B[i][i] != 0 for i in range(n)):
        raise ValueError("B must have zero diagonal")
    d = [None] * n
    for start in range(n):
        if d[start] is not None:
            continue
        d[start] = Fraction(1)
        todo = [start]
        while todo:
            i = todo.pop()
            for j in range(n):
                a, b = B[i][j], B[j][i]
                if not a and not b:
                    continue
                if a * b >= 0:
                    raise ValueError("B is not sign-skew-symmetric")
                value = -d[i] * Fraction(a, b)
                if d[j] is None:
                    d[j] = value
                    todo.append(j)
                elif d[j] != value:
                    raise ValueError("B is not skew-symmetrizable")
    multiple = lcm(*(v.denominator for v in d))
    result = [int(v * multiple) for v in d]
    common = gcd(*result)
    return [v // common for v in result]


def mutate_matrix(E, k):
    return [
        [
            -E[i][j]
            if i == k or j == k
            else E[i][j]
            + max(E[i][k], 0) * max(E[k][j], 0)
            - max(-E[i][k], 0) * max(-E[k][j], 0)
            for j in range(len(E[0]))
        ]
        for i in range(len(E))
    ]


def build_certificate(B, g, w, sequence):
    n = len(B)
    D = symmetrizer(B)
    if len(g) != n or len(w) != n:
        raise ValueError("g and w must have length n")
    if any(not isinstance(x, int) for x in [*g, *w, *sequence]):
        raise ValueError("g, w and mutation indices must be integral")
    E = [list(r) for r in B] + [list(int(i == j) for j in range(n)) for i in range(n)]
    m, u = list(g) + [0] * n, [0] * n + [-v for v in w]
    beta = [-v for v in w]
    steps = []
    for k in sequence:
        if not 0 <= k < n:
            raise ValueError("mutation indices are zero-based and must lie in range(n)")
        steps.append({"k": k, "beta": beta[k], "m": m[k], "row": list(E[k])})
        ap = sum(u[i] * max(E[i][k], 0) for i in range(2 * n))
        am = sum(u[i] * max(-E[i][k], 0) for i in range(2 * n))
        new_u = list(u)
        new_u[k] = min(ap, am) - u[k]
        new_m = [
            -m[k] if i == k else m[i] + max(E[i][k], 0) * m[k] - E[i][k] * min(m[k], 0)
            for i in range(2 * n)
        ]
        new_beta = [
            -beta[k]
            if j == k
            else beta[j] + max(E[k][j], 0) * beta[k] - E[k][j] * min(beta[k], 0)
            for j in range(n)
        ]
        E = mutate_matrix(E, k)
        m, u, beta = new_m, new_u, new_beta
        if beta != [sum(E[i][j] * u[i] for i in range(2 * n)) for j in range(n)]:
            raise ArithmeticError("full-coordinate and root valuation updates disagree")
    if any(v < 0 for v in beta):
        raise ValueError(f"The supplied endpoint is not optimized: beta={beta}")
    J = [j for j in range(n) if beta[j] == 0]
    return {
        "n": n, "B": B, "g": g, "w": w, "sequence": sequence, "symmetrizer": D,
        "steps": steps, "final_extended_matrix": E, "final_label": m,
        "final_valuation": u, "final_root_valuation": beta, "J": J,
        "lower_B": [[E[i][j] for j in J] for i in J], "lower_g": [m[j] for j in J],
        "face_height": -dot(u, m),
    }


def normalize_rows(rows):
    out = set()
    for row in rows:
        row = tuple(row)
        common = gcd(*row)
        if common:
            out.add(tuple(a // common for a in row))
    return tuple(sorted(out))


@lru_cache(maxsize=None)
def strict_witness(n, rows):
    """Return exact v with row.v >= 1 for every nonzero row, or None.

    Such v exists iff the homogeneous cone row.v>=0 has nonempty interior.
    Free coordinates v are represented as differences of nonnegative variables.
    """
    if not rows:
        return tuple(0 for _ in range(n))
    A = [[-a for a in row] + list(row) for row in rows]
    try:
        _, solution = linprog([0] * (2 * n), A, [-1] * len(rows))
    except InfeasibleLPError:
        return None
    v = tuple(solution[i] - solution[i + n] for i in range(n))
    if any(dot(row, v) < 1 for row in rows):
        raise ArithmeticError("exact simplex returned an invalid witness")
    return v


@dataclass(frozen=True)
class Cell:
    roots: tuple
    prefactor: tuple
    inequalities: tuple


def linear_cells(cert):
    n = cert["n"]
    zero = (0,) * n
    roots = tuple(tuple(int(i == j) for j in range(n)) for i in range(n))
    cells = [Cell(roots, zero, ())]
    for step in cert["steps"]:
        k, beta, m, row = (step[key] for key in ("k", "beta", "m", "row"))
        next_cells = []
        for cell in cells:
            lk = cell.roots[k]
            if beta > 0:
                choices = [(zero, cell.inequalities)]
            elif beta < 0:
                choices = [(lk, cell.inequalities)]
            else:
                choices = [
                    (zero, normalize_rows((*cell.inequalities, scale(-1, lk)))),
                    (lk, normalize_rows((*cell.inequalities, lk))),
                ]
            for eta, inequalities in choices:
                if strict_witness(n, inequalities) is None:
                    continue
                new_roots = tuple(
                    scale(-1, lk)
                    if j == k
                    else add(cell.roots[j], add(scale(max(row[j], 0), lk), scale(-row[j], eta)))
                    for j in range(n)
                )
                prefactor = add(cell.prefactor, add(scale(max(m, 0), lk), scale(-m, eta)))
                next_cells.append(Cell(new_roots, prefactor, inequalities))
        cells = next_cells
    return cells


def support_value(cert, direction, lower_vertices):
    lam, pi = list(direction), 0
    for step in cert["steps"]:
        k, beta, m, row = (step[key] for key in ("k", "beta", "m", "row"))
        old = lam[k]
        eta = 0 if beta > 0 else old if beta < 0 else max(0, old)
        pi += max(m, 0) * old - m * eta
        lam = [-old if j == k else lam[j] + max(row[j], 0) * old - row[j] * eta for j in range(cert["n"])]
    return pi + max(dot(q, [lam[j] for j in cert["J"]]) for q in lower_vertices)


def face_vertices(cert, lower_vertices):
    n, J = cert["n"], cert["J"]
    vertices = sorted(set(tuple(q) for q in lower_vertices))
    if not vertices or any(len(q) != len(J) for q in vertices):
        raise ValueError("lower_vertices must be nonempty, with exponent length len(J)")
    if any(not isinstance(a, int) or a < 0 for q in vertices for a in q):
        raise ValueError("lower theta vertices must be nonnegative integral root exponents")
    cells = linear_cells(cert)
    retained = {}
    for cell in cells:
        image = {
            q: tuple(sum(q[t] * cell.roots[j][i] for t, j in enumerate(J)) for i in range(n))
            for q in vertices
        }
        for q in vertices:
            constraints = normalize_rows((*cell.inequalities, *(add(image[q], scale(-1, image[r])) for r in vertices if r != q)))
            witness = strict_witness(n, constraints)
            if witness is None:
                continue
            p = add(cell.prefactor, image[q])
            if dot(cert["w"], p) != cert["face_height"]:
                raise ArithmeticError("candidate vertex has incorrect face height; check lower input")
            if any(a < 0 for a in p):
                raise ArithmeticError("negative original root exponent; check lower input")
            retained[p] = witness
    return {
        "vertices": [list(p) for p in sorted(retained)],
        "exposing_directions": {str(p): [str(a) for a in retained[p]] for p in sorted(retained)},
        "tropical_cells": len(cells),
        "exact_solver": "sympy.solvers.simplex.linprog over exact rational numbers",
    }


def rational_circuit(cert, lower_terms=None):
    n = cert["n"]
    z = symbols(f"z0:{n}")
    roots, prefactor = list(z), Integer(1)
    for step in cert["steps"]:
        k, beta, m, row = (step[key] for key in ("k", "beta", "m", "row"))
        old = roots[k]
        H = Integer(1) if beta > 0 else old if beta < 0 else 1 + old
        prefactor = cancel(prefactor * old ** max(m, 0) * H ** (-m))
        roots = [cancel(1 / old if j == k else roots[j] * old ** max(row[j], 0) * H ** (-row[j])) for j in range(n)]
    result = {"variables": [str(a) for a in z], "prefactor": str(prefactor), "roots": [str(a) for a in roots]}
    if lower_terms is not None:
        for term in lower_terms:
            if len(term["exponent"]) != len(cert["J"]) or term["coefficient"] <= 0:
                raise ValueError("invalid lower_terms")
        f = cancel(prefactor * sum(term["coefficient"] * prod(roots[j] ** term["exponent"][t] for t, j in enumerate(cert["J"])) for term in lower_terms))
        polynomial = Poly(f, *z)
        if any(c <= 0 or not c.is_Integer for _, c in polynomial.terms()):
            raise ArithmeticError("result is not a positive integral face polynomial; check lower input")
        result["face_polynomial"] = str(polynomial.as_expr())
        result["face_terms"] = [{"exponent": list(p), "coefficient": int(c)} for p, c in polynomial.terms()]
    return result


def main():
    with open(sys.argv[1]) if len(sys.argv) > 1 else sys.stdin as stream:
        data = json.load(stream)
    cert = build_certificate(data["B"], data["g"], data["w"], data["sequence"])
    result = {"certificate": cert, "face": face_vertices(cert, data["lower_vertices"])}
    if data.get("include_circuit") or "lower_terms" in data:
        result["circuit"] = rational_circuit(cert, data.get("lower_terms"))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
