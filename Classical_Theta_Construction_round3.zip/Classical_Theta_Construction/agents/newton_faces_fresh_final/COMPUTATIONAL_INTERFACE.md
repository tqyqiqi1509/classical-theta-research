# Exact Newton-face interface

`initial_face_transform.py` implements Sections 4--6 of
`TIED_INITIAL_MUTATION_FACE_THEOREM.md`.

## Inputs

The JSON object has keys:

- `B`: square integral skew-symmetrizable matrix, in the tall/column-root
  convention of the theorem.
- `g`: initial theta leading exponent, length n.
- `w`: maximizing root-degree face normal, length n.
- `sequence`: the supplied mutation directions, **zero-based**.
- `lower_vertices`: the vertices of the final lower-rank theta Newton
  polytope, in the retained-index order `J` returned by the certificate.
  For rank zero use `[[]]`.
- Optional `lower_terms`: a list of objects with `exponent` and positive
  integer `coefficient`, describing that same lower theta polynomial.
- Optional `include_circuit`: true to return the explicit positive
  rational root coordinates and prefactor.

The program checks skew-symmetrizability, tracks full frozen labels,
checks agreement of full-coordinate and root valuation mutation, and
rejects a non-optimized supplied endpoint. It does not determine the
lower theta from its label. Its exact final lower matrix and label are
included in the result so that the supplied lower-polytope input can be
identified unambiguously.

## Invocation and output

Run with Python and a JSON input filename, or send JSON on standard input:

```text
python initial_face_transform.py input.json
```

The output includes the final seed, full label and valuation, retained
set J, lower matrix/label, face height, all original face vertices, and
exact rational exposing directions. With `lower_terms`, it additionally
returns every coefficient of the face polynomial after exact rational
denominator cancellation.

The only nonstandard dependency is **SymPy**. The polyhedral routine uses
`sympy.solvers.simplex.linprog` over exact integers/rationals. A cone has
nonempty interior precisely when its finitely many nonzero homogeneous
inequalities can all be scaled to `row.v >= 1`; the code solves that
feasibility problem exactly and verifies each returned witness exactly.
No floating-point hull or feasibility decision is used.

The algorithm is finite, but may be exponential in the number of tied
mutations. No complexity improvement is claimed.

## Verification already completed

The two Wolfram receipts check general symbolic root/prefactor
involution in all three valuation branches, the matrix/root exponent
identity, the full-label correction in all sign quadrants, and strict/tied
initial multiplicativity. They do not specialize the exchange entry to a
particular numerical matrix.

`verify_interface.py` additionally computes theta cluster variables by
direct exchange relations, normalizes their full initial leading labels,
and compares their exposed polynomial and vertices with the new circuit.
One input is skew-symmetric; the other has symmetrizer `(1,2,3)`. Both
paths include a tied exchange followed by a strict exchange. The exact
checks passed, as recorded in `interface_verification.json`.

No empirical support assertion is used in the theorem. The verification
only checks implementation of the already proved formulas.
