# Theta faces along arbitrary optimized mutation paths

2026-11-14. Classical parameter q=1. Arbitrary skew-symmetrizable integral
exchange matrices, hence in particular arbitrary skew-symmetric matrices.
This note removes the strict-exchange hypothesis from
`../positive_shear_fresh_review/CERTIFIED_THETA_FACE_REDUCTION.md`.
It gives an exact positive rational formula, and an exact finite transform of
the lower-rank Newton polytope. It does not turn a tied mutation into an
affine polytope map.

**Subsequent strengthening.** `BONGARTZ_MONOMIAL_FACE_THEOREM.md` absorbs
the tied mutations into changes of the lower-rank seed using Bongartz
completion. In that normalized lower seed, the final face is a single
nonnegative monomial substitution and its Newton polytope is one integral
affine image. The present interface remains useful when the lower
polytope is supplied specifically in the original optimized endpoint seed.

## 1. Statement and inputs

Use tall extended matrices and column roots. Put

    E_0=[B;I_n],  X_0=(x_1,...,x_n,y_1,...,y_n),
    z_j=X_0^(E_0 e_j)=y_j x^(B e_j),
    theta_g=X_0^m F_g^B(z),  m=(g,0).

Assume theta_g is finite in the initial cluster chart. GHKK v2,
Proposition 7.1 and Definition 7.2, imply that it is finite in every cluster
chart. Let w in Z^n be a requested maximizing normal for F_g. Start with
the additive MINIMUM valuation

    u_0=(0,-w),   beta_0=E_0^T u_0=-w.

Supply any finite mutation sequence k_1,...,k_s. Update the full extended
matrix and the full coordinate valuation in the usual way. If the current
exchange is

    X'_k=(M_++M_-)/X_k,
    M_+=product_i X_i^[E_ik]_+,
    M_-=product_i X_i^[-E_ik]_+,

write alpha_+=u(M_+), alpha_-=u(M_-), alpha=min(alpha_+,alpha_-), and set

    u'_k=alpha-u_k,    u'_i=u_i for i!=k.

No inequality alpha_+ != alpha_- is required. The only endpoint condition
is

    beta_s=E_s^T u_s >= 0 coordinatewise.                 (1.1)

Let J={j:beta_s,j=0}. Freeze the final mutable vertices outside J and let
theta^J_(m_s) be the theta function of that ice seed, retaining every frozen
variable and the full leading exponent m_s. Then

    in_(u_0)(theta_g)=Phi_1^* ... Phi_s^*(theta^J_(m_s)), (1.2)

where Phi_t is the explicitly defined initial mutation of Section 2.
Every Phi_t is either an integral monomial field isomorphism or the full
positive binomial mutation. Thus (1.2) is a single lower-rank theta under
a positive birational pullback.

If w!=0, then J is a proper subset: this is genuine rank reduction. The
endpoint assumption is exactly the known GHKK optimized-seed condition;
the theorem does not assert that every normal admits such an endpoint.

## 2. One mutation: initial forms commute, including ties

Work first over Q(X_1,...,X_N) with any integer coordinate weight u. For
nonzero rational f=A/B, define

    val_u(f)=val_u(A)-val_u(B),
    in_u(f)=in_u(A)/in_u(B).

The polynomial initial forms use minimum u-weight. These definitions are
independent of the chosen fraction. They agree with the lowest nonzero
coefficient and exponent of f(t^u X) in Q(X)((t)).

For the exchange above, define

    Phi^*(X'_i)=X_i                          (i!=k),
    Phi^*(X'_k)=M_+/X_k                     (alpha_+<alpha_-),
                  M_-/X_k                   (alpha_-<alpha_+),
                  (M_++M_-)/X_k             (alpha_+=alpha_-). (2.1)

The first two possibilities are unimodular monomial maps: their exponent
matrix fixes all columns except k and has k-th diagonal entry -1. The
third is a birational involution, with inverse

    X_k=(M_++M_-)/X'_k,

because neither exchange monomial uses X_k and reversing the exchange
interchanges M_+ and M_-. All three maps are isomorphisms of rational
function fields. They are homogeneous from weight u' to weight u.

**Initial-form lemma.** For every nonzero rational function f in the new
chart,

    val_u(mu^*f)=val_(u')(f),
    in_u(mu^*f)=Phi^*(in_(u')(f)).                      (2.2)

**Proof.** Normalize the exchange by t:

    t^(-u'_k) mu^*(X'_k)(t^u X)
      =(t^(alpha_+-alpha)M_+ + t^(alpha_--alpha)M_-)/X_k.

Its t=0 value is (2.1); the other normalized coordinates are just X_i.
For a Laurent polynomial f, collect all terms of its minimum u'-weight
into a nonzero Laurent polynomial f_min. Substitution gives lowest
candidate coefficient Phi^*(f_min). It is nonzero because Phi^* is a
field isomorphism. Terms of greater u'-weight occur at higher t-order.
This proves both equalities for Laurent polynomials. Apply numerator and
denominator separately to prove the rational case. QED.

This argument does not require positive coefficients in f. Positivity
will matter later when tropicalizing an unexpanded rational expression.
The key point at a tie is injectivity of the complete binomial field map,
not linear independence of its individual monomial expansions.

Consequently every step of an arbitrary mutation chain transports
initial forms exactly. One need not move tied mutations to the end, or
prove a separate path-reordering theorem.

## 3. The optimized endpoint and freezing

Mutation covariance gives the current theta label by the standard
full-lattice tropical update

    m'_k=-m_k,
    m'_i=m_i+[E_ik]_+ m_k-E_ik min(m_k,0)       (i!=k). (3.1)

This includes frozen coordinates. In the final chart,

    theta_(m_s)=X_s^(m_s) sum_(p>=0) a_p z_s^p,
    z_s,j=X_s^(E_s e_j).

Under (1.1), the minimum valuation is u_s.m_s, since a_0=1. A term has
that valuation exactly when p_j=0 for every j outside J. The established
zero-root-degree freezing identity identifies this subseries with
theta^J_(m_s). Finiteness follows by taking a subset of the finite final
Laurent support. Iterating (2.2) proves (1.2).

There is also a root-only update, needing no full coordinate valuations:

    beta'_k=-beta_k,
    beta'_j=beta_j+[B_kj]_+ beta_k-B_kj min(beta_k,0) (j!=k). (3.2)

It is the ordinary invertible tropical Y-mutation. In particular
beta_s=0 implies beta_0=0. Thus w!=0 and beta_s>=0 force at least one
strictly positive beta_s,j, proving |J|<n.

The support value itself is already known before the lower-rank theta is
computed:

    max_(p in Supp F_g) w.p = -u_s.m_s.                 (3.3)

This is the familiar optimized valuation calculation, now accompanied by
the full initial-form identity.

## 4. Explicit formula using only independent root variables

For a current step, put beta=beta_k and a=m_k. Define

                  1          if beta>0,
    H_beta(r)=    r          if beta<0,
                  1+r        if beta=0.               (4.1)

The sign convention follows alpha_+-alpha_-=beta. Starting with

    R_j=z_j,   P=1,

apply the following updates, always using the OLD R_k, old B, and old m:

    P'   =P R_k^[a]_+ H_beta(R_k)^(-a),
    R'_k =R_k^(-1),
    R'_j =R_j R_k^[B_kj]_+ H_beta(R_k)^(-B_kj)  (j!=k). (4.2)

In parallel update E, m by (3.1), and beta by (3.2). All R_j and P are
positive rational functions with integer exponents. Denote the final
ones by R_s,j and P_s. Then the exact F-polynomial face formula is

    F_g^B |_max(w)
       =P_s(z) F^(B_s,JJ)_(m_s,J)((R_s,j(z))_(j in J)). (4.3)

Here the lower-rank F-polynomial uses principal roots for the matrix
B_s,JJ; substituting R_s,j reinstates the frozen coefficient monomials
of the final ice seed. The full frozen powers were already accounted for
in P_s through (3.1). No specializations of original principal coefficients
are made.

**Derivation of (4.2).** The full exchange can be written

    X'_k=X^(-e_k+[-E_k]_+)(1+z_k).

Matrix mutation gives

    mu^*(z'_k)=z_k^(-1),
    mu^*(z'_j)=z_j z_k^[B_kj]_+ (1+z_k)^(-B_kj).

Using (3.1) in the full Laurent lattice gives the leading-monomial
identity

    mu^*(X'^(m'))/X^m=z_k^[m_k]_+(1+z_k)^(-m_k).       (4.4)

Replacing 1+z_k by its initial form (4.1) yields (4.2). The calculation
of (4.4) reduces, in each row i!=k, to

    [E_ik]_+ m_k-E_ik min(m_k,0)-[-E_ik]_+ m_k
       = E_ik [m_k]_+.

This also shows why using a different sign for the prefactor would be
incorrect. The root formula uses a ROW B_kj; the label formula uses a
COLUMN E_ik.

Formula (4.3) is an equality of rational functions whose left side is a
positive ordinary polynomial. Therefore its right side simplifies to
that same polynomial. Intermediate P or R_j need not be Laurent
polynomials. Individual lower-theta monomials need not map to single
monomials. No coefficient-by-coefficient affine transport is asserted.

If the lower-rank F-polynomial is supplied explicitly, (4.3) computes the
entire face polynomial by finite exact rational operations, followed by
exact denominator cancellation. It includes every original face
coefficient, not merely its vertices.

## 5. The full Newton face from the lower-rank polytope alone

Let Q=Newt(F^(B_s,JJ)_(m_s,J)). For a positive rational expression A(z)
define its logarithmic slope

    ell_A(v)=lim_(t->+infinity) log A(exp(t v))/t.       (5.1)

For the circuits here the limit always exists and is finite. It is
integral piecewise linear, but may fail to be convex. It satisfies

    ell_(AB)=ell_A+ell_B,
    ell_(A/B)=ell_A-ell_B,
    ell_(A+B)=max(ell_A,ell_B).                         (5.2)

The addition formula uses positivity. For a positive Laurent polynomial,
ell_A is its usual maximizing Newton support function. Do NOT interpret
each intermediate rational ell_A as a Newton-polytope support function.

Write pi(v)=ell_(P_s)(v) and lambda_j(v)=ell_(R_s,j)(v). Tropicalizing
(4.3), with positivity of the lower-rank theta, proves

    h_(Face_w Newt(F_g))(v)
        =pi(v)+h_Q((lambda_j(v))_(j in J)).             (5.3)

The right side is convex because it equals the support function of the
face polynomial. Neither summand separately needs to be convex.

There is no need to construct the rational expressions to evaluate
(5.3). Initialize pi=0 and lambda_j(v)=v_j. At each mutation set

                  0                if beta_k>0,
    eta(v)=       lambda_k(v)      if beta_k<0,
                  max(0,lambda_k(v)) if beta_k=0,

then update

    pi'=pi+[m_k]_+ lambda_k-m_k eta,
    lambda'_k=-lambda_k,
    lambda'_j=lambda_j+[B_kj]_+lambda_k-B_kj eta (j!=k). (5.4)

Thus a finite mutation certificate and the finite polytope Q determine
the complete original face. In particular its geometry does not require
the lower theta's coefficients.

## 6. Finite exact vertex reconstruction

Here is a precise finite procedure, avoiding an unsupported claim that
the original face is a single affine image of Q.

1. Carry all lambda_j and pi as integral linear forms on polyhedral cones
   in v-space. Start with the whole R^n. Only a tied step splits a cone:
   split along lambda_k=0, retain its full-dimensional subregions, and
   use the corresponding branch of max in (5.4). There are finitely many
   resulting cones C; at most 2^(number of tied steps) before removing
   empty or redundant regions.
2. On each C write pi=a_C.v and lambda_j=A_C,j.v. The full root matrix
   with columns A_C,j lies in GL_n(Z), since each chosen branch is an
   elementary integral monomial mutation. Write A_C,J for its retained
   columns.
3. For each vertex q of Q, test whether

       C intersect (A_C,J^T)^(-1)(N_Q(q))

   has full dimension n. Here N_Q(q) is the maximizing normal cone of Q.
   This is an exact finite rational polyhedral feasibility/dimension
   calculation. Retain

       a_C+A_C,J q                                      (6.1)

   exactly when the intersection has full dimension.
4. Remove duplicate points. The retained points are precisely the
   vertices of Face_w Newt(F_g); take their convex hull if desired.

**Proof.** On every full-dimensional refined cone, (5.3) is the linear
form with gradient (6.1). Since (5.3) is a convex support function, that
gradient is an exposed vertex. Conversely every vertex has a normal cone
with nonempty interior in R^n, also when the polytope is lower-dimensional.
Its interior meets a full-dimensional cell of the finite refinement,
recovering the vertex as (6.1). The retained root columns are independent,
so distinct vertices q do not have accidentally identical gradients
within one fixed C. QED.

Taking every point of every affine image a_C+A_C,J Q without its normal
cone test is unjustified and can enlarge the result. This is why the
normal-cone condition is part of the algorithm.

For a strict path there is only one cone C, so (5.3)--(6.1) collapse to the
previous integral affine formula. For tied paths the finite collection of
linear pieces and their normal domains is the correct replacement.

## 7. Exact scope of computability

This is a rank-reducing transform of the full face problem. Its inputs
are B,g,w, the finite optimized path, and a finite description of the
lower-rank F-polynomial (for coefficients) or its Newton polytope (for
geometry). It does not by itself provide an algorithm that discovers the
support of every finite lower-rank theta from its label alone. That is
the separate support-stopping issue identified in the previous slice
work. In rank zero the lower polynomial is 1; in any rank where a full
lower-theta solver is already available, the transform is an actual
terminating full-face algorithm.

This distinction does not weaken (4.3) or (5.3): both are exact identities
for arbitrary finite theta labels under the sole given-path endpoint
condition (1.1). No lower-rank coefficients, Newton polytope, or support
bound is used to certify the path, compute P_s,R_s, determine J, or
calculate the face height (3.3).

## 8. Skew-symmetrizable data

All formulas above use the usual integral exchange rules. The identities
in Sections 2, 4, and 5 do not use B_ij=-B_ji; they use only B_kk=0 and
ordinary matrix mutation. The symmetrizer is therefore needed for the
underlying theta/scattering construction and its freezing theorem, but
does not alter any exponent, sign test, prefactor, or polyhedral step.
The restricted mutable matrix B_s,JJ is symmetrized by D_J.

## 9. Established machinery and the concrete increment

- Fomin--Zelevinsky, *Cluster algebras IV: Coefficients*, arXiv:math/0602259,
  Definition 2.4 and formula (2.3): ordinary birational and tropical
  Y-mutation. The positive-rational tropical rules are standard semifield
  algebra, not a new result.
- GHKK, *Canonical bases for cluster algebras*, arXiv:1411.1394v2,
  Proposition 7.1/Definition 7.2: finiteness transports between cluster
  charts; Definition 9.1/Lemma 9.3: the optimized endpoint; Proposition
  9.7: the existing optimized valuation mechanism.
- Root-degree freezing of theta functions is an established input,
  reviewed in the companion project notes. No claim of novelty for
  freezing itself is made.
- CMMM, *Valuative independence and cluster theta reciprocity*,
  arXiv:2505.09585v2, Theorem 3.8 and Theorem 3.15: already established
  valuative independence and vertex monicity. Neither theorem is needed
  to justify the new tied-path formula; neither is claimed anew.

The concrete increment over the previous strict-path interface is:
retain every tied initial mutation; prove exact transport by the
birational initial-form lemma; derive the root-prefactor circuit (4.3);
and combine it with lower-rank freezing to obtain the complete face
support function and finite vertex transform (5.3)--(6.1).

## 10. Fei's actual November 2026 statement

Primary text: Jiarui Fei, *On the Orthogonal Projections*,
https://arxiv.org/html/2510.01615v4, dated 3 November 2026, Section 8.3.
Corollary 8.11 concerns representation F-polynomials and a rigid
presentation whose weight is the face normal. Its final genericity
assertion additionally assumes the positive completion is
extended-reachable. Remark 8.13 permits general faces. Question 8.14
asks for the corresponding theta-F-polynomial conclusion.

The present result has a directly checkable optimized-path hypothesis
and a positive rational change of variables. Fei's desired conclusion
uses a monomial change of variables and a projected QP. No identification
between these hypotheses or between these coordinate changes has been
proved here. Thus (4.3) supplies a general theta mechanism for optimized
normals and removes the previously artificial strict-path condition; it
does not settle Question 8.14 as stated.

The actual v4 Example 8.12 records an obstruction to extending its
generic representation statement to a tame non-real normal. That example
does not obstruct the present rational formulation, and is not imported
as a theta counterexample.

Primary links actually consulted:

- https://arxiv.org/pdf/1411.1394v2
- https://arxiv.org/html/2510.01615v4
- https://arxiv.org/html/2505.09585v2
- https://arxiv.org/pdf/math/0602259

The literature comparison with Reading--Stella's 8 November 2026 paper
and Bossinger's initial exchange forms is recorded separately.
