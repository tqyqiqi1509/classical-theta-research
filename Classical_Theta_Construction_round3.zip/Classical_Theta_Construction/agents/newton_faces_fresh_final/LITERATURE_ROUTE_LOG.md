# Newton-face route and primary-source comparison

## 2026-11-14 00:40--01:00 UTC

**Route.** Read the previous strict certificate, formal shear/slice note,
and CMMM finite-span audit in full. The strict certificate was located at
`../positive_shear_fresh_review/CERTIFIED_THETA_FACE_REDUCTION.md`, not the
initially named support-accessibility directory. The principal gap was
not a loss of initial-form functoriality: a tied initial exchange is
itself a homogeneous birational field isomorphism. This closes arbitrary
interspersed ties without reordering the mutation path.

**Result.** `TIED_INITIAL_MUTATION_FACE_THEOREM.md` gives the complete
positive rational root circuit and its finite piecewise-linear Newton
face transform. The root separately reviewed Sections 1--6 and reported
PASS. `initial_face_transform.py` implements exact rational feasibility;
`interface_verification.json` records two endpoint checks against direct
exchange-expanded theta functions, including a genuinely
skew-symmetrizable input. These are implementation checks, not substitutes
for the general proof.

### Useful, actual primary passages read

| Primary source | Version and passage actually read | Use and boundary |
|---|---|---|
| [GHKK, Canonical bases for cluster algebras](https://arxiv.org/pdf/1411.1394v2) | v2; Proposition 7.1 and its proof, Definition 7.2, Definition 9.1, Lemma 9.3, Proposition 9.7 | Finiteness is chart-independent; nonnegative final root valuations are exactly the established optimized-seed mechanism. This is old input. |
| [Fei, On the Orthogonal Projections](https://arxiv.org/html/2510.01615v4) | v4, 3 Nov 2026; all of Section 8.3, plus the definition of extended-reachability and Theorem 8.8 statement | Actual Corollary 8.11 concerns representation F-polynomials, with additional extended-reachability for its genericity assertion. Question 8.14 asks the theta analogue. Extended-reachability permits global tau shifts, so it is not automatically an ordinary mutation optimized certificate. |
| [Reading--Stella, Mutation of Theta Functions](https://sigma-journal.com/2026/109/) | SIGMA 22 (2026),109, published 8 Nov; [arXiv v4](https://arxiv.org/html/2603.19391v4). Section 4 equations (4.1)--(4.6), Theorem 4.2, Propositions 4.4--4.5, Lemma 4.9 and its mutation proof; Theorem 5.14 and Remark 5.15 | Confirms the ordinary rational root mutation and full theta mutation as prior machinery. Their wide-matrix convention is the transpose of ours. The small canonical algebra and pointed reduced-basis theorem do not furnish the missing arbitrary finite support bound. No valuation-face/freezing theorem is asserted in the passages read. |
| [Fomin--Zelevinsky, Cluster algebras IV: Coefficients](https://arxiv.org/pdf/math/0602259) | Definition 2.4, formula (2.3), ordinary semifield setup | Root rational mutation and tropical evaluation are old. Our circuit uses these formulas after keeping the entire tied initial exchange. |
| [CMMM, Valuative independence and cluster theta reciprocity](https://arxiv.org/html/2505.09585v2) | v2, 21 May 2026; Section 2.5 and Lemma 2.11; previously reviewed finite chain in `notes/CMMM_FINITE_SPAN_AUDIT.md` | Local-star limits already exist. Theorem 3.8 valuative independence and Theorem 3.15 vertex monicity are prior results, not new. The present field-level proof does not need either. |
| [Bossinger, Tropical totally positive cluster varieties](https://arxiv.org/abs/2208.01723) | v2 PDF, Lemma 3.17 and nearby proof | Initial exchange relations with g-vector weighting matrices already give toric binomial degenerations. This does not supply the present tied rational theta-face/freezing formula. |

### Useful comparison, but not used as a theorem

Fei's Section 8.3 has a monomial-coordinate conclusion for the projected
representation F-polynomial. Our normal-cone construction uses rational
coordinates at ties, so it does not settle that stated monomial theta
question. The actual v4 Example 8.12 obstructs an extension to tame
non-real representation normals, not this rational theta statement.

Reading--Stella explicitly compares its mutation notion with GHKK:
its positive chamber is fixed while the matrix and skew form change.
Its formulas involve frozen monomial renormalization; our use of full
leading exponents retains that correction directly. Therefore neither
the full theta covariance nor the root prefactor derived from ordinary
covariance should be advertised as an independent new mutation theorem.
The concrete increment is the combined initial-face reduction and
explicit complete-polytope transform.

### Found but not adopted

- The search hit *Finite quantum theta functions for skew-symmetrizable
  seeds*, identifier **hexagon:2610.00201**, is a Hexagon manuscript, not
  arXiv:2610.00201. The surfaced version labels itself primarily
  AI-generated, with no claimed human understanding. Its claims are not
  used; full proof not read.
- Fei's 12 November Hexagon manuscript *Laurent Phenomenon Algebras on
  Minuscule Grassmannians and their Mirrors* was found through its primary
  deposit, but its LP/mirror comparison is not needed for this general
  ordinary cluster mutation argument. Full proof not read in this cycle.
- Newton--Okounkov and cluster toric-degeneration papers surfaced by the
  broad search concern a different polytope or require stronger finite
  generation hypotheses. No conclusion from them is imported.

### What has and has not closed

The extra **strict exchange** condition is fully removed. A supplied
optimized path now determines a rank-smaller theta expression for the
complete face, including all ties. A supplied lower-rank polytope gives a
terminating exact algorithm for all vertices of that face. The existence
of optimized endpoints for every normal, a monomial-coordinate version
matching Fei's full question, and a support-stopping algorithm for every
finite theta label are not established by this route.

The next useful question is whether a stronger residue-atlas or mutation
fan argument can identify a monomial-coordinate reduced theta for these
optimized normals. This is additional work; the proved rational formula
does not depend on a positive answer.

## 2026-11-14 01:00--01:24 UTC

**Route change and result.** The monomial strengthening has now closed
for the same GIVEN optimized-normal class. The relevant general mechanism
is ordinary cluster Bongartz completion, applied to the **-B coefficient
pattern**, paired by tropical duality with G-matrices for **B^T**. In a
reverse ambient step with beta_k=0, positivity on the fixed partial
cluster and row sign coherence force a unique retained column C_j=e_k.
That identifies the exact lower mutation that absorbs the binomial.
The symmetrizer identity d_j=d_k makes its theta prefactor match, provided
the lower label uses the actual face exponent A_mut, not the original g.

`BONGARTZ_MONOMIAL_FACE_THEOREM.md` gives the full proof, and root
independently recomputed the decisive weighted label identity. A second
independent reviewer is checking the theorem and its canonical extension.
`normalize_bongartz_face.py` is a working integer-arithmetic interface
using only the Python standard library. It returns a single affine root
map and its normalized lower seed. On the two already independently
expanded inputs, the full polynomial and vertex images equal the direct
exchange result. No new case catalogue was used as a replacement for
the general argument.

**Further general consequence.** Bongartz uniqueness makes S and the
lower exchange matrix depend only on the minimal dual g-vector cone
containing beta_0=-w, up to the usual seed permutation. The face's unique
coordinatewise least exponent p makes the translation path-independent;
h=D_red^(-1) S^T D(g+Bp) is then path-independent as well. The data are
constant on the relative interior of that dual cluster cone. This is
written in `CANONICAL_FACE_MODEL_ON_DUAL_CLUSTER_CONES.md`. S is a
nonnegative Z-basis for the cone's orthogonal integer lattice; it is
not asserted to generate the whole nonnegative lattice monoid.

### Newly useful primary sources, actually read

| Primary source | Exact passages | Contribution and boundary |
|---|---|---|
| [Nakanishi--Zelevinsky](https://arxiv.org/pdf/1101.3736v3) | Theorem 1.2 (1.11)--(1.13), Propositions 1.3--1.4, Proposition 4.2 and its proof | Supplies C=G^(-T) with the required transpose/sign and the initial-seed change rule. Its historical sign-coherence hypothesis is supplied by GHKK. |
| [Cao--Gyoda--Yurikusa](https://arxiv.org/pdf/2106.11668v2) | Final v2 of 13 Dec 2022: Theorems 3.17--3.20, Definition 4.9, beginning of Section 4.2 on opposite seeds, Lemmas 4.13--4.14 and proofs, Theorem 4.15 and proof | Defines nonnegative complementary C-columns and proves unique Bongartz completion; transpose/opposite correspondence makes the partial cluster unambiguous. Final theorem is 4.15, although older citations call it 4.14. |
| [Fu--Geng--Liu](https://arxiv.org/pdf/2207.05555) | Theorem 2.1, Proposition 2.2, Definition 3.6, Lemmas 3.8--3.10 with full proofs | The adjacent-initial-seed completion step, including at most one retained pivot, is already established. The contribution here is its exact theta-face/root/label compatibility. The stronger non-leaving-face theorem is not needed as an extra input. |
| [Cao--Li](https://arxiv.org/pdf/1803.05281v2) | Definitions 4.4--4.5, Proposition 4.6, Theorem 4.8 and scattering-diagram proof, Theorem 5.5 and uniqueness proof | Original enough g-pairs existence and uniqueness, for arbitrary skew-symmetrizable principal coefficients. CGY's published-reference numbers 8 and 9 correspond to these arXiv numbers. No Li--Pan result enters. |
| [GHKK](https://arxiv.org/pdf/1411.1394v2) | Additional reading: Theorem 2.13, Corollary 5.9, Theorem 5.11, Lemma 5.12 | Genuine simplicial g-fan, chamber generators, and row sign coherence support the canonical-cone statement. These fan/valuation facts are old. |

### Still outside the proved scope

An optimized endpoint for an arbitrary normal is not asserted. The
algorithm needs a lower theta polynomial/polytope in its returned lower
seed, or the earlier rational interface needs it in the original
optimized endpoint seed. Neither interface is an arbitrary theta
support-stopping algorithm. Fei's extended-reachable representation
class, including tau shifts, is not identified with this ordinary dual
cluster-fan normal class. The earlier entry's statement that the
monomial strengthening was open is now superseded within this optimized
class; the unrestricted representation-to-theta question remains
separate.

Root is inspecting Cao arXiv:2602.07929v2 for a possible prior Newton/
Bongartz face theorem. This subagent has not read that full paper and
does not treat it as independent evidence. Root's preliminary report
identifies its main theorem as recognition of non-initial cluster
monomials by Newton polytopes, with no theta or face statement in the
full-text search. Final attribution should follow root's direct reading.

## 2026-11-14 01:24--01:36 UTC: closed interfaces and handoff

The canonical theorem was independently reviewed by
`generic_q_fresh_attack`; its proof check is recorded in
`../generic_q_fresh_attack/BONGARTZ_FACE_INDEPENDENT_PROOF_CHECK.md`.
The root also independently checked the complete monomial and canonical
arguments. The corrected convention is beta_0=-w in the B^T g-fan.
The canonical lower weights and matrix can be read from the embedding:

    D_red,jj=gcd_i(d_i S_ij),
    Q_red=D_red^(-1) S^T D B S.

The integer normalizer now also outputs `canonical_sequence`,
`canonical_B`, and `canonical_full_label`. It actually appends all
recorded retained pivots, recomputes the matrix and full ordinary theta
label, and checks that the retained label/matrix match its reduced
output. The resulting endpoint is canonical; the certificate word can
depend on the input word. Its length is at most twice the input length.

**Nested reductions closed.** `ITERATED_FACE_COMPATIBILITY.md` proves,
for compatible partial clusters U subset V, that the secondary lower
normal is S_U^T w_V and is itself an optimized lower normal. The data
satisfy

    S_V=S_U S_(V/U),
    p_V=p_U+S_U p_(V/U),
    Q_V=Q_(V/U),  h_V=h_(V/U),

with equality of the complete face polynomial, including coefficients.
The new primary input actually read for this step is CGY Lemma 4.17,
Theorem 4.18 with its full proof, and Theorem 5.4 with its full proof.
Their nonnegative coefficient-block specialization and Bongartz
commutativity are old. The theta-face substitution and weighted label
compatibility are the additional interface. The root reports a complete
independent review of this nested theorem, including the C-block
factorization, dual G-projection, and translated D-label calculation.

The subtask is complete at the root's request. No unrestricted normal
existence theorem, universal theta support stopping criterion, or
identification with Fei's full extended-reachable representation class
has been added. Those scope boundaries remain as stated above.
