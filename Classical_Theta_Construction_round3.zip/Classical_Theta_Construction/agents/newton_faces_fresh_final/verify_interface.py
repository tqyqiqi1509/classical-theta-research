"""Two end-to-end checks against independently expanded cluster variables.

This verifies the computational interface, not the general theorem. The
general symbolic mutation checks are in the Wolfram receipts.
"""
import itertools
import json
from pathlib import Path

from sympy import Integer, Poly, cancel, prod, symbols

from initial_face_transform import (
    build_certificate, dot, face_vertices, mutate_matrix, normalize_rows,
    rational_circuit, strict_witness,
)


def run_case(B):
    n = len(B)
    # Locate a short path with a tie followed by a strict step.
    # Start from beta_final=(1,0,0), so the endpoint is certified by design.
    for path in itertools.product(range(n), repeat=4):
        if any(path[t] == path[t+1] for t in range(3)):
            continue
        E = [list(r) for r in B] + [[int(i == j) for j in range(n)] for i in range(n)]
        history = [E]
        for k in path:
            E = mutate_matrix(E, k)
            history.append(E)
        beta = [1, 0, 0]
        signs = []
        for t in reversed(range(len(path))):
            k, E = path[t], history[t+1]
            b = beta[k]
            signs.append(-b)
            beta = [-b if j == k else beta[j]+max(E[k][j],0)*b-E[k][j]*min(b,0) for j in range(n)]
        signs.reverse()
        if any(signs[i] == 0 and signs[j] != 0 for i in range(3) for j in range(i+1,4)):
            break
    z = symbols(f"z0:{n}")
    X, E = [Integer(1)] * n + list(z), history[0]

    def exchanged(k):
        return cancel((prod(X[i] ** max(E[i][k],0) for i in range(2*n))
                       + prod(X[i] ** max(-E[i][k],0) for i in range(2*n))) / X[k])

    for k in path:
        X[k] = exchanged(k)
        E = mutate_matrix(E, k)
    # A cluster variable adjacent to the final chart in a retained direction.
    # Its reduced theta has exactly F=1+z_j, so no theta coefficient oracle is used.
    j = 1
    actual = exchanged(j)
    m = [-1 if i == j else max(-E[i][j], 0) for i in range(2*n)]
    for t in reversed(range(len(path))):
        k, E = path[t], history[t+1]
        a = m[k]
        m = [-a if i == k else m[i]+max(E[i][k],0)*a-E[i][k]*min(a,0) for i in range(2*n)]
    actual_F = cancel(actual * prod(z[i] ** (-m[n+i]) for i in range(n)))
    w = [-a for a in beta]
    cert = build_certificate(B, m[:n], w, list(path))
    J = cert["J"]
    q = [0] * len(J)
    q[J.index(j)] = 1
    lower_vertices = [[0]*len(J), q]
    terms = [{"exponent": p, "coefficient": 1} for p in lower_vertices]
    transformed = rational_circuit(cert, terms)
    actual_poly = Poly(actual_F, *z)
    height = max(dot(p, w) for p, c in actual_poly.terms())
    face_terms = [(p,c) for p,c in actual_poly.terms() if dot(p,w) == height]
    actual_face = sum(c*prod(z[i]**p[i] for i in range(n)) for p,c in face_terms)
    actual_support = [p for p,c in face_terms]
    actual_vertices = sorted(p for p in actual_support if strict_witness(n, normalize_rows(tuple(a-b for a,b in zip(p,q)) for q in actual_support if q != p)) is not None)
    computed = face_vertices(cert, lower_vertices)
    polynomial_equal = cancel(actual_face - Poly(transformed["face_polynomial"],*z).as_expr()) == 0
    polytope_equal = actual_vertices == [tuple(p) for p in computed["vertices"]]
    assert polynomial_equal and polytope_equal
    return {
        "B":B, "D":cert["symmetrizer"], "path":path, "g":m[:n], "w":w,
        "step_root_valuations":signs, "J":J, "lower_B":cert["lower_B"], "lower_g":cert["lower_g"],
        "actual_F":str(actual_F), "actual_face":str(actual_face),
        "computed_face":transformed["face_polynomial"], "polynomial_equal":polynomial_equal,
        "actual_vertices":actual_vertices, "computed_vertices":computed["vertices"],
        "polytope_equal":polytope_equal, "tropical_cells":computed["tropical_cells"],
    }


if __name__ == "__main__":
    cases = [
        [[0,2,-1],[-2,0,1],[1,-1,0]],
        [[0,2,-3],[-1,0,3],[1,-2,0]],
    ]
    result = [run_case(B) for B in cases]
    target = Path(__file__).with_name("interface_verification.json")
    target.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
