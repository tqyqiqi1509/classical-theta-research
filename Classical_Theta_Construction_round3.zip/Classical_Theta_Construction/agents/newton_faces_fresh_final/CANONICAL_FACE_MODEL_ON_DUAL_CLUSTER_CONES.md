# Canonical lower theta models on dual cluster cones

2026-11-14. Corollary and refinement of
`BONGARTZ_MONOMIAL_FACE_THEOREM.md`, in the same tall column-root
convention and for classical finite theta functions.

## 1. Statement

Fix B, its positive integral diagonal skew-symmetrizer D, and the principal root
variables z. Let Delta(B^T) be the ordinary g-vector fan of the cluster
algebra with exchange matrix B^T. Let rho be a cone of this fan, and let
U be the partial cluster whose g-vectors are its primitive rays. Write

    d=dim rho,   r=n-d.

For maximizing normals w with **-w in relint(rho)**, the construction
of the preceding theorem gives canonical data

    S_rho >= 0,  Q_rho,  D_rho,

depending only on B and rho, up to simultaneous permutation of the r
lower seed indices. They do not depend on a choice of optimized endpoint
or mutation path. Here S_rho is an n by r integral matrix of rank r,
and D_rho symmetrizes Q_rho.

For each finite theta theta_g, there are canonical data

    p_(g,rho) in N^n,  h_(g,rho) in Z^r

with the same permutation convention, such that for EVERY such w,

    F_g^B |_max(w)
      = z^(p_(g,rho)) F_(h_(g,rho))^(Q_rho)(z^(S_rho)),           (1.1)
    face_w Newt(F_g^B)
      = p_(g,rho) + S_rho Newt(F_(h_(g,rho))^(Q_rho)).             (1.2)

Thus both the face and its normalized lower theta model are constant
on the relative interior of a dual cluster cone (with the minus sign
coming from maximum versus minimum valuation). Different cones rho
can expose the same Newton face; the assertion does not identify their
possibly different lower models.

If G_U is the n by d matrix of the g-vectors in U, then the columns of
S_rho form a nonnegative integral Z-basis of the saturated lattice

    L_rho={q in Z^n : G_U^T q=0}.                              (1.3)

This is a lattice-basis statement. It does not assert that S_rho N^r
is the whole monoid L_rho intersect N^n, or that these columns form a
Hilbert basis of that monoid. The theta face support lies in the
particular translated monoid supplied by (1.1).

## 2. Why the partial cluster U is unambiguous

GHKK arXiv:1411.1394v2, Theorem 2.13, shows that the cluster chambers
form a simplicial fan. Corollary 5.9 identifies its generators with
ordinary cluster g-vectors; Theorem 5.11 gives their row sign coherence.
Apply these statements to the B^T pattern. Therefore every point in
the support of this fan belongs to the relative interior of a unique
cone rho. Its primitive rays correspond to a unique partial cluster U.

Suppose a supplied path ends at t with beta_t>=0. Holding that endpoint
cluster fixed, express its G-matrix in each successive initial chart
while reading the path backwards. The g-vector initial-seed mutation
formula for B^T is exactly the tropical beta mutation. Row sign
coherence makes it linear on a nonnegative combination of all columns.
Consequently

    beta_0=-w=G_t^(B^T;0) beta_t.                              (2.1)

The strictly positive coefficients in beta_t select exactly the rays
of the minimal cone rho. Hence ANY optimized endpoint for this normal
selects the same partial cluster U, even though the zero directions
and the full completion cluster may differ.

For the Bongartz argument, U must be interpreted in the -B pattern,
not silently reused as a cluster in the wrong algebra. There is a
canonical abstract cluster correspondence under the same mutation
indices:

    clusters of B^T  <-> clusters of B <-> clusters of -B.

The first correspondence is Cao--Gyoda--Yurikusa (CGY)
arXiv:2106.11668v2, Lemma 4.13: equality of two cluster variables is
preserved under transpose. The second is the opposite-seed discussion
at the beginning of Section 4.2: coefficient inversion and B -> -B
commute with mutation. Coefficient independence of the cluster complex
permits principal coefficients on each side (CGY Proposition 3.7).
Thus the image U^- of U
in the -B pattern is independent of all mutation words used to present
its cluster variables.

## 3. Uniqueness of the final root embedding and lower matrix

At the original initial chart, the preceding construction finishes
with a genuine C-matrix of the -B pattern, for a completion cluster T
that contains U^-. Every column indexed by T minus U^- is nonnegative.
These are exactly CGY Definition 4.9(i)'s two requirements for the
Bongartz completion of U^- relative to the original -B seed.

CGY Theorem 4.15 proves existence and uniqueness of this completion.
Therefore

    T = B_(U^-)(initial seed of -B)                             (3.1)

for every supplied optimized path. A cluster determines its seed up
to index permutation in this principal-coefficient pattern (CGY
Theorem 3.6; coefficient columns permute as in Proposition 3.11). Hence the
full C-matrix and its completion exchange matrix -Q agree up to that
permutation. The set of omitted directions is the fixed partial
cluster U^-, so their complementary data

    S_rho=C_(T minus U^-),
    Q_rho=Q_(T minus U^-, T minus U^-)

and the associated diagonal symmetrizer agree up to simultaneous
permutation. In particular S_rho and Q_rho are independent of g as
well as independent of the optimized path.

The lower diagonal weights can also be recovered from S_rho without
remembering an endpoint labeling. Since D C D^(-1) is integral
unimodular, each of its columns is primitive. For a retained column j,

    (D_rho)_jj = gcd_i (d_i (S_rho)_ij).                         (3.2)

Thus the weights in the lower label formula are themselves determined
by the canonical root embedding and the fixed original D.
Taking the retained block of the weighted exchange identity also gives

    Q_rho = D_rho^(-1) S_rho^T D B S_rho.                       (3.3)

Thus the lower matrix is recovered directly from S_rho, D, and B.

This step uses uniqueness, not only an existence theorem for a
nonnegative completion. It is what makes the output canonical.

The algorithm also returns an explicit path to this canonical optimized
endpoint. Append to the supplied ambient path the completion pivots j
recorded during the reverse construction, in their recorded order.
All lie in the original retained set J. Starting from beta_t=a, every
such mutation has beta_j=0, so beta remains a throughout. The full
exchange matrix at the new endpoint is Q, and the retained part of its
ordinary full theta label is h. Thus the abstract canonical completion
is an actual optimized seed reached by a path of length at most twice
the original one. This does not assert a path having only strict steps.

## 4. The saturated orthogonal lattice

Order the completion so that I indexes U^- and J its complement.
Its dual G-matrix for B^T satisfies

    G^T C=I_n,  G_I=G_U,  S_rho=C_J.

Every integer vector q can be written uniquely as q=C b with b in
Z^n, because C is unimodular. The equations G_U^T q=0 say exactly
b_I=0. Thus

    L_rho=C_J Z^r=S_rho Z^r,

and these columns form a Z-basis. Being the kernel of an integral map
to a torsion-free group, this lattice is saturated; alternatively it
is a coordinate direct summand in the unimodular C-basis. Its rank is
n-d. Nonnegativity of the chosen basis comes from Bongartz completion,
not from the equations defining the kernel alone.

## 5. A fixed lower model throughout relint(rho)

Choose any full cluster containing U, and a mutation path to it.
For every beta_0 in relint(rho), equation (2.1) gives a positive
coefficient vector a on I and zero on J at that same endpoint. Thus
the chosen endpoint is optimized for every such beta_0.

Run the normalizer backwards. At any stage beta=G a, where the fixed
partial cluster occupies I and all a_i>0 for i in I. Row sign coherence
has the following consequence:

    beta_k=0 iff G_ki=0 for every i in I;
    otherwise sign(beta_k) is the common nonzero sign in that row on I.

Neither alternative depends on the values of the positive a_i. Hence
the strict/tie pattern and every chosen completion pivot are constant
over relint(rho). The starting theta label m_t depends on g and the
chosen path but not on a. All subsequent ACTUAL face prefactor updates
and lower theta label updates therefore produce the same A,h,p for
every such normal. This proves that the face polynomial itself, not
only its support value, is constant on relint(rho).

Equivalently, the Newton normal fan is coarser than this portion of the
negative dual g-vector fan. Linearity of optimized theta valuations
on cluster cones is existing GHKK machinery; here the exact lower
theta and nonnegative root embedding are retained along with it.

## 6. Why p and h do not depend on the optimized path

For any fixed normal in relint(rho), formula (1.1) has S_rho>=0 and
a lower F-polynomial with constant term 1. Every face exponent has the
form p+S_rho q with q>=0, and p itself occurs. It follows that p is
the unique coordinatewise least point of the entire Newton face,
and is its unique coordinatewise least support exponent. Its
coefficient is 1 because the root map is injective.

This characterizes p using the original face alone. Therefore any two
optimized paths give the same p. Since the original principal chart
has E_0=[B;I], its ACTUAL mutable prefactor is

    v=A_mut=g+Bp.

The weighted label invariant proved in Section 5 of the main theorem
now gives the explicit path-independent formula

    h_(g,rho)=D_rho^(-1) S_rho^T D (g+B p_(g,rho)).              (6.1)

It is integral by the construction. One must retain the Bp term:
using the ordinary initial theta label g in place of the actual face
prefactor g+Bp would usually give the wrong lower label.

The preceding section shows that the face is constant on relint(rho),
so this same characterization proves constancy of p and h throughout
the cone's relative interior. Together with Section 3, all data in
(1.1) are canonical in the stated sense.

## 7. Primary-source and attribution details

* GHKK, arXiv:1411.1394v2: Theorem 2.13, Corollary 5.9, Theorem 5.11,
  and Lemma 5.12 were inspected directly for the fan, g-vector, and
  duality conventions.
* CGY, arXiv:2106.11668v2: Section 4.2's opposite-seed construction,
  Lemma 4.13 and its proof, Lemma 4.14, Definition 4.9, and Theorem
  4.15 and its proof were inspected directly. Theorem 3.20 summarizes
  the enough g-pairs existence and uniqueness inputs.
* Cao--Li, arXiv:1803.05281v2: Definitions 4.4--4.5, Proposition 4.6,
  Theorem 4.8 and its scattering-diagram proof, and Theorem 5.5 and
  its uniqueness proof were inspected directly. The arXiv theorem
  numbering is 4.8 and 5.5; CGY's published-reference numbering is
  Theorems 8 and 9.

Bongartz uniqueness and the cluster fan are old results. The practical
consequence added here is that the preceding theta-face transport
produces a canonical, nonnegative, coefficient-preserving lower theta
model on each specified dual cluster cone, with explicit p and h.
