# Computing the monomial theta face transform

`normalize_bongartz_face.py` implements the algorithm in
`BONGARTZ_MONOMIAL_FACE_THEOREM.md`. It uses the Python standard library
only; the final polytope step needs no polyhedral solver.

## Input and use

The required JSON keys are:

* `B`: an integral skew-symmetrizable square matrix, in tall/column-root
  convention.
* `g`: the label of the given finite classical theta function.
* `w`: the integer maximizing normal for the requested F-polynomial face.
* `sequence`: a supplied mutation list, using **zero-based** indices.

Run from this directory:

```sh
python normalize_bongartz_face.py request.json
```

Or call `normalize_face(B, g, w, sequence)` from Python. The script
computes valuations and labels, and rejects a path whose endpoint root
valuation is not coordinatewise nonnegative. The caller supplies the
finiteness hypothesis for the theta function; this is not a finiteness
decision procedure.

## Output and exact formula

The main outputs are:

| Key | Meaning |
| --- | --- |
| `translation` | The nonnegative vector p. |
| `root_embedding` | The n by r nonnegative integer matrix S. |
| `lower_B` | The normalized lower-rank exchange matrix Q_red. |
| `lower_g` | The lower theta label h in that normalized seed. |
| `lower_sequence` | Zero-based lower mutation list, starting in the optimized endpoint's retained seed. |
| `canonical_sequence` | Original ambient path followed by the recorded retained pivots; it reaches the canonical Bongartz completion and remains optimized. |
| `canonical_B`, `canonical_full_label` | Full matrix and ordinary full theta label at that constructed optimized endpoint. |
| `endpoint_lower_B`, `endpoint_lower_g` | Original optimized endpoint lower seed, before normalization. |
| `J` | Retained indices in the optimized ambient seed. |
| `face_height` | The exact value max(w dot p) on the requested face. |
| `full_completion_C` | The unimodular C-matrix whose retained columns form S. |
| `actual_prefactor_exponent` | The full Laurent exponent A; its frozen part is p. |

The result certifies

    F_g^B |_max(w) = z^p F_h^(Q_red)(z^S),
    face_w Newt(F_g^B) = p + S Newt(F_h^(Q_red)).

The map q -> p+Sq is injective, so it preserves every coefficient and
sends vertices exactly to vertices. For nonzero w, r<n.

The returned normalized optimized path has at most twice the length of
the input path. Its appended mutations all have root valuation zero,
so the nonnegative endpoint valuation is unchanged. Its full theta label
has retained part `lower_g`; the program checks the full endpoint
matrix and this label equality by the appended ordinary mutations.
The actual face prefactor A used in the
proof is a different object and remains separately recorded.
The name `canonical_sequence` means a certificate path to the canonical
endpoint; the mutation word itself can depend on the input path.

With `include_trace: true`, each reverse ambient step records C, the
actual prefactor A, and the lower label. At a tied step, the trace
identifies the unique retained completion pivot and its lower index.
At every step the implementation checks, with integer arithmetic,

    C_J >= 0,
    C^T beta = beta_endpoint,
    D Q = C^T D B C,
    C_J^T D A_mut = D_J h.

It also checks the final principal-root identity A_mut-g=Bp and the
supporting hyperplane identities w dot p=face_height and w^T S=0.
These checks certify arithmetic consistency; the general theorem is
the mathematical proof of the algorithm.

## Supplying the lower polytope or polynomial

After obtaining the normalized lower seed, a second invocation may
add either or both optional keys:

* `lower_vertices`: the lower theta's vertices, as nonnegative integer
  vectors of length r. The output `face_vertices` is their affine image.
* `lower_terms`: objects with keys `exponent` and `coefficient`. These
  describe the complete lower polynomial, with positive integer
  coefficients. The output `face_terms` preserves those coefficients.

The lower input MUST refer to the returned `lower_B` and `lower_g`.
It generally differs from the original optimized endpoint lower seed.
The script does not infer a lower polynomial from its label, and cannot
verify that an externally supplied polynomial is the correct theta.

If only the lower polytope in the ORIGINAL optimized endpoint seed is
available, use `initial_face_transform.py` instead. Its positive rational
circuit and exact rational feasibility filter handle that input directly.
The normalized interface avoids that filter by choosing a lower seed in
which the final face map is a single nonnegative monomial substitution.

## Verification already performed

The new normalizer was run on the two existing independently expanded
cluster-variable inputs used for the rational interface, including a
matrix with unequal symmetrizer entries. Their paths contain ties before
and after strict steps. All exact normalizer identities passed; the
results are recorded in `bongartz_normalization_verification.json`.
Their monomially transformed polynomials and vertices agree exactly
with the independent direct exchange calculations.
The independent direct exchange calculations are in
`interface_verification.json`. These are implementation checks only;
the proof and symbolic identities apply to general matrices.
