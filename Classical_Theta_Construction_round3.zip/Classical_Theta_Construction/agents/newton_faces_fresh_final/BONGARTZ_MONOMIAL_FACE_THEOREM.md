# Absorbing tied mutations into the lower-rank seed

2026-11-14. Classical q=1; arbitrary skew-symmetrizable B. This strengthens
`TIED_INITIAL_MUTATION_FACE_THEOREM.md`: the supplied optimized path can
have ties, and after changing the lower-rank seed at exactly the required
ties, its face is a single nonnegative integral monomial image. The
positive rational interface remains valid without this normalization.

## 1. Result and scope

Use the tall principal extension E_0=[B_0;I], independent roots
z_j=X_0^(E_0 e_j), and a finite theta function

    theta_g=X_0^(g,0) F_g^(B_0)(z).

For a requested maximum face with normal w, put u_0=(0,-w). Supply a
finite ambient mutation path from seed 0 to seed s for which the usual
minimum coordinate valuations satisfy

    beta_s=E_s^T u_s >= 0.

Set I={i:beta_s,i>0}, J={j:beta_s,j=0}, r=|J|. Then there are explicitly
computable

    p in N^n,  S in Mat_(n by r)(N),  rank S=r,
    an integral skew-symmetrizable r by r matrix Q_red,
    and a lower-rank theta label h in Z^r

such that

    F_g^(B_0)|_max(w) = z^p F_h^(Q_red)(z^(S_1),...,z^(S_r)).       (1.1)

The lower theta is finite. More precisely, S consists of r columns of
an integral unimodular C-matrix. Thus the complete face, including its
coefficients, is obtained by an injective root-degree map, and

    face_w Newt(F_g) = p + S Newt(F_h^(Q_red)).                     (1.2)

No convex hull enlargement or branch filter is needed in (1.2). The
matrix Q_red is mutation-equivalent to the optimized endpoint matrix
B_s,JJ by mutations entirely within J. If w is nonzero, r<n.

The input is still a GIVEN optimized path. This theorem does not assert
that every normal is optimized, and does not compute an arbitrary lower
theta support without an independent method for that lower-rank input.
It turns that input into an exact affine face computation.

## 2. Old cluster facts used, and the two dual patterns

Fix a positive diagonal skew-symmetrizer D=diag(d_i), so DB is skew-
symmetric. The same D symmetrizes every ambient matrix along the path.
No representation-theoretic S-matrix is imported.

We use two ordinary cluster patterns at every current ambient seed:

* G is the G-matrix of a completion cluster in the pattern with initial
  exchange matrix B^T.
* C=G^(-T) is the C-matrix of the corresponding completion in the pattern
  with initial exchange matrix -B.

This is Nakanishi--Zelevinsky, Theorem 1.2, equation (1.11), applied with
their B equal to our B^T. C-columns and G-rows are sign-coherent; both
matrices are integral unimodular. NZ Proposition 4.2(iii),(v), together
with general sign coherence, supplies the initial-seed change formula.
These hold for all skew-symmetrizable matrices.

Write -Q for the exchange matrix at the completion in the -B pattern;
equivalently Q^T is its matrix in the B^T pattern. Then

    D Q = C^T D B C.                                             (2.1)

The matrices C and D C D^(-1) are both integral unimodular. Indeed,
scaling the whole coefficient pattern for -B by D on the left and
D^(-1) on the right gives the coefficient pattern for B^T: positive
diagonal scaling commutes with the positive-part mutation formula.
Both patterns start with coefficient matrix I. This also proves the
integrality of the inverses used below.

For clarity, the nonnegative complement property is an old Bongartz
completion property. Cao--Gyoda--Yurikusa, arXiv:2106.11668v2 (13 Dec
2022), Definition 4.9 and Theorem 4.15, prove its existence and uniqueness
using Cao--Li enough g-pairs and tropical duality. Fu--Geng--Liu,
arXiv:2207.05555, Lemma 3.10, prove that when the initial seed changes by
one mutation, this completion either stays fixed or changes in one
complement direction. Sections 3--4 reproduce the necessary local
argument, and identify precisely when that change is a valuation tie.
The extra interface proved here is its compatibility with the actual
theta face prefactor and the lower theta mutation, including D.

## 3. Induction from the optimized endpoint

Read the supplied ambient mutation path BACKWARDS, starting at seed s.
The frozen variables remain those of the original tall principal setup;
only the ambient mutable coordinates change. At the start put

    C=G=I,  Q=B_s,  a=beta_s,
    A=m_s,  h=(m_s)_J.

Here m_s is the ordinary full theta label in seed s, including frozen
coordinates. The vector a has fixed positive entries on I and zero
entries on J. The letters A and a have different roles:

    a is the fixed positive coefficient vector defining the normal;
    A is the ACTUAL full Laurent monomial exponent of the FACE prefactor.

In later seeds A need not be the theta's usual leading label. In
particular its mutable part v=A_mut can equal g_current+B_current p.
Replacing v by g_current in the weighted label formula below is wrong.

At every stage maintain

    beta=G a,  C=G^(-T),  C_J>=0,  DQ=C^T DBC,                    (3.1)
    h=D_J^(-1) C_J^T D v,    v=A_mut,                           (3.2)
    H_current=X^A F_h^(Q_JJ)((z^(C_j))_(j in J)),                (3.3)

where H_current=in_u(theta) is the minimum initial form in that ambient
chart. At the optimized seed, (3.3) is exactly the known zero-root-degree
freezing identity. In particular it is one finite lower theta.

The matrix C is always a genuine C-matrix of the -B pattern, and G is
the corresponding genuine G-matrix for B^T. Mutations of their completion
will occur only in J, keeping the partial cluster indexed by I fixed.
Consequently beta=Ga continues to represent the same tropical normal.

Since C^T G=I, each complement column obeys

    beta^T C_j = a_j = 0,             j in J.                    (3.4)

Equation (3.4) alone is NOT a proof that C_j is nonnegative. That fact is
maintained using sign coherence and the following local completion step.

## 4. The local completion step

Let k be the next ambient mutation index. For epsilon in {+1,-1}, put

    E_epsilon=J_k + [epsilon B]_(row k,+).

Thus E_epsilon changes only row k, has entry -1 at (k,k), and
(k,i)-entry [epsilon B_ki]_+ for i!=k. It satisfies E_epsilon^2=I.
Let B'=mu_k B and let the full tall matrix change to E_ambient'.
To avoid confusing the two E's, E_epsilon always denotes the square
row matrix just defined; E_ambient denotes the tall exchange matrix.

If row k of G has common sign epsilon, the old completion viewed from
the new ambient initial seed has

    G_temp=E_epsilon^T G,  C_temp=E_epsilon C.                    (4.1)

This is precisely the g-vector initial-seed transformation for B^T.
Also

    B'=D^(-1) E_epsilon^T D B E_epsilon.                         (4.2)

### 4.1 Strict valuation: beta_k != 0

The common sign of row k of G equals epsilon=sign(beta_k), because
beta_k=sum_(i in I) G_ki a_i and every a_i is positive.

Set C'=E_epsilon C, G'=E_epsilon^T G and Q'=Q. Every complement
column C_j has a positive entry outside row k. Otherwise C_j, being
nonnegative and primitive, would equal e_k, contradicting (3.4) and
beta_k!=0. The transformation (4.1) leaves those entries unchanged.
Since the new C-column is sign-coherent, it is nonnegative. Therefore
C'_J>=0 without changing the completion.

The ordinary normal mutation is beta'=E_epsilon^T beta=G'a.
Equation (4.2), together with E_epsilon^2=I, preserves (2.1).

### 4.2 Tied valuation: beta_k=0

Row sign coherence and a_i>0 imply G_ki=0 for every i in I.
Let x=G^T e_k=C^(-1)e_k. Thus x_I=0. The remaining entries have one
common sign, since x is the transpose of row k of G. The identity

    e_k = C_J x_J

and C_J>=0 show that this common sign is positive. All entries in the
nonzero columns C_J are nonnegative integers. Consequently exactly one
j in J has x_j=1 and C_j=e_k, and all other x_l are zero. To see the
uniqueness explicitly, the sum has k-th coordinate 1 and all other
coordinates 0, so any contributing column must be supported at k;
integral primitivity and invertibility leave one such column.

Thus the tie determines a unique complementary pivot j satisfying

    C_j=e_k,  row_k G=e_j^T.                                    (4.3)

The diagonal weights at these two indices are equal:

    d_j=d_k.                                                    (4.4)

Indeed, the j-th column of DCD^(-1) is (d_k/d_j)e_k, and the k-th
column of its inverse is (d_j/d_k)e_j. Both coefficients are positive
integers, so both equal 1. This step is needed in the symmetrizable case.

The common row sign is now +. Put

    C_temp=E_+ C,
    R=J_j+[Q]_(row j,+),
    C'=C_temp R,   G'=G_temp R^T,   Q'=mu_j Q.                    (4.5)

Since C_temp,j=-e_k, its sign is negative. Formula (4.5) is exactly
coefficient mutation at j for the -B' pattern whose completion matrix
is -Q. In particular C' and G' remain genuine cluster matrices.

The j-th column of C' is e_k. Every other complement column retains
its entries outside row k, because C_temp,j is supported at k; at least
one such entry is positive, since C is invertible. The new column's
sign coherence therefore makes it nonnegative. Hence C'_J>=0.

Only the completion cluster variable at j changes, so the partial
cluster on I remains fixed. Algebraically R^T a=a because a_j=0,
and therefore G'a=G_temp a=beta'. Matrix identity (2.1) is preserved
by the usual weighted mutation identity at j.

This completes the old local Bongartz step and its tie identification.

## 5. Root and label compatibility: the theta interface

The actual ambient coordinate mutation is

    X'_k=(M_++M_-)/X_k,
    z'_k=z_k^(-1),
    z'_i=z_i z_k^[B_ki]_+ (1+z_k)^(-B_ki)       (i!=k).           (5.1)

The initial-form mutation Phi replaces 1+z_k by 1 if beta_k>0,
by z_k if beta_k<0, and retains 1+z_k if beta_k=0. The earlier
initial-form lemma states that these maps are field isomorphisms and
transport initial forms exactly, including ties. Thus it suffices at
each step to construct H_new with Phi^*(H_new)=H_current.

### 5.1 Strict step

Put epsilon=sign(beta_k). Define the new ACTUAL face prefactor exponent
by the strict monomial coordinate transformation:

    A'_k=-A_k,
    A'_i=A_i+[-epsilon E_ambient,ik]_+ A_k       (i!=k),           (5.2)

including all frozen rows. Then

    Phi^*(X'^A')=X^A,
    Phi^*(z'^(C'_l))=z^(C_l)                   (l in J).        (5.3)

The second equality follows directly from (5.1), C'=E_epsilon C,
and the replacement of 1+z_k by 1 or z_k.

The mutable exponent update in (5.2) is

    v'=L_epsilon v,  L_epsilon=D^(-1)E_epsilon^T D.

Thus E_epsilon^T D L_epsilon=D, and

    C'_J^T D v' = C_J^T D v.

So h'=h and (3.2) is preserved. Equations (5.3) prove (3.3) after
this step, with no lower-rank seed mutation.

### 5.2 Tie step: roots

Use the unique pivot j given by (4.3). Write

    Y_l=z^(C_l),  l in J;  in particular Y_j=z_k.

The weighted exchange identity and d_j=d_k give, for every l,

    Q_jl = sum_i B_ki C_il.                                    (5.4)

For any integer column q, direct substitution in (5.1) gives

    mu_k^*(z'^(E_+ q))=z^q (1+z_k)^(-sum_i B_ki q_i).            (5.5)

Apply this with q=C_l, then use C'=E_+ C R. The result is

    mu_k^*(z'^(C'_j))=Y_j^(-1),
    mu_k^*(z'^(C'_l))
       =Y_l Y_j^[Q_jl]_+ (1+Y_j)^(-Q_jl),       l in J, l!=j.    (5.6)

These are EXACTLY the root mutations in the lower matrix Q_JJ.
They are binomial rational mutations, not monomial maps. The point is
that they now act inside the lower theta function.

### 5.3 Tie step: prefactor and the lower label

Choose the new full prefactor exponent by

    A'_k=-A_k,
    A'_i=A_i+[E_ambient,ik]_+ A_k
                    -E_ambient,ik min(A_k,0),   i!=k.           (5.7)

This is the usual theta tropical label formula applied to the ACTUAL
prefactor exponent A. Its validity for the following monomial ratio
is a direct algebraic identity; it does not assume A is the ambient
theta's usual initial label:

    mu_k^*(X'^A')/X^A
       =z_k^[A_k]_+ (1+z_k)^(-A_k).                            (5.8)

By (3.2), (4.3), and (4.4),

    h_j = d_j^(-1) C_j^T D v = v_k=A_k.                         (5.9)

Let h' be the usual lower theta label mutation at j:

    h'_j=-h_j,
    h'_l=h_l+[Q_lj]_+ h_j-Q_lj min(h_j,0),    l in J, l!=j.      (5.10)

Classical theta mutation covariance, written in F-polynomial form,
states

    F_h^(Q_JJ)(Y)
      =Y_j^[h_j]_+ (1+Y_j)^(-h_j)
          F_(h')^((mu_j Q)_JJ)(mu_j Y).                         (5.11)

Equations (5.6), (5.8), and (5.9) identify the right side of (5.11)
with mu_k^*(X'^A' F_(h')(...))/X^A. This proves the full face identity
at the tied step. No series expansion or cancellation assumption is
used; both sides are equal rational functions and the left is finite.

It remains to verify that the weighted projection (3.2) persists, since
the next tie will need it. This can be checked with a full n-component
auxiliary label b=D^(-1)C^T D v; only b_J=h is used in the theta.
Let t=v_k=h_j. Formula (5.7) gives

    E_+^T D v' = Dv - d_k [t]_+ (B_(row k))^T.

Using (5.4), skew-symmetry of DQ, and (4.5), one obtains

    D^(-1) C_temp^T D v' = b + Q_(column j) [t]_+,
    D^(-1) C'^T D v'
       =D^(-1) R^T D (b+Q_(column j)[t]_+).                    (5.12)

Its j-th component is -b_j, and for l!=j it is

    b_l+Q_lj[b_j]_+ +[-Q_lj]_+ b_j
      =b_l+[Q_lj]_+ b_j-Q_lj min(b_j,0).

Restricting to J is exactly (5.10). This verifies (3.2) and closes
the induction.

## 6. Return to the original principal chart

After all reverse steps, let A,C,Q,h be the resulting data and put

    S=C_J.

By construction S>=0, its columns are part of a unimodular basis, and

    in_(u_0)(theta_g)=X_0^A F_h^(Q_JJ)(z^S).                     (6.1)

The constant term of the finite lower F-polynomial is 1. Since S has
full column rank, it maps distinct lower exponents to distinct ambient
root exponents. Consequently the monomial X_0^A really occurs in
(6.1), with coefficient 1. As (6.1) is a face of the pointed expansion
X_0^(g,0) F_g(z), there is a unique p in N^n with

    A-(g,0)=E_0 p.                                             (6.2)

For principal E_0=[B_0;I], it is explicitly p=A_frozen. The mutable
identity A_mut-g=B_0 p is a useful exact consistency check.
Divide (6.1) by X_0^(g,0) to obtain (1.1); the injective affine map
of supports proves (1.2), preserving every coefficient.

The lower theta remains finite in all J-seeds by ordinary theta
mutation finiteness (GHKK v2, Proposition 7.1 and Definition 7.2).
All changes of its seed used above are actual J-mutations.

Finally, beta mutation is invertible, so beta_s=0 iff beta_0=0.
Therefore w!=0 implies I is nonempty and r<n.

## 7. Explicit finite interface

Given B_0,g,w and the certified ambient mutation list:

1. Run forward to record every tall exchange matrix, root valuation,
   and full theta label. Check beta_s>=0. This is the existing circuit
   interface's preprocessing.
2. Initialize C=I,Q=B_s,A=m_s,h=(m_s)_J. Traverse the ambient list
   backwards. At a strict step apply (4.1) and (5.2). At a tie find
   the unique j in J with C_j=e_k, then apply (4.5),(5.7),(5.10).
3. Return p=A_frozen,S=C_J,Q_red=Q_JJ,h and the recorded J-mutation
   list. Every operation is integral matrix arithmetic and positive
   parts. An arbitrary fixed positive skew-symmetrizer D suffices
   for the proof; implementations can check the D identities.
4. When a lower polynomial or Newton polytope is supplied in this
   normalized lower seed, return the coefficient-preserving affine
   image (1.1) or (1.2). No polyhedral solver is needed for this step.

The earlier positive rational circuit instead accepts the lower
polytope in the ORIGINAL optimized endpoint seed. The two interfaces
use different lower seed inputs. To use only that original polytope,
one can retain the previously proved piecewise-linear circuit method;
a mutation generally does not carry an arbitrary F-polytope by one
global affine map. The present theorem supplies a preferred lower
seed for which the final ambient face map IS globally affine.

## 8. Relation to Fei and attribution boundary

Fei arXiv:2510.01615v4, 3 Nov 2026, Section 8.3, Corollary 8.11 and
Question 8.14 concern representation-theoretic F-polynomials and
orthogonal projections. Their nonnegative dimension-vector matrix is
not a theta theorem and has not been substituted into this argument.
The construction above is a pure cluster/theta counterpart for normals
with a supplied optimized seed: the MINIMUM root valuation beta_0=-w
(the negative of the requested maximizing normal) lies in the B_0^T
cluster fan because beta transforms as a g-vector of B^T, and its zero link
is normalized by Bongartz completion in the -B_0 coefficient pattern.

Fei's extended-reachable conventions can include additional global
tau operations. Identifying every such normal with the optimized
normal class above requires a separate theorem; no such identification
is claimed here. Similarly, this does not prove the unrestricted
version of his question for all representation-theoretic F-functions.

The following components are established literature, not new claims:
theta mutation and freezing, optimized valuations, tropical C/G
duality, sign coherence, Bongartz completion, the adjacent-seed
completion step, and the ordinary root mutation formulas. The
additional usable synthesis in this note is the full theta-face
transport with the ACTUAL prefactor label, the symmetrizer-compatible
identification h_j=A_k at a tie, and the resulting computable
nonnegative root embedding giving the exact entire Newton face.

## 9. Primary-source locations actually inspected

* Nakanishi--Zelevinsky, arXiv:1101.3736v3, Theorem 1.2 (1.11)--(1.13),
  Propositions 1.3--1.4, and Proposition 4.2 with its proof. The paper
  states the sign-coherence hypothesis; general sign coherence is
  supplied by GHKK, not by treating that old hypothesis as automatic.
* Cao--Gyoda--Yurikusa, arXiv:2106.11668v2, Theorems 3.17--3.20,
  Definition 4.9, Lemma 4.14, Theorem 4.15 and its proof. In the final
  v2 this is Theorem 4.15; Fu--Geng--Liu's older reference calls it
  Theorem 4.14. The numbering discrepancy is chronological.
* Fu--Geng--Liu, arXiv:2207.05555, Theorem 2.1, Proposition 2.2,
  Definition 3.6, and Lemmas 3.8--3.10 with their proofs. Its main
  non-leaving-face theorem is not needed as an extra black box here.
* GHKK, arXiv:1411.1394v2, Proposition 7.1, Definition 7.2,
  Definition 9.1 and Lemma 9.3; zero-root-degree freezing was established
  in the preceding note independently of Li--Pan.
* Reading--Stella, arXiv:2603.19391v4, 8 Nov 2026, Section 4,
  equations (4.1)--(4.6), Theorem 4.2 and Lemma 4.9: the theta/root
  mutation apparatus is old, including frozen monomial adjustments.
* Fei, arXiv:2510.01615v4, Section 7 and Section 8.3, read in the actual
  November 2026 version. The analogy and boundary are stated above.
