# Nested cluster normals: coefficient-level compatibility of face reduction

2026-11-14. Classical finite theta functions; arbitrary integral
skew-symmetrizable B. This is a further consequence of the proved
monomial face theorem and its canonical version, using the actual
commutativity and coefficient-specialization statements of
Cao--Gyoda--Yurikusa (CGY), arXiv:2106.11668v2.

## 1. Setup and result

Let U be a subset of V, where V is a partial cluster in the B^T
g-vector fan. Use the canonical abstract cluster correspondence to
view both partial clusters in the -B coefficient pattern when taking
Bongartz completions. Write rho_U and rho_V for their g-vector cones.
Choose

    beta_U in relint(rho_U),  beta_V in relint(rho_V),
    w_U=-beta_U,  w_V=-beta_V.

For the original finite theta F_g^B, its canonical U-face model is

    F_g^B |_max(w_U) = z^(p_U) F_(h_U)^(Q_U)(z^(S_U)).           (1.1)

The lower matrix has rank parameter r_U=n-|U|. Define a lower normal

    beta_(V/U)=S_U^T beta_V,
    w_(V/U)=S_U^T w_V=-beta_(V/U).                              (1.2)

This lower normal lies in the relative interior of the dual cluster
cone for the partial cluster V minus U in the link of U, expressed
in the canonical lower Q_U^T seed. In particular it has an optimized
endpoint. When U is a proper subset of V, it is nonzero.

Apply canonical face reduction to the lower theta in (1.1):

    F_(h_U)^(Q_U) |_max(w_(V/U))
      = Y^(p_(V/U)) F_(h_(V/U))^(Q_(V/U))(Y^(S_(V/U))).          (1.3)

After matching seed indices, the direct V-face data satisfy

    S_V = S_U S_(V/U),
    p_V = p_U + S_U p_(V/U),
    Q_V = Q_(V/U),
    h_V = h_(V/U).                                             (1.4)

Thus the TWO reductions and the direct reduction agree as complete
polynomials, with every coefficient preserved:

    F_g^B |_max(w_V)
      = z^(p_U+S_U p_(V/U))
          F_(h_(V/U))^(Q_(V/U))(z^(S_U S_(V/U))).                (1.5)

This is stronger data than the formal identity for taking a face of
a face: the lower normal is explicitly identified, the canonical
nonnegative root matrices multiply, and the theta labels match.

## 2. Old completion and specialization facts used

Let T_U and T_V be the unique Bongartz completions of U and V,
respectively, in the -B pattern relative to the original initial seed.
CGY Theorem 4.18, applied to V=U disjoint-union (V minus U), gives

    T_V = B_V(T_U) = B_(V minus U)(T_U).                        (2.1)

CGY Theorem 5.4 identifies the exchange graph of clusters containing
U with the exchange graph after freezing U at T_U. In particular,
T_V is reached from T_U by a mutation sequence that never changes U,
and its remaining variables are a lower cluster for -Q_U.

There is also a precise coefficient-matrix multiplication statement.
Let C_U be the full C-matrix of T_U relative to the original -B seed,
and let J index the complement T_U minus U. Thus S_U=(C_U)_J>=0.
For any mutation sequence using only J, let C_red be the coefficient
matrix of that sequence in the rank-r_U pattern with initial matrix
-Q_U. The corresponding full C-matrix C_new satisfies

    (C_new)_J = S_U C_red.                                    (2.2)

Equation (2.2) is CGY Lemma 4.17's nonnegative coefficient
specialization, used in precisely this restricted block in the proof
of their Theorems 4.18 and 5.4. It is NOT an assertion that arbitrary
full C-matrices multiply under arbitrary changes of initial seed.

For completeness, its local reason is straightforward. Initially
C_red=I. The retained columns of the original full coefficient block
start as S_U. A lower C-column is sign-coherent. Since S_U is
nonnegative and injective, multiplication by S_U preserves its sign
and nonvanishing. Therefore the same coefficient-mutation formula
updates both sides of (2.2), proving it inductively.

## 3. Identification of the nested canonical root embedding

Index T_U so U occupies I and its complement occupies J. Realize
T_V by a J-mutation path, keeping these positions for the variables
of U. At its end let K subset J index V minus U, and let L=J minus K
index T_V minus V.

The reduced seed associated to T_V is the Bongartz completion of
V minus U in the reduced -Q_U pattern. One way to see this is to lift
its lower Bongartz completion by keeping U frozen. Its complementary
lower C-columns are nonnegative. The columns belonging to the fixed
initial variables U have an identity block in the U rows and are
sign-coherent, so they too are nonnegative. The lift is therefore the
full Bongartz completion of V minus U relative to T_U, which is T_V
by (2.1) and uniqueness.

Hence

    S_(V/U)=(C_red)_L >= 0.

Apply (2.2) at T_V and retain L:

    S_V=(C_V)_L=S_U (C_red)_L=S_U S_(V/U).                      (3.1)

The lower seed after the second completion is the principal L-block
of the matrix at T_V, so it is exactly Q_V, with its inherited
diagonal symmetrizer D_V. Equivalently, the weighted formula verifies
the same equality algebraically:

    Q_(V/U)
      =D_V^(-1) S_(V/U)^T D_U Q_U S_(V/U)
      =D_V^(-1) (S_U S_(V/U))^T D B (S_U S_(V/U))
      =Q_V.                                                   (3.2)

The matrix product is nonnegative and has full column rank. Its
columns are again part of the full unimodular coefficient basis at
T_V; it is not merely an arbitrary nonnegative matrix product.

## 4. Why the secondary normal is a lower cluster normal

Let G_V=(C_V)^(-T) be the G-matrix of T_V in the original B^T
pattern. Let G_red=(C_red)^(-T) be the G-matrix of the corresponding
reduced completion in the Q_U^T pattern. From (2.2) and G_V^T C_V=I,

    (G_V)_J^T S_U C_red=I_(r_U),

so

    S_U^T (G_V)_J=G_red.                                     (4.1)

Also S_U^T (G_V)_I=0, since the columns indexed by I are precisely
the fixed partial cluster U. Write beta_V as its positive combination
of the g-vectors in V at T_V:

    beta_V=(G_V)_I a_I+(G_V)_K a_K,
    a_I>0,  a_K>0.

Then

    S_U^T beta_V=(G_red)_K a_K.                               (4.2)

This proves that beta_(V/U) is in the relative interior of the lower
dual cluster cone K. The projected coefficients at the lower endpoint
T_V are a_K>0 and zero on L, so the endpoint is optimized. If K is
nonempty, the independent G_red columns make this normal nonzero.
Thus the second application of the face theorem meets its actual
normal hypothesis; it is not inferred just from an orthogonality
equation.

## 5. Exact equality of the iterated and direct face polynomials

Because U is a subset of V, the vector

    beta_U + epsilon beta_V

lies in relint(rho_V) for every epsilon>0. The canonical-cone theorem
says that its maximum face with the negative sign is the same as
the w_V face. For a finite polynomial, sufficiently small positive
epsilon realizes lexicographic face selection. Consequently

    (F_g^B |_max(w_U)) |_max(w_V) = F_g^B |_max(w_V).             (5.1)

The nonnegative root map in (1.1) is injective. For an exponent q of
the lower polynomial,

    w_V dot (p_U+S_U q)
      =w_V dot p_U+(S_U^T w_V) dot q.

Thus selecting the second face of (1.1) selects exactly the lower
face with normal w_(V/U), with unchanged coefficients. Substitute
(1.3) and obtain (1.5).

The translation p_U+S_U p_(V/U) is nonnegative, occurs with coefficient
1, and is coordinatewise no larger than any exponent on this face.
By uniqueness of the coordinatewise least face point, it equals the
direct canonical translation p_V. This proves the second equality
in (1.4), in addition to the embedding and matrix identities already
proved. In particular

    p_V-p_U belongs to S_U N^(r_U).

## 6. Matching the ACTUAL lower theta label

The U-reduction label uses its actual face prefactor:

    h_U=D_U^(-1) S_U^T D(g+B p_U).                             (6.1)

The second reduction therefore has label

    h_(V/U)
      =D_V^(-1) S_(V/U)^T D_U(h_U+Q_U p_(V/U)).                (6.2)

Insert (6.1), D_U Q_U=S_U^T D B S_U, and the identities for S_V,p_V:

    h_(V/U)
      =D_V^(-1) S_V^T D(g+B p_U+B S_U p_(V/U))
      =D_V^(-1) S_V^T D(g+B p_V)
      =h_V.                                                   (6.3)

This proves the last equality in (1.4). Omitting either translation
term from the actual prefactor would destroy this compatibility.

## 7. Iteration along a flag and the computational interface

For a flag U subset V subset W, the same argument gives

    S_W=S_U S_(V/U) S_(W/V),
    p_W=p_U+S_U p_(V/U)+S_U S_(V/U) p_(W/V).

The final exchange matrix and theta label are the direct W-data.
Ordinary associativity of matrix multiplication and monomial
substitution, together with Bongartz commutativity, shows that these
formulas do not depend on how the flag is grouped. The statement
concerns compatible nested partial clusters, not unrelated normals.

For actual calculations, the second call to the normalizer uses

    B_lower=Q_U,  g_lower=h_U,  w_lower=S_U^T w_V.

A J-mutation path from T_U to T_V supplies its optimized path; existence
is guaranteed by CGY Theorem 5.4, and the original/direct normalizers
already provide paths to the two canonical ambient endpoints. If a
lower path has not been constructed, this statement does not treat an
arbitrary sequence as an optimized certificate.

If both direct models have already been computed, one may recover
the relative affine data without a path search. Since C_U is
unimodular and S_U is its J-column block, let

    L_U=(C_U^(-1))_(J rows).

Then L_U S_U=I and the proved identities give

    S_(V/U)=L_U S_V,
    p_(V/U)=L_U(p_V-p_U).                                     (7.1)

These vectors/matrices are nonnegative integers for the nested
cluster-cone inputs considered here. Formula (7.1) is a computational
consequence of the theorem, not a general positivity claim for a left
inverse of a nonnegative matrix.

## 8. Primary-source boundary

CGY arXiv:2106.11668v2, Lemma 4.17, Theorem 4.18 and its full proof,
and Theorem 5.4 and its full proof were read directly for this step.
The product formula for the retained coefficient block and the
commutativity of Bongartz completion are their established results.
The additional theta interface here identifies the projected normal,
proves the exact face-polynomial substitution with preserved
coefficients, and checks the weighted translated theta label across
successive reductions. No representation F-polynomial theorem and
no Li--Pan result is used.
