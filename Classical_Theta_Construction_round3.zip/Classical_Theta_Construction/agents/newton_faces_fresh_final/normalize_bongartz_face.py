"""Normalize an optimized theta face to a nonnegative monomial root image.

Standard-library-only JSON CLI. Required keys: B, g, w, sequence.
All mutation indices are ZERO-BASED. Optional lower_vertices / lower_terms
must be in the returned NORMALIZED lower seed, not the original endpoint.
The algorithm returns that seed, its label, and the lower mutation list.

This constructs the face transform; it does not discover the lower theta
polynomial from its label. See BONGARTZ_MONOMIAL_FACE_THEOREM.md.
"""
from __future__ import annotations

from fractions import Fraction
from math import gcd, lcm
import json
import sys


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def symmetrizer(B):
    n = len(B)
    if not n or any(len(row) != n for row in B):
        raise ValueError("B must be a nonempty square matrix")
    if any(type(x) is not int for row in B for x in row):
        raise ValueError("B must be integral")
    if any(B[i][i] for i in range(n)):
        raise ValueError("B must have zero diagonal")
    d = [None] * n
    for start in range(n):
        if d[start] is not None:
            continue
        d[start] = Fraction(1)
        queue = [start]
        while queue:
            i = queue.pop()
            for j in range(n):
                b, c = B[i][j], B[j][i]
                if b == c == 0:
                    continue
                if b * c >= 0:
                    raise ValueError("B is not sign-skew-symmetric")
                value = -d[i] * Fraction(b, c)
                if d[j] is None:
                    d[j] = value
                    queue.append(j)
                elif d[j] != value:
                    raise ValueError("B is not skew-symmetrizable")
    denominator = lcm(*(x.denominator for x in d))
    integers = [int(x * denominator) for x in d]
    common = gcd(*integers)
    return [x // common for x in integers]


def mutate_matrix(E, k):
    return [
        [
            -E[i][j] if i == k or j == k else
            E[i][j] + max(E[i][k], 0) * max(E[k][j], 0)
            - max(-E[i][k], 0) * max(-E[k][j], 0)
            for j in range(len(E[0]))
        ]
        for i in range(len(E))
    ]


def mutate_label(E, label, k):
    a = label[k]
    return [
        -a if i == k else label[i] + max(E[i][k], 0) * a - E[i][k] * min(a, 0)
        for i in range(len(label))
    ]


def mutate_beta(B, beta, k):
    a = beta[k]
    return [
        -a if j == k else beta[j] + max(B[k][j], 0) * a - B[k][j] * min(a, 0)
        for j in range(len(beta))
    ]


def forward_history(B, g, w, sequence):
    n = len(B)
    E = [row[:] for row in B] + [[int(i == j) for j in range(n)] for i in range(n)]
    m, u, beta = g + [0] * n, [0] * n + [-x for x in w], [-x for x in w]
    history = [{"E": E, "m": m, "u": u, "beta": beta}]
    for k in sequence:
        a_plus = sum(u[i] * max(E[i][k], 0) for i in range(2 * n))
        a_minus = sum(u[i] * max(-E[i][k], 0) for i in range(2 * n))
        next_u = u[:]
        next_u[k] = min(a_plus, a_minus) - u[k]
        m, beta = mutate_label(E, m, k), mutate_beta(E[:n], beta, k)
        E, u = mutate_matrix(E, k), next_u
        if beta != [sum(E[i][j] * u[i] for i in range(2 * n)) for j in range(n)]:
            raise ArithmeticError("coordinate/root valuation inconsistency")
        history.append({"E": E, "m": m, "u": u, "beta": beta})
    return history


def check_invariants(C, Q, B, D, beta, a, J, A, h):
    """Exact internal certificate checks, using integers only."""
    n = len(B)
    if any(C[i][j] < 0 for i in range(n) for j in J):
        raise ArithmeticError("the complement C-columns lost nonnegativity")
    if [sum(C[i][j] * beta[i] for i in range(n)) for j in range(n)] != a:
        raise ArithmeticError("C^T beta != endpoint beta")
    for t, j in enumerate(J):
        if sum(C[i][j] * D[i] * A[i] for i in range(n)) != D[j] * h[t]:
            raise ArithmeticError("actual prefactor and lower label are incompatible")
    BC = [[sum(B[i][k] * C[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            if sum(C[k][i] * D[k] * BC[k][j] for k in range(n)) != D[i] * Q[i][j]:
                raise ArithmeticError("D Q != C^T D B C")
            if (D[i] * C[i][j]) % D[j]:
                raise ArithmeticError("D C D^-1 is not integral")


def normalize_face(B, g, w, sequence, include_trace=False):
    n = len(B)
    D = symmetrizer(B)
    if len(g) != n or len(w) != n:
        raise ValueError("g and w must have length n")
    if any(type(x) is not int for x in [*g, *w, *sequence]):
        raise ValueError("g, w, and mutation indices must be integral")
    if any(not 0 <= k < n for k in sequence):
        raise ValueError("mutation indices are zero-based and must be in range(n)")
    history = forward_history(B, g, w, sequence)
    final = history[-1]
    if any(x < 0 for x in final["beta"]):
        raise ValueError(f"endpoint is not optimized: beta={final['beta']}")
    a = final["beta"][:]
    J = [j for j in range(n) if a[j] == 0]
    C = [[int(i == j) for j in range(n)] for i in range(n)]
    Q, A = [row[:] for row in final["E"][:n]], final["m"][:]
    h = [A[j] for j in J]
    initial_lower_B = [[Q[i][j] for j in J] for i in J]
    initial_lower_h = h[:]
    lower_sequence, trace = [], []
    check_invariants(C, Q, final["E"][:n], D, final["beta"], a, J, A, h)
    for t in range(len(sequence), 0, -1):
        current = history[t]
        E, beta, k = current["E"], current["beta"], sequence[t - 1]
        b = beta[k]
        epsilon = 1 if b >= 0 else -1
        C_temp = [row[:] for row in C]
        C_temp[k] = [
            -C[k][j] + sum(max(epsilon * E[k][i], 0) * C[i][j] for i in range(n))
            for j in range(n)
        ]
        entry = {"ambient_from": t, "ambient_to": t - 1, "k": k, "beta_k": b}
        if b:
            v = A[k]
            A = [-v if i == k else A[i] + max(-epsilon * E[i][k], 0) * v for i in range(2 * n)]
            C = C_temp
            entry["kind"] = "strict"
        else:
            pivots = [j for j in J if all(C[i][j] == int(i == k) for i in range(n))]
            if len(pivots) != 1:
                raise ArithmeticError(f"expected a unique complementary pivot, got {pivots}")
            j = pivots[0]
            p = J.index(j)
            if D[j] != D[k] or h[p] != A[k]:
                raise ArithmeticError("tie pivot symmetrizer/label identity failed")
            A = mutate_label(E, A, k)
            lower_B = [[Q[i][l] for l in J] for i in J]
            h = mutate_label(lower_B, h, p)
            C = [
                [-C_temp[i][j] if l == j else C_temp[i][l] + C_temp[i][j] * max(Q[j][l], 0)
                 for l in range(n)]
                for i in range(n)
            ]
            Q = mutate_matrix(Q, j)
            lower_sequence.append(p)
            entry.update({"kind": "tie", "completion_pivot": j, "lower_pivot": p})
        check_invariants(C, Q, history[t - 1]["E"][:n], D, history[t - 1]["beta"], a, J, A, h)
        if include_trace:
            entry.update({"C": [row[:] for row in C], "prefactor_exponent": A[:], "lower_g": h[:]})
        trace.append(entry)
    p, S = A[n:], [[C[i][j] for j in J] for i in range(n)]
    if any(x < 0 for x in p):
        raise ArithmeticError("translation is negative; the supplied theta may not be finite")
    if [A[i] - g[i] for i in range(n)] != [dot(B[i], p) for i in range(n)]:
        raise ArithmeticError("prefactor difference does not lie in the principal root lattice")
    height = -dot(final["u"], final["m"])
    if dot(w, p) != height or any(sum(w[i] * S[i][j] for i in range(n)) for j in range(len(J))):
        raise ArithmeticError("affine image does not lie on the requested supporting hyperplane")
    completion_pivots = [J[pivot] for pivot in lower_sequence]
    canonical_sequence = list(sequence) + completion_pivots
    canonical_E, canonical_m = [row[:] for row in final["E"]], final["m"][:]
    for pivot in completion_pivots:
        if a[pivot] != 0:
            raise ArithmeticError("canonical endpoint extension is not valuation-zero")
        canonical_m = mutate_label(canonical_E, canonical_m, pivot)
        canonical_E = mutate_matrix(canonical_E, pivot)
    if canonical_E[:n] != Q or [canonical_m[j] for j in J] != h:
        raise ArithmeticError("constructed canonical endpoint disagrees with the reduced seed")
    if len(canonical_sequence) > 2 * len(sequence):
        raise ArithmeticError("canonical path length bound failed")
    return {
        "n": n, "rank": len(J), "J": J, "symmetrizer": D,
        "optimized_root_valuation": a, "face_height": height,
        "translation": p, "root_embedding": S,
        "lower_B": [[Q[i][j] for j in J] for i in J], "lower_g": h,
        "lower_symmetrizer": [D[j] for j in J], "lower_sequence": lower_sequence,
        "canonical_sequence": canonical_sequence,
        "canonical_B": Q, "canonical_full_label": canonical_m,
        "endpoint_lower_B": initial_lower_B, "endpoint_lower_g": initial_lower_h,
        "full_completion_C": C, "actual_prefactor_exponent": A,
        "steps": trace,
        "lower_input_convention": "returned normalized lower_B/lower_g; not the original endpoint seed",
        "dependencies": "Python standard library only",
    }


def affine_image(data, exponent):
    if len(exponent) != data["rank"] or any(type(x) is not int or x < 0 for x in exponent):
        raise ValueError("lower root exponent must be a nonnegative integer vector of normalized rank")
    return [p + dot(row, exponent) for p, row in zip(data["translation"], data["root_embedding"])]


def solve(payload):
    data = normalize_face(payload["B"], payload["g"], payload["w"], payload["sequence"], payload.get("include_trace", False))
    if "lower_vertices" in payload:
        if not payload["lower_vertices"]:
            raise ValueError("lower_vertices must be nonempty")
        data["face_vertices"] = sorted([affine_image(data, q) for q in payload["lower_vertices"]])
    if "lower_terms" in payload:
        terms = []
        for term in payload["lower_terms"]:
            coefficient = term["coefficient"]
            if type(coefficient) is not int or coefficient <= 0:
                raise ValueError("theta coefficients must be positive integers")
            terms.append({"exponent": affine_image(data, term["exponent"]), "coefficient": coefficient})
        data["face_terms"] = sorted(terms, key=lambda term: term["exponent"])
    return data


if __name__ == "__main__":
    stream = open(sys.argv[1]) if len(sys.argv) > 1 else sys.stdin
    try:
        print(json.dumps(solve(json.load(stream)), indent=2))
    except (ValueError, ArithmeticError, KeyError) as error:
        print(json.dumps({"error": str(error)}), file=sys.stderr)
        sys.exit(2)
    finally:
        if stream is not sys.stdin:
            stream.close()
