# A rank criterion for color genericity and actual-arrow boundedness

2026-11-13. Independent derivation during the adversarial review.

This strengthens and simplifies the parameter-selection step in
`../phase_descent_round1/COLOR_GENERIC_VALUATION_WINDOW.md`. It does not
replace the geometric work of that note by a numerical test. The proof
below uses its elementary projection-image calculation, reproduced here,
but does not assume its recession theorem.

## 1. Exact matrix statement

Let `E` have basis `e_0,e_1,...,e_r`, an alternating rational form `eta`,
and positively charged leaves

    beta_0=e_0,      beta_v=k_v e_color(v), k_v>0.

There is exactly one frame leaf. Put `alpha=sum beta_v`. An actual arrow
exists between `u,v` precisely when `eta(beta_u,beta_v)` is nonzero; its
multiplicity and orientation do not affect the following kernel statement.

Fix a rooted nonplanar full binary hierarchy `H`. For every internal support
`S`, put

    (v_S)_v = eta(beta_S,beta_v) if v is in S, and 0 otherwise.

Delete the frame row and let `M_H` have these columns. Let `U` be the image
of `ann(alpha)` in the frame-deleted leaf covector space, under

    mu -> (mu(beta_v))_(v != 0).

**Rank-recession lemma.** If `U` is contained in `image(M_H)`, then every
vector `a>=0` with `M_H a=0` has

    a_S>0  =>  all leaves in S have one original mutable color.       (1)

In particular, for every actual arrow `(u,v)`,

    sum_(S contains u,v) a_S = 0.                                   (2)

There is no assumption that a positive depth vector exists. Real
solvability for all original-color covectors is sufficient.

## 2. Choose an auxiliary covector for the proof only

For a nonzero cut pairing define

    Pi_(S,A)(phi) = phi - phi(A) eta(S,-)/eta(S,A).

There are finitely many compositions of these maps along nested support
chains of length at most the number of leaves. Choose an auxiliary
`nu in ann(alpha)` outside the kernel of every nonzero functional

    nu -> (L nu)(beta_C)

arising from those chains and support charges. Such a covector exists,
even with every mutable weight positive. This is the projection-generic
choice in the earlier note; it is used only to prove the matrix lemma.

The inclusion `U subset image(M_H)` provides a vector `t` of **real** depths
such that

    M_H t = - (nu(beta_v))_(v != 0).                              (3)

The proof does not require `t>=0`. This is what allows the matrix criterion
to replace projection-chain genericity in the actual algorithm.

## 3. Recursive elimination with real depths

Maintain a subtree with total charge `S`, an incoming covector `phi`, its
current depths `t_A`, and a nonnegative homogeneous solution `a_A`. The
leaf equations are

    phi(beta_v) + sum_(A contains v) t_A eta(beta_A,beta_v) = 0,
    sum_(A contains v) a_A eta(beta_A,beta_v) = 0.                 (4)

Initially these are (3) and `M_H a=0`. Every vector `v_A` has total row sum
zero, so restoring the omitted frame row is legitimate. Summing (4) over
a child `L` of `S=L disjoint-union R` gives

    phi(L)+t_S eta(S,L)=0,
    a_S eta(S,L)=0.                                              (5)

### A nonzero cut

If `eta(S,L) != 0`, then `a_S=0` and

    t_S=-phi(L)/eta(S,L),
    phi_new=Pi_(S,L)(phi).

Delete `S` and pass `phi_new` to both children. No sign condition on `t_S`
has been used. At the first split, the incoming image `ann(alpha)` maps
onto `ann(S,L)`. Thereafter retain a nondegenerate two-plane `P` containing
the current charge and incoming image `ann(P)`.

For completeness, `Pi_(S,L)` is injective on `ann(P)`: its possible kernel
is the line spanned by `eta(S,-)`, and that line is not in `ann(P)` because
`P` is nondegenerate and contains the nonzero vector `S`. Its image lies in
`ann(S,L)`; both spaces have codimension two. Thus the new image is exactly
`ann(S,L)`, and the new memory plane is nondegenerate.

### A zero cut

If `eta(S,L)=0`, then (5) implies `phi(L)=0`. By the auxiliary genericity
of `nu`, this vanishing is an identity on the entire incoming image.

At the root, this would put `L` in the line `Q alpha`. It is impossible:
one of the two nonempty children has frame coordinate zero, while `alpha`
has frame coordinate one and all charges have nonnegative coordinates.

Below the root, it puts `L` in `P`. Since `P` is nondegenerate and
`eta(S,L)=0`, it follows that

    L=lambda S,       R=(1-lambda) S,       0<lambda<1.            (6)

The strict inequalities use positivity of the charges, not positivity of
the depth vector. On the child supports,

    v_S|_L=lambda^(-1)v_L,
    v_S|_R=(1-lambda)^(-1)v_R.                                   (7)

Delete `S`, add `t_S/lambda` to the child's current depth at `L`, and add
`a_S/lambda` to the child's homogeneous coefficient. Do the analogous
operation at `R`. Keep `phi` and the old nondegenerate plane `P` unchanged.
If a child is a singleton, its column is zero and the added term is
discarded; (6) then already says that child is parallel to `S`.

These operations preserve (4) exactly. They preserve nonnegativity of the
homogeneous vector `a`, even if some real depths `t` are negative. Thus the
induction and all projection-image assertions remain valid.

## 4. Positive homogeneous coefficients cannot reach an interacting leaf

Take any original node `S` with `a_S>0`. In the recursive elimination above,
positive contributions arriving from ancestors can only increase its
current homogeneous coefficient. It therefore cannot be removed as a
nonzero cut, since (5) would require that coefficient to be zero.

It must be removed by (6)–(7), and it passes a positive homogeneous
coefficient to every nonsingleton child. Repeating the same argument, no
descendant can have a nonzero cut. Every descendant leaf is consequently a
positive multiple of the original charge `S`. Since the leaves are positive
multiples of distinct coordinate basis vectors, all leaves under `S` have
one original color. A support with more than one leaf cannot consist of
frame leaves, because there is only one frame leaf. Hence that color is
mutable. This proves (1), and alternating pairings vanish within a color,
which proves (2).

This completes the proof of the rank-recession lemma.

### The effective depth fibers are polytopes

A monochromatic support has `v_S=0`. Consequently the lemma gives the exact
identity

    ker(M_H) intersect R_>=0^n
      = span_>=0{unit vector at S : S is monochromatic}.          (9)

Delete these zero columns and call the resulting matrix `M_eff`. Every
nonempty fiber

    {t_eff>=0 : M_eff t_eff=b}

is a bounded polytope: its recession cone is zero. The original nonempty
fiber is exactly this polytope times an orthant indexed by the deleted
monochromatic nodes. These are collision-depth polytopes; no assertion
identifying them with a theta Newton polytope is intended.

The strict alternative for linear inequalities also supplies a rational
dual vector `u` with

    M_eff^T u >= 1.

Thus `sum t_eff <= u.b` simultaneously bounds every actual-arrow valuation,
because an actual arrow is contained in no monochromatic support. One dual
certificate per retained hierarchy is enough; separate programs for every
arrow objective are unnecessary. This is a direct simplification of the
uniform-window computation.

## 5. A smaller exact genericity algorithm

Write the mutable-color image as an explicit rational matrix `W`: its row
at leaf `v` has entry `k_v` in column `color(v)` and zero elsewhere. A
positive diagonal scaling of the columns is harmless; in particular one
may use `W D` so that primitive row target exponents are integral powers
`z^(i-1)`.

For every binary hierarchy, compute a rational basis of the left kernel
of `M_H`. For every basis vector `l`, form the row

    l^T W.                                                       (8)

Discard zero rows. Choose positive original-color weights avoiding the
zero set of every remaining row. This is finite and exact. With the power
curve

    mu(e_i)=D_i z^(i-1),
    mu(e_0)=-sum_i p_i D_i z^(i-1),

each retained row gives a nonzero rational polynomial in `z`. The least
integer `z>=2` that is not a root of any of them works. Clear denominators,
divide by the gcd, and normalize the first nonzero sign to deduplicate
the finite list if desired.

For such a chosen `mu`, feasibility `M_H t=-W mu` forces every row (8) to
be zero: otherwise the chosen `mu` would violate that left-kernel equation.
Thus every feasible hierarchy has `U subset image(M_H)`. The lemma applies,
and all subsequent LP-dual bounds and the full parameter-neighborhood
construction in the earlier window note follow unchanged.

This criterion can be considerably cheaper than enumerating projection
words. It uses the original graph and finite rational matrix operations;
it never asks for a theta coefficient.

## 6. Independent computation

`recession_rank_probe.py` implements a separate matrix/cone search. It never
uses projection images, parallel splits, or the absorption algorithm.
It tests exact ranks with FLINT, then solves a compact kernel-simplex LP.
Every accepted no-arrow-recession result is accompanied by an exactly
verified rational dual inequality `M_H^T u >= c`, where `c` is the sum of
all actual-arrow valuation objectives. An infeasible kernel simplex is
certified by `M_H^T u >= 1`.

The computation is a stress check of the proof, not its logical premise.
The JSON receipt records the final counts, seed, and any rejected numerical
certificate. Only the final exact-certificate run is the authoritative
receipt.
