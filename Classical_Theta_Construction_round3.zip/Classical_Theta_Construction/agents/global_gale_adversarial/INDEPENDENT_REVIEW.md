# Independent adversarial review of the global framed Gale construction

Date: 2026-11-13. Reviewer branch: `global_gale_adversarial`.

## Verdict

**PASS for the new finite-factor/Young-character bridge, under the stated
classical charged-graph hypotheses and the finite color-genericity condition.**

I independently reconstructed the collision-coordinate count, the
two-plane projection argument, the parallel-depth elimination, the
actual-arrow valuation bounds, the full-target finite flat family, and the
fixed-cycle normalization. I found no mathematical obstruction after the
corrections already present in the current drafts. The decisive new step
really is the uniform window, not finiteness at one fixed target.

The identification with theta coefficients uses the previously proved
one-frame identity and the signed cycle flow formula. I read their precise
statements and normalization in the prior `universal_tree_positive.md`;
this review does not claim a new proof of the external Argüz–Bousseau
general scattering theorem on which that earlier formula depends.

The result is a finite graph-defined algebraic-point model for each formal
coefficient, with a positive free-Young-orbit interpretation. It is not a
new elementary Dyck-path rule, and it does not yet give a uniform finite
Laurent support bound for every regular theta label.

## 1. Strong-generic collision count

The signs agree. For an arrow `u -> v`, the valuation contribution to the
Gale rows is negative at `u` and positive at `v`. Hence the cluster column
at leaf `i` is `eta(beta_S,beta_i)` and the equations are
`M_H t=-theta`. Summing over a child `L` gives
`theta(L)=t eta(L,R)`, exactly the earlier flow admission convention.

The anchored differences form a linear coordinate system because the
anchor-pair edges form a tree. A full binary positive-depth hierarchy makes
the leading form of each arrow difference a signed single anchor variable.
Thus the initial system is a monomial isogeny, rather than a sum of leading
terms that would invalidate the determinant count. The unimodular change
between cluster columns and least-common-ancestor columns is valid.

The determinant induction gives one factor `|eta(L,R)|` at every split.
Characteristic zero supplies reduced initial fibers and Hensel lifting.
Strong genericity excludes both rank-deficient hierarchies and
multifurcations; a coincidence of nonadjacent coordinates has fewer finite
depths and is likewise excluded in this strong-generic comparison fiber.
No acyclicity is used.

## 2. The original-color window is valid

The nonzero projection has a one-dimensional kernel in the full dual
space. At the first split it maps `ann(alpha)` onto the annihilator of a
nondegenerate two-plane. At subsequent splits its kernel does not intersect
the retained annihilator, because the current charge lies in that
nondegenerate plane. Dimension then gives the claimed image exactly.

At a zero-pairing split, genericity says the vanishing child functional is
identically zero on the incoming image. The child lies in the retained
plane and is orthogonal to the current charge, hence is a positive multiple
of that charge. Positivity follows from the coordinate-positive charges,
not from the depth parameters. The unique frame prevents this case at the
root.

The removal rule must act simultaneously on a feasible solution and on its
homogeneous nonnegative direction. It must leave the incoming covector and
its old plane unchanged. With these exact rules, the proof works: a
positive homogeneous coefficient propagates with positive factors until a
nonzero split would contradict its homogeneous cut equation. Therefore all
leaves below that coefficient have one color, so no actual arrow can be
affected.

I also proved a stronger matrix version in
`RANK_GENERICITY_AND_RECESSION.md`: inclusion of the entire color image in
`image(M_H)` is sufficient, even if a real depth solution has negative
entries. This gives a smaller exact generic-weight selector using left
kernels, and shows that the effective depth fibers are bounded polytopes
after deleting monochromatic zero columns.

The passage to a full leaf-parameter neighborhood is justified. Each
hierarchy image cone is finitely generated and closed. The finitely many
cones not containing the center can be avoided uniformly. On every
remaining cone a rational LP-dual certificate bounds actual-arrow
valuations for all nearby parameters, not merely at the central value.

The lower-bound proof using components of edges with valuation greater than
the minimum is also valid. A minimum-valued edge cannot have both endpoints
joined by a path of greater-valued edges, by the ultrametric inequality.
All boundary edges of such a component therefore have exactly the minimum
valuation, and a nonzero cut sum bounds it away from zero.

This reasoning only uses real valuations and exact linear equations, so it
applies over arbitrary completed residue fields of the analytic family.
It is not restricted to generic constant targets. The heuristic
substitution of an auxiliary parameter by `T^N` is not needed for the
rigorous proof once the affinoid argument is used.

## 3. Finiteness and flatness of the full target family

The displayed bounds on `x_v` and inverse arrow forms really do provide an
affinoid presentation over a full target polyannulus. The stronger uniform
window places every relative generator strictly inside its allowed radius.
Temkin's relative-interior definition and finite-map criterion apply
directly. A mere compactness assertion would not have been enough; the
draft uses the required strict margins.

Eliminating the target variables identifies the total source with an
analytic domain of the open coordinate configuration space. Therefore it
has regular local rings of the same pure dimension as the regular target
polyannulus. Since the map is finite, the local fiber dimension is zero;
the precise dimension equality in miracle flatness holds. This justifies
finite flatness and constant degree on the connected target.

Primary statements independently read:

* Temkin, *Introduction to Berkovich analytic spaces* (2010), Definition
  3.4.9, Remark 3.4.10, Fact 3.4.11(iv),
  <https://berkovich-2010.imj-prg.fr/lecture-notes/Temkin-lecture-notes.pdf>.
* Stacks Project, Lemma 10.128.1, tag 00R4, statement and proof,
  <https://stacks.math.columbia.edu/tag/00R4>.

These are standard older inputs. No 2026 positivity or moduli theorem is
needed in this step.

## 4. Every cycle restriction has its own flatness proof

The order of operations in the current assembly is correct: first take the
full independent target family; then impose targets fixed by a permutation;
then impose the coordinate equalities. This fixed source is closed in a
finite base change, hence finite. Its equations reduce to one original row
per permutation cycle. Since a cycle has only one original color, it
contains no actual arrows, and its configuration space is an open subset
of affine space with one coordinate per cycle. It is smooth and has the
same dimension as the fixed target polyannulus. Miracle flatness applies
again. It is not inferred from original-family flatness alone.

On a cycle of length `r_A`, the exponent of a row against another cycle is
`m_ij r_B / D_i`, which equals `M_AB/(r_A D_i)`. Raising this primitive row
to `r_A D_i` gives the ordinary packet row. The independent target power
map has degree `product_A r_A D_i`; there is no hidden gcd because the
frame row is omitted and the frame content is one. The degree identity
therefore gives the primitive count `T_lambda` at each fixed-cycle fiber.

## 5. Trace and positivity

The selected positive fiber is a full isolated finite factor of a regular
square map. Any positive-dimensional algebraic germ through a selected
point would remain in the strict positive analytic neighborhood, violating
the finiteness already proved. Clearing denominators by an invariant unit
preserves the square equations and their local algebras.

I checked the coordinatewise Hermite perturbation proof in
`YOUNG_FIXED_CYCLE_LENGTH_LEMMA.md`. The degree bound `n_i-1` is enough:
values at distinct equality blocks and derivatives at repeated blocks give
at most `n_i` conditions. Distinct stabilizer factors prevent mixing of
their normal standard representations. The restricted fixed-cycle systems
are square and have isolated special fibers, so their separate finite-free
deformations are justified by a regular-sequence argument.

Consequently the trace equals the fixed-scheme length, rather than the
dimension of an invariant subalgebra. After a generic small polynomial
perturbation, the algebra is a permutation module on actual tuples. Their
stabilizers are products of symmetric groups on equality blocks. The total
sign occurs once exactly on a free orbit and zero times on every nonfree
orbit. This is the precise positive interpretation of the old signed cycle
average.

The newer polynomial perturbation in the assembly is compatible with the
window: the added `T^N p_i(x_v)` only changes the target by a unit on the
positive coordinate domain. It removes the need for exponential series in
the defining model.

## 6. Fixed-target saturation and the rational staircase

The cut argument in `GALE_FIXED_TARGET_FINITE_FACTOR.md` is correct: after
saturating by the product of `T` and actual arrow forms, every ordinary cut
relation belongs to the ideal. At `T=0`, a proper component of the zero-arrow
graph has only nonzero boundary forms, contradicting its nonzero cut
weight. Thus the special fiber is supported at the origin and is finite.

Basis lifting makes its completion finite over the DVR. Saturation and flat
completion make `T` and the arrow product regular. Only after passing to
the fraction **field** is the latter automatically a unit in the finite
Artin algebra. The completed finite algebra is an open-and-closed factor
of the original square system and retains all local multiplicities.

The assembly initially included an unnecessary warning that saturation
could retain nonzero special-fiber centers. That warning was too broad for
the present cut-generic positive chamber and has been corrected using the
preceding cut proof. No extra local support selection is needed here.

Finally, exactness of the alternating projector and the Vandermonde
divisibility theorem give

    A_0^sign = Delta R / (J_0 intersect Delta R)
             isomorphic to R / ((J_0:Delta) intersect R).

The latter is zero-dimensional. A Gröbner staircase is therefore a finite
explicit basis whose size is the theta coefficient. Its order dependence
and algebraic nature should remain explicit; this is not by itself a
canonical graded or direct lattice-point model.

## 7. Independent computational challenge

The program `recession_rank_probe.py` uses exact FLINT ranks, a kernel-simplex
LP, and exact rational dual verification. It deliberately contains none of
the projection, parallelity, or absorption rules used by the proof.

The final run checked 16,000 random charged hierarchies with one frame,
2–9 mutable leaves, 1–5 original colors, positive packet contents up to 3,
and arbitrary skew entries from -4 to 4:

* 6,678 matrices were nonsingular.
* 3,743 excluded the full color image by an exact rank test.
* 5,562 contained the color image and had only nonedge nonnegative recession.
* 17 contained the color image and had no nonzero nonnegative kernel.

Every LP conclusion in the last two groups has an exact rational dual
certificate verified by the program. No counterexample or uncertified LP
case occurred. These checks challenge the stronger matrix lemma; they are
not used as a substitute for its proof.

## 8. Limitations that remain mathematical, not missing details of this bridge

The new construction is coefficientwise. It does not decide a priori where
the support of an arbitrary theta label stops, nor does it identify theta
with every other positive or triangular basis. Its point set and staircase
depend on finite genericity and perturbation choices. Their cardinality is
intrinsic by the proved character identity; no canonical choice-free set
bijection has been established. The earlier one-frame and flow identities
remain the external algebraic interface to theta functions.

None of these limitations reopens the finite flat symmetry gap that was the
subject of this review.
