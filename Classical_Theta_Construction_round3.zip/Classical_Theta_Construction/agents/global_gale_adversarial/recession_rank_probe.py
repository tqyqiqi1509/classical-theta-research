"""Independent matrix/cone probe for the charged Gale valuation bound.

This deliberately does NOT implement projection or depth absorption.
It asks whether a hierarchy matrix whose image contains the whole color
parameter space can have a nonnegative kernel vector increasing an actual
arrow length. Exact ranks use FLINT; LP only searches the compact kernel
simplex. Any candidate violation is rationalized and checked exactly.
"""
from __future__ import annotations

from fractions import Fraction
from pathlib import Path
from random import Random
import json
import time

import numpy as np
from flint import fmpq_mat
from scipy.optimize import linprog


def random_tree(leaves, rng):
    if len(leaves) == 1:
        return leaves[0]
    order = list(leaves)
    rng.shuffle(order)
    split = rng.randrange(1, len(order))
    return (random_tree(order[:split], rng), random_tree(order[split:], rng))


def clusters(tree):
    if isinstance(tree, int):
        return {tree}, []
    left, lc = clusters(tree[0])
    right, rc = clusters(tree[1])
    whole = left | right
    return whole, [sorted(whole)] + lc + rc


def check_one(colors, charges, skew, tree):
    n = len(colors) - 1
    _, supports = clusters(tree)
    pair = [[charges[u] * charges[v] * skew[colors[u]][colors[v]]
             for v in range(n+1)] for u in range(n+1)]
    # Delete frame row; every column sums to zero in all rows.
    mat = [[sum(pair[u][v] for u in support) if v in support else 0
            for support in supports] for v in range(1, n+1)]
    width = len(skew)-1
    color_image = [[charges[v] if colors[v] == c else 0
                    for c in range(1, width+1)] for v in range(1, n+1)]
    rank = fmpq_mat(mat).rank()
    if rank == n:
        return 'nonsingular', None
    augmented = [row + image for row, image in zip(mat, color_image)]
    if fmpq_mat(augmented).rank() != rank:
        return 'color_image_excluded', None
    objective = [sum(1 for u in support for v in support
                     if u < v and pair[u][v] != 0) for support in supports]
    aeq = np.array(mat + [[1]*n], dtype=float)
    beq = np.array([0]*n + [1], dtype=float)
    ans = linprog(-np.array(objective, dtype=float), A_eq=aeq, b_eq=beq,
                  bounds=(0, None), method='highs')
    if ans.status == 2:
        cert = linprog(np.zeros(n), A_ub=-np.array(mat, dtype=float).T,
                       b_ub=-np.ones(n), bounds=[(None,None)]*n, method='highs')
        if cert.success:
            for denominator in (10**5,10**8,10**12):
                dual = [Fraction(float(v)).limit_denominator(denominator) for v in cert.x]
                if all(sum(Fraction(mat[i][j])*dual[i] for i in range(n)) >= 1 for j in range(n)):
                    return 'no_positive_kernel_exact_dual', None
        return 'UNVERIFIED_INFEASIBILITY', {'matrix':mat}
    if not ans.success:
        return 'LP_failure', {'message': ans.message, 'status': ans.status}
    if -ans.fun < 1e-8:
        for denominator in (10**5,10**8,10**12):
            dual = [Fraction(float(-v)).limit_denominator(denominator)
                    for v in ans.eqlin.marginals[:n]]
            if all(sum(Fraction(mat[i][j])*dual[i] for i in range(n)) >= objective[j]
                   for j in range(n)):
                return 'only_nonedge_recession_exact_dual', None
        return 'UNVERIFIED_ZERO_OPTIMUM', {'matrix':mat, 'objective':objective,
            'dual_float':ans.eqlin.marginals.tolist()}
    rat = [Fraction(float(v)).limit_denominator(10**6) for v in ans.x]
    exact = all(sum(Fraction(a)*b for a,b in zip(row,rat)) == 0 for row in mat)
    exact &= all(v >= 0 for v in rat) and sum(rat) == 1
    exact &= sum(a*b for a,b in zip(objective,rat)) > 0
    return ('COUNTEREXAMPLE' if exact else 'UNVERIFIED_LP_CANDIDATE'), {
        'colors': colors, 'charges': charges, 'skew': skew, 'tree': tree,
        'supports': supports, 'matrix': mat, 'rank': rank,
        'objective': objective, 'kernel': [str(v) for v in rat],
        'exact_verified': exact}


def main():
    started = time.time()
    rng = Random(21142026)
    counts = {}
    examples = []
    total = 16000
    for trial in range(total):
        n = rng.randrange(2, 10)
        r = rng.randrange(1, min(5, n)+1)
        colors = [0] + list(range(1, r+1)) + [rng.randrange(1, r+1) for _ in range(n-r)]
        tail = colors[1:]
        rng.shuffle(tail)
        colors[1:] = tail
        charges = [1] + [rng.randrange(1, 4) for _ in range(n)]
        skew = [[0]*(r+1) for _ in range(r+1)]
        for i in range(r+1):
            for j in range(i+1, r+1):
                skew[i][j] = rng.randrange(-4, 5)
                skew[j][i] = -skew[i][j]
        tree = random_tree(list(range(n+1)), rng)
        status, data = check_one(colors, charges, skew, tree)
        counts[status] = counts.get(status, 0) + 1
        if data:
            examples.append(data)
            break
    report = {
        'input_family': 'charged leaves with unique frame; arbitrary integer original skew form',
        'seed': 21142026, 'requested_trials': total,
        'actual_trials': sum(counts.values()), 'counts': counts,
        'independence': 'exact matrix ranks plus kernel-simplex LP; every accepted LP result has an exact rational dual certificate; no projection/absorption code',
        'tested_matrix_statement':
          'If image(M_H) contains the full color parameter space, every nonnegative kernel vector changes only nonedge valuations.',
        'proof_file': 'RANK_GENERICITY_AND_RECESSION.md',
        'counterexamples_or_failures': examples,
        'wall_seconds': round(time.time()-started, 3),
    }
    path = Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
