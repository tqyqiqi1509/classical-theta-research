# Independent review: weighted Q Bézout and graph-density radius

2026-11-13. Classical skew-symmetrizable cluster data. Reviewer branch:
`weighted_bezout_review`.

## Verdict and exact dependency

**PASS, conditional on the previously proved global Q positive-factor
identity and its strict affinoid valuation window.** The new coefficient
bound does not require a new Morse perturbation. In particular, its proof
does not multiply the ranks of coupled one-color factorization algebras.
It applies to any rank/cut-generic signed endpoint, not just the initial
positive endpoint.

Write

\[
\alpha_i=[g_i]_++\sum_j[B_{ij}]_+p_j,\qquad
\beta_i=[-g_i]_++\sum_j[-B_{ij}]_+p_j,\qquad
d_i=\max(\alpha_i,\beta_i).
\]

For the coefficient \(a_{g,U}(p)\), the asserted result is

\[
0\le a_{g,U}(p)\le\prod_i\binom{d_i}{p_i}.\tag{1}
\]

The convention is \(\binom d0=1\), and \(\binom dp=0\) for \(p>d\).
The case \(p=0\) has coefficient one. All other cases are covered below.

## 1. Why the selected Q factor is an isolated algebraic factor

Over an algebraic closure of the Laurent-series field, the Q equations
are the \(n=\sum_i p_i\) coefficients of

\[
F_i(z)\bmod Q_i(z),\qquad
F_i=T^{[a_i]_+}A_i-T^{[-a_i]_+}E_i,
\]

in the same number \(n\) of coefficient variables. The signed endpoint
has \(a_i\ne0\) on every active color. The required selected factor is
the locus whose Q roots have positive valuation and whose actual-arrow
resultants and frame factors are nonzero.

There is a particularly precise algebraic way to see that this is an
isolated factor. Let

\[
C=\mathbb Q[T,c]/(J:(TS)^\infty),\qquad A=\widehat C^{\,(T)}.
\]

The existing global theorem gives finite-dimensional \(C/TC\),
T-torsion-freeness, and the actual-arrow unit property after inverting T.
The completion A is finite over \(\mathbb Q[[T]]\): lifts of a basis of
\(C/TC\) generate it by the complete Nakayama argument. It is
T-torsion-free, hence finite free. Set

\[
C'=\mathbb Q[[T]]\otimes_{\mathbb Q[T]}C.
\]

This is Noetherian, and its T-adic completion is A. The completion map
\(C'\to A\) is flat. It is also surjective: the same finitely many basis
lifts belong to C', and all their \(\mathbb Q[[T]]\)-linear combinations
belong to its image. A finitely presented flat quotient of a ring is the
quotient by an idempotent ideal; here the kernel is finitely generated
because C' is Noetherian. Therefore A is a direct factor of C'. Inverting
T shows that \(A[1/T]\) is an actual Artin direct factor of the saturated
remainder system over \(\mathbb Q((T))\). Since S is a unit on this
factor, its local algebras are the local algebras of the original
unsaturated remainder equations. Its length is the theta coefficient.

For comparison, the analytic argument reaches the same conclusion.
The existing valuation-window theorem gives strict bounds on every
selected point after enlarging the affinoid inequalities. Consequently a
small analytic neighborhood of any such point belongs to the same open
root-coordinate conditions. In that neighborhood the finite selected
factor is the full polynomial Q zero set, rather than a quotient obtained
by imposing an additional equation. Thus its local dimension is zero and
its local Artin algebra equals the algebraic local Artin algebra of the
remainder system. Completion of a zero-dimensional local algebra does
not change it.

One can also check dimension via the finite map from ordered roots to
monic coefficients: every Q solution lifts to ordered roots satisfying
the original Gale row equations. A positive-dimensional Q germ would
lift to a positive-dimensional Gale germ in the strict selected affinoid,
contradicting finiteness there. Actual-arrow localization is harmless at
these points, since its denominator is a unit.

The Q/sign compression and the finite-flat identity identify the sum of
these local lengths with \(a_{g,U}(p)\). No discriminant localization is
made. Repeated roots and nilpotents remain in this length.

If \(p_i>d_i\), a monic Q polynomial of degree \(p_i\) cannot divide
\(F_i\). Indeed, the latter is nonzero of degree \(d_i\): when the two
monic product degrees are equal, its leading coefficient is
\(T^{[a_i]_+}-\epsilon_iT^{[-a_i]_+}\ne0\), and otherwise its top
coefficient is a nonzero Laurent monomial. Therefore there are no
selected solutions. Henceforth assume \(p_i\le d_i\) on each active
color.

## 2. The weighted-degree calculation

Assign weight one to \(z\), and weight \(k\) to \(c_{i,k}\). Then
\(Q_i=z^{p_i}+c_{i,1}z^{p_i-1}+\cdots+c_{i,p_i}\) is homogeneous of
weight \(p_i\). The two products \(A_i,E_i\) are homogeneous of weights
\(\alpha_i,\beta_i\). Coefficients involving \(T\) have weight zero.

Division by a monic homogeneous polynomial preserves the total weighted
filtration. More explicitly, replacing \(z^{p_i}\) by
\(-\sum_{l=1}^{p_i}c_{i,l}z^{p_i-l}\) preserves the weight of every
monomial. Thus if

\[
F_i\bmod Q_i=\sum_{k=0}^{p_i-1}r_{i,k}(c)z^k,
\]

then

\[
\operatorname{wdeg}r_{i,k}\le d_i-k.\tag{2}
\]

This is a simultaneous grading on all colors. It does not assume that
the other Q polynomials are constant, and cyclic coupling introduces no
extra degree.

## 3. Weighted Bézout including ramification and multiplicity

Here is the precise elementary reduction required. Let \(f_1,\ldots,f_n\)
be polynomials in \(c_1,\ldots,c_n\), with positive variable weights
\(w_j\) and weighted-degree bounds \(m_l\). Let \(Z\) be any finite
union of isolated local components of their zero scheme. Then

\[
\operatorname{length}Z\le
\frac{\prod_l m_l}{\prod_jw_j}.\tag{3}
\]

To prove it, use the map

\[
c_j=u_j^{w_j}.
\]

The polynomial ring in \(u\) is finite free over the polynomial ring in
\(c\), with basis \(u^e\), \(0\le e_j<w_j\). Hence the inverse image
of \(Z\) has length exactly \((\prod_jw_j)\operatorname{length}Z\).
This statement holds on coordinate hyperplanes, at branch points, and
for nonreduced schemes. Each inverse-image local component is still
isolated because the map is finite. The pulled-back polynomial \(f_l\)
has ordinary total degree at most \(m_l\).

Affine Bézout bounds the sum of the intersection multiplicities of
isolated solutions of \(n\) equations in affine \(n\)-space by the
product of their degrees. At an isolated solution the ambient local ring
is regular of dimension \(n\), and these \(n\) equations form a system
of parameters and therefore a regular sequence. Consequently that
intersection multiplicity is the local quotient length used here. Apply
ordinary Bézout to the pullback and divide by \(\prod_jw_j\). This proves
(3), without any assertion about positive-dimensional components
elsewhere in the whole polynomial zero set.

For the Q equations, \(w_{i,l}=l\), and (2) gives

\[
\frac{\prod_i\prod_{k=0}^{p_i-1}(d_i-k)}
     {\prod_i\prod_{l=1}^{p_i}l}
=\prod_i\binom{d_i}{p_i}.
\]

Combining with Section 1 proves (1). The numerator and denominator here
are degrees of one coupled polynomial system and its finite free cover;
they are not products of independently chosen local solutions.

**Primary source checked:** Pinaki Mondal, *How many zeroes? Counting
solutions of systems of polynomials via toric geometry at infinity*,
author-hosted introduction, Theorems I.2 and I.4, pp. 2–3. The preceding
problem statement explicitly counts isolated solutions with intersection
multiplicity. Theorem I.2 is the ordinary affine bound, and I.4 gives the
positive-weight bound. URL:
https://pinakimondal.org/wp-content/uploads/2021/12/p1_to_16.pdf .
The proof above provides the particular reduction used here; no claim of
novelty is made for weighted Bézout itself.

## 4. Graph-density and clique-number convergence bounds

Let \(C_{ij}=|B_{ij}|\), including \(C_{ii}=0\), let
\(G=\max_i|g_i|\), and define

\[
\kappa_B=\max_{t\ge0,\ \sum t_i=1}t^TCt.
\]

For \(n=|p|>0\) and \(t=p/n\), (1) gives

\[
a_{g,U}(p)
\le\frac{\prod_i(G+n(Ct)_i)^{p_i}}{\prod_i p_i!}
\le\frac{(G+\kappa_Bn)^n}{\prod_i p_i!}.\tag{4}
\]

The second inequality is weighted arithmetic-geometric mean with weights
\(t_i\); factors with \(t_i=0\) are omitted. Thus the nonsymmetry of
\(C\) in the skew-symmetrizable case is harmless: only its symmetric
part contributes to \(t^TCt\).

With \(s=\sum_i|z_i|\), summing (4) over \(|p|=n\) yields

\[
\sum_{|p|=n}a_{g,U}(p)|z|^p
\le \frac{(G+\kappa_Bn)^n}{n!}s^n.
\]

Consequently every fixed label and every generic endpoint series
converges absolutely and locally uniformly on

\[
s<\frac1{e\kappa_B}.\tag{5}
\]

If \(B=0\), then \(\kappa_B=0\), and the majorant is \(e^{Gs}\), so
the coefficient series are entire. For nonzero \(B\), \(\kappa_B>0\).
For \(t=s e^{\kappa_Bt}\) on the branch \(t(0)=0\), the scalar
majorant is exactly

\[
\sum_{n\ge0}\frac{(G+\kappa_Bn)^n}{n!}s^n
=\frac{e^{Gt}}{1-\kappa_Bt}.
\]

This identity is the standard rooted-tree/functional-digraph series and
can alternatively be proved by Lagrange inversion.

Let \(\Gamma\) be the undirected support graph of \(B\), let
\(b=\max|B_{ij}|\), and let \(\omega\) be its clique number. Since
\(C\le bA_\Gamma\) entrywise, Motzkin–Straus gives

\[
\kappa_B\le b(1-1/\omega).
\]

Here the adjacency quadratic form counts each unordered edge twice;
this is why the factor \(1/2\) in the original theorem is absent. Thus
the ball with radius \(1/[eb(1-1/\omega)]\) is a valid, possibly smaller
ball than (5). Triangle-free nonempty support gives the concrete radius
\(2/(eb)\). These are sufficient radii, not asserted optimal radii.

**Primary antecedent:** Motzkin–Straus (1965), *Maxima for graphs and a new
proof of a theorem of Turán*, Theorem 1, DOI 10.4153/CJM-1965-053-6. The
application to the Q coefficient bound is the proposed consequence; the
graph theorem and the AM–GM step are old elementary inputs.

## 5. Rejected stronger inference

This proof does not yield the replacement of \(d_i\) by the outgoing
degree \(\beta_i\) for arbitrary signed endpoints. The explicit signed
A2 counterexample recorded by `q_support_round2` has selected local
one-color ranks one but total length \(M\). It is consistent with (1):
the maximum degrees are \(M\) and one. The new proof counts the actual
coupled remainder equations and therefore retains that multiplicity.

The original polynomial-row Morse proposal is also mathematically
plausible under the enlarged-affinoid unit bound, but it is unnecessary
for this theorem. Removing that extra deformation makes the argument
shorter and avoids having to reprove equivariant transversality for a
different perturbation family.
