"""Universal balanced-cutoff majorants, not special theta examples.

T_n(p) is the maximal recursive balanced-tree count with terminal
weight one and the cutoff n <= M p^2.  The same recursion counts every
admissible degree assignment and tracks its maximum active-node count.
"""
from pathlib import Path
from functools import lru_cache
from math import isqrt
import json, time


def floor_bmp(M,p):
    # floor(p + 2 p sqrt(M) + 2 p sqrt(2M)) evaluated with an exact
    # rational enclosure and then certified by interval separation.
    scale=10**30
    def sqrt_interval(x):
        lower=isqrt(x*scale*scale)
        return lower,lower+1
    a,b=sqrt_interval(M);c,d=sqrt_interval(2*M)
    lo=(p*scale+2*p*a+2*p*c)//scale
    hi=(p*scale+2*p*b+2*p*d)//scale
    assert lo==hi,(M,p,lo,hi)
    return lo


def run(nmax=1024,pmax=80):
    start=time.time();allrows=[];cells=0;positive=0;node_checks=0
    for M in [1,2,4,9]:
        tables=[[1]+[0]*pmax for _ in range(nmax+1)]
        active=[[-1]*(pmax+1) for _ in range(nmax+1)]
        tables[1]=[1]*(pmax+1);active[1]=[0]+[1]*pmax
        integer_bounds=[0]+[2**(p-1)*(4**(floor_bmp(M,p)+1)-4)//3 for p in range(1,pmax+1)]
        largest_active_ratio=(0,1);worst=None
        for n in range(1,nmax+1):
            if n>1:
                left,right=n//2,n-n//2
                active[n][0]=0
                for p in range(1,pmax+1):
                    if n>M*p*p:continue
                    count=0;nodes=-1
                    for q in range(p+1):
                        if tables[left][q] and tables[right][p-q]:
                            count+=tables[left][q]*tables[right][p-q]
                            nodes=max(nodes,1+active[left][q]+active[right][p-q])
                    tables[n][p]=count;active[n][p]=nodes
            for p in range(1,pmax+1):
                cells+=1
                if n>M*p*p:assert tables[n][p]==0
                if not tables[n][p]:continue
                positive+=1
                assert active[n][p]<=floor_bmp(M,p),(M,n,p,active[n][p])
                assert tables[n][p]<=integer_bounds[p],(M,n,p,tables[n][p])
                node_checks+=1
                if active[n][p]*largest_active_ratio[1]>largest_active_ratio[0]*p:
                    largest_active_ratio=(active[n][p],p);worst=(n,p)
        # Brute-force terminal assignments independently verify the DP,
        # including the locations selected by left/right coding.
        brute_checks=0
        def comps(total,parts):
            if parts==1:
                yield (total,);return
            for x in range(total+1):
                for rest in comps(total-x,parts-1):yield (x,)+rest
        def valid_and_nodes(ds):
            p=sum(ds);n=len(ds)
            if not p:return True,0
            if n>M*p*p:return False,0
            if n==1:return True,1
            a,la=valid_and_nodes(ds[:n//2]);b,lb=valid_and_nodes(ds[n//2:])
            return a and b,1+la+lb
        for n in range(1,9):
            for p in range(1,9):
                count=0;nodes=-1
                for ds in comps(p,n):
                    good,L=valid_and_nodes(ds)
                    if good:count+=1;nodes=max(nodes,L)
                assert count==tables[n][p],(M,n,p,count,tables[n][p])
                assert nodes==active[n][p],(M,n,p,nodes,active[n][p])
                brute_checks+=1
        # Store a large independent-plugin audit slice, not all huge ints.
        samples=[]
        for n in list(range(1,25))+[31,32,33,63,64,65,127,128,129,255,256,257,511,512,513,1023,1024]:
            for p in [1,2,3,4,5,8,12,16,24,32]:
                samples.append([n,p,str(tables[n][p]),active[n][p]])
        row=dict(M=M,nmax=nmax,pmax=pmax,brute_assignment_checks=brute_checks,
                 largest_active_nodes_per_degree=list(largest_active_ratio),witness=worst,samples=samples)
        allrows.append(row)
        print(json.dumps({k:v for k,v in row.items() if k!='samples'}),flush=True)
    report=dict(status='PASS',coefficient_cells=cells,positive_cells=positive,
                active_node_bound_checks=node_checks,runs=allrows,seconds=time.time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='runs'}),flush=True)

if __name__=='__main__':run()
