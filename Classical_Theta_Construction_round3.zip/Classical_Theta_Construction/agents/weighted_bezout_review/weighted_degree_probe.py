"""Independent exact weighted-remainder and ramified-length checks.

The theorem is proved in INDEPENDENT_REVIEW.md.  These tests challenge
cyclic coupling and the use of nonreduced/ramified factors in that proof.
"""
from pathlib import Path
import sys, json, random, time
from math import factorial, comb
import sympy as s

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from graph_gale_staircase import standard_basis


def run(trials=240):
    started=time.time();rng=random.Random(2611132257)
    z=s.Symbol('z');checks=0;systems=[];zero_rows=0
    for trial in range(trials):
        r=1+trial%4
        D=[rng.randint(1,3) for _ in range(r)]
        B=[[0]*r for _ in range(r)]
        for i in range(r):
            for j in range(i+1,r):
                v=rng.choice([-1,0,0,1])
                B[i][j]=D[j]*v; B[j][i]=-D[i]*v
        p=[rng.randint(0,2) for _ in range(r)]
        while sum(p)>6:p[rng.choice([i for i in range(r) if p[i]])]-=1
        if not any(p):p[0]=1
        g=[rng.randint(-3,3) for _ in range(r)]
        variables=[];weights=[];Q=[]
        for i,pi in enumerate(p):
            ci=s.symbols(f'c{i}_1:{pi+1}')
            variables.extend(ci);weights.extend(range(1,pi+1))
            Q.append(z**pi+sum(c*z**(pi-k) for k,c in enumerate(ci,1)))
        rows=[]
        for i,pi in enumerate(p):
            if not pi:continue
            alpha=max(g[i],0)+sum(max(B[i][j],0)*p[j] for j in range(r))
            beta=max(-g[i],0)+sum(max(-B[i][j],0)*p[j] for j in range(r))
            Ai=z**max(g[i],0)*s.prod(Q[j]**max(B[i][j],0) for j in range(r))
            Ei=(-1)**beta*z**max(-g[i],0)*s.prod(Q[j]**max(-B[i][j],0) for j in range(r))
            Fi=s.expand(2*Ai-3*Ei)
            rem=s.Poly(s.rem(Fi,Q[i],z),z)
            d=max(alpha,beta)
            for k in range(pi):
                f=s.expand(rem.nth(k))
                if f==0:
                    zero_rows+=1;continue
                mon=s.Poly(f,*variables).monoms()
                wd=max(sum(a*w for a,w in zip(m,weights)) for m in mon)
                assert wd<=d-k,(B,g,p,i,k,d,wd,str(f))
                # Independently form the power-cover polynomial and compute
                # its ordinary degree, including coordinate-zero branches.
                u=s.symbols(f'u0:{len(variables)}')
                lifted=f.subs({c:uj**w for c,uj,w in zip(variables,u,weights)},simultaneous=True)
                od=s.Poly(lifted,*u).total_degree()
                assert od==wd
                checks+=1; rows.append([i,k,d-k,wd])
        systems.append(dict(B=B,D=D,g=g,p=p,rows=rows))
        if (trial+1)%40==0:
            print(json.dumps(dict(systems=trial+1,degree_checks=checks,seconds=time.time()-started)),flush=True)

    ramified=[]
    for pi in range(1,4):
        for degree in range(pi,pi+4):
            c=s.symbols(f'c1:{pi+1}');u=s.symbols(f'u1:{pi+1}')
            Q=z**pi+sum(ci*z**(pi-k) for k,ci in enumerate(c,1))
            rem=s.Poly(s.rem(z**degree,Q,z),z)
            equations=[rem.nth(k) for k in range(pi)]
            length=len(standard_basis(s.groebner(equations,*c,order='grevlex')))
            pull=[f.subs({ci:ui**k for k,(ci,ui) in enumerate(zip(c,u),1)},simultaneous=True) for f in equations]
            lift_length=len(standard_basis(s.groebner(pull,*u,order='grevlex')))
            assert length==comb(degree,pi)
            assert lift_length==factorial(pi)*length
            ramified.append(dict(p=pi,d=degree,length=length,lift_length=lift_length,cover_rank=factorial(pi),passed=True))
    report=dict(status='PASS',systems=trials,nonzero_remainder_degree_checks=checks,
                zero_remainder_coefficients=zero_rows,ramified_nonreduced_cases=ramified,
                elapsed_seconds=time.time()-started,cases=systems)
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'}),flush=True)

if __name__=='__main__':run()
