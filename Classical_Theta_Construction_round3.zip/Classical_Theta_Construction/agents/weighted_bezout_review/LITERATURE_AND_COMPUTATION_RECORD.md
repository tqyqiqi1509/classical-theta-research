# Literature and computation record: weighted Q branch

Date: 2026-11-13, 22:49–23:00 UTC.

## General route outcomes

1. **Successful.** Polynomial-row Morse perturbation would avoid the old
   outgoing-denominator degree penalty. On review, this extra deformation
   is unnecessary: the unperturbed Q positive factor is already an
   isolated Artin factor of the actual remainder system. Its weighted
   degrees give the binomial product directly by a finite free power
   cover and ordinary affine Bézout.
2. **Successful.** The zero diagonal of \(|B|\) permits the graph-density
   constant \(\kappa_B\). Weighted AM–GM and the original Motzkin–Straus
   theorem give the explicit all-label, all-endpoint convergence radius.
3. **Successful analytic corollary.** Binomial entropy gives a larger
   computable logarithmically convex sufficient domain depending only
   on B. This is a consequence of the bound, not an exact coefficient
   formula or an assertion of optimal analytic continuation.
4. **Not justified and not used.** Multiplying one-color Grassmann ranks
   would give a stronger outgoing-only bound. Cyclic dependence prevents
   that argument. The signed A2 counterexample of `q_support_round2`
   disproves such a bound for arbitrary endpoints and is consistent with
   the proved maximum-degree bound.

## Primary-source checks

- Pinaki Mondal, *How many zeroes?*, author-hosted introduction:
  https://pinakimondal.org/wp-content/uploads/2021/12/p1_to_16.pdf .
  Read the affine isolated-solutions problem statement and Theorems I.2
  and I.4, including the positive-weight hypothesis and multiplicity
  convention. **Useful; accepted as standard intersection-theoretic
  input.** No claim was made that weighted Bézout is new.
- Motzkin–Straus (1965), DOI 10.4153/CJM-1965-053-6, original Theorem 1
  and its proof, pp. 533–534. Checked that the original form sums each
  unordered edge once, so the adjacency-matrix quadratic form has twice
  that value. **Useful; accepted.** It is applied here only to bound
  \(\max_\Delta t^T|B|t\).
- Focused searches for cluster-theta coefficient Bézout/binomial
  convergence bounds did not identify the displayed maximum-degree
  bound or graph-density radius in an earlier paper. Search results
  were mostly unrelated classical theta/Lovász-theta material. This is
  **limited negative search evidence**, not a proof of novelty.
- Search surfaced arXiv:2611.09357 on hypergraph Motzkin–Straus analogues.
  **Not useful to this ordinary-graph argument; not used and not
  mathematically audited.** Its 2026 metadata alone was not treated as
  a theorem input.
- Existing 2026 theta reciprocity/analytic sources remain covered by
  the root's broader literature log. No new 2026 theorem is used in
  this branch.

## Exact computations

`weighted_degree_probe.py` uses deterministic seed 2611132257 and
constructs 240 independent systems of ranks 1–4, both skew and valued
skew-symmetrizable, including cyclic couplings. It performs actual
symbolic monic polynomial remainders, rather than inferring degrees from
the claimed formula.

- 607 nonzero remainder coefficients: weighted degree at most \(d_i-k\).
- Each is independently pulled back by \(c_{i,l}=u_{i,l}^l\); ordinary
  degree equals its directly computed weighted degree.
- 15 zero remainder coefficients, recorded separately.
- 12 confluent factorization schemes \(Q\mid z^d\), with p=1,2,3 and
  d=p,...,p+3: Gröbner staircases have length \(\binom dp\), and the
  power-cover schemes have length exactly \(p!\binom dp\). These cases
  are deliberately nonreduced and ramified, testing the point where a
  reduced-point-only Bézout argument would be insufficient.

Python exact arithmetic: **all PASS**. Wolfram plugin then independently
performed all 240 remainder constructions, all 607 weighted degree
checks, and all 607 power substitutions: **all PASS**. The precise
Wolfram input and returned result are saved beside this record.

These checks validate the algebraic implementation and challenge the
cyclic/ramification details. The general theorem is proved separately in
`INDEPENDENT_REVIEW.md`; finite computations do not establish it by
themselves.

## Second review: universal polynomial-sparsity mechanism

The root then requested an independent review of the new whole-sequence
balanced-tree pressure proof. The written review is
`DYADIC_PRESSURE_INDEPENDENT_REVIEW.md`. The abstract counting theorem,
all-n geometric tail, and exact transported ratio tending to one passed.
Endpoint-germ positivity is assigned to a separate reviewer and is
explicitly retained as an input here.

`balanced_sparsity_probe.py` tests the universal extremal balanced-cutoff
majorants with terminal weights one, rather than special theta examples:

- n=1,...,1024; p=1,...,80; M=1,2,4,9;
- 327,680 coefficient cells;
- 274,239 positive cells, each satisfying the active-node bound and the
  exact integer four-symbol/composition counting bound;
- 256 independent brute-force small-block checks enumerate all terminal
  degree assignments and reproduce both the coefficient and maximal
  active-node count from the dynamic program;
- Wolfram independently checks 1,640 dispersed n/p/M combinations,
  comparing the exact recursive coefficient, the maximum active-node
  count, and the bound with its algebraic square-root constant. All
  4,920 checks pass.

The final fresh review of the face root-span and flag mechanism is in
`FACE_ROOT_SPAN_AND_FLAG_REVIEW.md`. It supplies the iterated small-
Lipschitz-tail proof that justifies recursively taking face derivatives;
it does not infer infinite face flags from one unqualified polynomial
lexicographic path.
