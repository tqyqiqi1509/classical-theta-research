# Fresh review of the zero-group face span and recursive flags

2026-11-13. Reviewed §§3–4 of
`../convex_face_independent_review/ZERO_GROUP_FACE_REDUCTION.md`.

**Verdict: PASS, with the explicit iterated-limit justification below.**
The earlier finite scattering-polytope theorem, positive Minkowski-summand
inclusions, and uniform analytic slope bounds remain inputs. This review
does not reprove the global theta/Gale identification.

## 1. The local root-span equality

At finite principal order N, let Z be the total element of the tangent
scattering germ at g and let

\[
V_N=\operatorname{span}\{Da:(\log Z)_a\ne0\}.
\]

Let \(\mathfrak h\) be the direct sum of all root spaces indexed by a
with \(Da\in V_N\), in the finite nilpotent Lie algebra modulo degree
greater than N. This really is a Lie subalgebra: every nonzero bracket
has degree \(a+b\), and \(D(a+b)=Da+Db\in V_N\). It is preserved by
the three sign projections for every linear functional on the roots.

The finite signed factorization algorithm uses only these projections,
addition, scalar multiplication, and iterated brackets. Since \(\log Z\)
lies in \(\mathfrak h\), every signed factor of Z lies in
\(\exp\mathfrak h\). Reconstruction of a consistent finite scattering
diagram from its total element therefore places every effective local
wall factor in this subgroup. A nontrivial wall factor on a ray a has
a nonzero root component at some multiple \(ka\), so its normal Da
belongs to \(V_N\). This proves the direction that could otherwise
be obscured by cancellation in a path product.

Conversely, choose any generic finite path from the negative to the
positive cone of the local root system. Its product equals Z. The BCH
formula expresses every supported root of \(\log Z\) as a sum of
supported wall roots. Hence \(V_N\) is contained in the span of those
wall normals. Both inclusions are valid in the truncated Lie algebra,
and their union gives the full root-span equality.

The positive polytope \(P_N\) has a nonzero slope jump at every
effective finite wall. The vertices of \(F_g(P_N)\) come from the
adjacent tangent chambers, so its affine direction space is exactly
this local wall span. The positive Minkowski-summand inclusion then
embeds that space in the direction space of \(F_g(K_z)\). Together
with the direct upper inclusion from logarithmic root directions,
this proves the claimed exact face dimension.

This argument uses positivity to ensure that an effective wall has a
nonzero evaluated slope jump at the chosen positive point. It does not
require the zero subgroup to be abelian, and it does not assume that
individual BCH coefficients cannot cancel.

## 2. A necessary distinction about lexicographic perturbations

For each fixed finite principal cutoff, the endpoint

\[
g_1+t g_2+\cdots+t^{j-1}g_j+t^jD^{-1}(1,\ldots,1)
\]

with sufficiently small t does select the required lexicographic signs.
It therefore realizes each truncated composite factor \(P_j\) as an
original negative factor and gives the same uniform analytic bound.
This finite-order use of the polynomial path is valid.

One should **not** replace the subsequent argument by claiming that
one such polynomial path necessarily selects an entire exposed-face
flag of an arbitrary nonpolyhedral convex body. In a general convex
body, transverse curved gains at one order can interfere with a later
order. What is needed here is the successive directional-derivative
passage. The available uniform slope tails supply it, as follows.

## 3. Iterated directional derivatives and a common analytic domain

For every stage j and cutoff N, define \(f_{j,N}(h)\) from the finite
factorization formula for the support function of the prospective j-th
face. It is a continuous piecewise-linear, positively homogeneous
function of h. Its chamber slopes are the degree-N truncations of

\[
\log\bigl(x^{-1}P_j B_{j,h}^-x\bigr)(z).
\]

At each finite cutoff, the composite \(P_jB_{j,h}^-\) is realized by
a lexicographic endpoint followed by h. It is consequently an original
negative factor at that cutoff. The existing bound K and Cauchy tail
therefore apply uniformly in j and h. If M>N, every chamber slope of
\(f_{j,M}-f_{j,N}\), after refining the two finite fans, has norm at
most \(\epsilon_N\), with

\[
\epsilon_N=\frac{K R^{-N-1}}{1-R^{-1}}.
\]

Integrating along a generic line through the finite fans proves the
global estimate

\[
\operatorname{Lip}_{\ell^1}(f_{j,M}-f_{j,N})
\le\epsilon_N.
\]

The limit \(f_j=\lim_Nf_{j,N}\) inherits
\(\operatorname{Lip}(f_j-f_{j,N})\le\epsilon_N\). This estimate is
stronger than mere uniform convergence of support functions and is the
point that permits iteration on exposed faces.

Inductively assume \(f_j=h_{F^{(j)}}\). Convexity ensures its
one-sided directional derivative at \(g_{j+1}\) exists. The Lipschitz
tail gives, for every h,

\[
\left|
D f_j(g_{j+1};h)-D f_{j,N}(g_{j+1};h)
\right|\le\epsilon_N\|h\|_1.
\]

Finite signed factorization identifies
\(D f_{j,N}(g_{j+1};h)=f_{j+1,N}(h)\): roots with nonzero
\(g_{j+1}\)-weight enter the new fixed factor, and the remaining
zero-weight group is split by h. Letting N tend to infinity gives

\[
f_{j+1}(h)=D h_{F^{(j)}}(g_{j+1};h)
          =h_{F^{(j+1)}}(h).
\]

The last equality is the standard directional-derivative formula for
the support function of a compact convex body. Starting at j=0 proves
the entire face-flag formula. The same tail bound gives the claimed
Hausdorff approximation at each specified stage.

No domain shrinks with j: all finite composites were original negative
factors and already had the same K and R. No interchange of an
uncontrolled derivative and an infinite sum is used. This supplies an
explicit proof of the short sentence in the original §4 saying that
the directional-derivative argument can be applied at every stage.

## 4. Scope

The conclusions concern the analytic transport body. The per-integral-
direction ray-pressure theorem proved separately does not by itself
identify that body with the ray-scaling body on one label-independent
positive domain. These scope distinctions remain necessary after this
review.
