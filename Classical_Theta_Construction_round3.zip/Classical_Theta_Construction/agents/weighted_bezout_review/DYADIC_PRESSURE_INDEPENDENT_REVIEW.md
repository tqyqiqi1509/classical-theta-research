# Independent review: polynomial sparsity and vanishing pressure

2026-11-13. Reviewed the whole-sequence version of
`../ray_pressure_mechanism/DYADIC_VANISHING_PRESSURE.md`.

## Verdict

**PASS for the abstract counting theorem, the full-sequence uniform
coefficient bound, and the analytic return identity.** The theta
application is conditional on the positive endpoint-germ covariance and
the previously established quadratic stable-ray theorem; a separate
reviewer is checking the endpoint convention and positivity passage.

There is no missing constant prefactor in the conclusion
\(F_{ng}/H_g^n\to1\). The coefficientwise zero background and the
uniform exponential bound genuinely force the entire residual series
to tend to one on a small common complex domain.

## 1. Balanced recursion without a hidden position factor

For each n, fix once and for all the ordered binary tree obtained by
splitting m terminal positions into \(\lfloor m/2\rfloor\) and
\(\lceil m/2\rceil\). It is important that this tree is fixed before
counting. Apply coefficientwise submultiplicativity at every internal
node, and discard coefficients forbidden by \(m>Mp^2\).

For any retained leaf-degree assignment, an active node is a block with
positive total degree. At depth \(\ell<h=\lceil\log_2n\rceil\),
its block size is at least

\[
\lfloor n/2^\ell\rfloor\ge n/2^{\ell+1}.
\]

The active blocks at a fixed depth are disjoint and their total degrees
sum to at most p. Since a positive block of size m consumes at least
\(\sqrt{m/M}\) degree, the number of active nodes at that depth is at
most \(p\sqrt{M2^{\ell+1}/n}\). There are at most p active terminal
nodes at depth h. Consequently their total number L satisfies

\[
L\le p+p\sqrt{2M/n}\sum_{\ell=0}^{h-1}2^{\ell/2}
\le b_Mp,\qquad b_M=1+\frac{2\sqrt M}{\sqrt2-1}.
\]

For n=1 the conclusion is immediate. The estimate uses \(2^h<2n\)
for n>1; strict inequality is not needed in the final result.

The depth-first four-symbol code records, at each active node, whether
its active children are none, only left, only right, or both. The
fixed ambient balanced tree and the left/right information determine
the embedded active pattern uniquely. There is therefore **no additional
choice of leaf locations** and no omitted factor depending on n.

An active node with no active children must be a terminal leaf of the
original tree, since its positive degree is the sum of its children's
degrees. If there are r active terminal leaves, their positive degrees
form a composition of p, giving \(\binom{p-1}{r-1}\le2^{p-1}\)
choices. The product of terminal weights is at most \(B^p\).

Summing the four-symbol code lengths gives

\[
a_n(p)\le
B^p2^{p-1}\sum_{L=1}^{\lfloor b_Mp\rfloor}4^L
\le\bigl(2B4^{b_M+1}\bigr)^p.
\]

The final inequality is loose but valid for every p≥1. It also covers
patterns that do not occur in a balanced tree, so overcounting only
increases this upper bound. No injection between the actual algebraic
objects for different n is required: only coefficient inequalities are
being iterated.

## 2. Strict cutoff and convergence

The hypothesis is \(a_n(p)=0\) when \(n>Mp^2\). Accordingly every
positive degree in \(f_n-1\) satisfies

\[
p\ge m_n=\left\lceil\sqrt{n/M}\right\rceil.
\]

Equality at \(n=Mp^2\) is allowed, so the displayed ceiling is the
correct lower support bound. There is no off-by-one loss. With
\(K=2B4^{b_M+1}\), the preceding estimate yields

\[
|f_n(s)-1|\le\frac{(K|s|)^{m_n}}{1-K|s|},\qquad K|s|<1.
\]

This proves convergence of each f_n, uniform convergence of the whole
sequence to one on compact subsets, and eventual zero-freeness there.
The assumption that every positive evaluation exists is unnecessary for
the strengthened version because the coefficient estimate proves it.
Fekete's lemma is needed only for the weaker pressure statement if one
uses the original dyadic version rather than this full-sequence result.

## 3. Multivariable radialization

For nonnegative multivariable coefficients and a vector \(w_i\ge0\),
\(\sum_iw_i=1\), radialization \(f_n(s)=G_n(sw)\) preserves
coefficientwise submultiplicativity and total-degree sparsity. The
all-endpoint majorant implies

\[
[s^p]G_1(sw)\le\frac{(G+Cp)^p}{p!}
\le[e(G+C)]^p,
\]

using \(p!\ge(p/e)^p\), \(p\ge1\). The bound is uniform in w.
Thus for complex z one can set
\(w_i=|z_i|/\sum_j|z_j|\) and dominate termwise. This yields the
claimed bound in the full complex \(\ell^1\) ball, not just along
one positive ray. The zero vector is immediate. If the improved
\(\kappa_B\) majorant is substituted, the same argument works with
\(C=\kappa_B\), except that a harmless positive upper bound should be
used in the trivial \(G=\kappa_B=0\) case.

## 4. Transport back to the initial seed

Let A be the analytic germ automorphism and let

\[
A(x^g)=x^gH_g(z),\qquad A(z_j)=W_{g,j}(z).
\]

The formal identity \(A^{-1}(\vartheta_{ng})=x^{ng}G_n(z)\) gives,
by multiplicativity of the same automorphism A,

\[
F_{ng}(z)=H_g(z)^nG_n(W_g(z)).\tag{1}
\]

This is exactly the claimed orientation and exponent: the identity does
not involve the inverse coordinate map on the right side. Since
\(H_g(0)=1\), \(W_g(0)=0\), and \(dW_g(0)=I\), there is a
nonempty complex neighborhood on which H is nonzero, the original
theta series converge, the transport is analytic, and
\(K\sum_j|W_{g,j}(z)|<1\). Equality of the convergent germs proves
(1) there for every n.

For a compact subset on which
\(K\sum_j|W_{g,j}(z)|\le q<1\), division gives

\[
\left|\frac{F_{ng}(z)}{H_g(z)^n}-1\right|
\le\frac{q^{\lceil\sqrt{n/M}\rceil}}{1-q}.
\]

In particular the residual tends to exactly one; a nontrivial constant
prefactor would contradict this inequality. Once the right side is less
than one, the ratio has a uniquely normalized holomorphic logarithm,
and the normalized logarithms converge to \(\log H_g\). On the
positive real locus H is positive, giving
\(\Phi_z(g)=\log H_g(z)\). This conclusion is local for each fixed
integral direction g. The displayed constants do not provide one fixed
ball simultaneously for all primitive integral labels of unbounded
norm, so no all-label equality of the two convex bodies is inferred.

## 5. What remains conditional

The algebraic inequalities in Section 1 are abstract and fully proved.
The theta specialization still requires both:

- the actual positive zero-root endpoint germ has coefficientwise
  nonnegative coefficients and positive theta multiplication, so that
  submultiplicativity survives transport;
- applying the inverse transport to the existing stable-ray theorem
  gives the stipulated zero-background sparsity with its exact
  filtration convention.

The proof does not justify those assertions merely by saying that an
inverse positive automorphism preserves positivity. In general it does
not. The separate finite-order endpoint-germ argument in the parent
note is the necessary interface and is undergoing a separate review.
