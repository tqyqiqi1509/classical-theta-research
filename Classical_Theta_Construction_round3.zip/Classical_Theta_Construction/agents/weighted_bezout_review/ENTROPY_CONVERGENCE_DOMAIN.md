# A label-independent entropy domain from the weighted Q bound

2026-11-13. This is an analytic consequence of the coefficient bound in
`INDEPENDENT_REVIEW.md`, not a separate exact combinatorial formula for
theta coefficients.

Let \(\Delta=\{t_i\ge0,\sum_i t_i=1\}\), and set

\[
\alpha_i(t)=\max\{(B_+t)_i,(B_-t)_i\},\qquad
\mathcal A_B=\{t\in\Delta:t_i\le\alpha_i(t)\ \forall i\}.
\]

For \(0\le v\le u\), put

\[
\phi(u,v)=u\log u-v\log v-(u-v)\log(u-v),
\]

with \(0\log0=0\). Define the continuous entropy function

\[
\Psi_B(t)=\sum_i\phi(\alpha_i(t),t_i)
\quad(t\in\mathcal A_B).
\]

**Theorem.** Every fixed classical theta label, at every generic
endpoint, has an absolutely convergent coefficient series at positive
absolute values \(z_i\) satisfying

\[
\boxed{\quad
\sup_{t\in\mathcal A_B}
\left(\Psi_B(t)+\sum_i t_i\log z_i\right)<0.
\quad}\tag{1}
\]

The domain depends only on B. It is logarithmically convex and downward
closed in the positive orthant. Compact subsets admit locally uniform
convergence. Coordinate-zero points are included whenever a slightly
larger positive vector satisfies (1). If \(\mathcal A_B\) is empty,
the supremum is \(-\infty\) and all fixed-label series have finite
support under the same bound.

## Proof

Fix g and put \(G=\max|g_i|\). A nonzero coefficient of degree
\(p\), \(n=|p|\), satisfies

\[
p_i\le d_i\le n\alpha_i(p/n)+G.
\]

For integers \(0\le k\le d\), the standard binomial bound
\(\binom dk\le\exp(\phi(d,k))\) follows, for example, by taking the
\(k\)-th summand of \((x+(1-x))^d=1\) at \(x=k/d\). Thus

\[
\frac1n\log\bigl(a_{g,U}(p)z^p\bigr)
\le\sum_i\phi\left(\alpha_i(t)+G/n,t_i\right)
     +\sum_i t_i\log z_i,\qquad t=p/n.\tag{2}
\]

Monotonicity of \(\phi(u,v)\) in \(u\), with v fixed, justifies
replacing \(d_i/n\) by the displayed upper bound. The possible t lie in
the compact sets

\[
\mathcal A_{B,n,G}
=\{t\in\Delta:t_i\le\alpha_i(t)+G/n\ \forall i\}.
\]

Any accumulation point of a sequence in these sets belongs to
\(\mathcal A_B\). Since \(\phi\) is continuous on bounded triangular
domains \(0\le v\le u\), the limsup of the supremum of the right side
of (2) is at most the supremum in (1). Therefore (1) supplies a number
\(\delta>0\) and an integer \(n_0(g,z)\) such that every nonzero term
of total degree n is bounded by \(e^{-\delta n}\) for \(n\ge n_0\).
There are at most \(\binom{n+r-1}{r-1}\) degree-n vectors, which is a
polynomial in n. Summation proves convergence.

The same compactness argument works uniformly when \(\log z\) ranges
over a compact subset satisfying (1). The expression in (1) is a
supremum of affine functions in \(\log z\), giving logarithmic
convexity. Every t has nonnegative coordinates, giving downward
closure. Finally, if \(\mathcal A_B\) is empty, compactness implies
\(\mathcal A_{B,n,G}\) is empty for all large n, proving the finite
support assertion. This proof does not assert an effective finite
support stopping bound in the general nonempty case.

## Comparison with the graph-density ball

For \(0\le v\le u\),
\(\phi(u,v)\le v\log(eu/v)\). With \(C=|B|\) and
\(\kappa_B=\max_\Delta t^TCt\), weighted AM–GM gives

\[
\Psi_B(t)
\le 1+\log\kappa_B-\sum_i t_i\log t_i.
\]

The Gibbs variational formula

\[
\sup_{t\in\Delta}
\left(-\sum_i t_i\log t_i+\sum_i t_i\log z_i\right)
=\log\sum_i z_i
\]

therefore shows that \(e\kappa_B\sum_i z_i<1\) implies (1).
Hence the entropy domain contains the simpler graph-density ball.
The entropy domain can be evaluated as a finite-dimensional optimization
problem; it is only a sufficient convergence domain and is not claimed
to be the exact analytic continuation domain.

All deductions here are elementary consequences of the new Q coefficient
bound and old binomial entropy inequalities. No new 2026 source is used.

## Endpoint-sensitive refinement from the selected Weierstrass degree

The one-color preparation theorem already proved in
`../q_support_round2/COMPLEMENTARY_Q_MUTATION.md` supplies an additional
necessary support inequality. For a fixed generic endpoint, put
\(\sigma_i=\operatorname{sign}(a_i)\) and

\[
C^{\sigma}_{ij}=[-\sigma_iB_{ij}]_+,
\qquad b_i^{\sigma}=[-\sigma_i g_i]_+.
\]

Every nonzero selected coefficient satisfies

\[
p_i\le b_i^{\sigma}+\sum_j C^{\sigma}_{ij}p_j.
\]

This follows from the degree of the distinguished Weierstrass polynomial
that Q_i divides; it is a support restriction, not the unproved product
of outgoing binomial ranks. Define

\[
\mathcal A_{B,\sigma}
=\{t\in\Delta:t_i\le(C^{\sigma}t)_i\ \forall i\}.
\]

It is contained in \(\mathcal A_B\). The preceding compactness proof
therefore works with the smaller set \(\mathcal A_{B,\sigma}\) in
(1), while keeping the same valid entropy \(\Psi_B\) based on the
maximum degrees. This gives a possibly larger convergence domain for
that endpoint sign pattern.

If this smaller set is empty, the support inequalities already bound
the support of each fixed label. In particular, an acyclic nonnegative
matrix \(C^{\sigma}\) is nilpotent and gives the familiar finite bound
\(p\le(I-C^{\sigma})^{-1}b^{\sigma}\). This is an old acyclic
mechanism and is recorded only as a limiting consistency check. It does
not settle finite Laurent termination for general cyclic data.
