# A local analytic Fock–Goncharov scaling pairing for every classical theta label

Date: 2026-11-13, UTC. Classical skew-symmetric and skew-symmetrizable cluster algebras only.

This theorem is a consequence of the all-label analytic majorant and positive theta multiplication already established in this research run. The limiting construction is explicitly attributed to Fock–Goncharov; its idea, the subadditivity argument, and ordinary log-sum-exp convexity are not claimed as new. The useful additional scope is one explicit analytic domain on which **all formal labels** admit the construction, without a Laurent-finiteness or full-basis assumption.

## 1. Inputs, conventions, and the precise old problem

Fix an integral skew-symmetrizable exchange matrix `B` of rank size `r`, and a positive integral diagonal symmetrizer `D`. Work in one principal seed and its positive endpoint chamber. Write

\[
\vartheta_g(x,y)=x^g F_g(z),\qquad
z_j=y_jx^{Be_j},\qquad
F_g(z)=\sum_{p\in\mathbb N^r}a_g(p)z^p,
\quad a_g(p)\in\mathbb Z_{\geq0},\quad a_g(0)=1.
\]

No finite-Laurent hypothesis is imposed. Put

\[
C=\max(1,\max_{i,j}|B_{ij}|),\qquad
\mathcal D_C^+=\{z\in\mathbb R_{>0}^r:\ s(z):=\sum_i z_i<1/(eC)\}.
\]

The two inputs from `../../notes/THETA_ANALYTIC_MAJORANT.md` are:

1. For `z` in this domain and `G=||g||_infty`,

   \[
   1\leq F_g(z)\leq \frac{\exp(Gt)}{1-Ct},
   \qquad t=t(s)\in(0,1/C),\quad t=s\exp(Ct).
   \tag{1.1}
   \]

   Here `t` is the small positive solution; in particular it is finite and depends on the positive point but not on the label or symmetrizer.

2. Normalized positive multiplication has the normally convergent identity

   \[
   F_g(z)F_h(z)
   =F_{g+h}(z)+
     \sum_{0\ne p\in\mathbb N^r}
          c_{g,h}(p)z^pF_{g+h+Bp}(z),
   \qquad c_{g,h}(p)\in\mathbb Z_{\geq0}.
   \tag{1.2}
   \]

   The coefficient of the displayed unshifted theta summand is one. This follows from principal leading degree, not from an assumed atomicity property. Tonelli and the common analytic domain justify evaluating the possibly infinite sum.

The historical reference is Fock–Goncharov, *Cluster ensembles, quantization and the dilogarithm*, Ann. Sci. Éc. Norm. Supér. (4) **42** (2009), 865–930, DOI [10.24033/asens.2112](https://doi.org/10.24033/asens.2112), [arXiv:math/0311245v7](https://arxiv.org/abs/math/0311245v7).

Their Section 4.2, equation (76), proposes

\[
I_*(l,u)=\lim_{N\to\infty}\frac1N\log I_*(Nl)(u).
\tag{1.3}
\]

Conjecture 4.5 asks for existence. Their Theorem 4.6 and Lemma 4.7 explain how this scaling construction, assuming the proposed canonical maps and existence, produces the convex, homogeneous real-tropical pairings of Conjecture 4.3. The labels `* = A` and `* = X` refer to both Langlands-dual cluster-ensemble sides in that paper. Our theorem below establishes a **principal-seed formal-theta local version**. It does not establish those full global maps, atomicity, both ensemble pairings, or their existence at every positive point.

The primary published PDF was read at [Numdam](https://www.numdam.org/item/10.24033/asens.2112.pdf), and the arXiv text is retained in `sources/fg_ensemble_0311245v7.txt`.

## 2. The theorem

### Theorem A

For every `z` in `D_C^+` and every integral label `g`, the finite limit

\[
\boxed{
\Phi_z(g)
 =\lim_{n\to\infty}\frac1n\log F_{ng}(z)
 =\inf_{n\geq1}\frac1n\log F_{ng}(z)
}
\tag{2.1}
\]

exists. It satisfies

\[
0\leq\Phi_z(g)\leq
\min\{\log F_g(z),\ t(s(z))\|g\|_\infty\}.
\tag{2.2}
\]

There is a unique extension to `g` in `R^r` which is continuous, positively homogeneous, and convex. More precisely,

\[
\Phi_z(g+h)\leq\Phi_z(g)+\Phi_z(h),
\qquad
|\Phi_z(g)-\Phi_z(h)|
\leq t(s(z))\|g-h\|_\infty.
\tag{2.3}
\]

For each fixed real `g`, the function

\[
u\longmapsto\Phi_{\exp u}(g)
\tag{2.4}
\]

is convex and continuous on the open convex domain

\[
\mathcal U_C=
\{u\in\mathbb R^r:\sum_i e^{u_i}<1/(eC)\}.
\tag{2.5}
\]

These are separate convexities in the label and the logarithmic positive-point variables. Joint convexity is not asserted.

### Proof

For fixed integral `g`, set `b_n=log F_(ng)(z)`. Equation (1.2) applied to `ng` and `mg` gives

\[
b_{n+m}\leq b_n+b_m.
\]

The constant term one gives `b_n>=0`; the analytic input makes each `b_n` finite. The elementary subadditive limit lemma therefore gives (2.1). For completeness, for every fixed `k` write `n=qk+j`, `0<=j<k`; then

\[
\frac{b_n}{n}\leq\frac{qb_k+b_j}{qk+j}
\longrightarrow\frac{b_k}{k}.
\]

Taking the infimum over `k` proves the limit formula. This proof uses no interchange of a coefficientwise limit with pointwise evaluation.

The first upper bound in (2.2) follows by choosing `n=1` in the infimum. For the second, (1.1) gives

\[
\frac1n\log F_{ng}(z)
\leq t(s)\|g\|_\infty
       -\frac1n\log(1-Ct(s)),
\]

and then let `n` tend to infinity.

For a positive integer `k`, taking the subsequence `nk` in (2.1) proves

\[
\Phi_z(kg)=k\Phi_z(g).
\]

Equation (1.2) applied to `ng,nh` proves subadditivity on the integral lattice after taking limits. Define on the rational lattice

\[
\Phi_z(g/k)=\Phi_z(g)/k.
\]

Integer homogeneity makes this independent of representation, and subadditivity persists. Applying it once to `g=h+(g-h)` and once to `h=g+(h-g)`, and then using (2.2), yields the Lipschitz bound on rational labels. Completeness of `R` yields a unique continuous extension to `R^r`; homogeneity and subadditivity extend by continuity. Their combination is ordinary convexity.

For (2.4), first take integral `g`. Each function

\[
u\longmapsto\frac1n\log\sum_p a_{ng}(p)e^{p\cdot u}
\]

is convex on `U_C` by Hölder's inequality; the series are finite in value there. Their pointwise limit is finite by (2.2), hence is convex. Rational homogeneity gives the same conclusion for rational labels. On a compact subset of `U_C`, the scalar `t(sum e^u_i)` is uniformly bounded, so (2.3) gives uniform approximation in `u` of real labels by rational ones. Thus convexity also holds for real labels. A finite convex function on an open convex set is continuous. The proof is complete.

## 3. The associated body and the unnormalized pairing

Every finite continuous sublinear function is a support function. Thus

\[
K_z^{\mathrm{sc}}
=\{v\in\mathbb R^r:\ g\cdot v\leq\Phi_z(g)
                              \text{ for all }g\in\mathbb R^r\}
\tag{3.1}
\]

is a nonempty compact convex set, and

\[
h_{K_z^{\mathrm{sc}}}=\Phi_z,
\qquad 0\in K_z^{\mathrm{sc}},
\qquad K_z^{\mathrm{sc}}\subseteq
       \{v:\|v\|_1\leq t(s(z))\}.
\tag{3.2}
\]

The last inclusion follows by taking the supremum over `||g||_infty<=1` in the support inequalities. This body is attached to the **actual scaling limit**. Its full normal-cone structure has not been identified here.

Restoring the leading monomial gives the local pairing

\[
\mathcal I(g;x,y)
=\lim_{n\to\infty}\frac1n\log\vartheta_{ng}(x,y)
=g\cdot\log x+\Phi_{yx^B}(g),
\tag{3.3}
\]

for `x_i,y_i>0` satisfying `sum_j y_j x^(Be_j)<1/(eC)`. It is continuous, convex, and positively homogeneous in the real label `g`. In the logarithmic seed coordinates `(log x,log y)`, it is convex for fixed `g`, because `log z` is linear in those coordinates and the additional term in (3.3) is linear. Adding a frozen tropical label `q` simply adds `q dot log y`.

The normalization `Phi=I-g dot log x` is seed-dependent. Mutation compatibility can be asserted on analytically justified common chart domains, but no global analytic continuation or whole-positive-variety result is being inferred from this note.

## 4. Exact distinction from the stable-log transport body

Let

\[
H_g=x^{-g}A_g^-(x^g),\qquad L_z(g)=\log H_g(z),
\tag{4.1}
\]

where `A_g^-` is transport from the endpoint `Dg` towards the positive chamber, with the boundary convention established in the stable-log proof. The coefficientwise stabilization result proves that `L` is the formal stable logarithm. The sibling analytic-body proof additionally identifies its convergent analytic evaluation as a support function on a smaller explicit domain.

These facts do **not** automatically prove

\[
\Phi_z(g)=L_z(g).
\tag{4.2}
\]

The root's positive-transport argument gives `L_z(g)<=Phi_z(g)` on their common positive domain, because the endpoint theta expansion after transport is a positive factor with constant term one. Consequently, once both support-function statements are established,

\[
K_z^{\mathrm{tr}}\subseteq K_z^{\mathrm{sc}}.
\tag{4.3}
\]

This inclusion by itself does not identify their normal cones or show equality of either body. The quantitative comparison proposed in `../../notes/FG_PAIRING_FLAT_COMPARISON.md` is a separate theorem and requires its own independent check. No assertion about it is used in the proof of Theorem A.

For a cluster-monomial label, `theta_(ng)=theta_g^n`, hence `Phi_z(g)=log F_g(z)`. The coefficientwise stable-log identity then gives `L_z(g)=log F_g(z)` wherever the analytic transport is defined. In finite type these cluster cones cover the label space, so the analytic family is an incarnation of the old finite-type canonical pairing. Any novelty claim must concern its general infinite-wall scope, quantitative analytic construction, or new consequences beyond this case.

## 5. A precise Newton interface for finite theta functions

The following compatibility is useful, but it is a direct consequence of known Newton homogeneity and positivity, not a new Newton theorem.

### Proposition B

Suppose `F_g` is a polynomial. Then all `F_(ng)` are polynomials, the limit in (2.1) is defined for every `z>0` along this fixed ray, and if `P_g=Newt(F_g)`, then for every `u` in `R^r`,

\[
\lim_{s\to+\infty}\frac{\Phi_{\exp(su)}(g)}s=h_{P_g}(u).
\tag{5.1}
\]

In particular, the actual positive-point scaling pairing retains the full Newton support function as its recession function. The statement concerns varying the positive point after constructing the label-ray limit; it is not obtained by interchanging two uncontrolled limits.

### Proof

Equation (1.2) iterated gives `F_(ng)<=F_g^n` coefficientwise, so `F_(ng)` is finite and the same subadditive proof defines the limit at any positive point. Positive scattering also gives

\[
\operatorname{Newt}(F_{ng})=n\operatorname{Newt}(F_g).
\tag{5.2}
\]

This is the normalized principal form of Lemma 2.9 of Cheung–Magee–Mandel–Muller, *Valuative independence and cluster theta reciprocity*, [arXiv:2505.09585v2](https://arxiv.org/abs/2505.09585v2). Its proof uses the positive unshifted theta summand for one inclusion and scaling each broken line's attached exponents for the other. The complete short proof was re-read in the primary text; it invokes no Li–Pan result. See the scope audit below.

Choose a vertex `p` of `P_g` maximizing `p dot u`. Equation (5.2) ensures that `n p` occurs in `F_(ng)` with positive integral coefficient. Therefore, for `s>0`,

\[
n s h_{P_g}(u)
\leq\log F_{ng}(e^{su})
\leq n\log F_g(e^{su}).
\]

Divide by `n`, take the existing limit, and divide by `s`:

\[
h_{P_g}(u)
\leq\frac{\Phi_{e^{su}}(g)}s
\leq\frac{\log F_g(e^{su})}s.
\]

The right side tends to `h_(P_g)(u)` by the elementary finite-sum Laplace principle. This proves (5.1).

For arbitrary formal labels, the small coefficient domain does not permit arbitrary `e^(su)` as `s` tends to infinity. Proposition B must not be extended to that setting without an additional domain argument.

## 6. Hypothesis audit and novelty limits

| Source / statement | What was actually checked | Consequence retained | What is not imported |
|---|---|---|---|
| FG2009 §4.1, Conjecture 4.1 | The proposed maps identify integral tropical points with extremal universally positive Laurent polynomials and generate all such polynomials; positive multiplication has an unshifted coefficient one | Exact historical target and the reason for the subadditive inequality | Atomicity, a complete global basis, or finiteness for every theta label |
| FG2009 §4.2, (76), Conjecture 4.5, Theorem 4.6, Lemma 4.7 | Full relevant paragraphs read in arXiv v7 and located in the published paper | The scaling-pairing idea and convex/homogeneous objectives are old | Theorem 4.6 is not cited as the proof of Theorem A; our proof supplies analytic existence, Hölder convexity, and explicit bounds directly |
| FG2009 §4.4 and §5 | Type A2 formulas, finite-type canonical maps, and tropical pairing construction read | Finite-type specialization is known in essence | Arbitrary infinite-type transport-body theorem |
| FG2006 §12.2–12.3 | Additive pairing defined via geodesic lengths, subadditivity/continuity argument read | The surface-length interpretation is a genuine old predecessor | A general cluster formula or a proof that our two functions agree |
| CMMM2505.09585v2 (2026), Lemma 2.9 | Both inequalities and broken-line scaling argument checked directly in the primary text; same proof independently recorded in the root audit | Newton homogeneity in Proposition B | Any other 2026 theorem or any Li–Pan-based assertion |
| Ishibashi2603.14338v2 (2026), Lemma 2.5 and Proposition 2.7 | Cauchy–Schwarz equality proof checked in official PDF; the earlier HTML date differs from the downloaded version and is not used as metadata | Ordinary log-Laurent convexity is established background | Fixed-point theorem, full paper correctness, or convexity in the tropical label variable |

Theorem A's elementary analytic deductions should not be sold individually as new inventions. The candidate new result is that the previous all-label coefficient theorem makes these deductions valid **simultaneously for all formal classical labels on an explicit seed domain**, and supplies a concrete transport function with which the old scaling pairing can now be compared.

The equality with `L_z`, a global positive-variety pairing, a complete identification of the scaling body's normal fan, and an effective label-ray convergence rate remain distinct questions.
