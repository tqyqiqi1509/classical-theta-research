# Analytic theta convex bodies, the Fock–Goncharov pressure, and the remaining equality mechanism

**Research interval:** 2026-11-13, approximately 21:54–22:26 UTC.  
**Scope:** classical skew-symmetric and then skew-symmetrizable cluster algebras.  
**Status:** primary-source comparison and proved interface lemmas. The equality of analytic stable log and actual ray pressure remains open here. No Li–Pan theorem is used.

## 1. What is potentially new, and what is already old

Let `B` be a classical exchange matrix, write a principal-seed theta function as

\[
\vartheta_g=x^gF_g(z),\qquad z_i=y_ix^{Be_i},
\]

and let

\[
H_g=x^{-g}A_g^-(x^g),\qquad L_z(g)=\log H_g(z).
\]

Here `A_g^-` is the scattering transport from the asymptotic endpoint in direction `Dg` to the chosen positive endpoint. The construction in the companion analytic-body proof evaluates an actually convergent transport, at one sufficiently small positive point `z`; it is not a choice of summable weights on finitely many polytopes.

The following distinction is essential.

| Statement | Novelty assessment after this search |
|---|---|
| A consistent cluster scattering diagram defines a complete fan | Old: Reading. |
| Finite module Newton polytopes realize selected stability/cluster cones | Old: Fei, Asai–Iyama and related representation theory. |
| Finite sums of Newton polytopes have the common-refinement normal fan | Ordinary convex geometry; already used in cluster and amplitude literature. |
| An infinite scattering fan has a compact convex realization by rapidly weighted finite bodies | Already obtained in this project's earlier `POLYTOPAL_STABLE_LOG_THEOREM.md`, §9. It cannot be advertised again as the new result. |
| Actual evaluation `g ↦ log H_g(z)` is sublinear, with strict bends at every effective wall, on one explicit common analytic domain | No exact theorem matching this full statement was found among the primary sources checked below. This is the candidate increment, subject to the independent analytic-body proof. |
| The body varies with a genuine positive point and has an explicit approximation rate from the same analytic series | A substantive addition to an arbitrary-weight Minkowski construction, if the companion estimates hold. |
| The ray limit `lim_n n^{-1}log F_(ng)(z)` is a new definition | False: the definition is Fock–Goncharov's equation (76). |
| Existence of that ray limit for every formal theta label on an explicit common local domain | A useful new-scope consequence of the present all-label majorant and positive product. The Fekete argument itself is old and elementary. |
| `L_z(g)` equals that ray limit | Not proved. Do not call the analytic body the Fock–Goncharov body without this qualification. |
| The actual body is always a finite Newton polytope | Not established and generally incompatible with infinitely many effective walls. Logarithmic support coordinates are real, not intrinsically integral. |

The search is not a claim of exhaustive coverage. In particular, no unsupported universal conclusion is drawn from an abstract saying that an object is a polytope or a positive geometry.

## 2. Primary literature: precise overlaps and limits

### 2.1 Reading, Fei, Asai–Iyama, Mou

- **Reading, _Scattering fans_, arXiv:1712.06968v3, IMRN 2020.** Theorem 3.1 gives completeness of the scattering fan. Remark 3.2 permits features of infinite fans that differ substantially from finite polyhedral fans. This supplies the fan, not a support function realizing the entire fan. Primary: <https://arxiv.org/abs/1712.06968> and <https://academic.oup.com/imrn/article/2020/23/9640/5177805>.
- **Fei, _Tropical F-polynomials and General Presentations_, arXiv:1911.10513v6.** Theorem 5.17 realizes any finite collection of cluster cones in the normal fan of a representation Newton polytope. Remark 8.5 explicitly offers the infinite direct-sum picture heuristically. That remark does not prove a compact analytic convex body or specify convergent weights. Primary: <https://arxiv.org/abs/1911.10513>.
- **Asai–Iyama, _M-TF equivalences in the real Grothendieck groups_, arXiv:2404.13232.** Theorem 3.15 identifies the fan belonging to a fixed module with its Newton normal fan. Passing from a fixed finite module to all effective cluster-scattering walls is additional work; equality of categorical walls and nontrivial integrated walls must not be assumed. Primary: <https://arxiv.org/abs/2404.13232>.
- **Mou, _Scattering diagrams of quivers with potentials and mutations_, arXiv:1910.13714.** Signed factorizations and their finite/inverse-limit cone structures are directly relevant to `A_g^-`, but do not by themselves evaluate a real-analytic support function. Primary: <https://arxiv.org/abs/1910.13714>.

The relevant passages were read in the local primary-source texts retained by `agents/stable_hall_interface/sources/`. These are useful structural inputs, not evidence that the actual positive-point construction is already present.

### 2.2 Fock–Goncharov: the ray-pressure construction is explicitly old

**Fock–Goncharov, _Cluster ensembles, quantization and the dilogarithm_, Ann. Sci. Éc. Norm. Supér. 42 (2009), 865–930, arXiv:math/0311245v7, DOI 10.24033/asens.2112.** Equation (76), Conjecture 4.5, Theorem 4.6 and Lemma 4.7 are the exact source. Their setup uses the stronger proposed canonical maps of Conjecture 4.1 and the full positive loci on both ensemble sides. Our result provides a local principal-seed version for formal theta series, without proving those global maps or atomicity. Section 4.4 supplies the finite-type `A_2` example; those finite-type cases are not novel.

Primary: <https://www.numdam.org/item/10.24033/asens.2112.pdf>. A complete local theorem and proof, with a scope comparison, are in `LOCAL_FG_SCALING_PAIRING.md`.

**Fock–Goncharov, _Moduli spaces of local systems and higher Teichmüller theory_, PMIHES 103 (2006), arXiv:math/0311149v4, §12.** Surface length/lamination pairings and trace growth give older geometric realizations. They do not supply an all-classical-exchange-matrix argument. Primary: <https://arxiv.org/abs/math/0311149>.

### 2.3 Positive geometries and logarithmic coordinate maps

**Arkani-Hamed–He–Lam, _Stringy Canonical Forms_, arXiv:1912.08707v3, JHEP 02 (2021) 069.** Section 7.1, Claim 4 gives a positive-coordinate gradient map associated with a finite weighted collection of Laurent polynomials; its image is the interior of their Minkowski Newton sum. This is a gradient in the positive-point coordinates. Our support function varies the tropical label while the point is fixed. The two constructions should not be identified merely because both use logarithms and Newton polytopes. Primary: <https://arxiv.org/abs/1912.08707>.

**Herderschee, _Algebraic branch points at all loop orders from positive kinematics and wall crossing_, arXiv:2102.03611v3, JHEP 07 (2021) 049, Appendix F.** The discussion states an unrestricted scattering-diagram/polytope correspondence, but its explicit construction requires choosing heights with the desired combinatorics and uses finite Newton sums/examples. No proof of such heights for every infinite cluster fan is supplied there. As a universal finite-polytope assertion this is overbroad; it is not accepted as a theorem resolving our question. Primary: <https://arxiv.org/abs/2102.03611>.

**Kulkarni–Matherne–Mousavand–Rock, _A continuous associahedron of type A_, arXiv:2108.12927v2, Math. Z. 2025.** The ambient object is an infinite product of coordinate spaces, defined by continuous mesh relations and positivity; some cluster-point existence/uniqueness questions remain open. This is not the proposed compact body in one fixed finite-dimensional label space. Primary: <https://arxiv.org/abs/2108.12927>.

**Kontsevich–Soibelman, arXiv:1303.3253v4, §§6.2 and 10.2.** Convex/Hessian potentials in affine or SYZ geometry are related background. The cited passages do not assert that the actual evaluated log-transport is a support function whose normal cones are precisely the complete cluster scattering fan. The separate audit of analytic scattering convergence is already in `agents/global_gale_novelty/ANALYTIC_CONVERGENCE_NOVELTY_ROUND2.md` and is not duplicated here.

**Nakanishi, arXiv:2111.09555v4.** Dilogarithm potentials, logarithmic wall factors and Hamiltonian derivatives are old. They do not alone establish the global label convexity or exact normal-cone statement under examination.

### 2.4 Our own older work

Both pages of the 85-item Qiyue Tang Hexagon catalog were searched by title and matching abstracts; this was not a line-by-line audit of all 85 proofs. The relevant positive-polytope paper was read through its exact interface: **2611.00015v1, _Positive polytopes and the full Fock–Goncharov conjecture_**, <https://hexagonmath.org/2611.00015v1>, source <https://hexagonmath.org/api/v1/works/2611.00015v1/source?path=main_GHKK.tex>. Its broken-line positivity/compactification criterion belongs to the GHKK–CMN notion of positive sets. It does not identify the ordinary Euclidean normal fan of the present analytic body.

Locally, the strongest prior overlap is more direct: the stable-log finite-polytope theorem and its §9 infinite Minkowski construction already give a body with the desired fan. The new report must say explicitly that it replaces auxiliary summable weights by evaluation of the analytically convergent stable log, if the new proof is accepted.

## 3. Strong review of 2026 sources actually encountered

| Source | Material checked | Decision |
|---|---|---|
| Ishibashi, arXiv:2603.14338v2, _Fixed point theorem for cluster modular groups_ | Official v1/v2 PDF metadata; §2 Lemma 2.5 and Proposition 2.7, ordinary log-sum-exp convexity and its strictness argument | The local convexity statement is correct by direct Cauchy–Schwarz/Hölder computation and is old in substance. It concerns logarithmic point coordinates, not our label-space support function. The full fixed-point theorem is not imported. |
| CMMM, arXiv:2505.09585v2, revised 21 May 2026 | Lemma 2.9, both inequalities: positivity of the unshifted product summand and scaling of broken lines | Accepted for Newton scaling in the stated Laurent-finite situation. Its proof does not require Li–Pan. It supports the Newton-recession interface in the companion note, not equality `Phi=L`. |
| Cao–de Saint Germain–Lu, arXiv:2405.10330, 2026 published version | Metadata and finite-type tropical-pairing abstract | Useful search lead; not imported as a general analytic theorem. Full proof not audited in this round. |
| Fu–Zhang, arXiv:2609.14388 | Abstract/scope | Quantum acyclic Hall topic; outside this task and not used. |

**Metadata warning:** the rendered HTML date for one Ishibashi version did not agree with the official arXiv version record/PDF. The official version record and PDF were used. No conclusion is based on the inconsistent HTML timestamp.

## 4. Independent check of the exponentially small comparison

The root note `../../notes/FG_PAIRING_FLAT_COMPARISON.md` proves, conditional on its already stated analytic transport and stable-degree inputs,

\[
0\leq\Phi_{\epsilon v}(g)-L_{\epsilon v}(g)
\leq 3\exp(-c_g(v)/\epsilon).
\]

I checked the analytic comparison and the floor-function constants, rather than inferring equality from a formal expansion. Write

\[
A=\max(1,2G\textstyle\sum_i v_i,2M_H/R),\quad
M'=\max(1,M),\quad \alpha=\log2,
\]

and choose

\[
d=\left\lfloor\frac{\alpha}{6AM'\epsilon}\right\rfloor,
\qquad n=Md^2+1,\qquad \rho=2\epsilon.
\]

The zero of order `d+1` in `F_(ng)(sv)-H_g(sv)^n`, Cauchy's estimate, and the real lower bound for `H_g` give

\[
0\leq\Phi-L
\leq\frac3n\exp(3An\epsilon)2^{-d-1}.
\]

For `epsilon <= alpha/(12AM')`, set `t=alpha/(6AM'epsilon) >=2`. Using `d<=t` and `d>=t-1`,

\[
3AM'\epsilon d^2\leq\tfrac12\alpha d,
\]

\[
3An\epsilon-(d+1)\alpha
\leq-\frac{\alpha^2}{12AM'\epsilon}
       -\frac\alpha2+3A\epsilon
\leq-\frac{\alpha^2}{12AM'\epsilon}-\frac\alpha4.
\]

Thus the displayed constant in the root note is conservative. **Audit outcome: conditional PASS.** The endpoint-transport lower bound and the stable-degree theorem are distinct inputs, not reproved here.

This is a quantitative bridge to the old FG limit, but its perturbative agreement does not imply equality. Even positivity and convexity in `log epsilon` permit a positive flat correction: `exp(-c/epsilon)` has positive second derivative in that logarithmic coordinate whenever `epsilon<c`. This observation identifies what an additional argument must control; it is not a proposed replacement of the main goal by a counterexample study.

## 5. A precise sufficient condition that would prove equality

The next elementary complex-analysis lemma makes the unresolved input concrete.

### Lemma: a common zero-free neighborhood forces the true ray pressure to equal stable log

Fix an integral label `g` and a positive vector `v`. Suppose:

1. `F_n(s):=F_(ng)(sv)` is holomorphic on `|s|<R_0`, satisfies `F_n(0)=1`, and for each `R<R_0` there is `C_R<infinity` with
   \[
   |F_n(s)|\leq\exp(nC_R+C_R)\qquad(|s|\leq R).
   \]
2. There is a radius `R_1>0`, independent of sufficiently large `n`, on which every `F_n` is zero-free.
3. `H(s):=H_g(sv)` is holomorphic and zero-free near zero, `H(0)=1`, and for every fixed degree `d`,
   \[
   F_n(s)=H(s)^n\pmod {s^{d+1}}
   \]
   once `n` is sufficiently large.

Then on a fixed smaller disk,

\[
\frac1n\log F_n(s)\longrightarrow\log H(s)
\]

locally uniformly, with logarithms normalized to vanish at zero. In particular, `Phi_(epsilon v)(g)=L_(epsilon v)(g)` there.

**Proof.** Work in a disk contained in all three analytic neighborhoods. A normalized holomorphic logarithm `f_n=(log F_n)/n` exists by assumption 2. Assumption 1 bounds `Re f_n` above uniformly. The Borel–Carathéodory estimate, applied on each smaller concentric disk and using `f_n(0)=0`, bounds `|f_n|` there uniformly. Hence this is a normal family. Every subsequential holomorphic limit has, by assumption 3 and the formal logarithm identity, every Taylor coefficient equal to the corresponding coefficient of `log H`. The identity theorem identifies every limit with `log H`. Therefore the whole sequence converges. The positive-real branches coincide with the branches in the pressure definition. ∎

The common majorant already gives assumption 1; coefficient stabilization gives assumption 3. **Assumption 2 is the missing mathematical statement.** It is not a consequence of the upper bound on `|F_n|` or of nonnegative coefficients.

A multivariate polydisk version follows by the same argument on complex lines and local normal-family bounds. A fixed positive ray suffices for the desired pointwise equality.

## 6. Two primary interfaces for producing the missing control

### 6.1 Reineke: exact framing powers at fixed stability

**Reineke, _Cohomology of quiver moduli, functional equations, and integrality of Donaldson–Thomas type invariants_, arXiv:0903.0261v1, Compositio 147 (2011), 943–964.** Theorem 2.2 gives a cell decomposition of the noncommutative Hilbert scheme by framing-indexed forests. Proposition 3.1 consequently gives

\[
F^{\mathbf n}(t)=\prod_iF^i(t)^{n_i},\qquad
F^i(t)=1+t_i\prod_jF^j(t)^{r_{ij}}.
\]

For fixed stability `Theta` and slope `mu`, Theorem 4.2 likewise implies

\[
Q^{\mathbf n}_\mu(t)
=\sum_{\mu(d)=\mu}\chi(M^\Theta_{d,\mathbf n}(Q))t^d
=\prod_iQ^i_\mu(t)^{n_i}.
\]

The framing is genuinely independent at the Euler-generating-function level in these fixed problems. Primary: <https://arxiv.org/abs/0903.0261>. The defining stability condition and the theorem proof were read, not just the formula.

**Application status.** This is the most concrete Hall/forest mechanism found in this round. It cannot yet be applied to arbitrary `theta_(ng)`: changing the theta label, the degree being extracted, and the endpoint/stability condition is not the same operation as scaling a framing at fixed `Theta,mu`. An actual identification or a quantitative locality theorem is required. Negative coefficients of some stable factors `H_g` also rule out silently interpreting them as positive independent-root counting functions.

The source for the smooth models is **Engel–Reineke, arXiv:0706.4306v2, _Smooth models of quiver moduli_**. The definitions, Theorem 5.2 and the forest construction in §7 were checked at the relevant interface. No equality with arbitrary theta labels is asserted there.

**Bridgeland, arXiv:1603.00416, Theorem 1.4 / §10.** The framed-moduli description explicitly restricts its labels to the positive cone; the text leaves general labels for further work. It cannot be treated as the missing all-label identification. Primary: <https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf>.

### 6.2 Connected polymer expansions: what would be sufficient, and what is not yet present

**Fernández–Procacci, _Cluster expansion for abstract polymer models. New bounds from an old approach_, arXiv:math-ph/0605041v2, CMP 274 (2007), 123–140**, was read in §§2–4. It records the Kotecký–Preiss criterion in (2.15), derives the connected logarithm, and proves uniform convergence by tree bounds (Proposition 7). Primary: <https://arxiv.org/abs/math-ph/0605041>, <https://webspace.science.uu.nl/~ferna107/papers/ferpro07.pdf>.

Suppose one actually expresses the finite-label theta partition function as

\[
F_{ng}(z)=\sum_{\Gamma\text{ compatible}}\prod_{\gamma\in\Gamma}w_{n,\gamma}(z)
\]

on a polymer incompatibility graph, with a size function `a`. A sufficient analytic estimate, uniform in `n`, is

\[
\sum_{\eta\not\sim\gamma}|w_{n,\eta}(z)|e^{a(\eta)}\leq a(\gamma).
\]

The convergent connected logarithm yields the required zero-free neighborhood. The lemma in §5 then proves `Phi=L`, without any interchange of formal and real limits.

**What is missing.** The present Gale/Bezout majorant counts dominating forests or functional digraphs, but it is an inequality for coefficients. It is not an identity giving compatible components of the actual theta coefficient algebra. A majorant tree cannot be substituted for the polymers in the displayed criterion. In particular, the interactions induced by arrow collisions, saturation, and the positive special fiber have to be shown local in a framing-component decomposition. That is the current research target.

The original Kotecký–Preiss article is CMP 103 (1986), 491–498, DOI <https://doi.org/10.1007/BF01211762>. Two attempted direct PDF mirrors did not deliver a usable full text in this round. The criterion above was verified in the authors' later primary mathematical paper, rather than claiming to have read the unavailable scan.

## 7. Ray generating functions and spectral data

**Arkani-Hamed–Lam–Spradlin, _Non-perturbative geometries for planar N=4 SYM amplitudes_, JHEP 03 (2021) 065, arXiv:1912.08222.** The formal journal version §3.2, (3.10)–(3.11), defines

\[
f_g(t)=\sum_{k\geq0}B(kg)t^k.
\]

Only when this is rational do the authors define their algebraic functions as reciprocal-pole roots; their positivity is conjectured. No general rationality theorem is supplied. The rank-two formulas and the Grassmannian examples therefore do not provide a general finite transfer matrix for theta rays. Primary journal PDF: <https://inspirehep.net/files/5546d1936ddf99d3dd9006f80d7a05a3>. The arXiv v1 and published versions use different section/equation numbering; the numbers above refer to the published version.

Our proved local pressure immediately implies, by Cauchy–Hadamard,

\[
\operatorname{rad}_t\left(\sum_{n\geq0}F_{ng}(z)t^n\right)
=e^{-\Phi_z(g)}.
\]

Thus identifying the dominant singularity with `H_g(z)^{-1}` would give equality. This is a useful spectral reformulation connected to existing literature, not an independent solution. Rationality alone would still require selection/control of the dominant branch and its local analytic behavior.

## 8. Newton support versus pressure

When `F_g` is finite, positivity gives `F_(ng) <= F_g^n` coefficientwise, and the audited Newton-scaling lemma gives

\[
\operatorname{Newt}(F_{ng})=n\operatorname{Newt}(F_g).
\]

A direct squeeze proves that the large-positive-point recession of the pressure is the support function of that Newton polytope; see Proposition B of the companion FG note. This furnishes a clean finite Laurent/Newton interface.

It does not determine pressure at a fixed positive point. The exponent support gives the extremal energy, while exponential growth of coefficients can contribute additional entropy. Consequently neither Newton equality nor an ordinary Laplace-principle slogan removes the flat discrepancy. One needs coefficient-level thermodynamic control, an exact factorization, a connected expansion, or comparable analytic information.

## 9. Route and search log

| UTC interval | Route / primary search | Result and next mathematical consequence |
|---|---|---|
| 21:54–22:04 | Reading, Fei, Asai–Iyama, Mou; compare own earlier stable-log body | First-body and first-fan claims withdrawn. Actual evaluation and explicit analytic approximation are the candidate increment. |
| 22:04–22:13 | FG original §4; surface pairing; stringy and continuous associahedra; 2026 log-convexity | Exact FG historical interface identified. Wrote full local scaling-pairing theorem; did not import full global FG assumptions. |
| 22:13–22:20 | Root exponential comparison; constants; own Hexagon catalog and positive-polytopes interface | Flat estimate passes conditional review. Formal agreement explicitly separated from equality. |
| 22:20–22:26 | Reineke fixed-framing powers, Bridgeland label restriction, ALS ray series, Fernández–Procacci connected expansion | Exact general sufficient condition isolated: a uniform zero-free neighborhood. Reineke gives a genuine component factorization in fixed stability, but transfer to arbitrary theta remains missing. |

Searches for cluster-theta zero-free theorems mostly returned classical Jacobi theta functions, which are different objects. Searches for `f-polynomial` zero statements also returned face enumerators rather than cluster `F`-polynomials. These hits are not used. The next route is to construct an actual connected decomposition of the framed Gale coefficient algebra, or to identify a Hall model in which the moving stability contributes only subextensive pressure. Repeating the already proved Bezout convergence estimate cannot supply this missing statement.
