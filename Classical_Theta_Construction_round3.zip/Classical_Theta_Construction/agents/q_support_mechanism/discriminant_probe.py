"""Probe whether generic constant color targets suffice for strong Q solutions.

This is a mechanism test, not a replacement for the reviewed Morse theorem.
The Q remainder ring is additionally saturated by same-color discriminants.
If its positive special length drops, constant-target strong solutions do
not capture the whole coefficient in that instance.
"""
from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
import sympy as s
from graph_gale_staircase import graph_data,color_generic_weights,standard_basis
from incoming_recursion import IncomingSchur


def probe(B,D,g,p,targets):
    started=time.time(); colors,eta=graph_data(B,D,g,p)
    weights,cert=color_generic_weights(eta,colors,D)
    a={c:w for c,w in zip(colors[1:],weights)}
    z,T,u=s.symbols('z T u');cs=[];Q=[]
    for i,n in enumerate(p):
        ci=s.symbols(f'c{i}_1:{n+1}') if n else ()
        cs.extend(ci);Q.append(z**n+sum(c*z**(n-k-1) for k,c in enumerate(ci)))
    rows=[];boundary=s.Integer(1);disc=s.Integer(1)
    for i,n in enumerate(p):
        if not n:continue
        N=z**max(g[i],0)*s.prod(Q[j]**max(B[i][j],0) for j in range(len(B)))
        E=max(-g[i],0)+sum(max(-B[i][j],0)*p[j] for j in range(len(B)))
        O=(-1)**E*z**max(-g[i],0)*s.prod(Q[j]**max(-B[i][j],0) for j in range(len(B)))
        f=T**a[i]*N-targets[i]*O
        rows.extend(s.Poly(s.rem(f,Q[i],z),z).all_coeffs())
        if g[i]:boundary*=Q[i].subs(z,0)
        if n>1:disc*=s.discriminant(Q[i],z)
        for j in range(i+1,len(B)):
            if p[j] and B[i][j]:boundary*=s.resultant(Q[i],Q[j],z)
    gb=s.groebner(rows+[u*T*boundary*disc-1],u,*cs,T,order='lex')
    sat=[f.as_expr() for f in gb.polys if not f.as_expr().has(u)]
    special=[f.subs(T,0) for f in sat]
    g0=s.groebner(special,*cs,order='grevlex')
    actual=len(standard_basis(g0))
    expected=IncomingSchur(B,D).theta_prefix(tuple(g),tuple(p)).get(tuple(p),0)
    return dict(B=B,D=D,g=g,p=p,targets=targets,degree=actual,theta=expected,
                equals=actual==expected,seconds=time.time()-started,
                discriminant=str(disc),special_groebner=[str(f.as_expr()) for f in g0.polys])


def run():
    cases=[
      ([[0]],[1],[-4],[3]),
      ([[0,1],[-1,0]],[1,1],[-3,-2],[2,2]),
      ([[0,1],[-1,0]],[1,1],[-2,1],[2,1]),
      ([[0,2],[-2,0]],[1,1],[-2,-2],[2,2]),
      ([[0,3],[-2,0]],[2,3],[-2,1],[2,1]),
      ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-2,-1,-1],[2,1,1]),
      ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-2,0],[2,1,1]),
      ([[0,-2,2],[2,0,-2],[-2,2,0]],[1,1,1],[-1,-1,-1],[2,1,1]),
    ]
    out=[]
    for B,D,g,p in cases:
        for targets in [[1]*len(B),[2+i for i in range(len(B))]]:
            result=probe(B,D,g,p,targets);out.append(result)
            Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
            print(json.dumps({k:result[k] for k in ['g','p','targets','degree','theta','equals','seconds']}),flush=True)
    return out
if __name__=='__main__':run()
