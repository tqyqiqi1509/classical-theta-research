from pathlib import Path
import sys,json,random,time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from incoming_recursion import IncomingSchur
from arbitrary_endpoint_ray import endpoint


def mutate(B,g,p,k):
    n=len(B)
    bb=[[(-B[i][j] if i==k or j==k else B[i][j]+max(B[i][k],0)*B[k][j]+B[i][k]*max(-B[k][j],0)) for j in range(n)] for i in range(n)]
    gg=[-g[i] if i==k else g[i]+max(B[i][k],0)*g[k]+B[i][k]*max(-g[k],0) for i in range(n)]
    pp=list(p); pp[k]=max(-g[k],0)+sum(max(-B[k][j],0)*p[j] for j in range(n))-p[k]
    return bb,gg,pp


def run(trials=160):
    rng=random.Random(2611132157);out=[];bad=[]
    for it in range(trials):
        n=2 if it<60 else 3
        D=[rng.randint(1,3) for _ in range(n)];B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                b=rng.randint(-2,2);B[i][j]=D[j]*b;B[j][i]=-D[i]*b
        g=tuple(rng.randint(-3,3) for _ in range(n));p=tuple(rng.randint(0,2 if n==2 else 1) for _ in range(n));k=rng.randrange(n)
        a=[11**i for i in range(n)]
        bb,gg,pp=mutate(B,g,p,k)
        want=IncomingSchur(B,D).theta_prefix(g,p).get(p,0)
        if pp[k]<0:
            got=0;ap=None
        else:
            ap=[-a[i] if i==k else a[i]+max(B[i][k],0)*a[k] for i in range(n)]
            got=endpoint(IncomingSchur(bb,D),tuple(gg),tuple(D[i]*ap[i] for i in range(n)),tuple(pp)).get(tuple(pp),0)
        row=dict(B=B,D=D,g=g,p=p,k=k,Bprime=bb,gprime=gg,pprime=pp,aprime=ap,before=want,after=got,equal=want==got)
        out.append(row)
        if want!=got:
            bad.append(row);print('FAIL',json.dumps(row),flush=True)
            break
    result=dict(status='PASS' if not bad else 'FAIL',inputs=len(out),nonzero=sum(r['before']>0 for r in out),failures=bad,examples=out[:12])
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
if __name__=='__main__':run()
