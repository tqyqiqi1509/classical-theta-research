# Good frozen-root derivations and theta-based degree filtrations

2026-11-14. A derived corollary combining the new positive-shear action with an explicitly audited 2026 input. This is not claimed as an independent new valuative-independence theorem or as theta BK-perfectness.

## 1. Precise space and operator

Work in characteristic zero. Let \(\mathcal M^+\) be the finite theta middle algebra with polynomial principal frozen coefficients: its full theta basis consists of the finite normalized theta functions and their nonnegative frozen monomial translates. Fix one frozen variable (y\), and suppose the optimized frozen-root operator is

\[
R=M(x)\partial_y,
\]

where (M\) is a monomial independent of (y\). In the principal coefficient construction (R_i=x_i\partial_{y_i}\). The positive-shear theorem proves that its divided powers preserve the nonnegative theta cone. The general nonnegative frozen-row extension uses the corresponding (M\).

Every element of \(\mathcal M^+\) is polynomial in (y\), and multiplication by (M\) is injective. Therefore

\[
R^k f=0\quad\Longleftrightarrow\quad\deg_y f<k.
\tag{1}
\]

## 2. The old theorem used, with its finite scope

Cheung–Magee–Mandel–Muller, *Valuative independence and cluster theta reciprocity*, arXiv:2505.09585v2 (2026-05-21), Theorem 3.8 states

\[
\operatorname{val}_v\Bigl(\sum_\lambda c_\lambda\theta_\lambda\Bigr)
=\inf_{c_\lambda\ne0}\operatorname{val}_v(\theta_\lambda)
\]

when the right-hand side is finite. The statement and proof were read in the primary text, including the generic-valuation argument and extension to nongeneric valuations. Here the sum is finite and every theta is a finite Laurent polynomial, so the required finiteness is automatic for the valuation (v=-e_y\).

That valuation equals minus the largest (y\)-degree. Thus for any finite theta linear combination,

\[
\deg_y\Bigl(\sum_\lambda c_\lambda\theta_\lambda\Bigr)
=\max_{c_\lambda\ne0}\deg_y\theta_\lambda.
\tag{2}
\]

In particular, even signed linear combinations cannot cancel their maximal frozen degree. No specialization theorem, full Fock–Goncharov theorem, or equality of the upper and middle algebras is needed.

## 3. The based nilpotence filtration

Combining (1) and (2) gives

\[
\boxed{\ker R^k
=\operatorname{span}\{\theta_\lambda:
\deg_y\theta_\lambda<k\}.}
\tag{3}
\]

The nilpotence order of an individual basis element is exactly

\[
\varepsilon_R(\theta_\lambda)
=\max\{j:R^j\theta_\lambda\ne0\}
=\deg_y\theta_\lambda.
\tag{4}
\]

Thus the theta basis is good for this locally nilpotent derivation in the based-kernel sense used in the BK framework. Together with positive divided powers, this is a concrete connection to Fei's optimized frozen derivations. It does **not** produce a unique highest-string successor, which is a further requirement in a perfect/biperfect basis statement.

For the commuting principal operators, intersections are based as well:

\[
\bigcap_i\ker R_i^{k_i}
=\operatorname{span}\{\theta_\lambda:
\deg_{y_i}\theta_\lambda<k_i\text{ for every }i\}.
\]

More generally, for any nonnegative weight vector (w\), valuative independence makes the finite weighted-degree subspaces theta-based. The operator (R_i\) lowers their weighted degree by (w_i\). This gives a compatible family of Newton-height filtrations, rather than only one frozen-variable filtration.

## 4. Audit and priority boundary

The no-cancellation assertion is a direct application of CMMM Theorem 3.8, not a new proof of valuative independence. The new action supplies theta-positive divided powers and preservation of the finite polynomial-frozen theta algebra. Their combination gives (3)–(4). Fei's own root-derivation and generic-character crystal statements remain separate; no identification of theta with generic characters is made.

The cited Theorem 3.8 argument uses that paper's own valuative-tautness results and classical scattering positivity. Its later discussion of Li–Pan in the Newton-vertex section is not an input here, and no Li–Pan conclusion is imported.

Primary source: https://arxiv.org/abs/2505.09585 . The local audited copy is `../fei_newton_interface/sources/cmmm_2505.09585v2.txt`; the web reference read in this branch is `turn776view0`.
