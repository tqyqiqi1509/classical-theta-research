# Fresh finite-support mechanism search

Started 2026-11-13 23:04 UTC. Classical skew-symmetric first, then symmetrizable. No Li–Pan theorem is used.

## 1. Fresh primary-source audit: Fei, 2309.08326v4

**Source:** Jiarui Fei, *Crystal Structure of Upper Cluster Algebras*, arXiv:2309.08326v4, revised 2026-11-11, 77 pages. Primary metadata https://arxiv.org/abs/2309.08326; full text https://arxiv.org/pdf/2309.08326v4. Retrieved and read: introduction; Proposition 8.1 with full proof; Lemma 8.5 with full proof; Theorem 8.10 and Corollary 8.11 with proof. Earlier representation-theoretic ingredients, especially Theorems 3.7 and 5.5, have not been independently reconstructed in this fresh branch.

**Scope checked against the text:** frozen-Jacobi-finite nondegenerate ice quivers with potential; reachable frozen vertices; compatible grading and additional hypotheses where stated. The crystal is on presentation weights indexing generic characters, not directly on the monomial support of one F-polynomial. Theorem 8.10 assumes generic characters form a basis. The theta and triangular bases being BK-biperfect remain conjectural in the introduction, despite the version metadata saying that all conjectures were settled. The metadata wording must not be promoted to a theorem about theta.

**Useful proved interface:** at an i-optimized seed, with i frozen and a sink relative to mutable vertices,

    R_i = (product_{u -> i} x_u) partial_{x_i}

is a locally nilpotent derivation preserving the upper cluster algebra (Proposition 8.1). The adjacent-mutation check is explicit: if x_u x_u' = A x_i^m + B and x_u divides the coefficient of the derivation with multiplicity m, differentiating the exchange relation gives a Laurent element in the adjacent chart. Full-rank reduction plus addition and specialization of frozen sources remove the temporary full-rank hypothesis used in this local argument. Local nilpotence uses polynomial frozen variables, not invertible ones.

**Useful generic-character string:** if n = rho_i(delta) = -delta(i) at the optimized seed,

    R_i^n C_gen(delta) = n! C_gen(r_i^n delta),

and the first derivative differs from n C_gen(r_i delta) by an element killed by R_i^{n-1} (Lemma 8.5). The proof compares quotient Grassmannians under an exact sequence and identifies precisely the terms of maximal frozen degree; it does not assert positivity of the residual basis expansion.

**Use status:** useful new lowering-operator interface; not accepted as a proof of theta support accessibility. No apparent local error found in the read statements/proofs, subject to unreaudited earlier inputs. Theta positivity of these derivations remains a genuinely missing bridge.

## 2. Other literature searches

Queries included "F-polynomial connected support", "F-polynomials no gaps", theta support connectedness, quiver-Grassmann support saturation, and 2026 Fei crystal updates. No source retrieved proved arbitrary-theta coordinate support accessibility or total-degree no gaps. This is only a search result, not an absence-of-literature theorem.

* Fei 1909.10151: saturation for rigid representations and acyclic interfaces; does not identify arbitrary theta supports with all submodule dimension vectors. Previously audited by the parent branches; no new claim imported here.
* Rank-three Newton-polytope paper, Algebraic Combinatorics DOI 10.5802/alco.141: §5 supplies polyhedral support restrictions, but its Remark 5.3 still treats saturation generally as a conjecture. No general accessibility conclusion used.
* 2026 dimer-face-polynomial work, DOI 10.1007/s00029-026-01146-w: dimer/surface scope; not imported into arbitrary exchange matrices.
* Qiyuetang Hexagon 2611.00006v1 (MV=theta), 2610.00614v1 (MV pointedness), and 2611.00190v2 (Lusztig positivity) were located. The MV comparison is for C[N] of semisimple groups; no arbitrary-B extension is inferred. Its Fei reference predates the new November 11 revision. Metadata only in this branch, so not a proof dependency.

## 3. Mechanism attempts being developed

### 3.1 Positive root-derivation shear

The Fei derivation exponentiates at an optimized seed to a shear x_i -> x_i + t product_{u->i} x_u. Both the initial chart and the single adjacent mutable charts have manifest positive Laurent expressions. This alone does not prove positivity in every scattering chart: differentiating a negative exponent can introduce signs, and upper-algebra preservation is weaker than theta-positive expansion. The general bridge is under investigation, not claimed.

Even a positive theta expansion would need a second argument to yield accessibility within one fixed F-polynomial. With principal coefficient variable y_i and z_i = y_i x^{B e_i}, the rank-one-looking operator x_i partial_{y_i} sends

    x^g F_g(z) -> x^{g+e_i+B e_i} partial_{z_i} F_g(z).

The label shift contains the column B e_i and is not coordinatewise positive in general. Initial-variable multiplication monotonicity alone does not close the gap.

### 3.2 Cyclic graded module criterion

If there is a module V_g = direct_sum_p V_{g,p}, generated by a degree-zero vector under operators of degrees e_i, with dim V_{g,p} = a_g(p), then support accessibility is immediate from a nonzero word and one of its nonzero prefixes. The old naive spherical module has incorrect dimensions (and even an incorrect support example), so it is excluded. A possible attractor-ideal correction must be proved to give the exact theta module and retain this cyclic generation; no such equality is assumed.

### 3.3 Root deletion in the positive Gale factor

Deleting a colored root changes each remaining endpoint exponent by B_{ji} val(x_j-x_removed). Positivity and equality among equal-color targets are not automatic. Arbitrary positive choice of the initial endpoint, followed by a hierarchical-target limiting argument, might provide a deletable leaf, but no induction has yet been established. A proof must include repeated colors and Young-sign nonvanishing; a raw uncolored solution is insufficient.

## 4. Known checks are not proofs

The parent branch's 1,800 inputs and 19,470 support checks are supporting data only. This branch does not repeat those checks as a substitute for a mechanism. The stronger proposed deletion rule requiring a negative endpoint exponent was already falsified and is not used.

## 5. 23:20–23:45 UTC refresh: a positive-shear mechanism

The source-leaf extension and high transverse path lift led to the proof draft `FREEZING_POSITIVE_SHEAR_DRAFT.md`. The root reviewed the main mechanism and requested the explicit completed inverse, which has now been added. The finite result is that all divided powers of x_i partial_{y_i} preserve the finite theta-positive cone for normalized principal theta functions. This yields the residual support inequalities in `DERIVATIVE_RESIDUAL_SUPPORT.md`. The proof is not inferred from the numerical probes.

### Primary sources checked for this mechanism

1. **Mandel, arXiv:1605.03202v2, *Theta bases are atomic*.** Entire three-page paper read. Theorem 1 and its proof explicitly concern a topological theta algebra A. The proof extracts a theta coefficient c_p as a monomial coefficient in the scattering chart near p, citing GHKK Proposition 6.4. Thus the positivity argument is not restricted to an already finite expansion. The completed inverse in the draft supplies the required expansion for a finite initial Laurent polynomial. This source is accepted for that precise coefficient-extraction interface.

2. **Qin, arXiv:2407.03186v1, *Applications of the freezing operators on cluster algebras*.** Read §5.1/Lemma 5.1, the statements around Theorem 6.17, and Proposition 6.19. Lemma 5.1 identifies the diagram obtained by killing all root degrees using a frozen index with the diagram of the frozen seed. Theorem 6.17 is a basis/localization theorem with full-rank, basis, Property (S), factorization, and additional hypotheses inherited from Theorem 6.13. Section 6.4 initially assumes injective reachability for its upper-algebra basis statements. These assumptions must not be dropped. Proposition 6.19 itself is a finite-theta shift statement, and its last-bend proof can be applied to finite constituents without assuming upper=middle. The parent has reconstructed a finite positive-freezing proof by combining this shift mechanism with strong multiplication positivity. Thus positive freezing in isolation is very close to existing Qin mechanisms; novelty should be assessed for the resulting coefficient shears, divided-power positivity, and residual support inequalities, not advertised merely for the freezing lemma.

3. **Fei, arXiv:2309.08326v4.** Rechecked occurrences of positivity, theta, and biperfectness, including Remark 7.8. That remark explicitly distinguishes the span of generic characters, the middle algebra, and the upper algebra, and states generic/theta characters need not agree individually. The root derivation theorem proves preservation and local nilpotence; the generic-character string theorem proves a leading string estimate. Neither read passage asserts the nonnegative theta expansion of every divided derivative. The theta and triangular BK-biperfectness problem remains distinct from the shear-positivity result here. No priority claim is made from search absence alone.

4. **Cheung–Magee–Mandel–Muller, arXiv:2505.09585v2 (2026-05-21).** Read the introduction's unfreezing statements and scope. Its unfreezing theorem requires an extension lying in the relevant finite theta span in the application; regularity is upgraded to finite theta span via full Fock–Goncharov in the moduli-space example. The source-leaf argument in our draft instead forces the new-root degree to vanish directly. We do not use this 2026 theorem to assume general upper=middle.

### Additional search outcome

Queries for theta-positive derivatives, Demazure roots, additive-group actions on theta functions, positive freezing, and theta root operators located no exact statement of the principal-coefficient divided-power theorem. Fei is the closest root-derivation interface; Qin/Mandel supply the closest freezing/positivity mechanism. This is a bounded novelty assessment, not proof of priority.

## 6. A fresh finite-stopping mechanism tested and corrected

Positive divided derivatives imply that a sequence of firings at i with

    g_i+p_i+(Bp)_i < 0

gives supported root degrees. It was natural to ask whether these legal words at least reach the largest total support degree, even though exact support equality is already too strong. An exact search quickly falsified this proposed degree certificate:

    B=[[0,-2,3],[2,0,-3],[-3,3,0]], g=(-1,1,1).

The legal graph closes after seven states, at maximum degree 6, but a_g(2,3,2)=1 has degree 7. The graph is explicitly finite and the coefficient was independently recomputed. This route is retired in that form. Nonconstant frozen coefficients in the positive derivative action cannot be discarded.

The remaining useful general statement is the residual-theta support inclusion: for supported r, the finite theta at h=g+(I+B)r has r+Supp(F_h) contained in Supp(F_g). This also gives the terminal constraint g+(I+B)r>=0 for every coordinatewise maximal supported r. It does not yet provide a bounded outer support polytope or a stopping theorem.

## 7. Computation receipts

* `derivation_probe.py`, `derivation_probe_large.json`: 1,550 exact derivation expansions, 2,353 nonzero coefficients, no negative coefficient; random ranks 2–4 and mixed signs. Motivating data only.
* `mixed_derivative_inequality_checks.json`: 500 random skew-symmetrizable inputs, 9,526 nonzero mixed inequalities checked, all passed. The proof is the positive divided-power expansion, not the tests.
* `legal_firing_probe.py/json`: the explicit degree-cofinality counterexample above.
* Wolfram Language computation plugin: 1,000 random rank-2–12 leaf matrix mutations and 136 binomial coefficient identities, all passed. The first call used an accidentally reused symbol and reported `Coefficient::ivar`; it was corrected in a fresh Module, and only the corrected call is used. The symbolic matrix mutation and ordinary binomial theorem remain the proofs.

## 8. 23:54–00:14 UTC: general firing criterion corrected; nonvacuum algebra constructed

The parent proposed the weaker converse “all legal vacuum firing paths terminate implies finite theta.” A rank-nine example from GHK's birational geometry disproves that converse. The primary geometric interfaces were read: Construction 5.3 / Proposition 5.4, Theorem 6.2 proof, Example 6.3, and §7 of arXiv:1309.2573v2; and GHKK Proposition 7.1 / Construction 7.11 / Definition 7.12 in arXiv:1411.1394v2. The exact classical skew-symmetric seed has three groups of three vertices with cyclic all-ones blocks, and g=B e1. Its full legal graph has 464 states, 91 symmetry orbits, and maximum total degree 27. A verifier without a degree cutoff exhausts the queue and checks the supplied closed graph. Nevertheless the normalized theta is infinite, since multiplying it by y1 would otherwise descend to an X-function with a nonkernel exponent, contradicting Up(X)=k[K]. The rank-three weighted/singular variant is not used. Full argument: `FINITE_FIRING_DOES_NOT_CERTIFY_THETA.md`.

This is a correction of the proposed stopping mechanism, not a main output or a new program of collecting exclusions. Work immediately moved to the entire nonvacuum derivative action.

For every divided-derivative branch coefficient d(g;r,q), the simultaneous leaf construction gives one coefficient of C=[[B,I],[-I,0]], label (g,0), root degree (q+r,r), with old endpoint near g+(I+B)r+Bq and leaf endpoints large positive. The independent positive-shear reviewer checked the exponents and detector. Eliminating the leaf remainders gives Q_i=P_i S_i+(-1)^(q_i+r_i)T^L_i, with degrees r_i,q_i. The old-leaf resultant is a pure T-power, so it introduces no additional saturation. The resulting explicit finite algebra is in `DIVIDED_DERIVATIVE_BRANCHING_ALGEBRA.md`.

At 00:00 UTC the Wolfram computation plugin checked the exact leaf-remainder and resultant identities for all 42 symbolic degree pairs 1<=r<=6 and 0<=q<=6. Both identities passed in all cases. These are checks of the elementary elimination identities, not proof of the global coefficient theorem. The independent reviewer subsequently checked the general symbolic argument, including r=0 and phase signs.

## 9. 00:14–00:34 UTC: two-scale positive geometry and a based derivative filtration

The parent suggested a genuine model-level product stratum for the residual inequality. This developed into `SEPARATED_MARKED_Q_FACTOR.md`.

The selected old roots split as Q=U V, with U in an inner delta-valuation layer and V in an outer T-layer. The leaf polynomial P is the unique inner Hensel factor of Q-c; it is not assumed to follow individual U-roots. At an inner U-root, P=-c/S exactly. This leaves inner framing g, with explicit sign/unit target corrections. At an outer V-root, P behaves as z^r and U_j as z^(r_j), producing the framing h=g+(I+B)r. A bounded unit homotopy joins the actual separated equations to an inner finite-flat coefficient family pulled back over the outer coefficient algebra. Uniform inner windows, outer nilpotent-power bounds, strict affinoid interior, the exact remainder-equation count, and miracle flatness give the candidate product-rank factor without a distinct-root assumption.

An actual issue was found and repaired explicitly: the unperturbed outer algebra can have coordinate zero when h_i=0. A generic allowed equivariant polynomial target perturbation avoids this by a finite equality-stratum/evaluation-rank argument. No coordinate or discriminant saturation is added. The selected generic factor is specialized by two saturated DVR lattices; the original special fiber is not claimed to be a direct product. The parent read the full proof and accepted the main finite-flat mechanism in review, requesting two details now added: finite-algebraic descent of the selected factor before single-weight substitution, and the sign-projector/direct-summand justification for compressed-family flatness.

The full two-scale cover also has a new exact structural lemma: at first endpoint (old=0, leaf>0), every nonframe residue cluster containing a leaf violates its cut equation. Hence all leaves lie in the frame cluster. If u is the old inner degree then u>=r, so the marked factor is stratified by u=r+q with 0<=q<=p; its outer framing is h+Bq. The q=0 factor is controlled above. For q>0, old-only zero-cut clusters remain, and uniform finite/no-escape control is still open. This is being attacked jointly with the fresh finite-mechanism agent; no generic-rank theorem is silently applied at that zero endpoint.

A useful exact reparametrization of that core was derived: its homogeneous row-degree vector is (m,-u), where m=h+Bq. Scaling every core coordinate x=delta^t xi sends endpoint (0,a) to (t m,a-t u). This moves to the coefficient-detector direction but does not automatically repair rank genericity: the homogeneous degree vector is a common hierarchy root-depth column. The coefficient of final monomial m does not jump across old walls orthogonal to m, yet nongeneric algebra length still needs a no-escape argument.

### 2026 primary-source audit refreshed

CMMM, arXiv:2505.09585v2 (2026-05-21), Theorem 3.8 and its proof were read directly at web reference `turn776view0`. The finite theta case at v=-e_y satisfies its finiteness premise automatically. It implies that maximal frozen degree cannot cancel in a finite theta linear combination. Combining this old theorem with the new R=M partial_y action proves ker R^k is spanned by theta elements of y-degree < k, so these derivations are good in the based-kernel BK sense. This is recorded as a derived corollary in `GOOD_DERIVATION_FILTRATIONS.md`, not as a new valuative-independence result or a proof of BK-perfectness. The paper's later Li–Pan discussion is not an input.

Additional primary-source search was made for finite Gröbner-weight perturbations and universal factorization algebras. The independent reviewer is auditing Laksov–Thorup and Gatto–Santiago for the Schur-basis marking module; I do not use their statements without that review. The two-scale proof uses only the elementary finite-weight realization of an iterated initial ideal, to be stated with a complete ideal/Gröbner basis rather than merely the displayed generators.

## 10. 00:34–01:14 UTC: generic-residue core, full layers, and one-T origin algebras

The joint zero-cut problem was resolved by the generic-residue detector-window argument in the fresh finite-mechanism branch. Only initial components dominant over the actual color-target torus are retained at a generic residue; this avoids replacing color-generic targets by falsely independent root targets. The connected target annulus transfers the rank from nearby generic endpoints. Equal-rank nested deep factors give the full old-zero/leaf-positive factor. A fixed good color open and fixed perturbation direction make this a family statement, so it can be pulled back over a nonreduced outer factor. The parent independently audited the central dominance and annulus steps.

This supplies the nonvacuum inner core in `FULL_MARKED_Q_LAYER_DECOMPOSITION.md`. The actual disjoint factors have inner old degree r+q, leaf degree r, and outer degree p-q. Their lengths are d_(g;r,q) a_(h+Bq)(p-q). CRT gives independent core target constants while fixing outer remainders. The independent fresh reviewer strengthened this to a statement on every dominant incidence component; inverting the finite-flat multiplication determinant makes the core good-open condition hold over the entire outer Artin factor. The factor construction is geometric; coverage uses the separately proved positive derivative convolution. It is not advertised as a pure combinatorial injection or a direct product on the original special fiber.

The generic-unit theorem permits all ordinary primitive endpoints to be one, and derivative endpoints to be old zero/leaf one. This removes large generic integer endpoint choices. `UNIVERSAL_UNIT_COEFFICIENT_ALGEBRAS.md` gives a single-T algebra, actual-boundary saturation, and the origin-local special fiber. The origin-completion finiteness step was proved by an explicit parameter/valuation argument, not by assuming finite positive points automatically imply an Artin special quotient. The fresh reviewer reconstructed that argument. Primary Stacks tags 00MB, 031C, 00U8, 00KW, 031D and 032D were checked for the exact completion, dimension, finiteness, and idempotent-factor interfaces; the proof retains a self-contained algebraic chain.

The executable `universal_unit_coefficient.py` and `origin_macaulay_length.py` implement exact generic-unit saturation followed by finite truncated Macaulay matrices. Equality of two successive local truncated lengths is a Nakayama stopping certificate. Ordinary A2 coefficient 6 and derivative coefficient 4 were independently checked; the latter has an entire special quotient of length 6, demonstrating why the origin factor is essential. The generic-symbolic Markov saturation was interrupted after becoming expensive and remains explicitly uncompleted. The parent independently has the numeric-generic Markov value 7 and the incoming value 7; these do not replace the general proof or a missing symbolic run.

## 11. 01:14–01:34 UTC: a complete-support mechanism from zero-endpoint complement mutation

The fixed-leaf core suggests mutating an old zero-endpoint index without changing the positive leaf endpoints. Its row reduces at the coefficient origin to z^alpha-lambda z^beta. Generic lambda makes its positive Weierstrass degree min(alpha,beta), so a nonzero factor requires the complementary degree min(alpha,beta)-P_k to be nonnegative. Matrix and framing update are the ordinary extended-matrix mutation. This gives necessary conditions after every finite word and hence a finite-support certificate if their degree set is bounded. The full-theta interface is d_(g;p,0)=a_g(p), with doubled degrees (p,p).

Two genuine proof gaps were found rather than hidden. First, the old nonzero-endpoint argument had used complete-color/frame separation, which need not hold in the unperturbed zero-endpoint core. Second, the arbitrary mutated mixed-endpoint core required constant rank for its nested deep factors, not just the special derivative detector. Both were repaired in the next interval. The main proof is `ZERO_ENDPOINT_Q_MUTATION_AND_SUPPORT_CERTIFICATES.md`.

Benini–Park–Zhao, arXiv:1406.2699, Section 3.3 and equations (3.29)–(3.39), was reopened. Complementary-polynomial identities are existing machinery. Its full-degree maximum, strong/weak distinction, and restricted chiral-ring claims cannot be imported to the positive-origin factor without new work. The Q-system search also located q-oper/QQ interfaces; no unverified nondegeneracy theorem was used.

## 12. 01:34–01:55 UTC: full-Artin proof repaired, executable certificate, novelty reduced

The zero-endpoint separation repair uses bounded equivariant polynomial target perturbations with constant residue. The full positive family remains finite flat. Its incidence is an analytic domain in a graph over the actual-arrow-open monic configuration space; generic perturbations avoid proper coordinate-zero and intercolor-resultant divisors without adding those divisors to the saturation. Complement and inverse division then identify the old full Artin algebra with an open-and-closed factor of the new coupled-unit algebra. Homotoping normalized units gives one length inequality; a separately constructed reverse mutation gives the opposite inequality. The undeformed special algebras are not asserted to be isomorphic.

For arbitrary fixed C,G,P, the parent and fresh reviewer supplied the missing rank-constancy step: finitely many cut, rank, feasible-hierarchy/flow, and finite scattering sign forms determine the relevant chamber. One fixed generic direction makes mu_0+t(M+eta nu) stay in the same chamber for all small t. The generic selected-Q length is consequently constant; connected annuli and nested equal-rank deep factors prove the general mixed-endpoint finite-flat theorem. The proof does not need to name that generic length as a theta coefficient at an arbitrary signed endpoint. The independent zero-endpoint reviewer read the complete repaired proof and found no remaining material objection.

`zero_endpoint_support_certificate.py` implements arbitrary classical skew-symmetrizable B,g and finite old-index words, with optional fixed r. It stores each prefix's degree state, covers every min branch, checks exact Farkas contradictions and coordinate dual certificates, and returns an explicit recession ray on failure. A bounded result feeds the audited finite coefficient recursion and returns the entire Laurent polynomial. The cyclic validation has 32 feasible branches, 96 coordinate bounds, and 18 output terms; Wolfram independently verified all 96 dual bounds. A separate LP-free reviewer checked the saved arithmetic and exhaustion argument. A SymPy invalid primal witness was detected by exact verification and replaced by exact rational vertex enumeration; it was never accepted. Empty-word inputs initially lacked a feasible-point field; that runtime defect was fixed and independently rechecked. Failure to certify never means the theta function is infinite.

### Strong primary novelty refresh

Reading–Stella arXiv:2603.19391v4, dated 8 November 2026, was directly read in Section 5.3: the definitions of psi, phi, nu and N, Theorems 5.6–5.7 with the former's proof, Lemmas 5.10–5.12, and Section 5.4/Remark 5.15. Its nonnegative mutation-word conditions, pointed elements, signed-nondegenerating coefficient hypotheses, and mutation-fan restrictions are recorded rather than ignored. No general strategy of intersecting tropical inequalities is claimed as new.

The root's fresh novelty review identified an exact standard interpretation, stronger than a vague resemblance: take auxiliary mutable block C-transpose, add frozen framing row G-transpose, and freeze the leaves. With weights (P,1), the degree rule is exactly tropical A mutation. Fomin–Zelevinsky, math/0602259v3, equations (2.13)–(2.15), and GHKK1411.1394v2, Theorem 4.10, were opened to verify the extended matrix and positive Laurent interfaces. Every resulting degree is the minimum of finitely many Laurent-support affine forms. Thus the complete certificate set is a convex rational polyhedron; the code's branch union is merely a redundant representation. Formula, convexity, halfspaces, and LP are all standard consequences and removed from novelty claims. The remaining candidate contribution is full-Artin positive-origin length invariance and the doubled-core theta-support bridge, without an assertion of historical priority.

Fei1911.10513v6 was reopened at Theorem 5.1 and its proof, Remark 6.10 and Conjecture 6.11. The module Newton polytope already has a hom-halfspace presentation. Its theta/triangular equality with the generic representation polytope is a conjecture in that text, and the finite-dimensional Jacobian assumptions remain visible. This gives an important interface but cannot identify an arbitrary theta with a module character. The 2026 paper on modules determined by Newton polytopes appeared in the search; only its metadata/abstract was inspected, and it is not used as an input.

## 13. General consequence of the convex certificate, before final handoff

The homogeneous recession test is independent of the label. For full-theta degrees (p,p), the polyhedron always contains p=0, and its recession cone is the degree cone with framing-variable weight zero and initial degrees (v,v). The framing vector g drops out of every tropical mutation. Therefore a fixed word set is bounded for one label exactly when it is bounded for all labels of that matrix. This gives a reusable matrix-level all-label construction when the criterion succeeds; the affine bounds still depend on the label. It also explains its exact limitation: a matrix having any infinite formal theta cannot admit this certificate, even at a finite label. For fixed divided derivatives the nonempty polyhedron's recession test uses (v,0) and is independent of g,r. This is a general structural conclusion, not another special-case exclusion exercise. It is recorded as a standard polyhedral consequence of the support bridge, with no claim that every regular theta is decided.

The fresh reviewer then reduced the numerical support bridge further. His `NOVELTY_REDUCTION_AND_CONVEXITY.md` gives a direct proof from GHKK Definition 8.2 and Proposition 8.14, plus the already established positive-freezing/Mandel detector. For the doubled C, h_t(M)-h_t(G) is exactly the iterated tropical degree. The principal separation formula makes the nonlinear walls of h_t depend only on the old coordinates, so the detector germ realizes (dh_t)(M)=h_t(M). A nonzero broken-line coefficient and min-convexity imply the nonnegative degree. This bypasses the full-Artin Q mutation theorem. The parent independently checked the primary GHKK passages and the separation formula. The main manuscript now includes this direct proof and explicitly retracts novelty for the numerical support inequality itself. Only the full-Artin origin-factor realization and length invariance remain a distinct candidate contribution, still without a blanket priority claim.

The same separation calculation gives principal B-transpose halfspaces (a+b).p >= h_t(g)-b.g, where X_t=sum c_ab x^a y^b and h_t(g)=min_b b.g. Hence the normals are fixed for B and the word set. Fixed exact dual multipliers yield reusable bounds U_i(g)<=C_i ||g||_infinity. This is a useful concrete all-label algorithm interface whenever the homogeneous cone certificate succeeds, presented as a standard separation/polyhedral corollary. The present code implements the equivalent branch decomposition; a second fixed-normal backend has not been claimed or silently substituted.
