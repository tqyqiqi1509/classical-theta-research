# A separated marked-Q factor for the residual-support inequality

2026-11-14. Proof draft submitted for adversarial review. Classical skew-symmetric and skew-symmetrizable data. This supplies a model-level route to the inequality; it does not assume the positive theta branching theorem in order to infer the factor's existence.

## 0. Statement, choices, and precise scope

Let (B\) be an integral skew-symmetrizable matrix, (g\in\mathbb Z^n\), and (r,p\in\mathbb N^n\). Put

\[
m=p+r,\qquad h=g+(I+B)r.
\]

The marked coefficient is the initial-positive-chamber coefficient of the leaf-extended matrix

\[
C=\begin{pmatrix}B&I\\-I&0\end{pmatrix},\qquad
G=(g,0),\qquad (m,r).
\]

By the source-face theorem and the explicit commuting leaf mutation (z_i=z_i'(1+w_i)\), its value is

\[
M_{g;r,p}=\binom{p+r}{r}a_g(p+r).
\tag{0.1}
\]

This is **not** the detector-endpoint derivative branching coefficient (d_{g;r,p}\). In this note all old endpoint coordinates are positive, and the leaf coordinates are much larger and positive.

The proposed geometric theorem is as follows. After a permitted bounded equivariant target deformation and finite field extensions/ramifications, the generic marked coefficient algebra has an isolated finite factor of length

\[
a_g(r)a_h(p).
\tag{0.2}
\]

It is obtained by placing exactly (r_i\) old roots and all (r_i\) leaf roots in an inner valuation layer, with the remaining (p_i\) old roots in an outer layer. The separated factor is a flat deformation of the pullback of the inner finite-flat coefficient family over the outer coefficient algebra. The pullback has rank (a_g(r)\) over the outer algebra, hence length (0.2).

Saturated lattice specialization gives a subspace, in fact an ideal as a module under the ambient algebra, of dimension (0.2) in the original marked special fiber after residue-field extension. This subspace is defined by closure of the selected generic factor. It is not an arbitrary dimension-based embedding. We do **not** assert that the original special algebra is a direct product, or that this subspace is canonically isomorphic as an algebra to \(\mathcal Q_{g,r}\otimes\mathcal Q_{h,p}\).

Consequently the model itself gives

\[
\binom{p+r}{r}a_g(p+r)\ \ge\ a_g(r)a_{g+(I+B)r}(p).
\tag{0.3}
\]

The inequality is already known from the independently proved positive-shear theorem. Here the requested new content is the selected finite factor, its two-scale equations, and its deformation construction. No stopping or support-connectivity conclusion is inferred.

## 1. Inputs used

1. The already reviewed signed/global monic-Q coefficient theorem, including its positive-endpoint version.
2. The already reviewed full target-annulus window and finite-flat theorem, including bounded equivariant polynomial target perturbations. See `../gale_boundary_round2/AFFINOID_FINITE_FLAT_BRIDGE.md`, §§1–4.
3. Ordinary monic Hensel factorization for two factors with coprime reductions.
4. The strict-generator relative-interior criterion for an affinoid morphism to be finite, and miracle flatness for a finite Cohen–Macaulay source over a regular base. These are the same standard analytic/algebraic inputs already read and used in the full-annulus theorem.
5. The finite Gröbner-weight perturbation principle for replacing a two-stage initial degeneration by a sufficiently separated single weight. Its role is spelled out in §7; no arbitrary substitution into an infinite Hensel series is made.

The coefficient-field characteristic is zero. All lengths may be checked after field extension; this does not change their numerical values.

## 2. The exact marked equations and the two scales

Choose positive rational endpoint coordinates (b\) generic for the coefficient (a_h(p)\), and positive rational (a\) generic for (a_g(r)\). Clear denominators. First use two parameters (T,\delta\), with \(\delta\) infinitesimal relative to the coefficient field \(K=\Bbbk((T))\). The old targets are

\[
t_i=T^{-b_i},
\]

and the leaf target equations use \(\delta^{a_i}\). Write

\[
\kappa_i=(-1)^{m_i},\qquad c_i=\kappa_i\delta^{a_i}.
\]

The monic leaf elimination proved in `DIVIDED_DERIVATIVE_BRANCHING_ALGEBRA.md` is

\[
Q_i=P_iS_i+c_i,\quad \deg Q_i=m_i,\quad
\deg P_i=r_i,\quad\deg S_i=p_i,
\tag{2.1}
\]

when (r_i>0\). When (r_i=0\), take (P_i=1\), (S_i=Q_i\), and omit (c_i\) and the leaf equation.

For a root (z\) of (Q_i\), the old primitive row equation is

\[
\varepsilon_g(m)_i^{-1}
z^{g_i}P_i(z)\prod_jQ_j(z)^{B_{ij}}=t_i,
\quad
\varepsilon_g(m)_i=(-1)^{[-g_i]_++\sum_jm_j[-B_{ij}]_+}.
\tag{2.2}
\]

This equation means monic remainder vanishing after clearing actual-arrow denominators. It is not restricted to distinct roots. The signs in (2.2) are retained throughout.

We also allow the parent's bounded polynomial deformation on old rows only:

\[
t_i\longmapsto f_i(z)=t_i-\eta T^N\phi_i(z),
\qquad \deg\phi_i\le m_i-1,
\tag{2.3}
\]

with bounded coefficients and sufficiently large (N\). The leaf equations remain unchanged, so (2.1) is still exact. The full-annulus theorem makes this marked family finite flat and preserves the marked coefficient length. The role of \(\eta\) is to allow a generic deformation and then return to the original fiber.

For the outer-origin avoidance below, it is enough to restrict further to \(\deg\phi_i\le p_i-1\) when (p_i>0\), and to set \(\phi_i=0\) when (p_i=0\). Thus the deformation simultaneously lies within the already proved degree bounds for both the big marked family and the outer (h,p\)-family; no extension of the perturbation theorem to higher degree is needed.

## 3. Removing the only outer-origin obstruction

An outer coefficient algebra may have a root equal to zero at a color with (h_i=0\); there is then no frame arrow excluding that point. It would be wrong to assume (V_i(0)\) invertible in every fixed-target outer algebra.

Use (2.3) generically to avoid **all coordinate-zero loci**, without saturating by them and without removing any same-color diagonal.

Here is the transversality argument. Stratify the labeled-root configuration space by its finitely many equality partitions. On a stratum, let (s_i\) be the number of distinct coordinate values of color (i\), and let (d\) be the number of distinct free coordinate values across all colors. There are \(\sum_i s_i\) distinct row equations. The coefficients of \(\phi_i\) evaluate surjectively onto these (s_i\) values, since (s_i\le p_i\le m_i\) and a degree-((m_i-1)\) polynomial has an evaluation matrix of rank (s_i\). Therefore the incidence variety of row equations has the expected parameter codimension \(\sum_i s_i\). Requiring one coordinate value to be zero leaves at most (d-1\le\sum_i s_i-1\) free coordinate values. Its parameter image consequently has codimension at least one. If zero is included as a frame block in the partition, the same count gives (d\le\sum_i s_i-1\) directly.

The union over the finitely many strata is still a proper algebraic subset of the parameter space. The bounded parameter polydisc meets its complement, exactly as in the parent's Hermite perturbation argument. Thus a generic allowed deformation has no outer coordinate equal to zero. This argument does not require roots of the same color to be distinct. Scheme multiplicities remain in the finite-flat family.

Fix such a generic deformation temporarily. The outer algebra is the finite positive-(T\) factor for (B,h,p\), with the corresponding polynomial row targets and constant signs described below. It still has length (a_h(p)\), and all (V_i(0)\) are units in its generic (T\)-fiber.

## 4. Inner/outer factorization and exact row reduction

Write the actual old polynomial as

\[
Q_i=U_iV_i,
\qquad \deg U_i=r_i,\quad\deg V_i=p_i.
\tag{4.1}
\]

All roots of (U_i\) have positive \(\delta\)-valuation. All roots of (V_i\) have valuation zero and reduce to the chosen outer finite factor. Thus modulo \(\delta\),

\[
Q_i-c_i\equiv z^{r_i}\overline V_i(z),
\qquad\overline V_i(0)\ne0.
\]

The factors (z^{r_i}\) and \(\overline V_i\) are coprime. Monic Hensel factorization gives unique (P_i,S_i\) satisfying (2.1), with (P_i\) the inner factor and (S_i\) the outer factor. This does **not** claim that individual (P_i\)-roots are close to individual (U_i\)-roots. That stronger statement can fail when their valuation scales coincide. The coprime block factorization is all that is needed.

Since \(\operatorname{Res}(U_i,V_i)\) is a \(\delta\)-unit, remainder vanishing modulo (Q_i\) is equivalent, scheme-theoretically, to remainder vanishing modulo (U_i\) and modulo (V_i\). This Chinese-remainder step includes confluent conditions at repeated same-color roots.

### 4.1 Inner equations

At a (U_i\)-root (x\), the exact relation (Q_i=P_iS_i+c_i\) gives

\[
P_i(x)=-c_i/S_i(x).
\tag{4.2}
\]

Define the usual primitive old ratio on the inner polynomials by

\[
\Gamma_{g,r;i}(x)
=\varepsilon_g(r)_i^{-1}x^{g_i}\prod_jU_j(x)^{B_{ij}}.
\]

Equation (2.2), with the deformation (f_i\), becomes exactly

\[
\Gamma_{g,r;i}(x)
=\sigma_i^{\mathrm{in}}\delta^{-a_i}
f_i(x)S_i(x)\prod_jV_j(x)^{-B_{ij}},
\tag{4.3}
\]

where

\[
\sigma_i^{\mathrm{in}}
=-\kappa_i\,\varepsilon_g(m)_i/\varepsilon_g(r)_i
=(-1)^{m_i+1+\sum_jp_j[-B_{ij}]_+}.
\tag{4.4}
\]

Its framing is exactly (g\). Every factor involving (V_j,S_i\) is a \(\delta\)-unit. Factoring out its constant term gives

\[
\Gamma_{g,r;i}(x)
=\delta^{-a_i}A_i(V)\,u_i(x),\qquad u_i\equiv1\pmod{\delta^{\beta}},
\tag{4.5}
\]

for some uniform \(\beta>0\), with

\[
A_i(V)=\sigma_i^{\mathrm{in}} f_i(0)
V_i(0)\prod_jV_j(0)^{-B_{ij}}.
\]

The factors (A_i(V)\), including their signs, are arbitrary nonzero unit targets for the inner generic-endpoint finite-flat family. They are not silently set to one.

### 4.2 Outer equations

At a (V_i\)-root (z\), all inner factors satisfy

\[
P_i(z)/z^{r_i}\equiv1\pmod{\delta^{\beta}},\qquad
U_j(z)/z^{r_j}\equiv1\pmod{\delta^{\beta}}.
\]

Consequently (2.2) becomes

\[
\Gamma_{h,p;i}(z)
=\sigma_i^{\mathrm{out}} f_i(z)\,v_i(z),
\qquad v_i\equiv1\pmod{\delta^{\beta}},
\tag{4.6}
\]

where

\[
h_i=g_i+r_i+\sum_jB_{ij}r_j,
\qquad
\sigma_i^{\mathrm{out}}=\varepsilon_g(m)_i/\varepsilon_h(p)_i.
\tag{4.7}
\]

This is the exact origin of the extra (+r_i\) in (h=g+(I+B)r\): it comes from the explicit leaf polynomial (P_i\) in the old row. Splitting an unmarked old (Q\)-system would give only (g+Br\) and would miss it.

The constants \(\sigma_i^{\mathrm{out}}\) are again legitimate unit targets. The positive-factor length for (h,p\) is independent of these units by the already proved full-annulus theorem.

## 5. A finite-flat unit homotopy, including nonreduced fibers

Replace the correction units in (4.5)–(4.6) by

\[
u_i\longmapsto1+s(u_i-1),\qquad
v_i\longmapsto1+s(v_i-1),\qquad |s|\le1.
\tag{5.1}
\]

They remain units congruent to one. At (s=1\) these are the actual marked equations on the selected separated domain. At (s=0\), the outer equations are exactly the chosen perturbed (h,p\)-factor, and the inner equations are the (g,r\)-coefficient family pulled back along its unit targets (A_i(V)\).

The required finite-flat assertion can be checked directly as follows.

**Uniform inner bounds.** At every solution throughout (5.1), the valuation equations of the inner system are precisely those with endpoint (a\), because every (A_i(V)\) and every correction is a \(\delta\)-unit. The previously proved full target-annulus window supplies uniform positive lower bounds on inner coordinates and actual-arrow differences, and uniform upper bounds on actual-arrow valuations. No Jacobian-inverse estimate at a possibly nonreduced point is used.

**Uniform outer bounds.** Modulo \(\delta\), the outer equations are independent of (s\) and give the chosen isolated finite Artin outer factor. After a finite extension, treat each of its finitely many residue points separately. In the local outer coefficient ring, a power of its maximal ideal lies in the outer equation ideal. If the correction equations have valuation at least \(\beta\), this ideal containment bounds every outer displacement below by \(\beta/e\) for some finite (e\). Choose a slightly larger closed polydisc around each residue point; every solution is then strictly inside it. The statement uses a power of the maximal ideal, so it retains nonreduced outer factors rather than replacing them by reduced points.

**Leaf bounds.** Monic Hensel factorization keeps all (P_i\)-roots in the inner layer. Their valuations have a uniform positive lower bound from the inner coefficient bounds and (a_i>0\). The identity

\[
\operatorname{Res}(P_i,Q_i)=c_i^{r_i}
\]

bounds the valuations of every actual old–leaf arrow difference from above: all such differences have nonnegative valuation and their sum is fixed. Mixed inner–outer differences are units for the \(\delta\)-valuation. Same-color diagonals are not inverted.

These bounds give strict inequalities for a finite collection of affinoid generators and inverses. The strict-generator relative-interior criterion therefore makes the selected family finite over the (s\)-disc.

For flatness, use the monic coefficient coordinates of (U_i,V_i\). Hensel factorization expresses (P_i,S_i\) as unique analytic functions in these coordinates; its factorization Jacobian is invertible because the inner and outer reductions are coprime. The ambient space is therefore regular. There are exactly

\[
\sum_i(r_i+p_i)
\]

remainder equations in that many coefficient variables. Finiteness forces the expected codimension. They form a regular sequence locally in the regular ambient space, so the source is Cohen–Macaulay. Miracle flatness over the regular (s\)-disc gives a finite-flat family. This argument uses complete-intersection equations and scheme lengths, not a distinct-root assumption.

At (s=0\), the inner compressed coefficient algebra is finite flat of rank (a_g(r)\) over the full unit-target annulus. Pulling it back along the Artin outer algebra, including its nilpotents, gives length

\[
a_g(r)\dim_K A_{h,p}=a_g(r)a_h(p).
\]

Flatness proves the same length at (s=1\). The selected domain is open and closed in the finite marked generic fiber, hence retains the complete local Artin algebras at its selected points. It is an actual finite factor.

### 5.1 Why the compressed inner family is finite flat

This is not an assertion that an arbitrary quotient of a flat labeled family is flat. Restrict the already proved labeled finite-flat family to color-invariant unit targets. Its coordinate algebra is still finite flat by base change, and the color Young group \(G_r=\prod_iS_{r_i}\) acts over that base. In characteristic zero the sign projector

\[
e_{\mathrm{sgn}}=|G_r|^{-1}\sum_{\sigma\in G_r}
\operatorname{sgn}(\sigma)\sigma
\]

is an idempotent module endomorphism. Its image is a direct summand of a finite locally free module, hence finite locally free. On the connected unit annulus its rank is the constant (a_g(r)\), by the reviewed character/coefficient theorem.

The remainder/alternant compression identifies this sign module with the monic-remainder coefficient algebra as a module over the unit-target base. The proof is base-linear: monic division, the adjugate Vandermonde identity, and the alternating projector commute with localization, saturation by the actual-arrow factors, and finite base change. No discriminant is inverted. Thus the compressed family is finite flat as a module even though the sign summand itself is not a subalgebra of the labeled algebra. This is exactly the finite-flat statement used in the Artin base change above.

## 6. What the construction does and does not identify

The (s=0\) object is a pullback of a finite-flat **family** of inner coefficient algebras over the outer algebra. Its unit targets vary with (V_i(0)\). It need not be literally the tensor product of a single fixed-target inner algebra with the outer algebra. Its rank is nevertheless exactly the product, by finite-flat base change.

The (s=1\) object is a separated factor in a generic deformed marked fiber. No claim is made that the same idempotent persists at undeformed coefficient targets or in the special fiber where every root is zero. The closure operation in §8 is the precise replacement.

## 7. Replacing two scales by one is a finite algebraic operation

All equations defining the marked model, the monic factorization, the remainder conditions, and the required localizations are finite polynomial data after denominators are introduced as additional variables. The selected isolated factor can likewise be specified after finite extension and localization. Work with the two-stage valuation order: first \(\delta\), then (T\) in the residue field.

More explicitly, the (s=1\) selected points are isolated points of the original finite polynomial marked system over \(\Bbbk(T,\delta,\eta)\), with the finitely many actual-arrow factors inverted. Their coordinates are algebraic over that rational function field: local dimension zero gives a finite residue-field extension. The entire local Artin factor is specified by finitely generated primary/localized polynomial ideals after a finite algebraic extension. The Hensel series used to recognize its inner/outer branch are expansions of these algebraic coordinates; they are not new infinite defining data. Idempotents or isolating localizations can be chosen after the same finite extension. The valuation comparisons that select this branch therefore concern a finite algebraic factor, including its nilpotent structure.

A finite Gröbner basis for the relevant weighted initial systems produces finitely many strict weight inequalities. The lexicographic two-stage order on this finite data is realized by weights

\[
\operatorname{val}(\delta)=L,\qquad \operatorname{val}(T)=1
\]

for every sufficiently large integer (L\). Equivalently, iterated initial ideals are realized by a sufficiently small rational perturbation of the first weight. Include the finitely many strict inequalities defining inner/outer separation and positivity of every selected actual-arrow valuation. Thus (\delta=T^L\) is justified through finite initial-ideal data, not by substituting into arbitrary infinite Hensel expansions.

The big endpoint becomes ((b,La)\), with all entries positive. Its cut and rank genericity conditions are finitely many nonzero rational linear forms. Choose (a,b\) in the required dense open sets; each remaining condition excludes at most one (L\), unless its coefficient of (L\) is zero, in which case the generic choice of (b\) already avoids it. A sufficiently large permitted (L\) therefore exists and is found by finite exact operations.

After this choice, all outer roots have their original positive (T\)-valuations, all inner roots have sufficiently large positive (T\)-valuations, and all leaf roots are positive. The separated factor is a factor of the same positive marked finite algebra whose total length is (0.1).

## 8. Returning to the original fiber by two saturated lattices

Choose a generic line of polynomial perturbations through zero, parameterized by \(\eta\). The full-annulus theorem gives a finite-flat family over the completed DVR (K[[\eta]]\), with original marked generic-(T\) algebra at \(\eta=0\). After a finite ramification if necessary, let (S\) be the selected direct factor over (K((\eta))\). Its length is (0.2).

For the ambient finite-free family (A\), set

\[
L_\eta=A\cap S\subset A\otimes K((\eta)).
\]

This is a saturated finite-free (K[[\eta]]\)-submodule: if \(\eta x\in L_\eta\), then (x\in S\) and hence (x\in L_\eta\). Therefore

\[
L_\eta/\eta L_\eta\hookrightarrow A/\eta A
\]

is injective. It defines a subspace (W\) of the original marked generic-(T\) algebra of dimension (0.2). Since (S\) is an ideal factor, the intersection and its specialization are stable under ambient multiplication.

Now take the original finite-free completed (T\)-model of the marked coefficient algebra. After the necessary finite extension of (K\), use its valuation DVR \(\mathcal O\). Intersect its integral model with (W\). The same saturation argument gives a free \(\mathcal O\)-module of rank (0.2), whose residue fiber injects into the original marked special fiber after residue-field extension.

This is the announced model-defined injection. It uses finite-flatness and saturated intersection twice; it does not infer an injection merely from the numerical inequality. It also explains why an original special-fiber direct-product assertion would be unjustified.

## 9. Review points requiring explicit checking

The exact polynomial identities and sign factors in §4 are elementary and independently testable. The main proof obligation is §5's selected-domain finite-flat argument: the domain must retain the full local monic-remainder factors, and the inner/outer bounds must be uniform for the entire (s\)-disc. The argument above supplies the requisite windows, outer nilpotent-power bound, equation count, and regular ambient factorization chart. The single-scale realization in §7 must use initial ideals of the finite localized systems, not only initial forms of the displayed generators. These are the points submitted to the parent for adversarial review.
