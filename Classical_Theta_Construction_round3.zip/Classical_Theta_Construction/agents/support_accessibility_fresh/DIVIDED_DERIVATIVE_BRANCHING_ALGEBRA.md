# A finite coefficient algebra for the positive divided-derivative action

2026-11-14. Classical skew-symmetric and skew-symmetrizable cluster data. The endpoint/exponent calculation has been independently checked by `positive_shear_fresh_review`.

## 1. The coefficients to compute

For (r,q\in\mathbb N^n\), put (h=g+(I+B)r\). The reviewed positive-shear theorem gives

\[
R^{[r]}\theta_g
=\sum_{q\ge0}d_{g;r,q}\,y^q\theta_{h+Bq},
\qquad d_{g;r,q}\in\mathbb Z_{\ge0}.
\tag{1}
\]

This identity is coefficientwise finite for every formal label (g\). The ordinary triangular recurrence computes (d\) using subtraction. The construction below computes each (d\) as the dimension of one explicit finite rational algebra, with no intermediate derivative expansion or theta coefficient required as input.

## 2. One extended theta coefficient

Let

\[
C=\begin{pmatrix}B&I\\-I&0\end{pmatrix},\qquad
D_C=\operatorname{diag}(D,D),\qquad
G=(g,0),\qquad P=(q+r,r).
\tag{2}
\]

This is the mutable matrix after the commuting source-leaf mutations in the positive-shear proof. The extended source theta transforms as

\[
x^gF_g\bigl(z_1'(1+w_1),\ldots,z_n'(1+w_n)\bigr),
\quad z_i'=(u_i/a_i')x^{Be_i},\quad w_i=v_ix_i/u_i.
\]

Its term of big root degree (P=(q+r,r)\) has old mutable exponent

\[
m=h+Bq=g+B(q+r)+r.
\]

After freezing the leaves, the full monomial is

\[
(a')^{-q-r}u^qv^r x^m.
\]

Choose an old endpoint (a_{\rm old}\) in the same finite sign germ as (m\), and choose all leaf endpoint coordinates (a_{\rm leaf}\) sufficiently large and positive. Then

\[
\boxed{d_{g;r,q}=c^C_{G,P}(D_Ca),}
\tag{3}
\]

where the right side is the extended theta coefficient at that signed endpoint, rather than necessarily at the initial positive chamber.

Here is an effective precise choice. Let (K=|q|+2|r|\). If (K=0\), the coefficient is one. Choose positive rational (v\) and

\[
a_{\rm old}=m+\epsilon v,
\qquad0<\epsilon<\frac1{1+K D_{\max}\max_i v_i}.
\]

For every old normal (0\ne\alpha\in\mathbb N^n\) of degree at most (K\), the pairing \(\alpha^TD a_{\rm old}\) has the sign of \(\alpha^TDm\) whenever the latter is nonzero. If the latter is zero, the new pairing is positive. A sufficiently small generic rational perturbation preserves these finite sign conditions. Choose the leaf coordinates so that each

\[
D_i a_{{\rm leaf},i}>
K D_{\max}\max(1,\|a_{\rm old}\|_\infty)+1.
\tag{4}
\]

The straight old path from a positive endpoint to (a_{\rm old}\), lifted at this leaf height, misses every big wall of degree at most (K\) whose normal uses a leaf. Thus its big transport agrees through the target degree with the old transport. The coefficient of (x^m\) in the old chart near (m\) is the theta coefficient of the leading label (m\): a final segment with velocity (-m\), traced backward from (a_{\rm old}\), cannot hit any old wall of relevant degree, by the sign conditions. This is the elementary last-segment version of Mandel's coefficient detector. It proves (3).

Finally impose the cut and rank genericity conditions from `../dyck_flow_round2/SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md`, §1, for (C,G,P\). They remove finitely many proper rational hyperplanes. The open conditions just imposed remain nonempty, so rational enumeration finds such an endpoint. Rescale positively to make all its coordinates integral. The entire choice is finite and depends only on (B,D,g,r,q\).

## 3. The immediate finite algebra

Apply the parent's signed-endpoint monic-(Q\) theorem to (C,G,P\):

\[
\boxed{d_{g;r,q}=\dim_{\mathbb Q}\mathcal Q(C,G,P;D_Ca).}
\tag{5}
\]

The theorem's explicit polynomial division, saturation, and special-fiber construction is recalled below in a compressed form adapted to the leaf geometry. The only substantive input beyond positive freezing is the already reviewed global signed-endpoint coefficient theorem. This does not assert an elementary path enumeration independent of that theorem.

## 4. Eliminate the leaf equations: two monic polynomials per color

Write (m_i=q_i+r_i\), and let (L_i=a_{{\rm leaf},i}>0\), (b_i=a_{{\rm old},i}\) after integral scaling. Introduce monic polynomials (P_i(z)\) and (S_i(z)\) of degrees (r_i\) and (q_i\). Degree-zero polynomials are one. Define

\[
Q_i(z)=
\begin{cases}
P_i(z)S_i(z)+(-1)^{m_i}T^{L_i},&r_i>0,\\
S_i(z),&r_i=0.
\end{cases}
\tag{6}
\]

Thus (Q_i\) is monic of degree (m_i\), including (Q_i=1\) when (m_i=0\). Put

\[
\varepsilon_i=(-1)^{[-g_i]_++\sum_jm_j[-B_{ij}]_+},
\]

\[
H_i(z)=T^{[b_i]_+}z^{[g_i]_+}P_i(z)
          \prod_jQ_j(z)^{[B_{ij}]_+}
-T^{[-b_i]_+}\varepsilon_i z^{[-g_i]_+}
          \prod_jQ_j(z)^{[-B_{ij}]_+}.
\tag{7}
\]

Let \(\mathscr R\) be the rational polynomial ring in (T\) and all nonleading coefficients of the (P_i,S_i\). Let (I\) consist of every coefficient of (H_i\bmod Q_i\), for all (i\). Define

\[
\Sigma=\prod_{i:g_i\ne0}Q_i(0)
\prod_{i<j:B_{ij}\ne0}\operatorname{Res}(Q_i,Q_j),
\]

\[
\mathscr D_{B,g;r,q}
=\mathscr R\big/\bigl((I:(T\Sigma)^\infty)+(T)\bigr).
\tag{8}
\]

Then

\[
\boxed{d_{g;r,q}=\dim_{\mathbb Q}\mathscr D_{B,g;r,q}.}
\tag{9}
\]

### Elimination proof

In the big (Q\)-algebra, call the old color polynomials (Q_i\) and the leaf polynomials (P_i\), of degrees (m_i\) and (r_i\). The leaf row of (C\) has just one entry, (-1\), and its label is zero. Since (L_i>0\), its remainder equation is precisely

\[
P_i\mid T^{L_i}-(-1)^{m_i}Q_i.
\]

Monic polynomial division therefore gives the unique monic quotient (S_i\) and formula (6) when (r_i>0\). This is an isomorphism of the coefficient-coordinate quotient rings, not just a bijection on distinct roots. When (r_i=0\), there is no leaf equation and (S_i=Q_i\).

The old row of (C\) has an additional positive entry (+1\) at its leaf. Its cleared equation is exactly (7). The old-leaf resultant, the only additional boundary factor, becomes

\[
\operatorname{Res}(P_i,Q_i)
=\bigl((-1)^{m_i}T^{L_i}\bigr)^{r_i}.
\]

It is already inverted by (T\)-saturation. Thus the remaining saturation is precisely (8). The special fiber and its dimension are preserved by the coordinate-ring isomorphism. This proves (9).

There is still **no discriminant saturation**. Repeated roots of (P_i,S_i,Q_i\) retain their scheme multiplicities. The two monic polynomials select (r_i\) leaf roots and (q_i\) residual roots through a confluent algebra, so the model does not discard coincident same-color configurations.

## 5. Why this advances the general mechanism

Equation (9) computes all nonvacuum branches of the positive divided-derivative action from finite polynomial data. The rank-nine obstruction in `FINITE_FIRING_DOES_NOT_CERTIFY_THETA.md` shows that such branches are necessary: the vacuum firing graph can terminate while the source theta remains infinite. This algebra supplies an explicit positive replacement for the missing branches, though it does not by itself bound their degrees or certify that the entire branch graph is finite.

No BK-perfectness, generic-character equality, Newton-polytope equality between bases, or (\mathrm{mid}=\mathrm{up}\) hypothesis is used.
