# Running the universal-unit coefficient model

Use Python 3 with SymPy. All file references below are relative to the project root. Neither implementation contains a workspace-specific path.

## One supplied input

Run:

    python agents/support_accessibility_fresh/universal_unit_coefficient.py --input agents/support_accessibility_fresh/universal_unit_example.json

The supplied JSON specifies a divided-derivative branch and returns length 4. Its exact local-length certificate is L_4=L_5, with successive truncated dimensions 1, 2, 3, 4, 4.

For an ordinary theta coefficient, use a JSON object of the form:

    {"kind":"theta","B":[[0,1],[-1,0]],"g":[-2,-2],"p":[1,1]}

For a derivative branching coefficient, use:

    {"kind":"derivative","B":[[0,1],[-1,0]],"g":[-2,-2],"r":[0,1],"q":[1,0]}

The matrix is the convention of the proof: z_i=y_i x^(B e_i). It must be an integral skew-symmetrizable matrix. The code checks this and constructs a positive integral symmetrizer. Degrees p,r,q must be nonnegative integer vectors.

## Programmatic use

From the project root:

    from agents.support_accessibility_fresh.universal_unit_coefficient import (
        theta_coefficient, derivative_branch, theta_system, derivative_system
    )
    B = [[0, 1], [-1, 0]]
    a = theta_coefficient(B, [-2, -2], [1, 1])
    d = derivative_branch(B, [-2, -2], [0, 1], [1, 0])
    assert a["length"] == 6
    assert d["length"] == 4

The system constructors expose the monic remainder equations, actual boundary product, coefficient variables, and independent symbolic unit parameters. They can be passed to a different exact computer-algebra backend.

## What the implementation does

1. It forms the T-exponent-one ordinary system, or the old-exponent-zero/leaf-exponent-one derivative system.
2. It performs monic division and exact saturation by T times the required frame and actual-arrow boundary product.
3. It sets T=0.
4. It computes truncated Macaulay matrix ranks at the coefficient origin until the first exact consecutive equality of quotient dimensions.

The proof in UNIVERSAL_UNIT_COEFFICIENT_ALGEBRAS.md establishes that this local algebra is Artinian. Nakayama's lemma makes one equality a rigorous stopping certificate. This is not a numerical threshold.

Arithmetic is over a rational function field in independent unit parameters. No numerical generic values, scattering diagram, previously computed theta coefficient, discriminant saturation, or degree cutoff is used. Same-color collisions and nilpotents remain in the algebra.

## Verification and practical limit

The full implementation gives the ordinary A2 coefficient 6, independently confirmed by the incoming recursion, and the derivative coefficient 4, independently confirmed by symbolic elimination with the Wolfram computation plugin. In the latter example the global special quotient has length 6; the origin-local algorithm correctly removes its nonorigin length-two component.

The parent run independently confirmed the Markov coefficient 7 with Wolfram at generic numerical units and with the incoming recursion. A direct generic-symbolic-unit Markov Gröbner saturation was started here and interrupted before completion because it was consuming unnecessary time. It is recorded as uncompleted, not as a passed check of this implementation.

Gröbner saturation can be expensive even for a small number of variables. This is an exact reference implementation of a finite algorithm, not a complexity claim. Its guaranteed stopping concerns each requested coefficient algebra. It does not supply a stopping rule for the entire Laurent support of an arbitrary theta label.
