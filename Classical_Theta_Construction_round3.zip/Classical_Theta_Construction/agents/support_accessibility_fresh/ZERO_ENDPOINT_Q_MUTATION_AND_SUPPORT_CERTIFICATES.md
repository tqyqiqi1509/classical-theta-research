# Zero-endpoint Q mutation and finite support certificates

2026-11-14. Classical skew-symmetric and skew-symmetrizable data.

We prove that the generic-unit origin model realizes ordinary tropical A mutation at an endpoint coordinate equal to zero, while preserving its full Artin length. The degree formula itself is standard tropical mutation. The work here concerns the positive-origin finite algebra, including its multiplicities, and its connection to theta coefficients. The earlier nonzero-endpoint complement argument does not directly establish this statement: neither complete-color separation nor the degree of the distinguished factor can be imported unchanged.

The application is a finite, decidable certificate for the complete support of a theta Laurent polynomial. A fresh comparison also derives these numerical support inequalities directly from GHKK min-convexity and the previously established coefficient detector; the certificate is therefore an explicit use of existing tropical mechanisms, not a new support theorem requiring the Q model. The full-Artin Q realization remains a separate statement. The certificate need not exist for every finite theta function. Its successful production gives an actual bound, after which the coefficient algorithm produces the entire polynomial.

## 1. General mixed-endpoint origin factors

Let \(C\) be an integral skew-symmetrizable matrix, \(D C\) skew-symmetric, and let \(G\) be an integral framing vector. Partition its mutable indices into \(I\sqcup J\). Use primitive endpoint zero on \(I\) and a fixed positive vector \(a\) on \(J\). Let \(P\ge0\) be the monic-Q degree vector. Write

\[
A_i=z^{[G_i]_+}\prod_jQ_j^{[C_{ij}]_+},\qquad
E_i=z^{[-G_i]_+}\prod_jQ_j^{[-C_{ij}]_+}.
\]

Absorb the fixed row signs into independent generic unit parameters \(\lambda_i\). The rows are

\[
T^{a_i}A_i-\lambda_i E_i\quad (i\in J),\qquad
A_i-\lambda_iE_i\quad(i\in I).
\tag{1.1}
\]

Use the actual frame/arrow saturation and select the coefficient-origin factor, exactly as in UNIVERSAL_UNIT_COEFFICIENT_ALGEBRAS.md.

The generic-residue core theorem extends to this data without any source-leaf assumption. Here are the parts of its proof that need checking. Put

\[
M=G+CP,\qquad \mu_0=(0,a).
\]

Common coordinate scaling \(x=T^t\xi\) changes the endpoint to

\[
\mu_t=\mu_0+tM.
\tag{1.2}
\]

For an old-only cut, its raw weight at \(\mu_t\) is \(t\) times its skew cut pairing, up to the fixed orientation sign. For a cut meeting \(J\), the positive initial weight dominates the \(tM\) term for sufficiently small \(t>0\). Therefore every zero cut at \(\mu_t\) has zero skew cut pairing. The minimum-edge argument gives the uniform nearby lower bound; the same rank-recession certificates give the upper bound. Empty sets of nonzero-pairing cuts are treated by the minimum-edge contradiction, so the corresponding generic positive factor is empty.

The finite-initial-ideal color-torus argument, connected target annulus, complete-intersection flatness, and nested-deep-factor argument use no additional property of the original source-leaf matrix. They therefore give a finite flat full positive factor over a nonempty generic-unit open for (1.1). All statements hold over valued extensions and over the generic rational-function unit field.

Here is the rank-constancy step needed for that last sentence. Fix the degree window \(P\). Only finitely many scattering roots \(\alpha\le P\), graph cut forms, hierarchy rank forms, feasible-hierarchy/flow sign forms, and initial-polynomial exponent tie forms occur. Include all of them in the generic choice. Choose one rational generic direction \(\nu\) and one sufficiently small \(\eta>0\). For all small \(t>0\), the nearby generic endpoint

\[
\mu_0+t(M+\eta\nu)
\tag{1.3}
\]

has a fixed sign on every one of these forms: when its value at \(\mu_0\) is nonzero, that term controls the sign; otherwise the sign is that of its value on \(M+\eta\nu\), independent of \(t\). Thus all these endpoints lie in one chamber of the finite hyperplane refinement relevant to degree \(P\). The general rank-generic Gale/sign theorem, equivalently its finite collision-chart counts and character formula, gives one and the same generic selected-Q length \(c\) there. No separate identification with a theta coefficient at an arbitrary signed endpoint is needed. The fixed-direction connecting annulus may have valuation length \(\eta t\); if a smaller length is needed, its endpoint remains in that same germ chamber, with the same length \(c\).

The connected-annulus comparison gives rank \(c\) for every sufficiently small scaled deep factor \(C_t\), over the same good color-unit open. The nested domains \(C_{t_0}\subset C_t\) have equal full Artin rank and hence agree as families. Their union is the full positive origin factor. This proves finiteness and constant rank for the general mixed-endpoint system without presupposing a derivative interpretation of \(c\). Formal positive freezing and the Mandel coefficient detector provide an additional interpretation when desired, but are not needed for this rank-constancy argument.

Let its length be

\[
\ell_I(C,G,P).
\]

For \(P=0\) the length is one. A nonempty component disconnected from the frame imposes a nontrivial generic-unit monomial relation and contributes no factor. These conventions include the degenerate cases.

The same window works when each target is multiplied by an analytic unit with residue one on the positive-coordinate domain. At each solution the normalized target residue is still the same generic color residue. Thus the generic-residue argument bounds every point of a coupled-unit system as well. Strict relative interior makes the selected family finite; the number of monic remainder equations equals the number of coefficient variables, so the usual complete-intersection and miracle-flatness argument retains its entire Artin length over a regular homotopy base.

## 2. The full-Artin realization of tropical degree mutation

Choose \(k\in I\). Define

\[
\alpha_k=[G_k]_++\sum_j[C_{kj}]_+P_j,\qquad
\beta_k=[-G_k]_++\sum_j[-C_{kj}]_+P_j,
\]

\[
\boxed{d_k=\min(\alpha_k,\beta_k),\qquad
P'_k=d_k-P_k,\quad P'_j=P_j\ (j\ne k).}
\tag{2.1}
\]

If \(P'_k<0\), the origin factor is zero.

Otherwise mutate the matrix and framing:

\[
C'=\mu_k(C),
\]

\[
G'_k=-G_k,\qquad
G'_j=G_j+[C_{jk}]_+G_k+C_{jk}[-G_k]_+
\quad(j\ne k).
\tag{2.2}
\]

The endpoint is still zero on \(I\) and \(a\) on \(J\): mutation at an endpoint coordinate equal to zero does not change the other endpoint coordinates.

The resulting equality is

\[
\boxed{\ell_I(C,G,P)=\ell_I(C',G',P').}
\tag{2.3}
\]

This is an equality of full local lengths obtained through actual complementary factors and finite flat unit families. No direct isomorphism between the two undeformed origin-special algebras is asserted.

## 3. Preparation at endpoint zero

At the coefficient origin, the \(k\)-th row reduces to

\[
z^{\alpha_k}-\lambda_k z^{\beta_k}.
\]

Its zero-root multiplicity is \(d_k\). If the degrees are equal, genericity excludes \(1-\lambda_k=0\). Weierstrass preparation therefore gives a unique monic distinguished polynomial \(W_k\) of degree \(d_k\), times a unit.

The old row condition is \(Q_k\mid W_k\). Hence \(P_k\le d_k\) is necessary. If this inequality holds, put

\[
Q'_k=W_k/Q_k,\qquad Q'_j=Q_j\quad(j\ne k).
\tag{3.1}
\]

This is monic of degree (2.1), and all its roots are positive. Monic division makes the construction valid over nonreduced coefficient rings.

Both \(W_k\) and its preparation unit are constructed from \(A_k,E_k\) and the fixed target perturbation \(f_k\). Since \(C_{kk}=0\), they depend only on \(Q_j\) with \(j\ne k\), and on the fixed parameters; they do not depend on the old \(Q_k\). They are therefore analytic functions of the new coefficient coordinates as well. The recovered old polynomial is the monic quotient of \(W_k\) by \(Q'_k\), whose division coefficients are defined before imposing the zero-remainder equations.

The residue of the Weierstrass unit for the unnormalized row is \(1\), \(-\lambda_k\), or \(1-\lambda_k\), according as \(\alpha_k<\beta_k\), \(\alpha_k>\beta_k\), or equality holds. After dividing by this nonzero constant, the unit takes the form \(1+\) positive valuation on every positive root. The possible higher powers of \(z\) in the residue polynomial cause no problem on the strict positive-coordinate domain.

The normalized preparation is over the bounded coefficient ring in which the necessary constants \(\lambda_k\) and, in the equal-degree case, \(1-\lambda_k\) are inverted as units. Its Hensel coefficients remain bounded there. Consequently the resulting restricted power series converge on every closed coefficient polydisc strictly inside the positive open polydisc, including the enlarged generator windows used below. This provides a common analytic domain for the unit homotopy; no arbitrary substitution into a merely formal infinite series is used.

## 4. Complete separation is obtained by a flat perturbation

The unperturbed zero-endpoint factor need not have all distinct colors separated, nor need an unframed color avoid zero. These properties are not assumed.

For every active color introduce a polynomial \(\phi_i(z)\) of degree less than \(P_i\), and replace its target by

\[
\lambda_i\bigl(1+T^N\phi_i(z)\bigr),
\qquad N>0.
\tag{4.1}
\]

Its coefficients vary in a bounded polydisc. All correction values have residue one at positive roots, so §1 supplies a uniform positive window and a finite flat family. The original factor is its \(\phi=0\) fiber, with its full length.

On the actual-arrow-open monic chart, multiplication by \(E_i\) is invertible in the quotient by \(Q_i\). The map from the coefficients of \(\phi_i\) to the remainder of the \(i\)-th equation is therefore an invertible linear map, multiplied by the nonzero scalar \(T^N\lambda_i\). Equivalently, the incidence equation uniquely solves

\[
\phi_i\equiv T^{-N}
\left(T^{a_i}A_i/(\lambda_iE_i)-1\right)\pmod{Q_i},
\tag{4.2}
\]

where \(a_i=0\) on \(I\).

Consequently the total algebraic incidence is a graph over the actual-arrow-open monic coefficient configuration space. The bounded positive incidence is a full-dimensional analytic domain in that graph; it need not itself be an open polydisc. The conditions

\[
Q_i(0)=0,\qquad \operatorname{Res}(Q_i,Q_j)=0\quad(i\ne j)
\tag{4.3}
\]

are proper hypersurfaces of that space when the relevant degrees are positive. They are not identically satisfied on any full-dimensional analytic component. A finite morphism sends each such lower-dimensional boundary locus to a proper analytic parameter locus. A generic bounded parameter choice therefore avoids all of (4.3), at every point of the finite fiber.

This argument may also avoid same-color discriminants, but no discriminant is added to a saturation ideal. It is a deformation of the full algebra, not deletion of its collision states. Every nilpotent contribution in the original fiber is retained by finite flatness.

We perform the complementary-factor construction on one such generic perturbed fiber.

## 5. The transformed unit targets are generically dominant

Write the old perturbed primitive equations as

\[
R_i=z^{G_i}\prod_jQ_j^{C_{ij}}
=\lambda_iT^{-a_i}f_i(z),\qquad
f_i=1+T^N\phi_i.
\]

Let \(m_k=\alpha_k-\beta_k=G_k+\sum_jC_{kj}P_j\).
The following formulas absorb the harmless fixed row signs into the units.

If \(m_k>0\), normalize preparation as

\[
E_k-\lambda_k^{-1}f_k^{-1}A_k=U_kQ_kQ'_k,
\qquad \overline{U_k(0)}=1.
\]

If \(m_k<0\), use

\[
A_k-\lambda_kf_kE_k=U_kQ_kQ'_k,
\qquad \overline{U_k(0)}=1.
\]

At \(m_k=0\), either expression may be used, with its constant residue \(1-\lambda_k^{-1}\) or \(1-\lambda_k\).

For \(j\ne k\), the exact quotient-ring identities are

\[
\frac{R'_j}{R_j}=
\begin{cases}
(A_k/(Q_kQ'_k))^{C_{jk}},&C_{jk}>0,\\
(E_k/(Q_kQ'_k))^{C_{jk}},&C_{jk}<0,\\
1,&C_{jk}=0.
\end{cases}
\tag{5.1}
\]

The separation from §4 permits every displayed inverse. Reduction modulo \(Q_j\) kills exactly one of \(A_k,E_k\). Thus every transformed target is a constant unit \(\lambda'_j\), times its unchanged power \(T^{-a_j}\), times an analytic unit of residue one. The latter is an explicit product of the old \(f_i\)'s and of normalized \(U_k\).

Put \(b=C_{jk}\). The constant-unit map is

\[
\lambda'_k=\lambda_k^{-1},
\]

\[
\lambda'_j=
\begin{cases}
\lambda_j(-\lambda_k)^{[\sigma b]_+},
&m_k\ne0,\quad \sigma=\operatorname{sign}(m_k),\\[2mm]
\lambda_j(1-\lambda_k)^{[b]_+}
(1-\lambda_k^{-1})^{-[-b]_+},
&m_k=0.
\end{cases}
\tag{5.2}
\]

In the second line of the displayed cases the juxtaposition is multiplication of the two factors. These maps are birational on the unit torus, on the open where \(1-\lambda_k\ne0\) in the zero case. Their inverses are the same formulas for the mutated matrix: \(b'=-b\) and \(m'_k=-m_k\). Hence independent generic old units give generic new units in every degree branch. No undescribed dominance assertion is used.

More explicitly, shrink the generic old residue base by the inverse image, under (5.2), of the good residue open for the mutated graph, and by \(1-\lambda_k\ne0\) when needed. Birationality makes this a nonempty open. Thus both uniform-window theorems are applied on their actual hypotheses throughout the construction.

The \(k\)-th new row has target \(\lambda_k^{-1}f_k^{-1}\). The other correction units are explicit products as above. Dividing out the constants (5.2), each has residue one throughout the positive-coordinate domain.

## 6. Boundary control and a two-sided length argument

At a neighbor \(j\) of \(k\), preparation reduced modulo \(Q_j\) is a nonzero monomial product times units. The separation in §4 makes it a unit in that quotient. Hence \(Q'_k\) is coprime to every new neighbor. Newly created edges between two other colors are allowed because those old colors were already separated. All newly required frame factors are nonzero; at \(k\), when \(G_k\ne0\), this follows by evaluating the prepared equation at zero. Thus every old point and its local algebra lands in the actual-arrow-open part of the new coupled-unit system.

Conversely, on the new coupled-unit system the \(k\)-th row says \(Q'_k\mid W_k\). Recover \(Q_k=W_k/Q'_k\). On the open where the recovered old complete-separation conditions hold, (5.1) read backwards gives the old system. Therefore the old full finite algebra is an open-and-closed factor of the new coupled positive algebra. This statement includes its local Artin multiplicities.

There may initially be extra weak factors in the new coupled system. They are not discarded by an unjustified assertion. Instead homotope every normalized new correction unit \(v_i\) by

\[
v_{i,s}=1+s(v_i-1),\qquad |s|\le1.
\]

Its residue remains one. The generic-residue window for the mutated data therefore makes this full positive family finite flat, by §1. At \(s=0\) its length is \(\ell_I(C',G',P')\). Since its \(s=1\) fiber contains the old full factor, this proves

\[
\ell_I(C,G,P)\le\ell_I(C',G',P').
\tag{6.1}
\]

Now repeat the entire construction in the reverse direction, starting from the constant-unit mutated core and its own generic separating perturbation. Matrix and framing mutation are involutions. The two degrees at row \(k\) exchange, so \(d'_k=d_k\) and

\[
P''_k=d_k-P'_k=P_k.
\]

The unit maps (5.2) are birational inverses. Thus the reverse argument gives the opposite inequality, proving (2.3).

This avoids using a nonexistent complete-color-separation theorem at the original zero endpoint. It also avoids assuming that a strong solution cannot acquire weak extra companions after mutation.

### Standard tropical A interpretation and convexity

The numerical update in (2.1) is exactly ordinary tropical A mutation, not a new tropical transformation. Form the auxiliary seed with mutable block \(C^{\mathsf T}\), add one frozen row \(G^{\mathsf T}\), and freeze the indices \(J\). Assign weights \(P_j\) to its original variables and weight one to the added frozen variable \(x_f\). Its exchange relation at \(k\in I\) is

\[
x_kx'_k=x_f^{[G_k]_+}\prod_jx_j^{[C_{kj}]_+}
       +x_f^{[-G_k]_+}\prod_jx_j^{[-C_{kj}]_+}.
\tag{6.2}
\]

Tropical evaluation gives \(P'_k=\min(\alpha_k,\beta_k)-P_k\). Ordinary extended-matrix mutation gives exactly the framing update (2.2). Transposition causes no scope problem: the transpose of a skew-symmetrizable matrix is again skew-symmetrizable, with reciprocal symmetrizer after clearing denominators.

For any finite word \(w\), the standard positive Laurent phenomenon writes every resulting cluster variable as a finite positive Laurent polynomial in the initial variables. If its exponent support is \(E_{w,k}\subset\mathbb Z^{|I|+|J|+1}\), then

\[
P_{w,k}(P)=\min_{e\in E_{w,k}}
\left(e_f+\sum_j e_jP_j\right).
\tag{6.3}
\]

Consequently \(P_{w,k}(P)\ge0\) is equivalent to the finite collection of linear inequalities

\[
e_f+\sum_je_jP_j\ge0\qquad(e\in E_{w,k}).
\tag{6.4}
\]

Thus the degree constraints for any finite set of words define a **convex rational polyhedron**. Substituting either affine initial degree map in §§7–8 preserves this property. The piecewise linear branch decomposition used below and in the code is a redundant way to compute this same convex set; it is not evidence of a new polyhedral mechanism. Standard positive Laurent expressions provide an alternative implementation by explicit halfspaces. The Q proof realizes these inequalities through nonzero positive-origin Artin factors. The direct comparison below shows that their numerical theta-support consequence does not depend on that realization.

### Direct support argument from established tropical convexity

The independent comparison `../zero_endpoint_q_fresh_review/NOVELTY_REDUCTION_AND_CONVEXITY.md`, §§4–6, supplies a second proof. For the doubled matrix, set \(P=(u,r)\), \(u=r+q\), and

\[
M=G+CP=(g+Bu+r,-u),\qquad
C^{-1}M=(u,g+r),\quad C^{-1}G=(0,g).
\]

If \(X_t\) is an old-index cluster variable for the dual pattern, let \(h_t\) be its tropicalization pulled to scattering coordinates by \(C^{-1}\). The elementary intertwining identity for ordinary tropical mutation gives

\[
P_t=h_t(M)-h_t(G).
\tag{6.5}
\]

Writing \(X_t=x^{\gamma_t}F_t(yx^{B^{\mathsf T}})\), the separation formula gives

\[
h_t(m,l)=-\gamma_t\cdot l+(F_t)_{\min}(m).
\tag{6.6}
\]

Thus its nonlinear walls depend only on the old coordinates \(m\). At the coefficient-detector endpoint, the old coordinates lie in a sufficiently close generic germ at \(M_I\), while the leaf coordinates are large positive. Every active linear form in that germ has value \(h_t(M)\) on \(M\), even if \(M_I\) is on a tie wall. A nonzero detector coefficient supplies a broken line with initial decoration \(G\) and final decoration \(M\). GHKK Definition 8.2 and Proposition 8.14, the min-convexity of tropical global monomials, then give

\[
h_t(M)=(dh_t)_{\rm endpoint}(M)\ge h_t(G),
\]

and hence \(P_t\ge0\). A finite set of words requires avoiding only a finite additional set of walls. The positive-freezing/Mandel detector identification is used here, but no complementary-Q theorem and no prior Laurent finiteness are needed. For the skew-symmetrizable convention, in the relevant seed the coordinate functional is \(e_i^{\mathsf T}C_t^{-1}\); on a primitive scattering increment \(C_t\alpha\) it takes value \(\alpha_i\ge0\), as required by the min-convex criterion of GHKK Proposition 8.15(1). If physical coordinates use \(D_tC_t\alpha\), pull the functional back by \(D_t^{-1}\); its value is unchanged. The exact transpose/intertwining calculation transports it back to the initial seed, without asserting an integral lattice isomorphism. This directly proves the numerical support implications in §§7–8 from established convexity and the detector, narrowing the novelty claim accordingly.

## 7. A finite certificate for a fixed divided-derivative support

For the derivative problem start with

\[
C=\begin{pmatrix}B&I_n\\-I_n&0\end{pmatrix},\quad
G=(g,0),\quad I=\{1,\ldots,n\},\quad J=\{n+1,\ldots,2n\},
\]

\[
P(q)=(r+q,r),\qquad q\in\mathbb R_{\ge0}^n.
\tag{7.1}
\]

The initial length is \(d_{g;r,q}\) on integral \(q\).

Choose finitely many words in the indices \(I\), including every prefix of each word. Update \(C,G\) by (2.2) and the degree vector by (2.1). For every nonzero branch coefficient, every intermediate degree must remain nonnegative. The leaf degrees remain exactly \(r\); only old indices are mutated.

Let \(S_{\mathcal W}(B,g,r)\) be the set of real \(q\ge0\) satisfying all these finitely many necessary inequalities. By (6.3)–(6.4), it is a convex rational polyhedron. Every update is also a minimum of integral affine expressions in the previous degrees, giving an explicit, possibly redundant finite-union representation.

To construct the union, split each minimum into its two linear branches and impose the corresponding comparison inequality. Repeat through the finite words and intersect the conditions. Boundary equalities can occur in either branch and cause no omission.

If this polyhedron is bounded, it is a support certificate. Exact rational linear programming gives bounds for every \(q_i\), either on its halfspace representation or on every member of the branch decomposition. Compute \(d_{g;r,q}\) by the universal-unit origin algorithm only at those finitely many integer points. Every omitted coefficient is zero by the mutation inequalities.

Boundedness is decidable: each nonempty polyhedron is bounded exactly when its homogeneous recession cone is zero. It is enough to solve finitely many rational feasibility problems, or use any exact polyhedral algorithm. Real boundedness is a sufficient condition; no assertion about unbounded integer-empty branches is needed.

This certificate is not inferred from a long run of zero coefficients. It is a finite algebraic and polyhedral proof of exhaustion.

## 8. A complete Laurent-output certificate

The constant theta coefficient in the divided-derivative expansion gives

\[
d_{g;r,0}=a_g(r).
\tag{8.1}
\]

Therefore use the same doubled matrix and framing but put

\[
\boxed{P(p)=(p,p),\qquad p\in\mathbb R_{\ge0}^n.}
\tag{8.2}
\]

Apply any finite prefix-closed set of old-index mutation words. Let \(T_{\mathcal W}(B,g)\) be the real degree set on which all intermediate degrees are nonnegative. It is a convex rational polyhedron, computable by its positive Laurent halfspaces or the finite branch decomposition. If it is bounded, then

\[
\operatorname{Supp}F_g
\subseteq T_{\mathcal W}(B,g)\cap\mathbb Z_{\ge0}^n.
\tag{8.3}
\]

The right side is a finite computable set. Compute the ordinary coefficient algebra at each of its lattice points and return

\[
\theta_g=x^g\sum_{p\in T_{\mathcal W}\cap\mathbb Z^n}
a_g(p)y^p x^{Bp}.
\tag{8.4}
\]

This is the complete Laurent polynomial, with a stopping certificate supplied by the bounded degree set. The certificate itself proves finiteness of the theta function; that finiteness is not an input to the proof.

One may enumerate finite word sets and try their boundedness tests. A successful test terminates the complete computation. **No theorem here says that such a test must succeed for every regular theta label.** If the sets stay unbounded, the procedure has not proved either infinitude or finiteness. This is a conditional complete-output algorithm, not a decision procedure for all labels.

### A reusable matrix-level criterion

There is a useful further consequence of the standard tropical interpretation. For a fixed word set, the boundedness question for the full-theta certificate is independent of the label \(g\).

Indeed, the polyhedron \(T_{\mathcal W}(B,g)\) contains \(p=0\): every old and leaf degree stays zero, since at each mutation \(\min([G_k]_+,[-G_k]_+)=0\). Its recession cone is obtained from (6.4) by deleting the constant terms. Equivalently, tropicalize with framing-variable weight zero and initial old/leaf weights \((v,v)\). The framing column then contributes zero at every mutation, so the result depends only on \(C\), not on \(G=(g,0)\). Thus

\[
\operatorname{rec}T_{\mathcal W}(B,g)
=T_{\mathcal W}(B,0)
=:K_{\mathcal W}^{\mathrm{diag}}(B).
\tag{8.5}
\]

The cone on the right uses initial degrees \((v,v)\) and homogeneous framing weight zero. Therefore

\[
T_{\mathcal W}(B,g)\text{ is bounded for one }g
\quad\Longleftrightarrow\quad
K_{\mathcal W}^{\mathrm{diag}}(B)=\{0\}
\quad\Longleftrightarrow\quad
T_{\mathcal W}(B,g)\text{ is bounded for every }g.
\tag{8.6}
\]

One may consequently precompute a successful finite word set at \(g=0\) and reuse it for all labels of the same matrix. The affine bounds still depend on \(g\), but the word-set success test does not. Combined with the coefficient theorem, such a successful word set proves finiteness and supplies complete Laurent output for every label of that matrix.

This also precisely limits the mechanism. If a matrix has even one infinite formal theta function, no finite word set can give a bounded full-theta certificate for that matrix, even for a finite label such as \(g=0\). This follows from (8.6); it is not an inference from numerical examples. Thus the current criterion addresses a matrix-level finite-construction property rather than deciding finiteness separately for each label.

For the fixed-divided-derivative problem, the same reasoning gives recession degrees \((v,0)\), because \(r\) is fixed. Whenever \(S_{\mathcal W}(B,g,r)\) is nonempty, its recession cone depends only on \(B,\mathcal W\), not on \(g,r\). An empty derivative polyhedron remains a separate, immediate zero-support certificate. All these recession statements are standard polyhedral consequences of the proved support-containment interface; they are not claims of a new tropical mutation law.

### Fixed normals, reusable dual bounds, and linear degree growth

This can be made completely explicit using only principal cluster variables for \(B^{\mathsf T}\). For each old coordinate at each prefix, compute its finite positive Laurent expansion

\[
X_t=\sum_{(a,b)\in E_t}c_{a,b}x^ay^b,
\qquad c_{a,b}>0,
\quad h_t(g)=\min_{(a,b)\in E_t}b\cdot g.
\]

Fomin–Zelevinsky separation specializes the principal coefficients to \(y_j=L_jZ^{g_j}\), with denominator \(Z^{h_t(g)}\). The leaf exponents in that denominator are zero because the principal F-polynomial has nonnegative exponents and constant term one. Evaluating old and leaf weights at \((p,p)\), and \(Z\) at weight one, gives the exact halfspaces

\[
\boxed{(a+b)\cdot p\ge h_t(g)-b\cdot g
\quad ((a,b)\in E_t).}
\tag{8.7}
\]

The normals \(a+b\) depend only on \(B,\mathcal W\); the right-hand sides are nonpositive, again showing \(p=0\) is feasible. For fixed derivatives, the corresponding halfspaces are

\[
a\cdot q\ge h_t(g)-b\cdot g-(a+b)\cdot r.
\tag{8.8}
\]

Write (8.7) as \(A p\le b(g)\), with rows \(A_s=-(a_s+b_s)\) and \(b_s(g)=b_s\cdot g-h_{t_s}(g)\ge0\). If its homogeneous cone in the nonnegative orthant is zero, exact linear programming supplies, once for the matrix and word set, rational vectors \(u^{(i)}\ge0\) with

\[
A^{\mathsf T}u^{(i)}\ge e_i.
\]

For every label the same multipliers then prove

\[
p_i\le U_i(g):=\sum_su_s^{(i)}
\bigl(b_s\cdot g-h_{t_s}(g)\bigr)
\le C_i\lVert g\rVert_\infty,
\tag{8.9}
\]

where one explicit constant is

\[
C_i=\sum_su_s^{(i)}
\max_{(a',b')\in E_{t_s}}\lVert b_s-b'\rVert_1.
\]

This gives a reusable matrix-level all-label constructor with computable linear degree bounds whenever the finite cone certificate succeeds. Computing the principal Laurent supports may be costly; the present implementation instead uses the equivalent branch representation. The fixed-normal formulation, the dual estimate, and its linear growth are concrete algorithmic consequences of standard tropical and polyhedral facts plus the detector. They are not asserted as independent new GHKK-type results.

## 9. Scope and novelty comparison

Complementary Q polynomials and ordinary tropical mutation are existing mechanisms. The earlier project file COMPLEMENTARY_Q_MUTATION.md already gives a nonzero-endpoint degree descent, with its comparison to Benini–Park–Zhao, arXiv:1406.2699, §3.3. That argument has a different distinguished degree and cannot simply be used at endpoint zero.

The degree formula, extended-matrix update, positive Laurent halfspace description, convexity, and finite linear-programming test are standard tropical A consequences. The numerical theta-support inequality also follows directly from GHKK min-convexity and the coefficient detector, as explained above. None is claimed as a new general support mechanism. The remaining substantive candidate addition is the full-Artin positive-origin realization and length invariance at endpoint zero, with the separation repair by an actual finite flat parameter family and preservation of nilpotents. Its historical priority against complementary-Q and quiver-duality literature still requires assessment. The proof and its conditional scope do not depend on a priority assertion.

No Li–Pan conclusion is used. The individual coefficient algorithm and the bounded-support certificate are kept distinct.

### Targeted primary comparison in this round

- Fomin–Zelevinsky, [Cluster algebras IV, arXiv:math/0602259v3](https://arxiv.org/pdf/math/0602259), §2, equations (2.13)–(2.15), gives exactly the extended-matrix geometric exchange rule used in (6.2). Gross–Hacking–Keel–Kontsevich, [arXiv:1411.1394v2](https://arxiv.org/pdf/1411.1394), Theorem 4.10, proves the positive Laurent phenomenon used in (6.3). These passages were directly checked. Convexity and the halfspace implementation are direct standard consequences, not separate new theorems.
- Benini–Park–Zhao, [arXiv:1406.2699](https://arxiv.org/pdf/1406.2699), §3.3, equations (3.29)–(3.39), was reopened. Their complementary polynomial has the full degree maximum, and the text explicitly separates strong and weak solutions and does not claim a complete general chiral-ring presentation. The quotient/complement identities are prior machinery. The positive-origin Artin factor and the flat separation/two-sided-length proof above are the additional work here; the resulting minimum formula itself is standard tropical A mutation.
- Reading–Stella, [arXiv:2603.19391v4](https://arxiv.org/html/2603.19391v4), 8 November 2026, §5.3, definitions of \(\psi,\phi,\nu,\mathcal N\), Theorem 5.6 with its proof, Theorem 5.7 and Lemmas 5.10–5.12, and §5.4/Remark 5.15 were directly read. Their finite-word nonnegativity conditions concern theta expansions of pointed elements and products whose labels share a mutation-fan cone; signed-nondegenerating coefficients and the small canonical algebra are explicit hypotheses. The present certificate concerns the ordinary coefficient support through a doubled, partially frozen, zero-endpoint core. A generic “intersect tropical inequalities” strategy should not be claimed as new. No theorem read there directly supplies the origin-local complementary-factor construction or guarantees boundedness of our degree set. This is a precise scope comparison, not proof of historical priority.
- Fei, [arXiv:1911.10513v6](https://arxiv.org/pdf/1911.10513), Theorem 5.1 and its proof, gives the hom-halfspace presentation of the Newton polytope of a finite-dimensional representation. The finite-dimensional Jacobian assumption is retained in Remark 6.10. The identification of theta and triangular Newton polytopes with the generic representation Newton polytope appears there as Conjecture 6.11, not as an unconditional theorem. These passages provide a useful comparison but do not justify replacing an arbitrary theta function by a module character. No claim is made that support halfspaces or representation Newton-polytope methods themselves are new.
- The Q-system/Bethe-ansatz search located Frenkel–Koroteev–Sage–Zeitlin on q-opers and polynomial QQ systems, and Gu–Jiang–Sperling on rational Q systems. Their shifted equations and nondegeneracy hypotheses differ from the present classical remainder system. They are retained as interfaces only; no result from them is imported.

The executable support and complete-polynomial routines, with exact dual certificates, are described in ZERO_ENDPOINT_CERTIFICATE_RUN.md.
