# Residual theta inequalities and terminal supports

2026-11-13. Deduction from the positive divided-power theorem in `FREEZING_POSITIVE_SHEAR_DRAFT.md`, conditional only on that theorem's final independent review. No finite upper=middle assumption is used in these deductions.

Write

    theta_g = x^g F_g(z),   F_g(z)=sum_p a_g(p) z^p,
    z_i=y_i x^{B e_i},     R_i=x_i partial_{y_i}.

For r>=0 put R^[r]=product_i R_i^{r_i}/r_i! and h=g+(I+B)r. The commuting ordinary derivatives give exactly

    R^[r] theta_g = x^h sum_{p>=0} binom(p+r,r) a_g(p+r) z^p.       (1)

Here the binomial is the product of the coordinate binomials. The leading coefficient of (1) is a_g(r). Therefore in its theta-positive expansion the theta_h coefficient with no extra frozen monomial is exactly a_g(r). All remaining contributions are nonnegative. Hence

    binom(p+r,r) a_g(p+r) >= a_g(r) a_{g+(I+B)r}(p).              (2)

This holds for every p,r>=0 and every finite principal theta_g. A coefficientwise extension to any formal theta in the common completion uses the same positive-shear argument; the finite case is sufficient for the current stopping problem.

## Residual support inclusion

If a_g(r)>0, then

    r + Supp(F_{g+(I+B)r}) subset Supp(F_g).                       (3)

In particular a finite theta_g produces another finite theta at every supported r, with a concrete translated Newton-polytope inclusion

    r + Newt(F_{g+(I+B)r}) subset Newt(F_g).

This is a genuinely same-g support restriction, although the residual theta has a changed label. It is stronger than a numerical bound on the value of F_g.

## Terminal points

If r is coordinatewise maximal in Supp(F_g), then (1) is the single monomial a_g(r)x^h. The positive theta_h contribution forces F_h=1. The singleton coefficient formula a_h(e_i)=[-h_i]_+ then implies

    g+(I+B)r >= 0 coordinatewise.                                (4)

This proof does not need to infer regularity of a monomial from an upper-algebra theorem.

More generally, if a_g(r)>0 and h_i=g_i+r_i+(Br)_i<0, (2) at p=e_i yields

    (r_i+1) a_g(r+e_i) >= (-h_i) a_g(r) > 0.                      (5)

Thus every supported point whose residual label has a negative coordinate has a one-step supported successor. For finite F_g, iterating legal successor steps eventually reaches a point satisfying (4).

## What this does not show

It does not imply a predecessor at every nonzero supported point, nor that all support components are reached by the successor process started at zero. A fresh exact probe falsified even the weaker assertion that this initial legal process reaches the largest total degree.

Take

    B = [[0,-2,3],[2,0,-3],[-3,3,0]],   g=(-1,1,1).

The process p -> p+e_i when g_i+p_i+(Bp)_i<0 has exactly the seven states

    (0,0,0), (1,0,0), (1,0,1), (1,0,2),
    (1,1,2), (1,2,2), (1,3,2).

Its maximum total degree is 6, whereas the exact coefficient oracle gives

    a_g(2,3,2)=1,

of total degree 7. The seven-state graph is a direct finite integer calculation, not a truncation of an unbounded search. The oracle computation was repeated independently in the derivative-inequality probe. Therefore “enumerate only vacuum derivative words and stop when this graph closes” is not a valid finite support certificate.

The positive mixed-derivative inequalities remain valid and give a new interface for a fuller greedy algorithm. A larger mechanism must account for the nonconstant frozen coefficients in the positive derivative expansion.
