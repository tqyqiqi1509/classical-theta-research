"""Exact generic-unit coefficient algebras for classical cluster theta.

The functions construct the polynomial systems in
UNIVERSAL_UNIT_COEFFICIENT_ALGEBRAS.md, saturate by T times the actual
frame/arrow boundary, and compute the origin-local special length by
finite Macaulay matrices. No numerical generic target, endpoint search,
scattering data, or prior coefficient value is used.

This is an exact reference implementation. Groebner saturation can be
expensive. Each individual input terminates by the origin-finiteness
theorem; this says nothing about stopping the full theta support.
"""
from dataclasses import dataclass
from math import gcd, lcm
from pathlib import Path
import argparse
import json
import time
import sympy as sp
try:
    from .origin_macaulay_length import origin_length
except ImportError:
    from origin_macaulay_length import origin_length


def symmetrizer(B):
    n = len(B)
    if any(len(row) != n for row in B):
        raise ValueError("B must be square")
    if any(int(x) != x for row in B for x in row):
        raise ValueError("B must have integer entries")
    if any(B[i][i] != 0 for i in range(n)):
        raise ValueError("B must have zero diagonal")
    D = [None] * n
    for root in range(n):
        if D[root] is not None:
            continue
        D[root] = sp.Rational(1)
        component = [root]
        queue = [root]
        while queue:
            i = queue.pop()
            for j in range(n):
                if B[i][j] == B[j][i] == 0:
                    continue
                if B[i][j] * B[j][i] >= 0:
                    raise ValueError("B is not skew-symmetrizable")
                wanted = -D[i] * sp.Rational(B[i][j], B[j][i])
                if D[j] is None:
                    D[j] = wanted
                    component.append(j)
                    queue.append(j)
                elif D[j] != wanted:
                    raise ValueError("B is not skew-symmetrizable")
        denominator = lcm(*(int(D[i].q) for i in component))
        integers = [int(D[i] * denominator) for i in component]
        common = gcd(*integers)
        for i, value in zip(component, integers):
            D[i] = value // common
    return tuple(map(int, D))


def check_vectors(n, g, *degrees):
    if len(g) != n or any(int(x) != x for x in g):
        raise ValueError("g must be an integer vector of length n")
    for degree in degrees:
        if len(degree) != n or any(int(x) != x or x < 0 for x in degree):
            raise ValueError("degrees must be nonnegative integer vectors")


def monic(z, degree, prefix):
    variables = tuple(sp.Symbol(f"{prefix}_{j}") for j in range(1, degree + 1))
    return z**degree + sum(c * z**(degree-j)
                           for j, c in enumerate(variables, 1)), variables


def remainder_generators(H, Q, z):
    if sp.degree(Q, z) == 0:
        return []
    remainder = sp.Poly(H, z).rem(sp.Poly(Q, z))
    return [sp.expand(c) for c in remainder.all_coeffs() if c != 0]


def actual_boundary(B, g, Q, z):
    n = len(g)
    sigma = sp.Integer(1)
    for i in range(n):
        if g[i] != 0:
            sigma *= Q[i].subs(z, 0)
        for j in range(i + 1, n):
            if B[i][j] != 0:
                sigma *= sp.resultant(Q[i], Q[j], z)
    return sp.factor(sigma)


@dataclass
class CoefficientSystem:
    kind: str
    T: object
    variables: tuple
    parameters: tuple
    generators: tuple
    boundary: object
    symmetrizer: tuple


def theta_system(B, g, p):
    D = symmetrizer(B)
    n = len(B)
    check_vectors(n, g, p)
    z, T = sp.symbols("z T")
    parameters = tuple(sp.Symbol(f"lambda_{i+1}") for i in range(n))
    Q, variables = [], []
    for i in range(n):
        polynomial, coefficients = monic(z, int(p[i]), f"c_{i+1}")
        Q.append(polynomial)
        variables.extend(coefficients)
    generators = []
    for i in range(n):
        if p[i] == 0:
            continue
        A = z**max(g[i], 0)
        E = z**max(-g[i], 0)
        sign = (-1)**(max(-g[i], 0) +
                     sum(p[j]*max(-B[i][j], 0) for j in range(n)))
        for j in range(n):
            A *= Q[j]**max(B[i][j], 0)
            E *= Q[j]**max(-B[i][j], 0)
        H = T*A - parameters[i]*sign*E
        generators.extend(remainder_generators(H, Q[i], z))
    return CoefficientSystem("theta", T, tuple(variables), parameters,
                             tuple(generators), actual_boundary(B, g, Q, z), D)


def derivative_system(B, g, r, q):
    D = symmetrizer(B)
    n = len(B)
    check_vectors(n, g, r, q)
    z, T = sp.symbols("z T")
    old_units = tuple(sp.Symbol(f"zeta_{i+1}") for i in range(n))
    leaf_units = tuple(sp.Symbol(f"lambda_{i+1}") for i in range(n))
    u = tuple(r[i] + q[i] for i in range(n))
    P, Q, variables = [], [], []
    for i in range(n):
        p_i, a_i = monic(z, int(r[i]), f"a_{i+1}")
        s_i, b_i = monic(z, int(q[i]), f"b_{i+1}")
        P.append(p_i)
        Q.append(p_i*s_i + (-1)**u[i]*T/leaf_units[i]
                 if r[i] else s_i)
        variables.extend(a_i + b_i)
    generators = []
    for i in range(n):
        if u[i] == 0:
            continue
        A = z**max(g[i], 0)*P[i]
        E = z**max(-g[i], 0)
        sign = (-1)**(max(-g[i], 0) +
                     sum(u[j]*max(-B[i][j], 0) for j in range(n)))
        for j in range(n):
            A *= Q[j]**max(B[i][j], 0)
            E *= Q[j]**max(-B[i][j], 0)
        H = A - old_units[i]*sign*E
        generators.extend(remainder_generators(H, Q[i], z))
    return CoefficientSystem("derivative", T, tuple(variables),
                             old_units + leaf_units, tuple(generators),
                             actual_boundary(B, g, Q, z), D)


def coefficient_length(system):
    start = time.monotonic()
    if not system.variables:
        return {"length": 1, "certificate": "empty degree",
                "dimensions": [], "kind": system.kind,
                "symmetrizer": system.symmetrizer}
    w = sp.Symbol("saturation_variable")
    field = sp.QQ.frac_field(*system.parameters)
    gb = sp.groebner(
        list(system.generators) + [1 - w*system.T*system.boundary],
        w, system.T, *system.variables, order="lex", domain=field)
    saturated = [polynomial.as_expr() for polynomial in gb.polys
                 if w not in polynomial.as_expr().free_symbols]
    special = [polynomial.subs(system.T, 0) for polynomial in saturated]
    result = origin_length(special, system.variables, system.parameters)
    result.update({
        "kind": system.kind,
        "symmetrizer": system.symmetrizer,
        "variables": len(system.variables),
        "remainder_equations": len(system.generators),
        "saturated_generators": len(saturated),
        "elapsed_seconds": round(time.monotonic() - start, 6),
    })
    return result


def theta_coefficient(B, g, p):
    return coefficient_length(theta_system(B, g, p))


def derivative_branch(B, g, r, q):
    return coefficient_length(derivative_system(B, g, r, q))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path,
                        help="JSON file with kind, B, g and p or r,q")
    options = parser.parse_args()
    if options.input:
        data = json.loads(options.input.read_text())
        if data["kind"] == "theta":
            results = theta_coefficient(data["B"], data["g"], data["p"])
        elif data["kind"] == "derivative":
            results = derivative_branch(data["B"], data["g"],
                                        data["r"], data["q"])
        else:
            raise ValueError("kind must be theta or derivative")
    else:
        B = [[0, 1], [-1, 0]]
        results = {
            "ordinary_A2": theta_coefficient(B, [-2, -2], [1, 1]),
            "derivative_A2": derivative_branch(B, [-2, -2], [0, 1], [1, 0]),
        }
    print(json.dumps(results, indent=2))
