# Universal unit coefficient algebras with only T exponents zero and one

2026-11-14. Classical skew-symmetric and skew-symmetrizable cluster data. This is an algorithmic simplification of the reviewed global coefficient model and the generic-residue detector-window theorem.

The formulas below require no large generic integer endpoint vector. Their coefficient fields are rational function fields in explicitly independent unit parameters. The final answer is the dimension of a finite **local** rational algebra, computable by polynomial division, saturation, and a local standard basis or primary-component extraction. No infinite series is used by the algorithm.

## 1. Ordinary theta coefficients: every endpoint exponent can be one

Fix \(B,g,p\). Introduce algebraically independent units \(\lambda_i\) and the coefficient field

\[
K=\mathbb Q(\lambda_1,\ldots,\lambda_n).
\]

For \(p_i>0\), introduce the monic polynomial

\[
Q_i(z)=z^{p_i}+c_{i,1}z^{p_i-1}+\cdots+c_{i,p_i};
\]

take \(Q_i=1\) when \(p_i=0\). Put

\[
A_i(z)=z^{[g_i]_+}\prod_jQ_j(z)^{[B_{ij}]_+},
\]

\[
E_i(z)=(-1)^{[-g_i]_++\sum_jp_j[-B_{ij}]_+}
z^{[-g_i]_+}\prod_jQ_j(z)^{[-B_{ij}]_+}.
\]

The row polynomials are simply

\[
\boxed{H_i(z)=T A_i(z)-\lambda_i E_i(z).}
\tag{1.1}
\]

Let \(J\) be the ideal of all coefficients of \(H_i\bmod Q_i\) in \(R=K[T,c]\). Let

\[
\Sigma=\prod_{i:g_i\ne0}Q_i(0)
\prod_{i<j:B_{ij}\ne0}\operatorname{Res}(Q_i,Q_j),
\qquad I=J:(T\Sigma)^\infty.
\tag{1.2}
\]

At the origin \(\mathfrak m=(T,c)\), define

\[
\mathcal A_{B,g,p}^{\rm unit}
=\bigl(R/I\bigr)_{\mathfrak m}/T\bigl(R/I\bigr)_{\mathfrak m}.
\tag{1.3}
\]

If the origin is not in the saturated scheme, this localization is the zero algebra. For \(p=0\), use the one-dimensional algebra \(K\).

Then

\[
\boxed{a_g(p)=\dim_K\mathcal A_{B,g,p}^{\rm unit}.}
\tag{1.4}
\]

### Why the all-ones endpoint is legitimate

The primitive endpoint is \(a_i=1\) for every color. Every nonempty frame-free cut has strictly positive raw weight \(\sum_iD_i v_i\). Thus no proper cut has zero weight, and the lower actual-arrow bound is uniform in a small neighborhood.

The generic-color-residue argument in `../finite_mechanism_fresh_7h/GENERIC_RESIDUE_DETECTOR_WINDOW.md`, §§4–7, applies at this potentially rank-nongeneric endpoint. There are only finitely many initial degeneration types of the Gale graph. Excluding the images of components which do not dominate the color target torus gives a nonempty generic-unit open. A central positive point with unit residue in this open is approximated tropically by points at nearby rank-generic color endpoints. The uniform upper bounds from the good hierarchies, and the cut lower bound just noted, pass to it. A connected one-parameter target annulus compares its degree to the nearby generic endpoint, which remains in the same positive chamber.

The algebraically independent \(\lambda_i\) lie in every nonempty Zariski-open set defined by these finite rational data. The nearby generic-endpoint global theorem identifies the degree with \(a_g(p)\). Characteristic-zero Young sign projection and the base-linear remainder/alternant compression then give the same finite-flat degree for the monic coefficient algebra.

Thus genericity has moved from potentially huge endpoint exponents into a canonical rational-function coefficient field. Formula (1.1) uses only the first power of \(T\).

## 2. Divided-derivative branches: old exponents zero, leaf exponents one

Let \(r,q\ge0\), \(u=r+q\), and \(h=g+(I+B)r\). Define \(d_{g;r,q}\) by

\[
R^{[r]}\theta_g
=\sum_{q\ge0}d_{g;r,q}\,y^q\theta_{h+Bq}.
\]

Use the field

\[
K'=\mathbb Q(\zeta_1,\ldots,\zeta_n,
\lambda_1,\ldots,\lambda_n)
\]

of independent old and leaf unit parameters. Introduce monic \(P_i,S_i\) of degrees \(r_i,q_i\), respectively, and define

\[
Q_i(z)=
\begin{cases}
P_i(z)S_i(z)+(-1)^{u_i}\lambda_i^{-1}T,&r_i>0,\\
S_i(z),&r_i=0.
\end{cases}
\tag{2.1}
\]

Here \(Q_i\) has degree \(u_i\). Put

\[
\varepsilon_i=(-1)^{[-g_i]_++\sum_ju_j[-B_{ij}]_+},
\]

\[
\boxed{H_i(z)=z^{[g_i]_+}P_i(z)
\prod_jQ_j(z)^{[B_{ij}]_+}
-\zeta_i\varepsilon_i z^{[-g_i]_+}
\prod_jQ_j(z)^{[-B_{ij}]_+}.}
\tag{2.2}
\]

Let \(J\) be the monic-remainder ideal \(H_i\bmod Q_i\). Use

\[
\Sigma=\prod_{i:g_i\ne0}Q_i(0)
\prod_{i<j:B_{ij}\ne0}\operatorname{Res}(Q_i,Q_j),
\qquad I=J:(T\Sigma)^\infty,
\tag{2.3}
\]

in \(R'=K'[T,\text{coefficients of }P,S]\). At the origin of all these coefficient variables and \(T\), define

\[
\mathcal D_{B,g;r,q}^{\rm unit}
=\bigl(R'/I\bigr)_{\mathfrak m}/T\bigl(R'/I\bigr)_{\mathfrak m}.
\tag{2.4}
\]

Then

\[
\boxed{d_{g;r,q}=\dim_{K'}\mathcal D_{B,g;r,q}^{\rm unit}.}
\tag{2.5}
\]

The generic-residue core theorem permits **any** positive leaf endpoint \(a\), in particular \(a_i=1\). Indeed, after common coordinate scaling, the endpoint is

\[
(t(h+Bq),\,\mathbf1-tu),
\]

and sufficiently small \(t>0\) keeps every leaf-containing proper cut nonzero while making every old-only zero cut have zero skew cut pairing. The detector direction and large-relative-leaf condition are obtained by taking \(t\) small. No genericity of \(\mathbf1\) itself is needed.

Before eliminating leaves, their rows are

\[
P_i\mid T-(-1)^{u_i}\lambda_iQ_i,
\]

which is exactly (2.1). The old–leaf resultant becomes a nonzero constant times \(T^{r_i}\), already handled by \(T\)-saturation. There is no discriminant factor. The local choice in (2.4) is essential: at old endpoint zero, other special-fiber components can represent outer old roots. Taking the entire global \(T=0\) quotient would not make the required selection.

## 3. The origin-completion lemma

The remaining bridge is a general algebra statement. It prevents the invalid inference that a finite set of positive solutions automatically makes an arbitrary global special fiber finite.

### Lemma

Let \(k\) be an infinite characteristic-zero field, let \(R=k[T,c_1,\ldots,c_N]\), and let

\[
I=J:(T\Sigma)^\infty.
\]

Localize \(R/I\) at the origin \(\mathfrak m=(T,c)\), obtaining \(C\), and let \(\widehat C\) be its \(\mathfrak m\)-adic completion. Assume that the actual algebraic system on \(T\Sigma\ne0\), restricted to all \(c_i\) having positive valuation, has a finite **full Artin factor** \(A_+\) over \(k((T))\), of length \(d\). This statement is assumed over arbitrary complete valued extensions, as supplied by an affinoid finite-factor theorem.

Then \(C/TC\) is Artinian, \(\widehat C\) is finite free over \(k[[T]]\), and

\[
\widehat C[1/T]\cong A_+,\qquad
\dim_k(C/TC)=\operatorname{rank}_{k[[T]]}\widehat C=d.
\tag{3.1}
\]

The zero algebra is allowed.

### Proof: saturation removes the two spurious sources of dimension

Saturation makes multiplication by \(T\) and by \(\Sigma\) injective on \(R/I\), hence on \(C\). Noetherian local completion is flat, so both remain nonzerodivisors on \(\widehat C\). This removes vertical \(T=0\) components and components supported entirely on the excluded actual-arrow boundary.

### Proof: an algebraic dimension argument for the origin tube

Suppose \(\dim C=s\ge2\). Since \(T\) is a nonzerodivisor, choose \(s-1\) elements \(z_1,\ldots,z_{s-1}\) from the original local ring, for instance suitable \(k\)-linear combinations of the \(c_i\), so that

\[
(T,z_1,\ldots,z_{s-1})
\]

is \(\mathfrak m\)-primary. The completed ring \(\widehat C\) is finite over

\[
B_0=k[[T,z_1,\ldots,z_{s-1}]].
\]

To see finiteness directly, lift a finite \(k\)-basis of the quotient by that parameter ideal and reduce iteratively; completeness makes the resulting power-series coefficients converge. The parameter ring embeds: a nonzero kernel would lower its dimension, contradicting the equality of dimensions under a finite ring map.

Take algebraically independent residues \(w_1,\ldots,w_{s-1}\) and evaluate

\[
z_j=T w_j
\]

in \(k(w_1,\ldots,w_{s-1})[[T]]\). The map from \(B_0\) is injective: in the first nonzero total degree of a power series, substitution gives a nonzero polynomial in the algebraically independent \(w_j\). Choose a minimal prime \(P\) of \(\widehat C\) which contracts to zero in \(B_0\). Such a component exists by lying-over. Then \(D=\widehat C/P\) is a finite domain over \(B_0\), and \(\Sigma\) is nonzero in \(D\), since it avoids every minimal prime of \(\widehat C\).

Let \(L=\operatorname{Frac}(D)\) and \(F=k(w)((T))\). The finite algebra

\[
L\otimes_{\operatorname{Frac}(B_0)} F
\]

is nonzero. Choose one of its field quotients \(E\), a finite extension of \(F\). The map \(L\to E\) is injective because it is a nonzero map from a field. Thus the induced valued point still has \(\Sigma\ne0\). Extend the \(T\)-adic valuation from \(F\) to \(E\), normalized by \(v(T)=1\).

Every element of \(\widehat C\) is integral over \(B_0\), and the image of \(B_0\) has nonnegative valuation. Consequently every image of an element of \(\widehat C\) has nonnegative valuation. Choose \(N\) such that \(\mathfrak m^N\subset(T,z_1,\ldots,z_{s-1})\). All generators on the right have valuation one, and their coefficients have nonnegative valuation, so \(v(c_i)\ge1/N\) for every \(i\). Thus this is an actual-arrow-open point in the origin positive factor.

But \(z_j=T w_j\) is transcendental over \(k((T))\), whereas every coordinate of a point of a finite \(k((T))\)-algebra is algebraic over \(k((T))\). The \(z_j\) were chosen in the original local ring, so they too would be algebraic if the point factored through \(A_+\). This contradiction proves \(\dim C\le1\).

If \(C\ne0\), \(T\)-regularity forces dimension one. Then \(C/TC\) is a zero-dimensional Noetherian local ring, hence Artinian. This is the desired dimension conclusion without invoking an unproved generic-tube dimension assertion.

### Proof: finite freeness and preservation of local multiplicities

Because \(C/TC\) is Artinian, the \(T\)-adic and \(\mathfrak m\)-adic topologies on \(C\) are equivalent. Lift a finite \(k\)-basis of \(C/TC\). Iterative \(T\)-adic reduction shows that these lifts generate \(\widehat C\) over \(k[[T]]\). Therefore \(\widehat C\) is finite; \(T\)-regularity makes it torsion-free and thus free over the DVR.

For completeness, the resulting generic fiber is a full local factor, not just an algebra with the same points. Put

\[
C'=k[[T]]\otimes_{k[T]} C.
\]

Its \(T\)-adic completion is \(\widehat C\). The completion map is flat and is surjective, since the finite lifted basis and its \(k[[T]]\)-coefficients already lie in \(C'\). A surjective flat map of Noetherian rings has an idempotent kernel. Hence \(\widehat C\) is an open-and-closed factor of \(C'\). After inverting \(T\), multiplication by \(\Sigma\) is injective on a finite-dimensional algebra and therefore invertible.

Every point of this factor has all \(c_i\) of positive valuation. Conversely every actual-arrow-open positive point localizes at \(\mathfrak m\) and extends continuously to the completion, because each denominator with nonzero residue at the origin is a unit. The open-and-closed factor argument retains every local Artin algebra. It follows that \(\widehat C[1/T]\) is exactly \(A_+\). Reduction modulo \(T\) identifies \(\widehat C/T\widehat C\) with \(C/TC\), proving (3.1). QED.

## 4. Applying the lemma to the two coefficient formulas

For monic polynomials, all coefficient variables reducing to zero is equivalent to every root having positive valuation (zero roots have infinite valuation and are allowed unless an actual frame/arrow factor excludes them). In the eliminated derivative model this also identifies the new coordinates correctly. If all roots of the old \(Q_i\) and leaf \(P_i\) are positive, then every nonleading coefficient of \(Q_i-(-1)^{u_i}\lambda_i^{-1}T\) has positive valuation. This monic polynomial has only positive roots, and its quotient \(S_i\) by \(P_i\) therefore has only positive roots. Conversely positive roots of \(P_i,S_i\) imply positive nonleading coefficients and hence positive roots of \(Q_i=P_iS_i+(-1)^{u_i}\lambda_i^{-1}T\). Thus the coefficient origin in \((P,S)\) is exactly the original core positive tube, not an additional restriction.

Their finite-factor and finite-flat results hold after arbitrary complete valued base extensions, and the remainder/alternant compression preserves the full Artin modules. Apply the lemma over \(K\) for (1.3), and over \(K'\) for (2.4). This proves that the displayed local special algebras are finite, and that their dimensions are the required coefficients.

## 5. A finite exact algorithm

The proof uses completion, but the algorithm does not:

1. Perform monic polynomial division to form the finite remainder ideal \(J\).
2. Compute \(I=J:(T\Sigma)^\infty\), for example by adjoining a variable \(w\), imposing \(1-wT\Sigma=0\), and eliminating \(w\).
3. Set \(T=0\).
4. Extract the local component at the coefficient origin. One may use a local standard basis or primary decomposition, but the finite matrix procedure below avoids both.
5. Return its local length. That integer is (1.4) or (2.5).

### 5.1 A matrix-only local-length procedure with a stopping certificate

Let \(I_0=(I+(T))/(T)\subset K[c]\), and write \(\mathfrak n=(c_1,\ldots,c_N)\). For each integer \(s\ge1\), compute

\[
L_s=\dim_K K[c]/(I_0+\mathfrak n^s).
\tag{5.1}
\]

This is a finite linear-algebra problem. Columns are the monomials of total degree less than \(s\). Rows are the generators of \(I_0\), multiplied by every monomial of degree less than \(s\), then truncated to those columns. Their exact row rank subtracted from the number of columns is \(L_s\). No Gröbner computation is needed for this stage.

If \(L_1=0\), return zero. Otherwise stop at the first equality

\[
L_s=L_{s+1}
\tag{5.2}
\]

and return \(L_s\). Indeed the truncated quotient is supported only at the origin, so it equals the corresponding quotient of the origin-local ring. Equality (5.2) says \(\mathfrak n^s/\mathfrak n^{s+1}=0\) there. Nakayama's lemma applied to the finitely generated module \(\mathfrak n^s\) gives \(\mathfrak n^s=0\). Thus the returned value is the entire local length, not merely a stabilized-looking numerical prefix. The origin-completion lemma proves that the local ring is Artinian, so this equality must eventually occur.

The accompanying `origin_macaulay_length.py` implements this exact finite-matrix stage over a rational function field and records the successive dimensions. This local stopping certificate is for an individual coefficient algebra; it must not be confused with a stopping theorem for the entire Laurent support of a theta function.

All arithmetic takes place in an explicitly given characteristic-zero rational function field. The local component is proven finite, so its staircase computation terminates. Variables with degree zero are simply omitted. No choice of a scattering chamber, large exponent vector, generic numerical target, or prior theta coefficient is part of the input.

## 6. Scope and priority boundary

The original global Gale/sign identification and the new generic-residue detector-window theorem remain the substantive inputs. The universal-unit formulas simplify their final algorithm; they do not replace those proofs with a genericity assertion. Polynomial remainder algebra, saturation, local standard bases, and formal Noether normalization are standard algebraic tools.

The construction gives every individual formal coefficient and every divided-derivative branching coefficient by finite algebra. It does not assert that every theta label has finite Laurent support, nor does it yet supply a general stopping certificate for every finite theta polynomial.

## 7. Standard commutative-algebra references checked

The proof above includes the dimension argument explicitly. Its routine completion steps agree with the following primary statements, read directly in this round:

- [Stacks, Tag 00MB](https://stacks.math.columbia.edu/tag/00MB), Lemma 10.97.2: Noetherian completion is flat and is exact on finite modules.
- [Stacks, Tag 031C](https://stacks.math.columbia.edu/tag/031C), Lemma 10.97.4: reduction modulo powers of the completion ideal commutes with completion.
- [Stacks, Tag 00U8](https://stacks.math.columbia.edu/tag/00U8), Lemma 10.143.9: a surjective flat finitely presented map is localization at an idempotent. Here finite presentation follows from Noetherianity.

These are standard algebraic inputs. The new work in this formula is the generic-unit positive-factor identification and its reduction to the finite origin-local algebra, not a new completion theorem.
