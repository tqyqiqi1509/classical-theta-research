"""Exact origin-local length from finite truncated Macaulay matrices.

Input ideal generators are after T-saturation and T=0 specialization.
The mathematical application proves the origin-local algebra Artinian.
One equality L_s=L_(s+1) is then an exact Nakayama certificate, not a
heuristic stability threshold. Arithmetic is over QQ(parameters).
"""
import json
import sympy as sp


def monomials_below(n, bound):
    if n == 0:
        return [()]
    if bound <= 0:
        return []

    def fixed_degree(number, degree):
        if number == 1:
            yield (degree,)
        else:
            for first in range(degree + 1):
                for tail in fixed_degree(number - 1, degree - first):
                    yield (first,) + tail

    return [a for degree in range(bound)
            for a in fixed_degree(n, degree)]


def sparse_rank(rows, field):
    pivots = {}
    for source in rows:
        row = {j: a for j, a in source.items() if a != field.zero}
        while row:
            j = min(row)
            a = row[j]
            if j not in pivots:
                pivots[j] = {k: b / a for k, b in row.items()}
                break
            for k, b in pivots[j].items():
                value = row.get(k, field.zero) - a * b
                if value == field.zero:
                    row.pop(k, None)
                else:
                    row[k] = value
    return len(pivots)


def truncated_length(generators, variables, parameters, bound):
    n = len(variables)
    field = sp.QQ.frac_field(*parameters) if parameters else sp.QQ
    if n == 0:
        return int(not any(field.from_sympy(sp.sympify(f)) != 0
                           for f in generators))
    basis = monomials_below(n, bound)
    column = {a: j for j, a in enumerate(basis)}
    polynomials = [sp.Poly(f, *variables, domain=field).rep.to_dict()
                   for f in generators if f != 0]
    polynomials = [f for f in polynomials if f]

    def rows():
        for polynomial in polynomials:
            minimum = min(map(sum, polynomial))
            if minimum >= bound:
                continue
            for shift in monomials_below(n, bound - minimum):
                row = {}
                for degree, coefficient in polynomial.items():
                    out = tuple(a + b for a, b in zip(degree, shift))
                    if sum(out) < bound:
                        row[column[out]] = coefficient
                if row:
                    yield row

    rank = sparse_rank(rows(), field)
    return len(basis) - rank


def origin_length(generators, variables, parameters=()):
    dimensions = []
    bound = 1
    previous = None
    while True:
        value = truncated_length(generators, variables, parameters, bound)
        dimensions.append({'power': bound, 'dimension': value})
        if bound == 1 and value == 0:
            return {'length': 0, 'certificate': 'L_1=0',
                    'dimensions': dimensions}
        if previous == value:
            return {'length': value,
                    'certificate': f'L_{bound-1}=L_{bound}',
                    'maximal_ideal_nilpotence_bound': bound - 1,
                    'dimensions': dimensions}
        previous = value
        bound += 1


if __name__ == '__main__':
    x, u, a = sp.symbols('x u a')
    # The universal-unit derivative core B_12=1, g=(-2,-2), r=(0,1),
    # q=(1,0), at T=0. Global elimination has an additional nonorigin
    # length-two component; this routine must select local length four.
    result = origin_length([x-u-a*x*x, u*u*(u-x)], (x, u), (a,))
    print(json.dumps(result, indent=2))
