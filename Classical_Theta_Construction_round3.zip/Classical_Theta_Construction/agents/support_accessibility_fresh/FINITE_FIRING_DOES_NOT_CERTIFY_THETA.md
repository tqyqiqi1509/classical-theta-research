# Finite vacuum firing does not certify a finite theta function

2026-11-14, 00:04 UTC. This closes the specific proposed converse, not the main finite-stopping problem. It isolates why the nonconstant coefficients of the positive divided-derivative action are essential.

## 1. The exact assertion being tested

For a skew-symmetric exchange matrix (B), let a legal firing from (p\in\mathbb N^n) be

\[
p\longmapsto p+e_i\quad\text{when}\quad
g_i+p_i+(Bp)_i<0.
\]

Positive divided derivatives imply that every legally reached (p) is in the support of (F_g). Consequently, if (F_g) is finite, all legal firing paths terminate. The converse is false.

## 2. A classical skew-symmetric counterexample

Partition nine vertices into three ordered groups (A,B,C), each with three vertices. Let (J) be the (3\times3) all-ones matrix and put

\[
B=\begin{pmatrix}0&J&-J\\-J&0&J\\J&-J&0\end{pmatrix},
\qquad
g=B e_1=(0,0,0,-1,-1,-1,1,1,1).
\]

The entire legal firing graph starting from (p=0) has **464 states**. Its maximum total degree is **27**. Quotienting by the group (S_3^3), which permutes coordinates within each block, gives **91 states**. Thus every legal firing path has length at most 27.

This finite assertion is checked by a terminating exhaustive integer computation, not by truncating an unclosed graph. The companion `finite_firing_infinite_theta_certificate.json` lists all 91 quotient states and every successor. The independent verifier `verify_finite_firing_certificate.py` checks closure, reachability, every possible legal move, the 464 unquotiented states, and the total-degree bound. The symmetry quotient loses no transitions because the matrix and (g) are invariant under (S_3^3). Each firing strictly increases total degree, so a finite graph here has no directed cycles.

Nevertheless, the normalized principal-coefficient theta series (\theta_g=x^gF_g(yx^B)) has **infinite** Laurent support.

## 3. Geometric proof of infinite theta support

Use the seed in Gross–Hacking–Keel, *Birational geometry of cluster algebras*, arXiv:1309.2573v2, Construction 5.3 and Example 6.3. Its rank-nine lattice (N) maps onto \(\bar N=\mathbb Z^2\) by sending the three (A)-basis vectors to ((1,0)), the three (B)-basis vectors to ((0,1)), and the three (C)-basis vectors to ((-1,-1)). All multiplicities (\nu_i) are one. Choose the sign of the alternating pairing so that the root-exponent map is (p^*=B), as above.

These data satisfy Proposition 5.4 exactly: there are no frozen variables in the underlying (X)-seed; the quotient alternating form is unimodular; the images of all basis vectors are primitive; and the vectors generate \(\bar N\). There is no appeal to the weighted, singular rank-three variant mentioned later in the same example.

Let (K=\ker p^*\). The generic (X\)-fiber is, up to codimension two, the complement of the boundary in a surface obtained from \(\mathbb P^2\) by blowing up three points on each coordinate line. Its boundary is a cycle of three \((-2)\)-curves. The proof of GHK Theorem 6.2 shows that a very general such fiber has only constant regular functions: the normal bundle of the boundary is nontorsion, so the successive spaces (H^0(Y,\mathcal O_Y(mD))) all equal the constants. Section 7 then explicitly concludes

\[
\operatorname{up}(X)=\Gamma(X,\mathcal O_X)=\Bbbk[K].
\]

Now suppose (F_g) were finite. GHKK, *Canonical bases for cluster algebras*, arXiv:1411.1394v2, Proposition 7.1 proves that finiteness of a principal theta function in one cluster chamber implies that it is a universal Laurent polynomial. Therefore

\[
f=y_1\theta_g
\]

is a global regular function on (A_{\mathrm{prin}}). Every monomial of (f) has exponent

\[
(g+Bp,e_1+p)=(B(e_1+p),e_1+p).
\]

The principal torsor \(\widetilde p:A_{\mathrm{prin}}\to X\) pulls back the (X\)-monomial (z^n) to the monomial with exponent ((p^*n,n)). Consequently (f) is invariant under the torsor torus and descends to a regular function on (X\). This precise pullback and invariant-part construction appear in GHKK §7.2–7.3, particularly Construction 7.11 and Definition 7.12; no equality of middle and upper algebras is assumed.

The initial expansion of the descended function contains (z^{e_1}) with coefficient one. Since (p^*e_1=g\ne0), we have (e_1\notin K\). But a Laurent polynomial in \(\Bbbk[K]\) has every exponent in (K\). This contradicts \(\Gamma(X,\mathcal O_X)=\Bbbk[K]\). Hence (F_g) is infinite.

The argument actually proves that for this rank-nine seed, every nonzero (g\in p^*(N)\) has an infinite normalized principal theta expansion: choose (n\) with (p^*n=g\), multiply by the frozen monomial (y^n\), and repeat the same descent. Only one such (g\) is used to refute the firing criterion.

## 4. Consequence for a general stopping mechanism

The obstruction is substantive: vacuum firings use only the constant coefficient of the positive theta expansion of (x_i\partial_{y_i}\). In the example, this finite part cannot see the infinite support. Any criterion built from the entire divided-derivative action must retain its nonconstant frozen coefficients. The result does not disprove support accessibility or a no-empty-total-degree-layer theorem. It prevents replacing either missing theorem by termination of the vacuum firing game.

## 5. Audited source interfaces

* GHK, arXiv:1309.2573v2, Construction 5.3, Proposition 5.4, Theorem 6.2 proof, Example 6.3, and §7: read in the primary text. The rank-nine all-multiplicity-one example is used; the rank-three weighted example is deliberately not needed.
* GHKK, arXiv:1411.1394v2, Proposition 7.1: read its proof; initial finite theta implies universal Laurent polynomial by positivity and adjacent-chamber transport.
* GHKK, Construction 7.11 / Definition 7.12, and the preceding principal torsor formula: read in the primary text; the invariant subalgebra is the (X\)-algebra. No full Fock–Goncharov conjecture is used.

Primary URLs: https://arxiv.org/abs/1309.2573 and https://arxiv.org/abs/1411.1394 . Web retrieval references in this branch include `turn723view0` for GHK §§6–7 and `turn715view0` for GHKK.
