"""Exact finite verification of the rank-nine legal firing counterexample.

No theta oracle and no degree/state cutoffs are used. The queue exhausts.
"""
from collections import deque
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
B = tuple(tuple(0 if i // 3 == j // 3 else
                (1 if (j // 3 - i // 3) % 3 == 1 else -1)
                for j in range(9)) for i in range(9))
g = (0, 0, 0, -1, -1, -1, 1, 1, 1)


def successors(p):
    for i in range(9):
        h = g[i] + p[i] + sum(B[i][j] * p[j] for j in range(9))
        if h < 0:
            yield tuple(p[j] + (j == i) for j in range(9))


def orbit(p):
    return tuple(tuple(sorted(p[3 * i:3 * i + 3])) for i in range(3))


def main():
    zero = (0,) * 9
    seen = {zero}
    queue = deque([zero])
    while queue:
        p = queue.popleft()
        for q in successors(p):
            if q not in seen:
                seen.add(q)
                queue.append(q)
    assert len(seen) == 464
    assert max(map(sum, seen)) == 27
    assert all(q in seen for p in seen for q in successors(p))

    data = json.loads((HERE / 'finite_firing_infinite_theta_certificate.json').read_text())
    states = [tuple(tuple(v) for v in item['p']) for item in data['states']]
    index = {p: i for i, p in enumerate(states)}
    assert set(states) == {orbit(p) for p in seen}
    assert len(states) == 91
    for state, item in zip(states, data['states']):
        flat = sum(state, ())
        expected = {index[orbit(q)] for q in successors(flat)}
        assert expected == set(item['next'])
    receipt = {'status': 'PASS', 'full_states': len(seen),
               'quotient_states': len(states), 'max_degree': max(map(sum, seen)),
               'cutoff_used': False, 'theta_oracle_used': False}
    (HERE / 'finite_firing_certificate_verification.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
