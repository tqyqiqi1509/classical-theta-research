"""Probe a stronger finite certificate: cofinality of vacuum derivative words.

From theta-positive R_i, a legal word has g_i+p_i+(Bp)_i<0 at every
firing and gives a nonzero F coefficient. This direction has a proof.
The tested converse is only total-degree cofinality, not exact support equality.
"""
from collections import deque
import json, random, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'computation'))
from incoming_recursion import IncomingSchur, box


def legal_states(B, g, limit=10000, degree_limit=40):
    zero = (0,) * len(g)
    seen = {zero}
    queue = deque([zero])
    while queue:
        p = queue.popleft()
        h = [g[i]+p[i]+sum(B[i][j]*p[j] for j in range(len(g))) for i in range(len(g))]
        for i, v in enumerate(h):
            if v < 0:
                q = tuple(p[j]+(j == i) for j in range(len(g)))
                if q not in seen:
                    seen.add(q)
                    queue.append(q)
                    if len(seen)>limit or sum(q)>degree_limit:
                        return False, seen
    return True, seen


def main():
    rng = random.Random(202611132342)
    start = time.time(); accepted=0; checked=0; skipped=0
    for trial in range(1000):
        n=3
        B=[[0]*n for _ in range(n)]
        for a in range(n):
            for b in range(a+1,n):
                B[a][b]=rng.randrange(-3,4); B[b][a]=-B[a][b]
        g=tuple(rng.randrange(-2,4) for _ in range(n))
        finite,S=legal_states(B,g)
        if not finite:
            skipped+=1; continue
        D=max(map(sum,S))
        if D>7:
            skipped+=1; continue
        accepted+=1
        R=IncomingSchur(B)
        cap=(min(4,D+2),)*n
        F=R.theta_prefix(g,cap)
        beyond=[(p,c) for p,c in F.items() if sum(p)>D]
        checked+=sum(1 for p in box(cap) if sum(p)>D)
        if beyond:
            result={'status':'cofinality_counterexample','B':B,'g':g,'legal_max_degree':D,
                    'legal_states':sorted(S,key=lambda p:(sum(p),p)),
                    'theta_beyond':beyond,'cap':cap,'accepted':accepted,'checked':checked,
                    'skipped':skipped,'seconds':time.time()-start}
            Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
            print(json.dumps(result),flush=True);return
        if accepted%50==0:print({'accepted':accepted,'checked':checked,'skipped':skipped,'seconds':time.time()-start},flush=True)
    result={'status':'no_counterexample','accepted':accepted,'checked':checked,'skipped':skipped,'seconds':time.time()-start}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)

if __name__=='__main__':main()
