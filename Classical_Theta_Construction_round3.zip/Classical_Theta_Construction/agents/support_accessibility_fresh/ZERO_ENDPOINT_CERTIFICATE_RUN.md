# Running the complete-support certificate

The theorem is ZERO_ENDPOINT_Q_MUTATION_AND_SUPPORT_CERTIFICATES.md. The code accepts any integral skew-symmetrizable matrix, label, and finite collection of original-index mutation words. It automatically includes all prefixes.

The numerical degree update is standard tropical A mutation on the auxiliary seed with mutable block C-transpose and framing row G-transpose, with the leaf indices frozen. Positive Laurent expressions show that the allowed degree set is a convex rational polyhedron. The code computes it through a possibly redundant branch decomposition. The connection to theta support has two proofs: the positive-origin full-Artin mutation theorem, and a direct GHKK min-convexity argument using the coefficient detector. The latter establishes that the numerical support certificate is an explicit consequence of existing tropical mechanisms; only the full-Artin realization remains a separate candidate contribution.

## Dependencies and portable paths

The routines use Python and SymPy, together with the Python standard library. They were run with Python 3.12.14 and SymPy 1.14.0. The complete-polynomial wrapper also loads the project's `computation/incoming_recursion.py`. Its fallback path is derived from the script's own location; no machine-specific workspace path is embedded. The support-certificate routine itself does not need that coefficient backend.

The general one-T coefficient implementation is an alternative, using `universal_unit_coefficient.py` and `origin_macaulay_length.py` in this directory; see `UNIVERSAL_UNIT_RUN.md`. Its exact generic-unit saturation can be expensive, so the complete-output demonstration uses the audited incoming recursion after establishing the finite support bound.

## Complete theta polynomial

From the project root:

    python agents/support_accessibility_fresh/zero_endpoint_support_certificate.py --input agents/support_accessibility_fresh/zero_endpoint_cyclic_example.json --complete

The input JSON contains B, g, and words. Indices in words are zero-based. The supplied cyclic rank-three input uses the words 0, 1, 2, 01, 02. It produces:

- A bounded rational support certificate, with integer box (2,2,3).
- Every dual multiplier proving those bounds on every linear branch.
- The entire Laurent polynomial, recorded as coefficient, x-exponent, and y-exponent for each term.

For this run there are 32 feasible polyhedral branches and 96 coordinate bounds. The Wolfram computation plugin independently checked every nonnegative dual multiplier and every combined inequality, with result True for all 96. The resulting polynomial has 18 nonzero terms. This example validates the executable chain; the theorem is for arbitrary classical skew-symmetrizable input and is not inferred from the example.

The finite support bound is proved before any coefficient is computed. The coefficient stage uses the previously audited incoming-normalized finite recursion. The generic-unit origin algebra is an independent alternative for individual entries.

## Fixed divided-derivative support

Supply an additional vector r in the JSON and omit --complete. The same finite words now constrain q in d_(g;r,q), starting from degrees (r+q,r). A bounded result gives a complete finite search region for all these branching coefficients.

Programmatic calls:

    from agents.support_accessibility_fresh.zero_endpoint_support_certificate import (
        support_certificate, complete_laurent_from_certificate
    )
    cert = support_certificate(B, g, words, r=r)
    polynomial = complete_laurent_from_certificate(B, g, words)

## Meaning of the outcomes

The successful status bounded_support_certificate is a proof of exhaustion for the supplied input. The status not_certified_by_supplied_words says only that this finite collection of words has not supplied a bound. It does not assert that the theta function is infinite.

An empty word collection, or a collection containing only the empty word, returns not_certified_by_supplied_words with an exact nonnegative recession ray. The initial branch stores its zero feasible point. Both forms were checked in theta and fixed-derivative modes, and through the complete-output wrapper.

No theorem in this work guarantees that every finite theta admits one of these certificates. Searching larger word sets is a possible further procedure, with no claimed general stopping theorem.

More precisely, for full-theta support the existence of a bound from a fixed word set depends only on B, not on g. The initial polyhedron always contains the origin, and its homogeneous recession test uses degrees (v,v) with framing weight zero. A successful word set can therefore be found at g=0 and reused for all labels of that matrix. The resulting affine numerical bounds still depend on g. If the matrix has any infinite formal theta function, this particular word certificate cannot succeed for any label of that matrix. The theorem's Section 8 gives the exact argument.

Section 8 also gives an alternative using principal B-transpose Laurent supports. Its halfspace normals are independent of g, so one fixed collection of exact dual multipliers bounds every label; the bound grows at most linearly with the infinity norm of g. This fixed-normal optimization is stated mathematically but is not a second implemented backend in this release. The executed code remains the fully checked branch implementation.

## Exact arithmetic and a backend issue caught during validation

All branch inequalities have integer coefficients. The implementation uses exact rational linear programming and checks every proposed witness itself. Coordinate bounds are accepted only with verified nonnegative dual multipliers. Discarded branches require verified Farkas contradictions. Unbounded branches include a verified nonnegative recession ray.

During the cyclic validation, SymPy's simplex routine returned an invalid primal witness for a redundant constraint system. The explicit witness checks rejected it. The code now falls back to finite exact rational vertex enumeration, including normalized recession-ray enumeration where needed. The invalid output was never used as a certificate.

There is no floating-point tolerance in an accepted certificate. The exact enumeration fallback may be expensive in large dimension; this is an implementation cost, not an additional mathematical hypothesis.

## Saved receipts

- `zero_endpoint_complete_laurent_receipt.json`: complete cyclic-input polynomial and its support certificate.
- `zero_endpoint_cyclic_certificate_receipt.json`: the same support computation without coefficient enumeration.
- `zero_endpoint_support_certificate_receipt.json`: the first exact validation input.
- `zero_endpoint_dual_wolfram.wl` and `zero_endpoint_dual_wolfram_receipt.json`: independent computation-plugin verification of all 96 coordinate dual bounds.
- `zero_endpoint_empty_words_receipt.json`: the empty-word regression checks and explicit unbounded witnesses.
- `universal_unit_run_receipt.json`: the separate generic-unit coefficient implementation's successful anchors and its explicitly recorded interrupted symbolic computation.

Independent mathematical review is in the sibling `zero_endpoint_q_fresh_review` directory; the LP-free check of the saved support and complete-output receipt is in the sibling `face_graded_algebra` directory.
