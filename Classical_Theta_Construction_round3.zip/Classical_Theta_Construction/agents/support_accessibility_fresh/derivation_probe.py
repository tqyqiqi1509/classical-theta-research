"""Exact triangular probe for x_i d/dy_i on principal theta series.

This probes a proposed positive-root-derivation bridge, not theta positivity.
The oracle is the already audited incoming-normalized coefficient recursion.
"""
import json, random, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'computation'))
from incoming_recursion import IncomingSchur, box, le, sub


def derivative_expansion(R, g, i, cap):
    source_cap = tuple(x + (j == i) for j, x in enumerate(cap))
    F = R.theta_prefix(g, source_cap)
    h = tuple(g[j] + R.B[j][i] + (j == i) for j in range(R.n))
    J = box(cap)
    c = {}
    H = {}
    for q in J:
        p = tuple(q[j] + (j == i) for j in range(R.n))
        a = (q[i] + 1) * F.get(p, 0)
        for r, b in c.items():
            if le(r, q):
                a -= b * H[r].get(sub(q, r), 0)
        if a:
            c[q] = a
            H[q] = R.theta_prefix(R.shift(h, q), sub(cap, q))
    return h, c


def main():
    rng = random.Random(202611132315)
    results = []
    start = time.time()
    for n, count, cap in [(2, 40, (2, 2)), (3, 80, (1, 1, 1))]:
        for trial in range(count):
            B = [[0] * n for _ in range(n)]
            for a in range(n):
                for b in range(a + 1, n):
                    B[a][b] = rng.randrange(-2, 3)
                    B[b][a] = -B[a][b]
            g = tuple(rng.randrange(-3, 4) for _ in range(n))
            R = IncomingSchur(B)
            for i in range(n):
                h, c = derivative_expansion(R, g, i, cap)
                negative = {str(q): a for q, a in c.items() if a < 0}
                if negative:
                    result = dict(B=B, g=g, i=i, h=h, cap=cap,
                                  negative=negative,
                                  expansion={str(q): a for q, a in c.items()})
                    results.append(result)
                    print(json.dumps(result), flush=True)
                    if len(results) >= 8:
                        output = dict(status='counterexamples', results=results,
                                      seconds=time.time()-start)
                        Path(__file__).with_suffix('.json').write_text(json.dumps(output, indent=2))
                        return
    output = dict(status='no_counterexample_in_probe', results=results,
                  seconds=time.time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(output, indent=2))
    print(json.dumps(output), flush=True)

if __name__ == '__main__':
    main()
