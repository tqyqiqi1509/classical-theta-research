# Full marked-Q layers and the positive derivative convolution

2026-11-14. Assembly after the parent's review of the generic-residue detector-window theorem. Classical skew-symmetric and skew-symmetrizable cluster data.

This note constructs actual disjoint finite factors first. It then uses the independently proved positive-derivative convolution to verify that they cover the full generic marked factor. The independent \(q=0\) construction in `SEPARATED_MARKED_Q_FACTOR.md` does not use that convolution. The full decomposition here does, and this dependency is explicit.

## 1. Statement

Fix \(B,g,r,p\), and put

\[
m=p+r,\qquad h=g+(I+B)r,
\qquad C=\begin{pmatrix}B&I\\-I&0\end{pmatrix},\quad G=(g,0).
\]

The coefficient algebra for \(C,G,(m,r)\) at a positive old endpoint and a much larger positive leaf endpoint has total length

\[
M=\binom{p+r}{r}a_g(p+r).
\tag{1.1}
\]

Choose the generic bounded polynomial old-row perturbations and independent leaf unit targets described below. After finite algebraic extension, this generic marked algebra is the direct sum of open-and-closed factors indexed by

\[
0\le q\le p.
\]

The \(q\)-factor has inner old degree \(u=r+q\), leaf degree \(r\), and outer old degree \(v=p-q\). Its length is

\[
\boxed{d_{g;r,q}\,a_{h+Bq}(p-q).}
\tag{1.2}
\]

Each factor is a finite-flat deformation of a core coefficient family pulled back over an outer coefficient algebra. The core family has rank \(d_{g;r,q}\). All local Artin multiplicities are retained.

At the undeformed original special fiber, the generic idempotents may merge. Choosing an ordering of the \(q\)'s and taking saturated closures gives a filtration whose successive dimensions are (1.2). We do not claim an original-special-fiber direct product, a canonical tensor-product identification, or a pure combinatorial injection between chosen staircase bases.

## 2. The new input: the generic zero-old-endpoint core

For each \(q\), use the theorem in

`../finite_mechanism_fresh_7h/GENERIC_RESIDUE_DETECTOR_WINDOW.md`.

Its core has matrix \(C\), label \(G=(g,0)\), degree \((u,r)=(r+q,r)\), and first-scale endpoint

\[
(0,a),\qquad a_i>0.
\]

On a nonempty Zariski-open set of color unit targets, its complete positive factor is finite flat of rank \(d_{g;r,q}\). The proof is not an application of the generic-endpoint theorem at a nongeneric endpoint. It uses finite initial degenerations and dominant color-target components to obtain a generic-residue window, a connected one-parameter annulus to compare a shifted detector endpoint with a nearby generic endpoint, and exact homogeneous scaling to cover the entire zero-old-endpoint positive locus.

In particular, if \(L=h+Bq=g+Bu+r\), the row-degree vector for common coordinate scaling is

\[
(L,-u).
\]

The substitution \(x=\delta^t\xi\) sends endpoint \((0,a)\) to

\[
(tL,a-tu).
\]

For sufficiently small \(t>0\), this is the old coefficient-detector direction with leaf coordinates still large positive. The theorem constructs the same fixed deep finite-flat family over its generic unit base and proves that it equals the full positive core, including every local Artin block. This uniform family, rather than merely a pointwise degree statement, is the input used below.

## 3. Common parameters for all layers

Use a first parameter \(\delta\) for the inner scale and \(K=\Bbbk((T))\) for the outer coefficient field. Choose a positive old endpoint \(b\) generic for every nonempty outer coefficient

\[
a_{h+Bq}(p-q),\qquad0\le q\le p.
\]

There are only finitely many such conditions. Put \(t_i=T^{-b_i}\), and deform the old row targets by

\[
f_i(z)=t_i-\eta T^N\phi_i(z),\qquad \deg\phi_i\le m_i-1,
\tag{3.1}
\]

with bounded coefficients and \(N\) sufficiently large. Give the leaf rows independent color unit targets \(\lambda_i\delta^{-a_i}\). Their monic equations are

\[
P_i\mid Q_i-(-1)^{m_i}\lambda_i^{-1}\delta^{a_i}.
\tag{3.2}
\]

All these deformations belong to the already proved full target-annulus and bounded polynomial-perturbation families. They preserve the total marked coefficient length. The leaf constants are varied independently; they are not assumed to become generic merely because outer determinants vary.

For an outer layer the degree of \(\phi_i\) may exceed \(v_i-1\). The finite-flat perturbation argument still applies for this fixed finite degree: on the positive coordinate domain a polynomial with bounded coefficients remains bounded, independently of its finite degree; multiplying it by the prescribed sufficiently high \(T\)-power leaves the target valuation unchanged. The same actual-arrow window gives strict relative interior, and the same graph/equation-count argument gives flatness. The bound \(v_i-1\) in the original smoothing lemma was sufficient for interpolation, not necessary for this valuation/flatness argument. Thus allowing the extra coefficients in (3.1) is a direct instance of the same proof, with a larger finite parameter polydisc.

As in §3 of `SEPARATED_MARKED_Q_FACTOR.md`, a generic choice avoids zero outer coordinates for every one of the finitely many outer factors. Same-color repeated roots are still permitted, and no discriminant is saturated.

## 4. Actual inner/outer coordinates for the \(q\)-layer

Fix \(q\), and write

\[
Q_i=U_iV_i,\quad\deg U_i=u_i=r_i+q_i,
\quad\deg V_i=v_i=p_i-q_i.
\tag{4.1}
\]

The \(U_i\)-roots and every \(P_i\)-root are in the positive \(\delta\)-valuation layer. The \(V_i\)-roots have valuation zero and reduce to the chosen positive-\(T\) outer factor. All \(V_i(0)\) are units.

The factorization (4.1) is the monic Hensel factorization with coprime reductions \(z^{u_i}\) and \(\overline V_i\). It is an analytic étale change of monic coefficient coordinates. It does not require the roots within \(U_i\) or \(V_i\) to be distinct.

For the full \(q\)-layer it is best to retain the leaf polynomial \(P_i\), rather than eliminate it. There are

\[
|u|+|r|+|v|=|m|+|r|
\]

monic coefficient variables, the same number as in the original big \(Q,P\)-system. The old remainder equations split modulo \(U_i\) and \(V_i\); the leaf remainder equations remain modulo \(P_i\).

The actual-arrow localizations also split correctly. For example,

\[
\operatorname{Res}(Q_i,P_i)
=\operatorname{Res}(U_i,P_i)\operatorname{Res}(V_i,P_i),
\]

and the second factor is a \(\delta\)-unit. Intercolor old resultants similarly split into the inner resultant, the outer resultant, and mixed unit factors. Thus the selected domain retains exactly the complete local coefficient algebras, with no hidden extra saturation.

## 5. Exact equations, signs, and outer label

Write

\[
\varepsilon_g(w)_i=(-1)^{[-g_i]_++\sum_jw_j[-B_{ij}]_+}.
\]

### 5.1 Inner old rows

For an inner \(U_i\)-root \(x\), the primitive ratio for the core \(C,G,(u,r)\) is

\[
\Gamma_i^{\rm core}(x)
=\varepsilon_g(u)_i^{-1}x^{g_i}P_i(x)
\prod_jU_j(x)^{B_{ij}}.
\]

The actual big row becomes

\[
\Gamma_i^{\rm core}(x)
=\frac{\varepsilon_g(m)_i}{\varepsilon_g(u)_i}
f_i(x)\prod_jV_j(x)^{-B_{ij}}.
\tag{5.1}
\]

Its leading unit target is

\[
A_i(V)=\frac{\varepsilon_g(m)_i}{\varepsilon_g(u)_i}
f_i(0)\prod_jV_j(0)^{-B_{ij}}.
\tag{5.2}
\]

The ratio of the right side of (5.1) to (5.2) is congruent to one in positive \(\delta\)-order.

### 5.2 Inner leaf rows

At a leaf \(P_i\)-root \(y\), the full row is

\[
\frac{(-1)^{m_i}}{U_i(y)V_i(y)}
=\lambda_i\delta^{-a_i}.
\]

The core leaf ratio is therefore

\[
\frac{(-1)^{u_i}}{U_i(y)}
=(-1)^{v_i}\lambda_i V_i(y)\delta^{-a_i}.
\tag{5.3}
\]

Its leading unit target is

\[
A_i^{\rm leaf}(V)=(-1)^{v_i}\lambda_i V_i(0).
\tag{5.4}
\]

These signs and units are retained. The generic-core theorem allows precisely these independent unit targets after the parameter argument in §6.

### 5.3 Outer rows

At an outer \(V_i\)-root \(z\), the leading contributions are

\[
P_i(z)\sim z^{r_i},\qquad U_j(z)\sim z^{u_j}.
\]

Hence the outer label is

\[
L=g+r+Bu=h+Bq.
\tag{5.5}
\]

The exact outer equation is the \(B,L,v\) primitive row with target

\[
\frac{\varepsilon_g(m)_i}{\varepsilon_L(v)_i}f_i(z)
\]

times a unit congruent to one in positive \(\delta\)-order. Thus its limiting finite positive-\(T\) algebra has length \(a_L(v)\).

## 6. Why the core units really are generic over the outer algebra

This is a scheme-level parameter statement, not an assertion that determinant values of outer roots happen to be generic.

For every color with \(u_i>0\), we have \(v_i+1\le m_i\). Since \(V_i(0)\) is a unit, the Chinese remainder map

\[
\{\phi_i:\deg\phi_i\le m_i-1\}
\longrightarrow
\mathcal O[z]/(V_i)\ \oplus\ \mathcal O,
\qquad\phi_i\longmapsto(\phi_i\bmod V_i,\phi_i(0))
\tag{6.1}
\]

is surjective over **any Artin coefficient base** \(\mathcal O\). Indeed \(z\) and \(V_i\) are comaximal, and a representative modulo \(zV_i\) has degree at most \(v_i\le m_i-1\).

Fixing \(\phi_i\bmod V_i\) fixes the entire outer remainder equation, including all confluent conditions at repeated roots. The value \(\phi_i(0)\) can still be chosen independently. Therefore the old core units (5.2) can vary independently while the outer algebra is fixed. Colors with \(u_i=0\) have no inner old row and need no such parameter.

The CRT inverse may have large \(T\)-adic norm because \(V_i(0)\) can be \(T\)-small. This does not require unbounded perturbation coefficients: shrink the independent parameter balls so that their CRT preimages remain in the allowed bounded polydisc. Their images are still nonempty \(K\)-analytic polydiscs, hence Zariski dense. They therefore suffice to avoid every proper algebraic bad-unit locus. No claim that the bounded polydisc surjects onto all numerical unit targets is needed.

The leaf constants \(\lambda_i\) do not occur in the outer limiting equations. Thus (5.4) gives independent leaf core units as well. This supplies the full color torus required by the generic-core theorem.

Here is a precise simultaneous avoidance argument, including every component and every nilpotent outer state. Write

\[
\phi_i=A_i+V_iB_i,\qquad \deg A_i<v_i,
\]

with \(\deg B_i<u_i\). If \(v_i=0\), this means \(V_i=1,A_i=0,B_i=\phi_i\); if \(u_i=0\), \(B_i\) is absent and no inner old target is needed.

Use the scalar \(c_i=\phi_i(0)\) instead of the coefficient \(B_i(0)\). Because \(V_i(0)\) is a unit, this is an invertible change of coordinates over the universal outer incidence scheme. Its defining outer equations depend on \(A_i\), but not on \(c_i\). Every dominating irreducible incidence component therefore has the same independent core-unit coordinates \(c_i\), together with the independent leaf constants \(\lambda_i\). Inverting the old and leaf core units gives a free color-target torus factor over that component. The pullback of a nonzero polynomial defining a principal good core-unit open is consequently nonzero on every such component; it cannot vanish identically on one of the outer solutions merely because that solution varies with the perturbation parameters.

After the harmless shrinkage of the perturbation base on which the outer coefficient family is finite flat, let \(F_{\rm core}\) be a product of the finitely many bad-locus equations, evaluated in that finite algebra. Multiplication by \(F_{\rm core}\) is generically invertible on every outer factor by the preceding free-parameter argument. Its determinant (the finite-flat norm) is therefore a nonzero function on the base. Invert this determinant. Then \(F_{\rm core}\) is a unit in the entire outer algebra, including its nilpotents, so every Artin outer factor maps into the good core-unit open. A finite intersection of these nonempty base opens handles all \(q\)'s simultaneously. This is stronger than selecting good individual closed points and justifies the pullback of the complete core finite-flat family.

For the algebraic genericity assertion before choosing a positive analytic factor, use this coordinate description on each dominant component of the universal incidence scheme. The outer equations uniquely determine \(A_i\) from \(V\) on the actual-arrow-open chart, so the incidence is a graph with the free \(B_i\) coefficients just displayed. Nondominant components have proper parameter images. On each dominant generically finite component the bad locus has strictly smaller dimension, hence also has proper parameter-image closure. Spreading the generic finite algebra to an open base and clearing the denominators in its multiplication determinant produces the same nonzero algebraic open conditions. The bounded analytic perturbation polydisc is Zariski dense and meets their common complement. Full independent reconstruction, including nilpotents and boundary cases, is in the companion GENERIC_RESIDUE_AND_FULL_LAYER_AUDIT.md, §5.

## 7. Construction and length of each factor

Replace each correction unit in §5 by \(1+s(u-1)\), for \(|s|\le1\). Its residue does not change, so the inner target stays in the same good core-unit open. The generic-core theorem supplies a uniform inner positive-factor window. The outer limiting finite Artin algebra supplies the same uniform nilpotent-power displacement bounds used in the independent \(q=0\) proof.

The strict-generator interior criterion makes this selected family finite over the \(s\)-disc. In the regular monic \(U,V,P\) chart there are exactly \(|m|+|r|\) remainder equations in that many coefficient variables. Finiteness gives the expected codimension, hence a local complete intersection and a Cohen–Macaulay source. Miracle flatness gives a finite-flat family over the regular disc.

At \(s=0\), it is the core finite-flat family of rank \(d_{g;r,q}\), pulled back over the finite outer algebra of length \(a_L(v)\). Its length is (1.2), including nilpotents. At \(s=1\), it is an actual isolated finite factor of the marked algebra, with the same length.

The finite-algebraic descent and Gröbner-weight argument in §7 of `SEPARATED_MARKED_Q_FACTOR.md` replaces \(\delta\) by \(T^A\) for a sufficiently large integer \(A\), simultaneously for all finitely many layers. It preserves all selected local Artin factors, their separation inequalities, and positive valuations. The big endpoint \((b,Aa)\) is chosen to satisfy its finite cut/rank genericity conditions as well.

Different \(q\)-factors are disjoint: they have different numbers \(u=r+q\) of old roots in the inner valuation layer. They retain full local Artin blocks, so their direct sum is an actual subfactor of the generic marked algebra.

## 8. Completeness from the independently known convolution

The positive divided-power expansion is

\[
R^{[r]}\theta_g
=\sum_{q\ge0}d_{g;r,q}\,y^q\theta_{h+Bq}.
\]

Taking its root coefficient of degree \(p\) gives the exact finite identity

\[
\binom{p+r}{r}a_g(p+r)
=\sum_{0\le q\le p}
d_{g;r,q}\,a_{h+Bq}(p-q).
\tag{8.1}
\]

All terms on the right are the lengths of the actual disjoint factors already constructed in §7. Their sum equals the ambient length (1.1). Therefore no other local Artin block remains. This verifies coverage; it is not used to invent the factors or to infer a factorization from equal dimensions alone.

This use of (8.1) avoids an unjustified claim that every possible nonframe old-only residue collision automatically vanishes for generic color targets. Such collisions require their own boundary analysis if one wants a wholly independent proof of the complete convolution from the marked model. The present full decomposition is rigorous with the stated dependency on the already established derivative identity.

## 9. What survives specialization

Choose any ordering of the finitely many \(q\)'s. In the generic deformed marked algebra take successive partial sums of its actual factor ideals. Intersect these nested ideals with the finite-free perturbation-DVR model. Each intersection is saturated, and successive quotients are torsion-free over the DVR. Specializing gives a filtration in the original generic-\(T\) algebra with successive dimensions (1.2).

Intersect that filtration with the original finite-free completed \(T\)-model and specialize its valuation DVR once more. This gives a filtration of the original marked special coefficient algebra after residue-field extension, with the same successive dimensions. Its construction is by Hensel-separated factors and saturated closure. The generic tensor-family interpretation need not remain a direct-product algebra decomposition at the origin.

The result is a finite positive geometric organization of all derivative branches. It does not yet bound the support of \(F_g\), prove a finite Laurent stopping theorem, or prove coordinatewise support accessibility.
