# Positive freezing and frozen-root shears: proof draft for adversarial review

2026-11-13. This is a general mechanism submitted for independent review. It is independent of support-accessibility computations. The initial root review accepted the high-lift mechanism and requested the explicit completed triangular inverse now supplied in Step 2. No support-accessibility conclusion is inferred.

## 1. Positive freezing by a high transverse lift

Let s^+ be a classical seed and let s^0 be obtained by freezing one mutable index k. Retain the same full lattices and all coefficient variables. Write D^+ and D^0 for their cluster scattering diagrams in the common ambient tropical vector space. In principal coefficients, or with enough extra principal variables to distinguish root degrees, work first modulo the ideal of total mutable-root degree > K.

The walls whose normals n have n_k=0 are precisely the old scattering diagram D^0, up to equivalence. This follows directly from the nonnegative root grading: the quotient killing all degrees with n_k>0 is a Lie algebra quotient, and consistency/uniqueness identify its diagram with the scattering diagram for s^0. Old walls are cylinders in the direction f_k dual to e_k. Indeed their initial walls are cylinders, and scattering only old root degrees preserves this property; equivalently their normal n has n_k=0 and their joint construction is invariant under that translation.

For every finite path gamma in the old tropical space, choose A>0 so large that its translate gamma+A f_k does not meet any wall of D^+_K whose normal has n_k>0. Such an A exists: every such wall lies in n^perp, and along the lifted compact path

    <n, gamma(t)+A f_k> = <n,gamma(t)> + A n_k > 0

once A is large enough. There are finitely many walls modulo the chosen root-degree truncation. The lifted path therefore has the same path-ordered product as gamma in D^0_K.

If gamma starts at a point in the positive initial chamber of s^0, choose its initial k-coordinate positive. The vertical segment to height A stays in the full positive initial chamber of s^+, since all mutable coordinates are positive. Thus no extra initial transport is introduced.

Consequently, if f is a theta function for s^+ (or any element positive in every D^+ scattering chart), its initial Laurent expression is positive in every old D^0 scattering chart: for each coefficient, choose K large enough to determine that coefficient, then use the above finite-height lift. No uniform height as K tends to infinity is asserted or required.

## 2. Extracting the old theta coefficients

Mandel, *Theta bases are atomic*, arXiv:1605.03202v2, Theorem 1 and its proof, treats the topological theta algebra. The proof explicitly says that for a formal expansion

    f = sum_m c_m theta_m,

the coefficient c_p is the monomial coefficient of z^p in the chart at Q sufficiently close to p, by GHKK Proposition 6.4. Thus positivity in every old scattering chart forces every c_p to be nonnegative. Since old walls are cylinders in f_k, a chart close to p is the same chart as one translated to large positive k-height, even if p_k is negative.

Here is the required completed triangular inverse explicitly. Keep principal root markers, so the old map p*:N_old -> M is injective. Let S be the finite initial Laurent support of f. Divide S into its finitely many cosets modulo p*(N_old). In a coset choose a representative b. Write its support exponents as b+p*(r), with r ranging through a finite subset of Z^n, and subtract the coordinatewise minimum r_min. Then this sector of f has the form

    x^h P(z_1,...,z_n),   h=b+p*(r_min),

with P an ordinary finite polynomial in the old root monomials. For every q in N^n the old theta at h+p*(q) has expansion

    theta_{h+p*(q)} = x^h z^q (1 + sum_{r>0} a_{h+p*(q)}(r) z^r).

This is a unitriangular matrix, ordered by total root degree. The explicit inverse recursion is

    c(q) = [z^q] P - sum_{r<q} c(r) a_{h+p*(r)}(q-r),

where r<q means r<=q coordinatewise and r!=q. Every sum is finite. Thus there is a unique integral theta expansion in the old root-adic completion, with labels in the finite union of translates h+p*(N^n). Path-ordered products for old walls preserve this completion: all their corrections increase old root degree. Consequently the expansion gives the same formal section in every old scattering chart. This is exactly the topological setting of Mandel's coefficient-extraction argument; no finite-span assertion about the upper algebra is used.

For a **finite initial Laurent polynomial**, once c_m>=0 is established, every nonzero c_m contributes its distinct positive leading monomial x^m to the initial expression. It follows that m belongs to S, hence only finitely many c_m occur. Each occurring theta itself has finite initial support, since every one of its positive monomials occurs in f and cannot cancel. Thus finiteness is a consequence of positivity after the completed inverse, rather than an assumption that mid=up.

Coefficientwise comparison with the big diagram is legitimate because its full p* is also injective after retaining markers. For any target monomial and any one of the finitely many initial monomials of f, at most one nonnegative big-root degree can reach that target. A finite big-root cutoff therefore determines the coefficient. This gives the cutoff K used in Step 1 without requiring a single lift height to work at every order.

**Freezing conclusion for review:** every finite theta function for the larger seed has a finite nonnegative integral expansion in the finite theta functions for the frozen seed. More generally the statement holds coefficientwise for elements in the common completed theta algebra. Mutation covariance supplies the regular interpretation on the seed charts; throughout the proof “finite” is first the concrete initial Laurent support condition, not an unstated upper=middle hypothesis.

This is not Qin's freezing operator, which drops all terms using the frozen root degree. It concerns the entire unchanged Laurent expression and its branching into the smaller theta basis. The high-lift argument is the proposed proof of that stronger inclusion positivity. Relevant comparison: Qin, *Applications of the freezing operators on cluster algebras*, arXiv:2407.03186, not yet fully audited in this branch.

## 3. A leaf extension realizing a coefficient shear

Fix a principal coefficient y_i. Introduce one new mutable leaf a, replacing y_i as the coefficient at the old mutable vertex i. Add two new frozen variables u,v, coupled only to a. Choose the extended exchange matrix so that

    B_{a,i}=1,  B_{i,a}=-1,
    B_{u,a}=1,  B_{v,a}=-1,

and all other entries involving a,u,v and the old mutable vertices vanish, except the displayed ones. The old mutable block B is unchanged and the other principal coefficient rows remain unchanged. The exchange at a is

    a a' = u + v x_i.

Before mutation, freezing a gives the original old algebra with y_i=a, plus independent coefficient variables u,v. After mutation at a and freezing a', the old block is still B, while direct matrix mutation gives

    B'_{u,i}=1,  B'_{v,i}=0,  B'_{a',i}=-1.

Thus after specializing a'=1, u is the original coefficient y_i and v is independent of the old mutable vertices.

The source theta with old label g and a-label zero has no bends using the new root a. One direct proof uses the positive-endpoint one-color necessary bound already established in the parent work:

    p_a <= [-g_a]_+ + sum_j [-B_{a,j}]_+ p_j = 0.

Alternatively, this is the elementary source-leaf special case of the usual freezing/unfreezing comparison. Therefore it is exactly theta_g(x,y_i=a) as an extended theta function. This argument must be stated with the orientation convention used above; reversing all conventions reverses which leaf is a source.

Mutation invariance, followed by the candidate positive freezing result and the coefficient specialization a'=1, gives a positive old-theta expansion of

    theta_g(x, y_i=u+v x_i).

When theta_g is finite, this is a polynomial in v. The coefficient of v^r is

    (1/r!) (x_i partial_{y_i})^r theta_g.

Since old theta functions after a'=1 are independent of v, their expansion coefficients at each power v^r are nonnegative integers. In particular every divided power of the frozen-root derivation R_i=x_i partial_{y_i} is theta-positive.

There is also a direct scattering-positivity formulation avoiding any premature coefficient specialization. In the mutated seed, v has zero exchange entries in all old mutable columns, so taking [v^r] commutes with every old path-ordered product. The variable a' is frozen in the small seed, so setting a'=1 also commutes with old transports. Apply both operations to the positive old-chart expression furnished by Step 1. This makes the divided derivative positive in every old scattering chart, after which Step 2 applies directly to that finite Laurent polynomial.

For a skew-symmetrizable old B, choose D_a=D_i and keep B_{a,i}=1, B_{i,a}=-1. This is compatible with the enlarged diagonal symmetrizer. The mutable leaf calculation and the shear exchange relation are unchanged. The argument therefore extends from the classical skew-symmetric case to the classical skew-symmetrizable case, using classical scattering positivity and covariance in that generality.

The operators R_i commute because all x_i are independent of all coefficient variables y_j. Hence all mixed divided powers product_i R_i^{p_i}/p_i! preserve the finite theta-positive cone as well. This follows by composition of the one-color results, not by a new theta=representation identification.

## 4. Why this is relevant but not yet accessibility

The conclusion is stronger than ordinary Laurent positivity of a derivative and applies to arbitrary old B in the skew-symmetric case, subject to the completed-freezing argument above. It does not assume a representation-theoretic theta=generic-character identification or a biperfectness theorem.

It does **not by itself** prove that a_g(p)>0 implies some a_g(p-e_i)>0. Differentiation changes the leading mutable label:

    R_i theta_g = x^{g+e_i+B e_i} partial_{z_i} F_g.

Its positive theta constituents can start at positive root degree, and their labels need not dominate g coordinatewise. A further relation tying these positive constituents back to F_g is needed. No finite-stop theorem is claimed here.

## 5. Exact mechanism probes

`derivation_probe.py` computes the unique triangular expansion

    R_i theta_g = sum_{q>=0} c_q y^q theta_{g+e_i+B e_i+Bq}

from the independently implemented incoming coefficient oracle. The larger probe tested 1,550 derivations for random skew-symmetric ranks 2–4, mixed g-signs and cyclic B, with 2,353 nonzero expansion coefficients, and found no negative coefficient. These tests motivated the leaf-extension argument; they are not a logical premise.

One cyclic example is the three-vertex Markov matrix with B_12=B_23=B_31=2, g=(-1,-1,-1). For i=1, the tested coefficient box q<= (2,2,2) gives coefficients 1,3,5,6 at q=(0,0,0),(0,0,1),(0,1,2),(1,2,2), respectively. Thus the expected positive action is not a single generic crystal arrow.
