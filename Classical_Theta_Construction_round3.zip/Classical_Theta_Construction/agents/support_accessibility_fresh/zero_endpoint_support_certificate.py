"""Exact finite-word support certificates from zero-endpoint Q mutation.

The theorem is ZERO_ENDPOINT_Q_MUTATION_AND_SUPPORT_CERTIFICATES.md.
All polyhedral arithmetic uses exact rational LPs. Every retained bound
is checked by its nonnegative dual multipliers; every discarded branch
is checked by a Farkas certificate. An unbounded result concerns only
the supplied finite word set, never infinitude of a theta function.
"""
from itertools import combinations
from pathlib import Path
import argparse
import json
from math import gcd
import sympy as sp
from sympy.solvers.simplex import linprog, InfeasibleLPError, UnboundedLPError

try:
    from .universal_unit_coefficient import symmetrizer, check_vectors
except ImportError:
    from universal_unit_coefficient import symmetrizer, check_vectors


def add(a, b):
    return tuple(x+y for x, y in zip(a, b))


def scale(k, a):
    return tuple(k*x for x in a)


def subtract(a, b):
    return add(a, scale(-1, b))


def const(n, value):
    return (value,) + (0,)*n


def mutate(C, G, k):
    size = len(C)
    new_C = tuple(tuple(
        -C[i][j] if i == k or j == k else
        C[i][j] + max(C[i][k], 0)*max(C[k][j], 0)
        - max(-C[i][k], 0)*max(-C[k][j], 0)
        for j in range(size)) for i in range(size))
    new_G = tuple(
        -G[k] if i == k else
        G[i] + max(C[i][k], 0)*G[k] + C[i][k]*max(-G[k], 0)
        for i in range(size))
    return new_C, new_G


def normalize(rows):
    out = set()
    for a, b in rows:
        common = gcd(*(abs(int(v)) for v in tuple(a)+(b,)))
        if common:
            a, b = tuple(int(v)//common for v in a), int(b)//common
        if any(a) or b < 0:
            out.add((tuple(a), b))
    return tuple(sorted(out))


def le_zero(f):
    return (f[1:], -f[0])


def ge_zero(f):
    return (tuple(-v for v in f[1:]), f[0])


def enumerate_lp(c, rows):
    """Exact finite fallback if the simplex backend returns an invalid witness."""
    n = len(c)
    all_rows = list(rows) + [
        (tuple(-int(i == j) for i in range(n)), 0) for j in range(n)
    ]
    best = None
    for indices in combinations(range(len(all_rows)), n):
        matrix = sp.Matrix([all_rows[i][0] for i in indices])
        if matrix.det() == 0:
            continue
        point = list(matrix.inv()*sp.Matrix([all_rows[i][1] for i in indices]))
        if any(sum(a[j]*point[j] for j in range(n)) > rhs
               for a, rhs in all_rows):
            continue
        value = sum(c[j]*point[j] for j in range(n))
        if not any(c):
            return value, point
        if best is None or value < best[0]:
            best = value, point
    if best is None:
        raise InfeasibleLPError("exact vertex enumeration finds no feasible vertex")
    # The nonnegative orthant makes every feasible polyhedron pointed.
    # A descending recession direction has a vertex after normalization sum(v)=1.
    for indices in combinations(range(len(all_rows)), max(n-1, 0)):
        matrix = sp.Matrix([[1]*n] + [all_rows[i][0] for i in indices])
        if matrix.det() == 0:
            continue
        ray = list(matrix.inv()*sp.Matrix([1]+[0]*(n-1)))
        if any(sum(a[j]*ray[j] for j in range(n)) > 0
               for a, rhs in all_rows):
            continue
        if sum(c[j]*ray[j] for j in range(n)) < 0:
            raise UnboundedLPError("exact normalized recession ray")
    return best


def lp(c, rows):
    n = len(c)
    if not rows:
        if any(v < 0 for v in c):
            raise UnboundedLPError("negative objective on nonnegative orthant")
        return sp.Integer(0), [sp.Integer(0)]*n
    A = [list(a) for a, b in rows]
    b = [b for a, b in rows]
    value, point = linprog(list(c), A, b)
    if (any(v < 0 for v in point)
        or any(sum(x*y for x, y in zip(a, point)) > rhs for a, rhs in rows)
        or value != sum(x*y for x, y in zip(c, point))):
        value, point = enumerate_lp(c, rows)
    return value, point


def feasibility(rows, n):
    try:
        _, point = lp([0]*n, rows)
        return point, None
    except InfeasibleLPError:
        m = len(rows)
        # u>=0, A^t u>=0, b.u<=-1 is a Farkas certificate.
        dual_rows = [
            (tuple(-rows[j][0][i] for j in range(m)), 0)
            for i in range(n)
        ] + [(tuple(rhs for a, rhs in rows), -1)]
        _, u = lp([0]*m, dual_rows)
        lhs = [sum(u[j]*rows[j][0][i] for j in range(m)) for i in range(n)]
        rhs = sum(u[j]*rows[j][1] for j in range(m))
        if any(v < 0 for v in u) or any(v < 0 for v in lhs) or rhs >= 0:
            raise ArithmeticError("Invalid Farkas certificate")
        return None, {"multipliers": u, "combined_left": lhs,
                      "combined_right": rhs}


def coordinate_bound(rows, n, index):
    m = len(rows)
    if not rows:
        ray = [sp.Integer(int(i == index)) for i in range(n)]
        return None, {"ray": ray}
    dual_rows = [
        (tuple(-rows[j][0][i] for j in range(m)), -int(i == index))
        for i in range(n)
    ]
    try:
        value, u = lp([rhs for a, rhs in rows], dual_rows)
    except InfeasibleLPError:
        ray_rows = [(a, 0) for a, rhs in rows]
        ray_rows.append((tuple(-int(i == index) for i in range(n)), -1))
        _, ray = lp([0]*n, ray_rows)
        return None, {"ray": ray}
    combined = [sum(u[j]*rows[j][0][i] for j in range(m)) for i in range(n)]
    if any(combined[i] < int(i == index) for i in range(n)):
        raise ArithmeticError("Invalid coordinate-bound dual certificate")
    return value, {"multipliers": u, "combined_left": combined,
                   "combined_right": value}


def support_certificate(B, g, words, r=None):
    """r=None certifies full F_g support; fixed r certifies d_(g;r,q)."""
    D = symmetrizer(B)
    n = len(B)
    check_vectors(n, g, *((r,) if r is not None else ()))
    if any(any(not isinstance(k, int) or not 0 <= k < n for k in word)
           for word in words):
        raise ValueError("words use zero-based original mutable indices")
    C = tuple(tuple(
        B[i][j] if i < n and j < n else
        int(i == j-n) if i < n <= j else
        -int(i-n == j) if j < n <= i else 0
        for j in range(2*n)) for i in range(2*n))
    G = tuple(g)+(0,)*n
    variables = [tuple([0]+[int(i == j) for i in range(n)]) for j in range(n)]
    if r is None:
        P = tuple(variables+variables)
    else:
        P = tuple(add(variables[i], const(n, r[i])) for i in range(n))
        P += tuple(const(n, r[i]) for i in range(n))

    prefixes = {()}
    for word in words:
        prefixes.update(tuple(word[:j]) for j in range(1, len(word)+1))
    ordered = sorted(prefixes-{()}, key=lambda w: (len(w), w))
    seeds = {(): (C, G)}
    branches = [{"rows": (), "degrees": {(): P},
                 "point": [sp.Integer(0)]*n}]
    discarded = []
    for word in ordered:
        parent, k = word[:-1], word[-1]
        C, G = seeds[parent]
        seeds[word] = mutate(C, G, k)
        next_branches = []
        for branch in branches:
            old_P = branch["degrees"][parent]
            alpha, beta = const(n, max(G[k], 0)), const(n, max(-G[k], 0))
            for j in range(2*n):
                alpha = add(alpha, scale(max(C[k][j], 0), old_P[j]))
                beta = add(beta, scale(max(-C[k][j], 0), old_P[j]))
            choices = [(alpha, beta)] if alpha == beta else [(alpha, beta), (beta, alpha)]
            for chosen, other in choices:
                degree = subtract(chosen, old_P[k])
                rows = normalize(list(branch["rows"]) +
                                 [le_zero(subtract(chosen, other)), ge_zero(degree)])
                point, contradiction = feasibility(rows, n)
                if contradiction is not None:
                    discarded.append({"word": word, "rows": rows,
                                      "farkas": contradiction})
                    continue
                new_P = list(old_P)
                new_P[k] = degree
                degrees = dict(branch["degrees"])
                degrees[word] = tuple(new_P)
                next_branches.append({"rows": rows, "degrees": degrees,
                                      "point": point})
        branches = next_branches
        if not branches:
            break

    result = {"kind": "theta" if r is None else "derivative",
              "B": B, "g": g, "r": r, "symmetrizer": D,
              "words": ordered, "discarded_branches": discarded,
              "feasible_branch_count": len(branches)}
    upper = [sp.Integer(0)]*n
    bounded = []
    for branch in branches:
        bounds, duals = [], []
        for i in range(n):
            bound, certificate = coordinate_bound(branch["rows"], n, i)
            if bound is None:
                result.update({"status": "not_certified_by_supplied_words",
                               "unbounded_branch": {"rows": branch["rows"],
                                                    "point": branch["point"],
                                                    "coordinate": i,
                                                    **certificate}})
                return result
            bounds.append(bound)
            duals.append(certificate)
            upper[i] = max(upper[i], bound)
        bounded.append({"rows": branch["rows"], "bounds": bounds,
                        "dual_certificates": duals})
    result.update({"status": "bounded_support_certificate",
                   "rational_upper_bounds": upper,
                   "integer_box": [int(sp.floor(v)) for v in upper],
                   "branches": bounded})
    return result


def json_default(value):
    if isinstance(value, sp.Integer):
        return int(value)
    if isinstance(value, sp.Rational):
        return str(value)
    raise TypeError(type(value).__name__)


def complete_laurent_from_certificate(B, g, words):
    certificate = support_certificate(B, g, words)
    if certificate["status"] != "bounded_support_certificate":
        return {"status": "not_certified_by_supplied_words",
                "support_certificate": certificate}
    try:
        from computation.incoming_recursion import IncomingSchur
    except ModuleNotFoundError:
        import importlib.util
        source = Path(__file__).resolve().parents[2]/"computation"/"incoming_recursion.py"
        spec = importlib.util.spec_from_file_location("incoming_theta_coefficients", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        IncomingSchur = module.IncomingSchur
    oracle = IncomingSchur(B, certificate["symmetrizer"])
    coefficients = oracle.theta_prefix(tuple(g), tuple(certificate["integer_box"]))
    terms = []
    for p, coefficient in sorted(coefficients.items(), key=lambda item: (sum(item[0]), item[0])):
        if not coefficient:
            continue
        inside = any(all(sum(a[j]*p[j] for j in range(len(g))) <= rhs
                         for a, rhs in branch["rows"])
                     for branch in certificate["branches"])
        if not inside:
            raise ArithmeticError("A coefficient contradicts the supplied support certificate")
        terms.append({"coefficient": coefficient, "y_exponent": p,
                      "x_exponent": [g[i]+sum(B[i][j]*p[j] for j in range(len(g)))
                                     for i in range(len(g))]})
    return {"status": "complete_laurent_polynomial",
            "coefficient_backend": "audited incoming-normalized finite coefficient recursion",
            "support_certificate": certificate, "terms": terms}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path,
                        help="JSON with B,g,words and optional r")
    parser.add_argument("--complete", action="store_true",
                        help="after a successful full-theta support certificate, output every Laurent term")
    args = parser.parse_args()
    if args.input:
        data = json.loads(args.input.read_text())
    else:
        data = {"B": [[0, 1], [-1, 0]], "g": [-2, -2],
                "words": [[0], [1], [0, 1], [1, 0]]}
    if args.complete:
        if data.get("r") is not None:
            raise ValueError("--complete is for full theta support, so omit r")
        result = complete_laurent_from_certificate(data["B"], data["g"], data["words"])
    else:
        result = support_certificate(**data)
    print(json.dumps(result, default=json_default, indent=2))
