from root_merge_probe import *
from math import prod
from time import time

def partitions(n,m=None):
 if n==0:yield ();return
 for k in range(min(n,m or n),0,-1):
  for tail in partitions(n-k,k):yield (k,)+tail

def cycle_blocks(part,start=0):
 out=[]
 for k in part:out.append(frozenset(range(start,start+k)));start+=k
 return out

def tight_fixed(obs,a,rs,ss):
 cyc=cycle_blocks(rs)+cycle_blocks(ss,a)
 n=0
 for z in obs:
  bl=[set(x) for x in z[3].values()]
  if all(all(not c.intersection(x) or c.issubset(x) for c in cyc) for x in bl):n+=1
 return n

def toric_trace(rs,ss):
 a=sum(rs);b=sum(ss);p=len(rs);q=len(ss)
 es=[(p+j,i,0) for i in range(p) for j in range(q)]
 theta=tuple(-b*r for r in rs)+tuple(a*s for s in ss)
 total=0;num=0
 for T in all_trees(p+q,es):
  if not stable(p+q,es,T,theta):continue
  deg=[0]*(p+q)
  for k in T:
   u,v,_=es[k];deg[u]+=1;deg[v]+=1
  wt=prod(c**(d-1) for c,d in zip(rs+ss,deg))
  total+=wt;num+=1
 return total,num

def main():
 report=[]
 for a,b in [(1,1),(2,3),(3,2),(2,5),(5,2),(3,4),(4,3),(3,5),(5,3),(4,5),(5,4)]:
  t=time();obs=list(objects(a,b));rows=[]
  for rs,ss in product(partitions(a),partitions(b)):
   tf=tight_fixed(obs,a,rs,ss);tt,nt=toric_trace(rs,ss)
   rows.append({'E_cycles':rs,'N_cycles':ss,'tight_fixed':tf,'toric_trace':tt,'quotient_stable_trees':nt,'pass':tf==tt})
  row={'a':a,'b':b,'tight_objects':len(obs),'classes':len(rows),'all_pass':all(r['pass'] for r in rows),'seconds':time()-t,'characters':rows}
  report.append(row);print(json.dumps({k:v for k,v in row.items() if k!='characters'}),flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))

if __name__=='__main__':main()
