"""Fast independent exact tests with long permutation cycles and valued rows."""
from pathlib import Path
import json, multiprocessing as mp, time
from primitive_fixedcycle_ideals import ideal_worker, independent_cycle_value

HERE=Path(__file__).resolve().parent
def run():
    inputs=[]
    for B,D in [([[0,3],[-2,0]],[2,3]),([[0,3],[-2,0]],[4,6]),
                ([[0,5],[-3,0]],[6,10]),([[0,2],[-2,0]],[2,2]),
                ([[0,2],[-1,0]],[3,6])]:
        for g,lam in [((-2,1),((2,),(1,))),((-2,1),((2,),(2,))),
                      ((-3,1),((3,),(1,))),((-2,0),((2,),(1,)))]:
            inputs.append((B,D,g,lam,[1,1]))
    results=[];start=time.time()
    for payload in inputs:
        B,D,g,lam,a=payload
        q=mp.Queue();proc=mp.Process(target=ideal_worker,args=(payload,q));proc.start();proc.join(18)
        if proc.is_alive():proc.terminate();proc.join();out={'timeout_seconds':18}
        else:out=q.get(timeout=2)
        value,Bc,Dc=independent_cycle_value(B,D,g,lam)
        out.update({'B':B,'D':D,'g':g,'cycles':lam,'cycle_B':Bc,'cycle_D':Dc,
                    'incoming_cycle_value':value})
        if 'length' in out:out['match']=out['length']==value
        results.append(out)
        (HERE/'primitive_two_packet_checks.json').write_text(json.dumps({'results':results,'seconds':time.time()-start},indent=2))
        print(json.dumps({k:out[k] for k in ['D','g','cycles','length','incoming_cycle_value','match','timeout_seconds','seconds'] if k in out}),flush=True)
    return results
if __name__=='__main__':run()
