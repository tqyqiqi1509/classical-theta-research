# Fixed-cycle lengths of isolated equivariant square-map factors

Date: 2026-11-13, 20:40 UTC. Classical, characteristic-zero algebra only.

## 1. Purpose and status

This note supplies the precise bridge needed for the general framed Gale
construction: the trace of a permutation on a finite algebra is the length of
the **coordinate-fixed scheme**, provided the algebra is a full isolated
factor of a square map carrying the same coordinate action in source and
target. It is not a new existence theorem for Young permutation modules. The
coordinatewise deformation is already in the user's previous work
`history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/local_permutation_upgrade.md`,
Section 3, and in Tang, Hexagon 2611.00238v1, Lemma 6.1.

The extra point made explicit here is flatness of the **fixed-locus** family.
Flatness of the original family alone would not justify preservation of
fixed-scheme length. Here the restricted system is square again, so the
required flatness has a separate complete-intersection proof.

## 2. Statement

Let \(K\) be algebraically closed of characteristic zero, put

\[
 V=\bigoplus_{c=1}^tK^{n_c},\qquad
 G=\prod_{c=1}^tS_{n_c},\qquad N=\sum_cn_c,
\]

and let \(F:V\to V\) be a polynomial map equivariant for the same coordinate
permutation action on both copies of \(V\). Let \(Z\) be a \(G\)-stable
finite union of **isolated full local factors** of \(F^{-1}(0)\), with their
entire Artin structures. Write \(A=\mathcal O(Z)\).

For \(\sigma\in G\), let \(V^\sigma\) be the coordinate subspace defined
by \(x_i=x_{\sigma(i)}\). Define

\[
 Z_\sigma=Z\times_VV^\sigma,
 \qquad
 A_\sigma=A/(x_i-x_{\sigma(i)}:\ i\in V).
\]

This quotient is the coordinate ring of the fixed subscheme. It is **not** the
invariant subalgebra \(A^{\langle\sigma\rangle}\).

**Fixed-cycle lemma.** Under these assumptions,

\[
 \boxed{\operatorname{Tr}(\sigma\mid A)=\dim_K A_\sigma.} \tag{2.1}
\]

More precisely, there are polynomials \(p_c(z)\) of degree at most \(n_c-1\)
such that the same deformation

\[
 F_{c,i}(x)+s\,p_c(x_{c,i})=0 \tag{2.2}
\]

has a finite free selected factor \(\mathscr A\) over \(K[[s]]\) specializing
to \(A\), has geometrically reduced generic fiber, and, simultaneously for
every \(\sigma\in G\),

\[
 \mathscr A_\sigma
 =\mathscr A/(x_i-x_{\sigma(i)})
\]

is finite free and specializes to \(A_\sigma\). Its generic rank equals the
number of \(\sigma\)-fixed tuples in the selected reduced generic fiber.

The same statement holds for a regular square map on a \(G\)-invariant open
subset of \(V\), after clearing denominators by a common invariant unit and
retaining the specified isolated factors.

## 3. Proof of a reduced equivariant deformation

Use independent coefficients for one polynomial of degree at most \(n_c-1\)
for each color. Stratify \(V\) by the equality partitions of coordinates
within each color. A stratum has \(d_c\) distinct values in color \(c\), and
let \(r_c\) of its blocks have size at least two. Then
\(d_c+r_c\le n_c\).

On that stratum all coordinate equations in one equality block agree by
equivariance. Keep one equation per block. Evaluation of the perturbing
polynomial at the \(d_c\) distinct values is surjective. The incidence
variety of block equations and parameters is therefore smooth of the same
dimension as the parameter space. Each dominating component is generically
finite and, in characteristic zero, generically étale. Nondominating
components and the non-étale loci have images contained in proper closed
subsets of parameter space. Hence the Jacobian on block-constant directions
is invertible outside a proper exceptional parameter locus.

At a point of this stratum the stabilizer is the product of the symmetric
groups on its equality blocks. The full Jacobian preserves the block-constant
space and acts by a scalar on the sum-zero standard representation of each
repeated block. These standard representations belong to distinct stabilizer
factors, so they do not mix. Hermite interpolation independently prescribes
the polynomial values at all blocks and its first derivatives at all repeated
blocks, since \(d_c+r_c\le n_c\). Varying such a derivative changes the
corresponding normal scalar without changing the block equations. The locus
where that scalar vanishes is therefore a proper divisor in the incidence
variety, with image closure of smaller dimension than parameter space.

There are finitely many equality strata. Removing all their bad image
closures gives a nonempty open set of parameters where every zero has
invertible full Jacobian. The full affine zero scheme is then reduced and
zero-dimensional, hence finite. Choose a parameter vector whose line from the
origin meets this open set. This gives (2.2), reduced over \(K((s))\).

This argument is reproduced to identify the exact input. No Laurent
positivity or cluster-theoretic conclusion from Tang's 2026 paper is used.

## 4. Finite flat selection of the original factors

Because \(Z\) is a union of isolated full factors, it has an idempotent in
\(K[x]/(F)\). Average a polynomial lift over \(G\) and call the result \(g\).
Localization at \(g\) has special fiber exactly \(A\). Complete

\[
 K[[s]][x,g^{-1}]/(F+sP)
\]

in the \(s\)-adic topology. Its completion \(\mathscr A\) is finite over
\(K[[s]]\): lift a basis of the finite special fiber, reduce successively
modulo \(s,s^2,\ldots\), and collect the coefficients as power series.

At each support point \(z\in Z\), the \(N+1\) elements
\((F_1+sP_1,\ldots,F_N+sP_N,s)\) are a parameter system in the regular
local ring \(K[[s,x-z]]\). Thus they form a regular sequence. In particular
\(s\) is a nonzerodivisor after quotienting by the \(N\) equations.
The completed selected algebra is the product of these local completions,
so it is finite torsion-free, hence finite free, over \(K[[s]]\).

The chosen lifted basis also shows that the map from the localized algebra
to its completion is surjective. After inverting \(s\), the completion is a
quotient of a finite reduced algebra, hence a reduced direct factor. Thus its
geometric generic fiber is an actual finite set \(\mathcal S\) of tuples.
The construction is \(G\)-invariant throughout.

## 5. Separate flatness of every fixed-cycle restriction

Fix \(\sigma\in G\) and let \(m\) be its number of coordinate cycles.
Write one variable \(X_C\) for each cycle. Equivariance gives

\[
 F_i\big|_{V^\sigma}=F_j\big|_{V^\sigma}
 \quad\text{whenever }i,j\text{ lie in the same cycle}.
\]

The same holds for the perturbations, since the polynomial is common within
each color. Consequently the restricted system has exactly **one equation
per cycle in one variable per cycle**. Extra copies of the equations add no
relations. Its selected special fiber is \(Z_\sigma\), which is finite as
a closed subscheme of \(Z\).

Only support points fixed by \(\sigma\) contribute. A component at a point
moved by \(\sigma\) has a nonzero coordinate difference and contributes
zero after quotienting by the fixed-coordinate equations. At a fixed
support point \(z\), the \(m\) restricted equations together with \(s\)
form a parameter system in the regular ring
\(K[[s,X_C-z_C]]\). The same regular-sequence argument proves that their
local quotient is finite free over \(K[[s]]\). The restricted isolating
polynomial \(g|_{V^\sigma}\) selects exactly these local factors.

Completion commutes with this finite coordinate quotient, so the resulting
algebra is precisely \(\mathscr A_\sigma\). Its generic fiber is the fixed
subscheme of a finite reduced scheme, hence consists of exactly
\(\mathcal S^\sigma\) with multiplicity one. Therefore

\[
 \dim_KA_\sigma=|\mathcal S^\sigma|. \tag{5.1}
\]

Since \(G\) acts over the DVR and characteristic is zero, each isotypic
multiplicity module of \(\mathscr A\) is a direct summand of a finite free
module. Its special and generic ranks agree. Thus

\[
 \operatorname{Tr}(\sigma\mid A)
 =\operatorname{Tr}(\sigma\mid K[\mathcal S])
 =|\mathcal S^\sigma|,
\]

which proves (2.1). The same polynomial deformation works for all
\(\sigma\), since reducedness of the full generic zero scheme was already
proved and there are only finitely many elements of \(G\).

## 6. Consequence for sign alternation

Every tuple stabilizer in \(\mathcal S\) is a product of symmetric groups
on the equal-coordinate blocks within each color. For a Young subgroup
\(H\), Frobenius reciprocity gives

\[
 \dim\operatorname{Hom}_G(\mathrm{sgn}_G,K[G/H])
 =\dim\operatorname{Hom}_H(\mathrm{sgn}_G|_H,\mathbf1).
\]

This is one precisely when every equality block has size one, and zero
otherwise: every nontrivial symmetric-group factor contains a transposition.
Hence

\[
 \frac1{|G|}\sum_{\sigma\in G}\mathrm{sgn}(\sigma)\dim_K A_\sigma
 =\#\{\text{free }G\text{-orbits in }\mathcal S\}. \tag{6.1}
\]

This is an actual positive finite-set explanation of the alternating cycle
sum once a graph-defined square-map factor with the required fixed-cycle
lengths has been established. It does not by itself identify those lengths
with any theta coefficient.

## 7. Correct fixed-cycle Gale equations

Consider a graph obtained by cloning each mutable color \(i\), with no
within-color arrows, a fixed frame vertex, and \(m_{ij}\) parallel arrows
between a clone of \(i\) and a clone of \(j\), in the specified direction.
Let \(\sigma\) have a cycle packet \(A\) of length \(r_A\), and put
\(x_v=X_A\) for \(v\in A\). A single original Gale row at a vertex of
packet \(A\) restricts to a row whose exponent on
\(X_B-X_A\) is \(\pm m_{i(A),i(B)}r_B\). This is the actual fixed-coordinate
equation. It is not its \(r_A\)-th power.

Equivalently, define the ordinary packet graph with arrow multiplicity

\[
 M_{AB}=m_{i(A),i(B)}r_Ar_B.
\]

The fixed-coordinate row is the packet row with every exponent divided by
\(r_A\). If an original valued row already has exponent
\(m_{ij}/D_i\), with integral divisibility assumed, then the fixed row has
exponent

\[
 \frac{m_{ij}r_B}{D_i}
 =\frac{M_{AB}}{r_AD_i}.
\]

Thus the primitive packet content is \(d_A=r_AD_i\), exactly the content
appearing in the phase quotient. Row targets and valuations remain those of
one original vertex; raising the row to its content gives the ordinary
packet target. Replacing the primitive row by that raised equation includes
additional root-of-unity branches and generally changes the length. The
phase-kernel normalization is essential if one counts ordinary packet
equations first.

This identity of restricted equations is algebraic and holds for all cycle
types, all arrow multiplicities, and cyclic as well as acyclic graphs. The
separate remaining theorem is existence and tropical enumeration of the
selected positive-valuation finite factor, being developed in
`agents/phase_descent_round1/`.

## 8. Primary-source audit and overlap record

* **Tang, Hexagon 2611.00238v1, Lemma 6.1, pp. 16–17.**
  <https://hexagonmath.org/pdf/2611.00238v1>.
  Read the full lemma and proof directly on 2026-11-13. The equality-stratum
  incidence dimension, Hermite degree bound, normal Jacobian scalars, isolated
  factor completion, and finite-free character comparison were independently
  checked. No flaw was found in this lemma. The paper's other statements,
  including generalized Laurent positivity, were not used or thereby
  certified. The fixed-cycle flatness argument in Section 5 above is an
  explicit corollary/refinement of this proof, not a new permutation-existence
  claim.
* **Stacks Project, Tag 00R4, miracle flatness.**
  <https://stacks.math.columbia.edu/tag/00R4>.
  Primary statement and proof read. It supplies the standard local flatness
  principle; the special DVR case needed here is proved directly by a regular
  sequence above.
* **Previous local own-work files.** The square-map deformation was already
  present in `agents/local_permutation_upgrade.md`, Section 3, and
  `agents/valued_gale_attached_theorem.md`, Section 7, inside the prior
  `Higher_Rank_Greedy_Theta` package. The old
  `proofs/PRIMITIVE_CENTER_GALE_FINITE_MODEL.md`, Section 6, also used the
  trace/fixed-length conclusion, but did not spell out the separate
  fixed-restriction regular-sequence argument. This note makes that interface
  explicit and records exactly which general hypotheses justify it.

Route record: the toric cohomology representation and cyclic flagged-tree
count cannot be identified merely from equal dimensions; their natural
Young actions differ. The square-map fixed-cycle lemma gives a direct
route to the relevant primitive cycle traces without asserting an equivariant
lift of the flagged-tree sweep. This avoids that unresolved representation
lift, provided the independent positive-valuation Gale theorem succeeds.
