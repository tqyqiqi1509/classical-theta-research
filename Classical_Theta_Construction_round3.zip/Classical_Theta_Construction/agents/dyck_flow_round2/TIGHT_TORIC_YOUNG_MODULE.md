# Tight gradings as a Young permutation module for toric quiver cohomology

Research date: 2026-11-13. This note concerns ordinary, classical objects. It does
not construct a quantum theta basis. All cohomology below has rational
coefficients and its cohomological grading is forgotten unless explicitly shown.

**Novelty correction, 20:39 UTC.** Theorem A is already a direct consequence
of the user's earlier two-alphabet theorem in Tang, *Lefschetz coefficients of
quantum theta functions*, Hexagon 2610.00587v1, Theorem 2.1, together with the
BLM tight-grading formula. It must not be presented as a newly discovered
property. The derivation here is an independent elementary character proof and
supplies the explicit orbit-tree phase kernel used below. The genuinely useful
remaining interface is the general cyclic phase description and an actual
input-defined model for the higher-rank Young cancellation, not Theorem A alone.

## 1. Result and its precise scope

Let (a,b>0) be coprime. Orient the complete bipartite graph from (b) source
vertices (N_1,\ldots,N_b) to (a) sink vertices (E_1,\ldots,E_a), and put

\[
 \theta(E_i)=-b,\qquad \theta(N_j)=a.
\]

Write (X_{a,b}) for its thin stable quiver moduli space. Equivalently, it is the
smooth projective toric variety of the transportation polytope

\[
 P_{a,b}=\{(x_{ij})\geq0:\ \sum_jx_{ij}=b,\ \sum_ix_{ij}=a\}.
\]

The natural group (G=S_a\times S_b) acts by permuting vertices. Choose a
determinant-one Dyck rectangle (W\geq a,H\geq b), (aH-bW=1). Let
\(\mathcal T_{a,b}\) be the following **actual finite set**:

* a tight grading of totals (a) on vertical edges and (b) on horizontal edges;
* a partition of the (a) sink labels into blocks of sizes given by the vertical
  grades, assigned to those actual vertical positions;
* independently, a partition of the (b) source labels into blocks of sizes
  given by the horizontal grades, assigned to those actual horizontal positions.

The earlier two-stack theorem gives an equivalent definition using the actual
boundary-embedded two-page rooted trees. No scattering coefficient is used to
define this set. The label permutations give its natural (G)-action.

**Theorem A.** There is an isomorphism of ungraded rational (G)-modules

\[
 H^*(X_{a,b};\mathbb Q)\ \cong\ \mathbb Q[\mathcal T_{a,b}].       \tag{1.1}
\]

More explicitly, if \(\omega\) ranges over **undecorated** tight gradings, and
\(\alpha(\omega)\) and \(\beta(\omega)\) are its lists of positive vertical and
horizontal grades, then

\[
 H^*(X_{a,b};\mathbb Q)
 \cong\bigoplus_{\omega}
 \operatorname {Ind}_{\prod S_{\alpha_i(\omega)}}^{S_a}\mathbf1
 \boxtimes
 \operatorname {Ind}_{\prod S_{\beta_j(\omega)}}^{S_b}\mathbf1.   \tag{1.2}
\]

Consequently its Frobenius characteristic is the explicit (h)-positive sum

\[
 \operatorname {Frob}H^*(X_{a,b})
 =\sum_{\omega} h_{\alpha(\omega)}(X)h_{\beta(\omega)}(Y).       \tag{1.3}
\]

This identifies a particular, elementary Young permutation module, rather than
only proving the existence of some permutation representation. It does **not**
give a canonical cohomology class for each tight object, an equivariant bijection
to torus fixed points, or a bijection between tight gradings and stable trees.
Those statements are different. In fact the natural action on stable trees can
have different fixed-point counts.

The proof uses the established tight wall-coefficient formula and the established
nilpotent weighted-tree formula, plus the direct toric character calculation
below. Theorem A is also a corollary of the user's own earlier work, as detailed
in Section 8 below; its statement has no novelty claim. The general existence of permutation cohomology for
smooth projective toric varieties is claimed in the September 2026 preprint of
Gui–Qin–Shen–Xiong; that result is **not** an input to this proof. Their general
theorem must not be credited to the present work.

## 2. A general orbit-tree phase formula

The useful mechanism is not restricted to complete bipartite graphs.

Let (Q) be a finite connected acyclic directed multigraph with tail-minus-head
incidence \(\partial\). Let \(\theta\in\mathbb R^{Q_0}\) have total zero, satisfy

\[
 \theta(S)\ne0\quad(\varnothing\ne S\subsetneq Q_0),             \tag{2.1}
\]

and suppose \(\partial x=\theta\) has a strictly positive solution. The flow
polytope is bounded, and its thin quiver variety (X_{Q,\theta}) is smooth and
projective. Let \(\sigma\) be a finite-order quiver automorphism preserving
\(\theta\). Parallel arrows remain distinct and may be permuted.

Let \(\bar Q=Q/\langle\sigma\rangle\) retain one arrow for **each arrow orbit**.
For a vertex orbit (v), let (c_v) be its length. For an arrow orbit (e), let

\[
 L_e=|e|,\qquad \bar\theta_v=c_v\theta(v).
\]

Both endpoint orbit lengths divide (L_e). Let \(\mathscr S(\bar Q,\bar\theta)\)
be the set of spanning trees whose unique tail-minus-head flow of netflow
\(\bar\theta\) is strictly positive. For such a tree (T), define the literal
finite phase group

\[
 K_T=\ker\left[
 \bigoplus_{e\in T}\mathbb Z/L_e\mathbb Z
 \xrightarrow{\partial_T}
 \bigoplus_v\mathbb Z/c_v\mathbb Z\right],                       \tag{2.2}
\]

where the (v)-coordinate is the signed sum of incident edge phases, reduced
modulo (c_v).

**Theorem B.**

\[
 \operatorname {Tr}(\sigma\mid H^*(X_{Q,\theta}))
 =\sum_{T\in\mathscr S(\bar Q,\bar\theta)}|K_T|
 =\sum_{T\in\mathscr S(\bar Q,\bar\theta)}
   \frac{\prod_{e\in T}L_e}{\prod_vc_v}.                         \tag{2.3}
\]

Every summand in the last expression is an integer, and (2.2) gives its
combinatorial objects. No arbitrary set of a prescribed cardinality is used.

### 2.1 Genericity supplies the required divisibility

Let (d=\gcd_vc_v). If (d>1), choose exactly (c_v/d) vertices in each orbit.
Their union is a nonempty proper subset with theta sum

\[
 \sum_v(c_v/d)\theta(v)=\frac1d\theta(Q_0)=0,
\]

contradicting (2.1). Hence

\[
 \gcd_vc_v=1.                                                   \tag{2.4}
\]

For any connected tree (T), the cokernel of \(\partial_T\) in (2.2) has order
\(\gcd_vc_v\). Indeed, dualizing finite abelian groups, a character in the kernel
of \(\partial_T^*\) is a tuple

\[
 \lambda_v\in (c_v^{-1}\mathbb Z)/\mathbb Z
\]

whose values agree at both ends of every edge. Connectivity makes all values
equal, and the common subgroup has order \(\gcd_vc_v\). Thus (2.4) makes
\(\partial_T\) surjective. Taking orders proves

\[
 |K_T|=\frac{\prod_eL_e}{\prod_vc_v}.                            \tag{2.5}
\]

### 2.2 Toric orbit proof of the trace formula

For a toric stratum, let (H\subset Q) be its support: all original vertices
and precisely the arrows which are nonzero on that stratum. Such a support
occurs exactly when there is a strictly positive (\theta)-flow on (H).
Genericity forces every such (H) to be connected. Its torus is

\[
 O_H=(\mathbb C^*)^{H_1}/((\mathbb C^*)^{Q_0}/\mathbb C^*),
\]

with character lattice

\[
 M_H=\ker(\partial_H:\mathbb Z^{H_1}\to\mathbb Z^{Q_0}).
\]

Only \(\sigma\)-invariant supports can meet the fixed locus. For such a support
the all-one representation gives a fixed identity of (O_H), so the induced
action is a torus group automorphism, with no translation ambiguity.

The exact cycle-incidence sequence gives

\[
 \dim(M_H\otimes\mathbb Q)^\sigma
 =|H_1/\sigma|-|Q_0/\sigma|+1.                                  \tag{2.6}
\]

If this dimension is positive, (O_H^\sigma) is a finite union of positive
dimensional algebraic tori, so its Euler characteristic is zero. If it is zero,
the fixed torus is finite and

\[
 |O_H^\sigma|=|\det(1-\sigma\mid M_H)|.
\]

As (H/\sigma) is connected, the zero-dimensional condition in (2.6) is exactly
that (H/\sigma) be a tree (T). The characteristic polynomial identity from
the cycle-incidence sequence yields

\[
 \det(1-q\sigma\mid M_H)
 =(1-q)\frac{\prod_{e\in T}(1-q^{L_e})}
                    {\prod_v(1-q^{c_v})}.
\]

Since (T) has one fewer edge than vertices, taking (q\to1) gives the positive
integer (2.5).

Finally, averaging a positive flow on a \(\sigma\)-invariant support gives an
invariant positive flow. On an arrow orbit its total flow is (L_e) times its
per-arrow flow, and its netflow at a vertex orbit is \(\bar\theta_v\). Conversely
a positive flow on the quotient tree lifts by dividing its edge flow by (L_e).
At each original vertex the netflow becomes \(\bar\theta_v/c_v=\theta(v)\).
The lift is connected, since otherwise a component contradicts (2.1).
Thus the supports contributing nonzero Euler characteristic correspond exactly
to the stable quotient trees in (2.3).

The fixed-locus Lefschetz formula for a finite-order action gives

\[
 \sum_i(-1)^i\operatorname {Tr}(\sigma\mid H^i(X))=\chi(X^\sigma).
\]

Smooth projective toric varieties have no odd cohomology. Summing the orbit
contributions proves Theorem B. This proof does not assume that an automorphism
fixing a cone fixes it pointwise, and it does not use the 2026 permutation
representation theorem.

## 3. The complete bipartite character

Write the cycle lengths of \(\sigma\in S_a\) as (r_1,\ldots,r_p), and those of
\(\tau\in S_b\) as (s_1,\ldots,s_q). Thus \(\sum r_i=a,\sum s_j=b\).
Between the (i)-th sink cycle and (j)-th source cycle there are exactly

\[
 \gcd(r_i,s_j)\quad\hbox{arrow orbits, each of length}
 \quad\operatorname {lcm}(r_i,s_j).
\]

The quotient netflow is

\[
 \bar\theta(E_i)=-br_i,\qquad\bar\theta(N_j)=as_j.                \tag{3.1}
\]

For each underlying tree, summing its choices of parallel arrow orbits replaces
each edge factor (L_e) by
\(\gcd(r_i,s_j)\operatorname {lcm}(r_i,s_j)=r_is_j\). Therefore

\[
 \boxed{
 \operatorname {Tr}((\sigma,\tau)\mid H^*(X_{a,b}))
 =\sum_{T\in\mathscr S(K_{p,q},\bar\theta)}
       \prod_{i=1}^p r_i^{\deg_T(E_i)-1}
       \prod_{j=1}^q s_j^{\deg_T(N_j)-1}.}
                                                                    \tag{3.2}
\]

All exponents are nonnegative. An actual object counted by a summand is a
stable tree together with a residue in \(\mathbb Z/r_i\) at all but one of its
incidences at (E_i), and similarly with \(\mathbb Z/s_j\) at (N_j).
One may select the omitted incidence by a fixed edge order.

## 4. Why the same formula counts fixed tight objects

A decorated tight grading is fixed by \((\sigma,\tau)\) precisely when every
label block is a union of whole permutation cycles. This is equivalent to
choosing decorations from the coefficients of

\[
 P_1(x)=\prod_{i=1}^p(1+u_ix^{r_i}),\qquad
 P_2(y)=\prod_{j=1}^q(1+v_jy^{s_j}),                              \tag{4.1}
\]

and extracting the squarefree monomial \(\prod_i u_i\prod_jv_j\) in total degree
\((a,b)\). The tight grading theorem of Burcroff–Lee–Mou identifies this count
with that coefficient in the wall function on the primitive ray \((a,b)\).

Here one can impose (u_i^2=v_j^2=0): it does not affect the requested
coefficient. In this nilpotent setting, the weighted tree formula of
Reineke–Stoppa–Weist identifies the coefficient for incoming factors

\[
 \prod_i(1+r_i u_i x^{r_i}),\qquad
 \prod_j(1+s_j v_j y^{s_j})                                     \tag{4.2}
\]

with the number of stable trees on the levelled complete bipartite quiver having
\(r_is_j\) distinct arrows between its (i,j) vertices and stability (3.1).
This is Proposition 4.3 and the square-zero argument in its proof, followed by
Corollary 5.3. The outgoing degree is primitive, so there is no outgoing normal
factor. In the squarefree degree the wall function and its logarithm also have
the same coefficient, since a decomposition into two positive vectors on that
ray would require a proper positive multiple of the primitive total degree.

Substituting (u_i/r_i,v_j/s_j) in (4.2) gives (4.1). Hence

\[
 |\mathcal T_{a,b}^{(\sigma,\tau)}|
 =\frac1{\prod_i r_i\prod_j s_j}
   \sum_{T\in\mathscr S(K_{p,q},\bar\theta)}\prod_{ij\in T}r_is_j,
\]

which is exactly (3.2). This division is an identity of coefficients; Section 5
also gives literal phase objects for the resulting integer tree weights.

The characters agree on every element of (S_a\times S_b), so the rational
modules are isomorphic. Equivalently, first use semisimplicity over \(\mathbb C\)
and then the rational character theory of symmetric groups. For a fixed
undecorated grading its label-allocation orbit is the product of the two Young
coset sets. This proves (1.2) and (1.3).

### Normalization check

The factors (r_i,s_j) in (4.2) matter. Omitting them before applying the
nilpotent tropical-tree formula gives the wrong trace. In Hamiltonian language
the incoming primitive-normal factor (1+u x^r) has Lie leaf weight (1/r),
whereas the pairwise determinant is (r_is_j). Thus the same denominator
\(\prod r_i\prod s_j\) is forced independently by the Poisson normalization.

## 5. An actual all-arity phase bijection on each tree

The simplification from cyclic orbit data to vertex colors in (3.2) need not be
treated merely as a cardinality calculation.

Let (T) be any oriented tree with at least two vertices and positive vertex
integers (c_v) of gcd one.
For an edge (e:u\to v), put

\[
 g_e=\gcd(c_u,c_v),\qquad l_e=\operatorname {lcm}(c_u,c_v).
\]

Define two actual sets:

* (A_T): residues \(\alpha_{v,e}\in\mathbb Z/c_v\) at every incidence, with
  \(\sum_{e\text{ out of }v}\alpha_{v,e}-\sum_{e\text{ into }v}\alpha_{v,e}=0\).
  Choosing all but one incidence at each vertex freely gives
  \(\prod_vc_v^{\deg(v)-1}\) objects.
* (B_T): an edge-orbit offset \(\delta_e\in\{0,\ldots,g_e-1\}\) on every edge,
  together with (k\in K_T\) for edge moduli (l_e).

Fix the explicit leaf-gcd section in Section 5.1, which returns one solution
\(s(b)\) of \(\partial s=b\). Such a solution exists for every (b\), by the
surjectivity proved in Section 2.1. A Smith-normal-form implementation is an
alternative, but is not needed.

Given \(\alpha\in A_T\), set

\[
 \delta_e=\alpha_{v,e}-\alpha_{u,e}\pmod {g_e},
\]

using the displayed representatives. Solve the compatible pair of congruences

\[
 t_e\equiv\alpha_{u,e}\pmod {c_u},\qquad
 t_e\equiv\alpha_{v,e}-\delta_e\pmod {c_v}.                      \tag{5.1}
\]

The Chinese remainder theorem gives a unique (t_e\pmod {l_e}\). The vertex
balance equations imply

\[
 (\partial t)_v=\sum_{e\text{ into }v}\delta_e\pmod {c_v}
 =:b(\delta)_v.
\]

Return \((\delta,k=t-s(b(\delta)))\in B_T\).

Conversely, from \((\delta,k)\), put (t=k+s(b(\delta))\), and on each edge
set

\[
 \alpha_{u,e}=t_e\pmod {c_u},\qquad
 \alpha_{v,e}=t_e+\delta_e\pmod {c_v}.
\]

The incidence equation for (t\) makes these residues balanced. They recover
the original offsets and CRT solutions, so the maps are mutual inverses.

This construction works with arbitrary degrees and arbitrary tree size. It
mixes edge offsets and existing phases by explicit finite congruences. It does
not preserve a fictitious root-copy coordinate and does not require matching
objects by their enumeration indices.

### 5.1 A linear-size Euclidean section, with no group enumeration

At every step choose the first leaf (v) in a fixed vertex order. Let (p) be
its neighbor, (e) its remaining edge, and let \(\varepsilon\in\{1,-1\}\) be
the incidence sign of (e) at (v). Suppose the current moduli are (A=c_v),
(B=c_p), and the current targets are (b_v,b_p). Record these quantities and
the other remaining edges incident with (p). Remove (v,e), and replace

\[
 c_p\leftarrow\gcd(A,B),\qquad
 b_p\leftarrow b_p+b_v\pmod{\gcd(A,B)}.                         \tag{5.2}
\]

After all leaves have been removed, the remaining modulus is
\(\gcd_vc_v=1\), so the last equation is automatically satisfied.

Reconstruct the edges in reverse removal order. The other edges at the recorded
parent are now known; let (S) be their signed phase sum. Choose (t_e) by

\[
 t_e\equiv\varepsilon b_v\pmod A,\qquad
 t_e\equiv-\varepsilon(b_p-S)\pmod B.                          \tag{5.3}
\]

The reduced parent equation in (5.2) is exactly the compatibility condition for
these two congruences. Take the least nonnegative CRT solution modulo
\(\operatorname {lcm}(A,B)\). This modulus divides the original edge modulus,
since current vertex moduli only decrease by taking gcds. Every reconstruction
step restores both original recorded congruences. Induction proves that the
final edge phases solve the original system. The algorithm uses one gcd and one
CRT calculation per edge, with no enumeration of the group or its kernel.

### 5.2 Arbitrary common content and its single global phase constraint

The same construction works when \(g=\gcd_vc_v\) is larger than one. The
incidence image is exactly

\[
 \{b\in\bigoplus_v\mathbb Z/c_v:\ \sum_vb_v=0\pmod g\}.
\]

Indeed, the sum condition is necessary, and the dual-character proof of
Section 2.1 shows its index is exactly (g). Equivalently, the leaf-gcd
section finishes with modulus (g) and target \(\sum_vb_v\pmod g\), so it
succeeds exactly under this condition.

Replace (B_T) by the actual set

\[
 \left\{(\delta_e)\in\prod_e\mathbb Z/g_e:
                \sum_e\delta_e=0\pmod g\right\}\times K_T.      \tag{5.4}
\]

For a balanced incidence assignment, the sum of its edge offsets is zero
modulo (g), by summing all vertex balances. Conversely (5.4) makes
\(b(\delta)\) a compatible target for the section. Therefore the same CRT
forward and inverse maps prove the bijection for **all** positive contents.
The offset constraint has index (g), while

\[
 |K_T|=g\frac{\prod_el_e}{\prod_vc_v}.
\]

These factors cancel, giving the same \(\prod_vc_v^{\deg(v)-1}\) cardinality.
The common content is retained as one explicit global phase constraint; it is
not silently discarded by primitive reduction.

## 6. What this resolves and what remains

The natural tight-label action is a model for **ungraded toric cohomology**, not
for the permutation action on the torus fixed-point set. For (K_{2,3}), a
transposition in either factor has trace (4), and a source 3-cycle has trace
(3); the corresponding stable-tree fixed counts are zero. The tight Young
orbits have sizes (1,2,3). Thus the earlier mismatch has a structural positive
resolution, rather than requiring an incorrect equivariant tree bijection.

Theorem B supplies a general positive quotient-tree/phase mechanism for arbitrary
acyclic quivers. Theorem A then identifies the actual local Dyck alphabets with
a specific representation-theoretic object. These are useful inputs to a
higher-rank construction, but do not yet give its all-degree natural set-level
associator. They should not be presented as a full solution of that problem.

An explicit geometric basis map remains open here. A trial assigning a product
of tautological line bundles using only the producer positions gave full rational
rank in several computations, but generally non-unit Euler Gram determinants,
and some natural normalizations become singular already for (K_{3,4}). It is
therefore not asserted to be an integral basis or a correct general formula.

## 7. Computation and literature decisions

`tight_toric_character.py` compares two independently defined finite counts:
literal fixed decorated tight objects and positive-flow quotient trees with the
weights (3.2). It checked **183 conjugacy classes**, across **6,985 actual tight
objects**, in eleven coprime dimensions through ((4,5)) and ((5,4)). Every
comparison passed. No random numerical approximation is involved. These checks
validate conventions; Sections 2–4 supply the proof.

Primary sources inspected:

1. Burcroff–Lee–Mou, *Positivity of generalized cluster scattering diagrams*,
   arXiv:2503.03719v1, Theorem 1.2, Sections 5 and 6.
   <https://arxiv.org/html/2503.03719v1>.
   Used for the literal tight coefficient formula. Section 6 gives Euler
   characteristics of framed moduli, not the symmetric-group character theorem
   above. No cohomology representation result was found there.
2. Reineke–Stoppa–Weist, *MPS degeneration formula for quiver moduli and refined
   GW/Kronecker correspondence*, Geometry & Topology 16 (2012), 2097–2134,
   Proposition 4.3, its square-zero proof, and Corollary 5.3.
   <https://msp.org/gt/2012/16-4/gt-v16-n4-p06-s.pdf>;
   <https://arxiv.org/pdf/1110.4847>.
   The levelled-quiver weighted-tree identity is established prior work. Its
   input factors include the level multipliers, as recorded in Section 4.
3. Burcroff–Lee–Mou–Musiker–Reineke,
   *Cluster scattering diagrams via quiver moduli and tight gradings*,
   <https://arxiv.org/html/2511.14672v1>, Sections 3, 4, 9.2.
   Their Section 9.2 leaves a general tight-grading/stable-tree bijection open.
   The inspected text has no symmetric-group/cohomology representation theorem.
   Its HTML identifies v1 with a November 2025 submission but prints an August
   2026 compilation date; the specific claims used here also have the 2012/2025
   primary sources above, so no unreviewed 2026 theorem is required.
4. Gui–Qin–Shen–Xiong, *Permutation representations on cohomology of toric
   varieties*, arXiv:2609.06597v1, Theorem 1.2 and Sections 2–3.
   <https://arxiv.org/html/2609.06597v1>.
   **2026 audit / novelty comparator only.** It claims existence of some finite
   permutation set for every smooth projective toric variety, via deformed
   Stanley–Reisner rings and local Jacobian algebras. It does not provide the
   tight set in (1.1). The root agent is separately auditing the external local
   singularity theorem used there. It is not a proof input here.

Searches also covered toric quiver exceptional collections, graphical parking
functions, transportation polytopes, orbit harmonics, and toric permutation
characters. The earlier statement that no prior source for (1.2) was located
is superseded by the own-prior comparison in Section 8.

Route record, 19:51–20:17 UTC:

* Root identification/one-edge deletion and several mass-cancellation traversals
  were tested as candidate actual tree maps. They collapse distinct objects and
  do not give the required bijection; they are not claimed as results.
* A tautological-line-bundle model led to the correct cohomology target but did
  not yield an integral basis formula. Its exact modular Euler Gram data are
  retained as failed-route evidence.
* The equivariant trace calculation produced Theorem B and the explicit
  weighted character (3.2). The fixed-tight interpretation and the old
  nilpotent weighted-tree formula then prove Theorem A.
* The phase kernel was converted into an actual all-arity CRT/Smith bijection,
  so the positive cyclic weights have concrete objects rather than formal
  division by orbit sizes.

## 8. Own-prior comparison and the classical specialization

Primary source: Qiyue Tang, *Lefschetz coefficients of quantum theta functions*,
Hexagon 2610.00587v1, Theorem 2.1 and equations (2.1)–(2.4),
<https://hexagonmath.org/pdf/2610.00587v1>. The definitions and theorem statement
were read directly in the primary PDF on 2026-11-13; the root agent separately
read the full source. This paragraph audits the overlap, not the entire old
Lefschetz proof.

The old incoming quantum factor has classical Hamiltonian

\[
 \lim_{t\to1}(t-t^{-1})\log E(-p_1(U)X)
 =\sum_{m\ge1}\frac{(-1)^{m+1}p_m(U)}{m^2}X^m.
\]

Its associated primitive classical wall function is therefore
\(\prod_i(1+u_iX)\). In coprime bidegree \((a,b)\), no higher Adams term from
a smaller positive integral degree contributes. The first outgoing wall
coefficient is the specialization \(P_{a,b;1}(1;U,V)\). The old theorem
identifies this with the Frobenius characteristic of
\((\mathrm{sgn}_a\boxtimes\mathrm{sgn}_b)\otimes H^*(X_{a,b})\).
Opposite-quiver duality reconciles the source/sink convention in this note.
Smoothness follows from coprimality and total unimodularity. The cohomological
shift disappears at \(t=1\); moreover the dimension \((a-1)(b-1)\) is even
in this coprime case, so there is no hidden parity ambiguity.

BLM gives the same coefficient as
\(\sum_\omega e_{\alpha(\omega)}(U)e_{\beta(\omega)}(V)\).
Applying the symmetric-function involution \(\omega_U\omega_V\), which
tensors both group factors with sign, gives exactly (1.3). Consequently the
Young permutation decomposition is a direct old-theorem-plus-BLM corollary.
The present character proof does not rely on the correctness of the old
Lefschetz theorem and remains a separate check of this classical case.

Additional exact verification for the explicit phase bijection in Section 5:
`tree_phase_transport.py` checked 4,684 tree/content cases, including 338
noncoprime-content cases, 364,688 literal forward/inverse transports, and
15,052 compatible leaf-gcd section solves. Tests included trees with 40
vertices and moduli up to 1,000; all passed. These computations verify the
implementation; the proof is the explicit CRT and leaf-contraction argument.

