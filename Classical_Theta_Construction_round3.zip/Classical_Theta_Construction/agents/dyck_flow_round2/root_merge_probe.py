from pathlib import Path
from itertools import product
from collections import Counter, defaultdict
import sys,json
ROOT=Path('/workspace/scratch/0e6dfa966050/theta_20261114')
sys.path.insert(0,str(ROOT/'agents/dyck_flow_interface'))
from thin_boundary_probe import *

def labelled(z,revE=False,revN=False):
 word,gr,f,blocks=z
 root=f.nontrivial_roots[0]
 active=set(x for e in f.edges for x in e)
 start=(root-len(active)+1)%len(word)
 rank={v:(v-start)%len(word) for v in active}
 labs={root:-1}
 for v,bl in blocks.items():
  children=sorted([w for u,w in f.edges if u==v],key=rank.get,reverse=revE if word[v]=='E' else revN)
  labs.update(zip(children,bl))
 return tuple((labs[u],labs[v]) if word[u]=='N' else (labs[v],labs[u]) for u,v in f.edges)

def merges(edges,a,b):
 out=defaultdict(list)
 for r in range(a,a+b):
  es=tuple((r if u==-1 else u,v,0) for u,v in edges)
  for k in range(len(es)):
   T=tuple(j for j in range(len(es)) if j!=k)
   try:
    ok=stable(a+b,es,T,(-b,)*a+(a,)*b)
   except (AssertionError,KeyError):ok=False
   if ok:out[tuple(sorted((u,v) for j,(u,v,_) in enumerate(es) if j!=k))].append((r,k))
 return out

def main():
 report=[]
 for a,b in [(2,3),(3,2),(3,4),(4,3),(2,5),(5,2),(3,5),(5,3),(4,5)]:
  obs=list(objects(a,b));row=[]
  for re,rn in product([False,True],repeat=2):
   vals=[merges(labelled(z,re,rn),a,b) for z in obs]
   row.append({'flags':[re,rn],'image_sizes':dict(Counter(map(len,vals))),'all_images':len(set(t for d in vals for t in d))})
  report.append({'a':a,'b':b,'objects':len(obs),'maps':row})
  print(json.dumps(report[-1]))
 Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))

if __name__=='__main__':main()
