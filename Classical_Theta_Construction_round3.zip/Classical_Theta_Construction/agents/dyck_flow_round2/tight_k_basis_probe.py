"""A substantive candidate: tight objects index tautological K classes.

Compute the toric Euler Gram matrix using exact modular localization.
Nothing here is a proof that the candidate is a basis.
"""
from root_merge_probe import *
from fractions import Fraction
from math import factorial
from time import time

BERN=[Fraction(1),Fraction(-1,2),Fraction(1,6),0,Fraction(-1,30),0,Fraction(1,42),0,Fraction(-1,30),0,Fraction(5,66),0,Fraction(-691,2730)]

def conv(x,y,D,P):
 out=[0]*(D+1)
 for i,c in enumerate(x):
  for j,d in enumerate(y[:D+1-i]):out[i+j]=(out[i+j]+c*d)%P
 return out

def ff(q,P):
 q=Fraction(q);return q.numerator*pow(q.denominator,-1,P)%P

def toric_data(a,b,P):
 n=a+b;D=(a-1)*(b-1)
 edges=[(a+j,i,0) for i in range(a) for j in range(b)]
 costs=[2**i for i in range(len(edges))]
 data=[]
 for T in all_trees(n,edges):
  if not stable(n,edges,T,(-b,)*a+(a,)*b):continue
  phi=[None]*n;phi[0]=0
  while any(x is None for x in phi):
   for e in T:
    u,v,_=edges[e]
    if phi[u] is not None:phi[v]=phi[u]-costs[e]
    elif phi[v] is not None:phi[u]=phi[v]+costs[e]
  ds=[costs[e]-phi[u]+phi[v] for e,(u,v,_) in enumerate(edges) if e not in T]
  assert len(ds)==D and all(ds)
  td=[1]+[0]*D;den=1
  for d in ds:
   td=conv(td,[ff(BERN[k]*((-1)**k)*Fraction(d**k,factorial(k)),P) for k in range(D+1)],D,P)
   den=den*d%P
  coeff=[td[D-k]*pow(factorial(k),-1,P)*pow(den,-1,P)%P for k in range(D+1)]
  data.append((phi,coeff))
 return data

def weights(z,a,b,signE=1,signN=1):
 word,gr,f,blocks=z
 E=N=0;coords={}
 for i,c in enumerate(word):
  coords[i]=(E,N)
  if c=='E':E+=1
  else:N+=1
 assert a*N-b*E==1
 # Symmetric normalization: lambda=N*sum_E - E*sum_N has total 1.
 w=[0]*(a+b)
 for v,ls in blocks.items():
  x,y=coords[v]
  for l in ls:w[l]=(signE*y if word[v]=='N' else signN*x)
 s=sum(w)
 return tuple(w[i]-s*(N if i<a else -E) for i in range(a+b))

def evalpoly(cs,x,P):
 ans=0
 for c in reversed(cs):ans=(ans*x+c)%P
 return ans

def determinant(mat,P):
 mat=[r[:] for r in mat];n=len(mat);det=1;rank=0
 for k in range(n):
  j=next((j for j in range(k,n) if mat[j][k]),None)
  if j is None:return 0,k
  if j!=k:mat[k],mat[j]=mat[j],mat[k];det=-det
  d=mat[k][k];det=det*d%P;di=pow(d,-1,P)
  for j in range(k+1,n):
   mul=mat[j][k]*di%P
   for l in range(k+1,n):mat[j][l]=(mat[j][l]-mul*mat[k][l])%P
  rank+=1
 return det%P,rank

def gram(ws,data,P):
 n=len(ws);out=[[0]*n for _ in range(n)]
 for phi,cs in data:
  vals=[sum(x*y for x,y in zip(w,phi))%P for w in ws]
  for i,u in enumerate(vals):
   for j,v in enumerate(vals):out[i][j]=(out[i][j]+evalpoly(cs,(v-u)%P,P))%P
 assert all(out[i][i]==1 for i in range(n)),[out[i][i] for i in range(n)]
 return out

def main():
 P=1000000007;report=[]
 for a,b in [(2,3),(3,2),(2,5),(5,2),(3,4),(4,3),(3,5),(5,3)]:
  t=time();obs=list(objects(a,b));data=toric_data(a,b,P);rows=[]
  for se,sn in product([1,-1],repeat=2):
   ws=[weights(z,a,b,se,sn) for z in obs]
   G=gram(ws,data,P);det,rank=determinant(G,P)
   rows.append({'signs':[se,sn],'distinct':len(set(ws)),'det_mod':det,'elim_rank':rank})
  row={'a':a,'b':b,'objects':len(obs),'vertices':len(data),'prime':P,'seconds':time()-t,'maps':rows}
  report.append(row);print(json.dumps(row),flush=True)
  Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))

if __name__=='__main__':main()
