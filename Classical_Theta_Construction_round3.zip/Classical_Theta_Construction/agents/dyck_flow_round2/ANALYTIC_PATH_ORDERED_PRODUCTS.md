# Explicit analytic convergence of cluster path-ordered products

2026-11-13. Classical principal-coefficient cluster scattering.

## 0. Status

This note proves an analytic consequence of the uniform theta estimate
(0.1) in `WALL_AND_MULTIPLICATION_ANALYTIC_BOUNDS.md`. Its single-bend lemma
gives all coefficient and coordinate-factor bounds used here. The proof
below handles domain drift and the insertion of infinitely many walls;
neither is inferred just from convergence of the individual wall functions.
The underlying Bezout estimate and novelty comparison have their own
independent audits. No quantum claim is made.

Let r be the mutable rank, let b=max_ij |B_ij|, and put

    C=max(1,b),          A=exp(1/C),
    z_i=y_i x^{B e_i},   q(z)=e C sum_i |z_i|.

Fix a generic polygonal tropical path gamma with at most L>=1 straight
segments. Its endpoints and segment vertices avoid the wall support, and
it avoids joints and crosses encountered walls transversely. All statements
are understood degree by degree if necessary. The constants below depend
only on r,b,L, not on the path's geometric length, its location, or D.

## 1. Explicit constants and theorem

Choose any real q_1 with

    0<q_1<1/(1+A).

For example q_1=1/(2(1+A)) works. Define

    delta=A q_1/(1-q_1) <1,
    K_0=A/((1-q_1)(1-delta)),
    K=L K_0 ((1-q_1)^(-r)-1),
    Lambda=L r^2 b A q_1/((1-delta)(1-q_1)^(r+3)),
    q_0=(q_1/2) exp(-r b K).                              (1.1)

**Theorem.** The formal path-ordered product of the classical cluster
scattering diagram along gamma is represented by a holomorphic map on

    D_0={(x,y) in (C*)^r x C^r : q(y_i x^{B e_i})<q_0}.   (1.2)

The products retaining all crossing normals of degree at most N, with
their full analytic germs, converge there locally normally. These are the
precise finite products used below; arbitrary unrelated high-order choices
of representatives are not meant. In logarithmic x coordinates their
corrections converge uniformly, with the explicit tail estimate in
Section 5. The resulting map fixes y and has exactly the prescribed
formal Taylor expansion in the principal degrees.

All generic paths with at most L segments share this explicit domain.
Formal consistency therefore gives equality of the corresponding analytic
maps whenever their formal path products agree, on their common domains.
This theorem does not say that D_0, or the larger q<q_1 ball, is invariant
under every individual wall map.

## 2. Coordinate factors and logarithmic displacements

At a crossing with primitive positive charge n, write

    m=|n|,             u=Dn/gcd_i(D_i n_i),

and let f be the combined local wall function at the crossing. Every
coordinate with u_i>0 has the coefficient estimate

    [z^{kn}]f^{u_i} <= (1+Ckm)^{km}/product_j(kn_j)!,

by the single-bend lemma. Coordinates with u_i=0 have factor one. Hence
throughout q(z)<=q_1,

    |f^{u_i}-1| <= A q_1^m/(1-q_1^m) <= delta <1.         (2.1)

The branch of log(f^{u_i}) with zero constant term is holomorphic there.
Set w_i=log(x_i) locally. A wall crossing with either orientation is

    Phi(w)=w+V(w,y),
    V_i=+/- log(f(z^n)^{u_i}).                            (2.2)

These logarithms agree with u_i log(f) by their common germ at z=0. Also
u dot Bn=0, so z^n is unchanged by (2.2). Thus (2.2) is the exact wall
map, equivalently the time-one map of this constant-along-orbits vector
field, rather than a first-order approximation.

Since -log(1-t)<=t/(1-delta) for 0<=t<=delta,

    ||V||_infinity
      <= A q_1^m/((1-q_1^m)(1-delta))
      <= K_0 q_1^m =: d_m.                              (2.3)

This bound applies to either orientation and contains no factor depending
on the size of the primitive normal u.

## 3. Summable derivatives

The same coefficient bound controls derivatives without an unspecified
Cauchy constant. Put H_i=f^{u_i}-1. Because

    partial_{w_j}(z^{kn})=k(Bn)_j z^{kn},
    |(Bn)_j|<=b m,

we have

    |partial_{w_j} H_i|
      <= b m A q_1^m/(1-q_1^m)^2.

Dividing by |1+H_i|>=1-delta and summing over j gives the operator bound
for the infinity norm,

    ||D_w V|| <=
       r b m A q_1^m/((1-q_1)^2(1-delta)) =: lambda_m.   (3.1)

For fixed y, the logarithmic domain q(z(w,y))<q_1 is convex. Indeed
q is a positive sum of exponentials of real linear forms in Re(w), so
its sublevel sets are convex. Therefore (3.1) gives a Lipschitz bound
between any two points in this domain, not merely along short segments.

There are at most binom(m+r-1,r-1) nonzero positive integer charge vectors
of total degree m. Counting all such vectors overestimates the primitive
ones. A straight segment crosses the hyperplane of a given primitive n
at most once; L segments cross it at most L times. All coincident walls
at one crossing have already been combined into f. Consequently

    sum_crossings d_|n| <= K,
    sum_crossings lambda_|n| <= Lambda,                  (3.2)

using

    sum_{n in N^r\{0}} q_1^{|n|}=(1-q_1)^(-r)-1,
    sum_{n in N^r\{0}} |n|q_1^{|n|}=r q_1(1-q_1)^(-r-1).

Artificial subdivisions of a wall do not affect this count: it counts
crossings of root hyperplanes and their combined germs, not the number
of cones in a chosen representative.

## 4. Domain drift for every finite ordered subproduct

Start at a point with q(z)<q_0. Take any finite set of crossings and compose
their full analytic wall maps in path order. Inductively suppose the maps
already used were evaluated inside q<q_1. Their total logarithmic change
has infinity norm at most the sum of their d_|n|, hence at most K. For each
principal degree variable,

    |z_j(new)|
       <= |z_j(old initial)| exp(sum_i |B_ij| K)
       <= |z_j(old initial)| exp(r b K).

It follows that every intermediate point satisfies

    q(z(new)) < q_0 exp(r b K)=q_1/2 <q_1.               (4.1)

This closes the induction. Thus all finite ordered subproducts are
holomorphic on the same initial domain and remain in the larger domain
where (2.3) and (3.1) hold. The argument works uniformly over arbitrary
finite subcollections; an enumeration of a potentially dense crossing
order is unnecessary.

## 5. Inserting new walls: a uniform Cauchy estimate

Let E_N contain the actual crossing events whose primitive normals have
|n|<=N, using the complete analytic germ f at each event. This is a finite
set by Section 3. Write P_N for its product in path order and H_N for its
logarithmic correction, so P_N(w)=w+H_N(w,y).

For M>N, run the two finite trajectories corresponding to E_N and E_M,
inserting an identity step into the first trajectory whenever the second
encounters a new event. Both trajectories stay inside q<q_1/2 by (4.1).
At a common event of degree m, their difference is multiplied by at most
1+lambda_m. At a new event, it increases by at most d_m. Iterating gives

    ||H_M-H_N||_infinity
       <= exp(Lambda) sum_{events in E_M\E_N} d_|n|.

The derivative estimate applies between the two trajectories because the
logarithmic q<q_1 domain is convex at fixed y. Therefore the estimate is
uniform over the entire initial domain D_0.

For any rho with q_1<rho<1,

    ||H_M-H_N||_infinity
       <= exp(Lambda) L K_0 (q_1/rho)^(N+1)
                            ((1-rho)^(-r)-1).           (5.1)

This follows by summing q_1^{|n|} over |n|>N and comparing with rho^{|n|}.
It proves uniform convergence of the logarithmic corrections and local
normal convergence of the holomorphic maps. The limit fixes y and sends
x_i to x_i exp(H_i).

All formulas are periodic under w -> w+2pi i Z^r because B is integral.
Thus the limit descends from logarithmic coordinates to the torus domain
(1.2). No logarithm of a mutable coordinate needs to be selected globally
in the resulting map.

## 6. Identification with the formal scattering product

The product P_N uses the full analytic germ of each wall normal with
|n|<=N. A wall with |n|>N has no nonconstant term of degree <=N; it cannot
affect those formal degrees. A germ already included may have arbitrarily
high terms, but those terms likewise do not affect degrees <=N. Hence

    P_N agrees with the formal path-ordered product through degree N.

Uniform holomorphic convergence near the principal central fiber permits
coefficient extraction, so the analytic limit has exactly the formal
scattering expansion. Formal equivalence of positive representatives
therefore produces the same analytic limit on this domain. Formal
consistency becomes analytic consistency there as well.

The bound depends on the number of path segments because a path can cross
one root hyperplane more than once. It does not depend on the number of
scattering walls or the number of chambers met. A common fixed domain for
paths with no bound on their number of segments is not asserted.

## 7. Relation to individual maps and theta multiplication

The larger domain q<1/(1+A) already gives analytic individual wall maps
and inverses, while (1.2) makes a finite-segment path product converge
despite domain drift and infinitely many possible crossings. The theta
and theta-multiplication series in the companion note converge on the
larger domain q<1. These different domains answer different questions
and are not conflated.

All conclusions still rest on the uniform coefficient estimate and the
positive cluster-scattering representative. They establish analytic
convergence, not Laurent finiteness. Literature comparison is required
before making a novelty claim for this analytic consequence.
