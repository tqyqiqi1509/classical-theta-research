# The framed Gale finite factor, all cycle traces, and free Young orbits

2026-11-13, updated after the independent rank-recession review. Classical skew-symmetric and skew-symmetrizable cluster
data only.

## 0. Status and dependencies

This note proves the complete finite-factor/character interface. The
**uniform positive valuation window** stated in Section 2 is now proved in
`../phase_descent_round1/COLOR_GENERIC_VALUATION_WINDOW.md` and has an
independent, simpler proof of its central rank-recession statement in
`../global_gale_adversarial/RANK_GENERICITY_AND_RECESSION.md`. The present
branch has checked that proof. It uses a projection-generic auxiliary
covector only in the proof; the actual parameter is chosen by finite exact
rank conditions. The finite-factor/character theorem is therefore no longer
conditional on an unfinished window argument. Its other declared inputs
remain the earlier one-frame/flow identities stated below. Fixed-locus
flatness, packet powers, primitive degrees, and sign multiplicity are
proved here with their exact hypotheses.

For a covector with arbitrary signs, the same conclusion holds with the
theta expansion taken in its endpoint chart, provided **both rank genericity
and cut genericity** are imposed. The complete extension, its explicit
parameter choice, and the resulting finite algebras for all finite-arity
structure constants are proved in `SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md`.
Cut genericity alone suffices for fixed-target finiteness but does not
suffice for the degree/theta identification.

The independent fixed-target algebraic construction is now proved in
`../phase_descent_round1/GALE_FIXED_TARGET_FINITE_FACTOR.md`. It establishes
finiteness even at an arbitrary cut-generic covector. The valuation window
is needed here to compare its degree through the full target annulus, not
to establish fixed-target finiteness from scratch.

The strong-generic binary-chart counting input is
`../phase_descent_round1/GALE_POSITIVE_FACTOR_GENERIC.md`, Sections 1–4. The
fixed-cycle trace lemma is `YOUNG_FIXED_CYCLE_LENGTH_LEMMA.md`. Both inputs
are independent of the desired coefficient: neither defines a set by its
cardinality. The one-frame and signed cycle identities are the earlier
classical results in the user's `Higher_Rank_Greedy_Theta` package, especially
`agents/universal_tree_positive.md`, Sections 1–3.

The resulting model is a single explicitly presented graph ideal and a
finite set of algebraic tuples. It is not claimed to be a Dyck-path rule or
an elementary lattice-point formula. It avoids the recursive local
cohomology/Specht modules of the earlier model, and its defining equations do
not ask for any theta coefficient.

## 1. Original input, clones, and primitive Gale rows

Let \(B\in M_r(\mathbb Z)\), and let
\(D=\operatorname{diag}(D_1,\ldots,D_r)\) be positive integral with \(DB\)
skew-symmetric. Fix \(g\in\mathbb Z^r\) and \(p\in\mathbb N^r\). Put

\[
 \widehat B=\begin{pmatrix}0&-g^TD\\g&B\end{pmatrix},\qquad
 \widehat D=\operatorname{diag}(1,D),\qquad
 \eta(a,b)=-a^T\widehat D\widehat B b.
\]

Use one frame vertex \(0\), of charge \(e_0\), and \(p_i\) individually
labeled clone vertices of charge \(e_i\) for each mutable color \(i\). Let
\(V\) be this vertex set and \(n=|p|\). The symmetry group is

\[
 G_p=\prod_{i=1}^rS_{p_i}.
\]

For distinct vertices \(u,v\), place
\(|\eta(\gamma_u,\gamma_v)|\) parallel arrows from \(u\) to \(v\) when
\(\eta(\gamma_u,\gamma_v)>0\). Thus an ordered pair supports arrows in at
most one direction, and two vertices of the same color have no arrows
between them. Let \(m_{uv}\) denote the multiplicity on an actual directed
pair. Set \(D_0=1\), and \(d_v=D_i\) for a mutable clone of color \(i\).
Then both endpoint contents divide every arrow multiplicity:

\[
 d_u\mid m_{uv},\qquad d_v\mid m_{uv}.
\]

Set \(x_0=0\), put \(L_e=x_{h(e)}-x_{t(e)}\), and work on

\[
 U=\mathbb A^n\setminus\bigcup_e\{L_e=0\}.
\]

The ordinary and primitive Gale maps, with the frame row omitted, are

\[
 \Gamma_v^{\rm ord}(x)
 =\frac{\prod_{h(e)=v}L_e}{\prod_{t(e)=v}L_e},
 \qquad
 \Gamma_v^{\rm pr}(x)
 =\frac{\prod_{h(e)=v}L_e^{1/d_v}}
        {\prod_{t(e)=v}L_e^{1/d_v}}.                 \tag{1.1}
\]

In the second expression parallel-arrow powers are combined first: its
exponents are the integers \(m_{uv}/d_v\). No fractional function is being
adjoined. In particular

\[
 \Gamma_v^{\rm ord}=(\Gamma_v^{\rm pr})^{d_v}.       \tag{1.2}
\]

Choose a rational covector \(\mu\) on the charge space with

\[
 \mu(e_i)>0\quad(p_i>0),\qquad
 \mu(e_0)=-\sum_i p_i\mu(e_i).
\]

It is additionally chosen outside the finite original-color exceptional
hyperplanes of the window lemma. Write \(\theta_v^0=\mu(\gamma_v)\).
The coefficient field has characteristic zero and a parameter \(T\) with
\(\operatorname{val}(T)=1\). Clear all rational powers by a finite
ramification when necessary. The primitive equations are

\[
 \Gamma_v^{\rm pr}(x)
 =q_vT^{-\theta_v^0/d_v},\qquad v\ne0.             \tag{1.3}
\]

At first the \(q_v\) are independent target coordinates. The desired
\(G_p\)-equivariant fiber will be \(q_v=1\) for every vertex.

If the underlying graph is disconnected, a component not containing the
frame has positive total \(\theta^0\); multiplying its ordinary equations
contradicts this valuation. Thus the selected positive factor is empty and
the framed flow count is zero. In the rest of the proof assume the graph is
connected. If \(p=0\), use the one-point algebra with trivial group action
separately.

## 2. The exact valuation-window input

For a rational full leaf covector \(\theta\) of total sum zero, consider the
ordinary equations

\[
 \Gamma_v^{\rm ord}(x)=c_vT^{-\theta_v}.
\]

The required window statement is the following.

**Uniform window lemma.** For a generic original-color \(\theta^0\) as in
Section 1, there are a full neighborhood \(\mathcal N\) of \(\theta^0\) in
the \(n\)-dimensional leaf covector space and constants
\(0<\varepsilon<M\), such that, over every complete real-valued extension
field, any solution with \(\theta\in\mathcal N\), unit targets \(c_v\),
and all actual arrow valuations positive satisfies

\[
 \varepsilon\le\operatorname{val}(L_e)\le M
 \quad\text{for every actual arrow }e.             \tag{2.1}
\]

The constants are independent of the residue constants of the targets.
They must also work for units such as \(1+T^N\); a statement only about
constant generic complex targets would not suffice.

Here is why the *full* neighborhood follows from the companion recession
statement. There are only finitely many binary collision hierarchies \(H\).
For each one,

\[
 M_Ht=-\theta,\qquad t\ge0,\qquad
 w_e=\sum_{S\supseteq\{t(e),h(e)\}}t_S.
\]

Its feasible target cone is closed and polyhedral. Hierarchies infeasible at
\(\theta^0\) remain infeasible in a sufficiently small neighborhood. For a
hierarchy feasible at \(\theta^0\), the recession statement says

\[
 r\ge0,\quad M_Hr=0\quad\Longrightarrow\quad
 \sum_{S\supseteq\{t(e),h(e)\}}r_S=0
 \quad\text{for every actual arrow }e.             \tag{2.2}
\]

Thus each edge-valuation objective has a finite linear-programming upper
bound, uniformly for \(\theta\) in a small compact neighborhood. One may
obtain the uniform bounds from feasible dual linear functionals or from the
finitely many basic solutions. The lower bound follows from the first
collision cut: the positive cut chamber has all proper cut sums bounded
away from zero, while there are only finitely many integral cut pairings.
Binary refinements of multifurcations are permitted with zero inserted
depths. Coincidences across nonadjacent vertices require no inverse and
cannot violate (2.1).

The parallel-depth proof of (2.2) uses the nondegenerate memory plane
described in Section 9 below. It does not assume the original quiver is
acyclic.

## 3. One finite flat family over the full target polyannulus

Take a complete nontrivially valued characteristic-zero field \(K\)
containing the required powers of \(T\), and choose \(\delta>0\) small
enough that

\[
 \theta_v=\theta_v^0-d_v\operatorname{val}(q_v),
 \qquad |\operatorname{val}(q_v)|\le\delta
\]

lies in \(\mathcal N\). Let \(\mathcal B\) be this closed \(n\)-dimensional
polyannulus of independent targets. It is connected and its affinoid
algebra is regular. Use radii in the value group after finite extension.

Define \(\mathcal X\) as the solutions of (1.3) over \(\mathcal B\) subject
to the closed inequalities

\[
 \operatorname{val}(x_v)\ge\varepsilon/2,
 \qquad
 \operatorname{val}(L_e)\le M+1.                    \tag{3.1}
\]

The second inequality is a bound on the regular coordinate \(L_e^{-1}\).
These equations and inequalities give a closed affinoid subspace of a
relative polydisc over \(\mathcal B\), using coordinates \(x_v\) and
\(L_e^{-1}\), with the relations \(L_eL_e^{-1}=1\).

It is exactly the entire positive solution locus. Indeed (3.1) makes every
arrow difference positive; conversely (2.1), and the expression of each
\(x_v\) as a sum of arrow differences along a frame path, imply (3.1).
Moreover every point satisfies the **strictly stronger** bounds

\[
 \operatorname{val}(x_v)\ge\varepsilon>\varepsilon/2,
 \qquad
 \operatorname{val}(L_e)\le M<M+1.                  \tag{3.2}
\]

Consequently every point lies in the relative interior of the displayed
polydisc presentation. The morphism

\[
 f:\mathcal X\longrightarrow\mathcal B
\]

is boundaryless between affinoid spaces and hence finite. This uses the
standard affinoid criterion for finiteness, not an inference from
topological compactness alone. A closed disc is compact but has a boundary;
the strict margins in (3.2) are the necessary additional fact.

For flatness, observe that the graph of (1.3) is an analytic domain of
\(U^{\rm an}\), with \(q_v=T^{\theta_v^0/d_v}\Gamma_v^{\rm pr}(x)\).
Thus \(\mathcal X\) is locally a smooth \(n\)-dimensional space over
\(K\). A finite map from this Cohen–Macaulay source to the regular
\(n\)-dimensional base is flat by the local dimension criterion. Equivalently,
one can use the square equations and a regular sequence. Therefore

\[
 \boxed{f\text{ is finite flat over the entire connected }\mathcal B.}
                                                               \tag{3.3}
\]

The empty family has rank zero. Otherwise its degree means the constant
rank of \(f_*\mathcal O_{\mathcal X}\), or, equivalently, the length of any
geometric fiber including its full Artin structure. Reducedness of a
particular fiber is not asserted.

## 4. Why the fixed-cycle family is finite flat

The group \(G_p\) acts on both \(x\) and the independent targets \(q\).
The initial exponents and contents are constant on each color. Choose the
same annulus radii for all target coordinates, and the source bounds
uniformly. Then \(f\) is equivariant.

Fix \(\sigma\in G_p\), and let \(\mathcal B^\sigma\) be its fixed target
polyannulus. It has one target coordinate for each permutation cycle. Let
\(\mathcal X^\sigma\) be the fixed source scheme above
\(\mathcal B^\sigma\). Scheme-theoretically it is obtained by imposing

\[
 x_v=x_{\sigma(v)},\qquad q_v=q_{\sigma(v)}.
\]

First, \(\mathcal X^\sigma\) is a closed subspace of the finite base change
\(\mathcal X\times_{\mathcal B}\mathcal B^\sigma\), hence finite over
\(\mathcal B^\sigma\). Second, on the fixed coordinate subspace, every
original row in the same permutation cycle agrees with every other row in
that cycle. Retaining one row per cycle gives a square map in the cycle
variables.

No actual arrow has both endpoints inside one permutation cycle: cycles
lie in a single original color, and same-color pairings vanish. Hence
\(U^\sigma\) is a nonempty open subset of affine space on the cycle
variables whenever the fixed positive locus is nonempty. If the number of
mutable cycles is \(m\), it is smooth of dimension \(m\). The fixed
equations determine their \(m\) target coordinates, so
\(\mathcal X^\sigma\) is an analytic domain of \((U^\sigma)^{\rm an}\).
The fixed base is a regular connected \(m\)-dimensional polyannulus.
The same finite-map flatness argument now gives

\[
 \boxed{\mathcal X^\sigma\longrightarrow\mathcal B^\sigma
        \text{ is finite flat}.}                   \tag{4.1}
\]

Only after this step do we restrict to the smaller target locus
\(\mathcal B^{G_p}\), where targets agree within each original color.
Both the whole family and all fixed families remain finite flat there by
base change. This order is essential: flatness of the original family does
not, by itself, imply flatness of its fixed subschemes.

## 5. Exact packet equations and the primitive divisor

Let the mutable cycles of \(\sigma\) be the packets \(A\). A cycle of
length \(r_A\) and original color \(i(A)\) has charge

\[
 \gamma_A=r_Ae_{i(A)},\qquad d_A=r_AD_{i(A)}.
\]

Keep the frame as a packet of charge \(e_0\) and content \(d_0=1\).
For two mutable packets, let

\[
 M_{AB}=r_Ar_Bm_{i(A),i(B)},
\]

with the direction inherited from the original skew pairing; for the frame
use the same formula with \(r_0=D_0=1\). These are exactly the ordinary
arrow multiplicities \(|\eta(\gamma_A,\gamma_B)|\) of the packet graph.

Put \(x_v=X_A\) on a cycle. A single primitive original row at a vertex
of \(A\) has \(r_B\) incident vertices in packet \(B\), so its exponent is

\[
 \frac{m_{i(A),i(B)}r_B}{D_{i(A)}}
 =\frac{M_{AB}}{d_A}.                              \tag{5.1}
\]

Thus the fixed rows are precisely the **primitive packet Gale rows**. Their
targets are

\[
 q_AT^{-\theta_A^0/d_A},\qquad
 \theta_A^0=r_A\theta_{i(A)}^0.                    \tag{5.2}
\]

One must retain these rows as written. Raising them to \(d_A\) gives the
ordinary packet rows, and inserts all corresponding target phases unless
the primitive target has already been specified.

The target power map

\[
 \pi:(q_A)_A\longmapsto(q_A^{d_A})_A
\]

is finite étale of degree

\[
 \deg\pi=\prod_{A\ne0}d_A.                        \tag{5.3}
\]

There is no additional gcd divisor: the frame has content one and its row
has been omitted, so all mutable target coordinates are independent. The
ordinary packet Gale map is the composite of the primitive packet map
with \(\pi\). On positive factors their domains are the same, and the
annulus radii are rescaled by the corresponding \(d_A\). Therefore

\[
 \deg(\Gamma_{\rm packet}^{\rm ord,+})
 =\left(\prod_{A\ne0}d_A\right)
   \deg(\Gamma_{\rm packet}^{\rm pr,+}).            \tag{5.4}
\]

This is a degree calculation for explicit maps, not formal division of an
integer count. It also explains the phase normalization independently of
the flagged-tree phase quotient.

## 6. Computing the fixed degree by a strong-generic packet perturbation

The fixed base \(\mathcal B^\sigma\) has independent targets for every
packet. Varying their valuations slightly makes the ordinary packet
covector strongly generic while remaining in the same positive cut chamber
and in the full neighborhood of Section 2. Such rational valuation choices
exist because only finitely many proper rational hyperplanes are excluded.

For a strongly generic packet covector, every positive solution has a full
binary collision hierarchy with independent columns. In the anchored
hierarchy coordinates, the initial Gale equations are a finite torus
isogeny. Its determinant is

\[
 \prod_{S=L\sqcup R}|\eta(\gamma_L,\gamma_R)|.
\]

Each initial point is simple and has one Hensel lift. Summing over admitted
hierarchies gives the raw colored packet flow count \(F_\sigma\). It counts
individually labeled parallel-arrow choices, with the actual descendant
projections; it does not use toric cohomology or stable-tree fixed-point
counts.

Finite flatness from Section 4 transports this degree back to
\(q_A=1\). By (5.4), the fixed primitive length is

\[
 \ell_\sigma
 :=\dim_K\mathcal O((\mathcal X_{q=1})^\sigma)
 =\frac{F_\sigma}{\prod_{A\ne0}r_AD_{i(A)}}
 =T_{\lambda(\sigma)}.                            \tag{6.1}
\]

The last equality is the earlier primitive flow normalization. For a binary
node of charges \(\alpha,\beta\), put
\(d(\gamma)=\gcd_j(\widehat D_j\gamma_j)\). Its positive integer weight is

\[
 |\eta(\alpha,\beta)|\,
 \frac{d(\alpha+\beta)}{d(\alpha)d(\beta)}.
\]

The numerator contents telescope over the tree, and the total framed charge
has content one. This gives exactly the denominator in (6.1), separately
for every tree. The whole construction works for \(D=I\) and for general
integral symmetrizers.

## 7. Character, theta coefficient, and actual free orbits

Let

\[
 A_{B,D,g,p}=\mathcal O(\mathcal X_{q=1}).
\]

This is a finite algebra with the natural coordinate action of \(G_p\).
The positive analytic fiber is an open-and-closed finite collection of
isolated full local factors of the algebraic Gale fiber. Indeed a
positive-dimensional algebraic component through one of these points would
give a positive-dimensional analytic germ satisfying the strict positive
inequalities, contrary to finiteness. Its local scheme structures are
unchanged by analytification.

Clear denominators by a common invariant product of actual arrow forms.
Near these factors that product is a unit. The resulting equations form
a polynomial square map with identical coordinate action in source and
target. The fixed-cycle lemma therefore gives

\[
 \operatorname{Tr}(\sigma\mid A_{B,D,g,p})
 =\dim_K A_{B,D,g,p}/(x_v-x_{\sigma(v)})
 =T_{\lambda(\sigma)}.                            \tag{7.1}
\]

The earlier one-frame flow formula is

\[
 a_g^B(p)=
 \sum_{\lambda^i\vdash p_i}
 \frac{(-1)^{|p|-\sum_i\ell(\lambda^i)}}
      {\prod_i z_{\lambda^i}}\,T_{\boldsymbol\lambda},
 \qquad
 z_\lambda=\prod_{k\ge1}k^{m_k(\lambda)}m_k(\lambda)!.
                                                               \tag{7.2}
\]

Combining (7.1) with the elementary conjugacy-class formula yields

\[
 \boxed{a_g^B(p)=
 \dim\operatorname{Hom}_{G_p}
   (\mathrm{sgn}_{G_p},A_{B,D,g,p}).}               \tag{7.3}
\]

Apply the bounded-degree coordinatewise Hermite deformation of
`YOUNG_FIXED_CYCLE_LENGTH_LEMMA.md` to the selected full finite factor.
After extension to an algebraic closure of its deformation field, its
generic fiber is a finite \(G_p\)-set \(\mathcal S_{B,D,g,p}\) of actual
coordinate tuples. The equations, the positivity selection, and the
perturbation specify this set before any coefficient is computed. Its
stabilizers are Young subgroups, determined by the equal-coordinate blocks
within each color.

An orbit contributes one copy of the total sign representation exactly when
every one of these blocks has size one. Equivalently its stabilizer is
trivial. Thus

\[
 \boxed{a_g^B(p)=
 \#\bigl(\mathcal S_{B,D,g,p}^{\rm free}/G_p\bigr).} \tag{7.4}
\]

The trace computation needs the fixed-cycle lemma; the deformation is only
needed to exhibit actual reduced tuple objects and their free orbits.
Equation (7.4) is a positive finite algebraic-point model. It is not a
claim that a particular spanning-tree action has these traces: the natural
stable-tree action can have different fixed counts.

### 7.1 A bounded additive perturbation with no second formal parameter

There is a particularly direct realization of the reduced tuple set. Put
\(a_i=\mu(e_i)/D_i>0\), choose \(N\ge1\), and use

\[
 \Gamma_v^{\rm pr}(x)-T^{-a_i}
       +T^N p_i(x_v)=0,
 \quad
 p_i(z)=\sum_{j=0}^{p_i-1}b_{i,j}z^j,\quad
 \operatorname{val}(b_{i,j})\ge0.                 \tag{7.5}
\]

Here the degree bound uses the clone count \(p_i\); a zero clone count
contributes no polynomial. On the positive locus the right side is

\[
 T^{-a_i}\bigl(1-T^{N+a_i}p_i(x_v)\bigr),
\]

whose parenthesis has valuation zero. Thus exactly the same uniform
valuation window holds for all parameters in the coefficient polydisc.
The strict-interior affinoid argument gives a finite family over that
connected regular polydisc. The family is cut out by \(n\) equations in
\(n\) source coordinates; finiteness makes this a relative complete
intersection, so it is flat. The same argument applies after each fixed
cycle restriction.

The Hermite incidence proof works directly for the regular rational map
\(\Gamma^{\rm pr}-T^{-a}\) on the affine open \(U\). Equality strata are
intersected with \(U\), and evaluation and derivative interpolation remain
surjective. Clearing a common invariant denominator multiplies both the
equations and the perturbation by a unit; at a zero its Jacobian is merely
multiplied by that unit. Therefore the same bound \(\deg p_i\le p_i-1\)
gives a nonempty parameter open set of reduced fibers. Bounded rational
coefficient tuples are Zariski dense, so one can choose such a tuple by
enumeration and exact dimension/Jacobian tests.

With one such choice, \(\mathcal S_{B,D,g,p}\) is simply the positive
solution set of the explicit rational equations (7.5), equivalently of
their saturated polynomial equations. No logarithm, exponential, analytic
critical-point definition, or second deformation variable enters its
definition. The isotypic ranks and all fixed lengths agree with the
unperturbed algebra by the finite flat parameter family.

This is coefficientwise. It does not assert that every formal theta label
in every cluster algebra has finite Laurent support. A finite support
theorem, when available, permits these finite coefficient constructions to
be assembled into the complete Laurent polynomial.

## 8. Rational special algebra and a direct ideal computation

Scale \(\mu\) by a common positive integer so that all exponents
\(\theta_v^0/d_v\) are integers. This does not change any flow admissions.
At the target \(q=1\), clear powers of \(T\) and arrow denominators in
(1.3), and saturate by \(T\prod_e L_e\). Call the resulting quotient
\(C=\mathbb Q[T,x]/J\). In the present cut chamber its entire special
fiber is supported at

\[
 T=0,\qquad x_v=0\text{ for every mutable }v.        \tag{8.1}
\]

Indeed, raise primitive rows to their contents and multiply over any
vertex subset. The resulting ordinary cut relation belongs to the
saturated ideal. At a special-fiber point, partition the vertices into
connected components of the actual arrows whose differences vanish. Every
boundary arrow of one such component is a unit. If the component were
proper, its nonzero cut weight would make the cut relation assert that a
unit equals a positive power of \(T\) times another unit, a contradiction
at \(T=0\). Thus all vertices are in the frame component and all their
coordinates are zero. This is the exact cut argument of
`GALE_FIXED_TARGET_FINITE_FACTOR.md`, Section 2, independently checked here.

Consequently \(C/TC\) is finite-dimensional. Its \(T\)-adic completion is
finite over \(\mathbb Q[[T]]\) by successive basis lifting. Saturation
makes \(T\) a nonzerodivisor, and flatness of completion preserves this;
the completion is therefore finite free. The same argument applies to
\(\prod_eL_e\), making it a unit after inverting \(T\). The completed
generic algebra is exactly the full positive Gale factor, including all
Artin structures. Its special algebra \(A_0=C/TC\) is a finite rational
\(G_p\)-algebra with the same character.

Thus no additional support selection is needed in this cut-generic
framed situation. Outside these hypotheses saturation alone need not
select a positive factor; the proof above must not be omitted.

If \(A_0=\mathbb Q[x]/J_0\), let

\[
 \Delta=\prod_i\prod_{1\le a<b\le p_i}
             (x_{i,a}-x_{i,b}),
 \qquad R=\mathbb Q[x]^{G_p}.
\]

Every alternating polynomial is \(\Delta\) times a symmetric polynomial.
Since taking an isotypic component is exact in characteristic zero,

\[
 A_0^{\mathrm{sgn}}\cong
 R/\bigl((J_0:\Delta)\cap R\bigr)                  \tag{8.2}
\]

as vector spaces, with the map \(h\mapsto\Delta h\bmod J_0\). In the
elementary symmetric generators of \(R\), a Gröbner staircase of this
zero-dimensional quotient has cardinality (7.3). The root branch is
developing the exact finite ideal construction and implementation.

This calculation requires neither root-of-unity choices nor explicit
evaluation of the alternating cycle sum. The finite presentation is
specified from the framed graph. The staircase depends on a chosen monomial
order; no canonical graded basis claim follows from it.

## 9. The precise memory-plane mechanism behind the window

This subsection records the linear algebra used by the companion boundary
proof, including the parallel-child correction.

Let \(E\) be the rational charge space with alternating form \(\eta\).
For a current charge \(S\), a nonzero cut pairing \(\eta(S,A)\) gives
the projection

\[
 P_{S,A}(\ell)=
 \ell-\frac{\ell(A)}{\eta(S,A)}\eta(S,-).          \tag{9.1}
\]

At the root the allowed image is \(\operatorname{ann}(S)\), and this map
surjects onto \(\operatorname{ann}(S,A)\), with one-dimensional kernel.
Thereafter retain a **nondegenerate two-dimensional memory plane** \(P\)
containing the current charge \(S\), and incoming image
\(\operatorname{ann}(P)\). Since \(\eta(S,-)\) does not vanish on \(P\),
it is not in \(\operatorname{ann}(P)\). Hence (9.1) is injective there
and, by dimensions, its image is exactly
\(\operatorname{ann}(S,A)\).

One must not always replace \(P\) by the span of the literal parent and
current charge. After a multifurcation a child can be parallel to its
parent; their span is then only a line. The previous nondegenerate plane
must be retained until the next nonzero projection.

There are finitely many symbolic cut chains. Exclude the kernels of all
nonzero rational functionals
\(\mu\mapsto\ell_{\rm current}(A)\) at their zero-pairing cuts; earlier
parallel cuts are skipped as below. At a feasible zero-pairing cut,
genericity then forces its child charge \(A\) into the annihilator of the
entire incoming covector image. At a nonroot node this says

\[
 A\in P\cap S^{\perp_\eta}=\mathbb Q S.
\]

At the root it says the same directly. Positivity of the charges gives
\(A=\lambda S\) with \(0<\lambda<1\). Such a root cut is impossible
because the root has frame coefficient one, so a proper parallel child
would have a nonintegral frame coefficient.

For a mutable-only parallel cut, do **not** treat its undetermined depth as
a new free covector parameter. If its children are \(A=\lambda S\) and
\(B=(1-\lambda)S\), then

\[
 v_S|_A=\lambda^{-1}v_A,
 \qquad
 v_S|_B=(1-\lambda)^{-1}v_B.                       \tag{9.2}
\]

Absorb its positive depth into the two child depths with these positive
factors, remove the zero-pairing node, and keep the incoming memory plane.
The effective child depths remain positive. The next nonzero split is
again governed by (9.1). If all subsequent cuts are parallel down to the
leaves, every leaf charge is on one original coordinate ray, and the whole
cluster has no actual arrows.

Apply the same absorption to a nonnegative recession vector. At a first
node with positive effective recession depth, a nonzero cut would force
that increment to vanish by its cut equation. A zero cut passes positive
increments to its children. Therefore a positive recession can persist
only in clusters whose leaves all have one original color, which contain
no actual arrows. This is the intended proof of (2.2), with synthetic
zero-depth binary refinements included. The companion branch is checking
the global hierarchy bookkeeping and exact linear-programming tests.

## 10. Primary-source audit and prior-work comparison

1. **Temkin, Introduction to Berkovich analytic spaces**, 2010 lecture
   notes, Definition 3.4.9 and Fact 3.4.11(iv): a presentation in a relative
   closed polydisc is interior where all its coordinate bounds are strict;
   an affinoid morphism with empty relative boundary is finite.
   <https://berkovich-2010.imj-prg.fr/lecture-notes/Temkin-lecture-notes.pdf>.
   The exact definitions and criterion were read in the primary author
   text, pp. 17–18. This is the precise analytic input to Section 3.
2. **Stacks Project, Tag 00R4**, miracle flatness.
   <https://stacks.math.columbia.edu/tag/00R4>.
   The regular-base/Cohen–Macaulay-source dimension criterion was read
   directly. Its finite equal-dimensional application is used separately
   for the whole family and each fixed-cycle family.
3. **Tang, Hexagon 2611.00238v1, Lemma 6.1**, pp. 16–17.
   <https://hexagonmath.org/pdf/2611.00238v1>.
   The complete proof was independently checked in the companion note.
   Only its elementary square-map deformation mechanism is used. The
   broader 2026 generalized-cluster conclusions are not proof inputs.
4. **Earlier own work.** Primitive cycle normalization, the one-frame
   reduction, the signed cycle formula, and local square-map deformations
   already occur in the user's previous package. The new candidate is the
   single arbitrary-graph positive Gale factor together with the invariant
   valuation-window theorem and its all-cycle identification. The
   coprime tight/toric Young representation from
   `TIGHT_TORIC_YOUNG_MODULE.md` is an own-prior-plus-BLM corollary and has no
   novelty claim here.

The restriction to generic original-color \(\mu\) is substantive. The
cyclic three-vertex example at \(\theta_i=1\) can lose all solutions at
the unit target despite a nonzero generic-target count; that covector is
nongeneric in its original-color parameter space. No unconditional
all-target statement at an arbitrary invariant covector is asserted.
