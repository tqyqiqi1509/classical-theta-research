"""Literal tree phase transport: CRT, leaf gcd elimination, and inverse.

No cardinality matching, rank/unrank, or coefficient oracle is used.
"""
from itertools import product
from math import gcd, lcm, prod
from functools import reduce
from pathlib import Path
from random import Random
from time import time
import json

def crt(a,r,b,s):
 g=gcd(a,b)
 assert (s-r)%g==0
 mod=b//g
 k=0 if mod==1 else ((s-r)//g*pow(a//g,-1,mod))%mod
 return (r+a*k)%lcm(a,b)

def incidence(edges,n):
 adj=[[] for _ in range(n)]
 for e,(u,v) in enumerate(edges):adj[u].append((e,1));adj[v].append((e,-1))
 return adj

def net(t,edges,c):
 b=[0]*len(c)
 for x,(u,v) in zip(t,edges):b[u]+=x;b[v]-=x
 return tuple(x%m for x,m in zip(b,c))

def section(edges,c,b):
 """A specified section of finite cyclic incidence, by leaf elimination.

At a leaf v adjacent to p replace the modulus of p by gcd(c_v,c_p)
and its target by b_p+b_v. Then reconstruct edge phases with CRT.
"""
 n=len(c);g_all=reduce(gcd,c);assert sum(b)%g_all==0
 adj=incidence(edges,n);active=set(range(n));mod=list(c);rhs=[x%m for x,m in zip(b,c)]
 alive=set(range(len(edges)));records=[]
 while len(active)>1:
  v=min(v for v in active if sum(e in alive for e,s in adj[v])==1)
  e,sv=next((e,s) for e,s in adj[v] if e in alive)
  u,w=edges[e];p=w if v==u else u
  other=tuple((f,s) for f,s in adj[p] if f in alive and f!=e)
  records.append((e,v,p,sv,mod[v],rhs[v],mod[p],rhs[p],other))
  g=gcd(mod[v],mod[p]);mod[p]=g;rhs[p]=(rhs[p]+rhs[v])%g
  active.remove(v);alive.remove(e)
 root=next(iter(active));assert mod[root]==g_all and rhs[root]==0
 t=[0]*len(edges)
 for e,v,p,sv,a,bv,bpmod,bprhs,other in reversed(records):
  S=sum(s*t[f] for f,s in other)
  rv=sv*bv%a
  rp=(-sv*(bprhs-S))%bpmod
  t[e]=crt(a,rv,bpmod,rp)
 assert net(t,edges,c)==tuple(x%m for x,m in zip(b,c))
 return tuple(t)

def forward(alpha,edges,c):
 ds=[];t=[];b=[0]*len(c)
 for e,(u,v) in enumerate(edges):
  g=gcd(c[u],c[v]);d=(alpha[v,e]-alpha[u,e])%g;ds.append(d)
  t.append(crt(c[u],alpha[u,e],c[v],(alpha[v,e]-d)%c[v]))
  b[v]+=d
 s=section(edges,c,b)
 k=tuple((x-y)%lcm(c[u],c[v]) for x,y,(u,v) in zip(t,s,edges))
 assert not any(net(k,edges,c))
 assert sum(ds)%reduce(gcd,c)==0
 return tuple(ds),k

def inverse(value,edges,c):
 ds,k=value;b=[0]*len(c)
 assert sum(ds)%reduce(gcd,c)==0
 for d,(u,v) in zip(ds,edges):b[v]+=d
 s=section(edges,c,b);alpha={}
 for e,((u,v),d,x,y) in enumerate(zip(edges,ds,k,s)):
  t=(x+y)%lcm(c[u],c[v]);alpha[u,e]=t%c[u];alpha[v,e]=(t+d)%c[v]
 for v,row in enumerate(incidence(edges,len(c))):assert sum(sign*alpha[v,e] for e,sign in row)%c[v]==0
 return alpha

def balanced(edges,c):
 adj=incidence(edges,len(c));free=[]
 for v,row in enumerate(adj):
  for e,s in row[1:]:free.append((v,e))
 for vals in product(*(range(c[v]) for v,e in free)):
  alpha=dict(zip(free,vals))
  for v,row in enumerate(adj):
   if not row:continue
   e,sg=row[0]
   alpha[v,e]=(-sg*sum(s*alpha[v,f] for f,s in row[1:]))%c[v]
  yield alpha

def tree_from_prufer(seq):
 n=len(seq)+2;degree=[1]*n
 for x in seq:degree[x]+=1
 es=[]
 for x in seq:
  v=next(i for i,d in enumerate(degree) if d==1)
  es.append((v,x));degree[v]-=1;degree[x]-=1
 u,v=[i for i,d in enumerate(degree) if d==1];es.append((u,v))
 return tuple(es)

def run():
 start=time();rng=Random(923147);cases=0;maps=0;section_checks=0;max_modulus=0;max_fiber=0;noncoprime=0
 def check(edges,c):
  nonlocal cases,maps,section_checks,max_modulus,max_fiber,noncoprime
  g=reduce(gcd,c)
  if g>1:noncoprime+=1
  cases+=1;seen=set()
  for alpha in balanced(edges,c):
   value=forward(alpha,edges,c)
   assert inverse(value,edges,c)==alpha
   assert value not in seen;seen.add(value);maps+=1
  max_fiber=max(max_fiber,len(seen))
  gproduct=prod(gcd(c[u],c[v]) for u,v in edges)
  kernsize=g*prod(lcm(c[u],c[v]) for u,v in edges)//prod(c)
  assert len(seen)==gproduct//g*kernsize
  for j in range(3):
   b=[rng.randrange(m) for m in c];b[-1]=(b[-1]-sum(b)%g)%c[-1];b=tuple(b);s=section(edges,c,b)
   assert net(s,edges,c)==b;section_checks+=1
  max_modulus=max(max_modulus,max(c))
 for n in range(2,5):
  for seq in product(range(n),repeat=n-2):
   edges=tree_from_prufer(seq)
   for c in product(range(1,5),repeat=n):check(edges,c)
 for n,trials in [(5,180),(6,100),(7,50),(8,20)]:
  for _ in range(trials):
   edges=tree_from_prufer(tuple(rng.randrange(n) for _ in range(n-2)))
   edges=tuple((u,v) if rng.randrange(2) else (v,u) for u,v in edges)
   c=tuple(rng.randrange(1,8) for _ in range(n));check(edges,c)
 for _ in range(30):
  n=5;edges=tree_from_prufer(tuple(rng.randrange(n) for _ in range(n-2)))
  c=tuple(2*rng.randrange(1,8) for _ in range(n));check(edges,c)
 # Large arbitrary trees exercise the section independently of tiny fibers.
 for _ in range(1000):
  n=rng.randrange(2,41);edges=tree_from_prufer(tuple(rng.randrange(n) for _ in range(n-2)))
  c=(1,)+tuple(rng.randrange(1,1001) for _ in range(n-1));b=tuple(rng.randrange(m) for m in c)
  assert net(section(edges,c,b),edges,c)==b;section_checks+=1
 result={'all_pass':True,'tree_modulus_cases':cases,'noncoprime_cases':noncoprime,'literal_forward_inverse_checks':maps,'compatible_section_checks':section_checks,'max_vertex_modulus_exhaustive':max_modulus,'max_literal_fiber':max_fiber,'large_section_tree_vertices':40,'large_section_vertex_modulus':1000,'seconds':time()-start}
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':run()
