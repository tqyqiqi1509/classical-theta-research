# Wall functions and theta multiplication on a common complex domain

2026-11-13. Classical cluster scattering with principal coefficients.

## 0. Status and the one declared quantitative input

The deductions in this note are proved below. They use the uniform theta
coefficient estimate being independently reviewed in
`notes/ANALYTIC_CONVERGENCE_CANDIDATE.md`:

    0 <= a_{g,Q}(p) <= (G+C |p|)^{|p|}/product_i p_i!,   p!=0,   (0.1)
    G=max_i |g_i|,      C=max(1,max_ij |B_ij|).

The endpoint Q is arbitrary generic; no endpoint appears in the bound.
The estimate comes from the global free-Young-orbit model, a bounded-degree
same-color perturbation, and isolated affine Bezout. This note does not
replace that audit. Its conclusions become unconditional once that input
is accepted. Novelty against prior analytic scattering literature is a
separate ongoing review; no priority assertion is made here.

Write z_i=y_i x^{B e_i}, so a theta expansion has the form

    theta_{Q,g}=x^g F_{Q,g}(z),
    F_{Q,g}(z)=sum_{p>=0} a_{g,Q}(p) z^p.

The common complex domain below is expressed in these degree variables z.
In principal torus coordinates it is the domain with
sum_i |y_i x^{B e_i}| below the stated constant. This distinction keeps the
mutable Laurent factors in the convergence statement.

## 1. A single bend detects every wall-germ coefficient

Let n in N^r\{0} be primitive, let d(n)=gcd_i(D_i n_i), and set

    u=Dn/d(n),            m=|n|.

Thus u is the primitive integral normal in mutable exponent coordinates.
At a general point v in a wall supported on u-perp, combine all walls
through v with that normal into the intrinsic local wall function

    f_v(z)=1+sum_{k>=1} c_k z^{kn}.                       (1.1)

Use a positive representative of the classical cluster scattering diagram,
so c_k>=0. The local product is well-defined degree by degree. It is more
intrinsic than a choice of subdivision of the wall support.

**Single-bend lemma.** For every i with u_i>0 and every k>=1, there is a
generic endpoint Q (depending on i,k) such that

    a_{-e_i,Q}(kn) >= [z^{kn}] f_v(z)^{u_i} >= u_i c_k.  (1.2)

**Proof.** Work first through total degree k|n|, where only finitely many
walls matter. Move v slightly within its relative wall germ if needed to
avoid their joints and boundaries. Take initial exponent g=-e_i. The
incoming ray approaches v from v+t g, t>0, with velocity -g. At every
earlier crossing select the constant term, so the attached monomial is
unchanged.

At v, the primitive normal chosen against the path direction is -u.
Its pairing with g is u_i>0. Therefore the bending rule multiplies the
attached monomial by f_v^{u_i}, never by its inverse. Select its degree kn
term. The outgoing mutable exponent is

    g+B(kn).

Since u dot Bn=0, the incoming and outgoing velocities have the same
nonzero normal component. For sufficiently small delta>0, choose

    Q_mut=v_mut-delta(g+B(kn)).                         (1.3)

The short final segment is on the crossed side and can be made generic.
The map (v,delta) -> Q_mut is locally open because its delta direction is
transverse to the wall. Hence the endpoint can also avoid any prescribed
finite set of coefficient-computation or rank-generic hyperplanes.

In the full principal exponent space the exponents are (g,0) and
(g+B(kn),kn). Thus this is a genuine bend even when Bn=0; the frozen
component changes. The wall has frozen lineality, so the frozen component
of v and the endpoint can be chosen accordingly. Higher-order walls do
not affect the coefficient under consideration. Equivalently, a generic
small perturbation realizes the same finite-degree broken line in the
full diagram.

The selected broken line contributes the coefficient of f_v^{u_i} to
theta_{Q,-e_i}. All other contributions are nonnegative. Finally, choosing
the c_k term from one of the u_i factors and the constant term from the
others gives [z^{kn}]f_v^{u_i}>=u_i c_k. This proves (1.2).

The orientation and the positivity used here are exactly those in
Gross--Hacking--Keel--Kontsevich, *Canonical bases for cluster algebras*,
Remark 1.27, Theorem 1.28, Definition 3.1 and Remark 3.2. The author-hosted
primary PDF was read directly:
<https://paulhacking.github.io/canonicalbases.pdf>.
Their wall-crossing normal pairs negatively with path velocity; the
broken-line exponent is the negative of that velocity. The resulting
bending power is positive. The displayed estimate (1.2) is the deduction
made here from those definitions.

## 2. Explicit exponential bounds for every wall function

Put A=exp(1/C). Applying (0.1) to g=-e_i in (1.2) gives

    [z^{kn}]f_v^{u_i}
      <= (1+Ckm)^{km}/product_j(kn_j)!,                  (2.1)

and hence

    c_k <= (1+Ckm)^{km}/(u_i product_j(kn_j)!).           (2.2)

One may choose i maximizing u_i in the latter estimate. Using
j!>=(j/e)^j and (1+1/(Ckm))^{km}<=exp(1/C), this gives the pure
exponential estimate

    c_k <= A/u_i * R_n^{-k},
    R_n = product_{j:n_j>0} n_j^{n_j}/(e C m)^m.          (2.3)

Thus the one-variable series f_v(w)=1+sum c_k w^k converges whenever
|w|<R_n. In particular it converges throughout

    Omega_B={z in C^r : sum_i |z_i| < 1/(e C)}.          (2.4)

Indeed weighted arithmetic-geometric mean gives
|z^n| <= (sum |z_i|)^m product_j(n_j/m)^{n_j}<R_n.

There is a useful bound uniform in the normal, the wall germ, and D. Put

    q=e C sum_i |z_i| < 1.

For every i with u_i>0, (2.1) and the multinomial theorem imply

    |f_v(z)^{u_i}-1| <= A q^m/(1-q^m),                  (2.5)
    |f_v(z)-1| <= A q^m/(u_i(1-q^m)).                   (2.6)

To check the summation, set N=km. Then
(1+CN)^N <= A(CN)^N <= A(eC)^N N!, and
N! product_j |z_j|^{kn_j}/product_j(kn_j)!
is at most (sum |z_j|)^N. Summing over k gives (2.5)--(2.6).

The coordinate-factor estimate (2.5) is stronger than first bounding f_v
and then raising it to u_i: it has no factor growing with u_i. If u_i=0,
the corresponding coordinate factor is exactly one.

On the smaller common domain

    q < 1/(1+A),                                       (2.7)

every f_v and every coordinate factor f_v^{u_i} is nonzero, because its
distance from 1 is less than 1. Thus all individual wall transformations
and their inverses have holomorphic definitions there. The branch of the
logarithm with constant term zero is well-defined and obeys

    |log(f_v^{u_i})|
       <= -log(1-A q^m/(1-q^m)).                       (2.8)

This is a common domain of definition. The ball (2.7) need not be preserved
by every wall transformation; controlling compositions requires a separate
domain-drift argument. No inference about arbitrary infinite path products
is hidden in (2.7).

## 3. A coefficient majorant retaining the same radius for all products

Fix k labels g_1,...,g_k, and put

    G_l=max_i |(g_l)_i|,       A_l=exp(G_l/C),
    B_l(q)=1+A_l q/(1-q).

For every generic endpoint Q, (0.1) gives the coefficientwise majorant

    F_{Q,g_l}(z) <=_coeff B_l(e C sum_i z_i),             (3.1)

where <=_coeff compares nonnegative coefficients. The degree-zero term is
one. For degree n>0, use (G_l+Cn)^n<=A_l(Cn)^n and n^n<=e^n n!.

Let m(g_1,...,g_k;p) be the coefficient of y^p theta_h in the formal
principal theta product, with h=sum_l g_l+Bp. The signed-endpoint theorem
in `SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md` expresses this coefficient
as the convolution at one endpoint selected for p. That endpoint may
depend on p, but (3.1) is independent of it. Consequently

    sum_p m(g_1,...,g_k;p) t^p
      <= product_{l=1}^k B_l(q),
    q=e C sum_i t_i <1,     t_i>=0.                      (3.2)

Thus the generating series of structure coefficients has the same common
domain Omega_B for every fixed finite number k of inputs. There is no
factor k in the exponential radius.

Here is an explicit homogeneous bound. For n=|p|>0, expansion of
product_l(1+A_l q/(1-q)) gives

    m(g_1,...,g_k;p)
      <= (n!/product_i p_i!)(e C)^n
          sum_{j=1}^{min(k,n)} e_j(A_1,...,A_k) binom(n-1,j-1),     (3.3)

where e_j is the elementary symmetric polynomial. A simpler bound is

    m(g_1,...,g_k;p)
      <= exp((sum_l G_l)/C)(e C)^n
           (n!/product_i p_i!) binom(n+k-1,k-1).         (3.4)

The additional factor is polynomial in n when k is fixed. Inequality
(3.2), rather than an unnecessarily coarse k^n estimate, is the useful
analytic conclusion.

## 4. The full theta-basis multiplication series converges on that domain

Fix one generic endpoint Q throughout this section. The formal principal
theta multiplication identity is

    product_l F_{Q,g_l}(z)
       =sum_{p>=0} m(g_1,...,g_k;p) z^p
                         F_{Q,sum_l g_l+Bp}(z).          (4.1)

Every coefficient on both sides is nonnegative. For t_i>=0 with
q=e C sum t_i<1, Tonelli's theorem and equality of the formal coefficients
give

    sum_p m(g_1,...,g_k;p) t^p F_{Q,sum_l g_l+Bp}(t)
       =product_l F_{Q,g_l}(t)
       <=product_l B_l(q)<infinity.                     (4.2)

For complex z the absolute value of each term of (4.1) is bounded by its
value at t_i=|z_i|. Thus the actual theta-basis expansion, including the
varying output theta functions, is absolutely convergent on Omega_B and
equals the analytic product there.

This avoids a misleading separate estimate of the growing output label
sum_l g_l+Bp, which would artificially shrink the convergence radius.

There is also an explicit tail estimate. For q<rho<1,

    sum_{|p|>=N} m(g_1,...,g_k;p) |z|^p
                     |F_{Q,sum_l g_l+Bp}(z)|
      <= (q/rho)^N product_l B_l(rho).                  (4.3)

Indeed every term indexed by |p|>=N contributes only to total degrees
at least N, and those coefficients are bounded by the same-degree tail
of the product majorant in (3.1). The elementary positive-series estimate
sum_{n>=N} b_n q^n <= (q/rho)^N sum_n b_n rho^n proves (4.3).

For a compact K inside Omega_B, replace q by its maximum q_K<1 and choose
rho in (q_K,1). This gives uniform absolute tails. Moreover each individual
term is bounded on K by product_l B_l(rho)(q_K/rho)^{|p|}; summing these
bounds over all p gives product_l B_l(rho)(1-q_K/rho)^{-r}. Hence the
series is locally normally convergent in the usual holomorphic sense.

The same argument works for every fixed finite k. It establishes genuine
complex analytic multiplication, while leaving open finite Laurent
support for arbitrary labels. Infinite convergent expansions are allowed.

## 5. What is and is not proved here

The wall estimate uses an explicit single-bend construction with the
correct positive exponent and a generic endpoint. It is not an unsupported
coefficient comparison between unrelated charts. The same constant C works
for skew-symmetric and skew-symmetrizable classical data, independently of
the numerical size of D.

The product estimates control both the scalar structure-coefficient series
and the full varying-theta output expansion. They require no new finite
Laurent-support theorem and do not assert that the dimension algebras are
Newton polytopes.

All quantitative conclusions depend on (0.1); its Bezout and perturbation
audits remain explicitly separate. Prior-literature comparison must be
completed before calling these analytic consequences new.
