# Route and audit record for the Dyck/Gale interface branch

Classical cluster data only. This compact record points to the full proofs
and exact computations in this directory; it does not replace them.

## Tight gradings and toric cohomology

The natural action on ordinary stable trees fails to have the required
Young fixed counts already for the complete bipartite (2,3) example. Root
deletion and direct mass-greedy allocation also failed; their scripts and
JSON outputs remain present. These failures were not treated as a solution
to the general construction problem.

The replacement interface is the cohomology representation and an explicit
orbit-tree finite phase kernel. `TIGHT_TORIC_YOUNG_MODULE.md` and
`CYCLIC_TORIC_TRACE_EXTENSION.md` contain the general trace calculation,
including semiprojective directed graphs. `tree_phase_transport.py` gives
the constructive CRT/leaf-section bijection, with 4,684 tree/content cases
and 364,688 forward/inverse checks in its saved receipt.

**Novelty correction:** the tight Young-permutation-module identification
is not claimed new. The user's Hexagon 2610.00587v1 Theorem 2.1 already
supplies the universal cohomology/Frobenius interface; its classical limit,
the alphabet involution, and the BLM coefficient formula give this
identification. The full overlap and normalization are recorded in
`TIGHT_TORIC_YOUNG_MODULE.md`, Section 8. The direct trace/phase proof remains
useful, but is not marketed as a new cohomology correspondence.

## General Young characters and global Gale factors

`YOUNG_FIXED_CYCLE_LENGTH_LEMMA.md` proves equality between the coordinate
permutation trace and the length of the fixed **subscheme**, not the
invariant ring. The equal source/target coordinate action and the separate
fixed-family flatness proof are indispensable. The bounded Hermite
perturbation already occurs in the user's old work and in Tang
2611.00238v1 Lemma 6.1; that lemma's primary proof was read and audited,
without importing other 2026 claims.

The tempting assertion of uniform all-target degree at every cut-generic
covector is false. The directed triangle with one root arrow at each
vertex and theta=(1,1,1) has saturated degree 4 for targets (2,3,5), but
degree 0 for targets (1,1,1). The corrected theorem selects a generic
original-color covector using finite rank conditions. The independent
rank-recession proof in
`../global_gale_adversarial/RANK_GENERICITY_AND_RECESSION.md` was read in
full and checked. Its auxiliary positive covector does not constrain the
signs of the actual selected endpoint.

`GALE_YOUNG_THETA_DEGREE_THEOREM.md` assembles the full-target annulus,
fixed-target base change, primitive cycle degree, character identity, and
free Young orbit model. Its former conditional-window status was updated
after the independent rank-recession proof passed review. The special
T=0 algebra is wholly supported at the origin under cut genericity;
no unnecessary residual-center localization remains in the current text.

## Independent valued computations

Twenty two-packet ideal computations, including D=(2,3), (4,6), (6,10),
(2,2), (3,6), cycles of lengths 2 and 3, common contents, and zero framing
entries, agree with the independent IncomingSchur cycle values. SymPy and
the Wolfram computation plugin independently produced the same saturated
special lengths and Gröbner ideals. The reproducible scripts, exact data,
and raw Wolfram output are `primitive_two_packet_checks.py/.json` and
`wolfram_two_packet_checks.wl`, `wolfram_two_packet_output.txt`.

The D=(2,3), p=(2,1), g=(-2,1) full character check gives identity length
12, transposition length/trace 6, hence theta coefficient (12-6)/2=3.
The corresponding g=(-2,-1) check gives 20,10, and 5. Several optional
higher-dimensional Gröbner runs timed out; they are retained as incomplete
computations, not failures of an equality or successful certifications.
Further special-example work stopped when the general signed-endpoint
extension became the priority.

## Signed endpoints and direct product algebras

`SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md` proves the mixed-sign extension
with **both** cut and rank genericity. Signed rows are
T^[a_i]_+ A_i-T^[-a_i]_+ E_i. The additive perturbation needs
N>max(-a_i), a genuine correction to the positive-only shortcut N>=1.

The old arbitrary-endpoint and dual-coefficient proof in
`TWO_FRAME_INDEPENDENT_REVIEW.md`, Sections 2 and 6, was reread. A finite
choice a=Lh+e simultaneously avoids all required rank rows, keeps every
proper cut nonzero, and makes every nonzero dual root event time negative.
This yields a finite direct-sum/tensor-product Q algebra for every fixed
finite-arity structure coefficient. The implementation's parameter choice
was checked line by line against that proof. This extends the new global
model; it is not a priority claim for the old dual coefficient functional.

## Analytic consequences

Root's candidate Bezout bound gives an endpoint-uniform coefficient
majorant. The deductions in
`WALL_AND_MULTIPLICATION_ANALYTIC_BOUNDS.md` and
`ANALYTIC_PATH_ORDERED_PRODUCTS.md` are explicitly conditional on that
quantitative input until its independent audit is accepted.

A direct primary-source check of GHKK Remark 1.27, Theorem 1.28, Definition
3.1, and Remark 3.2 verified the bending orientation. A one-bend theta
object with label -e_i dominates each coefficient of the positive local
wall factor raised to the primitive coordinate normal u_i. This yields
uniform exponential wall bounds, including bounds on the coordinate
factors independent of the magnitude of D or u.

The path-product proof then controls logarithmic domain drift and sums
derivatives over root normals. It proves a quantitative common domain for
all generic paths with a fixed number of straight segments; it does not
assume a common ball is invariant under every map. Theta structure
coefficients and the full varying-output theta expansion converge on the
original theta domain by convolution and positivity/Tonelli, with explicit
geometric tails.

The literature branch is comparing these conclusions with
Kontsevich--Soibelman 2005.10651v3, Weist's Kronecker bounds, and the user's
old rank-two exponential estimate. Those preliminary comparisons are not
proof inputs here. Analytic factorization and rank-two exponential growth
are prior subjects. Any eventual novelty claim must concern the stated
arbitrary-rank, cyclic, valued, quantitative scope, and must not claim to
answer KS Question 3.8.4 for arbitrary analytic stability data.
