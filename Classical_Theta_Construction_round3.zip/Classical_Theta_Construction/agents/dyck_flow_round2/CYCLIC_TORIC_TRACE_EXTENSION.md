# Orbit-tree phase characters for arbitrary cyclic quivers

2026-11-13, continuation of `TIGHT_TORIC_YOUNG_MODULE.md`.

The acyclicity hypothesis in Theorem B can be removed. This extends the actual
positive phase character formula to the raw stable-tree object in the cyclic
problem. It does not identify a non-equivariant sweep with an equivariant
cohomology isomorphism.

## Theorem C

Let (Q) be a finite connected directed multigraph, with directed cycles,
opposite arrows, and loops allowed. Let \(\theta\) be a generic rational
netflow of total zero, meaning \(\theta(S)\ne0\) for every nonempty proper
vertex subset. Suppose its nonnegative flow polyhedron is nonempty. Let
\(\sigma\) be a finite-order quiver automorphism preserving \(\theta\).

For each vertex orbit write (c_v=|v|), for each arrow orbit write (L_e=|e|),
and put \(\bar\theta_v=c_v\theta(v)\). Form the quotient multigraph with one
edge per arrow orbit. Retain opposite edges and parallel edges. Quotient loops
are permitted in the graph, but cannot be selected in a spanning tree.

The thin stable quiver moduli space (X_{Q,\theta}) is smooth semiprojective,
and

\[
 \operatorname {Tr}(\sigma\mid H^*(X_{Q,\theta};\mathbb Q))
 =\sum_{T\in\mathscr S(Q/\sigma,\bar\theta)}
 \left|\ker\left(\bigoplus_{e\in T}\mathbb Z/L_e
             \longrightarrow\bigoplus_v\mathbb Z/c_v\right)\right|
 =\sum_T\frac{\prod_{e\in T}L_e}{\prod_vc_v}.                  \tag{C.1}
\]

The map is signed incidence modulo the vertex orbit lengths. The gcd of all
vertex orbit lengths is one, so it is surjective on each quotient tree. Every
summand is therefore the cardinality of an explicit finite phase kernel.

If the flow polyhedron is empty, both sides are zero. For generic real theta,
choose a rational theta in the same chamber and in the sigma-fixed subspace;
the finite open rational inequalities make this possible, and neither side
changes. Thus the result also supplies the character attached to a real chamber.

## 1. Why the variety is smooth semiprojective

The effective gauge torus \((\mathbb C^*)^{Q_0}/\mathbb C^*\) acts on
\(\mathbb A^{Q_1}\), with weights the incidence columns. Genericity makes
semistability equal stability. A stable support is connected, so its gauge
stabilizer is exactly the diagonal before passing to the effective torus.
Consequently the quotient is smooth. Equivalently, every maximal minor of a
spanning-tree incidence matrix is unimodular.

The GIT quotient is projective over the affine invariant quotient. The flow
polyhedron is pointed because it lies in a nonnegative orthant, so a nonempty
one has a vertex. Genericity makes every vertex support a spanning tree with
strictly positive tree flow, hence the quotient has torus fixed points.

These are precisely the semiprojective toric varieties of Hausel–Sturmfels,
*Toric Hyperkähler Varieties*, Documenta Mathematica 7 (2002), Theorem 2.6.
The general semiprojective toric setup is in Section 2, before their special
Lawrence/hyperkähler constructions. No doubled-quiver or symplectic hypothesis
is imposed in that section.

Their Proposition 2.11 gives the ordinary integral cohomology presentation and
proves it using a **filtrable Białynicki–Birula decomposition into affine
spaces**. In particular both ordinary and compactly supported cohomology are
finite dimensional and concentrated in even degrees. The cells need not be
permuted by \(\sigma\); that is not used.

The original positive-flow hypothesis is automatic when generic theta has a
nonempty flow polyhedron. Indeed, start at a positive stable-tree vertex, add
a sufficiently small positive flow on every other edge, and correct its
netflow on the tree. The correction preserves positivity on the tree. Loops
can be added independently. This also gives the dense torus orbit of the
quotient.

## 2. Compact-support versus ordinary characters

Let (d=\dim_{\mathbb C}X\). For a finite-order algebraic automorphism, the
compactly supported Lefschetz formula gives

\[
 \sum_i(-1)^i\operatorname {Tr}(\sigma\mid H_c^i(X;\mathbb Q))
 =\chi_c(X^\sigma).                                             \tag{C.2}
\]

This can be obtained by a finite equivariant algebraic triangulation; it does
not require projectivity. The holomorphic automorphism preserves the complex
orientation, so equivariant Poincaré duality identifies

\[
 H_c^{2d-i}(X;\mathbb Q)\simeq H^i(X;\mathbb Q)^*,
\]

where the dual action has trace \(\operatorname {Tr}(\sigma^{-1}|H^i)\).
All the representations are defined over \(\mathbb Q\). For a finite-order
operator their character is real, and the inverse eigenvalues are the complex
conjugates. Hence

\[
 \operatorname {Tr}(\sigma^{-1}|H^i)
 =\operatorname {Tr}(\sigma|H^i).
\]

There is no odd cohomology by Section 1. Thus (C.2) is exactly the ungraded
ordinary trace on the left of (C.1). This is the required justification; one
must not silently replace ordinary trace by compact-support trace for an
arbitrary noncompact space.

## 3. The toric orbit calculation survives unchanged

An invariant support (H\subset Q) has torus stratum

\[
 O_H=(\mathbb C^*)^{H_1}/((\mathbb C^*)^{Q_0}/\mathbb C^*).
\]

The all-one point is sigma fixed. Its character lattice is the integral cycle
lattice of (H), and the sigma-fixed dimension is

\[
 |H_1/\sigma|-|Q_0/\sigma|+1.
\]

A positive-dimensional fixed torus has compactly supported Euler
characteristic zero. Thus only supports with quotient a tree contribute.
For them the cycle-incidence sequence gives

\[
 |O_H^\sigma|
 =\lim_{q\to1}(1-q)
   \frac{\prod_{e\in H_1/\sigma}(1-q^{L_e})}
        {\prod_{v\in Q_0/\sigma}(1-q^{c_v})}
 =\frac{\prod_eL_e}{\prod_vc_v}.
\]

An original oriented cycle can certainly be present in (Q). It is simply
absent from any support whose quotient is a tree; some other supports still
contribute zero Euler characteristic. No operation cancels opposite arrows.
An original or quotient loop likewise cannot belong to a contributing tree.

Positive quotient flows lift by dividing each total orbit flow by (L_e),
and invariant positive flows descend by summing over each orbit. As before,
genericity forces the lifted support to be connected. This completes the proof.

## 4. Interface with cyclic signed flow trees

For fixed sigma, replace each arrow orbit by (L_e) individually colored
parallel arrows. The raw weighted stable-tree count is then
\(\sum_T\prod_{e\in T}L_e\). Division by \(\prod_vc_v\) has the literal phase
kernel interpretation (C.1). A framing vertex fixed by sigma has (c_0=1\),
which is a particularly direct source of the required gcd-one property.

This allows the existing primitive-phase construction to realize each value of
the **correct cohomology character** on a folded graph. It does not justify
using the natural permutation action on the original stable-tree set: that
action gives a different character in general.

For the cyclic sweep identity (H_\theta=F_\theta\circ R\), a representation
level lift still requires appropriate cohomology or chain objects for the
residual factor (R\). The existing set bijection uses auxiliary orders and is
not equivariant under clone permutations. Therefore the representation identity
cannot be inferred from equality of ordinary cardinalities. A useful next
interface is a natural equivariant flag/bar complex or a cohomological
stratification whose alternating character is the signed hierarchy formula.

## 5. Primary audit

Primary published text inspected: Hausel–Sturmfels,
<https://ftp.gwdg.de/pub/misc/EMIS/journals/DMJDMV/vol-07/16.pdf>.
Theorem 2.6 identifies generic affine-torus GIT quotients with semiprojective
toric orbifolds. The proof surrounding equations (8)–(11) establishes
filterability, and Proposition 2.11 explicitly identifies the smooth cells
with affine spaces and derives the cohomology presentation. The incidence
unimodularity and stable-support connectedness give smoothness in the present
application. These are established 2002 results, not a novelty claim.

The newly assembled formula (C.1), its finite phase objects, and the tight Young
module comparison are the interfaces retained for the current project. No
unreviewed 2026 theorem is used.

