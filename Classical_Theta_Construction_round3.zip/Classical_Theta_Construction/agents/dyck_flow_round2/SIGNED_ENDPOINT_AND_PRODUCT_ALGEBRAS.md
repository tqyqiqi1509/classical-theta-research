# Signed endpoints and finite algebras for theta multiplication

2026-11-13. Classical skew-symmetric and skew-symmetrizable cluster data.

## 0. Result and exact scope

The graph-Gale coefficient construction extends to endpoint covectors with
mixed signs. It needs two separate finite conditions: **cut genericity**
and **rank genericity**. Positivity of the mutable covector values is not
needed. Positivity of the leaf charges in the original coordinate basis is
still used, and is automatic for the clone construction.

Consequently every fixed principal theta structure coefficient, including
every finite-arity product coefficient, is the dimension of a finite
rational algebra obtained as a finite direct sum of tensor products of the
monic-Q coefficient algebras. The construction reads only the exchange
matrix, labels, output degree, and explicit rational polynomial operations.
It does not first compute the desired coefficient or intermediate product
coefficients. The algebraic compression itself is standard invariant
theory; the global cyclic finite-factor/character identification is the
substantive input. This is an algebraic-point/staircase model, not yet a
direct Dyck-path rule or a prescribed Newton-polytope lattice-point rule.

The earlier arbitrary-endpoint and dual-coefficient arguments were already
proved in the user's package, in
`history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/TWO_FRAME_INDEPENDENT_REVIEW.md`,
Sections 2 and 6. They are rechecked below because their signs and their
finite genericity requirements matter here. No new priority is claimed
for those earlier statements.

## 1. Two finite genericity conditions

Let B be an integral r-by-r matrix and D a positive integral diagonal
symmetrizer. Fix a label g and a degree q in N^r. Write

    U = D a,                     a in Q^r,
    mu(e_i)=U_i,                mu(e_0)=-U(q).

Use one frame of charge e_0 and q_i labeled leaves of charge e_i. Thus the
total charge is alpha=e_0+sum q_i e_i, and mu(alpha)=0. The alternating
form is the one in `GALE_YOUNG_THETA_DEGREE_THEOREM.md`, Section 1.

**Cut condition.** Require

    U(v) != 0 for every 0 < v <= q.                         (1.1)

For a proper nonempty vertex subset, either it is frame-free, in which case
its charge is some such v, or its complement is frame-free. Hence (1.1) is
exactly nonvanishing on every proper vertex cut. It permits arbitrary signs.

**Rank condition.** For each rooted full binary hierarchy H of these
individually labeled leaves, let M_H have the columns

    (v_S)_v = eta(beta_S,beta_v) if v belongs to S, and 0 otherwise,

with the frame row deleted. Let W have row D_i e_i^T at a mutable leaf of
color i, so the frame-deleted covector is W a. Choose a rational basis of
the left kernel of M_H. For every basis row l, retain the nonzero row

    f = l^T W.

Require

    f(a) != 0 for every retained row f and every H.         (1.2)

This is a finite exact algorithm. Different choices of a left-kernel basis
may give different sufficient open sets; every one has the needed property.
If M_H t=-W a is feasible at a satisfying (1.2), then all its left-kernel
rows vanish on W. Therefore

    image(W) is contained in image(M_H).                   (1.3)

The rank-recession lemma then gives

    ker(M_H) intersect R_{>=0}^{H}
      = the orthant supported on monochromatic nodes.     (1.4)

This statement and proof are in
`../global_gale_adversarial/RANK_GENERICITY_AND_RECESSION.md`.

## 2. Why the entire finite-factor proof survives mixed signs

The proof of (1.4) selects a separate projection-generic auxiliary
covector nu for which all mutable values may be positive. Its existence
uses only (1.3); the selected endpoint a never has to equal nu. Real depth
solutions, rather than positive ones, suffice for this auxiliary argument.
The induction propagates nonnegative homogeneous recession coefficients
through positive **charge ratios**. A leaf charge is a positive multiple of
one coordinate basis vector, regardless of the sign of mu on that vector.
Thus the rank-recession proof has no hidden endpoint-positivity assumption.

The remainder of the uniform-window proof is also sign-free. There are
finitely many closed hierarchy cones. A neighborhood of the chosen W a
avoids every cone not containing it. On every remaining cone, (1.4) bounds
all actual-arrow valuation objectives by linear-programming duality. A
uniform positive lower bound follows from

    delta = min_C |theta(C)| > 0

on a sufficiently small closed neighborhood, by the least-arrow-valuation
cut argument. Only absolute cut values occur. This gives the same full
leaf-parameter window

    0 < epsilon <= val(L_e) <= M < infinity.               (2.1)

If the underlying graph is disconnected, a component not containing the
frame has nonzero theta by (1.1). Its cut product has no boundary arrows,
so the positive factor is empty. This replaces the positive-component-sum
sentence used for the positive chamber. The degree-zero case is the
one-dimensional algebra separately.

The full independent-target annulus, strict-interior affinoid finiteness,
finite flatness, and fixed-cycle finite flatness in Sections 3--6 of
`GALE_YOUNG_THETA_DEGREE_THEOREM.md` now apply without change. At a cycle of
length k in color i, the primitive row content remains k D_i; no sign of
U_i enters this content. The target power isogeny still has degree
product_A(k_A D_{i(A)}). Strong-generic packet covectors can be chosen in
the same cut chamber and sufficiently close to the selected endpoint.

Finally, the saturated fixed-target special algebra is supported only at
x=0. Its cut proof needs theta(C) != 0, not theta(C)>0: one chooses the side
of the cut identity whose T exponent is positive. Thus saturation followed
by T=0 still computes the entire positive factor, with no extra localization.

These arguments prove the mixed-sign finite-factor/character theorem under
(1.1)--(1.2). In particular this is not an assertion of constant degree at
an arbitrary covector satisfying only (1.1).

### 2.1 The substantive distinction between the two conditions

For the unit directed triangle 1->2->3->1 with one arrow i->0 at each
mutable vertex, theta_i=1 and theta_0=-3 satisfy every proper-cut condition.
Yet the saturated positive Gale factor has length 4 at targets (2,3,5)
and length 0 at targets (1,1,1). This exact computation, including the
cleared equations, is retained in
`../phase_descent_round1/GALE_FIXED_TARGET_FINITE_FACTOR.md`, Section 5.
That endpoint violates the necessary rank-generic avoidance. It rules out
silently replacing (1.1)--(1.2) by cut genericity alone.

### 2.2 Actual reduced tuples at a signed endpoint

After clearing denominators of a by a positive common scaling, use the
additive coordinatewise perturbation

    Gamma_v^pr - T^{-a_i} + T^N P_i(x_v) = 0,
    deg P_i <= q_i-1,

with bounded generic coefficients. The correct uniform choice is

    N > max_i(-a_i),                                    (2.2)

and N may also be required positive. The target then equals
T^{-a_i}(1-T^{N+a_i}P_i(x_v)), with a unit in parentheses on the positive
locus. The window and Hermite argument apply. The former shortcut N>=1
was sufficient only when all a_i>0. The reduced tuple stabilizers remain
Young subgroups, and the theta coefficient counts free Young orbits.

## 3. Identification with the theta expansion at U

Use z^q=y^q x^{Bq}. At a generic endpoint U, write

    theta_{U,g} = x^g sum_{q>=0} c_{g,q}(U) z^q.           (3.1)

At frame degree one the framed root spaces form an abelian module M.
With the positive-normal derivations E_a, the correct module map is

    J(-E_{(1,q)})=x^g z^q.

The minus sign compensates the action on x_0^{-1}. If C is the unframed
incoming group element and

    C_hat=exp(M_pos) C,
    C=C_{U,-} C_{U,+},

then

    C_hat=C_{U,-} exp(Ad(C_{U,-}^{-1}) M_pos) C_{U,+}.

The framed covector (-U(q),U) has a unique zero framed root (1,q) in the
target box, by (1.1). Three-factor uniqueness and the module map therefore
identify its zero-factor coefficient with c_{g,q}(U). This is exactly the
earlier arbitrary-endpoint single-frame lemma; the argument never assumes
U positive.

The same finite Lie-factorization identity can be polarized along the
original axes. A part k of a color partition contributes the initial
axis-logarithm coefficient (-1)^{k-1}/k, and repeated equal parts give their
factorial denominators. The general flow-tree expansion evaluates each
squarefree packet coefficient at the same covector. Its internal admitted
vertex weights are the positive primitive weights, whatever the endpoint
cut chamber. Thus

    c_{g,q}(U)
      = sum_lambda sign(lambda) T_lambda(U) / product_i z_{lambda^i}.

The fixed-cycle calculation gives Tr(sigma|A_U)=T_{lambda(sigma)}(U).
The previous Young fixed-cycle lemma, now applied to the mixed-sign finite
factor, proves

    c_{g,q}(U)=dim Hom_{G_q}(sgn,A_U).                    (3.2)

This extends the coefficient identification, not only the existence of a
finite ideal. The general flow-tree theorem and the previous one-frame
identity are declared inputs, as in the positive-chamber assembly.

## 4. The signed monic-Q algebra

Take integral a satisfying (1.1)--(1.2). Introduce monic polynomials

    Q_i(z)=z^{q_i}+c_{i,1}z^{q_i-1}+...+c_{i,q_i};
    Q_i=1 if q_i=0.

In R=Q[T,c_{i,j}], put

    A_i(z)=z^{[g_i]_+} product_j Q_j(z)^{[B_ij]_+},
    E_i(z)=(-1)^{[-g_i]_+ + sum_j q_j[-B_ij]_+}
           z^{[-g_i]_+} product_j Q_j(z)^{[-B_ij]_+},
    F_i(z)=T^{[a_i]_+} A_i(z)-T^{[-a_i]_+} E_i(z).       (4.1)

Let I_rem be generated by all coefficients of the remainder of F_i upon
division by the monic Q_i. Let

    S=product_{i:g_i!=0} Q_i(0)
      product_{i<j:B_ij!=0} Res_z(Q_i,Q_j),
    K=I_rem:(T S)^infinity,
    Q(B,g,q;U)=R/(K+(T)).                                (4.2)

Empty factors are omitted. For q=0 the algebra is Q. There is no same-color
discriminant saturation. The sign and primitive exponent check is exactly
that in `../global_gale_novelty/Q_POLYNOMIAL_REMAINDER_THEOREM.md`:
Gamma^pr=A_i(x)/E_i(x), so (4.1) is precisely the cleared equation
Gamma^pr=T^{-a_i}. All exponents of T are nonnegative even when a_i<0.

The remainder/alternant compression, saturation, and specialization proof
uses no positivity assumption on the T exponents before clearing them.
Consequently (3.2) gives the finite algebra formula

    dim_Q Q(B,g,q;U)=c_{g,q}(U).                          (4.3)

The field degree is insensitive to a positive common rescaling of U;
equivalently this is finite ramification of T. A reduced Gröbner basis in
any fixed monomial order yields a finite standard-monomial set of this
cardinality.

## 5. One explicit endpoint for all required coefficient algebras

Fix k labels g_1,...,g_k and one principal degree p. Set

    h=g_1+...+g_k+Bp.                                    (5.1)

For every pair (g_l,q) with 0<q<=p, collect all nonzero rank rows f in
(1.2), expressed in the common primitive exponent coordinates a. There
are finitely many such rows; call their union F.

Choose an integer z>=2 such that, for

    e=(1,z,z^2,...,z^{r-1}),

every f in F with f(h)=0 has f(e)!=0. This is finite and exact: each such
f produces a nonzero polynomial in z. Choose an integer L satisfying

    L > sum_i D_i p_i e_i,
    L > |f(e)/f(h)| for all f in F with f(h)!=0.           (5.2)

Then set

    a=Lh+e,                     U=D a.                  (5.3)

This a satisfies every rank condition simultaneously. If f(h)=0, its
value is f(e)!=0; otherwise the second inequality in (5.2) prevents
cancellation.

It satisfies every needed cut condition as well. For 0<v<=p, if
(Dh)(v)=0 then U(v)=(De)(v)>0. Otherwise (Dh)(v) is a nonzero integer,
and

    |(De)(v)| <= sum_i D_i p_i e_i < L.

So U(v) has the sign of (Dh)(v). In particular it is nonzero. This proves
cut genericity separately rather than treating it as a consequence of
rank genericity. Dividing a by the gcd of its entries is harmless, being
a positive common rescaling.

There is no need to implement an infinite infinitesimal flag. The finite
construction (5.2)--(5.3) suffices for all algebras and for the dual
coefficient argument below. It works when h has mixed signs or h=0.

## 6. The dual coefficient functional with a finite rational endpoint

For any 0<=b<=p and label r satisfying h=r+Bb, consider the framed target
R=(1,b) for r. With the above endpoint, its root covector is

    Xi=(-U(b),U)
      =L eta(R,-)+(-De(b),De).                           (6.1)

The identity uses skew-symmetry of DB, giving b^TDBb=0. For any candidate
root C=(c_0,c) in the box [0,R] with eta(R,C)!=0, the correction in (6.1)
has absolute value at most sum_i D_i p_i e_i. Since eta(R,C) is an integer
of absolute value at least one, the event parameter obeys

    tau=-Xi(C)/eta(R,C)<0.                               (6.2)

Therefore no positive-time event can create R. If b>0 it is a nonaxis
root and its incoming coefficient is zero; if b=0 it is the frame axis
and its initial coefficient is one. The arbitrary-endpoint single-frame
identity proves

    [y^b x^h] theta_{U,r}=delta_{b,0}
       whenever h=r+Bb and 0<=b<=p.                      (6.3)

This proves the needed finite form of duality directly. Roots with zero
eta pairing cannot create R and require no denominator. Equality faces
of Dh and the case h=0 are included.

For a principal theta term y^s theta_r of nonnegative principal degree,
the monomial y^p x^h can occur only if b=p-s>=0 and h=r+Bb. Thus (6.3)
gives

    [y^p x^h](y^s theta_{U,r})=delta_{s,p} delta_{r,h}.    (6.4)

All statements are in the finite nonnegative principal-degree completion;
negative frozen shifts can be handled by shifting the whole expression
first. This avoids a hidden assumption that arbitrary frozen degrees
fit in the chosen box.

## 7. A finite algebra for every finite-arity structure coefficient

Let m(g_1,...,g_k;p) denote the coefficient of y^p theta_h in
theta_{g_1}...theta_{g_k}, with h as in (5.1). Choose the single endpoint
U by Section 5. Define the finite rational algebra

    M(B;g_1,...,g_k;p)
       = direct-sum_{q_1+...+q_k=p}
             tensor_{l=1}^k Q(B,g_l,q_l;U).              (7.1)

There are finitely many summands, so the direct sum may equivalently be
viewed as the finite product algebra. Zero algebras and degree-zero factors
are permitted. Tensor products are over Q.

Expanding all factors at this common endpoint gives

    [y^p x^h] product_l theta_{U,g_l}
       =sum_{q_1+...+q_k=p} product_l c_{g_l,q_l}(U).

By (6.4), the left side is exactly m(g_1,...,g_k;p). By (4.3), the right
side is exactly the vector-space dimension of (7.1). Therefore

    m(g_1,...,g_k;p)=dim_Q M(B;g_1,...,g_k;p).             (7.2)

This proves the desired coefficient formula, including all symmetrizer
and frozen-degree normalizations. If B has a kernel, different p can give
the same h; (7.1)--(7.2) keep those principal outputs distinct.

Choosing standard monomials in each factor gives actual finite objects:
a composition p=sum q_l and one standard monomial in each corresponding
Q algebra. Permuting input labels and tensor factors gives the evident
commutativity bijection when the common endpoint is retained. No new
associator between unrelated choices of endpoint or Gröbner order is
asserted. The construction is direct for every k and does not require
successively expanding binary products in the theta basis.

This is coefficientwise for formal theta functions. In settings where the
theta labels lie in the middle algebra and the established finite basis
multiplication theorem applies, these are its usual finite structure
constants. No theorem that every arbitrary label has finite Laurent
support is inferred.

## 8. Review of the implementation interface

`computation/q_endpoint_coefficients.py` uses the signed row (4.1) and
checks rank and cut conditions separately. Its independent comparison is
the earlier signed incoming-factor transport, not a second version of the
same Gale count.

`computation/q_structure_coefficients.py::generic_dual_endpoint` implements
exactly Section 5: all labels and all nonzero q<=p contribute rank rows;
e is selected on the power curve; L dominates both the rank cancellation
ratios and the root correction bound. Its separate positive-chart
triangular expansion is a validation oracle only, not an input to (7.1).

This branch checked that algorithm line by line against the proof. The
proof is general; the associated exact examples test the implementation
and do not replace any argument above.
