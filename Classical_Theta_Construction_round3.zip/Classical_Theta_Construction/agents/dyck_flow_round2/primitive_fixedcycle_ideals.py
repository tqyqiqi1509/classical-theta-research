"""Independent exact primitive Gale/fixed-cycle checks against IncomingSchur.

The geometric algebra is constructed by saturation in Q[T,x]; no flow count
is used. Only after its T=0 length is computed is the separate incoming
integer-Schur engine queried. Symmetrizer scaling and cycle contents enter
the original arrow multiplicities before primitive row division.
"""
from pathlib import Path
from itertools import product, combinations
from fractions import Fraction
from math import factorial
import argparse, json, multiprocessing as mp, sys, time
import sympy as sp

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'))
from incoming_recursion import IncomingSchur

def partitions(n, lower=1):
    if n==0:
        yield ()
    for k in range(lower,n+1):
        for rest in partitions(n-k,k):
            yield (k,)+rest

def zvalue(lam):
    out=1
    for k in set(lam):
        m=lam.count(k);out*=k**m*factorial(m)
    return out

def equations(B,D,g,lam,a=None):
    """One original primitive row per packet, never its content-th power."""
    r=len(D); packets=[(i,k) for i in range(r) for k in lam[i]]
    n=len(packets); xs=sp.symbols('x0:'+str(n));t,z=sp.symbols('t z')
    a=a or [1]*r
    colors=[-1]+[i for i,k in packets]
    lengths=[1]+[k for i,k in packets]
    contents=[1]+[k*D[i] for i,k in packets]
    coords=[sp.Integer(0)]+list(xs)
    eta=[[0]*(r+1) for _ in range(r+1)]
    for i in range(r):
        eta[0][i+1]=g[i]*D[i];eta[i+1][0]=-eta[0][i+1]
        for j in range(r):eta[i+1][j+1]=-D[i]*B[i][j]
    nums=[sp.Integer(1)]*(n+1);dens=[sp.Integer(1)]*(n+1)
    forms=[]; arrows=[]; incident_n=[set() for _ in range(n+1)];incident_d=[set() for _ in range(n+1)]
    for u in range(n+1):
        for v in range(u+1,n+1):
            iu=0 if u==0 else colors[u]+1
            iv=0 if v==0 else colors[v]+1
            pairing=lengths[u]*lengths[v]*eta[iu][iv]
            if not pairing:continue
            tail,head=(u,v) if pairing>0 else (v,u)
            m=abs(pairing);L=coords[head]-coords[tail]
            assert m%contents[tail]==m%contents[head]==0
            nums[head]*=L**(m//contents[head])
            dens[tail]*=L**(m//contents[tail])
            forms.append(L)
            form_id=len(forms)-1
            incident_n[head].add(form_id);incident_d[tail].add(form_id)
            arrows.append({'tail':tail,'head':head,'m':m,
                           'tail_content':contents[tail],
                           'head_content':contents[head]})
    eq=[sp.expand(t**a[colors[v]]*nums[v]-dens[v]) for v in range(1,n+1)]
    # In the localized equations, if one side of a row is a product of
    # units then so is the other. Choose a minimal seed of edge forms
    # whose unit closure contains every form. Saturation by this seed
    # and T is therefore exactly saturation by T times every arrow form.
    # The frame row follows from the product of the ordinary powered rows.
    # Here using mutable rows alone already gives the required closure.
    def close(seed):
        units=set(seed)
        while True:
            old=len(units)
            for v in range(1,n+1):
                if incident_n[v]<=units:units|=incident_d[v]
                if incident_d[v]<=units:units|=incident_n[v]
            if len(units)==old:return units
    chosen=None
    for size in range(len(forms)+1):
        for seed in combinations(range(len(forms)),size):
            if len(close(seed))==len(forms):chosen=seed;break
        if chosen is not None:break
    sat=t*sp.prod(forms[i] for i in chosen)
    return xs,t,z,eq,sat,arrows,contents

def staircase(gb,xs):
    if len(gb.polys)==1 and gb.polys[0].as_expr()==1:return []
    leading=[p.LM(order='lex').exponents for p in gb.polys]
    bounds=[]
    for i in range(len(xs)):
        pure=[e[i] for e in leading if e[i]>0 and sum(e)==e[i]]
        if not pure:raise RuntimeError('positive-dimensional special fiber')
        bounds.append(min(pure))
    return [e for e in product(*(range(b) for b in bounds))
            if not any(all(a<=b for a,b in zip(l,e)) for l in leading)]

def ideal_worker(payload,q):
    try:
        B,D,g,lam,a=payload;start=time.time()
        xs,t,z,eq,sat,arrows,contents=equations(B,D,g,lam,a)
        G=sp.groebner(eq+[1-z*sat],z,t,*xs,order='lex',domain=sp.QQ)
        J=[sp.expand(f.as_expr().subs(t,0)) for f in G.polys
           if not f.as_expr().has(z)]
        H=sp.groebner(J,*xs,order='lex',domain=sp.QQ)
        basis=staircase(H,xs)
        q.put({'length':len(basis),'equations':[str(f) for f in eq],
               'saturation':str(sat),'saturation_equivalence':'unit-closure certificate from the defining primitive rows',
               'special_groebner':[str(f.as_expr()) for f in H.polys],
               'basis_exponents':[list(e) for e in basis],
               'arrows':arrows,'contents':contents,'seconds':time.time()-start})
    except Exception as e:q.put({'error':repr(e)})

def independent_cycle_value(B,D,g,lam):
    packets=[(i,k) for i in range(len(D)) for k in lam[i]]
    Bc=[[l*B[i][j] for j,l in packets] for i,k in packets]
    Dc=[k*D[i] for i,k in packets]
    gc=tuple(g[i] for i,k in packets);cap=(1,)*len(packets)
    value=IncomingSchur(Bc,Dc).theta_prefix(gc,cap).get(cap,0)
    return value,Bc,Dc

def run(timeout=35):
    seeds=[
      ('valued_cyclic',[ [0,3],[-2,0]],[2,3],(-2,1),(2,1)),
      ('common_factor',[ [0,3],[-2,0]],[4,6],(-2,1),(2,1)),
      ('valued_acyclic',[ [0,3],[-2,0]],[2,3],(-2,-1),(2,1)),
      ('both_colors_cycle',[ [0,3],[-2,0]],[2,3],(-2,1),(2,2)),
      ('cycle_length_three',[ [0,3],[-2,0]],[2,3],(-3,1),(3,1)),
      ('coprime_six_ten',[ [0,5],[-3,0]],[6,10],(-2,1),(2,1)),
      ('nonprimitive_skew',[ [0,2],[-2,0]],[2,2],(-2,1),(2,2)),
      ('valued_zero_sign',[ [0,2],[-1,0]],[3,6],(-2,1),(2,2)),
    ]
    results=[];cache={};start=time.time()
    for name,B,D,g,p in seeds:
        rows=[]
        for lam in product(*(list(partitions(n)) for n in p)):
            xs,t,z,eq,sat,arrows,contents=equations(B,D,g,lam,[1]*len(D))
            key=(tuple(map(str,eq)),str(sat))
            if key in cache:
                out=dict(cache[key]);out['cached_identical_equations']=True
            else:
                q=mp.Queue();proc=mp.Process(target=ideal_worker,args=((B,D,g,lam,[1]*len(D)),q))
                proc.start();proc.join(timeout)
                if proc.is_alive():
                    proc.terminate();proc.join();out={'timeout_seconds':timeout}
                else:out=q.get(timeout=2)
                cache[key]=dict(out)
            out.update({'cycle_type':[list(x) for x in lam],
                        'contents':[1]+[k*D[i] for i in range(len(D)) for k in lam[i]],
                        'arrows':arrows})
            incoming,Bc,Dc=independent_cycle_value(B,D,g,lam)
            out.update({'incoming_cycle_value':incoming,'cycle_B':Bc,'cycle_D':Dc})
            if 'length' in out:out['match']=out['length']==incoming
            rows.append(out)
            print(json.dumps({'name':name,'cycle_type':out['cycle_type'],
                              **{k:out[k] for k in ['length','incoming_cycle_value','match','timeout_seconds','seconds'] if k in out}}),flush=True)
        rec={'name':name,'B':B,'D':D,'g':g,'p':p,'rows':rows,
             'incoming_theta_coefficient':IncomingSchur(B,D).theta_prefix(g,p).get(p,0)}
        if all('length' in row for row in rows):
            alt=sum((Fraction((-1)**(sum(p)-sum(map(len,row['cycle_type'])))*row['length'],
                              sp.prod(zvalue(tuple(x)) for x in row['cycle_type'])) for row in rows),Fraction())
            rec['ideal_sign_average']=str(alt)
            rec['theta_match']=alt==rec['incoming_theta_coefficient']
        results.append(rec)
        output={'results':results,'seconds':time.time()-start,
                'all_completed_comparisons_match':all(row.get('match',True) for rec in results for row in rec['rows']),
                'all_completed_sign_comparisons_match':all(rec.get('theta_match',True) for rec in results)}
        (HERE/'primitive_fixedcycle_ideals.json').write_text(json.dumps(output,indent=2,default=str))
    return output

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--timeout',type=int,default=35)
    args=ap.parse_args();out=run(args.timeout)
    print(json.dumps({k:v for k,v in out.items() if k!='results'}),flush=True)
