from root_merge_probe import *

def greed(z,a,b,revE,revN,selfE,selfN,popE,popN):
 word,gr,f,blocks=z
 root=f.nontrivial_roots[0]
 active=set(x for e in f.edges for x in e)
 start=(root-len(active)+1)%len(word)
 rank={v:(v-start)%len(word) for v in active}
 adj={v:[] for v in active}
 for u,v in f.edges:adj[u].append(v)
 labs={root:-1}
 for v,cs in adj.items():
  cs.sort(key=rank.get,reverse=revE if word[v]=='E' else revN)
  labs.update(zip(cs,blocks.get(v,())))
 flow=Counter()
 def merge(x,y):
  x=list(x);y=list(y)
  while x and y and x[0][1]*y[0][1]<0:
   ix=-1 if (popN if x[0][1]>0 else popE) else 0
   iy=-1 if (popN if y[0][1]>0 else popE) else 0
   u,c=x[ix];v,d=y[iy]
   w=min(abs(c),abs(d))
   e=(u,v) if c>0 else (v,u)
   flow[e]+=w
   c=c-w if c>0 else c+w
   d=d-w if d>0 else d+w
   if c:x[ix]=(u,c)
   else:x.pop(ix)
   if d:y[iy]=(v,d)
   else:y.pop(iy)
  return x+y
 def dfs(v):
  lab=labs[v]
  me=[] if lab<0 else [(lab,a if lab>=a else -b)]
  children=[dfs(w) for w in adj[v]]
  use_after=selfE if word[v]=='E' else selfN
  parts=children+[me] if use_after else [me]+children
  out=[]
  for p in parts:out=merge(out,p)
  return out
 assert not dfs(root)
 assert len(flow)==a+b-1
 return tuple(sorted(flow))

def main():
 cases=[(2,3),(3,2),(3,4),(4,3),(3,5),(5,3)]
 flags=list(product([False,True],repeat=6))
 report=[]
 for a,b in cases:
  obs=list(objects(a,b));rows=[]
  for f in flags:
   vals=[greed(z,a,b,*f) for z in obs]
   rows.append({'flags':f,'images':len(set(vals))})
  report.append({'a':a,'b':b,'objects':len(obs),'maps':rows})
  print(json.dumps({'a':a,'b':b,'objects':len(obs),'best':max(r['images'] for r in rows),'good':[r['flags'] for r in rows if r['images']==len(obs)]}),flush=True)
 Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))

if __name__=='__main__':main()
