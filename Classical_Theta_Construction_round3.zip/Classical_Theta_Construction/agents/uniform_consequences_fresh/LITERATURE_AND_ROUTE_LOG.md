# Literature and route log: uniform consequences branch

Started 2026-11-13 around 23:22 UTC; refreshed searches through 23:40 UTC. Primary texts were opened rather than relying on search summaries. Search absence is not a historical-priority proof.

## Routes

| Route | Result | Relation to the main task |
|---|---|---|
| Uniform analytic ray theorem -> actual multiplication probabilities | Independently reviewed PASS | Makes the full scattering fan detectable by the true large-label product, with a quantitative rate. |
| Exact positive multiplication -> mixture and total variation | PASS | Produces asymptotic convolution inside common closed normal cones; no signed stable series is treated as a probability law. |
| Complex quasi-powers -> Gaussian/ratio/Newton consequences | Independently reviewed PASS | Old probability tools applied to the new general theta input; all singular-covariance and rationality restrictions retained. |
| Vanishing limiting variance -> complete kernel rigidity | General proof written, root review requested | Unit prefactor plus superpolynomial error kills every mixed analytic derivative; gives a parameter-independent fluctuation subspace. |
| Stable support -> negative-factor Lie root support | General minimal-degree proof written, root review requested | Gives an algebraic/combinatorial description of that subspace and separates it from the zero-group face span. |
| Stable support span -> full single-theta support span | OPEN | Shared with the ray branch; requires an actual theta support mechanism. Abstract quasi-power axioms and Newton homogeneity do not suffice. |
| Uniform pressure -> coefficient entropy upper bound | Proved elementary corollary | Gives a general quantitative coefficient bound; does not supply Laurent-finiteness or stopping. |
| General quasi-power theorem without a unit prefactor | Explicit failure of mixed-kernel rigidity | Gaussian vector (Z^2,sqrt(n)Z) has a varying asymptotic Hessian kernel; isolates the needed theta hypothesis. |
| 2026 type-A log-concavity paper as a strong support/log-concavity bridge | Rejected for this purpose | Its proved coordinatewise notion is weaker; its asserted equivalence to joint log-concavity is false. Exact audit below. |

## Primary literature read and assessed

### Heuberger--Kropf: higher-dimensional quasi-powers

Source: https://arxiv.org/pdf/1609.09599 , Theorem 1 and Proposition 1.1; published DOI https://doi.org/10.1007/s00605-018-1215-6 .

Status: useful, directly checked. Theorem 1 matches a fixed complex polydisc and a label-independent analytic quasi-power exponent. Positive definite Hessian is needed for the quantitative lower-orthant result. Singular covariance still gives weak Gaussian convergence, with an explicit warning that a uniform distribution-function rate is not automatic. Proposition 1.1 gives polynomial moment asymptotics. These are established tools and are not counted as new results of this project.

The paper's general hypotheses allow a nontrivial analytic order-one prefactor. They do not state the present parameter-independent support-space kernel theorem. The new kernel proof uses the stronger unit prefactor and superpolynomial error supplied by the theta result.

### Heuberger--Kropf--Wagner: transducer covariance degeneracy

Source: https://arxiv.org/pdf/1404.3680 , Theorem 3.1, Corollary 3.7, and Section 5.3; published DOI https://doi.org/10.1016/j.ejc.2015.03.004 .

Status: relevant antecedent, not used as a theta premise. It characterizes bounded asymptotic variance for finite-state transducers by relations on directed cycles and gives a corresponding singular-covariance criterion. This shows that structural covariance degeneracy is an established topic. Its finite-state cycle/coboundary mechanism is different from the present unrestricted theta unit-prefactor argument. No finite automaton presentation of arbitrary theta functions has been supplied, so that theorem cannot simply be invoked here.

### Biane--Bougerol--O'Connell: random crystals and product probabilities

Source: https://arxiv.org/pdf/math/0403171 , *Littelmann paths and Brownian paths*, Section 5, especially the transition probabilities immediately before Lemma 5.8.

Status: relevant antecedent, directly read at the interface. Normalized tensor-product multiplicities weighted by representation dimensions already define probability kernels. Consequently converting positive basis multiplication into a probability mixture is not a new general principle. The present theta contribution is the explicit small-positive-domain scaled-label asymptotic and its fan-dependent stretched-exponential concentration. No identification of arbitrary theta functions with those representation characters is assumed.

### GHKK, Fock--Goncharov, and Mandel

Sources: https://arxiv.org/abs/1411.1394 ; https://arxiv.org/abs/math/0311245 ; https://arxiv.org/abs/1605.03202 .

Status: established structural context. Positive principal multiplication and leading degree zero are inputs already rechecked in the local signed-product proof. The scaling-pairing agenda is old. Scattering-atlas atomicity must not be silently replaced by cluster-atlas atomicity or by minimality among all strongly positive bases. This branch makes neither substitution.

## Strong audit of a 2026 result: a real definition-level error

Zhichao Chen, Guanhua Huang, Zhe Sun, *Log-concavity of cluster algebras of type A_n*, Nagoya Mathematical Journal 261 (2026), e28; online 24 April 2026; DOI https://doi.org/10.1017/nmj.2026.10110 . Primary full article:

https://www.cambridge.org/core/journals/nagoya-mathematical-journal/article/logconcavity-of-cluster-algebras-of-type-an/CECB10C9A014DA0C852E83539898A7D2

Directly checked Definition 2.17, Lemma 2.20, Remark 2.21, Theorems 5.3 and 6.8 and their proofs. The precise findings are:

1. Definition 2.17 tests adjacent coefficients only along coordinate directions, with other coordinates fixed.
2. Lemma 2.20 asserts equivalence with the existence of a jointly concave logarithmic extension on a convex domain containing the support. **This assertion is false.**
3. For an explicit general family, take a_(i,j)=b^(ij), 0<=i,j<=2, with b>1. Every row and column is geometric, so all the coordinatewise adjacent log-concavity inequalities hold with equality. The support is the complete 3-by-3 grid and has no relevant coordinate holes. But joint concavity along the diagonal from (0,0) to (2,2) requires a_(1,1)^2>=a_(0,0)a_(2,2), namely b^2>=b^4, which is false.
4. At b=2 the exact matrix is [[1,1,1],[1,2,4],[1,4,16]]. The midpoint inequality is 4>=16, false. A Wolfram exact calculation independently checked all row/column inequalities and this failure.
5. Remark 2.21 says subsequent arguments use Definition 2.17. Therefore the false equivalence alone does **not** refute the coordinatewise claims of Theorems 4.2, 5.3, or 6.8. The binomial argument in Theorem 5.3 was checked and gives the stated coordinatewise type-A2 result. Theorem 6.8 uses degree at most one in every coefficient variable, making its coordinatewise three-term condition automatic.
6. This paper is not a source for joint log-concavity, Lorentzian structure, complete log-concavity, or arbitrary-theta support connectivity. None of its conclusions is used in the new analytic or covariance proofs. The broader assertions in the abstract must be interpreted with the explicit definition and the failed equivalence in mind.

This is a targeted error record with an exact counterexample, not a blanket claim that the whole paper is false.

## Search record and nonmatching results

Queries included:

- cluster theta functions multiplication asymptotic scaling canonical basis Fock Goncharov convex pairing;
- theta basis probability Gaussian central limit theorem cluster algebras;
- exact phrases theta/multiplication/asymptotic/cluster and theta basis/asymptotic/probability;
- canonical basis large deviations cluster;
- scattering fan support function theta asymptotic;
- Littelmann crystal tensor product random walk character probability large deviations;
- positive basis hypergroup canonical basis theta functions probability convolution;
- quasi-powers variance zero; quasi-power degenerate linear; quasi-powers covariance kernel;
- analytic quasi-powers Hessian singular; vanishing asymptotic variance coboundary;
- cluster algebras theta covariance; theta functions cluster quasi-power.

Both search engines were used. Many broad theta/covariance hits concern classical analytic theta series, cosmological clusters, or statistical clustering, and were rejected as unrelated. The current 2026 Reading--Stella mutation work was returned; its previously audited finite-order structure-constant and pointed-basis results do not supply the present analytic all-label rate. No unverified 2026 theorem was used as a proof input. Searches did not locate a matching general theta covariance-kernel or asymptotic-convolution theorem, but they cannot certify historical priority.
