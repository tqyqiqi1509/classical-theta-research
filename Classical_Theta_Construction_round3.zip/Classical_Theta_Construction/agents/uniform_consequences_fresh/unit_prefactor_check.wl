Clear[s,t,n,w];
exponent=t^2/(2(1-2s));
hess=Table[D[exponent,a,b],{a,{s,t}},{b,{s,t}}];
nullVector={1,-2t/(1-2s)};
mgf=Integrate[Exp[s w^2+t Sqrt[n] w-w^2/2]/Sqrt[2 Pi],
 {w,-Infinity,Infinity},
 Assumptions->(Element[{s,t,n},Reals]&&s<1/2&&n>0)];
<|"mgf"->mgf,"hessian"->hess,"determinant"->Together[Det[hess]],
 "nullCheck"->Simplify[hess.nullVector],
 "baseHessian"->(hess/.{s->0,t->0}),
 "mixedDerivative"->(D[exponent,s,t,t]/.{s->0,t->0})|>
