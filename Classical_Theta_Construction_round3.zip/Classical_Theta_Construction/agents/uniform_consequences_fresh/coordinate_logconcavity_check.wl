matrix=Table[2^(i j),{i,0,2},{j,0,2}];
rowChecks=Table[matrix[[i,2]]^2>=matrix[[i,1]]matrix[[i,3]],{i,1,3}];
colChecks=Table[matrix[[2,j]]^2>=matrix[[1,j]]matrix[[3,j]],{j,1,3}];
<|"coefficientMatrix"->matrix,
 "coordinateLogConcavity"->And@@Join[rowChecks,colChecks],
 "jointMidpointCondition"->(matrix[[2,2]]^2>=matrix[[1,1]]matrix[[3,3]]),
 "midpointSides"->{matrix[[2,2]]^2,matrix[[1,1]]matrix[[3,3]]}|>
