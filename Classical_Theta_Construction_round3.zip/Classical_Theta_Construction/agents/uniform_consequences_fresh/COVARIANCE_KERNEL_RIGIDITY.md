# Covariance-kernel rigidity and the stable root-support space

2026-11-13. Classical principal-coefficient theta functions, skew-symmetric or skew-symmetrizable. **New consequence proved below; independent root review requested.** The input is the reviewed common-domain unit-prefactor ray theorem. The argument does not need finite Laurent support or positivity of the stable quotient H itself.

## 1. Statement

Fix an integral label g. Write H_g(z)=exp(L_g(z)), H_g(0)=1, and let

    V_g = span_R {p in N^r : [z^p] H_g != 0, p!=0}.

This is a rational linear subspace: it is spanned by integer vectors, and a basis can be selected from finitely many of them. The same space is obtained by taking the support of L_g=log H_g, because formal exponential and logarithm form only sums of support degrees.

For a strictly positive z in the common small analytic domain, put

    mu_g(z)=grad_(log z) L_g(z),
    Sigma_g(z)=Hess_(log z) L_g(z).

The ray theorem implies that these are respectively the limiting mean per n and covariance per n of the positive root-exponent law P_(ng,z). Then

    ker Sigma_g(z)=V_g^perp                         (1.1)

for every such z. In particular, the rank of Sigma is independent of z; there are no isolated positive points of covariance degeneracy. It is positive definite on V_g, and mu_g(z) lies in V_g.

There is also an actual concentration statement, stronger than only a degenerate central limit theorem:

    Pr(P_(ng,z) notin V_g)=O(exp(-c sqrt(n))).        (1.2)

The estimate is uniform on smaller positive compact domains after g and a lattice basis of V_g^perp are fixed. The principal degree is kept throughout; mutable collisions under B do not change the statement.

## 2. An abstract unit-prefactor rigidity lemma

Let X_n be real r-dimensional random vectors with a moment generating function on a fixed complex polydisc, and suppose

    log E exp(<t,X_n>)=n U(t)+E_n(t),
    U(0)=0, E_n(0)=0,
    sup |E_n|=O(epsilon_n),

where U is analytic and epsilon_n decreases faster than every negative power of n. The theta application has epsilon_n=exp(-c sqrt(n)). Let S=Hess U(0), which is positive semidefinite as a limiting covariance. If v^T S v=0, then

    D_v D_(w_2) ... D_(w_k) U(0)=0                 (2.1)

for every k>=2 and arbitrary real w_2,...,w_k. Thus D_v U is constant on a neighborhood of 0.

### Proof

Cauchy estimates give every fixed-order joint cumulant as n times the corresponding derivative of U plus O(epsilon_n). Let Y_n=X_n-E X_n. Its first-order cumulants vanish; all its fixed-order cumulants of order >=2 are O(n). The moment-cumulant formula therefore gives polynomial bounds in n for every fixed even moment of every linear form, and hence for every fixed moment of ||Y_n||. No bound uniform in the order is needed.

The assumption v^T S v=0 gives

    E(<v,Y_n>^2)=Var(<v,X_n>)=O(epsilon_n).

For any fixed k>=2, Cauchy--Schwarz gives

    |E[<v,Y_n> product_(j=2)^k <w_j,Y_n>]|
       <= O(sqrt(epsilon_n))
          (E product_(j=2)^k <w_j,Y_n>^2)^(1/2)
       <= sqrt(epsilon_n) times a polynomial in n.

This tends to zero faster than every negative power of n. In every partition term defining a mixed cumulant with one designated v argument, the block containing that argument either has size one, in which case its centered moment is zero, or has size at least two and has the displayed small bound. All other block moments have polynomial bounds. Therefore every such centered mixed cumulant of total order at least two is superpolynomially small. Centering does not change cumulants of order >=2.

Comparing this with

    kappa(<v,X_n>,<w_2,X_n>,...,<w_k,X_n>)
       =n D_v D_(w_2)...D_(w_k)U(0)+O(epsilon_n)

proves (2.1). The Taylor series of D_v U consequently has only a constant term. Analyticity proves the final assertion. This proof uses the absence of an order-one prefactor: a nonzero prefactor could leave a nonvanishing transverse variance.

## 3. Apply the lemma at one positive theta point

Fix one positive z_0 in the common domain, and let u_0=log z_0. The theta probability law has analytic quasi-power exponent

    U(t)=L_g(z_0 exp(t))-L_g(z_0).

If v lies in ker Sigma_g(z_0), Section 2 shows that the logarithmic directional derivative D_v L_g is constant on an open neighborhood of u_0. Here

    D_v =sum_i v_i z_i partial_(z_i)

is an Euler vector field. The real log-positive domain

    {u in R^r : sum_i exp(u_i)<rho_*}

is connected (indeed convex). The real-analytic identity theorem therefore makes D_v L_g constant on this whole domain.

Its constant is zero. To see this, take any positive z in the domain and let s tend to zero through positive values. The Euler derivative is holomorphic at z=0 and vanishes there because L_g has zero constant term. Thus D_v L_g(s z) tends to zero. This argument does not differentiate log z at z=0; it uses the holomorphic Euler derivative in the z coordinates.

Consequently D_v L_g=0 identically. The holomorphic identity theorem, or uniqueness of power-series coefficients on the positive open set, gives

    <v,p> [z^p] L_g=0

for every p. Hence v annihilates the support span of L_g and therefore V_g.

Conversely, if v annihilates V_g, every coefficient of D_v H_g is zero. Since H_g is zero-free in the common domain, D_v L_g=0. Differentiating shows Sigma_g(z)v=0 at every positive z. This proves (1.1). The mean vector belongs to V_g because it pairs to zero with every vector in V_g^perp.

## 4. Concentration on a rational support subspace

Choose integer vectors v_1,...,v_s spanning V_g^perp. Such vectors exist because V_g is rational. For each j, the common ray estimate and Cauchy derivatives give

    E <v_j,P_(ng,z)>=O(epsilon_n),
    Var(<v_j,P_(ng,z)>)=O(epsilon_n),

since v_j pairs to zero with mu_g and lies in the covariance kernel. Therefore

    E <v_j,P_(ng,z)>^2=O(epsilon_n).

The random variable <v_j,P_(ng,z)> is an integer. Its nonzero values have square at least one, so

    Pr(<v_j,P_(ng,z)>!=0)<=E <v_j,P_(ng,z)>^2.

A finite union bound proves (1.2). In particular, the total variation distance between the exponent law and its conditioning on V_g is O(epsilon_n). Equivalently, coupling to the orthogonal projection onto V_g gives the same upper bound. On V_g the covariance is nonsingular, so every chosen linear coordinate isomorphism V_g -> R^dim(V_g) has the usual nondegenerate quasi-power Gaussian approximation. The statement is intrinsic to this support space; it does not claim an unqualified full-space singular lower-orthant rate.

## 5. A sharper Newton barycenter statement

Assume additionally that F_g is a polynomial and use the independently checked known identity

    Newt(F_(ng))=n P,       P=Newt(F_g).

Then all P_(ng,z)/n lie in P, and the mean limit mu_g(z) lies in P intersect V_g. The new kernel theorem improves this to

    mu_g(z) in relint_(V_g)(P intersect V_g).       (5.1)

Indeed, restrict the map u -> mu_g(exp u) to the affine parameter slice u_0+V_g. Its derivative is Sigma_g restricted to V_g, which is positive definite and maps V_g to itself. The inverse function theorem gives an open neighborhood of mu_g(z) in V_g contained in the image. Every point of this image lies in P intersect V_g. Thus mu_g(z) is an interior point relative to V_g. This also proves that P intersect V_g has affine span V_g. The case V_g={0} is included.

If an independent theta argument establishes V_g=span(P), this becomes the familiar full relative-interior assertion and rank Sigma=dim P. That equality is **not proved here**. The analytic ray theorem alone cannot prove it: the abstract positive family 1+z^n has stable quotient 1 but Newton interval [0,n]. This is a logical warning, not a theta counterexample. Determining whether the general theta mechanism eliminates such transient support directions is an additional combinatorial question.

## 6. What is new in this implication, and what is not

The moment-cumulant identity, Cauchy--Schwarz, analytic continuation, and exponential-family covariance are standard tools. The key strengthening supplied by the theta theorem is a unit asymptotic prefactor and an error smaller than every power of n on a complex neighborhood. This makes a vanishing limiting variance eliminate every mixed analytic derivative, rather than merely yield a degenerate Gaussian limit.

Heuberger--Kropf, arXiv:1609.09599, Theorem 1 and Proposition 1.1, directly read during the review, supply general quasi-power limits and moment formulas. They do not, in those statements, identify the complete covariance kernel with an intrinsic power-series support space or prove its positive-parameter independence. Their general hypotheses allow a nontrivial order-one prefactor. Historical priority for the rigidity lemma itself is not asserted; a dedicated literature search is recorded separately.

### Why the unit prefactor matters

This distinction is substantive even for ordinary real random vectors. Let Z be standard Gaussian and take X_n=(Z^2,sqrt(n) Z). Direct Gaussian integration gives

    E exp(s X_(n,1)+t X_(n,2))
       =(1-2s)^(-1/2) exp(n t^2/(2(1-2s))).

Thus the quasi-power exponent is U(s,t)=t^2/(2(1-2s)), with the nontrivial prefactor (1-2s)^(-1/2). Its Hessian is

    [[4t^2/(1-2s)^3, 2t/(1-2s)^2],
     [2t/(1-2s)^2,   1/(1-2s)]].

It has rank one for s<1/2 and kernel spanned by (1,-2t/(1-2s)), which varies with t. At the base point, its first coordinate is a kernel direction, but D_s D_t^2 U(0)=2 is nonzero. Therefore the mixed-derivative rigidity lemma fails if its unit-prefactor condition is dropped. This example is not a cluster theta family; it isolates the exact logical role of the stronger analytic input. The Gaussian integral, Hessian, determinant, null vector, and mixed derivative were independently checked with the Wolfram computational plugin; the exact script and result are retained in this directory.
