# The stable support space equals the negative-factor root span

2026-11-13. Classical skew-symmetric and skew-symmetrizable principal data. **Proof written for independent root review.** This identifies the space in `COVARIANCE_KERNEL_RIGIDITY.md` by the actual root support of the signed negative factor. It concerns the negative factor at g, not the zero group that controls exposed-face dimensions in the separate convex-body theorem.

## 1. An algebraic support-span lemma

Let the completed scattering Lie algebra have one-dimensional root spaces indexed by positive a in N^r. Choose a root derivation E_a normalized so that

    E_a(x^m)=c(a,m) x^m z^a,

where c(a,m) is a nonzero scalar multiple of a^T Dm. Its action on a monomial changes the principal degree by a. Different primitive-normal conventions only rescale E_a by a nonzero number and do not affect support.

Let

    X=sum_(a>0) kappa_a E_a,       A=exp(X),
    H=x^(-g) A(x^g).

Assume c(a,g)!=0 whenever kappa_a!=0. Then

    span_R supp(H-1)=span_R {a:kappa_a!=0}.         (1.1)

### Proof

Every term of exp(X)(x^g) has principal degree a sum of roots in supp X. Thus the left-hand span V is contained in the right-hand span W.

If W were not contained in V, choose a root a outside V of smallest total degree with kappa_a!=0. Every active root of smaller degree lies in V. In the coefficient of z^a in H, a nonlinear term from X^j, j>=2, cannot use a root outside V: any such root has degree at least |a|, and adding another positive root makes total degree larger than |a|. A nonlinear term using only roots in V has degree in V and therefore cannot equal a. Hence

    [z^a] H=kappa_a c(a,g)!=0,

contradicting a outside V. This proves (1.1). The argument is entirely degreewise and applies to infinite completed series. It makes no positivity assumption on H or on the kappa_a.

The support spans of H-1 and log H agree: exponential and logarithm only add positive support degrees, so each is contained in the linear span of the other.

## 2. Apply to the coarse negative factor

For the signed factorization at g,

    C=A_g^- Z_g A_g^+,
    lambda_g(a)=a^T Dg,

the logarithm of A_g^- is supported only on roots with lambda_g(a)<0. Therefore c(a,g) is nonzero on every active root. Section 1 proves

    V_g=span_R supp(H_g-1)
       =span_R supp(log H_g)
       =span_R supp(log A_g^-).                    (2.1)

Combining this with the covariance theorem yields the concrete kernel formula

    ker Sigma_g(z)
       =(span_R supp(log A_g^-))^perp.             (2.2)

This remains valid on higher-codimension label faces: the coarse negative factor excludes roots with lambda_g=0, so the nonvanishing assumption is exact. If g=0 or A_g^-=1, both spans are zero. This formula does not identify the covariance space with the zero-group root span; those are different objects with different roles.

## 3. Geometric version: the roots of the walls actually crossed

For generic g, choose a generic straight segment from Dg to a point of the positive chamber, in the physical covector coordinates used in the path theorem. Every wall crossed has primitive positive normal a with lambda_g(a)<0. The segment starts on the negative side of that wall hyperplane and ends on its positive side. Its wall automorphism has the common orientation

    x^m -> x^m f_a^(-<m,u_a>),

where u_a is the primitive integral normal and f_a has positive coefficients and constant term one.

Let W_path be the linear span of every root degree appearing in a nontrivial combined local wall function encountered by this path. Then

    W_path=span supp(log A_g^-)=V_g.                (3.1)

One inclusion follows because the logarithm of a product of wall automorphisms uses sums of their root degrees. For the converse, let W=span supp(log A_g^-), and suppose some crossed wall has a root degree outside W. Choose such a degree p with smallest total degree. Every lower-degree contribution of every crossed wall lies in W.

In a wall function of the primitive direction a parallel to p, p is its first nonzero degree outside W: if a lower nonzero multiple of a occurred, then a, and hence p, would already lie in W. Thus its coefficient in log f_a equals its coefficient in f_a and is strictly positive. In the degree-p coefficient of the logarithm of the full product, a nonlinear Baker--Campbell--Hausdorff term either uses only lower roots in W, and so has degree in W, or uses an outside root of degree at least |p| and has total degree larger than |p|. Neither can contribute at p.

The remaining linear contributions from all crossed walls of degree p have the same orientation and the same primitive normal. Their nonzero coefficients have the same sign, so their sum cannot vanish. Hence p occurs in log A_g^-, contradicting p outside W. This proves (3.1).

For nongeneric g, perform this argument at each finite degree with the established positive-zero-side endpoint perturbation. In that finite truncation the crossed roots are exactly the negative-sign factors; zero roots remain on the positive side. The degreewise arguments are compatible as the truncation grows. This defines the same root span (2.1), without requiring one fixed infinitesimal perturbation to represent every degree.

Thus the span of the crossed wall roots is independent of the chosen admissible straight path, because it equals the intrinsic negative-factor support span. This is a statement about the span, not equality of the lists of crossed walls.

## 4. Relation to the unfinished finite-support problem

The theorem identifies every stable fluctuation direction using actual negative scattering roots. It does not yet show that all degrees in the single theta expansion F_g lie in this space. The possible stronger statement

    span supp F_g=V_g

requires an additional theta-specific mechanism, such as a valid projection or support-propagation argument for broken lines. It is not a consequence of the analytic quasi-power estimate or of Newton homogeneity alone. No such equality is used in (2.1)--(3.1).
