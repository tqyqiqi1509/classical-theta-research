# A pressure upper bound for individual structure coefficients

2026-11-13. A useful consequence, not an independent replacement for the coefficient construction or a finite-support stopping rule.

## 1. Uniform positive evaluation bound

For a positive z in the common small domain, the label-uniform self-germ theorem gives an explicit finite E(z) such that

    0 <= log F_m(z)-L_z(m) <= E(z)

for every integral m. One can take E(z)=-log(1-q_z), where q_z is the explicitly controlled transported radial norm in `../ray_pressure_mechanism/UNIFORM_SELF_ENDPOINT_MAJORANT.md`, Section 7.

For any finite list of integral labels g_1,...,g_k, put G=sum_i g_i, and write its principal structure coefficient as c(g_1,...,g_k;q). Positive multiplication contains the summand

    c(g_1,...,g_k;q) z^q F_(G+Bq)(z)

inside product_i F_(g_i)(z). Therefore

    c(g_1,...,g_k;q)
       <= exp(k E(z)) z^(-q)
          exp(sum_i L_z(g_i)-L_z(G+Bq)).             (1.1)

The leading scalar coefficient is 1 at q=0. All frozen shifts remain distinct even if B has a kernel. The estimate uses the lower bound on the output theta factor and the upper bound on the k inputs; no estimate depending on the output-label norm is lost.

## 2. Scaled inputs and output degrees

Let q_n be nonnegative integral vectors with q_n/n -> u in R_>=0^r, and let c_n(q_n)=c(ng_1,...,ng_k;q_n). By homogeneity and continuity of L,

    limsup_(n->infinity) (1/n) log c_n(q_n)
      <= sum_i L_z(g_i)-L_z(G+Bu)-<u,log z>,         (2.1)

with log 0=-infinity. This holds for every positive z in the common domain, so the infimum over such z is also a valid upper bound. The additive k E(z) disappears after division by n.

Formula (2.1) is a Chernoff-type positive-evaluation bound. Its value is the uniform theta pressure input and the absence of an output-height loss. It is not a complete large-deviation principle, does not give a matching lower bound, and does not by itself identify the Newton support. In particular, because the certified domain is small and u>=0, the term -<u,log z> generally increases with degree. There is no claim that this bound supplies a finite Laurent stopping certificate.

## 3. An information-theoretic strengthening of compatible multiplication

Let mu_n be the law of the sum of independent input exponent vectors and nu_n the exponent law for nG. The exact positive mixture gives

    mu_n >= w_n(0) nu_n

pointwise. Hence the one-sided relative entropy and chi-squared divergence satisfy

    D_KL(nu_n || mu_n) <= -log w_n(0),
    chi_squared(nu_n || mu_n) <= 1/w_n(0)-1.         (3.1)

The first inequality follows from nu_n/mu_n<=1/w_n(0). For the second,

    sum nu_n^2/mu_n -1 <= (1/w_n(0)) sum nu_n -1.

If the input labels share a closed normal cone of the analytic scattering body, then w_n(0)=1-O(exp(-c sqrt(n))), and both divergences in (3.1) are O(exp(-c sqrt(n))). More generally the relative entropy is at most n delta_z+O(exp(-c sqrt(n))), with delta_z the explicit support-function deficit.

No reverse relative-entropy bound is asserted: the mixture can have support outside the unshifted exponent law. The divergence bounds and mixture comparison are elementary probability principles; the theta-specific quantitative input is the common-domain ray estimate.
