# Independent review of analytic theta consequences

2026-11-13. Classical principal-coefficient cluster theta functions; skew-symmetric and skew-symmetrizable matrices. This is a fresh review of the actual arguments in `../ray_pressure_mechanism/THETA_RAY_GAUSSIAN_AND_RATIO.md` and `MULTIPLICATION_ENTROPY_AND_FAN.md`, using the independently reviewed common-domain theorem as an input.

## Verdict and precise input

**PASS**, with the full principal degree convention retained. For one matrix-dependent complex seed neighborhood, uniformly in every integral label g,

    F_(ng)(z)=exp(n L_z(g)) (1+R_(n,g)(z)),
    sup_K |R_(n,g)| <= A_K exp(-c_K sqrt(n)),

on every smaller compact neighborhood. The stable exponential H_g=exp(L_g) is zero-free, H_g(0)=1. This does not assert that H_g has nonnegative coefficients. All probability arguments below use the positive F_(ng), never H_g as a probability generating function.

## 1. Principal multiplication: the zero-degree distinction is essential

The exact completed identity is

    product_i F_(ng_i)(z)
      =sum_(q>=0) c_n(q) z^q F_(nG+Bq)(z),
    G=sum_i g_i,       c_n(q)>=0,       c_n(0)=1.

This is the already proved principal multiplication formula. Its zero-degree assertion follows from pointedness in the full principal grading. It is not an assertion that the coefficient-ring coefficient of the mutable label nG is exactly the scalar 1: when B has a kernel, q>0 may have Bq=0. Such a term has a nonzero frozen shift and is a separate event.

Every summand is nonnegative at a positive point in the common domain. Coefficientwise finite sums and monotone convergence give the stated evaluation identity. Its zero-degree component consequently has probability

    w_n(0)=F_(nG)/product_i F_(ng_i).

Applying the uniform ray estimate to the k input labels and their sum proves

    w_n(0)=exp(-n delta_z) (1+O_k(exp(-c sqrt(n)))),
    delta_z=sum_i L_z(g_i)-L_z(G).

The constant is uniform in the labels when k is fixed. The label G=0 causes no difficulty: F_0=H_0=1 exactly.

For any compact convex body with support function L, delta=0 if and only if the exposed faces of the input labels have a common point. More precisely, in that case

    Face(G)=intersection_i Face(g_i).

Indeed, a maximizer for G has a sum of nonnegative individual support deficits equal to delta. Thus every input label belongs to the normal cone of the exposed face Face(G). This is the clean version for using the previously proved full inverse-limit fan theorem; it avoids any assumption that a point of a nonpolyhedral body must itself be exposed.

The exact exponent-law mixture follows by coefficient extraction:

    Law(sum_i independent P_(ng_i,z))
       =sum_q w_n(q) Law(q+P_(nG+Bq,z)).

Therefore, in the compatible-face case, its total variation distance from Law(P_(nG,z)) is at most 1-w_n(0), hence stretched-exponentially small. The argument also proves the arbitrary n,m split statement on one ray. A central limit theorem alone would not imply this total variation conclusion; here it follows from an actual positive mixture.

## 2. Quasi-powers and all derivative claims

At fixed strictly positive z, a small complex polydisc in t has z exp(t) in the common analytic domain. For large n, 1+R is uniformly within 1/2 of 1 there, so the analytic logarithm exists with

    log E exp(<t,P_n>)
       =n (L_(z exp t)(g)-L_z(g))+E_n(t),
    sup |E_n|=O(exp(-c sqrt(n))),       E_n(0)=0.

Cauchy's derivative estimates justify every fixed-order cumulant statement. In particular, mean and covariance errors are stretched-exponentially small, with no hidden order-one prefactor. Positive semidefiniteness of the limiting covariance follows from actual covariance matrices. Nonnegativity of its mean vector follows from the nonnegative exponent support.

The characteristic-function proof of the multivariate Gaussian limit is valid for singular covariance as well. For the quantitative lower-orthant bound, the paper correctly requires positive definite covariance. Any fixed projection with positive definite projected covariance has a complex polydisc after shrinking the radius, so the same quantitative theorem applies to it. The zero label is covered by the degenerate Gaussian statement, not by the positive-definite estimate.

I reopened the primary full paper of Heuberger--Kropf, arXiv:1609.09599, and checked Theorem 1 and Proposition 1.1 directly. Theorem 1 explicitly gives the singular weak limit and explicitly warns that a uniform distribution-function rate need not hold in that case. The present manuscript preserves this distinction. The covariance/cumulant formulas can also be derived directly by Cauchy estimates, as above.

## 3. Newton, quotients, and the generating series

The mutable exponent formula ng+B P_n respects the stated principal convention; frozen exponents remain distinguished before aggregation. The Fisher information identity is the standard identity for a positive exponential family and gives exactly the actual covariance.

The Newton statement requires the independently checked input Newt(F_(ng))=n Newt(F_g) and finiteness of F_g. Under those hypotheses the mean limit is in the Newton polytope. The manuscript deliberately does not claim relative interior from the ray estimate alone. This is correct: abstract positive families such as F_n(z)=1+z^n have the same type of local unit-prefactor asymptotic with H=1 but a boundary mean. That family is only a warning about the logical implication, not an asserted theta example.

The locally uniform quotient F_(n+1)/F_n tends to H, because the residual denominator is eventually uniformly nonzero. The normalized ray generating series splits into 1/(1-T) plus a series with stretched-exponentially decaying coefficients. Thus its remainder and all fixed derivatives extend continuously to the circle; this is not a meromorphic extension theorem. Under a separate rationality hypothesis all boundary poles of the remainder are removable, giving the unique smallest-modulus simple pole and residue stated in the manuscript. No unconditional rationality is inferred.

## 4. Primary sources and novelty separation

- Heuberger--Kropf, *Higher Dimensional Quasi-Power Theorem and Berry--Esseen Inequality*, arXiv:1609.09599, Theorem 1 and Proposition 1.1: https://arxiv.org/pdf/1609.09599 . Directly read. Old probability machinery, not a new theorem of this project.
- GHKK, *Canonical bases for cluster algebras*, arXiv:1411.1394: https://arxiv.org/abs/1411.1394 . Existing positive multiplication and principal pointedness input; the current review also checked the local proof in `../dyck_flow_round2/SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md`, especially Sections 6--7 and the kernel-B qualification.
- Fock--Goncharov, *Cluster ensembles, quantization and the dilogarithm*, arXiv:math/0311245: https://arxiv.org/abs/math/0311245 . Existing scaling-pairing agenda; the new claim remains the explicit local common-domain theorem and its quantitative consequences.

The probability mixture construction and support-face equality criterion are elementary existing principles. The new candidate theta content is the actual common-domain asymptotic, its stretched-exponential error, and the resulting quantitative multiplication behavior in arbitrary classical type. Searches found related random-crystal and positive-convolution literature; these must be treated as antecedents for the probabilistic language, not as counterexamples to the theta argument. Absence of a matching search result is not a priority proof.
