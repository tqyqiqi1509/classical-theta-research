"""Targeted independent algebra checks for stable-log scattering polytopes.

This does not rerun the existing all-chamber/global-inequality computation.
It stresses irregular downward root sets, noncommutative zero factors,
normalization, and the first positive multiplication obstruction.  Algebra is
over Fraction. The cluster block reuses ONLY the existing total-transport
coefficient oracle; factorization, log, arbitrary-downset extraction and
structure inversion are independently implemented here.
"""
from fractions import Fraction as F
from itertools import product
from math import factorial, gcd, lcm
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'))
from incoming_recursion import IncomingSchur

def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def le(a,b): return all(x<=y for x,y in zip(a,b))
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def mv(B,a): return tuple(dot(row,a) for row in B)
def clean(a): return {p:F(v) for p,v in a.items() if v}
def order(J): return sorted(J,key=lambda p:(sum(p),p))
def downset(*tops):
    return order(set().union(*(set(product(*(range(x+1) for x in p))) for p in tops)))
def polyadd(a,b,c=1):
    out=dict(a)
    for p,v in b.items(): out[p]=out.get(p,F(0))+c*v
    return clean(out)
def polymul(a,b,J):
    out={}
    for p,v in a.items():
        for q,w in b.items():
            r=add(p,q)
            if r in J: out[r]=out.get(r,F(0))+v*w
    return clean(out)
def polylog(a,J):
    z=tuple(0 for _ in next(iter(J))); a=polyadd(a,{z:1},-1)
    out={}; power={z:F(1)}
    for k in range(1,max(map(sum,J))+1):
        power=polymul(power,a,J)
        out=polyadd(out,power,F((-1)**(k-1),k))
    return out
def polyexp(a,J):
    z=tuple(0 for _ in next(iter(J)));out={z:F(1)};power=dict(out)
    for k in range(1,max(map(sum,J))+1):
        power=polymul(power,a,J)
        out=polyadd(out,power,F(1,factorial(k)))
    return out
def matrix_identity(J): return {(p,p):F(1) for p in J}
def matrix_add(a,b,c=1): return polyadd(a,b,c)
def matrix_mul(a,b):
    right={}
    for (r,q),w in b.items(): right.setdefault(r,[]).append((q,w))
    out={}
    for (p,r),v in a.items():
        for q,w in right.get(r,[]): out[p,q]=out.get((p,q),F(0))+v*w
    return clean(out)
def matrix_exp(A,J):
    out=matrix_identity(J);power=dict(out)
    for k in range(1,max(map(sum,J))+1):
        power=matrix_mul(power,A)
        out=matrix_add(out,power,F(1,factorial(k)))
    return out
def action(A,poly):
    out={}
    for (p,q),v in A.items():
        out[p]=out.get(p,F(0))+v*poly.get(q,0)
    return clean(out)
def root_matrix(B,D,m,a,J):
    Jset=set(J);out={}
    for q in J:
        p=add(q,a)
        if p in Jset:
            val=dot(a,tuple(D[i]*(m[i]+mv(B,q)[i]) for i in range(len(D))))
            if val:out[p,q]=F(val)
    return out
def lie_matrix(B,D,m,coeff,J):
    out={}
    for a,c in coeff.items(): out=matrix_add(out,root_matrix(B,D,m,a,J),c)
    return out
def negative_factor(C,g,D,J):
    """Strict negative versus nonnegative split, by a triangular recurrence."""
    minus=matrix_identity(J); plus=matrix_identity(J)
    intervals=sorted(((p,q) for p in J for q in J if p!=q and le(q,p)),
                     key=lambda pq:(sum(sub(*pq)),pq))
    for p,q in intervals:
        val=C.get((p,q),0)-sum(minus.get((p,r),0)*plus.get((r,q),0)
            for r in J if r!=p and r!=q and le(q,r) and le(r,p))
        a=sub(p,q)
        if val:
            (minus if dot(g,tuple(d*x for d,x in zip(D,a)))<0 else plus)[p,q]=val
    assert matrix_mul(minus,plus)==C
    return minus
def evaluated(poly,w,t):return sum(v*t**dot(w,p) for p,v in poly.items())
def first_layer(poly,w):
    if not poly:return None,{}
    d=min(dot(w,p) for p in poly)
    return d,{p:v for p,v in poly.items() if dot(w,p)==d}
def dumped(poly):return [[list(p),str(v)] for p,v in sorted(poly.items())]

def synthetic_local_tests():
    cases=[([[0,1,2],[-1,0,3],[-2,-3,0]],[1,1,1]),
           ([[0,3,3],[-2,0,2],[-1,-1,0]],[2,3,6])]
    out=[]
    for B,D in cases:
      for nonprimitive in [False,True]:
        J=downset((3,3,0),(2,2,2));Jset=set(J);zero=(0,0,0)
        a=(1,1,0);aa=tuple(x*d for x,d in zip(a,D));delta=gcd(*aa)
        g0=(D[1],-D[0],100)
        gm=sub(tuple(2*x for x in g0),(1,0,0));gp=add(tuple(2*x for x in g0),(1,0,0))
        wall={zero:F(1), (2,2,0):F(2), (3,3,0):F(1)} if nonprimitive else {zero:F(1),a:F(1)}
        psi={p:-v/delta for p,v in polylog(wall,Jset).items()}
        zlog={p:v/p[0] for p,v in psi.items()}
        aminus={(0,1,0):F(-3,2),(0,2,0):F(2,3)}
        aplus={(1,0,0):F(4,5),(0,0,1):F(-2,7)}
        gradients=[]
        for i in range(3):
            m=tuple(int(j==i) for j in range(3))
            Am=matrix_exp(lie_matrix(B,D,m,aminus,J),J)
            Zm=matrix_exp(lie_matrix(B,D,m,zlog,J),J)
            Ap=matrix_exp(lie_matrix(B,D,m,aplus,J),J)
            C=matrix_mul(matrix_mul(Am,Zm),Ap)
            Ngm=negative_factor(C,gm,D,J);Ngp=negative_factor(C,gp,D,J)
            assert Ngm==matrix_mul(Am,Zm)
            assert Ngp==Am
            gradients.append(polyadd(polylog(action(Ngm,{zero:1}),Jset),polylog(action(Ngp,{zero:1}),Jset),-1))
        Az=matrix_exp(lie_matrix(B,D,zero,aminus,J),J)
        Q=action(Az,psi)
        for i in range(3): assert gradients[i]=={p:aa[i]*v for p,v in Q.items() if aa[i]*v}
        checks=[]
        for w in [(1,1,1),(1,2,3),(4,1,1)]:
            d,layer=first_layer(Q,w);leading=sum(layer.values());assert leading<0
            tail=sum(abs(v) for p,v in Q.items() if dot(w,p)>d)
            t=min(F(1,2),(-leading)/(2*tail)) if tail else F(1,2)
            assert evaluated(Q,w,t)<0
            checks.append({'w':w,'first_weight':d,'first_coefficient':str(leading),'small_t':str(t)})
        out.append({'B':B,'D':D,'irregular_downset_size':len(J),'nonprimitive_first_root':nonprimitive,
                    'Q':dumped(Q),'weight_checks':checks})
    return out

def noncommutative_boundary_test():
    B=[[0,1,2],[-1,0,3],[-2,-3,0]];D=[1,1,1];g=(1,-1,0)
    J=order(p for p in product(range(5),repeat=3) if sum(p)<=4);zero=(0,0,0)
    a=(1,1,0);b=(0,0,1);c=(0,1,0)
    A=root_matrix(B,D,g,a,J);Bmat=root_matrix(B,D,g,b,J)
    comm=matrix_add(matrix_mul(A,Bmat),matrix_mul(Bmat,A),-1)
    expected={k:5*v for k,v in root_matrix(B,D,g,add(a,b),J).items()}
    assert comm==expected and comm
    Z=matrix_exp(matrix_add(A,Bmat),J);Am=matrix_exp(root_matrix(B,D,g,c,J),J)
    assert action(Z,{zero:1})=={zero:F(1)}
    assert action(matrix_mul(Am,Z),{zero:1})==action(Am,{zero:1})
    wrong=polyadd(action(matrix_mul(Z,Am),{zero:1}),action(Am,{zero:1}),-1)
    assert wrong
    return {'omega':5,'zero_group_fixes_label':True,'not_central':True,'wrong_order_difference':dumped(wrong)}

def theta_in_downset(R,g,J):
    zero=J[0];out={zero:F(1)}
    for p in J[1:]:
        terminal=R.shift(g,p)
        I=[q for q in J if le(q,p) and (q==p or dot(terminal,tuple(R.D[i]*(p[i]-q[i]) for i in range(R.n)))<0)]
        row={p:F(1)}
        for q in reversed(I[:-1]):
            row[q]=-sum(row.get(r,0)*R.c(sub(r,q),R.shift(g,q)) for r in I if r!=q and le(q,r))
        val=-sum(row[q]*out.get(q,0) for q in I if q!=p)
        if val:out[p]=val
    return out
def stable_log(R,g,J):
    C={(p,q):F(R.c(sub(p,q),R.shift(g,q))) for p in J for q in J if le(q,p)}
    H=action(negative_factor(clean(C),g,R.D,J),{J[0]:F(1)})
    return polylog(H,set(J))
def threshold(R,g,J):
    ret=F(0)
    for p in J:
        for a in J[1:]:
            den=dot(g,tuple(R.D[i]*a[i] for i in range(R.n)))
            if le(a,p) and den:
                num=dot(mv(R.B,p),tuple(R.D[i]*a[i] for i in range(R.n)))
                ret=max(ret,abs(F(num,den)))
    return ret
def structure_in_downset(R,g,h,J):
    zero=J[0];summed=add(g,h);Fs={}
    target=polymul(theta_in_downset(R,g,J),theta_in_downset(R,h,J),set(J))
    out={}
    for q in J:
        val=target.get(q,0)-sum(c*Fs[p].get(sub(q,p),0) for p,c in out.items() if p!=q and le(p,q))
        if val:
            out[q]=val
            remaining=order(s for s in J if add(s,q) in set(J))
            Fs[q]=theta_in_downset(R,R.shift(summed,q),remaining)
    return out
def cluster_obstruction_tests():
    cases=[([[0,1],[-1,0]],[1,1],downset((3,1),(1,3)),[((-2,1),(-1,2)),((-1,1),(-2,2)),((1,0),(0,1)),((0,0),(-2,1))]),
           ([[0,3],[-2,0]],[2,3],downset((3,1),(1,3)),[((-3,2),(-2,3)),((-1,0),(2,1)),((-3,1),(-6,2))]),
           ([[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],downset((1,1,1),(2,0,0)),[((-1,1,0),(1,0,-1)),((1,-1,0),(-1,1,0)),((1,-1,0),(2,-2,0)),((0,0,0),(-1,1,1))]),
           ([[0,2,0],[-1,0,1],[0,-2,0]],[1,2,1],downset((3,0,0),(0,0,2)),[((-1,1,0),(1,-1,0)),((0,1,0),(0,-1,0))])]
    results=[]
    for B,D,J,pairs in cases:
        R=IncomingSchur(B,D)
        for g,h in pairs:
            k=add(g,h);Lg=stable_log(R,g,J);Lh=stable_log(R,h,J);Lk=stable_log(R,k,J)
            defect=polyadd(polyadd(Lg,Lh),Lk,-1)
            th=max(threshold(R,x,J) for x in (g,h,k));N=th.numerator//th.denominator+1
            if N<1:N=1
            layers=[]
            for scale in [N,N+1]:
                ng=tuple(scale*x for x in g);nh=tuple(scale*x for x in h)
                for label,L in [(ng,Lg),(nh,Lh),(add(ng,nh),Lk)]:
                    assert theta_in_downset(R,label,J)==polyexp({p:scale*v for p,v in L.items()},set(J))
                constants=structure_in_downset(R,ng,nh,J)
                assert all(v>=0 and v.denominator==1 for v in constants.values())
                assert constants.get(J[0])==1
                nonconstant={p:v for p,v in constants.items() if p!=J[0]}
                assert bool(nonconstant)==bool(defect)
                for w in [tuple(1 for _ in D),tuple(i+1 for i in range(len(D)))]:
                    d,layer=first_layer(defect,w)
                    if d is None:continue
                    assert all(v>=0 and v.denominator==1 for v in layer.values())
                    assert all(dot(w,p)>=d for p in nonconstant)
                    assert all(nonconstant.get(p,0)==scale*defect.get(p,0) for p in J if dot(w,p)==d)
                    layers.append({'N':scale,'w':w,'weight':d,'defect_coefficients':dumped(layer)})
            results.append({'B':B,'D':D,'downset':J,'g':g,'h':h,'threshold':str(th),'N':N,'compatible':not bool(defect),'first_layers':layers})
    return results

def necessity_examples():
    # Q[z]/(z^3): evaluating after truncation is linear, never a ring map.
    J={(0,),(1,),(2,)};z={(1,):F(1)}
    zz=polymul(z,z,J);zero=polymul(zz,z,J)
    assert evaluated(zero,(1,),F(1,2))==0
    assert evaluated(zz,(1,),F(1,2))*evaluated(z,(1,),F(1,2))==F(1,8)
    # Rank-one cluster: h(g)=max(-g,0)(t-t^2/2). At t=2 the fan
    # collapses; at t=3 the support inequality h(1)+h(-1)>=h(0) fails.
    rankone={ (1,):F(1),(2,):F(-1,2)}
    assert evaluated(rankone,(1,),F(2))==0
    assert evaluated(rankone,(1,),F(3))==-F(3,2)
    # A genuine A2 cluster calculation: positivity of EVERY coordinate of w
    # is essential, and t=1 is already too large at total root degree two.
    R=IncomingSchur([[0,-1],[1,0]],[1,1])
    J2=order(p for p in product(range(3),repeat=2) if sum(p)<=2)
    u=(-1,-3);v=(1,-3)
    defect=polyadd(polyadd(stable_log(R,u,J2),stable_log(R,v,J2)),stable_log(R,add(u,v),J2),-1)
    assert defect=={(1,0):F(1),(1,1):F(-1),(2,0):F(-1,2)}
    assert evaluated(defect,(1,1),F(1))==-F(1,2)
    assert evaluated(defect,(1,0),F(1,10))==-F(1,200)
    return {'evaluation_nonhom_counterexample':{'E(z^2*z)':0,'E(z^2)*E(z)':'1/8'},
            'small_t_indispensable':{'h_t2(-1)':0,'h_t3(1)+h_t3(-1)':'-3/2','h_t3(0)':0},
            'cluster_weight_counterexample':{'B':[[0,-1],[1,0]],'D':[1,1],'J':'total degree <=2','u':u,'v':v,
                'defect':dumped(defect),'w11_t1':'-1/2','w10_any_t':'-t^2/2'},
            'infinite_face_example':{'K':'sum_{n>=1} 2^(-n)[0,(1,1/n)]',
              'finite_closed_cone':'x+y>=0 and N*x+y>=0',
              'closed_limit_cone':'x>=0 and x+y>=0',
              'face_fiber':'(x>0 and x+y>0) or (x=0 and y>0)',
              'missing_normal_cone_face':'x=0,y>=0'}}

if __name__=='__main__':
    result={'status':'PASS','synthetic_local':synthetic_local_tests(),
            'noncommutative_boundary':noncommutative_boundary_test(),
            'cluster_obstructions':cluster_obstruction_tests(),
            'necessity_counterexamples':necessity_examples()}
    path=Path(__file__).with_name('adversarial_probe_results.json')
    path.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':result['status'],'synthetic_local_cases':len(result['synthetic_local']),
                      'cluster_pairs':len(result['cluster_obstructions']),'output':str(path)},indent=2))
