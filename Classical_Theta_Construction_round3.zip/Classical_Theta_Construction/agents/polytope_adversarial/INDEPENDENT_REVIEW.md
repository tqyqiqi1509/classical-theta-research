# Adversarial review of the stable-log scattering polytope theorem

Date: 2026-11-13 UTC / 2026-11-14 Asia/Shanghai.

## Verdict and actual changes requested

The finite theorem, the large-label multiplication compatibility criterion,
and the carefully qualified infinite closed-class realization survive this
review. I found no counterexample to their current stated scope. This verdict
is after supplying two missing geometric reasons, not a claim that the first
draft already proved them. I sent both repairs to the author, who incorporated
them in the main file:

1. An arrangement containing the supporting hyperplanes of the walls does
   **not by that observation alone** refine the supports of those walls.
   Signed-factor reconstruction of the local middle factor supplies the
   missing implication.
2. The lower-dimensional case should identify the exact affine span and
   lineality. If `S={i:e_i in J}`, they are `R^S` and `R^{S^c}` respectively.

There is also a previously reported, still mandatory, repair in the stable-ray
input: for target root `s`, the sign comparison must be made in `[0,s]`, not
on all of `J`. The stated threshold only controls roots `a<=s`.

I constructed explicit counterexamples to three tempting stronger statements:
setting `t=1` need not give convexity; permitting zero entries of the weight
vector can destroy convexity for every positive `t`; and an infinite Minkowski
sum need not have relatively open exposed-face classes or a face-closed family
of ordinary exposed-face normal cones. These do not refute the current theorem,
which keeps the necessary hypotheses and terminology.

The most promising general contribution is the exact finite support-function
construction and its effective multiplication criterion. The generic operation
of turning a sequence of finite polytopes into a summable Minkowski body is
elementary convex geometry and should not be presented as the main novelty.
Literature priority remains a separate question.

## 1. Original-source interfaces checked

The review consulted the original papers, rather than treating the earlier
internal reports as authority.

| Input | Original source and exact locus | Permitted use |
|---|---|---|
| Positive cluster walls | GHKK, arXiv:1411.1394v2, Theorem 1.13 | A representative with positive wall functions; the first nonzero coefficient has positive sign. |
| Arbitrary formal theta labels and positive multiplication | GHKK, Definition-Lemma 6.2 and Proposition 6.4(2)–(4), with Corollary 6.11 | The product is valid in the principal completion for all integral labels, not only the regular theta domain. |
| Last-exponent coefficient extraction | GHKK, proof of Proposition 6.4(3), printed p.60; compare Mandel, arXiv:1605.03202v2, proof of Theorem 1 | At finite order, choose a chart near the terminal exponent; the terminal-monomial coefficient detects the theta label. |
| Signed reconstruction | Bridgeland, arXiv:1603.00416v4, Section 3.2, Lemma 3.1 and Proposition 3.3 | The local wall is the zero factor of the total transport. Inverting his positive-to-negative total element gives the ordering used here. |
| Minimal support and finite/infinite class geometry | Reading, arXiv:1712.06968v3, Proposition 2.8, Lemma 2.11, Theorem 3.1, Propositions 3.8–3.11 | Effective support and finite class fans; the full relation is the intersection of finite relations, with closures treated explicitly. |

Primary URLs:

- https://arxiv.org/pdf/1411.1394v2
- https://arxiv.org/pdf/1603.00416v4
- https://arxiv.org/pdf/1712.06968v3
- https://arxiv.org/pdf/1605.03202v2

No Hall-to-cluster identification, generic-basis identification, potential,
reddening hypothesis, or Li–Pan claim is needed. No 2026 external theorem is
used in the proof under review.

### Why formal multiplication really has the displayed root form

This is an independent deduction from pointedness and the preceding formal
product input. In the initial principal chart, the input labels are `(u,0)`
and `(v,0)`, and every bend adds `(Bq,q)` for `q>=0`. Thus an output label has
the form `(u+v+Bq,q)`. Frozen translation factors out `y^q`. Since the initial
principal root map `q -> (Bq,q)` is injective even when `B` is singular, root
degrees remain separated. The product therefore reads

\[
 \vartheta_u\vartheta_v
 =\vartheta_{u+v}+\sum_{q>0}c_{u,v}(q)y^q\vartheta_{u+v+Bq},
 \qquad c_{u,v}(q)\in\mathbb Z_{\ge0}.
\]

The coefficient at `q=0` is exactly one because only the two unbent leading
terms can contribute. For fixed surviving root `p`, only `q<=p` can contribute;
the formal sum is finite at every coefficient. This is the required sense of
multiplication when a label does not define a Laurent polynomial.

## 2. Independent finite-algebra audit of stabilization

Let `J` be downward closed and finite, and let the nilpotent Lie action be

\[
 e_a(x^m z^q)=a^TD(m+Bq)x^m z^{q+a}.
\]

If a monomial degree is outside `J`, adding a positive root cannot put it back
inside `J`. Thus the root quotient is preserved by every operator, exponential,
product, and inverse. This is the actual reason a nonrectangular root cutoff
is allowed.

For a target `s`, work in `[0,s]`. If

\[
 N>T_J(g)=\max\left(\{0\}\cup
 \left\{\frac{|(Bs)^TDa|}{|g^TDa|}:
 s\in J,\;0<a\le s,\;g^TDa\ne0\right\}\right),
\]

then the terminal-exponent sign rule at `Ng+Bs` refines the coarse rule
`a -> g^TDa` on this smaller quotient. Write

\[
 C=A_g^-Z_gA_g^+,
 \qquad Z_g=V_{s,-}V_{s,0}V_{s,+}.
\]

The negative extraction factor is `A_g^- V_{s,-}`, in precisely that order.
Every generator in `V_{s,-}` has `g^TDa=0`, so it kills `x^{Ng}`. Hence

\[
 (A_g^-V_{s,-})^{-1}A_g^-(x^{Ng})=x^{Ng}.
\]

The candidate has the right leading coefficient and all nonleading extraction
coefficients vanish. The extraction equations are unitriangular, so
`theta_{Ng}=A_g^-(x^{Ng})` through `J`. Multiplicativity gives

\[
 F_{Ng}=H_g^N,\qquad H_g=x^{-g}A_g^-(x^g).
\]

There is no illicit exchange of an infinite limit and an algebraic operation:
all the preceding statements hold in the finite nilpotent quotient. Restriction
compatibility then produces the formal family. The consecutive ratio proves
`H_g` is integral even though its coefficients need not be nonnegative.

For total root degree at most `d`, let `M=max |D_i B_ij|`. Since

\[
 (Bs)^TDa=(B(s-a))^TDa,
\]

and `|a||s-a|<=d^2/4`, while every nonzero integral denominator is at least one,

\[
 T_J(g)\le Md^2/4.
\]

Thus `floor(Md^2/4)+1` works uniformly in all integral labels. This is a
finite-order statement; it supplies no uniform label-to-support bound for the
entire infinite theta series.

## 3. Ordering, normalization, and continuity

### 3.1 The zero factor is not central

On a coarse boundary, refinement moves a factor of `Z_g` to the **right** of
`A_g^-`. The continuity identity is

\[
 A_g^-Z_-(x^g)=A_g^-(x^g),
\]

not `Z_-A_g^-(x^g)=A_g^-(x^g)`. The first identity uses only that `Z_-` fixes
one leading monomial. Noncommutativity of the zero-root algebra is harmless.
The reversed-order identity is false in the explicit rank-three test below.

The chamber-linear formula for `L(g)=log H_g` follows from the automorphism
property on Laurent monomials. To avoid any unnecessary analytic meaning for
`x^g` at real `g`, prove gluing first at rational boundary points and extend the
linear identities to the whole real face; rational points are dense in each
rational face. This is equivalent to the formal-symbol interpretation in the
main proof.

### 3.2 A concrete symmetrizable lattice dictionary

The normalization `delta_a=gcd_i(D_i a_i)` is correct. Here is an independent
check that it matches the primitive normal on the exponent lattice, rather
than merely passing the simple-root test.

Choose `c=lcm_i D_i` and put `d_i=c/D_i`. Set

\[
 N=\mathbb Z^r,\quad N^\circ=\bigoplus_i\mathbb Z d_i e_i,
 \quad f_i=e_i^*/d_i.
\]

In the `f_i` exponent coordinates, choose the skew form so that
`p^*(e_i)=sum_j B_{ji}f_j`. For primitive root `a`, the primitive positive
element of `N^circ` parallel to `a` is

\[
 n'_a=\frac{c}{\delta_a}a.
\]

Indeed, membership is the condition that `(c/delta_a)a_i/d_i=D_i a_i/delta_a`
be integral; those integers have gcd one. Therefore

\[
 \langle \sum_i g_i f_i,n'_a\rangle
 =\frac{a^TDg}{\delta_a}.
\]

The wall action in the negative-to-positive convention is consequently
`x^g -> x^g f^{-(a^TDg)/delta_a}`. Comparing it with
`Z(x^g)=x^g exp((a^TDg)Psi_Z)` gives

\[
 \Psi_Z=-\delta_a^{-1}\log f.
\]

For example `D=(2,3,6)` and primitive `a=(3,2,1)` give `delta_a=6` and
primitive coordinate normal `(1,1,1)`, a case in which omitting the gcd would
be a genuine normalization error. The Wolfram check includes this example.

### 3.3 The exact jump is transported in the forward direction

For a generic facet with primitive root `a`, use `ell(g)=a^TDg`. The negative
factors on the two sides are `A^-Z` and `A^-`. It follows by applying `A^-`
to `Z(x^g)` that

\[
 L^-(g)-L^+(g)=\ell(g)A^-(\Psi_Z).
\]

Neither `Psi_Z` alone nor `A^{-1}(Psi_Z)` is correct. The independent tests use
nontrivial transport, including positive and negative higher coefficients, so
they would detect those substitutions.

## 4. Finite convexity and the two geometric repairs

All operations occur in the root quotient before the linear map `E_{w,t}` is
applied. There is no quotient algebra homomorphism to `Q[t]` obtained by
putting `z_i=t^{w_i}`. For example, modulo `z^3`, the product `z^2*z` is zero,
whereas the product of its two evaluations at `t=1/2` is `1/8`.

If `f-1` begins with `c z^{ka}`, `c>0`, then `Psi_Z` begins with
`-c z^{ka}/delta_a`. The operator `A^-` only adds strictly positive root
degrees, and positive `w_i` strictly increase the weight of every added root.
Thus the first nonzero coefficient of `E_{w,t}(A^-(Psi_Z))` is negative. Equal
weights for different higher roots create no difficulty. There are finitely
many facets, so the elementary tail estimate in the main proof chooses one
rational `t` for all of them.

### Repair A: the arrangement must refine wall supports, not just hyperplanes

An arbitrary finite set of half-walls gives a counterexample to the implication
“supporting hyperplanes belong to the arrangement, therefore the arrangement
refines supports.” A half-wall can terminate inside a cell of its supporting
hyperplane. Consistency is what excludes this behavior here.

A direct proof uses reconstruction. A point in the relative interior of an
arrangement cell has a fixed sign on every root in `J`. The three factors of
`C` are unique for that sign decomposition. Its zero factor is therefore
constant on that cell. At a generic codimension-one cell, reconstruction
identifies it with the local effective wall factor. Consequently that entire
cell either has trivial local transport or has the same nontrivial local
transport. This supplies the missing support subdivision statement.

Alternatively, if a rampart had a boundary point avoiding every nonparallel
root hyperplane, one could cross its boundary within that hyperplane. Reading's
Lemma 2.11 would produce a second wall through the point with a nonparallel
hyperplane, a contradiction. The argument requires effective/minimal support.

With this repair, strict bending occurs on exactly the effective codimension-one
walls. A finite convex piecewise-linear function has convex linearity domains.
Two allegedly different chambers with the same gradient would be joined inside
one such domain by a generic line crossing an effective wall, contradicting the
strict slope increase. This identifies the maximal cones. Since both finite
fans contain all faces, their maximal-cone equality identifies the whole fan.

### Repair B: exact affine span and lineality

Let `S={i:e_i in J}`. Downward closure implies `a_i=0` for every surviving root
`a` and every `i` outside `S`. Thus all generators fix `x_i`, giving `U_i=0`
for `i` outside `S`. The positive chamber has gradient zero, so the gradient
hull lies in `R^S`, with no translational ambiguity.

For each `i` in `S`, choose a generic facet point on the initial hyperplane
`g_i=0` with all other active coordinates positive. The initial wall survives
and its jump is a nonzero multiple of `e_i`. Hence differences of gradients
span every active coordinate. It follows that

\[
 \operatorname{aff} P_J=\mathbb R^S,
 \qquad \operatorname{lin}\mathcal N(P_J)=\mathbb R^{S^c}.
\]

This includes `J={0}`: the polytope is `{0}` and the unique cone is all of
`R^r`. It also covers omitted simple roots coupled to retained roots by `B`;
the omitted mutable label directions still act as lineality in this quotient.

## 5. Positive multiplication proof and the compatibility criterion

Set `Delta=L(g)+L(h)-L(g+h)` in the nilpotent root quotient. For every allowed
large integer `N`, exact stabilization yields

\[
 F_{Ng}F_{Nh}-F_{N(g+h)}
 =H_{g+h}^{N}(\exp(N\Delta)-1).
\]

Suppose `d` is the least positive `w`-weight in `supp Delta`. At every root `p`
of weight `d`, the coefficient on the right is exactly `N Delta_p`: a second
factor of `Delta` increases the weight, as does a nonconstant prefactor term.
The formal positive product from Section 1 implies `Delta_p>=0` at each such
root separately. At least one is positive. This rootwise assertion, rather
than positivity of their scalar sum alone, is what rules out equal-weight
cancellation.

The same argument applies to a componentwise-minimal root of `supp Delta`,
without imposing a weight. At such a root the structure coefficient is also
`N Delta_p`: triangularity leaves no earlier contributing structure degree.
Using two consecutive large integers proves `Delta_p` is integral. An
alternative integrality proof observes that
`exp Delta=H_g H_h/H_{g+h}` is an integral unit; its first surviving root
coefficient is `Delta_p`.

This does **not** make all coefficients of `Delta` nonnegative or integral.
The explicit A2 defect in Section 7 has negative coefficients `-1` and `-1/2`.

For the zero-defect equivalence, exponential and logarithm are inverse on the
nilpotent ideal over `Q`. Therefore a single allowed `N` gives zero product
defect if and only if `Delta=0`, if and only if all allowed `N` do. No positivity
is needed for this implication.

The remaining direction uses the finite polytope correctly. Equality

\[
 h_P(g)+h_P(h)=h_P(g+h)
\]

is equivalent to `F_P(g) intersect F_P(h)` being nonempty. That intersection
is a face and contains a vertex, so both directions lie in a common closed
vertex normal cone. This handles zero labels, boundary labels and lineality;
no open-chamber assumption is being smuggled in. A common closed cone gives
linearity of the vector-valued function `L`, hence `Delta=0`.

The same argument works for a fixed finite number of input labels: a finite
collection of exposed faces has a common point precisely when the support
function is additive on their sum. The universal stabilization scale already
controls each input and the sum.

## 6. Infinite Minkowski sums: correct theorem and a sharp warning

Let `P_N` have the prescribed finite fans and choose positive `b_N` such that
`sum b_N sup_{x in P_N}||x||` converges. The summation map from `product P_N`
is uniformly convergent, so its image `K` is compact and convex. Every exposed
face is

\[
 F_K(g)=\sum_N b_NF_{P_N}(g).
\]

The key inclusion equivalence in the main proof is valid:

\[
 F_K(g)\subseteq F_K(h)
 \Longleftrightarrow
 F_{P_N}(g)\subseteq F_{P_N}(h)\quad\text{for every }N.
\]

For the nontrivial direction, choose a nonmaximizing `N`th summand if one
exists and arbitrary maximizing `g`-summands elsewhere. Its `h`-deficit is a
sum of nonnegative numbers with one strictly positive term. Nonuniqueness of
Minkowski decompositions does not undermine this proof: it compares a fixed
point with its support value using a valid decomposition.

Write `E_N(g)` for the finite relative-open class and `C_N(g)` for its closure.
If `h` belongs to every `C_N(g)`, then
`(1-s)h+s g` belongs to every `E_N(g)` for `0<s<=1`. Letting `s` tend to zero
proves

\[
 \overline{\bigcap_N E_N(g)}=\bigcap_N C_N(g)
 =N_K(F_K(g)).
\]

This also proves the full compatibility claim that was only stated briefly in
the main text. If `g,h` share a closed finite cone at every cutoff, then they
both lie in `C_N(g+h)` at each cutoff. Indeed, under support additivity,
`F_N(g+h)=F_N(g) intersect F_N(h)`. Thus `g,h` lie in the single full closed
class `C(g+h)=intersection_N C_N(g+h)`. No compactness selection of unrelated
finite cones is needed.

### Explicit infinite counterexample to the stronger normal-fan vocabulary

Consider

\[
 K=\sum_{n\ge1}2^{-n}[0,(1,1/n)],
 \qquad v=\sum_{n\ge1}2^{-n}(1,1/n)=(1,\log 2).
\]

The series converges absolutely. The face exposed by `g=(0,1)` is `{v}`.
A direction `(x,y)` exposes exactly this point if and only if
`x+y/n>0` for every `n`, so its exposed-face class is

\[
 E=\{x>0,\ x+y>0\}\ \cup\ \{x=0,\ y>0\}.
\]

Its closure and its normal cone are

\[
 C=N_K(v)=\{x\ge0,\ x+y\ge0\}.
\]

Thus `E` contains the nonzero boundary ray `rho={(0,y):y>=0}` of `C` but does
not equal `relint C`. Moreover `rho` is not the complete normal cone of any
exposed face of `K`. Every nonzero direction on `rho` exposes the same point
`v`, whose normal cone is the strictly larger cone `C`.

At the finite level the corresponding cones are
`C_N={x+y>=0, Nx+y>=0}`. These come from finite zonotopes with integer normal
directions proportional to `(n,1)`. The same wall supports can be realized by
a consistent positive diagram with `B=0` and full hyperplane walls carrying
`1+z_1^n z_2`; commuting wall actions make consistency immediate. This is a
general positive diagram, **not** the cluster diagram for `B=0`.

The example proves that the main text must keep its explicit instruction to
adjoin all faces of closed-class cones. Calling the exposed-face normal cones
alone a fan would be false in the advertised generality.

## 7. Exact computations and counterexamples

Reproducer: `adversarial_probe.py`; output: `adversarial_probe_results.json`.
All arithmetic uses rational fractions. These computations do not repeat the
existing all-chamber polytope test.

### 7.1 Noncommutative zero-group stress test

Use

\[
 B=\begin{pmatrix}0&1&2\\-1&0&3\\-2&-3&0\end{pmatrix},\quad
 g=(1,-1,0),\quad a=(1,1,0),\quad b=(0,0,1),\quad c=e_2.
\]

Both `a` and `b` have zero `g`-pairing, but `Omega(a,b)=5`. In the 35-dimensional
root quotient of total degree at most four, set
`Z=exp(e_a+e_b)` and `A=exp(e_c)`. Both Python and the independent Wolfram
plugin verified the commutator representation exactly and found

\[
 Z(x^g)=x^g,\qquad AZ(x^g)=A(x^g),
 \qquad ZA(x^g)-A(x^g)\ne0.
\]

The first wrong-order coefficient is `3 z_2 z_3`. This specifically checks the
boundary ordering, not just commutative or generic facets. The complete Wolfram
code and successful output are saved as `WOLFRAM_BOUNDARY_CHECK.wl` and
`WOLFRAM_OUTPUT.txt`.

### 7.2 Irregular root ideals and nonprimitive first terms

Four synthetic local factorization cases use the 34-root downward set
`[0,(3,3,0)] union [0,(2,2,2)]`, two exchange/symmetrizer pairs, and wall
functions `1+z^a` or `1+2z^{2a}+z^{3a}`. Independent matrix factorization checks
the exact chamber factors and all coordinate jump identities. Three different
strictly positive weights per case check first-term signs and a rational small
parameter. These cases include transported higher coefficients of both signs.
They validate the general local algebra; they are not claimed to be complete
cluster scattering diagrams with those synthetic factors.

### 7.3 Actual cluster obstruction checks

Thirteen label pairs in ranks two and three use irregular downward sets,
valued matrices, a cyclic seed, zero labels, wall labels and missing simple
roots. Each pair is checked at two consecutive integers exceeding its exact
threshold. The computation verifies stabilization, formal structure
nonnegativity, the zero-defect equivalence and the exact first-layer formula
for two positive weights. Its cluster input is the preexisting total-transport
coefficient oracle; the downset extraction, factorization, logarithms and
structure inversion are independent implementations. This is a targeted
algebra check, not independent evidence for the oracle's identification with
theta functions, which was audited from sources above.

Two nontrivial first obstructions are:

| Exchange data and pair | Exact threshold | First defect root | Coefficient | Checked scales |
|---|---:|---:|---:|---:|
| `B=[[0,1],[-1,0]], D=I; g=(-2,1), h=(-1,2)` | 3 | `(1,1)` | 1 | 4, 5 |
| `B=[[0,3],[-2,0]], D=(2,3); g=(-3,2), h=(-2,3)` | 6 | `(2,1)` | 1 | 7, 8 |

The first corresponding structure coefficient is exactly the scale `N` in
both examples. In the missing-simple-root example, opposite labels entirely
in the omitted coordinate have zero defect, as required by lineality.

### 7.4 An actual cluster counterexample to weakened weight assumptions

Take

\[
 B=\begin{pmatrix}0&-1\\1&0\end{pmatrix},\quad D=I,
 \quad J=\{p:|p|\le2\},\quad u=(-1,-3),\ v=(1,-3).
\]

Exact finite calculation gives

\[
 \Delta_J(u,v)=z_1-z_1z_2-\tfrac12z_1^2.
\]

The example also has a closed-form verification independent of the coefficient
oracle. Put `P=1+z_2+z_1 z_2`. The A2 chamber products give
`H_u=(1+z_1)P^3`, `H_v=(1+z_2)P^2` and `H_{u+v}=P^6`. Equivalently, these
follow by factoring the acyclic total action `T_1 T_2`, where
`T_i(x^m)=x^m(1+z_i)^{-m_i}`. Thus the untruncated logarithmic defect is

\[
 \Delta(u,v)=\log\frac{(1+z_1)(1+z_2)}{1+z_2+z_1z_2},
\]

whose degree-two prefix is exactly the displayed expression. This does not
contradict positivity of the full product defect: before logarithmic truncation
the corresponding ordinary product difference is `z_1 P^5`.

With `w=(1,1)`, evaluation at `t=1` gives `-1/2`, violating the support-function
subadditivity inequality. With `w=(1,0)`, evaluation is `-t^2/2` for every
positive `t`. The theorem needs both strictly positive coordinates of `w` and
a sufficiently small parameter. This example also disproves coefficientwise
nonnegativity of the whole logarithmic defect.

## 8. Literature comparison and admissible novelty claim

### Reading, arXiv:1712.06968v3

The reviewed paper constructs the full scattering fan from minimal support and
proves its convex-cone and inverse-limit properties. I did not find a finite
polytope realization or this stable-log support function there. Its general
fan theorem does not assume positive walls. The current support-function
construction uses an additional sign input and should be described as such.

### Fei, arXiv:1911.10513v6

Relevant loci are Theorem 5.17, Lemma 8.2, Proposition 8.4 and Remark 8.5. Fei
realizes prescribed finite collections of clusters using representation Newton
polytopes, treats normal fans and direct sums, and discusses an infinite-object
heuristic. These are substantial prior finite-realization and refinement
mechanisms. They do not supply the present arbitrary-matrix, prescribed-root-
truncation construction from formal theta ratios.

URL: https://arxiv.org/pdf/1911.10513v6

### Asai–Iyama, arXiv:2404.13232

The finite `M`-TF normal-fan theorem already appears in v1, dated April 2024;
there is no need to depend on the March 2026 v3 for that priority statement.
The v3 uses explicit generalized-fan terminology and develops further results.
The comparison adopted here is only that the fan for one finite-length object
is realized by its Newton polytope. The proof under review does not assume any
2026 identification with all cluster diagrams. That would require a separate
theorem, especially for arbitrary skew-symmetrizable input.

URLs:

- https://arxiv.org/pdf/2404.13232v1
- https://arxiv.org/pdf/2404.13232v3

There is an elementary reason this prior line is close: for objects with
dimension vectors in a fixed downward finite set, only finitely many possible
subobject-dimension subsets exist. Choosing representatives can reduce a
bounded categorical fan comparison to finitely many Newton polytopes. Any
categorical subclass where this identifies the desired scattering truncation
must be credited, not repackaged as a new unrestricted theorem. The new route
avoids requiring such objects or a categorical identification as input.

### An overbroad sentence in a physics thesis is not a general proof

Aidan Herderschee's 2023 dissertation, Appendix A.4, says that every scattering
diagram is dual to a polytope. Its relevant main-text discussion in Section
2.5.1 explicitly restricts the asserted fan comparison to the finite case,
without proof, and its subsequent degenerations use selected Newton polytopes.
I found no arbitrary-root-truncation theorem there. The appendix sentence
cannot establish priority in the full scope asserted here.

URL: https://deepblue.lib.umich.edu/bitstream/handle/2027.42/176510/aidanh_1.pdf?sequence=1

This review establishes neither exhaustive literature coverage nor priority.
The defensible current description is a general theorem proved by the present
argument, with novelty of this precise construction still under review.

## 9. Precise adoptable scope

The following claims are supported after the stated repairs:

- For every integral skew-symmetrizable `B`, positive integral `D`, finite
  downward root set `J` and strictly positive integer weight `w`, a sufficiently
  small rational specialization of the stable logarithms is a rational convex
  homogeneous piecewise-linear support function.
- Its gradient hull realizes exactly the effective finite scattering fan,
  including all faces and the stated lineality.
- All inputs can be recovered from finitely many formal theta coefficients at
  explicitly bounded large labels.
- A single sufficiently large common scale detects whether any fixed finite
  collection of integral labels lies in a common closed truncated cone.
- Every componentwise-minimal logarithmic multiplication obstruction is a
  nonnegative integer, and the corresponding first structure coefficient is
  exactly `N` times that integer.
- A summable sequence of these polytopes realizes the full closed scattering
  classes as exposed-face normal cones; adjoining all their faces gives the
  full scattering fan in Reading's sense.

The local convexity proof actually needs only positivity of the first
effective wall coefficient in every relevant truncation. Full positivity of
all wall coefficients is a sufficient cluster-theoretic input. This may be
useful when formulating an abstract theorem, provided the reconstruction and
faithful monomial-action hypotheses remain explicit.

Claims not established include a single ordinary theta Newton polytope with
this normal fan, an analytic specialization of the full formal series at one
common nonzero point, global Laurent finiteness of all labels, a finite
description of the full infinite fan, an ordinary face-closed normal fan of
exposed faces without the stated convention, or any quantum analogue.
