(* Exact independent check, run with the Wolfram plugin on 2026-11-13 UTC. *)
b = {{0, 1, 2}, {-1, 0, 3}, {-2, -3, 0}};
g = {1, -1, 0};
aa = {1, 1, 0}; bb = {0, 0, 1}; cc = {0, 1, 0};
roots = SortBy[Select[Tuples[Range[0, 4], 3], Total[#] <= 4 &],
  {Total, Identity}];
dim = Length[roots];
ee[a_] := Table[
  If[roots[[i]] == roots[[j]] + a, a.(g + b.roots[[j]]), 0],
  {i, dim}, {j, dim}];
(* Explicit nilpotent exponential avoids the evaluator's MatrixPower[m,0]
   behavior in an earlier unsuccessful call. *)
ex[m_] := IdentityMatrix[dim] + m + m.m/2 + m.m.m/6 + m.m.m.m/24;
ea = ee[aa]; eb = ee[bb]; ec = ee[cc];
zz = ex[ea + eb]; ac = ex[ec]; v = UnitVector[dim, 1];
comm = ea.eb - eb.ea - (aa.b.bb) ee[aa + bb];
wrong = (zz.ac - ac.zz).v;
changed = Select[MapThread[List, {roots, wrong}], Last[#] != 0 &];
dd = {2, 3, 6}; ar = {3, 2, 1};
delta = Apply[GCD, dd ar]; denom = Apply[LCM, dd];
<|
 "rootCount" -> dim,
 "omega" -> aa.b.bb,
 "representationCommutatorExact" -> SameQ[comm, ConstantArray[0, {dim, dim}]],
 "zeroGroupFixesLabel" -> SameQ[zz.v, v],
 "correctBoundaryOrderExact" -> SameQ[ac.zz.v, ac.v],
 "reversedOrderDiffers" -> UnsameQ[zz.ac.v, ac.v],
 "reversedOrderDifference" -> changed,
 "primitiveNormalTest" -> <|
   "D" -> dd, "a" -> ar, "delta" -> delta,
   "primitiveCoordinateNormal" -> dd ar/delta,
   "GHKKd" -> denom/dd,
   "primitiveRootMultiple" -> denom/delta
   |>
 |>
