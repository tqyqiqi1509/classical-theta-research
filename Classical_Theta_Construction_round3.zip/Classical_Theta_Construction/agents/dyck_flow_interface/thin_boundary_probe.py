from pathlib import Path
from itertools import combinations, product
from collections import Counter
from math import gcd
import sys,json
ROOT=Path('/workspace/scratch/0e6dfa966050/theta_20261114')
sys.path.insert(0,str(ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/computations'))
sys.path.insert(0,str(ROOT/'agents/intrinsic_greedy_round2'))
from tight_grading_two_input import tight_profiles,dyck_word
from two_stack_shadow_forests import boundary_forest
from balanced_cut_transport import all_trees,stable,tree_flows

def block_labels(labels,sizes):
    if not sizes:
        if not labels: yield ()
        return
    for c in combinations(labels,sizes[0]):
        rest=tuple(x for x in labels if x not in c)
        for tail in block_labels(rest,sizes[1:]):yield (c,)+tail

def objects(a,b,k=1):
    prof,gs,rect=tight_profiles(a,b,k,1,1,True)
    word=dyck_word(*rect)
    aa,bb=a*k,b*k
    for gr in gs:
        f=boundary_forest(word,gr)
        ep=[i for i,x in enumerate(word) if x=='E' and gr[i]]
        np=[i for i,x in enumerate(word) if x=='N' and gr[i]]
        for ev,nv in product(block_labels(tuple(range(aa,aa+bb)),[gr[i] for i in ep]),block_labels(tuple(range(aa)),[gr[i] for i in np])):
            blocks=dict(zip(ep,ev));blocks.update(zip(np,nv))
            yield word,gr,f,blocks

def naive_tree(word,gr,f,blocks,reverse_e=False,reverse_n=False):
    root=f.nontrivial_roots[0]
    # The active window's canonical linear order ends at its vertical root.
    active=set(x for e in f.edges for x in e)
    start=(root-len(active)+1)%len(word)
    rank={v:(v-start)%len(word) for v in active}
    inc={root:-1}
    for v,lab in blocks.items():
        children=sorted([b for a,b in f.edges if a==v],key=rank.get,reverse=reverse_e if word[v]=='E' else reverse_n)
        assert len(children)==len(lab)
        inc.update(zip(children,lab))
    out=tuple(sorted(tuple(sorted((inc[a],inc[b]))) for a,b in f.edges))
    return out

def main():
    report=[]
    for a,b in [(1,1),(2,1),(1,2),(2,3),(3,2),(3,4),(4,3)]:
        es=[(a+j,i,0) for i in range(a) for j in range(b)]
        target=tuple(T for T in all_trees(a+b,es) if stable(a+b,es,T,(-b,)*a+(a,)*b))
        obs=list(objects(a,b))
        sample=[]
        for word,gr,f,blocks in obs[:6]:
            sample.append({'word':''.join(word),'grading':gr,'blocks':blocks,'edges':f.edges,'naive':naive_tree(word,gr,f,blocks)})
        report.append({'a':a,'b':b,'objects':len(obs),'stable_trees':len(target),'root_degrees':dict(Counter(gr[f.nontrivial_roots[0]] for word,gr,f,blocks in obs)),'samples':sample,'target':[[(es[e][0],es[e][1]) for e in T] for T in target[:8]]})
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
    print(json.dumps([{k:v for k,v in row.items() if k not in ['samples','target']} for row in report],indent=2))
if __name__=='__main__':main()
