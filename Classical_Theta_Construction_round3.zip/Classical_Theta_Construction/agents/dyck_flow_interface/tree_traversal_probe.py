from weighted_stack_candidate import *

def traversal(z,revE,revN,postE,postN):
 word,gr,f,bl=z
 root=f.nontrivial_roots[0]
 active=set(x for e in f.edges for x in e)
 start=(root-len(active)+1)%len(word)
 rank=lambda v:(v-start)%len(word)
 adj={v:[] for v in active}
 for u,v in f.edges:adj[u].append(v)
 edge_label={}
 for u,vs in adj.items():
  vs.sort(key=rank,reverse=revE if word[u]=='E' else revN)
  for v,label in zip(vs,bl.get(u,())):edge_label[u,v]=label
 seq=[]
 def dfs(v):
  for w in adj[v]:
   after=postE if word[v]=='E' else postN
   if not after:seq.append(edge_label[v,w])
   dfs(w)
   if after:seq.append(edge_label[v,w])
 dfs(root)
 return tuple(seq)

def main():
 report=[]
 for a,b in [(2,3),(3,2),(3,4),(4,3),(3,5),(5,3),(4,5)]:
  obs=list(objects(a,b));rows=[]
  for flags in product([False,True],repeat=4):
   vals=[charge_stack(traversal(z,*flags),a,b)[0] for z in obs]
   rows.append({'flags':flags,'images':len(set(vals))})
  report.append({'a':a,'b':b,'objects':len(obs),'maps':rows})
 Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
 print(json.dumps([dict(a=r['a'],b=r['b'],objects=r['objects'],best=max(x['images'] for x in r['maps']),good=[x for x in r['maps'] if x['images']==r['objects']]) for r in report],indent=2))
if __name__=='__main__':main()
