from thin_boundary_probe import objects
from balanced_cut_transport import all_trees,stable
from itertools import permutations,product
from collections import Counter
from pathlib import Path
import json

def cycles(p):
 seen=set();out=[]
 for i in range(len(p)):
  if i in seen:continue
  j=i;n=0
  while j not in seen:seen.add(j);n+=1;j=p[j]
  out.append(n)
 return tuple(sorted(out,reverse=True))

def main():
 a,b=2,3
 obs=list(objects(a,b))
 es=[(a+j,i,0) for i in range(a) for j in range(b)]
 trees=[frozenset((es[e][0],es[e][1]) for e in T) for T in all_trees(a+b,es) if stable(a+b,es,T,(-b,)*a+(a,)*b)]
 out={}
 for pv,ph in product(permutations(range(a)),permutations(range(b))):
  pi=tuple(pv)+tuple(a+x for x in ph)
  fc=sum(all(set(pi[x] for x in block)==set(block) for block in z[3].values()) for z in obs)
  ft=sum(frozenset((pi[u],pi[v]) for u,v in T)==T for T in trees)
  typ=(cycles(pv),cycles(ph));out[str(typ)]={'tight_fixed':fc,'tree_fixed':ft}
 p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
