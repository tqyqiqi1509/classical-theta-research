from thin_boundary_probe import *
from collections import defaultdict

def service_labels(word,gr,f,blocks,revE=True,revN=True):
    root=f.nontrivial_roots[0]
    active=set(x for e in f.edges for x in e)
    start=(root-len(active)+1)%len(word)
    rank={v:(v-start)%len(word) for v in active}
    inc={}
    for v,lab in blocks.items():
        children=sorted([b for a,b in f.edges if a==v],key=rank.get,reverse=revE if word[v]=='E' else revN)
        inc.update(zip(children,lab))
    return tuple(inc[v] for v in sorted(inc,key=rank.get))

def charge_stack(seq,a,b):
    heights=[0]
    for v in seq:heights.append(heights[-1]+(a if v>=a else -b))
    assert heights[-1]==0
    start=min(range(len(seq)),key=lambda i:heights[i])
    seq=seq[start:]+seq[:start]
    stk=[];edges=Counter()
    for v in seq:
        if v>=a:stk.extend([v]*a)
        else:
            for j in range(b):edges[stk.pop(),v]+=1
    assert not stk
    return tuple(sorted(edges)),dict(edges)

def main():
 report=[]
 for a,b in [(1,1),(2,1),(1,2),(2,3),(3,2),(3,4),(4,3),(2,5),(5,2),(3,5),(5,3)]:
    obs=list(objects(a,b));results=[]
    es=[(a+j,i,0) for i in range(a) for j in range(b)]
    tar={tuple(sorted((es[e][0],es[e][1]) for e in T)) for T in all_trees(a+b,es) if stable(a+b,es,T,(-b,)*a+(a,)*b)}
    for re,rn in product([False,True],repeat=2):
      vals=[charge_stack(service_labels(*z,re,rn),a,b)[0] for z in obs]
      counts=Counter(vals)
      bad=[v for v in vals if v not in tar]
      results.append({'revE':re,'revN':rn,'images':len(counts),'duplicates':sum(n-1 for n in counts.values()),'missing':len(tar-set(vals)),'bad':len(bad)})
    report.append({'a':a,'b':b,'objects':len(obs),'target':len(tar),'maps':results})
 Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
