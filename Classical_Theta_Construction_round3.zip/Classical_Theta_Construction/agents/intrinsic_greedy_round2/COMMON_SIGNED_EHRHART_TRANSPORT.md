# A finite common signed universe for lattice triangulations

Research branch: `intrinsic_greedy_round2`. Date: 2026-11-13.

**Proved here:** an explicit height-preserving bijection between the half-open
Box objects of any two lattice triangulations of one fixed lattice polytope,
obtained by bounded sign-reversing cancellation in one common finite set.
Choosing a reference triangulation makes all resulting transition maps
strictly coherent. No ranking of either fixed-point set occurs.

The Ehrhart positivity, half-open decomposition, and involution-principle
ingredients are established methods. This note claims the explicit reusable
construction and proves its precise interface; it does not claim priority for
those ingredients or for Ehrhart positivity. Section 7 identifies an actual
stable-tree consumer. Section 9 states the remaining theta interfaces.

## 1. Fixed lattice data

Let `L` be a lattice of rank `r=d+1`, let `h:L→Z` be integral, and let
`Q⊂{h=1}` be a `d`-dimensional lattice polytope. Put `K=R_{≥0}Q`.
Thus every nonzero point of `K` has strictly positive height, and each
bounded-height part of `K` is compact. Work in the lattice of the span if
the original ambient dimension is larger.

Let `𝒯` be any geometric triangulation of `Q` into full-dimensional lattice
simplices. Extra lattice vertices are allowed; regularity and unimodularity
are not required. Fix a total order of `Q∩L`, used only to order the `r`
vertices of each simplex. It is not an order of Box objects.

For a collection of triangulations choose one vector `w∈int(K)` outside the
linear spans of all their cone facets. One such `w` exists. It can even be
chosen once for **all** lattice triangulations of `Q`: the finite set `Q∩L`
has only finitely many subsets, hence only finitely many relevant facet
hyperplanes. A rational such vector can be found by finite search.

For a maximal simplex `σ`, write its ordered vertices as `u_1,…,u_r`, and
write

\[
w=\sum_{j=1}^r\lambda_j u_j,\qquad \lambda_j\ne0.
\]

Call facet `j` open if `λ_j<0`, and closed if `λ_j>0`. The half-open cone is

\[
K_\sigma^w=\left\{\sum c_j u_j:
c_j>0\text{ at open facets},\quad c_j\ge0\text{ at closed facets}\right\}.
\tag{1}
\]

These cones partition `K`. Indeed, for each `v∈K`, the nearby point
`v+εw` lies in the interior of a unique maximal cone for all sufficiently
small positive `ε`; its cone is exactly the one satisfying (1). The
direction is inward at the boundary of `K` because `w∈int(K)`.

At least one facet of each cone is closed: otherwise every `λ_j<0`, which
would contradict `h(w)=Σλ_j>0`.

## 2. Box decomposition without a unimodularity assumption

Define

\[
\Pi_\sigma^w=\left\{\sum b_j u_j:
0<b_j\le1\text{ at open facets},\quad
0\le b_j<1\text{ at closed facets}\right\}.
\tag{2}
\]

Every lattice point `v∈K_σ^w∩L` has a unique decomposition

\[
v=b+\sum_{j=1}^r n_j u_j,
\qquad b\in\Pi_\sigma^w\cap L,\quad n_j\in\mathbb Z_{\ge0}.
\tag{3}
\]

To compute it, solve for the rational coordinates `c_j` of `v`. Set

\[
n_j=\begin{cases}
\lfloor c_j\rfloor,&j\text{ closed},\\
\lceil c_j\rceil-1,&j\text{ open},
\end{cases}
\qquad b_j=c_j-n_j.
\tag{4}
\]

All `n_j` are nonnegative. The vector `b=v−Σn_ju_j` is a lattice point.
Conversely (3) remains in the same half-open cone for every nonnegative
integer vector `n`.

Every Box point has height in `{0,…,d}`. Its height is the integer `Σb_j`,
each `b_j≤1`, and at least one closed coordinate is strictly less than 1.
Consequently `0≤h(b)<r=d+1`.

The number of Box points is the lattice index
`[L:Σ_j Z u_j]`, but no choice of a bijection with an abstract set of that
cardinality is made. The actual lattice point and its rational coordinates
are retained. In the unimodular case there is exactly one Box point,

\[
b_\sigma=\sum_{j:\lambda_j<0}u_j,
\tag{5}
\]

of height equal to the number of open facets.

## 3. The common finite signed set

For `0≤k≤d` let

\[
\mathcal S_k(Q,L)=\{(v,A):v\in K\cap L,\ A\subseteq[r],\
h(v)+|A|=k\},\qquad
\operatorname{sgn}(v,A)=(-1)^{|A|}.
\tag{6}
\]

Set `𝒮=⊔_{k=0}^d 𝒮_k`. This is finite and depends on `Q,L,h` only.
In particular it contains no triangulation, simplex, stable tree, or generic
parameter as part of its data.

Given `𝒯`, locate `v` in its unique half-open cone and compute (3).
Choose the least `j∈[r]` for which `j∈A` or `n_j>0`. If there is no such
index, leave `(v,A)` fixed. Otherwise define

\[
I_\mathcal T(v,A)=
\begin{cases}
(v+u_j,A\setminus\{j\}),&j\in A,\\
(v-u_j,A\cup\{j\}),&j\notin A\text{ and }n_j>0.
\end{cases}
\tag{7}
\]

**Theorem 1.** `I_𝒯` is a grade-preserving sign-reversing involution away
from its fixed points. Its fixed-point set consists exactly of the
positive objects

\[
\mathcal B_\mathcal T^w
=\bigsqcup_{\sigma\in\mathcal T^{\max}}(\Pi_\sigma^w\cap L),
\tag{8}
\]

embedded as `(b,∅)∈𝒮`.

**Proof.** In (7) only `n_j` changes, by `+1` or `−1`. In the latter case
it was positive. Thus the point stays in the same half-open cone, and its
Box point, simplex, and ordering of the vertices remain unchanged. Every
index below `j` is still ineligible. The index `j` is still eligible and
the opposite branch applies on the next step. This proves involutivity.
The height change is canceled by the change of `|A|`, while parity reverses.
The fixed-point condition is exactly `A=∅` and `n=0`. Section 2 shows that
all such fixed points occur in grades at most `d`, so the truncation has
discarded none. Distinct half-open cones are disjoint, hence (8) is an
actual disjoint set of points. ∎

This is a finite object-level realization of

\[
(1-t)^r\sum_{v\in K\cap L}t^{h(v)}
=\sum_{b\in\mathcal B_\mathcal T^w}t^{h(b)}=h_Q^*(t).
\tag{9}
\]

The proof of Theorem 1 does not assume (9), Ehrhart positivity, or equality
of the right-hand sides for different triangulations.

## 4. Actual bijections and their termination

For two triangulations `𝒯,𝒰`, start at a fixed point `x` of `I_𝒯`.
If `I_𝒰(x)=x`, stop. Otherwise apply `I_𝒰`, then `I_𝒯`, and repeat
until a fixed point of `I_𝒰` is reached. Write the endpoint
`P_{𝒯,𝒰}(x)`.

**Theorem 2.** The procedure terminates and defines a height-preserving
bijection `P_{𝒯,𝒰}:𝓑_𝒯^w→𝓑_𝒰^w`. Its inverse is
`P_{𝒰,𝒯}`, with the path traversed backward. At most `|𝒮_k|−1`
nontrivial involution edges are used by a path in grade `k`.

**Proof.** In each grade, draw one edge of each color for the nonfixed
pairs of the corresponding involution. Every vertex has degree at most 2.
A start fixed by `I_𝒯` is an endpoint unless it is fixed by both, in which
case the path has length zero. An endpoint path in a finite degree-two
graph cannot enter a cycle. Every involution fixed point has positive sign.
Alternating signs then force the other endpoint to be fixed by `I_𝒰`,
not again by `I_𝒯`. Reversal gives the inverse, and (7) preserves grade.
The path has no repeated vertex, giving the stated bound. ∎

The only operations are rational linear solving, testing signs, taking a
floor or ceiling, and adding or subtracting one simplex vertex. An
individual path does not require first enumerating `𝒮` or either Box set.

## 5. Strict coherence from one reference

Pairwise alternating-path maps need not compose coherently. Fix a reference
triangulation `𝒯₀` and define

\[
N_\mathcal T=P_{\mathcal T,\mathcal T_0},\qquad
\Phi_{\mathcal T,\mathcal U}=N_\mathcal U^{-1}N_\mathcal T.
\tag{10}
\]

Then, as actual maps of finite sets,

\[
\Phi_{\mathcal U,\mathcal V}\Phi_{\mathcal T,\mathcal U}
=\Phi_{\mathcal T,\mathcal V},\quad
\Phi_{\mathcal T,\mathcal T}=\mathrm{id},\quad
\Phi_{\mathcal U,\mathcal T}=\Phi_{\mathcal T,\mathcal U}^{-1}.
\tag{11}
\]

Every closed polygon of transitions, including a pentagon, is therefore
the identity on each object. This is a constructive coherence statement
**relative to the chosen reference and direction**. It does not assert
that direct pairwise paths are flat, that the choices are canonical under
automorphisms, or that the resulting maps already implement a theta
associator.

Changing the reference changes the identifications by explicit bijections.
Existence of one common signed universe makes the choice controllable;
it does not make it disappear.

## 6. Computation

`ehrhart_signed_transport.py` implements (1)–(10) over exact rational
numbers. It accepts general full-dimensional lattice triangulations, not
only unimodular ones. Its supplied family contains dilated cubes in
dimensions 1–4, coarse simplices of volumes 7, 9, and 8, and unimodular
grid refinements of the same polytopes. Coordinate reflections supply
distinct triangulations with one shared direction.

The recorded run checks all states of every signed universe, verifies the
involution twice, traces each Box point to the reference and back, compares
the complete reversed paths, and verifies actual compositions around
five-step loops. All checks passed; the raw data include a longest path
for each family in `ehrhart_signed_results.json`.

| Polytope | Triangulations | Signed states | Box points per triangulation | h* vector | Longest path |
|---|---:|---:|---:|---|---:|
| `[0,7]` | 4 | 11 | 7 | `(1,6)` | 2 |
| `[0,3]^2` | 6 | 120 | 18 | `(1,13,4)` | 42 |
| `[0,2]^3` | 7 | 1280 | 48 | `(1,23,23,1)` | 98 |
| `[0,1]^4` | 5 | 3904 | 24 | `(1,11,11,1,0)` | 26 |

There are 29,244 exhaustive involution-state checks and 592 transported
Box objects in this run. These computations test the general algorithm's
boundary conventions and nonunimodular handling; the proofs above establish
its scope independently of these examples.

## 7. A genuine cographic stable-tree consumer

Let `G=(V,E)` be a connected acyclic directed multigraph. Put
`∂e_{s→t}=e_s−e_t`, `θ₀=∂1`, and let

\[
P_0=\{x\in\mathbb R_{\ge0}^E:\partial x=\theta_0\}.
\tag{12}
\]

This polytope is nonempty and bounded: `1` is feasible, and a nonnegative
circulation on an acyclic graph is zero. Its dimension is
`r=|E|−|V|+1`, since `1` has all coordinates positive.

Choose an integral cycle-lattice basis as rows of a totally unimodular
cographic matrix `A`, and denote its columns by `a_e∈Z^r`. Then
`Aᵀ:Z^r→ker(∂)∩Z^E` is an isomorphism, and the complements of spanning
trees are exactly the unimodular column bases of `A`.

For each vertex `x₀` of `P₀`, its positive support `F=supp(x₀)` is a
forest. Indeed a cycle in the support supplies a nonzero signed circulation
along which both sufficiently small perturbations remain nonnegative,
contradicting extremality. Conversely a feasible point with forest support
is a vertex. Total unimodularity of the incidence matrix makes `x₀`
integral. Therefore the uniquely determined vector `y₀` in

\[
x_0=\mathbf1-A^T y_0
\tag{13}
\]

belongs to `Z^r`. Put

\[
I_0=E\setminus F,\quad
C_F=\operatorname{pos}\{a_e:e\in I_0\},\quad
Q_F=\operatorname{conv}\{a_e:e\in I_0\}.
\tag{14}
\]

The cone `C_F` is the full-dimensional pointed normal cone of `P₀` at
`x₀` (using its cycle coordinates); its generators satisfy
`⟨y₀,a_e⟩=1`. Thus `Q_F=C_F∩{⟨y₀,·⟩=1}` is a lattice polytope of
dimension `r−1` in the **fixed** lattice `Z^r`, with integral height
`h_F=⟨y₀,·⟩`. This is the required Gorenstein cone.

The whole cographic configuration generally spans all of `R^r` as a
positive cone, so it must **not** be put into a single global height-one
slice. The localization at `F` is essential.

Take a sufficiently small generic `θ′=θ₀+εδ`, with `Σδ=0`. Choose
`w′>0` with `∂w′=θ′`. The polytope `P_{θ′}` is simple, and its vertices
are precisely its positive-flow spanning trees `T`. A tree flow is a
linear function of `θ`, obtained by summing `θ` on the fundamental cuts.
Choose `ε` small enough to preserve every nonzero `θ₀` cut sign. Then
each positive `θ′` tree has a nonnegative limit at `θ₀`, supported on a
unique forest `F`, and `F⊂T`.

In cycle coordinates the normal cone at `T` is
`pos(a_e:e∈E\T)`. It is unimodular and lies in `C_F`, since
`E\T⊂E\F`. The normal fan of `P_{θ′}` is complete; hence the cones
limiting to `F` partition `C_F` and give a unimodular triangulation

\[
\mathcal T_{F,\delta}
=\{\operatorname{conv}(a_e:e\in E\setminus T):
T\text{ positive for }\theta',\ \lim T=F\}
\tag{15}
\]

of the same `Q_F` for every generic refinement `δ`.

Repeated cographic columns require a bookkeeping remark. A generic
inequality presentation has only the least bound for any repeated column
active; two different stable trees in one refinement cannot give the same
full-dimensional cone, because distinct vertices of a polytope have
disjoint interiors of their normal cones. Retain the original edge label
with each simplex of (15); decoding that simplex back to its tree is unique
within its refinement. Zero cographic columns are bridge edges, belong to
every positive support `F`, and do not occur in `I₀`.

**Corollary 3.** For each forest `F`, choose a generic direction in `C_F`
and one reference refinement. Equations (5)–(11) give explicit mutually
inverse, coherent bijections between all positive spanning-tree sets
limiting to `F`. Taking their disjoint union gives such bijections for
all positive spanning trees near `θ₀`. The positive limiting forest is
preserved exactly. Any decorations attached to its unchanged edges can be
carried unchanged.

When `r=0`, the original graph is a tree and its positive tree set is a
singleton; the construction is the identity. There is then no nontrivial
polytope of dimension `r−1` to introduce.

## 8. Prior-art check and source decisions

1. Elia–Kim–Supina, *Techniques in Equivariant Ehrhart Theory*, published
   online 2023, Annals of Combinatorics 28 (2024), §3.2, Definitions
   3.21 and 3.26: the half-open decomposition and exactly the open/closed
   Box convention (2) are established. Their Theorems 3.30 and 3.32 impose
   specific hypotheses for equivariant permutation conclusions. We do not
   infer a Young action from an arbitrary generic direction.
   Primary text: <https://link.springer.com/article/10.1007/s00026-023-00673-z>.
2. Garsia–Milne's involution principle is the standard mechanism used in
   Theorem 2. The exact finite graph proof is included above, so no
   complexity or naturality claim beyond that proof is imported. A recent
   complexity discussion is Ekhad–Zeilberger, SIGMA 21 (2025), 015:
   <https://emis.muni.cz/journals/SIGMA/2025/015/>.
3. Rimányi, arXiv:2608.05057v1 (2026), §§9–12, was checked directly for
   the common-universe and alternating-path mechanism. Its partition
   involutions are not claimed to coincide with (7), nor with tight
   gradings. The present construction does not use a `q→1` specialization.
4. Targeted searches on 2026-11-13 for Ehrhart half-open triangulations,
   sign-reversing involutions, common signed sets, and inter-triangulation
   Box bijections located the established ingredients above. They did not
   locate the exact finite set (6) and toggle (7) packaged as this transport
   theorem. This is a search result, not a proof of historical novelty.
5. The earlier local `PRIMITIVE_CENTER_GALE_FINITE_MODEL.md` and
   `GALE_DEGREE_AND_CYCLE_TORI.md` construct finite Gale algebras and
   count stable trees via a squarefree degeneration. The explicit common
   finite signed set (6) was not present in the inspected versions.

## 9. What this supplies to theta, and the exact remaining bridges

The construction solves a concrete interface: different generic
refinements of the **same local thin cographic data** now have actual
coherent tree transports, with an explicit shared finite universe and
unchanged positive limiting support. Equality of Euler characteristics,
volumes, or determinant indices is not used as a substitute for those maps.

It does not yet identify a tight grading with a Box point. In particular,
the 2026 Burcroff–Lee–Mou–Musiker–Reineke paper, §9.2, explicitly says
that a general stable-tree/tight-grading pattern remains unavailable;
its numerical identities cannot fill this object-level step. The consumer
must supply an actual encoding and inverse.

It also does not by itself identify the local data on the two sides of a
binary theta association. If regrouping changes the child charges or their
boundary covectors, the corresponding cographic configurations and
polytopes can change. An explicit common geometric object or a compatible
decomposition must be proved before (10) can be called a theta associator.

For valued data, Theorems 1–2 genuinely allow nonunimodular lattice
simplices. But a valued phase set must first be identified with the actual
Box points in one fixed lattice, in a way compatible with (7). Equal
determinants or equal phase cardinalities do not supply that identification.

Finally, generic directions, simplex orders, and a reference refinement
need not respect equal-color permutations. The theorem supplies coherent
maps after those choices; it does not assert an equivariant descent.
