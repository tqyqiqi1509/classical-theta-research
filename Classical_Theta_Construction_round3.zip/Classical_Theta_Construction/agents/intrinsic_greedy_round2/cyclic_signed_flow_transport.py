"""Common signed graphical plethysm for cyclic axis-leaf flow trees.

Every quotient retains original cross-arrow labels and both directions;
loops internal to a partition block are discarded at that quotient.
Residual germ normalization uses actual half-open cographic Box points.
No sets of coefficient objects are paired by sorting or cardinality.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
from random import Random
from collections import Counter
import json
from stable_tree_sweep import Sweep, DegenerateProjection
from balanced_cut_transport import components, all_trees, tree_flows
from lawrence_activity_transport import cycle_matrix
from ehrhart_signed_transport import Triangulation, alternating_path


@lru_cache(None)
def partitions(S):
    if not S:
        return ((),)
    head, tail = S[0], S[1:]
    out = []
    for P in partitions(tail):
        out.append(((head,),) + P)
        for i in range(len(P)):
            Q = list(P); Q[i] = (head,) + Q[i]
            out.append(tuple(sorted(Q, key=lambda B: B[0])))
    return tuple(out)


@lru_cache(None)
def support(j):
    if j[0] == 'leaf':
        return (j[1],)
    return tuple(sorted(v for child in j[2] for v in support(child)))


@lru_cache(None)
def internal_nodes(j):
    return 0 if j[0] == 'leaf' else 1 + sum(internal_nodes(c) for c in j[2])


def state_sign(state):
    return (-1) ** sum(internal_nodes(j) for j in state[0])


def is_axis(o):
    return o[0] == 'leaf' or (o[0] == 'node' and is_axis(o[2]) and is_axis(o[3]))


class EulerianBoxes:
    """One finite Eulerian cographic configuration, possibly with loops."""
    def __init__(self, n, edges):
        self.n = n
        self.edges = tuple(edges)
        self.A = cycle_matrix(n, edges)
        self.r = self.A.rows
        assert self.r > 0
        assert all(sum(int(self.A[i, j]) for i in range(self.r)) == 1
                   for j in range(len(edges)))
        # Integral coordinates: first r-1 cycle coordinates, then height.
        self.vertices = tuple(tuple(int(self.A[i, j]) for i in range(self.r - 1))
                              for j in range(len(edges)))
        lam = tuple(3**j for j in range(len(edges)))
        self.w = tuple(sum(self.vertices[j][i] * lam[j] for j in range(len(edges)))
                       for i in range(self.r - 1)) + (sum(lam),)
        self.trees = tuple(all_trees(n, edges))
        self.tris = {}
        self.path_calls = 0
        self.path_steps = 0
        self.longest = 0

    def triangulation(self, delta):
        stable = tuple(U for U in self.trees
                       if all(x > 0 for x in tree_flows(self.n, self.edges, U, delta).values()))
        assert stable
        if stable not in self.tris:
            simplices = []
            for U in stable:
                N = tuple(e for e in range(len(self.edges)) if e not in U)
                assert len(N) == self.r
                assert abs(self.A[:, N].det()) == 1
                simplices.append(tuple(self.vertices[e] for e in N))
            tri = Triangulation('eulerian_' + str(len(self.tris)), simplices)
            tri.set_direction(self.w)
            tri.tree_to_index = {U: i for i, U in enumerate(stable)}
            tri.index_to_tree = stable
            assert len({s.vertices for s in tri.simplices}) == len(stable)
            self.tris[stable] = tri
        return self.tris[stable]

    def transport(self, U, source, target):
        left, right = self.triangulation(source), self.triangulation(target)
        i = left.tree_to_index[U]
        simplex = left.simplices[i]
        b = tuple(sum(ray[k] for ray, op in zip(simplex.rays, simplex.open) if op)
                  for k in range(self.r))
        x = (b, 0)
        assert left.involution(x) == x
        y, path = alternating_path(left, right, x)
        j = right.locate(y[0])[0]
        self.path_calls += 1
        self.path_steps += len(path) - 1
        self.longest = max(self.longest, len(path) - 1)
        return right.index_to_tree[j]


class SignedFlowUniverse:
    def __init__(self, n, original_edges):
        self.n = n
        self.original_edges = tuple(original_edges)
        self.S = tuple(range(n))
        self.quotients = {}
        self.boxes = {}
        self.residual_calls = 0

    def quotient(self, P):
        if P not in self.quotients:
            index = {v: i for i, B in enumerate(P) for v in B}
            arrows = []
            for eid, (s, t, _) in enumerate(self.original_edges):
                if s in index and t in index and index[s] != index[t]:
                    arrows.append((index[s], index[t], eid))
            sw = Sweep(len(P), arrows)
            sw.original_ids = tuple(e[2] for e in arrows)
            sw.to_local = {eid: i for i, eid in enumerate(sw.original_ids)}
            self.quotients[P] = sw
        return self.quotients[P]

    @staticmethod
    def reference_parameter(P):
        if len(P) == 1:
            return (F(0),)
        v = [F(2**i) for i in range(len(P) - 1)]
        return tuple(v + [-sum(v)])

    def theta_on(self, P, theta):
        return tuple(sum(theta[i] for i in B) for B in P)

    @lru_cache(None)
    def H(self, P, theta):
        sw = self.quotient(P); S = tuple(range(len(P)))
        return tuple(tuple(sw.original_ids[e] for e in T) for T in sw.trees(S)
                     if sw.stable(S, T, theta))

    @lru_cache(None)
    def R(self, P):
        sw = self.quotient(P); S = tuple(range(len(P)))
        v = sw.velocity(S); q = self.reference_parameter(P)
        out = []
        for T in sw.trees(S):
            fv, fq = sw.flows(S, T, v), sw.flows(S, T, q)
            if all(a > 0 or (a == 0 and b > 0) for a, b in zip(fv, fq)):
                out.append(tuple(sw.original_ids[e] for e in T))
        return tuple(out)

    @lru_cache(maxsize=100000)
    def residual_transport(self, P, Tids, source, target):
        self.residual_calls += 1
        if source == target or len(P) == 1:
            return Tids
        sw = self.quotient(P); S = tuple(range(len(P)))
        T = tuple(sorted(sw.to_local[e] for e in Tids))
        base = sw.velocity(S)
        fb = sw.flows(S, T, base)
        fs = sw.flows(S, T, source)
        assert all(a > 0 or (a == 0 and b > 0) for a, b in zip(fb, fs))
        forest = tuple(e for e, x in zip(T, fb) if x > 0)
        cs = tuple(sorted(components(len(P), [sw.edges[e] for e in forest]), key=min))
        if len(cs) == 1:
            return Tids
        ci = {v: i for i, C in enumerate(cs) for v in C}
        # Keep loops here: they are independent pyramid columns in Gale.
        nonforest = tuple(e for e in range(len(sw.edges)) if e not in forest)
        ge = tuple((ci[sw.edges[e][0]], ci[sw.edges[e][1]], sw.original_ids[e])
                   for e in nonforest)
        degree = [0] * len(cs)
        for i, j, _ in ge:
            degree[i] += 1; degree[j] -= 1
        assert not any(degree), ('quotient is not Eulerian', P, forest)
        key = (P, forest)
        if key not in self.boxes:
            self.boxes[key] = EulerianBoxes(len(cs), ge)
        box = self.boxes[key]
        back = {e: i for i, e in enumerate(nonforest)}
        U = tuple(back[e] for e in T if e not in forest)
        d1 = tuple(sum(source[v] for v in C) for C in cs)
        d2 = tuple(sum(target[v] for v in C) for C in cs)
        assert sum(d1) == sum(d2) == 0
        V = box.transport(U, d1, d2)
        out = tuple(sorted([sw.original_ids[e] for e in forest] + [ge[e][2] for e in V]))
        outlocal = tuple(sw.to_local[e] for e in out)
        fo, ft = sw.flows(S, outlocal, base), sw.flows(S, outlocal, target)
        assert all(a > 0 or (a == 0 and b > 0) for a, b in zip(fo, ft))
        assert tuple(e for e, x in zip(outlocal, fo) if x > 0) == forest
        return out

    @lru_cache(None)
    def J(self, S):
        if len(S) == 1:
            return (('leaf', S[0]),)
        out = []
        for P in partitions(S):
            if len(P) < 2:
                continue
            roots = self.R(P)
            if not roots:
                continue
            for children in product(*(self.J(B) for B in P)):
                for r in roots:
                    out.append(('J', r, children))
        return tuple(out)

    def universe(self, theta):
        states = []
        for P in partitions(self.S):
            trees = self.H(P, self.theta_on(P, theta))
            if not trees:
                continue
            for kids in product(*(self.J(B) for B in P)):
                for T in trees:
                    states.append((kids, T))
        assert len(states) == len(set(states))
        return tuple(states)

    def normalized_sweep(self, state, theta):
        kids, Tids = state
        P = tuple(support(j) for j in kids)
        sw = self.quotient(P); S = tuple(range(len(P)))
        th = self.theta_on(P, theta)
        T = tuple(sw.to_local[e] for e in Tids)
        obj = sw.encode(S, T, th)

        def recurse(o, V, val):
            if o[0] == 'leaf':
                return ('R', (), (kids[o[1]],))
            if o[0] == 'terminal_on':
                PP = tuple(P[i] for i in V)
                ids = tuple(sw.original_ids[e] for e in o[1])
                ref = self.reference_parameter(PP)
                r = self.residual_transport(PP, ids, val, ref)
                assert r in self.R(PP)
                return ('R', r, tuple(kids[i] for i in V))
            _, color, left, right = o
            L, R = sw.leaves(left), sw.leaves(right)
            a = sw.crossing(V, L)[0]
            d = dict(zip(V, val)); h = sum(d[i] for i in L)
            vl, vr = sw.project(V, val, h / a, L, R)
            return ('F', color, recurse(left, L, vl), recurse(right, R, vr))
        return recurse(obj, S, th)

    @staticmethod
    def outer_leaves(f):
        if f[0] == 'R':
            return (f,)
        return SignedFlowUniverse.outer_leaves(f[2]) + SignedFlowUniverse.outer_leaves(f[3])

    @staticmethod
    def f_support(f):
        if f[0] == 'R':
            return tuple(sorted(i for j in f[2] for i in support(j)))
        return tuple(sorted(SignedFlowUniverse.f_support(f[2]) + SignedFlowUniverse.f_support(f[3])))

    def unnormalized_inverse(self, f, theta):
        kids = tuple(sorted((j for leaf in self.outer_leaves(f) for j in leaf[2]), key=lambda j: support(j)[0]))
        P = tuple(support(j) for j in kids)
        sw = self.quotient(P); S = tuple(range(len(P)))
        th = self.theta_on(P, theta)

        def recurse(o, V, val):
            if o[0] == 'R':
                if len(V) == 1:
                    assert o[1] == () and len(o[2]) == 1
                    return ('leaf', V[0])
                PP = tuple(P[i] for i in V)
                assert tuple(support(j) for j in o[2]) == PP
                ref = self.reference_parameter(PP)
                ids = self.residual_transport(PP, o[1], ref, val)
                local = tuple(sw.to_local[e] for e in ids)
                return ('terminal_on', local, V)
            _, color, left, right = o
            ls = set(self.f_support(left))
            L = tuple(i for i in V if P[i][0] in ls)
            R = tuple(i for i in V if i not in L)
            assert L and R and min(V) in L
            a = sw.crossing(V, L)[0]
            d = dict(zip(V, val)); h = sum(d[i] for i in L)
            vl, vr = sw.project(V, val, h / a, L, R)
            return ('node', color, recurse(left, L, vl), recurse(right, R, vr))
        raw = recurse(f, S, th)
        T = sw.decode(S, raw, th)
        return (kids, tuple(sw.original_ids[e] for e in T))

    @lru_cache(maxsize=200000)
    def involution(self, theta, state):
        f = self.normalized_sweep(state, theta)
        bad = [r for r in self.outer_leaves(f)
               if len(r[2]) != 1 or r[2][0][0] != 'leaf']
        if not bad:
            return state
        chosen = min(bad, key=lambda r: self.f_support(r)[0])
        if len(chosen[2]) >= 2:
            changed = ('R', (), (('J', chosen[1], chosen[2]),))
        else:
            j = chosen[2][0]
            assert j[0] == 'J' and chosen[1] == ()
            changed = ('R', j[1], j[2])
        def replace(o):
            if o == chosen:
                return changed
            if o[0] == 'R':
                return o
            return (o[0], o[1], replace(o[2]), replace(o[3]))
        out = self.unnormalized_inverse(replace(f), theta)
        assert state_sign(out) == -state_sign(state)
        return out

    def transport(self, source_theta, target_theta, state):
        assert self.involution(source_theta, state) == state
        x = state; path = [x]; seen = {x}
        while True:
            y = self.involution(target_theta, x)
            if y == x:
                return x, path
            assert state_sign(y) == -1
            path.append(y)
            x = self.involution(source_theta, y)
            assert state_sign(x) == 1 and x not in seen
            path.append(x); seen.add(x)


def validate(name, n, edges, trials=6, seed=0):
    rng = Random(seed)
    alg = SignedFlowUniverse(n, edges)
    parameters = []
    for _ in range(trials):
        v = [F(rng.randrange(1, 10**8)) for _ in range(n - 1)]
        parameters.append(tuple([-sum(v)] + v))
    common = alg.universe(parameters[0]); common_set = set(common)
    signs = Counter(state_sign(s) for s in common)
    fixed = []
    checks = 0
    for theta in parameters:
        assert set(alg.universe(theta)) == common_set
        fs = []
        for s in common:
            t = alg.involution(theta, s)
            assert t in common_set
            assert alg.involution(theta, t) == s
            if t == s:
                assert state_sign(s) == 1
                assert all(j[0] == 'leaf' for j in s[0])
                fs.append(s)
            checks += 1
        P = tuple((i,) for i in range(n)); sw = alg.quotient(P)
        independent = sw.enumerate_objects(tuple(range(n)), theta)
        axis = {o for o in independent if is_axis(o)}
        images = {sw.encode(tuple(range(n)), tuple(sw.to_local[e] for e in s[1]), theta) for s in fs}
        assert images == axis
        assert len(fs) == signs[1] - signs[-1]
        fixed.append(tuple(fs))
    reference = parameters[0]
    maps = []; inv = []; max_steps = 0; sample = None
    for i, theta in enumerate(parameters):
        mp = {}
        for s in fixed[i]:
            t, path = alg.transport(theta, reference, s)
            back, reverse_path = alg.transport(reference, theta, t)
            assert back == s and reverse_path == list(reversed(path))
            mp[s] = t
            if len(path) - 1 > max_steps:
                max_steps = len(path) - 1
                sample = {'parameter': i, 'path': path}
        assert set(mp.values()) == set(fixed[0])
        maps.append(mp); inv.append({b: a for a, b in mp.items()})
    def coherent(i, j, s):
        return inv[j][maps[i][s]]
    pentagons = 0
    cyc = [i % trials for i in range(5)]
    for s in fixed[cyc[0]]:
        x = s
        for k in range(5):
            x = coherent(cyc[k], cyc[(k + 1) % 5], x)
        assert x == s
        assert coherent(1 % trials, 2 % trials, coherent(0, 1 % trials, s)) == coherent(0, 2 % trials, s)
        pentagons += 1
    return {'name': name, 'vertices': n, 'arrows': len(edges),
            'parameters': [[str(x) for x in th] for th in parameters],
            'signed_universe_size': len(common), 'positive_states': signs[1],
            'negative_states': signs[-1], 'axis_fixed_points': len(fixed[0]),
            'involution_state_checks': checks,
            'actual_transported_objects': sum(map(len, fixed)),
            'max_signed_alternating_steps': max_steps, 'pentagon_objects': pentagons,
            'residual_normalizations': alg.residual_calls,
            'eulerian_configurations': len(alg.boxes),
            'eulerian_box_path_calls': sum(b.path_calls for b in alg.boxes.values()),
            'eulerian_box_path_steps': sum(b.path_steps for b in alg.boxes.values()),
            'max_eulerian_box_path_steps': max((b.longest for b in alg.boxes.values()), default=0),
            'max_J_internal_nodes': max((sum(internal_nodes(j) for j in s[0]) for s in common), default=0),
            'all_actual_inverses_and_coherence': True,
            'sample_longest_signed_path': sample}


if __name__ == '__main__':
    markov = [(i, j, k) for i, j in ((1, 2), (2, 3), (3, 1)) for k in range(2)] + [(i, 0, 0) for i in (1, 2, 3)]
    double = [(1, 2, 0), (2, 3, 0), (3, 1, 0), (1, 4, 0), (4, 5, 0), (5, 1, 0)] + [(i, 0, 0) for i in range(1, 6)]
    weighted = [(2, 1, 0), (1, 3, 0), (1, 3, 1), (3, 2, 0), (4, 2, 0), (4, 3, 0)] + [(i, 0, 0) for i in range(1, 5)]
    overlap = [(2, 1, 0), (1, 3, 0), (4, 1, 0), (3, 2, 0), (4, 2, 0), (3, 4, 0), (3, 4, 1)] + [(1, 0, 0), (2, 0, 0), (2, 0, 1), (3, 0, 0), (3, 0, 1), (4, 0, 0)]
    out = []
    for seed, (name, n, edges) in enumerate([('Markov_framed', 4, markov),
                                           ('two_overlapping_cycles', 6, double),
                                           ('weighted_cycle_with_sources', 5, weighted),
                                           ('overlap_weighted_cycles', 5, overlap)]):
        r = validate(name, n, edges, seed=seed)
        out.append(r)
        print(json.dumps({k: v for k, v in r.items() if k != 'sample_longest_signed_path'}), flush=True)
        Path(__file__).with_name('cyclic_signed_flow_results.json').write_text(json.dumps(out, indent=2))
