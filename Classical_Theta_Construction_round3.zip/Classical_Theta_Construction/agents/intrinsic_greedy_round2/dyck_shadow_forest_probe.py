"""Probe a general two-stack shadow forest, across all small grading weights.

This is a mechanism experiment, not a claimed tree/quiver identification.
The complete combinatorial input is an arbitrary pair of total weights.
"""
from itertools import product
from functools import lru_cache
from collections import Counter
from pathlib import Path
import json


@lru_cache(None)
def weak(total, n):
    if n == 0:
        return ((),) if total == 0 else ()
    if n == 1:
        return ((total,),)
    return tuple((i,) + tail for i in range(total + 1)
                 for tail in weak(total - i, n - 1))


def dimensions(a, b):
    from math import gcd
    g = gcd(a, b)
    for m in range(a, a + a // g + 2):
        num = b * m - g
        if num % a == 0 and num // a >= b:
            return m, num // a
    raise AssertionError((a, b))


def path(m, n):
    p = []
    for x in range(1, m + 1):
        p.append('H')
        p.extend('V' for _ in range(n * x // m - n * (x - 1) // m))
    return tuple(p)


def shadows(p, grades, color):
    n = len(p)
    active = [i for i, a in enumerate(grades) if a]
    result = {}
    for i in active:
        level, found = 0, []
        step = 1 if color == 'H' else -1
        for k in range(n):
            j = (i + step * k) % n
            if p[j] == color:
                level += grades[j]
            else:
                level -= 1
                found.append(j)
                if level == 0:
                    break
        else:
            found = [j for j in range(n) if p[j] != color]
        result[i] = frozenset(found)
    return result


def direct_parents(p, hs, vs):
    parent = {}
    for sh in (hs, vs):
        targets = set().union(*sh.values()) if sh else set()
        for j in targets:
            candidates = [i for i in sh if j in sh[i]]
            mi = min(len(sh[i]) for i in candidates)
            owners = [i for i in candidates if len(sh[i]) == mi]
            assert len(owners) == 1, ('ambiguous owner', p, sh, j)
            parent[j] = owners[0]
    return parent


def cycle_of(parent, n):
    done = set()
    for i in range(n):
        stack = []
        cur = i
        while cur in parent and cur not in done:
            if cur in stack:
                return stack[stack.index(cur):]
            stack.append(cur)
            cur = parent[cur]
        done.update(stack)
    return None


def probe(a, b, max_combinations=2000000):
    m, n = dimensions(a, b)
    p = path(m, n)
    hi = [i for i, c in enumerate(p) if c == 'H']
    vi = [i for i, c in enumerate(p) if c == 'V']
    hc, vc = weak(b, m), weak(a, n)
    if len(hc) * len(vc) > max_combinations:
        return {'a': a, 'b': b, 'skipped': len(hc) * len(vc)}
    H, V = [], []
    for c in hc:
        g = [0] * len(p)
        for i, z in zip(hi, c):
            g[i] = z
        H.append((tuple(g), shadows(p, g, 'H')))
    for c in vc:
        g = [0] * len(p)
        for i, z in zip(vi, c):
            g[i] = z
        V.append((tuple(g), shadows(p, g, 'V')))
    compatible, tight, cyclic, degree_bad = 0, 0, 0, 0
    roots = Counter()
    first_bad = None
    for hg, hs in H:
        covered = set().union(*hs.values())
        for vg, vs in V:
            if any(v in hs[h] and h in vs[v] for h in hs for v in vs):
                continue
            compatible += 1
            if not set(vs) <= covered:
                continue
            tight += 1
            parent = direct_parents(p, hs, vs)
            cyc = cycle_of(parent, len(p))
            if cyc:
                cyclic += 1
                if first_bad is None:
                    first_bad = {'path': p, 'hg': hg, 'vg': vg,
                                 'parent': parent, 'cycle': cyc}
            deg = Counter(parent.values())
            if any(deg[j] != hg[j] + vg[j] for j in range(len(p))):
                degree_bad += 1
                if first_bad is None:
                    first_bad = {'path': p, 'hg': hg, 'vg': vg,
                                 'parent': parent, 'degree': dict(deg)}
            root = [j for j in range(len(p)) if j not in parent]
            roots[(len(root), sum(p[j] == 'H' for j in root),
                   sum(bool(hg[j] + vg[j]) for j in root))] += 1
    return {'a': a, 'b': b, 'm': m, 'n': n,
            'grading_pairs': len(H) * len(V), 'compatible': compatible,
            'tight': tight, 'cyclic_shadow_graphs': cyclic,
            'wrong_local_degrees': degree_bad,
            'roots': {str(k): v for k, v in sorted(roots.items())},
            'first_bad': first_bad}


if __name__ == '__main__':
    results = []
    for a in range(1, 7):
        for b in range(1, 7):
            r = probe(a, b)
            results.append(r)
            print(json.dumps(r), flush=True)
    Path(__file__).with_name('dyck_shadow_forest_results.json').write_text(json.dumps(results, indent=2))
