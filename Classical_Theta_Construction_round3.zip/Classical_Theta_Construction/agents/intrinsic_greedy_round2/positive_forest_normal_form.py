"""Exact rank-two stable-tree normal forms, without set-rank matching."""
from fractions import Fraction
from itertools import combinations
from random import Random
from collections import Counter
from pathlib import Path
import json
from balanced_cut_transport import components, all_trees, tree_flows, stable


def graph(charges):
    edges=[]
    for i,x in enumerate(charges):
        for j,y in enumerate(charges):
            if i!=j:
                m=x[0]*y[1]-x[1]*y[0]
                edges.extend((i,j,k) for k in range(max(m,0)))
    theta=[0]*len(charges)
    for i,j,_ in edges:theta[i]+=1;theta[j]-=1
    return edges,theta


def component_data(n,edges,F):
    cs=tuple(sorted(components(n,[edges[e] for e in F]),key=lambda c:min(c)))
    ci={v:i for i,c in enumerate(cs) for v in c}
    lists={}
    for e,(s,t,_) in enumerate(edges):
        i,j=ci[s],ci[t]
        if i!=j:lists.setdefault((i,j),[]).append(e)
    for i,j in lists:
        assert len(lists[i,j])==len(lists.get((j,i),[]))
    return cs,ci,lists


def encode(n,edges,T,base):
    f=tree_flows(n,edges,T,base)
    assert all(x>=0 for x in f.values())
    F=tuple(e for e in T if f[e]>0)
    cs,ci,lists=component_data(n,edges,F)
    U=[]
    for e in T:
        if e in F:continue
        s,t,_=edges[e];i,j=ci[s],ci[t]
        U.append((min(i,j),max(i,j),lists[i,j].index(e)))
    return F,tuple(sorted(U))


def decode(n,edges,obj,delta):
    F,U=obj
    cs,ci,lists=component_data(n,edges,F)
    if len(cs)==1:return F
    vals=[sum(delta[v] for v in c) for c in cs]
    flow=tree_flows(len(cs),U,tuple(range(len(U))),vals)
    out=list(F)
    for e,(i,j,k) in enumerate(U):
        assert flow[e]
        out.append(lists[i,j][k] if flow[e]>0 else lists[j,i][k])
    return tuple(sorted(out))


def generic_delta(base,rng):
    n=len(base)
    cuts=[C for size in range(1,n) for C in combinations(range(n),size)
          if sum(base[v] for v in C)==0]
    while True:
        d=[rng.randrange(-40,41) for _ in range(n-1)];d.append(-sum(d))
        if all(sum(d[v] for v in C)!=0 for C in cuts):return d


def check(charges,trials=10,seed=0):
    n=len(charges);edges,base=graph(charges)
    trees=list(all_trees(n,edges));rng=Random(seed)
    normal=None;forests=Counter();objects=0;params=[];encoded=[]
    for _ in range(trials):
        d=generic_delta(base,rng)
        scale=1+2*sum(abs(x) for x in d)
        theta=[Fraction(a)+Fraction(b,scale) for a,b in zip(base,d)]
        ts=[T for T in trees if stable(n,edges,T,theta)]
        mp={T:encode(n,edges,T,base) for T in ts}
        assert len(set(mp.values()))==len(ts)
        if normal is None:
            normal=set(mp.values());forests=Counter(len(o[0]) for o in normal)
        else:assert set(mp.values())==normal
        for T,o in mp.items():assert decode(n,edges,o,d)==T
        objects+=len(ts);params.append((d,theta));encoded.append(mp)
    # Full cross-chamber decoding and re-encoding of every common object.
    cross=0
    for o in normal:
        original=o
        for d,theta in params:
            T=decode(n,edges,o,d)
            assert stable(n,edges,T,theta)
            o=encode(n,edges,T,base)
            assert o==original
            cross+=1
    return {'charges':charges,'vertices':n,'arrows':len(edges),'all_trees':len(trees),
            'refinements':trials,'common_objects':len(normal),
            'positive_forest_edge_counts':dict(sorted(forests.items())),
            'roundtrip_objects':objects,'full_loop_objects':cross,
            'all_bijections_and_coherence':True}


if __name__=='__main__':
    families=[[(1,0)]*k+[(0,1)]*k for k in (2,3,4)]
    families += [[(1,0),(0,1),(2,1),(1,2)],
                 [(1,0),(0,1),(2,1),(1,2),(1,1)],
                 [(1,0),(0,1),(2,1),(1,2),(1,1),(1,1)],
                 [(2,0),(0,1),(1,1),(1,0)],
                 [(1,0),(0,2),(1,1),(0,1)],
                 [(1,0),(0,1),(1,2),(2,1),(2,2)]]
    out=[]
    for i,c in enumerate(families):
        r=check(c,12,i);out.append(r);print(json.dumps(r),flush=True)
    Path(__file__).with_name('positive_forest_results.json').write_text(json.dumps(out,indent=2))
