# Intrinsic combinatorial transport: second research branch

Start: 2026-11-13 18:13 UTC. Classical cluster algebras only. This log records
routes while they are being explored; it does not label an interface as a theta
theorem before the object-level identification is proved.

## 18:13–18:31: common signed universes and graphical cuts

### Prior work read before construction

The earlier `BOUNDED_FLAGGED_DYCK_TREES.md`,
`FRAMED_TWO_PACKET_EVENT_FLIP.md`, `universal_tree_positive.md`,
`intrinsic_partition_model.md`, `primitive_center_ih_bridge.md`, and
`valued_polyhedral_mechanism.md`, especially its final Young-species section,
were inspected. The existing work already contains the finite event grammar,
the first multilinear valued ABC rectangle, disjoint-leaf descendant
transport, Young permutation modules from elementary positivity, and a Gale
finite-point realization. None of these is being claimed again here.

### Rimányi, arXiv:2608.05057v1, §§9–12

Primary local PDF/text were available from the earlier branch and read in
detail. The finite Algorithm Z, its inverse, the local distinct/ordinary
partition toggle, the two first-moving involutions, and the alternating-path
termination argument were checked directly.

Useful interface: for any finite family of binary color trees, retain every
internal subset color in a common signed universe. A tree determines disjoint
blocks `D(A union B) P(A) P(B)` and cancellation blocks for unused colors.
Each block has an actual involution, and a fixed reference involution can give
coherent transition maps by passing through one fixed-point set.

Not yet a theta construction: the fixed-point blocks here are Durfee
rectangles and ordinary partitions, not arbitrary-valued tight gradings.
Setting the partition parameter to one is singular; it is not a way to
remove the partitions or factorial denominators. No such substitution is used.
Pairwise alternating-path bijections, by themselves, do not imply a pentagon;
the common reference normalization is an additional construction.

### Burcroff–Lee–Mou, arXiv:2503.03719, §§5.4–5.5

Read the proof of the shadowed/tight grading formula. Lemma 5.24 compares
counts using equality of greedy and theta expansions, induction, and deletion
of a final bend. It does not supply a generic literal correspondence between
the two finite decorated sets. Consequently one cannot simply replace its
counting argument by the required cancellation involution.

### Burcroff–Lee–Mou–Musiker–Reineke, JLMS 114(2), e70642 (2026)

Primary published HTML:
<https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/jlms.70642>.
First published 28 July 2026, checked on the primary page. Read §7 at the
mutation/retraction interface and §§8–9 at the exact scope relevant here.
The published §9.2 expressly leaves a general stable-tree/tight-grading
correspondence as an open direction; §9.1 similarly asks for a general
bijection between its two angular-momentum grading models. The paper does
not provide the missing object-level bridge. Its Weyl reflection warning
explains why a quiver tree model cannot automatically be identified with a
tight grading.

Use decision: useful precise interface, no unproved 2026 theorem adopted.
The relevant positive formulas are not treated as bijections.

### Rietsch–Williams, Root, flow and order polytopes (2025)

Primary published HTML:
<https://www.cambridge.org/core/journals/forum-of-mathematics-sigma/article/root-flow-and-order-polytopes-with-connections-to-toric-geometry/053568CA407FF25C226D606DF1EBA638>.
Read Definition 3.1, Theorem 3.4 and its proof, Remark 3.10, and the
unimodularity interface in §5. The canonical flow polytope is the translated
all-one incidence fiber, precisely the relevant local anti-attractor object.
Its reflexivity is old (Altmann–Hille), and planar duality with a root
polytope requires planarity. No planar identity is applied to a general
high-rank/nonplanar graph. A common triangulated polytope could organize
local tree transitions, but equality of volumes or Ehrhart polynomials is
not an object-level bijection.

### Chen–Mandel–Qin, arXiv:2306.04104v2 (2024), §§4,6

Primary PDF downloaded and extracted in this directory's `sources`.
Read the nice-grading hypotheses, Proposition 4.17 in full, the nilpotence
cutoff Lemmas 4.19–4.20, Corollary 4.21, and Theorem 6.1's finite cyclic-cover
construction. The restriction theorem uses a torus fixed-locus decomposition
and Euler characteristics. Example 4.18 sends the Euler characteristic of
`P^1` to that of two fixed points; this is not a bijection of all objects.
The required covering is a regular quiver covering; independent leaf
polarization in the existing flow-tree grammar is not automatically one.

Minor source correction: Lemma 4.14's assertion that a nonempty locally
closed invariant subset of a projective variety must have a nonempty fixed
locus is false (take `C*` inside `P^1`). Its Euler-characteristic equality
does hold, and the Grassmannians actually used in Proposition 4.17 are
projective. Thus this wording issue does not invalidate that argument.
The source is useful for its finite truncation and grading mechanism, not
as an automatic combinatorial descendant transport theorem.

### Route currently under construction

For a local thin graph at anti-attractor weight, crossing a generic balanced
cut changes a stable spanning tree only when its cut edge has zero limiting
flow. Removing it gives a fixed two-component forest. The total numbers of
arrows across the cut in either direction are equal, so a literal arrow
pairing gives a local reversible edge replacement. This preserves all
forest edges and their descendant decorations. The unresolved substantive
steps are simultaneous-cut coherence and a direct map from these graphical
objects to the existing tight-gradings objects. Neither follows from a
Hall/Euler-characteristic equality. The next calculations test the local
replacement itself and try coherent pairings at intersecting cuts.

## 18:31–18:39: local cut bijections and the coherence correction

`balanced_cut_transport.py` constructs exact rational positive tree flows,
local balanced-cut edge replacements, and all the chambers on a generic
two-dimensional loop through the anti-attractor weight. All 440 local maps
in the first 40 cases were actual bijections with actual inverses. This is
not enough for coherence. Lexicographic and rectangular arrow pairings had
nontrivial monodromy already for `K_(3,3)`. A ribbon-contour/Dyck pairing
passed those first tests, but the all-descendant `K_(4,4)` test disproved
its flatness: among 384 stable trees, only 316, 321, and 310 were fixed in
the three tested loops. Both ribbon reversals failed in the same counts.
The root agent was informed immediately. No planar or Bernardi theorem is
being extrapolated to these nonplanar graphs.

Primary Bernardi/rotor interfaces located: Baker–Wang, *The Bernardi Process
and Torsor Structures on Spanning Trees*, arXiv:1406.5084 / IMRN 2018;
the planar basepoint-independence results for rotor-routing, and the
nonplanar disagreement results for the two torsors. These explain why a
ribbon contour alone is not a source of general flatness; they are not
used to replace the explicit failed computations.

A different graphical mechanism was then derived: retain the whole positive
limiting forest `F₀`, contract its balanced components, pair opposite arrows
**within each pair of components**, and forget only the direction of the
zero-flow quotient-tree edges. For rank-two pointed charges each component
charge is parallel to the total charge, so the two arrow sets have equal
size. Reorientation by the new generic quotient cut-flow reconstructs the
tree. This gives an actual reference-free normal form relative to the local
arrow pairings. It is not a full theta associator and does not automatically
commute with Young permutations. A complete standalone writeup/computation
of this second mechanism remains to be finished.

## 18:39–18:47: finite Ehrhart cancellation and its actual consumer

The root agent proposed a common bounded-height signed lattice-point set.
The construction was checked and extended to arbitrary lattice
triangulations by retaining actual half-open Box points. The complete
proof and implementation are in `COMMON_SIGNED_EHRHART_TRANSPORT.md` and
`ehrhart_signed_transport.py`. The common universe, first eligible toggle,
alternating paths, and fixed-reference coherence are all literal finite
maps, with no matching by rank.

The first computational family uses 22 triangulations of four lattice
polytopes, including nonunimodular and unimodular triangulations of the same
polytope. All 29,244 full-state involution checks and all 592 object
transports/returns passed. The longest actual path had 98 elementary steps.

The stable-tree application required an important correction: the entire
cographic cone is usually all of its ambient space and has no positive
height. One must first localize at a vertex `F₀` of the canonical flow
polytope. Its normal cone has the common integral height-one slice `Q_F₀`;
generic positive trees give unimodular triangulations of that slice. This
was proved directly using the integral cycle lattice and forest supports.
The construction preserves `F₀` exactly. Repeated/zero Gale columns were
handled explicitly in the writeup.

Novelty decision: Elia–Kim–Supina, *Techniques in Equivariant Ehrhart
Theory*, Ann. Comb. 28 (2024), §3.2, already supplies the half-open Box
formalism. Garsia–Milne supplies alternating paths. The present finite
universe and toggle were not found in the inspected old Gale notes or the
targeted search, but no historical priority assertion is made. Equivariant
statements need the extra conditions in EKS Theorems 3.30/3.32; choosing a
generic direction does not make a Young-equivariant model.

## 18:47–18:57: tight-grading interfaces; avoid rediscovering the prior work

Read the full 13-page PDF of Burcroff–Lee–Mou,
arXiv:2611.10154v1, and primary abstract/HTML. Metadata: submitted
6 November 2026; the downloaded PDF's printed date is 10 November, while
the HTML displays 6 November and has slightly different numbering. The
record explicitly says extended abstract, full paper forthcoming. Its
disclosure says the proofs will appear in that full version. Therefore its
stated bijections are treated as explicit algorithmic interfaces requiring
independent verification, not as fully audited general theorems. Section 4
uses auxiliary rightmost children and a three-letter parenthesis inverse
for central equal-value gradings only. It does not give arbitrary tight
gradings ↔ stable quiver trees.

This paper was already cited in the previous round's
`DYCK_THREE_FACTOR_COHERENCE.md`; it is not a new discovery relative to
the whole project. Reading the complete old `TWO_STACK_DYCK_FORESTS.md`
showed that the two-stack forest criterion, determinant-one active window,
positive-core compression, and literal padding/power transports were all
already proved there. The new `dyck_shadow_forest_probe.py` is only an
independent reconstruction/check of that mechanism. It is not entered as
a new result. The current hard gap is old §7.3: charged insertion with the
actual boundary slot orders and causal child catalogs retained.

Rupel–Weist, arXiv:1803.06590, §5.20 gives a genuine compatible-pair ↔
strong-successor-closed-subset map: ordered vertices correspond to path
edges, the vertical subset is read directly, and the horizontal subset is
complemented. The proof depends on their recursively constructed 2-quivers
for exceptional/truncated-preprojective representations. The graph is a
representation-dependent cell-labeling device; it is not automatically the
thin stable-tree graph needed here. Its scope is retained.

The next live interface is the exact noncrossing-tree-sequence ↔ integer
flow ↔ DKK simplex correspondence of Postnikov–Stanley and
Mészáros–Morales–Striker. Recent primary leads: Brunner–Hanusa, EJC
33(4), P4.10 (9 October 2026), *A Triangulation of the Flow Polytope of the
Zigzag Graph*; `Framingtopes`, arXiv:2609.20656; `Permutation Flows I`,
arXiv:2512.04078. A matching of counts or a common Tamari vocabulary is
not sufficient; the required next step is an actual encoding of the two
pages into the routes/groves of a fixed flow graph.
