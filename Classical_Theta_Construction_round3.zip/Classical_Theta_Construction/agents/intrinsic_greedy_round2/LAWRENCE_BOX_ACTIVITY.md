# Lawrence Box coordinates for positive-forest normal forms

Date: 2026-11-13. This proves a compatibility of the local graphical
normal form with an actual common half-open lattice direction. The
Lawrence-polytope / matroid h-polynomial identity itself is established
literature, not a new theta theorem. The global charged-insertion and
tight-Dyck identification remain separate problems.

## 1. The exact local polytope, including its pyramid factors

Use the data and notation of `POSITIVE_FOREST_NORMAL_FORM.md`. Fix an
admissible positive limiting forest F. Contract each component of F and
keep every other arrow, including loops created by contraction. Opposite
arrows between each pair of components have equal cardinality; use the
fixed pairing from that note to identify the crossing arrows with the
bidirected version of a connected undirected multigraph H. Write

* s = number of vertices of H;
* e = number of its undirected, individually colored edges;
* l = number of loops created by contracting F;
* g = e-s+1.

Orient the undirected edges of H once, let B be its incidence matrix,
and let A be any integral cycle-lattice basis, with g rows and e columns.
Thus the rows of A form a Z-basis of ker(B) intersected with Z^e.
Projection to the arrows outside F induces an integral isomorphism from
the original cycle lattice onto the cycle lattice of the contracted
graph: a quotient circulation extends uniquely across a forest, and leaf
elimination gives integral extension coefficients. The contracted
incidence matrix is `[B,-B,0]`. Its integral cycle lattice has the basis

\[
 K=\begin{pmatrix}A&0&0\\I_e&I_e&0\\0&0&I_l\end{pmatrix}.
 \tag{1}
\]

Indeed, `B(x-y)=0` is equivalent to `x-y=A^T z` with integral z, and the
loop coordinates are free. This also proves that (1) is a lattice basis,
not merely a basis over Q.

The local normal-cone configuration is consequently integrally equivalent
to the columns

\[
 v_e^+=(a_e,e_e,0),\quad v_e^-=(0,e_e,0),\quad p_j=(0,0,e_j).
 \tag{2}
\]

All have height one for the integral functional that sums the final e+l
coordinates. Thus the local slice Q_F is the join of the cographic
Lawrence polytope `conv(v_e^+,v_e^-)` and the simplex on the p_j. The
simplex contributes l iterated pyramid factors. Omitting these factors
would give the wrong dimension, although it would leave h* unchanged.

If an edge of H is a bridge, its cographic column a_e is zero, so the
two columns v_e^+,v_e^- coincide. A generic refinement selects exactly
one of the two labels in each complementary simplex. The geometric
point is a pyramid vertex; labels are retained for the inverse stable
tree decoder. If s=1, the crossing part is absent and Q_F is simply
the simplex on the contracted loops. If the whole cone has dimension
zero, its sole local object is treated separately as the identity.

## 2. Complementary simplices and the common direction

For a fixed generic stability refinement, a stable tree with positive
limiting forest F is encoded by an undirected spanning tree U of H.
The complementary maximal simplex contains both v_e^+,v_e^- for
`e not in U`, exactly one ray from the pair for `e in U`, and every p_j.
Write chi_e=1 when the included singleton is v_e^+, and chi_e=0 when
it is v_e^-. The included singleton is opposite to the original arrow
selected by the quotient flow.

Put N=E(H) minus U. The matrix A_N is a unimodular square matrix. This
follows either from the integral cycle-lattice construction or from
fundamental cycles relative to U. Consequently every complementary
simplex is unimodular in the lattice of (1).

Fix an ordering of E(H), and choose positive integral numbers lambda_e
such that each is larger than the sum of all preceding numbers. Powers
of 3 suffice. Choose positive numbers kappa_j for the pyramid rays and
the single vector

\[
 w=(A\lambda/2,\lambda,\kappa).
 \tag{3}
\]

This is an interior vector, since it is a strictly positive combination
of all the rays (2), with coefficient lambda_e/2 on both rays of every
pair. It is the same vector for every stability refinement.

For a maximal simplex, write w in its ray basis. The singleton
coefficient for a tree edge f is lambda_f, and the pyramid coefficient
is kappa_j. For e in N, the two coefficients are mu_e and
lambda_e-mu_e, where

\[
 \mu_N=A_N^{-1}\left(A\lambda/2-
       \sum_{f\in U}\chi_f\lambda_f a_f\right).
 \tag{4}
\]

Let R=A_N^{-1}A_U. Its entries belong to {0,1,-1}; the support of row e
is exactly the set of tree edges in the fundamental cycle C(U,e).
Equation (4) becomes

\[
 2\mu_e=\lambda_e+
       \sum_{f\in U}R_{ef}(1-2\chi_f)\lambda_f.
 \tag{5}
\]

The largest lambda appearing in a nonempty sum of distinct signed lambda
terms dominates the sum of all the others. Thus (5) is neither 0 nor
2lambda_e, for every U and every choice of the singleton signs. This
proves that w is generic for all the relevant simplex facets at once.

## 3. An objectwise activity formula

Call a non-tree edge e externally active when it is the **largest** edge
of C(U,e). This is the usual activity convention with the edge order
reversed. If e is externally active, the lambda_e term dominates (5),
and

\[
             0<\mu_e<\lambda_e.
\]

If e is not externally active, the largest edge in C(U,e) belongs to U.
Its signed lambda term dominates, so either mu_e<0 or
mu_e>lambda_e. Exactly one of the two ray coefficients is then negative.
All singleton and pyramid coefficients are positive.

For the half-open convention `v+epsilon*w` enters the simplex, a facet
is open exactly when the corresponding coefficient of w is negative.
Since the simplex is unimodular, its unique half-open Box point is the
sum of precisely those rays with negative coefficients. Denote this
actual lattice point by b_delta(U). We have proved

\[
     h(b_\delta(U))=g-\operatorname{ea}(U).
 \tag{6}
\]

The right side is independent of the stability refinement delta. The
point itself is given explicitly by (5): include v_e^+ when mu_e<0,
include v_e^- when mu_e>lambda_e, and include neither otherwise.
There are no unknown lattice phases or determinant-only labels here.

**Theorem.** After fixing the opposite-arrow pairings and an edge order,
the positive-forest normal form induces, for every pair of sufficiently
small generic stability refinements, a grade-preserving bijection of
their actual half-open Box points. It preserves F literally and retains
the quotient spanning tree U. All such maps obey the strict cocycle
identity, hence every pentagon, because they are the compositions of
the actual encode/decode maps through the same pairs (F,U).

This is a different coherent transport from choosing a reference
triangulation in the signed Ehrhart universe. No equality between those
two transports is asserted. They solve related local identification
problems with different auxiliary choices.

Summing (6) gives the familiar identity

\[
 h^*_{Q_F}(t)=\sum_U t^{g-\operatorname{ea}(U)}
            =t^g T_H(1,t^{-1}).
 \tag{7}
\]

The pyramid factors do not change this polynomial. Formula (7) by itself
is not new: it is the unimodular cographic case of the Lawrence
polytope / matroid h-polynomial relation. The useful interface proved
here is the compatibility of a single explicit direction (3), actual
Box coordinates (5), and the positive-forest refinement transport.

## 4. Source comparison and scope

Alan Stapledon, *Ehrhart Theory for Lawrence Polytopes and Orbifold
Cohomology of Hypertoric Varieties*, Proc. AMS 137 (2009), 4243–4253,
arXiv:0806.4669, Theorem 1.6 and its combinatorial proof in Section 3,
give the more general Box-weighted contraction formula for the Ehrhart
numerator. In the unimodular case only the empty Box contribution
remains, recovering the matroid h-polynomial. The primary paper is
<https://arxiv.org/abs/0806.4669>. It already supplies refined positivity
and Lefschetz-related results for Lawrence polytopes; those conclusions
must not be repackaged as new properties of theta functions without an
independently proved theta identification.

Recent related object maps include Crepeau, arXiv:2505.09719, generalized
break divisors from cographic Lawrence triangulations, and
Backman–Santos–Yuen, DCG 75 (2026), 969–994, extension/lifting bijections
for oriented matroids. These were located as further interfaces. Their
general signatures, break-divisor classes, and our explicitly fixed
positive-forest quotient tree are different data; no novelty conclusion
is based on their abstracts alone.

No statement here identifies tight Dyck gradings with the Box points.
No statement transports a child decoration whose boundary covector is
changed by a new charged insertion. Pairings need not be Young-equivariant.
The ordinary thin-quiver lattice is unimodular; a valued/skew-symmetrizable
species requires an independently identified lattice and genuine Box
phase decoder. The general signed Ehrhart theorem can transport such
phases once that data is supplied, but a determinant count is not a
substitute for supplying it.

## 5. Exact reproducible computation

`lawrence_activity_transport.py` constructs an integral cographic matrix
from fundamental cycles, checks every complementary basis determinant,
evaluates the actual coordinates in (5), compares their negative-ray
sum with (6), and checks injectivity and every inverse transport in a
family of generic refinement triangulations. It also tests all singleton
orientations for several graphs, rather than only the orientations seen
in one chamber. Graphs include bridges, parallel edges, K5, K6, K3,3,
and K4,4. The nonplanar cases test the general mechanism that failed for
the earlier ribbon-cut pairing; no planarity assumption is used here.
Results are stored in `lawrence_activity_results.json`.
