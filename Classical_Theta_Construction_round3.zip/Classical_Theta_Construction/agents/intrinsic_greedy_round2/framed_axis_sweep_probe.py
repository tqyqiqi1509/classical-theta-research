"""Test an actual framed arrow-order mechanism, not equality of counts.

Framing arrows are placed last.  The hard question is whether the
ordinary-tree subset decoded from axis-leaf flow objects remains fixed
as the positive mutable root covector varies.  The separate induced-
acyclic-component candidate is compared on exactly the same objects.
"""
from itertools import product, combinations
from random import Random
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
import json
from stable_tree_sweep import Sweep, DegenerateProjection


def is_axis(o):
    return o[0] == 'leaf' or (o[0] == 'node' and is_axis(o[2]) and is_axis(o[3]))


def arborescences(n, edges):
    outgoing = [[e for e, (i, j, _) in enumerate(edges) if i == v]
                for v in range(1, n)]
    for picks in product(*outgoing):
        nxt = {v: edges[e][1] for v, e in zip(range(1, n), picks)}
        good = True
        for v in range(1, n):
            seen = set()
            while v and v not in seen:
                seen.add(v); v = nxt[v]
            if v:
                good = False; break
        if good:
            yield tuple(sorted(picks))


def acyclic_components(n, edges, T):
    p = list(range(n))
    def root(x):
        while p[x] != x:
            p[x] = p[p[x]]; x = p[x]
        return x
    for e in T:
        i, j, _ = edges[e]
        if i and j:
            p[root(i)] = root(j)
    adj = [[] for _ in range(n)]
    for i, j, _ in edges:
        if i and j and root(i) == root(j):
            adj[i].append(j)
    color = [0] * n
    def visit(v):
        if color[v] == 1:
            return False
        if color[v] == 2:
            return True
        color[v] = 1
        for w in adj[v]:
            if not visit(w):
                return False
        color[v] = 2
        return True
    return all(visit(v) for v in range(1, n))


def check(name, mutable_edges, frame_multiplicities, trials=8, seed=0):
    n = len(frame_multiplicities) + 1
    edges = mutable_edges + [(i, 0, k) for i in range(1, n)
                             for k in range(frame_multiplicities[i - 1])]
    S = tuple(range(n)); ts = tuple(arborescences(n, edges))
    candidate = {T for T in ts if acyclic_components(n, edges, T)}
    rng = Random(seed); sets = []; params = []
    for trial in range(trials):
        for attempt in range(20):
            vals = [rng.randrange(1, 10**8) for _ in range(1, n)]
            theta = tuple(map(F, (-sum(vals),) + tuple(vals)))
            sw = Sweep(n, edges)
            try:
                good = {T for T in ts if is_axis(sw.encode(S, T, theta))}
                break
            except DegenerateProjection:
                continue
        else:
            raise AssertionError('could not make generic parameter')
        sets.append(good); params.append(vals)
    same = all(x == sets[0] for x in sets)
    same_count = len({len(x) for x in sets}) == 1
    candidate_exact = all(x == candidate for x in sets)
    out = {'name': name, 'mutable_vertices': n - 1, 'arrows': len(edges),
           'stable_arborescences': len(ts), 'axis_counts': [len(x) for x in sets],
           'axis_count_parameter_independent': same_count,
           'axis_subset_parameter_independent': same,
           'induced_acyclic_component_candidate': len(candidate),
           'candidate_is_exact_object_set': candidate_exact}
    if not same or not candidate_exact:
        out.update({'edges': edges, 'root_parameters': params})
        if not same:
            j = next(j for j in range(1, len(sets)) if sets[j] != sets[0])
            out['subset_change'] = {'parameters': [0, j],
                                    'only_first': sorted(sets[0] - sets[j])[:10],
                                    'only_second': sorted(sets[j] - sets[0])[:10]}
        if not candidate_exact:
            j = next(j for j, x in enumerate(sets) if x != candidate)
            out['candidate_difference'] = {'parameter': j,
                                          'axis_not_candidate': sorted(sets[j] - candidate)[:10],
                                          'candidate_not_axis': sorted(candidate - sets[j])[:10]}
    return out


if __name__ == '__main__':
    families = []
    for m in range(3, 7):
        for multiplicity in (1, 2):
            es = [(i, i % m + 1, k) for i in range(1, m + 1) for k in range(multiplicity)]
            families.append((f'directed_cycle_{m}_mult_{multiplicity}', es, [1] * m))
    families.append(('overlap_cycles_shared_vertex',
                     [(1, 2, 0), (2, 3, 0), (3, 1, 0),
                      (1, 4, 0), (4, 5, 0), (5, 1, 0)], [1] * 5))
    rng = Random(4102)
    for j in range(32):
        m = 4 if j < 20 else 5
        es = []
        for i, k in combinations(range(1, m + 1), 2):
            if rng.randrange(5) == 0:
                continue
            a, b = (i, k) if rng.randrange(2) else (k, i)
            es.extend((a, b, r) for r in range(1 + int(rng.randrange(5) == 0)))
        fs = [1 + int(rng.randrange(4) == 0) for _ in range(m)]
        families.append((f'random_oriented_{j}', es, fs))
    result = []
    for j, (name, es, fs) in enumerate(families):
        out = check(name, es, fs, seed=j)
        result.append(out)
        print(json.dumps(out), flush=True)
        Path(__file__).with_name('framed_axis_sweep_results.json').write_text(json.dumps(result, indent=2))
