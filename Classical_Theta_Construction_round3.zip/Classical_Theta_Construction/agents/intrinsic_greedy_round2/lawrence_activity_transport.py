"""Exact Lawrence Box coordinates for every tree of a finite graph.

No point sets are matched by rank.  A common tree U labels one actual
half-open Box point in each generic flow triangulation.  The program
checks integer lattice bases, coordinates, injectivity, grade, and inverse
transport through that same U.  Bridge columns are allowed to coincide.
"""
from itertools import combinations, product
from collections import Counter
from random import Random
from pathlib import Path
import json
import sympy as sp
from balanced_cut_transport import all_trees, tree_flows


def cycle_matrix(n, edges):
    base = next(all_trees(n, edges))
    rows = []
    for e, (s, t, _) in enumerate(edges):
        if e in base:
            continue
        theta = [0] * n
        theta[s] -= 1
        theta[t] += 1
        f = tree_flows(n, edges, base, theta)
        row = [0] * len(edges)
        row[e] = 1
        for j, x in f.items():
            row[j] = x
        rows.append(row)
    return sp.Matrix(rows) if rows else sp.zeros(0, len(edges))


def path_edges(n, edges, U, s, t):
    adj = [[] for _ in range(n)]
    for e in U:
        a, b, _ = edges[e]
        adj[a].append((b, e))
        adj[b].append((a, e))
    todo = [(s, -1, ())]
    while todo:
        v, parent, p = todo.pop()
        if v == t:
            return p
        todo.extend((j, v, p + (e,)) for j, e in adj[v] if j != parent)
    raise AssertionError('disconnected tree')


def tree_data(n, edges, A, U):
    U = tuple(U)
    N = tuple(e for e in range(len(edges)) if e not in U)
    r = A.rows
    AN = A[:, N] if N else sp.zeros(0, 0)
    assert abs(AN.det()) == 1
    R = AN.inv() * A[:, U] if r else sp.zeros(0, len(U))
    RR = tuple(tuple(int(R[i, j]) for j in range(len(U))) for i in range(r))
    assert all(x in (-1, 0, 1) for row in RR for x in row)
    ext = []
    for i, e in enumerate(N):
        s, t, _ = edges[e]
        cycle = set(path_edges(n, edges, U, s, t)) | {e}
        assert {U[j] for j, x in enumerate(RR[i]) if x} == cycle - {e}
        if e == max(cycle):
            ext.append(e)
    return U, N, RR, tuple(ext)


def box_point(A, datum, chi, lam, verify_coordinates=True):
    U, N, R, ext = datum
    m, r = len(lam), A.rows
    twice_mu = []
    negative = []
    for i, e in enumerate(N):
        q = lam[e] + sum(R[i][j] * (1 - 2 * chi[j]) * lam[f]
                         for j, f in enumerate(U))
        assert q != 0 and q != 2 * lam[e]
        twice_mu.append(q)
        if q < 0:
            negative.append((e, 1))
        elif q > 2 * lam[e]:
            negative.append((e, 0))
    assert len(negative) == r - len(ext)
    # Actual lattice point, in Z^r x Z^m, not a volume/degree label.
    b = [0] * (r + m)
    for e, plus in negative:
        b[r + e] += 1
        if plus:
            for i in range(r):
                b[i] += int(A[i, e])
    if verify_coordinates:
        lhs = [0] * r
        for i, e in enumerate(N):
            for j in range(r):
                lhs[j] += twice_mu[i] * int(A[j, e])
        for i, e in enumerate(U):
            for j in range(r):
                lhs[j] += 2 * chi[i] * lam[e] * int(A[j, e])
        rhs = [sum(int(A[j, e]) * lam[e] for e in range(m)) for j in range(r)]
        assert lhs == rhs
    return tuple(b)


def generic_delta(n, rng):
    while True:
        d = [rng.randrange(-100, 101) for _ in range(n - 1)]
        d.append(-sum(d))
        if all(sum(d[i] for i in C) for size in range(1, n)
               for C in combinations(range(n), size)):
            return d


def check_graph(name, n, edges, exhaustive=False, trials=12):
    A = cycle_matrix(n, edges)
    m, r = len(edges), A.rows
    lam = tuple(3**e for e in range(m))
    data = [tree_data(n, edges, A, U) for U in all_trees(n, edges)]
    hstar = Counter(r - len(x[3]) for x in data)
    arbitrary_checks = 0
    if exhaustive:
        for datum in data:
            for chi in product((0, 1), repeat=n - 1):
                box_point(A, datum, chi, lam)
                arbitrary_checks += 1
    rng = Random(n * 100 + m)
    maps = []
    for _ in range(trials):
        delta = generic_delta(n, rng)
        forward = {}
        reverse = {}
        for datum in data:
            U = datum[0]
            flows = tree_flows(n, edges, U, delta)
            assert all(flows.values())
            # Positive flow selects the + arrow in the stable tree,
            # so its complementary simplex contains the - ray.
            chi = tuple(int(flows[e] < 0) for e in U)
            b = box_point(A, datum, chi, lam)
            assert b not in reverse
            assert sum(b[r:]) == r - len(datum[3])
            forward[U] = b
            reverse[b] = U
        maps.append((forward, reverse))
    transports = 0
    for datum in data:
        U = datum[0]
        b = maps[0][0][U]
        grade = sum(b[r:])
        # All parenthesizations of a chain agree because every map uses
        # its actual inverse tree U; also test all chamber roundtrips.
        for i in range(len(maps)):
            b2 = maps[i][0][maps[0][1][b]]
            assert sum(b2[r:]) == grade
            assert maps[0][0][maps[i][1][b2]] == b
            transports += 1
        bcur = b
        for i in range(len(maps)):
            j = (i + 1) % len(maps)
            bcur = maps[j][0][maps[i][1][bcur]]
        assert bcur == b
    return {'name': name, 'vertices': n, 'edges': m, 'cycle_rank': r,
            'lawrence_dimension': r + m - 1, 'trees': len(data),
            'hstar': [hstar[i] for i in range(r + 1)],
            'arbitrary_orientation_coordinate_checks': arbitrary_checks,
            'generic_refinements': trials, 'box_roundtrips': transports,
            'all_exact_coordinates_unimodularity_grade_and_coherence': True}


if __name__ == '__main__':
    families = [
        ('path_with_bridges', 5, [(i, i + 1, 0) for i in range(4)], True),
        ('triangle', 3, [(0, 1, 0), (1, 2, 0), (0, 2, 0)], True),
        ('parallel_4', 2, [(0, 1, k) for k in range(4)], True),
        ('triangle_parallel_bridge', 4,
         [(0, 1, 0), (0, 1, 1), (1, 2, 0), (0, 2, 0), (2, 3, 0)], True),
        ('K4', 4, [(i, j, 0) for i, j in combinations(range(4), 2)], True),
        ('K5', 5, [(i, j, 0) for i, j in combinations(range(5), 2)], True),
        ('K3_3', 6, [(i, j, 0) for i in range(3) for j in range(3, 6)], True),
        ('K6', 6, [(i, j, 0) for i, j in combinations(range(6), 2)], False),
        ('K4_4', 8, [(i, j, 0) for i in range(4) for j in range(4, 8)], False),
    ]
    result = []
    for name, n, edges, exhaustive in families:
        out = check_graph(name, n, edges, exhaustive)
        result.append(out)
        print(json.dumps(out), flush=True)
    Path(__file__).with_name('lawrence_activity_results.json').write_text(json.dumps(result, indent=2))
