"""Actual stable spanning tree <-> colored flow-tree sweep bijection.

Incidence is tail minus head.  The sweep velocity on S is minus the
all-one incidence vector of the induced graph.  At a wall, every entering
bridge is paired to one departing bridge; surplus departing bridges are
the positive binary-vertex colors.  Children receive the exact projected
covector, and the inverse tracks the same swaps backwards.
"""
from fractions import Fraction as F
from itertools import combinations, product
from functools import lru_cache
from random import Random
from pathlib import Path
from collections import Counter
import json
from balanced_cut_transport import all_trees


class DegenerateProjection(Exception):
    pass


class Sweep:
    def __init__(self, n, edges):
        self.n = n
        self.edges = tuple(edges)
        self.steps = 0
        self.reverse_steps = 0
        self.max_sweep = 0
        self.projected_nodes = 0

    @lru_cache(None)
    def induced_edges(self, S):
        return tuple(i for i, (s, t, _) in enumerate(self.edges) if s in S and t in S)

    @lru_cache(None)
    def trees(self, S):
        if len(S) == 1:
            return ((),)
        idx = {v: i for i, v in enumerate(S)}
        es = self.induced_edges(S)
        local = [(idx[self.edges[e][0]], idx[self.edges[e][1]], e) for e in es]
        return tuple(tuple(es[i] for i in U) for U in all_trees(len(S), local))

    @lru_cache(None)
    def velocity(self, S):
        val = {i: 0 for i in S}
        for e in self.induced_edges(S):
            s, t, _ = self.edges[e]
            val[s] -= 1
            val[t] += 1
        return tuple(val[i] for i in S)

    @lru_cache(maxsize=100000)
    def cuts(self, S, T):
        adj = {v: [] for v in S}
        for e in T:
            s, t, _ = self.edges[e]
            adj[s].append((t, e)); adj[t].append((s, e))
        out = []
        for e in T:
            start = self.edges[e][0]
            todo = [start]; seen = {start}
            while todo:
                v = todo.pop()
                for w, f in adj[v]:
                    if f != e and w not in seen:
                        seen.add(w); todo.append(w)
            out.append(tuple(sorted(seen)))
        return tuple(out)

    def flows(self, S, T, theta):
        d = dict(zip(S, theta))
        return tuple(sum(d[v] for v in C) for C in self.cuts(S, T))

    def stable(self, S, T, theta):
        return all(x > 0 for x in self.flows(S, T, theta))

    @lru_cache(None)
    def crossing(self, S, L):
        left = set(L)
        plus, minus = [], []
        for e in self.induced_edges(S):
            s, t, _ = self.edges[e]
            if s in left and t not in left:
                plus.append(e)
            elif t in left and s not in left:
                minus.append(e)
        a = len(plus) - len(minus)
        if not a:
            return a, (), ()
        depart, enter = (plus, minus) if a > 0 else (minus, plus)
        assert len(depart) > len(enter)
        return a, tuple(depart), tuple(enter)

    def split(self, S, T, e):
        C = self.cuts(S, T)[T.index(e)]
        left = set(C)
        if min(S) not in left:
            left = set(S) - left
        L = tuple(sorted(left))
        R = tuple(v for v in S if v not in left)
        TL = tuple(f for f in T if self.edges[f][0] in left and self.edges[f][1] in left)
        TR = tuple(f for f in T if self.edges[f][0] not in left and self.edges[f][1] not in left)
        assert len(TL) == len(L) - 1 and len(TR) == len(R) - 1
        return L, R, TL, TR

    def project(self, S, theta, t, L, R):
        vel = self.velocity(S)
        vals = {v: x + t * y for v, x, y in zip(S, theta, vel)}
        assert sum(vals[v] for v in L) == 0
        assert sum(vals[v] for v in R) == 0
        self.projected_nodes += 1
        return tuple(vals[v] for v in L), tuple(vals[v] for v in R)

    def encode(self, S, T, theta):
        assert sum(theta) == 0
        assert self.stable(S, T, theta)
        if len(S) == 1:
            return ('leaf', S[0])
        current = F(0)
        count = 0
        while True:
            f0 = self.flows(S, T, theta)
            df = self.flows(S, T, self.velocity(S))
            candidates = [(-x / y, e) for e, x, y in zip(T, f0, df)
                          if y < 0 and -x / y > current]
            if not candidates:
                # Residual attractor-germ object, absent on connected
                # acyclic induced graphs with at least two vertices.
                assert all(y >= 0 for y in df)
                self.max_sweep = max(self.max_sweep, count)
                return ('terminal_on', T, S)
            t = min(z[0] for z in candidates)
            active = [e for z, e in candidates if z == t]
            if len(active) != 1:
                raise DegenerateProjection((S, theta, T, t, active))
            e = active[0]
            L, R, TL, TR = self.split(S, T, e)
            a, depart, enter = self.crossing(S, L)
            assert a and e in depart
            k = depart.index(e)
            at = tuple(x + t * y for x, y in zip(theta, self.velocity(S)))
            assert all(x > 0 for f, x in zip(T, self.flows(S, T, at)) if f != e)
            if k < len(enter):
                T = tuple(sorted((set(T) - {e}) | {enter[k]}))
                current = t
                count += 1; self.steps += 1
                continue
            self.max_sweep = max(self.max_sweep, count)
            thL, thR = self.project(S, theta, t, L, R)
            return ('node', k - len(enter),
                    self.encode(L, TL, thL), self.encode(R, TR, thR))

    @staticmethod
    @lru_cache(None)
    def leaves(obj):
        if obj[0] == 'leaf':
            return (obj[1],)
        if obj[0] == 'node':
            return tuple(sorted(Sweep.leaves(obj[2]) + Sweep.leaves(obj[3])))
        if obj[0] == 'terminal_on':
            return obj[2]
        raise ValueError('unknown object')

    def object_partition(self, S, left, right):
        # An optional terminal leaf stores its actual support explicitly
        # at the enumeration boundary; ordinary acyclic objects use leaf
        # labels alone.  The two formats are normalized by pack().
        def support(o):
            return o[2] if o[0] == 'terminal_on' else self.leaves(o)
        L, R = support(left), support(right)
        assert tuple(sorted(L + R)) == S
        assert min(S) in L
        return L, R

    def decode(self, S, obj, theta):
        if obj[0] == 'leaf':
            assert S == (obj[1],)
            return ()
        if obj[0] in ('terminal', 'terminal_on'):
            T = obj[1]
            f0 = self.flows(S, T, theta)
            df = self.flows(S, T, self.velocity(S))
            assert all(y > 0 or (y == 0 and x > 0) for x, y in zip(f0, df))
            current = None  # positive infinity, not the starting chamber
        else:
            _, color, left, right = obj
            L, R = self.object_partition(S, left, right)
            a, depart, enter = self.crossing(S, L)
            th = dict(zip(S, theta))
            h = sum(th[v] for v in L)
            assert a and h / a > 0
            t = h / a
            thL, thR = self.project(S, theta, t, L, R)
            TL = self.decode(L, left, thL)
            TR = self.decode(R, right, thR)
            assert 0 <= color < len(depart) - len(enter)
            e = depart[len(enter) + color]
            T = tuple(sorted(TL + TR + (e,)))
            current = t
        while True:
            f0 = self.flows(S, T, theta)
            df = self.flows(S, T, self.velocity(S))
            candidates = [(-x / y, e) for e, x, y in zip(T, f0, df)
                          if y > 0 and -x / y > 0 and (current is None or -x / y < current)]
            if not candidates:
                assert self.stable(S, T, theta)
                return T
            t = max(z[0] for z in candidates)
            active = [e for z, e in candidates if z == t]
            if len(active) != 1:
                raise DegenerateProjection((S, theta, T, t, active))
            e = active[0]
            cut, _, _, _ = self.split(S, T, e)
            _, depart, enter = self.crossing(S, cut)
            assert e in enter
            eprev = depart[enter.index(e)]
            T = tuple(sorted((set(T) - {e}) | {eprev}))
            current = t
            self.reverse_steps += 1

    @lru_cache(maxsize=100000)
    def enumerate_objects(self, S, theta):
        if len(S) == 1:
            return (('leaf', S[0]),)
        out = []
        for T in self.trees(S):
            f0 = self.flows(S, T, theta)
            df = self.flows(S, T, self.velocity(S))
            if all(y > 0 or (y == 0 and x > 0) for x, y in zip(f0, df)):
                out.append(('terminal_on', T, S))
        for size in range(1, len(S)):
            for tail in combinations(S[1:], size - 1):
                L = (S[0],) + tail
                R = tuple(v for v in S if v not in L)
                a, depart, enter = self.crossing(S, L)
                if not a:
                    continue
                vals = dict(zip(S, theta))
                h = sum(vals[v] for v in L)
                if not h:
                    raise DegenerateProjection((S, theta, L))
                if h / a <= 0:
                    continue
                thL, thR = self.project(S, theta, h / a, L, R)
                left = self.enumerate_objects(L, thL)
                if not left:
                    continue
                right = self.enumerate_objects(R, thR)
                for color, l, r in product(range(abs(a)), left, right):
                    out.append(('node', color, l, r))
        return tuple(out)


def check(name, n, edges, trials=4):
    rng = Random(n * 10000 + len(edges))
    cases = []
    for trial in range(trials):
        for attempt in range(10):
            sw = Sweep(n, edges)
            vals = [F(0) for _ in range(n)]
            for i, j, _ in edges:
                x = F(rng.randrange(1, 101))
                vals[i] += x; vals[j] -= x
            perturb = [rng.randrange(-10**9, 10**9) for _ in range(n - 1)]
            perturb.append(-sum(perturb))
            theta = tuple(x + F(y, 10**12) for x, y in zip(vals, perturb))
            S = tuple(range(n))
            ts = [T for T in sw.trees(S) if sw.stable(S, T, theta)]
            try:
                mp = {T: sw.encode(S, T, theta) for T in ts}
                assert len(set(mp.values())) == len(ts)
                independent = sw.enumerate_objects(S, theta)
                assert len(independent) == len(set(independent))
                assert set(independent) == set(mp.values())
                for T, o in mp.items():
                    assert sw.decode(S, o, theta) == T
                # The independent definition is fed to the decoder too.
                for o in independent:
                    T = sw.decode(S, o, theta)
                    assert sw.encode(S, T, theta) == o
                cases.append({'stable_trees': len(ts), 'independent_flow_objects': len(independent),
                              'forward_swaps': sw.steps, 'reverse_swaps': sw.reverse_steps,
                              'max_single_sweep_swaps': sw.max_sweep,
                              'exact_child_projections': sw.projected_nodes,
                              'all_actual_roundtrips': True})
                break
            except DegenerateProjection:
                continue
        else:
            raise AssertionError('could not find fully generic root parameter')
    return {'name': name, 'vertices': n, 'arrows': len(edges), 'trials': cases}


if __name__ == '__main__':
    # Keep the families explicit; repeated edge labels are genuine colors.
    families = [('transitive_triangle', 3, [(0, 1, 0), (1, 2, 0), (0, 2, 0)]),
        ('mixed_parallel_DAG', 4, [(0, 1, k) for k in range(2)] +
         [(1, 2, 0), (0, 3, 0), (2, 3, 0), (2, 3, 1), (0, 2, 0)]),
        ('complete_DAG_5', 5, [(i, j, 0) for i, j in combinations(range(5), 2)]),
        ('complete_DAG_6', 6, [(i, j, 0) for i, j in combinations(range(6), 2)]),
        ('K3_3', 6, [(i, j, 0) for i in range(3) for j in range(3, 6)]),
        ('K4_4', 8, [(i, j, 0) for i in range(4) for j in range(4, 8)]),
        ('cycle_3_terminal', 3, [(0, 1, 0), (1, 2, 0), (2, 0, 0)]),
        ('cycle_4_with_chords', 4,
         [(0, 1, 0), (1, 2, 0), (2, 3, 0), (3, 0, 0), (0, 2, 0), (1, 3, 0)]),
    ]
    result = []
    for name, n, edges in families:
        out = check(name, n, edges)
        result.append(out)
        print(json.dumps(out), flush=True)
    Path(__file__).with_name('stable_tree_sweep_results.json').write_text(json.dumps(result, indent=2))
