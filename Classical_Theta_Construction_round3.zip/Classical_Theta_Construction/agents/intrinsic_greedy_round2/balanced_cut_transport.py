"""Exact object-level stable-tree transport at balanced cuts.

The local theorem applies to arbitrary finite directed multigraphs.  The
codimension-two loop experiment uses complete bipartite graphs as a small
test of the general local mechanism, not as evidence of a theta theorem.
"""
from fractions import Fraction
from itertools import combinations
from math import atan2, gcd
from random import Random
import json
from pathlib import Path


def components(n, edges):
    p = list(range(n))
    def find(a):
        while p[a] != a:
            p[a] = p[p[a]]; a = p[a]
        return a
    for i, j, _ in edges:
        a, b = find(i), find(j)
        if a == b:
            return None
        p[a] = b
    out = {}
    for i in range(n):
        out.setdefault(find(i), set()).add(i)
    return tuple(frozenset(v) for v in out.values())


def tree_flows(n, all_edges, tree, theta):
    adj = [[] for _ in range(n)]
    for e in tree:
        i,j,_ = all_edges[e]
        adj[i].append((j,e)); adj[j].append((i,e))
    vals = list(theta); deg = [len(a) for a in adj]
    q = [i for i,d in enumerate(deg) if d == 1]
    flow = {}
    for i in q:
        if deg[i] != 1:
            continue
        j,e = next((j,e) for j,e in adj[i] if deg[j] > 0)
        s,t,_ = all_edges[e]
        flow[e] = vals[i] if s == i else -vals[i]
        vals[j] += vals[i]
        deg[i] = 0; deg[j] -= 1
        if deg[j] == 1: q.append(j)
    return flow if len(flow) == n-1 else None


def all_trees(n, edges):
    for T in combinations(range(len(edges)), n-1):
        if components(n,[edges[e] for e in T]) is not None:
            yield T


def stable(n, edges, T, theta):
    f = tree_flows(n,edges,T,theta)
    return f is not None and all(x > 0 for x in f.values())


def cut_lists(edges,U):
    plus=[];minus=[]
    for e,(i,j,_) in enumerate(edges):
        if i in U and j not in U: plus.append(e)
        if j in U and i not in U: minus.append(e)
    return plus,minus


def forest_tour_pairing(n,edges,forest,U,reverse=False):
    """Pair boundary arrows by the contour of the retained forest component.

    This is an actual local Dyck-stack rule; no coefficient cardinalities
    appear.  It is an experimental candidate for coherent cut transport.
    """
    adj=[[] for _ in range(n)]
    for e,(i,j,_) in enumerate(edges):
        adj[i].append(e);adj[j].append(e)
    for i in range(n):
        adj[i].sort(key=lambda e:(sum(edges[e][:2])-i,edges[e][2]),reverse=reverse)
    i=min(U);start=(i,adj[i][0]);cur=start;ports=[]
    visited=set()
    while cur not in visited:
        visited.add(cur);i,e=cur
        s,t,_=edges[e];j=t if s==i else s
        if j not in U:ports.append(e)
        if e in forest:
            i=j
        pos=adj[i].index(e)
        cur=(i,adj[i][(pos+1)%len(adj[i])])
    assert cur==start
    plus,minus=cut_lists(edges,U)
    assert set(ports)==set(plus+minus)
    pset=set(plus);mp={}
    for a,e in enumerate(ports):
        if e not in pset:continue
        level=1
        for step in range(1,len(ports)+1):
            f=ports[(a+step)%len(ports)]
            level+=1 if f in pset else -1
            if level==0:
                assert f not in mp
                mp[e]=f;mp[f]=e;break
        else:raise AssertionError('unbalanced tour')
    assert len(mp)==len(ports)
    return mp


def cut_map(n,edges,T,U,oldtheta,newtheta,pairing='lex'):
    if stable(n,edges,T,newtheta): return T
    plus,minus=cut_lists(edges,U)
    assert len(plus)==len(minus)
    if pairing == 'transpose':
        # Applies to bipartite unit-arrow graph, preserving rectangular indices.
        plus=sorted(plus,key=lambda e:(edges[e][0],edges[e][1]))
        minus=sorted(minus,key=lambda e:(edges[e][1],edges[e][0]))
    bad=[]
    for e in T:
        c=components(n,[edges[x] for x in T if x!=e])
        if c and U in c: bad.append(e)
    assert len(bad)==1,(T,U,bad)
    e=bad[0]
    if pairing.startswith('tour'):
        mp=forest_tour_pairing(n,edges,set(T)-{e},U,pairing=='tour_reverse')
    else:
        mp=dict(zip(plus,minus));mp.update(zip(minus,plus))
    Tout=tuple(sorted((set(T)-{e})|{mp[e]}))
    assert stable(n,edges,T,oldtheta)
    assert stable(n,edges,Tout,newtheta),(T,Tout,U)
    return Tout


def primitive(x,y):
    d=gcd(x,y);return(x//d,y//d)


def loop_check(k,pairing='lex',seed=0):
    n=2*k;edges=[(i,k+j,0) for i in range(k) for j in range(k)]
    base=[k]*k+[-k]*k
    cuts=[]
    for r in range(1,k):
        for a in combinations(range(k),r):
            for b in combinations(range(k,n),r):
                U=frozenset(a+b)
                if 0 in U: cuts.append(U)
    rng=Random(seed)
    for attempt in range(10000):
        u=[rng.randrange(-100,101) for _ in range(n-1)];u.append(-sum(u))
        v=[rng.randrange(-100,101) for _ in range(n-1)];v.append(-sum(v))
        rays={};good=True
        for U in cuts:
            a=sum(u[i] for i in U);b=sum(v[i] for i in U)
            if (a,b)==(0,0): good=False;break
            r=primitive(-b,a)
            if r in rays or (-r[0],-r[1]) in rays:good=False;break
            rays[r]=U;rays[-r[0],-r[1]]=U
        if good:break
    assert good
    rays_order=sorted(rays,key=lambda r:atan2(r[1],r[0]))
    dirs=[]
    for i,r in enumerate(rays_order):
        s=rays_order[(i+1)%len(rays_order)]
        d=(r[0]+s[0],r[1]+s[1]);assert d!=(0,0)
        delta=[d[0]*u[j]+d[1]*v[j] for j in range(n)]
        scale=1+100*sum(abs(x) for x in delta)
        dirs.append(tuple(Fraction(base[j])+Fraction(delta[j],scale) for j in range(n)))
    trees=list(all_trees(n,edges))
    start=[T for T in trees if stable(n,edges,T,dirs[0])]
    current={T:T for T in start};steps=[]
    for j in range(1,len(dirs)+1):
        old=dirs[(j-1)%len(dirs)];new=dirs[j%len(dirs)]
        U=rays[rays_order[j%len(dirs)]]
        target=[T for T in trees if stable(n,edges,T,new)]
        nxt={T:cut_map(n,edges,V,U,old,new,pairing) for T,V in current.items()}
        assert len(set(nxt.values()))==len(target)==len(start)
        for T,V in current.items():
            assert cut_map(n,edges,nxt[T],U,new,old,pairing)==V
        steps.append({'cut':sorted(U),'stable_count':len(target),
                      'moved':sum(nxt[T]!=current[T] for T in start)})
        current=nxt
    nonfixed=[{'source':list(T),'target':list(current[T])} for T in start if current[T]!=T]
    left=set(start);cycles=[]
    while left:
        T=min(left);cyc=[]
        while T in left:
            left.remove(T);cyc.append(T);T=current[T]
        cycles.append(len(cyc))
    return {'k':k,'pairing':pairing,'seed':seed,'trees':len(trees),'stable':len(start),
            'walls':len(steps),'local_all_bijective':True,
            'monodromy_fixed':len(start)-len(nonfixed),'monodromy_cycles':sorted(cycles),
            'nonfixed':nonfixed[:3],
            'u':u,'v':v,'edges':edges,'steps':steps}


if __name__=='__main__':
    results=[loop_check(k,pairing,seed) for k in (2,3)
             for pairing in ('lex','transpose','tour','tour_reverse') for seed in range(5)]
    out=Path(__file__).with_name('balanced_cut_results.json')
    out.write_text(json.dumps(results,indent=2))
    print(json.dumps({'cases':len(results),'local_bijections':sum(r['walls'] for r in results),
                      'nontrivial_monodromy_cases':sum(r['monodromy_fixed']<r['stable'] for r in results),
                      'summary':[{k:r[k] for k in ('k','pairing','seed','stable','walls','monodromy_fixed')} for r in results]}))
