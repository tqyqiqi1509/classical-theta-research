# Positive-forest normal forms for rank-two thin stable trees

Date: 2026-11-13. This is a second explicit local refinement transport.
It does not use the Ehrhart signed universe, and it does not assert a
global theta associator or Young-equivariance.

## The finite data and common objects

Let the vertices of a finite connected quiver carry nonzero charges
`β_v` in a pointed cone of a rank-two lattice with a nondegenerate
alternating form `η`. There are `max(η(β_u,β_v),0)` individually labeled
arrows `u→v`. The resulting quiver is acyclic. Write `S=Σβ_v`,
`∂e_{u→v}=e_u−e_v`, and

\[
\theta_0=\partial\mathbf1,
\qquad (\theta_0)_v=-\eta(S,\beta_v).
\]

Call a spanning forest `F` admissible when its unique possible internal
flow `x^F` satisfies `∂x^F=θ₀` and every edge of `F` has strictly
positive flow. Isolated vertices are allowed. The support determines this
flow uniquely, by leaf elimination. Equivalently these are exactly the
supports of vertices of the canonical flow polytope.

Order the components `C₁,…,C_s` of each admissible forest by their least
original vertex label. Each component is balanced:

\[
\theta_0(C_i)=0,\qquad \eta(S,\beta_{C_i})=0.
\]

The rank-two and nondegeneracy assumptions imply `β_{C_i}∈Q S`.
Therefore

\[
\#E(C_i,C_j)-\#E(C_j,C_i)
=\eta(\beta_{C_i},\beta_{C_j})=0.
\tag{1}
\]

For each unordered component pair, fix a bijection between its two
opposite arrow sets. For example, use the original vertex order and the
parallel-arrow label to order both lists and match their entries. This
is a local pairing of original arrows; it is not a ranking of feasible
trees. The pairing supplies an undirected color set of size
`m_ij=#E(C_i,C_j)`.

The common finite objects are pairs `(F,U)`, where `F` is admissible
and `U` is a spanning tree of the undirected multigraph on its components
with `m_ij` colors on the pair `{i,j}`. If there is only one component,
`U` is empty. No generic refinement occurs in this definition.

## Encoding a positive tree

Take a generic zero-sum vector `δ` such that `δ(C)≠0` for every
nonempty proper `θ₀`-balanced vertex subset. Choose `ε>0` so small
that the signs of every nonzero `θ₀(C)` are unchanged in
`θ′=θ₀+εδ`. This is one finite list of strict inequalities, so a
single `ε` works for every tree.

If a spanning tree `T` has strictly positive `θ′`-flow, then its
`θ₀`-flow is nonnegative. For an edge `e`, the unique tree flow is
`±θ(C_e)` on one component of `T\e`; sign preservation proves the
assertion edge by edge. Let `F` be the edges with strictly positive
limiting flow. Its components are balanced, and contracting them in `T`
produces a tree on the components. Record the color of each zero-flow
edge using (1), then forget its direction. The result is `(F,U)`.

## Decoding and exact inversion

Conversely, take `(F,U)` and a generic `δ`. Put `δ_i=δ(C_i)`.
Give each edge of the quotient tree an arbitrary reference orientation.
Its unique `δ_i`-flow is obtained by cut sums; it is nonzero because
each side is a nonempty proper union of balanced components. Orient
the edge in its positive-flow direction and take the original arrow
of that direction specified by its color. Adjoin these arrows to `F`.

The resulting graph is a spanning tree: contracting `F` gives exactly
`U`, so it is connected and has `|V|−1` edges without a cycle. The
new quotient-edge flows for `θ₀+εδ` are `ε` times the positive
quotient flows. On each edge of `F`, the flow is its positive limiting
value plus `ε` times a fixed cut sum. The same global sign-preservation
choice of `ε` makes all these flows positive. Its limiting support is
therefore exactly `F`.

Encoding and decoding are inverse. In particular an original zero-flow
edge is recovered because the sign of its quotient cut flow is the one
that made it positive, and the retained color identifies its actual
original arrow. All positive-flow edges are retained literally.

**Theorem.** For every sufficiently small generic refinement, this gives
a bijection between its positive spanning trees and the same finite set
of pairs `(F,U)`. Transport from refinement `δ` to `δ′` means encode
once and decode at `δ′`; the maps obey the strict cocycle identity and
every pentagon on the nose.

This mechanism explains why pairing arrows across one whole neutral cut
can fail: such a pairing may mix arrows between different limiting
forest-component pairs. The common quotient tree preserves those pairs
simultaneously, rather than repairing one cut while changing another.

The theorem extends verbatim to any finite acyclic quiver whose balanced
forest components satisfy the pairwise equality (1). Rank-two pointed
charge data is a sufficient condition. Componentwise balance alone in
an arbitrary quiver is weaker than (1) and is not substituted for it.

## Boundary of the result

This is an actual local positive normal form. Decorations on retained
forest edges or their fixed vertices can be carried unchanged. Decorations
whose definition depends on the changed arrows require their own decoder.
The chosen opposite-arrow pairings need not commute with permutations of
identical charges. Neither natural Young-equivariance nor an identification
with tight Dyck gradings follows merely from this theorem.

Different high-rank binary associations can also change the child charges,
the quiver, and the inherited boundary covectors. The theorem applies when
the original thin graph is fixed and only its generic stability refinement
changes. It is not being used beyond that scope.
