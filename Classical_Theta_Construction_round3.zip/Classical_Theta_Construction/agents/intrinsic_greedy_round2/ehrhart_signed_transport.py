"""Finite common signed universes and actual Box-point transport.

All geometry and involutions use exact Fraction arithmetic.  Triangulations
are supplied as lists of lattice simplices in ordinary affine coordinates.
No sorting/ranking of fixed-point sets is used to define a transport.
"""
from fractions import Fraction as F
from itertools import product, permutations, combinations
from math import factorial, comb
from collections import Counter
from pathlib import Path
import json
import time


def inverse(a):
    n = len(a)
    b = [[F(x) for x in row] + [F(i == j) for j in range(n)]
         for i, row in enumerate(a)]
    det = F(1)
    for j in range(n):
        p = next((i for i in range(j, n) if b[i][j]), None)
        if p is None:
            raise ValueError('singular simplex')
        if p != j:
            b[j], b[p] = b[p], b[j]
            det = -det
        x = b[j][j]
        det *= x
        b[j] = [z / x for z in b[j]]
        for i in range(n):
            if i != j:
                x = b[i][j]
                b[i] = [z - x * y for z, y in zip(b[i], b[j])]
    return tuple(tuple(row[n:]) for row in b), abs(det)


def matvec(a, v):
    return tuple(sum(x * y for x, y in zip(row, v)) for row in a)


class Simplex:
    def __init__(self, vertices):
        self.vertices = tuple(sorted(set(tuple(x) for x in vertices)))
        self.r = len(self.vertices)
        assert all(len(v) + 1 == self.r for v in self.vertices)
        self.rays = tuple(v + (1,) for v in self.vertices)
        self.inv, self.volume = inverse(tuple(zip(*self.rays)))
        self.open = None

    def set_direction(self, w):
        c = matvec(self.inv, w)
        assert all(c), ('direction on a facet', self.vertices, w)
        self.open = tuple(x < 0 for x in c)
        assert not all(self.open), ('positive height required', w)

    def coordinates(self, v):
        return matvec(self.inv, v)

    def contains(self, c):
        return all(x > 0 if op else x >= 0
                   for x, op in zip(c, self.open))

    def decompose(self, c):
        # Open coordinate: n=ceil(c)-1; closed: n=floor(c).
        n = tuple((x.numerator - 1) // x.denominator if op
                  else x.numerator // x.denominator
                  for x, op in zip(c, self.open))
        assert all(x >= 0 for x in n)
        b = tuple(x - k for x, k in zip(c, n))
        assert all(0 < x <= 1 if op else 0 <= x < 1
                   for x, op in zip(b, self.open))
        return n, b


class Triangulation:
    def __init__(self, name, simplices):
        self.name = name
        self.simplices = [Simplex(s) for s in simplices]
        self.d = self.simplices[0].r - 1
        self.r = self.d + 1
        self.vertices = sorted(set(v for s in self.simplices for v in s.vertices))
        self.cache = {}

    def set_direction(self, w):
        for s in self.simplices:
            s.set_direction(w)
        self.w = tuple(w)
        self.cache.clear()

    def locate(self, v):
        if v in self.cache:
            return self.cache[v]
        found = []
        for i, s in enumerate(self.simplices):
            c = s.coordinates(v)
            if s.contains(c):
                n, b = s.decompose(c)
                found.append((i, n, b))
        if len(found) > 1:
            raise AssertionError(('overlapping half-open cells', self.name, v))
        ans = found[0] if found else None
        self.cache[v] = ans
        return ans

    def involution(self, state):
        v, mask = state
        loc = self.locate(v)
        assert loc is not None, ('state outside cone', state)
        i, n, _ = loc
        for j in range(self.r):
            if mask & (1 << j) or n[j]:
                sign = 1 if mask & (1 << j) else -1
                ray = self.simplices[i].rays[j]
                out = (tuple(x + sign * y for x, y in zip(v, ray)),
                       mask ^ (1 << j))
                assert out[0][-1] + out[1].bit_count() == v[-1] + mask.bit_count()
                return out
        return state

    def box_record(self, state):
        v, mask = state
        assert mask == 0 and self.involution(state) == state
        i, n, b = self.locate(v)
        assert not any(n)
        return {'simplex': self.simplices[i].vertices,
                'point': v, 'height': v[-1],
                'barycentric': [str(x) for x in b]}


def choose_direction(triangulations, interior):
    """Choose one rational direction avoiding all supplied simplex facets."""
    d = triangulations[0].d
    for N in range(17, 2000):
        w = tuple(F(x) + F(1, N ** (j + 1))
                  for j, x in enumerate(interior)) + (F(1),)
        if all(all(s.coordinates(w)) for T in triangulations for s in T.simplices):
            for T in triangulations:
                T.set_direction(w)
            assert all(T.locate(w) is not None for T in triangulations)
            return w
    raise ValueError('could not choose direction')


def common_universe(T):
    """Enumerate all (v,A), ht(v)+|A|<=d, using one membership oracle."""
    d = T.d
    lo = tuple(min(v[j] for v in T.vertices) for j in range(d))
    hi = tuple(max(v[j] for v in T.vertices) for j in range(d))
    states, heights = [], Counter()
    for h in range(d + 1):
        for v0 in product(*(range(h * a, h * b + 1) for a, b in zip(lo, hi))):
            v = tuple(v0) + (h,)
            if T.locate(v) is None:
                continue
            heights[h] += 1
            for mask in range(1 << (d + 1)):
                if h + mask.bit_count() <= d:
                    states.append((v, mask))
    return tuple(states), heights


def alternating_path(T, U, source):
    """Map Fix(I_T) to Fix(I_U), retaining the actual signed path."""
    assert T.involution(source) == source
    x = source
    path = [x]
    seen = {x}
    while True:
        y = U.involution(x)
        if y == x:
            return x, path
        assert y[1].bit_count() % 2 == 1
        path.append(y)
        z = T.involution(y)
        assert z != y and z[1].bit_count() % 2 == 0
        path.append(z)
        assert z not in seen, ('alternating cycle reached from a fixed point', source)
        seen.add(z)
        x = z


def validate_family(name, triangulations, interior):
    start = time.monotonic()
    w = choose_direction(triangulations, interior)
    states, lattice_counts = common_universe(triangulations[0])
    state_set = set(states)
    fixed, checks = {}, 0
    for T in triangulations:
        f = []
        for x in states:
            y = T.involution(x)
            assert y in state_set
            assert T.involution(y) == x
            if y == x:
                assert x[1] == 0
                f.append(x)
            else:
                assert (x[1].bit_count() - y[1].bit_count()) % 2
            checks += 1
        assert len(f) == sum(s.volume for s in T.simplices)
        fixed[T.name] = f
    grades = Counter(x[0][-1] for x in fixed[triangulations[0].name])
    signed_grades = Counter()
    for v, mask in states:
        signed_grades[v[-1] + mask.bit_count()] += (-1) ** mask.bit_count()
    assert all(grades[k] == signed_grades[k] for k in range(triangulations[0].d + 1))
    for T in triangulations:
        assert Counter(x[0][-1] for x in fixed[T.name]) == grades
    ref = triangulations[0]
    normalizations, inverse_normalizations = {}, {}
    max_steps, total_steps, objects = 0, 0, 0
    sample = None
    for T in triangulations:
        mp = {}
        for x in fixed[T.name]:
            y, path = alternating_path(T, ref, x)
            z, back = alternating_path(ref, T, y)
            assert z == x and back == list(reversed(path))
            assert y[0][-1] == x[0][-1]
            mp[x] = y
            steps = len(path) - 1
            max_steps = max(max_steps, steps)
            total_steps += steps
            objects += 1
            if sample is None or steps > sample['steps']:
                sample = {'from': T.name, 'to': ref.name, 'steps': steps,
                          'source': T.box_record(x), 'target': ref.box_record(y),
                          'path': [{'v': a, 'A': [j for j in range(T.r) if b & (1 << j)]}
                                   for a, b in path]}
        assert set(mp.values()) == set(fixed[ref.name])
        normalizations[T.name] = mp
        inverse_normalizations[T.name] = {y: x for x, y in mp.items()}
    def transport(T, U, x):
        return inverse_normalizations[U.name][normalizations[T.name][x]]
    # Verify actual compositions around 5 labelled vertices, including repetitions
    # when a family has fewer than 5 distinct supplied triangulations.
    cycle = [triangulations[i % len(triangulations)] for i in range(5)]
    pentagon_objects = 0
    for x in fixed[cycle[0].name]:
        y = x
        for i in range(5):
            y = transport(cycle[i], cycle[(i + 1) % 5], y)
        assert y == x
        left = transport(cycle[1], cycle[2], transport(cycle[0], cycle[1], x))
        right = transport(cycle[0], cycle[2], x)
        assert left == right
        pentagon_objects += 1
    return {'name': name, 'dimension': ref.d,
            'direction': [str(x) for x in w],
            'triangulations': [{'name': T.name, 'simplices': len(T.simplices),
                                'simplex_volumes': dict(Counter(str(s.volume) for s in T.simplices))}
                               for T in triangulations],
            'universe_size': len(states), 'lattice_counts': dict(lattice_counts),
            'fixed_points_per_triangulation': len(fixed[ref.name]),
            'h_star': [grades[i] for i in range(ref.d + 1)],
            'involution_state_checks': checks, 'transport_objects': objects,
            'alternating_steps': total_steps, 'max_alternating_steps': max_steps,
            'coherence_objects': pentagon_objects,
            'sample_longest_path': sample,
            'elapsed_seconds': round(time.monotonic() - start, 4)}


def box_triangulation(d, q, flipmask=0, fine=False):
    cells = product(range(q), repeat=d) if fine else [tuple(0 for _ in range(d))]
    scale = 1 if fine else q
    simplices = []
    for cell in cells:
        for order in permutations(range(d)):
            p = list(cell)
            chain = [tuple(p)]
            for j in order:
                p[j] += scale
                chain.append(tuple(p))
            chain = [tuple(q - x if flipmask & (1 << j) else x
                           for j, x in enumerate(v)) for v in chain]
            simplices.append(chain)
    return Triangulation(f'box_d{d}_q{q}_flip{flipmask}_' + ('fine' if fine else 'coarse'), simplices)


def run_suite():
    specs = [(1, 7, [0, 1]), (2, 3, [0, 1, 2, 3]),
             (3, 2, [0, 1, 2, 3, 5]), (4, 1, [0, 1, 2, 3, 5])]
    out = []
    for d, q, masks in specs:
        ts = [box_triangulation(d, q, m) for m in masks]
        if q > 1:
            ts += [box_triangulation(d, q, m, True) for m in masks[:2]]
        out.append(validate_family(f'dilated_cube_{d}_{q}', ts, [F(q, 2)] * d))
        print(json.dumps({k: v for k, v in out[-1].items()
                          if k not in ('sample_longest_path', 'triangulations')}), flush=True)
    p = Path(__file__).with_name('ehrhart_signed_results.json')
    p.write_text(json.dumps(out, indent=2))
    return out


if __name__ == '__main__':
    run_suite()
