# A reversible arrow sweep from stable trees to colored flow trees

Date: 2026-11-13. This is an explicit finite map, with an inverse, on
individually labeled arrows. It is not inferred from equality of Euler
characteristics. Its counting recurrence is the familiar attractor-flow
recurrence; historical novelty of this particular arrow-level realization
is not asserted without further source comparison.

The main application proved here is the full child-covector transport for
colored flow trees on a **fixed acyclic thin graph**. The cyclic case has
an exact variant with residual terminal trees, described below. Neither
case by itself identifies tight Dyck gradings or a general theta
multiplication associator.

## 1. Data and sign convention

Let Q be a finite loopless directed multigraph with individually labeled
arrows. Multiple and oppositely directed arrows are allowed. Fix a total
order on the arrows. For disjoint vertex sets A,B, put

\[
 \eta(A,B)=\#E(A,B)-\#E(B,A).
\]

The incidence convention is `partial(u to v)=e_u-e_v` (tail minus head).
For a nonempty vertex set S, write

\[
 c_S=\partial_S\mathbf1,
 \qquad v_S=-c_S=\eta(S,-)|_S.
 \tag{1}
\]

A theta-stable tree on S means an unoriented spanning tree made of
actual directed arrows for which the unique solution of
`partial_T x=theta` has every x_e>0. Here theta(S)=0. If removing an arrow
e=u to v leaves a component C containing u, then its flow is theta(C).
This cut formula fixes every sign below.

At a recursive node we sweep along

\[
                 \theta(t)=\theta+t v_S,\qquad t\geq0.
 \tag{2}
\]

The direction is **minus** the all-one incidence vector. Avoiding a name
such as attractor/anti-attractor is useful because opposite conventions
for incidence and stability reverse those names.

We assume genericity strong enough that all finite positive crossing
times in every recursive restriction are distinct except for the two
descriptions of one cut. This excludes only finitely many rational
hyperplanes. To see that the excluded equations are nontrivial, vary the
initial covector only inside the current descendant S, with total zero
there. All earlier ancestor cut sums are unchanged, so its current
restriction can vary freely over the zero-sum covectors on S. Two
different unoriented cuts then give distinct linear forms. The same
argument deals with vanishing current cut sums. Exact lexicographic
infinitesimals, or a rational point outside this finite union, suffice.

## 2. One crossing is an injection plus explicit surplus colors

Suppose a stable tree loses stability at time t0. Exactly one arrow e
has zero flow. Removing e gives two actual trees T_L,T_R, whose internal
flows are still strictly positive at theta(t0). Choose L to contain the
least vertex of S and put R=S minus L. Set

\[
 a=\eta(L,R),\quad h=\theta(L).
\]

Since `v_S(L)=-a`, the crossing time is t0=h/a>0. In particular a is
nonzero and h,a have the same sign. If a>0, the departing bridge arrows
are E(L,R), and the entering arrows are E(R,L); if a<0 these roles are
reversed. The departing list has exactly |a| more members than the
entering list.

Order both lists by the fixed arrow order. Pair the kth entering arrow
with the kth departing arrow. The remaining |a| departing arrows are
the surplus colors 0,...,|a|-1, in their actual arrow order. This pairs
individual arrows, never an ordered list of theta coefficients or whole
feasible-tree sets.

For a paired departure, replace e by its paired entering arrow and keep
the entire forest T_L union T_R. The new graph is a spanning tree. At
t0 its internal flows are exactly the old internal flows, because its
new bridge also has zero flow. Thus it is stable immediately after t0.
This proves a literal reversible map on the paired part of the crossing.
Every entering bridge has a predecessor. Only surplus departures stop.

## 3. Forward algorithm

Start at a stable tree T for theta. Its edge flows along (2) are affine
functions. Compute the next time when one of them becomes zero.

1. If its departing arrow is paired, replace it as in Section 2 and
   continue the sweep.
2. If it is surplus, record its color and the cut L|R. Recursively encode
   T_L and T_R with their **actual projected covectors**

\[
 \theta_L'=(\theta+(h/a)\eta(S,-))|_L,\qquad
 \theta_R'=(\theta+(h/a)\eta(S,-))|_R.
 \tag{3}
\]

3. If no edge ever becomes zero again, record the current tree as a
   residual terminal object at positive infinity.

Each paired move strictly increases t, among the finite list

\[
 \left\{\theta(C)/\eta(C,S\setminus C)>0:
    \varnothing\ne C\subsetneq S,\ \eta(C,S\setminus C)\ne0\right\}.
\]

Thus every sweep terminates. Every recursive split strictly decreases
the number of vertices. The whole algorithm is finite.

The residual terminal trees on S are exactly the actual trees T whose
cut-flow coefficient pairs satisfy

\[
 (x_e(v_S),x_e(\theta))>_{\rm lex}(0,0)
 \quad\hbox{for every }e\in T.
 \tag{4}
\]

Equivalently, they are stable for all sufficiently large t. They need
not be stable at t=0; retaining that distinction is essential for the
cyclic case.

## 4. Independent target definition and the inverse algorithm

Define a colored flow object recursively, without reference to the
forward algorithm:

* A residual terminal object is any tree satisfying (4), with its
  labeled support retained.
* A binary object consists of a cut S=L disjoint-union R with the least
  vertex in L, a=eta(L,R) nonzero, h/a>0, one of |a| colors, and two
  flow objects for the restricted covectors (3).

For a singleton support the unique object is the labeled leaf. This is
finite because the binary support decreases, and the terminal catalogs
are finite collections of spanning trees.

To decode a binary object, recursively decode its children at (3), join
their actual trees using the surplus departing arrow specified by its
color, and start just before t0=h/a. The joined graph is stable there:
the internal edge flows have positive limits and the bridge has positive
flow on that side.

Now move t backwards. If an edge becomes zero, it is an **entering**
arrow for the forward crossing. It has a unique paired departing arrow.
Replace it by that predecessor, keeping the same two-component forest,
and continue backwards. The crossing times strictly decrease, so the
process reaches t=0 in finitely many steps. No unmatched obstruction
can occur backwards, because every forward entering arrow is paired.

For a residual terminal object, start with its stable germ at positive
infinity and perform the same backwards rule. The finite list of crossing
times makes this exact; no numerical infinite parameter is required.

All replacements invert the same arrow pairing. Between crossings the
tree is unchanged. Consequently forward and backward sweeps reverse
one another, and induction on |S| proves that the two recursive maps
are mutually inverse.

**Theorem 1 (general finite arrow sweep).** For a generic theta and any
finite loopless directed multigraph, stable spanning trees are in an
explicit bijection with the independently defined colored flow objects
above. The bijection retains every vertex label, records actual surplus
arrow colors, and passes the full projected covectors (3) to children.

## 5. The acyclic theorem and all-descendant transport

If Q[S] is connected, acyclic, and has at least two vertices, choose a
source with an outgoing arrow. At that vertex the velocity v_S is
strictly negative. A positive flow would require a nonnegative, in fact
positive, source balance, which fails for t large. Thus no non-singleton
terminal object exists. Disconnected supports have no spanning tree.

**Theorem 2 (acyclic colored flow trees).** For a fixed acyclic thin
graph, the map in Theorem 1 is a bijection from theta-stable spanning
trees to ordinary full binary flow trees with the given individually
labeled singleton leaves, admission condition
`sign(theta(L))=sign(eta(L,R))`, child covector (3), and exactly
`|eta(L,R)|` positive colors at each admitted vertex.

The weighted counting version is the standard flow-tree formula in this
thin acyclic setting. The result here gives its actual arrow-level maps,
including all descendants. It requires no induction that tensors an ABC
flip with unchanged child objects: the child covectors are explicitly
recomputed and their actual subtrees are decoded/encoded at those values.

If theta_1 and theta_2 lie in the same chamber of the cut hyperplanes,
they have the same set of stable spanning trees, literally. Write E_i
for the forward sweep and D_i for its inverse. Then

\[
                    \Phi_{ij}=E_jD_i
\tag{5}
\]

is an actual positive correspondence on the colored flow-tree objects.
It obeys `Phi_jk Phi_ij=Phi_ik` and every pentagon, because D_j E_j is
the identity on the common stable-tree set. Internal fake walls may
change the binary types and all inherited covectors; formula (5) still
recomputes them correctly.

For the pointed rank-two setting of `POSITIVE_FOREST_NORMAL_FORM.md`,
different sufficiently small generic refinements of the canonical
all-one incidence covector can lie in different cut chambers. Insert
the explicit (F,U) stable-tree transport between D_i and E_j. The same
cocycle conclusion then follows through that common graphical object
set. This is not a claim that arbitrary thin graphs admit that extra
cross-chamber transport.

In a cyclic graph, (5) also transports the **full** catalogs including
residual terminal objects. Restricting to binary trees with singleton
leaves gives an explicit subset of stable spanning trees: those whose
forward recursion has no non-singleton terminal. Nothing here proves
that changing theta preserves this subset. The distinction must remain
visible in any general cluster-theta application.

## 6. Relation to the theta task and the remaining interface

The old flow-tree construction uses the same rational child projection
(3). In the skew-symmetric squarefree framed setting, every packet leaf
and the root have primitive degree one, so the product of its primitive
vertex multiplicities is exactly the product of the raw |eta| colors.
The present maps therefore apply directly to that raw-color realization
when its induced graph is acyclic. For general cyclic graphs the
singleton-leaf subcatalog is still explicit, but residual attractor
objects cannot be silently discarded when transporting between parameters.

Higher packet weights and valued species introduce nontrivial leaf
degree/phase factors. They need their own actual phase decoder. Likewise,
the two-stack tight-Dyck trees are not yet identified with the stable-tree
objects, so this note does not claim the BLMMR Section 9 bijection.
These are the exact remaining consumers, rather than a gap in the sweep
or its inverse.

## 7. Verification and source review

`stable_tree_sweep.py` independently enumerates the recursive target
catalog, compares it with every forward image, and checks both inverse
compositions for every object. Exact Fraction arithmetic is used for
all child covectors and crossing times. The families include complete
acyclic graphs, parallel arrows, K3,3, K4,4, and cyclic graphs requiring
the infinity-germ terminal clause. The first cyclic attempt incorrectly
required terminal trees to be stable at the starting parameter; the
nontrivial cyclic test detected this, and both the definition and inverse
were corrected to (4). Results are in `stable_tree_sweep_results.json`.

Primary sources being compared include Alexandrov–Pioline,
arXiv:1804.06928; Arguz–Bousseau, arXiv:2102.11200; Mozgovoy,
arXiv:2101.07636; and Mozgovoy–Reineke, arXiv:1212.0410. Their flow-tree,
operadic, and abelian wall-crossing recurrences are established work.
The comparison must distinguish those identities from an explicit
stable-arrow-tree inverse of the kind above. No historical claim is
deduced from keyword-search absence.
