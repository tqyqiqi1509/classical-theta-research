# Literature and route record

Window: 2026-11-13 17:30–17:52 UTC. Scope: independent Gauss/primitive-positivity review and the prefix-carry cyclic construction.

## Primary sources actually inspected

| Source | Inspected interface | Decision |
|---|---|---|
| GHKK, *Canonical bases for cluster algebras*, author PDF, https://paulhacking.github.io/canonicalbases.pdf | Remarks 1.27 and 3.2; Theorem 1.28; Definitions 3.1, 3.3; Proposition 3.4; Definition-Lemma 6.2; Theorem 0.2 | Used as established classical inputs. Integral normal lattice, positive wall functions, coefficientwise finiteness, finite middle algebra, and closure of Θ under scaling were checked. No full-rank hypothesis is inserted into the principal lattice argument. |
| Mandel, arXiv:1503.06183v5, https://arxiv.org/html/1503.06183v5 | Theorem 4.2 and its scaled broken-line proof | Direct overlap at modulus p. Must be credited. The displayed theorem does not state higher prime powers or positive Möbius primitives. |
| Moree, *The formal series Witt transform*, arXiv:math/0311194v2, https://arxiv.org/pdf/math/0311194 | Definition 1; Theorems 3 and 4; circular-word section | Standard integer/positive Witt transform and necklace mechanism. The initial C_h argument reduces to this mechanism on every skeleton, not only on multiplicative theta rays. It is not new necklace theory. |
| Gossow, *Polynomial and combinatorial analogues of Gauss congruence*, arXiv:2410.05678v2, https://arxiv.org/html/2410.05678v2 | Sections 3–6, especially Lemmas 4.9–4.10, Definition 5.1, Theorems 5.2, 6.4, 6.5 | Existing ranked-semigroup/Lyndon-structure language, general cyclic-set Gauss implications, and universal necklace models. No cluster or scattering occurrence was found in the full text. The theta-specific action and its hypotheses still need to be supplied; we do so explicitly. Do not advertise the general cyclic-set implication as new. |
| Beukers–Houben–Straub, *Gauss congruences for rational functions in several variables*, https://arminstraub.com/pub/gausscongruences | Author abstract/bibliographic page and search-exposed introduction | Relevant broader arithmetic context, but not used as a theorem premise. Rationality of the complete theta-ray generating series has not been proved here, so no immediate application is claimed. |

## Search queries and outcomes

Both search engines were used for combinations of “cluster theta”, “Gauss congruences”, “prime-power”, “Witt transform”, “Dold”, “necklace”, “symmetric powers”, “complete symmetric”, and “lambda-ring”. Most theta hits concerned analytic or modular theta functions and were irrelevant. No directly matching cluster-theta higher-power or positive primitive theorem was identified in this search window. This is a limited search outcome, not a priority certification.

Broader searches on products of binomial coefficients, multivariate cycle lemmas, and Gauss/Lagrange inversion led to Moree, Beukers–Houben–Straub and Gossow. The Gossow source is a useful interface and a necessary novelty boundary.

No 2026 work was used as a mathematical premise. Search-only 2026 aggregator entries on unrelated congruences or generalized quantum clusters were not promoted to evidence; they remain unused and unaudited. This avoids importing unverified 2026 claims into the classical argument.

## Route evolution and status

1. **Adversarial arithmetic review.** Checked p=2, integral valued normals, nonprimitive wall monomials, zero-weight potential skeletons, finite coefficient cutoffs and output-dependent multiplication endpoints. No defect found within the principal classical scope. Complete review in `INDEPENDENT_REVIEW.md`.
2. **Per-skeleton strengthening.** Proved N divides each skeleton Möbius numerator by prefix valuations and prime-pair telescoping. Combined with the C_h free-point count, this gives a nonnegative integer per skeleton. It still did not exhibit a C_N action.
3. **Prior-art reduction.** Observed S/h is a coefficient of the ordinary multivariate h-th Witt transform of the product of local series raised to a_j/h. Thus the C_h positivity mechanism itself is classical.
4. **Auxiliary major-index route.** Considered a q-Gauss refinement via q-multinomial root values. This suggested looking for a direct cyclic action. It is paused; no q or quantum claim is part of the result.
5. **Prefix-carry action.** Constructed an actual C_N action by recursively inducing the next local word rotation from the prefix stabilizer. Fixed points are literally repeated words. Lexicographic representatives make repetition maps equivariant under quotient cyclic actions. This yields free-orbit primitive counts and prime-power Gauss divisibility directly. Full proof in `PREFIX_CARRY_CYCLIC_ACTION.md`.
6. **Explicit verification.** Arithmetic Wolfram run: 434 synthetic local skeletons, N=2,…,32, no failure. Exact Python action enumeration: ten datasets, 10,660 decorations, all subgroup fixed-set and repetition-equivariance checks passed. Independent Wolfram action run: 420 points with four length-3 orbits and 68 length-6 orbits, agreeing exactly. These synthetic local tests do not assert that every datum occurs as a cluster-geometric skeleton.
7. **Remaining naturality boundary.** The action uses a fixed diagram, endpoint, coefficient cutoff, alphabet realization and alphabet ordering. No equivariant associator under wall refinement or endpoint transport has been proved. Alphabet choices do not affect the fixed-point cardinalities or primitive coefficient. This limitation is recorded rather than silently promoted to a global geometric symmetry.

