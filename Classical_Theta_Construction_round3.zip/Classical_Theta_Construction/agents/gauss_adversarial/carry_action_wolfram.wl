ClearAll[step, w1s, w2s, states];
w1s = Select[Tuples[{0,1},6], Total[#] == 2 &];
w2s = Select[Tuples[{0,1},8], Total[#] == 2 &];
states = Flatten[Table[Join[u,v], {u,w1s},{v,w2s}],1];
step[state_List] := Module[{u=Take[state,6],v=Drop[state,6],orb,r,can,phase,d}, orb=DeleteDuplicates[Table[RotateLeft[u,k],{k,0,5}]];r=Length[orb];can=First[Sort[orb]];phase=First[FirstPosition[Table[RotateLeft[can,k],{k,0,r-1}],u]]-1;d=6/r;Join[RotateLeft[u,1],If[phase==r-1,RotateLeft[v,8/d],v]]];
lengths = Length[DeleteDuplicates[NestList[step,#,5]]] & /@ states;
counts = Counts[lengths];
<|"Decorations"->Length[states],"SixthPowerIdentity"->And@@(Nest[step,#,6]==#& /@states),"OrbitCounts"->Association[KeyValueMap[#1->#2/#1&,counts]],"FixedCounts"->Association[Table[d->Count[states,s_/;Nest[step,s,6/d]==s],{d,Divisors[6]}]],"ExpectedOrbitCounts"-><|3->4,6->68|>|>
