# Independent adversarial review: Gauss and positive Witt theta functions

Date: 2026-11-13 UTC. Reviewer: `gauss_adversarial`.

This review starts from the local wall-crossing definition, not from the prior coefficient engine. It has checked the two drafts `GAUSS_CONGRUENCES.md` and `MOBIUS_POSITIVITY.md` against GHKK's original definitions. The core proposed proofs withstand the specific attacks below. This is a mathematical review verdict within the stated assumptions, not a claim that literature novelty has been established.

**Subsequent development.** Sections 5–6 describe the first reviewed proof, when only a $C_h$ action was available. The later companion `PREFIX_CARRY_CYCLIC_ACTION.md` constructs an actual $C_N$ action, with divisor-compatible fixed sets, and therefore supersedes the earlier limitation about the absence of such an action. The arithmetic review below is retained as an independent proof and a record of the route that led to that construction.

## 1. Precise scope accepted by this review

Let $L=M^\circ\oplus N$ be the **full integral principal-coefficient exponent lattice**. Fix a classical cluster scattering diagram in a seed and its positive integral representative. The skew-symmetrizable case is included because wall normals pair integrally with $L$, even when the prime divides a symmetrizer entry. Put $P=\{(Bq,q):q\in\mathbb N^n\}\$, in integral seed coordinates.

The following statements are coefficientwise statements in a translate of the $P$-adic completion:

\[
\vartheta_{p^r g,Q}-\psi_p\vartheta_{p^{r-1}g,Q}
\in p^r\mathbb Z[[P]]Z^{p^r g},
\qquad \psi_d(Z^m)=Z^{dm}.
\]

For the positivity assertion, the more precise conclusion is

\[
\frac1N\sum_{d\mid N}\mu(d)\psi_d(\vartheta_{(N/d)g,Q})
\in Z^{Ng}\mathbb N[[P]].
\]

For $g\in\Theta$, the theta functions and these seedwise expressions are Laurent finite. Formal labels outside Θ are not asserted to yield finite Laurent polynomials. The label $g=0$ is treated separately by θ₀=1; all displayed statements then hold directly. A full label with a frozen monomial translation may be handled in the full lattice rather than pretending that its coordinates lie in the mutable lattice alone.

The operation ψ is chartwise. No mutation-equivariant Adams endomorphism of the cluster algebra is obtained from ordinary monomial substitution.

## 2. Original-definition checks

The source checked directly was GHKK, *Canonical bases for cluster algebras*, author PDF, <https://paulhacking.github.io/canonicalbases.pdf>:

- Remark 1.27: crossing a wall acts by $Z^m\mapsto Z^m f^{\langle n,m\rangle}$, with $n\in N^\circ$ primitive in that normal lattice.
- Theorem 1.28: a representative has wall functions $(1+Z^v)^c$ with $c$ a positive integer. Hence products of overlapping same-normal walls have integral nonnegative coefficients.
- Definition 3.1 and Remark 3.2: a broken line has velocity (-m); the local exponent at a genuine crossing is positive. Negative binomial powers are not needed for its bend coefficient.
- Proposition 3.4: the broken-line sum is coefficientwise finite.
- Definition-Lemma 6.2 and Proposition 6.4: multiplication uses a generic endpoint close to the output label; it is not arbitrary-chamber coefficient extraction.
- Theorem 0.2(2),(4),(6),(7): Θ is closed under seedwise addition, the middle algebra has finite positive products, its theta functions are Laurent positive, and the principal-coefficient realization is injective.

Retrievals in this reviewer context: `turn70view1`, `turn88view0`, `turn88view1`, `turn88view2`. The parent should reopen the source when citing it in its own final response.

## 3. Attacks on the local arithmetic

### 3.1 Prime 2 and signed wall coefficients

For any $f\in1+t\mathbb Z[[t]]$, $a\ge1$,

\[
j[t^j]f^a=a[t^{j-1}]f'f^{a-1}
\]

gives

\[
v_p([t^j]f^a)\ge\max(0,v_p(a)-v_p(j)).
\]

Also $f(t)^p=f(t^p)+ph(t)$, and the $k$-th binomial term after raising to $a$ has valuation at least

\[
k+v_p(a)-v_p(k)\ge1+v_p(a).
\]

Thus

\[
f(t)^{pa}-f(t^p)^a\in p^{1+v_p(a)}\mathbb Z[[t]].
\]

The inequality used is valid for $p=2$, including $k=2$, where it can be sharp. There is no missing odd-prime hypothesis. Neither arithmetic lemma needs coefficient positivity. Positivity enters only when coefficients are interpreted as cardinalities.

### 3.2 Valued normals

The only required fact is λ∈Hom(L,Z). If $m\in p^sL$, then $p^s\mid\lambda(m)$. This remains true if the primitive normal in a larger rational vector space is not integral in a chosen ambient coordinate basis. A proof replacing λ with that nonintegral normal would fail; the current draft does not make this replacement.

### 3.3 Nonprimitive monomial directions

Write a local monomial direction $w=hv$, with $v$ primitive in $L$, and use $t=Z^v$. The old series becomes a series with zero coefficients in degrees not divisible by $h$. This preserves integrality and positivity. In principal coefficients the frozen part implies that the primitive $v$ still has a positive integral root coordinate. Consequently every positive index increases the completion degree.

The purpose of primitivity is exact: if $m,m+jv\in pL$, then $p\mid j$. Without primitivity this implication is false, and a proposed direct comparison using the original nonprimitive index would be wrong.

## 4. Prefix invariant and zero-weight skeletons

Define $s_p(m)=\max\{s:m\in p^sL\}$. If a potential skeleton starts at $p^r g$, its prefix weight $A$ obeys

\[
v_p(A)+s_p(m)\ge r.
\]

If $m'=m+jv$ has $s_p(m')<s_p(m)$, primitivity gives $v_p(j)=s_p(m')$, and the derivative bound compensates exactly for this drop. All other steps preserve the inequality directly. A zero local coefficient merely makes the prefix weight zero, so the argument remains valid for potential skeletons.

Therefore a path that ever leaves (pL) has total weight divisible by $p^r$, including a path whose final exponent later returns to (pL). Checking only final divisibility would be insufficient.

For paths staying in (pL), divide every segment exponent and bend index by $p$, and reparametrize by δ$t$=γ(t/p). The geometric image, generic crossing signs and singular-locus avoidance are unchanged. The comparison must allow zero weights: for example $f=1+t^2$ can have a nonzero even upper coefficient and a zero divided lower coefficient.

There is no need to assert that **all** conceivable zero-weight geometric data form a finite set. Use only the union of the actual upper broken lines and the scaled actual lower broken lines at the prescribed coefficient. Both lists are finite by Proposition 3.4. In the positive argument, a nonzero lower decoration can additionally be repeated to show that its upper skeleton has nonzero weight.

The telescope with upper prefix, one local difference, and lower suffix is correct. Immediately before a lower bend of exponent $m_j$, its local error has valuation at least $1+s_p(m_j)$; the upper prefix has valuation at least ℓ=max$0,r-1-s_p(m_j)$. Their sum is at least $r$. This establishes the same-skeleton congruence without cancellation between different skeletons.

## 5. Positive cyclic-word argument

For an upper skeleton at label (Ng), let its positive bend indices be $u_j$, local positive exponents $a_j$, and

\[
h=\gcd(N,u_1,\ldots,u_s).
\]

Each $a_j$ is divisible by $h$. Interpret $[t^{u_j}]f_j^{a_j}$ as the number of colored words of length $a_j$ and degree $u_j$. The action of $C_h$ simultaneously rotating word $j$ by $a_j/h$ places is a genuine action. For $d\mid h$, its subgroup of order $d$ fixes precisely the tuples of $d$-fold repeated words, counted by

\[
W_d=\prod_j[t^{u_j/d}]f_j^{a_j/d}.
\]

The exact contribution of this skeleton to the Möbius numerator is

\[
S=\sum_{d\mid h}\mu(d)W_d
=\#\{\text{decorations with trivial }C_h\text{-stabilizer}\}\ge0.
\]

The empty-word straight skeleton has a singleton decoration set, hence contributes 0 for $N>1$, as required. Missing local degrees and zero coefficients do not cause extra fixed points.

This proves positivity of the numerator. The displayed action gives divisibility by $h$, not automatically by $N$. The next section proves the stronger arithmetic divisibility, but still does not provide a natural $C_N$ action.

## 6. Strengthening: $N\mid S$ for every individual upper skeleton

This strengthens the current draft, which only explicitly claims divisibility after summing skeletons.

Fix $p^r\Vert N$.

**Case 1: $p\nmid h$.** At least one $u_j$ is not divisible by $p$. For every divisor $d\mid h$, $d$ is a $p$-unit. The divided skeleton contributing $W_d$ starts at $(N/d)g\in p^rL$ and has at least one bend index $u_j/d$ not divisible by $p$. Because its direction is primitive, at least one of the segment exponents adjacent to this bend is outside (pL). The prefix invariant therefore gives $p^r\mid W_d$. Hence $p^r\mid S$.

**Case 2: $p\mid h$.** Write $h=p^t h_0$, $p\nmid h_0$. Terms with nonsquarefree divisors vanish, and

\[
S=\sum_{e\mid h_0}\mu(e)(W_e-W_{pe}).
\]

The potential skeleton for $W_e$ begins at $(N/e)g\in p^rL$. Because $pe\mid h$, every segment exponent and every bend index is divisible by $p$, so its divided skeleton is exactly the one for $W_{pe}$. The same-skeleton prefix-plus-telescoping proof gives

\[
W_e-W_{pe}\equiv0\pmod{p^r}.
\]

This includes either weight being zero. Therefore $p^r\mid S$ in this case too.

Doing this for every prime factor of $N$ proves

\[
\boxed{S/N\in\mathbb N\quad\text{for every upper skeleton individually}.}
\]

Consequently each coefficient of $K_{N,g,Q}$ is a finite sum of these nonnegative integers. The conclusion is a local arithmetic property of a genuine decoration count. It is **not** a quotient construction by an exhibited $C_N$ action. Arbitrarily enumerating the free points and grouping them in blocks of $N$ would not be a natural new combinatorial explanation.

The same proof applies to a tuple of broken-line skeletons: put all bend indices from all tuple members in the gcd.

## 7. Structure constants: endpoint review

Let an upper output full label be $R=N\sum_i g_i+(Bq,q)$. For the divisor $d$, a term can contribute only if $d\mid q$; its output is (R/d). Choose a common generic $Q$ sufficiently close to $R$ so that (Q/d) is sufficiently close to (R/d) for every relevant divisor and finite cutoff. This is possible because the divisor set is finite.

Radial homogeneity identifies theta coefficients at (Q/d) and $Q$, with **unchanged** labels: a radial rescaling of the image combined with time reparametrization preserves each velocity decoration. Independently, scaling all segment exponents by $d$ preserves the image after another time reparametrization. These are different uses of homogeneity and should not be conflated.

With these identifications, all divisor terms can be grouped by the same upper tuple of skeletons. The Gauss and cyclic-word arguments apply. This validates the proposed extension to structure constants under GHKK's output-dependent multiplication convention.

## 8. Global complete-symmetric elements: finiteness and integer theta coefficients

For $g\in\Theta$, define

\[
\mathcal H_g(T)=\exp\left(\sum_{k\ge1}\vartheta_{kg}T^k/k\right)
=\sum_{N\ge0}H_{N,g}T^N.
\]

This is intrinsically defined because it uses only addition and multiplication of global theta functions. GHKK's semigroup property ensures $kg\in\Theta$, and the middle algebra's finite multiplication makes every $H_{N,g}$ a finite rational theta combination. The cycle-index formula and theta multiplication positivity make those rational coefficients nonnegative.

The seedwise positive Witt transform gives

\[
\mathcal H_g(T)=\prod_{k,m}(1-Z^mT^k)^{-k_{k,m}},
\qquad k_{k,m}\in\mathbb N.
\]

The joint completion is legitimate: for fixed $T$-degree only finitely many $k$ matter; for a fixed positive-root coefficient only finitely many monomials and partitions contribute. Thus every Laurent coefficient of $H_{N,g}$ is integral and nonnegative.

Here is the exact integral-saturation argument for the theta expansion. Let

\[
H_{N,g}=\sum_{r\in S} c_r\vartheta_r,\qquad
S\subset\Theta\text{ finite},\ c_r\in\mathbb Q.
\]

Each θᵣ is integral and has expansion $Z^r(1+\text{positive }P\text{-degree})$. Order $S$ by $r\preceq r'$ if $r'-r\in P$. Since $P\cap(-P)=\{0\}$, this is a partial order. Choose a minimal $r\in S$. The coefficient of $Z^r$ in the displayed sum is $c_r$: no different label in $S$ can contribute to that monomial. As the Laurent coefficients are integral, $c_r\in\mathbb Z$. Remove this integer multiple of θᵣ and repeat on the finite set. Every $c_r$ is integral, hence nonnegative integral.

This proof does not require the mutable matrix $B$ to have full rank: the map $q\mapsto(Bq,q)$ is injective and its cone is sharp because of the frozen coordinate. In fact the leading term of $H_{N,g}$ is $Z^{Ng}$ with coefficient 1, so its theta expansion starts with θₙᵧ with coefficient 1.

### Specialization warning that affects the mathematical statement

Once the positive integral identity has been proved in principal coefficients, any permitted integral coefficient specialization preserves that identity. For example $y_i=1$ yields a nonnegative integer combination of specialized theta functions even for non-full-rank $B$.

If independence of the specialized theta family has not been established in the intended setting, the justified statement is **existence of a positive integral theta expression**. It is not a claim of unique basis coefficients or a new proof of specialized theta independence. This distinction is unnecessary in the principal realization, where injectivity is part of the established input.

## 9. Additional consequences and limits

The same-skeleton repetition injection and Gauss divisibility imply the positive congruence refinement

\[
\vartheta_{Ng,Q}-\psi_p\vartheta_{(N/p)g,Q}
\in p^{v_p(N)}Z^{Ng}\mathbb N[[P]]
\quad(p\mid N).
\]

This is also immediate from positive Witt inversion. More generally, if $d\mid N$,

\[
\vartheta_{Ng,Q}-\psi_d\vartheta_{(N/d)g,Q}
=\sum_{\substack{e\mid N\\d\nmid e}}(N/e)\psi_e(K_{N/e,g,Q})\ge0.
\]

These coefficientwise inequalities do not establish a λ-ring, Schur positivity, a new basis, or strong positivity of the multiplication table of the $H$-family. No such conclusions are accepted by this review. A separate agent reports a candidate negative exterior-power coefficient; it should be checked independently before being used.

The existing proof remains a proof **using** integral positive scattering data. Replacing a positive coefficient by that many unnamed colors is sufficient for the positivity theorem, but does not by itself remove the abstractness of computing the theta function. To obtain the user's requested explicit pure-combinatorial construction, the colors should be replaced by explicitly computable finite sets (for example tight-Dyck objects from the prior algorithm), and the relevant finite skeletons should be constructible from the seed and target degree. That is a distinct construction task.

## 10. Literature boundary checked so far

Mandel, *Scattering diagrams, theta functions, and refined tropical curve counts*, arXiv:1503.06183v5, Theorem 4.2, explicitly proves θᵤᵖ ≡ θₚᵤ mod $p$. It is exactly the $r=1$ overlap after freshman's dream, and must receive explicit credit. The proof uses scaling of broken lines. Source checked: <https://arxiv.org/html/1503.06183v5>, retrieved as `turn70view0`, `turn88view3`.

Searches on both engines for combinations of cluster theta, Gauss congruence, prime-power, Dold, and Witt transform did not identify a direct earlier statement of the higher-power theorem or its positive Möbius refinement. Most hits concern classical analytic theta series and are irrelevant. This is a search record, **not** proof of priority. The ordinary positive Witt transform and necklace construction are classical and must not be advertised as new.

No 2026 paper is needed as a premise of the arguments accepted above. No Li–Pan theorem has been used.

