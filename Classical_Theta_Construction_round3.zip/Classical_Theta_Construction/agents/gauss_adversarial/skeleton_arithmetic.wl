ClearAll[coef, oneCase, t];
coef[fs_List, a_Integer, u_Integer] := Module[{cs = {1}, k, i}, Do[AppendTo[cs, Together[Sum[((a + 1) i - k) fs[[i + 1]] cs[[k - i + 1]], {i, 1, Min[k, Length[fs] - 1]}]/k]], {k, 1, u}]; Last[cs]];
SeedRandom[20261113];
oneCase[n_Integer] := Module[{g, m, targeth, s, vs = {}, us = {}, aa = {}, ff = {}, v, lam, a, u, f, h, divs, ww, numerator, j, p, pg, upper, lower, r, gaussResults = {}},
g = RandomInteger[{-4, 4}, 2]; If[g == {0, 0}, g = {1, -1}]; m = n g;
targeth = RandomChoice[Divisors[n]]; s = RandomInteger[{1, 5}];
Do[
v = {0, 0}; a = 0;
While[a == 0, v = RandomInteger[{0, 4}, 2]; If[v == {0, 0}, Continue[]]; v = v/(GCD @@ v); lam = RandomChoice[{1, 2, 3, 6, 10}] {v[[2]], -v[[1]]}; a = lam.m; If[a < 0, lam = -lam; a = -a]];
u = targeth RandomInteger[{1, 4}]; f = Join[{1, RandomInteger[{1, 4}]}, RandomInteger[{0, 4}, 2]];
AppendTo[vs, v]; AppendTo[us, u]; AppendTo[aa, a]; AppendTo[ff, f]; m = m + u v,
{j, 1, s}];
h = GCD @@ Prepend[us, n]; divs = Divisors[h];
ww = Table[Times @@ Table[coef[ff[[j]], aa[[j]]/d, us[[j]]/d], {j, 1, s}], {d, divs}];
numerator = Total[MapThread[MoebiusMu[#1] #2 &, {divs, ww}]];
Do[If[Mod[h,p] == 0, upper = First[ww]; lower = Times @@ Table[coef[ff[[j]], aa[[j]]/p, us[[j]]/p], {j,1,s}]; AppendTo[gaussResults, Mod[upper-lower,p^IntegerExponent[n,p]] == 0], AppendTo[gaussResults, Mod[First[ww],p^IntegerExponent[n,p]] == 0]],
{p, First /@ FactorInteger[n]}];
{n, h, And @@ gaussResults, IntegerQ[numerator/n], numerator >= 0, If[!IntegerQ[numerator/n] || numerator < 0, {g, vs, us, aa, ff, numerator}, Null]}
];
cases = Flatten[Table[oneCase[n], {n, 2, 32}, {rep, 1, 14}], 1];
failures = Select[cases, !(#[[3]] && #[[4]] && #[[5]]) &];
<|"Seed" -> 20261113, "RandomSkeletons" -> Length[cases], "TestedN" -> Range[2,32], "MöbiusFailures" -> Length[failures], "NontrivialGCDCases" -> Count[cases, c_ /; c[[2]] > 1], "FullGCDCases" -> Count[cases, c_ /; c[[2]] == c[[1]]], "Failures" -> Take[failures, UpTo[2]]|>
