"""Exact finite verification of the prefix-carry cyclic action.

These are local skeleton data, not assertions that every synthetic datum occurs
as a geometrically valid cluster broken line. No theta coefficient engine is used.
"""
from functools import lru_cache
from itertools import product
from math import gcd
from collections import Counter
import json
from pathlib import Path


def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]


@lru_cache(None)
def words(degrees, length, degree):
    if length == 0:
        return ((),) if degree == 0 else ()
    if degree < 0:
        return ()
    return tuple((letter,) + tail
                 for letter, weight in enumerate(degrees)
                 if weight <= degree
                 for tail in words(degrees, length - 1, degree - weight))


def rotate(word, distance):
    if not word:
        return word
    distance %= len(word)
    return word[distance:] + word[:distance]


def cycles(action):
    unseen = set(action)
    result = []
    while unseen:
        representative = min(unseen)
        orbit = []
        current = representative
        while current not in orbit:
            orbit.append(current)
            current = action[current]
        assert current == representative
        unseen.difference_update(orbit)
        result.append(tuple(orbit))
    return result


def carry_action(n, lengths, degrees, alphabets):
    action = {(): ()}
    stage_data = []
    for length, degree, alphabet in zip(lengths, degrees, alphabets):
        extension = {}
        local_words = words(tuple(alphabet), length, degree)
        prefix_orbits = cycles(action)
        stage_data.append({
            "prefix_orbit_lengths": dict(sorted(Counter(map(len, prefix_orbits)).items())),
            "local_word_count": len(local_words),
        })
        for orbit in prefix_orbits:
            r = len(orbit)
            assert n % r == 0
            stabilizer = n // r
            assert length % stabilizer == 0, (n, length, stabilizer)
            for phase, prefix in enumerate(orbit):
                next_prefix = orbit[(phase + 1) % r]
                for word in local_words:
                    next_word = rotate(word, length // stabilizer) if phase == r - 1 else word
                    extension[prefix + (word,)] = next_prefix + (next_word,)
        action = extension
        assert set(action.values()) == set(action)
    return action, stage_data


def iterate(action, point, steps):
    for _ in range(steps):
        point = action[point]
    return point


def repeated(point, repetitions):
    for word in point:
        if len(word) % repetitions:
            return False
        block = word[:len(word) // repetitions]
        if block * repetitions != word:
            return False
    return True


def repeat(point, repetitions):
    return tuple(word * repetitions for word in point)


def verify(case):
    n, lengths, degrees, alphabets = case
    action, stages = carry_action(n, lengths, degrees, alphabets)
    orbit_lengths = Counter(len(orbit) for orbit in cycles(action))
    assert all(n % r == 0 for r in orbit_lengths)
    fixed_counts = {}
    for e in divisors(n):
        fixed = {x for x in action if iterate(action, x, n // e) == x}
        repeated_points = {x for x in action if repeated(x, e)}
        assert fixed == repeated_points, (case, e, "fixed-point mismatch")
        fixed_counts[e] = len(fixed)
        if all(a % e == 0 for a in lengths) and all(u % e == 0 for u in degrees):
            lower, _ = carry_action(n // e, [a // e for a in lengths],
                                    [u // e for u in degrees], alphabets)
            assert {repeat(x, e) for x in lower} == fixed
            assert all(action[repeat(x, e)] == repeat(lower[x], e) for x in lower), (case, e, "equivariance mismatch")
        else:
            assert not fixed
    return {
        "N": n, "lengths": lengths, "bend_indices": degrees,
        "alphabet_degrees": alphabets, "decorations": len(action),
        "orbit_counts_by_length": dict(sorted(orbit_lengths.items())),
        "fixed_counts_by_subgroup_order": fixed_counts,
        "free_orbit_count": orbit_lengths[n], "stages": stages,
        "all_checks_passed": True,
    }


CASES = [
    (2, [2], [2], [[0, 2]]),
    (4, [4, 6], [2, 2], [[0, 1], [0, 1]]),
    (4, [8, 2], [2, 1], [[0, 1], [0, 1]]),
    (6, [6, 8], [2, 2], [[0, 1], [0, 1]]),
    (6, [6, 3], [3, 2], [[0, 1], [0, 1]]),
    (6, [6, 4, 6], [2, 2, 1], [[0, 1], [0, 1], [0, 1]]),
    (6, [6, 8], [2, 2], [[0, 1, 1, 2], [0, 1]]),
    (8, [8, 4], [4, 2], [[0, 1], [0, 1]]),
    (9, [9, 6], [3, 3], [[0, 1], [0, 1]]),
    (12, [12, 6], [6, 1], [[0, 1], [0, 1]]),
]


if __name__ == "__main__":
    results = [verify(case) for case in CASES]
    output = {
        "test_scope": "Exact prefix-carry action, fixed sets, and repetition equivariance on finite local word tuples",
        "case_count": len(results),
        "total_decorations": sum(r["decorations"] for r in results),
        "failures": 0,
        "results": results,
    }
    target = Path(__file__).with_name("carry_action_results.json")
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({k: v for k, v in output.items() if k != "results"}, indent=2))
    for r in results:
        print(json.dumps({k: r[k] for k in ("N", "lengths", "bend_indices", "decorations", "orbit_counts_by_length", "fixed_counts_by_subgroup_order")}))
