"""Exact off-leading positive carriers for classical principal theta functions.

The mathematical proof is OFF_LEADING_POSITIVE_CARRIER.md. The prescribed-degree
theta engine comes from the previous package; this module supplies finite known
cluster products, sparse triangular extraction, support certificates, and a fair
exhaustive search. A stage limit is a computational limit, not a nonexistence test.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations_with_replacement, product
from pathlib import Path
import json
import sys
import time

import sympy as sp

ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT / "history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents"
if str(OLD) not in sys.path:
    sys.path.insert(0, str(OLD))
from incoming_recursion import IncomingSchur


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def le(a, b):
    return all(x <= y for x, y in zip(a, b))


def shifted(B, g, p):
    return tuple(g[i] + sum(B[i][j] * p[j] for j in range(len(g)))
                 for i in range(len(g)))


def sparse_mul(F, H):
    out = {}
    for p, a in F.items():
        for q, b in H.items():
            r = add(p, q)
            out[r] = out.get(r, 0) + a * b
    return {p: a for p, a in out.items() if a}


def sparse_terms(F):
    return [[list(p), a] for p, a in sorted(F.items(), key=lambda pc: (sum(pc[0]), pc[0]))]


@dataclass
class Variable:
    g: tuple
    F: dict
    word: tuple
    index: int

    def key(self):
        return self.g, tuple(sorted(self.F.items()))

    def certificate(self):
        return {"mutation_word_zero_based": list(self.word), "index_zero_based": self.index,
                "g": list(self.g), "F": sparse_terms(self.F)}


class PrincipalMutations:
    """Compute principal F-polynomials and g-vectors by exact exchange relations."""

    def __init__(self, B):
        self.B = tuple(tuple(map(int, row)) for row in B)
        self.n = len(B)
        self.y = sp.symbols(f"y0:{self.n}")

    def initial(self):
        n = self.n
        E = self.B + tuple(tuple(int(i == j) for j in range(n)) for i in range(n))
        gs = tuple(tuple(int(i == j) for i in range(n)) for j in range(n))
        Fs = tuple(sp.Poly(1, *self.y, domain=sp.ZZ) for _ in range(n))
        return E, gs, Fs

    def mutate(self, seed, k):
        E, gs, Fs = seed
        n = self.n
        positive = sp.Poly(1, *self.y, domain=sp.ZZ)
        negative = positive
        for i in range(n):
            positive *= Fs[i] ** max(E[i][k], 0)
            negative *= Fs[i] ** max(-E[i][k], 0)
            positive *= sp.Poly(self.y[i] ** max(E[n+i][k], 0), *self.y, domain=sp.ZZ)
            negative *= sp.Poly(self.y[i] ** max(-E[n+i][k], 0), *self.y, domain=sp.ZZ)
        new_F = (positive + negative).exquo(Fs[k])
        assert new_F.coeff_monomial((0,) * n) == 1
        assert all(c > 0 for _, c in new_F.terms())
        g_positive = tuple(-gs[k][a]
            + sum(max(E[i][k], 0) * gs[i][a] for i in range(n))
            - sum(self.B[a][i] * max(E[n+i][k], 0) for i in range(n))
            for a in range(n))
        g_negative = tuple(-gs[k][a]
            + sum(max(-E[i][k], 0) * gs[i][a] for i in range(n))
            - sum(self.B[a][i] * max(-E[n+i][k], 0) for i in range(n))
            for a in range(n))
        assert g_positive == g_negative
        new_E = tuple(tuple(-E[i][j] if i == k or j == k else
            E[i][j] + max(E[i][k], 0) * max(E[k][j], 0)
                    - max(-E[i][k], 0) * max(-E[k][j], 0)
            for j in range(n)) for i in range(2*n))
        new_gs = list(gs)
        new_Fs = list(Fs)
        new_gs[k] = g_positive
        new_Fs[k] = new_F
        return new_E, tuple(new_gs), tuple(new_Fs)

    def seed_from_word(self, word):
        seed = self.initial()
        for k in word:
            seed = self.mutate(seed, k)
        return seed

    def variable(self, word, index):
        _, gs, Fs = self.seed_from_word(word)
        return Variable(gs[index], {p: int(c) for p, c in Fs[index].terms()}, tuple(word), index)

    def variables_through_depth(self, depth):
        """Consecutive identical mutations may be omitted by involutivity."""
        seen = {}
        frontier = [((), self.initial())]
        for d in range(depth + 1):
            nxt = []
            for word, seed in frontier:
                _, gs, Fs = seed
                for i in range(self.n):
                    v = Variable(gs[i], {p: int(c) for p, c in Fs[i].terms()}, word, i)
                    seen.setdefault(v.key(), v)
                if d < depth:
                    for k in range(self.n):
                        if word and word[-1] == k:
                            continue
                        nxt.append((word + (k,), self.mutate(seed, k)))
            frontier = nxt
        return sorted(seen.values(), key=lambda v: (v.g, tuple(sorted(v.F.items()))))


class Coefficients:
    def __init__(self, B, D=None):
        self.engine = IncomingSchur(B, D)

    @lru_cache(maxsize=None)
    def at(self, g, p):
        return self.engine.theta_prefix(g, p).get(p, 0)

    def on_support(self, g, S):
        return {p: a for p in sorted(S, key=lambda p: (sum(p), p))
                if (a := self.at(g, p))}


def product_data(factors, n):
    h = (0,) * n
    H = {(0,) * n: 1}
    for v in factors:
        h = add(h, v.g)
        H = sparse_mul(H, v.F)
    return h, H


def extract_theta_expansion(B, h, H, oracle):
    """All structure coefficients, inspecting only the finite support of H.

    Valid for a certified positive theta product. Arbitrary positive polynomials
    are not automatically accepted as certified theta products.
    """
    assert H.get((0,) * len(h)) == 1 and all(a > 0 for a in H.values())
    C = {}
    for q in sorted(H, key=lambda p: (sum(p), p)):
        value = H[q] - sum(c * oracle.at(shifted(B, h, r), sub(q, r))
                           for r, c in C.items() if le(r, q))
        assert value >= 0, ("negative structure coefficient", B, h, q, value)
        if value:
            C[q] = value
    return C


def certificate_from_product(B, target, factors, oracle):
    n = len(target)
    h, H = product_data(factors, n)
    possible = [q for q in H if shifted(B, h, q) == target]
    if not possible:
        return None
    C = extract_theta_expansion(B, h, H, oracle)
    for q in sorted(possible, key=lambda p: (sum(p), p)):
        c = C.get(q, 0)
        if not c:
            continue
        S = {sub(r, q) for r in H if le(q, r)}
        F = oracle.on_support(target, S)
        assert F.get((0,) * n) == 1
        assert all(c * a <= H[add(p, q)] for p, a in F.items())
        return {"status": "complete by positive carrier",
                "g": list(target), "product_leading_label": list(h),
                "root_degree_q": list(q), "theta_multiplicity": c,
                "factor_certificates": [v.certificate() for v in factors],
                "product_F": sparse_terms(H),
                "product_theta_coefficients": sparse_terms(C),
                "sparse_support_bound": [list(p) for p in sorted(S)],
                "theta_F": sparse_terms(F)}
    return None


def search_cluster_product_carrier(B, D, target, max_stage=None):
    """Halts on every target theta in the ordinary cluster algebra.

    If max_stage is None this is an unbounded semialgorithm. Failure by a finite
    supplied stage does not imply nonregularity or absence of a later carrier.
    """
    target = tuple(target)
    mutation = PrincipalMutations(B)
    oracle = Coefficients(B, D)
    tested = set()
    stage = 0
    while max_stage is None or stage <= max_stage:
        variables = mutation.variables_through_depth(stage)
        for size in range(stage + 1):
            for ids in combinations_with_replacement(range(len(variables)), size):
                factors = [variables[i] for i in ids]
                key = tuple(v.key() for v in factors)
                if key in tested:
                    continue
                tested.add(key)
                certificate = certificate_from_product(B, target, factors, oracle)
                if certificate is not None:
                    certificate.update({"discovery_stage": stage,
                                        "products_tested": len(tested)})
                    return certificate
        stage += 1
    return {"status": "stage limit reached; no negative conclusion",
            "max_stage": max_stage, "products_tested": len(tested)}


def verify_product_decomposition(B, D, factors):
    """Reconstruct the entire known product from all certified finite summands."""
    h, H = product_data(factors, len(B))
    oracle = Coefficients(B, D)
    C = extract_theta_expansion(B, h, H, oracle)
    recovered = {}
    records = []
    labels = {}
    for q, c in C.items():
        g = shifted(B, h, q)
        S = {sub(r, q) for r in H if le(q, r)}
        F = oracle.on_support(g, S)
        assert F.get((0,) * len(B)) == 1
        for p, a in F.items():
            assert c * a <= H[add(p, q)]
            r = add(q, p)
            recovered[r] = recovered.get(r, 0) + c * a
        records.append({"q": list(q), "g": list(g), "multiplicity": c,
                        "bound_size": len(S), "theta_terms": len(F)})
        labels.setdefault(g, []).append(q)
    assert recovered == H, (B, h, recovered, H)
    collisions = [{"mutable_g": list(g), "distinct_frozen_q": [list(q) for q in qs]}
                  for g, qs in labels.items() if len(qs) > 1]
    return {"B": B, "D": D, "product_leading_label": list(h),
            "product_terms": len(H), "theta_summands": records,
            "off_leading_summands": sum(any(q) for q in C),
            "singular_mutable_label_collisions": collisions}


def verify_mutation_normal_form(B, word):
    mutation = PrincipalMutations(B)
    n = len(B)
    xs = sp.symbols(f"x0:{n}")
    ys = mutation.y
    current = list(xs)
    E, _, _ = mutation.initial()
    for k in word:
        positive = negative = sp.Integer(1)
        for i in range(n):
            positive *= current[i] ** max(E[i][k], 0) * ys[i] ** max(E[n+i][k], 0)
            negative *= current[i] ** max(-E[i][k], 0) * ys[i] ** max(-E[n+i][k], 0)
        current[k] = sp.cancel((positive + negative) / current[k])
        E = tuple(tuple(-E[i][j] if i == k or j == k else
            E[i][j] + max(E[i][k], 0) * max(E[k][j], 0)
                    - max(-E[i][k], 0) * max(-E[k][j], 0)
            for j in range(n)) for i in range(2*n))
    _, gs, Fs = mutation.seed_from_word(word)
    z_sub = {ys[j]: ys[j] * sp.prod(xs[i] ** B[i][j] for i in range(n)) for j in range(n)}
    for i in range(n):
        normal = sp.prod(xs[j] ** gs[i][j] for j in range(n)) * Fs[i].as_expr().subs(z_sub, simultaneous=True)
        assert sp.cancel(normal - current[i]) == 0
    return {"B": B, "word": list(word), "variables_checked": n}


def run_checks():
    start = time.time()
    data = [
        ([[0, 1], [-1, 0]], [1, 1], [2, 2]),
        ([[0, 2], [-2, 0]], [1, 1], [3, 3]),
        ([[0, 3], [-2, 0]], [2, 3], [2, 2]),
        ([[0, 2, -2], [-2, 0, 2], [2, -2, 0]], [1, 1, 1], [1, 1, 1]),
        ([[0, 1, -2], [-1, 0, 1], [2, -1, 0]], [1, 1, 1], [1, 1, 1]),
        ([[0, 2, 1], [-1, 0, 1], [-1, -2, 0]], [1, 2, 1], [1, 1, 1]),
    ]
    results = []
    for B, D, exponents in data:
        M = PrincipalMutations(B)
        factors = []
        for i, multiplicity in enumerate(exponents):
            factors += [M.variable((i,), i)] * multiplicity
        results.append(verify_product_decomposition(B, D, factors))
    mutation_checks = []
    for B, _, _ in data:
        for word in [(0, 1), (1, 0, 1)]:
            mutation_checks.append(verify_mutation_normal_form(B, word))
    search = search_cluster_product_carrier([[0, 2], [-2, 0]], [1, 1], (-1, 1), max_stage=2)
    assert search["status"] == "complete by positive carrier"
    result = {"status": "PASS", "seconds": time.time() - start,
              "product_checks": results, "independent_mutation_checks": mutation_checks,
              "complete_exhaustive_search_example": search,
              "scope": "Exact implementation and sign checks only; the general termination theorem is proved separately."}
    Path(__file__).with_name("positive_carrier_checks.json").write_text(json.dumps(result, indent=2))
    print(json.dumps({"status": result["status"], "seconds": result["seconds"],
        "products_reconstructed": len(results),
        "all_theta_summands": sum(len(r["theta_summands"]) for r in results),
        "off_leading_summands": sum(r["off_leading_summands"] for r in results),
        "mutable_label_collision_groups": sum(len(r["singular_mutable_label_collisions"]) for r in results),
        "mutation_variables_independently_checked": sum(r["variables_checked"] for r in mutation_checks),
        "search_stage": search["discovery_stage"]}, indent=2))


if __name__ == "__main__":
    run_checks()
