# A complete Laurent algorithm from off-leading positive carriers

Date: 2026-11-13 UTC. Independent branch: `finite_envelope_review`.

**Result.** For a classical skew-symmetrizable seed with principal coefficients and inverted frozen variables, a prescribed-degree algorithm for theta coefficients can be upgraded to an algorithm which returns the **complete finite Laurent polynomial** of every theta function that belongs to the ordinary cluster algebra. The algorithm needs only the seed data and the label. It does not require middle = upper, a reddening sequence, a support-dimension vector, or the 2026 valuative-independence theorem.

The additional idea is an exhaustive search for a theta summand of an explicitly known positive product. This is a general effective positive-basis argument. Its support domination is already implicit in the proof of GHKK, Theorem 7.5(2); it must not be presented as a new deep positivity theorem. What is made explicit here is the finite sparse extraction, the treatment of off-leading labels and frozen translations, and the termination proof on the ordinary-cluster-algebra domain. The prior package already contained the leading and injective product bounds.

## 1. Conventions and inputs

Fix an integer skew-symmetrizable matrix \(B\) of size \(n\), with a positive integer symmetrizer \(D\). Work over \(\mathbb Z[y_1^{\pm1},\ldots,y_n^{\pm1}]\), or over its characteristic-zero scalar extension. Set

\[
z_j=y_j\prod_i x_i^{B_{ij}},\qquad
\vartheta_g=x^g F_g(z),\qquad
F_g(z)=\sum_{p\in\mathbb N^n}a_g(p)z^p,
\quad a_g(0)=1.
\]

The coefficients \(a_g(p)\) are nonnegative integers. The input from the previous work is a terminating finite integer procedure for each prescribed \((g,p)\). That coefficient procedure may be used even before a label is known to be regular. It is not an oracle for a complete unknown infinite series.

The full principal exponent lattice is

\[
L=\mathbb Z^n_x\oplus\mathbb Z^n_y,
\qquad \beta(p)=(Bp,p).
\]

The root map \(\beta\) is injective whether or not \(B\) has a kernel. A displayed mutable label \(g\) means the full label \((g,0)\). Frozen translation gives

\[
\vartheta_{(u,v)}=y^v\vartheta_u.
\]

Thus \(y^q\vartheta_{h+Bq}\) has full leading label \((h+Bq,q)\). Different \(q\)'s remain different full labels even when \(Bq\) is the same. No argument below identifies labels merely modulo \(\ker B\).

The standard theta input is exactly the following: cluster variables are regular theta functions; regular theta functions have positive Laurent expansions; theta structure coefficients are nonnegative integers; and their formal product has the pointed form determined by the full root cone. These are GHKK, Definition-Lemma 6.2, Proposition 6.4(3), and Theorem 7.5(1), (2), (4). The finite-product proof of Theorem 7.5(2) is particularly relevant.

## 2. A known finite product and its sparse theta expansion

Take any finite list of cluster variables, with repetitions permitted and with no requirement that the variables belong to a common cluster. Finite mutation words provide the variables and their computable expressions

\[
X_\nu=x^{g_\nu}F_\nu(z),
\qquad F_\nu\in\mathbb N[z],\quad F_\nu(0)=1.
\]

Put

\[
P=\prod_{\nu=1}^s X_\nu=x^hH(z),
\qquad h=\sum_\nu g_\nu,
\qquad H=\prod_\nu F_\nu.
\]

The empty product is allowed. In full principal labels the positive theta expansion is

\[
P=\sum_{q\in\mathbb N^n}c_P(q)y^q\vartheta_{h+Bq},
\qquad c_P(q)\in\mathbb N.
\tag{1}
\]

Equivalently,

\[
H(z)=\sum_qc_P(q)z^qF_{h+Bq}(z).
\tag{2}
\]

The leading coefficient of every \(F\) is one and every summand is positive. Therefore

\[
0\le c_P(q)\le [z^q]H.
\tag{3}
\]

Consequently the complete theta structure support lies in the **known finite set**

\[
\{q:c_P(q)>0\}\subseteq S:=\operatorname{supp}H.
\tag{4}
\]

This is why a product can be tested in finite time. One must not solve \(Bq=g-h\) and then launch an unbounded enumeration of its nonnegative solutions. Even for singular \(B\), only the finitely many \(q\in S\) matter.

### Sparse triangular extraction

Order \(S\) by increasing total root degree, breaking ties lexicographically. For \(r\le q\) coordinatewise write \(r<q\) when \(r\ne q\). Comparing coefficients in (2) gives

\[
\boxed{
c_P(q)=[z^q]H-
\sum_{\substack{r\in S\;:\;r<q}}
c_P(r)a_{h+Br}(q-r).
}
\tag{5}
\]

Every term on the right has already been obtained or is a prescribed theta coefficient. Terms outside \(S\) are zero by (3), so no omitted root degree has to be recursively searched. Formula (5) computes the entire finite theta expansion of \(P\) by integer arithmetic. It may involve subtraction computationally, but its output is nonnegative by the independently established theta product positivity.

The zero degree occurs in \(S\), and \(c_P(0)=1\). The new freedom compared with a leading-label carrier is that a desired target may be detected at **any** \(q\in S\).

## 3. Sparse carrier theorem

**Theorem.** Suppose a product \(P=x^hH(z)\) as above has a degree \(q\in S\) with

\[
g=h+Bq,\qquad c:=c_P(q)>0.
\tag{6}
\]

Then \(\vartheta_g\) is a regular theta function and

\[
\boxed{
\operatorname{supp}F_g\subseteq
S_{P,q}:=\{p\in\mathbb N^n:q+p\in\operatorname{supp}H\},
\qquad
c\,a_g(p)\le[z^{q+p}]H.
}
\tag{7}
\]

In particular (7) is a finite support certificate, including the holes in the support. Its convex consequence is

\[
\operatorname{Newt}F_g\subseteq
\bigl(\operatorname{Newt}H-q\bigr)\cap\mathbb R_{\ge0}^n,
\]

but the sparse statement is stronger and is what the algorithm uses.

**Proof.** In (1) the full theta label of the selected term is \((g,q)\). Multiply the whole identity by the allowed frozen unit \(y^{-q}\). The selected term becomes \(c\vartheta_g\), and all remaining theta summands still have positive coefficients. Divide the resulting initial-chart Laurent identity by \(x^g\). Since \(g=h+Bq\), the left side becomes \(z^{-q}H(z)\). Hence

\[
z^{-q}H(z)
=cF_g(z)+
\sum_{r\ne q}c_P(r)z^{r-q}F_{h+Br}(z).
\tag{8}
\]

All coefficients in (8) are nonnegative, including those at degrees with some negative coordinates on the left. Comparing the coefficient at any \(p\in\mathbb N^n\) gives (7). Regularity also follows from GHKK, Theorem 7.5(2): the selected full theta label is a positive summand of a product of regular theta functions, and frozen translation preserves regularity. Alternatively, applying the same positive domination in every cluster chart proves it directly. No valuative-independence statement is used. \(\square\)

The certificate consists of finite mutation words for the factors, their multiplication multiplicities, \(q\), and the positive integer \(c\) verified by (5). The support bound is then computed directly from the known \(H\).

## 4. Complete finite output once a certificate is found

Given (6), list the finite set \(S_{P,q}\). For each \(p\) in this set evaluate the prescribed-degree integer coefficient procedure. Return

\[
x^g\sum_{p\in S_{P,q}}a_g(p)z^p.
\tag{9}
\]

Equation (7) proves that no omitted coefficient is nonzero. Successive prefixes do not need to stabilize empirically. A rectangle containing \(S_{P,q}\) can be used by an implementation of the coefficient engine; the certificate still proves that all support outside the sparse set vanishes.

If several carriers are found, intersect their sparse support sets and take the smallest coefficient upper bound. The integrality of \(a_g(p)\) improves a rational upper bound to

\[
a_g(p)\le\left\lfloor[z^{q+p}]H/c\right\rfloor.
\]

These are computational refinements of the same proof, not additional structural claims.

## 5. An exhaustive algorithm with a termination theorem

At stage \(m=0,1,2,\ldots\):

1. Enumerate mutation words of length at most \(m\). Compute all variables in the resulting finitely many seeds, together with their initial \(g\)-vectors and finite principal \(F\)-polynomials. Repeated variables may be removed.
2. Enumerate all commutative products of at most \(m\) variables from this finite list, with repetitions. Include the empty product.
3. For each previously untested product, form \((h,H)\). If no \(q\in\operatorname{supp}H\) satisfies \(h+Bq=g\), discard this product without any theta coefficient calculation.
4. Otherwise use (5), test the finitely many possible \(q\)'s, and stop at the first positive coefficient satisfying (6).
5. Return (9), with the finite carrier data that proves its completeness.

Every stage is finite. Each cluster variable has a finite mutation word, and every finite cluster product is eventually tested. Exact mutation and the Laurent phenomenon give a finite method of computing the required factor polynomials. The algorithm does not rely on a list of all cluster variables or on recognition of mutation equivalence.

**Termination theorem.** If the input theta function \(\vartheta_g\) belongs to the ordinary principal-coefficient cluster algebra \(A\), then the algorithm halts.

**Proof.** By the definition of \(A\) as the algebra generated by cluster variables over the frozen Laurent coefficient ring, there is a finite expression

\[
\vartheta_g=\sum_{j=1}^t a_jy^{b_j}P_j,
\qquad a_j\in\mathbb Z,quad b_j\in\mathbb Z^n,
\tag{10}
\]

where each \(P_j\) is a finite cluster product. A characteristic-zero scalar extension allows rational or field coefficients without changing the argument. Write \(P_j=x^{h_j}H_j(z)\), and expand every product by (1). The coefficient of the full theta label \((g,0)\) in (10) is one. Thus at least one summand on the right contributes nontrivially to that full label. For that summand there exists \(q\in\mathbb N^n\) with

\[
b_j+q=0,\qquad h_j+Bq=g,\qquad c_{P_j}(q)>0.
\tag{11}
\]

By (3), this \(q\) lies in the finite support of \(H_j\). The exhaustive enumeration eventually tests \(P_j\), computes its coefficient at this \(q\), and stops. Neither the unknown expression (10) nor its coefficients need to be found by the algorithm. \(\square\)

The domain statement is deliberately one-sided. Success can occur for a theta function whose membership in \(A\) has not been established: being a positive theta summand of an element of \(A\) is not, by itself, a proved membership test for \(A\). We do not assert that every regular theta function of the upper algebra is reachable in this way. In particular, no theorem here identifies the positive-summand closure of cluster products with the whole regular theta set.

## 6. A general positive-basis formulation

The proof uses no cluster-specific geometric assertion after the coefficient rule, positivity, and pointedness are supplied. In any algebra with an effective pointed positive basis, known generators with effective finite positive coordinate expressions, and effective prescribed basis coefficients, the same procedure does the following:

- extracts the finite basis expansion of a known positive product from its finite coordinate support;
- certifies the coordinate support of every basis summand;
- terminates on each basis element that belongs to the algebra generated by the known generators.

The argument is a constructive positive-basis lemma. The cluster specialization is useful because the earlier coefficient algorithm provides the previously missing effective extraction input, while principal frozen coordinates provide an injective root-degree bookkeeping system even at singular exchange matrices.

The same extraction can be applied to products of any already computed regular theta functions. This can enumerate additional regular theta functions and their complete Laurent polynomials. Such iterative discovery is valid; completeness for all regular labels would need a further theorem and is not claimed.

## 7. Relation to the other support mechanisms

The older leading-product bound asks for a product with leading label \(g\), or a product with leading label \(kg\) together with a dilation argument. This theorem permits \(g=h+Bq\) with \(q\ne0\) and verifies the actual structure coefficient at that degree. The multiplicity \(c\) can improve coefficient bounds.

The signed adjacent-divisibility envelope is different. It accepts a possibly signed finite element of the upper algebra and, under a finite-theta-span hypothesis, uses valuative independence to control cancellation. The positive-product procedure needs no such input because every term in (8) is nonnegative. Its proven automatic termination domain is \(\vartheta_g\in A\); the signed envelope covers all regular labels when middle = upper has been established.

The dilation bound from `agents/finite_laurent/RATIONAL_CARRIER_CERTIFICATES.md` can also be composed with an off-leading carrier for \(\vartheta_{kg}\). This gives further valid support certificates, but does not establish reachability for all regular labels. The present termination theorem already holds with \(k=1\).

## 8. Prior-art and use record

- **GHKK, Theorem 7.5(2): used and checked in the original proof.** The positivity argument for finite products, finite theta expansions, and regularity of all positive summands is established prior work. The sparse inequalities and exhaustive discovery algorithm are explicit consequences once the prescribed-degree computation is available.
- **GHKK, Definition-Lemma 6.2 and Proposition 6.4(3): used.** They supply the nonnegative structure coefficients and the formal multiplication identity. The proof is not replacing a signed linear decomposition by an unproved positive one.
- **Previous local injective/reddening and rational leading carriers: overlap recorded.** Their positive product domination is not new here. Off-leading extraction and the termination argument for every theta lying in the generated ordinary algebra are the additional operational statements.
- **CMMM 2026: not needed for this theorem.** Its finite valuative-independence result is used only by the separate signed-envelope route.
- **Li–Pan: no conclusion used.**
- **Search status.** Targeted primary-source searches on 2026-11-13 for theta finite algorithms, cluster products, and Newton support bounds did not identify a source explicitly stating this exact exhaustive sparse algorithm. This is not evidence that the elementary positive-basis argument is novel; the GHKK overlap is substantial and is stated above.

Primary source: Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, especially Definition-Lemma 6.2, Proposition 6.4, and Theorem 7.5, https://paulhacking.github.io/canonicalbases.pdf and https://arxiv.org/abs/1411.1394 .

The accompanying `positive_carrier.py` implements exact principal-coefficient mutations, finite sparse theta extraction, carrier verification, and the exhaustive search with an optional user-supplied stage limit. The optional limit controls a computation; reaching it is reported as an incomplete search, never as a negative mathematical decision.
