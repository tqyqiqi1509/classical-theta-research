# Independent review: direct GHKK support inequalities

Reviewed 2026-11-14 against the final `../zero_endpoint_q_fresh_review/NOVELTY_REDUCTION_AND_CONVEXITY.md`, especially §§4, 6–7. I also read GHKK, *Canonical bases for cluster algebras*, [arXiv:1411.1394v2](https://arxiv.org/abs/1411.1394v2), Definition 8.2, Proposition 8.14, Lemma 8.15 and their relevant proofs in the saved primary text.

**Conclusion:** the direct support-containment argument and the label-independent boundedness criterion are sound, conditional only on the already established positive-freezing/Mandel detector identification. They do not use the complementary-Q length theorem. The support certificate should therefore be attributed to the application of existing tropical mutation, GHKK min-convexity, and the detector, rather than treated as a new general support mechanism.

## 1. Coordinates and signs

Put

\[
C=\begin{pmatrix}B&I\\-I&0\end{pmatrix},\quad
G=(g,0),\quad P=(u,r),\quad
M=G+CP=(g+Bu+r,-u).
\]

Then

\[
C^{-1}G=(0,g),\qquad C^{-1}M=(u,g+r).
\]

The cluster pattern used to tropicalize degree coordinates has exchange matrix **\(C^T\)**. Its old mutable block is \(B^T\), and its leaf coefficient block is \(I\), so an old-only word uses the ordinary principal-coefficient \(B^T\) cluster variables. The identity

\[
C'\operatorname{Trop}\mu^{A}_{k,C^T}(w)
=\varphi_{k,C}(Cw)
\]

has no additional \(D\)-factor. In a seed where the chosen coordinate is linear, its value on a scattering increment \(C_t\alpha\) is \(\alpha_i\geq0\). GHKK Lemma 8.15 therefore supplies the required min-convexity in these conventions; positive symmetrizer rescaling does not need to be asserted to give an integral lattice isomorphism.

## 2. The detector endpoint is sufficient

Write an old-only principal cluster variable in the separated form

\[
X_t=x^{\gamma_t}F_t(yx^{B^T}).
\]

Its transported tropical function is

\[
h_t(m,l)=\operatorname{Trop}X_t\bigl(C^{-1}(m,l)\bigr)
=-\gamma_t\cdot l+\min_{b\in\operatorname{supp}F_t}b\cdot m.
\]

Thus the nonlinear walls depend only on the old coordinates \(m\). At an endpoint in a sufficiently close generic germ of \(M_{\rm old}\), the active linear form attains the minimum at \(M_{\rm old}\). Its derivative evaluated on \(M\) equals \(h_t(M)\), even at a tie. The leaf term is linear, so requiring large positive leaf endpoint coordinates does not disturb this equality. The same homogeneity argument on the initial unbounded ray gives derivative value \(h_t(G)\).

GHKK Definition 8.2 specifies that the derivative evaluated on **decoration exponents** increases along broken lines. Accordingly a nonzero detector coefficient gives

\[
h_t(M)\geq h_t(G).
\]

The frozen-frame degree identity identifies their difference with the mutated degree. A finite family of coordinates requires avoiding only finitely many additional tropical walls in the detector germ. This argument is coefficientwise and does not assume a priori Laurent finiteness.

## 3. Explicit halfspaces and the recession cone

For a full theta support exponent put \(u=r=p\). Expand the ordinary positive principal Laurent polynomial

\[
X_t(B^T)=\sum_{a,b}c_{a,b}x^ay^b,\qquad c_{a,b}>0,
\]

and set \(H_t(g)=\min_{a,b}b\cdot g\). The mutated degree is exactly

\[
P_t=\min_{a,b}\bigl((a+b)\cdot p+b\cdot g\bigr)-H_t(g).
\]

Hence its nonnegativity is equivalent to the finite linear constraints

\[
(a+b)\cdot p\geq H_t(g)-b\cdot g
\quad\text{for every occurring }(a,b).
\]

Intersect these for all selected prefix coordinates and with \(p\geq0\). The origin is feasible because every right-hand side is nonpositive. The polyhedron is therefore never empty, and its recession cone is exactly

\[
\{v\geq0:(a+b)\cdot v\geq0
\text{ for all selected }t,(a,b)\}.
\]

This cone depends on the matrix and selected words, not on \(g\). Consequently the full-theta certificate is bounded for one label precisely when it is bounded for every label. This statement concerns a fixed finite word family; it does not imply that any family eventually succeeds.

For fixed divided-derivative order \(r\), put \(u=r+q\) instead. The variable coefficient of a Laurent term is \(a\cdot q\), so the nonempty derivative polyhedron has recession cone \(\{v\geq0:a\cdot v\geq0\}\). The affine right-hand sides may make that polyhedron empty, unlike the full-theta case.

The stronger full-Artin invariance statement remains separate: an inequality for support does not construct the origin factor, flat collision deformation, or equality of local lengths. I have not inferred novelty for that algebraic realization from this review.
