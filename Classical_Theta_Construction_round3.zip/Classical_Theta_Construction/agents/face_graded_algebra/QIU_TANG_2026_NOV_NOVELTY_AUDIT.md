# Qiu–Tang November 2026: overlap audit

Checked 2026-11-14 against the primary text of Yu Qiu and Liheng Tang, *X-evolution flows/foliations for cluster algebras: partial Bongartz (co-)completions and acyclicity*, [arXiv:2611.09155v1](https://arxiv.org/html/2611.09155v1). The [submission record](https://arxiv.org/abs/2611.09155) dates v1 to **6 November 2026**, rather than 9 November.

## Exact relevant scope

The paper's standing Assumption 1.1 is existence of a green-to-red sequence. Definition 3.4 defines partial Bongartz (co-)completion by intersecting the ordinary completions for all full clusters extending a given partial initial cluster. Lemma 3.8 proves independence of the normalized positive/negative row data used for evolution directions. Theorem 3.12 identifies evolution supports with these partial completions and proves their rank relation.

The closest polynomial result is Theorem 5.7. Its dominant sets are defined through **scalar tropical evaluations of cluster-variable F-polynomials**. It compares those sets for upward/downward evolution supports. I read its proof: the key step perturbs a g-cone vector into the Bongartz co-completion cone using signed weighted C-columns, then compares scalar tropical F-values. Section 2.4 supplies standard cluster-variable F-polynomial facts.

## Consequence for the current theorem

This is relevant adjacent work on canonical completion and boundary cones. Its statements above do not supply either of the concrete assertions proved in our toric note:

\[
\operatorname{in}_{\rho}(Y^a)=X^{Ma},\qquad
M=\begin{pmatrix}D^{-1}C^{-T}D&0\\F&I\end{pmatrix}
\in GL_{2n}(\mathbb Z),\qquad ME_T=E_0C,
\]

or the complete lower-theta coefficient and full-label correspondence

\[
c_r=a+b+E_{T,J}r,\qquad
l_r=\mu^{\mathrm{trop}}_{T\to0}(c_r),\qquad
\alpha(m,n;l_r)=\kappa_{a_J,b_J}(r).
\]

The logical distinction is substantive: a scalar maximum of exponent pairings does not determine the coefficient polynomial on an exposed face, the full frozen-coordinate monomial map, or individual multiplication coefficients. The rank in Theorem 3.12 counts cluster-variable support; it should not be identified with a theorem on lower-rank theta face algebras.

The audit included the definitions and proofs just specified, not only a title/abstract check. A supplementary full-text search found no discussion under the terms “theta”, “Newton”, “initial form”, “toric”, “monomial”, “polytope”, “degeneration”, “freezing”, or “structure constants”. This supports the narrower reading but is not its proof.

**Assessment:** cite Qiu–Tang as adjacent recent work; no exact overlap with our coefficient-sensitive face or uniform toric-initial statements was found in v1. This single-paper audit is not a global priority claim. Qin's freezing coefficient identities and Fujiwara–Gyoda's F/C/G identities remain essential prior results and must retain the attribution already recorded in the main note.

Local primary snapshots: `sources/qiu_tang_2611.09155v1.html` and `.txt`.
