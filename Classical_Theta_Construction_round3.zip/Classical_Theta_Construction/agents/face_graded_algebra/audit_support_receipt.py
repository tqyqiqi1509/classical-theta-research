"""LP-free exact arithmetic verification of recorded support dual certificates.

This checks certificate arithmetic and the integer-box/output bookkeeping.
Branch coverage is established by the independent source review, not this script.
It does not independently recompute theta coefficients.
"""
import json
from pathlib import Path
import sys
import sympy as s


def rat(x): return s.Rational(x)
def vector(x): return [rat(y) for y in x]


def audit(path):
    payload=json.loads(Path(path).read_text())
    cert=payload.get('support_certificate',payload)
    n=len(cert['g'])
    words=[tuple(w) for w in cert['words']]
    assert len(words)==len(set(words))
    assert words==sorted(words,key=lambda w:(len(w),w))
    wordset=set(words)
    assert all(w[:j] in wordset for w in words for j in range(1,len(w)))
    checks=0
    for discarded in cert['discarded_branches']:
        rows=discarded['rows'];f=discarded['farkas'];u=vector(f['multipliers'])
        assert len(u)==len(rows) and all(t>=0 for t in u)
        lhs=[sum(u[j]*rat(rows[j][0][i]) for j in range(len(rows))) for i in range(n)]
        rhs=sum(u[j]*rat(rows[j][1]) for j in range(len(rows)))
        assert lhs==vector(f['combined_left']) and rhs==rat(f['combined_right'])
        assert all(t>=0 for t in lhs) and rhs<0
        checks+=1
    assert cert['status']=='bounded_support_certificate'
    branches=cert['branches']; assert len(branches)==cert['feasible_branch_count']
    maxima=[s.Integer(0)]*n
    for branch in branches:
        rows=branch['rows']
        assert len(branch['bounds'])==n and len(branch['dual_certificates'])==n
        for i,d in enumerate(branch['dual_certificates']):
            u=vector(d['multipliers'])
            assert len(u)==len(rows) and all(t>=0 for t in u)
            lhs=[sum(u[j]*rat(rows[j][0][k]) for j in range(len(rows))) for k in range(n)]
            rhs=sum(u[j]*rat(rows[j][1]) for j in range(len(rows)))
            assert all(lhs[k]>=int(k==i) for k in range(n))
            assert lhs==vector(d['combined_left'])
            assert rhs==rat(d['combined_right'])==rat(branch['bounds'][i])
            maxima[i]=max(maxima[i],rhs)
            checks+=1
    assert maxima==vector(cert['rational_upper_bounds'])
    assert [int(s.floor(v)) for v in maxima]==cert['integer_box']
    seen=set()
    for term in payload.get('terms',[]):
        p=tuple(term['y_exponent']);assert len(p)==n and p not in seen;seen.add(p)
        assert all(isinstance(v,int) and 0<=v<=cert['integer_box'][i] for i,v in enumerate(p))
        assert term['coefficient']>0
        assert any(all(sum(rat(a[j])*p[j] for j in range(n))<=rat(b) for a,b in branch['rows']) for branch in branches)
        expected=[cert['g'][i]+sum(cert['B'][i][j]*p[j] for j in range(n)) for i in range(n)]
        assert term['x_exponent']==expected
    return {'receipt':str(path),'exact_certificate_checks':checks,
            'branches':len(branches),'discarded_branches':len(cert['discarded_branches']),
            'integer_box':cert['integer_box'],'output_terms_checked':len(seen),
            'status':'all arithmetic certificates and output bookkeeping verified',
            'scope':'no LP calls; no independent recomputation of theta coefficients or branch coverage'}


if __name__=='__main__':
    path=sys.argv[1] if len(sys.argv)>1 else 'agents/support_accessibility_fresh/zero_endpoint_complete_laurent_receipt.json'
    print(json.dumps(audit(path),indent=2))
