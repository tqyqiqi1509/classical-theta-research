import sympy as s
import json, random
from pathlib import Path

def pos(x): return max(int(x),0)
def mutate(E,k):
    E=s.Matrix(E); n=E.cols
    return s.Matrix(E.rows,n,lambda i,j: -E[i,j] if i==k or j==k else E[i,j]+pos(E[i,k])*E[k,j]+E[i,k]*pos(-E[k,j]))
def beta_mut(B,b,k):
    return s.Matrix([ -b[k] if j==k else b[j]+pos(B[k,j])*b[k]-B[k,j]*min(b[k],0) for j in range(B.rows)])
def data(B,path):
    B=s.Matrix(B);n=B.rows; E=B.col_join(s.eye(n)); Em=(-B).col_join(s.eye(n)); F=s.zeros(n); rec=[]
    for k in path:
        rec.append((s.Matrix(E),k))
        R=E[n:,:]; Q=E[:n,:]
        a=R[:,k].applyfunc(pos)+F*Q[:,k].applyfunc(pos)
        b=R[:,k].applyfunc(lambda v:pos(-v))+F*Q[:,k].applyfunc(lambda v:pos(-v))
        F[:,k]=s.Matrix([max(a[i],b[i])-F[i,k] for i in range(n)])
        E=mutate(E,k);Em=mutate(Em,k)
    C=Em[n:,:];G=C.inv().T
    beta=G*s.ones(n,1);M=s.eye(2*n); H=s.eye(n); signs=[]
    for Ee,k in rec:
        eps=s.sign(beta[k]);assert eps!=0
        N=s.eye(2*n); N[:,k]=Ee[:,k].applyfunc(lambda v:pos(-eps*v));N[k,k]=-1
        h=s.eye(n);h[k,:]=Ee[k,:].applyfunc(lambda v:pos(eps*v));h[k,k]=-1
        M=M*N;H=H*h
        signs.append(int(eps));beta=beta_mut(Ee[:n,:],beta,k)
    assert beta==s.ones(n,1)
    assert H==C
    assert M*E==B.col_join(s.eye(n))*C
    return dict(C=C,F=F,M=M,E=E,signs=signs)

def mat(a): return [list(map(int,a.row(i))) for i in range(a.rows)]

rng=random.Random(7731)
Bs=[[[0,2],[-1,0]],[[0,2,0],[-1,0,0],[0,0,0]],[[0,1,-1],[-1,0,1],[1,-1,0]],[[0,2,-2],[-2,0,2],[2,-2,0]],[[0,2,0],[-1,0,1],[0,-2,0]]]
results=[]
for B in Bs:
    mismatches=[]
    for _ in range(40):
        n=len(B);path=[rng.randrange(n) for _ in range(rng.randrange(1,9))]
        d=data(B,path)
        if d['M'][n:,:n]!=d['F']:
            mismatches.append({'path':[x+1 for x in path], 'K':mat(d['M'][n:,:n]), 'F':mat(d['F']), 'C':mat(d['C'])})
    results.append({'B':B,'mismatches':mismatches})
print(json.dumps(results))
Path(__file__).with_name('toric_probe_results.json').write_text(json.dumps(results,indent=2))
