# A uniform toric initial chart at the canonical Bongartz endpoint

2026-11-14. Classical parameter q=1. Arbitrary skew-symmetrizable B with a positive integral diagonal symmetrizer D. This note assumes the already proved canonical Bongartz face theorem in `../newton_faces_fresh_final/CANONICAL_FACE_MODEL_ON_DUAL_CLUSTER_CONES.md` and its independent check. It makes the full coordinate transition and all surviving multiplication coefficients explicit. No quantum statement and no unrestricted lower-theta lifting theorem are asserted.

## 1. Data and the closed formula

Use the full principal torus with exponent lattice L=Z^(2n), coordinates X=(x,y), and tall root matrix

    E_0 = [B; I_n],       z_j = X^(E_0 e_j).

Let -w lie in the relative interior of a specified cone rho of the B^T g-vector fan. Let T be its canonical Bongartz endpoint, with I the d positive directions of the optimized root valuation and J its r=n-d zero directions. In this note T also denotes the corresponding endpoint in the ordinary B pattern; the abstract cluster correspondence is the one already fixed in the canonical theorem. Set

    Q = B_T,
    R = C_T(B),                 ordinary principal coefficient matrix,
    C = C_T(-B),                opposite-pattern coefficient matrix,
    F = F_T(B),                 ordinary F-matrix of maximal F-degrees,
    P = D^(-1) C^(-T) D = G_T(-B),
    E_T = [Q; R],
    S = C_J >= 0,              Q_red = Q_JJ.

Both C and R are integral unimodular. The F-matrix is an n by n nonnegative integral matrix. The uniform initial coordinate map from the T torus to the original torus is

    Phi_rho^*(Y^a) = X^(M a),

                    [ P  0 ]
    M =             [ F  I ]       in GL_(2n)(Z).                 (1.1)

Every scalar coefficient in this monomial map is exactly 1. The full root identity is

    M E_T = E_0 C,                                               (1.2)

including the columns in I, not only the retained columns in J. Equivalently,

    P Q = B C,          F Q + R = C.                              (1.3)

No inverse of B or Q occurs. The distinction R=C_T(B) versus C=C_T(-B) is essential.

The map depends only on the canonical endpoint relative to the original seed and is independent of the supplied optimized path and of the location of -w in relint(rho), up to the same endpoint index permutation already allowed by the canonical theorem.

The matrix identities in (1.3), and the description of F, are old: Fujiwara--Gyoda, arXiv:1808.02156v2, Theorem 2.8, Proposition 2.13, Corollary 2.15. The new deduction here is that this particular entire toric map is the actual initial-form transition at the canonical Bongartz boundary cone, even when an available path has valuation ties.

## 2. Why the entire boundary transition is monomial

Take any path to T and form its composite initial-form field isomorphism Phi. Individual strict steps are integral monomial maps, and tied steps retain the full binomial exchange map. The earlier initial-form lemma proves

    in_(u_0)(f) = Phi^*( in_(u_T)(f) )

for every rational f, in the corresponding charts. Here u_0=(0,-w), and E_T^T u_T is positive on I and zero on J.

Apply the canonical face formula to each mutable coordinate Y_j of T. Its full theta label in the T chart is e_j. Its lower label is e_j restricted to J, hence either a standard positive basis vector or zero. In both cases its lower F-polynomial is 1. Therefore

    Phi^*(Y_j) = in_(u_0)(Y_j)

is a single Laurent monomial with coefficient 1. Frozen coordinates are fixed. Thus Phi is a monomial field isomorphism on all 2n coordinates, with an integral exponent matrix of block form [P,0;K,I]. Its matrix is unimodular: a monomial map of rational function fields is an isomorphism only when its character-lattice index is one (for example, apply Smith normal form).

This argument uses that T is the canonical completion. An arbitrary optimized endpoint can have binomial initial mutable coordinates in its zero directions.

Now write -w=G_T(B^T) a, with a_I>0 and a_J=0. Perturb a to a'>0 in the full T chamber. Every mutable coordinate Y_j has just one initial monomial at a, so its finite support gives a neighborhood on which the same monomial remains the unique initial monomial. Consequently the boundary matrix M equals the strict matrix at sufficiently close a'>0.

At any intermediate chart of a path to T, the transformed normal is the G-matrix of T viewed from that chart times a'. Every row is nonzero and sign coherent. Therefore every coordinate of that normal is nonzero, and all mutations along the path are strict. At a strict step k, with epsilon the sign of its root valuation, the exponent pullback matrix N_k has

    N_k e_i = e_i                                      (i != k),
    N_k e_k = -e_k + [-epsilon E_current(:,k)]_+.

The square root pullback matrix is

    H_k = J_k + [epsilon B_current]_(row k,+).

They satisfy

    N_k E_next = E_current H_k,
    (N_k)_mut = D^(-1) H_k^T D.

Tropical duality identifies the ordered product of the H_k with C_T(-B). Since each H_k is an involution, the ordered product of their mutable blocks is D^(-1) C^(-T) D. Telescoping the first identity gives (1.2) for all columns. Hence P has exactly the stated sign and D-weighting.

## 3. The frozen block is the ordinary F-matrix, including singular B

The equations P Q=B C and K Q+R=C do not by themselves determine K when Q is singular. Nor does the ordinary homogeneity equation P=G_T(B)+B K determine K when B is singular. Cancelling B or Q here would be invalid.

Instead use the invertible square principal extension

                  [ B  -I ]
    Bbar =        [ I   0 ],             Dbar=diag(D,D).

Regard all 2n coordinates as mutable, but perform only the original first-n mutations. The first n columns of Bbar_current are exactly E_current. Thus the strict mutable coordinate matrices for the extended pattern are exactly the original full matrices N_k.

Start with the strict normal beta_0=G_T(B^T)a' in the first n root coordinates. The evolution of these first n coordinates depends only on themselves and the original B_current. Choose the remaining n initial root coordinates large enough that they are positive at T. They are never mutated, and each changes by an additive quantity determined by the fixed first-n evolution, so this is possible. The resulting 2n-dimensional normal ends in the interior of the full T chamber.

For clarity about valuations: since Bbar is invertible, this extended root normal is realized by a coordinate weight ubar=(Bbar^T)^(-1) betabar. Its first n root pairings are E_0^T ubar=beta_0. Therefore ubar minus the original coordinate weight annihilates E_0. Every original cluster-variable support lies in one translate of E_0 N^n, so this change of coordinate weight changes all its monomial weights by the same constant. It changes none of its initial monomials. Equivalently, the strict branch signs in the original n mutation directions are unchanged.

Apply the already established strict mutable-block formula to Bbar. It gives

    M = G_T(-Bbar).

Fujiwara--Gyoda Theorem 4.2 and Corollary 4.5 give

    G_T(Bbar) = diag(G_T(B), I),
    F_T(Bbar) = diag(F_T(B), 0).

Their Theorem 2.8 gives, for the same mutation word,

    G_T(-Bbar) = G_T(Bbar) + Bbar F_T(Bbar)
               = [ G_T(B)+B F_T(B),  0 ; F_T(B), I ]
               = [ G_T(-B),          0 ; F_T(B), I ].

This proves K=F_T(B) without cancelling a singular matrix. It also identifies the boundary-selected monomial of every endpoint cluster variable with its unique componentwise maximal F-monomial. Its coefficient is one, in agreement with the earlier face proof.

## 4. Uniform face anchors and labels for every finite theta

Let theta_m have full original label m=(g,f). Write

    a = mu^trop_(0 -> T)(m),      A = M a.

The full-lattice theta label transformation is the usual one, at a step k:

    m'_k = -m_k,
    m'_i = m_i + [E_ik]_+ m_k - E_ik min(m_k,0)     (i != k),

including frozen rows. Then

    in_(u_0)(theta_m)
        = X^A F_(a_J)^(Q_red)(z^S).                             (4.1)

The lower theta is finite. For the normalized original theta_g, whose original frozen label is zero, the complete canonical data are

    p_(g,rho) = F_T(B) a_mut + a_frozen,
    h_(g,rho) = a_J,
    S_rho    = C_T(-B)_J,
    Q_rho    = Q_JJ.                                             (4.2)

Thus all matrices are precomputed once per cone. There is no theta-dependent reverse tie-normalization after the ordinary tropical label a has been found.

For a general original frozen translation f, subtract f from the first expression in (4.2). In either case the support identity proves p>=0 and

    A_mut-g = B p.

The inverse matrix is integral and explicit:

    M^(-1) = [ P^(-1),0 ; -F P^(-1), I ].

The valuation itself also needs no path after this precomputation. With beta_0=-w,

    u_T = M^T(0,beta_0) = (F^T beta_0, beta_0),
    beta_T = E_T^T u_T = C^T beta_0.

Thus the specified cone is checked by beta_T,I>0 and beta_T,J=0. The value of any finite theta is simply u_T.a, or beta_0.p for a normalized original theta.

Consequently the map from full theta labels to actual face prefactors,

    m |-> A=M mu^trop_(0 -> T)(m),

is a bijection of the entire tropical lattice. This statement concerns labels; regularity/finiteness of the theta indexed by a label is a separate restriction.

The weighted formula from the canonical theorem is recovered without dropping the prefactor shift:

    a_mut = D^(-1) C^T D A_mut,
    h = D_J^(-1) S^T D (g+Bp).

## 5. An integral split into reduced principal coefficients and spectators

A freeze of I in the T chart has mutable variables Y_J, frozen variables Y_I and the original y, and root columns E_T,J. Its coefficient rows need not be the identity. They nevertheless admit an explicit unimodular split because R=C_T(B) is unimodular.

Define independent torus coordinates

    u_j   = Y_j,                              j in J,
    v_j   = Y_I^(Q_Ij) y^(R_j),                j in J,
    t_i   = Y_i,                              i in I,
    eta_i = y^(R_i),                          i in I.

There are 2r lower principal coordinates (u,v) and 2d spectator coordinates (t,eta). This is a unimodular change of all 2n torus coordinates: first replace y by y^(R_i), then make the indicated triangular shear using Y_I. In these coordinates

    zeta_j = Y^(E_T e_j) = u^(Q_Jj) v_j,       j in J.

For a full endpoint label a=(a_mut,a_frozen), put c=R^(-1)a_frozen and define

    ell(a)   = (a_J, c_J)                 in Z^(2r),
    sigma(a) = (a_I-Q_IJ c_J, c_I)       in Z^(2d).               (5.1)

The map Lambda:a |-> (sigma(a),ell(a)) is an integral lattice isomorphism. Its inverse is

    a_J=h,
    c_J=f_red,
    c_I=sigma_eta,
    a_I=sigma_t+Q_IJ f_red,
    a_frozen=R c.

The frozen theta image is exactly

    Y^a F_(a_J)^(Q_red)(zeta_J)
       = (t,eta)^(sigma(a)) theta^red_(ell(a))(u,v).             (5.2)

At the lattice level the root correspondence is

    Lambda E_T,J r = (0, (Q_red r,r)).                          (5.3)

The spectator component is zero because the two terms Q_IJ r cancel in (5.1). This is the precise compatibility used in the multiplication formula below.

In particular distinct full ambient labels give distinct lower full labels plus spectator exponents. They remain linearly independent. This is the precise reason no output coefficients need be added together after reduction.

It is unsafe to retain only the reduced mutable label. For Q_red=0 in rank one,

    theta_1 theta_(-1) = 1+v.

Both outputs have mutable label zero, but their full lower labels are (0,0) and (0,1). Dropping the principal coefficient degree loses the individual outputs.

## 6. Exact correspondence of every valuation-minimal output

Let m,n be labels of finite ambient theta functions and let a,b be their full T-chart labels. Write their finite positive ambient product as

    theta_m theta_n = sum_l alpha(m,n;l) theta_l.

For any occurring output, positivity and the pointed T expansions imply that its full endpoint head c satisfies

    c = a+b+E_T q,              q in N^n,                        (6.1)

uniquely. Indeed the output head occurs with coefficient one, so it belongs to the positive Laurent support of the product. E_T has full column rank (its lower block R is unimodular), so q is unique.

Put beta_T=E_T^T u_T, which is positive on I and zero on J. Since every finite theta is pointed and beta_T>=0,

    nu(theta_l)-nu(theta_m)-nu(theta_n) = beta_T . q >= 0.

Equality holds exactly when q_I=0. This establishes the valuation criterion before any comparison of lower coefficients.

Define reduced principal structure constants kappa_(h,k)(r), for r in N^r, by

    theta^red_(h,0) theta^red_(k,0)
       = sum_(r>=0) kappa_(h,k)(r)
           theta^red_(h+k+Q_red r, r).                          (6.2)

The two reduced inputs here are finite by (4.1), so this is a finite sum with nonnegative integer coefficients. The full lower label in each summand includes r, even when Q_red is singular.

For every r with kappa_(a_J,b_J)(r)>0, set

    c_r = a+b+E_T,J r,
    l_r = mu^trop_(T -> 0)(c_r).                                (6.3)

Then theta_(l_r) is finite and

    alpha(m,n;l_r) = kappa_(a_J,b_J)(r),                         (6.4)
    nu(theta_(l_r)) = nu(theta_m)+nu(theta_n).

Conversely every valuation-minimal ambient output is exactly one l_r from (6.3), with the same coefficient. The correspondence is injective since E_T,J has independent columns and tropical mutation is bijective.

Proof of the converse and finiteness is worth making explicit. Take the initial form of the finite positive ambient product. Only q_I=0 survives, by the previous valuation criterion. Apply the split (5.2). Every surviving full output is a distinct element of the lower theta basis times a spectator monomial. All have spectator exponent sigma(a)+sigma(b). On the other hand the product of the two split inputs is exactly (6.2), shifted by their full lower frozen labels and multiplied by that same spectator monomial. Linear independence of the full lower principal theta basis forces a unique surviving ambient output for each nonzero term in (6.2), with its exact coefficient. The ambient product already consists only of finite theta functions, so every lifted theta in (6.3) is finite. No general theorem that arbitrary lower finite labels lift to ambient finite labels is used.

In original exponents the output anchors satisfy the especially simple exact identity

    A_(l_r) = A_m+A_n+E_0 S r.                                  (6.5)

Also

    h_(l_r) = a_J+b_J+Q_red r.

Equations (6.3)--(6.5) give an effective label-and-coefficient correspondence, not merely an equality of sums of face polynomials.

### 6.1 The normalized principal-coefficient convention

For users who write only the mutable initial theta labels, retain the principal coefficient monomials explicitly:

    theta_(g1) theta_(g2)
      = sum_(v>=0) c_B(g1,g2;v) y^v theta_(g1+g2+Bv).

For an occurring output put g_v=g1+g2+Bv, and let p_1,p_2,p_v be the canonical face anchors of the three normalized theta functions. The output is valuation-minimal exactly when

    w . (v+p_v-p_1-p_2) = 0.

For such an output the stronger integral statement is

    v+p_v-p_1-p_2 = S r

for a unique r in N^r, and

    c_B(g1,g2;v) = kappa_(h_1,h_2)(r).

Conversely compute l_r by (6.3) with initial labels (g1,0),(g2,0). Its frozen component is v and its mutable component is g1+g2+Bv. The ambient positivity argument proves v>=0. Thus the full-label algorithm also returns every normalized coefficient monomial individually. Even if B is singular, different v must be retained; they can accompany the same mutable output theta.

## 7. Associated graded: the exact scope

Let A=mid(A_prin(B)) denote the finite-theta algebra with its full frozen Laurent lattice, and let Theta_T be its set of full labels in the T chart. The theta basis is adapted to nu: for any nonzero finite linear combination,

    nu(sum_m b_m theta_m) = min_(b_m != 0) nu(theta_m).           (7.1)

Indeed the minimum-weight initial forms are distinct lower full theta basis elements with spectator tags under (5.2), so even signed coefficients cannot cancel them all.

Consequently there is a basis-preserving algebra isomorphism

    gr_nu A  ~=  span { (t,eta)^sigma(a) theta^red_ell(a)
                         : a in Theta_T }                      (7.2)

onto the displayed based subalgebra of

    k[t_i^(+/-1),eta_i^(+/-1):i in I] tensor mid(A_prin(Q_red)).  (7.3)

The grading on the right is the original weight transported by Lambda^(-1); every reduced root has weight zero. The original-chart realization of (7.2) is the monomial torus isomorphism M followed by (5.2).

There is no blanket claim that (7.2) fills all of (7.3). That would require a finite ambient lift for every lower finite label and every spectator exponent. Qin's general freezing-image construction does not provide this without additional hypotheses. If all ambient lattice theta functions are finite, then all lower ones are finite by freezing and Lambda is a bijection on the whole lattice; in that additional situation (7.2) is onto the entire tensor product (7.3).

The abstract based freezing subalgebra and preservation of surviving coefficients are already in Qin's Lemma 6.10 and its proof. The associated-graded interpretation is a standard reformulation. The contribution being recorded here is the canonical uniform original-chart monomial realization (1.1), its closed F-matrix anchor formula, and the fully integral explicit correspondence (5.1), (6.3) on all minimal outputs.

## 8. A finite exact precomputation

Given an actual mutation sequence to the canonical endpoint, compute the ordinary plus and opposite tall patterns in parallel, starting with [B;I] and [-B;I]. Start F=0. At a step k, using the current plus principal coefficient matrix R and exchange matrix Q, leave all columns except k fixed and set

    F_new(:,k) = -F(:,k)
       + max( [R(:,k)]_+  + F [Q(:,k)]_+,
              [-R(:,k)]_+ + F [-Q(:,k)]_+ ),                   (8.1)

where max is componentwise. Then mutate both tall patterns in direction k. This is the ordinary tropical maximal-degree recurrence for F-matrices; no endpoint F-polynomials must be expanded. At the end obtain P and M from (1.1), and check the exact identities (1.3).

For each finite theta input, mutate its full label along the recorded tall plus matrices, apply M once, and retain the J components as the lower label. For a lower output r, apply (6.3) and reverse the ordinary tropical labels. `canonical_face_toric.py` implements these operations with exact integer arithmetic and never inverts B or Q.

## 9. Primary-source audit and attribution boundary

The following primary statements were read directly, including their proofs where indicated:

* Fujiwara--Gyoda, **Duality between Final-Seed and Initial-Seed Mutations in Cluster Algebras**, arXiv:1808.02156v2 (15 May 2019), Theorem 2.8 equations (2.20)--(2.22), Proposition 2.13, Corollary 2.15, Proposition 4.1, Theorem 4.2, and Corollary 4.5. In particular their signs are exactly C(-B)=C(B)+F(B)B_T and G(-B)=G(B)+BF(B). Their square principal extension is exactly [B,-I;I,0]. Source: https://arxiv.org/html/1808.02156v2 .
* Qin, **Applications of the freezing operators on cluster algebras**, arXiv:2407.03186v1 (3 July 2024), Definition 4.1, Lemma 4.3, Theorem 5.2, Proposition 6.5, Lemma 6.10 and its proof, Theorem 6.18, and Proposition 6.19. Lemma 4.3 already supplies the head-relative support filter and multiplicativity; Theorem 5.2 identifies the frozen theta; Lemma 6.10 already gives the injective based image algebra with surviving coefficients unchanged. Theorem 6.18 is stated in the injective-reachable setting of Section 6.4. Source: https://arxiv.org/html/2407.03186v1 .
* GHKK, **Canonical bases for cluster algebras**, arXiv:1411.1394v2, Theorem 7.5: finite positive multiplication and closure of the finite label set, used in Section 6. Earlier face notes supply the already checked mutation and freezing apparatus.
* Reading--Stella, **Mutation of Theta Functions**, arXiv:2603.19391v4, Sections 2.4 and 2.6 and the supplied primary text: the coefficient-sensitive structure constants, their mutation transport, and the warning about losing coefficient degrees when frozen monomials are dependent are existing machinery. The present formulas retain the full independent principal lattice throughout.
* Qiu--Tang, **X-evolution flows/foliations for cluster algebras: partial Bongartz (co-)completions and acyclicity**, arXiv:2611.09155v1 (6 November 2026), Assumption 1.1, Definition 3.4, Lemma 3.8, Theorem 3.12, and Theorem 5.7 with its proof. This is adjacent recent work on partial completion, evolution supports, and scalar tropical cluster-variable F-invariants, under a standing green-to-red hypothesis. The inspected results do not state a theta face, full toric initial map, or coefficient-level multiplication correspondence. See the separate `QIU_TANG_2026_NOV_NOVELTY_AUDIT.md` for the precise comparison. Source: https://arxiv.org/html/2611.09155v1 .

No claim is made that freezing multiplicativity, the reduced coefficient identity in an already optimized chart, F/C/G identities, or the abstract associated-graded construction is new. The entire canonical boundary transition being one explicit unimodular monomial map is the concrete further interface proved here.
