"""Exact classical toric data for a supplied canonical Bongartz mutation word.

Conventions: tall principal extension E=[B;I], column roots, D*B skew.
Mutation indices and retained/positive index sets are zero based.
The caller supplies an actual word to the canonical endpoint and the sets I,J.
This module does not decide theta finiteness or find the canonical endpoint.
It never inverts B or its endpoint Q.  SymPy is used only for exact matrices.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Sequence
import sympy as sp


def positive(value):
    return max(value, 0)


def _integer_matrix(matrix):
    matrix = sp.Matrix(matrix)
    if any(value.is_Integer is not True for value in matrix):
        raise ValueError("An integral matrix is required")
    return matrix


def _integer_vector(vector):
    vector = _integer_matrix(vector)
    if vector.rows == 0 and vector.cols == 0:
        return sp.zeros(0, 1)
    if vector.cols != 1:
        raise ValueError("A column vector is required")
    return vector


def mutate_tall(exchange, k: int):
    exchange = sp.Matrix(exchange)
    rows, n = exchange.shape
    if not 0 <= k < n:
        raise ValueError("Mutation index is out of range")
    return sp.Matrix(rows, n, lambda i, j:
        -exchange[i, j] if i == k or j == k else
        exchange[i, j] + positive(exchange[i, k]) * exchange[k, j]
        + exchange[i, k] * positive(-exchange[k, j]))


def mutate_theta_label(exchange, label, k: int):
    """Full tropical theta label, including frozen rows."""
    exchange = sp.Matrix(exchange)
    label = sp.Matrix(label)
    if label.shape != (exchange.rows, 1):
        raise ValueError("Label has wrong dimension")
    t = label[k]
    return sp.Matrix([-t if i == k else
        label[i] + positive(exchange[i, k]) * t
        - exchange[i, k] * min(t, 0)
        for i in range(exchange.rows)])


def mutate_root_weight(exchange, beta, k: int):
    exchange = sp.Matrix(exchange)
    beta = sp.Matrix(beta)
    t = beta[k]
    return sp.Matrix([-t if j == k else
        beta[j] + positive(exchange[k, j]) * t
        - exchange[k, j] * min(t, 0)
        for j in range(exchange.cols)])


def mutate_f_matrix(f_matrix, exchange, k: int):
    """Componentwise maximum-degree recurrence, no F-polynomial expansion."""
    exchange, f_matrix = sp.Matrix(exchange), sp.Matrix(f_matrix)
    n = exchange.cols
    if exchange.rows != 2*n or f_matrix.shape != (n, n):
        raise ValueError("Principal tall exchange and square F-matrix required")
    q, r = exchange[:n, :], exchange[n:, :]
    plus = r[:, k].applyfunc(positive) + f_matrix*q[:, k].applyfunc(positive)
    minus = r[:, k].applyfunc(lambda x: positive(-x)) + f_matrix*q[:, k].applyfunc(lambda x: positive(-x))
    out = sp.Matrix(f_matrix)
    out[:, k] = sp.Matrix([max(plus[i], minus[i])-f_matrix[i,k] for i in range(n)])
    return out


def _part(vector, indices):
    return sp.Matrix(len(indices), 1, [vector[i] for i in indices])


def _sub(matrix, rows, cols):
    return matrix.extract(list(rows), list(cols))


@dataclass(frozen=True)
class ToricData:
    B: sp.Matrix
    D: sp.Matrix
    sequence: tuple[int, ...]
    positive_indices: tuple[int, ...]
    retained_indices: tuple[int, ...]
    plus_history: tuple[sp.Matrix, ...]
    C: sp.Matrix
    F: sp.Matrix
    P: sp.Matrix
    M: sp.Matrix

    @property
    def n(self): return self.B.rows
    @property
    def E(self): return self.plus_history[-1]
    @property
    def Q(self): return self.E[:self.n, :]
    @property
    def R(self): return self.E[self.n:, :]
    @property
    def S(self): return _sub(self.C, range(self.n), self.retained_indices)
    @property
    def Q_red(self): return _sub(self.Q, self.retained_indices, self.retained_indices)
    @property
    def D_red(self): return _sub(self.D, self.retained_indices, self.retained_indices)

    def optimized_normal(self, original_root_weight):
        """Validate beta_0=-w in this cone and return all full coordinate weights."""
        beta = sp.Matrix(original_root_weight)
        if beta.shape != (self.n, 1):
            raise ValueError("Root weight has wrong dimension")
        beta_T = self.C.T*beta
        if any(beta_T[i] <= 0 for i in self.positive_indices):
            raise ValueError("The supplied positive directions are not strictly positive")
        if any(beta_T[j] != 0 for j in self.retained_indices):
            raise ValueError("The retained directions do not have weight zero")
        u_0 = sp.zeros(self.n,1).col_join(beta)
        u_T = self.M.T*u_0
        assert u_T == (self.F.T*beta).col_join(beta)
        assert self.E.T*u_T == beta_T
        return {"original_coordinate_weight":u_0, "endpoint_coordinate_weight":u_T,
                "endpoint_root_weight":beta_T}

    def endpoint_head(self, original_label):
        a = _integer_vector(original_label)
        if a.shape != (2*self.n,1):
            raise ValueError("A full original label of length 2n is required")
        for exchange,k in zip(self.plus_history[:-1], self.sequence):
            a = mutate_theta_label(exchange,a,k)
        return a

    def original_head(self, endpoint_label):
        a = _integer_vector(endpoint_label)
        if a.shape != (2*self.n,1):
            raise ValueError("A full endpoint label of length 2n is required")
        for index in reversed(range(len(self.sequence))):
            a = mutate_theta_label(self.plus_history[index+1], a, self.sequence[index])
        return a

    def face_data(self, original_label):
        """Valid as a theta face for finite inputs and the supplied canonical cone."""
        m = _integer_vector(original_label)
        a = self.endpoint_head(m)
        A = self.M*a
        p = A[self.n:, :] - m[self.n:, :]
        assert A[:self.n,:] - m[:self.n,:] == self.B*p
        return {"endpoint_head":a, "anchor":A, "p":p,
                "h":_part(a,self.retained_indices), "S":self.S,
                "Q_red":self.Q_red}

    def split_head(self, endpoint_label):
        a = _integer_vector(endpoint_label)
        c = self.R.inv()*a[self.n:,:]
        I,J = self.positive_indices,self.retained_indices
        aI,aJ,cI,cJ = _part(a,I),_part(a,J),_part(c,I),_part(c,J)
        spectator = (aI-_sub(self.Q,I,J)*cJ).col_join(cI)
        lower = aJ.col_join(cJ)
        return spectator,lower

    def unsplit_head(self, spectator, lower):
        I,J = self.positive_indices,self.retained_indices
        d,r = len(I),len(J)
        spectator,lower = _integer_vector(spectator),_integer_vector(lower)
        if spectator.shape != (2*d,1) or lower.shape != (2*r,1):
            raise ValueError("Split labels have wrong dimensions")
        c,a = sp.zeros(self.n,1),sp.zeros(2*self.n,1)
        for offset,i in enumerate(I): c[i] = spectator[d+offset]
        for offset,j in enumerate(J):
            a[j] = lower[offset]
            c[j] = lower[r+offset]
        aI = spectator[:d,:]+_sub(self.Q,I,J)*lower[r:,:]
        for offset,i in enumerate(I): a[i] = aI[offset]
        a[self.n:,:] = self.R*c
        return a

    def lift_minimal_output(self, original_left, original_right, lower_root_degree):
        """Lift one full lower coefficient index r to its unique ambient label.

        If r has nonzero coefficient in the lower product of the two finite
        inputs, the returned ambient theta is finite and has exactly that
        coefficient in the ambient product.  This function does not calculate
        the lower coefficient or assert its nonvanishing.
        """
        r = _integer_vector(lower_root_degree)
        if r.shape != (len(self.retained_indices),1) or any(v<0 for v in r):
            raise ValueError("A nonnegative retained root vector is required")
        a,b = self.endpoint_head(original_left),self.endpoint_head(original_right)
        c = a+b+_sub(self.E,range(2*self.n),self.retained_indices)*r
        full_label = self.original_head(c)
        h = _part(a,self.retained_indices)+_part(b,self.retained_indices)+self.Q_red*r
        return {"original_label":full_label, "endpoint_head":c,
                "lower_output_label":h.col_join(r), "anchor":self.M*c}


def precompute(B, D: Sequence[int], canonical_sequence: Iterable[int],
               positive_indices: Iterable[int]) -> ToricData:
    """Precompute C(-B), F(B), Q, R, P, M along an authorized canonical word.

    An exact assertion C_J>=0 checks the essential completion condition,
    but canonical reachability and the cone interpretation remain caller input.
    """
    B = _integer_matrix(B)
    if B.rows != B.cols: raise ValueError("B must be square")
    n = B.rows
    D = sp.diag(*D)
    if D.shape != (n,n) or any(v<=0 or v.is_Integer is not True for v in D.diagonal()):
        raise ValueError("D must be a list of positive integral symmetrizer entries")
    if D*B != -(D*B).T: raise ValueError("D does not symmetrize B")
    sequence = tuple(canonical_sequence)
    I = tuple(positive_indices)
    if len(set(I))!=len(I) or any(i<0 or i>=n for i in I):
        raise ValueError("Positive index set is invalid")
    J = tuple(i for i in range(n) if i not in I)
    ep,em = B.col_join(sp.eye(n)),(-B).col_join(sp.eye(n))
    history=[ep]; F=sp.zeros(n)
    for k in sequence:
        F=mutate_f_matrix(F,ep,k)
        ep,em=mutate_tall(ep,k),mutate_tall(em,k)
        history.append(ep)
    C,R,Q=em[n:,:],ep[n:,:],ep[:n,:]
    P=_integer_matrix(D.inv()*C.inv().T*D)
    M=P.row_join(sp.zeros(n)).col_join(F.row_join(sp.eye(n)))
    assert C.det() in (-1,1) and R.det() in (-1,1) and M.det() in (-1,1)
    assert C == R+F*Q
    assert P*Q == B*C
    assert M*ep == B.col_join(sp.eye(n))*C
    assert D*Q == C.T*D*B*C
    assert all(v>=0 for v in F)
    if any(v<0 for v in _sub(C,range(n),J)):
        raise ValueError("C(-B)_J is not nonnegative; this is not the requested completion")
    return ToricData(B,D,sequence,I,J,tuple(history),C,F,P,M)


def _json_matrix(matrix):
    return [list(map(int,matrix.row(i))) for i in range(matrix.rows)]


def demo():
    import json
    # Singular B and a genuinely nonsymmetric symmetrizer; rank reduction to Q_red=0.
    B=[[0,2,0],[-1,0,0],[0,0,0]]
    data=precompute(B,[1,2,3],[1],[1])
    # Endpoint heads of Y_1^2 and V^2, with V=(1+zeta_1)/Y_1.
    left_T=sp.Matrix([2,0,0,0,0,0])
    right_T=sp.Matrix([-2,0,0,0,0,0])
    left,right=data.original_head(left_T),data.original_head(right_T)
    outputs=[]
    for power,coefficient in enumerate([1,2,1]):
        out=data.lift_minimal_output(left,right,[power,0])
        out["coefficient"]=coefficient
        outputs.append({key:_json_matrix(val) if isinstance(val,sp.MatrixBase) else val for key,val in out.items()})
    sample=sp.Matrix([3,-2,5,7,-4,2])
    split=data.split_head(sample)
    assert data.unsplit_head(*split)==sample
    assert data.original_head(data.endpoint_head(sample))==sample
    report={"B":B,"D":[1,2,3],"canonical_sequence_1_based":[2],
        "I_1_based":[2],"J_1_based":[1,3],"C":_json_matrix(data.C),
        "F":_json_matrix(data.F),"M":_json_matrix(data.M),
        "Q_red":_json_matrix(data.Q_red),"S":_json_matrix(data.S),
        "left_original":_json_matrix(left),"right_original":_json_matrix(right),
        "minimal_outputs":outputs,
        "verified":["unimodularity","full root identity","weighted exchange identity",
                    "opposite C/F identity","split inverse","tropical inverse"]}
    print(json.dumps(report,indent=2))


if __name__ == "__main__": demo()
