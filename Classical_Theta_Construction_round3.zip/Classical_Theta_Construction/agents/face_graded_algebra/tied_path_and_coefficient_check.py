"""Exact checks of the concrete risks in the toric face theorem; not proof premises."""
import json
from pathlib import Path
import sympy as s
from canonical_face_toric import precompute, mutate_tall, mutate_root_weight


def monomial(coords, powers):
    out=s.Integer(1)
    for x,p in zip(coords,powers): out*=x**p
    return out


def transport(B,path,beta,initial_only=False):
    n=len(B)
    E=s.Matrix(B).col_join(s.eye(n))
    base=list(s.symbols('x1:'+str(n+1)))+list(s.symbols('y1:'+str(n+1)))
    X=base.copy(); beta=s.Matrix(beta); trace=[]
    for k in path:
        plus=monomial(X,[max(v,0) for v in E[:,k]])
        minus=monomial(X,[max(-v,0) for v in E[:,k]])
        val=beta[k]
        chosen=plus+minus if not initial_only or val==0 else (minus if val>0 else plus)
        X[k]=s.factor(chosen/X[k])
        trace.append({'k':k+1,'root_valuation':int(val),'new_coordinate':str(X[k])})
        beta=mutate_root_weight(E,beta,k)
        E=mutate_tall(E,k)
    return base,X,E,beta,trace

B=[[0,2,0],[-1,0,0],[0,0,0]]
long_path=[0,1,0,1,0]
short_path=[1]
base,actual,E,beta,trace=transport(B,long_path,[1,-1,0],False)
_,short_actual,shortE,_,_=transport(B,short_path,[1,-1,0],False)
assert E==shortE
assert all(s.cancel(a-b)==0 for a,b in zip(actual,short_actual))
_,initial,_,_,initial_trace=transport(B,long_path,[1,-1,0],True)
long_data=precompute(B,[1,2,3],long_path,[1])
short_data=precompute(B,[1,2,3],short_path,[1])
assert long_data.M==short_data.M
assert long_data.F==short_data.F
assert long_data.C==short_data.C
predicted=[monomial(base,long_data.M[:,j]) for j in range(6)]
assert all(s.cancel(a-b)==0 for a,b in zip(initial,predicted))
assert sum(row['root_valuation']==0 for row in initial_trace)==2

x1,x2,x3,y1,y2,y3=base
Y1,Y2,Y3=short_actual[:3]
V=s.factor((1+y1*Y2)/Y1)
product=s.expand(Y1**2*V**2)
ambient_decomposition=1+2*y1*Y2+y1**2*Y2**2
assert s.cancel(product-ambient_decomposition)==0
face=(1+y1*y2*x1**2/x2)**2
assert s.cancel(face-(1+monomial(base,s.Matrix(B).col_join(s.eye(3))*s.Matrix([1,1,0])))**2)==0

# Positive-direction mutation: exactly one of the two output heads is minimal.
a=short_data.endpoint_head(s.Matrix([0,-1,0,0,0,0]))  # Y2's normalized original label
b=short_data.endpoint_head(s.Matrix([0,1,0,0,0,0]))   # original x2
assert a==s.Matrix([0,1,0,0,0,0])
assert b==s.Matrix([2,-1,0,0,1,0])
assert a+b+short_data.E[:,1]==s.zeros(6,1)
assert s.cancel(Y2*x2-(x1*x1*y2+1))==0

report={
 'B':B,'D':[1,2,3],
 'short_path_1_based':[2],'long_path_1_based':[1,2,1,2,1],
 'initial_root_weight':[1,-1,0], 'final_root_weight':list(map(int,beta)),
 'initial_transition_trace':initial_trace,
 'final_initial_coordinates':[str(v) for v in initial],
 'coefficient_example':{'V':str(V),'ambient_product':'1 + 2*y1*Y2 + y1^2*Y2^2',
    'face':str(s.expand(face)),'reduced_coefficients':[1,2,1]},
 'positive_direction_example':{'product':'Y2*x2 = x1^2*y2 + 1',
    'minimal_output':'x1^2*y2','higher_output':'1','root_degrees':[[0,0,0],[0,1,0]]},
 'verified':['nontrivial five-step path equals one-step canonical endpoint',
    'two tied binomial steps collapse to the asserted monomial transition',
    'same full M, F, C for both paths','singular B','nontrivial D',
    'individual coefficients 1,2,1 with coincident reduced mutable labels',
    'positive-direction root degree is excluded from minimal outputs']}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
