# Independent review of the finite-word support certificate

2026-11-14, reviewed by `face_graded_algebra`. Scope: the polyhedral implementation in `../support_accessibility_fresh/zero_endpoint_support_certificate.py`, the exhaustion argument in Sections 7--8 of `ZERO_ENDPOINT_Q_MUTATION_AND_SUPPORT_CERTIFICATES.md`, and the call to `IncomingSchur.theta_prefix`. This does **not** re-audit the general analytic Q-length theorem or the already audited coefficient recursion.

## Conclusion

**A successfully returned bounded certificate is sound, conditional on the established zero-endpoint coefficient reflection and coefficient oracle.** I found no missing min branch, dropped prefix condition, incorrect dual sign, or circular use of theta finiteness in the stopping argument. One small runtime defect was reproduced for an empty set of nonempty mutation words. The author has now fixed it by adding the known feasible origin to the initial branch, and I independently confirmed the corrected return value and exact orthant ray for both empty-word inputs.

## 1. Min branches and all prefixes

At a prefix `word=parent+(k,)`, the code reads `branch['degrees'][parent]`, not the most recently visited word. Matrix/framing data depend only on the word and are stored separately. Thus breadth-first processing correctly intersects the necessary conditions from different words while preserving each word's own degree evolution.

The affine branch constraints are exactly

    chosen <= other,          chosen - old_P[k] >= 0.

Both choices are retained when the affine expressions differ. Their weak comparison halfspaces cover all real parameter points, including the equality boundary. Identical expressions need only one branch. Any duplicated boundary representation gives the same numerical degree at that point, so subsequent splits still agree pointwise. All other degrees are inherited unchanged from the parent and were already constrained nonnegative. Initial degrees are nonnegative because the LP variables lie in the nonnegative orthant and r>=0.

`prefixes` explicitly inserts every prefix of every supplied word. Normalization divides an integral inequality by a positive gcd; it drops only tautological zero-row inequalities and retains `0 <= -1`. It therefore preserves every branch.

## 2. Exact feasibility and bounds

For a branch `q>=0, A q<=b`, a discard certificate satisfies

    u>=0,        A^T u>=0,        b^T u<0.

These are the correct Farkas signs: a feasible q would imply `0 <= (A^T u).q <= b^T u < 0`. The code recomputes these quantities exactly after obtaining the candidate multipliers.

A coordinate bound uses

    u>=0,        A^T u>=e_i,      q_i <= b^T u.

Again the signs are correct. The `lp` wrapper checks multiplier nonnegativity, all dual constraints, and the exact objective equality; `coordinate_bound` recomputes the combined left side. Thus a returned feasible dual gives a valid upper bound even if the backend's claimed optimum were not optimal. Taking the maximum over all retained branches and then the floor gives a valid integer box for their union.

An unbounded coordinate is accompanied by a feasible branch point and a ray `v>=0, A v<=0, v_i>=1`. The same wrapper verifies the ray constraints exactly. This proves only failure of the supplied word set, as the code correctly reports.

The fallback enumeration is mathematically complete for the polyhedra it receives. Any nonempty polyhedron inside the nonnegative orthant has a vertex: minimize the coordinate sum on a bounded sublevel and take a vertex of its compact optimal face. A vertex has n independent active inequalities, including orthant inequalities. Every nonzero recession direction can be normalized by `sum(v)=1`; this gives a compact polytope, whose vertices are found by the enumeration of n-1 active homogeneous rows plus the normalization. A descending ray exists exactly when one such vertex has negative objective. Backend exceptions can cause operational failure, but the certificate checks prevent accepting an invalid successful bound or discard.

## 3. Empty branches and exhaustion

If every branch becomes infeasible, breaking early is sound: further prefix conditions can only shrink the empty intersection. Reporting a bounded empty union is valid for a divided derivative that is identically zero. In the full-theta case p=0 survives every correct degree reflection, so an empty union cannot occur mathematically; the complete-output membership check would also reject it when the constant coefficient one is computed.

Once the union is bounded, `theta_prefix(g, integer_box)` iterates the entire finite coordinate box. Its coefficient dependencies are downward intervals within that box, so no unknown coefficient outside it is needed. The code then keeps every nonzero coefficient and verifies membership in the branch union. Every omitted exponent outside the box is ruled out by the necessary mutation inequalities and the verified dual bounds. No inference is made from a long run of zeros, and theta finiteness is a conclusion of the certificate, not an input to this stage.

## 4. Reproduced edge defect and exact fix

For positive rank, both `words=[]` and `words=[[]]` leave the initial branch without a `point` entry. `coordinate_bound` correctly finds an orthant ray, but the unbounded-result constructor then reads the missing `branch['point']`.

Initialize the branch with the known feasible origin:

    branches = [{'rows': (), 'degrees': {(): P},
                 'point': [sp.Integer(0)] * n}]

The author applied this exact fix. I inspected the updated source and independently reran `words=[]` and `words=[[]]`; both correctly return “not certified by supplied words” with origin point and standard-basis recession ray. The author's broader receipt is `../support_accessibility_fresh/zero_endpoint_empty_words_receipt.json`. No change to the mathematical branch construction was required. I did not modify the author's files.

## 5. Independent arithmetic receipt

`audit_support_receipt.py` is an LP-free verifier of stored rational dual/Farkas arithmetic, prefix closure, the global integer-box calculation, and output exponent bookkeeping. On the existing complete Laurent receipt it verified all 96 coordinate dual certificates for 32 branches, the integer box [2,2,3], and all 18 reported output exponent records. The receipt is `support_receipt_independent_arithmetic.json`. This check does not independently recompute theta coefficients and is not a substitute for the branch-coverage proof above.
