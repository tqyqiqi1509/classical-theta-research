# A finite Laurent algorithm from adjacent divisibility and Newton envelopes

Status: constructive combination developed in this run. The parent independently checked the mutation signs and simplified the integer search to exact rational linear algebra. A fresh reviewer independently confirmed the leading-term argument and the semidecision strengthening; its separate note records the detailed audit of the 2026 valuative-independence input. This note does not claim that adjacent Laurentness alone characterizes theta functions. The novelty comparison in Section 6 includes the close 2026 Fei interface and the old package's divisibility matrices.

## 1. Scope and the structural hypothesis

Fix a classical skew-symmetrizable exchange matrix B of size r by r, and work with principal coefficients y_1,...,y_r, inverted frozen variables, and characteristic zero. Put

    z_j=y_j product_i x_i^(B_ij),
    theta_g=x^g F_g(z).

Assume that the upper cluster algebra equals the middle cluster algebra (over Q is sufficient), so every upper-cluster element has a FINITE expansion in regular theta functions. More generally, the argument applies to a particular candidate f whenever a separate certificate gives f a finite theta expansion; equality of the two entire algebras is a convenient sufficient condition.

The input label g is an arbitrary integral vector. Under the global middle=upper hypothesis the search halts if and only if g belongs to the regular theta set Theta, and in that event computes its complete Laurent polynomial. It is therefore a semidecision algorithm for the regular label set, not a decision algorithm. No reddening word, injective support-dimension vector, known theta support, or positive product carrier is supplied to the algorithm.

The principal extended exchange matrix (B;I_r) has full column rank. BFZ, *Cluster algebras III*, Corollary 1.7 and Proposition 1.8, therefore identify the upper cluster algebra with the finite intersection of the initial Laurent ring and its r adjacent Laurent rings. This uses inverted frozen coefficients as in BFZ.

## 2. Completely explicit integer slice equations

Let P(z)=sum_p c_p z^p be a polynomial with rational or integer coefficients. Consider f=x^g P(z). Fix a mutable index i and a vector pbar=(p_j)_(j!=i). Define

    R_(i,pbar)(t)=sum_(p_i>=0) c_(pbar,p_i) t^(p_i),
    u_(i,pbar)=g_i+sum_(j!=i) B_ij p_j,
    k_(i,pbar)=max(0,-u_(i,pbar)).

Then f is Laurent in the seed obtained by mutating i if and only if, for every pbar,

    (1+t)^k_(i,pbar) divides R_(i,pbar)(t).                    (D)

Proof. The exchange relation is

    x_i x_i' = product_(j!=i) x_j^[-B_ji]_+ * (1+z_i).

The variable z_i is independent of x_i, since B_ii=0. In a fixed pbar slice, the exponent of x_i is u_(i,pbar). Substitution produces the factor (1+z_i)^u R_(i,pbar)(z_i), multiplied by a Laurent monomial. All other frozen variables retain their distinct exponent vector pbar, so different slices cannot cancel each other's denominator. Laurentness is therefore exactly (D). Divisibility in the Laurent ring Q[t,t^-1] is equivalent here to divisibility in Q[t], since (1+t)^k has nonzero constant term and R is a polynomial.

For an explicit root box J=[0,N]^r, (D) is the finite linear system

    sum_(j=s)^N (-1)^(j-s) binom(j,s)c_(pbar,j)=0,
                 0<=s<min(k_(i,pbar),N+1).                  (E)

These are ordinary integer binomial coefficients. When k>N, the first N+1 derivative equations force the whole slice to be zero, as required.

Taking (E) for all i and all pbar makes f Laurent in all adjacent charts. By the BFZ finite-upper-bound theorem, f belongs to the upper cluster algebra.

## 3. A signed finite candidate bounds theta_g

Suppose a candidate P satisfying (E) has nonzero constant term c_0=m. Under the structural hypothesis in Section 1, f=x^gP has a finite theta expansion. Its homogeneity for the principal coefficient torus forces the expansion to have the shape

    f=sum_(q in a finite subset of Z^r) b_q y^q theta_(g+Bq).

Every theta summand has leading full monomial x^g z^q and all remaining monomials have root degrees q+N^r. If any q outside N^r had nonzero coefficient, choose a minimal such q among the finite summand set in the positive-root partial order. Its leading monomial could not be cancelled by another summand, contradicting the polynomial support of P. Thus every q is nonnegative. Comparing degree zero gives

    b_0=m !=0.

Since the expansion consists of regular theta basis elements, this also proves that g is a regular theta label. Thus regularity need not be supplied as an oracle before the search. With the more local hypothesis of a separately certified finite theta expansion of this candidate, the same conclusion follows for this candidate.

The Valuative Independence Theorem of Cheung–Magee–Mandel–Muller, Theorem 3.8 in arXiv:2505.09585v2, applies to this FINITE theta expansion. In particular, for every seed monomial valuation v,

    val_v(f)=min_(b_q!=0) val_v(y^q theta_(g+Bq))
            <=val_v(theta_g).

All functions in this minimum are finite Laurent polynomials, so the finiteness premise in that theorem is satisfied. Varying v gives the Newton inclusion

    Newt(theta_g) subseteq Newt(f).

Equivalently, using frozen-coordinate valuations to identify the principal root affine space,

    Newt(F_g) subseteq Newt(P),
    supp(F_g) subseteq Newt(P) intersect N^r.                 (N)

Crucially, P may have negative coefficients. Neither cluster positivity nor theta positivity of the candidate is assumed. Cancellation is controlled by valuative independence, not by an unproved positivity assertion for arbitrary regular functions.

## 4. Terminating construction

For N=0,1,2,... perform these finite steps:

1. Form (E) for the unknown coefficients c_p, p in [0,N]^r, and append c_0=1 over Q.
2. Solve the finite rational linear system exactly. If inconsistent, increase N.
3. If consistent, choose any rational solution and clear its denominators, producing an integer P with c_0=m>0.
4. Compute the finite Newton polytope Q=Newt(P). Evaluate the prescribed-degree theta coefficient algorithm on Q intersect N^r, or simply on its enclosing finite box.
5. Return x^g sum_p a_g(p)z^p.

The support inclusion (N) proves completeness of the returned Laurent polynomial. Empirical stabilization of successive prefixes is not used as a stopping rule.

Why the search halts for every regular label: theta_g itself is finite and belongs to the upper algebra. For sufficiently large N, P=F_g is a solution of (E) with c_0=1. Thus a consistent box must eventually be encountered. Conversely, under the global structural hypothesis, any found candidate forces g to be regular by Section 3. The search need not choose F_g; any signed candidate in the first successful box gives a valid support envelope.

The exact rational step is enough. An integer solution with c_0=1 is not required, so there is no need for a Smith-normal-form Diophantine search. The leading coefficient m after denominator clearing still guarantees that theta_g occurs with nonzero coefficient, which is all that the Newton argument uses.

## 5. What this accomplishes and what it does not assume

This gives a complete finite Laurent algorithm for every regular theta label in any classical principal-coefficient class for which middle equals upper has been established. It requires no effective prior support bound and no effective reddening sequence. Its input-side operations are integer binomial constraints, exact linear algebra, a finite convex hull, and the previously supplied finite coefficient rule.

The argument does not prove that all classical seeds have middle equal to upper. It is not a decision procedure for membership in Theta: under the stated equality, a label outside Theta makes the unbounded search continue forever. Reaching a user-imposed radius cap is explicitly inconclusive. Nor does the argument allow arbitrary finite upper-cluster candidates to be used when middle differs from upper; their formal theta expansions may be infinite, and the finite-valuative argument would then be unavailable.

The method does not claim that theta_g is uniquely characterized by the support envelope or adjacent divisibility. Many elements can have the same Newton polytope. The finite coefficient rule remains the final step selecting theta_g.

## 6. Relation to greedy divisibility, Fei, and the previous package

The row divisibility conditions are the direct higher-rank form of the adjacent Laurent conditions underlying rank-two greedy constructions. They are established cluster algebra algebra, not a newly invented mutation law. The new constructive combination is: arbitrary signed adjacent-Laurent carrier + a finite theta expansion + valuative independence yields a support certificate, making the prescribed-degree formula into a terminating complete-Laurent algorithm on the stated domain.

In fact, the prior package already contains the entire binomial-moment matrix mechanism in `agents/degree_finiteness_audit.md`, Sections 5 and 6. That note correctly says that membership in a pointed finite kernel does not by itself certify a theta function or bound full root support. The present addition fills exactly that interface under the extra finite-theta-span hypothesis, using valuative independence. The matrix itself must not be counted as new in this run.

The old package's positive cluster-product and injective-product envelopes use coefficientwise domination. The present envelope need not be such a product and need not be positive. It therefore uses a different certificate mechanism. It can find a support bound without exhibiting the label as a nonnegative rational combination of supplied cluster g-vectors.

Fei's Newton reconstruction and face-reduction perspective motivates treating a polytope as usable data rather than as a decorative picture. No Fei theorem equating theta and a generic character is assumed. No Li–Pan conclusion is used.

There is a close 2026 comparison that must be disclosed. Fei, *Laurent phenomenon algebras on minuscule Grassmannians and their mirrors*, Hexagon 2611.00328v1, Corollary 9.3, describes finite theta recognition using a known bounded Newton region and adjacent Laurent divisibility. Section 5.1 obtains support inequalities from regular source functions. This is outside the present classical generality and is not a proof input here; nevertheless it precludes calling the general combination of valuative independence, Newton bounds, and divisibility new. The additional step isolated here is to search for ANY signed pointed finite regular function, which itself yields the needed Newton envelope, without a preexisting coercive source-function system or a one-dimensional recognition space. Fei's reference [7], *Theta functions and intrinsic mirrors of Laurent phenomenon algebras*, is listed only as a manuscript. Exact-title searches in two engines located the citation but no public companion text as of 2026-11-13 18:02 UTC. Priority relative to that unavailable manuscript remains unassessed.

## 7. Implementation and verification

`finite_envelope.py` implements (E) using FLINT exact rational RREF. It verifies every returned integer candidate against every binomial slice equation. Its 12 runs include rank-two symmetric and valued data, rank-three acyclic and valued acyclic data, and a mutation-acyclic oriented triangle. In half the runs a negative free coefficient was deliberately selected; the signed candidate still satisfies every exact adjacent-Laurent constraint. These tests verify the finite solver and sign conventions; they do not algorithmically certify middle=upper.

The `construct_theta` entry point takes only B, D, g and a search cap, together with the explicit mathematical finite-span premise. After finding a candidate it computes coordinatewise support maxima, calls the previous package's exact `IncomingSchur` procedure on that finite box, and returns the complete theta terms together with the envelope and the proof premise. It checks the final polynomial against ALL adjacent divisibility equations again, as well as nonnegative integral coefficients and constant coefficient one. All 12 complete runs pass; the resulting term counts are 4,4,8,8,7,7,14,14,10,10,3,3. Results are in `complete_laurent_envelope_checks.json`. These checks supplement the mathematical support certificate; they are not used as a substitute for it.

Primary sources:
- BFZ, arXiv:math/0305434v3, Corollary 1.7, Proposition 1.8; original proofs inspected for the full-rank/copimality implication.
- CMMM, arXiv:2505.09585v2 (21 May 2026), Theorems 3.5, 3.7, 3.8. A separate fresh branch is auditing this input. The proof chain used here precedes and does not invoke the later Li–Pan-dependent remarks.
- Fei, arXiv:1909.10151v3, Theorems 3.4 and 6.8, used as methodological comparison only.
