"""Finite adjacent-Laurent envelopes; exact rational linear algebra only.

Mathematical use of a found envelope as a theta support certificate requires
mid=up (or a separate finite-theta-expansion certificate) and valuative
independence. The solver itself makes no unverified structural declaration.
"""
from itertools import product, count
from math import comb, gcd, lcm
from functools import reduce
from pathlib import Path
import json, time, sys
from flint import fmpq_mat


def box(cap):
    return sorted(product(*(range(k+1) for k in cap)), key=lambda p:(sum(p),p))


def divisibility_rows(B,g,cap):
    """Derivative/binomial conditions at t=-1 for every adjacent slice."""
    n=len(g); J=box(cap); index={p:i for i,p in enumerate(J)}; rows=[]
    for i in range(n):
        rest=[j for j in range(n) if j!=i]
        for pb in product(*(range(cap[j]+1) for j in rest)):
            p=[0]*n
            for j,v in zip(rest,pb): p[j]=v
            exponent=g[i]+sum(B[i][j]*p[j] for j in rest)
            required=max(0,-exponent)
            for s in range(min(required,cap[i]+1)):
                row=[0]*len(J)
                for u in range(s,cap[i]+1):
                    p[i]=u
                    row[index[tuple(p)]]=(-1)**(u-s)*comb(u,s)
                rows.append(row)
    return J,rows


def envelope_at_box(B,g,cap,negative_free=False):
    J,A=divisibility_rows(B,g,cap); d=len(J)
    # c_0=1 over Q is harmless: clear denominators after solving.
    rows=[row+[0] for row in A]+[[1]+[0]*(d-1)+[1]]
    R,rank=fmpq_mat(rows).rref()
    pivots=[]
    for i in range(rank):
        pivot=next((j for j in range(d+1) if R[i,j]),None)
        if pivot==d:return None
        pivots.append((i,pivot))
    free=[j for j in range(d) if j not in {p for _,p in pivots}]
    values=[R[0,0]*0 for _ in J]
    if negative_free and free: values[free[0]]=-1
    for i,p in pivots:
        values[p]=R[i,d]-sum(R[i,j]*values[j] for j in free)
    den=1
    for v in values: den=lcm(den,int(v.denominator))
    ints=[int(v*den) for v in values]
    common=reduce(gcd,(abs(v) for v in ints if v),0)
    ints=[v//common for v in ints]
    assert ints[0]>0
    assert all(sum(a*c for a,c in zip(row,ints))==0 for row in A)
    return {'cap':list(cap),'unknowns':d,'equations':len(A),
            'rational_solution_dimension':len(free), 'leading_coefficient':ints[0],
            'terms':[[list(p),v] for p,v in zip(J,ints) if v],
            'negative_coefficients':sum(v<0 for v in ints),
            'structural_condition':'mid=up or independently certified finite theta expansion'}


def find_envelope(B,g,max_radius=12,negative_free=False):
    """Search root boxes; max_radius=None gives the unbounded semidecision."""
    failures=[]
    radii=count() if max_radius is None else range(max_radius+1)
    for radius in radii:
        out=envelope_at_box(B,g,(radius,)*len(g),negative_free)
        if out is not None:
            out['failed_smaller_radii']=failures
            return out
        failures.append(radius)
    return {'status':'search_bound_reached','radii':failures}


def construct_theta(B,D,g,max_radius=12,negative_free=False,finite_theta_span=False):
    """Return a complete theta polynomial under an explicitly supplied premise.

    finite_theta_span=True means the caller has established mid=up or has an
    independent finite-theta-expansion certificate for the selected envelope.
    It is a mathematical premise, not something inferred from the slice test.
    Under global mid=up, success also certifies regularity of the input label.
    max_radius=None is the mathematical unbounded search; a finite cap is only
    a computational resource limit and its failure says nothing about regularity.
    """
    if not finite_theta_span:
        raise ValueError('A proved finite-theta-span premise is required for this envelope route.')
    n=len(g)
    if not n or len(B)!=n or any(len(row)!=n for row in B) or len(D)!=n:
        raise ValueError('B must be square with the same positive size as D and g.')
    if any(not isinstance(v,int) for row in B for v in row) or any(not isinstance(v,int) for v in g):
        raise ValueError('B and g must be integral.')
    if any(not isinstance(d,int) or d<=0 for d in D):
        raise ValueError('D must be a positive integral symmetrizer.')
    if any(D[i]*B[i][j]!=-D[j]*B[j][i] for i in range(n) for j in range(n)):
        raise ValueError('DB must be skew-symmetric.')
    env=find_envelope(B,g,max_radius,negative_free)
    if 'cap' not in env:return env
    support_cap=tuple(max(p[i] for p,_ in env['terms']) for i in range(len(g)))
    root=Path(__file__).resolve().parents[2]
    old=root/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
    if str(old) not in sys.path:sys.path.insert(0,str(old))
    from incoming_recursion import IncomingSchur
    F=IncomingSchur(B,D).theta_prefix(tuple(g),support_cap)
    J,A=divisibility_rows(B,g,support_cap)
    c=[F.get(p,0) for p in J]
    assert c[0]==1 and all(v>=0 for v in c)
    assert all(sum(a*v for a,v in zip(row,c))==0 for row in A)
    full_terms=[{'mutable_exponents':[g[i]+sum(B[i][j]*p[j] for j in range(n)) for i in range(n)],
                 'frozen_exponents':list(p),'coefficient':v} for p,v in F.items()]
    return {'status':'complete under stated premise','envelope':env,
            'proof_premise':'middle equals upper over Q, or an independent finite theta expansion certificate for the returned envelope; finite valuative independence',
            'regular_label_under_stated_premise':True,
            'B':B,'D':D,'g':g,
            'certified_support_box':list(support_cap),
            'theta_terms':[[list(p),v] for p,v in F.items()],
            'laurent_terms':full_terms,
            'theta_term_count':len(F)}


def check_demo():
    start=time.time(); outputs=[]
    cases=[
      ([[0,3],[-3,0]],[-1,1],5),
      ([[0,3],[-3,0]],[-2,2],6),
      ([[0,3],[-2,0]],[-2,1],6),
      ([[0,1,0],[-1,0,1],[0,-1,0]],[-1,-1,-1],5),
      ([[0,2,1],[-1,0,1],[-1,-2,0]],[-1,0,-1],5),
      ([[0,1,-1],[-1,0,1],[1,-1,0]],[-1,0,0],5),
    ]
    for B,g,limit in cases:
        for negative in [False,True]:
            out=find_envelope(B,g,limit,negative)
            outputs.append({'B':B,'g':g,'negative_free_choice':negative,**out})
    result={'status':'PASS','cases':len(outputs),'seconds':time.time()-start,
            'note':'Every returned candidate was checked against all exact binomial slice equations. Structural hypotheses are mathematical inputs, not inferred by the solver.',
            'results':outputs}
    Path(__file__).with_name('finite_envelope_checks.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'status':result['status'],'cases':len(outputs),'seconds':result['seconds'],
                      'radii':[o.get('cap') for o in outputs],
                      'negative_counts':[o.get('negative_coefficients') for o in outputs]}))

if __name__=='__main__': check_demo()
