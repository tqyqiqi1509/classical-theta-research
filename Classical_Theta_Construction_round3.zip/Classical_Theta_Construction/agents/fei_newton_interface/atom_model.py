"""Exact finite-cutoff stable-atom and top-coefficient verification."""
from fractions import Fraction
from math import factorial
from itertools import product
from pathlib import Path
import json,random,time

ROOT=Path(__file__).resolve().parents[2]

def box(cap):return sorted(product(*(range(k+1) for k in cap)),key=lambda p:(sum(p),p))
def le(a,b):return all(x<=y for x,y in zip(a,b))
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def mul(A,B,cap):
    C={}
    for p,v in A.items():
        for q,w in B.items():
            t=tuple(x+y for x,y in zip(p,q))
            if le(t,cap):C[t]=C.get(t,0)+v*w
    return {p:v for p,v in C.items() if v}

def atom_model(H,cap):
    J=box(cap);zero=J[0];degree={zero:0};atoms=[]
    for p in J[1:]:
        lengths=[degree[sub(p,a)]+1 for a in atoms if le(a,p) and sub(p,a) in degree]
        if lengths:degree[p]=max(lengths)
        elif H.get(p,0):
            assert H[p]>0,('negative atom',p,H[p])
            atoms.append(p);degree[p]=1
    # Independently compute every polynomial coefficient via log H.
    U={p:Fraction(v) for p,v in H.items() if p!=zero}; L={}; power={zero:Fraction(1)}
    for k in range(1,sum(cap)+1):
        power=mul(power,U,cap)
        for p,v in power.items():L[p]=L.get(p,0)+Fraction((-1)**(k+1),k)*v
    L={p:v for p,v in L.items() if v}
    allpowers={zero:Fraction(1)}; atompowers={zero:Fraction(1)}
    atomseries={a:Fraction(H[a]) for a in atoms}; exact_degree={zero:0};exact_lead={zero:Fraction(1)}
    predicted={zero:Fraction(1)}
    for k in range(1,sum(cap)+1):
        allpowers=mul(allpowers,L,cap);atompowers=mul(atompowers,atomseries,cap)
        for p,v in allpowers.items():
            exact_degree[p]=k;exact_lead[p]=v/factorial(k)
        for p,v in atompowers.items():
            if degree.get(p)==k:predicted[p]=v/factorial(k)
    assert exact_degree==degree,('degree mismatch',exact_degree,degree)
    assert all(exact_lead[p]==predicted[p]>0 for p in degree)
    return {'atoms':[[list(a),H[a]] for a in atoms],
            'eventual_support_size':len(degree),'checked_coefficients':len(J),
            'degrees_and_leads':[[list(p),degree[p],str(predicted[p])] for p in J if p in degree]}

def main():
    start=time.time();src=json.loads((ROOT/'computation/stable_root_results.json').read_text());out=[]
    for ex in src['examples']:
        H={tuple(p):v for p,v in ex['stable_root_terms']}
        out.append({'B':ex['B'],'D':ex['D'],'g':ex['g'],'cap':ex['cap'],**atom_model(H,ex['cap'])})
    rng=random.Random(26061114)
    for _ in range(60):
        cap=(4,4,4);J=box(cap);zero=J[0]
        # Chosen generators are provably indecomposable; signed composite terms
        # test the covering/leading-degree mechanism independently of theta code.
        atoms=[(1,0,0),(1,1,0),(0,0,2)];H={zero:1}
        for a in atoms:H[a]=rng.randint(1,4)
        for p in J[1:]:
            if p in atoms:continue
            if p[0]>=p[1] and p[2]%2==0 and rng.random()<.35:
                v=rng.randint(-5,5)
                if v:H[p]=v
        result=atom_model(H,cap)
        out.append({'input':'synthetic signed series with positive atoms','cap':cap,**result})
    report={'status':'PASS','cases':len(out),'coefficient_checks':sum(v['checked_coefficients'] for v in out),
            'seconds':time.time()-start,'results':out}
    Path(__file__).with_name('atom_model_checks.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='results'}))

if __name__=='__main__':main()
