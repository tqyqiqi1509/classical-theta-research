# Complete symmetric theta rays and the band construction

This note compares the parent's family

    H_(n,g)=[T^n] exp(sum_(k>=1) theta_(kg) T^k/k)

with the surface band family. It is a comparison of a general algebraic construction, not a claim that all theta labels come from surfaces. The general integrality and theta positivity of H are proved in the parent's Gauss/pre-lambda notes. No 2026 band=triangular theorem is used below.

## 1. One trace ray

For two commuting formal eigenvalues alpha,beta, put a=alpha+beta and kappa=alpha*beta. Define

    T_k(a;kappa)=alpha^k+beta^k,
    U_n(a;kappa)=sum_(i=0)^n alpha^(n-i)beta^i.

These are the usual normalized first- and second-kind Chebyshev families. Both satisfy the recurrence V_n=aV_(n-1)-kappa V_(n-2), with T_0=2,T_1=a and U_0=1,U_1=a. The identity

    exp(sum_(k>=1) T_k(a;kappa)T^k/k)
       =1/((1-alpha*T)(1-beta*T))
       =sum_(n>=0) U_n(a;kappa)T^n

proves that H agrees with the band polynomial on a single bracelet trace ray. For a simple arc, theta_(kg)=theta_g^k, so the same exponential gives H_(n,g)=theta_g^n.

For unpunctured surface cluster algebras, the existing bracelet=theta identification makes the trace-ray description applicable. Mandel–Qin, arXiv:2301.11101v3, Theorem 1.1, identifies weighted simple multicurve bracelets with theta functions; the loop components are first-kind Chebyshev polynomials. This is an established theorem, not a new property in the present run.

## 2. Two independent compatible trace rays

Let X={alpha,beta}, Y={gamma,delta}, with a=alpha+beta, b=gamma+delta, kappa_1=alpha*beta and kappa_2=gamma*delta. Suppose

    theta_(kg)=T_k(a;kappa_1) T_k(b;kappa_2).

For example, this is the bracelet ray of two disjoint non-homotopic simple loops, with the coefficient normalization understood. Then

    H_(n,g)=h_n(XY),

where XY consists of the four products alpha*gamma, alpha*delta, beta*gamma, beta*delta. The Cauchy identity gives the exact formula

    H_(n,g)=sum_(j=0)^floor(n/2)
                (kappa_1*kappa_2)^j
                U_(n-2j)(a;kappa_1) U_(n-2j)(b;kappa_2).       (C)

Indeed, h_n(XY)=sum_(lambda partition n) s_lambda(X)s_lambda(Y). Only partitions lambda=(n-j,j) survive in two variables, and s_(n-j,j)(X)=kappa_1^j U_(n-2j)(a;kappa_1).

By contrast, the ordinary band attached to the multicurve with both component weights n is U_n(a;kappa_1)U_n(b;kappa_2). Consequently

    H_(2,g)=U_2(a;kappa_1)U_2(b;kappa_2)+kappa_1*kappa_2.

In the coefficient-free normalization kappa_1=kappa_2=1, the difference is exactly 1. Thus the global family H should not be called the band basis on arbitrary labels. It extends the single-loop formula but changes how compatible components are combined. Formula (C) gives a positive band expansion, rather than merely showing that the families differ.

## 3. General compatible products and the boundary of the analogy

If g=g_1+...+g_s satisfies theta_(kg)=product_i theta_(kg_i) for every positive k, then the power-sum sequences are multiplied pointwise. In the standard big-Witt description this is the product of the corresponding complete-symmetric series. For several trace components, ordinary Schur functor decompositions of a tensor product produce the resulting band coefficients. This is standard symmetric-function algebra applied to the theta ray; it is not claimed as a new symmetric-function identity.

The comparison does not justify arbitrary Schur positivity for general theta rays. Other branches of this project already found an elementary symmetric specialization with a negative theta coefficient. The positive complete-symmetric family is a pre-lambda structure, and multiplicativity of all Adams operations is not assumed.

## 4. Sources and audit boundary

- Mandel–Qin, *Bracelets bases are theta bases*, arXiv:2301.11101v3, Theorem 1.1 and the definition of bracelets in the introduction and Section 4.2. Primary PDF: https://arxiv.org/pdf/2301.11101v3 . Used only for the surface realization of the trace formulas.
- Qin–Shen, *Band Bases as Common Triangular Bases in Cluster Algebras from Surfaces*, arXiv:2606.02164v2. The local source is in `agents/finite_laurent/sources/`. Definition 2.3 was read to check the componentwise band convention. The 2026 main theorem was not fully audited by this branch and is not a premise of (C).
- The identities above are proved directly in the formal eigenvalue ring, so they remain valid independently of the 2026 paper.
