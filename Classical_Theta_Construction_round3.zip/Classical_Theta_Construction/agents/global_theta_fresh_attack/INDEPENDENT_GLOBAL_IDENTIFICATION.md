# Independent reconstruction of the cyclic Gale–theta identification

Date: 2026-11-13, 23:16 UTC. Classical cluster algebras only.

This review reads the original arguments, including the inherited one-frame and flow-tree interface. It does not infer a theorem from the earlier PASS reports or from experiments. No conclusion of Li–Pan, a quiver-with-potential realization, or an acyclic Jacobian positivity argument is used.

## 1. Conclusion and exact dependency

I found no mathematical gap in the chain below under its stated **rank-generic and cut-generic original-color parameter choice**:

1. The full positive-valuation factor of the framed Gale equations is finite, including its local Artin structures.
2. Near the selected original-color covector, every actual arrow valuation has uniform positive lower and finite upper bounds.
3. This gives a finite flat family over independent target annuli, and a separately proved finite flat family on every coordinate-fixed locus.
4. At a generic packet target, binary collision charts count the fixed-locus degree by primitive flow-tree weights.
5. The trace of a Young permutation on the selected square-map factor equals that fixed-locus length.
6. The inherited one-frame identity and the general Argüz–Bousseau flow-tree theorem identify the total-sign multiplicity with the classical formal theta coefficient.
7. The remainder/alternant identity, followed by invariant saturation and specialization, realizes that multiplicity as the stated finite algebra in monic Q-polynomial coordinates.

The theta identification in item 6 remains an essential dependency. Items 1–5 alone do not identify a graph-defined degree with a theta coefficient. Conversely, the old signed flow formula alone does not prove the positive finite model. Neither side is used to define the other.

The strongest useful simplification from this audit is a **direct primitive-chart determinant proof** in Section 4. It eliminates the need to obtain the packet normalization by dividing degrees of a global target-power map. The quotient is an integer separately in every admitted chart.

This result computes each formal coefficient by a finite algorithm. It does not prove that every label has finite Laurent support, and the Q remainder presentation is not by itself an elementary Dyck-path rule.

## 2. Rank genericity really controls all positive solutions

Write the leaf charges as beta_0=e_0 and beta_v=k_v e_color(v), with exactly one frame leaf and k_v>0. Put alpha=sum beta_v. For a full binary hierarchy H, let M_H have columns

    (v_S)_v = eta(beta_S,beta_v)  if v is in S, and 0 otherwise,

with the frame row omitted. Let U be the image of ann(alpha) in the remaining leaf covectors.

The substantive rank-recession statement is

    U subset image(M_H)
      => ker(M_H) intersect R_{>=0}^n
         is the orthant supported on monochromatic internal nodes.

I checked the proof with a real solution M_H t=-nu, not a positive solution. This distinction matters: rank genericity is enough to produce the real t used in the proof, while positivity is needed only for the homogeneous recession vector a.

At S=L union R, summing the leaf equations over L gives

    phi(L)+t_S eta(S,L)=0,      a_S eta(S,L)=0.

For a nonzero cut, a_S=0, and the projected incoming covector is

    Pi(phi)=phi-phi(L) eta(S,-)/eta(S,L).

After the first nonzero split, its possible values form ann(P), where P is a nondegenerate two-plane containing S. The restriction of Pi to ann(P) is injective: its only possible kernel is the line eta(S,-), which cannot annihilate the nondegenerate plane P. The image has codimension two and equals ann(S,L).

For a zero cut, auxiliary genericity forces phi(L)=0 identically on that incoming image. At the root this would make a proper child parallel to alpha, impossible with one frame and nonnegative coordinate charges. Below the root it puts L in P. Nondegeneracy and eta(S,L)=0 imply L=lambda S, R=(1-lambda)S with 0<lambda<1. Absorb the parent coefficients into the children by factors 1/lambda and 1/(1-lambda). This preserves the leaf equations and, crucially, preserves nonnegativity of a.

A positive recession coefficient cannot pass through a nonzero cut. Propagating it down to leaves therefore forces every descendant leaf to be parallel, hence of the same original mutable color. An actual arrow cannot lie inside such a node. This is the actual-arrow recession exclusion needed for the valuation window; it is not an exclusion of all coordinate coincidences.

The finite genericity selector is also valid. For every hierarchy take a left-kernel basis ell of M_H and discard the zero rows ell^T W, where W records original colors. Choose the color covector outside the kernels of all retained rows. Feasibility of a hierarchy at that covector then forces U subset image(M_H). No theta coefficient enters this selector.

After deleting the monochromatic zero columns, the nonnegative kernel is zero. A rational strict-alternative certificate M_eff^T u>=1 bounds sum t_eff and hence every actual arrow valuation. Finitely many hierarchy cones are closed; cones missing the selected covector stay absent in a small full leaf-covector neighborhood. Taking a common neighborhood and the finitely many dual bounds gives the uniform upper bound, including target-unit variations.

For the lower bound, use the components of the graph of arrows whose valuation exceeds the least actual-arrow valuation m. An arrow of valuation m joins distinct components by the ultrametric inequality. Every boundary arrow of one such component has valuation m. Summing its Gale equations gives

    |theta(C)| = m |eta(C,V minus C)|.

The numerator stays away from zero by cut genericity and the denominator belongs to a finite integral list. This gives m>=epsilon>0. The argument is valid for signed endpoint covectors as well, when both genericity conditions are imposed.

### Clarification of the disconnected-cluster sentence

The strong-generic chart note says a disconnected induced cluster gives rank deficiency. A fully explicit reason avoids assuming that its connected components occur as hierarchy nodes. If S has c>1 induced components, every column indexed by a descendant node A subset S has row sum zero separately on each component. There are |S|-1 such internal columns, but their span has dimension at most |S|-c. They are therefore dependent. This proves the assertion for an arbitrary hierarchy refinement.

## 3. The positive factor is selected algebraically, including nilpotents

Let J be the contraction of the cleared Gale ideal from the localization where T and all actual arrow forms are invertible. Put C=k[T,x]/J and A=the T-adic completion of C.

The cut relations belong to J because they hold in that localization. At a T=0 point, group vertices by connected components of the zero-arrow subgraph. Every boundary arrow of a proper component is nonzero there. Its cut relation has a nonzero product on one side and a strictly positive T power on the other. Cut genericity makes this impossible. Thus the special fiber is supported at the single coordinate origin; if the framed graph is disconnected, it is empty. In either case C/TC is finite.

Lifting a basis of C/TC gives finite generation of A over k[[T]]. Saturation makes T and the arrow product regular on C; flatness of Noetherian completion preserves this. Hence A is finite free over the DVR. Only **after** passing to K=k((T)) does regularity of the arrow product imply that it is a unit on A_K.

There is a useful nonformal point here. For C'=k[[T]] tensor_{k[T]} C, the completion map C' -> A is not merely flat: it is surjective. Indeed, the lifted finite basis of A and all of its k[[T]] coefficients already belong to C'. The kernel of this flat quotient is an idempotent ideal. Thus A, and then A_K, is a full direct factor of the actual square-system algebra. This proves preservation of local Artin lengths. A finite quotient without this direct-factor argument would not have been enough for the trace theorem.

All points of A_K have positive coordinate, and hence positive actual-arrow, valuation. Every positive solution conversely reduces to the special origin and factors through the completion. This verifies that T-saturation followed by the T=0 fiber selects the **entire** positive factor, not an arbitrarily chosen subset of branches. It does not assert that the unspecialized polynomial algebra is finite over k[T].

The previously found cyclic target-specialization counterexample lies outside rank genericity. It does not invalidate this fixed-target finiteness theorem, and it prevents replacing the valuation-window argument by cut genericity alone.

## 4. Direct primitive binary-chart determinant lemma

This is an independent normalization check and a shorter replacement for the target-power-map degree division.

Let packet A have charge beta_A=k_A e_i, content d_A=k_A D_i, and let the frame content be d_0=1. The oriented multiplicity between packets is |eta(beta_A,beta_B)|. Every exponent in its ordinary Gale row is divisible by d_A. Therefore the primitive packet row is a rational function with integral exponents and

    Gamma_A^ord=(Gamma_A^pr)^{d_A}.

Choose a strongly generic leaf covector, so every positive solution has a unique full binary collision hierarchy with all relative depths positive and all cut pairings nonzero. In anchor-difference coordinates delta_S=T^{depth_S} y_S, the ordinary initial equations are a torus monomial map with exponent matrix b. Its columns differ from the collision matrix M_H by an integral unitriangular transformation. Thus

    |det b|=product_{S=L union R} |eta(beta_L,beta_R)|.

The **primitive** initial equations are obtained by dividing row A of b by d_A. No root extraction of their target constants is performed: the primitive row itself was already defined with integral exponents. Their exponent matrix is

    b_pr=diag(d_A^{-1}) b,

and consequently

    |det b_pr|
      = product_nodes |eta(beta_L,beta_R)| / product_{A != 0} d_A.   (4.1)

The matrix b_pr is integral and nonsingular, so (4.1) is a positive integer. Its monomial torus map has exactly this many simple roots over an algebraically closed characteristic-zero residue field, for every nonzero set of primitive target residues. Hensel lifting gives one positive solution per root. Every positive solution occurs in exactly one chart. There are no missing phase or gcd factors.

This is also exactly the primitive tree weight. With d(gamma)=gcd_j(Dhat_j gamma_j), the Lie bracket is

    [X_gamma,X_delta]
      =-eta(gamma,delta) d(gamma+delta)/(d(gamma)d(delta)) X_{gamma+delta}.

Each vertex weight |eta| d(parent)/(d(left)d(right)) is integral: d(left) and d(right) both divide eta, and their gcd divides d(parent). Its product telescopes to (4.1), since the root has frame degree one and hence content one.

For a permutation cycle of length r in original color i, the retained fixed equation is precisely this primitive row with packet content rD_i. Keeping one equation per cycle gives (4.1) directly. Raising that retained row to rD_i before counting would introduce spurious roots of unity. The proof above avoids doing so.

## 5. Why the same count reaches clone-invariant targets and all cycle traces

The valuation window places the entire positive locus strictly inside the source bounds used in the affinoid presentation. Thus the relative boundary is empty. The affinoid properness/finite criterion yields a finite map over the connected polyannulus of independent target coordinates. Compactness alone would not justify that step.

The source is the graph of the primitive Gale map on an analytic domain of the open arrow-complement configuration space, and is smooth of the same dimension as the regular target annulus. The finite equal-dimensional Cohen–Macaulay-to-regular criterion gives flatness. A nonempty source component cannot be vertical, since its dimension equals the dimension of the integral target. This is the required full-neighborhood family, not a family only on color-invariant targets.

For each Young permutation sigma, impose coordinate equalities and target equalities within its cycles. No actual arrow joins two coordinates of one such cycle. Keeping one equation per cycle again presents a smooth graph over an open affine configuration space of the cycle variables. Finiteness follows by closed base change; flatness is proved separately by the same dimension criterion. **Flatness of the original family alone would not imply flatness of its fixed subschemes.** The supplied proof does not make that mistake.

Now vary the fixed-cycle target valuations slightly inside this family to a strongly generic packet covector. Section 4 computes its degree. Flatness transports that degree, with scheme lengths, back to the color-invariant target. It therefore gives the primitive packet count T_lambda for every cycle type.

The fixed-cycle trace lemma is applicable because Section 3 gave full isolated factors of an equivariant square map with the same coordinate permutation representation on source and equations. Its coordinatewise perturbation proof is complete: Hermite interpolation provides independent block values and normal derivatives; each fixed-cycle restriction is again a square system and has its own regular-sequence flatness proof. Hence

    Tr(sigma | A_K)=length A_K/(x-sigma x)=T_lambda.

This fixed-coordinate quotient is not the invariant subalgebra. Generic equivariant smoothing gives a finite set whose point stabilizers are products of symmetric groups. The sign representation occurs exactly once for each free Young orbit and not for a nontrivial such stabilizer.

## 6. The inherited theta bridge and its external theorem really match

I reread the original `universal_tree_positive.md`, the one-frame coefficient theorem, and the incoming recursion audit. Here c_alpha(m) is a coefficient of the **total incoming transport acting on x^m**; it is not the incoming middle-wall coefficient, which is zero for a non-axis root. Keeping those notions distinct removes a possible apparent contradiction in the one-frame argument.

The one-frame identity is

    a_g^B(p)=c_{(1,p)}^{Bhat}(-e_0).

Its recurrence proof retains equality faces: zero-frame coefficients on x_0^{-1} vanish, and the framed block has exactly the endpoint signs, with the pivot-0 secondary signs strictly excluding the endpoint equality faces. I checked this dependence rather than treating the one-frame statement as automatic.

Choose a covector mu whose mutable coordinates are positive and whose frame coordinate makes mu(1,p)=0. In the finite root box up to (1,p), all nonzero zero-frame roots are positive, every proper framed root is negative, and (1,p) is the only zero root. In C=U^- U^0 U^+, U^+ fixes x_0^{-1}; U^- cannot by itself contribute (1,p), nor change such a term, because two framed increments have frame degree two. Thus the desired total-action coefficient is its middle-wall action coefficient. The wall logarithm uses the negative of the transport logarithm, while X_(1,p) acts on x_0^{-1} by -1. Those two signs cancel.

I opened Argüz–Bousseau, arXiv:2102.11200v2, and checked the exact abstract hypotheses. Section 3.2 only requires that the bracket vanish when the skew pairing vanishes; it does not require a nondegenerate skew form or a quiver-with-potential realization. Theorem 4.24 is the fixed-skew-form, perturbed-endpoint version needed here. The root-box quotient makes the graded Lie algebra finite, so only finitely many genericity conditions are involved. Their vertex sign and the primitive bracket above give the positive vertex multiplicity in Section 4.

The initial wall logarithm has leaf coefficient (-1)^(k-1)/k at the packet k e_i. Polarization contributes 1/m_k!, giving exactly 1/z_lambda and the sign (-1)^(|p|-ell(lambda)). Therefore

    a_g^B(p)=sum_lambda sgn(lambda) T_lambda / product_i z_{lambda^i}
            =multiplicity of total sign in A_K.

No acyclic master-function theorem is used for this identification.

Primary sources checked:

- Argüz–Bousseau, *The flow tree formula for Donaldson–Thomas invariants of quivers with potentials*, arXiv:2102.11200v2, §3.2, Definition 2.21, and Theorem 4.24: https://arxiv.org/pdf/2102.11200 . The general scattering theorem precedes its DT specialization.
- Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, arXiv:1411.1394v2, §1.2 and §3: https://arxiv.org/pdf/1411.1394 . The incoming construction and broken-line convention are used only with the normalizations spelled out in the inherited audit.

## 7. Q remainder compression has no hidden generic-root hypothesis

For P=k[T,x_{i,a}], R=P^G, and invariant-coefficient polynomials F_i(z), let I=(F_i(x_{i,a})) and J be the ideal of the coefficients of F_i mod Q_i. The identity

    (I:Delta) intersect R=J

holds even if the coefficients of F_i depend on Q_i, even if roots repeat, and even if the quotient is nonreduced. The forward inclusion follows from the adjugate Vandermonde system. For the reverse inclusion, I subset JP and the R-linear map

    Phi(f)=Alt(f)/(|G| Delta)

is polynomial and sends Delta to 1. Therefore Delta h in I implies h in J. Exactness of the characteristic-zero sign projector gives (P/I)^sgn isomorphic to R/J as R-modules.

If s is invariant, apply the same identity to s^m h to get

    ((I:s^infinity):Delta) intersect R=J:s^infinity.

The projector is also T-linear, so its formation commutes with reduction modulo T. The arrow-open saturation pulls back exactly from the product of frame factors Q_i(0) and intercolor resultants. There is no discriminant factor, because equal same-color coordinates have no arrows.

The resulting special Q algebra therefore has precisely the sign multiplicity already identified in Section 6. Its ordinary multiplication is a presentation convenient for computing dimension; the sign component was only identified as a module, not as a subalgebra of the clone algebra. No infinite limit or unproved finiteness of the global polynomial family is needed.

The older Q-divisibility presentation in Benini–Park–Zhao, arXiv:1406.2699 §3.3, is acknowledged in the original note. The general invariant-theoretic compression should not be advertised as a separate new theta theorem. The substantive mathematical bridge audited here is the global cyclic positive factor and its Young character.

## 8. Files inspected directly

- `agents/phase_descent_round1/GALE_POSITIVE_FACTOR_GENERIC.md`
- `agents/phase_descent_round1/COLOR_GENERIC_VALUATION_WINDOW.md`
- `agents/phase_descent_round1/GALE_FIXED_TARGET_FINITE_FACTOR.md`
- `agents/global_gale_adversarial/RANK_GENERICITY_AND_RECESSION.md`
- `agents/dyck_flow_round2/GALE_YOUNG_THETA_DEGREE_THEOREM.md`
- `agents/dyck_flow_round2/YOUNG_FIXED_CYCLE_LENGTH_LEMMA.md`
- `agents/dyck_flow_round2/SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md`
- `agents/global_gale_novelty/Q_POLYNOMIAL_REMAINDER_THEOREM.md`
- `history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/universal_tree_positive.md`
- `history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/ONE_FRAMING_COEFFICIENT_THEOREM.md`
- `history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/incoming_independent_audit.md`

No numerical test is a premise of the conclusions above. This branch contributes an independent proof reconstruction and the direct determinant simplification, rather than another list of prior experimental passes.
