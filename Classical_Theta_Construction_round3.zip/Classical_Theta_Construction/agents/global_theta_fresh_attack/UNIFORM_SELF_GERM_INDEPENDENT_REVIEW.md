# Independent proof review: label-uniform self-endpoint theta germs

2026-11-13. Classical skew-symmetric and skew-symmetrizable data.

## Verdict

The argument in `../ray_pressure_mechanism/UNIFORM_SELF_ENDPOINT_MAJORANT.md` passes this independent review. It proves a matrix-dependent exponential majorant for **every integral-label self-endpoint germ**, uniformly in the label, by a new total normal-variation estimate followed by a positive profile convolution. It removes the label-height dependence left by the preceding balanced-tree argument.

I supplied the zero-point version of the oscillation lemma below, which makes the proof valid even when other contacts with a root hyperplane are tangential or contain zero plateaus. The updated main proof incorporates it. No assumption of global hyperplane-crossing regularity remains.

The dependencies are the proved endpoint-uniform theta coefficient estimate and its one-coordinate wall-factor consequence, classical positivity and covariance, and the common analytic domain for one-segment transport. The new estimate does not use finite Laurent support, an unproved positive quotient, or a polymer expansion. The coefficient bounds and the large-label stabilization can both be proved directly from broken-line geometry.

## 1. Correct coordinates and the self germ

Use the normalized mutable label coordinates gamma. With initial label m and accumulated principal degree q, the velocity is

    gamma'=-(m+Bq).

For primitive positive a, its hyperplane is a^T D gamma=0, and its primitive integral normal is

    u_a=Da/delta_a,     delta_a=gcd_i(D_i a_i).

Thus the positive wall exponent at a bend is |a^T D(m+Bq)|/delta_a. This is the same convention as the single-bend estimate. If instead one uses physical covector coordinates D gamma, both the endpoint and the velocity must be multiplied by D. The main proof now states both conventions consistently.

At any fixed principal degree d, choose an endpoint alpha m+epsilon D^{-1}v, alpha>0, v_i>0, with epsilon sufficiently small. For every nonzero a^T Dm at that degree, the endpoint has the same sign. Every zero value acquires positive sign. The limit is coefficientwise; there is no claim that one epsilon works at all degrees. The finite truncation has only finitely many relevant walls and packet sequences, so a generic endpoint may be chosen within that sign germ.

For principal coefficients the mutable projection can have an unchanged slope even when B a=0. This causes no issue: the full principal exponent still records the nonzero packet. Its hyperplane intersection is transverse whenever the selected wall exponent is nonzero, and the frozen path is uniquely recovered once the mutable bend times are known.

## 2. A general scalar variation lemma

Let phi be a continuous piecewise-linear function on (-infinity,0], with finitely many slope changes and initial slope v_0=-lambda. Suppose phi has sign lambda near negative infinity and at its endpoint when lambda is nonzero. Let V be the total variation of its slope.

Choose any finite increasing list of zero times t_1,...,t_k at which the slope is continuous and nonzero, and write v_j=phi'(t_j). These may be only selected crossings; other zeros, tangencies, or zero intervals are allowed.

First, if k>0 and lambda!=0, the selected crossing and return to the endpoint sign force an interval with slope opposite to v_0. Thus |lambda|<=V. For lambda=0 the same inequality is automatic.

Second, the slope variation between two consecutive selected zero times is at least |v_j|+|v_(j+1)|. If the two slopes have opposite signs this follows immediately. If they have the same sign, phi(t_j)=phi(t_(j+1)) forces an opposite-sign slope in between; the variation through it is again at least that sum. Adding the initial part gives

    V >= |v_1-v_0| + sum_j (|v_j|+|v_(j+1)|)
      >= 2 sum_j |v_j| - |v_0| - |v_k|.

Since |v_k|<=|v_0|+V, one obtains

    sum_j |v_j| <= V+|lambda| <= 2V.                 (2.1)

For lambda=0 the stronger sum<=V holds. For k=1 the same calculation uses an empty intermediate sum. This is a deterministic one-dimensional lemma; no scattering claim or numerical test is involved.

Now put phi=a^T D gamma. Its slope changes by -a^T D B Delta q, so with M=max_ij |D_i B_ij|,

    V_a <= M |a| d.

At an actual a-bend, Delta q=k a and a^T D B a=0. Thus the normal slope is continuous there, and it is nonzero because a zero wall exponent selects no nonconstant term. These are exactly the hypotheses of the scalar lemma. Consequently all a-bends together satisfy

    sum_j E_j <= 2M |a| d/delta_a.                 (2.2)

This bound is independent of m, and includes arbitrarily many repeated visits to the same normal hyperplane.

## 3. Primitive normalization and one majorant for all wall germs

Let u_max=max_i D_i a_i/delta_a. Then

    u_max >= D_min |a|/(r delta_a).

The independently proved single-bend estimate supplies the coefficientwise inequality

    f^{u_max} <= U_a,
    U_a=1+sum_{k>=1} beta_(ka) z^(ka),
    beta_b=(1+C|b|)^|b|/product_i b_i!,
    C=max(1,max|B_ij|),

for every combined local wall function f of primitive normal a. Different places on the hyperplane may have different functions; all are bounded by this same U_a.

Set L_j=ceil(E_j/u_max). Positivity and constant term one imply f_j^{E_j}<=U_a^{L_j}. The number of nonempty a-bends is at most d. Therefore (2.2) implies

    sum_j L_j <= T d,
    T=ceil(2Mr/D_min)+1.                            (3.1)

There is no missing content factor: E contains 1/delta_a, while u_max contains the same factor. Common rescaling of D cancels from M/D_min.

Every nonzero principal degree b is a unique positive multiple of one primitive a. Hence for the formal product P=product_a U_a,

    sum_a (U_a-1)=sum_(b!=0) beta_b z^b.

At nonnegative z with q=eC sum_i z_i<1, the right-hand side is at most exp(1/C) q/(1-q). The product therefore converges, with

    P(z)<=exp(exp(1/C) q/(1-q)).                    (3.2)

This uses the sum of individual positive coefficients, rather than a bound that grows with the primitive normal.

## 4. No factorial loss in ordered packet counting

For a fixed ordered sequence of nonzero packet degrees b_1,...,b_l with total p, there is at most one geometric broken line to a fixed generic endpoint. Going backwards, the final mutable exponent is m+Bp. The last packet determines its primitive normal uniquely. The line intersects that normal hyperplane in at most one point, because its actual wall exponent is nonzero; skew-symmetry gives the same normal speed before and after the bend. Continue with the preceding packet. Support and positivity-of-time constraints can invalidate the sequence, but cannot create another line.

Combined local wall coefficients already include choices among coincident walls. Crossings where one selects the constant term introduce no new packet and no choice. A frozen-direction packet with B b=0 still has a uniquely determined primitive normal and a unique intersection time. Thus it does not break the reconstruction argument.

For fixed a let N_a be the sum of packet multiplicities k_j with b_j=k_j a. The product of their selected coefficients is bounded by

    product_j [z^(k_j a)] U_a^(L_j)
      <= [z^(N_a a)] U_a^(sum_j L_j)
      <= [z^(N_a a)] U_a^(T d).                    (4.1)

The first comparison is one particular term of a nonnegative Cauchy convolution. It needs no equality of the original local wall functions or of their exponents.

The number of ordered nonzero vector compositions of a fixed p is at most

    2^(d-1) binomial(d;p_1,...,p_r) <= (2r)^d.

Indeed, sort unit colors within each packet, concatenate the words, and mark cuts. This is an injection into color words of content p with a subset of the d-1 gaps marked. In particular, the same exponential bound applies to every fixed primitive-normal profile.

Group the broken lines by that profile. Summing (4.1) over profiles is exactly coefficient extraction in product_a U_a^(Td). It follows that

    [z^p] G_(m,self) <= (2r)^d [z^p] P(z)^(Td).       (4.2)

The ordered sequences cost only the displayed exponential factor. Introducing a factorial here would count the same coefficient splits a second time.

## 5. Uniform radial bound and direct quadratic vanishing

Fix w_i>=0 with sum_i w_i=1. Since Td is the same for every p of degree d, summing (4.2) against w^p is legitimate and gives

    [s^d]G_(m,self)(s w)
      <= (2r)^d [s^d]P(s w)^(Td).

At rho_0=1/(2eC), formula (3.2) gives P(rho_0 w)<=exp(exp(1/C)). A positive evaluation bounds each univariate coefficient, yielding

    [s^d]G_(m,self)(s w) <= B_*^d,
    B_*=4eCr exp(T exp(1/C)).                       (5.1)

This is uniform in both m and w, including directions with some zero coordinates. The individual multivariate coefficient bound follows as stated in the main note, but (5.1) is more useful and does not lose another factor r when estimating the absolute series.

There is also a short independent proof of the needed stabilization. Let m=ng with integral g and suppose a nontrivial broken line has final degree d. At its first nonempty bend with primitive normal a, the preceding exponent is ng, so lambda_g(a)=a^T Dg is a nonzero integer. The self-crossing lemma gives

    n <= n |lambda_g(a)| <= V_a.

All packets parallel to a contribute exactly zero to this normal variation. If their total degree is N_a |a|, then N_a>=1, and

    V_a <= M |a| (d-N_a |a|)
        <= M |a| (d-|a|)
        <= M d^2/4.                               (5.2)

Thus a nonconstant coefficient of G_(ng,self) can occur only when n<=M d^2/4. The main note's conservative condition n>M' d^2 with M'=max(1,M) is therefore valid. This proves the required gap directly, without invoking the earlier signed-factorization stabilization theorem.

For B=0, M=0 and the same argument permits no nonconstant self-germ coefficient. No division by M is needed in that case.

Combining (5.1) with this gap gives, for s=sum_i |z_i|<1/B_* and M'=max(1,M),

    |G_(ng,self)(z)-1|
      <= (B_* s)^ceil(sqrt(n/M'))/(1-B_* s).         (5.3)

At an exact square boundary the displayed bound may retain a zero degree, which only makes it weaker. It is valid for all n and g and implies a stretched-exponential rate. The balanced-tree theorem is no longer needed for this particular conclusion.

## 6. Return to the seed and the all-real-label consequence

The previous path theorem provides constants q_*,K_path independent of the real endpoint such that every coarse one-segment transport A_g^- is analytic for eC sum|z_i|<q_* and its logarithmic coordinate displacement has infinity norm at most K_path. Its boundary-germ construction is obtained by a normal-family argument with stabilized Taylor coefficients, not by an unjustified interchange of analytic and formal limits.

Write A_g^-(x^g)=x^g H_g(z), A_g^-(z)=W_g(z). The ray sign factor is unchanged by a positive multiple of g, so the exact formal identity is

    F_(ng)(z)=H_g(z)^n G_(ng,self)(W_g(z)).

The uniform transport estimate gives sum|W_g(z)|<=exp(rb K_path) sum|z_i|, with b=max|B_ij|. Therefore on

    sum|z_i| < rho_*,
    rho_*=min{q_* /(eC), exp(-rb K_path)/B_*},

both sides converge and the identity is analytic. On every smaller closed ball, (5.3) gives a common stretched-exponential error bound for

    F_(ng)(z)/H_g(z)^n - 1,

uniformly in every integral g. H_g is nonzero there, since it is the exponential of an analytic logarithmic transport scalar.

At positive z, taking logarithms divided by n yields Phi_z(g)=log H_g(z)=L_z(g) for every integral g on this **one common domain**. Positive homogeneity gives equality for rational labels. Continuity extends it to real labels. The continuity step has a standard independent justification: positive theta multiplication makes Phi subadditive, and the all-endpoint coefficient estimate bounds it above by a constant times ||g||. Consequently its homogeneous extension from rational labels is Lipschitz. The analytic stable-log function L is already continuous on real labels by the uniform finite-degree tails.

Thus the common-domain statement in the main note follows. It does not imply equality outside this local positive domain or finite Laurent support for arbitrary theta labels. The common radius is very small but strictly positive and matrix dependent, which is the precise assertion needed.

## 7. External convention check and search record

I reopened GHKK, arXiv:1411.1394v2, and the author-hosted primary PDF. Definition 3.1 and Remark 3.2 explicitly give the velocity as minus the attached exponent and the positive bending power. Proposition 3.4 uses backward reconstruction for finite-degree finiteness; the packet-level uniqueness argument above is a direct refinement with packet degrees fixed. No new external theorem is required for Sections 2–5.

Primary URLs:

- https://arxiv.org/pdf/1411.1394
- https://paulhacking.github.io/canonicalbases.pdf

Searches made during this review included analytic convergence of cluster theta functions, large-label ray asymptotics, and total variation of broken lines, using both search engines. They returned Maurer–Cartan asymptotic constructions, tropical-disk formulas, scattering fans, and the 2026 mutation/affine-theta papers, but no matching label-uniform self-germ majorant. These search results do not establish novelty. No unverified 2026 result is used as a premise of this proof.
