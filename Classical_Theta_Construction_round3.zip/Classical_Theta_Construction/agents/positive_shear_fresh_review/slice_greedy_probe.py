"""Exact adversarial checks of positive freezing slices and maximal greediness.

The full theta prefix and every lower-rank theta use the independent
incoming-normalized recursion.  A zero slice remainder in some direction
would give the proposed max-of-proper-slice greedy coefficient.
"""
import json, random, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from incoming_recursion import IncomingSchur,box,le,sub

def analyze(B,D,g,cap):
    n=len(B); R=IncomingSchur(B,D); F=R.theta_prefix(g,cap)
    branches=[]; neg=[]
    for i in range(n):
        J=[j for j in range(n) if j!=i]
        L=IncomingSchur([[B[j][l] for l in J] for j in J],[D[j] for j in J])
        lowercap=tuple(cap[j] for j in J)
        cache={}
        def coeff(h,t):
            key=(h,t)
            if key not in cache: cache[key]=L.theta_prefix(h,t).get(t,0)
            return cache[key]
        bs={}
        for k in range(cap[i]+1):
            layer={}
            for q in box(lowercap):
                full=list(q); full.insert(i,k); full=tuple(full)
                v=F.get(full,0)
                for r,b in layer.items():
                    if b and le(r,q):
                        h=tuple(g[j]+B[j][i]*k+sum(B[j][l]*r[t] for t,l in enumerate(J)) for j in J)
                        v-=b*coeff(h,sub(q,r))
                layer[q]=v; bs[full]=v
                if v<0: neg.append({'i':i,'p':full,'b':v})
        branches.append(bs)
    cores=[]
    for p in box(cap):
        if not all(p): continue
        bi=[br[p] for br in branches]
        if min(bi)>0:
            cores.append({'p':p,'a':F.get(p,0),'b':bi,'core':min(bi)})
    return {'B':B,'D':D,'g':g,'cap':cap,'nonzero_theta':len(F),
            'negative_branches':neg,'positive_core':cores}

def main():
    rng=random.Random(11142359); start=time.time(); results=[]
    settings=[(3,(2,2,2),300),(4,(1,1,1,1),300),(5,(1,1,1,1,1),100)]
    special=[([[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],(-1,-1,-1),(2,2,2)),
             ([[0,-2,3],[2,0,-3],[-3,3,0]],[1,1,1],(-1,1,1),(2,3,2))]
    for args in special:
        out=analyze(*args); results.append(out); print(json.dumps(out),flush=True)
    for n,cap,count in settings:
        for step in range(count):
            D=[1]*n if step%2==0 else [rng.randint(1,3) for _ in range(n)]
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    t=rng.randint(-2,2)
                    B[i][j]=D[j]*t; B[j][i]=-D[i]*t
            g=tuple(rng.randint(-3,3) for _ in range(n))
            out=analyze(B,D,g,cap); results.append(out)
            if out['positive_core'] or out['negative_branches']:
                print(json.dumps(out),flush=True)
            if (step+1)%25==0:
                print(json.dumps({'progress':len(results),'rank':n,'seconds':time.time()-start}),flush=True)
            # First genuine counterexample is decisive; finish a modest
            # surrounding set to identify its mechanism, not a huge census.
            if sum(bool(r['positive_core']) for r in results)>=12: break
        if sum(bool(r['positive_core']) for r in results)>=12: break
    summary={'status':'PASS' if all(not r['negative_branches'] for r in results) else 'FAIL',
             'cases':len(results),'core_cases':sum(bool(r['positive_core']) for r in results),
             'seconds':time.time()-start,'results':results}
    (Path(__file__).with_suffix('.json')).write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)

if __name__=='__main__':main()
