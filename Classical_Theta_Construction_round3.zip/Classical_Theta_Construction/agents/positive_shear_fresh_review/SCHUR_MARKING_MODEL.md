# Schur marking states inside the divided-derivative coefficient algebra

2026-11-14. A structural interpretation and a finite matrix reduction of
the two-polynomial model in
`../support_accessibility_fresh/DIVIDED_DERIVATIVE_BRANCHING_ALGEBRA.md`.
The finite-free factorization theorem is classical. The contribution here
is its precise insertion into the theta divided-derivative branch algebra;
we do not claim a new theorem about Grassmannian cohomology.

## 1. Independent review of the leaf elimination

Write m_i=r_i+q_i and C=[[B,I],[-I,0]]. The leaf row has label zero and
one negative entry -1. At a positive leaf endpoint L_i, its monic remainder
equation is

    P_i | T^(L_i)-(-1)^(m_i)Q_i.

For r_i>0 this is equivalent, in coefficient rings, to the unique monic
factorization

    Q_i=P_i S_i+(-1)^(m_i)T^(L_i),
    deg P_i=r_i, deg S_i=q_i.                        (1)

The sign is correct. The quotient of Q_i-(-1)^(m_i)T^(L_i) by P_i is
monic; writing a quotient of the oppositely signed remainder without
normalizing it would lose this sign. For r_i=0 there is no leaf equation,
P_i=1 and S_i=Q_i. This separate case is necessary when m_i=0, because a
degree-zero monic polynomial is identically one.

The old row has the extra positive entry +1 at its leaf, hence its
remainder polynomial contains the factor P_i in precisely the positive
term. The sign in its negative term has no contribution from r_i. The
only additional boundary factor is the old-leaf resultant:

    Res(P_i,Q_i)=((-1)^(m_i)T^(L_i))^(r_i).

Up to the harmless sign from swapping its arguments, this is a power of
T. Therefore the original boundary saturation becomes exactly saturation
by T times the old Q boundary. No same-color discriminant is inverted.
The coordinate-ring elimination, its saturation, and the special fiber
are all scheme-theoretic, so multiplicities are retained.

Verdict: the elimination statement, including its zero-degree cases,
passes independent review.

## 2. Universal marking is a finite free Schur module

Let A be a commutative ring, let

    f(z)=z^m+c_1 z^(m-1)+...+c_m,
    m=r+q,

and let Fact_r(f) represent factorizations f=P S into monic polynomials
of degrees r and q. It is finite free over A of rank binom(m,r). A basis
is

    {s_lambda(alpha_1,...,alpha_r): lambda subset (q^r)},  (2)

where the alpha are the formal roots of P. This notation means the
symmetric Schur polynomial in the coefficients of P; actual roots need
not exist and no discriminant is inverted. Equivalently, the basis is
indexed by r-element subsets of {1,...,m}, or by partitions fitting in
an r by q rectangle.

Here is an algebraic presentation suitable for implementation. Write

    P(z)=z^r+p_1 z^(r-1)+...+p_r,
    1/(1+p_1 t+...+p_r t^r)=sum_(k>=0) h_k t^k.

Put c_0=1 and

    H_k=sum_(j=0)^min(k,m) c_j h_(k-j).

Then

    Fact_r(f)=A[p_1,...,p_r]/(H_(q+1),...,H_(q+r)).   (3)

Indeed the coefficients of the monic quotient S are H_0,...,H_q. The
displayed r equations say exactly that the remainder vanishes. Subsequent
coefficients vanish by the recurrence obtained from multiplication by
1+p_1t+...+p_rt^r.

For the universal coefficient ring Z[c_1,...,c_m], the usual Schur
straightening with relations (3) reduces to the rectangle basis (2): its
highest terms are the ordinary Grassmannian relations h_(q+1),...,h_(q+r),
and every deformation term has smaller degree in the p variables.
Over the generic coefficient field, f is separable and has exactly
binom(m,r) monic degree-r factors after adjoining its roots. This proves
independence of the spanning rectangle family. Base change gives the
assertion for every A, including repeated-root and nonreduced cases.

This is the classical universal factorization algebra theorem of
Laksov--Thorup. Gatto--Santiago, arXiv:math/0702759, Remark 3.11 and
Theorem 4.8, identify the same algebra through exterior powers and give
its presentation. Their Pieri theorem and Schur basis make the reduction
effective. These references are used for this established algebraic
input, not for a statement about theta branches.

## 3. What a collision means combinatorially

If f has m distinct roots over an algebraically closed field, a point of
Fact_r(f) is an r-element subset of those roots. If f=z^m, the factorization
scheme has only the point P=z^r,S=z^q, but its length is still binom(m,r).
Its coordinate ring is the ordinary cohomology ring

    H^*(Gr(r,m),Z),

with the Schur classes (2). Thus coincident marked particles do not
disappear. They carry rectangle-partition states. At the universal
all-collision fiber, multiplication is the ordinary Littlewood--Richardson
rule restricted to the rectangle.

More generally, if

    f=product_a (z-lambda_a)^(m_a),   lambda_a distinct,

then the factorization algebra decomposes into components indexed by
allocations 0<=r_a<=m_a with sum r_a=r. The component has, after translating
each lambda_a to zero, the tensor product of the factorization algebras
of z^(m_a) in degrees r_a. Its length is

    product_a binom(m_a,r_a),

and its marking states are one rectangle partition for each root cluster.
The sum of these lengths is binom(m,r), by Vandermonde's identity.
One proves the decomposition by the coprime factorization/Hensel
property, or directly by the Chinese remainder idempotents of A[z]/f.

This is a genuine finite combinatorial description of the marking
multiplicities. It is precisely why saturating by a same-color
discriminant would destroy the intended model.

## 4. Insert the marking module into the theta branch equations

Take the base ring

    A_0=Q[T, all nonleading coefficients of the old Q_i],

where deg Q_i=m_i. For r_i>0 define

    f_i=Q_i-(-1)^(m_i)T^(L_i),
    E_i=Fact_(r_i)(f_i).

For r_i=0 put E_i=A_0. Then

    E=tensor_(A_0,i) E_i

is a finite free A_0-algebra of rank

    R=product_i binom(r_i+q_i,r_i).                 (4)

Its basis is the product of the rectangle Schur bases. This E is exactly
the coefficient algebra of the P_i,S_i parametrization before imposing
the old-row equations. At generic T the marked roots are roots of the
shifted polynomial f_i, not roots of Q_i itself. At T=0 they become a
monic divisor of Q_i and record the collision data described above.

Let f_alpha in E be the coefficients of the old-row remainders

    H_i(z) mod Q_i(z),

with H_i defined in equation (7) of the companion note. The ideal they
generate is also the A_0-submodule generated by all products

    f_alpha s_lambda,

where s_lambda runs over the finite product Schur basis. Hence the
quotient E/(f_alpha) has the concrete finite presentation

    A_0^(R times number of relations) --> A_0^R --> E/(f_alpha) --> 0, (5)

whose blocks are the R by R multiplication matrices of the f_alpha.
Every matrix entry can be calculated by Schur/Pieri straightening using
(3). The old-row expression is especially simple in these coordinates:
its positive term is linear in the coefficients of P_i, while all other
factors use only old Q variables.

Write Sigma for the old boundary product. Saturation by T Sigma is now
the saturation of the image submodule in (5), since T Sigma belongs to
the base ring A_0. Quotienting by T afterwards produces exactly the
branch algebra D_(B,g;r,q). Thus

    d_(g;r,q)=dim_Q of this explicitly presented special-fiber module. (6)

This is an alternative computation by finite Schur matrices. All leaf
variables have been absorbed into a finite marking space whose rank is
known in advance from (4); there is no root-separation assumption and no
theta-expansion oracle.

## 5. The limitation that must be retained

The old-row equations couple different colors and can impose nontrivial
relations among the marking states. The resulting branch algebra is not
claimed to remain free over the old Q coefficient ring. In particular,
its dimension is not generally the product in (4), and one cannot select
an arbitrary subset of Young diagrams and count it without doing the
relations and saturation.

The rectangle basis gives a concrete finite marking model and a
combinatorial matrix calculus for the new two-polynomial branch algebra.
It does not yet produce a cancellation-free path model for every branch,
nor a global bound on all branch degrees q. Those are separate remaining
steps, not consequences of universal factorization flatness.

## Primary literature and audit record

- Dan Laksov and Anders Thorup, *Schubert calculus on Grassmannians and
  exterior powers*, preprint dated 8 May 2008; Indiana Univ. Math. J.
  58 (2009), 283--300. The university publication record confirms the
  2009 date. The search service's recent crawl label is not a publication
  date. Primary author URL: https://web.math.ku.dk/~thorup/temp/lt2b.pdf .
  The direct PDF server timed out/returned HTTP503 in this session; its
  indexed primary text states the universal factorization and free Schur
  basis theorem. We do not rely on unread additional statements there.
- Letterio Gatto and Taise Santiago, *Schubert Calculus on a Grassmann
  Algebra*, arXiv:math/0702759v1, 26 Feb 2007, later Canadian Math. Bull.
  52 (2009), 200--212. Primary PDF was read at §3, especially Remark3.11,
  and §4, Theorem4.8. This verifies the factorization/exterior-power
  identification and presentation independently of the unavailable PDF.
  https://arxiv.org/pdf/math/0702759 .
- The direct application to the theta branch equations is the algebraic
  construction in §§1 and4 above. It is proved from the already reviewed
  signed-Q theorem and monic leaf elimination; no 2026 speculative
  representation-theoretic identification is imported.

