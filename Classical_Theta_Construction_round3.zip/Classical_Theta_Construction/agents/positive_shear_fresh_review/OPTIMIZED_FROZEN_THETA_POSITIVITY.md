# Theta-positive divided powers at an optimized frozen row

2026-11-14. Classical skew-symmetric and skew-symmetrizable seeds. This is
an extension of the source-leaf proof, not a claim that the underlying
root derivation is new. Fei, arXiv:2309.08326v4, §8.1, already studies the
corresponding derivations under his hypotheses; see the comparison below.

## Statement in a fixed matrix convention

Let the mutable exchange matrix be B, with D B skew-symmetric. Let y be
a frozen variable whose row is c=(c_1,...,c_n), with all c_j>=0. Retain
enough independent principal degree markers to distinguish positive root
degrees when working formally.

Choose a positive integer D_a such that

    m_j=D_a c_j/D_j is integral for every j,
    M=x_1^(m_1)...x_n^(m_n).

In the skew-symmetric case one takes D_j=D_a=1 and M=x^c.
Consider a theta function whose initial frozen y exponent is ell>=0,
written in this seed as

    theta = y^ell x^g f_other sum_(p>=0) a(p) z^p,
    z_j=y^(c_j) z_(j,other),   a(p)>=0.

The notation f_other denotes its fixed Laurent monomial in the other
frozen variables. Every divided power

    R^[r]=(M^r/r!) partial_y^r

has a coefficientwise nonnegative integral theta expansion in the original
ice seed. If theta is finite, that expansion is finite and every occurring
theta is finite. Its leading frozen y exponents are nonnegative. Thus the
shear y -> y+t M preserves the finite theta algebra with polynomial
dependence on this optimized frozen variable and acts with nonnegative
theta matrix entries.

This statement includes arbitrary formal theta labels satisfying ell>=0;
it does not require a Jacobi-finite potential, a representation-theoretic
identification of theta, or equality of the upper and middle algebras.

## Source-leaf proof

Unfreeze y to a new mutable variable a with

    B_(a,j)=c_j,     B_(j,a)=-m_j,

and symmetrizer D_a. Add frozen u,v with B_(u,a)=1, B_(v,a)=-1 and no other
initial new entries. The extended matrix is skew-symmetrizable, since
D_j(-m_j)=-D_a c_j. The new row is a source. Its theta label has coordinate
ell>=0, so the proved source cap says its a-root degree is zero. Freezing
a recovers the stated original theta expression.

Mutation at a has exchange relation

    a a'=u+v M.

Because B_(j,a)<=0 and B_(a,k)>=0, the old mutable block B is unchanged.
After freezing a', the relevant rows at old mutable columns are

    row(u)=c,       row(v)=0,       row(a')=-c.

Consequently set

    z_j'=(u/a')^(c_j) z_(j,other),   w=v M/u.

The initial theta transforms exactly into

    (u/a')^ell x^g f_other
      sum_p a(p) (z')^p (1+w)^(ell+c.p).             (1)

There are only finitely many leaf choices 0<=r<=ell+c.p at each old root
degree p. Since r<=ell+(max c_j)|p|, the old-root-plus-leaf and old-root
filtrations on (1) are comparable up to this fixed linear bound. This is a
continuous substitution in an explicit common completion.

The fixed v^r coefficient is

    v^r u^(ell-r) (a')^(-ell) x^(g+r m) f_other
      sum_p binom(ell+c.p,r) a(p) (z')^p.            (2)

It is one translate of the nonnegative old-root cone. Old transports
preserve v-degree, since its old row is zero. The high transverse lift
therefore proves scattering positivity of (2), coefficient by coefficient.
Completed triangular inversion plus the last-segment coefficient detector
gives its nonnegative integral old-theta expansion.

The prefactor u^(ell-r) can have negative exponent. This causes no
problem: a branch indexed by old degree p has leading u exponent
ell-r+c.p. If this is negative, the corresponding coefficient of (2) is
zero because binom(ell+c.p,r)=0. Positive triangular expansion then forces
that branch coefficient to vanish. Every occurring branch thus has
nonnegative leading u exponent. All its subsequent u increments are
c.q>=0. Setting a'=1 and renaming u as y proves the assertion, with all
principal degree markers retained.

For finite theta, (1) is an actual Laurent polynomial with polynomial
u,v dependence. A positive old-theta expansion of a finite Laurent
polynomial has only finitely many nonzero leading monomials. It is
therefore finite, and each constituent must be finite by positivity.

## Several optimized frozen rows

The same construction works for a collection of frozen variables y_s
whose rows c_s are all nonnegative. Give the newly mutable a_s no edges
between themselves. Choose D_(a_s) so that

    m_(s,j)=D_(a_s)c_(s,j)/D_j is integral.

All a_s are sources, their mutations commute, and the old block remains
B. The corresponding shears are

    y_s -> y_s+t_s M_s,       M_s=product_j x_j^(m_(s,j)).

Because each M_s is independent of every y_t, the shears commute and
their parameters add under composition. All mixed divided powers are
theta-positive by the simultaneous high-lift argument. On the finite
algebra regular in these optimized frozen variables this gives a Ga^s
coaction over Z with nonnegative theta matrix coefficients.

For a row of the opposite sign one must first change to the corresponding
opposite matrix/duality convention; the displayed formulas should not be
used with signed c_j and negative binomial tops without a new proof.

## Precise comparison with Fei

Fei, *Crystal Structure of Upper Cluster Algebras*, arXiv:2309.08326v4,
§8.1, formula (8.1), defines the root derivation at an optimized frozen
vertex as a monomial times the frozen partial derivative. Proposition 8.1
proves preservation of the upper algebra and local nilpotence in his
setting. For a principal singleton row this is x_i partial_(y_i), subject
to the paper's arrow convention.

Thus neither the differential expression, the existence of a translation,
nor local nilpotence on finite polynomials is a novelty claim here. The
additional statement proved above is nonnegativity of every theta
expansion coefficient for all divided powers, including the formal and
skew-symmetrizable scopes, together with the explicit branch algebras of
the companion note. Fei's Conjecture 8.14 still explicitly asks for theta
and classical triangular bases to be BK-biperfect. The present proof does
not supply the distinguished leading crystal term or the required
degree filtration inequalities, and does not claim that conjecture.

Primary source: https://arxiv.org/html/2309.08326v4

