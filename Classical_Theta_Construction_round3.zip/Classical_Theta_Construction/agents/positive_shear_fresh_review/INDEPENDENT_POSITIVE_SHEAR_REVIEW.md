# Independent review of positive freezing and coefficient shears

2026-11-13, begun 23:42 UTC. Classical skew-symmetric and
skew-symmetrizable cluster data. This is an independent reconstruction of
`../support_accessibility_fresh/FREEZING_POSITIVE_SHEAR_DRAFT.md`, not a
review based only on its computational results.

## Verdict and exact scope

**PASS for the finite theta statement.** A finite normalized principal
theta function has a nonnegative integral theta expansion after every
coefficient shear `y_i -> y_i+t x_i`. Consequently all commuting mixed
divided powers of `R_i=x_i partial_(y_i)` are theta-positive.

The root degree must be retained; principal coefficients, or an injective
full charge map, prevent accidental monomial collisions. The specific leaf
extension used in the proof already has full rank, so it needs no extra
marker specialization. The finite conclusion uses neither upper=middle
nor theta=generic-character identification.

The displayed residual coefficient inequality and its support/terminal
consequences also pass. They do not provide a full support stopping rule.

The all-formal extension is justified separately in
`FORMAL_SHEAR_AND_POSITIVE_SLICES.md`, by an explicit common completion;
it should not be inferred merely by substituting into an arbitrary formal
Laurent series.

## 1. The high transverse path lift

Let `k` be frozen, retaining the full lattice. The Lie ideal consisting of
positive roots with nonzero k-coordinate gives the old scattering diagram
as a quotient. This is the familiar freezing quotient of Qin, Lemma 5.1.

Fix a finite root truncation K and a compact generic old path gamma from
the positive old chamber. Translate it by A f_k, with A sufficiently
positive. For every surviving new wall normal n with n_k>0,

    <n,gamma(t)+A f_k> > 0

on the whole path. There are only finitely many relevant walls, so one A
works. The path therefore crosses no new-root wall. Its product in the
large diagram equals its product in the quotient diagram. The quotient is
equivalent to the old diagram, whose wall construction is invariant under
translation by f_k. Thus this product equals the old product along gamma.

This formulation only needs equivalence of the quotient diagram. It does
not require that a particular fragmented representative of the large
diagram literally contain cylindrical old walls. Choose the starting
k-coordinate positive; the lift from that start stays in the full positive
chamber and introduces no extra transport.

If the initial expression f is a large theta function, its expression at
the lifted endpoint is positive. For any chosen monomial coefficient, a
finite K suffices, and so the corresponding old-chart coefficient is
positive. Full charge-map injectivity ensures this finite determination:
from each fixed initial monomial there is at most one big-root degree
reaching a specified target monomial. No single height A for all orders is
asserted.

## 2. Completed inversion followed by positivity proves finiteness

For a finite Laurent f, partition its monomial support by cosets of the
old root lattice. In each coset subtract coordinatewise lower bounds on
the root coordinates. The sector becomes `x^h P(z_old)` with P finite
and nonnegative root exponents. The old theta family in that sector is
unitriangular with respect to root degree:

    theta_(h+p*q) = x^h z^q (1 + higher old-root degrees).

Recursive triangular inversion therefore gives a unique integral theta
expansion in the old completion. Every coefficient is determined by a
finite root box. Old path-ordered products are continuous in this
completion, since all their corrections have positive old-root degree.

Mandel's coefficient extraction at a generic point sufficiently close to
the target label then makes each expansion coefficient nonnegative. The
lift may be translated far in the frozen direction because old charts
are invariant in that direction. Negative k-coordinates of the label do
not obstruct detection.

Now every occurring theta contributes its distinct positive leading
monomial to f. Hence its label belongs to the finite support of f. There
are only finitely many such labels, and every monomial of every occurring
theta also belongs to the support of f. Each constituent is therefore
finite. Finiteness is deduced after positivity, not assumed through an
upper-cluster-algebra spanning theorem.

## 3. Source-leaf comparison and full rank

Replace the principal coefficient y_i by a new mutable a. Add frozen u,v
and take

    B_(a,i)=1, B_(i,a)=-1,
    B_(u,a)=1, B_(v,a)=-1.

All other new-to-old entries vanish. The new mutable a is a source in the
row convention used by this project, and the extended theta label has
a-coordinate zero. The already independently reviewed source-face theorem
in `../source_face_round4/SOURCE_FACE_AND_CORE_RETRACTION.md`, Section 2,
therefore gives root degree p_a=0. Its proof is the coefficient-preserving
GHKK mutation law, followed by charge nonnegativity. This avoids invoking
the stronger and still unproved outgoing-only product-of-binomial bound.

The zero-a-degree freezing theorem identifies the entire theta expression
with the old theta_g with y_i=a. This works for every formal old label,
and immediately for every finite old theta.

The extended charge map is injective. Its matrix has an invertible
(n+1)-minor using the n−1 old principal frozen rows j!=i, the mutable
row a for old column i, and the frozen row u for column a. Thus the
completion and detection arguments apply to the actual leaf seed.

## 4. Exact mutation and specialization

Mutation at a gives

    a a' = u+v x_i.

The old mutable block is unchanged. In the remaining mutable columns,
the new frozen rows are

    row(u)=e_i^T, row(v)=0, row(a')=-e_i^T.

The other principal frozen rows remain unchanged. After freezing a', the
old i-th principal root monomial is `(u/a')x^(B e_i)`. The variable v is
independent of all old root monomials.

Positive freezing applies to the mutated large theta. Extracting the
coefficient of v^r preserves positivity, because every old theta has one
fixed frozen v-power. Setting a'=1 preserves positivity and identifies
the remaining theta functions with the original principal family, now
with y_i=u. These operations can also be applied chartwise before theta
inversion: v-coefficient extraction commutes with all old transports,
and so does a'=1. The remaining old principal rows retain full rank, so
specialization does not create an infinite sum for one coefficient.

Taylor expansion now gives exactly

    [v^r] theta_g(y_i=u+v x_i)
      = x_i^r/r! partial_(y_i)^r theta_g.

This is a positive theta expansion with nonnegative polynomial frozen
multipliers. Negative frozen powers cannot occur: their positive leading
monomials would occur in the displayed polynomial, whose frozen powers
are nonnegative. Mixed divided powers follow by composition and the
ordinary positive Leibniz rule.

## 5. Valued data

If D symmetrizes B, set D_a=D_i and retain the two mutable leaf entries
1 and -1. Then `D_a B_(a,i)=-D_i B_(i,a)`, and all other new mutable
pairings are zero. The enlarged mutable matrix is skew-symmetrizable.
The exchange relation, source cap and coefficient specializations are
unchanged. No square root of a symmetrizer, folding multiplicity, or
division of the operator R_i is introduced.

## 6. Residual support conclusions

For multi-index r>=0, set h=g+(I+B)r. Direct differentiation gives

    R^[r] theta_g
      = x^h sum_(p>=0) binom(p+r,r) a_g(p+r) z^p.

Its unshifted theta_h coefficient is a_g(r), by the constant root term.
All other terms are nonnegative, so

    binom(p+r,r) a_g(p+r) >= a_g(r) a_h(p).

Thus a_g(r)>0 implies `r+Supp(F_h) subset Supp(F_g)`. If r is a
coordinatewise maximal support point of a finite F_g, then F_h=1.
Since `a_h(e_i)=[-h_i]_+`, this gives h>=0. If some h_i<0,

    (r_i+1) a_g(r+e_i) >= (-h_i) a_g(r)>0.

These exact statements do not imply a predecessor for an arbitrary
supported point, nor completeness of the vacuum-only firing graph.

## 7. Primary-source comparison

- Mandel, *Theta bases are atomic*, arXiv:1605.03202v2: the entire proof
  of Theorem 1 was read. It supplies the completed scattering-atlas
  coefficient detector. It does not replace the scattering atlas by the
  cluster atlas.
- Qin, *Applications of the freezing operators on cluster algebras*,
  arXiv:2407.03186v1, Sections 5.1 and 6.3–6.4: freezing quotients,
  large-shift disappearance of the frozen degree, and localization are
  established mechanisms. Positive branching of a finite theta can also
  be reconstructed by multiplying by a sufficiently large power of the
  newly frozen cluster variable, applying strong positivity, and using
  the bounded support in the proof of Proposition 6.19. Freezing itself
  is not a novelty claim here.
- Fei, arXiv:2309.08326v4, November 11, 2026: the optimized frozen-root
  derivations and their upper-algebra invariance have explicit QP
  hypotheses. Theta BK-biperfectness is still Conjecture 8.14 in that
  version. Positive divided powers on theta functions are different from
  the perfectness assertion with a distinguished crystal successor and
  a strict string-degree remainder. The latter is not proved here.

No Li–Pan theorem is an input. Historical priority for the shear and
residual inequalities is not asserted from the absence of a search hit.
