# Route and computation log

## 2026-11-13 23:45--2026-11-14 00:15 UTC

### Positive freezing and coefficient shear

- **Question:** Does the high transverse lift prove theta-positive
  freezing without an upper=middle theorem?
- **Outcome:** Yes. The finite proof passes independent review; the
  simultaneous-source-leaf construction supplies the missing common
  completion for arbitrary formal labels. Full frozen degrees are retained.
- **Output:** INDEPENDENT_POSITIVE_SHEAR_REVIEW.md and
  FORMAL_SHEAR_AND_POSITIVE_SLICES.md.
- **Novelty correction:** Freezing alone is close to Qin's existing
  localization/shift mechanism. Fei already studies optimized frozen root
  derivations. The new assertion to evaluate is positivity of all theta
  divided-power coefficients, its valued/formal scope, and the explicit
  branch algebras, not existence of the differential operator.

### Positive proper slices as a proposed higher-rank greedy rule

- **Question:** For p>0, write b_i(p)=a_g(p)-S_i(p), with S_i determined by
  lower root degrees and lower-rank theta functions. Does
  a_g(p)=max(0,max_i S_i(p)) hold?
- **Outcome:** No. The exact slice theorem survives, but the equality
  fails even in rank3 and even for an acyclic mutable matrix. Thus the
  positive branch correction cannot be discarded in a greedy construction.
- **Decisive data:**

| B, g, p | a_g(p) | b_i(p) | proposed greedy value |
|---|---:|---|---:|
| B=[[0,2,-2],[-2,0,2],[2,-2,0]], g=(-1,-1,-1), p=(1,1,1) | 7 | (0,0,0) | 7 |
| same B,g, p=(2,2,2) | 23 | (5,5,5) | 18 |
| B=[[0,0,-2],[0,0,1],[2,-1,0]], g=(1,-3,-1), p=(1,1,1) | 8 | (6,2,2) | 6 |
| B=[[0,-6,4],[4,0,-4],[-4,6,0]], D=(2,3,2), g=(2,-2,-3), p=(2,2,2) | 2762 | (2442,787,972) | 1975 |

- **General test:** 322 exact skew/valued matrix-label cases, in ranks3
  and4, all computed slice branch coefficients nonnegative. Twelve cases
  had a positive residual min_i b_i(p). The run stops after this decisive
  mechanism is established; it is not an additional special-case project.
- **Independent plugin verification:** Wolfram Language reimplemented the
  incoming recursion and slice inversion and confirmed all four rows of
  the table. A first Wolfram port incorrectly returned from the inner Do
  in the sign tie-break, causing zero tie signs. This implementation bug
  was diagnosed by comparing every sign for the degree-(1,1,1) box and
  fixed by SelectFirst over the exact tie functionals. The final receipt
  is saved separately and matches Python exactly.
- **Files:** slice_greedy_probe.py/json, slice_greedy_wolfram.wl,
  slice_greedy_wolfram_receipt.json.
- **Next useful mechanism:** The full positive b_i are explicit signed-Q
  coefficients. A maximum of proper-face bounds is insufficient; all
  proposed simplifications must retain these actual branch multiplicities.
  Calling min_i b_i a new invariant would merely restate the identity, so
  no such novelty claim is made.

### Arbitrary optimized frozen rows

- **Question:** Does the singleton coefficient shear extend to Fei's
  optimized frozen monomial derivative?
- **Outcome:** Yes, using a source with row c_j>=0 and valued reverse
  exponents m_j=D_a c_j/D_j. The exact substitution is
  z_j -> z_j'(1+w)^(c_j). All formal completions and nonnegative leading
  frozen powers are checked in OPTIMIZED_FROZEN_THETA_POSITIVITY.md.
- **Restriction:** Initial y exponent ell>=0 is required. Negative
  frozen powers are not silently included. Multiple optimized rows give
  commuting theta-positive shears.

### Top divided derivative

- **Question:** Is the highest nonzero R_i^[N] theta_g a single theta
  with coefficient one?
- **Test:** 421 nonzero top divided derivatives from random rank3
  acyclic matrices and labels. Input Laurent polynomials were complete:
  mutating sources once in topological order supplies a proved finite
  box, via the source cap at each step. Every tested top derivative had
  exactly one branch of coefficient one.
- **Status:** Evidence only. This is stronger than positivity. The
  source-leaf proof turns it into a highest slice at a sink, to which the
  source cap cannot be applied. It is not a proof of BK-perfectness.
- **Files:** top_derivative_probe.py/json. No theorem is imported from
  this experiment.

### Monic leaf algebra and Schur marking

- **Question:** Is the two-polynomial leaf elimination correct, including
  r=0, signs, saturation and collisions?
- **Outcome:** PASS. It is an isomorphism of coefficient rings, and the
  old-leaf resultant becomes a power of T. No discriminant saturation.
- **Constructive next step:** Each marking factor is a finite free
  universal factorization algebra of rank binom(r+q,r), with a rectangle
  Schur basis. Thus the leaf variables become explicit finite Schur/Pieri
  multiplication matrices; coupling the old row equations is a finite
  module presentation. This is written in SCHUR_MARKING_MODEL.md.
- **Limit:** The coupled quotient need not remain free. One cannot count
  all rectangle partitions without imposing the equations and saturation.

### Literature refresh: exact primary interfaces

1. Mandel, arXiv:1605.03202v2: whole three-page paper read. Its
   scattering-atlas coefficient detector is used; cluster-atlas atomicity
   is not substituted for it.
2. Qin, arXiv:2407.03186v1: §5.1 freezing quotient and §6 localization
   interface checked. Freezing by itself is not a priority claim.
3. Fei, arXiv:2309.08326v4, 11 Nov2026: §8.1 formula(8.1) and Prop8.1
   already give the root derivative and its upper-algebra/local-nilpotence
   properties with hypotheses. Conj8.14 keeps theta BK-biperfectness
   conjectural. Used as a novelty comparator, not as proof input.
4. Laksov--Thorup, 2008 preprint/2009 publication, and Gatto--Santiago,
   arXiv:math/0702759v1: the latter's primary §3/§4 was read and supplies
   the universal factorization/Schur presentation. Recent crawl labels
   on the former are not interpreted as 2026 publication dates.
5. Fei, arXiv:2510.01615v4, header 3 Nov2026: primary §8.3 read.
   Cor8.11 needs a rigid normal, and its final genericity statement needs
   extended-reachability of e^+. Remark8.13 extends facets to faces.
   The theta question is **Question8.14**, not 8.13. A positive sum of
   lower-rank theta slices is not automatically its desired single
   projected object. No theorem of this recent manuscript is assumed.

### Strict valuation certificates for theta faces

- **Question:** Can a genuine single-theta face formula be proved with
  explicit input instead of assuming Fei's requested projection theorem?
- **Outcome:** Yes under a checkable mutation certificate. Every exchange
  must have unequal valuations, and the final root valuations must be
  nonnegative. Each initial mutation is then unimodular monomial;
  root-zero freezing at the endpoint gives one lower-rank theta.
- **Output:** CERTIFIED_THETA_FACE_REDUCTION.md, including full frozen
  label updates, integral monomial shift, and the exact F-face map.
- **Limit:** Existence of the certificate for every relevant normal is
  not proved. Tied exchanges cannot be replaced by one term; after the
  final cone is reached they can be retained as ordinary mutations
  inside the reduced theta seed.
- **Novelty precision after primary GHKK check:** In arXiv:1411.1394v2,
  Definition9.1 and Lemma9.3 identify the final nonnegative-root condition
  exactly with an optimized seed; existence is dual cluster-complex
  membership. Proposition9.7 already gives no cancellation at minimal
  valuation. Strictness of the supplied path is an additional condition
  used only to obtain a concrete unimodular monomial map. The formula is
  therefore an explicit freezing/initial-form interface to established
  GHKK structure, not a new general optimized-seed theorem.

