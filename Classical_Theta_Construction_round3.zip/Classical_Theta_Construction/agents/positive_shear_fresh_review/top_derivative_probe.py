"""Top divided derivatives, with proved acyclic source bounds.

For the acyclic orientation B_ij>=0 when i<j, mutate sources in the order
0,...,n-1.  The source cap bounds each original root coordinate before it
is mutated.  Hence the computed input polynomial below is complete.
"""
import json,random,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from incoming_recursion import IncomingSchur,box,le,sub

def acyclic_cap(B,g):
    b=[row[:] for row in B]; h=list(g); cap=[]
    for k in range(len(g)):
        assert all(b[k][j]>=0 for j in range(len(g)))
        t=max(-h[k],0); cap.append(t)
        for j in range(len(g)):
            if j!=k:h[j]+=b[j][k]*t
        h[k]=-h[k]
        for j in range(len(g)):
            b[k][j]=-b[k][j];b[j][k]=-b[j][k]
    return tuple(cap)

def top_branches(R,g,F,cap,i):
    N=max(p[i] for p in F)
    h=tuple(g[j]+N*(R.B[j][i]+(i==j)) for j in range(R.n))
    cut=tuple(0 if j==i else cap[j] for j in range(R.n))
    cs={};hs={}
    for q in box(cut):
        p=list(q);p[i]=N;v=F.get(tuple(p),0)
        for r,c in cs.items():
            if le(r,q):v-=c*hs[r].get(sub(q,r),0)
        if v:
            cs[q]=v;hs[q]=R.theta_prefix(R.shift(h,q),sub(cut,q))
    return N,h,cs

def main():
    rng=random.Random(11140005);start=time.time();results=[]
    for step in range(300):
        n=3;B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):B[i][j]=rng.randint(0,2);B[j][i]=-B[i][j]
        g=tuple(rng.randint(-2,2) for _ in range(n));cap=acyclic_cap(B,g)
        size=1
        for a in cap:size*=a+1
        if size>120:continue
        R=IncomingSchur(B);F=R.theta_prefix(g,cap)
        for i in range(n):
            N,h,cs=top_branches(R,g,F,cap,i)
            if not N:continue
            out={'B':B,'g':g,'complete_cap':cap,'i':i,'N':N,'h':h,'branches':[[q,c] for q,c in cs.items()]}
            results.append(out)
            if len(cs)>1 or list(cs.values())!=[1]:
                print(json.dumps(out),flush=True)
                if sum(len(x['branches'])>1 for x in results)>=5:break
        if sum(len(x['branches'])>1 for x in results)>=5:break
    summary={'cases':len(results),'multi':sum(len(x['branches'])>1 for x in results),'seconds':time.time()-start,'results':results}
    Path(__file__).with_suffix('.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='results'}))
if __name__=='__main__':main()
