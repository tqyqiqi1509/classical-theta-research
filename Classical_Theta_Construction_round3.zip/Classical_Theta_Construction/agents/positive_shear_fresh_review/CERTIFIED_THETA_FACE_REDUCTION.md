# A certified mutation and freezing formula for theta faces

2026-11-14. Classical skew-symmetric and skew-symmetrizable principal
cluster data. This is an explicit consequence of mutation covariance and
root-degree freezing. It does not assert that every facet normal has the
certificate below, or that Fei's extended-reachability hypotheses imply
such a certificate.

## 1. Input and the exact certificate

Let B be the initial mutable matrix and let

    Btilde=[B;I],       theta_g=x^g F_g(z),
    z_j=y_j x^(B e_j),

be a finite theta function. The full initial leading exponent is
m=(g,0) in the lattice of the x and y variables. For an integral weight
w on root degrees, the desired face maximizes w.p over Supp(F_g).

Give the initial Laurent variables the additive valuation

    u(x_j)=0,       u(y_j)=-w_j.                    (1)

Take a finite proposed mutation sequence k_1,...,k_s. At every step use
the full current extended matrix and the full current valuation vector.
If mutating k, write the two exchange monomials as

    M_+=product_j X_j^([Btilde_(j,k)]_+),
    M_-=product_j X_j^([-Btilde_(j,k)]_+),
    alpha_+=u(M_+), alpha_-=u(M_-).

The first certificate condition is

    alpha_+ != alpha_- at every step.              (2)

If epsilon is the sign selecting the smaller alpha, update

    u'_k=min(alpha_+,alpha_-)-u_k,   u'_j=u_j (j!=k). (3)

Mutate the exchange matrix in the usual way. At the final seed define
the root valuations

    beta_j=u_final . Btilde_final e_j.

The second condition is

    beta_j>=0 for every mutable j.                 (4)

Let J={j:beta_j=0}. All operations in (1)--(4) are exact finite integer
calculations involving B,w and the supplied sequence. No theta
coefficients, Newton polytope, or unknown support bound is used to check
the certificate.

## 2. The unimodular monomial map carried by the certificate

At a strict mutation k, define a full exponent map T_k from the new
Laurent lattice to the old one by

    T_k(e'_j)=e_j (j!=k),
    T_k(e'_k)=-e_k+sum_j [epsilon Btilde_(j,k)]_+ e_j, (5)

where epsilon=+1 if M_+ has lower valuation and epsilon=-1 otherwise.
The determinant is -1 because Btilde_(k,k)=0. Thus (5) is an integral
unimodular monomial isomorphism. Let T be their composition, from the
final full lattice to the initial one.

Track the theta leading exponent m along the same mutations using
mutation covariance. In these conventions its tropical update is

    m'_k=-m_k,
    m'_j=m_j+[Btilde_(j,k)]_+ m_k
                  -Btilde_(j,k) min(m_k,0),  j!=k.  (6)

This update is applied also to frozen coordinates; those frozen
coordinates must not be discarded. Denote the final exponent by m'.

## 3. The face theorem

Let theta_(m')^J denote the theta function in the seed obtained by
freezing all final mutable vertices outside J, with the same full leading
exponent m'. Then the initial Laurent face of theta_g for valuation (1)
is exactly

    in_u(theta_g)=T(theta_(m')^J).                  (7)

Here T means substitution by the monomial map (5), not the tropical map
on labels. In particular, the face is a single lower-rank theta function
up to the explicitly recorded monomial and variable changes. All its
coefficients are positive integers, and its distinguished constant
coefficient is one.

### Proof

At a strict exchange, the initial form of X'_k is M_epsilon/X_k. This
is exactly (5). Distinct Laurent monomials of the new chart have distinct
initial monomials because T_k is unimodular. Consequently their leading
terms cannot cancel after this substitution. For every Laurent polynomial
f in the new chart,

    in_u(f)=T_k(in_(u')(f)).                       (8)

Theta mutation covariance identifies the Laurent polynomials along the
sequence, so iterating (8) transports the required face to the final
seed. There the theta expansion is

    X^(m') sum_(p>=0) a_(m')(p) (z_final)^p.

Condition (4) says that its minimum valuation is u_final.m'. A term has
this value precisely when p_j=0 for all j outside J. Root-degree
freezing identifies that zero-degree subseries with theta_(m')^J. This
proves (7). Finiteness is inherited from the original finite theta and
the mutation charts; the frozen subseries is finite as well.

The proof uses only the classical mutation rules, injective principal
degree bookkeeping, and the already reviewed freezing theorem. The
symmetrizer does not affect this valuation argument, so it applies
unchanged to skew-symmetrizable data.

## 4. An explicit formula for the original F-polynomial face

The original principal root map Btilde is injective. Matrix mutation
implies that T carries the final root lattice to the initial root
lattice. Therefore, for j in J, define the integral columns A_j by

    Btilde A_j=T Btilde_final e_j.                 (9)

The global monomial shift p_0 is determined by

    Btilde p_0=T m'-m.                             (10)

Both are particularly easy to calculate: take the frozen y rows of the
right sides, because the initial frozen block is I. The full mutable
rows provide an exact consistency check. Equation (7) guarantees
p_0>=0; it is the original root exponent of the surviving straight
leading monomial.

Writing g'_J for the mutable-J entries of m' and B'_JJ for the final
principal submatrix, the face formula becomes

    F_g|_(max w)
      =z^(p_0) F^(B'_JJ)_(g'_J)((z^(A_j))_(j in J)). (11)

Individual columns A_j may have negative entries. The final expression
nevertheless has the nonnegative support of the original face, by (7).
The monomial map is injective on the retained root lattice. Thus (11)
retains coefficients exactly, including multiplicities.

If J is empty, (11) is one monomial with coefficient one. If J is
nonempty, its Newton polytope is the explicit integral affine image

    p_0+A Newt(F^(B'_JJ)_(g'_J)).                  (12)

The same construction can be repeated on the reduced seed whenever a
further certified normal is supplied; it gives a genuine rank reduction
for a flag of faces.

## 5. What equality steps do and do not permit

If alpha_+=alpha_-, the initial exchange is the full binomial mutation,
not a monomial map. It must not be silently replaced by either summand.
The theorem above deliberately requires strictness at all steps used
in T.

Once (4) has been reached, mutations at vertices k in J have equal
exchange valuations and remain inside the reduced ice seed. Mutation
commutes with freezing the vertices outside J, so these equality steps
are ordinary changes of seed for the same lower-rank theta in (7).
They may be appended without losing the single-theta statement. They
are not, however, additional monomial changes of the original Newton
polytope. Interspersed equality steps before reaching (4) require a
separate reduced-atlas argument and are not covered here.

## 6. Fei interface and limits of the claim

Fei, *On the Orthogonal Projections*, arXiv:2510.01615v4, 3 Nov 2026,
§8.3, Corollary8.11, proves a generic F-polynomial face reduction for
rigid normal presentations; the final genericity statement additionally
assumes that e^+ is extended-reachable. Remark8.13 extends the formulation
from facets to faces. Question8.14 asks for the theta analogue.

Equation (11) is a direct theta-face statement when the explicit strict
valuation certificate (2)--(4) is present. No identification of this
certificate with Fei's categorical extended-reachability is proved here.
We therefore regard it as a concrete interface and a conditional
reachable-normal mechanism, not a solution of Question8.14 in its stated
generality. The proof is independent of the representation-theoretic
theorems of that 2026 manuscript.

Primary source checked for the problem and hypotheses:
https://arxiv.org/html/2510.01615v4 , §8.3.

## 7. Exact relation to the established optimized-seed condition

In GHKK, *Canonical bases for cluster algebras*, arXiv:1411.1394v2,
Definition9.1 and Lemma9.3, a seed is optimized for a valuation precisely
when its initial scattering monomials are regular along the corresponding
boundary divisor. In the present coordinates this says exactly

    u_final . Btilde_final e_j >= 0 for every j,

which is condition (4). Nonprimitive valuations may first be divided by
their positive common factor, with no change in any inequality.
Lemma9.3(2) characterizes existence of an optimized seed by membership
of the corresponding point, under GHKK's i identification, in the dual
cluster complex. Thus the endpoint requirement is established structure,
not a new sufficient condition invented here.

The strictness condition (2) is additional: it makes every associated
graded change of chart the explicit unimodular monomial map (5). We do
not assert that any optimized valuation automatically admits a strict
mutation path from the specified initial seed. A path encountering a
tied exchange needs the full binomial initial mutation.

GHKK Proposition9.7 already proves that theta functions do not cancel
at their lowest valuation when an optimized seed exists; its proof uses
the same nonnegative scattering-root cone. Combining that known cone
argument with root-degree freezing gives the concrete reduced-theta
identity (7), and the bookkeeping in (9)--(11) makes the face and its
support value computable from the supplied certificate. In particular,

    max_(p in Supp F_g) w.p = w.p_0

is obtained without enumerating the F-polynomial coefficients. This is
an explicit derived interface to the optimized-seed theory. It is not
claimed as a new general theorem that every theta normal is optimized.

Primary version checked: https://arxiv.org/pdf/1411.1394v2 , pp103--105
of the printed paper. Earlier local manuscript versions number these
optimized-seed statements in §10 instead of §9.


