ClearAll[boxTheta, leTheta, shiftTheta, signTheta, incomingTheta, prefixTheta, getTheta, sliceTheta];
boxTheta[p_List] := SortBy[Tuples[Range[0,#]& /@ p], {Total[#]&, Identity}];
leTheta[p_List,q_List] := And @@ Thread[p<=q];
shiftTheta[b_List,m_List,q_List] := m+b.q;
signTheta[b_List,d_List,a_List,q_List] := Module[{z,r,vals},
 z=(d*(b.a)).q; If[z!=0,Return[Sign[z]]];
 r=First[FirstPosition[a,x_/;x!=0]];
 vals=Table[a[[r]]q[[j]]-a[[j]]q[[r]],{j,Length[a]}];
 Sign[SelectFirst[vals,#!=0&,0]]];
incomingTheta[b_List,d_List,a_List,m_List] := incomingTheta[b,d,a,m] = Module[{supp,s,c,v},
 If[Total[a]==0,Return[1]];
 supp=Flatten[Position[a,x_/;x>0]];
 If[Length[supp]==1,Return[Binomial[-m[[First[supp]]],a[[First[supp]]]]]];
 s=Select[boxTheta[a],Total[#]>0 && #!=a && signTheta[b,d,a,#]>0&];
 If[s=={},Return[0]];
 c=Table[If[leTheta[s[[j]],s[[i]]],incomingTheta[b,d,s[[i]]-s[[j]],shiftTheta[b,m,s[[j]]]],0],{i,Length[s]},{j,Length[s]}];
 v=LinearSolve[c,incomingTheta[b,d,#,m]& /@ s];
 Sum[incomingTheta[b,d,a-s[[i]],shiftTheta[b,m,s[[i]]]]v[[i]],{i,Length[s]}]];
getTheta[f_Association,p_List] := Lookup[f,ToString[p,InputForm],0];
prefixTheta[b_List,d_List,g_List,cap_List] := Module[{js,av,p,mp,is,c,t},
 js=boxTheta[cap];av=ConstantArray[0,Length[js]];av[[1]]=1;
 Do[p=js[[l]];mp=shiftTheta[b,g,p];
 is=Select[Range[l],leTheta[js[[#]],p] && (#==l || (d*mp).(p-js[[#]])<0)&];
 c=Table[If[leTheta[js[[is[[j]]]],js[[is[[i]]]]],incomingTheta[b,d,js[[is[[i]]]]-js[[is[[j]]]],shiftTheta[b,g,js[[is[[j]]]]]],0],{i,Length[is]},{j,Length[is]}];
 t=Last[Inverse[c]];
 av[[l]]=-Sum[t[[j]]av[[is[[j]]]],{j,Length[is]-1}],{l,2,Length[js]}];
 AssociationThread[ToString[#,InputForm]& /@ js,av]];
sliceTheta[b_List,d_List,g_List,p_List] := Module[{n=Length[g],f,answers={},j,bb,dd,qs,bs,q,r,h,full,v},
 f=prefixTheta[b,d,g,p];
 Do[j=DeleteCases[Range[n],i];bb=b[[j,j]];dd=d[[j]];qs=boxTheta[p[[j]]];bs=<||>;
 Do[full=Insert[q,p[[i]],i];v=getTheta[f,full];
 Do[If[r==q,Break[]];If[leTheta[r,q],h=g[[j]]+b[[j,i]]p[[i]]+bb.r;
 v-=getTheta[bs,r]getTheta[prefixTheta[bb,dd,h,q-r],q-r]],{r,qs}];
 AssociateTo[bs,ToString[q,InputForm]->v],{q,qs}];
 AppendTo[answers,getTheta[bs,p[[j]]]],{i,n}];
 <|"B"->b,"D"->d,"g"->g,"p"->p,"coefficient"->getTheta[f,p],"branch"->answers,
   "maxGreedy"->getTheta[f,p]-Min[answers],"remainder"->Min[answers]|>];
cases={
 {{{0,2,-2},{-2,0,2},{2,-2,0}},{1,1,1},{-1,-1,-1},{1,1,1}},
 {{{0,2,-2},{-2,0,2},{2,-2,0}},{1,1,1},{-1,-1,-1},{2,2,2}},
 {{{0,0,-2},{0,0,1},{2,-1,0}},{1,1,1},{1,-3,-1},{1,1,1}},
 {{{0,-6,4},{4,0,-4},{-4,6,0}},{2,3,2},{2,-2,-3},{2,2,2}}
};
sliceTheta@@@cases
