# Formal coefficient shears and positive lower-rank theta slices

2026-11-13. New deductions from the independently reviewed positive-freezing
mechanism. Classical skew-symmetric and skew-symmetrizable data. These
statements retain principal root degrees throughout.

## 1. A simultaneous source-leaf construction

Let B be n by n and D symmetrize it. Replace the original principal frozen
variables y_i by new mutable variables a_i. On mutable variables (x,a), use

    B_ext = [[B,-I],[I,0]],       D_ext=diag(D,D).

For every i add frozen u_i,v_i with entries

    B_(u_i,a_i)=1,       B_(v_i,a_i)=-1,

and all other new frozen entries zero. Each a_i is a source in the row
convention of this project. The extended theta label (g,0) has no a-root
degree, by the reviewed source cap. Freezing all a_i therefore identifies
its expression with theta_g with y_i=a_i. This comparison is valid formally
and does not assume finite Laurent support.

The leaf mutations commute. Mutating all a_i gives

    a_i a_i' = u_i+v_i x_i.

After freezing a_i', the old mutable block is still B. The frozen rows at
old mutable columns are

    row(u_i)=e_i^T, row(v_i)=0, row(a_i')=-e_i^T.

Thus the old root monomial in the new seed is

    z_i'=(u_i/a_i')x^(B e_i),

while the new mutable leaf-root monomial is

    w_i=v_i x_i/u_i.

The source expression transforms by the explicit identity

    z_i = z_i'(1+w_i).

In particular its formal series in the mutated root coordinates is

    x^g sum_p a_g(p) (z')^p product_i(1+w_i)^(p_i).    (1.1)

This is a valid continuous formal substitution: every old degree p gives
only finitely many choices 0<=k<=p, and the total new degree is |p|+|k|.
Mutation covariance identifies (1.1) with the corresponding large theta.

## 2. The common completion after freezing

Set s=p-k. On the support of (1.1), s,k are nonnegative. The old-plus-v
degree is |s|+|k|=|p|, whereas the large mutated root degree is
|p|+|k|=|s|+2|k|. These two filtrations are equivalent, with a factor at
most two. This gives a concrete common completion; no substitution of an
unbounded Laurent series into an unrelated completion is being made.

For a fixed k, collecting v^k in (1.1) gives

    v^k (a')^(-k) x^(g+(I+B)k)
      sum_(s>=0) binom(s+k,k) a_g(s+k) (z')^s.        (2.1)

The factor preceding the sum is one Laurent monomial. Thus each fixed
v-degree is a single old-root completed sector, bounded below in all old
root coordinates. Old path-ordered products preserve this sector and do
not change k, because every v_i has zero entries in all old mutable
columns.

The high transverse lift proving positive freezing applies to every fixed
coefficient in (2.1). Its needed large-root cutoff is finite by the
filtration comparison. Completed triangular inversion and the scattering
coefficient detector therefore give a nonnegative old-theta expansion in
each sector, including when the original theta is formal and infinite.

Setting all a_i'=1 is coefficientwise well-defined: the remaining u_i are
independent principal coefficients, so each old-root degree is still
distinguished. This proves for every formal integral label g that

    theta_g(x,y+t*x)

has a coefficientwise nonnegative theta expansion in the t variables.
Equivalently, every mixed divided power

    R^[k]=product_i x_i^(k_i)/k_i! partial_(y_i)^(k_i)

is theta-positive. The initial series of (2.1) has no negative old root
degree, so its expansion has the form

    R^[k] theta_g
      = sum_(q>=0) d_(g;k,q) y^q
          theta_(g+(I+B)k+Bq),       d_(g;k,q)>=0.     (2.2)

All d are nonnegative integers. Every fixed coefficient is a finite sum.
If theta_g is finite, then its whole shear is polynomial in t, all
expressions in (2.2) are finite, and every occurring theta is finite.

## 3. A positive additive-group action on the finite middle algebra

Let M^+ be the Z-algebra spanned by the finite principal theta functions
with polynomial frozen multipliers:

    M^+ = direct sum_(g in Theta) Z[y_1,...,y_n] theta_g.

Principal strong positivity makes this an algebra. The explicit shear
preserves M^+[t_1,...,t_n]. Its value at t=0 is the identity, and composition
adds the parameters. Hence it is a Ga^n coaction on M^+ (over Z), with
commuting locally nilpotent derivations R_i. Its matrix in the full theta
basis has nonnegative integer coefficients in the t variables.

This statement concerns polynomial frozen coefficients. It does not assert
that a translation preserves the algebra in which arbitrary inverse powers
of y_i are allowed as regular generators. No theta BK-perfectness or
distinguished one-arrow crystal successor is asserted.

## 4. Positive slices in one deleted mutable direction

Fix i and write J=[n]\{i}. For every k>=0, there are unique nonnegative
integers b_(k,q), q in N^J, such that

    [z_i^k] F_g^B(z)
      = sum_(q>=0) b_(k,q) z_J^q
          F^(B_JJ)_(g_J+B_Ji k+B_JJ q)(z_J).          (4.1)

The identity is formal and coefficientwise finite. Its leading coefficient
is

    b_(k,0)=a_g(k e_i)=binom([-g_i]_+,k).             (4.2)

For k=0, ordinary zero-degree freezing gives b_(0,0)=1 and all other
b_(0,q)=0. For k>0, positive branching generally has additional terms.

### Proof with frozen powers retained

Freeze mutable i in the original principal seed. Its variable x_i becomes
frozen, and the original principal coefficient y_i now has zero entries
in every remaining mutable column. Extracting the y_i^k sector therefore
commutes with every old scattering transport. Positive freezing makes
that entire sector scattering-positive for the rank-|J| seed.

Before any specialization, the normalized sector is

    x^(g+B e_i k) sum_(p in N^J) a_g(k e_i+p) z_J^p.

Its old-theta expansion is supported at full leading monomials

    y_i^k y_J^q x_i^(g_i+B_iJ q)
      x_J^(g_J+B_Ji k+B_JJ q).

In these old theta functions the principal roots are
`y_j x_i^(B_ij) x_J^(B_JJ e_j)` for j in J. Factoring out the displayed
leading monomial yields exactly (4.1). One may set x_i=1 afterwards to
identify the ordinary principal coefficient family for B_JJ. The remaining
y_J keep the old charge map injective; no collision ambiguity results.

The completed detector gives b>=0; triangular inversion gives uniqueness.
If F_g is finite, the same leading-monomial positivity argument as in the
freezing theorem makes the branching finite and each constituent finite.

## 5. Explicit coefficient algebras for the branching coefficients

The b_(k,q) in (4.1) do not require an oracle for theta expansion. They can
be computed by the project's already proved signed-endpoint Q algebra.
Here is an effective endpoint construction.

Put p=k e_i+q, m=g+Bp, K=|p|. The case p=0 has b=1. Work in normalized
endpoint coordinates a, so the physical covector is U=Da. Choose a_J
in a sufficiently small rational sign germ of m_J. Concretely, choose
positive rational v_J and

    a_J=m_J+epsilon v_J,
    0<epsilon<1/(1+K D_max max_j v_j).

For every nonzero old root alpha with |alpha|<=K, this has

    sign(alpha^T D_J a_J)=sign(alpha^T D_J m_J)

whenever the right side is nonzero. When it is zero, the positive
perturbation makes the left side positive. Further small generic rational
perturbations preserve all these finite sign constraints.

Why this detects the target coefficient: a broken line in the old diagram
whose final monomial is x^m has final mutable-J velocity -m_J. Its last
segment traced backward is a_J+t m_J, t>=0. It cannot meet an old wall
alpha^perp: if alpha^T Dm is nonzero both terms have the same sign; if it
is zero the segment is parallel and its endpoint is off the wall. Thus
there is no nontrivial old broken line with that final monomial. Only the
straight old theta with that leading label contributes to it.

Choose the frozen coordinate a_i positive and so large that

    D_i a_i > K D_max max(1,max_j |a_j|)+1.            (5.1)

The straight old path from a positive old endpoint to a_J, lifted at this
height, stays strictly positive on every new normal alpha with alpha_i>0
and |alpha|<=K. Therefore its large-diagram product agrees through degree
K with the old product. The coefficient detected above is precisely the
large theta coefficient c_(g,p)(Da) at that endpoint.

Finally choose a rational point within these open conditions avoiding the
finite cut and rank hyperplanes in
`../dyck_flow_round2/SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md`, Section 1.
They are proper rational hyperplanes, so exact rational enumeration
terminates. A positive common scaling makes all a_j integral. Scaling
preserves every detector sign and every wall-crossing condition.

The already reviewed signed coefficient formula now gives

    b_(k,q) = dim_Q Q(B,g,p;Da).                     (5.2)

Here Q is the monic-Q remainder algebra, saturated by T times the actual
arrow boundary and then reduced modulo T. Same-color discriminants are
not saturated. The explicit formula reads only B,D,g,k,q and rational
polynomial operations. Its correctness uses the proved global
Gale-to-theta identification; no unknown branch coefficient is used to
choose the endpoint or build the algebra.

## 6. Newton slices and the genuine remaining stopping issue

If F_g is finite, (4.1) gives an exact positive decomposition of the
integer-height coefficient slice. Its Newton polytope is

    Newt([z_i^k]F_g)
      = conv union_(q:b_(k,q)>0)
          (q+Newt(F^(B_JJ)_(g_J+B_Ji k+B_JJ q))).     (6.1)

For an arbitrary fixed coefficient p, (4.1) only uses q<=p_J. It therefore
gives a finite positive rank-reducing recursion, terminating in rank-one
binomial theta coefficients. Unlike a source top-face formula, the slice
can contain many lower-rank theta functions, with algebraically explicit
positive branching multiplicities.

This does not yet determine how many slice heights k or branching labels
q occur for an input known only to be a finite theta label. Formula (5.2)
solves each requested branching coefficient, but supplies no global
support bound. Treating a finite prefix of b as the whole branching set
would reintroduce the original stopping gap.

## Source and novelty qualifications

Qin's root-degree freezing, Mandel's scattering-atlas atomicity, and
classical mutation covariance are established inputs. Positive branching
and its finite large-shift proof are close to Qin's localization mechanism;
the freezing idea itself is not presented as a new theorem of the project.
The explicit simultaneous leaf realization, full formal-completion
argument, mixed residual inequalities, and positive lower-rank slice
formula are the concrete mechanisms developed here. Their historical
priority still requires the recorded broader literature comparison.

In particular, Fei arXiv:2309.08326v4, §8.1, formula (8.1) and
Proposition 8.1, already treats the optimized frozen root derivation
M partial_y and its local nilpotence under his hypotheses. The
differential operator and existence of the additive action themselves
are therefore not claimed as new. The new proof target is theta
positivity of all divided powers, its general formal/valued scope, and
the explicit branch coefficient models. The companion
`OPTIMIZED_FROZEN_THETA_POSITIVITY.md` proves the same positivity for
arbitrary nonnegative optimized frozen rows. None of these statements
claims Fei's theta BK-biperfectness conjecture.
