"""Independent trace test of the remainder/alternant identity.

No global-Gale implementation is imported.  The root-side sign multiplicity
is evaluated by the full character projector on a Groebner monomial basis.
The coefficient side is a separate monic remainder ideal.
"""
from itertools import product, permutations, combinations
from pathlib import Path
from math import factorial
import json, random, time
import sympy as S


def basis(gb):
    if list(gb)==[1]: return []
    if not gb.is_zero_dimensional: raise ValueError('nonfinite fiber')
    leads=[p.LM(order=gb.order).exponents for p in gb.polys]
    bounds=[min(e[i] for e in leads if e[i]>0 and sum(bool(v) for v in e)==1)
            for i in range(len(gb.gens))]
    return [e for e in product(*(range(b) for b in bounds))
            if not any(all(a<=b for a,b in zip(l,e)) for l in leads)]


def mon(e,x): return S.prod(v**a for v,a in zip(x,e))
def parity(p): return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))


def one(ps, seed):
    rng=random.Random(seed); z=S.Symbol('z')
    cc=[S.symbols(f'c{i}_1:{n+1}') for i,n in enumerate(ps)]
    xx=[S.symbols(f'x{i}_1:{n+1}') for i,n in enumerate(ps)]
    cs=tuple(c for row in cc for c in row); xs=tuple(x for row in xx for x in row)
    Q=[z**n+sum(c*z**(n-k-1) for k,c in enumerate(row)) for n,row in zip(ps,cc)]
    cd={cc[i][k-1]:(-1)**k*sum(S.prod(sub) for sub in combinations(xx[i],k))
        for i,n in enumerate(ps) for k in range(1,n+1)}
    m=max(ps)+1
    F=[]
    for i,row in enumerate(cc):
        # Self-dependence and coupling are intentional.  Weighted lower terms
        # have degree <m in root coordinates, making the root fiber finite.
        f=z**m+rng.randint(-3,3)
        f+=sum(rng.randint(-2,2)*c for rr in cc for c in rr)
        f+=z*sum(rng.randint(-2,2)*rr[0] for rr in cc)
        F.append(S.expand(f))
    roots=[S.expand(F[i].subs(cd).subs(z,x)) for i,row in enumerate(xx) for x in row]
    rg=S.groebner(roots,*xs,order='grevlex'); rb=basis(rg)
    rem=[r for i in range(len(ps)) for r in S.Poly(S.rem(F[i],Q[i],z),z).all_coeffs()]
    cg=S.groebner(rem,*cs,order='grevlex'); cb=basis(cg)
    trace_sum=0; trace_terms=[]
    for perms in product(*(list(permutations(range(n))) for n in ps)):
        sub={xx[i][a]:xx[i][b] for i,p in enumerate(perms) for a,b in enumerate(p)}
        sign=S.prod(parity(p) for p in perms); tr=0
        for e in rb:
            img=mon(e,xs).xreplace(sub)
            reduced=rg.reduce(img)[1]
            tr+=S.Poly(reduced,*xs).coeff_monomial(e)
        trace_sum+=sign*tr
        trace_terms.append({'permutations':perms,'sign':int(sign),'trace':int(tr)})
    multiplicity=S.Rational(trace_sum,S.prod(factorial(n) for n in ps))
    result={'p':ps,'seed':seed,'F':[str(f) for f in F],
            'root_length':len(rb),'root_sign_multiplicity':int(multiplicity),
            'remainder_length':len(cb),'trace_terms':trace_terms,
            'pass':multiplicity==len(cb)}
    assert result['pass'],result
    return result


def run():
    start=time.time(); out=[]
    for j,ps in enumerate([[2],[3],[2,1],[2,2]]*3):
        t=time.time();r=one(ps,74501+j);r['seconds']=time.time()-t;out.append(r)
        print(json.dumps({k:r[k] for k in ['p','seed','root_length','root_sign_multiplicity','remainder_length','pass','seconds']}),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps({'results':out,'seconds':time.time()-start},indent=2)+'\n')


if __name__=='__main__':run()
