# Explicit color exponents without hierarchy enumeration

2026-11-13. Classical skew-symmetrizable case. This is a simplification of the input-selection step, not a new theta-identification theorem.

## Statement

Let `n=sum_i p_i>0`, and retain only the active colors `i_1,...,i_s` with `p_i>0`. Put

\[
E=\max\bigl(\{D_i|g_i|:p_i>0\}\cup
  \{D_i|B_{ij}|:p_i p_j>0\}\cup\{0\}\bigr),
\]
\[
A=\max(1,nE),\qquad
C=n!A^n,\qquad H=n(\max_{p_i>0}D_i)C,\qquad K=H+2.
\]

Choose the primitive exponents

\[
a_{i_j}=K^{j-1},\qquad
\mu(e_{i_j})=D_{i_j}a_{i_j},\qquad
\mu(e_0)=-\sum_i p_i\mu(e_i).
\]

This is a valid original-color generic choice for the rank-recession criterion in `../global_gale_adversarial/RANK_GENERICITY_AND_RECESSION.md`. In particular, every hierarchy that is feasible at this covector has its full color image contained in the image of its hierarchy matrix. No hierarchy enumeration or projection-word enumeration is needed to specify the coefficient algebra.

The bound is intentionally coarse. In computations, the smaller exact rank selector is usually much faster because the powers of T in the displayed choice can be enormous.

## Proof

Let `M` be any one of the frame-row-deleted binary hierarchy matrices. It is an integer `n`-by-`n` matrix. Each entry is a sum of at most `n` leaf pairings, each of absolute value at most `E`, so every entry has absolute value at most `A`.

An integer matrix of rank `k<n` has a spanning family for its left kernel whose entries have absolute value at most `k! A^k <= C`. To see this without a denominator assertion, choose `k` independent columns and a nonzero `k`-by-`k` row minor. For each row outside that minor, the usual alternating `(k+1)`-row dependence gives a kernel vector; its entries are signed `k`-by-`k` minors. The coordinate of that outside row is the fixed nonzero minor, so these `n-k` vectors are independent. Every minor has absolute value at most `k! A^k` by the Leibniz formula. For `k=0`, use the coordinate vectors.

Let `W` have entry `D_i` in the row of a clone of color `i` and zero in its other columns. For each of the bounded kernel vectors `l`, the coefficients of the integer row `l^T W` have absolute value at most `H`. If this row is nonzero, then

\[
f_l(z)=\sum_{j=1}^s(l^T W)_j z^{j-1}
\]

is a nonzero integer polynomial whose coefficients are bounded by `H`. It cannot vanish at `z=K=H+2`: if `d` is its highest nonzero degree, its leading term has absolute value at least `K^d`, whereas the sum of all lower terms has absolute value at most

\[
H(1+K+\cdots+K^{d-1})
=H\frac{K^d-1}{K-1}<K^d.
\]

If the selected color covector lies in `im M`, every left-kernel vector annihilates it. The preceding paragraph therefore forces `l^T W=0` for every vector of the kernel basis. Thus `im W` is contained in `im M`, exactly the rank criterion needed by the window theorem. This argument applies to every hierarchy simultaneously because the same entry bound applies to all of them.

The same choice also covers the packet hierarchies arising in fixed-cycle calculations. Expand a packet of charge `k e_i` into `k` unit leaves and insert a same-color binary subtree. Its added columns are zero; each packet row is the sum of the corresponding clone rows. Feasibility of the packet hierarchy lifts to feasibility of the expanded clone hierarchy. The full-color-image inclusion for the expanded matrix then descends by row summation to the packet matrix.

## Practical consequence and scope

The Q-polynomial coefficient ideal is now an entirely explicit construction from the finite integer data `(B,D,g,p)`: the only formerly generic choice can be replaced by the formula above. This does not give a uniform bound on the complete Laurent support of a theta function. Nor does it make the resulting enormous exponent choice computationally optimal.

Common rescaling of `D` changes this coarse choice of exponents but not the theorem identifying the algebra's dimension. One may normalize the symmetrizer to minimize the bound when convenient.
