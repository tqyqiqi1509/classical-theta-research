"""An explicit safe parameter choice requiring no hierarchy enumeration."""
from math import factorial


def explicit_generic_exponents(B,D,g,p):
    active=[i for i,n in enumerate(p) if n]
    n=sum(p)
    if not n:
        return {},{'n':0,'K':2}
    E=max([0]+[D[i]*abs(g[i]) for i in active]+
          [D[i]*abs(B[i][j]) for i in active for j in active])
    A=max(1,n*E)
    C=factorial(n)*A**n
    H=n*max(D[i] for i in active)*C
    K=H+2
    return {i:K**j for j,i in enumerate(active)},dict(n=n,E=E,A=A,C=C,H=H,K=K)


if __name__=='__main__':
    print(explicit_generic_exponents([[0,1],[-1,0]],[1,1],[-2,-1],[1,1]))
