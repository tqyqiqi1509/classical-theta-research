# A one-color factorization and Schur-basis interface

2026-11-13. This is an explanatory and computational interface for the Q-polynomial construction. The underlying factorization algebra and its Grassmannian/Schur description are established algebra; no novelty is claimed for them.

## 1. A direct general lemma

Let `A` be a commutative Q-algebra and `P(z)` a monic polynomial of degree `e`. Let

\[
Q(z)=z^p+c_1z^{p-1}+\cdots+c_p,
\qquad
\operatorname{Fact}_p(P)
=A[c_1,\ldots,c_p]/(\operatorname{coeff}(P\bmod Q)).
\]

For `0<=p<=e`, this is a finite free `A`-module of rank `binomial(e,p)`. A basis is supplied by the Schur polynomials in the roots of `Q` indexed by partitions inside the rectangle with `p` rows and `e-p` columns. For `p>e` the algebra is zero.

There is a short proof using the already reviewed alternant identity. The root algebra is

\[
A[x_1,\ldots,x_p]/(P(x_1),\ldots,P(x_p))
\cong (A[z]/P)^{\otimes p}.
\]

Its sign component is the exterior power `wedge^p(A[z]/P)`, a free module with basis the wedges of distinct powers `z^0,...,z^(e-1)`. Under multiplication by the Vandermonde, those basis vectors correspond to the determinants

\[
\det(x_a^{k_b})_{a,b=1}^p,\qquad
0\le k_1<\cdots<k_p\le e-1.
\]

Dividing by the Vandermonde gives precisely the stated rectangular Schur polynomials. The remainder/alternant lemma identifies this module with `Fact_p(P)`. If `p>e`, the exterior power vanishes, equivalently polynomial division produces a constant nonzero remainder coefficient after reduction to the highest degree.

This also gives a concrete multiplication implementation: represent multiplication by symmetric functions on the exterior power of the companion matrix of `P`. The basis consists of `p`-subsets of `{0,...,e-1}`.

## 2. Application to one color of the theta coefficient equations

Fix a color `i` and regard the coefficients of the other `Q_j` and `T` as parameters. Set

\[
e_i=[-g_i]_++\sum_j[-B_{ij}]_+p_j.
\]

Complete the parameter ring at `T=0` and at the vanishing of all other polynomial coefficients:

\[
A_i=\mathbb Q[[T,c_{j,k}:j\ne i]].
\]

The polynomial `F_i` is independent of the coefficients of `Q_i`, since `B_ii=0`. Modulo the maximal ideal of `A_i`, it is

\[
F_i(z)\equiv -\epsilon_i z^{e_i}.
\]

Formal preparation therefore gives a unique factorization

\[
F_i(z)=U_i(z)P_i(z),
\]

where `U_i` is a unit in `A_i[[z]]` and `P_i` is a monic distinguished polynomial of degree `e_i`. This preparation can be constructed directly by successive approximation: at each parameter-adic order split the error into its terms of `z`-degree below `e_i` and its multiple of `z^(e_i)`, correcting respectively `P_i` and `U_i`.

In the completion at `c_{i,k}=0`, the class of `z` modulo `Q_i` is topologically nilpotent. Multiplication by the class of `U_i(z)` is therefore invertible. Consequently the two remainder ideals agree after completion:

\[
(\operatorname{coeff}(F_i\bmod Q_i))
=(\operatorname{coeff}(P_i\bmod Q_i)).
\]

The one-color completed relation algebra is thus finite free over `A_i`, of rank

\[
\binom{e_i}{p_i},
\]

with a rectangular Schur basis whenever `p_i<=e_i`; it is zero otherwise. If the incoming degree of `F_i` is at most `e_i`, no nonpolynomial preparation is needed: normalize `F_i` by its unit leading coefficient to obtain `P_i` directly.

## 3. What this does and does not supply

This is a genuine description of each color's row relations by familiar finite algebra. It gives a possible implementation using companion matrices, exterior powers, and bounded partitions instead of clone coordinates. The remaining colors are coupled through the coefficients of `P_i`.

One must still impose the other colors' equations and select the actual-arrow-open, T-flat factor. The one-color freeness is not a theorem that the full unsaturated cyclic system is finite, nor does it imply a global tensor product of Grassmannian cohomology rings. Such a conclusion would erase the main cyclic difficulty. In particular, it supplies no global Lefschetz assertion for the final special coefficient algebra.

## 4. Primary-source novelty audit

Letterio Gatto and Taise Santiago, *Schubert Calculus on a Grassmann Algebra*, arXiv:math/0702759 (2007), https://arxiv.org/pdf/math/0702759 . Read directly: section 3.11, Theorems 4.7–4.8, and the surrounding exterior-power construction. Section 3.11 identifies the universal monic factorization algebra with their exterior-power operator algebra; the stated presentation and rectangular exterior-power basis are therefore established prior art. The paper attributes this interface to earlier Laksov–Thorup work. Its graded universal setting specializes to the coefficient rings used here; the direct proof in section 1 also avoids reliance on an unverified extension of its hypotheses.

The author-hosted Laksov–Thorup PDF at https://web.math.ku.dk/~thorup/temp/lt2b.pdf was located, but the direct open timed out. It is not used as an independently verified theorem input in this note. Search-result timestamps describing these old papers as recently published were not treated as publication dates.

The application here is specifically to the completed primitive quiver rows and the selected theta coefficient factor. The local factorization/Schur interface itself is not a new result of this run.
