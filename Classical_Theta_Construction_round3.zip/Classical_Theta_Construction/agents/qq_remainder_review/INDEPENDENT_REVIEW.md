# Independent review of the Q-polynomial coefficient algebra

2026-11-13. **Verdict: PASS.** This review audits the algebraic compression, its specialization, and its implementation. It takes the independently reviewed global graph-Gale/sign theorem as input and does not rerun the window proof.

## 1. The remainder/alternant identity is correct

Let `P=k[t,x_{i,a}]`, `G=product S_{p_i}`, `R=P^G`, and let `Delta` be the product of the same-color Vandermonde polynomials. For arbitrary `F_i(z) in R[z]`, including coefficients depending on the coefficients of `Q_i`, put

\[
I=(F_i(x_{i,a})),\qquad
J=(\operatorname{coeff}(F_i\bmod Q_i)).
\]

Then, in characteristic zero,

\[
(I:\Delta)\cap R=J.
\]

Both containments in the supplied proof are valid. The adjugate of each Vandermonde matrix gives `Delta J subset I`. Conversely, monic division gives `I subset JP`, and the `R`-linear map `Alt/(|G| Delta)` sends `Delta h` to `h` for invariant `h`. No root-separability hypothesis, complete-intersection hypothesis, generic reducedness, or independence from the coefficients of `Q_i` is used.

The sign component of `P/I` is therefore the cyclic `R`-module `R/J`, represented by multiplication by `Delta`. It is not a subalgebra under the multiplication of `P/I`; the separate quotient algebra `R/J` supplies the commutative algebra structure used by the algorithm.

Characteristic zero is sufficient. No algebraic closure of `k` is needed for this compression. The argument also works when the group order is invertible, with the usual sign convention; no integral or modular extension is asserted here.

## 2. Saturation and the special fiber

For invariant `s`, the identity

\[
((I:s^\infty):\Delta)\cap R=J:s^\infty
\]

follows directly by applying the first identity to `s^m h`; it does not require an informal interchange of an invariant functor with a limit. The sign projector is an idempotent `R`-linear map. Consequently its image commutes with reduction modulo the invariant parameter `T`, giving

\[
\left(P/(I:s^\infty,T)\right)^{\rm sgn}
\cong R/(J:s^\infty,T).
\]

This is the precise justification for the final quotient. It is not an assertion that saturation itself commutes with setting `T=0`. That latter assertion would in general be false.

The symmetrized boundary polynomial

\[
S=\prod_{g_i\ne0}Q_i(0)
\prod_{i<j:B_{ij}\ne0}\operatorname{Res}(Q_i,Q_j)
\]

has, after pullback, exactly the actual-arrow zero set. Its signs and multiplicities do not change the open set. Factors for inactive colors are `1`. Same-color discriminants are correctly omitted.

The warning about discriminants is mathematically justified by the general algebra identity: nonreduced repeated-root fibers can carry the required sign component. The example `F=z^2`, `p=2` verifies the mechanism. It should not be described as a theta-specific counterexample to discriminant saturation; it is an elementary counterexample to the proposed replacement in the general lemma.

## 3. Primitive signs and symmetrizers

Incoming color `j` arrows give `Q_j(z)^[B_ij]_+`; outgoing arrows give `(-1)^(p_j[-B_ij]_+)Q_j(z)^[-B_ij]_+`. The frame supplies the identical sign convention with `g_i` in place of a matrix entry. Thus the displayed polynomial

\[
T^{a_i}z^{[g_i]_+}\prod_jQ_j^{[B_{ij}]_+}
-(-1)^{[-g_i]_++\sum_jp_j[-B_{ij}]_+}
z^{[-g_i]_+}\prod_jQ_j^{[-B_{ij}]_+}
\]

has the correct target `Gamma_i^pr=T^{-a_i}`. Division by `D_i` changes every incident edge multiplicity into the corresponding entry of `B`, so no residual `D_i` belongs in these polynomial exponents. The symmetrizer enters the admissible choice of target valuations.

## 4. Implementation review

`computation/quiver_polynomial_staircase.py` agrees with the formulas above. Its auxiliary variable equation `u*T*S-1`, lexicographic elimination of `u`, and subsequent specialization correctly implement the required order of operations. The staircase routine raises an error if a purported nonzero special quotient is not zero dimensional. The existing small-exponent rank selector is valid and practical.

The new file `EXPLICIT_GENERIC_EXPONENTS.md` supplies a separate coarse, fully explicit choice requiring no hierarchy enumeration. This makes the mathematical input construction explicit in `(B,D,g,p)`; it is not proposed as the efficient default for Gröbner calculations.

## 5. Independent computations

`independent_alternant_probe.py` imports no global-Gale implementation. It constructs twelve finite root algebras whose `F_i` depend on their own `Q_i` coefficients and on other colors. It computes the sign multiplicity by summing the traces of every permutation on a Gröbner monomial basis. A separate coefficient-ring calculation computes the remainder-algebra length. All twelve comparisons pass. Root lengths are `9,64,27,81`, repeated for three random coefficient choices, and the corresponding sign multiplicities are `3,4,9,9`.

`independent_q_polynomials.wl` is a separate Wolfram implementation of the actual Q equations, resultant saturation, and special-fiber staircase. Its outputs are independently compared with `IncomingSchur`:

| Data | Q-algebra length | Independent theta coefficient |
|---|---:|---:|
| rank one, `g=-4`, `p=2` | 6 | 6 |
| `A2`, `g=(-3,-2)`, `p=(2,2)` | 18 | 18 |
| cyclic unit triangle, `g=(-2,-1,-1)`, `p=(2,1,1)` | 8 | 8 |
| `B=[[0,3],[-2,0]]`, `D=(2,3)`, `g=(-2,1)`, `p=(2,1)` | 3 | 3 |

These tests attack the compression and its implementation; they are not the logical premise of the general theorem.

## 6. Structural scope

The final coefficient algebra is finite and gives a positive cardinality through standard monomials. Its algebra structure need not be Gorenstein. For example, the already computed cyclic unit triangle with `g=(-1,-1,-1)`, `p=(1,1,1)` has special quotient `k[c_1,c_2,c_3]/(c_1,c_2,c_3)^2`, of length four and socle dimension three. Thus this auxiliary algebra alone does not provide a general Lefschetz or Poincaré-duality theorem.

There is, however, a precise one-color Grassmannian/factorization interface, recorded separately in `LOCAL_FACTORIZATION_INTERFACE.md`. The interface is old algebra applied to the new coefficient construction, not a priority claim for Schur bases or Grassmannian factorization rings.
