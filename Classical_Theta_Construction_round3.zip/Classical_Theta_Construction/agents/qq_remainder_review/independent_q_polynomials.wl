ClearAll[qqCheck,z,t,h,c];
qqCheck[b_,g_,p_,aa_]:=Module[{rr=Length[p],vars,q,eq={},f,boundary=1,gb,gs,g0,leads,limits,stair},
 vars=Flatten[Table[Table[c[i,j],{j,p[[i]]}],{i,rr}]];
 q=Table[z^p[[i]]+Sum[c[i,j] z^(p[[i]]-j),{j,p[[i]]}],{i,rr}];
 Do[If[p[[i]]>0,
 f=t^aa[[i]] z^Max[g[[i]],0] Product[q[[j]]^Max[b[[i,j]],0],{j,rr}]
 -(-1)^(Max[-g[[i]],0]+Sum[p[[j]]Max[-b[[i,j]],0],{j,rr}])
 z^Max[-g[[i]],0]Product[q[[j]]^Max[-b[[i,j]],0],{j,rr}];
 eq=Join[eq,CoefficientList[PolynomialRemainder[Expand[f],q[[i]],z],z]];
 If[g[[i]]!=0,boundary*=q[[i]]/.z->0]],{i,rr}];
 Do[If[p[[i]]p[[j]]b[[i,j]]!=0,boundary*=Resultant[q[[i]],q[[j]],z]],{i,rr},{j,i+1,rr}];
 gb=GroebnerBasis[Append[eq,h t boundary-1],Join[{h},vars,{t}],MonomialOrder->Lexicographic];
 gs=Select[gb,FreeQ[#,h]&];
 g0=GroebnerBasis[gs/.t->0,vars,MonomialOrder->DegreeReverseLexicographic];
 If[MemberQ[g0,1],Return[<|"p"->p,"g"->g,"length"->0,"specialBasis"->g0|>]];
 leads=(Exponent[First[MonomialList[#,vars,DegreeReverseLexicographic]],vars]&)/@g0;
 limits=Table[Min[Cases[leads,e_/;e[[i]]>0&&Total[Boole[#>0]&/@e]==1:>e[[i]]]],{i,Length[vars]}];
 stair=Select[Tuples[(Range[0,#-1]&)/@limits],Function[e,AllTrue[leads,Function[l,Not[And@@Thread[l<=e]]]]]];
 <|"p"->p,"g"->g,"length"->Length[stair],"specialBasis"->g0,"staircase"->stair|>
];
{
qqCheck[{{0}},{-4},{2},{1}],
qqCheck[{{0,1},{-1,0}},{-3,-2},{2,2},{1,2}],
qqCheck[{{0,-1,1},{1,0,-1},{-1,1,0}},{-2,-1,-1},{2,1,1},{1,2,4}],
qqCheck[{{0,3},{-2,0}},{-2,1},{2,1},{1,2}]
}
