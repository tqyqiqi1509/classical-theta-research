# Independent audit of the analytic coefficient bound

2026-11-13. **Verdict: the Morse-degree and isolated-point Bézout argument passes.** The novelty of the resulting convergence domain is a separate literature question and is not claimed here.

## 1. The permitted perturbation has the required degree

For an active color `i`, let

\[
A_i=[g_i]_++\sum_j[B_{ij}]_+p_j,
\qquad E_i=[-g_i]_++\sum_j[-B_{ij}]_+p_j.
\]

The primitive rational row has the form `N_i(x)/O_i(x)`, with total degrees `A_i` and `E_i` in all clone coordinates. The same polynomial `P_i(z)` of degree at most `p_i-1` is added to every row of color `i`, multiplied by a sufficiently positive power of `T`. Clearing the outgoing denominator gives

\[
N_i(x)-T^{-a_i}O_i(x)+T^N P_i(x_{i,a})O_i(x)=0.
\]

The total coordinate degree is at most

\[
d_i=\max(A_i,E_i+p_i-1)
\le |g_i|+\sum_j|B_{ij}|p_j+p_i-1.                 \tag{1}
\]

The target powers of `T` and the symmetrizer have no effect on this coordinate degree.

The degree `p_i-1` is sufficient for the reviewed Morse argument. On a same-color coincidence stratum with `d` distinct values, prescribing the values of `P_i` requires `d` conditions. If `r` of those values correspond to repeated blocks, prescribing derivatives there requires another `r`; the inequality `d+r<=p_i` holds. Hermite interpolation therefore supplies all needed transverse derivative variations. Smoothness on the stratum itself follows from the independent value variations and generic étaleness of the finite incidence projection. This does not require prescribing derivatives at every singleton block.

The perturbation coefficients can be chosen in a bounded rational grid outside the proper exceptional locus. Such coefficients have nonnegative T-valuation, so the positive-factor window remains valid. No exponential or logarithmic perturbation is used.

## 2. Other positive-dimensional components do not invalidate Bézout

After a generic permitted perturbation, the selected factor is finite and reduced. Each of its points is isolated in the actual-arrow-open system. Clearing denominators does not change the local equations there because every outgoing denominator is a unit. A component lying on an excluded arrow hyperplane cannot contain such a point. Thus every selected point is an isolated simple affine zero of the cleared polynomial rows.

For `n=sum p_i` polynomials in `n` variables, with row degree at most `d_i` repeated `p_i` times, the number of isolated simple affine zeros is at most

\[
\prod_i d_i^{p_i}.                                \tag{2}
\]

One can justify the precise form needed here without assuming the original whole zero set is finite. Perturb the homogenized rows by general forms of the same degrees. Each isolated simple original zero persists by the implicit-function/Hensel argument. The general projective complete intersection has total degree the product of the row degrees, so the persistent affine zeros cannot exceed that number. Extraneous components and points at infinity only consume part of the available intersection degree. If one of the row degree bounds is zero, an isolated square-system point cannot occur unless the constant equation is nonzero, in which case there are no zeros; the zero bound is therefore harmless. The looser positive bound used in the root note avoids this edge case altogether.

## 3. The Young factorial is legitimate

A point stabilizer under coordinate permutations is a product of symmetric groups on equal-coordinate blocks. The sign representation occurs in its orbit representation exactly when every block is a singleton. Thus, in the generic reduced factor,

\[
a_g(p)=\#\{\text{free Young orbits}\},\qquad
a_g(p)\prod_i p_i!\le\#\{\text{all selected points}\}.
\]

Combining with (1)–(2) gives the valid stronger coefficient bound

\[
0\le a_g(p)\le
\frac{\prod_i\bigl(|g_i|+\sum_j|B_{ij}|p_j+p_i-1\bigr)^{p_i}}
{\prod_i p_i!},                                    \tag{3}
\]

with inactive factors interpreted as `1`. No division of nonfree orbit counts is made.

Put `M=max(1,max|B_ij|)` and `G=max_i|g_i|`. The simpler bound in the parent note follows:

\[
a_g(p)\le\frac{(G+M|p|)^{|p|}}{\prod_i p_i!}.
\]

The multinomial theorem and `n!>=(n/e)^n` then prove absolute, locally uniform convergence for

\[
\sum_i|y_i|<\frac1{eM}.
\]

This is a convergence theorem for every formal theta F-series. It is not a statement that the support is finite.

## 4. A sharper positive combinatorial majorant

Set `G_i=|g_i|`, `C_ii=1`, and `C_ij=|B_ij|` for `i!=j`. The numerator in (3) counts maps from a colored labeled vertex set in which a vertex of color `i` chooses either one of `G_i` external terminals, or one of the `C_ij` colored arrows to a different vertex of color `j`. A vertex cannot point to itself. The factors count choices independently.

Let `T_i(y)` be the unique formal solutions with zero constant terms of

\[
T_j=y_j\exp\!\left(\sum_i C_{ij}T_i\right).
\]

The rooted-tree expansion gives the exact majorant identity

\[
\sum_{p\ge0}
\frac{\prod_i(G_i+\sum_j C_{ij}p_j-1)^{p_i}}{\prod_i p_i!}y^p
=
\frac{\exp\!\left(\sum_i(G_i-1)T_i\right)}
{\det(I-\operatorname{diag}(T)C)}.                  \tag{4}
\]

The apparently negative terms in the numerator exponent simply remove cycles of length one. A form making positivity manifest is

\[
\exp\!\left(\sum_iG_iT_i
+\sum_{k\ge2}\frac{\operatorname{tr}((\operatorname{diag}(T)C)^k)}k\right).
\]

Connected components of a functional digraph are a tree ending at an external terminal, or a directed cycle of length at least two decorated by incoming trees. This proves (4) by the exponential formula. Allowing self loops gives the parent's simpler majorant `exp(sum G_i T_i)/det(I-diag(T)C)`; it is also correct, just weaker. The majorant's objects and the functional-digraph identity are standard combinatorics, not a claimed new direct combinatorial formula for the exact theta coefficients.

Whenever a positive vector `t` satisfies `rho(diag(t) C)<1` and

\[
|y_j|\le t_j\exp(-\sum_i C_{ij}t_i),
\]

the rooted-tree iteration is bounded by `t`, giving a computable anisotropic convergence region and the corresponding determinant majorant. This is an optional strengthening of the scalar ball and requires no additional theta theorem.
