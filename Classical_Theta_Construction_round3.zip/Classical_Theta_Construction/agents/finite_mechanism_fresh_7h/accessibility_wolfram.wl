ClearAll[bx,leq,sgn,cc,tf,at];
bx[a_List]:=SortBy[Tuples[Range[0,#]&/@a],{Total,Identity}];
leq[a_List,b_List]:=And@@Thread[a<=b];
at[a_Association,p_List]:=Lookup[a,ToString[p,InputForm],0];
sgn[b_List,d_List,a_List,q_List]:=Module[{v,j,vals},
 v=(b.a).(d*q);If[v!=0,Return[Sign[v]]];
 j=First@FirstPosition[a,_?(#>0&)];
 vals=Select[Table[a[[j]]q[[i]]-a[[i]]q[[j]],{i,Length[a]}],#!=0&];
 If[vals=={},0,Sign[First[vals]]]];
cc[b_List,d_List,a_List,m_List]:=cc[b,d,a,m]=Module[{s,ss,v=<||>,ans=0,i},
 If[Total[a]==0,Return[1]];
 s=Flatten@Position[a,_?(#>0&)];
 If[Length[s]==1,i=First[s];Return[Binomial[-m[[i]],a[[i]]]]];
 ss=Select[bx[a],#!=a&&Total[#]>0&&sgn[b,d,a,#]>0&];
 Do[AssociateTo[v,ToString[t,InputForm]->(cc[b,d,t,m]-Total[
 Table[If[leq[q,t]&&q!=t,cc[b,d,t-q,m+b.q] at[v,q],0],{q,ss}]] )],{t,ss}];
 Total[Table[cc[b,d,a-t,m+b.t] at[v,t],{t,ss}]]];
tf[b_List,d_List,g_List,cap_List]:=Module[{j=bx[cap],f=<||>,ii,t,mp,qq},
 AssociateTo[f,ToString[ConstantArray[0,Length[g]],InputForm]->1];
 Do[mp=g+b.p;ii=Select[j,leq[#,p]&&(#==p||mp.(d*(p-#))<0)&];
 t=<|ToString[p,InputForm]->1|>;
 Do[AssociateTo[t,ToString[q,InputForm]->(-Total[
 Table[If[u!=q&&leq[q,u],at[t,u] cc[b,d,u-q,g+b.q],0],{u,ii}]])],
 {q,Reverse[Most[ii]]}];
 AssociateTo[f,ToString[p,InputForm]->(-Total[Table[at[t,q]at[f,q],{q,Most[ii]}]])],
 {p,Rest[j]}];f];
b={{0,-4,4},{6,0,-4},{-6,4,0}};d={3,2,2};g={4,-2,-1};f=tf[b,d,g,{1,2,2}]; <|"B"->b,"D"->d,"g"->g,"target"->at[f,{1,2,2}],"predecessors"->(at[f,#]&/@{{0,2,2},{1,1,2},{1,2,1}}),"prefix"->f|>