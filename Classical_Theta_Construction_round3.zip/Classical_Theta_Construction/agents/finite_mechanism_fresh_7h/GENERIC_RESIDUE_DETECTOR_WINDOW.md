# Generic residue windows at a degenerate detector endpoint

2026-11-14, 00:42 UTC; uniform nested-factor refinement 00:50 UTC. Classical cluster algebras, first skew-symmetric and then skew-symmetrizable. The parent independently reviewed the initial-degeneration argument and the annulus/complete-intersection comparison; the support-accessibility branch independently reviewed the annulus and parameter-family arguments. The proof below incorporates their requested sign and uniformity clarifications. It uses the project's already reviewed global Gale/Q coefficient theorem and its generic-endpoint collision-window theorem. It does not assume that the marked inner core already has the derivative branching length.

## 1. The core and the claim

Fix an integral skew-symmetrizable matrix B and a positive integral symmetrizer D. Let g be an integral theta label, and let r,q be nonnegative integral vectors. Put

\[
u=r+q,\qquad m=g+Bu+r,
\qquad C=\begin{pmatrix}B&I\\-I&0\end{pmatrix}.
\]

The inner core has old multiplicities u, leaf multiplicities r, and frame label (g,0). Its primitive target endpoint is

\[
\mu_0=(0,a),\qquad a_i>0.
\tag{1.1}
\]

All equations have independent **original-color** unit targets, including old and leaf colors. Units are equal on clones of a color. They are not assumed to be independent on individual clones. Let H be that color target torus, with sign constants absorbed by a fixed torus translation. The primitive row convention is

\[
\Gamma_v=\lambda_{\operatorname{col}(v)}\delta^{-\mu_0(v)}.
\tag{1.2}
\]

The positive factor means that every coordinate has positive delta valuation and every actual arrow difference is nonzero. Same-color coincidences are allowed with their scheme structure. In monic coordinates it is the corresponding saturated remainder factor, with no discriminant localization.

**Claim.** There is a nonempty Zariski open set of color target residues on which this entire positive core is finite. Its compressed Q-algebra has length

\[
d_{g;r,q},
\tag{1.3}
\]

the coefficient in the independently proved positive divided-derivative expansion

\[
\left(\prod_i\frac{x_i^{r_i}}{r_i!}\partial_{y_i}^{r_i}\right)\theta_g
=\sum_{q\ge0}d_{g;r,q}\,y^q\theta_{g+(I+B)r+Bq}.
\]

The general q-core is thus a detector algebra even though its displayed old endpoint is zero. The genericity is algebraic and finite: it can be imposed by finitely many nonvanishing Laurent polynomials in the color units. It is not an unsupported assertion that an arbitrary special unit target gives the same factor.

Every strictly positive a is allowed. In particular, one may take a_i=1 for every leaf color. The proof only makes t small relative to the finitely many positive leaf cut weights. No genericity of a itself is required.

## 2. Two inputs from the completed global coefficient construction

We recall the precise inputs, because the new step concerns a nongeneric endpoint.

**Generic endpoint window.** For any fixed packet graph, let U be the subspace of raw target weights constant, after the D scaling, on original colors. The finitely many binary collision hierarchies H have depth matrices M_H. For every hierarchy with U contained in im(M_H), all nonnegative kernel directions affect only monochromatic columns and therefore do not change actual arrow valuations. Deleting these zero columns gives a strict positive dual certificate.

Consequently, over a bounded set of target weights, all positive solutions at **rank-generic original-color weights** have a common upper bound on every actual arrow valuation. This bound is independent of target residues and of the small distance to a rank wall: there are finitely many good hierarchies, each with a fixed dual certificate. A generic point of U cannot lie in the image of a bad hierarchy.

**Window to finite flat family.** A uniform positive lower bound on coordinate and actual-arrow valuations, together with a uniform finite upper bound on actual-arrow valuations, gives an affinoid positive factor strictly inside its generator bounds. The strict relative-interior criterion makes that factor finite. In monic Q coordinates the source is cut out by N remainder equations in N coefficient variables over a regular parameter base. Finiteness gives the expected codimension; the equations form a regular sequence. Thus the source is Cohen--Macaulay, and miracle flatness gives a finite flat family.

These statements are proved in `../q_support_round2/COMPLETE_COLOR_SEPARATION.md` and `../gale_boundary_round2/AFFINOID_FINITE_FLAT_BRIDGE.md`. The identification of a generic-endpoint compressed factor with a theta coefficient is `../global_theta_fresh_attack/INDEPENDENT_GLOBAL_IDENTIFICATION.md` together with `../global_gale_novelty/Q_POLYNOMIAL_REMAINDER_THEOREM.md`.

## 3. A target coefficient does not see orthogonal walls

Let an old wall have positive root alpha and wall function f(z^alpha). Its action sends a monomial with mutable exponent ell to that monomial multiplied by

\[
f^{\langle D\alpha,\ell\rangle}.
\]

Suppose the mutable exponent of the coefficient being extracted is m and

\[
\langle D\alpha,m\rangle=0.
\tag{3.1}
\]

Every input monomial that could contribute to that coefficient has mutable exponent m-kB alpha. Skew-symmetrizability gives

\[
\langle D\alpha,m-kB\alpha\rangle
=\langle D\alpha,m\rangle=0.
\]

Its wall power is therefore zero. It produces no nonconstant wall contribution. The coefficient-extraction functional at m is fixed by this wall **term by term**. This is stronger than the statement that the wall action fixes the single monomial of exponent m.

For any fixed coefficient, only finitely many root degrees need be considered. It follows that the detector coefficient is the same in every sufficiently close generic germ at m, including germs with either sign on an m-orthogonal root. No preferred positive perturbation is needed. Nonorthogonal wall signs remain unchanged in a sufficiently small neighborhood.

This argument is used only to identify the nearby generic count. It does not, by itself, identify any nongeneric scheme fiber or rule out unit-dependent boundary loss.

## 4. Exact scaling and the zero-cut identity

The primitive homogeneity degrees of the core row maps are

\[
\deg\Gamma_{\rm old,i}=g_i+(Bu)_i+r_i=m_i,
\qquad
\deg\Gamma_{\rm leaf,i}=-u_i.
\tag{4.1}
\]

Thus the substitution x=delta^t xi is an exact algebraic isomorphism of the localized root equations, and also of their monic-Q presentations. It changes the endpoint (1.1) to

\[
\mu_t=(tm,a-tu).
\tag{4.2}
\]

The units lambda do not change. The same statement holds on nonreduced local algebras. Choose t>0 sufficiently small so that the leaf entries in (4.2) dominate every possible old cut contribution. Only finitely many cuts occur, so this is a finite list of strict inequalities.

Raw target weights at a vertex of color i are D_i times the primitive weights. For a proper cut A, let kappa_A be its signed skew pairing with its complement. Summing the raw row degrees inside an old-only cut with old color count alpha gives, up to the fixed global orientation convention,

\[
\kappa_A=\pm\langle D\alpha,m\rangle.
\tag{4.3}
\]

There is no internal contribution because internal arrow terms cancel.

**Zero-cut lemma.** At mu_t, a zero raw cut weight has kappa_A=0.

To prove this, replace a frame-containing cut by its complement. A cut without the frame and with at least one leaf has strictly positive weight by the choice of t. Thus a zero cut must be old-only. Its weight is t times <D alpha,m>, which vanishes exactly when (4.3) vanishes.

## 5. Uniform lower bounds near the detector

Take a positive solution at a nearby rank- and cut-generic color endpoint mu. Let v be the minimum valuation of any actual arrow difference. Join vertices whose actual arrow difference has valuation strictly greater than v and take a connected component A of this graph. Every actual edge crossing A has valuation v. Summing the row valuation equations over A therefore gives

\[
\mu(A)=\pm v\kappa_A.
\tag{5.1}
\]

For a nontrivial component, cut genericity makes mu(A) nonzero, so kappa_A is nonzero. By the zero-cut lemma, mu_t(A) is also nonzero for every cut with kappa_A nonzero. Since there are finitely many cuts, after shrinking a neighborhood of mu_t we obtain

\[
v\ge
\min_{\kappa_A\ne0}
\frac{|\mu(A)|}{|\kappa_A|}
\ge\varepsilon_t>0.
\tag{5.2}
\]

If the set of cuts with kappa_A nonzero is empty, do not take a minimum over an empty set. In the nontrivial connected framed case, a putative positive solution still has a minimum-valuation actual edge and therefore the cut used in (5.1). Its nonzero generic cut weight contradicts kappa_A=0. Thus there are no nearby generic positive solutions in this case. The asserted window is vacuous, and any fixed positive lower and upper bounds may be used. The degree-zero graph is treated separately by its one-dimensional coefficient algebra; unframed components are excluded by the generic-unit relation below.

Together with Section 2, this gives a common window

\[
\varepsilon_t\le \operatorname{val}(L_e)\le M_t
\tag{5.3}
\]

for every actual arrow in every nearby rank-generic positive solution, uniformly in all independent target residues. If the framed graph is connected, each coordinate is a sum of arrow differences along a path from the frame, so its valuation is at least epsilon_t as well.

If the graph has a component without the frame, its product row equation imposes a nontrivial color-unit monomial relation, since all its color multiplicities are nonnegative and not all zero. Generic color units avoid that relation. Such a component contributes no generic core factor. We may therefore use the connected framed graph case.

The fact that the numerator and denominator of a potentially dangerous zero cut vanish together is essential. A generic-endpoint theorem alone would not give (5.2) when approaching an arbitrary nongeneric endpoint.

## 6. Generic color residues transfer the window to the central endpoint

Here is the general algebraic lemma needed for the central point.

Let X be a closed subvariety of T_E times T_target over a characteristic-zero field k with trivial valuation. In the application X is the graph of the primitive Gale map in the torus of actual arrow differences and target variables. The source arrangement complement is very affine: in a connected framed graph the arrow differences generate its coordinate ring after actual arrows are inverted. Let H be the color target subtorus and U=Trop(H).

**Sign convention.** The actual target valuation is -mu because the target is lambda delta^(-mu). In this section we use signed tropical coordinates (v,mu), meaning the image of the ordinary tropicalization under (v,beta)->(v,-beta). Thus the initial scheme at a displayed point (v,mu) is the usual initial scheme for the actual weight (v,-mu). The initial-star and projection identities are transported by this fixed linear sign change. In particular, an endpoint direction nu corresponds to the actual target direction -nu. The linear subspace U is unchanged by negation.

There are finitely many usual initial ideals in_w I(X). For each resulting initial scheme W, form

\[
W_H=W\cap(T_E\times H).
\]

For every irreducible component Z of W_H whose projection to H is not dominant, remove the Zariski closure of that image from H. This removes a finite union of proper closed subsets. Choose a nonempty principal open H^circ inside its complement. The same H^circ works for **all** weights w; it is not chosen separately for each t or each solution.

Consider an actual point of X with weight (v,mu), positive source arrow weights v, color target weight mu, and target residue lambda in H^circ. The actual unit targets need not be equal on clones: only their normalized residues need to lie in H. Its initial point lies in W_H. It therefore lies on a component Z whose projection to H is dominant. Tropical elimination for the torus projection gives

\[
\operatorname{pr}_H\operatorname{Trop}(Z)=U.
\tag{6.1}
\]

In particular, for any rational direction nu in U there is a source direction w with (w,nu) in Trop(Z), hence in Trop(W). The initial-star identity gives

\[
(v+\epsilon w,\mu+\epsilon\nu)\in\operatorname{Trop}(X)
\tag{6.2}
\]

for all sufficiently small positive rational epsilon. By tropical lifting, these are weights of actual points over a valued extension. Because v is strictly positive, their source arrow weights remain positive. Choose nu so that the nearby color endpoint is rank- and cut-generic. The lifted target **residues** need not be equal on clones; this causes no problem because the generic-endpoint window is uniform over independent target residues.

Apply (5.3) to the lifted points and let epsilon decrease to zero. Every central positive solution with color target residue in H^circ satisfies the same window:

\[
\varepsilon_t\le v_e\le M_t.
\tag{6.3}
\]

This argument uses only dominance of the relevant initial component onto the actual color torus. It does not replace a generic translate in the full target torus by an unjustified generic translate in a smaller subtorus. It also does not assert that rank nongenericity disappears after the common scaling: it need not disappear.

The scheme may be nonreduced. Initial components are used only to bound points and rule out boundary escape. The subsequent complete-intersection argument retains all local multiplicities.

## 7. A connected finite-flat comparison with a generic detector germ

One must not claim that a residue-open torus at fixed target valuations automatically contains nearby valuations. We construct a specific connecting base.

Fix lambda in H^circ. Choose an integral generic direction nu and a small eta>0 such that mu_t+s nu is rank- and cut-generic for every 0<s<=eta, remains in the neighborhood used in (5.2), and has the same detector coefficient d_{g;r,q}. Also require distinct scalar products of nu with the distinct exponents of the polynomial F below; this excludes only finitely many additional hyperplanes. The detector assertion follows from Section 3 after rescaling by 1/t; leaf endpoint coordinates remain sufficiently large and positive.

One may choose this direction nu once for all sufficiently small t>0. There are finitely many rank and cut linear forms. Along mu_t=(tm,a-tu), shrink the t interval to avoid their finitely many nonzero crossing parameters; any form that vanishes identically along that interval is made nonzero by choosing nu outside its kernel. The finitely many differences of exponents of F give additional excluded hyperplanes. For this fixed nu, only eta=eta_t needs to shrink as t decreases. In particular, H^circ is the same residue open for every sufficiently small t; no infinite intersection of genericity conditions is taken.

Let S be an analytic annulus parameter, with 0<=val(S)<=eta, and let the targets vary as

\[
\lambda\,\delta^{-\mu_t}S^{-\nu}.
\tag{7.1}
\]

Choose a nonzero Laurent polynomial F on H with H^circ={F!=0}. Substitute lambda S^{-nu} into F and multiply by a power of S to make the least exponent zero:

\[
f(S)=S^{-b}F(\lambda S^{-\nu}),\qquad
b=\min\{-\langle\nu,\alpha\rangle:\alpha\in\operatorname{supp}F\}.
\tag{7.2}
\]

Its nonzero coefficients have delta valuation zero. The least exponent comes from a unique monomial of F, so its constant coefficient is a nonzero delta unit for every lambda in the color torus. No extra genericity of lambda is hidden in this normalization.

Use the affinoid base

\[
\mathcal A=\{\ |\delta|^\eta\le|S|\le1,\quad |f(S)|=1\ \}.
\tag{7.3}
\]

For val(S)>0 the second condition is automatic. At val(S)=0 it is precisely the condition that the target residue remain in H^circ. The annulus (7.3) is obtained by deleting finitely many bad residue discs from its outer boundary. It is connected and regular; it contains S=1 and S=delta^eta. Its skeleton is the original closed annulus skeleton, and each retained outer residue branch is attached to its outer endpoint. This gives an elementary geometric verification of connectedness, rather than inferring it from the nonemptiness of two unrelated parameter domains.

At positive val(S), Section 5 gives the common window. At val(S)=0, Section 6 gives it. Hence the entire selected positive Q family over A lies strictly inside fixed coefficient and inverse-boundary bounds. It is finite by the relative-interior criterion.

For clarity, let N=sum_i(u_i+r_i). The monic polynomial coefficients are N variables. The N monic remainder coefficients are N equations in an ambient regular analytic space of relative dimension N over A. All actual-arrow resultants and the required frame factors are inverted; same-color discriminants are not. Finiteness forces these equations to have height N. They form a regular sequence; the source is Cohen--Macaulay. Miracle flatness over regular A proves finite flatness, including nilpotents. No assertion that the preimage of the color torus is smooth is needed.

At S=delta^eta, the global Q coefficient theorem identifies the length with d_{g;r,q}. Connectedness and flatness therefore give that same length at S=1. Thus the positive factor at every shifted endpoint mu_t has length d_{g;r,q} on the generic residue locus.

More explicitly, use the color-unit affinoid base given by |lambda_i|=1 and |F(lambda)|=1. It is regular and connected: its reduction is the integral smooth ring k[H,1/F], and an idempotent would reduce to an idempotent of that ring. The uniform window (6.3) holds over every valued extension of this base. The same N-equation complete-intersection argument proves that the compressed factor is finite flat over this whole base. Its rank is d by the one-parameter comparison just given. It can therefore be pulled back along nonreduced Artin outer factors. Its rank assertion is not restricted to reduced target points.

## 8. Nested deep factors give the entire core, uniformly in parameters

This refinement was supplied by the parent's independent review. It replaces the earlier finite-type/local-dimension cover argument by an explicit equality of nested factors, and gives the uniform parameter-family statement directly.

Let C_t denote the part of the original endpoint-(0,a) core with all coordinate valuations greater than t. The exact scaling in Section 4 identifies C_t with the positive factor at mu_t. By Section 7, C_t is a finite-flat family of rank d over the **same** color-unit affinoid base, for every sufficiently small rational t>0.

Fix one such t_0. For 0<t<t_0 there is an actual inclusion of depth domains

\[
C_{t_0}\subseteq C_t.
\tag{8.1}
\]

On each geometric target fiber, C_t is a finite Artin scheme. The depth domain C_{t_0} selects complete local Artin factors of that scheme; it does not truncate their nilpotents. Both have length d by Section 7. Therefore (8.1) is equality on every fiber over every complete valued extension.

An inclusion of analytic domains that contains every such point is the whole analytic domain, with its inherited structure. Hence C_{t_0}=C_t as families. Every positive point of the original core has all coordinate valuations greater than some sufficiently small positive rational t, so it belongs to C_t and therefore to C_{t_0}. The entire positive core is exactly C_{t_0}.

This proves (1.3), including the rank-zero case, and proves the full uniform finite-flat family assertion at once. It also supplies a uniform positive depth bound at the original endpoint after the proof: the core inherits the shifted window translated by t_0. No pointwise-flatness inference and no infinite intersection of residue-open sets is used. The numerical equality is used only after the actual nested Artin factors have been constructed.

### Unit corrections needed for Hensel separation

The window argument only uses the normalized target residues, not equality of the actual clone units. It therefore remains valid when the old and leaf rows are multiplied by analytic correction units congruent to one in delta, provided the corrections are equivariant and define the same number of analytic monic-remainder equations as coefficient variables. A homotopy 1+s(U-1), |s|<=1, preserves their residues and every window. The positive shifted families remain finite complete intersections and are flat in s and in the color-unit base. Their rank is still d. The same deep-to-full argument then applies at the zero-old endpoint. This is the form needed when the target constants and correction units are functions on an outer Artin algebra.

## 9. Realizing generic inner units inside the marked problem

This section records the parameter-independence observation supplied by the support-accessibility branch. It is needed before applying the core statement to actual outer factors.

For the full marked problem, the old degree is M_i=p_i+r_i. In the q-layer the inner and outer degrees are

\[
u_i=r_i+q_i,\qquad v_i=p_i-q_i,\qquad M_i=u_i+v_i.
\]

Allow the already permitted old target polynomial perturbation phi_i with degree at most M_i-1. If u_i>0 and the outer polynomial V_i has V_i(0) invertible, then the map

\[
\phi_i\longmapsto(\phi_i\bmod V_i,\phi_i(0))
\tag{9.1}
\]

is surjective over any Artin outer base. An explicit lift of a remainder A_i of degree less than v_i and a prescribed constant c_i is

\[
\phi_i(z)=A_i(z)+\frac{c_i-A_i(0)}{V_i(0)}V_i(z).
\tag{9.2}
\]

Its degree is at most v_i<=M_i-1. This is valid for repeated outer roots and over nonreduced bases. If u_i=0 there is no inner row of that color and no additional constant needs to be prescribed. If v_i=0 the same formula reduces to the free constant choice.

Thus fixing every outer remainder target still leaves the inner old unit independently variable. The outer determinant units multiply these free constants and cannot impose a relation on them.

Also permit independent constant units in the leaf target equations. Monic leaf elimination becomes

\[
Q_i=P_iS_i+(-1)^{M_i}\lambda_{\rm leaf,i}^{-1}\delta^{a_i}.
\tag{9.3}
\]

The outer leading equations do not depend on these leaf units. In the inner core they change the leaf targets by invertible outer determinant factors. Consequently old and leaf inner target units can jointly meet the generic open H^circ, even after the outer equations are fixed. Finitely many q-layers require only a finite intersection of open conditions.

The perturbations can be chosen inside the bounded polydisc already allowed by the full marked finite-flat theorem: an algebraic nonzero polynomial over the secondary coefficient field cannot vanish on an entire nonempty polydisc. Returning the perturbation to zero and the leaf units to one uses the full marked flat family, not an assertion that the core rank is constant at every exceptional unit target.

## 10. What this does and does not close

For each marked layer indexed by q, the construction identifies its inner factor with an actual finite-flat core of rank d_{g;r,q}; the outer factor has label m=g+(I+B)r+Bq and degree p-q. Together with the support-accessibility branch's frame-residue clustering and Hensel separation, it supplies the missing core-recognition input for a full marked-Q filtration whose q-piece has length

\[
d_{g;r,q}\,a_{g+(I+B)r+Bq}(p-q).
\]

The numerical convolution was already known from positive coefficient shears. The new content here is the nongeneric inner algebra, the generic-unit no-escape mechanism, and its compatibility with actual marked-model parameters. It is not a new proof that every theta series is Laurent finite, nor a bound on its entire support. It should not be advertised as such.

## 11. Primary-source audit for the new tropical interface

1. Bernd Sturmfels and Jenia Tevelev, *Elimination theory for tropical varieties*, arXiv:0704.3471v1 (2007; published 2008). Primary PDF: https://arxiv.org/pdf/0704.3471 . Proposition 2.8, p.5, explicitly proves tropical surjectivity for a dominant restriction of a torus homomorphism. Its set-theoretic statement, not the generically finite multiplicity formula, is used in (6.1). The proof extends a valuation on the target function field. Opened and read 2026-11-14.

2. Brian Osserman and Sam Payne, *Lifting tropical intersections*, Documenta Mathematica 18 (2013), 121--175. Author PDF: https://web.ma.utexas.edu/users/sampayne/pdf/Lifting-tropical-intersections.pdf . Sections 2.1--2.2, pp.126--128, give finiteness of the initial-degeneration polyhedral decomposition, tropical lifting after valued field extension, and the initial-star identity used in (6.2). These passages were read directly. The generic-translate theorems are not used to claim genericity inside the color torus.

3. The same paper, Section 2.2, records the original gap in the earliest tropical-surjectivity proof and points to its corrected Theorem 4.2.5 and other complete proofs. The present argument uses the corrected statement, not the historical incomplete proof.

4. Michael Temkin, *Introduction to Berkovich analytic spaces*, Definition 3.4.9, Remark 3.4.10, Fact 3.4.11(iv), as already checked in the project's finite-flat bridge. Primary source: https://berkovich-2010.imj-prg.fr/lecture-notes/Temkin-lecture-notes.pdf . Used only for the strict-generator relative-interior criterion and finiteness of an affinoid morphism with empty relative boundary.

5. Stacks Project, Lemma 10.128.1, tag 00R4, https://stacks.math.columbia.edu/tag/00R4 . Used for miracle flatness after complete-intersection Cohen--Macaulayness is established.

6. Paul Alexander Helminck and Yue Ren, *Generic root counts and flatness in tropical geometry*, arXiv:2206.07838v3 (8 July 2025), https://arxiv.org/pdf/2206.07838 ; published in the Journal of the London Mathematical Society in 2025. Definition 3.1 and Theorems 3.21 and 4.5 were read directly. Their root-count theorem assumes generically Cohen--Macaulay, pure, complementary-dimensional families, tropical flatness at the chosen parameter, and a bounded tropical prevariety. The generic-flatness and root-count principles are established background. They do not by themselves verify the selected color-core window, its scaled zero-cut identity, or the marked-model parameter independence. We prove those inputs here rather than claim an automatic application or novelty for the general principles.

7. Frederic Bihan and Frank Sottile, *Gale duality for complete intersections*, arXiv:0706.3745v4 (2007), https://arxiv.org/pdf/0706.3745 ; Annales de l'Institut Fourier 58 (2008), 877--891. Introduction and Propositions 1.1--1.2 were read. Scheme-level conversion between torus equations and hyperplane-complement master functions is established background, not a new feature of our presentation.

No 2026 theorem, generic=theta assertion, Hall integration support assertion, or polytope-basis conclusion is used in this proof.

## 12. All-ones endpoints for ordinary theta coefficients

The same bridge simplifies the original coefficient algorithm. This corollary was identified by the parent after the core proof.

For the original packet graph (B,g,p), use primitive endpoint mu=(1,...,1). Every proper cut not containing the frame has strictly positive raw weight, the sum of its positive color multiplicities weighted by D. The minimum-edge cut argument therefore gives a uniform positive lower bound at all nearby generic endpoints. The good-hierarchy certificates give the uniform upper bound. Section 6 transfers this window to generic color residues at mu, and the annulus comparison in Section 7 can be kept entirely within the positive chamber. Its Q-factor length is a_g(p).

Thus over the purely transcendental coefficient field

\[
K=\mathbb Q(\lambda_i:p_i>0),
\]

all adaptive primitive target exponents can be replaced by the single exponent one. With the A_i and E_i of the global Q-polynomial theorem, use

\[
H_i(z)=T A_i(z)-\lambda_i E_i(z),\qquad
J=(\text{coefficients of }H_i\bmod Q_i).
\tag{12.1}
\]

Let S be exactly the old actual-arrow boundary product, with no discriminants. Saturate by TS and select the origin local factor, where T=0 and every monic coefficient c_{i,j}=0. Its T-adic formal completion is the finite free positive-factor model. The dimension of its T=0 fiber is a_g(p). The precise local-standard-basis implementation is being written in the support-accessibility branch.

This uses symbolic color units in place of large generic powers. It does not permit setting every lambda_i to one: special unit targets can lie in an excluded initial image and lose components. It also does not assert that every global T=0 component of a differently framed or zero-endpoint problem is the desired origin component. The origin selection is retained in the stated formula.
