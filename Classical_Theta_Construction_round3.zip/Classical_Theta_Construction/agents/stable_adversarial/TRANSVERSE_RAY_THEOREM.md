# Translated rays and a positive transverse theta algebra

Date: 2026-11-14, Asia/Shanghai.

Status: complete algebraic proof written by the independent reviewer of the
stable-ray argument. The parent independently checked the mechanism and
computed examples, but this is not an external referee certification.
The result is coefficientwise in the principal positive-root completion.
No assertion of Laurent finiteness for all labels is made. No Li--Pan
statement, generic-basis identification, reddening sequence, or cluster
structure on the transverse object is used.

## 1. Data and notation

Let B be an integral exchange matrix, D a positive integral diagonal
symmetrizer, and g,h integral mutable labels. Put

\[
 z_i=y_i x^{Be_i},\qquad
 \vartheta_h=x^hF_h(z),\qquad F_h(0)=1.
\]

We use the already established incoming total automorphism C and its
last-exponent extraction rule. Thus its finite root-graded Lie algebra
has generators e_a, a in the nonzero positive-root monoid, with

\[
 [e_a,e_b]=(a^TDBb)e_{a+b},\qquad
 e_a(x^h z^q)=a^TD(h+Bq)x^h z^{q+a}.
\]

Let J be a finite downward-closed subset of \(\mathbb N^r\) containing
zero, and let I_J be the monomial ideal of root degrees outside J. All
arguments may first be read modulo I_J. Restriction to a smaller such
set commutes with every factorization and recurrence below.

Write

\[
 \lambda_g(a)=g^TDa,\qquad
 P_g=\{a\in\mathbb N^r:\lambda_g(a)=0\}.
\]

P_g is a positive affine monoid (indeed the integer points in a rational
polyhedral cone), but it need not be a free monoid. We do not identify
its Hilbert basis with the vertices of a cluster seed.

The signed factorization of C is

\[
 C=A_g^- Z_g A_g^+,
\]

where the logarithmic root degrees have respectively negative, zero,
and positive \(\lambda_g\). The factor Z_g belongs to the group of the
zero-root Lie subalgebra. It is a middle factor, not a central element of
the full group. In general that zero-root subalgebra is noncommutative.

## 2. The zero-direction extraction family

Define

\[
 \eta_h^g=x^h\sum_{p\in P_g}b_h^g(p)z^p,\qquad b_h^g(0)=1,
\]

using only Z_g and the following finite triangular equations. For each
nonzero p in P_g, factor Z_g by the signs of

\[
 a\longmapsto (h+Bp)^TDa,\qquad a\in P_g,
\]

with an arbitrarily small positive tie covector, as in the ordinary
theta extraction. Denote its negative factor by V_{h,p}^-. Require

\[
 [x^h z^p](V_{h,p}^-)^{-1}\eta_h^g=0. \tag{2.1}
\]

The coefficient of b_h^g(p) in this equation is one, and every other
coefficient has smaller root degree. Hence it uniquely defines the
family over Q, coefficient by coefficient. Its restrictions to finite
root sets are compatible. For degrees outside P_g put b_h^g(p)=0.

This definition is sufficient for the theorem. It does not assume that
Z_g is the incoming transport of a new cluster seed. A possible local
scattering interpretation is additional structure, not a hypothesis of
the proof.

## 3. Exact stabilization along every translated ray

Define the explicit sufficient threshold

\[
 T_J(g;h)=\max\left(\{0\}\cup
 \left\{\frac{|(h+Bs)^TDa|}{|g^TDa|}:
 s\in J,\ 0<a\le s,\ g^TDa\ne0\right\}\right). \tag{3.1}
\]

For every integer n greater than this threshold,

\[
 \boxed{\vartheta_{ng+h}\equiv
 A_g^-(x^{ng}\eta_h^g)\pmod {I_J}.} \tag{3.2}
\]

Here congruence compares expansions with the common leading monomial
\(x^{ng+h}\).

### Proof

Fix a target p in J. Work in the smaller root quotient indexed by
\([0,p]\). This restriction is essential: (3.1) controls the signs of
roots a\le p, which are precisely the roots relevant to the p-th
coefficient, rather than all roots of J for every target p.

For every such root with \(\lambda_g(a)\ne0\), (3.1) gives

\[
 \operatorname{sgn}((ng+h+Bp)^TDa)
 =\operatorname{sgn}(g^TDa).
\]

For a in P_g, the extraction sign is the sign of
\((h+Bp)^TDa\), with the same positive tie convention. Consequently
the extraction sign rule is a refinement of the coarse g-sign rule.
Signed-factorization uniqueness gives the negative extraction factor

\[
 A_g^-V_{h,p}^-. \tag{3.3}
\]

If p is not in P_g, the notation V_{h,p}^- still means the indicated
signed factor of Z_g; no defining equation (2.1) at that p is required.

Every zero-root generator annihilates x^{ng}, since
\(a^TD(ng)=0\). Since these operators are derivations, every element of
the zero group fixes x^{ng} and commutes with multiplication by it.
Therefore the inverse extraction applied to the proposed expression is

\[
 (A_g^-V_{h,p}^-)^{-1}A_g^-(x^{ng}\eta_h^g)
 =x^{ng}(V_{h,p}^-)^{-1}\eta_h^g. \tag{3.4}
\]

The right-hand side has root support in P_g. Its p-th coefficient is
automatically zero if p is outside P_g. If p is a nonzero element of
P_g, that coefficient is zero by (2.1). The leading coefficient is one.
Thus the candidate satisfies every theta extraction equation through J.
Unitriangular uniqueness proves (3.2). Compatibility of restrictions
allows the same A_g^- and eta family to serve every p in J. QED.

## 4. A common growth factor and positive boundary coefficients

The stable-ray series from the unshifted theorem is

\[
 H_g=x^{-g}A_g^-x^g\in1+\mathbb Z[[z]].
\]

Define

\[
 R_{g,h}=x^{-h}A_g^-\eta_h^g.
\]

Multiplicativity of A_g^- turns (3.2) into

\[
 \boxed{F_{ng+h}\equiv H_g^n R_{g,h}\pmod {I_J}
 \quad(n>T_J(g;h)).} \tag{4.1}
\]

Both series are cutoff-independent. In particular, consecutive theta
quotients stabilize to the same series for every fixed shift h:

\[
 \frac{F_{(n+1)g+h}}{F_{ng+h}}\equiv H_g\pmod {I_J}.
\]

Since the F-series and the unit H_g are integral, (4.1), solved for
R_{g,h} in each finite quotient, proves
\(R_{g,h}\in1+\mathbb Z[[z]]\). Negative coefficients of H_g or R_{g,h}
are permitted.

The action of A_g^- adds only roots of strictly negative \(\lambda_g\).
Consequently (3.2) proves a sharper statement about the coefficient
boundary:

\[
 a_{ng+h}(p)=
 \begin{cases}
 0,&\lambda_g(p)>0,\\
 b_h^g(p),&\lambda_g(p)=0,
 \end{cases}
 \quad\text{for }n>T_J(g;h),\ p\in J. \tag{4.2}
\]

In the second line the zero root p=0 is included. Classical theta
positivity and integrality now imply

\[
 b_h^g(p)\in\mathbb N
\]

without first assuming positivity or integrality of an abstract new
scattering theory for Z_g. This is an actual consequence of the ordinary
theta coefficient family. For h=0, the zero-group extraction has
\(\eta_0^g=1\). Therefore every nonzero coefficient with
\(\lambda_g(p)\ge0\) in F_{ng} eventually vanishes.

For \(\lambda_g(p)<0\), (4.1) gives the exact eventual polynomial

\[
 a_{ng+h}(p)=
 \sum_{j=0}^{|p|}\frac{n^j}{j!}
 [z^p](\log H_g)^j R_{g,h}. \tag{4.3}
\]

The phrase boundary in (4.2) is coefficientwise. It does not assert that
the complete Newton polytope of a Laurent theta function has this face:
uncontrolled degrees outside a prescribed J might remain. A global
Newton statement needs an additional uniform support bound.

## 5. Exact stabilization of all transverse structure constants

The family eta is pointed and unitriangular in P_g, so there are unique
formal coefficients d^g_{h,k}(q), supported on P_g, such that

\[
 \eta_h^g\eta_k^g
 =\sum_{q\in P_g}d^g_{h,k}(q)y^q
                 \eta_{h+k+Bq}^g. \tag{5.1}
\]

The series are interpreted by root degree. The integer coefficients b
and unitriangular inversion first give d in Z. In fact d is nonnegative.

Let n,m be positive integers satisfying

\[
 n>T_J(g;h),\qquad m>T_J(g;k),\qquad
 n+m>T_J(g;h+k). \tag{5.2}
\]

Then the actual theta structure constants satisfy

\[
 \boxed{c_{ng+h,\,mg+k}(q)=
 \begin{cases}
 d^g_{h,k}(q),&q\in P_g,\\
 0,&q\notin P_g,
 \end{cases}\quad q\in J.} \tag{5.3}
\]

### Proof

Apply (3.2) to both factors and use the automorphism property:

\[
 \vartheta_{ng+h}\vartheta_{mg+k}
 \equiv A_g^-(x^{(n+m)g}\eta_h^g\eta_k^g)
 =\sum_{q\in P_g}d^g_{h,k}(q)y^q
 A_g^-(x^{(n+m)g}\eta_{h+k+Bq}^g). \tag{5.4}
\]

To identify the q-th summand with an output theta function, only the
remaining root set \(J_q=\{s:q+s\in J\}\) is needed. In its threshold,
the relevant numerator is

\[
 (h+k+Bq+Bs)^TDa=(h+k+B(q+s))^TDa,
\]

with \(a\le s\le q+s\). Hence

\[
 T_{J_q}(g;h+k+Bq)\le T_J(g;h+k).
\]

The last inequality in (5.2) therefore applies (3.2) to every necessary
output summand simultaneously. Equation (5.4) becomes the theta product
expansion with coefficients in (5.3). Finite unitriangular uniqueness
proves the claimed equality. Classical nonnegativity of theta structure
constants gives \(d^g_{h,k}(q)\ge0\). QED.

The argument also proves the corresponding assertion for any fixed
finite number of factors: take a large ray coefficient on each input
and a sufficiently large total coefficient on each output.

## 6. Meaning and limits of the construction

The zero-root family is a positive integral formal theta-type algebra
arising as an exact fixed-degree limit of translated ordinary theta
families. Associativity and commutativity follow from the ordinary
commutative completed monomial algebra and the unitriangular basis.
Nonnegativity follows separately from the exact stabilization of the
ordinary positive theta structure coefficients proved above; it does
not follow from unitriangularity alone. This is formal algebra;
finite multiplication or Laurent finiteness is not being inferred.

For every integer t,

\[
 \eta_{h+tg}^g=x^{tg}\eta_h^g,
\]

because all the zero-root actions and extraction signs are unchanged.
Thus its nontrivial label dependence is transverse to g, after accounting
for this monomial shift. If desired one may pass to the primitive lattice
direction of g; no arbitrary quotient lattice or freeness assertion is
needed for (2.1)--(5.3).

The substantive new statement is the exact theta-coefficient and
structure-coefficient stabilization (3.2), (4.2), and (5.3), with a finite
checkable threshold. Merely naming the factor Z_g would add no new
information. The subsequent literature comparison in
`../stable_hall_interface/NOVELTY_LOCAL_STAR.md` identifies this family
with the ordinary theta basis of the local scattering star at `g`.
The positive transverse algebra is therefore an instance of an existing
framework, not a new type of theta object. The candidate increment is
the effective arbitrary-rank stabilization with its uniform explicit
root cutoff; its priority is assessed in that note. The stronger
polytope and one-scale multiplication consequences are proved in
`../stable_hall_interface/POLYTOPAL_STABLE_LOG_THEOREM.md` and compared
with primary sources in
`../stable_hall_interface/POLYTOPAL_PRIMARY_LITERATURE_REVIEW.md`.

## 7. Computation record supplied by the parent

The independent implementation `computation/transverse_probe.py` and its
JSON result checked 36 inputs of ranks 2, 3, and 4, including valued and
resonant examples. There were 1,800 translated-theta coefficient checks
and 600 structure-coefficient checks. All passed, including the predicted
vanishing off P_g and nontrivial stabilized zero-direction coefficients.
Those computations corroborate the conventions. They are not used in
the proof above.
