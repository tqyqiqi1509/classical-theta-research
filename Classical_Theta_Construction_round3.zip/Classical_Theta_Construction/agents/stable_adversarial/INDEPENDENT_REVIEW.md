# Independent review of continuity, stable rays, and wall recovery

Date: 2026-11-14, Asia/Shanghai.

## Verdict

The three supplied mathematical arguments are valid under their stated
incoming-prefix and last-exponent extraction input, after the local
truncation clarification below. I did not find a counterexample or a
remaining algebraic gap in their main statements. This is an independent
internal mathematical review, not an external certification or a proof
of literature priority.

The most substantive statement is exact fixed-degree stabilization of
theta ratios. It is stronger than the prior run's eventual polynomiality.
The new companion `TRANSVERSE_RAY_THEOREM.md` proves the shifted-ray and
transverse multiplication extension from the same mechanism.

## 1. Correction needed in the stable-ray proof

The stated threshold controls roots a<=s for each target s. Therefore
one must restrict to the smaller root quotient [0,s] before saying that
the extraction sign rule refines the coarse g-sign rule. It is not
justified to claim that refinement on the entire J for every s from
that threshold alone. Every coefficient in row s uses only [0,s], and
signed factorization is compatible with restriction, so this fixes the
proof without changing the theorem or its threshold.

For a total-degree cutoff |s|<=N, a harmless sharpening of the rough
bound is available. Since a<=s and DB is skew,

    |(Bs)^TDa| = |(B(s-a))^TDa|
                  <= M |s-a| |a| <= M N^2/4,

where M=max |D_i B_ij| and the nonzero integral denominator is at least
one. This changes only the constant in the sufficient quadratic bound.
It does not establish linear escape of corrections.

## 2. Continuity: checks that matter

The representation identity has the correct sign. Acting on x^g z^q,
the commutator coefficient is

    Omega(a,b) (a+b)^TD(g+Bq),

where Omega(a,b)=a^TDBb. This agrees with the stated bracket.

On an H-boundary for target r, lambda(a)=Omega(a,r). If a+b=r and
lambda(a)=lambda(b)=0, then Omega(a,b)=Omega(a,r)=0. Thus the degree-r
coordinate on the zero Lie algebra really is a character. Refinement
cannot put the r-coordinate in a strict sign factor because every
refinement in use still has r of sign zero. This proves independence
of the normalization at simultaneous boundaries as well as ordinary
facets. The coefficient of the new log-C coordinate is one, so the
degree induction is legitimate and does not divide by a vanishing
pairing.

On an E-boundary, the proposed final row is annihilated by every
zero-root generator. The identity

    a^TD(g+B(p-a))=a^TD(g+Bp)-a^TDBa=0

is exact, and the ordering of inverses in

    row_p (A_- B_-)^{-1}=row_p B_-^{-1} A_-^{-1}

is correct. This is the essential reason the strict boundary tie rule
has the same value as the incident chamber polynomials. It is not an
assumed continuity property of broken lines.

The primitive-linear-factor divisibility follows from polynomial
vanishing on a relatively open facet and Gauss's lemma after choosing
integral coordinates on the lattice of DB-skew matrices. It must not
be advertised as nonnegativity or integer-valuedness of the quotient
without the p! multiplier. The axis example correctly rules out C1 in
general.

The extension to fixed-arity structure coefficients is valid: every
substitution g+h+Bq is affine linear in the parameter variables and
preserves continuity, total root-charge degree, and the factorial
denominator bound.

## 3. Stable root: checks that matter

The coarse zero subgroup fixes x^{ng}, not the whole module. That is
exactly what is needed after applying the inverse factor to the
candidate A_-x^{ng}. No unjustified commutativity between A_- and the
zero subgroup is used. Restriction compatibility produces a single
formal series independent of the cutoff.

The quotient of consecutive F-series proves integrality of H_g without
assuming an integral factorization theorem. Negative coefficients of
H_g are allowed and occur even in the affine rank-two setting. The
identity is only eventually true in each fixed root quotient, so it
does not imply theta_ng=theta_g^n or that theta_g is real.

The vanishing of low-degree same-ray structure corrections follows
from the full prefix identity and unitriangularity, with no cancellation
assumption about coefficients. The proof would work without positivity;
classical positivity is additional useful structure.

## 4. Logarithmic wall recovery

On a fixed sign chamber the negative factor is independent of g, so
log H_g is linear in g. At a boundary the moved zero factor fixes x^g,
which establishes continuous gluing of these linear expressions.

The wall-crossing order is correct:

    (A_- Z)x^g = A_-x^g * exp(L(g) A_-(Psi_Z)).

Hence the jump formula has the displayed A_-(Psi_Z), not Psi_Z and not
A_-^{-1}(Psi_Z). The factor  k in
Psi_Z=sum k lambda_k z^{k n_0} is necessary. It converts back to the
logarithmic group coordinate only after dividing by k. The D-normalized
axis example is consistent with the initial action (1+z_i)^(-g_i).

The reconstruction using r independent integral labels inside a rational
full-dimensional chamber determines the images of every x_i over Q.
The coefficient computations are finite at each cutoff, and the frozen
variables are fixed, so this indeed determines the automorphism needed
for inversion. This is recovery of the local factor through the chosen
cutoff, not a finite description of an infinite scattering diagram.

## 5. Large-label limits

The eventual polynomial formula from exp(n log H_g) is valid and is
independent of the C0 parameter theorem. Its highest possible n-degree
comes solely from root-degree-one terms. If this leading coefficient
vanishes, the full coefficient can have lower positive degree; no
eventual vanishing follows merely from the leading limit.

For the arbitrary-two-label multiplication limit, the C0 homogeneous
component argument is valid. Centrality of the finite arrangement makes
each homogeneous part glue separately. Finite piecewise polynomials are
locally Lipschitz, yielding the stated O(1/n) fixed-coefficient error.
At B=0 the delta_i formula is the exact binomial identity. There is no
analytic convergence claim or uniform-in-degree estimate.

## 6. Novelty and interpretation limits

These arguments continue to use the established group factorization
description of scattering and the last-exponent characterization of
theta coefficients. They do not supply an intrinsic high-rank greedy
model. Their potentially new content consists of exact numerical
relations between theta families, explicit stabilization thresholds,
continuous compatibility of branch coefficients, and extraction of a
positive transverse formal algebra. Merely renaming A_- or its
logarithm should not be presented as an independent construction.

An apparent stronger prior statement in an early Leung--Ma--Young
preprint requires version control; details are in
`LITERATURE_VERSION_CHECK.md`. The current author manuscript replaces
that portion with a marked-tree Maurer--Cartan construction. No direct
prior statement of the explicit ray-ratio theorem was found in the
sources inspected by this reviewer. That does not establish priority.
