# Literature and route record for the stable-ray independent review

Date: 2026-11-14, Asia/Shanghai.

## Leung--Ma--Young: a material version distinction

Title: *Refined scattering diagrams and theta functions from asymptotic
analysis of Maurer--Cartan equations*.

Primary records inspected:

- https://arxiv.org/abs/1902.05765 (v1 15 February 2019; v2 27 March 2019).
- https://archive.mpim-bonn.mpg.de/id/eprint/1320/1/preprint_2019_5.pdf
  (an early 32-page repository file with preliminary front matter).
- https://archive.ymsc.tsinghua.edu.cn/pacm_download/65/11722-qScatteringIMRNv2.pdf
  (later author IMRN manuscript, 29 pages, journal template placeholder
  date/DOI on its title page; those placeholders are not bibliographic data).
- https://doi.org/10.1093/imrn/rnz220 is the published article identifier.

The old MPIM file's Lemma 3.18 constructs a flat section equal to a
monomial in a neighborhood of a sufficiently far part of the label ray;
Theorem 3.19 identifies it with broken-line theta. Taken as an
unconditional prescription for all classical cluster labels, that would
force same-ray powers to be exact, contrary to the known affine
Chebyshev product. It is therefore unsafe to import that old statement
as a stronger theorem or as a priority objection to the present result.

The later author manuscript has a substantially different Section 4.3.2.
It constructs theta via the square-zero dg Lie algebra extension and a
marked-tree Maurer--Cartan expansion; its relevant identification is
Theorem 4.20. The early ray-neighborhood prescription is not the
construction used there. This comparison is a warning about the old
file, not an accusation that the current published theorem is false.
The later source is useful for broad theta/tree background but was not
used in the present algebraic proof.

## Other sources and search outcomes

GHKK, *Canonical bases for cluster algebras*,
https://arxiv.org/html/1411.1394v2 : inspected the primary record and
the stated formal-versus-regular distinction, and reopened Proposition
1.20, Theorem 1.21 (including its finite-order refinement argument), and
Proposition 6.4. The incoming-factor theorem indeed normalizes the ray
factor near p*(n), and its group-coordinate bijection is proved order
by order. Its incoming-factor and last-exponent framework is the
established input, not a new theorem of this project.

Searches combining theta, cluster/scattering, stable quotient, large ray,
asymptotic multiplicativity, and piecewise polynomial did not locate an
exact statement of the explicit eventual quotient stabilization.
This is a limited search outcome, not a proof of novelty.

The 2026 Zenodo record
https://zenodo.org/records/19580721/files/033_scattering_completion_tail_orbits.pdf?download=1
concerns recovering scattering from renormalized coefficient-tail orbits
of analytic functions, with a separate BPS/spectral-network input. Its
abstract and introduction were inspected because of similar keywords.
It does not state the cluster theta-label ray identity being studied
here. Its long chain of preceding hypotheses was not audited, and none
of its conclusions is used.

## Route decisions

1. Joint coefficient continuity: the zero-Lie-character / final-row
   mechanism survives independent algebraic review.
2. Stable unshifted rays: one local-truncation clarification was needed;
   the stated threshold survives.
3. Wall recovery: action order and D-normalization checked; no missing
   inverse found.
4. Attempted stronger universal same-ray identity: rejected. Existing
   affine Chebyshev behavior and the distinction between fixed-prefix
   stabilization and a full-series identity rule it out.
5. Translated rays and transverse multiplication: promising extension
   completed in `TRANSVERSE_RAY_THEOREM.md`. Positivity comes from an
   exact stabilized zero-root slice, not from assuming a new cluster
   seed.
6. Newton face claim: retained only in the coefficientwise truncated
   sense; a global Newton-polytope assertion requires an additional
   uniform support result and remains open here.
