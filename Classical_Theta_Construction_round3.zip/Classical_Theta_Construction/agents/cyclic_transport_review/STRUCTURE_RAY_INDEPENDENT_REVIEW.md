# Independent review of the positive binomial theorem for multiplication rays

Date: 2026-11-13, UTC.

## Verdict

The theorem in ../../notes/STRUCTURE_RAY_POSITIVE_COPIES.md is valid under
the already proved finite incoming-extraction and effective translated-ray
inputs. The arbitrary-endpoint step should be stated using the exact
signed-factor argument below. With that addition, I found no remaining
proof gap in the threshold, output-dependent endpoint, multi-input
extension, actual active-color bijection, or eventual-support test.

This is an independent internal proof review, not an external certification
or a proof of literature priority. No further random computations are needed
for the issues reviewed here: the parent already has independent
triangular-subtraction and endpoint checks, and the argument below resolves
the remaining conceptual risks directly.

The nontrivial assertion is the explicit common threshold and the actual
positive binomial coefficients already at that threshold. Eventual
polynomiality, or qualitative eventual positivity of differences, should
not be presented as the new result.

## 1. Exact arbitrary-endpoint local-star lemma

Fix a finite downward root set \(J\). Use label coordinates, with root
evaluation \(m\mapsto m^{\mathsf T}Da\). Write the already established
coarse signed factorization
\[
 C=A_g^-Z_gA_g^+,\qquad
 P_g=\{a\ge0:g^{\mathsf T}Da=0\}.
\tag{1}
\]
The effective translated-ray theorem gives
\[
 \vartheta_{Q_+,ng+h}
 =A_g^-\bigl(x^{ng}\eta_h^g\bigr)\pmod{I_J},
 \qquad n>T_J(g;h).
\tag{2}
\]
Its proof uses coefficientwise restriction to \([0,p]\) for each \(p\in J\);
that local restriction has already repaired the only threshold issue in
the earlier proof.

Let \(Q\) be any desired generic endpoint, written now as a root covector.
Set \(u=D^{-1}Q\). Choose a sufficiently small positive rational
\(\varepsilon\) and put
\[
 q=g+\varepsilon u.
\]
Choose it so that every root in \(J\) with nonzero \(g\)-evaluation
retains its sign. Every zero root has the sign of \(u\), equivalently
of \(Q\). This is a fixed finite sign condition, independent of \(n\).

Factor the zero group \(Z_g\) by the \(u\)-signs, and call its negative
factor \(Z_{g,u}^-\). Signed-factor uniqueness gives
\[
 A_q^-=A_g^-Z_{g,u}^-.
\tag{3}
\]
The standard finite scattering-chart relation is
\(\vartheta_{Q_+,m}=A_q^-\vartheta_{q,m}\). Combining it with
(2)–(3) yields exactly
\[
 \begin{aligned}
 \vartheta_{q,ng+h}
  &=(Z_{g,u}^-)^{-1}(A_g^-)^{-1}
       A_g^-(x^{ng}\eta_h^g)\\
  &=x^{ng}(Z_{g,u}^-)^{-1}\eta_h^g
       \pmod{I_J}.
 \end{aligned}
\tag{4}
\]
The last equality holds because every root in the zero group annihilates
\(x^{ng}\); as derivations, these root operators commute with
multiplication by that monomial. No commutativity of the zero group
itself is assumed.

Define
\[
 \eta_{u,h}^g=(Z_{g,u}^-)^{-1}\eta_h^g.
\tag{5}
\]
It is the usual local-star theta function at the refinement \(u\), and is
independent of \(n\). Its coefficients are nonnegative integers. This
can be seen either from the inherited positive local-star diagram, or
directly from (4) and positivity of the ordinary theta expression at
\(q\) for any integer \(n>T_J(g;h)\).

Thus (4) is an exact effective identity. It does not assume that a
theta function becomes monomial near its own ray with an unspecified
stabilization scale. For \(h=0\), \(\eta_{u,0}^g=1\).

For an actual alphabet, use the ordinary finite-root broken-line objects
of the local-star diagram, decorated by the already constructed positive
wall alphabets. Each nonconstant bend raises root degree, so a target
\(p\) permits at most \(|p|\) such bends and finitely many decorations.
This is an explicit finite positive catalog, not a set manufactured
from a known coefficient.

## 2. Why the path to an arbitrary endpoint is positive at the threshold

Convert \(q\) to the same coordinates as \(Q\) when choosing the segment.
A zero root of \(g\) has the same nonzero sign at both endpoints, so the
straight segment crosses none of its hyperplanes. A nonzero root
hyperplane is crossed at most once. A generic choice of \(Q\) within its
fixed chamber avoids joints; this does not change the theta expression.

The joint-avoidance assertion is not automatic for an arbitrary endpoint
representative, but it is available. For two independent root normals
\(a,b\), an intersection in the segment requires
\[
 (g^{\mathsf T}Da)(u^{\mathsf T}Db)
 -(g^{\mathsf T}Db)(u^{\mathsf T}Da)=0.
\]
Unless both \(g\)-evaluations vanish, this is a proper linear condition
on \(u\). If both vanish, the segment has a fixed nonzero sign on each
and does not meet that joint. There are only finitely many relevant
conditions.

Let \(a\) be the primitive positive root direction of a crossed wall,
\(\delta_a=\gcd_i(D_i a_i)\), and \(\nu_a=Da/\delta_a\).
The crossing orientation is determined by the initial \(g\)-sign, so the
wall's positive function is applied to a monomial of current root state
\(r\) with exponent
\[
 E(n,r)=n|\nu_a\cdot g|
       +\sigma_a\,\nu_a\cdot(h+Br),
\tag{6}
\]
where \(\sigma_a\in\{1,-1\}\) is fixed for that crossing. This treats
positive-to-negative and negative-to-positive crossings together.
The integer \(|\nu_a\cdot g|\) is strictly positive.

If a nonconstant wall term can contribute through \(J\), then
\(r+\ell a\in J\) for some \(\ell\ge1\). Downward closure gives
\(s=r+a\in J\). Since \(a^{\mathsf T}DBa=0\),
\[
 (h+Br)^{\mathsf T}Da=(h+Bs)^{\mathsf T}Da.
\]
Hence \(N_0>T_J(g;h)\) implies \(E(N_0,r)\ge0\), indeed strict
positivity for every such relevant state. The crucial target is
\(s=r+a\); using \(a\le r\) would be wrong.

If no nonconstant term can survive the cutoff at a given state, discard
that wall action at that state: only its constant term contributes.
This convention is needed before speaking about ordered slots, since the
untruncated exponent at an irrelevant state need not be nonnegative.
It does not affect any coefficient through \(J\).

For every relevant state,
\[
 E(N_0+k,r)=E(N_0,r)+k|\nu_a\cdot g|.
\tag{7}
\]
The complete wall path and the local-star starting catalog are fixed
independently of \(k\).

## 3. Dual endpoint extraction and the target-dependent chamber

Put \(G=\sum_i g_i\), \(H=\sum_i h_i\), and
\(R_n=nG+H+Bp\). The established theta coefficient-duality input gives
\[
 c_p(n)=[y^p x^{R_n}]
       \prod_i\vartheta_{Q_n,ng_i+h_i},
 \qquad Q_n=DR_n+\epsilon,
\tag{8}
\]
with a sufficiently small generic positive independent perturbation.
Equivalently, this is the coefficient of \(x^{nG+H}z^p\).

The coefficient functional in (8) kills every other theta summand.
If \(y^s\vartheta_r\) can contribute, its extra root is \(a=p-s\)
and \(R_n=r+Ba\). For \(a>0\), the last-exponent extraction rule kills
that coefficient at \(D(r+Ba)+\epsilon\); for \(a=0\), the leading
coefficient is one. If \(s\not\le p\), positive root support rules it
out before extraction. This verifies the indexing in the parent note.

The chamber stabilization proof must take place in \([0,p]\), not claim
that the same bound fixes every irrelevant root of a larger \(J\).
For \(a\le p\) with \(G^{\mathsf T}Da\ne0\),
\[
 N_0>T_J(G;H)
 \ \Longrightarrow\
 \operatorname{sgn}\bigl((nG+H+Bp)^{\mathsf T}Da\bigr)
 =\operatorname{sgn}(G^{\mathsf T}Da)
\]
for every \(n\ge N_0\), by the term \(s=p\) in the defining maximum.
For a zero \(G\)-root, the remaining evaluation is constant in \(n\);
the fixed perturbation resolves a possible tie. A single sufficiently
small perturbation works for all \(n\ge N_0\), because the nonzero
leading evaluations have their smallest absolute margin at \(N_0\).

Choose one fixed generic representative \(Q_p\) of the resulting finite
chamber. Equation (8) is unchanged if all factors are evaluated there.
Apply Sections 1–2 independently to every input, always in the quotient
\([0,p]\). Each intermediate root state is at most \(p\), since no
positive wall or local-star contribution can later decrease root degree.
Thus all input thresholds in the theorem suffice simultaneously.

The cases \(G=0\) or \(g_i=0\) cause no exception. If \(G=0\), the
output endpoint is already independent of \(n\). If \(g_i=0\), that
input has only a fixed local-star catalog and no positive-size copy
groups.

## 4. Actual positive binomial coefficients

At every relevant wall of every input, use the ordered slots in (7):
the fixed base slots and \(k\) groups of
\(|\nu_a\cdot g_i|\) slots. The same color set \([k]\) is used
throughout the entire tuple of input histories.

A nonempty slot carries an actual positive wall-alphabet object and a
nonzero positive root increment. A color is active if any slot of that
color is nonempty in any factor at any wall. A total target \(p\) permits
at most \(|p|\) active colors.

For \(j\le|p|\), let \(V_{p,j}\) be the actual history catalog with
colors \([j]\), every color active, and combined target increment \(p\).
Its local-star starting objects, base-slot choices, and wall decorations
are retained. Relabeling the active colors of a history over \([k]\)
in increasing order gives an element of \(V_{p,j}\) and a \(j\)-subset
of \([k]\). The inverse inserts empty groups on unused colors.

Removing or inserting empty groups does not change any earlier root
increment. Therefore all later base exponents \(E(N_0,r)\), relevance
decisions, and available decorations are unchanged. This verifies the
state-dependent part of the bijection, which is the only subtlety in
the usual active-color argument.

It follows that
\[
 c_p(N_0+k)=\sum_{j=0}^{|p|}|V_{p,j}|\binom{k}{j}.
\tag{9}
\]
The construction treats every number of inputs simultaneously; it does
not iterate binary theta multiplication or need thresholds for
intermediate output rays.

## 5. Consequences and bounds checked

Equation (9) proves all claimed forward-difference inequalities.
At \(k=|p|\), every \(\binom{|p|}{j}\) is strictly positive. Thus
\[
 c_p(n)\text{ is eventually nonzero}
 \quad\Longleftrightarrow\quad
 c_p(N_0+|p|)>0.
\tag{10}
\]
If it is nonzero there, it remains positive for all larger \(n\).
The first nonzero value after \(N_0\) is detected by the least \(j\)
with \(V_{p,j}\ne\varnothing\).

For zero offsets and \(|s|\le d\),
\[
 |(Bs)^{\mathsf T}Da|
 =|(B(s-a))^{\mathsf T}Da|
 \le M|a|\,|s-a|
 \le Md^2/4,\qquad M=\max_{i,j}|D_iB_{ij}|.
\]
Every nonzero denominator \(|g^{\mathsf T}Da|\) is a positive
integer. Consequently
\[
 N_0=\lfloor Md^2/4\rfloor+1
\tag{11}
\]
works uniformly for all integral input directions, their sum, and every
number of inputs. The specified offset-dependent maximum is also
correct; a coarse bound adds
\(d\max_i|D_i h_i|\) for each relevant offset, including \(H\).

These are finite root-window claims. Neither (9) nor (10) supplies
finite Laurent support for an arbitrary complete theta function or its
whole product.

## 6. Literature and interpretation

The exact signed-factor derivation uses the standard reconstruction and
local-star formalism already reviewed in
../stable_hall_interface/NOVELTY_LOCAL_STAR.md:
Bridgeland, arXiv:1603.00416, Section 3; and
Cheung–Magee–Mandel–Muller, arXiv:2505.09585v2, Section 2.5.
The local-star theta family and positivity are established structures,
not new objects.

Qin, Freezing operators on cluster algebras, arXiv:2407.03186v1,
Proposition 6.19 and its surrounding freezing results, already gives
eventual translation/freezing statements in coordinate directions under
the stated Laurent-finiteness assumptions. The explicit arbitrary-ray
finite-root threshold and simultaneous multiplication-copy catalogs are
different claims.

A fresh targeted search for theta structure constants, binomial expansions,
finite differences, scaling, and positive binomial coefficients found the
already identified close 2026 source Reading–Stella, Mutation of Theta
Functions, arXiv:2603.19391v4 (8 November 2026). Its current primary text,
introduction and Sections 5.1–5.3, concern mutation symmetries, pairs of
broken lines, and dominance restrictions. They do not state (9)–(11).
This comparison uses no new 2026 theorem as an input.

Primary URLs:

* https://arxiv.org/abs/1603.00416
* https://arxiv.org/html/2505.09585v2
* https://arxiv.org/html/2407.03186v1
* https://arxiv.org/html/2603.19391v4

Search absence is not a proof of priority. The claim should remain an
effective quantitative property of the existing theta family, with a
literal positive history realization, rather than an independent
scattering-free construction of that family.
