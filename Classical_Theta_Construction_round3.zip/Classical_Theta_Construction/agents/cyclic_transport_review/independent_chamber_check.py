"""Independent adversarial checks in mixed-sign cut chambers.

Imports the proposed object algorithms, but supplies unrelated graph families,
parameter sampling, and independent full target-catalog checks. Exact rational
arithmetic throughout. No whole finite sets are matched by their cardinalities.
"""
from pathlib import Path
import sys, json
from fractions import Fraction as F
from itertools import combinations, product
from random import Random
from collections import Counter, defaultdict

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'intrinsic_greedy_round2'))
from cyclic_signed_flow_transport import SignedFlowUniverse, state_sign, is_axis, internal_nodes
from stable_tree_sweep import DegenerateProjection


def flag_encode(state, alg):
    arrows = list(state[1])
    flags = []
    def descend(j):
        if j[0] == 'leaf':
            return (j[1],)
        arrows.extend(j[1])
        S = tuple(sorted(v for child in j[2] for v in descend(child)))
        flags.append(S)
        return S
    for child in state[0]:
        descend(child)
    assert len(arrows) == alg.n - 1 and len(set(arrows)) == len(arrows)
    T = tuple(sorted(arrows))
    L = tuple(sorted(flags))
    assert len(L) <= alg.n - 1
    assert all(not set(A) & set(B) or set(A) <= set(B) or set(B) <= set(A)
               for A, B in combinations(L, 2))
    for S in [tuple(range(alg.n))] + list(L):
        inside = [e for e in T if set(alg.original_edges[e][:2]) <= set(S)]
        assert len(inside) == len(S) - 1
        components = [{v} for v in S]
        for e in inside:
            a, b = alg.original_edges[e][:2]
            A = next(C for C in components if a in C)
            B = next(C for C in components if b in C)
            assert A is not B
            components.remove(A); components.remove(B); components.append(A | B)
        assert len(components) == 1
    return T, L


def flag_decode(flag, alg):
    T, L = flag
    def parts(S, proper):
        ss = set(S)
        eligible = [A for A in L if set(A) <= ss and (not proper or set(A) != ss)]
        maximal = [A for A in eligible if not any(set(A) < set(B) for B in eligible)]
        covered = set(v for A in maximal for v in A)
        return tuple(sorted(maximal + [(v,) for v in S if v not in covered]))
    def cross(P):
        membership = {v: i for i, S in enumerate(P) for v in S}
        return tuple(e for e in T if all(v in membership for v in alg.original_edges[e][:2])
                     and membership[alg.original_edges[e][0]] != membership[alg.original_edges[e][1]])
    def child(S):
        if len(S) == 1:
            return ('leaf', S[0])
        assert S in L
        P = parts(S, True)
        return ('J', cross(P), tuple(child(A) for A in P))
    P = parts(tuple(range(alg.n)), False)
    return tuple(child(A) for A in P), cross(P)


def chamber_signature(theta):
    n = len(theta)
    out = []
    for size in range(1, n):
        for C in combinations(range(1, n), size - 1):
            s = theta[0] + sum(theta[i] for i in C)
            if not s:
                return None
            out.append(1 if s > 0 else -1)
    return tuple(out)


def sample_chambers(n, seed, count=3, per=4):
    rng = Random(seed)
    grouped = defaultdict(list)
    for _ in range(100000):
        th = [F(rng.randrange(-10**7, 10**7)) for _ in range(n - 1)]
        th.append(-sum(th))
        # Force at least two positive and two negative entries where possible.
        if n >= 4 and (sum(x > 0 for x in th) < 2 or sum(x < 0 for x in th) < 2):
            continue
        sig = chamber_signature(th)
        if sig is None or len(grouped[sig]) >= per:
            continue
        grouped[sig].append(tuple(th))
        ready = [v for v in grouped.values() if len(v) == per]
        if len(ready) >= count:
            return ready[:count]
    raise AssertionError('parameter sampling did not finish')


def check_one(name, n, edges, parameters):
    alg = SignedFlowUniverse(n, edges)
    common = alg.universe(parameters[0])
    states = set(common)
    flags = [flag_encode(s, alg) for s in common]
    assert len(flags) == len(set(flags))
    assert all(flag_decode(f, alg) == s for f, s in zip(flags, common))
    fixed = []
    state_checks = 0
    for theta in parameters:
        assert set(alg.universe(theta)) == states
        pos = []
        for s in common:
            t = alg.involution(theta, s)
            assert t in states
            assert alg.involution(theta, t) == s
            assert t == s or state_sign(t) == -state_sign(s)
            if t == s:
                assert state_sign(s) == 1
                pos.append(s)
            state_checks += 1
        sw = alg.quotient(tuple((i,) for i in range(n)))
        independently_enumerated = set(o for o in sw.enumerate_objects(tuple(range(n)), theta) if is_axis(o))
        images = set()
        for s in pos:
            assert all(j[0] == 'leaf' for j in s[0])
            T = tuple(sw.to_local[e] for e in s[1])
            images.add(sw.encode(tuple(range(n)), T, theta))
        assert images == independently_enumerated
        fixed.append(tuple(pos))
    maps, inverses = [], []
    longest = 0
    changed = 0
    for i, theta in enumerate(parameters):
        m = {}
        for s in fixed[i]:
            t, path = alg.transport(theta, parameters[0], s)
            back, rev = alg.transport(parameters[0], theta, t)
            assert back == s and rev == list(reversed(path))
            m[s] = t
            longest = max(longest, len(path) - 1)
            changed += t != s
        assert set(m.values()) == set(fixed[0])
        maps.append(m)
        inverses.append({b: a for a, b in m.items()})
    coherent = lambda i, j, s: inverses[j][maps[i][s]]
    for s in fixed[0]:
        x = s
        loop = [0, 1, 2, 3, 1, 0]
        for i, j in zip(loop, loop[1:]):
            x = coherent(i, j, x)
        assert x == s
    return dict(name=name, n=n, m=len(edges), parameters=[[str(x) for x in t] for t in parameters],
                states=len(common), signs=dict(Counter(state_sign(s) for s in common)),
                state_checks=state_checks, axis_objects=len(fixed[0]),
                max_J_depth=max((sum(internal_nodes(j) for j in s[0]) for s in common), default=0),
                changed_objects=changed, max_path=longest, boxes=len(alg.boxes),
                box_path_steps=sum(b.path_steps for b in alg.boxes.values()),
                flagged_tree_roundtrips=len(flags), passed=True)


def main():
    rng = Random(8903)
    families = []
    # Eulerian graphs exercise total cancellation; their full axis catalog is empty.
    for n in (3, 4, 5):
        edges = [(i, (i + 1) % n, 0) for i in range(n)]
        families.append((f'directed_cycle_{n}', n, edges))
    # Opposite-arrow pairs are retained, including parallel arrows.
    families.append(('opposite_complete_4', 4,
                     [(i, j, 0) for i in range(4) for j in range(4) if i != j]))
    for case in range(18):
        n = 4 if case < 10 else 5
        edges = []
        for i, j in combinations(range(n), 2):
            u, v = (i, j) if rng.randrange(2) else (j, i)
            edges.append((u, v, 0))
            if rng.randrange(4) == 0:
                edges.append((v, u, 0))
            if rng.randrange(5) == 0:
                edges.append((u, v, 1))
        families.append((f'mixed_multigraph_{case}', n, edges))
    results = []
    for k, (name, n, edges) in enumerate(families):
        for j, parameters in enumerate(sample_chambers(n, 9001 + k, count=3)):
            try:
                out = check_one(name + f'_chamber{j}', n, edges, parameters)
            except DegenerateProjection:
                # A structural nongenericity would require attention; random coincidence
                # can be replaced by another whole same-chamber sample, never ignored.
                parameters = sample_chambers(n, 8000001 + 100 * k + j, count=1)[0]
                out = check_one(name + f'_chamber{j}_resampled', n, edges, parameters)
            results.append(out)
            print(json.dumps({key: out[key] for key in ('name', 'states', 'axis_objects', 'changed_objects', 'max_path', 'passed')}), flush=True)
            (HERE / 'independent_chamber_results.json').write_text(json.dumps(results, indent=2))
    summary = dict(cases=len(results), state_checks=sum(x['state_checks'] for x in results),
                   signed_states=sum(x['states'] for x in results),
                   axis_objects=sum(x['axis_objects'] for x in results),
                   changed_objects=sum(x['changed_objects'] for x in results),
                   flagged_tree_roundtrips=sum(x['flagged_tree_roundtrips'] for x in results),
                   max_path=max(x['max_path'] for x in results),
                   empty_catalog_cases=sum(x['axis_objects'] == 0 for x in results),
                   passed=True)
    (HERE / 'independent_chamber_summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
