# Cyclic flow-tree transport through flagged spanning trees

Independent reconstruction and proof review, 2026-11-13.

## Main result and its scope

Let \(Q\) be a finite directed multigraph on a totally ordered vertex set
\(V\), with individually labeled and totally ordered arrows. Opposite arrows
and parallel arrows are allowed. For generic covectors \(\theta,\psi\) in one
chamber of the cut hyperplanes
\[
 \sum_{i\in A}\theta_i=0,\qquad \varnothing\ne A\subsetneq V,
 \qquad \sum_{i\in V}\theta_i=0,
\]
there is an explicit finite bijection between their positive colored binary
flow trees. All singleton leaves retain their original labels. Every child
covector is recomputed by the actual flow projection. Directed cycles are
allowed; no assumption of acyclicity or pairwise balance is made.

The algorithm consists of arrow exchanges, a finite lattice-point toggle on
Eulerian cographic configurations, and a root graft/ungraft involution. Its
common signed state space has a concrete description:

> A state is an actual spanning tree \(T\) of \(Q\), together with a laminar
> family \(\mathcal L\) of nontrivial connected vertex subsets of \(T\).
> Each flagged quotient tree satisfies a fixed residual-reference condition;
> the top quotient tree is \(\theta\)-stable. Its sign is
> \((-1)^{|\mathcal L|}\).

The signed universe is literally the same throughout one cut chamber.
It contains no sets invented to have the size of a coefficient. No theta
coefficient, scattering function, or stable-tree count is used as an oracle.
Every state uses exactly \(|V|-1\) distinct original arrows.

Choosing one reference parameter makes the resulting positive transports
strictly coherent: every composition through intermediate parameters agrees
with the direct reference-based transport. This includes pentagons. It is a
statement about these actual raw-color objects, relative to specified orders
and references; it does not assert natural equivariance under permutations
of equal labels, or an unproved descent through primitive phase factors.

The scalar flow-tree formula, its invariance across fake walls, and the
rooted-tree formula for a plethystic inverse are prior work. The constructive
content proved here is the combination of actual arrow sweeps, residual
normalization, flagged-tree cancellation, and complete descendant transport.
Historical priority for this exact combination remains a literature question.

## 1. Conventions, quotients, and genericity

The incidence convention is
\[
 \partial(u\longrightarrow v)=e_u-e_v.
\]
For disjoint subsets \(A,B\subseteq V\), set
\[
 \eta(A,B)=|E(A,B)|-|E(B,A)|.
\]
For an induced support \(S\), put
\[
 v_S=-\partial_S{\bf1},\qquad
 v_S(i)=\eta(S,\{i\}).
\tag{1}
\]
A spanning tree means an undirected spanning tree made of the actual
directed arrows. Thus opposite or parallel arrows give different choices.
It is \(\theta\)-stable if the unique solution of
\(\partial_T x=\theta\) has every \(x_e>0\). If deleting \(e=u\to v\)
leaves the component \(A\) containing \(u\), then
\[
 x_e=\theta(A).
\tag{2}
\]

For a partition \(P\) of a subset \(S\subseteq V\), the graph \(Q[P]\)
has the blocks of \(P\) as vertices. It retains every original arrow with
endpoints in different blocks, including its original identity and order.
Arrows internal to a block are discarded. They have already become internal
data at the next level of the hierarchy and do not contribute to cuts.
In particular, contraction must not cancel opposite arrows.

Let \(\theta^P(A)=\theta(A)\) for \(A\in P\). If \(P\) is further
coarsened to a partition \(R\), then
\[
 \sum_{A\in P,\ A\subseteq C}v_P(A)=v_R(C).
\tag{3}
\]
Indeed, all internal arrow contributions cancel in the sum. For a cut
\(L|R'\) at any recursive node, write
\[
 a=\eta(L,R'),\quad h=\theta(L),\quad
 \theta'=\theta+\frac h a\,v_S.
\tag{4}
\]
Whenever \(a\ne0\), summing (4) over blocks commutes with contraction.
Both the admission condition \(h/a>0\) and the ordered surplus-arrow
colors also commute with contraction, because they depend on exactly the
same arrows across the same original vertex cut.

We require a strongly generic parameter: every recursive restriction and
every quotient used below has nonzero proper cut sums and no simultaneous
distinct positive crossing times. This excludes only a finite union of
proper rational hyperplanes. There are finitely many supports, partitions,
and nonunary hierarchies. At a descendant support one can vary the original
covector inside that support with zero total sum; all ancestor cut sums,
and hence ancestor projection times, remain unchanged. Its descendant
restriction therefore varies freely in its zero-sum space. The excluded
equations are consequently nontrivial. Each initial cut chamber has strongly
generic rational points, and exact ordered infinitesimals can specify a
generic refinement.

## 2. The actual arrow sweep

For clarity, the complete elementary mechanism is recalled. It is the one
implemented and separately verified in
../intrinsic_greedy_round2/stable_tree_sweep.py.

Starting with a \(\theta\)-stable tree on \(S\), increase \(t\) along
\[
 \theta(t)=\theta+t v_S,\qquad t\ge0.
\tag{5}
\]
At the first vanishing tree edge, delete it and obtain trees on \(L,R\).
Choose \(L\) to contain the least vertex. The crossing time is
\(t=h/a>0\), with \(a,h\) as in (4).

If \(a>0\), departing bridges are \(E(L,R)\) and entering bridges are
\(E(R,L)\); the roles reverse if \(a<0\). Pair the \(k\)-th entering
arrow with the \(k\)-th departing arrow using the fixed arrow order.
There are exactly \(|a|\) unpaired departing arrows. These are the
positive colors of a binary node.

For a paired departure, exchange it with its paired entering arrow and
keep the entire two-component forest. The internal flows have unchanged
positive limits at the crossing, and the new bridge becomes positive on
the other side. Continue (5). For a surplus departure, record its color
and the cut, and recurse on the two component trees with the exact
restrictions of (4).

If no future edge vanishes, retain a terminal tree stable at the germ
\(t=+\infty\). Its defining condition is
\[
 (x_e(v_S),x_e(\theta))>_{\mathrm{lex}}(0,0)
 \quad\text{for every }e.
\tag{6}
\]
It need not be stable at \(t=0\).

This sweep is finite: each exchange passes a strictly later member of
the finite list of positive cut times, and each split reduces the support.
It has an actual inverse. Decode both children at (4), join them by the
specified surplus arrow just before the crossing, and run (5) backwards.
Every backwards-vanishing bridge was a forward entering arrow and has a
unique paired predecessor. For a terminal object, start from its infinity
germ and run the same backwards rule through the finite list of cuts.

Thus stable spanning trees are in bijection with binary colored flow
objects whose terminal leaves are arbitrary trees satisfying (6).
Ordinary axis-leaf flow trees are the subcatalog having singleton terminals
only. In a directed acyclic graph all nonsingleton terminals are absent.
In a cyclic graph they cannot simply be deleted from a parameter transport:
the resulting subset of stable trees can change. Sections 3–6 remove that
obstruction by an actual finite cancellation.

## 3. Residual trees have one fixed finite alphabet

### 3.1 A positive limiting forest and its Eulerian quotient

Fix a connected graph \(K\) on \(S\), with \(v=-\partial{\bf1}\).
For a terminal tree \(T\) satisfying (6), its limiting tree flow
\(f_0=x_T(v)\) is nonnegative. Let
\[
 F=\{e\in T:f_0(e)>0\}.
\tag{7}
\]
It is a forest, and \(f_0\), extended by zero off \(T\), is determined
by \(F\): a forest supports at most one flow of a specified divergence.
For every connected component \(C\) of \(F\),
\[
 0=(\partial f_0)(C)=v(C)=-\partial{\bf1}(C).
\tag{8}
\]
Contract \(F\), and retain all arrows outside \(F\), including loops
created by this contraction. Equation (8) says that this connected quotient
\(K/F\) is Eulerian. The loops are harmless and will contribute ordinary
pyramid columns to its cographic configuration.

The remaining tree arrows \(U=T\setminus F\) form a spanning tree of
\(K/F\). Their order-one flows are the unique tree flows for the parameter
\[
 \delta(C)=\theta(C).
\tag{9}
\]
Conversely, every \(\delta\)-stable tree \(U\) of \(K/F\) lifts to
\(F\cup U\), stable for \(v+\varepsilon\theta\) for sufficiently small
positive \(\varepsilon\). Its base flow is the same \(f_0\), positive on
\(F\), and its formerly zero flows are positive to first order.

Therefore, for each fixed feasible \(F\), residual trees are exactly
the stable spanning trees of its Eulerian quotient. This argument also
proves that the collection of feasible positive limiting forests is
independent of the generic perturbation.

### 3.2 A common cographic lattice polytope

Let \(G\) be any connected Eulerian directed multigraph, loops allowed.
Put \(r=|E|-|V|+1\), and choose an integral cycle-lattice basis as the
rows of a totally unimodular matrix \(A\). Write \(a_e\in\mathbb Z^r\)
for its columns. The map \(A^{\mathsf T}\) identifies \(\mathbb Z^r\)
with the integral circulation lattice.

Since \({\bf1}\) is an integral circulation, there is an integral vector
\(\kappa\) such that
\[
 A^{\mathsf T}\kappa={\bf1}.
\tag{10}
\]
In particular,
\[
 Q_G=\operatorname{conv}\{a_e:e\in E\},\qquad
 C_G=\operatorname{pos}\{a_e:e\in E\},\qquad
 \langle\kappa,a_e\rangle=1.
\tag{11}
\]
The height \(h=\langle\kappa,-\rangle\) is primitive, \(C_G\) is
full dimensional and pointed, and \(\dim Q_G=r-1\). For a connected
Eulerian graph with at least two vertices, \(r>0\).

For any generic zero-sum parameter \(\delta\), the complements of
\(\delta\)-stable spanning trees give a unimodular triangulation of
\(Q_G\). Here is a proof valid also for the unbounded flow polyhedron.
Choose \(f\) with \(\partial f=\delta\) and write
\[
 P_\delta=\{y\in\mathbb R^r:f+A^{\mathsf T}y\ge0\}.
\tag{12}
\]
Adding a large positive multiple of \({\bf1}\) makes the flow strictly
positive, so (12) is nonempty and full dimensional. It is pointed because
\(A^{\mathsf T}\) is injective. A vertex has forest support; generic cut
sums force that support to be a spanning tree, with strictly positive
tree flows. Conversely such a tree gives a vertex.

The normal cone for minimizing at that vertex is
\[
 \operatorname{pos}(a_e:e\notin T).
\tag{13}
\]
The columns in (13) are a unimodular basis. The union of all these
minimizing normal cones is \(C_G\): linear programming duality says
precisely that a functional in the cone of the inequality normals is
bounded below, and a nonempty optimal face of a pointed polyhedron
contains a vertex. Distinct cones have disjoint relative interiors and
meet in common faces. Cutting by \(h=1\) proves the triangulation claim.
No completeness of the normal fan in \(\mathbb R^r\) is being assumed.

Repeated columns retain their original arrow identities. In any one generic
triangulation, two distinct stable trees cannot yield the same maximal
geometric cone: they would be distinct vertices with overlapping normal
cone interiors. Thus decoding a simplex back to its stable tree is unique
within that parameter. Loop columns are independent pyramid directions;
they must not be dropped from the cycle-lattice rank.

This height-one cographic geometry is established prior work. The proof
here records the exact generic-parameter version needed for residuals.

### 3.3 Explicit transport between the triangulations

Fix one rational \(w\in\operatorname{int}(C_G)\) avoiding every possible
simplex-facet span. There are only finitely many candidate column bases.
For a simplex with ordered rays \(u_1,\dots,u_r\), expand
\(w=\sum\lambda_j u_j\). Its \(j\)-th facet is open when
\(\lambda_j<0\), closed otherwise. Its half-open fundamental Box is
\[
 \Pi^w=\left\{\sum b_j u_j:
 0<b_j\le1\ \text{at open coordinates},\
 0\le b_j<1\ \text{at closed coordinates}\right\}.
\tag{14}
\]
The half-open cones partition \(C_G\). Because the simplex is unimodular,
its unique lattice Box point is
\[
 b_T=\sum_{\lambda_j<0}u_j,
\tag{15}
\]
and its height belongs to \(\{0,\dots,r-1\}\).

Use the common finite signed set
\[
 {\cal E}_G=
 \{(v,B):v\in C_G\cap\mathbb Z^r,\ B\subseteq[r],\
 h(v)+|B|\le r-1\},
 \qquad \operatorname{sgn}(v,B)=(-1)^{|B|}.
\tag{16}
\]
For a triangulation, locate \(v\) in its half-open simplex cone and write
uniquely
\[
 v=b+\sum n_j u_j,\qquad n_j\in\mathbb N.
\]
Take the least \(j\) with \(j\in B\) or \(n_j>0\). If none exists,
fix the state. Otherwise toggle by
\[
 (v,B)\longleftrightarrow(v+u_j,B\setminus\{j\})
 \quad\text{when }j\in B,
\tag{17}
\]
using the inverse subtraction when \(j\notin B,n_j>0\).
The point remains in the same half-open cone; the same index is chosen
on the return step. This is a sign-reversing, height-preserving involution,
whose fixed points are precisely \((b_T,\varnothing)\).

Alternate the source and target involutions in (16), starting at a source
fixed point, until a target fixed point is reached. The finite two-colored
involution graph has degree at most two; an endpoint path cannot enter a
cycle. All fixed points are positive, so the other endpoint has the target
color. The reversed path is the inverse map. This gives an actual bijection
of stable trees, not a correspondence inferred from volume.

Choose a generic reference parameter \(q_K\) for each quotient graph \(K\).
For each forest stratum (7), apply this Eulerian Box transport from (9)
to the component sums of \(q_K\), and restore the unchanged arrows of \(F\).
This gives mutually inverse finite maps
\[
 N_{K,\theta}:{\cal R}_{K,\theta}\longrightarrow{\cal R}_K,
 \qquad {\cal R}_K={\cal R}_{K,q_K}.
\tag{18}
\]
For a singleton graph the residual alphabet is the unique empty tree and
normalization is the identity. Direct pairwise Box transports need not
compose; normalization always uses the fixed reference. The complete
construction below only needs (18) and its inverse.

## 4. One finite signed universe, stated as actual objects

For every support \(S\subseteq V\), define a signed hierarchy \(J(S)\)
recursively.

* On a singleton, it has one positive leaf with that original label.
* Otherwise choose a partition \(P\) of \(S\) with at least two blocks,
  an actual residual-reference tree \(r\in{\cal R}_{Q[P]}\), and one
  hierarchy \(j_A\in J(A)\) for each block. Make a new internal root
  decorated by \(r\), with those children. This root contributes a minus
  sign.

Children are ordered by the least original vertex of their supports;
this only removes duplicate encodings of a set partition. An internal
node always has at least two children, so \(J(S)\) is finite and has at
most \(|S|-1\) internal nodes.

Define \({\cal S}_\theta(Q)\) to consist of:

1. a partition \(P\) of \(V\);
2. a \(\theta^P\)-stable actual spanning tree of \(Q[P]\);
3. one signed hierarchy \(j_A\in J(A)\) on each block.

The sign is the product of the hierarchy signs. Every construction uses
the restricted original graph and the original cross-arrow identities.

### Proposition 1. Equivalent flagged-tree description

There is an actual bijection between \({\cal S}_\theta(Q)\) and pairs
\((T,\mathcal L)\) satisfying the description at the start of this note.
Here is its full encoding and inverse.

To encode, take the union of the arrows of the top stable tree and of
every residual tree decorating an internal hierarchy node. At a node,
the child graphs are disjoint trees on disjoint supports, and its root
decoration is a tree connecting their contracted vertices. Their union
is therefore a tree. Induction, followed by the top stable tree, shows
that the full union is a spanning tree \(T\) of \(Q\).

No original arrow can occur twice. An arrow joins two original endpoints.
If those endpoints are in different children of a node, their lowest common
ancestor is that node, so the arrow is eligible for that node's decoration
only. Arrows in descendants have both endpoints within a single child.
The same reasoning handles the distinguished top stable node. Consequently
the union contains exactly \(|V|-1\) distinct original arrows.

Record the support of every internal \(J\)-node. These supports form a
laminar family \(\mathcal L\); they have size at least two, and their
induced subtrees in \(T\) are connected. The whole set \(V\) is allowed
in \(\mathcal L\): this is exactly the case where the distinguished top
stable node has one child and its own arrow set is empty.

Conversely, let \(T\) be a spanning tree and \(\mathcal L\) a laminar
family of subsets of size at least two, each connected in \(T\). For a
flag \(S\in\mathcal L\), its children are the maximal proper flags inside
\(S\), together with singleton vertices of \(S\) outside those flags.
Contract their connected subtrees in \(T[S]\). The remaining original
arrows are a unique quotient tree. Require this tree to belong to the fixed
alphabet \({\cal R}_{Q[P_S]}\). This determines its internal decoration.
At the distinguished top node, use the maximal flags of \(\mathcal L\)
and remaining singleton vertices; its contracted tree is required to be
\(\theta\)-stable. These conditions reconstruct the original state uniquely.
The sign is exactly \((-1)^{|\mathcal L|}\).

In particular, if \(\tau(Q)\) is the number of actual spanning trees,
\[
 |{\cal S}_\theta(Q)|
 \le \tau(Q)\sum_{j=0}^{|V|-1}
       \binom{2^{|V|}-|V|-1}{j}.
\tag{19}
\]
This rough bound is not an efficiency claim. It is a uniform finite bound
in the original graph data, independent of the parameter within its chamber.

### Proposition 2. The universe is constant in a cut chamber

For every partition \(P\), each flow of a quotient spanning tree is a
sum of original \(\theta_i\) over a proper original vertex subset,
with its sign fixed by the orientation of its actual arrow. Therefore
\({\cal H}_{Q[P],\theta^P}\) is literally the same set throughout one
chamber of all original cut hyperplanes. The hierarchies \(J\) use fixed
references and do not depend on \(\theta\). Hence
\[
 {\cal S}_\theta(Q)={\cal S}_\psi(Q)
\tag{20}
\]
as actual signed sets whenever \(\theta,\psi\) lie in that chamber.

## 5. A sign-reversing involution with axis-flow fixed points

Take a state in \({\cal S}_\theta(Q)\). Sweep its top stable quotient
tree by Section 2, keeping its \(J\)-hierarchies attached to their atomic
blocks. At every residual terminal, apply (18). The result is a colored
binary outer flow tree whose terminal leaves carry:

* a fixed residual-reference root \(r\) on a partition of that leaf's
  original support;
* one attached hierarchy \(j_A\) for each child block of that partition.

Call this normalized sweep \(E_\theta\). It has an explicit inverse:
undo (18) at each terminal using its actual projected covector, and run
the arrow sweep backwards. The original partition is read from the
supports of all attached hierarchies.

There is a subtle but essential compatibility here. A root operation at
a terminal can change the atomic partition. Nonetheless the outer binary
flow tree remains admissible: equation (3) shows that all projected sums
commute with this contraction; (4) gives the same outer crossing times
and projected block covectors; and the surplus-color lists consist of
the same original cross arrows. Thus inverse sweeping is defined after
the root operation below. This is why one cannot replace graphical
substitution by a bare equality of generating functions.

A terminal is good if its residual root is the singleton empty tree and
its single attached hierarchy is an original singleton leaf. Otherwise
call it bad. Select the bad terminal whose support contains the least
original vertex among bad supports. Toggle it as follows.

* If its residual root has at least two children, graft that root onto
  the attached hierarchies as a new internal \(J\)-root. Replace the
  residual root outside it by the singleton empty residual tree.
* If it has one child, that child is a nontrivial \(J\)-hierarchy.
  Ungraft its \(J\)-root and use its decoration as the residual root,
  with the former \(J\)-children attached directly.

The same terminal support is bad after the toggle and all other terminal
supports are unchanged. Hence the same bad terminal is selected on the
return step. Grafting and ungrafting are literal inverses and change the
number of \(J\)-nodes by one.

Pull this toggle back along \(E_\theta\) and its inverse. The result is
an explicit sign-reversing involution \(I_\theta\) on
\({\cal S}_\theta(Q)\), fixing a state precisely when every terminal is
good. Such a state has only original singleton \(J\)-leaves, has positive
sign, and its top tree sweeps to an ordinary axis-leaf flow tree.

### Theorem 3. Actual fixed-point realization

The maps in Sections 2–5 identify
\[
 \operatorname{Fix}(I_\theta)
 \longleftrightarrow {\cal F}_\theta(Q),
\tag{21}
\]
where \({\cal F}_\theta(Q)\) is the independently defined catalog of full
binary flow trees with original singleton leaves, admission \(h/a>0\),
child covector (4), and \(|a|\) actual positive colors at each vertex.

All fixed points are positive. The proof uses actual maps and their inverses;
it does not first calculate \(|{\cal F}_\theta|\) and then pair finite sets.

The identity suggested by these objects is
\(H_\theta=F_\theta\circ R\) and \(R\circ J=1\), with
\(J=1-R_+\circ J\). Its rooted-tree inverse is standard. The construction
above supplies the object-level meaning and the exact contraction
compatibility required to make that identity usable.

## 6. Positive transport and strict coherence

Let \(\theta,\psi\) belong to one cut chamber, so that (20) gives a
common finite signed set \(\mathcal S\). Begin with an axis-flow object
at \(\theta\), decode it to its fixed flagged-tree state, and alternate
\(I_\psi,I_\theta,I_\psi,I_\theta,\dots\), stopping at an
\(I_\psi\)-fixed state. Finally encode that state as an axis-flow
object at \(\psi\).

The two-colored involution graph on \(\mathcal S\) has degree at most
two. A start fixed by \(I_\theta\) is an endpoint; if fixed by both,
the path has length zero. Otherwise its endpoint path cannot enter a
cycle. Every fixed state has positive sign, so the other endpoint is
fixed by \(I_\psi\), rather than again by \(I_\theta\). Reversing the
path gives the inverse. At most \(|\mathcal S|-1\) nontrivial edges are
used, with the bound (19) available before any transport is attempted.

Write this direct alternating-path bijection as \(P_{\theta,\psi}\).
It need not satisfy a cocycle. Choose once a strongly generic reference
\(\theta_*\) in the chamber, and let
\[
 N_\theta=P_{\theta,\theta_*},\qquad
 \Phi_{\theta,\psi}=N_\psi^{-1}N_\theta.
\tag{22}
\]
Then, as literal maps of positive finite sets,
\[
 \Phi_{\psi,\xi}\Phi_{\theta,\psi}=\Phi_{\theta,\xi},\qquad
 \Phi_{\theta,\theta}=\mathrm{id}.
\tag{23}
\]
Every closed polygon, in particular every pentagon, acts identically.
This includes changes of every descendant projected parameter and every
binary shape caused by crossing internal fake walls. No children are
silently held fixed.

An equivalent parameter-independent positive catalog is the subset of
ordinary stable trees at \(\theta_*\) whose recursive sweep has singleton
terminals only. Its membership test uses just the graph and the finite
arrow sweep. Equation (22) identifies every \({\cal F}_\theta\) with
that catalog, even for graphs with directed cycles.

## 7. Independent verification and repairs checked

The independently written program independent_chamber_check.py imports the
proposed low-level maps, but supplies different graph families and parameter
chambers. It tests the remaining generality risks rather than repeating
only the framed chamber used in the original program.

The recorded run includes 22 graph families in three cut chambers each,
with four strongly generic parameters per chamber. Rank-four and rank-five
parameters have at least two positive and two negative coordinates.
Families include directed cycles, the complete graph with both arrow
directions, parallel arrows, and random mixed directed multigraphs.

Across 66 cases it checks:

* 49,176 full involution-state evaluations on 12,294 signed states;
* every state remains in the common universe and \(I_\theta^2=1\);
* every fixed-point catalog equals the separately recursively enumerated
  axis-flow catalog;
* every alternating path reverses exactly, and reference-based compositions
  satisfy the tested five-step loops;
* the flagged spanning-tree encoding and its explicit inverse on all
  12,294 states, including flags equal to the full vertex set.

There are 82 axis objects counted once per chamber, 22 objects that change
under transport to the reference, and a longest alternating path of eight
edges. Fifty-five cases have empty axis catalogs; complete cancellation
was checked there rather than being omitted. These examples validate the
algorithms and conventions; the proofs above establish the general theorem.

The earlier contraction-loop implementation error has been checked as
repaired: a loop adds \(-1\) and \(+1\) to the same incidence entry, giving
zero. Assignment by overwriting would give the wrong cycle lattice.
The current cycle_matrix uses cumulative additions and is correct.

Other review points explicitly resolved:

1. A residual terminal is an infinity germ, not necessarily a tree stable
   at the initial parameter.
2. The relevant Eulerian flow polyhedron can be unbounded. Its minimizing
   normal cones cover the fixed cone \(C_G\), which is all that is needed.
3. Quotient arrows retain their identities and both directions.
4. Loops are discarded for hierarchical graph contraction but retained
   in the auxiliary cographic quotient by a limiting positive forest.
5. Direct alternating paths need not be coherent; (22) uses one reference.
6. Fixed-reference generic choices do not produce a natural Young-group
   action. None is claimed.

## 8. Primary literature comparison and current mathematical use

The sources below were read at the indicated proof locations. No 2026
result is required as an input to this theorem.

1. Sergey Mozgovoy, Operadic approach to wall-crossing,
   arXiv:2101.07636v1, Sections 2.1 and 2.3, Lemma 2.7,
   Theorem 2.9, Remark 2.10, and Section 3.3:
   https://arxiv.org/abs/2101.07636 .
   The nonunary rooted-tree inverse, including its finite nature, is
   established there. Our \(J\) is its signed graphical realization;
   the inverse formula is not a novelty claim.

2. Sergey Mozgovoy and Markus Reineke, Abelian quiver invariants and
   marginal wall-crossing, arXiv:1212.0410v1, Sections 6–7, especially
   Theorem 7.15:
   https://arxiv.org/abs/1212.0410 .
   The stable-support interpretation and arrow-order deletion into
   semistable spanning trees are established. Their deletion procedure
   starts with connected stable subgraphs and proves a positive
   \(q\)-enumerator. It is not the present parameter sweep, residual
   Eulerian normalization, or pulled-back root cancellation.

3. Hülya Argüz and Pierrick Bousseau, The flow tree formula for
   Donaldson–Thomas invariants of quivers with potentials,
   arXiv:2102.11200, Theorems 1.1–1.2, Section 4.3, and Section 5:
   https://arxiv.org/abs/2102.11200 .
   Their theorem already supplies the scalar general flow-tree formula
   and its scattering reconstruction interpretation. The present theorem
   must not be described as first proving this formula.

4. Sergei Alexandrov and Boris Pioline, Attractor flow trees, BPS indices
   and quivers, arXiv:1804.06928, Section 2.6 and Appendix B:
   https://arxiv.org/abs/1804.06928 .
   Fake-wall cancellation and the full descendant projection are
   established mechanisms. The additional claim here is an explicit
   positive bijection realized through flagged original spanning trees,
   rather than only cancellation of the scalar weighted sum.

5. Lilla Tóthmérész, A geometric proof for the root-independence of the
   greedoid polynomial of Eulerian branching greedoids,
   arXiv:2204.12419v3, Section 3 and Theorem 4.1:
   https://arxiv.org/abs/2204.12419 .
   Eulerian cographic height-one geometry and arborescence triangulations
   are prior work. The main displayed greedoid normalization has a
   rank/dimension error, documented independently in
   ../../notes/EULERIAN_COGRAPHIC_INTERFACE_REVIEW.md; that formula is
   not used here.

6. The half-open Box decomposition and the Garsia–Milne involution
   principle are standard. Their explicit common finite lattice-point
   realization used in (16)–(17) is proved in
   ../intrinsic_greedy_round2/COMMON_SIGNED_EHRHART_TRANSPORT.md.

Searches on 2026-11-13 included combinations of flow trees, stable spanning
trees, quiver stability, bijections, involutions, attractor invariants,
plethystic inversion, and 2025–2026 literature. No exact previous flagged
spanning-tree realization was located. This records the search result;
it does not prove historical priority.

For the classical theta project, the theorem supplies a finite and entirely
graph-based way to remove generic-parameter ambiguity from raw colored
flow objects, including cyclic framed graphs. It closes the all-descendant
parameter-transport gap in that model. Identification with arbitrary
integer theta coefficients still requires the separate repeated-label and
primitive-phase descent. In the squarefree skew-symmetric framed situation
where all primitive leaf and root degrees are one, that additional phase
issue is absent. A direct tight-Dyck grading correspondence and natural
equal-label equivariance remain separate interfaces.
