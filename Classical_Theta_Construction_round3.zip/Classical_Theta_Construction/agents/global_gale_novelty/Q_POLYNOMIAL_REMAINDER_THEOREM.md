# A direct coefficient algebra in monic polynomial coordinates

2026-11-13, 21:24 UTC. Classical cluster algebras only.

## Status and contribution

This note proves an elementary algebraic compression of the global graph-Gale construction. Conditional only on the already assembled global Gale/sign theorem, it computes each theta coefficient by **one finite rational algebra on the coefficients of monic polynomials**. It removes the explicit clone variables, the Vandermonde colon, the Young character sum, and the generic perturbation from the final coefficient algorithm.

The compression lemma is standard invariant-theoretic algebra and is not claimed as a new theorem in isolation. The relevant old interface is the Q-polynomial presentation of quiver twisted chiral equations in Benini–Park–Zhao (2014), §3.3, equations (3.26)–(3.38). The mathematical contribution under investigation remains the global cyclic positive factor and its identification with arbitrary classical theta coefficients. This note makes that result easier to state and compute.

**Do not saturate by discriminants.** Coincident same-color roots, with their scheme structure, are required. Saturation removes only actual arrow collisions and T=0 before taking the flat special fiber.

## 1. Formula from B, g, and p

Let B be a skew-symmetrizable integral r-by-r matrix, let D_i>0 satisfy D_i B_ij=-D_j B_ji, let g be an integral label, and let p be a nonnegative degree vector. Set Q_i(z)=1 when p_i=0. Otherwise introduce a monic polynomial

\[
 Q_i(z)=z^{p_i}+c_{i,1}z^{p_i-1}+\cdots+c_{i,p_i}.
\]

Use the coefficient ring

\[
 R=\mathbb Q[T,c_{i,k}:1\leq k\leq p_i].
\]

Choose the same generic original-color covector used by the global finite-flat theorem. After positive integral rescaling and ramification, write

\[
 a_i=\mu(e_i)/D_i\in\mathbb Z_{>0}.
\]

Only this choice of generic exponents uses the symmetrizer in the following presentation. The primitive arrow exponents simplify to the original entries of B.

Define

\[
 A_i(z)=z^{[g_i]_+}\prod_j Q_j(z)^{[B_{ij}]_+},
\]

\[
 E_i(z)=\epsilon_i z^{[-g_i]_+}
                 \prod_j Q_j(z)^{[-B_{ij}]_+},
 \qquad
 \epsilon_i=(-1)^{[-g_i]_++\sum_jp_j[-B_{ij}]_+},
\]

and

\[
 F_i(z)=T^{a_i}A_i(z)-E_i(z).                         \tag{1.1}
\]

Divide by the **monic** polynomial Q_i:

\[
 F_i(z)=H_i(z)Q_i(z)+\sum_{k=0}^{p_i-1}r_{i,k}z^k.
                                                               \tag{1.2}
\]

No coefficient division is needed, so all r_i,k belong to R. Let

\[
 J_{\rm rem}=(r_{i,k}:i,\ 0\leq k<p_i)\subset R.       \tag{1.3}
\]

Put

\[
 S(c)=\prod_{i:g_i\ne0}Q_i(0)
       \prod_{i<j:B_{ij}\ne0}\operatorname{Res}_z(Q_i,Q_j).
                                                               \tag{1.4}
\]

Factors equal to 1 can be omitted. Multiplicities or nonzero rational constants in S do not affect saturation. Define

\[
 K_{B,g,p}=J_{\rm rem}:(T S)^{\infty},
 \qquad
 \mathcal Q_{B,g,p}=R/(K_{B,g,p}+(T)).                 \tag{1.5}
\]

The global Gale/sign theorem implies

\[
 \boxed{[y^p]F_g^B(y)=\dim_{\mathbb Q}\mathcal Q_{B,g,p}.}         \tag{1.6}
\]

Here F_g^B denotes the formal principal-coefficient theta F-series under the conventions of the global construction. The formula is coefficientwise and makes no unsupported assertion that every tropical label has finite Laurent support. If p=0, use the one-dimensional algebra separately; the construction also gives it directly if the empty products are retained.

This is a finite, nonnegative integer formula. A Gröbner staircase in the c variables gives a finite set of standard monomials of this size. The algorithm uses only rational arithmetic, polynomial division, ideal saturation, and a zero-dimensional quotient. No scattering walls or individual broken lines appear in its input.

## 2. Check of signs and primitive exponents

The extended alternating pairing in the global construction satisfies

\[
 \eta(e_0,e_i)=D_i g_i,
 \qquad
 \eta(e_j,e_i)=D_i B_{ij}.
\]

At a clone x_i,a=z, an incoming arrow from color j contributes z-x_j,b, while an outgoing arrow to j contributes x_j,b-z. After division by D_i, their products are respectively Q_j(z)^[B_ij]_+ and (-1)^{p_j[-B_ij]_+}Q_j(z)^[-B_ij]_+.

An incoming frame arrow contributes z; an outgoing frame arrow contributes -z. Consequently the primitive Gale row is exactly

\[
 \Gamma^{\rm pr}_{i,a}=A_i(x_{i,a})/E_i(x_{i,a}).
\]

The target equation Gamma=T^{-a_i} becomes F_i(x_i,a)=0 with F_i as in (1.1). This verifies the signs rather than absorbing them into a silent change of target.

The function S(c), pulled back to the clone variables, vanishes precisely on the union of the actual arrow hyperplanes. There is a frame factor only when g_i is nonzero and an intercolor resultant only when B_ij is nonzero. Same-color discriminants correspond to **no arrows** and are therefore absent.

## 3. General remainder/alternant lemma

Let k be a characteristic-zero field and let

\[
 P=k[t,x_{i,a}:1\leq a\leq p_i],\qquad
 G=\prod_iS_{p_i},\qquad R=P^G.
\]

The symbol t may stand for any family of auxiliary invariant parameters. Identify R with the polynomial ring in t and the coefficients of Q_i(z)=product_a(z-x_i,a). Let F_i(z) be any polynomial in R[z]. Its coefficients may even depend on the coefficients of Q_i itself. Define

\[
 I=(F_i(x_{i,a}):i,a)\subset P,
 \qquad
 J=(\text{coefficients of }F_i\bmod Q_i)\subset R.
\]

Choose

\[
 \Delta=\prod_i\prod_{a<b}(x_{i,b}-x_{i,a}).
\]

**Lemma.** There is an equality of ideals

\[
 (I:\Delta)\cap R=J.                                 \tag{3.1}
\]

Consequently the total-sign isotypic component of P/I is naturally isomorphic as an R-module to R/J:

\[
 (P/I)^{\rm sgn}\simeq R/J,
 \qquad [h]\longmapsto[\Delta h].                    \tag{3.2}
\]

The sign component is being identified as a module; its ordinary multiplication does not make it a subalgebra. R/J is nevertheless an ordinary commutative algebra with the same vector-space dimension.

### Proof

Write F_i(z) mod Q_i(z)=sum_{k=0}^{p_i-1} r_i,k z^k. Evaluation at the p_i roots gives the Vandermonde system

\[
 (F_i(x_{i,a}))_a=(x_{i,a}^{k})_{a,k}(r_{i,k})_k.
\]

The determinant is Delta_i=product_{a<b}(x_i,b-x_i,a). Multiplication by the adjugate shows Delta_i r_i,k belongs to I. Multiplying by the other color alternants gives Delta r_i,k in I. Thus J is contained in the left side of (3.1).

Conversely, polynomial division and Q_i(x_i,a)=0 give I contained in JP. Define the alternating R-linear map

\[
 \Phi:P\longrightarrow R,
 \qquad
 \Phi(f)=\frac{1}{|G|\Delta}
           \sum_{\sigma\in G}\operatorname{sgn}(\sigma)\sigma(f).
                                                               \tag{3.3}
\]

Every alternating polynomial is divisible by Delta, so Phi is a polynomial map of R-modules, and Phi(Delta)=1. If h belongs to R and Delta h belongs to I, then Delta h belongs to JP. Applying Phi shows h belongs to J. This proves (3.1).

Finally, characteristic zero makes the sign projection exact. Every alternating polynomial is Delta times an invariant polynomial. Taking the image and kernel of h maps to Delta h therefore gives (3.2). No reducedness, generic roots, regular-sequence assumption, or independence of the coefficients of F_i is used. Q_i monic is the only polynomial-division requirement. QED.

## 4. Saturation and specialization commute with this compression

Let s belong to R. From (3.1),

\[
 ((I:s^{\infty}):\Delta)\cap R
     =J:s^{\infty}.                                  \tag{4.1}
\]

Indeed, Delta h belongs to I:s^infinity iff s^m Delta h belongs to I for some m. Since s^m h is invariant, (3.1) is equivalent to s^m h belonging to J.

Thus

\[
 (P/(I:s^{\infty}))^{\rm sgn}
       \simeq R/(J:s^{\infty}).                      \tag{4.2}
\]

If T is an invariant parameter, exactness of the sign projection also gives

\[
 \left(P/(I:s^{\infty},T)\right)^{\rm sgn}
       \simeq R/(J:s^{\infty},T).                    \tag{4.3}
\]

One can see the only potentially subtle point directly: the sign part of T times a G-module equals T times its sign part, because the sign projector is R-linear. Therefore reduction mod T does not introduce an interchange-of-limits issue.

Apply this with s=T S(c). Its zero set agrees with T times the actual-arrow product used in the global clone construction. Equality of the saturated ideals follows after localizing at this open set. Equation (4.3), followed by the global theorem identifying the sign multiplicity with the theta coefficient, proves (1.6).

Finiteness of the rational special quotient follows from that of the raw special algebra: its sign component is a direct summand, and (4.3) identifies that component with the displayed quotient. T-saturation also makes the compressed algebra T-torsion-free, since its module is a direct summand of the T-torsion-free raw algebra. These statements do not require the full unspecialized algebra to be finite over Q[T].

## 5. Why discriminant saturation gives the wrong general object

On the open locus where each Q_i has distinct roots, remainder vanishing is equivalent to the root equations. In that open set, unordered roots are exactly free Young orbits. This recovers the familiar interpretation of strong Bethe-type solutions.

At repeated roots, the remainder equations retain the confluent derivative conditions. They automatically incorporate the sign contributions carried by nilpotent local algebras. Removing the repeated-root locus before forming the special algebra can remove those contributions.

A minimal algebraic illustration, used only to check this mechanism, is F(z)=z^2 with two roots x,y. The clone algebra k[x,y]/(x^2,y^2) has one-dimensional sign part, spanned by x-y. With Q(z)=z^2+u z+v, the remainder ideal is (u,v), also one-dimensional. Q has a repeated root. Saturation by disc(Q)=u^2-4v would annihilate this quotient and give the incorrect value zero.

This illustration is not evidence for the global theta theorem; the general adjugate/alternant proof above is the mechanism.

## 6. Relation to the 2014 Q-polynomial presentation

Primary source: Francesco Benini, Daniel S. Park, Peng Zhao, *Cluster algebras from dualities of 2d N=(2,2) quiver gauge theories*, arXiv:1406.2699, §3.3, equations (3.26)–(3.38), pages 31–34.

The source already packages eigenvalues into monic Q-polynomials and expresses product-of-differences vacuum equations through polynomial divisibility; dressed Q-polynomials obey cluster exchange. It distinguishes simple-root, edge-coprime strong solutions from weak solutions and explicitly does not establish a complete general ring presentation. The present note uses neither a claimed physical ring identification nor a quantum cluster theorem. It proves the required algebra identity directly and retains the full nonreduced quotient. The new research question concerns the classical theta identification of its selected finite special factor.

URL: https://arxiv.org/pdf/1406.2699 . Primary pages were opened and the equations and limitations above read directly on 2026-11-13.
