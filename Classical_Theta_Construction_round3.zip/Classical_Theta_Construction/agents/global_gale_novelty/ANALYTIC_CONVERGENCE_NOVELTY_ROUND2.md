# Universal analytic theta bounds: second-round novelty review

Date: 2026-11-13. Scope: ordinary, classical cluster algebras, first skew-symmetric and then skew-symmetrizable. This is a literature comparison and a check of the quantitative consequence of the team's new global Gale construction. It does not certify that construction independently.

## 1. Decision for the main research line

The proposed analytic result is a substantive new consequence to pursue. In the primary sources inspected here, I did **not** locate a theorem giving an explicit coefficient majorant, a common nonzero complex domain for every theta label and generic endpoint, and quantitative path-product bounds for **every finite classical exchange matrix**, including cyclic and skew-symmetrizable matrices.

This is a bounded novelty conclusion, not a claim of an exhaustive literature proof. There is substantial prior analytic scattering theory. There are old exponential bounds for Kronecker invariants, own prior rank-two wall bounds, and special geometric convergence results. The new claim must be the precise uniform all-seed theta statement below, supported by the new global finite-factor identification. Neither analytic wall-crossing in general, factorial/tree estimates, nor the multivariable inversion identity is new.

The construction also gives a meaningful answer to the user's concern about abstraction: its bounded polynomial systems would now imply explicit analytic estimates and error bounds, in addition to computing fixed coefficients. This changes what can be deduced from the construction. It is still distinct from finding the complete finite Laurent support of an arbitrary regular theta function.

## 2. Exact quantitative statement being compared

Write

\[
\vartheta_{g,Q}=x^gF_{g,Q}(z),\qquad
z_i=y_ix^{Be_i},\qquad
F_{g,Q}(z)=\sum_{p\in\mathbb N^r}a_{g,Q}(p)z^p.
\]

The coefficient statement under review is

\[
0\le a_{g,Q}(p)\le
\prod_{i=1}^r\frac{\left(G_i+\sum_j C_{ij}p_j\right)^{p_i}}{p_i!},
\quad
G_i=|g_i|,\quad C_{ii}=1,\quad C_{ij}=|B_{ij}|\ (i\ne j).
\tag{2.1}
\]

The endpoint does not occur in this bound. Endpoint weights and powers of the degeneration parameter change the coefficients of the cleared polynomial equations, not their degrees in the clone variables.

### Checks that matter for (2.1)

The generic same-color perturbation must be counted **after denominators are cleared**. A safe per-clone degree is

\[
|g_i|+\sum_j|B_{ij}|p_j+p_i.
\]

The smaller expression \(\max(N_{\rm in},N_{\rm out},p_i-1)\) does not in general count the product introduced on clearing the perturbation denominator. The safe bound above does.

On the reduced generic fiber, the sign multiplicity counts free Young-group orbits. Consequently it is at most the total number of isolated points divided by \(\prod_i p_i!\). One must not assert that the entire unperturbed fiber is free, or that its total length always equals the sign multiplicity times the group order. Same-color coincidences and nilpotents are allowed in the original finite algebra.

An isolated-points affine Bézout estimate is enough; the cleared equations may have other positive-dimensional components outside the selected open finite factor. The selected factor must consist of isolated solutions in that open locus. These are mathematical dependencies of the team's proof, not literature assumptions.

### An explicit common domain

Put

\[
c=\max(1,\max_{i,j}|B_{ij}|),\qquad G=\max_i|g_i|.
\]

For \(n=|p|>0\), (2.1) implies

\[
a_{g,Q}(p)\le\frac{(G+cn)^n}{\prod_i p_i!}
\le e^{G/c}(ec)^n\frac{n!}{\prod_i p_i!}.
\]

Therefore, with \(q=ec\sum_i|z_i|<1\),

\[
\sum_p a_{g,Q}(p)|z|^p
\le 1+e^{G/c}\frac q{1-q}.
\tag{2.2}
\]

Every label and generic endpoint shares the domain

\[
\Omega_B=\left\{z:\sum_i|z_i|<\frac1{ec}\right\}.
\tag{2.3}
\]

In particular, the polydisc \(|z_i|<1/(erc)\) works. In the original torus coordinates the condition is \(\sum_i|y_ix^{Be_i}|<1/(ec)\), not a statement uniform in unrestricted mutable coordinates with only \(y\) small.

### Anisotropic majorant: the identity is old, its theta application is the candidate

Let the unique formal solution with zero constant term be

\[
T_j=y_j\exp\!\left(\sum_i C_{ij}T_i\right).
\]

Multivariable Lagrange–Good inversion gives

\[
\sum_{p\ge0}\prod_i\frac{(G_i+\sum_jC_{ij}p_j)^{p_i}}{p_i!}\,y^p
=\frac{\exp(\sum_iG_iT_i)}{\det(I-\operatorname{diag}(T)C)}.
\tag{2.4}
\]

Indeed, take \(\phi_j(t)=\exp(\sum_iC_{ij}t_i)\) and \(f(t)=e^{G\cdot t}\) in the determinant version of the inversion formula. The coefficient becomes \([t^p]\exp(\sum_i(G_i+\sum_jC_{ij}p_j)t_i)\). This is also the familiar colored functional-digraph species calculation. Attribute the identity to Good and its combinatorial tradition, not to this project.

For any \(u>0\) with \(\rho(\operatorname{diag}(u)C)<1\), a sufficient explicit domain is

\[
|y_j|<u_j\exp\!\left(-\sum_iC_{ij}u_i\right),
\tag{2.5}
\]

and the majorant is bounded by \(e^{G\cdot u}/\det(I-\operatorname{diag}(u)C)\). The label enters only the numerator. Positivity of the formal solution and \(-\log\det(I-A)=\sum_{k\ge1}\operatorname{tr}(A^k)/k\) justify the entrywise majorization when \(A\ge0\) has spectral radius below one.

## 3. Closest primary literature and the actual differences

### Kontsevich–Soibelman: analytic stability data

Primary: [Analyticity and resurgence in wall-crossing, arXiv:2005.10651v3](https://arxiv.org/pdf/2005.10651).

Read: introduction; Theorem 3.2.1 and its higher-rank factorization extension; Sections 3.8–3.11; Section 6.3. They prove analytic sector factorization and openness/closedness of analytic stability data. Section 3.8 distinguishes this analytic notion from uniform exponential bounds. Question 3.8.4 concerns uniform constants for arbitrary rational analytic stability data; Proposition 3.8.5 gives raywise information. Section 3.11 defines analytic wall-crossing structures through local rational decorated endpoints. Section 6.3 mentions class P quivers and rational stability data, while some algebraic statements are announced with details deferred.

**Comparison:** This is essential prior theory, but no all-classical-seed theta coefficient bound (2.1), common radius (2.3), or explicit dependence only on \(B,r,L\) was located there. Our cluster statement does not answer Question 3.8.4 for its arbitrary stability-data input. Neither embedding all those inputs into cluster data nor identifying every hypothesis has been proved. Do not advertise it as a solution to that question.

### Weist: exponential bounds before this project

Primary: [On the Euler characteristic of Kronecker moduli spaces, arXiv:1203.2740](https://arxiv.org/html/1203.2740v1).

Read: hypotheses in the introduction and Section 2; bounds in Section 3, including Corollaries 3.6 and 3.13. The argument combines the Manschot–Pioline–Sen formula, localization, tree counts, and factorial contributions to obtain exponential upper bounds in Kronecker/bipartite settings. The thin-tree estimate includes \(m^{a+b-1}a^{b-1}b^{a-1}\); summing the degeneration formula yields directional exponential bounds.

**Comparison:** The broad mechanism “labeled trees plus factorial denominators gives exponential growth” is old. It is not our novelty. The extension to all cyclic classical theta labels and endpoints through one global finite factor is the candidate. The HTML page's current rendering date does not turn this 2012 preprint into a 2026 result.

### Barbieri–Stoppa: convergence with a growth hypothesis

Primary: [Frobenius type and CV-structures for Donaldson–Thomas theory and a convergence property, arXiv:1512.01176](https://arxiv.org/pdf/1512.01176).

Read: Theorem 1.1, Lemma 6.2, Corollary 6.4 and surrounding hypotheses. Their convergence statement assumes a support property and an exponential growth condition on the Donaldson–Thomas data; a sufficiently large central-charge scale then gives convergence of the relevant CV-deformation functions.

**Comparison:** This supplies an analytic application of growth bounds, not a proof of (2.1) for arbitrary cluster data. Do not use this theorem to justify the missing growth input. Conversely, a cluster growth theorem may provide an input for related constructions only after their other hypotheses are checked.

### Leung–Ma–Young: asymptotic analysis of theta functions

Primary: [Refined scattering diagrams and theta functions from asymptotic analysis of Maurer–Cartan equations, arXiv:1902.05765](https://arxiv.org/pdf/1902.05765).

Read: introduction and main-theorem descriptions; Section 2.1's completed coefficient algebra; definitions surrounding the theta/flat-section construction. The analytic asymptotic parameter and the degreewise formal completion are separate. Theta functions appear as limits of distinguished flat sections in the completed framework.

**Comparison:** This is not an estimate for the ordinary complex radius of the principal coefficient series. The word “analytic” alone is not evidence that (2.2) was already proved.

### Barrott: an actual geometric convergence theorem

Primary: [Convergence of the mirror to a rational elliptic surface, Transactions LMS 8 (2021)](https://londmathsoc.onlinelibrary.wiley.com/doi/full/10.1112/tlm3.12028).

Read: Theorems 1.3/9.4, Proposition 9.2, Lemma 9.3 and the discussion of scope in the introduction. The mirror equations for a rational elliptic surface relative to an \(I_4\) fiber converge near the origin. Bounds on enumerative contributions and explicit broken-line families enter the proof; a single-bend contribution has a concrete geometric-series bound. The paper also explicitly limits its method to the stated geometry.

**Comparison:** Analytic mirror/theta-related convergence is already established in specific settings. This does not give a uniform theorem for arbitrary exchange matrices or every theta label.

### Burcroff–Lee–Mou–Musiker–Reineke

Primary: [Cluster scattering diagrams via quiver moduli and tight gradings, arXiv:2511.14672](https://arxiv.org/pdf/2511.14672); [2026 journal version](https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/jlms.70642).

Read: main scope, Section 9.3, Conjecture 9.2 and the discussion of central-wall algebraicity. They study rank-two wall coefficients. Their directional conjecture asks for an exact continuous asymptotic limit, which is much stronger than an exponential upper bound. Known central-wall algebraic formulas give growth constants in that setting.

**Comparison:** A universal upper bound does not prove their directional limit. This source should establish rank-two context, not be cited as an unsolved general theta-convergence conjecture.

### Lagrange–Good attribution

Primary bibliographic sources: [I. J. Good, Generalizations to several variables of Lagrange's expansion, 1960](https://www.cambridge.org/core/journals/mathematical-proceedings-of-the-cambridge-philosophical-society/article/abs/generalizations-to-several-variables-of-lagranges-expansion-with-applications-to-stochastic-processes/26EF8FA662B93EA10D788140C4982560); [I. Gessel, A combinatorial proof of the multivariable Lagrange inversion formula, 1987](https://www.sciencedirect.com/science/article/pii/0097316587900136).

The coefficient identity (2.4) is an immediate specialization of this old formula. Its proof is given above, so the new theorem does not depend on any unverified modern restatement.

## 4. Own prior work: a correction to the initial search outcome

The first pass through downloaded local text and the first profile page did not find an analytic convergence theorem. Reading the **second Hexagon profile page** found two directly relevant rank-two manuscripts. The record must retain this correction.

Primary corpus entry point: [Qiyue Tang's Hexagon works](https://hexagonmath.org/users/user_bf3e39d8-d680-421d-8d68-7772f7717a25). Both profile pages were inspected; the current listing has 85 works.

1. [2610.00639, Asymptotic growth of rank-two scattering coefficients in the Badlands](https://hexagonmath.org/pdf/2610.00639v1). Corollary 3.5 explicitly states

   \[
   \tau(i,j)\le\gcd(bi,cj)
   {bi-1\choose j-1}{cj-1\choose i-1}
   \le\gcd(bi,cj)2^{bi+cj}.
   \]

   The proof of this upper bound forgets compatibility after selecting supports in the canonical frames. Sections 2.1–2.3 and the bound's proof were read; their cited tight-grading/frame input is the published rank-two literature. This is an own prior explicit exponential wall bound. The later editing and directional-limit proof was **not** fully reviewed in this pass and is not used as a theorem here.

2. [2610.00645, Algebraicity of rank-two scattering wall functions](https://hexagonmath.org/pdf/2610.00645v1). The claimed theorem concerns one primitive direction at a time for polynomial two-wall initial data. Its finite-automaton/catalytic-variable route and cited closure theorem were identified. No all-rank theta bound or uniform-in-direction radius is stated. Its complete algebraicity proof was **not** adopted as an input; even the advertised theorem is a different quantifier pattern from (2.1)–(2.3).

Additional own papers inspected for scope and relevant statements: [2611.00238](https://hexagonmath.org/pdf/2611.00238v1), [2610.00201v3](https://hexagonmath.org/pdf/2610.00201v3), [2611.00279](https://hexagonmath.org/pdf/2611.00279v1), [2611.00239](https://hexagonmath.org/pdf/2611.00239v1), and [2610.00587](https://hexagonmath.org/pdf/2610.00587v1). These supply the known local acyclic Gale or finite/degreewise constructions. Searches for convergence, analytic, exponential growth and radius did not find (2.1)–(2.3). Degree/energy bounds in a grading do not by themselves bound the absolute size of coefficients. Quantum statements were not used for the classical research line.

The aiXiv checks used the actual domain **aixiv.online**, including its math.RA and math.RT listings, and searches under Qiyue Tang/Qiyuetang. Zenodo name/topic searches and local text searches were also run. No matching all-seed analytic majorant was found. This is not a full proof audit of every listed own work.

## 5. New wall, multiplication and path consequences

The companion agent's deductions are in:

- `agents/dyck_flow_round2/WALL_AND_MULTIPLICATION_ANALYTIC_BOUNDS.md`;
- `agents/dyck_flow_round2/ANALYTIC_PATH_ORDERED_PRODUCTS.md`.

Their one-bend argument compares each positive local wall coordinate factor to a coefficient of \(\vartheta_{-e_i,Q}\), with the endpoint chosen for that coefficient. Uniformity in \(Q\) makes this legitimate. It yields exponential bounds for every wall germ and for the actual coordinate factor, without a growing primitive-normal factor. Positivity and Tonelli then show that the full varying-output-theta multiplication series converges normally on the original domain (2.3), not merely that its scalar structure-coefficient series converges.

For a path with at most \(L\) straight segments, their root-hyperplane count, logarithmic displacement bound and summable derivative estimate give an explicit smaller common domain and a geometric error bound for finite-degree path products. The constants depend on \(r,\max|B_{ij}|,L\), not the wall count, location, skew-symmetrizer size or primitive normal. The argument controls drift of the evaluation point and insertion of new walls; these cannot be inferred merely from convergence of individual wall germs.

This quantitative all-cluster conclusion is the useful interface with KS analytic wall-crossing. It is not a new analytic-factorization principle. It must remain conditional on the reviewed global coefficient theorem until that theorem's proof dependencies are discharged.

## 6. 2026 audit record and limits

| Source | What was checked | Status for this research |
|---|---|---|
| BLMMR, 2026 publication of 2511.14672 | Rank-two hypotheses, central-wall discussion, exact form of Conjecture 9.2 | Useful comparison. No claim that an upper bound settles an exact limit. |
| Tang 2610.00639 | Published tight-grading input, canonical-frame derivation, elementary support-count upper bound | Explicit rank-two bound must be credited as own prior. Whole directional-limit proof not adopted. |
| Tang 2610.00645 | Theorem's one-direction quantifiers and proof architecture | No all-rank common-radius result. Full algebraicity conclusion not used. |
| Other own 2026 PDFs listed above | Main scope and occurrences of analytic/growth/degree language | No matching universal analytic claim found; no blanket correctness endorsement. |
| Fei 2610.09868v2, Qin 2508.12761v2, Keel–White–Yu 2411.04067v2 | Detailed hypothesis checks recorded in the endpoint/finite-support companion note | No new unrestricted finite-Laurent stopping premise obtained. |

No confirmed mathematical error in the cited 2026 analytic-comparison statements was established during this pass. “Not adopted” means the relevant full proof was not needed or not fully checked; it does not mean false. Conversely, a manuscript's own previous AI-review statement is not a substitute for the checks above.

## 7. Search routes and outcomes

The search was widened through four routes: exact cluster/theta convergence phrases; analytic stability data and convergent BPS structures; explicit quiver-invariant growth; and own Hexagon/aiXiv/Zenodo work. Primary PDFs were opened for the plausible matches. Broad search results containing “analytic” often referred to an auxiliary asymptotic parameter or to formal/nonarchimedean convergence; those were excluded from the claimed equivalence.

Useful routes: KS exposed the uniform-exponential-versus-analytic distinction; Weist prevented an overclaim about factorial gains; Barrott supplied an actual earlier geometric convergence theorem; the second own profile page corrected the initial absence of a rank-two prior. The fresh all-seed searches did not locate a matching theorem. Genericity/Newton sources did not supply a new finite-support decision mechanism.

A safe research claim, subject to the global theorem being proved, is:

> The global finite-factor model yields an explicit majorant for every classical cluster theta coefficient, uniformly over generic endpoints and all labels. It gives a common nonzero complex domain, an anisotropic matrix majorant, and quantitative analytic wall and multiplication bounds for arbitrary finite skew-symmetrizable seeds.

Do not append “first proof of analytic scattering,” “solution of KS Question 3.8.4,” “solution of the rank-two exact-growth conjecture,” or “algorithm for arbitrary finite Laurent support.” None follows from this review.
