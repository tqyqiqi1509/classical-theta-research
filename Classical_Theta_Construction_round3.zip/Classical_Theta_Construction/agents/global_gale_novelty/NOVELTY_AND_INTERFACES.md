# Global cyclic Gale theta coefficients: prior art and actual increment

Audit performed 2026-11-13, approximately 21:16–21:28 UTC.
Scope: classical skew-symmetric and skew-symmetrizable cluster algebras.

## 1. Finding

The product-of-differences equations, their logarithmic potential, their interpretation as exponentiated twisted-chiral equations, Q-polynomial compression, and selection of a positive-valuation factor all have substantial prior art. A claim that any one of those ingredients is new would be misleading.

The strongest defensible candidate increment is much narrower and mathematically substantive:

> For the single framed clone graph constructed directly from arbitrary classical B, g, p, including directed cycles, a generic original-color covector gives a uniform positive valuation window in a full neighborhood of independent target valuations. This supplies one finite flat factor, including all same-color fixed loci. Its total-sign multiplicity is the desired theta coefficient. Equivalently, the coefficient is the dimension of a directly presented finite monic-Q-polynomial remainder algebra.

No prior source retrieved in this search states this theorem or supplies its color-symmetric cyclic boundary argument. This is a bounded literature conclusion, not an assertion that absence from search proves priority. The collision-window proof and the theta identification remain the pieces that require mathematical review. Renaming the known equations does not establish either piece.

The new compressed formula is proved in `Q_POLYNOMIAL_REMAINDER_THEOREM.md`. Its adjugate/alternant identity is elementary and should not be advertised as a new standalone invariant-theory result.

## 2. Old equations, exact identification

For each oriented arrow e let b_e=e_head-e_tail, with the frame coordinate removed, and L_e=b_e·x. The ordinary graph map is

\[
 \Gamma_v(x)=\prod_e L_e(x)^{b_{ev}}.
\]

On a local logarithm chart set

\[
 \mathcal W(x)=\sum_e L_e(x)(\log L_e(x)-1)
                       -\sum_v\tau_vx_v.
\]

Direct differentiation gives

\[
 \partial_{x_v}\mathcal W=\log\Gamma_v-\tau_v,
 \qquad
 \operatorname{Hess}\mathcal W
      =\sum_e\frac{b_e b_e^T}{L_e}.
\]

Thus the exponentiated critical equations are exactly the ordinary Gale equations. For primitive rows use tau_v=D_i log q_v-mu(e_i)log T; equivalently raise the primitive target to D_i. The ordinary/primitive degree distinction is still necessary and cannot be erased by calling both systems critical equations.

This derivation matches the general abelian gauge charge-matrix construction in Hori–Vafa, equation (3.84), with charge rows b_e. The weighted graph Laplacian Hessian is therefore an expected consequence of an old potential, not a novelty claim. Neither this formal identification nor a logarithm branch supplies the desired finite positive factor.

## 3. The strongest old neighbors

### A. Hori–Vafa, 2000

Primary PDF: https://arxiv.org/pdf/hep-th/0002222 . Read §3.3, equations (3.82)–(3.86), especially (3.84), pages 36–37.

**What is already present.** A general charge matrix gives an effective twisted superpotential involving linear forms times logarithms; exponentiating its derivatives gives products of linear forms with charge-matrix exponents. Incidence charges specialize to the graph equations above.

**What this does not provide.** The specific original-color valuation chamber, a uniform boundary theorem for cyclic clone graphs, the full fixed-cycle scheme degrees, or the classical theta-coefficient equality. The paper's quantum-cohomological/physical interpretation is not used as a proof of those statements.

**Audit disposition:** useful exact equation identification; no theorem imported into the proof. Its arXiv version is 2000; a later PDF compilation header is not a new 2024 mathematical result.

### B. Bihan–Sottile, 2007/2008

Primary PDF: https://arxiv.org/pdf/0706.3745 . Read introduction, Theorems 1.5 and 2.1, and §3. Theorem 2.1 gives scheme isomorphisms between Laurent complete intersections and products-of-linear-forms master-function complete intersections under primitive Gale-dual lattice hypotheses.

**Relevance.** Algebraic elimination and master-function reformulation are old even at scheme level. Generic-degree or fewnomial results do not identify the correct positive formal factor on a color-symmetric locus. An arbitrary change of presentation cannot prove that this factor survives a specialization at which full algebraic fibers may change degree.

**Audit disposition:** useful terminology and prior-art boundary; does not close or duplicate the cyclic-window step.

### C. Benini–Park–Zhao, 2014

Primary PDF: https://arxiv.org/pdf/1406.2699 . Read §2.2, equation (2.17) and following vacuum equations; §3.3, equations (3.26)–(3.38), pages 31–34.

**What is already present.** Monic Q-polynomials package same-node eigenvalues; a polynomial formed from neighboring Q-polynomials is divisible by Q_i. Dressed Q-polynomials obey a cluster exchange relation. The source separates strong solutions with simple, adjacent-coprime roots from weak solutions, and explicitly does not claim a complete general ring presentation or proof of full ring equivalence.

**Actual interface obtained here.** The independent adjugate/alternant lemma proves exactly which remainder algebra equals the sign component, including nilpotents and coincident same-color roots. It requires no physical ring conjecture. The global theta interpretation then follows from the cyclic finite-factor theorem, not from the 2014 exchange resemblance.

**Audit disposition:** indispensable prior art; direct constructive interface. No claim that the Q-polynomial presentation itself is new.

### D. González–Woodward, 2012–2024 versions, published 2019

Primary PDF: https://arxiv.org/pdf/1207.3253 . Read Notation 1.5(a), Definition 1.13, Theorem 1.15, Propositions 3.7, 3.13 and 3.19, and Theorem 4.19. The 2024 arXiv v9 is the reviewed version.

**What is already present.** A positive part of a Jacobian ring is defined by formal completion and inversion of the parameter and monomials. It selects critical points whose designated coordinates have positive valuation. Formal Batyrev/Jacobian identifications and a dimension theorem are proved for proper toric orbifolds; the linear weights are assumed to lie in an open half-space.

**Exact obstruction to reusing it unchanged.** For graph incidence weights, that half-space hypothesis is equivalent to acyclicity, as proved next. The general cyclic construction lies outside this hypothesis. Its positive-window argument has real work to do.

**Audit disposition:** closest old positive-factor theorem; useful comparison, not a substitute for the cyclic proof.

### E. Tang, Hexagon 2611.00238v1, 2026

Primary record: https://hexagonmath.org/2611.00238v1 . Primary PDF: https://hexagonmath.org/pdf/2611.00238v1 . Read §3, §4 including Proposition 4.2, §6 Lemma 6.1, §8's alternant comparison, and §12. Public record dated November 10; PDF dated November 9. Both were checked.

**Already in the user's own work.** Rank-two coprime-slope local Gale systems; an acyclic thin-quiver positive factor; Young equivariant deformation and fixed-length traces; Vandermonde comparison; finite algebras for elementary coefficients followed by assembly. Section 4 uses acyclicity both to bound the flow polytope and to make all arrow coordinates invertible in the generic factor.

**Increment over this work.** One arbitrary cyclic framed graph replaces local rank-two attached factors and their assembly. The original-color valuation window is the new geometric input. The final Q-remainder algebra is a useful direct form of that global construction.

**Audit disposition:** relevant passages strongly checked for scope; this note does not certify every theorem in the 41-page paper. No newly claimed result is permitted to be merely its local finite-algebra construction restated.

### F. Alexandrov–Pioline, 2018/2019

Primary PDF: https://arxiv.org/pdf/1804.06928 . Read §4.1, equation (4.3), and the comparison with tree indices; checked §3's loop/potential hypotheses using the local full-text copy.

**Distinction.** Their Coulomb potential uses signed logarithms of distances; differentiation gives inverse-distance equations. Our graph potential uses L(log L-1); differentiation gives logarithms and exponentiation gives Gale products. For cyclic quivers their Coulomb and tree indices can differ by scaling contributions. Therefore an analogy with Coulomb indices cannot identify the current graph factor or suppress possible boundary contributions.

**Audit disposition:** useful warning and conceptual interface; no Coulomb formula imported as the theta proof.

## 4. Why the cyclic extension is not a formal toric rephrasing

**Proposition.** Let Q be a finite directed graph with a distinguished frame. The incidence weights b_e, viewed in the vertex lattice modulo the constant direction, lie in an open half-space if and only if Q has no directed cycle.

**Proof.** A separating functional is a real-valued function h on vertices such that h(head)-h(tail)>0 for every arrow. Its sum around a directed cycle would be zero and strictly positive, a contradiction. Conversely, a topological ordering of an acyclic graph supplies such an h. Subtract h(frame) to fix the frame value without changing any inequality. QED.

Thus the compact toric positive-factor input and the user's earlier acyclic argument share a precise structural limitation. The cyclic window must replace that limitation by a different mechanism. The present proof's monochromatic-depth absorption and color-generic recession claim are targeted exactly at this gap.

The conclusion is not that every conceivable noncompact toric theorem is irrelevant. Noncompact mirrors and localized Jacobian rings exist. No result retrieved here gives the required all-cyclic, color-symmetric, full-local-factor theta statement; their hypotheses must still be matched individually before use.

## 5. What may and may not be claimed now

| Claim | Assessment |
|---|---|
| Products of differences give an explicit algebraic system | Old |
| The system is a critical or Bethe-type system | Old equation-level interpretation |
| Q-polynomial divisibility resembles cluster exchange | Explicitly old in 2014 |
| A positive valuation part can be defined by completion | Old |
| Young sign multiplicity can become free orbits after deformation | Already in the user's own local work |
| All arbitrary cyclic clone graphs admit the specified original-color uniform window | Candidate substantive new theorem; must be proved |
| That single global factor has the theta coefficient as its sign multiplicity | Candidate substantive new identification, resting on the window and old flow identity |
| One finite Q-remainder algebra computes that coefficient | Precise constructive corollary; independently proved compression |
| The result is already a direct Dyck-path or bounded-polytope counting rule | Not established |
| Every tropical label now yields a finite Laurent polynomial | Not established by a coefficientwise formula |

The finite quotient does reduce abstraction in a concrete way: from B,g,p one writes finitely many explicit polynomials and obtains a finite monomial staircase. It does not yet give a simple closed combinatorial description of that staircase. The latter remains a separate research target.

## 6. Search and route record

All searches were performed during this subtask on 2026-11-13. Both available search engines were used; primary documents above, rather than search snippets, support the comparisons.

| Route/query family | Result and decision |
|---|---|
| theta functions + Gale equations + twisted chiral ring + Bethe vacua | Located BPZ as the strongest exact polynomial interface; derived the remainder/alternant theorem rather than merely listing the source. |
| cluster + Horn + scattering diagrams | No matching graph-factor theta theorem retrieved. Many irrelevant Horn/scattering results; not used. |
| positive Jacobian ring + toric + noncompact | Located the precise González–Woodward positive-factor definition and half-space hypothesis; proved half-space iff acyclic for the present data. |
| quiver + Gale + Coulomb; twisted chiral + Donaldson–Thomas | No same theorem retrieved; Alexandrov–Pioline checked to prevent an invalid identification with inverse-distance Coulomb equations. |
| Qiyue Tang + Gale/theta; Hexagon domain queries | Recovered 2611.00238v1 and verified the local/acyclic scope. |
| aiXiv / Zenodo + Qiyue Tang + theta/Gale | Retrieved other positivity and theta papers but no direct global cyclic Gale theorem. No unseen theorem from these results was used. |
| 2025–2026 cluster theta updates | Reading–Stella's November 2026 publication appeared; root has already audited it in notes/READING_STELLA_2026_AND_NEWTON_COMPARISON.md, so this subtask did not duplicate that review. |
| 2026 Gale duality/NCCR and broad Zenodo reconstruction titles | Search results concern different mechanisms. Triage only, no mathematical dependency and no correctness claim. |
| theta functions + Batyrev; quiver moduli + twisted chiral ring; polynomial divisibility + theta | Follow-up search after deriving the compression retrieved toric-mirror and symmetric-quiver/3d references, but no matching theorem. These search-only items were not used as mathematical premises. |

The algebraic Q-polynomial route succeeded. The proposed shortcut through an already known compact toric theorem fails on the exact half-space hypothesis. The proposed shortcut through Coulomb indices fails at the level of the equations and cyclic correction terms. These failed shortcuts are recorded to avoid revisiting them without new evidence.

## 7. Primary source reference IDs for the parent

The parent should reopen any source it cites to the user. This list is a navigation aid, not a substitute for citations.

- Hori–Vafa equation (3.84): `turn471view2`, primary PDF above.
- Bihan–Sottile Theorem 2.1 and §3: `turn473view4`.
- BPZ Q relations and strong/weak caveat: `turn472view0`, `turn472view1`, `turn471view1`.
- González–Woodward positive part: `turn473view1`; half-space: `turn476view0`; formal identification and dimension: `turn473view2`, `turn476view2`.
- Tang 2026 local finite algebras: `turn472view2`, `turn473view0`; acyclic Proposition 4.2 text also retrieved as `turn478search3`, with the primary PDF directly opened earlier as `turn468view1`.
- Alexandrov–Pioline: `turn480view0`, plus the locally available full-text source used for equation (4.3).

