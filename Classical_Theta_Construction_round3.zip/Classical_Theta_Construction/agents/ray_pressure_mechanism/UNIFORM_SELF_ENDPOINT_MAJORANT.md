# A label-uniform self-endpoint majorant from crossing variation

2026-11-13, 23:12 UTC. **PASS after fresh independent adversarial review:** `../global_theta_fresh_attack/UNIFORM_SELF_GERM_INDEPENDENT_REVIEW.md`. Root also checked the full variation/profile/radial chain independently. This note is a new general mechanism, not an extrapolation from the numerical self-germ tests. It uses classical positive wall functions and the previously proved one-coordinate wall-factor majorant. No finite-Laurent hypothesis, quiver categorification, or actual polymer model is assumed. Historical novelty remains subject to the separately recorded literature comparison.

The aim is to remove the integral-height dependence from `DYADIC_VANISHING_PRESSURE.md`. The crucial improvement is to bound the **sum of all bending exponents on one root hyperplane**, rather than separately bounding each bend and then multiplying those bounds.

## 1. Coordinates and the exact object being counted

Fix an integral skew-symmetrizable matrix B of rank size r and a positive integral diagonal symmetrizer D. Put

    C=max(1,max|B_ij|),
    M=max|D_i B_ij|,
    D_min=min_i D_i.

Use normalized **label coordinates** for a broken line gamma. A line with initial monomial x^m and accumulated principal-root degree q has velocity

    gamma'(t)=-(m+Bq).

The wall of positive primitive root a lies in the hyperplane

    a^T D gamma=0.

The self-endpoint germ is approached by

    gamma(0)=alpha m + epsilon D^(-1)v,
    alpha>0, epsilon>0, v_i>0.

In physical root-covector coordinates the same conventions are endpoint `alpha Dm+epsilon v`, velocity `-D(m+Bq)`, and wall functional `a^T gamma`; the two conventions must not be mixed.

Fix an output multidegree p and d=|p|>0. Work in the finite root truncation through degree d. Choose epsilon small enough that every nonzero `lambda_m(a)=a^TDm` for a root of degree at most d has the same sign as its value at the endpoint. Zero values acquire positive sign. Choose the endpoint generically within this finite sign germ. Every coefficient considered below is then an ordinary positive broken-line count. Its coefficientwise germ limit is

    x^m G_(m,self)(z)=(A_m^-)^(-1)(theta_(m,+)).

Only the finite coefficient p is being represented by this endpoint; no single epsilon represents every root order at once.

The label m=0 is immediate from theta_0=1 and is excluded from the geometric discussion; all stated bounds still hold for it.

## 2. Total variation bounds all bends of one normal

Fix a primitive positive root a. Along one broken line contributing to p define

    phi(t)=a^T D gamma(t),
    lambda=a^TDm,
    v(t)=phi'(t)=-(lambda+a^TDBq(t)).

The accumulated q increases by the nonnegative packet degrees at bends and ends at p. Therefore the total variation V of the piecewise constant scalar slope satisfies

    V <= sum_bends |a^T D B Delta q|
      <= M |a| sum_bends |Delta q|
      = M |a| d.                                      (2.1)

### Lemma 2.1: a crossing forces |lambda|<=V

Suppose this broken line crosses `a^TD gamma=0` transversely at least once. If lambda=0 the assertion is immediate. If lambda is nonzero, phi has sign lambda near negative infinity, and its endpoint also has sign lambda by the self-germ choice. Its initial slope is `v_0=-lambda`. A transverse crossing followed by return to the initial sign requires a slope with sign opposite to v_0 somewhere along the path. Consequently the total slope variation is at least |v_0|=|lambda|. Hence

    |lambda|<=V.                                      (2.2)

This argument only needs equality of the two endpoint signs, not equality of the initial and final positions. Thus every positive scalar alpha is allowed.

### Lemma 2.2: the sum of the actual a-bending speeds is at most 2V

List only the genuine nonempty a-bends, at times t_1<...<t_k, with signed scalar slopes v_1,...,v_k. At each such time `phi(t_j)=0`; its normal slope is continuous across that bend because `a^TDBa=0`, and is nonzero because a zero wall exponent cannot select a nonconstant packet.

Between two consecutive a-bends the scalar slope has variation at least `|v_j|+|v_(j+1)|`. If their signs differ this follows from the variation between the endpoint slopes. If their signs agree, the equal values `phi(t_j)=phi(t_(j+1))=0` force an opposite-sign slope somewhere in between; going through that slope costs at least the same variation. This remains valid with intermediate tangencies, non-bending crossings, and zero plateaus.

Adding the variation from the initial slope to the first a-bend therefore gives

    V >= |v_1-v_0| + sum_(j=1)^(k-1)(|v_j|+|v_(j+1)|)
      >= 2 sum_(j=1)^k |v_j| - |v_0| - |v_k|.

The displayed formula also holds for k=1, with the empty middle sum. Since `|v_k|<=|v_0|+V`, it follows that

    sum_(j=1)^k |v_j| <= V+|v_0| <= 2V,              (2.3)

where (2.2) was used in the last step. If lambda=0 the stronger sum<=V follows. If k=0 there is nothing to prove. This proof needs no additional regularity assumption concerning crossings at which no bend occurs. This strengthened oscillation argument was supplied by the fresh independent reviewer.

Let

    delta_a=gcd_i(D_i a_i),
    u_a=Da/delta_a

be the primitive integral normal. The positive wall-function exponent at an a-bend is

    E_j=|u_a^T(m+Bq_j)|=|v_j|/delta_a.

Combining (2.1)--(2.3) gives the total exponent budget

    sum_(a-bends) E_j <= 2M |a| d/delta_a.            (2.4)

This estimate is independent of m and independent of the number of times that hyperplane is crossed.

## 3. One uniform positive function for every local a-wall

Choose i(a) so that `u_(a,i(a))=max_i u_(a,i)`, and denote this positive integer by u_a^max. Since `max_i a_i>=|a|/r`,

    u_a^max >= D_min |a|/(r delta_a).

For a nonzero multidegree b define

    beta_b=(1+C|b|)^|b|/product_i b_i!.

Set

    U_a(z)=1+sum_(k>=1) beta_(ka) z^(ka).             (3.1)

The previously established one-coordinate/single-bend estimate says that **every combined local wall function** f with primitive root a satisfies

    f^(u_a^max) <=_coeff U_a.                         (3.2)

The function f may vary from one cone of the root hyperplane to another; U_a dominates all of them. It is not necessary to assume a single global f on that hyperplane.

For each actual a-bend put `L_j=ceil(E_j/u_a^max)`. Positivity and constant term one imply

    f_j^(E_j) <=_coeff f_j^(u_a^max L_j)
               <=_coeff U_a^(L_j).

There are at most `d/|a|<=d` nonempty a-bends. Thus (2.4) gives

    sum_(a-bends) L_j
       <= 2Mr d/D_min + d
       <= T d,
    T=ceil(2Mr/D_min)+1.                              (3.3)

This common bound applies separately to each primitive root a, with the same T.

The infinite positive product

    P(z)=product_(a primitive positive) U_a(z)         (3.4)

is a well-defined formal series: only finitely many factors contribute in each degree. Moreover every nonzero b is a unique positive multiple of one primitive a, so

    sum_a (U_a(z)-1)=sum_(b>0) beta_b z^b.

For nonnegative z with `q=eC sum_i z_i<1`, the established label-norm-one majorant gives

    sum_(b>0) beta_b z^b <= exp(1/C) q/(1-q).

Therefore P converges absolutely on the same small complex ball, and on its positive locus

    P(z)<=exp(exp(1/C) q/(1-q)).                      (3.5)

## 4. Ordered packets, uniqueness, and grouping by primitive normal

A nonempty bend selects a packet `b_j=k_j a_j`, where a_j is primitive positive and k_j>=1. For a fixed ordered sequence `(b_1,...,b_ell)` of total p, there is at most one geometric broken line to a fixed generic endpoint.

Indeed the final exponent is `m+Bp`. Starting from the endpoint, follow the last segment backwards to the hyperplane with normal a_ell. The intersection time is uniquely determined because the actual bending exponent is nonzero. Subtract B b_ell from the exponent and repeat. This reconstructs every bending point and every segment. A nonpositive intersection time, a point outside the required wall support, or a forbidden joint simply makes that sequence inadmissible. Crossings without a bend add no choices. If several walls with the same normal occur at a reconstructed point, their wall functions are combined before applying the bending rule, as in the existing wall-factor estimate. Their coefficient already includes every local monomial selection. Thus neither coincident walls nor local multiplicities create additional geometric lines for the same packet sequence.

Fix one admissible packet sequence, and for every primitive a let `N_a=sum_(j:a_j=a) k_j`. Its coefficient weight is a product of the selected local wall-power coefficients. For the factors having this a, (3.2)--(3.3) and the ordinary nonnegative Cauchy convolution give

    product_(j:a_j=a) [z^(k_j a)] f_j^(E_j)
       <= [z^(N_a a)] U_a^(sum_j L_j)
       <= [z^(N_a a)] U_a^(T d).                     (4.1)

The first inequality selects one particular convolution split from a positive convolution sum. It remains valid when the f_j, E_j, and L_j differ at each occurrence. No equality of local wall functions is assumed, and no division by the number of splits is used.

The number of **all** ordered sequences of nonzero vectors in N^r having total multidegree p is at most

    2^(d-1) binomial(d;p_1,...,p_r) <= (2r)^d.       (4.2)

An explicit injection proves this bound: write the unit colors inside each packet in increasing color order, concatenate those words, and mark the packet cuts among the d-1 interior gaps. The word and the cuts recover the vector sequence. There are `binomial(d;p)` possible words and at most `2^(d-1)` cut patterns. This also bounds the number of sequences with any fixed primitive-normal profile. Set `C_r=2r`.

Group the broken-line sum by profile. Every sequence in a profile has the same upper bound from the product of (4.1), and its multiplicity is at most C_r^d. Summing the profile bounds is exactly the coefficient of the product (3.4) raised to Td. Thus

    [z^p]G_(m,self)(z)
       <= C_r^d [z^p] P(z)^(T d).                    (4.3)

This is where the apparent factorial loss is avoided: all repeated uses of the same wall normal share the **total** exponent budget before their coefficient splits are summed. The ordered packet sequences contribute only an additional exponential factor in d.

## 5. An explicit matrix-dependent exponential constant

Choose any nonnegative vector w with `sum_i w_i=1`, and put

    rho_0=1/(2eC),             A=exp(1/C).

Then `q(rho_0 w)=1/2` and (3.5) gives `P(rho_0 w)<=exp(A)`, independently of w. Summing (4.3) over all p of degree d with weights w^p, and using positivity to bound one coefficient by the positive evaluation, gives

    [s^d]G_(m,self)(sw)
      <= (2r)^d [s^d]P(sw)^(T d)
      <= (2r/rho_0)^d P(rho_0 w)^(T d)
      <= B_*^d,                                       (5.1)

with the completely explicit constant

    B_*=4eCr exp(T exp(1/C)),
    T=ceil(2Mr/D_min)+1.                              (5.2)

This bound is uniform in both the integral label m and the nonnegative radial direction w. The common rescaling of D cancels in M/D_min, so B_* is unaffected by that redundant choice of symmetrizer scale. It also implies the individual coefficient estimate `[z^p]G_(m,self)<=(rB_*)^|p|` by choosing all w_i=1/r; the sharper radial bound (5.1) is what is used below.

## 6. Direct sparsity and the common-domain ray theorem

For the previously defined ray germ

    x^(ng)G_n=(A_g^-)^(-1)(theta_(ng,+)),

the coarse negative factor depends only on the positive ray: `A_(ng)^-=A_g^-`. Hence G_n is exactly the self-endpoint germ for the label m=ng, and (5.1) applies **uniformly in both n and g**.

There is also a direct geometric proof of the required sparsity, independently of the earlier signed-factorization stabilization theorem. If a nontrivial broken line contributes to G_n, take its **first** bend, with primitive root a. Before this bend q=0, so a nonconstant wall term requires `lambda_g(a)=a^TDg` to be nonzero. It is an integer, hence `|lambda_g(a)|>=1`. Lemma 2.1, applied to the initial label m=ng, gives

    n <= n|lambda_g(a)| <= V_a.

All packets parallel to a contribute zero to V_a because `a^TDBa=0`. Their total degree is at least |a|. Hence, if the final total degree is d,

    V_a <= M |a| (d-|a|) <= M d^2/4.

Thus a nontrivial coefficient must satisfy `n<=Md^2/4`. If B=0 there is no nontrivial first bend and G_n=1. This recovers, and sharpens the convenient version of, the earlier quadratic gap by the same crossing-variation mechanism.

For the simplest uniform bound put `M'=max(1,M)` and use the weaker implication `[z^p](G_n-1)=0` when `n>M'|p|^2`. Combining this with (5.1), directly and without another tree constant, gives

    |G_n(z)-1|
       <= (B_* s)^ceil(sqrt(n/M'))/(1-B_* s),
    s=sum_i|z_i|<1/B_*.                               (6.1)

The analytic coarse factor used here is the unique boundary limit of one-segment transports from the degreewise self germ, as proved explicitly in `DYADIC_VANISHING_PRESSURE.md`, Section 2. The common logarithmic coordinate bounds give a normal family; each fixed Taylor coefficient is eventually the coarse coefficient, so analytic uniqueness identifies every subsequential limit. This supplies local uniform convergence and positivity of W_g on positive points. It does not choose one fixed generic endpoint for every root degree.

Let `q_*,K_path` be the uniform one-segment transport constants and let `b=max|B_ij|`. Since `sum|W_g(z)|<=exp(r b K_path)sum|z|` for all real coarse endpoints, define

    rho_*=min{q_*/(eC), exp(-r b K_path)/B_*}.

On every smaller closed complex ball `sum|z|<=rho<rho_*`, (6.1) and the exact analytic identity

    F_(ng)(z)=H_g(z)^n G_n(W_g(z))

gives a uniform-in-integral-g estimate

    F_(ng)(z)/H_g(z)^n =1+O(q^sqrt(n/M')),   q<1.

Consequently Phi_z(g)=L_z(g) for **all integral labels on one common positive domain**. Positive homogeneity gives equality for rational labels, and the established label continuity gives equality for all real labels. The two previously distinguished convex bodies agree on that common domain, with the full scattering-fan consequences of the analytic transport body. These conclusions have the review status stated at the beginning of this note.

The conclusion remains local in positive seed variables. It would not assert global Fock--Goncharov duality on the whole positive variety, global Laurent finiteness, or rationality of every ray generating function.

### 6.1 A common zero-free neighborhood for every label

Shrink the ball once more so that

    q=B_* exp(r b K_path) sum_i |z_i| <1/2.

For every integral m, (5.1) gives

    |F_m/H_m-1| <= q/(1-q) <1.

Since H_m is the exponential of its analytic stable logarithm, neither factor vanishes. Thus **all formal theta F-series are simultaneously holomorphic and zero-free on this one matrix-dependent complex neighborhood**. Their normalized logarithms have the uniform bound

    |log F_m(z)-L_z(m)|
       <= log((1-q)/(1-2q)).                          (6.2)

The branch is fixed by log F_m(0)=L_z(m)(0)=0. This follows from the usual convergent logarithm estimate for a disk centered at one. It does not require finite Laurent support, and it makes the original zero-free sufficient condition a theorem rather than an additional premise.

## 7. Bounded logarithmic discrepancy for every integral label

Fix a positive point in the common domain and let

    q=B_* exp(r b K_path) sum_i z_i <1.

The uniform radial estimate, before using any large-n sparsity, gives for every integral m

    1 <= F_m(z)/H_m(z) <= 1/(1-q).

Consequently

    0 <= log F_m(z)-L_z(m) <= -log(1-q),             (7.1)

with one additive bound independent of m. This by itself proves the pressure identity with an O(1/n) bound on normalized logarithms; the first-bend sparsity upgrades it to the stretched-exponential relative asymptotic already proved.

There is also an arbitrary-label-sequence consequence. If `a_k>0` tends to infinity and `m_k/a_k -> v` for integral labels m_k, then

    log F_(m_k)(z)/a_k -> L_z(v).

If L_z has label Lipschitz constant C_z in the chosen norm, the explicit error is at most

    [-log(1-q)]/a_k + C_z ||m_k/a_k-v||.

Thus the actual large-label limit is not limited to exact integral multiples of one fixed label.

## 8. Independent review checkpoints

The fresh review passed all of the following:

1. The bending-speed total-variation argument, including zero lambda, repeated normal visits, intermediate tangencies, and zero plateaus.
2. Primitive-normal normalization and the max-coordinate wall-factor estimate.
3. The one-geometric-line-per-ordered-packet-sequence reconstruction.
4. Grouping by primitive-root profile: each split is bounded by one term of a nonnegative convolution; repeated profile multiplicity costs only C_r^d.
5. The finite-degree endpoint-germ passage, the direct first-bend gap `n<=Md^2/4`, and the exact all-n/all-label consequence.

The bound is intentionally very coarse. Its purpose is to prove a nonzero common domain, not to supply a numerically practical radius.
