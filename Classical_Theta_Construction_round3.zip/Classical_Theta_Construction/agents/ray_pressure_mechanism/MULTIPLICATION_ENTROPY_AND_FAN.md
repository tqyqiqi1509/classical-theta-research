# Positive multiplication mass and the analytic scattering body

2026-11-13, 23:24 UTC; independent consequence review PASS. Classical principal coefficients. This is a consequence of the independently reviewed common-domain ray theorem in `UNIFORM_SELF_ENDPOINT_MAJORANT.md`. The elementary probability-mixture and support-function arguments are not claimed as new principles; the useful input is the actual uniform theta asymptotic.

## 1. A probability distribution on principal multiplication shifts

Fix a positive point z in the common small domain. Choose any finite list of integral labels `g_1,...,g_k`, and set `G=sum_i g_i`. The positive multiplication identity is

    product_i F_(ng_i)(z)
       = sum_(q in N^r) c_n(q) z^q F_(nG+Bq)(z),
    c_n(q)>=0,               c_n(0)=1.               (1.1)

The sum converges at z by the already proved analytic multiplication theorem. The identity is in the principal-coefficient algebra: q records a frozen monomial as well as a mutable label shift. In particular, if B has a kernel, q>0 can have Bq=0; it is still a different **principal shift** and is not included in the event q=0.

Define

    w_(n,z)(q)=c_n(q) z^q F_(nG+Bq)(z)
                    /product_i F_(ng_i)(z).          (1.2)

These nonnegative weights sum to one. The probability of the unshifted principal component is exactly

    w_(n,z)(0)=F_(nG)(z)/product_i F_(ng_i)(z).       (1.3)

Let

    delta_z(g_1,...,g_k)=sum_i L_z(g_i)-L_z(G)>=0.     (1.4)

The inequality follows from the sublinearity of the common scaling/transport support function. The ray theorem gives, uniformly for every integral direction h,

    F_(nh)=exp(n L_z(h)) [1+O(exp(-c sqrt(n)))].

For fixed k, substituting this into (1.3) proves

    w_(n,z)(0)
      =exp(-n delta_z)[1+O_k(exp(-c sqrt(n)))].       (1.5)

The error constants can be chosen uniformly in the integral labels on a fixed smaller positive seed domain; k is fixed. Thus:

- If delta_z=0, the total mass of all q>0 principal corrections is `O_k(exp(-c sqrt(n)))`.
- If delta_z>0, the unshifted principal component has exact exponential rate delta_z: `-log w_(n,z)(0)/n -> delta_z`.

This is a statement about actual positive multiplication weights. It does not identify an individual coefficient c_n(q) or assert a large-deviation principle for all possible output q.

## 2. Exact convex-geometric meaning of a zero rate

Let K_z be the compact convex body whose support function is L_z; on the common domain this is also the body defined by the actual ray pressure. For a real label h write

    Face_z(h)={x in K_z : <h,x>=L_z(h)}.

Then

    delta_z(g_1,...,g_k)=0
       iff intersection_i Face_z(g_i) is nonempty.  (2.1)

To prove this, a common maximizer realizes the sum of the support values, giving equality in subadditivity. Conversely, choose a maximizer x for G. Every difference `L_z(g_i)-<g_i,x>` is nonnegative, and their sum is delta_z. If delta_z=0, each difference is zero, so x lies in every face.

When delta_z=0, the stronger identity is

    Face_z(G)=intersection_i Face_z(g_i).             (2.2)

Every point in either side maximizes each summand, so the equality follows from the same nonnegative-deficit argument. Thus all g_i belong to the **closed normal cone of the exposed face** Face_z(G). This formulation uses exactly the exposed-face normal cones treated by the independently proved full scattering-fan identification; it does not rely on normal-cone conventions for a possibly nonexposed singleton of a nonpolyhedral body. Consequently (2.1) gives a precise asymptotic multiplication characterization of common full scattering cones, with the established limiting-cone/face convention.

The face-intersection formulation is the primary statement. It avoids assuming that every scattering cone is full dimensional, rational polyhedral, or the relative interior of one finite chamber. The equality of the two bodies on the common domain is essential: previously, this interpretation was only known for the analytic transport body.

## 3. An exact mixture law for exponent vectors

For any integral label h let P_(h,z) be the principal exponent random vector with

    Pr(P_(h,z)=p)=[z^p]F_h * z^p/F_h(z).

Let independent vectors `P_(ng_1,z),...,P_(ng_k,z)` be drawn from these laws. Their sum has generating series

    product_i F_(ng_i)(z exp(t))/product_i F_(ng_i)(z).

Using (1.1) coefficient by coefficient shows the exact mixture identity

    Law(sum_i independent P_(ng_i,z))
      = sum_q w_(n,z)(q) Law(q+P_(nG+Bq,z)).          (3.1)

Every law on the right is well defined by the common all-label convergence domain. The argument is simply positive coefficient convolution, so no finite support or signed probability generating function is involved.

The q=0 component of this mixture is the law of P_(nG,z). With total variation normalized as `sup_A |mu(A)-nu(A)|`, (3.1) gives

    TV(Law(sum_i independent P_(ng_i,z)),
       Law(P_(nG,z))) <= 1-w_(n,z)(0).                (3.2)

Consequently, when the equivalent conditions (2.1) hold,

    TV(Law(sum_i independent P_(ng_i,z)),
       Law(P_(nG,z)))=O_k(exp(-c sqrt(n))).           (3.3)

Thus inside a common closed normal cone, large theta exponent laws become convolution-compatible at a stretched-exponential rate. This is stronger than only comparing their logarithmic growth. There is no assertion of exact independent framing objects or an exact polymer decomposition.

## 4. Arbitrary splits along one label ray

Fix g and let n,m tend to infinity without requiring them to be equal. The two-factor version of positive multiplication gives an exact mixture whose unshifted weight is

    w_0=F_((n+m)g)(z)/(F_(ng)(z)F_(mg)(z)).

Since the stable factors H_g^(n+m) cancel and every normalized residual is `1+O(exp(-c sqrt(index)))`,

    1-w_0=O(exp(-c sqrt(min(n,m)))).

Hence

    TV(Law(P_((n+m)g,z)),
       Law(P_(ng,z)+independent P_(mg,z)))
        =O(exp(-c sqrt(min(n,m)))).                 (4.1)

This supplies an asymptotic convolution law for arbitrary macroscopic splits of a ray. It is compatible with the Gaussian and cumulant conclusions in `THETA_RAY_GAUSSIAN_AND_RATIO.md`, but its proof uses positivity and the analytic ratio estimate directly, rather than inferring total variation convergence from a central limit theorem.

## 5. Scope and novelty comparison

The identities (1.1) and c_n(0)=1 are existing positivity/leading-degree inputs. Mixture decompositions and the support-face equality criterion are elementary. The new candidate application is the uniform quantitative conclusion (1.5), together with the common-domain identification of the actual scaling body with the analytic scattering body. The terminology 'rate' refers only to the explicitly defined principal event q=0.

No assertion is made that positive coefficient errors vanish coefficientwise for a fixed n, that all individual multiplication coefficients are small, that the basis is minimal among strongly positive bases, or that a Gaussian approximation holds at each lattice point. Those require different arguments. The domain is the explicit local positive seed domain of the uniform theorem, not the whole positive cluster variety.
