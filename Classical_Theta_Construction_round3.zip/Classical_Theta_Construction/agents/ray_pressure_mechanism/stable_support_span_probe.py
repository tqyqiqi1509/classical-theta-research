"""Exact mechanism diagnostic: stable root-span versus theta support.

Finite prefixes cannot certify a global span. Witnesses are returned for
adaptive enlargement; no passing finite computation is promoted to theorem.
"""
from pathlib import Path
import sys,json,random,time
from flint import fmpq_mat
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from stable_root_probe import stable_root

def rank(rows,r):
    return fmpq_mat(rows).rref()[1] if rows else 0

def run(trials=600):
    rnd=random.Random(2611132342);t=time.time();examples=[];stats=[]
    bad_coord=bad_theta=0
    for it in range(trials):
        r=3 if it<400 else 4 if it<550 else 5
        D=[rnd.randint(1,3) for _ in range(r)]
        B=[[0]*r for _ in D]
        for i in range(r):
            for j in range(i+1,r):
                v=rnd.randint(-4,4);B[i][j]=D[j]*v;B[j][i]=-D[i]*v
        g=tuple(rnd.randint(-4,5) for _ in D)
        cap=(2,2,2) if r==3 else (1,)*r
        H,T,R=stable_root(B,D,g,cap)
        F=R.theta_prefix(g,cap)
        hs=[p for p in H if any(p)];fs=[p for p in F if any(p)]
        hr=rank(hs,r);active=sum(any(p[i] for p in hs) for i in range(r))
        joined=rank(hs+fs,r);fr=rank(fs,r)
        bc=hr<active;bt=joined>hr
        bad_coord+=bc;bad_theta+=bt
        if (bc or bt) and len(examples)<30:
            examples.append(dict(B=B,D=D,g=g,cap=cap,H=[[p,str(H[p])] for p in H],F=[[p,str(F[p])] for p in F],stable_prefix_rank=hr,stable_active=active,theta_prefix_rank=fr,joined=joined))
        if (it+1)%100==0:
            print(json.dumps(dict(inputs=it+1,noncoordinate_prefixes=bad_coord,transient_outside_prefix=bad_theta,seconds=time.time()-t)),flush=True)
    out=dict(status='finite-prefix diagnostic only',inputs=trials,noncoordinate_prefixes=bad_coord,transient_outside_prefix=bad_theta,witnesses=examples,seconds=time.time()-t)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='witnesses'}),flush=True)
if __name__=='__main__':run()
