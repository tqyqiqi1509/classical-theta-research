"""Exact general-arrangement check of the self-endpoint exponent budget.

Random skew-symmetrizable matrices and ordered nonnegative root packets are
tested by exact backward hyperplane reconstruction. Every positive-time path
is checked. No scattering support or theta coefficient is assumed, so this
challenges the geometric lemma in a larger class than actual broken lines.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd
from functools import reduce
import random, json, time

def primitive(q):
    k=reduce(gcd,q)
    return tuple(x//k for x in q),k

def shift(B,m,q):
    return tuple(m[i]+sum(B[i][j]*q[j] for j in range(len(m)))
                 for i in range(len(m)))

def pairing(D,a,b):
    return sum(D[i]*a[i]*b[i] for i in range(len(D)))

def run(trials=120000):
    rng=random.Random(202611132320);start=time.time()
    accepted=normal_checks=repeated_paths=0;best=Fraction(0);witness=None
    retained=[]
    for it in range(trials):
        r=2+it%4
        D=[rng.randint(1,3) for _ in range(r)];B=[[0]*r for _ in D]
        for i in range(r):
            for j in range(i+1,r):
                a=rng.randint(-4,4);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
        scale=(1,1,2,5,50)[it%5]
        m=tuple(scale*rng.randint(-3,3)+rng.randint(-1,1) for _ in D)
        if not any(m):continue
        packets=[]
        for j in range(rng.randint(2,9)):
            q=[0]*r
            for k in range(rng.randint(1,3)):q[rng.randrange(r)]+=1
            packets.append(tuple(q))
        total=tuple(sum(q[i] for q in packets) for i in range(r));d=sum(total)
        eps=Fraction(1,2*(d+1));pos=[Fraction(m[i])+eps/D[i] for i in range(r)]
        current=shift(B,m,total);events=[];valid=True
        for packet in reversed(packets):
            a,k=primitive(packet);den=pairing(D,a,current)
            if not den:valid=False;break
            tau=-pairing(D,a,pos)/den
            if tau<=0:valid=False;break
            pos=[pos[i]+tau*current[i] for i in range(r)]
            events.append((a,abs(den)))
            current=shift(B,current,tuple(-x for x in packet))
        if not valid:continue
        assert current==m
        accepted+=1
        grouped={}
        for a,e in events:grouped[a]=grouped.get(a,0)+e
        repeated_paths+=len(grouped)<len(events)
        details=[]
        for a,speed_sum in grouped.items():
            variation=sum(abs(pairing(D,a,shift(B,(0,)*r,q))) for q in packets)
            lam=abs(pairing(D,a,m));normal_checks+=1
            assert lam<=variation,(B,D,m,packets,a,lam,variation)
            assert speed_sum<=2*variation,(B,D,m,packets,a,speed_sum,variation)
            ratio=Fraction(speed_sum,2*variation) if variation else Fraction(0)
            details.append(dict(normal=a,speed_sum=speed_sum,variation=variation,lambda_abs=lam))
            if ratio>best:
                best=ratio;witness=dict(B=B,D=D,m=m,packets=packets,normal=a,
                                       speed_sum=speed_sum,variation=variation,ratio=str(ratio))
        if len(retained)<200 and (len(grouped)<len(events) or len(retained)<40):
            retained.append(dict(B=B,D=D,m=m,packets=packets,normal_checks=details))
        if (it+1)%30000==0:
            print(json.dumps(dict(candidates=it+1,accepted=accepted,normal_checks=normal_checks,
                                 repeated_paths=repeated_paths,seconds=time.time()-start)),flush=True)
    result=dict(status='PASS geometric diagnostic; proof is separate',candidates=trials,
        accepted_positive_time_paths=accepted,exact_normal_checks=normal_checks,
        repeated_normal_paths=repeated_paths,largest_ratio=str(best),witness=witness,
        retained=retained,seconds=time.time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='retained'}),flush=True)

if __name__=='__main__':run()
