# Dyadic sparsity closes a positive zero-background pressure problem

2026-11-13, 22:51 UTC; strengthened at 22:58 UTC. New general mechanism. The tree count and analytic application passed an independent review in `../weighted_bezout_review/DYADIC_PRESSURE_INDEPENDENT_REVIEW.md`; the second independent review `../q_support_round2/RAY_PRESSURE_INDEPENDENT_REVIEW.md` passed the endpoint germ, covariance orientation, positivity, zero-background stabilization, balanced-tree count, and analytic passage. This note does **not** presuppose a polymer model, a zero-free domain, or linear stabilization.

**Later strengthening:** `UNIFORM_SELF_ENDPOINT_MAJORANT.md` removes the label-height dependence by a different broken-line variation argument and has passed fresh independent review. The abstract balanced-tree theorem below remains an independent general result; references below to an unproved height-independent radius describe the scope of this original argument, not the current state of the project.

## 1. Abstract theorem

Let `f_n(s)=sum_{p>=0} a_n(p)s^p`, for positive integers n, be formal series with nonnegative real coefficients and constant coefficient one. Assume:

1. `f_(n+m) <=_coeff f_n f_m` for all positive integers n,m.
2. There is `M>=1` such that `a_n(p)=0` whenever `p>0` and `n>M p^2`.
3. There is `B>0` such that `a_1(p)<=B^p` for all `p>=1`.

Put

    c_M = sqrt(M)/(1-2^(-1/2)),
    K = 2 B 4^(c_M+1).

Then, for every h>=0 and p>=1,

    a_(2^h)(p) <= K^p.

Consequently, with `d_h=floor(sqrt(2^h/M))` and with an immaterial strict-boundary adjustment,

    |f_(2^h)(s)-1| <= (K|s|)^ceil(sqrt(2^h/M))/(1-K|s|),
                         whenever K|s|<1.

In particular `f_(2^h) -> 1` locally uniformly on `|s|<1/K`. If the positive evaluations of all f_n exist there, then

    lim_(n->infinity) log f_n(s)/n = 0,  0<=s<1/K.

### Proof of the coefficient estimate

The binary tree with `2^h` terminal leaves has a node for each dyadic interval. A node at height j above its terminal leaves represents a factor `f_(2^j)`. Repeatedly apply coefficientwise submultiplicativity and discard a coefficient whenever the second assumption forces it to vanish.

This bounds `a_(2^h)(p)` by the weighted count of all assignments of nonnegative integers `d_1,...,d_(2^h)` of total p to the terminal leaves, subject to the following condition at **every** dyadic interval I:

    if q_I=sum_(i in I) d_i > 0, then |I|<=M q_I^2.

The weight of an assignment is `product_i a_1(d_i)`, where `a_1(0)=1`. The repeated coefficientwise inequality is legitimate because every intermediate series and every coefficient is nonnegative. It can equivalently be formalized by the recursive majorant `T_0=f_1`, `T_j=1+Pi_(p>=ceil(sqrt(2^j/M)))(T_(j-1)^2-1)`.

Call a node active if its interval has positive total degree. At height j, the active intervals are disjoint and each consumes at least `sqrt(2^j/M)` units of degree. Their number is therefore at most

    p sqrt(M) 2^(-j/2).

The total number L of active nodes obeys

    L <= p sqrt(M) sum_(j>=0) 2^(-j/2) = c_M p.

For p>0, the active nodes form one rooted ordered subtree, with each node having no active child, its left child only, its right child only, or both children. Recording these four possibilities in depth-first order gives an injective code of length L over a four-letter alphabet. Thus the number of possible active patterns is at most

    sum_(1<=L<=floor(c_M p)) 4^L <= 4^((c_M+1)p).

Every active leaf of the subtree is a terminal leaf of the original binary tree: a positive degree cannot have two zero-degree children. If there are r such leaves, their positive degrees form a composition of p into r parts. There are `binom(p-1,r-1)<=2^(p-1)` possible compositions. Each has weight at most `B^p`. Combining the three bounds gives `a_(2^h)(p)<=K^p`.

The root condition gives zero coefficients for `p<sqrt(2^h/M)`. The geometric tail proves local uniform convergence. Finally, positivity gives `log f_n(s)>=0`; submultiplicativity and the dyadic subsequence give, by the elementary infimum formula for subadditive sequences, a limiting pressure equal to zero.

### Remarks

- The exponent 2 is not essential. If `n>M p^alpha` for a finite alpha>0 forces vanishing, the same proof uses `sum_j 2^(-j/alpha)` and still gives a positive convergence radius. Thus any fixed polynomial stabilization rate suffices **once the stable background has been changed to one while preserving positivity and coefficientwise submultiplicativity**.
- This is not a proof from pointwise submultiplicativity. Coefficientwise submultiplicativity is used at every node, before truncating forbidden degrees.
- An arbitrary signed quotient `F_n/H^n` need not satisfy these assumptions. The theta application below uses a genuine scattering-coordinate transport to a positive endpoint germ instead.
- The dyadic bound is deliberately conservative. The following balanced-tree refinement controls the whole sequence.

### Whole-sequence strengthening

Under exactly the same hypotheses, set

    b_M = 1 + 2 sqrt(M)/(sqrt(2)-1),
    K_all = 2 B 4^(b_M+1).

Then `a_n(p)<=K_all^p` for **all** n>=1 and p>=1, and

    |f_n(s)-1| <= (K_all|s|)^ceil(sqrt(n/M))/(1-K_all|s|).

To prove this, use the fixed balanced binary tree on n terminal leaves, recursively splitting a block of size m>=2 into blocks of sizes floor(m/2) and ceil(m/2). Let `h=ceil(log_2 n)`. At depth ell<h, every node has at least `floor(n/2^ell)>=n/2^(ell+1)` terminal descendants. (All terminal depths are h-1 or h.) Hence the number of active nodes at that depth is at most

    p sqrt(M 2^(ell+1)/n).

There are at most p active terminal nodes at depth h. The total number of active nodes is therefore at most

    p + p sqrt(2M/n) sum_(ell=0)^(h-1) 2^(ell/2)
      <= [1+2 sqrt(M)/(sqrt(2)-1)] p = b_M p,

using `2^h<2n` for n>1, with n=1 immediate. The same four-symbol subtree code and positive-composition bound apply. This proves the coefficient estimate and the geometric tail. No additional lower bound or consistency of combinatorial injections is required.

For every r<1/K_all, the bound tends to zero at rate `O((K_all r)^sqrt(n/M))`, uniformly on `|s|<=r`. Thus the f_n are zero-free on that closed disk for all sufficiently large n. This zero-free conclusion is a **consequence** of the counting proof, not an extra hypothesis.

## 2. The theta endpoint germ

Fix an integral classical theta label g. Let `A=A_g^-` be the coarse negative factor of the incoming-to-positive total scattering automorphism for the functional `lambda_g(a)=g^T D a`. It is the compatible inverse limit of its finite-root truncations. Choose a fixed vector v in the strictly positive initial chamber and consider endpoints

    U_epsilon = Dg + epsilon v,  epsilon>0.

For every finite root order d, there are finitely many walls. If epsilon is small enough, the signs at U_epsilon of all roots through degree d agree with the coarse sign of lambda_g when it is nonzero, and are positive when lambda_g is zero. Thus the path transport from U_epsilon to the positive chamber, in the degree-d quotient, is precisely A modulo degree>d. This is the **positive zero-root germ** convention; no single epsilon is claimed to work for all root degrees.

Define

    x^(ng) G_n(z) := A^(-1)(theta_(ng,pos)).

For every fixed n,d, the right hand side modulo degree>d is the theta expansion at U_epsilon for all sufficiently small epsilon. The covariance of theta functions under path transport proves this equality. Each such endpoint expansion has nonnegative integer coefficients and constant coefficient one. Hence

    G_n in 1+ N[[z_1,...,z_r]].

Compatibility as d varies follows from the inverse-limit definition of A, not from a uniform choice of epsilon. The cutoff may depend on both n and d; positivity passes coefficientwise and therefore remains valid for the one formal series G_n.

For precision, the analytic A in Section 5 is also a genuine boundary limit. Choose generic epsilon tending to zero and one-segment transports A_epsilon from U_epsilon to the positive chamber. The established path theorem gives a common complex domain and a uniform bound for their logarithmic x-coordinate corrections, independent of epsilon. These holomorphic corrections form a normal family. Every fixed Taylor coefficient eventually equals the corresponding coefficient of the coarse factor A. Any locally uniformly convergent subsequence therefore has the same Taylor series; analytic uniqueness gives a unique limit and hence local uniform convergence of the whole family. Its logarithmic coordinate bounds persist. At positive real points the corrections are real, so their exponentials and the resulting normalized degree coordinates W_j are strictly positive, with the same two-sided multiplicative bounds. No fixed generic endpoint is claimed to represent the germ at every root order, and no arbitrary passage from coefficientwise convergence to analytic convergence is being used.

The all-endpoint coefficient bound applies at every U_epsilon, and passes to the germ:

    [z^p]G_n <= (n||g||_infinity+C|p|)^|p|/product_i p_i!.

In particular every G_n converges on the common all-endpoint ball `sum|z_i|<1/(eC)`.

## 3. Coefficientwise submultiplicativity survives the germ

The positive theta multiplication identity is an identity of global theta functions. After transport to a generic U_epsilon it reads

    F_(ng,U_epsilon) F_(mg,U_epsilon)
      = F_((n+m)g,U_epsilon)
        + sum_(q>0) c_(ng,mg)(q) z^q
                    F_((n+m)g+Bq,U_epsilon),

where every displayed coefficient is nonnegative. For a fixed output degree only finitely many summands occur. Passing coefficientwise to the positive endpoint germ gives

    G_(n+m) <=_coeff G_n G_m.

It is not necessary that A preserve coefficientwise order on arbitrary series; it generally does not. The order statement is obtained from the separate positivity theorem for theta expansions at each endpoint, and only then passed to the limit.

## 4. Quadratic stabilization becomes zero-background sparsity

The established stable-ray theorem gives

    theta_(ng,pos) = A(x^(ng)) modulo degree>d
                                whenever n>M_0 d^2,
    M_0=max_(i,j)|D_i B_ij|.

Both A and its inverse preserve the root-degree filtration and induce the identity on the associated leading degree. Applying A^(-1) therefore gives

    G_n=1 modulo degree>d whenever n>M_0 d^2.

Thus `[z^p]G_n=0` for every p>0 with `n>M_0 |p|^2`. Set `M=max(1,M_0)` to use the abstract theorem without exceptional constants.

Fix any nonnegative vector w with `sum_i w_i=1`, and put `f_n(s)=G_n(sw)`. The coefficient assumptions of Section 1 hold. For n=1, the endpoint majorant gives

    [s^p]f_1 <= (G+Cp)^p/p! <= [e(G+C)]^p,
    G=||g||_infinity.

Consequently one may use the direction-independent constants

    c_M=sqrt(M)/(1-2^(-1/2)),
    K_g=2 e (G+C) 4^(c_M+1).

For every complex vector z with `sum_i|z_i|<1/K_g`, the multivariable version of the same radial estimate gives

    G_(2^h)(z) -> 1

locally uniformly. The majorant is obtained by setting `w_i=|z_i|/sum|z_i|`; all constants are independent of w.

For the whole sequence replace c_M by b_M and set

    K_(g,all)=2 e (G+C) 4^(b_M+1).

Then, with `s=sum_i|z_i|<1/K_(g,all)`,

    |G_n(z)-1| <= (K_(g,all)s)^ceil(sqrt(n/M))
                 /(1-K_(g,all)s).

## 5. Return to the original seed

Write the analytic positive transport in normalized variables as

    A(x^g)=x^g H_g(z),
    A(z_j)=W_(g,j)(z)=z_j u_(g,j)(z),   u_(g,j)(0)=1.

The established analytic path theorem makes H_g nonzero and W_g holomorphic on a small seed domain; for positive z it maps to positive coordinates. The exact formal identity

    F_(ng)(z)=H_g(z)^n G_n(W_g(z))

is therefore an analytic identity whenever both sides converge, after shrinking the domain if necessary. In any positive neighborhood where

    sum_j W_(g,j)(z)<1/K_g,

the dyadic estimate yields

    F_(2^h g)(z)/H_g(z)^(2^h) -> 1.

The real pressure already exists by positive multiplication. Its dyadic subsequence has limit log H_g(z). Therefore

    Phi_z(g)=log H_g(z)

on this explicit transported small neighborhood for the chosen integral g.

The conclusion is currently **per integral direction**, with a radius depending on ||g|| and the transport. It does not, without a further argument, establish one fixed positive ball for all real g, nor the equality on the entire earlier all-label convergence domain. The abstract lemma also gives a local common zero-free domain for the sufficiently large dyadic subsequence after transport, but no zero-free claim for every n is needed.

Using the whole-sequence refinement, on the smaller domain `sum_j|W_(g,j)(z)|<1/K_(g,all)` one obtains the stronger complex analytic asymptotic

    F_(ng)(z)/H_g(z)^n = 1 + O(q^sqrt(n/M)),

uniformly on each compact set where `K_(g,all) sum_j|W_(g,j)(z)|<=q<1`. In particular, every sufficiently large F_(ng) is zero-free on each such compact neighborhood, and the normalized analytic logarithms converge locally uniformly to log H_g. For a nonprimitive label g, using its primitive integral generator can improve the stated radius; the theorem is invariant under replacing g by a positive integral multiple.

## 6. An explicit common domain for bounded integral heights

Let `r` be the mutable rank, `b=max|B_ij|`, and let `q_*,K_path` be the established one-segment path constants, so every A_g^- is holomorphic on

    e C sum_i |z_i|<q_*,

and its logarithmic x-coordinate displacement is bounded by K_path, uniformly in the real endpoint. Then

    sum_j |W_(g,j)(z)| <= exp(r b K_path) sum_j |z_j|.

Fix R>=1 and define

    K_R=2e(R+C)4^(b_M+1),
    rho_R=min{ q_*/(eC), exp(-r b K_path)/K_R }.

All integral labels with `||g||_infinity<=R` satisfy the whole-sequence theorem on the **same** complex ball `sum|z_i|<rho_R`. On a smaller closed ball one may choose the same geometric factor q and the same multiplicative tail constant for all these labels.

The pressure identity also holds for every nonnegative real multiple of any of these integral labels, by the already established positive homogeneity of both Phi and L. Thus the relevant height is the infinity norm of the primitive integral generator of a rational ray, rather than the norm of a chosen large multiple.

There is a useful convex extension. Suppose a cone C is generated by finitely many such integral labels g_1,...,g_k, and L_z is linear on C (as happens when C lies in one full scattering cone). For `h=sum_i t_i g_i`, t_i>=0, one has

    L_z(h) <= Phi_z(h) <= sum_i t_i Phi_z(g_i)
             =sum_i t_i L_z(g_i)=L_z(h).

Therefore Phi=L on the entire real cone C on that same positive domain. This does not exhaust all infinite-fan limiting directions and does not claim a common radius independent of integral height.

## 7. Independent checks and remaining uniform-domain problem

1. The covariance convention and factorization order were checked against the existing incoming-to-positive normalization: PASS in the q_support review.
2. The positive initial perturbation selects precisely the coarse negative factor in each finite degree, including zero-root walls: PASS in that review. The normal-family argument needed for the analytic boundary limit is now included explicitly in Section 2.
3. The four-symbol subtree code and terminal-leaf composition count passed both reviews. No free choice of embedded leaf positions is inserted, since the left/right tree code already determines them.
4. A domain independent of the primitive integral height remains unproved. It is not an input or conclusion of the present theorem.

No external theorem beyond the previously established theta positivity/covariance and elementary counting is being invoked for the dyadic argument. Novelty and prior-literature search remain separate.
