# Ray-pressure mechanism: research route and literature log

2026-11-13, UTC. This log records successful and unsuccessful **general mechanisms**. Computation is used to challenge a proposed mechanism, not to replace its proof. Main proof: `UNIFORM_SELF_ENDPOINT_MAJORANT.md`; independent abstract route: `DYADIC_VANISHING_PRESSURE.md`; consequences: `THETA_RAY_GAUSSIAN_AND_RATIO.md` and `MULTIPLICATION_ENTROPY_AND_FAN.md`.

## Route record

| Route | Outcome | Mathematical reason / next interface |
|---|---|---|
| Infer log normality from a coefficient majorant alone | Rejected; not used | Bounds on F_n do not supply a common zero-free domain for log F_n. |
| Genuine frame-polymer expansion | Open, bypassed for the local theorem | The functional-digraph estimate is only a majorant. Reineke's independent-root product is at fixed stability; theta self-stability moves with the label and root degree. No false polymer representation is asserted. |
| Linear first-correction degree from extraction signs | Unproved; not needed for the new theorem | The exact extraction threshold can be quadratic even in rank two. Near-zero-root isotropy does not control a general extraction shift. |
| Positive coefficientwise submultiplicativity plus polynomial zero-background gap | **Proved** | Balanced multiplication trees have O(p) active nodes for total degree p, eliminating the apparent n-dependent leaf-position entropy. Uniform exponential coefficients and G_n→1 follow. |
| Divide F_n by H^n without changing coordinates | Invalid as a positivity argument | H can have negative coefficients, and the formal quotient need not have nonnegative coefficients. |
| Transport to the positive zero-root endpoint germ | **Proved and independently reviewed twice** | Each finite coefficient is an actual positive endpoint theta coefficient; product positivity is passed to the germ before taking the limit. The inverse coarse transport has the correct covariance orientation. |
| Uniform domain for bounded integral height | **Proved** | Uniform one-segment transport bounds combine with a common leaf coefficient bound for ||g|| bounded. |
| One domain for unbounded primitive integral heights | **Proved and independently reviewed** | Total normal-slope variation bounds the sum of all powers on each repeated wall normal, independent of g. Primitive-ray profile convolution and packet-word counting give one exponential coefficient bound for every self-endpoint germ. |
| Self-endpoint support contained in ker(g^TD) | **False** | `self_germ_support_probe.json` gives an immediate exact rank-two counterexample; hence this shortcut is discarded. No theorem depends on it. |
| Sharper factorial self-endpoint majorant | Specific sharp bound still unproved; a coarser uniform exponential theorem is now proved | `self_germ_uniform_majorant_probe.py/json` challenges `[z^p]G_(g,self) <= (C|p|)^|p|/prod p_i!`: 480 varied skew-symmetrizable inputs, 217 nonconstant terms, no failure, largest ratio 1/16. This is weak supporting evidence only; it proves no uniform theorem. |
| Quasi-power consequences | Proved from the complex ray theorem; fresh review PASS | Fixed-order cumulants, degenerate CLT, conditional nonsingular Berry--Esseen, Fisher covariance, and the limited Newton barycenter statement follow with their exact hypotheses. |
| Ray rationality from stretched-exponential error | Rejected | Only an Abelian boundary asymptotic follows. Rationality remains an additional hypothesis before calling the dominant singularity a meromorphic simple pole. |

### Abstract diagnostic that led to the successful route

`abstract_submultiplicative_probe.py/json` defines an honest positive integer sequence with H=1, A_1=(1-s)^(-1), `A_n[p]=0` for n>p^2, and otherwise the minimum over all binary convolution bounds. It satisfies coefficientwise submultiplicativity by construction and the common majorant `A_n<=(1-s)^(-n)`. It was investigated as a possible countermodel to small-domain pressure equality. The balanced-tree theorem proves that this entire model has zero pressure on some positive neighborhood: it cannot furnish the sought counterexample there. The finite evaluations are labeled diagnostics and are not used in the proof.

### Independent computational check of the tree mechanism

The Wolfram Language kernel computed the exact dynamic-programming maximum active-node count for all `1<=n<=256`, `1<=p<=64`, and M in {1,2,9}: 49,152 states. The maximal exact ratios L/p were respectively 23/8, 61/16, and 13/2. All satisfy the proved bound `1+2sqrt(M)/(sqrt(2)-1)` (and the simpler integer bound `1+5ceil(sqrt(M))`). This independently checks the budget recursion; it does not verify the theta covariance input. Code and compact result are retained below.

## Literature record: 22:30--22:50 UTC

Previously audited primary interfaces were reread in the local notes: Fock--Goncharov's original scaling pairing; Reineke arXiv:0903.0261 fixed-stability framing products; Bridgeland arXiv:1603.00416 endpoint transport; Fernández--Procacci arXiv:math-ph/0605041 polymer convergence; Arkani-Hamed--Lam--Spradlin arXiv:1912.08222 ray generating functions; CMMM arXiv:2505.09585v2 Newton homogeneity. None supplied the missing general uniform zero-free domain directly.

Queries included `submultiplicative sequence generating functions coefficientwise cluster expansion analyticity pressure` and the title/number of Michelen--Sahasrabudhe arXiv:1910.06890. The latter classifies eventual nonnegative polynomial powers, but no implication to arbitrary theta stable H was imported. It remains only a possible interface for the signed stable background; the positive endpoint-germ route makes it unnecessary for the new theorem.

A 2026 article *Submultiplicative polynomials in combinatorics*, DOI 10.1007/s11139-026-01475-6, appeared in results. Its abstract concerns Bessenrodt--Ono-type pointwise polynomial inequalities. It was not fully audited and is not used. Search snippets are not treated as proof of applicability or correctness.

## Literature record: 22:50--23:10 UTC

### Direct novelty searches

Queries through both available search engines included:

- `"coefficientwise submultiplicative" series`;
- `"submultiplicative" "power series" "coefficients" "vanishing"`;
- `"submultiplicative" "graded" "Hilbert" "growth"`;
- `"dyadic" "pressure" "generating function" analyticity`;
- `theta functions cluster algebras scaling limit positive tropical pairing ray asymptotic 2025 2026`;
- `"theta functions" "cluster" "central limit theorem"`;
- `"F-polynomials" "central limit" coefficients`;
- `"cluster algebra" "quasi-powers"`;
- `"theta basis" asymptotic coefficients Gaussian`;
- `"F-polynomial" "asymptotic" coefficients`;
- `cluster theta functions random exponents Gaussian limit F-polynomials asymptotics`.

No directly matching general theta theorem or the specific polynomial-gap coefficientwise-submultiplicative lemma was located. Most theta/Gaussian hits concern Jacobi, Riemann, or lattice theta functions and are irrelevant. The algebra-growth hits concern one-graded Hilbert growth, not the two-index coefficientwise convolution condition used here. This is a recorded search outcome, not a priority certificate.

### Primary probability theorem: useful and checked

Heuberger--Kropf, *Higher Dimensional Quasi-Power Theorem and Berry--Esseen Inequality*, [arXiv:1609.09599](https://arxiv.org/pdf/1609.09599), full 16-page version, Theorem 1 and its surrounding qualifications were read directly. Its fixed complex-polydisc, analytic exponent, divergence, and nonsingular-Hessian conditions match the theta moment generating function exactly. It explicitly includes degenerate Gaussian convergence but does not promise a uniform distribution-function rate in that case. The earlier [arXiv:1602.04055v2](https://arxiv.org/pdf/1602.04055) is a 10-page conference extended abstract of the same work; it is not an independent second theorem. The full version is the cited tool. Hwang's 1998 original is identified by DOI 10.1006/eujc.1997.0179; its journal page and the original theorem as reproduced in the full primary Heuberger--Kropf paper were checked.

The quantitative application in the consequence note uses exactly the lower-orthant CDF conclusion, not a local lattice theorem or a total-variation theorem. The semidefinite CLT is also given a direct characteristic-function proof.

### 2026 Reading--Stella publication: verified metadata, no new imported claim

The primary journal page [SIGMA 22 (2026), 109](https://sigma-journal.com/2026/109/) confirms *Mutation of Theta Functions*, DOI 10.3842/SIGMA.2026.109, published 2026-11-08, with arXiv:2603.19391. Root reports that v4, also dated November 8, was already substantively audited. This branch imported no theorem from the publication without that existing audit; final-PDF-versus-v4 comparison remains with root. Its topic is mutation, structure constants, and pointed reduced bases, not a probability limit theorem.

### Further geometric interfaces: currently not used

Searches for self-stability/attractor framing and theta functions locate Mozgovoy--Pioline, *Attractor invariants, brane tilings and crystals*, [arXiv:2012.14358](https://arxiv.org/abs/2012.14358), published DOI 10.5802/aif.3682, and flow-tree literature. These do not automatically identify a classical arbitrary-label theta endpoint germ with a framed DT attractor invariant. That missing identification is explicitly retained.

Searches for cluster master functions locate Schechtman--Varchenko, *Positive Populations*, *Journal of Singularities* 20 (2020), 342--370, DOI [10.5427/jsing.2020.20p](https://doi.org/10.5427/jsing.2020.20p). Its primary abstract/introduction concerns KZ/Bethe critical points and type-A positive charts. It is a possible conceptual interface, not a theorem about the Q coefficient fibers in this project. No conclusion is used. In particular, replacing a finite multiplicative fiber count by a logarithmic critical-point count would require a new proof.

## Review files

- `../weighted_bezout_review/DYADIC_PRESSURE_INDEPENDENT_REVIEW.md`: PASS for the abstract tree estimate, whole-sequence strengthening, and analytic return identity; deliberately delegates the germ input.
- `../q_support_round2/RAY_PRESSURE_INDEPENDENT_REVIEW.md`: PASS for the actual positive endpoint germ, covariance direction, product positivity, exact sparsity, tree count, analytic boundary limit, and stated bounded-height scope.

## Wolfram code retained

```wolfram
ClearAll[l, res];
res = Table[
  l = ConstantArray[-1000000, {257, 65}];
  l[[All, 1]] = 0; l[[2, 2 ;;]] = 1;
  Do[
    If[n <= mm p^2,
      l[[n + 1, p + 1]] = 1 + Max[Table[
        l[[Floor[n/2] + 1, q + 1]] +
        l[[Ceiling[n/2] + 1, p - q + 1]], {q, 0, p}]]],
    {n, 2, 256}, {p, 1, 64}];
  With[{ratios = Flatten[Table[
    If[n <= mm p^2, l[[n + 1, p + 1]]/p, 0],
    {n, 1, 256}, {p, 1, 64}]]},
    {mm, Max[ratios],
     N[1 + 2 Sqrt[mm]/(Sqrt[2] - 1), 12],
     And @@ Flatten[Table[
       If[n <= mm p^2,
          l[[n + 1, p + 1]] <= (1 + 5 Ceiling[Sqrt[mm]]) p,
          True], {n, 1, 256}, {p, 1, 64}]]}],
  {mm, {1, 2, 9}}];
```

Returned exact rows: `{1,23/8,5.828427124746...,True}`, `{2,61/16,7.828427124746...,True}`, `{9,13/2,15.485281374238...,True}`. The true proof is the geometric active-node count and the injective four-symbol code, already checked independently.


## Literature and route record: 23:10--23:35 UTC

### New all-label mechanism, completed and reviewed

`UNIFORM_SELF_ENDPOINT_MAJORANT.md` proves a single matrix-dependent complex convergence and nonvanishing neighborhood for all integral labels. The decisive estimate is the total variation of the normal slope along an entire broken line: all bends on one primitive normal have total wall power at most a constant times the final root degree. Positivity permits their local wall functions to be bounded by one universal ray series and combined by ordinary Cauchy convolution. An injective color-word/cut encoding bounds all ordered packet compositions. Neither a positive polymer model nor linear stabilization is assumed.

`../global_theta_fresh_attack/UNIFORM_SELF_GERM_INDEPENDENT_REVIEW.md` independently checked the whole chain, including GHKK velocity conventions and backward geometric reconstruction, and supplied the robust actual-bend oscillation proof. It also verifies the direct first-bend sparsity estimate n <= M d^2/4. The root independently reviewed the proof. This closes the common-domain gap left by the earlier dyadic argument and identifies actual local ray pressure with analytic stable transport for all real labels.

The independent exact geometry diagnostic `crossing_variation_probe.py/json` generated 120,000 arbitrary rank 2--5 skew-symmetrizable packet sequences, accepted 595 valid backward paths, and checked 1,461 normal bounds, including 44 paths with repeated normals. All bounds passed. An independent Wolfram kernel reconstructed 84 retained paths and checked 204 exact normal bounds, all passing; the largest exact ratio sum(|bend speed|)/(2 variation) was 1/2. These unrestricted-hyperplane checks challenge the geometric estimate; actual scattering-support membership is not asserted for these paths.

### Additional primary novelty comparisons

Searches for `broken lines total variation`, `broken lines bending bound theta convergence`, `theta stable quotient cluster`, `theta functions scaling limit cluster`, and `Fock Goncharov scaling analytic pairing` did not identify the new all-label normal-variation bound. This is a search outcome, not proof of priority.

Barrott, *Convergence of the mirror to a rational elliptic surface*, Trans. London Math. Soc. 8 (2021), DOI 10.1112/tlm3.12028, primary article <https://londmathsoc.onlinelibrary.wiley.com/doi/full/10.1112/tlm3.12028>, was reread at Proposition 9.2, Lemma 9.3, and Theorem 9.4. Its convergence mechanism is specialized to rational elliptic surface geometry and does not state this arbitrary-rank all-label common self-germ theorem. No Barrott conclusion is imported.

### Genuine finite-Laurent / greedy route resumed

After the uniform theorem and its multiplication/probability consequences were completed, the next goal was returned to an effective finite-support mechanism. Old rational leading carriers, off-leading positive carriers, and the earlier explicit coercive-gauge theorem were read before proposing another version. They already cover cluster-algebra theta elements, suitable saturated positive semigroups, and separately certified coercive gauges, so no repackaging is counted as a new result.

The analytic pressure width L(g)+L(-g) is an ordinary coercive convex function because the analytic body is full dimensional. It has NOT been shown convex in affine time along broken lines; using ordinary convexity as that stronger certificate would be invalid and would incorrectly imply finite Laurentness of every formal label. The small-positive-domain entropy bound also provides no upper degree cutoff, since -<q,log z> grows in positive root directions. These two shortcuts are explicitly rejected, and work continues on a true support mechanism.

A concrete open interface is now the support-padding statement: whether every actual theta support direction lies in the span of the eventual stable support. The reverse containment follows from positive product domination. The stable span can be identified with the root span of log A_g^- by the least-degree argument and nonzero lambda_g on that factor. The missing direction concerns genuine transient self-germ bends. An exact random span diagnostic is being run as a falsification tool, not a proof or a special-case substitute.


## Literature and route record: 23:35--00:00 UTC

The finite-state/transfer-matrix search was broadened to `theta functions automaton cluster`, `cluster algebras finite automata`, `theta basis automata`, `F-polynomials transfer matrix`, and related primary-title queries. Di Francesco--Kedem, [arXiv:0906.3421](https://arxiv.org/abs/0906.3421) and [arXiv:0811.3027](https://arxiv.org/abs/0811.3027), provide explicit path and transfer models for A_r Q-systems, with type-specific integrable structure. These are useful methodological interfaces, not an arbitrary-label/all-seed theta finite-state theorem. No such general theorem was located. ALS's ray-rationality proposal remains a separate additional hypothesis.

The actual CMMM [arXiv:2505.09585v2](https://arxiv.org/pdf/2505.09585v2) text was reread at Sections 3.2--3.5 and 5.2. Their rational broken-line deformation and tautness prove uniqueness for generic minimizing monomials, but do not state that all rational endpoint sets are star-shaped about the leading exponent, or that every theta Newton edge is saturated. Those unproved strengthenings were not used. A support-span proof by homotopy must control birth/removal of paired crossings at tangencies; consistency through joints alone is insufficient.

The Q-algebra pruning attempt is concrete: removing a root of color i whose positive T-valuation v is strictly smaller than all remaining root valuations replaces its factors in other rows by T-powers times analytic units. The remaining label g is unchanged and the endpoint shifts by a'_j=a_j+B_ji v. The previously proved coordinate-unit deformation handles the units, but positivity of every a'_j is not automatic. Also an outermost collision cluster need not split into one removable root. The full arbitrary-endpoint coefficient theorem is valid, but this operation does not yet give an initial-positive-chamber predecessor. This exact gap, rather than a fictitious Hall identification, is the current pruning interface.

The direct coarse-factor span probe `stable_support_span_probe.py/json` tested 600 rank 3--5 skew-symmetrizable inputs. Every stable finite-prefix span was a coordinate subspace; 107 theta prefixes had directions not yet visible in the same small stable prefix. The latter can be delayed stable activation and are not counterexamples. The global statements V_g coordinate and span supp(F_g)=V_g remain conjectural. The stable span equals the root span of log A_g^- by a least-degree argument, and also equals the span of actually crossed negative-path wall roots by the finite-cutoff positive-slot argument. The missing step is a theta-specific padding/reassociation mechanism for transient roots.
