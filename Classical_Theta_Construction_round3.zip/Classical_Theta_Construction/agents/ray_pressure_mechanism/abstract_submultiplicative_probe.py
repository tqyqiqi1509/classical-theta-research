"""Exact maximal coefficientwise-submultiplicative test model.

This is a logic probe, not a theta example. A_1=(1-z)^-1; recursively
A_n[p]=0 for n>p^2, otherwise the minimum over every convolution split.
It has positive integer coefficients, A_(m+n)<=A_m A_n, the same quadratic
coefficient-vanishing threshold as H=1, and A_n<=(1-z)^-n. No conclusion
about its pressure is presumed from a finite computation.
"""
from pathlib import Path
import math,json,time

def run(N=100,P=50):
    start=time.time();A=[[0]*(P+1) for _ in range(N+1)]
    A[0][0]=1;A[1]=[1]*(P+1)
    for n in range(2,N+1):
        A[n][0]=1
        for p in range(math.isqrt(n-1)+1,P+1):
            A[n][p]=min(sum(A[m][q]*A[n-m][p-q] for q in range(p+1))
                        for m in range(1,n//2+1))
        if n%20==0:print(n,time.time()-start,flush=True)
    rows=[]
    for n in [1,2,3,4,5,8,12,16,24,32,48,64,80,100]:
        if n>N:continue
        vals={str(z):math.log(sum(a*z**p for p,a in enumerate(A[n])))/n
              for z in [0.03,0.1,0.2,0.4,0.6]}
        rows.append(dict(n=n,first_positive=next((p for p in range(1,P+1) if A[n][p]),None),
                         finite_prefix_log_values=vals))
    out=dict(status='diagnostic only; no pressure theorem',N=N,P=P,rows=rows,
             coefficients=A,seconds=time.time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='coefficients'},indent=2),flush=True)

if __name__=='__main__':run()
