# Fresh continuation: finite Laurent support and stable-root span

2026-11-13, 23:58 UTC. This is an internal continuation note, not a new theorem or a replacement for the general finite-output problem.

## Completed input, available to use

`UNIFORM_SELF_ENDPOINT_MAJORANT.md` is independently reviewed. Its common local complex domain works for every integral label. In a smaller ball, q<1/2,

    F_m = exp(L(m)+E_m),
    |E_m| <= log((1-q)/(1-2q)),

uniformly in m. On an integral ray, the residual tends to zero with the explicit stretched-exponential bound. The geometric input is the sum-of-normal-bending-speeds bound; it does not give a root-degree upper cutoff.

`../uniform_consequences_fresh/NEGATIVE_FACTOR_ROOT_SPAN.md` proves the useful identity

    span supp(H_g-1) = span supp(log A_g^-).

The same span is the span of actual wall roots crossed by a straight positive-directed path from the positive-zero-root germ at g to the positive chamber. To see the nontrivial containment, fix a wall term and a finite degree cutoff. For n sufficiently large every wall exponent in that cutoff is nonnegative. Choose this wall term and the empty terms at all other walls. It gives a positive coefficient in H_g^n, and hence its degree belongs to the span of H_g. This uses positivity only after the finite large-n threshold; H_g itself need not have nonnegative coefficients.

The open theta-specific targets are

    V_g := span supp(H_g-1) is a coordinate subspace,
    span supp(F_g-1) = V_g.

The second would upgrade the covariance theorem to full Newton dimension and eliminate all dormant support directions. It would not alone prove finite Laurent termination.

## Constructive Q pruning operation

Start with an actual positive-valuation Q-algebra fiber for label g, root degree p, endpoint a. Suppose one root r of color i has T-valuation v>0 strictly smaller than every remaining root. For a remaining root of color j, its factor involving r is T^(B_ji v) times an analytic unit, with the same sign conventions as the Q-polynomial paper. Removing r therefore produces a Q system with

    p' = p-e_i,          g'=g,
    a'_j = a_j+B_ji v.

The previously proved coordinate-unit deformation can remove the analytic units. This is an operation on actual coefficient objects, not a numerical equality lookup. The unresolved issue is a'_j>0 for all remaining colors. The initial endpoint a may be chosen arbitrarily in the positive chamber, but no choice has been proved always to provide such a removable root.

Further, roots of several colors may occupy one outermost valuation/collision cluster. A single-root deletion then is unavailable; removal of a whole outer cluster gives an analogous endpoint shift. A bounded-size or positive-endpoint selection theorem for such clusters would be a genuine support-accessibility mechanism. It has not been obtained.

Do not require the removed direction to have negative final mutable exponent. The older exact counterexample to that stronger predecessor rule is retained in `../finite_core_round5/negative_accessibility_results.json`. Strictly isolated outermost roots satisfy that sign, but an arbitrary positive coefficient need not have such a root.

## Constructive wall-tree / span route

Suppose a root a on the negative path is obtained by a positive local rank-two scatter of child roots b,c, with a=u b+v c and u,v>0. Since lambda_g(a)<0, at least one child has negative lambda. If that child is already in V_g, then the other child is also in V_g. To turn this into coordinate-span induction, a lambda-positive composite child must be reassociated with the negative child so that a new actual negative-path root appears. Ordinary Jacobi identities are signed and do not certify this. A positive arrow/flagged-tree reassociation valid for the actual global wall catalog would suffice at the support level.

Available local explicit transport: `../intrinsic_greedy_round2/STABLE_TREE_FLOW_SWEEP.md` and `POSITIVE_FOREST_NORMAL_FORM.md`. Their fixed thin-graph and acyclicity restrictions must be respected. Raw stable trees are not automatically the global tight-grading theta catalog, and the cyclic residual-terminal selection is not proved invariant under arbitrary stability changes. This is the exact interface to improve.

A direct homotopy of broken lines is not yet a proof: local joint crossings change normals inside their rank-two spans, but a homotopy can create or remove pairs of crossings at a tangency. Control of those births is required before concluding that every transient bend lies in the negative-path span.

## Exact diagnostic, not a theorem

`stable_support_span_probe.py/json` uses the direct incoming coarse-factor routine `computation/stable_root_probe.py::stable_root`, returning (H, threshold, R), with R.theta_prefix(g,cap) for F.

Across 600 random skew-symmetrizable inputs of ranks 3--5, every computed H-prefix span was a coordinate subspace. In 107 cases the corresponding F prefix had directions not yet present in the small H prefix. These need delayed-activation analysis and are not global counterexamples. The JSON retains witnesses. There is no reason to repeat a broad random test without a concrete stronger hypothesis.

## Literature interfaces just refreshed

- CMMM, arXiv:2505.09585v2, Sections 3.2--3.5 and 5.2: rational bend deformation, taut minimizers, and uniqueness are genuine tools. They do not state star-shapedness of all rational endpoint sets or saturation of every theta Newton edge. Root already audited this primary source.
- Leung--Ma--Young, arXiv:1902.05765v2, primary opened, Theorems 3.15 and 3.20: theta functions as limits of flat sections of a Maurer--Cartan deformation and explicit marked-tree expansions. Their asymptotic variable is the concentration parameter hbar, not the large label n. Their Hall combinatorial theorem has acyclic/nondegenerate hypotheses. This is a possible tree/PDE interface, not a supplied all-label positivity or finite-state theorem.
- Di Francesco--Kedem, arXiv:0906.3421v3, primary opened: type A_r Q-system transfer matrices and local network rearrangements. These use integrable structure and are not an arbitrary-seed theta ray transfer model.
- Searches for arbitrary theta finite-state/automaton models did not locate a general result. ALS ray rationality remains an extra hypothesis.
- Fei generic F-polytope algorithms and generic-character quotient arguments cannot be identified with all theta functions without a separate theorem. No Li--Pan conclusion is used.

## Avoid duplicate routes

The old rational leading carriers, their saturation, off-leading positive cluster carriers, and explicit coercive-gauge theorem are already in the package. A new positive divided-power operator from the support-accessibility branch may enlarge the closure of known finite carriers, but completeness of this closure for all regular theta labels is unproved.

The analytic body width is an ordinary coercive convex function; it is not automatically convex in affine time along broken lines. The local small-z entropy bound does not give an upper support cutoff. Neither shortcut should be retried without a new structural input.
