# Analytic ray quotients, Gaussian exponent laws, and a local Newton interface

2026-11-13, 23:00 UTC; common-domain strengthening at 23:25 UTC. Classical skew-symmetric and skew-symmetrizable theta functions with principal coefficients. These are consequences of the general positive-germ theorem, first proved per direction in `DYADIC_VANISHING_PRESSURE.md` and then on one domain for all labels in the independently reviewed `UNIFORM_SELF_ENDPOINT_MAJORANT.md`. No finite-Laurent assumption is used until Section 5.

The probability machinery is classical. The substantive theta input is the **uniform complex asymptotic for the whole label ray**, proved by transporting to a positive endpoint germ; the uniform-in-label strengthening bounds the total wall exponents by scalar slope variation. The central-limit principle itself is not claimed as new.

## 1. The analytic input and actual stable quotients

Fix an integral label g. On the explicit small complex neighborhood from the ray theorem, write

    theta_(ng)=x^(ng) F_n(z),
    H(z)=H_g(z),             L(z)=log H(z),
    R_n(z)=F_n(z)/H(z)^n.

Here H is holomorphic and zero-free, with H(0)=1. On every compact subset K of that neighborhood there are constants A,c>0, independent of n, such that

    sup_(z in K) |R_n(z)-1| <= A exp(-c sqrt(n)).          (1.1)

On the common domain supplied by `UNIFORM_SELF_ENDPOINT_MAJORANT.md`, the constants A,c depend on K and the fixed seed, and may be chosen independently of the integral label g. The earlier balanced-tree proof alone gave the weaker direction-dependent domain. All statements below may now be made on the new common domain. The constants in a nondegenerate Gaussian approximation can still depend on g through the covariance and analytic exponent.

For large n, `|R_n-1|<1/2` on K. Therefore

    F_(n+1)(z)/(H(z)F_n(z)) -1
        = [R_(n+1)(z)-R_n(z)]/R_n(z),

and hence

    F_(n+1)/F_n = H [1+O(exp(-c sqrt(n)))].             (1.2)

Thus the formal stable quotient is also the actual locally uniform analytic quotient limit. On any smaller simply connected neighborhood, using logarithms with their prescribed value at coefficient zero,

    log F_n = n L + O(exp(-c sqrt(n))),
    (log F_n)/n = L + O(n^(-1)exp(-c sqrt(n))).         (1.3)

The error in (1.3), together with all its fixed-order complex derivatives on smaller compact subsets, has the same stretched-exponential bound. This follows from Cauchy's estimates applied to `log R_n`, not from a bound on F_n alone.

## 2. A probability law on principal exponents

Fix a strictly positive z in the small domain. Write

    F_n(z)=sum_(p in N^r) a_(ng)(p) z^p.

Define an N^r-valued random vector P_n by

    Pr(P_n=p)=a_(ng)(p) z^p/F_n(z).                    (2.1)

All terms are nonnegative and their sum is one. The common analytic convergence theorem makes this law meaningful even if F_n has infinitely many monomials.

Choose a fixed tau>0 such that `z exp(t)` remains inside the complex ray domain for all complex vectors t with `||t||_infinity<=tau`. Componentwise exponential and multiplication are meant. The moment generating function is

    M_n(t)=E exp(<t,P_n>)=F_n(z exp(t))/F_n(z).

Set

    U(t)=L(z exp(t))-L(z),
    mu_i=(z_i partial_(z_i)) L(z),
    Sigma_ij=(z_i partial_(z_i))(z_j partial_(z_j)) L(z).

By (1.1), uniformly on the fixed complex polydisc,

    M_n(t)=exp(n U(t))[1+O(exp(-c sqrt(n)))].           (2.2)

This is a multivariate quasi-power estimate with analytic exponent U and with no order-one prefactor: the prefactor tends to one. More precisely,

    log M_n(t)=n U(t)+E_n(t),
    E_n(0)=0,
    sup_(||t||<=tau) |E_n(t)|=O(exp(-c sqrt(n))).       (2.3)

### Cumulants and moments

For each fixed nonzero multi-index alpha, the corresponding joint cumulant satisfies

    kappa_alpha(P_n)
       = n (partial_t^alpha U)(0) + O(exp(-c sqrt(n))). (2.4)

Indeed joint cumulants are the derivatives of log M_n at zero; Cauchy's estimate bounds the derivative of E_n on a smaller polydisc. In particular,

    E P_n = n mu + O(exp(-c sqrt(n))),
    Cov(P_n)=n Sigma + O(exp(-c sqrt(n))).             (2.5)

The error is entrywise in the finite-dimensional vector or matrix. The matrix Sigma is positive semidefinite, since it is the limit of the positive semidefinite matrices `Cov(P_n)/n`. The entries of mu are nonnegative, since they are limits of `E P_(n,i)/n`.

Equation (2.5) also proves the law of large numbers in L^2:

    P_n/n -> mu,
    E ||P_n/n-mu||_2^2 = tr(Sigma)/n+o(1/n).          (2.6)

All mixed moments of a fixed total order can be recovered from the usual moment-cumulant partition formula. They are polynomials in n, determined by derivatives of L, up to an error bounded by a polynomial in n times `exp(-c sqrt(n))`. A slightly smaller c absorbs that polynomial if desired.

## 3. Gaussian limit, including degenerate directions

The centered exponent vector satisfies

    (P_n-n mu)/sqrt(n) ==> N(0,Sigma).                (3.1)

The Gaussian law is allowed to be degenerate. A direct proof is short. For fixed real u, insert `t=i u/sqrt(n)` into (2.3). Taylor expansion gives

    n[U(iu/sqrt(n))-i<u,mu>/sqrt(n)]
       = -u^T Sigma u/2 + O(n^(-1/2)||u||^3).

The analytic error E_n tends to zero. Hence the characteristic functions converge to `exp(-u^T Sigma u/2)`. The characteristic-function continuity theorem proves (3.1). Positive semidefiniteness was established independently from the covariance limit.

If Sigma is positive definite, the standard higher-dimensional quasi-power theorem applies with

    phi_n=n,          v(t)=0,          kappa_n=exp(c sqrt(n)).

It gives the quantitative lower-orthant distribution estimate

    sup_(x in R^r) |
      Pr((P_n-n mu)/sqrt(n) <= x)-Phi_Sigma(x)
    | = O(n^(-1/2)).                                  (3.2)

Here `<=` is componentwise, and Phi_Sigma is the nondegenerate Gaussian distribution function. No local lattice limit theorem is asserted. In the singular case (3.1) still holds, but (3.2) is not claimed. One may apply (3.2) to any fixed linear projection for which the projected covariance is positive definite.

The primary tool is Heuberger--Kropf, *Higher Dimensional Quasi-Power Theorem and Berry--Esseen Inequality*, Theorem 1, full version [arXiv:1609.09599](https://arxiv.org/pdf/1609.09599), later published in *Monatshefte für Mathematik* (DOI [10.1007/s00605-018-1215-6](https://doi.org/10.1007/s00605-018-1215-6)). Its stated hypotheses are exactly a fixed complex polydisc, analytic n-independent exponent functions, a diverging scaling parameter, and nonsingular Hessian for the quantitative conclusion; it also states the degenerate convergence conclusion. Hwang's original one-dimensional quasi-power method is [DOI 10.1006/eujc.1997.0179](https://doi.org/10.1006/eujc.1997.0179), *European Journal of Combinatorics* 19 (1998), 329--343. These are old probability tools; (1.1) is the theta-specific input.

## 4. Information metric and Laurent exponents

Use logarithmic positive parameters `u_i=log z_i`. The score of the family (2.1) is

    partial_(u_i) log Pr_u(P_n=p)
       = p_i - E_u P_(n,i).

Thus its Fisher information matrix is exactly `Cov_u(P_n)`. Equations (2.5) give

    Fisher_n(u)/n -> Hess_u L(exp u)=Sigma(u),          (4.1)

with stretched-exponential error after multiplying the normalized error by n. This supplies a direct statistical meaning for the analytic Hessian of the stable ray logarithm. It is a metric on any parameter subspace on which Sigma is positive definite; no universal nonsingularity is assumed.

For the mutable Laurent exponent vector `X_n=ng+B P_n`, the same results push forward linearly:

    E X_n=n(g+B mu)+O(exp(-c sqrt(n))),
    Cov(X_n)=n B Sigma B^T+O(exp(-c sqrt(n))),
    (X_n-n(g+B mu))/sqrt(n) ==> N(0,B Sigma B^T).       (4.2)

Frozen exponents are retained in P_n, so possible collisions among mutable Laurent monomials do not cause ambiguity. Aggregating collided monomials gives the same law for X_n.

These conclusions concern probability weights at a positive evaluation. They do not assert coefficientwise log-concavity, real-rootedness, or a local Gaussian approximation to each individual lattice coefficient.

## 5. Finite Newton polytopes: a limited but concrete consequence

Suppose in addition that F_g is a polynomial, and let `P=Newt(F_g)`. Using the known theta Newton homogeneity `Newt(F_(ng))=nP`, every `P_n/n` lies in P. Its mean lies in P, so (2.5) gives

    grad_(log z) L_z(g)=mu(z) in P.                   (5.1)

No claim that mu lies in the relative interior is needed or made. The differential of this barycenter map is Sigma. On any parameter subspace where the restricted covariance is positive definite, the inverse function theorem makes this map a local coordinate map onto its image in the corresponding projection of P.

The Newton homogeneity input is Cheung--Magee--Mandel--Muller, *Valuative independence and cluster theta reciprocity*, [arXiv:2505.09585v2](https://arxiv.org/abs/2505.09585), Lemma 2.9, independently checked elsewhere in this project. Statement (5.1) is a consequence of that known input and the new analytic ray asymptotic, not a new claim of Newton homogeneity.

## 6. Ray generating functions: Abelian conclusion and rational refinement

At a fixed positive z in the small domain, let

    S(t)=sum_(n>=0) F_n(z)t^n,       F_0=1,
    H=H_g(z)>0.

Since `F_n/H^n=1+O(exp(-c sqrt(n)))`, the exact radius of convergence of S is `H^(-1)`. For `T=tH`,

    S(t)=1/(1-T)+E(T),
    E(T)=sum_(n>=0) (F_n/H^n-1) T^n.                 (6.1)

The coefficients of E have stretched-exponential decay. In particular E and every fixed-order derivative have absolutely convergent series on `|T|<=1`. It follows that

    lim_(t up to H^(-1)) (1-tH) S(t)=1.              (6.2)

This is an Abelian principal-pole **asymptotic**, not a claim that S extends meromorphically through its convergence circle. The remainder E could, on the present estimates alone, have a natural boundary.

If one separately knows that S is rational in t, then (6.1) is rational as well. The absolute convergence of all its boundary derivatives excludes poles of E on `|T|=1`; rationality then implies that E is analytic on some larger disk. Therefore S has exactly one pole of smallest modulus, at `t=H^(-1)`, and it is simple, with residue `-H^(-1)`. The rationality assumption is additional and is not proved here. This is the precise conditional interface with ray-generating-function proposals such as Arkani-Hamed--Lam--Spradlin [arXiv:1912.08222](https://arxiv.org/abs/1912.08222), Section 3.2.

## 7. Novelty status and limits of this note

The generic quasi-power principle, cumulant differentiation, Fisher-covariance identity, and Abelian argument are established tools. The new general theta mechanism consists of the positive endpoint-germ normalization, the bounded total normal-slope variation, the positive packet-profile convolution, and the resulting actual complex asymptotic (1.1) for every integral classical label. The independent balanced-tree argument supplies a second, weaker route from polynomial sparsity to local ray convergence. The probability and Newton statements make the analytic asymptotic usable.

Searches on 2026-11-13 for cluster theta/F-polynomial random exponents, Gaussian limits, and quasi-powers did not identify an earlier general theta theorem with this hypothesis-free-in-type scope. This is evidence of coverage, not a proof of historical priority. The exact searches and rejected unrelated theta-function hits are recorded separately. The strengthened domain is one small seed neighborhood valid for all integral directions and for the continuous real-label pressure extension; the full global Fock--Goncharov scaling problem on the whole positive variety is not claimed.
