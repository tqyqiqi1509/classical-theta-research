"""Challenge a label-uniform self-endpoint coefficient majorant.

This is a diagnostic for an unproved general mechanism, not a theta theorem.
The oracle is the independent incoming signed-factor recurrence. The proposed
bound removes the framing norm G from the already proved all-endpoint bound.
"""
from pathlib import Path
from fractions import Fraction
from math import factorial
import json, random, sys, time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
from incoming_recursion import IncomingSchur
from arbitrary_endpoint_ray import endpoint

def run(trials=480):
    rng=random.Random(202611132310);start=time.time()
    checks=nonzero=0;best=Fraction(0);witness=None;failures=[]
    for it in range(trials):
        r=2 if it<120 else 3 if it<400 else 4
        D=[rng.randint(1,3) for _ in range(r)]
        B=[[0]*r for _ in D]
        for i in range(r):
            for j in range(i+1,r):
                a=rng.randint(-4,4);B[i][j]=D[j]*a;B[j][i]=-D[i]*a
        scale=(1,5,50,1000)[it%4]
        g=tuple(scale*rng.randint(-3,3)+rng.randint(-2,2) for _ in D)
        cap=(3,3) if r==2 else (2,2,2) if r==3 else (1,1,1,1)
        engine=IncomingSchur(B,D)
        F=endpoint(engine,g,tuple(D[i]*g[i] for i in range(r)),cap)
        C=max(1,max(abs(a) for row in B for a in row))
        for p,a in F.items():
            if not any(p):continue
            checks+=1;nonzero+=a>0
            d=sum(p);den=1
            for pi in p:den*=factorial(pi)
            num=(C*d)**d
            ratio=Fraction(a*den,num)
            if ratio>best:
                best=ratio;witness=dict(B=B,D=D,g=g,p=p,coefficient=a,
                    proposed_bound=[num,den],ratio=str(ratio))
            if a*den>num:
                failures.append(dict(B=B,D=D,g=g,p=p,coefficient=a,
                    proposed_bound=[num,den],ratio=str(ratio)))
        if failures:break
        if (it+1)%80==0:
            print(json.dumps(dict(completed=it+1,nonzero_terms=nonzero,
                                 largest_ratio=str(best),seconds=time.time()-start)),flush=True)
    result=dict(status='diagnostic only: no label-uniform theorem',
        proposed='[z^p]G_(g,self) <= (C*|p|)^|p|/prod(p_i!)',
        inputs=it+1,nonconstant_checks=checks,largest_ratio=str(best),
        witness=witness,failures=failures,seconds=time.time()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)

if __name__=='__main__':run()
