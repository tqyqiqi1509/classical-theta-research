# Independent check of the nonnegative monomial face theorem

2026-11-14. Fresh reconstruction of `../newton_faces_fresh_final/BONGARTZ_MONOMIAL_FACE_THEOREM.md`, with no reliance on prior PASS reports. Classical parameter \(q=1\). No numerical example is a premise.

## 1. Conclusion and hypotheses retained

The theorem is correct under its stated hypotheses: a finite principal theta function, and a supplied finite mutation path ending with nonnegative root valuations. The proof does not establish existence of such a path for every face normal.

The crucial symmetrizable formula is the weighted label

\[
h=D_J^{-1}C_J^TDv,\qquad v=A_{\mathrm{mut}},
\]

where \(A\) is the **actual face prefactor**, rather than the ambient theta's current leading label. I independently derived the strict and tied updates below. The displayed formulas in §§4–6 of the main note have the correct signs and \(D\)-weights.

One wording correction was sent to the author and has been incorporated: for the maximum face normal \(w\), the cluster-fan statement concerns \(\beta_0=-w\), not \(w\).

The external cluster ingredients actually checked are Nakanishi–Zelevinsky, arXiv:1101.3736v3, Theorem 1.2 and Proposition 4.2, and GHKK, arXiv:1411.1394v2, Proposition 7.1/Definition 7.2. Their locally available primary texts were read at these statements. The general sign-coherence input remains essential. The local proof below does not additionally require a black-box Bongartz existence theorem.

## 2. Why a tie has one complementary direction, with equal weights

At a current stage assume

\[
C=G^{-T},\quad C_J\ge0,\quad \beta=Ga,
\qquad a_I>0,\quad a_J=0,
\qquad DQ=C^TDBC.
\]

At \(\beta_k=0\), row sign coherence of \(G\) implies \(G_{ki}=0\) for every \(i\in I\). Set

\[
x=G^Te_k=C^{-1}e_k.
\]

Then \(x_I=0\), and the nonzero entries of \(x_J\) have one common sign. The equality \(e_k=C_Jx_J\), with \(C_J\ge0\), excludes the negative sign. The entries are nonnegative integers. Every contributing column must have zero entries outside row \(k\), because the sum has that property. Since a column of an integral unimodular matrix is primitive, each such column would have to be \(e_k\). Invertibility permits only one such column, and its coefficient must be one. Thus

\[
C_j=e_k,\qquad x=e_j,
\]

for a unique \(j\in J\).

The scaling \(D(-B)D^{-1}=B^T\) commutes with every matrix mutation, since the diagonal factors are positive. Applied to the full principal coefficient pattern, it shows that \(DCD^{-1}\) is another integral unimodular C-matrix. Its \(j\)-th column is \((d_k/d_j)e_k\), and the \(k\)-th column of its inverse is \((d_j/d_k)e_j\). Both ratios are positive integers. Therefore

\[
d_j=d_k.
\tag{2.1}
\]

This equality is indispensable: it makes the lower mutation exponent exactly \(h_j=v_k\), rather than a rescaled exponent. It is proved, not assumed.

At a strict step, a nonnegative complement column cannot be supported only at row \(k\), since \(\beta^TC_j=0\) and \(\beta_k\ne0\). Its positive entry outside that row survives the initial-seed change. At a tie, mutating the unique \(j\) makes the new \(j\)-column \(e_k\), and every other complement column still has a positive entry outside row \(k\). Sign coherence then makes every new complement column nonnegative. This verifies the induction maintaining \(C_J\ge0\).

## 3. Strict prefactors and labels

Let

\[
E_\varepsilon=J_k+[\varepsilon B]_{k\bullet,+},
\qquad \varepsilon=\operatorname{sign}(\beta_k).
\]

Then \(E_\varepsilon^2=I\), the current completion changes initial seed by

\[
C'=E_\varepsilon C,
\]

and the strict initial coordinate map is monomial. Its inverse exponent transformation on the prefactor is

\[
A'_k=-A_k,\qquad
A'_i=A_i+[-\varepsilon\mathcal E_{ik}]_+A_k\quad(i\ne k),
\]

where \(\mathcal E\) is the full tall exchange matrix. The formula includes all frozen rows. It gives \(\Phi^*(X'^{A'})=X^A\) exactly.

For the mutable part,

\[
v'=D^{-1}E_\varepsilon^TDv.
\]

Therefore

\[
C'^TDv'=C^TE_\varepsilon^TE_\varepsilon^TDv=C^TDv.
\]

The weighted lower label stays unchanged. The root calculation similarly gives \(\Phi^*(z'^{C'_l})=z^{C_l}\). Thus a strict ambient step leaves the lower theta seed and lower label fixed.

## 4. The tied step, computed without suppressing any weight

Write \(t=v_k\). At a tie use the unique \(j\) from Section 2. Set

\[
E=E_+,\quad C_{\mathrm{temp}}=EC,
\quad R=J_j+[Q]_{j\bullet,+},\quad C'=C_{\mathrm{temp}}R.
\]

The current full exponent update is

\[
A'_k=-t,\qquad
A'_i=A_i+[\mathcal E_{ik}]_+t-\mathcal E_{ik}\min(t,0).
\tag{4.1}
\]

Because \(X'_k=X_k^{-1}M_-(1+z_k)\), direct substitution, including the frozen exponents in (4.1), gives

\[
\frac{\mu_k^*(X'^{A'})}{X^A}
=z_k^{[t]_+}(1+z_k)^{-t}.
\tag{4.2}
\]

There is no requirement that \(A\) be an ambient theta label for this identity.

Put \(Y_l=z^{C_l}\). Since \(C_j=e_k\), \(Y_j=z_k\). The weighted exchange identity gives

\[
d_jQ_{jl}=C_j^TDBC_l
=d_k\sum_iB_{ki}C_{il}.
\]

By (2.1), \(Q_{jl}=\sum_iB_{ki}C_{il}\). Substitution into the ordinary root mutation now yields

\[
\mu_k^*(z'^{C'_j})=Y_j^{-1},
\]

\[
\mu_k^*(z'^{C'_l})
=Y_lY_j^{[Q_{jl}]_+}(1+Y_j)^{-Q_{jl}}
\quad(l\ne j).
\tag{4.3}
\]

These are exactly the root mutation formulas for \(Q_{JJ}\), with no residual frozen factor.

For the label, let \(b=D^{-1}C^TDv\), so \(b_J=h\), and \(b_j=t\). The matrix \(D^{-1}C^TD=(DCD^{-1})^T\) is integral, which also confirms label integrality. A componentwise calculation from (4.1) gives

\[
E^TDv'=Dv-d_k[t]_+B_{k\bullet}^T.
\]

Hence, using skew-symmetry of \(DQ\),

\[
D^{-1}C_{\mathrm{temp}}^TDv'
=b+Q_{\bullet j}[t]_+.
\]

Multiplication by \(D^{-1}R^TD\) then gives

\[
b'_j=-b_j,
\]

\[
b'_l=b_l+Q_{lj}[b_j]_++[-Q_{lj}]_+b_j
=b_l+[Q_{lj}]_+b_j-Q_{lj}\min(b_j,0).
\tag{4.4}
\]

Restricted to \(J\), this is exactly the lower theta label mutation. In particular \(h_j=t=A_k\).

The lower F-polynomial covariance has prefactor

\[
Y_j^{[h_j]_+}(1+Y_j)^{-h_j}.
\]

Equations (4.2)–(4.4) identify this prefactor and all lower roots with the actual ambient pullback. Thus the entire lower theta, not only its Newton polytope or a selection of branches, transports through the tie. This proves the face identity at that step.

## 5. Frozen variables at the optimized endpoint

At the endpoint, the full theta has the expansion

\[
X^{m_s}\sum_{q\ge0}a_qz^q.
\]

Since \(\beta_s\ge0\), its minimum part is exactly the subseries with root degrees supported on \(J\). Nonnegative root grading makes the degrees having a positive coordinate outside \(J\) a Lie ideal. Quotienting by that ideal leaves the rank-\(J\) scattering diagram. Equivalently, a broken line contributing zero degree outside \(J\) can bend only at roots supported on \(J\).

The coefficient of every retained root degree depends on the mutable \(J\)-part \((m_s)_J\) and the matrix \(B_{s,JJ}\). A frozen exponent pairs trivially with all remaining wall normals. The components of a retained root in the frozen directions remain in the actual monomial \(z_j=X^{\mathcal E_se_j}\); the frozen leading exponent remains in \(X^{m_s}\). Thus the precise expression is

\[
X^{m_s}F_{(m_s)_J}^{B_{s,JJ}}((z_j)_{j\in J}).
\]

This uses the full ice roots and does not specialize frozen variables to one. The columns of the tall principal exchange matrix remain independent under mutation, so the retained roots are independent. The lower F-series is therefore finite because this retained ambient subseries is finite. GHKK Proposition 7.1 then guarantees its finiteness in all lower seeds used by the tied mutations.

## 6. Why the final shift is nonnegative and the whole face is obtained

The induction ends in the original principal chart with

\[
\operatorname{in}_{u_0}(\theta_g)
=X_0^A F_h^{Q_{JJ}}(z^{C_J}).
\tag{6.1}
\]

Set \(S=C_J\). It is nonnegative and has full column rank, because its columns belong to an integral unimodular matrix. The lower F-polynomial is an ordinary polynomial with constant coefficient one. A nonzero lower degree cannot map to zero under \(S\). Therefore the monomial \(X_0^A\) occurs in (6.1), with coefficient exactly one.

The left side is an actual face of the pointed principal expansion

\[
X_0^{(g,0)}F_g(z),\qquad
\mathcal E_0=\binom{B_0}{I}.
\]

Consequently there is a unique \(p\in\mathbb N^n\) with

\[
A-(g,0)=\mathcal E_0p.
\]

The original frozen rows give \(p=A_{\mathrm{frozen}}\). This is the proof of nonnegativity; it is not assumed from the signs of the recursive exponent updates. The mutable rows give the exact check \(A_{\mathrm{mut}}-g=B_0p\).

Dividing (6.1) by the initial leading monomial yields

\[
F_g|_{\max(w)}=z^pF_h^{Q_{JJ}}(z^S).
\]

Every lower monomial has a distinct image, since both \(S\) and the original principal root map are injective. Thus this identity retains every coefficient and gives the full affine Newton face, without a convex-hull enlargement or a branch filter. The relation \(\beta_0^TC_J=0\) also gives \(w^TS=0\), as required for an image lying in one face hyperplane.

No additional hypothesis was found in these steps. The supplied optimized path, the standard cluster sign-coherence/duality input, and theta mutation plus zero-degree freezing are the exact dependencies.

## 7. Independent check of the subsequent canonical-cone corollary

I also read `../newton_faces_fresh_final/CANONICAL_FACE_MODEL_ON_DUAL_CLUSTER_CONES.md` and checked its additional path-independence argument against the primary CGY text. The corollary follows, with \(D\) understood to be a positive **integral** symmetrizer for its gcd formula.

The point \(-w\) in the relative interior of a simplicial \(B^T\) g-cone determines its primitive g-rays and therefore its partial cluster \(U\). Every optimized endpoint expresses this point as a positive linear combination of exactly those rays. The abstract variable correspondence from \(B^T\) to \(B\) is precisely CGY Lemma 4.13. Its passage from \(B\) to \(-B\) uses their opposite seed in §4.2; passing back to principal coefficients is justified by their Proposition 3.7, which preserves equality of cluster variables when the coefficients change. Thus the partial cluster \(U^-\) in the \(-B\) pattern is unambiguous.

The completed cluster produced by the local normalizer contains \(U^-\), and all C-columns outside \(U^-\) are nonnegative. These are exactly conditions (a) and (b) of CGY Definition 4.9(i). Theorem 4.15 says that there is only one such cluster. CGY Theorem 3.6 says a cluster determines its seed up to the same index permutation; Proposition 3.11 gives that permutation on the C-columns. Therefore the retained nonnegative matrix \(S_\rho\) is path-independent up to lower-index permutation.

The weight recovery formula is exact. For a retained column \(S_j=C_j\), primitivity of the integral column \((DCD^{-1})_j\) gives

\[
\gcd_i(d_iS_{ij})
=d_j\gcd_i\bigl((DCD^{-1})_{ij}\bigr)
=d_j.
\]

So the corresponding diagonal weight is determined by the column itself, including when two descriptions use different endpoint index labels. Moreover the lower exchange matrix can be recovered directly from these retained data:

\[
Q_\rho=D_\rho^{-1}S_\rho^TDBS_\rho.
\tag{7.1}
\]

This is the retained block of \(DQ=C^TDBC\). It confirms that no unspecified full-completion label remains in the lower matrix.

For the lattice assertion, write any \(q\in\mathbb Z^n\) uniquely as \(q=Cb\), where \(b=G^Tq\in\mathbb Z^n\). Then \(G_U^Tq=0\) is precisely \(b_I=0\). Hence \(\ker_{\mathbb Z}(G_U^T)=C_J\mathbb Z^r\). This is a saturated lattice with the displayed nonnegative basis. It gives no claim about generating its entire nonnegative monoid, and the corollary correctly excludes such a claim.

On one fixed optimized path, the alternatives \(\beta_k=0\), \(\beta_k>0\), and \(\beta_k<0\) depend only on the common sign of row \(k\) of \(G\) restricted to \(I\), not on the positive magnitudes of the coefficients of \(-w\) in its cone. Inductively, every completion pivot and every prefactor update is fixed throughout the cone's relative interior. Thus the face polynomial is constant there.

Finally, in any nonnegative representation \(z^pF_h(z^S)\), every face support exponent is componentwise at least \(p\), and \(p\) occurs. The same is true of every point in the convex hull. Therefore \(p\) is the unique coordinatewise least point of the actual face, a characterization independent of the chosen path. The mutable prefactor is \(g+Bp\), and the already verified weighted label invariant gives

\[
h=D_\rho^{-1}S_\rho^TD(g+Bp).
\]

This proves the claimed path-independence of the lower label as well. No hidden dependence on a frozen exponent or on the numerical positive coordinates inside the cone remains.

