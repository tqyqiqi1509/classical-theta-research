# Independent audit of the generic-residue window and full marked layers

2026-11-14, fresh-context adversarial reconstruction. Classical cluster algebras, including the stated skew-symmetrizable normalization. The reviewed global theta/Q identification and the rank-generic collision-window theorem are inputs. No conclusion of Li–Pan and no numerical experiment is used.

## 1. Result of the reconstruction

The finite-initial-ideal argument, the connected-annulus comparison, and the equality of nested deep factors have complete proofs under the hypotheses already written in `../finite_mechanism_fresh_7h/GENERIC_RESIDUE_DETECTOR_WINDOW.md`. In particular, they do not need genericity of the all-ones endpoint, independent unit parameters on individual clones, or a smoothness assertion for the preimage of the color torus.

The final paragraph of the earlier full-layer §6 needed a more explicit argument: a proper closed subset of a finite cover can map onto the entire base. The CRT freedom must be established on every relevant irreducible incidence component. Section 5 below proves this by an actual coordinate change and a determinant norm. This refinement was communicated to the support-accessibility branch for insertion in the main proof.

The origin-completion lemma also closes, with a genuine formal-dimension proof. The separate note `ORIGIN_TUBE_ALGEBRA_LEMMA.md` supplies the complete reconstruction, including the finite field tensor product that preserves the nonzero boundary function. It confirms the all-ones symbolic-unit coefficient formula with origin localization.

## 2. Generic residues in the actual color torus

Let \(X\subset T_E\times T_\mathrm{tar}\) be the closed graph of the primitive Gale map. Actual arrow differences are the source torus coordinates. For a connected framed graph they generate the configuration coordinate ring: each coordinate is a sum of arrow differences along a path from the frame. Thus positivity of all actual arrow weights implies positivity of all configuration coordinates. A coordinate may be zero where no actual arrow excludes this, and that does not impair the very-affine embedding by arrow coordinates.

Let \(H\subset T_\mathrm{tar}\) be the original-color target torus and \(U=\operatorname{Trop}(H)\). A fixed sign translation can be absorbed in the torus coordinates. Use the signed notation \((v,\mu)\), so the ordinary target valuation is \(-\mu\). This fixed linear sign change must also be applied to the initial-star and projection assertions.

Work first over an algebraic closure of the trivially valued coefficient field. There are finitely many initial ideals of the Laurent ideal of \(X\). For each corresponding initial scheme \(W\), intersect with the actual target torus:

\[
W_H=W\cap(T_E\times H).
\]

There are finitely many geometric irreducible components \(Z\) in this finite list. For each component whose projection to \(H\) is not dominant, remove the closure of its image. This produces a nonempty open subset \(H^\circ\), because every removed closed set is proper and \(H\) is irreducible. Take a nonempty principal open \(D(F)\subset H^\circ\).

This construction works simultaneously for every weight, not merely for the weights of a selected sequence of points. Over a non-algebraically closed coefficient field, the union of the removed geometric images is Galois-stable and descends; alternatively take products of the finitely many conjugate defining equations. For the rational Gale data one may therefore choose \(F\) with rational coefficients. This justifies later use of the generic point of \(\mathbb Q(\lambda_i)\).

Consider a positive point of \(X\), of weight \((v,\mu)\), whose normalized target residue belongs to \(D(F)\). Its initial point lies in \(W_H\). It cannot lie on a component with nondominant image, by the definition of \(D(F)\). Choose a component \(Z\) through it. The projection \(Z\to H\) is dominant.

Tropical elimination for a torus homomorphism gives

\[
\operatorname{pr}_H\operatorname{Trop}(Z)=U.
\tag{2.1}
\]

For every rational endpoint direction \(\nu\in U\), there is therefore a rational source direction \(w\) with \((w,\nu)\in\operatorname{Trop}(Z)\), in the signed convention. Rationality is harmless: the tropical set is a finite rational polyhedral complex, and a nonempty fiber over a rational vector has a rational point. Since \(Z\subset W\), the initial-star identity yields

\[
(v+\epsilon w,\mu+\epsilon\nu)\in\operatorname{Trop}(X)
\tag{2.2}
\]

for sufficiently small positive rational \(\epsilon\).

Choose \(\nu\) outside the finitely many forbidden rank and cut hyperplanes. Tropical lifting realizes these nearby weights over valued extensions. Because the original vector \(v\) has strictly positive entries and is finite, the nearby source arrow weights remain positive. Configuration-coordinate positivity follows from the framed paths described above.

The nearby targets have original-color **valuations**. Their normalized residues can be arbitrary, and generally do not equal the original residue. This is sufficient because the rank-generic collision window is uniform over independent target residues, including residues not equal on clones. There is no false claim of lifting with prescribed central residue.

Consequently, if every nearby rank- and cut-generic positive point satisfies

\[
\varepsilon\le v_e\le M,
\]

then (2.2) and passage to the limit prove the same inequalities at the central point. This establishes the central generic-residue window. Initial schemes are used only for point bounds, so their possible nonreduced structure is irrelevant here; multiplicities are retained by the later complete-intersection construction.

The standard tropical inputs are exactly the ones already checked by the parent: Sturmfels–Tevelev, *Elimination theory for tropical varieties*, Proposition 2.8, and Osserman–Payne, *Lifting tropical intersections*, §§2.1–2.2 with its corrected lifting theorem. The argument does not invoke a generic translate in the full target torus and then restrict that genericity without proof to \(H\).

## 3. The connecting annulus and the complete-intersection argument

At a shifted detector endpoint \(\mu_t=(tm,a-tu)\), take a generic integral direction \(\nu\). Shrink \(\eta>0\) so that every \(\mu_t+s\nu\), for \(0<s\le\eta\), is rank- and cut-generic, remains in the uniform-window neighborhood, and gives the same detector coefficient. The last condition uses the separate termwise orthogonal-wall calculation; it is not a consequence of tropicalization alone.

Choose \(\nu\) so that its scalar products with distinct exponents of \(F\) are distinct. For a unit target \(\lambda\in D(F)\), normalize

\[
f(S)=S^{-b}F(\lambda S^{-\nu}),
\qquad
b=\min_{\alpha\in\operatorname{supp}(F)}(-\langle\nu,\alpha\rangle).
\]

Then \(f\) is a polynomial in \(S\) with unit constant coefficient, and its other nonzero coefficients are units. On the closed annulus

\[
|\delta|^\eta\le|S|\le1,
\]

the condition \(|f(S)|=1\) is automatic when \(v(S)>0\). At \(v(S)=0\), it is precisely the good-residue condition. It retains both \(S=1\) and \(S=\delta^\eta\).

There is a useful direct connectedness check. After clearing rational exponents, a formal model of this affinoid is

\[
\mathcal O\langle S,R,U\rangle/
(SR-\delta^\eta,\,Uf(S)-1).
\]

Its special fiber is

\[
k[S,R,1/\overline f(S)]/(SR).
\]

This is the union of the two coordinate axes with finitely many points removed from the \(S\)-axis. The node remains because \(\overline f(0)\ne0\). The special fiber is reduced and connected. A generic-fiber idempotent belongs to the formal model: if \(\delta^n e\) is integral for a least \(n>0\), its reduction has square zero, and reducedness contradicts minimality. An integral idempotent reduces to zero or one on the connected special fiber and is then itself zero or one by completeness. Thus the affinoid is connected. Equivalently, it is the closed annulus with finitely many outer residue discs deleted, retaining the entire annulus skeleton. Its regularity follows because it is an analytic domain in the smooth annulus.

For every base point of this annulus, including arbitrary complete valued extensions, the positive source factor has the same strict generator bounds. At inner radii use the generic-endpoint window; on the outer boundary use Section 2. The strict relative-interior criterion therefore gives a **finite** analytic morphism. Compactness without this boundary criterion would not suffice.

Here is the exact local flatness argument, expanding the sentence that finiteness forces the expected codimension. Let the regular base have dimension \(d\), and let the regular ambient monic-coefficient space have relative dimension \(N\). Its local ring at a maximal point has dimension \(d+N\). The selected source is defined there by precisely \(N\) remainder equations. The height theorem gives source dimension at least \(d\). Finiteness over the base gives source dimension at most \(d\). Thus the ideal has height exactly \(N\).

An ideal of height \(N\) generated by \(N\) elements in this regular local ring is a complete-intersection ideal, and these generators form a regular sequence. The quotient is Cohen–Macaulay. Its dimension equals the dimension of the base local ring, and the closed fiber has dimension zero. Miracle flatness, Stacks Project [tag 00R4](https://stacks.math.columbia.edu/tag/00R4), proves flatness. This proof does not require the source over the color torus to be smooth, and it retains nilpotents.

Actual-arrow resultants and necessary frame factors are inverted in the ambient chart. These are open localizations of a regular space. Same-color discriminants are not inverted. The variables added to present inverses can either be eliminated or counted together with their graph equations; they do not change the relative dimension \(N\).

The same proof works over the full color-unit affinoid \(|\lambda_i|=1\), \(|F(\lambda)|=1\), and with the allowed correction-unit homotopy parameters. That base is regular and connected, with smooth integral reduction \(k[H,1/F]\). A single annulus comparison computes the rank on this connected base. Hence the resulting finite flat family can be pulled back over a nonreduced outer Artin algebra.

## 4. Why equal nested ranks give the whole core as a family

Let \(C_t\) be the analytic subdomain at the original zero-old endpoint on which every coordinate has valuation greater than \(t\). Exact scaling identifies it with the positive shifted factor at \(\mu_t\). The preceding proof gives finite flat rank \(d\) for every sufficiently small rational \(t>0\), over the same fixed good color-unit base.

For \(0<t<t_0\), there is an actual inclusion of analytic domains

\[
C_{t_0}\subset C_t.
\]

Over an algebraically closed complete valued field and a fixed target, a finite Artin algebra is the product of its complete local Artin algebras. A strict valuation condition on its points selects a subset of those factors. It cannot remove only a nilpotent subspace of a local factor: analytic-domain restriction has the inherited structure, and the finite local spectrum has a single point.

Both selected finite algebras have length \(d\). Thus the subset selected by \(C_{t_0}\) contains every local factor of \(C_t\), with its full length. This works for every geometric target fiber, including rank zero.

Every analytic point of \(C_t\) is seen after base change to its completed residue field and then to a completed algebraic closure. Therefore \(C_{t_0}\) contains every analytic point of \(C_t\). An analytic domain with the same underlying set as the ambient analytic space is the whole domain with the inherited sheaf. Hence the equality is one of families, not only of reduced point sets or of individual degrees.

Finally, every point with all coordinates of positive valuation belongs to some \(C_t\) with sufficiently small rational \(t>0\). The finitely many coordinates allow a single such \(t\). Therefore the entire positive core equals the fixed finite flat family \(C_{t_0}\). There is no infinite intersection of good-residue conditions, because \(F\) was fixed from the finite list of all initial ideals before \(t\) was chosen.

## 5. CRT freedom on every incidence component, and the norm repair

This is the only place where the earlier prose required a substantive logical expansion. A proper closed subset of a finite cover need not have proper image: one component of \(X\sqcup X\to X\) is already a counterexample. What is needed is properness on every dominant component.

Fix one layer \(q\), write \(m=u+v\), and work where every \(V_i(0)\) is invertible. Put \(a=\eta T^N\ne0\), so the old target is

\[
f_i(z)=t_i-a\phi_i(z),\qquad \deg\phi_i<m_i.
\]

Monic division gives an algebraic coordinate change

\[
\phi_i(z)=A_i(z)+V_i(z)B_i(z),
\qquad \deg A_i<v_i,\quad \deg B_i<u_i.
\tag{5.1}
\]

When \(u_i=0\), the polynomial \(B_i\) is absent. When \(v_i=0\), take \(V_i=1\), \(A_i=0\), and \(B_i=\phi_i\). These conventions include all boundary cases.

The outer remainder equations depend on \(\phi_i\) only through \(A_i\). This statement is valid scheme-theoretically because remainders are taken modulo the full monic polynomial \(V_i\), retaining all confluent conditions at repeated roots. Thus the \(B_i\) coefficients are free coordinates of the universal incidence scheme over its \((V,A)\)-part.

For a color with \(u_i>0\), replace the constant coefficient of \(B_i\) by

\[
c_i=\phi_i(0)=A_i(0)+V_i(0)B_i(0).
\tag{5.2}
\]

This is an invertible algebraic coordinate change on \(V_i(0)\ne0\). The old core target is

\[
y_i=\kappa_i\bigl(t_i-a c_i\bigr)
\prod_j V_j(0)^{-B_{ij}},
\tag{5.3}
\]

where \(\kappa_i\) is the fixed sign. The nonzero scalar \(a\), the determinant factors, and \(V_i(0)\) are units. Hence, after removing \(y_i=0\), replacing \(c_i\) by \(y_i\) is again invertible. Independently, the leaf core target is

\[
\ell_i=(-1)^{v_i}\lambda_i V_i(0),
\tag{5.4}
\]

so each leaf target coordinate is also a free torus coordinate.

Consequently, on this chart the universal incidence scheme has the form

\[
Y\times\mathbb A^{e}\times H_\mathrm{core},
\tag{5.5}
\]

with \(H_\mathrm{core}\) the **entire** required old-and-leaf target torus. The factor \(Y\) records the outer coefficient and outer remainder data. Each geometric irreducible component of (5.5) has the entire torus as a factor. A nonzero Laurent polynomial \(F_q\) defining the bad core locus therefore does not vanish identically on any component.

One can make the outer incidence description still more explicit. On the actual-arrow-open chart, the denominator of the outer primitive row is a unit in \(\mathcal O[z]/(V_i)\). The outer remainder equation uniquely determines \(f_i\bmod V_i\), and hence \(A_i\), as a regular function of \(V\). Thus the outer incidence is a graph over the open monic coefficient configuration space, with exactly the free quotient parameters in (5.1). No distinct-root hypothesis is used.

The bounded perturbation condition does not destroy this freedom. The inverse CRT transformation may have a large \(T\)-adic norm, but sufficiently small independent changes of \(c_i\) and \(\lambda_i\) stay within the allowed coefficient polydisc and keep the outer equations exactly fixed. Each such parameter ball is Zariski dense in the corresponding affine or torus coordinate. Around a smooth point of any selected analytic component, these changes stay in the same component. Therefore the bad polynomial is nonzero on every component of the finite outer incidence that dominates the perturbation base.

Now let \(A\) be the finite locally free outer algebra over an integral parameter ring \(R\), after the permitted shrinkage, and let

\[
b=F_q(y,\ell)\in A.
\]

Over the function field of \(R\), each local Artin component has a minimal prime coming from a dominant incidence component. The preceding coordinate proof says that the residue of \(b\) is nonzero in every such component. Hence \(b\) is a unit in every local Artin component, and therefore in the generic algebra.

Consider multiplication by \(b\) on the finite locally free \(R\)-module \(A\). Its determinant

\[
\Delta_q=\det(m_b)
\tag{5.6}
\]

is nonzero because multiplication is invertible over the function field. After inverting \(\Delta_q\), the adjugate matrix makes multiplication by \(b\) invertible over the entire base. In particular, \(b\) is a unit on the entire possibly nonreduced outer algebra. This is exactly the required simultaneous avoidance of the bad core locus at every outer point, including its nilpotents.

If one first works algebraically with the universal incidence before choosing its positive analytic factor, the same argument applies component by component. Nondominant components have proper parameter images. Every dominant component is generically finite, and its bad locus has strictly smaller dimension by (5.5). Shrinking the algebraic parameter base makes the finite generic algebra spread to a finite algebra and clears the denominators in (5.6). Thus the conditions can be expressed by nonzero algebraic parameter functions; the analytic bounded polydisc meets their complement. This supplies the algebraic genericity claimed in the full-layer construction.

There are finitely many \(q\)-layers, so one takes the product of the finitely many nonzero \(\Delta_q\) and the previously imposed outer-origin avoidance conditions. A generic parameter choice satisfies all of them. Returning the parameters to their original values uses the already proved finite flat marked family and saturated lattices; no assertion of constancy at exceptional core unit targets is introduced.

## 6. All-ones symbolic units and the exact scope

The rational initial-data argument of Section 2 shows why independent symbols \(\lambda_i\) over \(\mathbb Q\) meet the good residue open. Any nonzero Laurent polynomial in these symbols stays nonzero, and is a valuation unit, after an arbitrary complete valued extension on which the coefficient field remains trivially valued. This is stronger and more precise than an unspecified generic numerical choice.

For the ordinary coefficient graph, every nonempty frame-free cut has strictly positive raw weight at primitive endpoint \(\mathbf1\). The minimum-edge cut argument supplies a uniform lower bound in a neighborhood. Rank-generic hierarchy certificates supply a uniform upper bound at nearby generic endpoints. Section 2 transfers those bounds to \(\mathbf1\) with symbolic color residues; Section 3 compares its finite degree with the nearby generic degree in the same positive chamber.

The resulting row polynomial is therefore

\[
H_i(z)=T A_i(z)-\lambda_iE_i(z),
\]

with the original actual-arrow saturation. The separate origin-tube lemma identifies the local \(T=0\) quotient with the positive coefficient length and retains all Artin multiplicities. For the zero-old-endpoint core the same argument uses old exponent zero and leaf exponent one.

These formulas do not justify setting every \(\lambda_i\) to one, replacing the local origin factor by an arbitrary global special fiber, or claiming a stopping theorem for the entire Laurent support of every theta label. They do give a finite algebraic computation of each requested ordinary coefficient and each divided-derivative branching coefficient, using the stated reviewed theta/Q theorem as the identification input.

