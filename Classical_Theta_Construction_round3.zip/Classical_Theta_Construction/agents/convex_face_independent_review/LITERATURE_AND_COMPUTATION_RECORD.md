# Literature, route, and computation record

Fresh review begun 2026-11-13 22:30 UTC; completed 22:50 UTC. Classical data only. This is the record accompanying the general proofs in `ZERO_GROUP_FACE_REDUCTION.md`, not a substitute for them.

## 1. Routes examined and outcomes

| Route | Outcome | Consequence for the main problem |
|---|---|---|
| Dense-wall derivative and Hessian attack | PASS under the previously established uniform analytic coefficient bound | Arbitrary accumulation of walls does not invalidate the analytic body or its zero-group face formula. The derivative estimate must use a Lipschitz tail, and the curvature estimate must sum in total variation. |
| Infer all normal cones from binary compatibility alone | Presentation gap found and repaired | Added the exact all-face inclusion theorem (7.4) and normal-cone intersection formula (7.5) directly to `ANALYTIC_STABLE_LOG_BODY.md`. |
| Fei-style minimum/maximum reduction without module realization | PROVED generally | Every exposed face has explicit simultaneous coordinatewise minimum and maximum, computed by the negative factor and full zero factor. |
| Determine face dimension from the zero group | PROVED generally | The effective root span of `log Z_g` is exactly the affine direction space. This gives exact differentiability, edge, and facet criteria and works for noncommuting zero groups. |
| Repeat reduction for a whole face flag | PROVED generally | Successive signed factorizations compute nested exposed faces on the original analytic domain, with a common geometric approximation error. |
| Describe commuting zero groups as segment sums | PROVED generally in this stated case | Gives an absolutely convergent zonoid formula; finite ray support gives a zonotope. |
| Converse: zonotope geometry forces zero-group commutativity | NOT ESTABLISHED; not used | No assertion is made from one evaluated geometric coincidence to an identity of formal root derivations. |
| Identify this transport body with an individual theta Newton polytope or with the ray-growth body | NOT ESTABLISHED here | The face theorems concern the independently defined analytic transport body. The uniform two-body comparison remains valid without equality. |

## 2. Primary literature checked

### Fei, arXiv:1909.10151v3 (2021)

Primary file: https://arxiv.org/pdf/1909.10151v3 . Existing local full text: `../fei_newton_interface/sources/fei_1909.10151v3.txt`.

Read the statements and proofs of Theorem 3.4 and Theorem 6.8, together with Remark 6.12. The first proof uses closure of maximizing subobjects under intersection and sum. The face formula uses the interval between the extremal subobjects, the semistable quotient, and the induced change of monomials. Remark 6.12 explicitly allows higher-codimension faces, either by induction or by a single exposing weight.

**Assessment:** useful, correct at the reviewed steps with the paper's representation-theoretic hypotheses. The minimum/maximum and quotient-face architecture is established prior work, including arbitrary face codimension. It must not be presented as a new idea in itself. Our proof does not import those conclusions for arbitrary theta functions; it constructs an analytic counterpart from signed factorization. No general theta/module identification is assumed.

### Asai--Iyama, arXiv:2404.13232v3 (2026 revision)

Primary metadata: https://arxiv.org/abs/2404.13232 . Primary current PDF: https://arxiv.org/pdf/2404.13232v3 . The arXiv version history gives 6 March 2026 for v3. Both v1 and v3 are already available in `../stable_hall_interface/sources/`.

Checked the current main statement, Lemma 3.20, and the proof of Theorem 3.5; compared the exact earlier numbering in v1. The finite-object statement identifies the closures of `M`-TF classes with the Newton normal generalized fan. The proof passes through equality of exposed faces and then finite-polytope normal-cone duality.

**Version correction:** the novelty note's Theorem 3.15 is the correct **v1** number. The corresponding current **v3** theorem is **3.5**; the face-equivalence bridge is Lemma **3.20**. This is a version-sensitive citation, not evidence that the mathematical claim in the older note is false. Current wording uses a generalized fan, allowing lineality when the object is not sincere.

**2026 review status:** the cited finite-object proof segment and numbering have been inspected; no defect was found there. This is not a certification of the whole paper. It supplies historical context only: no 2026 result is an input to the new analytic face proofs.

### Reading, arXiv:1712.06968v3 (2018)

Primary file: https://arxiv.org/pdf/1712.06968v3 . Reopened Propositions 3.8--3.11 and the inverse-limit portion of their proofs.

**Assessment:** useful and correct at the reviewed steps. Finite-quotient equivalence detects full equivalence. The closure of a full class is the intersection of finite-class closures, by joining a relative-interior point to an arbitrary point in the intersection. Full classes need not equal relative interiors of their closures. This precisely supports the convention used after our new formula (7.5); it does not supply that formula for the analytic body.

### Bridgeland, arXiv:1603.00416

Primary file: https://arxiv.org/pdf/1603.00416 . Section 3 supplies the established total-group-element/signed-factorization background. The finite tangent-germ argument and its root-span consequence are proved explicitly in the new note; no new priority is claimed for signed factorization itself.

### Search scope and excluded transfer

The fresh search included combinations of scattering convex bodies, zero-group exposed faces, zonoids, stability reduction, and F-polynomial Newton faces. No primary source found in this pass states the exact convergent all-classical package above. This is a limited search outcome, not a proof of priority. Unrelated 2026 face-lattice results and nonprimary search commentary were not used. No Li--Pan conclusion enters any proof.

## 3. Exact computation

The test addresses one general mechanism across ranks, rather than supplying a list of special-case substitutes for a proof. `face_reduction_probe.py` compares two independent constructions:

1. Exposed faces and nested exposed faces are found by maximizing exact rational linear forms on all finite polytope vertices.
2. Negative and zero factors are reconstructed from full triangular operators; the matrix logarithm recovers the active root directions. The resulting corner vectors and root-span rank are compared against the first construction.

The evaluation parameter is chosen rationally using the first nonzero jump and a bound on the remaining finite coefficients. All chamber support inequalities are then checked exactly. All calculations use rational numbers, including chamber certificates and matrix ranks.

| Rank | Symmetrizer | Principal cutoff | Evaluation parameter | Arrangement chambers | Distinct vertices | Single faces | Nested flags |
|---:|---|---:|---|---:|---:|---:|---:|
| 2 | `(2,3)` | 4 | `1/21` | 14 | 8 | 9 | 18 |
| 3 | `(1,1,1)` | 3 | `3/23` | 110 | 24 | 27 | 27 |
| 3 | `(1,2,1)` | 3 | `3/35` | 110 | 20 | 27 | 27 |
| 4 | `(1,1,1,1)` | 2 | `1/5` | 150 | 42 | 81 | 36 |

The exact exchange matrices, face directions, corner coordinates, and active zero normals are recorded in `face_reduction_probe.json`.

**Python result:** PASS, 144 single-face checks and 108 nested-flag checks, 252 total. Each test verifies membership of both simultaneous coordinate corners, the entire coordinate box containment, and equality of the face dimension and active zero-root rank. Matrix-logarithm columns are also checked to be proportional to the corresponding root normal `Da`.

**Independent computation plugin:** a fresh Wolfram kernel received only the rational vertices and proposed face/corner/root data. It independently recomputed all successive maxima, coordinate minima/maxima, and both matrix ranks. Result: **PASS, 252/252**, with no failed indices. The four input groups passed 27, 54, 54, and 117 checks respectively. The exact code is `face_reduction_wolfram.wl`; the untouched tool result is `face_reduction_wolfram_result.json`.

These finite exact computations check the algebraic mechanism and implementation. The dense-wall passage, common analytic domain, and infinite face statements are justified by the written proofs, not by extrapolating finite experiments.

## 4. Files and dependency boundary

- `INDEPENDENT_REVIEW.md`: fresh adversarial audit and the repaired normal-cone bridge.
- `ZERO_GROUP_FACE_REDUCTION.md`: all new general face theorems and proofs.
- `face_reduction_probe.py` and `.json`: reproducible exact finite verification.
- `face_reduction_wolfram_input.json`, `.wl`, and `_result.json`: independent plugin recheck.

No additional copy of the existing literature PDFs was created. Parent-stage persistence and the final project package include this directory. The face proofs retain the previously accepted analytic majorant and finite stable-log theorem as explicit inputs.
