"""Exact checks of new zero-group face reduction, across ranks and valuations.

The geometry (maximizing finite vertices) is compared with independently
factored full triangular operators.  Matrix logarithms recover the active
zero-root span.  The tests concern the general reduction mechanism.
"""
from pathlib import Path
import sys, json, time
from fractions import Fraction as Q
from itertools import product
import sympy as sp

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'computation'))
import incoming_recursion
from stable_log_polytope import LogPolytope,chambers,dot,evaluate,logarithm


def negative_matrix(P,Ci,flag,zero_negative=False):
    neg={(a,a):Q(1) for a in P.J};pos=dict(neg)
    for p,q,beta,mids in P.intervals:
        value=Q(Ci[p,q])-sum(neg.get((p,r),0)*pos.get((r,q),0) for r in mids)
        if not value:continue
        signs=[dot(g,tuple(d*b for d,b in zip(P.D,beta))) for g in flag]
        sign=next((x for x in signs if x),0)
        target=neg if sign<0 or sign==0 and zero_negative else pos
        target[p,q]=value
    return neg


def zero_operator(P,N0,N1):
    Z={(a,a):Q(1) for a in P.J}
    for p,q,beta,mids in P.intervals:
        val=N1.get((p,q),0)-N0.get((p,q),0)-sum(N0.get((p,r),0)*Z.get((r,q),0) for r in mids)
        if val:Z[p,q]=val
    return Z


def operator_log_column(P,Z):
    out={};v={P.zero:Q(1)}
    for k in range(1,P.N+1):
        nxt={}
        for (p,q),c in Z.items():
            if p!=q and q in v:nxt[p]=nxt.get(p,Q(0))+c*v[q]
        v={p:c for p,c in nxt.items() if c}
        for p,c in v.items():out[p]=out.get(p,Q(0))+Q((-1)**(k+1),k)*c
    return {p:c for p,c in out.items() if c}


def flag_data(P,flag,t):
    maxima=[];minima=[];logs=[]
    for Ci in P.C:
        N0=negative_matrix(P,Ci,flag)
        N1=negative_matrix(P,Ci,flag,True)
        Z=zero_operator(P,N0,N1)
        logs.append(operator_log_column(P,Z))
        for mat,target in [(N0,maxima),(N1,minima)]:
            H={p:mat[p,P.zero] for p in P.J if mat.get((p,P.zero),0)}
            L=logarithm(H,P.J,P.N)
            target.append(sum(c*t**sum(p) for p,c in L.items()))
    active=[]
    for p in P.J[1:]:
        vals=[L.get(p,Q(0)) for L in logs]
        normal=tuple(d*a for d,a in zip(P.D,p))
        j=next(j for j in range(P.n) if normal[j])
        ratio=vals[j]/normal[j]
        assert vals==[ratio*a for a in normal],('operator-log not a root derivation',P.B,flag,p,vals,normal)
        if ratio:active.append(normal)
    rank=int(sp.Matrix(active).rank()) if active else 0
    return tuple(maxima),tuple(minima),rank,active


def prepare(P):
    C,stats=chambers(P.normals,P.n)
    U={s:P.specialize(P.gradient_series(g)) for s,g in C.items()}
    t=Q(1,2)
    for s in C:
        for j,a in enumerate(P.normals):
            if s[j]>0:continue
            plus=s[:j]+(1,)+s[j+1:]
            if plus not in C:continue
            i=next(i for i,x in enumerate(a) if x)
            q=[Q(x-y,a[i]) for x,y in zip(U[s][i],U[plus][i])]
            nz=[k for k,x in enumerate(q) if x]
            if not nz:continue
            first=nz[0];assert q[first]<0
            tail=sum(abs(v) for v in q[first+1:])
            if tail:t=min(t,(-q[first])/(2*tail))
    slopes={s:tuple(evaluate(poly,t) for poly in vec) for s,vec in U.items()}
    vertices=sorted(set(slopes.values()))
    # Exact independent support check for this chosen evaluation.
    for s,g in C.items():assert dot(g,slopes[s])==max(dot(g,v) for v in vertices)
    return vertices,t,stats,len(C)


def face(vertices,g):
    maximum=max(dot(g,v) for v in vertices)
    return [v for v in vertices if dot(g,v)==maximum]


def verify(P,vertices,flag,t):
    F=vertices
    for g in flag:F=face(F,g)
    vmax,vmin,rank,active=flag_data(P,flag,t)
    assert vmax in F and vmin in F,('missing corner',P.B,flag,vmax,vmin,F)
    assert all(all(a<=x<=b for a,x,b in zip(vmin,v,vmax)) for v in F)
    differences=[tuple(x-y for x,y in zip(v,vmax)) for v in F]
    observed=int(sp.Matrix(differences).rank())
    assert observed==rank,('dimension mismatch',P.B,flag,observed,rank,active,F)
    return dict(flag=[list(g) for g in flag],face_vertices=len(F),dimension=rank,
                maximum=[str(x) for x in vmax],minimum=[str(x) for x in vmin],
                active_zero_normals=[list(a) for a in active])


def run():
    start=time.time();records=[];wolfram=[];face_count=flag_count=0
    inputs=[([[0,3],[-2,0]],[2,3],4),
            ([[0,1,-2],[-1,0,1],[2,-1,0]],[1,1,1],3),
            ([[0,2,-1],[-1,0,1],[1,-2,0]],[1,2,1],3),
            ([[0,1,-1,0],[-1,0,2,-1],[1,-2,0,1],[0,1,-1,0]],[1]*4,2)]
    for B,D,N in inputs:
        P=LogPolytope(B,D,N);vertices,t,stats,chamber_count=prepare(P)
        gs=list(product([-1,0,1],repeat=P.n));checks=[]
        for g in gs:
            checks.append(verify(P,vertices,[g],t));face_count+=1
        # Nested exposed faces challenge the genuinely noncommuting zero-group step.
        hs=[tuple(int(i==j) for i in range(P.n)) for j in range(P.n)]
        for g in gs[::max(1,len(gs)//9)]:
            for h in hs:
                checks.append(verify(P,vertices,[g,h],t));flag_count+=1
        records.append(dict(B=B,D=D,degree=N,t=str(t),chambers=chamber_count,
                            vertices=len(vertices),exact_lp_certificates=stats,checks=checks))
        # A separate Wolfram kernel will recompute maximizing faces and coordinate corners.
        wolfram.append(dict(vertices=[[str(x) for x in v] for v in vertices],checks=checks))
        print(json.dumps(dict(rank=P.n,N=N,face_checks=face_count,flag_checks=flag_count,
                              seconds=time.time()-start)),flush=True)
    out=dict(status='PASS',single_face_checks=face_count,nested_flag_checks=flag_count,
             inputs=len(inputs),records=records,seconds=time.time()-start,
             scope='Finite truncations validate the general algebraic mechanism; analytic proof remains the theorem.')
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    Path(__file__).with_name('face_reduction_wolfram_input.json').write_text(json.dumps(wolfram)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='records'}),flush=True)


if __name__=='__main__':run()
