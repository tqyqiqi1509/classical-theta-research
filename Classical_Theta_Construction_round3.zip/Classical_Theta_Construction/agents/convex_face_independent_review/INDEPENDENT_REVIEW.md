# Fresh independent review: analytic theta body and exposed faces

2026-11-13, begun 22:30 UTC. Reviewer branch: convex_face_independent_review.

## Result

**PASS, conditional on the separately proved uniform analytic path bound and finite stable-log/polytope theorem.** The dense-wall limits, distributional Hessian, differentiability, and zero-group exposed-face formula withstand the checks below. A logical bridge from pairwise compatibility to exact normal cones was missing from the presentation; I supplied and inserted it in the main analytic-body note as (7.4)--(7.5). The conclusion survives, with a more precise proof.

This review does not purport to reprove the earlier global Gale/theta identification or its analytic coefficient majorant. Those are explicit inputs with their own independent reviews.

## Checks made

### 1. Infinite-wall convexity

For fixed root order N, the stable logarithm is continuous and PL on a finite central arrangement. Its individual evaluated truncation need not be convex. At every generic facet, the entire analytic jump has the positive sign because the positive wall germ is evaluated at an actual positive transported point. The difference from its truncation is bounded by twice the common Cauchy slope tail. The number of crossings on a straight segment is at most binom(N+r,r)-1, so the total possible negative second-derivative mass tends to zero. Uniform convergence plus distributional testing gives convexity. No local finiteness of the infinite diagram has been assumed.

### 2. Minkowski summands

For any fixed finite polytope P_M, only finitely many effective facets need a positive lower bound. The first positive wall term remains in the full germ everywhere on a refined generic part of that old facet. The positive transport bound supplies a common lower bound on that term. Taking the finite minimum makes L-c_M h_(P_M) convex by the same negative-mass estimate. The constant may depend on M and approach zero; this causes no error.

### 3. Full face inclusion and normal cones

For a general compact convex body, pairwise equality of support-function defects is not by itself a proof of every exposed-face normal-cone identification. Also one cannot assume the exposing direction lies in the relative interior of its normal cone. The inserted strengthening proves

    F_g(K) subseteq F_h(K) iff F_g(P_N) subseteq F_h(P_N) for all N,
    N_K(F_g(K))=intersection_N N_(P_N)(F_g(P_N)).

Forward: use each positive Minkowski summand and nonnegative support deficits. Reverse: in every finite normal cone, g-t h stays in the cone for sufficiently small t, so D_(-h)L_N(g)=-L_N(h). The globally Lipschitz Cauchy tail controls directional derivatives directly, giving D_(-h)L(g)=-L(h), hence all of F_g maximizes h. This proof explicitly allows the finite allowable t to shrink with N.

Reading 1712.06968v3, Proposition 3.8 and Proposition 3.10, support the stated inverse-limit closed-class convention. The relevant primary text was reopened and read. The proof does not identify infinite classes with relative interiors.

### 4. Total variation and no hidden curvature

For the total-principal-degree k layer, every gradient has Euclidean norm at most sqrt(r) K R^(-k). On a given root hyperplane its arrangement facets have disjoint relative interiors, so their total area in B_T is at most omega_(r-1)T^(r-1), not that area times the number of chambers. This proves the claimed bound

    |D^2 ell_k|(B_T)<=2 sqrt(r) K omega_(r-1)T^(r-1) M_k R^(-k).

The series is absolutely convergent in matrix-measure total variation. It therefore cannot create a Cantor contribution or a measure outside the countable union of the actual hyperplanes. The normalization of the jump density is correct:

    (nu tensor nu)/||nu||_2 * log f(T_g z).

Codimension-two joints have zero measure for each summand; countable summation preserves this. The r=1 convention H^0 at the origin is consistent. The quoted generating-function identity for M_k and its tail estimate are algebraically correct.

### 5. Differentiability outside all root hyperplanes

Every finite prefix is linear near a root-generic g. The entire tail has a globally small Lipschitz constant, not only a small value. Subtracting the limiting linear slope gives a first-order remainder bounded by twice that tail constant. Taking the displacement limit before taking N to infinity proves Frechet differentiability. Dense accumulation of walls does not invalidate the argument.

### 6. The high-codimension zero-group face formula

In every finite root quotient, first write C=A_g^- Z_g A_g^+, then factor Z_g by h. For small t>0 all nonzero g-root signs persist, so the exact negative factor at g+t h is A_g^- B_(g,h)^-. This uses factorization uniqueness; the zero group is not assumed commutative. The common analytic slope bound upgrades finite-order stabilization to an actual limit of U(g+t h).

For generic h, the line lies outside all root hyperplanes except at countably many t. L is Lipschitz and its derivative there is the stated gradient. Integrating the bounded limiting slope proves the directional derivative. This correctly avoids dividing a degree-tail error by t. For nongeneric h, scalar finite zero-group gluing and its uniform tail give the required continuity. Thus

    h_(F_g-U_g)(h)=h dot A_g^-[log(x^(-1) B_(g,h)^- x)](z)

is valid, including arbitrary joints. Every zero root annihilates x^g, giving the correct affine hyperplane. The single-ray case gives the stated segment with the correct minus sign and primitive-normal length.

### 7. Uniform two-body comparison

The root note UNIFORM_BODY_FLAT_COMPARISON.md was also checked at its generality boundary. Orthant subdivision makes the conic coefficient norm identity exact; maximal-minor ray bounds are valid for r=1 as well. The use of subadditivity plus two slope-tail errors is correct, and the floor choice meets the integer-label restriction. It is a near-zero uniform comparison of two bodies, not a proof of their equality at a fixed positive point. No infinite-N convergence to the scaling body beyond the possible flat floor is claimed.

## New mechanism developed after the review

`ZERO_GROUP_FACE_REDUCTION.md` proves coordinatewise extreme points, an exact dimension formula, recursive face reduction, and an explicit commuting-case segment sum. These are direct consequences of the accepted zero-group mechanism, with proofs independent of representation-theoretic identifications. The ordinary convex-geometry tools and the Fei-style historical analogy are credited; no Li--Pan statement is used.
