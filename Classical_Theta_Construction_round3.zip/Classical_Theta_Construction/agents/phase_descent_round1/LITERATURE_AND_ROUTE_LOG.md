# Primitive phases and Young cycles: research log

## 2026-11-13 20:07–20:21 UTC — a genuine phase-descent mechanism

Read the independently reconstructed cyclic flagged-tree theorem and the old
primitive-flow, valued-assembly, and failed local-phase routes. The key change
is to work on the common signed universe of **original spanning trees with
laminar flags**, rather than trying to shift the local interval colors of one
binary flow tree. Vertex phases permute parallel arrows and preserve every
reference condition. Their action is free because a spanning tree propagates
the phase from the degree-one frame.

An arbitrary non-equivariant positive cancellation can then be replaced by an
equivariant cancellation using Hall matching on its **actual orbit-incidence
graph**. No complete graph or target-cardinality matching is introduced. The
proof, explicit orbit gauge, fixed reference, and coherent transport are in
`PRIMITIVE_PHASE_ORBIT_THEOREM.md`. Eleven exact cases were run, including
valued matrices, nontrivial common symmetrizer divisors, repeated packets,
directed cycles, and total cancellation. The long Markov paths make the test
exercise nonlocal cancellation, rather than only free local color shifts.

Wolfram Language was also used independently to check the elementary
divisibility implication and gcd/lcm identity entering the primitive phase
arithmetic. This is a computational check, not a proof substitute.

**Status:** positive primitive packet catalog constructed. The permutation-cycle
sum remains separate and unresolved. The result does not revive the false
claim that a fixed binary tree has a termwise geometric phase sector.

## 20:21–20:29 — Young-cycle interface and early literature check

Read the Dyck branch's `TIGHT_TORIC_YOUNG_MODULE.md`. The stable-tree permutation
representation is not the right one. The correct character is the natural
toric cohomology character, with each quotient tree weighted by a finite
edge-to-vertex phase kernel. This is compatible with the present framed phase
gauge but is not yet a Young action on the raw axis-flow fixed set.

Candidate mechanism under investigation: replace stable-tree sets by actual
toric cohomology modules before residual substitution, then seek an equivariant
bar/flag cancellation. A generic reference covector distinguishing clone
vertices is the current obstruction; making it Young-invariant can force
zero cut sums. A free-group Hall argument alone does not solve a nonfree
Young action, and the ordinary tree representation has already been disproved.

Primary literature located, not yet imported as theorem input:

* Reineke–Stoppa–Weist, *MPS degeneration formula for quiver moduli and refined
  GW/Kronecker correspondence*, arXiv:1110.4847,
  <https://arxiv.org/abs/1110.4847>. Motivic abelianization and weighted thin
  moduli are directly relevant. Full proof still to be inspected.
* Hans Franzen, *Chow Rings of Fine Quiver Moduli are Tautologically Presented*,
  arXiv:1307.3066, <https://arxiv.org/abs/1307.3066>. The discriminant/
  antisymmetrization presentation may give a graph-defined linear-algebraic
  model for Young-sign multiplicities. Its acyclic/projective hypotheses must
  be respected; no arbitrary cyclic theta identification is assumed.
* Belmans–Franzen, *On Chow rings of quiver moduli*, arXiv:2307.01711,
  <https://arxiv.org/abs/2307.01711>. Primary author discussion:
  <https://pbelmans.ncag.info/blog/2023/07/06/new-paper-chow-rings-quiver-moduli/>.
* Official QuiverTools implementation,
  <https://sage.quiver.tools/_modules/quiver/moduli.html>, confirms the
  tautological relation/antisymmetrization algorithm and its stated hypotheses.
  Software documentation is useful for an implementation interface, not an
  independent proof of the desired theta theorem.
* Stapledon, *Equivariant Ehrhart theory, commutative algebra and invariant
  triangulations of polytopes*, arXiv:2311.17273; and *Techniques in Equivariant
  Ehrhart Theory*, Ann. Comb. 28 (2024), 819–870. Potential route: an equivariant
  finite cographic Box complex, not an invariant choice of a generic tree
  triangulation. Full relevant sections still to be read.

The searches `equivariant involution principle matching`, `sign-reversing
involution Hall group`, and `orbit matching involution principle` found standard
involution-principle and equivariant-division literature, but no exact prior
application to primitive packet phases in flagged flow trees. This limited
search is not a historical-priority certification. The abstract Hall and
alternating-path ingredients are standard; any novelty claim is confined to
the new application and its simultaneous cyclic transport.

No 2026 source has been used as a theorem input in this branch. The September
2026 toric-permutation preprint mentioned by the Dyck branch is relevant prior
work and requires the separate audit being performed there.

## 20:29–20:45 — a single cyclic Gale system, and a false shortcut caught

The new direct system is Γ_i=c_i T^(−θ_i), where Γ_i is the product of
incoming coordinate differences divided by outgoing differences, with the
frame coordinate zero. All actual arrow differences must have positive
valuation. This is defined from the original graph, without a wall history.

Collision hierarchies give −θ=sum t_S v_S, exactly the flow projections.
Binary initial charts are monomial isogenies with determinant equal to the
product of the cut pairings. This proves a finite reduced factor and the raw
flow count at a strongly generic parameter; the proof is in
`GALE_POSITIVE_FACTOR_GENERIC.md`.

The old spherical-image failure was explicitly distinguished from this
system. For r arrows on a directed triangle and one arrow per vertex into
the frame, exact saturated Gale degrees are 4,7,10 for r=1,2,3, matching raw
flow counts, whereas the old spherical quantities were 4,10,16. Saturation
and the positive-valuation condition are essential parts of the check.

A tempting uniform all-target flatness claim is **false**. In the r=1
example, targets (2,3,5) give length4, while (1,1,1) give the unit ideal and
length0. All branches can meet an internal collision boundary. This was
communicated immediately to the parent and both neighboring branches, and
is now retained as a regression case. Nonzero target constants alone do
not prevent boundary loss at a nongeneric invariant θ.

## 20:45–21:01 — fixed-target finiteness proved; symmetry interface narrowed

The cut argument proves a different, valid general theorem: for every
cut-generic θ and every fixed target field, the T-adic completion of the
TΛ-saturated Gale system is finite free. A special-fiber zero-arrow component
would have θ(C)=0 unless it is the whole graph, so the special fiber is
supported at the origin. Flat completion preserves T- and Λ-regularity.
After T is inverted the algebra is finite Artin over a field, so Λ is a
unit. The completion is an actual idempotent factor, retaining all local
Artin multiplicities. Full proof: `GALE_FIXED_TARGET_FINITE_FACTOR.md`.

The boundary branch independently checked the cut proof. The invalid
extension “Λ regular implies Λ unit over a multi-parameter base” was
explicitly rejected: that implication only holds over the finite Artin
field fiber, and the target-specialization counterexample shows why.

A cyclic repeated-label test checks more than total degree: for a unit
triangle, content (2,1,1), framing g=(-1,-2,0), and targets (2,2,3,5), the
positive factor has length10. Restricting one original equation per swap
cycle gives fixed-scheme length6, equal to the independent primitive packet
count; the resulting sign multiplicity is2. It is a mechanism check only.
An earlier message prematurely stated the anticipated values4 and3 before
the saved fixed-cycle computation finished. Those numbers were immediately
corrected to the actual exact outputs6 and2; no theorem or fit used them.

Current general route: choose θ generic on the original color space. Forced
multifurcations should then have child charges in a two-dimensional plane,
where their slope quiver is acyclic. This would permit the already proved
local many-slope Gale finite-factor argument while leaving the original
quiver arbitrary and cyclic. The precise projection-image induction and
possible Eulerian excess are being checked by the Dyck and boundary agents;
no global Young conclusion is asserted yet.

Primary interfaces located in this refresh:

* Sturmfels–Tevelev, *Elimination theory for tropical varieties*,
  <https://arxiv.org/abs/0704.3471>.
* Feichtner–Sturmfels, *Matroid polytopes, nested sets and Bergman fans*,
  <https://arxiv.org/abs/math/0411260>.
* Dickenstein–Feichtner–Sturmfels, *Tropical discriminants*, primary author
  PDF <https://mate.dm.uba.ar/~alidick/papers/tdFINAL.pdf>. The Horn map is a
  close linear-forms-to-monomials interface; its discriminant setting is not
  automatically the present framed positive factor.
* Bihan–Sottile, *Gale duality for complete intersections*. Its master-function
  complete intersections and tropical descriptions are relevant, but no
  positivity or boundary theorem was imported from a search snippet.
* Varchenko, *Critical Set of the Master Function and Characteristic Variety
  of the Associated Gauss–Manin Differential Equations*, primary page
  <https://armj.math.stonybrook.edu/html-articles/Files-2015-2024/15-20/>.
  This is a possible critical-algebra interface. Its critical equations are
  not the same as the multiplicative Gale equations used here.

The primary 2026 Tang Lemma6.1 has now been independently re-read by the Dyck
branch solely for its coordinatewise Young square-map deformation. The new
fixed-cycle lemma adds a separate finite-flat proof for every coordinate
restriction; full-family flatness alone would not preserve fixed-scheme
length. The global theta conclusion of that paper is not an input here.

## 21:01–21:09 — the missing color-generic valuation bound

The two-plane induction now keeps a nondegenerate plane P even when a child
charge is parallel to its parent. At a zero-pairing node all children are
forced parallel; its depth is absorbed with positive ratios into the child
depths while the incoming covector and ann(P) are retained. Applying the
same rule to a nonnegative recession vector shows that its positive support
can only lie in single-original-color clusters. Such clusters contain no
actual arrows. Hence actual arrow valuations are bounded above.

The proof works for closed hierarchy cones and therefore extends to a full
leaf-parameter neighborhood of the chosen generic color covector. Exact
linear-programming duality supplies uniform upper bounds; cut sums supply
a positive lower bound. It applies to arbitrary unit target series, not
only constant residues. A finite exact polynomial-avoidance algorithm
chooses the generic color covector. Full proof and the primitive-row
normalization are in `COLOR_GENERIC_VALUATION_WINDOW.md`.

The Dyck branch independently checked the retained-plane and absorption
arguments, including inserted zero-depth nodes. A fresh adversarial review
is still requested. The parent and boundary branches own the next step:
turn this valuation window into a proper finite flat analytic family that
meets both a strong-generic parameter and the clone-invariant subtorus.
No full Young or unsigned-theta conclusion is claimed by this branch
before that step and its specialization compatibility are proved.
