# Independent computation-plugin receipt

Executed through the Wolfram Language evaluator on 2026-11-13, during the
primitive-phase branch. The input was:

```wolfram
valid = And @@ Flatten[Table[
 If[Mod[m,d]==0 && Mod[m,e]==0 && Mod[k,GCD[d,e]]==0,
 Mod[m k,d e]==0, True],
 {d,1,12},{e,1,12},{m,1,72},{k,1,24}]];
cases=Table[With[{l=LCM[d,e],q=GCD[d,e]},
 {d,e,l,q,l q==d e}],{d,{2,4,6}},{e,{3,4,8}}];
{valid,cases}
```

The evaluator returned `True` for `valid` and `True` for the gcd/lcm identity
in all nine displayed pairs. This checks the finite arithmetic implication
that if both d and e divide m and gcd(d,e) divides k, then de divides mk.
The mathematical proof is simply
`lcm(d,e) gcd(d,e) = de`; no theorem depends on the finite range.

The main finite-set checks were performed by the reproducible Python program
`phase_orbit_matching.py`; its two JSON outputs retain the exact inputs and
counts. They test actual action laws and cancellation maps, not only the
divisibility of total counts.
