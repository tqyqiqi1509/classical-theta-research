# A bounded actual-arrow valuation window at a color-generic parameter

2026-11-13. This note addresses the missing symmetry bridge. It proves the
linear and tropical boundedness statement; the proper finite analytic-family
consequence is being independently written by the parent/boundary branch.

## 1. Charged leaves and a finite genericity condition

Let E be the rational vector space on the original mutable colors and one
frame color. Give E an alternating rational form η. The leaf charges are

    β_0=e_0,     β_v=k_v e_(color(v)),     k_v>0.

There is exactly one frame leaf. Put α=sum_v β_v. Between two leaves retain
|η(β_u,β_v)| actual arrows, directed according to the sign. Assume these
pairings are integral; the argument below concerns their valuations, so
individual parallel-arrow names do not matter.

Choose a covector μ∈ann(α) with μ(β_v)>0 at every mutable leaf. Thus the
framed leaf covector θ_v=μ(β_v) is cut-generic. We will choose μ outside a
specified finite union of proper rational hyperplanes in ann(α).

For charges S,A with η(S,A)≠0, define the linear projection

    Π_(S,A)(φ)=φ−φ(A)η(S,−)/η(S,A).                    (1)

Only S,A that are sums of leaves in nested supports are needed. Compose at
most |V| such projections. There are finitely many possible compositions L.
For every L and every support charge β_C, exclude the hyperplane

    (Lμ)(β_C)=0

if this equation is not identically zero on ann(α). This finite exclusion
is the meaning of **color-generic** here. It retains the symmetry among
leaves of one original color. A rational μ satisfying it exists in the
open framed chamber.

There is an entirely finite exact choice algorithm. Number the mutable
colors 1,...,r, let p_i be their total leaf multiplicities, and set

    μ(e_i)=z^(i−1),       μ(e_0)=−sum_i p_i z^(i−1).

Each nonzero excluded linear form becomes a nonzero rational polynomial
in z of degree at most r−1. Enumerate the finite projection words and
their nonzero pullbacks, then choose the least integer z≥2 at which none
of these polynomials vanishes. This terminates, uses exact rational
arithmetic, and automatically preserves every positive mutable weight.
Alternatively a common Cauchy root bound for these finitely many
polynomials gives a single sufficiently large integer z. No coefficient
or positivity oracle is needed to choose the parameter.

## 2. The projection image, including parallel steps

At the root, the covector image is ann(α). A first nonzero projection with
S=α has image ann(S,A), a codimension-two annihilator. The plane
P=span(S,A) is nondegenerate because η(S,A)≠0.

Inductively suppose the current covector ranges over ann(P), where P is a
nondegenerate two-plane containing the current charge S. If η(S,A)≠0,
the restriction of Π_(S,A) to ann(P) is injective: its possible kernel is
the line spanned by η(S,−), and that covector is not in ann(P). Its image
is contained in ann(S,A); both spaces have codimension two, so the image
is exactly ann(S,A).

If a child charge is parallel to S, the old plane P must be retained.
It must not be replaced by the one-dimensional span of two parallel
consecutive charges. The next subsection explains why a zero-pairing
node can be removed without changing the incoming ann(P) image.

## 3. Every forced node is either planar or parallel

Consider any rooted collision hierarchy, allowing a node to have more than
two children and allowing zero relative depths. Write β_S for the total
charge of a support S and, by slight abuse, S for this charge in η and μ.
At a node S with children A_1,...,A_m, its depth t and incoming covector φ
satisfy the cut equations

    φ(A_j)+t η(S,A_j)=0       for every j.               (2)

The covector φ is one of the finite projection images from Section 1 after
the parallel-node removal described below.

If η(S,A_1)≠0 for one child, (2) determines t and replaces φ by
Π_(S,A_1)φ. This projected covector annihilates every child charge.
Color genericity and Section 2 therefore imply

    A_j∈span(S,A_1)       for every j.                  (3)

The plane is nondegenerate. Its positive charge cone is pointed, so ordering
the child rays makes their skew-pairing quiver acyclic. This is the precise
local two-plane statement, valid also when t=0.

If η(S,A_j)=0 for every child, then (2) says φ(A_j)=0 for every j. Below
the root, color genericity forces A_j∈P; since P is nondegenerate and
contains S, the further equation η(S,A_j)=0 forces

    A_j=a_j S,       a_j>0,       sum_j a_j=1.          (4)

At the root this alternative is impossible. There the annihilator is only
ann(α), so it would force every child parallel to α. A child not containing
the unique frame has frame coordinate zero and cannot be a positive
multiple of α.

Here is the required removal rule for (4). In leaf coordinates,

    v_S|_(A_j)=a_j^−1 v_(A_j),                          (5)

because v_S(v)=η(S,β_v). Replace the depth at the child A_j by its old
depth plus a_j^−1 t, and delete the parent node S. Keep the incoming
covector φ unchanged. Equations on every leaf are unchanged, and every
effective depth stays nonnegative. If A_j is a singleton, its v-vector is
zero and the extra depth can be discarded.

This rule is essential. Propagating φ+tη(S,−) with a freely varying t
would appear to enlarge the covector image and would invalidate the
two-plane induction. Absorption instead keeps the old ann(P) image and
lets the induction continue correctly. The removal is used for equations
and recession analysis; it does not assert that all individual arrow
valuations are preserved by deleting the node.

## 4. No recession can increase an actual arrow valuation

For a full binary hierarchy H let its internal nodes include V. Define
the matrix M_H whose columns are v_S in the leaf zero-sum space. Allow
nonnegative depths and consider the closed fiber

    P_H(θ)={t≥0 : M_H t=−θ}.                            (6)

Suppose P_H(θ) is nonempty at θ_v=μ(β_v), with μ color-generic. Its
recession cone is

    Rec(P_H)={k≥0 : M_H k=0}.                           (7)

For an actual arrow e=(u,v), its valuation functional on this cone is

    w_e(k)=sum_(S contains u,v) k_S.                    (8)

**Theorem.** Every k in (7) has w_e(k)=0 for every actual arrow e.

**Proof.** Take a maximal support S with k_S>0, after removing any earlier
parallel nodes by Section 3. Ancestor recession coefficients are zero.
Summing M_H k=0 over a child A of S gives

    k_S η(S,A)=0,

because all deeper support vectors sum to zero on A. Thus every child
pairing is zero. Apply (4) and propagate the positive coefficient k_S
to each child using the positive ratios in (5), adding it to that child's
existing recession coefficient. Apply the same absorption simultaneously
to one feasible depth vector in (6), so that the unchanged incoming
covector still has the ann(P) image required by Section 3.

If a descendant ever has a nonzero child pairing, its positive effective
recession coefficient contradicts the same cut equation. Therefore all
descendants remain parallel nodes, and every leaf under S is parallel to S.
Since original leaves are positive multiples of distinct coordinate basis
vectors, all such leaves have one original mutable color. There is no
actual arrow between any two of them. Consequently no actual arrow lies
inside a support carrying positive original recession coefficient, proving
(8). QED.

The argument also handles zero feasible depths. It needs neither a choice
of target residues nor reducedness of a Gale fiber. In particular it
applies to solutions over arbitrary valued extensions with arbitrary
unit target series, not only constant complex targets.

## 5. A full leaf-parameter neighborhood, not merely a color slice

There are finitely many full binary hierarchies. Every collision hierarchy
can be refined to one by inserting zero depths. Coinciding nonadjacent
coordinates can be separated at arbitrarily greater depth without changing
the valuations of actual arrow forms, so the same finite list covers all
actual-arrow valuation vectors.

For each H, its cone C_H=M_H R_≥0^n is a closed rational polyhedral cone.
Choose a sufficiently small neighborhood U of −θ which avoids every C_H
not containing −θ. Only hierarchies already feasible at θ can then occur
for nearby full leaf covectors θ', whether or not θ' preserves colors.

For each remaining H and each actual arrow e, Section 4 says that w_e is
zero on the recession cone of (6). Linear-programming duality supplies a
single vector u_(H,e) with

    M_H^T u_(H,e) ≥ coefficient_vector(w_e).

It follows that, for all t≥0 with M_H t=−θ',

    w_e(t) ≤ u_(H,e)·(−θ').                             (9)

On a bounded small neighborhood the right side is uniformly bounded.
Taking the maximum over the finite H,e gives a finite bound M on every
actual arrow valuation. This upper bound is uniform in all target units.

There is also a positive uniform lower bound. Keep θ' in a compact subset
of the same original cut chamber, and let

    δ=min_(proper nonempty C) |θ'(C)| >0

uniformly there. For a nonnegative ultrametric arrow valuation vector, let
m be its minimum. Partition the vertices using edges of valuation strictly
greater than m. An edge of valuation m joins distinct components: a path of
strictly larger valuations would violate the ultrametric inequality.
For each component C every crossing arrow has valuation exactly m, so

    |θ'(C)|=m |η(C,V\C)|.

Thus m≥δ/K, where K=max_C |η(C,V\C)| over nonzero cuts. The case K=0
has no positive solution in a cut-generic chamber. We obtain a uniform
window

    0<ε≤val(L_e)≤M<∞                                  (10)

for all actual arrows in every positive Gale solution for θ' near θ.

## 6. Why the window is the right boundary statement

In a unit-target family at the fixed color-generic θ, suppose a branch
approached an actual collision divisor as an auxiliary parameter s→0.
Substitute s=T^N, with N arbitrarily large. The target coefficients remain
units, but the colliding arrow would acquire arbitrarily large valuation.
This contradicts (10). The same lower bound excludes an arrow leaving the
positive region through valuation zero.

The triangle counterexample with θ=(1,1,1) and targets tending to (1,1,1)
does not contradict this result: its three colors are distinct, and that
θ is not generic on the original color space. It lies on precisely the
extra collision degeneracies excluded in Section 1.

For the analytic-family application, take a full target polyannulus with
small valuations around zero. The effective leaf covector is
θ'=θ−val(q), so (10) places the entire positive locus strictly inside a
fixed affinoid domain in x and the inverses of the actual L_e. The parent
and boundary branches are checking the proper/finite and complete-
intersection flatness statements needed to turn this into a constant-
degree family meeting both a strong-generic parameter and the symmetric
target subtorus. Those algebraic/analytic conclusions are not substituted
for the explicit window proof here.

## 7. Primitive rows and packet cycles

The same window proof permits a positive integer d_v dividing every arrow
multiplicity incident to v, with d_0=1. Use the primitive Gale row obtained
by dividing every exponent in Γ_v by d_v, and divide its target valuation
by d_v. Multiplying that row valuation back by d_v recovers exactly (3)
in the raw leaf-charge coordinates, so Sections 1–6 apply unchanged.

For a permutation cycle of length k on original color i, the collapsed
charge is k e_i and its primitive row degree is d_v=kD_i. The restricted
equation is one original row, not its d_v-th power. At a binary chart its
exponent determinant is the raw determinant divided by product_v d_v,
which is the primitive positive count. This is the same normalization as
the independently constructed phase-orbit catalog.
