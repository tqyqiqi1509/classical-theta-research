"""Primitive packet phases on actual flagged spanning trees.

The signed universe and local involution come from the independently proved
cyclic transport. The new operation is a graph-theoretic orbit matching,
whose edges are actual local-involution pairs. No theta coefficient or
cardinality pairing is used to construct the positive objects.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import defaultdict, Counter
from math import prod
import sys, json, time, random

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'agents/intrinsic_greedy_round2'))
sys.path.insert(0, str(ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'))
from cyclic_signed_flow_transport import SignedFlowUniverse, state_sign
from universal_flow_tree_probe import FlowPackets


class PhaseModel:
    def __init__(self, degrees, eta):
        self.degrees = tuple(degrees)
        self.n = len(degrees)
        assert degrees[0] == 1
        self.eta = tuple(map(tuple, eta))
        edges=[]
        self.palette={}
        for i in range(self.n):
            for j in range(i+1,self.n):
                m=eta[i][j]
                if not m: continue
                u,v=(i,j) if m>0 else (j,i)
                m=abs(m)
                assert m % degrees[i] == m % degrees[j] == 0
                self.palette[u,v]=m
                edges.extend((u,v,c) for c in range(m))
        self.edges=tuple(edges)
        self.eid={e:i for i,e in enumerate(edges)}
        self.alg=SignedFlowUniverse(self.n,self.edges)
        self.order=prod(self.degrees)
        self.groups=tuple(product(*(range(d) for d in degrees)))

    def arrow_action(self,e,s):
        u,v,c=self.edges[e];m=self.palette[u,v]
        return self.eid[u,v,(c+(m//self.degrees[u])*s[u]
                              -(m//self.degrees[v])*s[v]) % m]

    def action(self,state,s):
        def node(j):
            if j[0]=='leaf':return j
            return ('J',tuple(sorted(self.arrow_action(e,s) for e in j[1])),
                    tuple(node(c) for c in j[2]))
        return (tuple(node(j) for j in state[0]),
                tuple(sorted(self.arrow_action(e,s) for e in state[1])))

    @staticmethod
    def tree_arrows(state):
        edges=list(state[1])
        def visit(j):
            if j[0]=='J':
                edges.extend(j[1])
                for c in j[2]:visit(c)
        for j in state[0]:visit(j)
        assert len(edges)==len(set(edges))
        return tuple(sorted(edges))

    def canonical(self,state):
        """Unique phase gauge, using the underlying tree rooted at frame 0."""
        T=self.tree_arrows(state)
        assert len(T)==self.n-1
        adj=[[] for _ in range(self.n)]
        for e in T:
            u,v,_=self.edges[e]
            adj[u].append((v,e));adj[v].append((u,e))
        phases=[None]*self.n;phases[0]=0
        todo=[0]
        for parent in todo:
            for child,e in sorted(adj[parent]):
                if phases[child] is not None:continue
                u,v,c=self.edges[e];m=self.palette[u,v]
                sign=1 if child==u else -1
                base=c-sign*(m//self.degrees[parent])*phases[parent]
                step=m//self.degrees[child]
                phases[child]=(-sign*(base//step)) % self.degrees[child]
                todo.append(child)
        assert len(todo)==self.n
        phases=tuple(phases)
        return self.action(state,phases),phases

    def build(self,theta):
        self.theta=theta
        self.states=tuple(self.alg.universe(theta));self.state_set=set(self.states)
        self.orbits=defaultdict(list)
        for s in self.states:
            c,g=self.canonical(s)
            assert c in self.state_set
            self.orbits[c].append(s)
        assert all(len(v)==self.order for v in self.orbits.values())
        self.negative=tuple(sorted(c for c in self.orbits if state_sign(c)<0))
        self.positive=tuple(sorted(c for c in self.orbits if state_sign(c)>0))
        self.adj={};self.witness={};self.local={}
        for s in self.states:
            t=self.alg.involution(theta,s)
            assert t in self.state_set and self.alg.involution(theta,t)==s
            self.local[s]=t
        for a in self.negative:
            neighbors=set()
            for s in self.orbits[a]:
                t=self.local[s]
                assert state_sign(t)>0
                b,_=self.canonical(t)
                neighbors.add(b)
                self.witness.setdefault((a,b),(s,t))
            self.adj[a]=tuple(sorted(neighbors))
        self.right_match={}
        def augment(a,seen):
            for b in self.adj[a]:
                if b in seen:continue
                seen.add(b)
                if b not in self.right_match or augment(self.right_match[b],seen):
                    self.right_match[b]=a
                    return True
            return False
        for a in self.negative:
            assert augment(a,set()),'Hall condition contradicted'
        self.left_match={a:b for b,a in self.right_match.items()}
        self.positive_objects=tuple(b for b in self.positive if b not in self.right_match)
        self.matched_edge={}
        for a,b in self.left_match.items():
            s,t=self.witness[a,b]
            for g in self.groups:
                sg,tg=self.action(s,g),self.action(t,g)
                assert sg not in self.matched_edge and tg not in self.matched_edge
                self.matched_edge[sg]=tg;self.matched_edge[tg]=sg

    def orbit_involution(self,s):
        return self.matched_edge.get(s,s)

    def axis_to_fixed(self,s):
        assert self.local[s]==s
        path=[s];seen={s}
        while True:
            t=self.orbit_involution(s)
            if t==s:return s,path
            assert state_sign(t)<0
            path.append(t)
            s=self.local[t]
            assert state_sign(s)>0 and s not in seen
            path.append(s);seen.add(s)


def packet_model(B,D,g,packets):
    fp=FlowPackets(B,D,g,packets)
    degrees=(1,)+tuple(D[i]*k for i,k in packets)
    return PhaseModel(degrees,fp.eta),fp


def check(name,B,D,g,packets,seed=0):
    model,fp=packet_model(B,D,g,packets)
    rng=random.Random(seed)
    vals=[F(rng.randrange(1,10**8)) for _ in packets]
    theta=tuple([-sum(vals)]+vals)
    start=time.time();model.build(theta)
    canonical_checks=equivariance_checks=0
    for s in model.states:
        c,_=model.canonical(s)
        assert model.canonical(c)[0]==c
        for h in model.groups:
            t=model.action(s,h)
            assert t in model.state_set
            assert model.canonical(t)[0]==c
            canonical_checks+=1
            assert model.orbit_involution(t)==model.action(model.orbit_involution(s),h)
            equivariance_checks+=1
        assert model.orbit_involution(model.orbit_involution(s))==s
    axis=[s for s in model.states if model.local[s]==s]
    images={};longest=0
    for s in axis:
        t,path=model.axis_to_fixed(s)
        images[s]=t;longest=max(longest,len(path)-1)
    expected={s for s in model.states if model.orbit_involution(s)==s}
    assert set(images.values())==expected and len(images)==len(expected)
    inverse={v:k for k,v in images.items()}
    action_checks=0
    for s in axis:
        for h in model.groups:
            t=inverse[model.action(images[s],h)]
            for k in model.groups:
                left=inverse[model.action(images[t],k)]
                hk=tuple((a+b)%d for a,b,d in zip(h,k,model.degrees))
                right=inverse[model.action(images[s],hk)]
                assert left==right
                action_checks+=1
    value,record=fp.evaluate()
    assert len(axis)==record['flow_weight']
    assert len(model.positive_objects)==record['primitive_flow_weight']
    return dict(name=name,vertices=model.n,arrows=len(model.edges),degrees=model.degrees,
                signed_states=len(model.states),phase_group_order=model.order,
                negative_orbits=len(model.negative),positive_orbits=len(model.positive),
                primitive_objects=len(model.positive_objects),raw_axis_objects=len(axis),
                orbit_graph_edges=sum(map(len,model.adj.values())),
                canonical_checks=canonical_checks,equivariant_involution_checks=equivariance_checks,
                induced_phase_action_checks=action_checks,longest_cancellation_path=longest,
                independent_flow_count=record,seconds=time.time()-start)


if __name__=='__main__':
    cases=[
        ('valued_rank2',[[0,3],[-2,0]],[2,3],(-1,-1),((0,1),(1,1))),
        ('repeated_packet_cycle',[[0,1,-1],[-1,0,1],[1,-1,0]],[1,1,1],(-1,-1,-1),((0,2),(1,1),(2,1))),
        ('two_repeated_packets',[[0,1,-1],[-1,0,1],[1,-1,0]],[1,1,1],(-1,-1,-1),((0,2),(1,2),(2,1))),
        ('valued_cycle',[[0,1,-1],[-2,0,1],[2,-1,0]],[2,1,1],(-1,-1,-1),((0,1),(1,1),(2,1))),
        ('markov_packet',[[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],(-1,-1,-1),((0,2),(1,1),(2,1))),
    ]
    out=[]
    for i,c in enumerate(cases):
        r=check(*c,seed=1132020+i)
        out.append(r)
        print(json.dumps(r),flush=True)
        Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
