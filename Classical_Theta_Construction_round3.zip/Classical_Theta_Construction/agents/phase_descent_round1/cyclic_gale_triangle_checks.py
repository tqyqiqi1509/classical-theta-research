"""Exact cyclic Gale checks which separate valid and false mechanisms.

This checks the positive factor in homogeneous examples, not merely the
unsaturated cleared equations. It includes the target-specialization failure.
"""
from pathlib import Path
import json, time, itertools, sys
import sympy as s

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'))
from universal_flow_tree_probe import FlowPackets


def quotient_length(gb):
    if list(gb)==[1]: return 0
    if not gb.is_zero_dimensional: return None
    leads=[p.LM(order=gb.order).exponents for p in gb.polys]
    bounds=[min(e[i] for e in leads if e[i] and sum(bool(z) for z in e)==1)
            for i in range(len(gb.gens))]
    return sum(not any(all(a<=b for a,b in zip(l,e)) for l in leads)
               for e in itertools.product(*(range(b) for b in bounds)))


def triangle(m,targets):
    x,y,z,u=s.symbols('x y z u'); c1,c2,c3=targets
    f=[(x-z)**m+c1*x*(y-x)**m,
       (y-x)**m+c2*y*(z-y)**m,
       (z-y)**m+c3*z*(x-z)**m]
    # The full cut relation is already implied after saturation and accelerates
    # the Groebner computation. Every root arrow is x_i -> 0.
    f.append(x*y*z+s.Rational(1,c1*c2*c3))
    t=time.time()
    gb=s.groebner(f+[u*x*y*z*(y-x)*(z-y)*(x-z)-1],u,z,y,x,order='grevlex')
    length=quotient_length(gb)
    lex=gb.fglm('lex') if length else gb
    eliminants=[str(p.as_expr()) for p in lex.polys if not p.as_expr().has(u,z,y)]
    B=[[0,-m,m],[m,0,-m],[-m,m,0]]
    raw=FlowPackets(B,[1,1,1],[-1,-1,-1],[(0,1),(1,1),(2,1)]).evaluate()[1]['flow_weight']
    return {'family':'directed_triangle','arrows_per_cycle_edge':m,'targets':targets,
            'homogeneous_positive_factor':True,'saturated_length':length,
            'independent_raw_flow_count':raw,'eliminants':eliminants,
            'unit_ideal':length==0,'seconds':time.time()-t}


def clone_case():
    # Two equal-color clones. The framing makes every master function have
    # homogeneous degree -1, so the entire generic fiber is positive.
    B=[[0,-1,1],[1,0,-1],[-1,1,0]]; g=[-1,-2,0]
    model=FlowPackets(B,[1,1,1],g,[(0,1),(0,1),(1,1),(2,1)])
    xs=s.symbols('x1:5');u=s.symbols('u');coords=(s.Integer(0),)+xs
    num=[s.Integer(1)]*5;den=[s.Integer(1)]*5;forms=[]
    for i in range(5):
        for j in range(i+1,5):
            a=model.eta[i][j]
            if a:
                q,r=(i,j) if a>0 else (j,i)
                form=coords[r]-coords[q];forms.append(form)
                den[q]*=form**abs(a);num[r]*=form**abs(a)
    c=[2,2,3,5]
    f=[s.expand(num[i]-c[i-1]*den[i]) for i in range(1,5)]
    gb=s.groebner(f+[u*s.prod(forms)-1],u,*reversed(xs),order='grevlex')
    length=quotient_length(gb)
    # Restrict one original row per permutation cycle, never its square.
    sub={xs[1]:xs[0]}
    fixed_f=[f[i].subs(sub) for i in [0,2,3]]
    fixed_sat=s.prod(forms).subs(sub)
    fixed_gb=s.groebner(fixed_f+[u*fixed_sat-1],u,xs[3],xs[2],xs[0],order='grevlex')
    fixed_length=quotient_length(fixed_gb)
    packet=FlowPackets(B,[1,1,1],g,[(0,2),(1,1),(2,1)]).evaluate()[1]
    raw=model.evaluate()[1]['flow_weight']
    assert length==raw and fixed_length==packet['primitive_flow_weight']
    return {'family':'two_equal_color_clones','B':B,'g':g,'content':[2,1,1],
            'targets':c,'homogeneous_positive_factor':True,'saturated_length':length,
            'swap_fixed_scheme_length':fixed_length,'independent_raw_flow_count':raw,
            'independent_packet_primitive_count':packet['primitive_flow_weight'],
            'sign_multiplicity':(length-fixed_length)//2}


if __name__=='__main__':
    results=[triangle(m,(2,3,5)) for m in [1,2,3]]
    results += [triangle(1,c) for c in [(1,1,2),(1,1,1)]]
    results.append(clone_case())
    target=Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
