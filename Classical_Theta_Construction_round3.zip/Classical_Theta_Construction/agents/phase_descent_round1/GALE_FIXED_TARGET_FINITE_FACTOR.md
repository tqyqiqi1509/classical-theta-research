# A finite positive Gale factor without acyclicity

2026-11-13. This theorem is for each fixed target field. Its proof does not
assert uniform flatness over all target constants; that stronger statement
is false, as Section 5 records.

## 1. Input and definition

Let k be any characteristic-zero field, Q a directed multigraph on
V={0,...,n}, and x_0=0. Put

    L_e=x_head(e)−x_tail(e),       Λ=product_e L_e,
    Γ_i=product_(head(e)=i) L_e / product_(tail(e)=i) L_e.

Choose integral θ with θ(V)=0 and

    θ(C)≠0 for every nonempty proper C⊂V.                (1)

Rational θ is handled by a finite ramification of T. Choose targets c_i∈k*
for i≠0 and define c_0=(product_(i≠0)c_i)^−1. Consider the square Gale
system Γ_i=c_i T^(−θ_i), i≠0, on the actual arrow-complement Λ≠0.

Let R=k[T,x_1,...,x_n]. Clear the powers of T and arrow denominators in
these equations and let J be the contraction of their ideal from
R[(TΛ)^−1] to R. Equivalently, saturate the cleared ideal by TΛ. Put

    C=R/J,      A=lim_m C/T^m C.                       (2)

The zero ring is allowed. The definition uses only the original graph,
θ, and the chosen nonzero targets.

## 2. The cut argument forces a zero-dimensional special fiber

For every C⊂V, multiplying the vertex equations cancels all internal arrows
and gives the cut relation

    product_(head in C, tail outside) L_e
      / product_(tail in C, head outside) L_e
       = c_C T^(−θ(C)),     c_C=product_(i∈C)c_i.        (3)

After clearing its T power and boundary denominator, (3) belongs to J:
it holds in the localized equation ideal, and J is its contraction.

Take a geometric point of the special fiber Spec(C/TC). Partition V into
the connected components of the graph of actual arrows for which L_e=0 at
that point. At any one component C, every boundary arrow form is nonzero.
If C is proper, condition (1) and (3) yield a contradiction at T=0: one
side is a product of nonzero boundary values, while the other contains a
strictly positive power of T. Thus there is a single zero-arrow component.
All vertex coordinates agree with x_0=0.

Therefore C/TC is supported at x_1=...=x_n=0 and is finite dimensional over
k. If Q is disconnected, a proper graph component has no boundary arrows;
the same argument makes the special fiber empty. This is consistent with
A=0.

This argument permits directed cycles, opposite arrows, zero framing
entries, and arbitrary signs of the framing. It uses cut genericity, not
the stronger collision-hierarchy genericity.

## 3. Finite freeness and the actual square-system factor

Lift a finite k-basis of C/TC. Iterative T-adic reduction shows that these
lifts generate A over k[[T]]. Hence A is finite over the complete DVR
k[[T]]. Saturation gives

    J:T=J,       J:Λ=J.

Thus T and Λ are nonzerodivisors on C. Noetherian adic completion is flat,
so they remain nonzerodivisors on A. In particular A is a finite torsion-free
k[[T]]-module, hence free.

After T is inverted,

    A_K=A⊗_(k[[T]]) K,       K=k((T)),                   (4)

is a finite-dimensional Artin K-algebra. Multiplication by Λ is injective
on A_K, hence bijective. Therefore Λ is a unit in A_K. This is the precise
place where the fixed target **field** is used. A regular element in an
algebra finite over a higher-dimensional target ring need not be a unit.

To see that A_K retains full local factors of the actual Gale system, set
C'=k[[T]]⊗_(k[T]) C. Its T-adic completion is A. The completion map
C'→A is flat. It is also surjective: the lifted finite basis and all its
k[[T]] coefficients already belong to C'. Its finitely generated kernel is
therefore an idempotent ideal. Consequently A is an open-and-closed direct
factor of C'. Inverting T and Λ identifies A_K with a direct factor of

    K[x_1,...,x_n,Λ^−1]/(Γ_i−c_i T^(−θ_i):i≠0).         (5)

It is an isolated full finite Artin factor of the **n equations in n
coordinates** in (5). Nilpotents have not been discarded.

## 4. Exactly the positive-valuation factor

Every point of A_K has all x_i in the maximal ideal of a finite extension
of k[[T]], because the special fiber of A is supported at x=0. Its actual
arrow differences have positive valuation, and they are nonzero because Λ
is a unit after inverting T.

Conversely, a Gale solution with every actual arrow difference of positive
valuation has all x_i of positive valuation by connectedness and x_0=0.
It extends over a finite valuation ring and reduces to the special point
x=0. Evaluation therefore factors through the completed algebra A and its
generic factor A_K. The direct-factor argument in Section 3 retains the
entire local Artin algebra at every such point.

Thus (2) is an exact finite algebraic construction of the full positive
Gale factor for every cut-generic θ, including a clone-invariant θ on
internal fake walls.

Any finite graph automorphism group fixing the frame and preserving θ and
the targets acts on this algebra by its actual coordinate permutation.
For Young groups permuting equal original colors, the fixed-cycle lemma in
`../dyck_flow_round2/YOUNG_FIXED_CYCLE_LENGTH_LEMMA.md` applies once one
compares this positive factor with the required raw flow character. That
comparison is the remaining task; finiteness alone does not supply it.

## 5. A necessary correction: no uniform all-target flatness theorem

Take the directed triangle 1→2→3→1, add one arrow i→0 for each i, and set
θ_i=1. Every Γ_i is homogeneous of degree −1, so x_i=T y_i. The positive
factor equals the saturated fiber of

    y_1−y_3+c_1 y_1(y_2−y_1)=0,
    y_2−y_1+c_2 y_2(y_3−y_2)=0,
    y_3−y_2+c_3 y_3(y_1−y_3)=0,

away from all actual arrow hyperplanes. Exact Groebner computations give:

| Targets | Saturated length |
|---|---:|
| (2,3,5) | 4 |
| (1,1,2) | 4 |
| (1,1,1) | 0; the saturated ideal is the unit ideal |

Thus internal collision divisors can absorb every branch on a unit-target
specialization. The fixed-target finiteness theorem remains true, but the
length is not constant over the full nonzero target torus at a fake wall.

The intended Young application keeps targets algebraically independent
between original colors, while equating only clones of one color. There
are no arrows between clones of a single original color. Whether this
restricted target family avoids the relevant collision boundary must be
proved, and is being attacked through the two-plane local collision
mechanism. The example above is retained to prevent a false universal
flatness shortcut.
