# Positive graph-Gale factors at a strongly generic parameter

2026-11-13. Work in progress toward Young-cycle descent. The theorem in
Sections 1–5 is independent of acyclicity. Section 6 states the remaining
symmetry bridge explicitly; it is not silently assumed.

## 1. A single graph-defined system

Let Q be a finite connected directed multigraph on V={0,...,n}, with frame 0.
Parallel arrows retain their multiplicity. Put x_0=0 and

    L_e=x_head(e)−x_tail(e),
    Γ_i(x)= product_(head(e)=i) L_e / product_(tail(e)=i) L_e.

The domain U is the complement of all actual arrow hyperplanes L_e=0 in
affine n-space. Nonadjacent coordinates are allowed to coincide. For a
zero-sum rational covector θ and nonzero complex targets c_i, consider

    Γ_i(x)=c_i T^(−θ_i),       i=1,...,n.                 (1)

The omitted equation at 0 is the reciprocal product of these equations.
We work over an algebraic closure of C((T)); rational exponents are absorbed
by one finite ramification. The **positive factor** means the full set of
isolated solutions for which val(L_e)>0 for every actual arrow e. This is
equivalent to val(x_i)>0 for all nonzero x_i, allowing x_i=0: connectivity
expresses each x_i as a sum of arrow differences along a path from 0.

No theta coefficient, wall function, precomputed multiplicity, or list of
flow trees enters the defining equations or positivity condition.

Our incidence convention is ∂(u→v)=e_u−e_v, and

    v_S=−∂_S 1,     η(A,B)=#E(A,B)−#E(B,A).

Thus val(Γ)=−∂ val(L), in agreement with the minus sign in (1).

## 2. Strong genericity and collision hierarchies

A rooted hierarchy on V records the clusters of coordinates which are closer
to one another than to their parent cluster. For a binary hierarchy H, let
its n internal clusters include the whole set V, and attach a positive
relative depth t_S to every internal cluster. The valuation of a difference
between leaves u,v is

    w_uv=sum_(S contains u and v) t_S.                   (2)

The same formula is valid for actual arrows, whether or not every pair is an
arrow. Its image under the logarithmic Gale map is

    −θ=sum_(internal S) t_S v_S.                         (3)

Choose θ outside the spans of all rank-deficient collision-hierarchy cones.
There are finitely many of them. In particular, this excludes every
nonbinary hierarchy cone, every unsplit coincident-coordinate block, and
every binary hierarchy for which the vectors v_S are dependent. We call this
**Gale-strong genericity**. It can be imposed together with the finite generic
conditions in the raw flow construction. In any nonempty open cut chamber,
such rational covectors exist, since the excluded spans are proper.

For this θ, every solution of (1) in the positive factor has a unique full
binary collision hierarchy with nonzero determinant in (3). Indeed, the
ultrametric inequality for valuations of coordinate differences constructs
its hierarchy. A nonbinary or unsplit hierarchy has fewer than n independent
depth parameters and would place θ in one of the excluded spans. If a
cluster is disconnected in the induced graph, its vector v_S is the sum of
the vectors of its connected pieces, forcing the same rank deficiency.

Conversely, a binary hierarchy is admissible exactly when the unique
solution of (3) has all t_S>0.

## 3. The determinant is the raw flow-tree weight

At a node S=L disjoint-union R, summing (3) over L gives the first projected
cut equation

    θ(L)=t_S η(L,R)

after the contributions of strict ancestors have been removed. This is
precisely the flow admission rule t_S=h/a, followed by the child parameter
θ'=θ+t_S v_S.

Let M_H be the integer n-by-n matrix with columns v_S, deleting the frame
row. Then

    |det M_H|= product_(nodes S=L⊔R) |η(L,R)|.             (4)

One direct unimodular induction proves (4). At the root choose L to contain
the frame. Replace one row indexed in R by the sum of all R rows. Every
proper-cluster column has zero sum in that row; the root column has value
η(L,R), up to the incidence sign. Expand in that row and root column. The
remaining matrix splits into the two child matrices, with one anchor row
deleted in each. Repeat. No extra gcd factor occurs.

The parent branch independently checked this determinant identity in 2,000
random integer skew inputs and binary hierarchies, including 367 singular
cases, using the computation plugin. Those checks support the implementation;
the induction is the proof.

## 4. Each admissible hierarchy gives exactly its determinant many lifts

Choose an anchor leaf for each cluster, inherited by the child containing
the parent anchor. For each internal node S with children L,R, define

    δ_S=x_anchor(R)−x_anchor(L).

Choose L to inherit the anchor. The n quantities δ_S form a unimodular
linear coordinate system on x_1,...,x_n: their anchor pairs form a spanning
tree. Put d_S=sum_(A ancestor of or equal to S) t_A and write

    δ_S=T^(d_S) y_S,       val(y_S)=0.

For an arrow crossing the children of S, its leading form is ±T^(d_S)y_S;
all descendant corrections have strictly larger valuation. Consequently
the initial equations of (1) in this chart are a square monomial system

    product_S y_S^(b_(i,S))=ε_i c_i,                     (5)

with ε_i∈{±1}. Here b_S is the incidence vector of the arrows crossing the
children of S. The column systems (b_S) and (v_S) differ by an integral
unitriangular transformation, because

    v_S=sum_(nodes A contained in S) b_A.

Hence |det(b_(i,S))|=|det M_H|. The monomial torus map (5) is a finite
isogeny of this degree. In characteristic zero every fiber over nonzero
targets consists of exactly |det M_H| distinct points, with invertible
logarithmic Jacobian. After clearing rational depths, formal Hensel lifting
therefore supplies one and only one solution of (1) per initial point.
Every lifted point has the stated hierarchy and is simple.

There are finitely many binary hierarchies. The preceding completeness
argument shows that these are all positive solutions. Thus the positive
factor is finite and reduced, and

    #positive Gale solutions
      =sum_(admissible H) product_nodes |η(L,R)|.          (6)

The right side is the already defined raw colored axis-flow count, including
all actual descendant projections. Equation (6) is an identification after
the polynomial system has been defined; it is not a rule selecting a fiber
with a desired length.

The construction also works uniformly over the nonzero target torus for a
fixed Gale-strong generic θ: every initial isogeny is finite étale over that
torus, and its formal Hensel lift remains so. In particular, repeated target
values alone cause no degeneracy at this strongly generic θ.

## 5. A cyclic check which distinguishes this factor from toric cohomology

Take r arrows on each edge of 1→2→3→1, and one arrow i→0 for each i. Put
θ_i=1. Every Γ_i is homogeneous of degree −1, so x_i=T y_i reduces the full
Gale fiber to a T-independent system. Its entire finite fiber is therefore
positive. This particular θ is not Gale-strong generic, so the calculation
is evidence for the extension in Section 6, not a substitute for that proof.

For targets (2,3,5), saturation by all actual arrow forms gives exact degrees
4, 7, 10 for r=1,2,3. These match the independently known raw flow counts
1+3r. They differ from the old spherical-image quantities 4,10,16. The
saturated systems and their univariate eliminants are retained in
`cyclic_gale_triangle_checks.py` and its JSON output.

## 6. The genuine remaining Young-symmetry bridge

For repeated original colors, the desired group permutes clone coordinates.
Its invariant θ can lie on the excluded fake walls. Thus Section 4 alone
does **not** give the desired Young action. One must still show that a finite
positive factor at such an invariant θ, possibly after a sufficiently small
same-color square-map perturbation, has the same finite character obtained
by a nearby strong-generic refinement.

The expected fixed-cycle operation is concrete: set x_v=x_(σv), and retain
one equation per permutation cycle. Do not raise that equation to the cycle
length; doing so inserts spurious roots-of-unity branches. The collapsed
equations have packet edge exponents divided by the appropriate packet
length, so their simple-lift count should be T_λ rather than the raw packet
count. The primitive phase theorem gives an independent positive catalog
for these numbers.

The companion Dyck branch is supplying the precise isolated-square-factor
lemma: a generic Young-equivariant separable perturbation has a finite
reduced coordinate-tuple fiber, and its fixed-cycle restrictions are finite
flat as well. Coordinate-tuple stabilizers are products of symmetric groups
on equal-coordinate blocks. Therefore a proved global positive factor would
turn its sign multiplicity into the number of free Young orbits, with no
coefficient rank matching. The missing positive-factor/fake-wall deformation
statement must be proved before claiming this consequence for theta.

## Literature status

Primary interfaces located: Sturmfels–Tevelev, *Elimination theory for
tropical varieties*, arXiv:0704.3471; Feichtner–Sturmfels, *Matroid polytopes,
nested sets and Bergman fans*, arXiv:math/0411260; Dickenstein–Feichtner–
Sturmfels, *Tropical discriminants*, whose Horn/Gale map is a closely related
linear-forms-to-monomials map; Bihan–Sottile, *Gale duality for complete
intersections*. The parent is reading the precise tropical pushforward and
lifting hypotheses. The proof above was written directly in binary charts
and does not import an unverified 2026 assertion.

The existing local acyclic Gale theorem is prior work in the user's files.
Its complete-fan regular-sequence proof is not transplanted to cyclic Q.
The new candidate here is the single arbitrary-graph positive factor and
its collision-hierarchy interpretation.
