# Primitive packet phases by orbit matching on flagged spanning trees

2026-11-13. Classical cluster algebras. This is a new constructive lemma and
its application to the independently proved cyclic flagged-tree transport.
It removes the primitive-normal division in each positive packet count.
It does **not** yet remove the alternating permutation-cycle sum over packet
types, and it does not assert that a previously chosen local primitive color
tuple is the orbit of the naive parallel-arrow action on a fixed binary tree.

## 1. A finite equivariant cancellation lemma

Let a finite group G act freely on a finite signed set S=S+ disjoint-union S−,
preserving signs. Suppose an explicitly given sign-reversing involution I on
S has only positive fixed points. I need not commute with G.

Make a finite bipartite graph Γ. Its left vertices are negative G-orbits and
its right vertices are positive G-orbits. Join A to B precisely when there
is s in A with I(s) in B. Retain an actual witness pair (s,I(s)) for every
edge, chosen by a fixed order on S.

For any set U of negative orbit vertices, the union of their states has
|G| |U| elements. Its images under I are distinct positive states, and all
lie in the union of the neighboring positive orbits. Consequently

    |G| |U| <= |G| |NΓ(U)|.

This proves Hall's condition. A standard augmenting-path algorithm, with
fixed orders on vertices and edges, finds a matching saturating every left
vertex. It never asks for the number of intended output objects. Its edges
are actual local-involution incidences, not a complete graph inserted because
two numbers happen to agree.

For a matched orbit pair A--B with witness s0,t0=I(s0), define

    M(g s0)=g t0,   M(g t0)=g s0.

Freeness makes this unambiguous. Fix every element of an unmatched positive
orbit. Then M is an actual G-equivariant sign-reversing involution. Its
positive fixed set is a disjoint union of free G-orbits.

There is an explicit bijection between Fix(I) and Fix(M): start at an
I-fixed point and alternate M and I until an M-fixed point is reached.
The finite two-colored involution graph has degree at most two. A path
starting at an endpoint cannot enter a cycle, and positivity of every fixed
point forces the other endpoint to have the other color. Reversing the path
is the inverse.

Thus the lemma also equips Fix(I) with an actual free G-action, transported
from Fix(M). This induced action can change the combinatorial shape of an
I-fixed object; no equivariance of the original I was assumed.

## 2. The packet graph and its phase group

Fix an exchange matrix B with integral positive symmetrizer D, a label g,
and a packet type λ: for each original mutable color i, choose a partition
λ^i of p_i. There is one framing vertex 0 and one individually labeled
vertex v for every packet k e_i. Its primitive degree is

    d0=1,    dv=k Di.

Use the framed skew pairing from the earlier positive flow formula,

    eta(a,b)=−a^T Dhat Bhat b,
    Bhat=[[0,−g^T D],[g,B]], Dhat=diag(1,D).

Between distinct packet vertices u,v put |eta(γu,γv)| individually colored
arrows, directed u→v when eta(γu,γv)>0. For a directed pair u→v, write
m_uv for this multiplicity and identify its colors with Z/m_uv Z. The
integral skew pairing implies du | m_uv and dv | m_uv.

The finite phase group is

    Gλ= product_(v != 0) Z/dv Z.

For phase s=(sv), with s0=0, its action on an original arrow color is

    c_uv -> c_uv+(m_uv/du) su−(m_uv/dv) sv   (mod m_uv).       (1)

This is a genuine action by permutations of the actual parallel arrows.
It fixes every original vertex, the direction of every arrow, and its pair
of endpoints. In particular it preserves every cut, every tree-flow
inequality, every projected covector and every limiting positive forest.

## 3. A free action on the common signed flagged-tree universe

Take the common signed universe Sλ from
`../cyclic_transport_review/CYCLIC_FLAGGED_TREE_TRANSPORT.md` in the framed
cut chamber: all mutable packet weights are positive and their sum is the
negative framing weight. It consists of an actual spanning tree T together
with a laminar family L of connected nontrivial vertex subsets, subject to
fixed residual-reference conditions on the flagged quotient trees and the
top stable-tree condition. Its sign is (−1)^|L|.

Apply (1) to every arrow of T and leave L unchanged. All conditions remain
valid: stable and residual-reference conditions depend on arrow endpoints
and orientations, not on the parallel-arrow color. Although auxiliary
reference covectors distinguish vertices, the phase action fixes vertices,
so it preserves those reference conditions as well.

The action is free. Indeed, a spanning tree contains at most one arrow on
any given unordered pair of vertices. If a phase fixes the tree, each of
its arrow colors is fixed. Equation (1) says

    su/du = sv/dv  in Q/Z

for every tree edge. Connectedness propagates this fraction from the frame,
where it is zero. Hence every sv is zero in Z/dv Z.

This proof is insensitive to directed cycles of the original packet graph.
The quotient trees may contain opposite arrows, but the phase action keeps
each original pair and its original arrow identity class. Internal graph
contractions in the hierarchy do not cancel opposite arrows.

## 4. An explicit phase gauge without group-orbit enumeration

Root the underlying spanning tree at 0. Fix the framing phase to zero.
Once the phase at a parent has been fixed, choose the phase of its child v
so that the transformed color of their tree edge belongs to

    {0,1,...,m_edge/dv−1}.

The coefficient of sv in (1) is ±m_edge/dv, so exactly one phase modulo dv
does this. Traverse outward from the root. This computes a unique canonical
representative of every orbit, using only integer division and modular
arithmetic. It also records the unique phase taking any given state to its
representative.

The algorithm applies to all arrows of the flagged state at once, because
their union is exactly T and has no repeated arrow. Thus it preserves the
full hierarchy, not only the top quotient tree.

## 5. The positive primitive catalog

Choose one strongly generic rational parameter θ* in the framed chamber.
The previous theorem supplies an explicit involution I_θ* on Sλ, with
positive fixed set the raw colored axis-leaf flow trees. Apply Section 1
to Gλ, Sλ and I_θ*. Define Pλ to be the unmatched positive phase orbits.
Equivalently, retain their canonical representatives from Section 4.

This is a finite input-defined positive catalog of flagged original
spanning trees. Its construction uses arrows, rational cut tests, bounded
cographic Box toggles, a root graft/ungraft operation, modular phase gauges
and augmenting paths in a specified finite graph. It uses no theta
coefficient, no flow-tree count and no prescribed output cardinality.

Its cardinality is the positive primitive flow count Tλ of the earlier
formula. The proof is a numerical identification after the objects have
already been defined:

    |Pλ| = (|Sλ+|−|Sλ−|)/|Gλ|
         = |Fix(I_θ*)| / product_v dv
         = Tλ.                                                   (2)

For the last equality, the primitive factors of every binary flow tree
telescope:

    product_nodes [ |eta(γL,γR)| d(γL+γR)/(d(γL)d(γR)) ]
      = product_nodes |eta(γL,γR)| / product_mutable_packets dv,

because the framed root has primitive degree one. This identity is only
used to compare the new explicit catalog with the old primitive-color
normalization; it is not an algorithm for creating Pλ.

The construction treats skew-symmetric and skew-symmetrizable matrices in
the same way. In the skew-symmetric case the nontrivial phases already
include packet sizes k; in the symmetrizable case they also include Di.

## 6. Coherent transport after primitive descent

Keep the matching involution M* from the fixed reference parameter θ*.
The underlying signed universe and its phase action are literally constant
throughout the framed cut chamber. For any strongly generic θ there, use
the alternating I_θ/M* path to define

    Aθ : raw axis-flow objects at θ -> Fix(M*).

The target is one fixed free Gλ-set. Pulling its action back gives a free
phase action on the raw flow objects at θ. For θ,ψ define

    Φθ,ψ=Aψ^−1 Aθ.

These actual maps are phase-equivariant and satisfy the strict cocycle law.
Their orbit sets all identify with Pλ. Every descendant covector changes
through the previously proved sweep and inverse, rather than being held
fixed during a tree rotation.

This is a global phase descent. The induced phase action need not coincide
with an attempted local shift of primitive color intervals on a fixed
binary shape. The old counterexamples to a termwise geometric phase quotient
are therefore not contradicted or bypassed by an assumption.

## 7. What this does and does not finish

The earlier coefficient identity becomes

    a_g(p) = sum_(λ^i partitions p_i)
       (−1)^(|p|−sum_i length(λ^i)) |Pλ| / product_i z_(λ^i).

Every positive packet count now has a parameter-independent, graph-based
primitive catalog with an explicit phase action and quotient. The remaining
cycle signs and zλ denominators are unchanged. In particular this theorem
does not manufacture a Young-group action having all Pλ as its fixed-point
catalogs. Constructing that action or a simultaneous cycle cancellation is
the next hard interface, still under active investigation.

The freeness of packet phases is essential to the Hall proof. Replacing
Gλ by a clone-permuting Young group is unjustified: its orbits need not have
equal sizes, it can move the reference-parameter data, and the natural
stable-tree permutation character is not the desired cohomology character.

## 8. Verification and novelty status

`phase_orbit_matching.py` implements every new map, including the phase
gauge, the orbit-incidence graph, the saturating matching, its equivariant
lift, and the induced action on raw axis-flow fixed points. It compares the
final primitive count with the separate rational packet recursion solely
as a check, not as a construction input. Compact JSON files retain exact
counts and all test parameters.

The underlying Hall theorem, augmenting paths, and involution principle
are standard. The contribution here is their application to the newly
available free phase action on the full cyclic flagged-tree universe, which
does not require the original cancellation involution to be equivariant.
The phase orbit-incidence method was not found in the primary searches so
far; this is not a proof of historical priority.
