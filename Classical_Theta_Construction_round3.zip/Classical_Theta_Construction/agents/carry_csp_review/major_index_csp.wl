ClearAll[words, maj, local, polynomial, fixed];
words[aa_List, 0, 0] := {{}};
words[aa_List, 0, u_Integer] := {};
words[aa_List, a_Integer, u_Integer] /; u < 0 := {};
words[aa_List, a_Integer, u_Integer] /; a > 0 := words[aa, a, u] =
  Flatten[Table[If[aa[[j]] <= u, Prepend[#, j] & /@ words[aa, a - 1, u - aa[[j]]], {}], {j, Length[aa]}], 1];
maj[w_List] := Total[Table[If[w[[i]] > w[[i + 1]], i, 0], {i, Length[w] - 1}]];
local[aa_, a_, u_] := Total[q^maj[#] & /@ words[aa, a, u]];
polynomial[cc_] := Expand[Times @@ MapThread[local, {cc[[4]], cc[[2]], cc[[3]]}]];
fixed[cc_, d_] := If[And @@ (Divisible[#, d] & /@ Join[cc[[2]], cc[[3]]]),
 Times @@ MapThread[Length[words[#1, #2/d, #3/d]] &, {cc[[4]], cc[[2]], cc[[3]]}], 0];
cases = {
 {2,{2},{2},{{0,2}}},
 {4,{4,6},{2,2},{{0,1},{0,1}}},
 {4,{8,2},{2,1},{{0,1},{0,1}}},
 {6,{6,8},{2,2},{{0,1},{0,1}}},
 {6,{6,3},{3,2},{{0,1},{0,1}}},
 {6,{6,4,6},{2,2,1},{{0,1},{0,1},{0,1}}},
 {6,{6,8},{2,2},{{0,1,1,2},{0,1}}},
 {8,{8,4},{4,2},{{0,1},{0,1}}},
 {9,{9,6},{3,3},{{0,1},{0,1}}},
 {12,{12,6},{6,1},{{0,1},{0,1}}}};
records = Table[With[{pp = polynomial[cc]},
 <|"N" -> cc[[1]], "Size" -> (pp /. q -> 1), "RootChecks" ->
 Table[{d, fixed[cc,d], PolynomialRemainder[pp, Cyclotomic[d,q],q] === fixed[cc,d]}, {d, Divisors[cc[[1]]]}]|>], {cc,cases}];
<|"Cases" -> Length[cases], "Decorations" -> Total[Lookup[records,"Size"]],
"AllPassed" -> And @@ Flatten[#[[All,3]] & /@ Lookup[records,"RootChecks"]],
"Records" -> records|>
