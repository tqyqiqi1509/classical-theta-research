# Local major index for classical theta decorations

Date: 2026-11-13 UTC. Independent reviewer: `carry_csp_review`.

This note supplies a precise auxiliary cyclic sieving refinement of the prefix-carry action. It is a classical combinatorial statistic on the already constructed positive decorations. It is not a quantum theta coefficient, and it does not remove the dependence of the original coefficient model on a scattering representative. The novelty boundary in Section 8 is essential.

## 1. The general finite word statement

Fix an integer N>=1 and stages j=1,...,s. At stage j fix a positively graded alphabet A_j, finite in each degree, with a single letter of degree zero. Only degrees at most the prescribed bend index u_j will be used. A_j can be a family of explicit tight-Dyck objects supplied by the previous coefficient construction; it need not be a set of unexplained numbered colors.

Let the positive word lengths a_j and positive indices u_j satisfy the following triangular divisibility condition:

> For each d dividing N and each stage j, if d divides u_i for every i<j, then d divides a_j.

For example, the condition follows from

    a_j = N b_j + sum_(i<j) c_(j,i) u_i,

with integers b_j,c_(j,i). It is not necessary that these integers be positive. Only the actual word lengths must be positive.

Let Y_j consist of words in A_j of length a_j and total letter degree u_j. Put X=Y_1 x ... x Y_s. Fix any total order on each relevant finite alphabet, and define the ordinary major index

    maj(w_1...w_a) = sum {i: 1<=i<a and w_i>w_(i+1)}.

Define the local polynomial

    M_(a,u,A)(q) = sum_(w in Y_(a,u,A)) q^(maj(w))

and the tuple polynomial

    C_X(q) = product_j M_(a_j,u_j,A_j)(q)
           = sum_((w_1,...,w_s) in X) q^(sum_j maj(w_j)).

The empty tuple has polynomial one. All these polynomials belong to N[q]. Infinite alphabets cause no issue: only finitely many colors and words are relevant at a fixed u.

### Theorem 1

Equip X with the prefix-carry C_N action of `PREFIX_CARRY_CYCLIC_ACTION.md`. For every divisor d of N and every primitive d-th root of unity zeta_d,

    C_X(zeta_d) = |X^(C_d)|
               = product_j |Y_(a_j/d,u_j/d,A_j)|

if every u_j is divisible by d, and the value is zero otherwise. In the product case every a_j is automatically divisible by d. Thus (X,C_N,C_X(q)) exhibits the cyclic sieving phenomenon.

The polynomial is computed from local words before the carry orbits are known. It is therefore more explicit than manufacturing a sieving polynomial from the orbit sizes, although the general root-of-unity reasoning has close predecessors in the existing q-Gauss literature.

## 2. The local root-of-unity lemma

Let A be a finite ordered alphabet with nonnegative integer degrees. For a content vector alpha=(alpha_c)_(c in A), let |alpha|=sum alpha_c. MacMahon's major-index identity is

    sum_(content(w)=alpha) q^(maj(w)) = [|alpha|; alpha]_q.

This is the ordinary q-multinomial coefficient. If d divides a=|alpha|, then

    [a;alpha]_(zeta_d) = (a/d)! / product_c (alpha_c/d)!

when every alpha_c is divisible by d, and the root value is zero otherwise.

One direct proof of the zero statement uses orders of vanishing in the q-factorial formula. The numerator has a/d factors divisible by the cyclotomic polynomial Phi_d. The denominator has sum_c floor(alpha_c/d) such factors. Since sum alpha_c=a, a carry among the residues makes the numerator have strictly higher order unless every alpha_c is divisible by d. When all are divisible, the standard q-Lucas specialization, or cancellation of the zero factors in the factorial quotient, gives the displayed ordinary multinomial. There is no additional sign in this case. The case d=1 is ordinary evaluation at q=1.

Summing over all contents satisfying sum_c degree(c)*alpha_c=u proves

    M_(a,u,A)(zeta_d) = 0                         if d does not divide u,
    M_(a,u,A)(zeta_d) = |Y_(a/d,u/d,A)|            if d divides u,

provided d divides a. This is exactly the number of d-fold repeated words. Letters of equal degree remain distinct in this argument; a repeated word must repeat colors as well as degrees. Missing degrees in an alphabet, such as A={0,2}, also cause no difficulty.

These local facts are established precedents. Useful primary sources are Gossow, arXiv:2410.05678v2, Remark 5.5 and Example 5.6, and Ahlbach–Swanson, arXiv:1706.08631v2, which develops substantially finer word CSP results. We do not claim the local lemma as new.

## 3. Proof of the triangular statement

Fix d|N. If some u_j is not divisible by d, let j be the first such stage. All earlier indices are divisible by d, so the triangular condition gives d|a_j. The local lemma says M_(a_j,u_j,A_j)(zeta_d)=0. Consequently the entire product C_X(zeta_d) is zero, regardless of whether the later a_i are divisible by d.

This last point is the reason one cannot naively apply the local word CSP independently at every stage: a later word length can fail to be a multiple of d. The first failed index already kills the product, so no invalid local specialization is used.

If every u_j is divisible by d, the triangular condition gives d|a_j at all stages. Applying the local lemma stage by stage gives the product of the divided word counts.

The carry fixed-point theorem says that X^(C_d) consists exactly of tuples in which every word is a literal d-fold repetition. Those fixed words have exactly the same product count. This proves Theorem 1.

The same proof works when some Y_j is empty. It then gives the zero polynomial and an empty cyclic set. A straight broken line is the empty list of words and contributes one for every d.

## 4. Application to classical theta coefficients

Work in the full integral principal-coefficient monomial lattice L=M^circ direct-sum N, in an integral basis. In mutable/frozen notation the monomial of root degree p in theta_(Ng) has exponent

    (Ng+Bp,p).

Fix one positive scattering representative, a generic endpoint Q, and a finite output-degree cutoff. Use the same representative and the same local coefficient-object alphabets when comparing all divisors of N. At each geometrically valid broken-line skeleton, write

    m_j = Ng + sum_(i<j) u_i v_i,
    a_j = lambda_j(m_j),

where v_i is a primitive full-lattice direction, lambda_j is an integral normal pairing, and a_j>0. Then

    a_j = N lambda_j(g) + sum_(i<j) lambda_j(v_i) u_i,

so the triangular divisibility condition holds. It also holds for primes dividing the symmetrizer. A nonprimitive wall root is handled by using its primitive full-lattice variable and leaving the unavailable alphabet degrees empty.

For a decorated broken line gamma let

    Maj(gamma) = sum_(bends j) maj(w_j).

Define

    A_(N,g,Q,p)(q) = sum_(gamma contributing to theta_(Ng,Q) at p) q^(Maj(gamma)).

This is a finite nonnegative polynomial at each prescribed p. Its value at one is the theta coefficient a_(Ng,Q)(p). The usual coefficientwise finiteness of broken lines is the only finiteness assertion here; the complete theta Laurent series need not be finite.

### Theorem 2

For each d|N,

    A_(N,g,Q,p)(zeta_d) = a_((N/d)g,Q)(p/d)       if p belongs to d N^n,
    A_(N,g,Q,p)(zeta_d) = 0                      otherwise.

The tuple of all decorated skeletons, equipped with its carry action, and the polynomial A form a CSP triple.

**Proof.** Apply Theorem 1 to each skeleton and sum. A nonzero root contribution requires all bend indices to be divisible by d. Dividing all full segment exponents and all bend indices by d produces an integral lower skeleton with the same geometric image after reparametrization. Conversely every lower decorated skeleton gives an upper one by repeating each local word d times. The primitive-direction convention guarantees exact divisibility of the bend indices. The output degree becomes p/d. The divided word counts in Theorem 1 are exactly the lower broken-line multiplicities. This proves the displayed equality.

For the no-bend contribution, p=0 and both sides equal one. Thus zero degree is included without an exception.

### Structure constants

The same construction applies to the tuples of broken lines counting c_(N g_1,...,N g_r)(p). Concatenate their local word lists in a fixed input-factor order, while preserving chronology inside each line. At the start of every component its initial exponent is N g_i. Hence divisibility of all preceding bend indices again implies divisibility of the next local word length; bends in another component simply have coefficient zero in its pairing formula.

The endpoint must be chosen sufficiently close to the output full label, as in GHKK's multiplication rule. For a divisor d, divide that endpoint and the output label by d. Homogeneity of cluster scattering walls identifies the corresponding lower and upper geometric data. The result is

    A_(N, g_tuple, p)^mult(zeta_d)
       = c_((N/d) g_tuple)(p/d)

when p is divisible by d, and zero otherwise. No arbitrary fixed-chamber extraction of structure constants is asserted.

## 5. Exact q-Gauss congruence

For fixed g and Q the family indexed by (N,p) satisfies the standard ranked-semigroup q-Gauss congruence:

    sum_(d | gcd(N,p)) mu(d) A_(N/d,g,Q,p/d)(q^d)
       is divisible by [N]_q in Z[q].

Here gcd(N,p) means gcd(N,p_1,...,p_n), including gcd(N,0)=N. This follows from Theorem 2 and the root-evaluation criterion, Proposition 4.2 of Gossow. Equivalently, one can check divisibility by every cyclotomic factor Phi_e(q) with e|N and e>1, pairing Möbius terms at a prime factor of e.

The analogous statement holds for the multiplication family. At q=1 the statement recovers ordinary Gauss congruences, but the actual major-index definition gives a positive polynomial refinement before specialization.

**No positivity claim is made for the quotient by [N]_q.** Nonnegative coefficients of A and integer divisibility of its Möbius combination do not imply this stronger statement.

## 6. Which choices remain visible?

The carry permutation on the original tuple set depends on the total orders used to select lexicographic prefix representatives. The major-index polynomial, however, does not depend on those orders. For each fixed content its generating polynomial is the q-multinomial, symmetric in the content multiplicities. Permuting the order on the alphabet leaves the sum over all allowed contents unchanged. It depends only on the graded alphabet cardinalities, and hence on the local positive wall functions for the chosen skeleton.

Changing the positive scattering representative, the splitting into local wall alphabets, or the skeleton decomposition can change the full polynomial A. No invariance of the unreduced polynomial has been established.

There is an exact weaker invariance. Two such polynomials computing the same theta coefficient have identical values at every N-th root of unity, since all those values are determined by the lower-scale theta coefficients in Theorem 2. Their difference is divisible by q^N-1 in Z[q]. Thus

    A_(N,g,Q,p)(q) modulo (q^N-1)

is independent of these auxiliary realizations, once the seed-chart coefficient is fixed. The residue has nonnegative coefficients: reduce a nonnegative polynomial by replacing each exponent by its residue modulo N.

This residue is not extra information beyond the collection of divisor-scale coefficients. In fact, the standard Fourier/Ramanujan formula recovers it from those values, as in Gossow Theorem 4.16. The explicit local statistic is the additional constructive input here.

The complex permutation representation of C_N furnished by the carry action likewise has a choice-independent isomorphism class, because its character is determined by those fixed counts. This is an abstract representation-theoretic consequence, not a canonical bijection between different scattering realizations. It does not solve the missing high-rank associator.

## 7. Independent calculations

`major_index_csp.py` computes local major-index distributions by dynamic programming, multiplies them, and takes exact remainders modulo every relevant cyclotomic polynomial. It imports no theta coefficient engine. It uses the existing carry permutation only for a separate comparison on its ten explicit finite datasets.

Results:

- 190 triangular word datasets;
- 633 exact root-value checks;
- 10,660 actual decorations independently compared with the carry permutation;
- the dynamic-programming tables count 70,521,409,365 decorations in total, without enumerating that many points;
- zero failures.

The data include nonprimitive alphabet degrees, repeated colors of the same degree, prime-power and composite N, negative coefficients in the triangular length formulas, and later word lengths not divisible by the subgroup order. These test the arithmetic mechanism; synthetic data are not asserted to all occur as cluster skeletons.

The independent Wolfram implementation in `major_index_csp.wl` explicitly constructs the local word sets for all ten carry benchmarks and verifies their cyclotomic remainders. It returns all checks true for the same 10,660 decorations. Its exact tool receipt is preserved.

## 8. Novelty assessment

The local q-multinomial CSP, the major-index identity, q-Gauss root criteria, cyclic subgroup inversion, Ramanujan formulas, and the abstract notion of a Lyndon structure are established mathematics. In particular, Gossow's Lemmas 4.9 and 4.10 already give prefix and suffix chaining operations, and Example 5.6 treats weighted compositions. The first-failed-index proof above is closely related to these chaining proofs. Calling it a new general CSP principle would be misleading.

The possible new contribution is its explicit realization on theta broken-line decorations with varying normal-pairing word lengths, together with the literal-repetition-compatible carry action and the resulting all-prime-power theta consequences. The polynomial is an auxiliary statistic of that realization. A focused search did not locate this theta application, but this is not an absolute priority statement.

Existing cluster CSP results must also be distinguished. Shen–Weng, *Cyclic Sieving and Cluster Duality of Grassmannian*, SIGMA 16 (2020), 067, uses the theta basis and a cluster modular group action on labels/plane partitions. That is not the dilation-size C_N action inside a fixed Laurent coefficient studied here. Both are legitimate cluster/theta CSP settings; it would be false to call the present construction the first connection between theta bases and cyclic sieving.

Sources read and used:

- Fern Gossow, arXiv:2410.05678v2, revised 2024-12-22, especially §§4.1, 5, 6 and the corresponding proofs in §9: https://arxiv.org/html/2410.05678v2 .
- Connor Ahlbach and Joshua Swanson, arXiv:1706.08631v2, *Refined Cyclic Sieving on Words for the Major Index Statistic*: https://arxiv.org/abs/1706.08631 .
- Linhui Shen and Daping Weng, SIGMA 16 (2020), 067: https://sigma-journal.com/2020/067/ . Used for the prior-art distinction, not as an input to the proof above.

