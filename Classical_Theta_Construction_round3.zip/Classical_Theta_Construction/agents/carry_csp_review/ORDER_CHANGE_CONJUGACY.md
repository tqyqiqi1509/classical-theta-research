# Changing the alphabet order: explicit compatible conjugacies

Date: 2026-11-13 UTC. The question was suggested by `intrinsic_greedy_round2`; the formula and proof below were independently checked by `carry_csp_review`.

Keep the same geometric skeletons and the same actual alphabet sets. Change only their total orders, hence the lexicographic representatives used by the prefix-carry construction. Write T_N and T'_N for the two actions on the same finite tuple set.

## Theorem

There is an explicit bijection Phi_N on the tuple set such that

    Phi_N T_N = T'_N Phi_N,
    Phi_N E_e = E_e Phi_(N/e)

for every applicable repetition map E_e. The construction is recursive in the number of word stages and uses only prefix orbit phases and rotations of the next word. It does not match points by sorting their full ranks or use equality of cardinalities as a substitute for a map.

## Recursive formula

Assume Phi has been constructed on prefixes and intertwines the old and new prefix actions. Let

    x_k = T^k x_0,       0<=k<r,

be an old prefix orbit, written from its old lexicographic representative. Its size r divides N. Put d=N/r and L=a_j/d, which is an integer by the existing carry induction.

The image prefix orbit also has size r. Let y_0 be its new lexicographic representative and let s be the unique integer 0<=s<r such that

    Phi(x_0) = (T')^s y_0.

For the next word w define

    Phi_new(x_k,w)
       = (Phi(x_k), rho_( L floor((s+k)/r) )(w)),             (1)

where rho_l is left rotation by l places. The exponent floor((s+k)/r) is zero or one. Start with the identity map on the empty prefix.

## Proof of conjugacy

On each fibre, formula (1) is a rotation, so it is bijective. For an old non-wrap step k<r-1, the increment

    floor((s+k+1)/r) - floor((s+k)/r)

is one exactly when the corresponding new prefix phase wraps. Thus the rotation inserted by the map compensates exactly for the difference of wrap positions.

At the old wrap k=r-1, the old action rotates w by L. On the new side, either s=0 and the new prefix wraps at the same step, or s>0 and the map has already inserted one rotation before that step. In both cases the total rotation after comparing the two routes is L. Therefore Phi_new T=T' Phi_new at every point.

This proves the conjugacy induction. Empty decoration sets are covered by the unique empty map.

## Proof of repetition compatibility

Suppose e divides N and all indices, so the divided skeleton exists. By the inductive repetition compatibility, corresponding prefix orbits upstairs and downstairs have equal length r, and their points correspond under E_e. Repetition preserves lexicographic order separately for each of the two chosen alphabet orders. Hence both their old representatives and their new representatives correspond. The phase s is consequently the same upstairs and downstairs.

Their wrap rotation lengths also agree:

    a_j/(N/r) = (a_j/e)/((N/e)/r).

Finally, rotating a repeated word by a fixed number of places equals repeating the rotated shorter word. Applying this to formula (1) proves Phi_N E_e=E_e Phi_(N/e). The induction begins at the empty prefix, so it holds at all stages and all divisors simultaneously.

## Coherent changes of order

The direct formula (1), independently applied to every ordered pair of total orders with 0<=s<r, need not satisfy strict three-order composition. It chooses representatives of phases modulo r, and the missing full-turn carry can produce an additional word rotation. In particular, the directly constructed reverse map need not be the inverse of the forward map. This does not affect the theorem, which asserts an explicit conjugacy.

If a coherent family is wanted, fix one reference order o_0. Let F_o be the conjugacy from o_0 to o constructed above. Define

    Phi_(o -> o') = F_(o') (F_o)^(-1).

These maps are explicit, commute with every repetition map, are actual inverses for reversed pairs, and obey

    Phi_(o' -> o'') Phi_(o -> o') = Phi_(o -> o'').

Thus changing the alphabet order changes the cyclic realization only up to a fully specified divisor-compatible isomorphism, with a coherent system after choosing a reference order.

This is naturality with respect to order choices within one fixed skeleton/alphabet realization. It is not a wall-refinement associator, endpoint-transport correspondence, or mutation-equivariant isomorphism. No connection between distinct global scattering schedules is established here.

## Exact computation

`order_conjugacy.py` independently reconstructs the carry actions for different total orders and implements formula (1). On 11 finite datasets it verifies:

- 14,440 points satisfy exact permutation conjugacy;
- 303 of the displayed bijections are nonidentity on points;
- 14,536 literal repetition-equivariance identities;
- 14,440 reference-based cocycle identities;
- zero failures.

The tests include repeated same-degree colors and nonprimitive degree alphabets. The proof uses the general triangular divisibility property, not the test datasets.

## Concrete tight-Dyck alphabets used here

The previous package gives an actual finite alphabet for every required local coefficient. Its exact interface is:

- `proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md`, Sections 1–3;
- `computations/tight_grading_two_input.py`, especially `valued_profiles`;
- global use in `computations/valued_event_flag_grammar.py`;
- assembly explanation in `agents/valued_global_assembly.md`, Section 2.1.

These files are in the recovered package `history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/` in the current research workspace. They are prior work, not new statements of this review.

For clarity, the local alphabet is obtained as follows. Given input carriers alpha,beta, integral alternating pairing m>0, and primitive-normal weights d=w(alpha), e=w(beta), put u=m/d and v=m/e. For a coprime output pair (a,b), let

    ell=gcd(a v,b u),  A=a v/ell,  B=b u/ell,
    c=m w(a alpha+b beta)/(ell d e)
      =w(a alpha+b beta)/gcd(a d,b e).

The previously checked normal conversion proves c is a positive integer. At coefficient degree j, take the maximal Dyck path to the deterministic rectangle (r,s) with

    A s-B r=1,   r>=j a v,   s>=j b u.

Its bounded nonnegative edge gradings obey the explicit compatibility and tight-shadow interval comparisons, with vertical weights divisible by v and horizontal weights divisible by u. Positive edges carry actual recursively supplied input objects. The coefficient letter for degree k is an ordered c-tuple of such decorated gradings whose degrees sum to k. Degree zero is the unique empty letter.

Each such complete tuple is one letter in the carry/CSP word. The cyclic action rotates whole letters; it never redefines a letter as an integer chosen from a set of size equal to an unknown theta coefficient. Thus the action and the order-change conjugacy remain genuine algorithms on the earlier explicit combinatorial encodings. The BLM rank-two tight-grading identity remains the cited established input behind their coefficient interpretation.

