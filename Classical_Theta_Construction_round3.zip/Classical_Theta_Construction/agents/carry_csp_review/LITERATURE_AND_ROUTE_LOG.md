# Literature and route log: carry / major-index / pre-lambda review

Research date: 2026-11-13 UTC. This is a mathematical research log, not a claim of completeness of bibliographic coverage.

## Sources and decisions

| Source | Material actually checked | Decision |
|---|---|---|
| Gossow, arXiv:2410.05678v2, revised 2024-12-22 | Official metadata; full PDF downloaded; §§4.1, 5, 6; §9 proofs of prefix/suffix chaining and q-multinomial specialization | Useful and adopted for established q-Gauss/CSP facts. Direct close prior art for the abstract major-index argument. No cluster/scattering occurrence found in the text. |
| Ahlbach–Swanson, arXiv:1706.08631v2 | Official metadata/abstract and PDF; introduction and fixed-content major-index statement | Useful prior art. Existing word CSP is considerably more refined locally. No claim of novelty for local word statistic. |
| Shen–Weng, SIGMA 16 (2020), 067 / arXiv:1803.06901 | Official journal abstract, scope, references; indexed theorem excerpts about theta-basis equivariance | Useful novelty correction: theta bases already appear in cyclic sieving. Their action concerns Grassmannian labels/plane partitions, not dilation inside one coefficient. Not used as an input theorem here. |
| Mandel, arXiv:1503.06183v5, Thm 4.2 | Relevant statement/proof already recovered in the parent; checked against the Gauss note | Known prime-modulus overlap. Do not call all Gauss congruences new without noting this. |
| 2026-03-30 cluster-complex parabolic-face CSP item | Search metadata/abstract only | Nearby topic but different finite Coxeter face sets. Not used; no mathematical correctness judgment made from metadata. |
| 2026 search hits on classical Jacobi theta, modular lambda, quantum generalized cluster algebras, unrelated physics | Metadata only | Irrelevant to the stated classical cluster problem. Not adopted. The word theta creates severe search noise. |

## Queries

Search engines were both used. Main query families:

- cyclic sieving iterated words / Lyndon structures / Gauss congruence;
- theta + cyclic sieving + cluster;
- theta functions + Gauss congruences / Dold;
- scattering diagrams + necklaces / Gauss congruence;
- cluster theta + symmetric powers / pre-lambda / Adams operations.

These searches found strong general combinatorial precedents and the Grassmannian theta-CSP connection. They did not locate the exact positive prime-power/carry theorem for arbitrary classical cluster theta coefficients. That absence is a bounded search result, not proof of priority.

## Route outcomes

1. **Carry action review: passed.** The changing stabilizer gives exactly the required divisor of the next word length. Repetition equivariance is valid with common alphabets and lexicographic representatives.
2. **Local-major-index CSP: proved.** The first bend index not divisible by d kills the corresponding q-multinomial factor; if none fails, all factors divide and count repeated words.
3. **Naively applying local CSP to every stage: rejected as a proof shortcut.** Later word lengths need not be divisible by d. The first-failure argument resolves this rather than assuming the missing divisibility.
4. **Full q-polynomial invariance under wall changes: not proved.** Only its residue modulo q^N-1 is determined by theta coefficients. No quantum interpretation is claimed.
5. **Alphabet-order dependence: refined.** The action depends on order, while the major-index polynomial does not, by the symmetric content formula.
6. **Pre-lambda review: passed with existing principal hypotheses.** The finite minimal-head subtraction argument justifies theta-integrality. No special-lambda or quotient-specialization assertion follows.
7. **General CSP novelty: narrowed.** Gossow's chaining results cover much of the abstract arithmetic. The theta application must carry the novelty burden.
8. **Changing alphabet order: solved within a fixed realization.** Explicit recursive prefix-phase/word-rotation conjugacies commute with all divisor repetition maps. A coherent system follows by passing through one reference order. Direct pairwise phase formulas must not be assumed to compose strictly. This does not solve the inter-schedule associator.

## Computation record

Python dynamic programming: 190 triangular word datasets, 633 exact cyclotomic checks, zero failures. Exact carry comparison: 10,660 points. The summed DP cardinality is 70,521,409,365; this is not a claim of enumerating every point.

Wolfram Language: ten independent local-word enumerations, 10,660 points in total, exact cyclotomic remainder checks all true. Code and returned receipt are saved beside this log.

Order conjugacy: 11 datasets, 14,440 permutation checks, 14,536 repetition checks and 14,440 coherent-reference cocycle checks; zero failures.

## Retrieval references for the parent

The parent must reopen sources before using these web IDs in its final citations:

- Gossow official HTML: `turn161view0`; root criteria/chaining: `turn167view1`; q-multinomial and Lyndon structure: `turn167view2`; official date metadata: `turn175view0`.
- Ahlbach–Swanson official record: `turn161view1`.
- Shen–Weng official journal page: `turn161view2`.
- Literature searches including 2026 cluster-complex hit: `turn185search2` (metadata only, not a proof input).

