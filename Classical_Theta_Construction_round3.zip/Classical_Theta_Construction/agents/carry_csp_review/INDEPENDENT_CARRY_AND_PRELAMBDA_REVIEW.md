# Independent review of the carry action and positive pre-lambda operations

Date: 2026-11-13 UTC. Reviewer: `carry_csp_review`.

## Verdict

I found no mathematical gap in the prefix-carry construction, its exact fixed-point description, or its divisor-compatible repetition maps, under its explicitly stated full integral lattice and common positive scattering representative conventions. The classical principal-coefficient statement includes skew-symmetrizable seeds. I also found no gap in the integral positive pre-lambda construction on the principal middle algebra, assuming the established positive theta multiplication and the reviewed carry/Möbius theorem.

This verdict does not imply a new intrinsic scattering-independent theta object model, a quantum refinement, a special lambda-ring structure, or a proof of minimal strong positivity. Those are not consequences of this argument.

## 1. Carry induction

For a prefix orbit O of length r|N, put d=N/r. Its points have stabilizer C_d, so the induction hypothesis says their existing words are d-fold repetitions. Hence all previous bend indices are divisible by d. Pairing the resulting exponent with the integral next normal proves d|a_j.

The rule advancing the prefix and rotating the next word by a_j/d at a phase wrap is a permutation. After N=rd steps the new word rotates by a_j positions, so its order divides N. No cardinality divisibility assumption is inserted at this point.

For e|N, a point in this prefix orbit can be fixed by T^(N/e) only if r divides N/e, equivalently e|d. In that case precisely d/e wraps occur, from any starting phase, and the next word rotates by a_j/e. Its fixed words are exactly e repetitions. This proves the claimed fixed-point set as an equality of finite sets, not merely of cardinalities.

The arithmetic does not depend on any coprimality between e and the skew-symmetrizer. It depends on working in the integral principal lattice, which the note does explicitly.

## 2. Divisor maps

For the divided skeleton, all word lengths and indices are divided by e. Corresponding prefix orbits have the same size r because the existing repetition map is injective and equivariant. Repeating equal-length words preserves their lexicographic order, so the selected representatives and all their phases agree under repetition. The wrap rotation amount is identical on the two sides:

    a_j/(N/r) = (a_j/e)/((N/e)/r).

Rotation by this common amount commutes with repetition. This completes the induction proving T_N E_e=E_e T_(N/e). Literal repetition also proves E_e E_f=E_(ef) whenever defined.

One must preserve the same local coefficient alphabets and their order under division. The common-data convention in the reviewed note supplies this. Arbitrarily recoding or recomputing lower-degree alphabets in unrelated orders would invalidate the displayed equality of maps, even though fixed counts would remain correct.

## 3. Geometry and full principal labels

A fixed decoration has every local word repeated e times, hence every u_j is divisible by e. Dividing the full segment exponents then preserves integrality at each step. The skeleton is divided in lattice velocities while its geometric image and endpoint remain fixed after time reparametrization. The primitive full-lattice direction ensures that division of increments and division of the integer u_j agree exactly.

Using only mutable exponents would be insufficient when B has a kernel. In the full exponent (Ng+Bp,p), the frozen component determines the root degree and detects its divisibility. The reviewed note uses this full lattice throughout.

For structure constants, the common endpoint must be near the output label and must be radially compared with its divided output. The carry action is valid on concatenated path lists, and cluster scattering homogeneity justifies the endpoint scaling. The warning in the source note about arbitrary endpoints is mathematically necessary and correct.

## 4. Positivity and the pre-lambda construction

The new cyclic action shows that

    K_(N,g) = (1/N) sum_(d|N) mu(d) psi_d(theta_((N/d)g))

has nonnegative integer coefficients in each seed chart: its coefficients count free C_N orbits. The chartwise psi_d operation must remain distinct from the intrinsic additive map Psi_d(theta_g)=theta_(dg).

The formal identity

    exp(sum_(n>=1) theta_(ng) T^n/n)
      = product_(k,m) (1-Z^m T^k)^(-[Z^m]K_(k,g))

is ordinary Möbius inversion and is correct in the T-adic/positive-root completion. At a fixed T-degree and root degree there are finitely many relevant factors. Its nonnegative exponents prove chartwise integral nonnegative coefficients.

For a regular theta label g, each fixed T-coefficient is a finite rational polynomial in regular theta functions, so it lies in the rational middle algebra and has a finite rational nonnegative theta expansion. The passage from integral Laurent coefficients to integral theta coefficients deserves an explicit argument, but it is valid:

1. Take the finite set of theta heads appearing in the expansion.
2. Choose one minimal under addition of the sharp principal positive-root monoid.
3. At its head monomial, no other remaining theta head contributes; its leading coefficient is one.
4. Its rational theta coefficient is therefore an integer.
5. Subtract that integral theta term and repeat on the finite set.

This proves integrality without assuming B has full mutable rank. Full principal injectivity and sharpness are the relevant inputs.

The additive maps Psi_n preserve the regular theta basis because positive integer dilation preserves regularity. Tropical mutation is positively homogeneous, so the definition on tropical labels is intrinsic. They satisfy Psi_m Psi_n=Psi_(mn), and the positive integral complete-symmetric series extends multiplicatively with respect to addition to all finite integer theta combinations. This gives the stated pre-lambda structure.

The failure of multiplicativity in the rank-one relation xx'=1+y is correct:

    Psi_n(xx')=1+y^n,
    Psi_n(x)Psi_n(x')=(1+y)^n.

Thus it is not a special lambda ring, and ordinary special-lambda identities are unavailable. Specializing coefficients also requires checking stability of the specialization kernel before transporting the intrinsic operations; merely specializing each positive identity does not prove a quotient pre-lambda structure.

## 5. Theta-order and Newton bounds

For the cycle-index polynomial H_(N,g), every partition product has theta_(Ng) with coefficient one and has only nonnegative rational theta coefficients. The cycle-index weights sum to one, yielding theta_(Ng) <=_theta H_(N,g). Replacing each theta_(kg) by its positive domination theta_g^k gives H_(N,g) <=_theta theta_g^N. Integrality already proved makes the two differences integral as well.

The Newton equality uses the already known dilation identity Newt(theta_(Ng))=N Newt(theta_g), identified in CMMM Lemma 2.9. It is not an independent new Newton theorem. For a positive finite theta combination f, the f^N/N! term supplies all extreme monomials of N Newt(f); all other cycle-index terms lie inside that polytope. Positivity prevents cancellation. Thus the generalized Newton statement in the parent's note is valid with its stated hypotheses.

## 6. Useful refinement and novelty correction

`MAJOR_INDEX_CYCLIC_SIEVING.md` proves an explicit auxiliary CSP using the sum of ordinary local major indices. It also records that the whole polynomial is independent of local alphabet order and that its residue modulo q^N-1 is fixed by the theta divisor-scale coefficients.

The strongest close predecessor newly identified in this review is Gossow's prefix/suffix chaining, Lemmas 4.9–4.10 of arXiv:2410.05678v2. The proof by the first failed divisibility index is closely related to that established mechanism. The review therefore narrows the novelty claim to the specific theta realization and its compatible changing-length carry action, not a general new CSP or necklace formalism.

