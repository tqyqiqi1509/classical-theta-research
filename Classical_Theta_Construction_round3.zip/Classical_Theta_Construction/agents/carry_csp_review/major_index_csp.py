"""Independent exact checks of local-major-index theta-decoration CSP.

Only the generic triangular word mechanism is tested here. Synthetic skeletons
are not asserted to occur in any particular cluster scattering diagram. The
proof for theta uses its integral normal pairing, not these finite samples.

No theta coefficient engine is imported. Major-index distributions are computed
by dynamic programming; root evaluations are integer polynomial remainders.
"""
from collections import Counter, defaultdict
from functools import lru_cache
from math import prod
from pathlib import Path
import importlib.util
import json
import random
import sympy as sp

Q = sp.Symbol("q")


def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]


@lru_cache(None)
def major_distribution(degrees, length, weight):
    """Return tuple (major index, number) for words of prescribed weight."""
    if weight < 0 or length < 0:
        return ()
    if length == 0:
        return ((0, 1),) if weight == 0 else ()
    # Keys (last letter, total degree, major index). At position i+1, a
    # descent from position i to i+1 adds i to the major index.
    states = {(letter, degree, 0): 1
              for letter, degree in enumerate(degrees) if degree <= weight}
    for i in range(1, length):
        new = defaultdict(int)
        for (last, degree, maj), count in states.items():
            for letter, delta in enumerate(degrees):
                if degree + delta <= weight:
                    new[letter, degree + delta, maj + (i if last > letter else 0)] += count
        states = new
    result = Counter()
    for (_, degree, maj), count in states.items():
        if degree == weight:
            result[maj] += count
    return tuple(sorted(result.items()))


def multiply(a, b):
    ans = Counter()
    for i, x in a.items():
        for j, y in b.items():
            ans[i + j] += x * y
    return ans


def stage_polynomial(lengths, weights, alphabets):
    ans = Counter({0: 1})
    for a, u, alphabet in zip(lengths, weights, alphabets):
        ans = multiply(ans, dict(major_distribution(tuple(alphabet), a, u)))
    return ans


def poly_from_counter(a):
    return sp.Poly.from_dict({(i,): v for i, v in a.items()}, Q, domain=sp.ZZ)


def expected_fixed(lengths, weights, alphabets, d):
    if any(u % d for u in weights) or any(a % d for a in lengths):
        return 0
    return prod(sum(v for _, v in major_distribution(tuple(alphabet), a // d, u // d))
                for a, u, alphabet in zip(lengths, weights, alphabets))


def check_case(n, lengths, weights, alphabets, use_action=False):
    counts = stage_polynomial(lengths, weights, alphabets)
    polynomial = poly_from_counter(counts)
    fixed = {}
    for d in divisors(n):
        value = expected_fixed(lengths, weights, alphabets, d)
        remainder = polynomial.rem(sp.Poly(sp.cyclotomic_poly(d, Q), Q, domain=sp.ZZ))
        assert remainder == sp.Poly(value, Q), (n, lengths, weights, alphabets, d, remainder, value)
        fixed[d] = value
    action_size = 0
    if use_action:
        action, _ = CARRY.carry_action(n, lengths, weights, alphabets)
        action_size = len(action)
        explicit = Counter(sum(sum(i for i in range(1, len(word)) if word[i-1] > word[i])
                               for word in point) for point in action)
        assert explicit == counts
        for d, value in fixed.items():
            assert sum(CARRY.iterate(action, point, n // d) == point for point in action) == value
    return {"N": n, "lengths": lengths, "weights": weights,
            "alphabet_degrees": alphabets, "decorations": sum(counts.values()),
            "polynomial_degree": polynomial.degree() if counts else -1,
            "fixed_counts": fixed, "action_points": action_size,
            "polynomial": dict(sorted(counts.items()))}


def generated_cases():
    rng = random.Random(20261113)
    alphabets = [(0, 1), (0, 2), (0, 1, 1), (0, 1, 2), (0, 2, 3), (0, 1, 1, 2)]
    for _ in range(180):
        n = rng.choice([2, 3, 4, 5, 6, 8, 9, 10, 12])
        stages = rng.randint(1, 4)
        weights = [rng.randint(1, 4) for j in range(stages)]
        lengths = []
        for j in range(stages):
            # This is exactly the arithmetic form supplied by normal pairings.
            a = n * rng.choice([1, 1, 2]) + sum(rng.randint(-1, 1)*weights[i] for i in range(j))
            if a <= 0:
                a += n * ((-a) // n + 1)
            lengths.append(a)
        yield n, lengths, weights, [list(rng.choice(alphabets)) for j in range(stages)]


if __name__ == "__main__":
    carry_path = Path(__file__).resolve().parents[1] / "gauss_adversarial/carry_action.py"
    spec = importlib.util.spec_from_file_location("existing_carry", carry_path)
    CARRY = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(CARRY)
    results = [check_case(*case, use_action=True) for case in CARRY.CASES]
    results += [check_case(*case) for case in generated_cases()]
    output = {"scope": "local-major-index CSP; exact cyclotomic remainders",
              "case_count": len(results),
              "root_evaluations": sum(len(r["fixed_counts"]) for r in results),
              "decorations_counted": sum(r["decorations"] for r in results),
              "actual_action_points": sum(r["action_points"] for r in results),
              "failures": 0,
              "results": results}
    Path(__file__).with_name("major_index_csp_results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({k:v for k,v in output.items() if k != "results"}, indent=2))
