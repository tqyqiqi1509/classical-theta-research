"""Explicit carry conjugacies for different alphabet orders.

The formula constructs a scale-compatible isomorphism, not a canonical map
between arbitrary wall factorizations. The coherent system is formed through
one reference order, with actual inverses, rather than assuming that direct
pairwise formulas compose strictly.
"""
from pathlib import Path
from collections import Counter
import importlib.util
import json

carry_path = Path(__file__).resolve().parents[1] / "gauss_adversarial/carry_action.py"
spec = importlib.util.spec_from_file_location("carry", carry_path)
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)


def point_key(point, orders):
    return tuple(tuple(orders[j][letter] for letter in word) for j, word in enumerate(point))


def orbits(action, orders):
    unseen = set(action)
    ans = []
    while unseen:
        base = min(unseen, key=lambda p: point_key(p, orders))
        orbit = [base]
        x = action[base]
        while x != base:
            orbit.append(x)
            x = action[x]
        unseen.difference_update(orbit)
        ans.append(orbit)
    return ans


def carry_step(n, previous, length, weight, alphabet, orders):
    action = {}
    for orbit in orbits(previous, orders):
        r = len(orbit)
        d = n // r
        assert n % r == 0 and length % d == 0
        shift = length // d
        for k, prefix in enumerate(orbit):
            for word in C.words(tuple(alphabet), length, weight):
                action[prefix + (word,)] = orbit[(k + 1) % r] + (
                    C.rotate(word, shift) if k == r - 1 else word,)
    return action


def conjugacy(n, lengths, weights, alphabets, old_orders, new_orders):
    old = new = {(): ()}
    phi = {(): ()}
    for j, (length, weight, alphabet) in enumerate(zip(lengths, weights, alphabets)):
        old_next = carry_step(n, old, length, weight, alphabet, old_orders)
        new_next = carry_step(n, new, length, weight, alphabet, new_orders)
        next_phi = {}
        target_phase = {}
        for target_orbit in orbits(new, new_orders):
            for k, point in enumerate(target_orbit):
                target_phase[point] = k
        for orbit in orbits(old, old_orders):
            r = len(orbit)
            d = n // r
            shift = length // d
            s = target_phase[phi[orbit[0]]]
            for k, prefix in enumerate(orbit):
                amount = shift * ((s + k) // r)
                for word in C.words(tuple(alphabet), length, weight):
                    next_phi[prefix + (word,)] = phi[prefix] + (C.rotate(word, amount),)
        assert set(next_phi) == set(old_next)
        assert set(next_phi.values()) == set(new_next)
        assert all(next_phi[old_next[x]] == new_next[next_phi[x]] for x in old_next)
        old, new, phi = old_next, new_next, next_phi
    return old, new, phi


def verify_case(case):
    n, lengths, weights, alphabets = case
    first = [list(range(len(a))) for a in alphabets]
    second = [list(reversed(range(len(a)))) for a in alphabets]
    third = [[(i+1) % len(a) for i in range(len(a))] for a in alphabets]
    old, new, phi = conjugacy(*case, first, second)
    equivariance = 0
    for e in C.divisors(n):
        if any(a % e for a in lengths) or any(u % e for u in weights):
            continue
        lower_case = (n // e, [a // e for a in lengths], [u // e for u in weights], alphabets)
        _, _, lower = conjugacy(*lower_case, first, second)
        for point in lower:
            assert phi[C.repeat(point, e)] == C.repeat(lower[point], e)
            equivariance += 1
    # Reference construction: C(first->second) and C(first->third) determine
    # C(second->third) by actual inverse, so every cocycle law holds literally.
    _, third_action, phi13 = conjugacy(*case, first, third)
    inverse12 = {v:k for k,v in phi.items()}
    phi23 = {y: phi13[inverse12[y]] for y in new}
    assert all(phi23[new[y]] == third_action[phi23[y]] for y in new)
    assert all(phi23[phi[x]] == phi13[x] for x in old)
    return {"N": n, "lengths": lengths, "weights": weights,
            "alphabet_degrees": alphabets, "points": len(phi),
            "nonidentity_points": sum(x != y for x,y in phi.items()),
            "repetition_equivariance_checks": equivariance,
            "coherent_reference_cocycle_checks": len(phi), "all_passed": True}


if __name__ == "__main__":
    cases = C.CASES + [(6, [6,8], [2,2], [[0,1,1,1],[0,1]])]
    results = [verify_case(case) for case in cases]
    output = {"case_count": len(results), "point_count": sum(r["points"] for r in results),
              "nonidentity_points": sum(r["nonidentity_points"] for r in results),
              "repetition_checks": sum(r["repetition_equivariance_checks"] for r in results),
              "coherent_cocycle_checks": sum(r["coherent_reference_cocycle_checks"] for r in results),
              "failures": 0, "results": results}
    Path(__file__).with_name("order_conjugacy_results.json").write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps({k:v for k,v in output.items() if k != "results"}, indent=2))
