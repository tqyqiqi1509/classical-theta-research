# Fixed-exchange-matrix rays have positive binomial coefficients

Independent check of the root agent's proposed mechanism,
2026-11-13 UTC. Classical skew-symmetrizable cluster algebras only.
The exchange matrix is fixed throughout. This is not the earlier
replication statement that also scales the exchange matrix.

## 1. Statement

Use the notation of `POLYTOPAL_STABLE_LOG_THEOREM.md` and
`../stable_adversarial/TRANSVERSE_RAY_THEOREM.md`. Fix integral labels
`g,h`, a finite downward root set `J`, and an integer

\[
 N_0>T_J(g;h)
  =\max\left(\{0\}\cup
     \left\{\frac{|(h+Bs)^TDa|}{|g^TDa|}:
       s\in J,\ 0<a\le s,\ g^TDa\ne0\right\}\right).
\]

For each `p in J`, define

\[
 A_p(k)=[z^p]F_{(N_0+k)g+h}(z),\qquad k\in\mathbb N.
\]

There are finite sets `C_{p,j}`, independent of `k`, such that

\[
 \boxed{A_p(k)=\sum_{j=0}^{|p|}|C_{p,j}|\binom{k}{j}.} \tag{1.1}
\]

In particular every forward difference of `A_p(k)` is nonnegative
for every `k>=0`. The coefficients of its binomial expansion based at
`N_0` are nonnegative integers, and its degree is at most `|p|`.
For `h=0` one may take the uniform label-independent start
`N_0=floor(Md^2/4)+1` when `J subseteq {|p|<=d}`.

These nonnegative integers also have a compact algebraic formula:

\[
 |C_{p,j}|=[z^p]\left(F_{N_0g+h}(z)(H_g(z)-1)^j\right)
              =\Delta_k^j A_p(0).                    \tag{1.2}
\]

Indeed, stable-ray factorization gives
`F_{(N_0+k)g+h}=F_{N_0g+h}H_g^k` in `R_J`, and the ordinary
binomial theorem gives (1.2). The positivity of (1.2) is the content
of the copy construction below; it is not formal from this formula,
and does not assume that `H_g-1` has nonnegative coefficients in all
degrees.

The finite sets below are explicit once the finite positive wall
functions and the finite local-star theta coefficients are supplied.
This is a positive combinatorial interpretation of the ray's binomial
coefficients, not a claim to replace every theta construction by a
new wall-free model.

## 2. A monotone path realizes the negative factor

Choose a positive rational covector `u`, generic for the finitely many
root hyperplanes. Choose `epsilon>0` small enough that all nonzero
signs of `a^TDg` are unchanged at `g+epsilon u`. Follow the ray
`g+t u`, starting at `t=epsilon` and ending sufficiently far into the
positive orthant. A generic choice of `u` avoids nonparallel joint
crossings. Every root hyperplane is crossed at most once.

Every crossed wall has `a^TDg<0`; zero roots have become positive at
the starting point and are never crossed. The signed-factorization
reconstruction identifies this transport with `A_g^-`. One can also
extend the line in both directions: its three consecutive groups of
crossings have negative, zero, and positive `g`-degrees in the
operator order `C=A_g^- Z_g A_g^+`, so uniqueness identifies the
future transport with the negative factor.

List its effective walls in application order as `1,...,m`, with
primitive integral positive normals `nu_l=Da_l/delta_l` and positive
wall functions

\[
 f_l(z)=1+\sum_{k\ge1} c_{l,k}z^{ka_l},
 \qquad c_{l,k}\in\mathbb N.
\]

Parallel walls crossed together can be kept separately or replaced by
their product. All calculations are in the finite quotient `R_J`.

## 3. The root-state bound needs `s=q+a`, not `s=q`

At an intermediate root state `q`, acting on
`x^{ng+h}z^q` multiplies it by `f_l` to the integer exponent

\[
 E_l(n,q)=-\langle ng+h+Bq,\nu_l\rangle
        =n A_l+B_l(q),\qquad
 A_l=-\langle g,\nu_l\rangle\in\mathbb Z_{>0}.
\]

Suppose this wall can make any nonzero contribution that survives in
`J`. Then `q+ka_l in J` for some `k>=1`, and downward closure gives
`s=q+a_l in J`. Skew symmetry gives

\[
 (h+B(q+a_l))^TDa_l=(h+Bq)^TDa_l.
\]

The threshold therefore proves

\[
 b_l(q):=N_0A_l+B_l(q)\ge0.                 \tag{3.1}
\]

This is the necessary check: the definition of `T_J` requires
`a_l<=s`, which is not guaranteed if one incorrectly takes `s=q`.
If no nonconstant wall term can survive from `q`, the wall acts as the
identity on that state in `R_J`; declare a unique forced empty choice
and do not attempt to interpret a possibly negative discarded
exponent as a number of copies.

## 4. The finite counting objects

By translated-ray stabilization,

\[
 \vartheta_{ng+h}=A_g^-(x^{ng}\eta_h^g)\pmod{I_J}
 \qquad(n>T_J(g;h)).                       \tag{4.1}
\]

The local-star family `eta_h^g=x^h sum_q b_h^g(q)z^q` has
nonnegative integer coefficients. For each surviving initial root
`q_0`, choose one of `b_h^g(q_0)` decorations. Apply the wall list,
always retaining only states in `J`.

At wall `l` and current state `q`, write

\[
 f_l^{E_l(N_0+k,q)}=f_l^{b_l(q)}
                         \prod_{c=1}^k f_l^{A_l}.       \tag{4.2}
\]

Interpret the first factor as `b_l(q)` ordered base slots. For each
color `c in [k]`, the factor `f_l^{A_l}` contributes `A_l` ordered
slots of that color. A slot chooses either the constant term or a
nonconstant term `z^{ka_l}` together with one of its `c_{l,k}`
decorations. Add all chosen roots to update `q`, and proceed to the
next wall. The number of base slots depends on `q`, but the positive
increment `A_l` is independent of `q` and of `k`.

These objects count the coefficient in (4.1) with no cancellation.
All sets are finite: there are finitely many walls, slots, and
surviving root choices. The zero-root local-star input is independent
of `k`; for `h=0` it is just the unique initial root-zero object.

Call a color active if at least one of its slots at at least one wall
chooses a nonconstant term. Use the same color set `[k]` at every
wall. If the final root is `p`, there are at most `|p|` active colors,
because every active color contributes a nonzero positive root
somewhere in the process.

For any active subset `S subseteq [k]` of size `j`, remove the
inactive constant slots and relabel `S` increasingly by `[j]`.
Intermediate roots remain identical, hence every state-dependent
base-slot count `b_l(q)` remains identical. This gives a bijection
with the objects for `j` colors in which every color is active.
Let `C_{p,j}` be exactly that finite set. Conversely, any choice of
the subset `S` inserts its active slots and restores all other colors
as constant slots. There are `binom(k,j)` such subsets, proving
(1.1).

## 5. What is stronger than eventual polynomial positivity

Finite-order stabilization already implies polynomial dependence on
`n`, because `H_g^n=exp(n log H_g)` in a nilpotent root quotient.
That observation alone does not prove nonnegative forward
differences at the same explicit start `N_0`. The monotone path and
(3.1) give that stronger statement and identify the binomial
coefficients with objects using every one of `j` common colors.

The construction works at nongeneric `g` because zero-root walls are
handled by the positive local-star input and excluded from the
monotone negative-factor path. It therefore extends directly to
translated rays `ng+h`, not only generic rays or cluster directions.

Preliminary targeted searches for theta-label scaling, binomial
positivity, and finite differences did not locate this exact theorem.
That negative search is not a priority proof. Existing greedy
binomial formulas, cluster-monomial powers, and mutation-sequence
F-polynomial stabilization are distinct predecessors that should not
be conflated with the fixed-`B`, arbitrary-label, explicit-start
statement here.

## 6. Check that positivity is not a consequence of `H_g>=0`

The root agent's previous exact computation already gave a negative
coefficient of `H_g`. We independently compared it with formal theta
extraction, rather than only reusing the factorization output. For

\[
 B=\begin{pmatrix}0&2\\-2&0\end{pmatrix},\quad
 D=I,\quad g=(-1,1),\quad J=[0,(3,1)],
\]

the surviving stable root series is

\[
 H_g=1+z_1+z_1^2z_2-z_1^3z_2\pmod{I_J}.
\]

Thus `[z_1^3z_2]H_g=-1`, whereas stable theta coefficients satisfy
`[z_1^3z_2]F_{ng}=n(n-2)` for sufficiently large `n`. At the universal
safe start `N_0=9`, the binomial expansion is

\[
 [z_1^3z_2]F_{(9+k)g}
       =63+17\binom{k}{1}+2\binom{k}{2}.
\]

Independent calls to the formal theta coefficient routine at
`n=9,10,11` gave `63,80,99` and matched the entire root box with
`H_g^n`. The exact record is
`positive_copy_negative_root_check.json`. This check isolates a
genuine issue resolved by the general copy proof: the stable root
itself need not be coefficientwise positive.
