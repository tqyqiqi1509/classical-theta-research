# Stable rays: local-star provenance and the actual remaining increment

Research checkpoint: 2026-11-13, UTC. Classical cluster algebras only.

## 1. Verdict

The transverse family `eta_h^g` in
`../stable_adversarial/TRANSVERSE_RAY_THEOREM.md` is the ordinary theta
family of the local star of the original scattering diagram at `g`.
It must **not** be presented as a new kind of positive theta algebra.
Its associative multiplication and nonnegative structure constants are
instances of the existing positive-scattering formalism. The zero factor
`Z_g` is not a new cluster seed, and its root monoid need not be free.

The general translated-ray theorem currently supplies an effective
calculation of how the original label family approaches this already
existing object:

\[
 \vartheta_{ng+h}=A_g^-(x^{ng}\eta_h^g)\pmod{I_J},
 \qquad F_{ng+h}=H_g^nR_{g,h}\pmod{I_J},
\]

for an explicit common cutoff depending only on `(B,D,g,h,J)`. Exact
stabilization of structure constants, with the output-shift estimate
absorbed in the same downward-closed set, is part of that effective
statement. These are **fixed-root-prefix** statements. They are not an
unconditional whole-Laurent formula.

The appropriate description of the work is therefore an effective,
uniform stable-ray calculus derived from standard scattering
factorization, rather than the discovery of a mysterious new transverse
basis. A search not finding precisely the effective theorem is not a
priority proof.

## 2. Exact local-star identification

Use the conventions of `TRANSVERSE_RAY_THEOREM.md`:

\[
 C=A_g^- Z_g A_g^+,
 \quad \lambda_g(a)=g^TDa,
 \quad P_g=\{a\in\mathbb N^r:\lambda_g(a)=0\}.
\]

Let `D` be an incoming-normalized consistent positive cluster scattering
diagram. Its local star at `g` consists of the walls through `g`, extended
in both directions parallel to `g`:

\[
 \mathfrak D_g
 =\{(W+\mathbb Rg,f,n):(W,f,n)\in\mathfrak D,\ g\in W\}.
\]

All roots carried by this diagram lie in `P_g`. Work first in a finite
downward root quotient. Three-factor uniqueness identifies the total
oriented total transport of this local diagram with the zero
factor `Z_g`, using the same order and path-orientation convention as in
the definition of `C`. One way to verify this explicitly is to use the
reconstruction description: a sufficiently small perturbation `g+epsilon u`
refines the signs of `lambda_g` by the signs of `u` on `P_g`; the middle
factor of `C` in that refined decomposition is precisely the middle
factor of `Z_g` for `u`. Thus every wall value of the reconstructed local
diagram agrees with the wall value reconstructed from `Z_g`. Consistent
diagrams with the same total group element are equivalent.

Ordinary coefficient extraction for `D_g` at the final exponent
`h+Bp` consequently gives exactly equation (2.1) in the transverse
theorem. Its coefficient-one triangular system proves

\[
 \eta_h^g=\vartheta^{\mathfrak D_g}_{h,Q_+}.
\]

The original positive chamber direction `Q_+` is positive on every
nonzero root of `P_g`. All statements are compatible with increasing
root quotients, so this proves the identification of the completed
series, not just one chosen truncation. In particular, inherited positive
wall functions prove positivity of coefficients and structure constants
by the usual theta theory. The proof in the transverse theorem deriving
positivity from stabilized original coefficients remains valid, but is an
alternative derivation of an established local-star property.

### Primary precedents

1. **Bridgeland, arXiv:1603.00416, Section 3.** Section 3.2 gives the
   sign decomposition of the graded Lie algebra and unique group
   factorization. Lemma 3.1 identifies a wall value with the middle
   projection of the total transport. Lemma 3.2 reconstructs a consistent
   diagram and gives transport from its positive/negative projections.
   Propositions 3.3–3.4 identify equivalence classes of consistent
   diagrams with group elements. Bridgeland explicitly attributes the
   underlying reconstruction to Kontsevich–Soibelman. His sign/order
   convention is `G_+ G_0 G_-`; it must be converted consistently rather
   than copied into the `A^- Z A^+` convention.
   Primary URL: https://arxiv.org/abs/1603.00416
   Local full text: `../intrinsic_greedy/sources/bridgeland1603.00416.txt`.

2. **Cheung–Magee–Mandel–Muller, arXiv:2505.09585v2, Section 2.5,
   Lemma 2.11.** This is an explicit statement of the above local star
   and of the degreewise limiting chart maps as
   `epsilon -> 0+`. Section 2.2, especially Lemma 2.3 and Corollary 2.5,
   supplies coefficient extraction and strong positivity in the general
   positive-scattering setting.
   Primary URL: https://arxiv.org/html/2505.09585v2
   Local full text: `../fei_newton_interface/sources/cmmm_2505.09585v2.txt`.
   The local-star proof was read directly: in each finite truncation a
   sufficiently small path near `g` crosses only walls containing `g`.
   This elementary argument, not an unaudited new theorem, is what is
   used here.

## 3. A close predecessor stronger than a merely formal limiting chart

**Qin, Freezing operators on cluster algebras, arXiv:2407.03186v1.**
The actual preprint is from 2024; the journal issue being dated 2026
does not turn the mathematical source into a new 2026 preprint.
Primary URL: https://arxiv.org/html/2407.03186v1
Local text: `sources/qin_freezing.txt`.

Proposition 6.19 states that if `theta_h` is a finite Laurent polynomial,
then for any initial mutable coordinate `k`, the root support of
`theta_{h+d f_k}` eventually avoids `k`. Lemma 6.15, Proposition 6.16,
and the freezing theorem turn this into an exact whole-Laurent formula:

\[
 \vartheta_{h+d f_k}=x_k^d\,\mathfrak f_{\{k\}}\vartheta_h
 \quad\text{for sufficiently large }d,
\]

where freezing means setting the corresponding root variable to zero.
The construction extends to a frozen subset and is independent of the
chosen sufficiently large shifts. Thus a claim that eventual theta
translation or its relation to freezing is new would be incorrect.

The proof of Proposition 6.19 even contains a finite effective system of
inequalities. If `N_h` is the root support with `n_k>0`, choose `d` such
that, for every `n` in this finite set, every `0<=n'<=n`, and every
`0<a<=n` with `a_k>0`,

\[
 \langle h+d f_k+p^*n',a\rangle>0.                 \tag{Q}
\]

Positivity of `x_k^d theta_h` gives support domination by the already
known finite `theta_h`; inequality (Q) rules out a broken line with a
`k`-root bend. The full proof, including this last half-space argument,
was read. The argument is sound in its stated setting.

The remaining distinction is precise:

| Existing Qin result | General stable-ray formula |
|---|---|
| Translation in an initial cluster-coordinate direction, or a frozen face after a chart change | Arbitrary integral `g`, including mixed signs and nontrivial zero-root Lie algebra |
| Starts with known finite `theta_h` and its finite support | Starts with a prescribed finite root set `J`; neither `theta_h` nor `theta_{ng+h}` is assumed Laurent finite |
| Gives a whole-Laurent identity | Gives an exact identity through `J`, with an explicit cutoff independent of unknown theta support |
| Limit is the theta function of a frozen cluster seed | Limit is the standard local-star theta, which need not be a cluster seed |

The general theorem is not stronger than Qin in every direction: without
a global support bound it does not recover Qin's whole-Laurent conclusion.

## 4. What the other checked sources do and do not establish

### GHKK

The local complete text `../finite_laurent/sources/ghkk.txt` was checked
at Lemmas 8.15–8.16, Propositions 8.17–8.20, and Proposition 11.8.
The bounded-positive-polytope arguments control finite generation,
polynomial theta multiplication, and finite theta expansions. Strict
increase at bends under a global-monomial valuation is used for these
claims. Proposition 11.8 uses sufficiently large `m` in a product
`theta_p theta_{mq}` to prove regularity from a min-convex function.
These are not statements of the explicit fixed-root identity
`F_{ng+h}=H_g^n R_{g,h}`. The file's theorem numbering is version-specific;
do not silently replace it by the journal numbering.

Primary URL: https://arxiv.org/abs/1411.1394

### Mandel

**Theta bases are atomic**, arXiv:1605.03202v2, Theorem 1, was read in
full. Its proof extracts a theta coefficient by choosing a scattering
chart sufficiently close to that coefficient's label, citing GHKK
Proposition 6.4. It establishes atomicity for the **scattering atlas**.
It does not state large-label stabilization, and does not establish
atomicity for arbitrary cluster atlases.

Primary URL: https://arxiv.org/abs/1605.03202v2
Local text: `../classical_minimal_interface/sources/mandel_atomic.txt`.

### Our own prior rank-two theorem

**Hexagon 2610.00083v2, Proposition 4.3** already states a finite-rectangle,
finite-offset formula for `G[Nv+h]` using one fixed scattering chart for
all sufficiently large `N`, when `v` avoids the nonzero deficit directions.
The proof and statement in
`../intrinsic_greedy/sources/tang_strong_2610.00083v2.txt` were read.

The current stable-ray theorem extends the mechanism to arbitrary rank,
allows nongeneric directions, replaces the missing generic monomial by
the already standard local-star theta, and supplies an explicit uniform
bound. The generic-rank-two phenomenon itself is internal prior work.
This source is not used to bypass any proof of the new statements.

### Gupta

**A formula for F-polynomials in terms of C-vectors and stabilization of
F-polynomials**, arXiv:1812.01910v2, concerns stabilization along mutation
sequences after a `C`-vector deformation. That varying-seed notion is
different from scaling the fixed-seed theta label `ng+h`. It is a useful
analogy but not an identification of the two problems.

## 5. Existing internal carrier work must not be rediscovered

The previous package already contains supplied-reddening constructions,
injective-product carriers, and Qin's sharp support-dimension box.
In particular, Sections 8–10 of
`history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents/valued_young_functor_reddening.md`
give a purely tropical formula for the smallest coordinate box from an
injective predecessor. A generic-presentation dimension box is generally
weaker and requires extra geometric input. Replacing one by the other is
not a new finiteness theorem.

The current signed-envelope approach has a different useful feature:
when its finite-theta-span hypothesis is available, it does not require
a supplied reddening word or a supplied generic module. Neither the
generic-basis identity nor a Newton-equality conjecture is needed.

## 6. Scope of the novelty conclusion

The checked primary sources establish all of the local-star ontology.
They do not, in the passages read here, state the exact arbitrary-`g`,
uniform finite-root cutoff theorem and simultaneous structure-constant
stabilization in the form presently proved. Nevertheless these are
natural consequences of the old sign-factorization framework once the
finite triangular coefficient rule is available. The mathematical claim
should be proportional: an effective quantitative generalization and
explicit formula, with the local object fully attributed.

Further work should improve the concrete computation or global support
problem, not rename `Z_g` or `eta`.
