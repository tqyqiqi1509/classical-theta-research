# Primary literature comparison: stable logarithms, polytopality, and multiplication

Review date: 2026-11-13 UTC. This is a claim-level novelty comparison,
not a claim that a search proves priority. The construction and proofs
being compared are in `POLYTOPAL_STABLE_LOG_THEOREM.md`. The earlier
local-star and large-label comparison is in `NOVELTY_LOCAL_STAR.md`.

## 1. Current conclusion

No exact predecessor was located for the following combined statement:
for every classical skew-symmetrizable exchange matrix and every finite
downward root set `J`, stable theta logarithms give an explicit rational
polytope whose normal fan is exactly the effective scattering fan
modulo `J`, and common closed-cone membership is equivalent to vanishing
of all positive-root structure coefficients through `J` at the single
scale

\[
 N_J=\lfloor M d^2/4\rfloor+1,
 \qquad M=\max_{i,j}|D_iB_{ij}|,
 \qquad J\subseteq\{|p|\le d\}.
\]

The individual ingredients have substantial precedents. Signed
factorization, local scattering stars, positivity, complete scattering
fans, cluster-cone multiplicativity, Newton-polytope realizations of
representation-theoretic fans, and convexity criteria for support
functions must all be credited as existing mathematics. In particular,
the transverse eta algebra is a local-star instance and is not a new
mysterious algebra. The presently defensible increment is the
**effective stable-theta support function, exact effective-wall normal
fan, and finite-order multiplication criterion**, subject to further
priority checking. Bare existence of polytopes for categorical
stability fans is not a defensible general novelty claim.

The polytopality proof is a concise consequence of known positive wall
actions plus a new use of stable-label data. Its conceptual distance
from the standard framework should not be exaggerated. The explicit
uniform scale and the structure-coefficient characterization are more
directly responsive to the theta-basis objective than merely naming
another polytope.

## 2. Reading: complete fans, not a polytopal theorem in the inspected paper

Primary source: Nathan Reading, *Scattering Fans*,
[arXiv:1712.06968v3](https://arxiv.org/abs/1712.06968v3), October 2018;
IMRN 2020, 9640--9673,
[publisher](https://academic.oup.com/imrn/article/2020/23/9640/5177805).
Local copy: `sources/reading_scattering_fans.txt`.

Read Theorem 3.1 and its proof, Propositions 3.8--3.11, and Theorem 5.6.
Theorem 3.1 proves completeness and the fan axioms for a consistent
minimal-support diagram. Proposition 3.8 recovers full equivalence
from all finite truncations. The finite-to-infinite argument carefully
distinguishes an equivalence class from the relative interior of its
closure. Theorem 5.6 expresses cluster monomials by transport from a
cluster chamber.

The inspected text contains no theorem constructing a convex support
function for every root truncation, and no normal-polytope conclusion.
Its proof of convexity of individual cones is not a proof that the fan
is regular. Our Section 9 uses its finite-equivalence characterization
and preserves the required closure/adjoin-faces convention; it does not
claim the infinite fan is the normal fan of a finite polytope.

**Assessment:** essential structural predecessor; does not supply the
new finite support function or explicit multiplication cutoff.

## 3. Fei: genuine Newton-polytope predecessors

Primary source: Jiarui Fei, *Tropical F-polynomials and General
Presentations*,
[arXiv:1911.10513v6](https://arxiv.org/abs/1911.10513v6), 2023 version.
Local copy: `sources/fei_tropical.txt`.

Read Theorem 5.17 with its separating-exchange-pair proof, Lemma 8.2,
Proposition 8.4, Remark 8.5, and the relevant definitions. Theorem 5.17
realizes any finite collection of cluster cones as normal cones of a
single representation Newton polytope. Direct sums yield Minkowski
sums and common refinements of normal fans. Remark 8.5 explicitly
suggests an infinite-representation normal-fan viewpoint heuristically.

This is close prior art for the geometric objective. It does not
identify arbitrary finite-root scattering chambers with those selected
cluster cones. Nor does a regular refinement imply that every
coarsening is regular. Our construction uses the integrated effective
wall support and requires no generic module or Jacobian realization.

Primary source: Fei, *Combinatorics of F-polynomials*,
[arXiv:1909.10151v3](https://arxiv.org/abs/1909.10151v3), Theorem 6.8.
The facet restriction is obtained by a torsion subobject and a
semistable reduction. Its proof is a direct identification of the
relevant submodule Grassmannians. This is an appropriate model for
categorical interfaces, but is not a formula for every cluster theta
function.

**Assessment:** use these ideas and cite their scope. Do not describe
Newton faces, direct-sum Minkowski sums, or finite cluster-cone
realization themselves as new.

## 4. Asai--Iyama and the bounded categorical wall fan

Primary source: Sota Asai and Osamu Iyama, *M-TF equivalences in the real
Grothendieck groups*,
[arXiv:2404.13232v1](https://arxiv.org/abs/2404.13232v1), April 2024.
Local copy: `sources/asai_iyama_2404.13232v1.txt`.

The 2024 version already proves `Sigma(M)=NormalFan(N(M))`, as Theorem
3.15. We read Definition 1.1, Lemmas 3.10, 3.13--3.14, and the proof.
The definition remembers both the torsion filtration and the simple
supports of its semistable middle piece; the latter cannot be omitted.
Lemma 3.13 identifies each exposed Newton face with subobjects of the
semistable middle piece. Therefore this is a prior theorem, not a
2026 novelty. The 2026 v3 was also retrieved, but is unnecessary for
this comparison and is not a dependency of our proof.

### A standard consequence, proved here to delimit novelty

Let `A` be any abelian length category with finitely many simple
objects. Fix a finite downward dimension set `J`. For every object
`M` of dimension in `J`, its subobject Newton polytope has vertices in
the finite set `J`. There are consequently only finitely many possible
polytopes. Choose one representative object for each occurring
polytope and form their Minkowski sum `P_J^cat`.

Its nondifferentiability locus is exactly the union of the King
semistability walls of nonzero objects of dimension in `J`. One can
see this without importing the whole TF-equivalence theorem. If `E`
is semistable at `theta`, then zero and `[E]` both maximize `theta`
on `N(E)`, giving a nontrivial exposed face. Conversely, the
maximizing subobjects of any `M` are closed under sums and
intersections, because dimension vectors are modular and every
subobject has value at most the maximum. Finite length gives a least
and greatest maximizing subobject `L<=U`. If the exposed face is
nontrivial, `U/L` is nonzero. It has total `theta`-value zero and
every subobject has nonpositive `theta`-value, so it is semistable.
Its dimension lies in `J` by downward closure. This proves the claim.

Thus bounded **categorical** King wall arrangements already admit
finite Newton/Minkowski realizations as a natural consequence of
established representation theory. The arbitrary-rank phenomenon by
itself is not new.

### Why this does not settle our effective-wall theorem automatically

The categorical wall support records existence of a nonzero
semistable object. Hall integration records enumerative invariants;
an integrated local wall can vanish even when the categorical
semistable category is nonzero. A claim that these supports agree
needs a theorem in the particular setting. Coarsening a polytopal fan
does not by itself preserve polytopality. We therefore do **not** claim
that Asai--Iyama automatically covers all skew-symmetric cluster root
truncations, much less all skew-symmetrizable ones. Our proof detects
exactly nontrivial integrated factors and supplies a strict bend at
each such factor.

## 5. Multiplication compatibility: Cao, Qin, and Reading--Stella

### Cao, 2025 version of a 2023 preprint

Primary source: Peigen Cao, *F-invariant in cluster algebras*,
[arXiv:2306.11438v4](https://arxiv.org/abs/2306.11438v4), October 2025.
Local copy: `sources/cao_f_invariant_2306.11438.txt`.

Read Definition 4.6, Theorems 4.19 and 4.24 with proofs. Theorem 4.19
characterizes when two cluster monomials have a cluster-monomial
product by vanishing of their F-invariant. Theorem 4.24 says that
F-compatible good elements have sign-coherent tropical points and
a good product. It does not identify that product with a single
theta element for arbitrary labels. The invariant uses tropical
F-polynomial support, not a prescribed root truncation and a bounded
large-label multiplication test.

**Assessment:** direct compatibility predecessor. Our criterion should
be compared with it explicitly, not advertised as the first relation
between multiplicativity and cone compatibility.

### Qin

Primary sources: *Bases for upper cluster algebras and tropical points*,
[arXiv:1902.09507v4](https://arxiv.org/abs/1902.09507v4), and
*Freezing operators on cluster algebras*,
[arXiv:2407.03186v1](https://arxiv.org/abs/2407.03186v1).
Local copies: `sources/qin_bases.txt`, `sources/qin_freezing.txt`.

Compatible pointedness constrains expansions in dominance regions;
it is different from a product being a single theta basis element.
Freezing Proposition 6.19 already proves eventual exact theta
translation in an initial cluster direction, under finite-support
hypotheses. Its proof uses half-space inequalities for all possible
root additions. This is a close predecessor to our stabilization
mechanism. The present claim changes the direction and finite-order
generality and gives an explicit label-independent cutoff; it must
not claim that eventual translation is new.

### Reading--Stella: latest version checked, November 2026

Primary source: Nathan Reading and Salvatore Stella, *Mutation of Theta
Functions*,
[arXiv:2603.19391v4](https://arxiv.org/abs/2603.19391v4), November 8,
2026; [SIGMA 22 (2026), 109](https://sigma-journal.com/2026/109/).
Local copy: `sources/reading_stella_2603.19391v4.txt`.

The latest version is **v4**, not September's v3. We checked Theorems
5.4, 5.6--5.7 and Lemmas 5.8, 5.10--5.12, including the expansion
proof of 5.6 and the cone-linearity proof of 5.12. Their result restricts
products of theta functions with labels in one mutation cone to a
dominance set; Theorem 5.7 gives a sharper set of possible root
corrections. It permits nonzero corrections. It contains neither the
root-order vanishing iff common **scattering** cone criterion nor the
uniform scale `floor(Md^2/4)+1`.

**2026 audit status:** the inspected application and its local proof
chain are coherent. The complete paper has not been re-proved; no
2026 theorem from it is needed for our new proof. This is an exact
scope comparison, not an unrestricted correctness endorsement.

## 6. Cheung--Magee--Nájera Chávez: a different convexity equivalence

Primary source: *Compactifications of cluster varieties and convexity*,
[arXiv:1912.13052v2](https://arxiv.org/abs/1912.13052v2), January 2021.
Local copy: `sources/cmn_convex_1912.13052.txt`.

Read the positive-set definition, the balanced broken-line
multiplication description, and Theorem 6.1 with its proof. The theorem
identifies positive subsets of tropical space with broken-line convex
subsets: nonzero structure constants force an output into the
appropriately dilated set. This concerns closure of whole sets under
all allowed outputs. Our claim instead detects absence of every
positive-root correction through a chosen finite order, after a
specific large-label scaling, and identifies an ordinary rational
polytope normal fan. Neither implication is the same statement.

The publisher's [erratum, DOI 10.1093/imrn/rnab245](https://academic.oup.com/imrn/article-abstract/2022/14/11202/6371788)
was checked. It identifies production errors in the first two
equations of Section 2.2.1 and says they were corrected online; it
does not announce a failure of the main convexity theorem.

**Assessment:** substantial positive-multiplication/convexity
predecessor, but not an exact source of the present effective
normal-fan characterization.

## 7. DT wall crossing and dilogarithmic potentials

### Mou: canonical finite and inverse-limit cone complexes

Primary source: Lang Mou, *Scattering diagrams of quivers with
potentials and mutations*,
[arXiv:1910.13714v1](https://arxiv.org/abs/1910.13714v1).
Local copy: `sources/mou_1910.13714v1.txt`.

Read Section 2.4, Theorem 2.19 and its proof, and Proposition 2.24.
The signed middle-factor map reconstructs the minimal finite cone
complex; inverse limits give the infinite structure. This is directly
relevant to why a finite root arrangement subdivides effective wall
supports, a point that cannot be inferred merely from containing the
wall hyperplanes. No convex support-function or polytope theorem was
found in the inspected text. Its cluster/stability identification is
conditional: green-to-red quivers agree, while the once-punctured
torus is explicitly treated as differing by a central wall crossing.

**Assessment:** existing minimal-support and signed-factor framework;
not evidence that arbitrary cluster scattering is automatically a
categorical Newton fan.

### Nakanishi: the transported logarithm is familiar

Primary source: Tomoki Nakanishi, *Dilogarithm identities in cluster
scattering diagrams*,
[arXiv:2111.09555v4](https://arxiv.org/abs/2111.09555v4), August 2023;
Nagoya Mathematical Journal 253 (2024), 1--22.
Local copy: `sources/nakanishi_dilog_2111.09555v4.txt`.

Read Section 3.1, Remark 3.2, and the Hamiltonian formulas and loop
identity in Theorem 3.4. Wall y-variables are transported monomials;
their logarithms occur as Hamiltonian derivatives of dilogarithms.
Thus our transported `log(f)` jump is not a new special function.
Remark 3.2(c) expressly distinguishes the cluster-chamber transport
formula from general theta functions. The inspected theorem concerns
loop dilogarithm identities, not a piecewise-linear function of the
theta label whose normal fan is the finite scattering fan.

**Assessment:** a close mechanism predecessor; the stable-label and
finite-polytopal consequences remain distinct in the inspected source.

### Kontsevich--Soibelman

Primary source: *Wall-crossing structures in Donaldson--Thomas
invariants, integrable systems and Mirror Symmetry*,
[arXiv:1303.3253v4](https://arxiv.org/abs/1303.3253v4), November 2013.
Local copy: `sources/ks_wcs_1303.3253v4.txt`.

The inspected material includes the nilpotent/pronilpotent WCS
framework, the wheel-of-cones construction, and the convex Hessian
potentials in Sections 6.2 and 10.2. These establish the older
wall-crossing and Hamiltonian setting. The smooth convex potentials
there describe metrics and dual affine structures, not the finite
label-space PL support function constructed here. No matching
finite-truncation polytopality or coefficient-vanishing theorem was
located. The 130-page paper was not audited theorem by theorem.

## 8. Further 2026 sources: kept separate from proof dependencies

- Hipolito Treffinger, [arXiv:2608.04233v1](https://arxiv.org/abs/2608.04233v1),
  *Scattering diagrams for Artin algebras*: introduction and relevant
  finite-length/inverse-limit descriptions inspected. It explicitly
  points to Asai--Iyama for a single-object dual polytope. Its complete
  new theorems have not been strongly audited and are not used here.
- Cao--Fujita--Murakami,
  [arXiv:2609.08781](https://arxiv.org/abs/2609.08781), *Partial
  F-invariants and cluster categorifications*: primary abstract
  identifies a new cluster-variable separation result. No full-proof
  audit performed; not used as a dependency or claimed to settle
  arbitrary theta compatibility.
- Fei [arXiv:2610.09868v2](https://arxiv.org/abs/2610.09868v2): available
  locally, but not used in the polytopality proof. The construction
  requires no 2026 ramified representation theorem.
- Own Hexagon 2610.00083v2, Proposition 4.3, already contains generic
  rank-two large-label stabilization. This is recorded in the
  separate local-star note and prevents claiming that whole
  phenomenon as new.

The Li--Pan polytope-basis conclusions are excluded as requested by the
user. None is used to establish the new statements.

## 9. Search and route log

The searches used both search engines and followed hits to primary
papers rather than treating snippets as proofs. Query families
included `scattering fan polytope/polytopal/regular/projective`,
`positive scattering diagram convex support function`,
`wall-crossing polytopes Donaldson Thomas`,
`dilogarithm scattering convex potential`, `stability polytopes quiver`,
`theta same cone multiplication`, `Qin multiplicative tropical
compatibility`, and `F-invariant theta`.

Useful outcomes were Reading's finite/infinite precision,
Asai--Iyama's already-polytopal categorical model, Fei's cluster-cone
realization, Cao's compatibility criterion, the latest Reading--Stella
version, and Nakanishi's transported logarithm. Queries also returned
particle-physics scattering polytopes and Gross--Siebert constructions
which start with a chosen convex PL polarization; those were not
silently treated as the desired theorem. A pre-existing polarization
is not a proof that the effective scattering chamber fan itself is
polytopal.

Route changes:

1. Downgraded the eta transverse algebra to an instance of known local
   scattering-star theory.
2. Rejected a generic-module dimension box as rediscovering the
   previous round's reddening/Qin support box.
3. Kept the stable-log polytope because it produces exact effective
   wall geometry from finite theta data, while explicitly narrowing
   novelty around categorical Newton-fan predecessors.
4. Added the stronger one-scale multiplication criterion and first
   obstruction integrality, since these state concrete theta
   properties rather than only repackage a fan.
5. Added an independent positive-multiplication proof of the convex
   facet sign, avoiding a separate positivity-of-wall-functions input.
6. Corrected two proof omissions after independent review: finite
   root arrangements require signed reconstruction to refine wall
   supports; the polytope's affine span and common lineality must be
   specified when `J` omits simple roots.

No negative search result is being represented as a proof of novelty.
