# Finite scattering fans from stable theta logarithms

Date: 2026-11-13, UTC. Classical skew-symmetric and skew-symmetrizable
cluster algebras. This file gives an independent proof of the root
agent's proposed construction. The literature comparison is separate;
the theorem is not being identified with a new construction of theta
functions themselves.

## 1. Statement and conventions

Let `B` be an integral exchange matrix, let `D` be a positive integral
diagonal symmetrizer, and put

\[
 z_i=y_i x^{Be_i},\qquad \Omega(a,b)=a^TDBb.
\]

Let `J` be a finite downward-closed subset of `N^r` containing zero.
Write

\[
 R_J=\mathbb Q[z_1,\ldots,z_r]/I_J,
\]

where `I_J` is the monomial ideal with root exponents outside `J`.
All logarithms and exponentials below are computed in the nilpotent
positive-root ideal of `R_J`. In particular they are finite operations.

Use the negative-to-positive total-transport convention in
`../newton_properties/STABLE_RAY_AND_WALL_RECOVERY.md`. Thus

\[
 C=A_g^- Z_g A_g^+,\qquad \lambda_g(a)=a^TDg,
\]

and logarithmic roots of the three factors have negative, zero, and
positive `lambda_g`, respectively. The monomial action is

\[
 e_a(x^m z^q)=a^TD(m+Bq)x^m z^{q+a}.              \tag{1.1}
\]

For integral `g`, let

\[
 H_g=x^{-g}A_g^-(x^g),\qquad L_J(g)=[\log H_g]_J. \tag{1.2}
\]

The functions `L_J` extend continuously and piecewise linearly to real
`g`; the proof is included below. Fix arbitrary positive integers
`w_1,...,w_r`, and define the **linear evaluation map**

\[
 E_{w,t}\left(\sum_{p\in J}c_pz^p\right)
       =\sum_{p\in J}c_pt^{w\cdot p}.
\]

This is a linear map from a finite root quotient. It is generally **not**
an algebra homomorphism from that quotient to `Q[t]`. No such
homomorphism is used in this proof: logarithms, products, and transports
are performed before evaluation.

Let `D_J` be the minimal-support representative of the scattering
diagram modulo `I_J`, and let `Fan(D_J)` be its scattering fan. Since
`J` is finite, this is a finite rational complete fan, permitting a
common lineality space when some initial roots have been removed.

### Theorem 1: finite polytopal realization

There is an effectively computable rational number `epsilon>0` such
that, for every rational `0<t<epsilon`, the function

\[
 \Phi_{J,w,t}(g)=E_{w,t}(L_J(g))                  \tag{1.3}
\]

is a continuous, convex, positively homogeneous rational piecewise
linear function on `R^r`. Its maximal regions of linearity are exactly
the closed chambers of `D_J`. Consequently

\[
 P_{J,w}(t)=\operatorname{conv}\{v_\sigma(t):
                  \sigma\text{ an arrangement chamber}\},\qquad
 \Phi_{J,w,t}|_\sigma(g)=g\cdot v_\sigma(t),       \tag{1.4}
\]

is a rational polytope satisfying

\[
 h_{P_{J,w}(t)}=\Phi_{J,w,t},\qquad
 \mathcal N(P_{J,w}(t))=\operatorname{Fan}(D_J).   \tag{1.5}
\]

Here an arrangement chamber refers to the finite rational central
arrangement `a^TDg=0`, `0<a in J`. Artificial arrangement facets on
which the scattering transport is trivial are glued automatically;
every genuine wall produces a strict convex bend.

The statement applies to every classical skew-symmetrizable exchange
matrix. No potential, weak-genteelness theorem, representation-finite
condition, reddening sequence, or Laurent finiteness of individual theta
functions is required. More generally, the proof applies to a rational
consistent positive homogeneous scattering diagram with this
positive-root grading and skew monomial action.

### Theorem 2: recovery from finite theta coefficients

For each fixed `J`, the polytope can be computed from finitely many
coefficients of finitely many theta functions, at explicitly bounded
large labels. The wall supports and wall coefficients do not have to be
given separately. A complete procedure is in Section 7.

## 2. Why all data are finite

Choose `N` with `J` contained in the total-degree set `|p|<=N`. A wall
that is nontrivial modulo `I_J` is also nontrivial modulo the usual
degree-`N` ideal. The scattering-diagram finiteness axiom therefore leaves
only finitely many walls. Taking finite intersections and subdivisions
does not change this.

All root normals of such walls are parallel to an element of `J`: if
the first nonzero root on a wall is `ka`, then `ka in J` implies `a in J`
because `J` is downward closed. The hyperplane arrangement used in
(1.4) is consequently finite and contains all wall hyperplanes.

Containment of those hyperplanes alone would not show that the
arrangement subdivides each wall support. The additional input is the
signed-factorization reconstruction of a consistent diagram
(Bridgeland, Section 3.2, Lemma 3.1; equivalently Mou, Section 2).
At a point `g`, its middle factor `Z_g` is the local total wall factor.
On a relatively open cell of the finite root arrangement the signs of
every surviving root are fixed, so the three subgroups and the unique
factorization of `C` are fixed. Thus `Z_g` is constant there. In
particular, on a generic arrangement facet it is either identically
trivial or is the same nontrivial effective wall throughout that
facet. Effective wall boundaries cannot cut through the relative
interior of such a cell. This justifies the arrangement refinement and
the facet-gluing procedure used below.

The root-graded Lie algebra modulo `J` is nilpotent because a bracket
adds nonzero root degrees. The positive/zero/negative signed
factorization is unique and involves rational coefficients. The same
factor is obtained by first computing in a larger root quotient and
then restricting to `J`.

No uniform finite number of walls is asserted for the untruncated
diagram.

## 3. Continuous gluing, including noncommutative zero groups

On a full-dimensional arrangement chamber `sigma`, the signs of all
roots in `J` are fixed, so the negative group factor `A_sigma^-` is
fixed. Put

\[
 U_{\sigma,i}=\log\bigl(x_i^{-1}A_\sigma^-(x_i)\bigr)\in R_J.
\]

Since `A_sigma^-` is an algebra automorphism fixing the coefficient
variables,

\[
 L_J(g)=\sum_{i=1}^r g_i U_{\sigma,i}             \tag{3.1}
\]

for integral `g in sigma`; this expression defines its linear extension
to real `g`.

At an arbitrary boundary point `g_0`, factor

\[
 C=A^- Z A^+
\]

using the coarse signs at `g_0`. Every nearby chamber refines this
factorization by factoring `Z`. Its negative factor is therefore
`A^- Z_-` for some refined negative factor `Z_-` of `Z`. Every root `a`
of `Z_-` satisfies `a^TDg_0=0`. Equation (1.1) gives

\[
 e_a(x^{g_0})=0,\qquad Z_-(x^{g_0})=x^{g_0}.
\]

Hence

\[
 (A^-Z_-)(x^{g_0})=A^-(x^{g_0})                 \tag{3.2}
\]

for every incident chamber. This proves agreement of their `H`
expressions and of their logarithms on every common face. It uses no
commutativity of `Z`, and does not claim that the zero group fixes all
monomials or commutes with `A^-`.

Thus `L_J` is a continuous rational piecewise-linear map with values
in the finite-dimensional space `R_J`, homogeneous of degree one in
`g`. The value at `g=0` is zero. Evaluation gives the same assertions
for `Phi`, prior to proving convexity.

## 4. The exact facet jump and its sign

Take a relative interior point `g_0` of a codimension-one facet of the
arrangement, avoiding every nonparallel root hyperplane. There is one
primitive positive root direction `a` with `a^TDg_0=0`. All zero roots
are multiples of `a`, so their Lie algebra is abelian by skew symmetry.
Write

\[
 Z=\exp\left(\sum_{ka\in J}\lambda_k e_{ka}\right),\qquad
 \Psi_Z=\sum_{ka\in J}k\lambda_k z^{ka},\qquad
 \ell_a(g)=a^TDg.
\]

Each `e_{ka}` annihilates every `z^{ja}`. Therefore

\[
 Z(x^g)=x^g\exp(\ell_a(g)\Psi_Z).              \tag{4.1}
\]

The negative factors on the two sides of the facet are

\[
 A_-^{\ell<0}=A^-Z,\qquad A_-^{\ell>0}=A^-.
\]

The order is essential. Applying `A^-` after `Z` gives

\[
 L_J^-(g)-L_J^+(g)
   =\ell_a(g)A^-(\Psi_Z).                      \tag{4.2}
\]

We now compare with the positive wall function rather than infer a
sign from the symbols `+` and `-`. Let

\[
 \delta_a=\gcd_i(D_i a_i)>0,\qquad \nu_a=Da/\delta_a,
\]

so `nu_a` is the primitive integral positive normal. In the
negative-to-positive convention, an effective positive wall function
`f=1+sum_{k>=1}c_k z^{ka}`, with `c_k>=0`, acts by

\[
 Z(x^g)=x^g f^{-\langle g,\nu_a\rangle}.
\]

Consequently

\[
 \Psi_Z=-\frac{1}{\delta_a}\log f.             \tag{4.3}
\]

At a point where parallel walls overlap, `f` is their effective
product. Its coefficients are nonnegative, and if the total wall is
nontrivial modulo `J`, its first surviving coefficient is strictly
positive. Formula (4.3) also covers nonprimitive first exponents: if the
first exponent is `ka`, the corresponding coefficient of `Psi_Z` is
strictly negative. For an initial wall `a=e_i`, this reads
`Psi_Z=-(1/D_i)log(1+z_i)`, agreeing with the action
`x^g -> x^g(1+z_i)^(-g_i)`.

Let `k_0 a` be the first surviving root of `f-1`. Since `J` is
downward closed, all lower multiples needed to compute the logarithm
also survive. The first nonzero term of `Psi_Z` is

\[
 -\frac{c_{k_0}}{\delta_a}z^{k_0a}.            \tag{4.4}
\]

The operator `A^-` is root-unitriangular: acting on `z^p` changes it
only by adding strictly positive root degrees. Because every `w_i` is
strictly positive, each such addition strictly raises `w dot p`.
Thus the first nonzero coefficient of

\[
 q_\tau(t)=E_{w,t}\bigl(A^-(\Psi_Z)\bigr)      \tag{4.5}
\]

is exactly the strictly negative coefficient in (4.4), at degree
`k_0 w dot a`. No later term of the logarithm or transport can cancel
it. Distinct root degrees are allowed to acquire the same `t` degree;
this cannot affect the first term, since the untransported wall roots
are collinear and all added roots have positive weight.

If `Z=1` modulo `J`, then `q_tau=0`. Conversely, if `Z` is nontrivial,
the first-term argument proves `q_tau` is not zero.

### 4.1 A second sign proof from positive theta multiplication alone

For the cluster theorem, the sign can alternatively be deduced from
theta coefficients and multiplication coefficients. This proof does
not invoke positivity of wall functions. It uses the signed
factorization only for continuity, piecewise linearity, and the exact
jump (4.2).

The principal-coefficient multiplication formula, with its leading
term normalized, is

\[
 \vartheta_u\vartheta_v=\vartheta_{u+v}
       +\sum_{q>0}c_{u,v}(q)y^q\vartheta_{u+v+Bq},
 \qquad c_{u,v}(q)\in\mathbb N.                \tag{4.6}
\]

Here the fixed initial chart is used, and `F_m` denotes the root
series in `theta_m=x^m F_m(z)`. Positivity of theta coefficients gives

\[
 F_uF_v-F_{u+v}
   =\sum_{q>0}c_{u,v}(q)z^qF_{u+v+Bq}(z)
       \in\mathbb N[[z]].                    \tag{4.7}
\]

Fix integral `u,v`, and put

\[
 \Delta=L_J(u)+L_J(v)-L_J(u+v).
\]

For any integer `N` exceeding the three stable-ray thresholds,

\[
 F_{Nu}F_{Nv}-F_{N(u+v)}
   =H_{u+v}^{N}\bigl(\exp(N\Delta)-1\bigr)
       \quad\text{in }R_J.                   \tag{4.8}
\]

If `Delta` is nonzero, let `d` be the least positive `w`-weight of a
root in its support. For every root `p` of weight `d`, the coefficient
on the right of (4.8) is exactly `N Delta_p`: higher powers of `Delta`
and nonconstant terms from the prefactor strictly raise weight.
Equation (4.7) therefore gives

\[
 \Delta_p\ge0\quad(w\cdot p=d),
 \qquad\text{and at least one of these coefficients is positive}.
                                                               \tag{4.9}
\]

This rootwise assertion rules out cancellation when different roots
have the same `w`-weight. In particular, the first nonzero coefficient
of `E_{w,t}(Delta)` is strictly positive. More generally, (4.9) applies
at each componentwise-minimal root of `supp(Delta)`.

Now take a rational point `g_0` in the relative interior of the facet,
a rational vector `e` with `ell_a(e)>0`, and a sufficiently small
positive rational `s` such that `g_-=g_0-se` and `g_+=g_0+se` lie in
the two neighboring arrangement chambers. Continuity and linearity
give, with `Q=A^-(Psi_Z)`,

\[
 L_J(g_-)+L_J(g_+)-L_J(2g_0)=-s\ell_a(e)Q.    \tag{4.10}
\]

Clear one common denominator `d_0`, apply (4.9) to the integral labels
`u=d_0g_-`, `v=d_0g_+`, and use homogeneity of `L_J`. A nontrivial
effective wall has `Psi_Z!=0`; the invertible map `A^-` then gives
`Q!=0` in `R_J`. Thus (4.9) and (4.10) imply that the first nonzero
coefficient of `E_{w,t}(Q)` is strictly negative. This is exactly the
sign needed in Section 5.

The argument also proves an abstract principle. Any positive
triangular root-graded basis with a unit leading term, whose large
labels satisfy a finite-order power law `F_{Ng}=H_g^N`, has a
lexicographically positive first multiplication defect
`L(u)+L(v)-L(u+v)` for every positive root weight. If its stable
logarithms glue piecewise linearly and each effective facet jump is a
nonzero scalar multiple of its facet equation, every finite chamber
fan admits the support-function construction above. Positivity alone
does not supply those gluing or nonzero-jump hypotheses; they are
proved by scattering factorization here.

## 5. One rational small parameter works for all facets

There are finitely many arrangement facets. For each facet with a
nontrivial wall write

\[
 q_\tau(t)=-c_\tau t^{d_\tau}
          +\sum_{k>d_\tau}q_{\tau,k}t^k,
 \qquad c_\tau>0,
 \qquad S_\tau=\sum_{k>d_\tau}|q_{\tau,k}|.
\]

For `0<t<=1`, the tail has absolute value at most
`S_tau t^(d_tau+1)`. Hence the explicit choice

\[
 0<t<\epsilon,
 \qquad
 \epsilon=\min\left(\{1\}\cup
       \left\{\frac{c_\tau}{2S_\tau}:S_\tau>0\right\}\right)
                                                               \tag{5.1}
\]

ensures `q_tau(t)<0` at every nontrivial facet. All numbers are rational
and computable in finite arithmetic. If there are no nontrivial facets,
take `epsilon=1`.

After evaluation, equation (4.2) becomes

\[
 \Phi^-(g)-\Phi^+(g)=\ell_a(g)q_\tau(t).       \tag{5.2}
\]

Move across the facet in any direction `v` with `ell_a(v)>0`, from
the negative side to the positive side. The directional slope increase
is

\[
  (\nabla\Phi^+-\nabla\Phi^-)\cdot v
      =-q_\tau(t)\ell_a(v)>0                  \tag{5.3}
\]

when the wall is nontrivial, and zero otherwise. Thus every facet bend
has the convex sign, and exactly the genuine walls have strict bends.

A continuous piecewise-linear function on a finite complete polyhedral
fan is convex when all facet slope jumps have this sign. For
completeness, restrict it to a generic affine line: its slope is
nondecreasing each time the line crosses a facet, so the restriction is
convex. Nongeneric lines are limits of generic lines; continuity passes
the convexity inequality to the limit. This proves global convexity of
`Phi` without assuming that the scattering fan is already polytopal.

## 6. Exact equality of the normal fan

For any linear piece `g dot v_sigma`, global convexity and continuity
imply

\[
 \Phi(g)=\max_\sigma g\cdot v_\sigma.
\]

For example, choosing an interior point of `sigma`, its gradient is a
subgradient of the global convex function, so its linear homogeneous
extension is everywhere at most `Phi`; equality holds on `sigma`.
This proves (1.4)–(1.5) at the level of support functions.

We must still rule out unwanted gluing of genuine scattering chambers.
Across an arrangement facet with trivial `Z`, (4.2) gives identical
gradients. Across a facet with nontrivial `Z`, (5.3) gives distinct
gradients and strict convexity. A maximal linearity domain of a convex
piecewise-linear function is a convex cone. If two nonadjacent open
scattering chambers had the same gradient, their open convex hull would
belong to that linearity cone. A generic segment in this hull would
cross a genuine separating wall but could have no strict slope jump,
contradicting (5.3).

Therefore the maximal linearity cones are precisely the closures of
the connected components of the complement of the effective wall
support. Their faces give exactly the minimal-support finite
scattering fan. In particular, a redundant subdivision or an
arrangement hyperplane carrying identity transport creates no extra
face of the polytope.

The affine span and lineality are explicit. Set
`S={i:e_i in J}`. Downward closure forces every root in `J` to be
supported on `S`. Equation (1.1) then gives `e_a(x_i)=0` for
`i notin S`, hence `U_sigma,i=0` and `P` is contained in the coordinate
space `R^S`. The positive chamber has gradient zero, so `0 in P`.
For each `i in S`, a generic point of the full initial wall `e_i^perp`
has a nontrivial effective factor: its surviving initial term cannot
cancel in a positive wall product. The corresponding strict gradient
jump is a nonzero multiple of `e_i`. These jumps span `R^S`.
Consequently

\[
 \operatorname{aff}(P)=\mathbb R^S,\qquad
 \operatorname{lin}(\operatorname{Fan}(D_J))
       =\operatorname{span}\{e_i:i\notin S\}. \tag{6.1}
\]

In particular, `P` is full dimensional exactly when `J` contains all
simple roots. Otherwise (1.5) is an equality of generalized fans with
the displayed common lineality.

## 7. A finite algorithm using only theta coefficient data

For each full-dimensional chamber `sigma` of the explicit arrangement
`a^TDg=0`, `0<a in J`, choose `r` linearly independent integral vectors
`g^(1),...,g^(r)` in that chamber. Such vectors exist because the chamber
is a nonempty rational open cone. For each one choose an integer `n`
strictly larger than

\[
 T_J(B,D,g)=\max\left(\{0\}\cup
 \left\{\frac{|(Bs)^TDa|}{|g^TDa|}:
 s\in J,\ 0<a\le s,\ g^TDa\ne0\right\}\right). \tag{7.1}
\]

The independently reviewed stable-ray theorem gives

\[
 H_g\equiv F_{(n+1)g}/F_{ng}\pmod {I_J}.        \tag{7.2}
\]

There is also a uniform bound independent of the integral label.
If `J` is contained in `|p|<=d` and

\[
 M=\max_{i,j}|D_iB_{ij}|,
\]

then

\[
 T_J(g)\le \frac{Md^2}{4}\quad\text{for every }g\in\mathbb Z^r.
                                                               \tag{7.3}
\]

Indeed, a nonzero denominator `g^TDa` is an integer of absolute value
at least one. Skew symmetry gives `a^TDBa=0`, so, for `0<a<=s`,

\[
 |(Bs)^TDa|=|a^TDB(s-a)|
 \le M|a|\,|s-a|\le M|s|^2/4\le Md^2/4.
\]

Thus the single integer

\[
 N_J=\lfloor Md^2/4\rfloor+1                  \tag{7.4}
\]

is valid simultaneously for every integral label. The sharper
label-specific bound (7.1) is optional.

Compute the finite quotient and its finite logarithm. Solve the `r` by
`r` rational linear system (3.1) to obtain each coefficient vector
`(U_sigma,1,...,U_sigma,r)`. Thus the whole chamber-gradient polynomial

\[
 v_\sigma(t)=\bigl(E_{w,t}U_{\sigma,1},\ldots,
                        E_{w,t}U_{\sigma,r}\bigr)
\]

is known. For each pair of adjacent arrangement chambers, divide the
gradient difference by the normal `Da` to recover `q_tau(t)`; the
divisibility and proportionality follow from continuity and (4.2).
Compute (5.1), choose a rational `t`, evaluate the gradients, and take
their convex hull.

This is finite for every input `(B,D,J,w)`. The theta coefficients in
(7.2) may be obtained from the previously established finite
combinatorial formula. No unknown theta Newton polytope is used to
bound the computation: the prescribed root set is the bound.

The polytope records the **full chamber geometry of the truncated
diagram**. It is not asserted to be the Newton polytope of one ordinary
theta function. Distinguishing these two objects is essential.

## 8. The scattering fan is detected by finite-order theta multiplication

This gives a property of theta multiplication itself, beyond the
existence of an associated polytope. Write `T_J(g)` for (7.1), and for
integral `g,h` put

\[
 T_J(g,h)=\max\{T_J(g),T_J(h),T_J(g+h)\},\qquad
 \Delta_J(g,h)=L_J(g)+L_J(h)-L_J(g+h).
\]

### Theorem 3: an effective coefficient-only compatibility criterion

The following conditions are equivalent.

1. The vectors `g,h` lie in a common closed cone of `Fan(D_J)`.
2. `Delta_J(g,h)=0` in `R_J`.
3. For some integer `N>T_J(g,h)`,
   `F_{Ng}F_{Nh}=F_{N(g+h)}` in `R_J`.
4. The same equality holds for every integer `N>T_J(g,h)`.
5. For some, equivalently every, integer `N>T_J(g,h)`, all positive
   root structure coefficients `c_{Ng,Nh}(q)`, `0<q in J`, vanish.

The equality in condition 3 can also be written
`theta_{Ng} theta_{Nh}=theta_{N(g+h)} mod I_J` after removing the
common leading Laurent monomial `x^{N(g+h)}`. This specifies exactly
what root-order truncation of the multiplication statement means.
In particular, one can use the single universal value `N=N_J` from
(7.4), irrespective of `g,h`. This gives a finite-order multiplication
test with an explicit label-independent scale.

**Proof.** If `g,h` share a closed scattering cone, `L_J` is linear on
that cone and hence condition 2 holds. Conversely, condition 2 gives
`Phi(g)+Phi(h)=Phi(g+h)`. Since `Phi=h_P` and `P` has exactly the
scattering normal fan, equality of these support-function values says
that `F_P(g)` and `F_P(h)` have a common point. Their intersection is
a nonempty face of a polytope, so it contains a vertex `v`. The
directions `g,h` both belong to the closed vertex normal cone
`N_P(v)`, proving condition 1. This uses a common closed cone; it does
not require either direction to lie in an open chamber.

For `N>T_J(g,h)`, equation (4.8) applies with `u=g,v=h`. The prefactor
is a unit in `R_J`, and exponential and logarithm are mutually inverse
on its nilpotent positive ideal over `Q`. Thus the product defect
vanishes if and only if `N Delta_J(g,h)=0`, equivalently if and only
if `Delta_J(g,h)=0`. This proves conditions 2--4, including the
stronger fact that one sufficiently large `N` suffices.

Finally, the right side of (4.7) is root-unitriangular and has
nonnegative coefficients. Every `F` has constant coefficient one.
Therefore it vanishes through `J` if and only if every structure
coefficient at a positive root in `J` vanishes. Downward closure is
essential here: a discarded root outside `J` cannot contribute back
to a surviving coefficient. This proves condition 5. Alternatively,
triangular inversion alone proves this equivalence without positivity.

### The first nonzero multiplication layer is exactly linear in `N`

Suppose the equivalent conditions fail. Let `d` be the first nonzero
`w`-weight of `Delta_J(g,h)`. For every `N>T_J(g,h)`, all structure
coefficients of weight less than `d` vanish, and for every `p in J`
with `w dot p=d` one has the exact identity

\[
 c_{Ng,Nh}(p)=N[z^p]\Delta_J(g,h)\ge0.        \tag{8.1}
\]

At least one such coefficient is strictly positive. Indeed, (4.8)
identifies the first root-coefficient layer, and root-unitriangularity
of the structure-constant expansion then identifies the same layer of
structure constants. This remains true for any componentwise-minimal
root of `supp(Delta_J(g,h))`, without choosing a weight.

In fact, every coefficient `[z^p]Delta_J(g,h)` in this first layer is
an integer. Apply (8.1) at any two consecutive sufficiently large
integers `N,N+1` and subtract: the difference of the two integral
structure coefficients is exactly `[z^p]Delta_J(g,h)`. Therefore the
first obstruction layer lies in `N[z]`, even though logarithms in
general have rational coefficients.

The same criterion holds for a finite list `g_1,...,g_k`: replace the
product by `prod_i theta_{Ng_i}`, the sum label by `N sum_i g_i`, and
the logarithmic defect by `sum_i L_J(g_i)-L_J(sum_i g_i)`. Equality
at the same universal scale `N_J` is equivalent to all labels lying
in one common closed cone. Indeed, equality in the support-function
inequality for a finite sum is equivalent to a nonempty intersection
of all maximizing faces; such an intersection contains a vertex.

Thus finite-order compatibility and its first obstruction can be
read from explicitly bounded large-label multiplication. They are
not assertions that `theta_g theta_h=theta_{g+h}` at the original
unscaled labels, or that finitely many tests determine the entire
untruncated fan. Exhausting the root monoid by `J` yields the full
closed-cone compatibility relation.

## 9. A compact convex realization of the full infinite structure

There is also a precise infinite consequence, with a necessary
terminological qualification.

Take nested total-degree cutoffs `J_N`, and for each one choose a
polytope `P_N` given by Theorem 1. Choose positive real numbers `b_N`
such that

\[
 \sum_N b_N R_N<\infty,\qquad
 R_N=\max_{x\in P_N}\|x\|.
\]

For instance, `b_N=2^(-N)/(1+R_N)` works. Define the convergent
Minkowski sum

\[
 K=\sum_{N\ge1}b_NP_N.
\]

It is a compact convex set: it is the image of the compact product
`prod_N P_N` under the uniformly convergent summation map. Its support
function is

\[
 h_K(g)=\sum_N b_N h_{P_N}(g).                 \tag{9.1}
\]

No common small `t` for all cutoffs is required; each `P_N` is already
a finite polytope with the correct normal fan.

Write `F_N(g)` and `F_K(g)` for the exposed maximizing faces in
direction `g`. Nonnegativity of each support-function defect gives

\[
 F_K(g)=\sum_N b_NF_N(g),
\]

and, more precisely,

\[
 F_K(g)\subseteq F_K(h)
 \quad\Longleftrightarrow\quad
 F_N(g)\subseteq F_N(h)\quad\hbox{for every }N. \tag{9.2}
\]

To prove the nontrivial implication, if some point of `F_N(g)` fails
to maximize `h`, choose that point as the `N`th summand and arbitrary
points of the other `F_j(g)`. The resulting point lies in `F_K(g)`
but has a strictly positive deficit from `h_K(h)`, since all deficits
are nonnegative and `b_N>0`. Thus it does not lie in `F_K(h)`.

Consequently equality of exposed faces of `K` is exactly simultaneous
equality of exposed faces at every finite cutoff. By Reading's
Proposition 3.8 this is precisely full scattering equivalence, when the
representatives have minimal support in every truncation.

Let `E_N(g)` be the finite scattering equivalence class of `g`, and
let `C_N(g)=closure(E_N(g))`. Let

\[
 E(g)=\bigcap_N E_N(g),\qquad C(g)=\overline{E(g)}.
\]

The closure cannot simply be omitted from the infinite statement. We
have

\[
 C(g)=\bigcap_N C_N(g)
     =N_K(F_K(g)).                            \tag{9.3}
\]

For the first equality, the easy inclusion is from left to right.
Conversely, if `h` is in every `C_N(g)`, then for `0<s<=1` the point
`(1-s)h+s g` lies in `relint C_N(g)=E_N(g)` for every `N`, by the
standard segment property of relative interiors. These points belong
to `E(g)` and converge to `h`. The second equality follows from (9.2).

Thus the **closed scattering classes** are exactly the normal cones
of the exposed faces of `K`. Reading defines the full scattering fan
by adjoining all faces of these cones. With the same face-closure
convention, the complete infinite scattering fan is realized by `K`.
One should not silently use the finite-polytope convention that every
scattering class is the relative interior of its closure: for infinite
fans that stronger assertion is not automatic. Likewise, for a general
compact convex body the phrase “normal fan” needs this explicit
face-closure convention. Formula (9.3) is the unambiguous content.

This convex body is not canonical: the choices of finite support
functions, small parameters, and summation weights vary. The full
scattering equivalence relation and the closed cones it realizes are
canonical up to the usual diagram equivalence.

## 10. What has and has not been proved

The proof establishes a finite rational polytope for every finite
downward root truncation of every classical skew-symmetrizable cluster
scattering diagram, with the exact scattering normal fan. It gives a
finite theta-data construction of that polytope and a compact convex
realization of the complete closed-class structure. It also gives an
effective criterion for truncated scattering-cone compatibility using
only vanishing of positive-root theta structure coefficients at one
sufficiently large pair of labels, with an exact linear formula for
the first nonzero obstruction.

It does not establish finite Laurent support for an arbitrary theta
label, identify `P_J` with `Newt(theta_g)`, or turn a local zero-root
monoid into a cluster seed. The polytope is a new concrete output of
stable theta data if the literature comparison confirms the proposed
generality and construction are not already available.
