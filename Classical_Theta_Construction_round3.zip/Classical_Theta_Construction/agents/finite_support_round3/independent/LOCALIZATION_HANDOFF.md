# Localization and finite support: independent handoff

Prepared 2026-11-13 UTC. Classical cluster algebras, principal coefficients, frozen variables inverted. This short branch was closed at the parent’s request to free a parallel slot; it does not claim to solve the general finite-output problem.

## 1. A precise reduction: division closure is the middle–upper gap

Let `A ⊂ M ⊂ U` denote the ordinary, middle and upper cluster algebras. Let `x_1,...,x_n` be one initial cluster. Then the following assertions are equivalent:

1. `M=U`.
2. If `f ∈ U` and `x^a f ∈ M` for some `a∈N^n`, then `f∈M`.
3. For every initial mutable coordinate, `M` is saturated under division by that coordinate inside `U`: `f∈U, x_i f∈M ⇒ f∈M`.

The implication (1)⇒(2) is immediate and (2)⇒(3) is a special case. For (3)⇒(1), take `f∈U`. It is a finite Laurent polynomial in the initial cluster with Laurent frozen coefficients. Choose `a≥0` clearing all mutable negative exponents. Then `x^a f` is an ordinary polynomial in initial mutable variables, with Laurent frozen coefficients, so lies in `A⊂M`. Apply coordinate division closure `|a|` times. This proves `f∈M`.

Therefore a blanket localization-saturation theorem cannot be used to bypass the existing `middle=upper` premise: it would prove precisely that premise. This is an elementary reduction, not a literature novelty claim.

For a promised regular theta function, the useful existence statement remains true:

`theta_g finite ⇒ x^a theta_g ∈ A` for some `a≥0`.

Since the product belongs to the middle algebra, it has a finite nonnegative theta expansion by theta strong positivity. But obtaining `theta_g` by reverse multiplication still needs control of the signs and support of the inverse operator.

## 2. Exact failure of positive reverse multiplication

Already in rank one with `B=(0)` and principal coefficient `y`, the exchange relation is

`x x' = 1+y`, with `theta_{-1}=x'`.

Set

`f = x'(1-y+y^2) = x^{-1}(1+y^3)`.

Then:

* `f` is a regular upper-cluster element (indeed an ordinary cluster element).
* Its initial-chart Laurent coefficients are nonnegative and its leading root coefficient is one.
* `x f = 1+y^3` has a finite nonnegative theta expansion.
* The theta expansion of `f` is `theta_{-1}-y theta_{-1}+y^2 theta_{-1}`, which has a negative coefficient.

Thus positive numerator + regular quotient + initial-chart positivity does **not** imply theta positivity of the quotient. In the adjacent chart the negative coefficient is visible. This example does not refute a stronger finite criterion and is not an impossibility theorem for the requested algorithm. It isolates the missing assertion in the naive denominator-clearing construction.

The accompanying exact SymPy script checks the factorization and both chart formulas over `Z[y,x,x^{-1}]`.

## 3. Primary-source checks

### CMMM 2026: extension does not remove finite span

Cheung–Magee–Mandel–Muller, *Valuative independence and cluster theta reciprocity*, arXiv:2505.09585v2 (21 May 2026), Sections 3.7 and 4.3, Theorems 3.14 and 4.12, read directly in the official PDF text already stored in the parent tree.

The extension theorem assumes that the theta function for the smaller diagram is a **finite linear combination** of theta functions for the extended diagram. Its proof takes the coefficient at the original label, then applies valuative independence to that finite expansion. The seed/unfreezing version checks the face-monoid condition and inherits this premise. Neither theorem establishes finite span from Laurent regularity.

Primary URL: https://arxiv.org/html/2505.09585v2

2026 review scope: exact statements and complete proofs of 3.14 and 4.12 were checked; no claim is made that this branch audited the whole paper or the later infinite-locus reciprocity discussion.

### GHKK: normality checked only under the stated global hypothesis

Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, author PDF version present in the parent tree: Section 9, especially Theorem 9.10 and its proof, read for possible normalization/saturation input. This theorem assumes enough global monomials; finite generation and a projective toric degeneration enter the proof of normality. The inspected passage does not give unconditional normality or coordinate-division saturation of an arbitrary middle cluster algebra.

Primary URLs: https://arxiv.org/abs/1411.1394 and https://paulhacking.github.io/canonicalbases.pdf

The numbering above is that of the local author PDF and is version-specific.

## 4. Search record and disposition

Three rounds of web searches covered: theta localization/freezing and regularity; formal completion/algebraization/finite determinacy; middle–upper equality, normality and division by cluster variables. The primary hits were GHKK, Qin’s freezing and injective-reachable papers, CMMM, and Reading–Stella. The latter two Qin/Reading routes were already present in the parent project and were not repackaged. No general effective finite-determinacy theorem was found in the checked sources.

An abstract appeal to Noetherianity is insufficient: an ascending sequence of coefficient ideals can stabilize without a recognizable stopping stage unless one has an effective finite defining system or a separate bound. This observation is a warning about a proposed proof step, not a claim of noncomputability for cluster theta functions.

No Li–Pan theorem is used. No conclusion from the 2026 Tang or Enhan Li papers was imported; those appeared only as search results.

## 5. Concrete next interface

A useful next theorem would be a **label-specific** positive-division certificate, weaker than coordinate saturation of all of `M` in `U`, that verifies all outgoing terms of the theta multiplication column for a target label using finite data. Denominator clearing guarantees that some finite numerator exists for every regular theta. It does not yet supply such a verifier. This branch leaves that construction to the parent rather than claiming that the numerator is already a complete stopping witness.
