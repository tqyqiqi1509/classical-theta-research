"""Exact check of the rank-one reverse-positivity obstruction."""
import json
import sympy as s

x, y = s.symbols("x y")
theta_minus_one = (1 + y) / x
signed_theta_coefficient = 1 - y + y**2
f = s.expand(theta_minus_one * signed_theta_coefficient)
assert s.expand((1 + y) * signed_theta_coefficient - (1 + y**3)) == 0
assert s.simplify(f - (1 + y**3) / x) == 0
assert s.simplify(x * f - (1 + y**3)) == 0

record = {
    "B": [[0]],
    "exchange": "x*xprime=1+y",
    "theta_minus_one": str(theta_minus_one),
    "quotient_initial_chart": str(f),
    "theta_expansion_frozen_coefficients": [1, -1, 1],
    "numerator": str(s.expand(x * f)),
    "status": "PASS",
}
print(json.dumps(record, indent=2))
