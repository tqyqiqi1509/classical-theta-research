"""Exact stress tests of the effective all-rank theta coefficient detector."""
from fractions import Fraction
from pathlib import Path
from itertools import product
from functools import lru_cache
import json, random, sys, time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'))
from incoming_recursion import IncomingSchur, box, le, sub

def add(u,v): return tuple(a+b for a,b in zip(u,v))
def scale(n,u): return tuple(n*a for a in u)
def dotD(u,D,v): return sum(a*d*b for a,d,b in zip(u,D,v))

def threshold(R,nu,g,cap):
    vals=[Fraction(0)]
    for s in box(cap):
        for a in box(s)[1:]:
            vals.append(Fraction(abs(dotD(R.shift(g,s),R.D,a)),abs(dotD(nu,R.D,a))))
    return max(vals)

def truncated_mul(F,G,cap):
    H={}
    for p,a in F.items():
        for q,b in G.items():
            s=add(p,q)
            if le(s,cap): H[s]=H.get(s,0)+a*b
    return {p:a for p,a in H.items() if a}

def theta_extract(R,g,F,cap,theta):
    c={}
    for p in box(cap):
        val=F.get(p,0)-sum(a*theta(R.shift(g,q),sub(p,q)).get(sub(p,q),0)
                           for q,a in c.items() if q!=p and le(q,p))
        if val: c[p]=val
    return c

def run_case(R,g,cap,rng):
    J=box(cap); h=R.shift(g,cap); u=tuple(range(1,R.n+1))
    K=1+max([0]+[abs(dotD(u,R.D,a))//abs(dotD(h,R.D,a))
                   for a in J[1:] if dotD(h,R.D,a)])
    nu=add(scale(K,h),u)
    assert all(dotD(nu,R.D,a)*dotD(h,R.D,a)>0 if dotD(h,R.D,a)
               else dotD(nu,R.D,a)>0 for a in J[1:])
    T=max(threshold(R,nu,R.zero,cap),threshold(R,nu,g,cap))
    N=T.numerator//T.denominator+1
    theta=lru_cache(None)(lambda label,cut: R.theta_prefix(label,cut))
    A={q:rng.randrange(-3,4) for q in J}
    A[cap]=-1-rng.randrange(3)
    F={}
    for q,a in A.items():
        if not a: continue
        for s,b in theta(R.shift(g,q),sub(cap,q)).items():
            p=add(q,s); F[p]=F.get(p,0)+a*b
    target=add(scale(N,nu),g)
    H=truncated_mul(F,theta(scale(N,nu),cap),cap)
    C=theta_extract(R,target,H,cap,theta)
    assert C.get(cap,0)==A[cap],(R.B,g,cap,nu,N,A[cap],C.get(cap,0))
    return {'g':g,'p':cap,'h':h,'nu':nu,'K':K,'N':N,'threshold':str(T),
            'target_coefficient':A[cap],'observed':C[cap],
            'root_entries':len(J),'prefixes':theta.cache_info().currsize}

def main():
    rng=random.Random(202611131901); start=time.time()
    specs=[('wild_rank2',[[0,3],[-3,0]],[1,1],(3,3),80),
           ('skew_symmetrizable_rank2',[[0,3],[-2,0]],[2,3],(3,3),80),
           ('acyclic_rank3',[[0,1,2],[-1,0,1],[-2,-1,0]],[1,1,1],(2,2,2),40),
           ('markov_rank3',[[0,2,-2],[-2,0,2],[2,-2,0]],[1,1,1],(2,2,2),40),
           ('valued_rank3',[[0,2,1],[-1,0,1],[-1,-2,0]],[1,2,1],(2,2,2),40),
           ('mixed_rank4',[[0,1,-1,2],[-1,0,2,0],[1,-2,0,1],[-2,0,-1,0]],
            [1,1,1,1],(1,1,1,1),80)]
    results=[]
    for name,B,D,cap,count in specs:
        R=IncomingSchur(B,D); rows=[]
        for _ in range(count):
            g=tuple(rng.randrange(-5,6) for _ in D)
            rows.append(run_case(R,g,cap,rng))
        results.append({'name':name,'B':B,'D':D,'cap':cap,'cases':rows,
                        'incoming_cache':R.c.cache_info()._asdict()})
        print(name,len(rows),'PASS',round(time.time()-start,3),flush=True)
    out={'status':'PASS','cases':sum(len(r['cases']) for r in results),
         'root_entries':sum(sum(c['root_entries'] for c in r['cases']) for r in results),
         'seconds':time.time()-start,'families':results}
    target=Path(__file__).with_name('detector_verification.json')
    target.write_text(json.dumps(out,indent=2))
    print('OUTPUT',target,flush=True)

if __name__=='__main__': main()
