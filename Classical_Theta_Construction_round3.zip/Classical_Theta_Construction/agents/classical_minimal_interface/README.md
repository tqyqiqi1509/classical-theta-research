# Classical minimality interface: handoff

## Established in this branch

1. `ALL_RANK_COEFFICIENT_DETECTOR.md`: exact all-rank detector, explicit root-box
   threshold, and a regular theta multiplier construction. Proof depends on the
   parent's incoming/translated-ray theorem. It does not assume an alternative
   basis is scattering-positive.
2. `NEWTON_ENVELOPE_LIMIT.md`: a Weyl-invariant open cone of nonparallel deficits
   invisible to every seed's Newton envelope, explaining why the proposed convex
   replacement of quantum rigidity is insufficient.

## Verification

* `detector_verify.py`, `detector_verification.json`: 360 exact tests; 7,080 root
  entries; ranks 2--4, skew-symmetric and skew-symmetrizable; all pass.
* `wolfram_exact_checks.json`: exact symbolic containment and reflection checks.
* `newton_verification.json`: independent SymPy symbolic reflection residuals
  and 7,380 finite Weyl checks, all pass.
* `carrier_coefficient_probe.py`, `carrier_coefficient_probe.json`: finite
  exploratory carrier family; no sufficient zero-coefficient envelope found.
  This is a route record, not a negative theorem about all carriers.

`LITERATURE_AUDIT.md` states what was read, what is accepted, and what is not
used. `ROUTES.md` records the successful and unsuccessful mechanisms. Downloaded
primary texts are under `sources/`; parent may omit duplicate PDFs from the final
package to keep it compact.

## Unresolved, not claimed

For an arbitrary classical strongly positive pointed basis B containing cluster
monomials, we have not proved the large-label transition window vanishes, that
the detector multiplier is B-positive, or that every B-element has nonnegative
theta expansion. Thus no least strongly positive basis theorem or general
triangular-to-theta positivity theorem is asserted.
