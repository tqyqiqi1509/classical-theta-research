# Why classical Newton envelopes do not supply the quantum rigidity step

This is a general mechanism check, retained only to prevent a false proof. The
research route continues with exact coefficients and multiplication.

Let b,c>0 with bc>4. For a positive rank-two imaginary denominator label a, the
greedy (=theta) Newton convex hull in pointed coordinates is

    Delta(a) = conv{(0,0),(a2,0),(0,a1)}.

Indeed Lee--Li--Zelevinsky, arXiv:1208.2391v3, Proposition 4.1(6), bounds support
by the possibly nonconvex broken-line region through (a1/b,a2/c); for imaginary
labels that point lies in this triangle, while all three corner coefficients
are nonzero.

For a positive deficit d with d1 divisible by b and d2 divisible by c, the
Newton triangle of G[a-d], viewed in G[a]'s pointed coordinates, has vertices

    (d1/b,d2/c),
    (a2-d2+d1/b,d2/c),
    (d1/b,a1-d1+d2/c).

If a-d is positive, containment in Delta(a) follows exactly from

    I1(a,d) = c a1 d1 + b a2 d2 - bc a2 d1 <= 0,
    I2(a,d) = c a1 d1 + b a2 d2 - bc a1 d2 <= 0.            (1)

The first vertex is coordinatewise below the other two, so its hypotenuse
inequality is then automatic. These inequalities allow an open cone of
nonparallel deficits when a is strictly imaginary: the interval of allowed
ratios has nonempty interior precisely when

    1 - a1/(b a2) - a2/(c a1) > 0.

There is no rescue by applying the same convex test in all rank-two seeds.
Under either simultaneous Weyl reflection

    s1(a)=(b a2-a1,a2),   s1(d)=(b d2-d1,d2),
    s2(a)=(a1,c a1-a2),   s2(d)=(d1,c d1-d2),

the two forms I1,I2 are exchanged. For positive imaginary a,d,a-d, all their
Weyl transforms remain positive imaginary. Thus (1) proves Newton containment
in every cluster chart, with the parameters interchanged as needed.

For example, b=c=3, a=N(1,1), d=(6,9), N>=11. Both d and a-d are positive
imaginary, the two containment forms are -9N and -36N, and d is not parallel to
a. The shifted vertices in the initial pointed triangle are

    (2,3), (N-7,3), (2,N-3).

Consequently G[a]+G[a-d] is universally positive, pointed at the same leading
label in every seed, and has exactly the same Newton polytope as G[a] in every
seed. Pointedness follows because every reflected deficit remains positive.
This observation does NOT assert that
these chosen elements extend to a strongly positive basis. It proves the
narrow point needed here: every method using strong positivity only to derive
carrier Newton containment cannot distinguish these elements, even if the
carrier envelopes are strengthened to the exact theta Newton polytopes.

The sparse supports differ: the upper vertex (2,N-3) of the shifted term is
outside the nonconvex support bound for G[N,N], whose upper boundary near that
vertex is q=N-2p. Thus an exact-coefficient or multiplication argument can still
distinguish them. Convexification discards precisely the necessary information.

Independent symbolic validation: Wolfram Language expanded all three triangle
inequalities and recovered the ratio interval [1/2,2] for b=c=3,a1=a2.
The code and further finite verification are recorded with this branch.
SymPy independently gives zero for all four symbolic reflection residuals;
7,380 finite Weyl checks (N=11,...,100, both alternating words through length
40) also pass. The proof for every word is the symbolic identity, not the finite
checks. Wolfram emitted a static undefined-symbol warning for the user-defined
function names in the second call, but evaluated the definitions and returned
the same four exact zeros; the independent SymPy check resolves that tool-level
warning.
