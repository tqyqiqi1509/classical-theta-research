"""Search exact theta-coefficient envelopes of leading cluster products.

Only a finite carrier family is tested. A positive minimum here is not a lower
bound for all cluster products. No basis-minimality claim follows from a search.
"""
from pathlib import Path
from functools import lru_cache
from itertools import combinations_with_replacement
from math import ceil
import json, sys, time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from detector_verify import IncomingSchur, add, scale, truncated_mul, theta_extract, box

def power(F,n,cap):
    out={(0,)*len(cap):1}
    while n:
        if n&1: out=truncated_mul(out,F,cap)
        F=truncated_mul(F,F,cap); n//=2
    return out

def cluster_labels(depth,b=3):
    out=[(1,0),(0,1),(0,-1),(-1,0),(-1,b)]
    lo=[(0,-1),(-1,0)]
    hi=[(0,1),(-1,b)]
    for _ in range(depth):
        lo.append(tuple(b*z-w for z,w in zip(lo[-1],lo[-2])))
        hi.append(tuple(b*z-w for z,w in zip(hi[-1],hi[-2])))
    return sorted(set(out+lo+hi))

def main():
    start=time.time(); R=IncomingSchur([[0,3],[-3,0]])
    cap=(3,3); zero=(0,0)
    theta=lru_cache(None)(lambda label,cut:R.theta_prefix(label,cut))
    vars=[v for v in cluster_labels(7) if v[0]<0]
    rows=[]
    for nu in [(-1,1),(-2,3),(-3,4)]:
      for N in [5,10,20,50]:
        g=scale(N,nu); candidates=[]
        for v in vars:
          m0=max(1,ceil((-g[0])/(-v[0])))
          for m in [m0,m0+1,2*m0]:
            vg=scale(m,v)
            if vg[0]>g[0]: continue
            # Initial x1 and x2 adjust nonnegative differences. A negative x2
            # difference is supplied by the cluster variable with g=(0,-1).
            k=max(0,vg[1]-g[1])
            F=truncated_mul(power(theta(v,cap),m,cap),
                            power(theta((0,-1),cap),k,cap),cap)
            C=theta_extract(R,g,F,cap,theta)
            assert all(a>=0 for a in C.values()),(g,v,m,k,C)
            candidates.append((v,m,k,C))
        minima={p:min(c[3].get(p,0) for c in candidates) for p in box(cap)[1:]}
        witnesses={p:next((c[0],c[1],c[2]) for c in candidates
                         if c[3].get(p,0)==minima[p]) for p in minima}
        rows.append({'nu':nu,'N':N,'g':g,'carriers':len(candidates),
                     'minimum_theta_coefficients':[[p,a,witnesses[p]] for p,a in minima.items()]})
        print(nu,N,{p:minima[p] for p in [(1,1),(1,2),(2,1),(2,3),(3,2)]},flush=True)
    out={'status':'PASS','seconds':time.time()-start,'cap':cap,'rows':rows}
    Path(__file__).with_name('carrier_coefficient_probe.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':main()
