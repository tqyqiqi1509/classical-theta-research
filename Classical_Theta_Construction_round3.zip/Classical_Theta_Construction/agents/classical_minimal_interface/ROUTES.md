# Classical minimal strong-positive interface: live route log

Started 2026-11-13 18:31 UTC. Scope: ordinary classical cluster algebras,
skew-symmetric first; principal coefficients used to retain root degrees.

## R1. Carrier Newton intersection (in progress)

Input: every strongly positive pointed basis containing all cluster monomials is
cluster-atlas universally positive. A product P of cluster variables with leading
label g expands positively and has leading B_g coefficient one. Hence B_g <= P
coefficientwise in each cluster chart. Intersecting all carrier Newton polytopes
gives a computable outer bound independent of the competing basis.

Question: does this force fixed-deficit B-to-theta transition rigidity along
large generic rays? Initial analysis warns that convex containment inside even
the actual greedy Newton triangle may allow an open cone of fixed deficits in
wild rank two. This is being verified before accepting any rigidity claim.

## R2. Sparse carrier coefficients (in progress)

Unlike Newton envelopes, exact coefficient bounds preserve holes. Seek a finite
carrier family whose minimum coefficient at strategically chosen translated
vertices isolates the transition coefficients. This must yield an independently
checkable condition in cluster products, not assume theta positivity of the
competing basis.

## R3. Stable-ray coefficient detection (available parent mechanism)

Parent transverse-ray theorem gives a common finite chart on a generic large ray.
It should imply a high-rank analogue of the coefficient-detection step in Tang
2610.00083v2, but does not by itself replace the quantum degree/bar-invariance
rigidity step. Need avoid presenting this conditional reduction as a proof of
minimality.

## R4. Positive multiplication and asymptotic coboundaries (new exploratory)

In a finite generic chart, competing-basis multiplication is a conjugate of a
translation operator. At the first unresolved deficit its coefficient may have
the form c + T_N(q) - T_{N+g}(q). Strong positivity plus a basis-independent lower
bound/sublinear growth of T_N could force c >= 0 by iteration. No such adequate
bound established yet; naive polynomial coefficient bounds are insufficient.

## Literature audit

* Davison--Mandel, arXiv:1910.12915v3, Section 1.4: read. Minimality is conjectural;
  the comparison is Laurent coefficientwise. Scattering-atlas atomicity is
  stronger than cluster-atlas positivity. Useful, valid; not a theorem resolving
  the present target.
* Mandel, arXiv:1605.03202v2: full three pages read. Theorem 1 is atomicity for the
  enlarged scattering atlas. Useful coefficient extraction proof, but replacing
  that atlas by the cluster atlas is invalid.
* Rupel--Stella, arXiv:2206.04778v2, Theorems 1.1--1.6 read. Explicit dominance
  polygons permit many pointed-basis deformations in the imaginary cone. Useful
  for pressure testing; pointedness alone does not imply rigidity.
* Tang, Hexagon2610.00083v2, Sections 3--5 (local prior work): quantum rank-two
  rigidity uses bar-invariance and a quantum-degree ellipse. It cannot be
  specialized to prove a claim about every classical strongly positive basis.
  The finite-chart/coefficient-detection portion can be examined independently.

All downloaded papers are in sources/. No Li--Pan conclusion is used.

## Round close, 2026-11-13 18:56 UTC

R1 is closed as insufficient for the intended rigidity proof: the all-seed
Weyl-invariant triangle containment mechanism is proved in
NEWTON_ENVELOPE_LIMIT.md. It is not a counterexample to strong-positive
minimality. Exact support holes remain visible and are lost by convexification.

R2 was pressure-tested with a finite family of leading cluster products in
wild rank two. Through root window (3,3), 12 scaled directions and 48 carriers
per direction were compared by exact theta coefficient extraction. The tested
family did not produce the proposed zero transition envelope. This finite
experiment proves no impossibility statement for all products and is not used
as a mathematical premise. See carrier_coefficient_probe.py/json.

R3 succeeded: an arbitrary-rank, skew-symmetrizable coefficient detector with
an explicit finite threshold is proved in ALL_RANK_COEFFICIENT_DETECTOR.md.
The threshold controls all shifted output labels simultaneously, and the
multiplier can be chosen in the regular theta domain when the target is regular.
360 exact randomized tests over ranks 2--4 and 7,080 root-window entries passed;
each input included a deliberately negative target theta coefficient, which
survived unchanged. This is not a positivity proof for competing bases.

R4 is left open. Positive multiplication plus a uniform lower bound on the
appropriate first-deficit transition would yield a useful telescoping argument.
The available cluster-product coefficient bounds do not establish that lower
bound after the necessary scattering-coordinate change. Lower-degree positive
transition terms can also contribute, so the naive scalar coboundary reduction
does not justify an induction for arbitrary deficits.

Parent requested ending this branch to free an independent-review slot. The
unresolved bridge is retained explicitly; no claim of a classical least strongly
positive basis or triangular-to-theta positivity has been made.
