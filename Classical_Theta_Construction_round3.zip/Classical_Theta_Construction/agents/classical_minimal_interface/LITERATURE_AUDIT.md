# Literature audit for this branch

Checked 2026-11-13 18:31--18:56 UTC. Searches used both web engines; authoritative
paper text, not snippets, supplies every adopted mathematical statement.

| Work | Precisely inspected | Correctness / usefulness assessment | Adoption |
|---|---|---|---|
| Davison--Mandel, Strong positivity for quantum theta bases of quantum cluster algebras, arXiv:1910.12915v3 | Section 1.4 paragraphs on minimality; strong positivity and scattering-atlas definitions; Theorem 3.16 statement and proof interface | Published result. Minimality paragraph is explicitly conjectural. Its `minimal` is not automatically `least`; cluster-atomicity does not establish comparison against every other positive basis. | Used to formulate the unresolved target and prevent an invalid atlas substitution. No conjecture used as a theorem. |
| Mandel, Theta bases are atomic, arXiv:1605.03202v2 | Entire three-page paper, especially Theorem 1 and its proof | Proof uses coefficient extraction in a scattering chart near the target. Cluster and scattering atlases are explicitly distinguished. | Adopted extraction interface only; no cluster-atlas atomicity assumption. |
| Lee--Li--Zelevinsky, Greedy elements in rank 2 cluster algebras, arXiv:1208.2391v3 | Definitions 1.2--1.3, Proposition 1.5--1.6, Theorem 1.7, Proposition 1.8, Proposition 4.1 and its adjoining explanation | Published primary source. Proposition 4.1 gives the possibly nonconvex support bound; corner support is nonzero. Proposition 1.8 gives the piecewise reflections. Those imply the Newton statements used here. | Adopted for the all-seed Newton pressure test. The nonconvex support bound is not silently replaced by a convex bound in a rigidity proof. |
| Rupel--Stella, Dominance regions for rank two cluster algebras, arXiv:2206.04778v2 | Theorems 1.1--1.6 and their introductory interpretation | Explicit pointed-basis deformation space is useful. This branch did not independently reprove the full dominance-region classification. | Motivation and cross-check only; neither of our proved notes depends on the classification. |
| GHKK, Canonical bases for cluster algebras, arXiv:1411.1394v2; authors' hosted PDF | Introductory theorem: Theta contains global monomial labels and is additively closed/saturated; standard last-exponent extraction cited via Mandel | Established primary result. Closure is for the specified regular theta domain; it is not an unrestricted statement that all integral labels give Laurent polynomials, nor that every regular theta lies in ordinary A. | Adopted to make the detector multiplier regular when the target is regular. Ordinary A membership is separately qualified. |
| Tang, Strongly positive bases and quantum greedy expansions, Hexagon2610.00083v2 (2026) | Local full text, Sections 3--5, especially the ellipse, finite chart, and coefficient-detection mechanism | Strong audit of the dependency relevant here: Section 3 uses quantum bar-degree and cannot be specialized to encompass all classical bases. The detection step has been independently reproved here in arbitrary classical rank from the parent's exact extraction theorem. The paper's overall quantum theorem was not assumed. | Used as our own rank-two antecedent and source of the question. No 2026 global claim imported without an independent argument. |
| Reading--Stella, Mutation of Theta Functions, SIGMA 22 (2026),109, arXiv:2603.19391 | Official publication page, date and abstract; referenced dominance interface | Metadata confirms the new publication. This branch did not finish a theorem-by-theorem proof audit. It works in a specified small canonical algebra, so ordinary upper-algebra claims would need careful translation. | Not adopted as a proof input. Kept as a future interface. |

## Retrieval links

* https://arxiv.org/html/1910.12915v3
* https://arxiv.org/abs/1605.03202
* https://arxiv.org/abs/1208.2391
* https://arxiv.org/abs/2206.04778
* https://arxiv.org/abs/1411.1394
* https://paulhacking.github.io/canonicalbases.pdf
* https://hexagonmath.org/pdf/2610.00083v2
* https://sigma-journal.com/2026/109/

No Fei, CMMM, or Li--Pan conclusion is required for either theorem proved in
this branch. Fei/CMMM remain potential interfaces for the parent project, not
hidden assumptions in the detector proof.

## Novelty decision

The coefficient-extraction fact is established literature. The rank-two product
detector is present in our own prior paper. The proposed addition is the uniform
arbitrary-rank, principal-coefficient product identity with an explicit threshold
and legal regular multiplier construction. This is a mechanism-level extension,
not a claim of a new atomicity theorem or a solution of the least-basis problem.
Further novelty review by the parent should compare the effective statement
against Qin's freezing results and CMMM local-star results; no identification
of the transverse basis as a new object is claimed here.
