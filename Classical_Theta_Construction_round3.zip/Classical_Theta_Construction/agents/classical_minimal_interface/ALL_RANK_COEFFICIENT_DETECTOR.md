# An effective all-rank theta coefficient detector

Status: proved from the parent's incoming extraction and translated-ray theorem;
independent exact computations are recorded separately. This is a classical,
root-graded statement, valid for a skew-symmetrizable exchange matrix with a
positive integral symmetrizer. It does not prove minimality of every strongly
positive basis.

## 1. Statement with explicit finite data

Let B be the exchange matrix, D its diagonal symmetrizer, and

    z_i = y_i x^(B e_i),  theta_g = x^g F_g(z).

Let a pointed formal element have its unitriangular theta expansion

    f = sum_(q >= 0) a_q y^q theta_(g+Bq).

Fix p >= 0, put J = [0,p] and h = g+Bp. Only the coefficients through J matter;
f need not have a finite theta expansion for the formal version.

Choose an integral vector nu so that, for every 0 < a <= p,

    sign(nu^T D a) = sign(h^T D a) if h^T D a != 0,
    nu^T D a > 0                    if h^T D a = 0.          (1.1)

Thus nu is generic for this finite root set, with the positive tie convention.
This is constructive: choose any strictly positive integral vector u and let

    nu = K h + u,
    K > max_{0<a<=p, h^TDa!=0} |u^T D a| / |h^T D a|.       (1.2)

For an integral vector v define

    T_J(nu;v) = max({0} union
        { |(v+B s)^T D a| / |nu^T D a| : s in J, 0<a<=s }). (1.3)

For every integer

    N > max(T_J(nu;0), T_J(nu;g)),                          (1.4)

the following exact coefficient identity holds:

    [ y^p theta_(N nu + h) ] (f theta_(N nu)) = a_p.        (1.5)

The coefficient on the left is measured in the theta expansion based at the
common initial leading label N nu + g; principal coefficient exponents are
retained. Formula (1.5) is exact, not an asymptotic limit, and N is computable
from B,D,g,p,nu alone.

## 2. Proof

Write A = A_nu^- for the negative factor of the incoming total automorphism in
the quotient by the root ideal outside J. By (1.1) there are no zero roots in J.
The translated-ray theorem gives

    theta_(N nu) = A(x^(N nu)) mod J.                     (2.1)

It also gives, for each q in J,

    theta_(N nu+g+Bq) = A(x^(N nu+g+Bq)) mod [0,p-q].      (2.2)

Here is why the single threshold (1.4) controls all q simultaneously. In the
extraction defining the coefficient at s <= p-q, its endpoint is
N nu+g+B(q+s). Put t=q+s. Then t belongs to J and every root a relevant to the
extraction satisfies 0<a<=s<=t. Consequently

    |(g+B(q+s))^T D a| / |nu^T D a| <= T_J(nu;g).

All required endpoint signs therefore equal the nu-signs. Applying the common
automorphism A^{-1} to the theta expansion of f theta_(N nu), and using its
multiplicativity together with (2.1)--(2.2), shows that the left side of (1.5) is

    [x^g z^p] A^{-1}(f).                                 (2.3)

Condition (1.1) says that A is precisely the finite negative factor used by the
last-exponent extraction at endpoint h=g+Bp, restricted to each relevant smaller
root interval. For q<p, this extraction annihilates the coefficient of
x^(g+Bq) z^(p-q) in theta_(g+Bq). For q=p it reads its leading coefficient one;
for q not <=p it contributes nothing. Hence (2.3) equals a_p. QED.

## 3. Ensuring that the multiplier is a regular theta function

If theta_h is a regular theta function, choose u as an initial cluster-monomial
label. The standard GHKK theta domain Theta contains u and is closed under
addition in the chosen seed lattice. Therefore

    nu=K h+u,   N nu,   N nu+h

are regular theta labels. This does not make theta_(N nu) an element, or a
positive combination of elements, of an arbitrary alternative positive basis.
That separate issue is precisely where a minimality proof still needs work.

If the coefficient problem is in the ordinary cluster algebra rather than the
middle algebra, regularity in the upper algebra alone should not be silently
replaced by membership in the ordinary cluster algebra. A legal multiplier in
the desired algebra follows when theta_h belongs to that algebra and its label
domain is known closed under the indicated leading-component operation (for
example via an explicit positive carrier). The formal identity itself does not
require that additional assertion.

## 4. Consequence and the remaining positivity bridge

A negative theta coefficient a_p survives unchanged as a structure coefficient
after multiplication by every sufficiently large theta_(N nu) in the explicit
cone (1.1). Thus no uncertainty about stabilization or choice of endpoint is
needed in trying to disprove a claimed positive expansion: this gives a finite
exact witness and a threshold.

For a strongly positive competing basis B, one cannot conclude that
f theta_(N nu) is B-positive merely because f belongs to B. One also cannot
identify its coefficient at B_(N nu+h) with (1.5) without controlling the finite
B-to-theta transition window. Those are two distinct missing bridges.

The result generalizes the finite-chart detection part of Tang,
Hexagon2610.00083v2, Section 5, from rank two to arbitrary classical rank and
adds an explicit threshold. It does not import the quantum bar-degree rigidity
from Section 3 of that paper.

## Sources and novelty status

* Parent: agents/stable_adversarial/TRANSVERSE_RAY_THEOREM.md, Sections 1--4.
* Tang, Strongly positive bases and quantum greedy expansions,
  https://hexagonmath.org/pdf/2610.00083v2, Section 5: rank-two antecedent.
* Mandel, Theta bases are atomic, arXiv:1605.03202v2, proof of Theorem 1:
  coefficient extraction near the target label is standard.
* GHKK, Canonical bases for cluster algebras, arXiv:1411.1394v2, introduction
  theorem on Theta containing global monomials and being additively closed.

The claimed contribution here is the effective arbitrary-rank product detector
derived from the present incoming recursion, not a new atomicity theorem.
