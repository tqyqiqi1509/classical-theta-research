# Tropical support certificates: exact reduction to existing mechanisms

2026-11-14. Literature and formula audit requested by the parent after the local-algebra review. Classical q=1, arbitrary skew-symmetrizable data. The conclusions below deliberately narrow the novelty claim.

## 1. Conclusions

1. The displayed minimum-degree reflection is exactly ordinary tropical A-cluster mutation with an additional frozen frame. It is not a new tropical mutation formula.
2. The proposed finite-word feasible set is actually one convex rational polyhedron. The finite-union construction in the draft is correct, but unnecessarily weak.
3. In the doubled coefficient setting, the support inequalities also follow from GHKK's min-convexity of tropical global monomials, together with the already established positive-freezing/Mandel detector identification. They do not require the new complementary-Q length theorem.
4. Thus the claim that remains specific to the Q argument is its full-Artin realization of these mutations, with the generic-residue origin factor, collision deformation, and nilpotents retained. The numerical support certificate should be presented as an explicit consequence of known tropical convexity and the detector construction, rather than a new general support mechanism.

The direct derivation in Sections 3–6 is my mathematical comparison of the sources with the project's conventions. I did not find a source stating this exact doubled-coordinate certificate verbatim. That does not make the resulting corollary independent of the established mechanisms.

## 2. Exact primary statements read

### Tropical mutation and tropical polyhedra

K. Rietsch and L. Williams, *A superpotential for Grassmannian Schubert varieties*, arXiv:2409.00734v2, Section 7, Definition 7.5, equation (7.3), p.25, defines tropical A mutation by the minimum of the incoming and outgoing weight sums minus the mutated weight. Proposition 7.6 transports polyhedra cut out by tropical universally positive Laurent polynomials and cites their earlier Corollary 11.16. This is the exact scalar operation in the draft.

Primary PDF: https://arxiv.org/pdf/2409.00734 . Retrieval references: turn858view2 and turn859view1.

### Positive Laurent phenomenon and min-convexity

Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*, arXiv:1411.1394v2: Corollary 0.4 / Theorem 4.10 gives positive Laurent expansions of cluster variables. Definition 8.2 measures min-convexity by the derivative on broken-line monomial decorations. Proposition 8.14 proves this property for tropicalizations of global monomials. Lemma 8.19 already gives finite tropical-global-monomial boundedness certificates in its EGM setting. The exact support deduction below uses Definition 8.2 and Proposition 8.14, not a general full Fock–Goncharov or EGM conclusion.

Primary PDF: https://arxiv.org/pdf/1411.1394 . Retrieval references: turn858view3, turn864view1, turn865view0, turn865view1, turn869view1.

### Separation of additions

Fomin–Zelevinsky, *Cluster algebras IV: Coefficients*, arXiv:math/0602259v3, Theorem 3.7 and Corollary 6.3, equation (6.5), express a cluster variable using its principal F-polynomial and g-vector, with the coefficient-semifield evaluation in the denominator. This gives the explicit specialization calculation below.

Primary PDF: https://arxiv.org/pdf/math/0602259 . Retrieval references: turn869view0, turn878view0, turn878view1.

### Dominance and Newton-polytope scope

Reading–Stella, *Mutation of Theta Functions*, SIGMA 22 (2026), 109, Section 5.3, defines dominance regions by intersecting nonnegative-cone conditions over mutation words. Theorem 5.4 restricts theta labels in certain theta products; Theorem 5.6 characterizes pointed elements through more refined word constraints. These are close structural precedents, but their stated objects are not the monomial support of a single arbitrary theta series.

Primary PDF: https://arxiv.org/pdf/2603.19391 . Retrieval references: turn859view0, turn860view1, turn861view0–turn861view2.

Rupel–Stella, *Dominance Regions for Rank Two Cluster Algebras*, arXiv:2206.04778v2 / Annals of Combinatorics 27 (2023), Theorem 1.6, already gives maximal possible support polygons for pointed rank-two basis elements. This rules out presenting rank-two outer support polygons as a new general principle.

Primary PDF: https://arxiv.org/pdf/2206.04778 . Retrieval reference: turn865view2; publisher statement at https://link.springer.com/article/10.1007/s00026-023-00636-4 .

Fei, *Tropical F-polynomials and General Presentations*, arXiv:1911.10513v6, Theorem 6.4 and Algorithm 6.5, gives a terminating generic representation Newton-polytope computation for path algebras, using bounded normal vectors and cluster mutation. The paper's broader Jacobian/cluster interpretation includes conjectural statements; it is not a theorem for all skew-symmetrizable theta labels. No identification with that broader conjectural scope is used here.

Primary PDF: https://arxiv.org/pdf/1911.10513 . Retrieval references: turn858view1, turn860view4, turn861view3.

## 3. The degree update is ordinary tropical A mutation

Use the conventional exchange matrix whose columns index mutable directions. Its mutable block is C^T, not C. Add the frozen frame row G^T. If only indices I are mutated, declare J frozen as well and retain the corresponding rows. Give the frame variable weight 1 and all other initial variables weights P.

The exchange relation in direction k has two monomials with weights

    alpha_k = [G_k]_+ + sum_j [C_kj]_+ P_j,
    beta_k  = [-G_k]_+ + sum_j [-C_kj]_+ P_j.

Tropicalizing the positive exchange sum gives

    P'_k = min(alpha_k,beta_k)-P_k.

The frozen-row mutation is

    G'_j = G_j + [C_jk]_+ G_k + C_jk[-G_k]_+,
    G'_k = -G_k,

exactly the draft's framing mutation. This comparison uses the transpose for arbitrary skew-symmetrizable data; replacing row exponents by column exponents without transposition would be incorrect.

## 4. A direct intertwining identity, including symmetrizers

There is an elementary coordinate check that removes any ambiguity about tropical conventions.

Let w be a vector, put m=Cw, and tropical-mutate w for the A exchange matrix C^T. Write S_+=sum_j[C_kj]_+w_j and S_-=sum_j[-C_kj]_+w_j. Then S_+-S_-=m_k. Using C'=mu_k(C), direct substitution gives

    (C'w')_k = -m_k,
    (C'w')_j = m_j+[C_jk]_+m_k+C_jk[-m_k]_+  (j!=k).

Thus multiplication by C intertwines A tropical mutation with the usual g/scattering piecewise-linear mutation in precisely the project's convention.

No symmetry of C was used in this calculation. If DC is skew-symmetric, then C^T has the dual symmetrizer, proportional to D^(-1). The GHKK tropical lattice conventions may replace individual coordinates by positive integer multiples; min-convexity and the sign of the inequalities are unchanged under those positive rescalings. One need not assert an incorrect integral lattice isomorphism.

There is also a direct verification using GHKK Lemma 8.15(1). In the seed where the chosen cluster coordinate is an initial coordinate, its transported tropical function is the linear functional e_i^T C_t^(-1) on primitive scattering coordinates. Its value on an initial scattering increment C_t alpha is alpha_i>=0. If physical coordinates use D_t C_t alpha, pull back the functional by D_t^(-1); the value remains alpha_i. Lemma 8.15(1) therefore makes it min-convex in that chart. The exact intertwining identity above and the mutation invariance in Definition 8.2 transport this statement to the original chart. This proves precisely the required min-convexity without relying on informal A/X identifications, and is the same mechanism used to prove Proposition 8.14.

When C is invertible, let

    w0=C^(-1)G,  w1=C^(-1)(G+CP)=w0+P.

Subtract the tropical A updates of w0 and w1. Since the difference between the two exchange-monomial weights at w0 is G_k, the difference after mutation is exactly the draft's minimum-degree reflection. Inductively, for every word and coordinate i,

    P_i^(word) = X_i,word^trop(w1)-X_i,word^trop(w0),       (4.1)

where X_i,word is the ordinary cluster variable of the C^T pattern. Formula (4.1) is an identity of piecewise-linear functions. It does not use the Q model or theta coefficients.

## 5. Why the finite-word feasible set is convex

In the frozen-frame description, each X_i,word has a finite positive Laurent expansion in the initial variables, by the positive Laurent phenomenon. Consequently its tropicalization is the minimum of finitely many integral linear forms in the initial weights.

Setting the frame weight to 1 and setting P=(r+q,r), or P=(p,p), restricts those linear forms to integral affine functions of q or p. The condition

    X_i,word^trop(1,P)>=0

is equivalent to every one of those finitely many affine functions being nonnegative. It is therefore a rational convex polyhedron. Intersecting finitely many words, coordinates, and initial nonnegative constraints gives one rational convex polyhedron, possibly empty or unbounded.

The draft's branch-by-branch minimum expansion remains a correct exact algorithm. Its polyhedral pieces collectively represent this one convex set. The stronger convexity statement is an existing positive-Laurent consequence, not an additional new convexity theorem.

## 6. Direct support containment from GHKK plus the detector

Now specialize to

    C = [[B,I],[-I,0]],  G=(g,0),  P=(u,r),  u=r+q.

The final monomial exponent is

    M=G+CP=(g+Bu+r,-u).

Because C is invertible,

    C^(-1)M=(u,g+r),   C^(-1)G=(0,g).                    (6.1)

The positive-freezing/Mandel detector already identifies d_(g;r,q) with the coefficient of this final monomial in the large theta function with initial exponent G, at an endpoint whose old coordinates are in a sufficiently close generic germ at

    m=g+Bu+r,

and whose leaf coordinates are sufficiently large and positive. This identification precedes the generic-unit origin algebra and does not need the Q mutation theorem.

For a word using only old indices, take the corresponding dual cluster coordinate and let h be its tropicalization transported to primitive scattering coordinates by C^(-1). Its min-convexity is verified directly in Section 4. Equation (4.1) says

    P_i^(word)=h(M)-h(G).                                (6.2)

To check exactly why the detector endpoint can be used in (6.2), write the principal B^T cluster variable as

    X_i,word = x^gamma F(y*x^(B^T)).

Put w=(v,yweight)=C^(-1)(m,l)=(-l,m+Bl). Its tropicalization is

    h(m,l)= -gamma·l + F_min(m),                         (6.3)

where F_min(m) is the minimum of a·m over the finite support of F. Thus all nonlinear walls of h depend only on the old coordinates m; its leaf dependence is linear.

Choose the detector old endpoint in a sufficiently close generic germ at M_old, avoiding the finitely many additional walls of h. The active linear form at that endpoint is one of the forms attaining the minimum at M_old. Hence the derivative of h at the detector endpoint, applied to the full final exponent M, is exactly h(M). This remains true when M_old lies on a tie wall: every adjacent active form has the same value on M_old. Large leaf coordinates do not change the active form in (6.3).

If the detector coefficient is nonzero, at least one broken line has initial decoration G and final decoration M. GHKK Proposition 8.14 and Definition 8.2 give

    (dh)_endpoint(M) >= (dh)_initial-ray(G)=h(G).

By the preceding paragraph this is h(M)>=h(G). Equation (6.2) gives P_i^(word)>=0. For finitely many words, choose the generic detector germ to avoid the finite union of all their additional walls. The detector's orthogonal-wall invariance already permits that choice.

This proves every finite-word degree inequality directly from existing tropical convexity and the detector identification. It applies coefficientwise to formal theta series; no prior Laurent finiteness is used. With u=r=p and q=0, d_(g;p,0)=a_g(p), giving the same Laurent-support containment as the Q proof.

### Equivalent coefficient-specialization calculation

Fomin–Zelevinsky separation gives an independent verification of (6.2). Add the frame variable Z and specialize principal coefficients to y_j=L_j Z^(g_j). The tropical coefficient-semifield denominator has every L_j exponent zero because F has nonnegative exponents and constant term one; its Z exponent is F_min(g). Therefore, at weights val(x)=u, val(L)=r, val(Z)=1, the auxiliary cluster coordinate has weight

    gamma·u + F_min(g+r+Bu)-F_min(g)
    = h(M)-h(G).

This is precisely the iterated degree coordinate, and it confirms the frame normalization rather than assuming it.

## 7. Fixed-word boundedness is a matrix-level property

For the full-support specialization u=r=p, write each dual principal cluster variable in its initial positive Laurent expansion as

    X_t(x,y)=sum_(a,b) c_(a,b) x^a y^b,

where b>=0. Put h_t(g)=min_(a,b) b·g. The exact inequalities become

    (a+b)·p >= h_t(g)-b·g  for every monomial of every tested X_t,
    p>=0.                                                  (7.1)

The supports of the finitely many X_t depend on B and the selected words, and do not depend on g. At p=0 every inequality holds, because h_t(g)<=b·g. Thus this polyhedron is nonempty for every g. Its recession cone is

    R_W={v>=0 : (a+b)·v>=0 for all tested monomials}.        (7.2)

This cone is independent of g. Since every polyhedron (7.1) is nonempty, it is bounded if and only if R_W={0}. Therefore a fixed finite word set succeeds for one label if and only if it succeeds for every label. It gives a matrix-level sufficient constructor for all theta labels, with g-dependent offsets and coefficient evaluations. It is not a label-sensitive certificate that can be expected to become complete by trying more words on each individually regular label.

One scope example can be recorded without further special-case work. For the cyclic three-vertex Markov quiver with two arrows on each edge, assign weight one to all old and leaf variables and zero to the frame in the recession problem. Every mutated mutable quiver is again of that form. The mutable part of either exchange monomial has weight two. Principal c-vector sign coherence puts any nontrivial coefficient contribution on only one of the two monomials and makes its weight nonnegative. The minimum weight is therefore two and the mutated old weight stays one. Thus (1,1,1) lies in every recession cone, so no finite word set of this form is bounded, even though theta_0=1. This is only a limitation of this constructor.

## 8. Consequence for presentation and priority

The boundedness test is still useful and correct. Once the finite polyhedron is bounded, it contains finitely many lattice points; computing the individual coefficients there yields the entire Laurent polynomial. Its success is a matrix-level property as just proved, and cannot characterize regular labels individually.

However, the support inequalities and the resulting boundedness certificate should be described as an explicit application of ordinary tropical mutation, positive Laurent expansions, and GHKK min-convexity to the detector construction. The direct proof above makes it inappropriate to claim that the Q realization creates an otherwise unavailable numerical support bound.

The full-Artin mutation equality remains a distinct statement: it constructs the finite origin factors, separates collisions in a flat family, complements distinguished Q factors, and compares complete local lengths. GHKK's inequality by itself does not provide that algebraic realization or an isomorphism of coefficient algebras. Whether that realization is new beyond the prior complementary-Q and quiver-duality literature still requires its own priority analysis; a change of language to Q polynomials alone is not evidence of novelty.
