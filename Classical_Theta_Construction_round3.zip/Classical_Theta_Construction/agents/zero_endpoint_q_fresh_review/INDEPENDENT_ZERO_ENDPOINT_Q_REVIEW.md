# Independent review of zero-endpoint complementary Q mutation

2026-11-14, independent adversarial review. Scope: classical q=1 and arbitrary integral skew-symmetrizable matrices. This review does not use a Li–Pan statement or a theorem that every regular label has a bounded certificate.

**Later novelty and scope audit:** `NOVELTY_REDUCTION_AND_CONVEXITY.md` gives an exact comparison with ordinary tropical A mutation and a direct GHKK-plus-detector proof of the numerical support inequalities. It also proves that a fixed finite word set's boundedness is independent of g, so this is a matrix-level sufficient constructor. The Q proof below passes as a full-Artin realization; the numerical support bound should not be claimed as a new independent mechanism.

## 1. Executive finding

The degree reflection, the explicit residue-unit maps, the separating perturbation, and the complementary-factor inverse all survive the checks below. The original draft's main missing argument was its claim that the entire generic positive factor is finite flat for arbitrary mixed-zero data and arbitrary admissible residue-one coupled units. The cited detector theorem proves this using a constant rank for every sufficiently deep factor, and the draft initially did not supply that constant rank after arbitrary mutations.

The parent supplied a satisfactory repair: for fixed matrix, framing, and degrees, choose the nearby generic endpoints in one chamber of a finite hyperplane arrangement. Their generic Q lengths are then one constant c. The existing annulus argument compares each shifted central endpoint to such a nearby endpoint, and the existing nested-full-Artin-factor argument applies with c in place of the derivative coefficient d. No new identification of c with a derivative coefficient is needed.

This review recommends explicitly including the finite collision-hierarchy/flow-tree sign forms in that arrangement, in addition to rank and cut forms. It also recommends making the analytic domains and the inverse quotient functions explicit. Subject to those repairs, I found no remaining gap in the conditional support certificate.

## 2. The general mixed-zero finite-flat lemma

Fix C,G,P and a partition I,J. Let mu0 have zero entries on I and strictly positive entries on J, and set M=G+CP. Common scaling x=T^t xi changes the endpoint exactly to mu_t=mu0+tM. This identity holds on localized equations and on their monic remainder algebras, so it does not discard nilpotents.

For a cut without the frame, its initial raw weight is positive if it meets J. There are finitely many cuts, so this positivity persists for all small t. An I-only cut has raw weight t times its skew cut pairing, up to the fixed orientation convention. Therefore every zero raw cut at mu_t has zero skew cut pairing. This is precisely the needed input to the minimum-actual-edge lower bound near mu_t. The upper bound comes from the finitely many good hierarchy recession certificates. Neither step uses the source-leaf form of the original doubled matrix.

An unframed connected component gives a nontrivial monomial relation among generic color units, after raising primitive rows to their symmetrizer powers. If its endpoint sum is nonzero, the valuation equation already excludes it; otherwise its residue relation excludes it. The generic residue open must include these finitely many exclusions. Thus the nonempty case reduces to a connected framed graph. Degree zero is handled separately and has length one.

### The missing constant rank and its repair

The proof needs an integer c independent of all sufficiently small t, not merely finiteness for each separate t.

Use a finite list L of rational linear forms controlling:

- rank and cut genericity;
- chambers of the generic fixed-degree collision/flow-tree count, including the finitely many cycle types needed for the sign projection;
- the exponent ties in the chosen Laurent polynomial defining the generic color-residue open.

The fixed-degree global theorem is a finite construction. Consequently the generic Q length is constant on each chamber of a finite rational arrangement after refining L if necessary. One can also read this directly from the finitely many generic collision chart counts and the character formula; no arbitrary-endpoint theta identification is required here.

Choose a rational vector nu outside the relevant kernels and choose eta>0 so small that, for each L vanishing at mu0, the expression L(M+s nu) is nonzero for 0<s<=eta. If L(M) is nonzero, choose eta before its first possible crossing; if L(M)=0, use L(nu) nonzero. Forms nonzero at mu0 retain their sign for sufficiently small t. Then

    mu*_t = mu0 + t(M + eta nu)

is rank- and cut-generic and lies in a single fixed generic-count chamber for every 0<t<t0. Its selected Q length is one constant c.

For each t, the annulus with endpoint direction nu and length eta*t joins mu_t to mu*_t. At positive annulus valuation use the nearby generic window; at its outer boundary use the one common generic-residue open from the finite initial-ideal argument. The annulus proof therefore gives rank c at mu_t.

Let C_t be the original system with all coordinate valuations >t. Scaling identifies C_t with this shifted positive factor. All C_t are finite flat of rank c over the same generic color-unit base. For t<t0 there is a domain inclusion C_t0 into C_t. Fiberwise, an analytic depth domain of a finite algebra selects entire local Artin factors. Equal lengths force equality of factors. Every positive point is in some C_t, so the whole positive family is exactly C_t0.

This supplies both the missing full finiteness and a uniform positive-depth bound. It does not infer finiteness from a generic point count.

### Coupled residue-one units

For an analytic correction v_i defined on the entire positive coefficient/root domain and satisfying v_i-1 topologically nilpotent there, the homotopy 1+s(v_i-1), |s|<=1, stays an analytic unit. At every solution its normalized target residue is still the same color unit. The initial-ideal argument therefore gives the same shifted windows uniformly over the homotopy parameters.

On each enlarged affinoid containing those windows, the source has N monic remainder equations in N coefficient variables over a regular parameter base. Actual-arrow inversions are analytic localizations of the regular ambient space. Finiteness gives codimension N; hence the equations form a complete intersection, the source is Cohen–Macaulay, and the finite morphism is flat. Comparing with s=0 gives the same rank c at every small t, and the preceding nested-factor argument again proves full finiteness uniformly over the entire parameter family.

The hypothesis that the correction is defined on the whole enlarged ambient domain is essential. Knowing its value only on the old solution algebra would not define this homotopy or justify the conclusion.

## 3. Weierstrass preparation and degree reflection

For k in I, put

    alpha = [G_k]_+ + sum_j [C_kj]_+ P_j,
    beta  = [-G_k]_+ + sum_j [-C_kj]_+ P_j,
    d = min(alpha,beta).

At the coefficient origin the row is z^alpha-lambda_k z^beta. Its zero multiplicity is d. If alpha=beta, invert 1-lambda_k on the residue base. Formal preparation yields a monic distinguished W_k of degree d and a unit. For the perturbed row, f_k=1+T^N phi_k, the same degree applies because f_k reduces to one.

The equation Q_k divides W_k is an identity of monic-polynomial remainder algebras. If P_k>d, the monic W_k has a nonzero remainder and the algebra is zero. If P_k<=d, monic division gives Q'_k=W_k/Q_k, of degree d-P_k. This construction is valid over every nonreduced local Artin coefficient algebra. Reduction gives Q'_k modulo the positive ideal equal to z^(d-P_k), so its roots are positive.

The key noncircularity point is that C_kk=0: W_k and its preparation unit depend only on Q_j for j != k, on lambda_k, and on the fixed perturbation polynomial f_k. They do not depend on the old Q_k. Those other Q_j are unchanged by complementation. Therefore W_k and the preparation unit are already analytic functions of the new coefficient variables.

After dividing the preparation unit by its nonzero constant residue, it has the form 1 plus positive-valued terms throughout the positive coefficient/root domain. In the equal-degree case the necessary coefficient ring inverts 1-lambda_k. In the unequal cases it inverts lambda_k. Formal preparation has bounded coefficients over these unit-residue affinoid bases and converges uniformly on every slightly enlarged strictly positive affinoid. This justifies the subsequent unit homotopy on an ambient domain.

## 4. Separation by an actual finite-flat perturbation

Introduce a polynomial phi_i of degree <P_i for every active color and replace the target by lambda_i(1+T^N phi_i(z)). On the actual-arrow-open monic configuration space, E_i is invertible modulo Q_i. Indeed all its possible denominator factors are actual frame or arrow factors, and precisely those are inverted.

The remainder equation solves uniquely for the P_i coefficients of phi_i:

    phi_i = T^(-N) (T^(a_i) A_i/(lambda_i E_i) - 1) mod Q_i.

Thus the full incidence scheme is a graph over the actual-arrow-open monic configuration space. This is an identity of schemes, including repeated-root states; the multiplication matrix of E_i modulo Q_i is invertible without a squarefree assumption.

The positive bounded-parameter incidence is an analytic domain of that graph. It need not literally be an open polydisc, but its nonempty components have the full ambient dimension. Every extra equation Q_i(0)=0 or Res(Q_i,Q_j)=0 for positive degrees cuts a proper divisor in this configuration space. It cannot contain a full-dimensional incidence component. Its finite image in the parameter polydisc is a proper analytic locus. A generic bounded parameter choice avoids the union of these finitely many images.

This proves full different-color separation and avoidance of zero at every point of a finite generic perturbed fiber. The original fiber's Artin length is retained by finite flatness. No same-color discriminant is added to a saturation; generic avoidance of a divisor is achieved by a deformation of the full algebra.

## 5. Exact target transformations

Let m=alpha-beta and b=C_jk. The quotient-ring identity is

    R'_j/R_j = (A_k/(Q_k Q'_k))^b  if b>0,
    R'_j/R_j = (E_k/(Q_k Q'_k))^b  if b<0.

Skew-symmetrizability makes C_kj have the opposite sign to b. Thus modulo Q_j exactly the other prepared monomial vanishes. Complete separation makes every denominator used in the identity invertible. These are quotient-ring identities, so they preserve every confluent condition and every local nilpotent relation.

For m>0 use E_k-lambda_k^(-1) f_k^(-1) A_k=U_k Q_k Q'_k with U_k residue one. For b>0 this gives A_k/(Q_k Q'_k)=-lambda_k f_k U_k; for b<0 it gives E_k/(Q_k Q'_k)=U_k. The constant multiplier is therefore (-lambda_k)^[b]_+.

For m<0 use A_k-lambda_k f_k E_k=U_k Q_k Q'_k with U_k residue one. For b>0 the quotient is U_k; for b<0 it is -lambda_k^(-1) f_k^(-1) U_k. The constant multiplier is (-lambda_k)^[-b]_+.

For m=0 use the latter preparation and write U_k=(1-lambda_k) U_tilde. The constant multiplier is

    (1-lambda_k)^[b]_+ (1-lambda_k^(-1))^(-[-b]_+).

These agree with the displayed formula in the draft. At k, the new target is lambda_k^(-1) f_k^(-1). In every case the remaining correction is an explicit product of f_i, powers of f_k, and powers of normalized U_k, hence has residue one on the whole positive domain.

The residue maps are birational. Under reverse mutation, b changes to -b and m changes to -m; lambda_k changes to its inverse. The two constant multipliers cancel in all three cases. Hence one must shrink the old residue base by the pullback of the new generic-residue open under this map, and also by 1-lambda_k in the zero case. This remains a nonempty generic open. Independent rational-function units satisfy it. No genericity is inferred merely from counting parameters.

## 6. The actual finite-Artin factor comparison

For an old neighbor j of k, preparation modulo Q_j leaves a unit times a monomial that is invertible by complete separation. Thus W_k, and therefore Q'_k, is invertible modulo Q_j. This gives every required new k-neighbor resultant. Newly created edges between j,l != k are covered by the old complete separation. Newly required frame factors away from k are covered by Q_j(0) !=0. If G_k !=0, evaluating the prepared row at zero shows W_k(0) !=0, and hence Q'_k(0) !=0.

The image is therefore in the new actual-arrow-open positive coupled system.

For the inverse, define the coefficients of recovered Q_k by global monic division of W_k by Q'_k, even before imposing vanishing of the remainder. These quotient coefficients are analytic functions of the new variables. The new k-th equation is equivalent to Q'_k dividing W_k and forces that remainder to vanish. The recovered monic Q_k has degree P_k and positive roots. On the open locus where its old complete-separation conditions hold, the exact identities above reverse and yield all old equations. These constructions are inverse scheme maps.

Consequently the entire old finite perturbed algebra, including each local Artin factor, is isomorphic to an open part of the new full positive algebra. An open subset of a finite Artin scheme is an open-and-closed factor. This is the needed justification for the length inequality; an injective map on geometric points alone would not suffice.

The new full coupled positive algebra can have extra factors. Homotoping its explicit residue-one corrections to one gives a finite flat family by Section 2. Therefore

    ell(C,G,P) <= ell(C',G',P').

Repeat from the constant-unit mutated core with its own separating perturbation. Row k's two degrees exchange, so d'=d and the reverse degree is P_k. Matrix and framing mutation are involutions. The reverse construction gives the opposite inequality. This proves equality of full lengths, without asserting an isomorphism of the two original special algebras and without deleting extra weak factors.

## 7. Support certificate audit

For a finite collection of mutation words, include every prefix. On every nonzero initial coefficient, all intermediate degree vectors must be nonnegative. The mutated C and G are determined by the word; each degree update is a minimum of integral affine expressions. Splitting all minima and imposing their comparison inequalities constructs a finite union of rational polyhedra containing the real extension of every possible integral support point. Boundary equalities may appear in both adjacent branches and cause no omission.

Exact boundedness of that union is decidable by recession-cone tests on its nonempty polyhedra. A bounded union supplies a finite lattice-point superset of support. Evaluate the already proved individual coefficient algebras only at those lattice points. Every point outside is excluded by a finite mutation-degree contradiction. This is a proof of exhaustion and a legitimate conditional complete-output algorithm.

For the doubled matrix and P=(p,p), the initial generic core length equals d_(g;p,0)=a_g(p). This last identity also follows immediately by taking the y^0 coefficient of the divided-derivative expansion. Therefore the proposed bounded-degree set proves a complete Laurent support bound in the stated classical setting.

Nothing in this argument proves that some finite word set succeeds for every regular theta label. An unbounded certificate candidate proves neither infinitude nor finiteness. The draft correctly preserves that limitation.

## 8. Dependencies and final status

I read the zero-endpoint draft, the universal-unit coefficient algebras note, the generic-residue detector-window proof, the old nonzero-endpoint complementary-Q note, the coordinate-unit deformation proof, the finite-flat bridge, and the complete-color-separation note. The general rank-recession, finite-initial-ideal residue argument, and monic remainder/sign compression are treated as the project's independently reviewed inputs. This review attacks the new extension and mutation interface rather than re-proving those earlier theorems.

The original omission in Section 1 is material; the finite-chamber constant-rank repair is required. With that repair and the explicit ambient/inverse/generic-base statements recorded here, the mutation and bounded-support conclusions pass this independent review.

I reread the author's updated draft at 01:46 UTC. It incorporated these repairs, including the finite collision/flow sign refinement, ambient convergence, noncircular inverse quotient functions, and generic-base pullback. No remaining material proof gap was identified. The later novelty audit narrows the presentation, not the validity of this full-Artin argument.
