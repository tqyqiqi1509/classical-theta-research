# 大标签、射线稳定幂律：查新交接

Checkpoint: 2026-11-13, after the parent's stable-ray construction. This note assesses novelty; the proof is being written by `/root`.

## 1. 本轮新命题及相对上一轮的增量

Parent's proposed theorem fixes B,g and constructs a single formal series

\[
H_g\in 1+(z_1,\ldots,z_n)\mathbb Z[[z_1,\ldots,z_n]]
\]

such that for every finite downward closed root set J there is a computable threshold T_J with

\[
F_{ng}\equiv H_g^n\pmod{z^q:q\notin J}\qquad(n>T_J).
\]

This is stronger than fixed-p piecewise polynomiality and stronger than the coefficientwise Poisson scaling limit. It gives one compatible master series across all degrees, eventual linearity of each coefficient of log F_{ng} in n, and exact same-ray multiplication up to any prescribed finite order.

For p≠0 in J, the resulting consequence is

\[
c_{mg,ng}(p)=0\qquad(m,n>T_J)
\]

after choosing a threshold that also controls m+n. At p=0 the structure constant is1.

A targeted `rg` search over the previous package's `proofs/*.md` and `agents/*.md` for asymptotic / Poisson / leading homogeneous / large label / highest label degree found no statement of this theorem or the Poisson limit. The old replication theorem scales B and g together; this theorem fixes B and scales only the label. It is a real increment relative to the provided prior package.

## 2. 最接近的已知结果

### 2.1 Cluster-chamber exact powers

GHKK arXiv:1411.1394, Prop3.8/Cor3.9, identify theta functions with monomials in their cluster chamber. Multiplicativity of transport then gives exact powers on those rays, without a threshold. This covers the cluster complex; the proposed theorem is meaningful outside it.

GHKK Prop6.4 proves extraction of theta structure constants by choosing an endpoint near the output exponent. The proof's unique final straight ray is closely related to the proposed coarse-factor proof. I did not locate a general eventual-power theorem in GHKK; checked the relevant passage and searches for sufficiently large / multiples / stabilization / asymptotic. The new result should still acknowledge that its ingredients are standard scattering factorization and theta extraction.

Primary: https://arxiv.org/pdf/1411.1394

### 2.2 Affine imaginary rays: a genuine special-case antecedent

Reading–Stella, *Theta functions in acyclic affine type*, arXiv:2603.23429v1, Thm3.3/3.4 (pp18–19), prove a Chebyshev recursion and the formulas

\[
\vartheta_{k\nu_c(\delta)}\vartheta_{\ell\nu_c(\delta)}
=\vartheta_{(k+\ell)\nu_c(\delta)}
+y^{\ell\delta}\vartheta_{(k-\ell)\nu_c(\delta)}\quad(k>\ell),
\]

and the corresponding square formula with correction 2y^{kδ}. Thus the correction escapes every fixed root truncation as min(k,ℓ) grows. The dominant formal root of the Chebyshev equation likewise gives a stable master power series. These are direct special-case antecedents to both conclusions above.

The paper itself traces the affine A and D instances to Musiker–Schiffler–Williams, together with identification of bracelets with theta by Mandel–Qin. Do not present same-ray finite-order stabilization as an entirely unprecedented phenomenon.

Primary: https://arxiv.org/pdf/2603.23429

2026 audit scope: checked the actual theorem statements, their relation in §3.1, and the explanation of prior cases; no reliance on this source for the new general proof. The manuscript contains minor front-matter/nomenclature typos (date “February52”, calling the normalization T₀=2,T₁=x “second kind”); these do not affect the displayed identities and are not evidence against them.

### 2.3 Different uses of “asymptotic” and “Frobenius”

Mandel arXiv:1503.06183 §4 treats classical characteristic-p and quantum root-of-unity Frobenius phenomena. These concern congruences or simultaneous exponent rescaling, not exact fixed-B large-label truncation stabilization.

Leung–Ma–Young arXiv:1902.05765 uses asymptotic analysis of Maurer–Cartan equations for constructing theta functions. The asymptotic parameter there is not n in the theta label ng. Its title should not be mistaken for the same theorem.

## 3. Search record and current novelty wording

Searched with both available engines:

- theta functions + large label / leading homogeneous / coefficients / scaling limit;
- framed quiver + asymptotic framing / polynomial Euler characteristic;
- cluster character + leading coefficient; quiver Grassmannians + asymptotic;
- asymptotic theta; stable ray theta; stabilization theta; generic multiples;
- theta scattering + eventually; theta functions + powers ray; cluster theta + nth root.

Results predominantly concerned Jacobi/mock theta or the listed known cluster cases. No primary source stating the arbitrary-B, arbitrary-g, single-H_g theorem was located in this search. This is a provisional negative search result, not proof of absolute originality.

Suggested defensible claim: **a uniform stable-ray theorem for all classical cluster data, with an effective finite-order threshold and a single integral master series, extending familiar cluster-chamber power laws and affine Chebyshev stabilization.**

The theorem should not claim a new definition of scattering or a complete finite Laurent formula for all labels. H_g itself need not be assumed coefficientwise nonnegative without proof.

## 4. Poisson leading term and independent mechanism

The proposed corollary is

\[
t^{-|p|}a_{tg}^B(p)\longrightarrow
\prod_i\frac{[-g_i]_+^{p_i}}{p_i!},
\qquad F_{tg}(z/t)\longrightarrow
\exp\!\left(\sum_i[-g_i]_+z_i\right)
\]

coefficientwise. The analogous multiplication limit uses
δ_i=[−g_i]_++[−h_i]_+−[−g_i−h_i]_+.

An independent explanation is a degree filtration on broken-line contributions: a wall of root height k, used r times, contributes at most r powers of the large label, while consuming root height rk. Only degree-one initial walls can contribute at the maximal label degree |p|. Their leading choices are independent, giving the exponential above. Every genuine unframed interaction is lower order. This is compatible with the parent's stronger master-series theorem and helps explain the disappearance of B from the leading term.

No exact external statement of this all-rank fixed-degree Poisson limit was located. The name “Poisson” is only an exponential generating-series analogy unless a probability normalization and convergence topology are separately introduced.

## 5. Recommended fresh review targets

1. Prove that the coarse negative factors for nested truncations are compatible, so H_g is a single series.
2. Check integrality of H_g, not only rationality of its logarithm.
3. Treat g on resonant root hyperplanes: the zero-root group must fix x^{ng} at the correct stage of factorization.
4. State exactly which endpoint inequalities are dominated by n and give T_J explicitly.
5. Derive same-ray structure constant vanishing through the full triangular expansion, including labels shifted by Bq.
6. Distinguish fixed-order eventual equality from one finite threshold valid at all degrees.

