# 搜索与路线记录

Checkpoint: 2026-11-13 17:20 UTC. Entries summarize batches, not fictitious continuous elapsed work.

| Batch | Search / read | Outcome | Action |
|---|---|---|---|
| Initial | Mandel theta tropical curves; Argüz–Bousseau flow trees; BLM tight gradings; Qiyue Tang theta trees | Located direct tree/formula antecedents | Read primary papers and compared precise theorem scope |
| 2026 refresh | theta combinatorial 2026; theta framing Dyck; official arXiv/journal recent versions | Reading–Stella Nov8 update; JLMS July2026 BLMMR | Metadata and selected proof audit; recorded limitations |
| Integer points | theta integer points polytope; theta non-intersecting trees | No direct arbitrary-rank bounded-dimensional positive-polytope theorem found | Retain as candidate, not declared novel |
| Parameter 1 | theta functions piecewise polynomial / piecewise-polynomial / piecewise quasipolynomial | Mostly Jacobi theta false positives; no exact label theorem | Checked old local package and found it already proved internally |
| Parameter 2 | cluster theta coefficients polynomial; scattering theta piecewise polynomial | No exact external match | Do not equate absent hit with new theorem |
| Continuity | theta coefficients piecewise polynomial continuity; scattering diagrams divisibility; theta wall crossing continuous; cluster theta spline | Mostly unrelated special-functions literature | Precise across-label continuity remains open in this branch |
| Nearby polynomiality | tropical disks polynomial wall crossing; framed quiver polynomial framing dimension | Found Gräfnitz–Luo 2312.13990; Reineke framing and functional equations | Read GL §4; replication novelty narrowed |
| Geometry | Bridgeland theta framed quiver moduli; Cheung quiver Grassmannians; theta framing binomial | Framed theta prior; Cheung–Mandel Hall broken-line counterexample | Warned root not to promote classic consistency automatically to Hall level |
| Projection algebra | Symbolic two-step framing projection for variable g | Actual quadratic sign numerator | Distinguish semialgebraic positive catalog from affine final coefficient partition |
| Route refinement | Across-wall factor f^L−1; normal jet | Plausible C⁰ / linear-divisibility mechanism; log f first jet | Parent independently proving; no theorem claimed here |

Access failures resolved: old arXiv HTML was unavailable for some papers, so used official PDF/PMC; official SIGMA PDF initially failed direct open but succeeded through official page link. No inaccessible document was treated as read.

Failed strengthening: uniform C¹ or higher-order wall divisibility cannot hold, since the general axis-root formula already has a simple zero at the label wall. Integer-valued quotient after dividing a wall form likewise fails in root degree2. These delimit the theorem; they are not a substitute research objective.

Later batch: large-label asymptotics, Poisson scaling, stable-ray/generic-multiple/eventual-power searches. No exact all-rank master-series theorem found. Important special-case antecedent found and read: Reading–Stella arXiv:2603.23429 Thm3.3/3.4, affine imaginary-ray Chebyshev and product formulas. GHKK Prop3.8/Cor3.9 supplies exact cluster-chamber powers; Prop6.4 supplies the related terminal extraction mechanism. Details in `STABLE_RAY_NOVELTY_HANDOFF.md`.

