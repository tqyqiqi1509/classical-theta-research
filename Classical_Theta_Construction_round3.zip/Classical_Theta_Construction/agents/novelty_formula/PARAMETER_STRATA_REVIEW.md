# 参数分区：已有定理、对象目录与真正新缺口

Checkpoint: 2026-11-13 17:20 UTC.

## 1. 上一轮已经有的命题

`agents/polyhedral_parameter_formula.md` §2 已证明：固定 D,p，theta 的根次数 p 系数在 (B,g) 的有限有理中心超平面分层上为总次数 ≤|p| 的多项式，p!=∏p_i! 清分母；每个分支的指定扩张在整数点上取整数值。固定 B 后为 g 的仿射超平面分层。

其超平面是

\[
H_{\alpha,\beta}=(B\alpha)^TD\beta,\qquad
E_{s,q}=(g+Bs)^TD(s-q),
\]

指标均位于 [0,p]。固定符号以后 incoming-prefix 算法仅用有限次广义二项式、加减乘和单位三角逆矩阵。根次数守恒给次数与分母界。

`proofs/TWO_FRAMING_THETA_MULTIPLICATION.md` §8.1 也已通过三角乘法递推得到结构常数的同类分层。不得将这些作为本轮新增。

原文明确没有证明相邻高维分支在公共面连续拼合；这才是本轮可研究的进一步性质。

## 2. 正对象目录自身自然只有半代数分区

单位 framing 的 skew form 随 g 改变。相继事件的协向量投影是有理函数，不一般是线性函数。

设 D=I，

\[
B=\begin{pmatrix}0&2&-1\\-2&0&3\\1&-3&0\end{pmatrix},\quad
p=(1,1,1),\quad H_a=g+Ba.
\]

从 U=(1,1,1)（加固定 generic infinitesimal 不改变开区域的主符号）依次剥离 b=e₃,c=e₂：

\[
U_1=U-\frac{U\cdot b}{H_p\cdot b}H_p,
\qquad
U_2=U_1-\frac{U_1\cdot c}{H_{p-b}\cdot c}H_{p-b}.
\]

直接恒等计算给

\[
U_2\cdot e_1=
-\frac{g_1g_3-5g_1-g_2g_3+g_2+4g_3-12}
{(g_2-2)(g_3-2)}.
\]

分子是 Q[g₁,g₂,g₃] 的不可约二次式。前两次事件正时间条件是非空的：在 (g₁,g₂,g₃)=(-2,0,1)，两个时间皆为1，而二次式为0；其附近穿越此曲面保持前两时间为正。

这没有否定最终 theta 系数的仿射分区。它说明单个正目录事件可以在更细的代数曲面上变化，而总和经过非平凡消去后只需要既有的仿射分区。不能从“有限比较”直接推出“比较都是线性”。

同类区别在 Argüz–Bousseau arXiv:2102.11200 中清楚可见：固定 skew form、只变初始 covector 时 Lemma2.19 是线性的；变 skew form 时 Lemma2.17/Prop2.18 只给有理函数及有限代数超曲面。这里 g 位于 framing skew form，属于后者。

## 3. 连续性 / 墙差的新颖性状态

截至此 checkpoint，针对 cluster theta 的 fixed-root-degree label coefficient 连续分段多项式、墙差线性整除、法向导数跳跃公式，没有检索到精确外部定理。已检索 theta coefficient / piecewise polynomial / spline / continuity / divisibility / framed quiver 等组合；多数结果属于经典 Jacobi theta、Hurwitz 数或 rank-2 初始权重多项式性，不能混作同一结论。

附近先例：Gräfnitz–Luo arXiv:2312.13990 §4 的初始乘数多项式；热带 Hurwitz 的 resonance wall-crossing；AB 流树变参代数性。它们提供方法启发，没有自动推出所需的标签 spline 定理。

## 4. 声明时的精度

- 只在 Q[g] 中声称线性整除，另保留 p! 清分母；整除商一般不整数值。
- C¹ 不可能无条件成立；轴根本身给简单零点。
- 若证明 first-jet 公式，须说明移动的是标签及其末端提取协向量，而不是将已有固定标签、变端点的 wall-crossing 改名。
- 还需审查多墙交汇的兼容性；相邻泛型面相等可推有限分区全局连续，但前提是各零层真实值也等于分支限制。

