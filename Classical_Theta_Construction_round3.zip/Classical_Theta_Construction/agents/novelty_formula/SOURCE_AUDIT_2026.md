# 2026 文献核查记录（持续更新）

Scope: only classical consequences considered. No Li–Pan result is adopted.

## Reading–Stella, Mutation of Theta Functions

- Source: https://sigma-journal.com/2026/109/ ; https://sigma-journal.com/2026/109/sigma26-109.pdf ; arXiv:2603.19391v4, revised 2026-11-08.
- Checked: official journal existence, date/version, definitions and main statements in §§3,5; theorem hypotheses on coefficients and finite theta support.
- Useful: mutation symmetry can constrain structure constant support (Thm5.1); common mutation-fan cones constrain output regions (Thm5.4); pointed reduced basis comparisons (Thm5.14).
- Caution: signed-nondegenerating coefficient assumption; formal theta and possibly infinite multiplication are explicitly allowed. This does not furnish arbitrary-label finite Laurent termination.
- Current assessment: useful primary source; no error located in checked passages. Full proof audit not completed, so do not assert all results re-proved here.

## Burcroff–Lee–Mou–Musiker–Reineke, Cluster scattering diagrams via quiver moduli and tight gradings

- Source: https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/jlms.70642 ; JLMS114, e70642, first online 2026-07-28.
- Checked: Thm1.2 and its §6 proof, normalization between power initial functions and cluster initial functions, relation to universal positive tight gradings.
- Useful: rank-2 coefficients admit positive products of binomial polynomials in b,c; this is a direct antecedent to replication positivity.
- Minor issue found: in the proof of Thm1.2(2), the displayed leading g^k term from F^{g/(bc)} appears to omit 1/k!. The correct leading term is (ρ₁/(bc))^k g^k/k!. The later exponential expansion in part(4) includes factorials. This is a local proof typo, not evidence that the main theorem is false.
- No local use of the typo; no adoption of geometric conclusions outside checked hypotheses.

## Cheung–Magee–Mandel–Muller, Valuative independence and cluster theta reciprocity

- Source: https://arxiv.org/pdf/2505.09585 ; v2, 2026-05-21 (v1 is 2025).
- Checked: current version metadata, Thm1.1, §3.9 Cor3.17/3.18, and placement of Newton vertex claim Cor3.16.
- Useful: tropical theta minimality under min has already been proved with finiteness hypotheses; it is not the user's minimum-among-strong-positive-bases question. Valuative independence can support Newton methods.
- Critical source dependency: after Cor3.16 the paper cites Li–Pan for the converse and a saturation statement. Those borrowed conclusions are expressly excluded from this project's inputs. The direct forward vertex-coefficient statement must be assessed on its own proof.
- Current assessment: promising interface; not yet fully audited, no blanket adoption.

## Other discoveries not adopted

- Reading–Stella, *Theta functions in acyclic affine type*, arXiv:2603.23429: read metadata/abstract only; useful if needed for comparative examples, not general mechanism.
- Huihui Ye, *Quantum Generalized Cluster Algebras from Scattering Diagrams: Positivity and Mutation*, arXiv:2611.00991: scope is quantum/generalized, not current classical task; not used.
- Various 2026 mirror sites/search snippets claiming new cluster positivity: not primary and not used. Search date labels are not reliable publication metadata; official version history controls.

## Additional focused check: Reading–Stella acyclic affine theta

- Subsequently read arXiv:2603.23429v1 §3.1 Thm3.3/3.4 directly for stable-ray novelty.
- Useful: Chebyshev recurrence and product corrections y^{min(k,ℓ)δ} escape every fixed degree. This is a real special-case precedent for the new stable-ray mechanism.
- It is used only for novelty comparison, not as an input theorem for the arbitrary-data proof.
- Minor manuscript typos observed: malformed date “February52,2026”; normalized Chebyshev T₀=2,T₁=x called “second kind”. Do not overstate these as mathematical counterexamples.

