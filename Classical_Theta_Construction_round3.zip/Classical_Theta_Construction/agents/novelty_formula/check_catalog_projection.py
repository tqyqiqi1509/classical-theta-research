"""Exact symbolic check: positive event catalogs need not have linear g walls.

This checks a general projection mechanism, not numerical theta coefficients.
No old package is modified. Run with Python and SymPy.
"""
import json
from pathlib import Path
import sympy as sp

g1, g2, g3 = sp.symbols("g1 g2 g3")
G = sp.Matrix([g1, g2, g3])
B = sp.Matrix([[0, 2, -1], [-2, 0, 3], [1, -3, 0]])
p = sp.Matrix([1, 1, 1])
b = sp.Matrix([0, 0, 1])
c = sp.Matrix([0, 1, 0])
d = sp.Matrix([1, 0, 0])
U = sp.ones(3, 1)
Hp = G + B * p
t1 = -U.dot(b) / Hp.dot(b)
U1 = sp.simplify(U + t1 * Hp)
Ha = G + B * (p - b)
t2 = -U1.dot(c) / Ha.dot(c)
U2 = sp.simplify(U1 + t2 * Ha)
value = sp.factor(U2.dot(d))
num, den = sp.fraction(value)
assert sp.Poly(num, g1, g2, g3).total_degree() == 2
assert len(sp.factor_list(num)[1]) == 1
assert sp.factor_list(num)[1][0][1] == 1
point = {g1: -2, g2: 0, g3: 1}
assert t1.subs(point) == 1 and t2.subs(point) == 1
assert num.subs(point) == 0 and den.subs(point) != 0
report = {
    "status": "PASS",
    "matrix": [list(B.row(i)) for i in range(3)],
    "first_time": str(sp.factor(t1)),
    "second_time": str(sp.factor(t2)),
    "final_covector_e1": str(value),
    "irreducible_numerator_degree": 2,
    "regular_boundary_point": [-2, 0, 1],
    "two_previous_times_at_boundary": [1, 1],
    "meaning": "Event-catalog signs can be semialgebraic; this does not refute affine strata for summed theta coefficients.",
}
text = json.dumps(report, indent=2, default=int)
Path(__file__).with_suffix(".json").write_text(text + "\n")
print(text)
