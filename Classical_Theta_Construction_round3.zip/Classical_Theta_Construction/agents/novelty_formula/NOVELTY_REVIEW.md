# 通用 theta 组合公式：外部查新与实质增量

Branch: `/root/novelty_formula`. Scope: classical cluster algebras only.
Checkpoint: 2026-11-13 17:20 UTC. This is an interim component, not a final verdict on all proofs.

## 1. 当前判断

上一轮的正整数对象不是“先算系数，再取同样大小集合”的循环定义。构造从整数矩阵、有限根盒、形式无穷小、正的 rank-2 tight grading 因子与槽位选择开始，先形成有限集合表达式，再求基数。因此确有可执行的组合内容。

但是，任意秩的树形 theta 展开、有限次数截断、以流树恢复散射图、局部 rank-2 正重排，再合成全局正性，都已有直接先例。新稿若自称第一次消除散射图、第一次任意秩组合 theta、第一次从树得到乘法，应当改窄。其目录中的状态、事件、射线次序、交叉历史与微扰旗标仍编码散射计算。

目前较能成立的增量候选是：

- 一个统一、正的、无自动同构分母的实际集合语法，覆盖给定根次数的系数和乘法系数，并精确处理斜对称化格归一化。
- 将局部长 Dyck 路径转为有限维整数位置约束，并给出只依赖根次数的维数和目录上界。
- 对单位 framing 的槽位压缩，使输入箭重很大时对象表达仍短。
- 全部输入参数的显式有限分段多项式公式。它已经在上一轮内部稿中，不能作为本轮新成果重复提出。

以上候选仍需跟 BLM 完整稿、AB 的有限流树和一般有限幂零算法逐项比较。尤其“固定次数时按输入位长多项式计算”本身不是独立新结论：固定次数的既有有限 Lie/矩阵算法也有这一性质。

## 2. 精确的外部重合

| 外部工作 | 已有机制 | 对上一轮主张的影响 |
|---|---|---|
| Mandel, *Scattering diagrams, theta functions, and refined tropical curve counts*, arXiv:1503.06183, Thm 3.7/3.9, Rmk 3.10 | 任意维数的热带树、热带盘；迭代 Lie 括号权；theta 系数和乘法；带 cyclic order 的 ribbon 版本 | 不能以“任意秩树公式”或“非交/平面树形式”单独声称新颖 |
| Argüz–Bousseau, *The flow tree formula for Donaldson–Thomas invariants of quivers with potentials*, arXiv:2102.11200, Thm 4.22/4.24 | 一般相容散射图由初始数据的有限二叉流树恢复；不限于 DT 特例 | 上轮状态投影和严格降次数机制与此关系紧密；应写明正重排替代有符号 Lie 权的具体改进 |
| Burcroff–Lee–Mou, arXiv:2503.03719, Thm 1.2, 5.17, 9.5, 9.9, §9.3 | tight gradings 给 rank-2 正因子；非本原子格；多条 rank-2 初始射线；任意秩正性 | 不能把这些局部/全局正性重新标成自证新定理；自己的贡献须是规范的组合合成与压缩 |
| Gräfnitz–Luo, arXiv:2312.13990, Thm 2 / Prop 4.1 | rank-2 壁因子指数对初始乘数的多项式性，正二项式展开，支撑消失 | 参数复制思想已有明确先例，早于 BLM 2026 |
| Burcroff–Lee–Mou–Musiker–Reineke, JLMS 2026, Thm 1.2 | rank-2 系数对 b,c 的二项式正展开与 quiver 模空间联系 | 复制参数正性的 novelty 必须注明任意秩 theta/结构常数的扩展，不应说首次 binomial positivity |
| Bridgeland, *Scattering diagrams, Hall algebras and stability conditions*, §10 / Thm 1.4 | 部分 theta 是 framed quiver moduli 的 Euler 生成函数 | framing 技术本身不是新颖性来源 |

Primary URLs:

- https://arxiv.org/pdf/1503.06183
- https://arxiv.org/pdf/2102.11200
- https://arxiv.org/pdf/2503.03719
- https://arxiv.org/pdf/2312.13990
- https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/jlms.70642
- https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf

## 3. 已读内部证明及局部判断

Root of the previous package:
`history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/`.

Read: `00_MAIN_REPORT_ZH.md`; `proofs/COMBINATORIAL_GLOBAL_THETA_THEOREM.md`; `agents/valued_global_assembly.md`; `proofs/BOUNDED_FLAGGED_DYCK_TREES.md`; `proofs/GLOBAL_SPARSE_POLYHEDRAL_RECIPE.md`; `proofs/TIGHT_GRADING_VALUED_LOCAL_OBJECTS.md`; `proofs/TWO_FRAMING_THETA_MULTIPLICATION.md`; `agents/INCOMING_NORMALIZED_INTEGER_PREFIX_THEOREM.md`; `agents/polyhedral_parameter_formula.md`; `computations/fast_framed_spine.py`.

### 3.1 斜对称化局部归一化

记 K=DB，w(a)=gcd_i(D_i a_i)。对于 m=K(α,β)>0，d=w(α)，e=w(β)，u=m/d，v=m/e，及互素 a,b>0，γ=aα+bβ，稿件使用

\[
\ell=\gcd(av,bu),\qquad c=\frac{m\,w(\gamma)}{\ell de}
=\frac{w(\gamma)}{\gcd(ad,be)}.
\]

由于 gcd(ad,be) 整除 γ 的每个 D 加权坐标，c 确为正整数。它等于扩张格输出法向与原始 primitive normal 的倍数；把局部函数取 c 次幂方向正确。本处未找到归一化错误。仍需与 BLM Thm 9.5 的同类非本原子格公式作书面一一对应。

### 3.2 乘法终点

初步担忧“任意终点的 Laurent 乘积系数被误作 theta 乘法系数”在精读后排除。稿件明确选择输出标签 h=g₁+g₂+Bp，并令终点 U=Dh+ε，再拼两条 framing 对象。它另证终端单项式的 delta 性质；这正是 GHKK/Mandel 所需的终点条件。没有依据把该处记成错误。

### 3.3 仍未消除的核心依赖

对象目录中保留事件旗标、occurrence 标识和相邻重排历史。更换辅助顺序时，只对无关交换或平行槽位给了容易的双射；共享 occurrence 的三因素重叠尚缺纯组合 associator。一个真正与调度无关的 greedy 解释仍要解决这一点。

固定 p 的有限计数不等于给定任意标签 g 的完整有限 Laurent 多项式。一般形式 theta 可无限；有限性需要 Θ/regularity 假设及有效支撑界。

## 4. 本轮应推进的实际接口

最有希望的非重复方向之一是把已有分段多项式进一步变成连续拼合的函数，证明跨参数墙的分支差被该墙线性型整除，并辨认首阶法向导数跳跃。外部精确检索目前未找到这一命题，但检索未命中不是新颖性证明。

自然局部机制是 ray 作用 f^L：差 f^L−1 在 Q[参数] 中含 L，且

\[
\left.\frac{f^L-1}{L}\right|_{L=0}=\log f.
\]

把这个恒等式落实到移动标签的终点提取，才构成证明，而非直接从固定终点 wall-crossing 偷换。Root 正独立推进此处。

无条件高阶光滑性不能成立：轴根的分支 binom(−g_i,k) 与零在 g_i=0 仅一阶接触。商也未必整数值，例如 binom(−g_i,2)/g_i=(g_i+1)/2。因此最稳妥目标为 C⁰、一次整除、可计算的有理 first-jet 公式。

