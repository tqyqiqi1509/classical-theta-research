# Complete separation of different colors in the selected Gale factor

2026-11-13. Classical skew-symmetric or skew-symmetrizable input. This note
strengthens the existing actual-arrow window. Its input is the proved
rank-recession lemma, not an assumption about Bethe roots being simple.

## Statement

Use the framed positive leaf charges, a rank-generic and cut-generic original
color covector, and the selected positive-valuation Gale factor of
`../global_gale_adversarial/RANK_GENERICITY_AND_RECESSION.md`.
The endpoint covector may have mixed signs. The frame is its own color and
has coordinate zero. Then there are constants

\[
0<\varepsilon\le M<\infty
\]

and a full leaf-target valuation neighborhood such that every selected
solution, over any valued extension and for arbitrary unit target series,
satisfies

\[
\varepsilon\le\operatorname{val}(x_u-x_v)\le M
\quad\text{whenever }\operatorname{color}(u)\ne
\operatorname{color}(v).                                    \tag{1}
\]

This includes pairs for which the original exchange pairing is zero.
In particular every mutable coordinate is nonzero, even when its frame
pairing is zero. Same-color coincidences are still allowed, including
nonreduced scheme structure.

## Proof, including exact collisions

Write `M_H` for the depth matrix of a full binary hierarchy and `U` for the
original-color covector image. The finite rank-generic avoidance implies
that every hierarchy feasible at the selected covector has
`U contained in image(M_H)`. The rank-recession theorem says precisely

\[
\ker M_H\cap\mathbb R_{\ge0}^{H}
=\sum_{S\text{ monochromatic}}\mathbb R_{\ge0}e_S.       \tag{2}
\]

Delete the monochromatic columns. They are zero columns. The effective
matrix `M_eff` has no nonzero nonnegative kernel vector, so the strict
linear alternative provides a rational vector `b_H` such that

\[
M_{\rm eff}^{t}b_H\ge\mathbf1.                         \tag{3}
\]

For a nonnegative depth vector with `M_H t=-theta'`, this gives

\[
\sum_{S\text{ nonmonochromatic}}t_S\le b_H(-\theta').    \tag{4}
\]

If `u,v` have different colors, every hierarchy node containing both is
nonmonochromatic. Thus the valuation objective

\[
\operatorname{val}(x_u-x_v)=\sum_{S\supset\{u,v\}}t_S
\]

is bounded by (4), whenever the difference is nonzero.

It remains to justify that a difference on an original nonedge cannot be
exactly zero. Suppose a coordinate value is shared by a set `C` containing
two colors. No actual arrow has both endpoints in `C`, because actual
arrow forms are inverted in the selected factor. Perturb the equal
coordinates inside `C` at an arbitrarily high valuation, beyond all the
finitely many nonzero differences. Such perturbations do not change the
valuation of any actual arrow form. Their valuation vector consequently
still satisfies the same linear Gale equations, even though the perturbed
points need not satisfy the original equations themselves.

The resulting ultrametric hierarchy has a node with support `C`, at an
arbitrarily large relative depth. It can be refined to a full binary
hierarchy by inserting depth-zero nodes. Its column `v_C` is zero: all
pairings of leaves inside `C` vanish. The hierarchy is feasible for the
original Gale valuation equations. Equation (2) forbids its nonnegative
kernel vector `e_C`, since `C` is not monochromatic. This contradiction
excludes the exact collision. The argument also covers a collision with
the frame. Equivalently, arbitrarily large finite depths would contradict
(4). Only the valuation equations are used in this perturbation step;
no unproved deformation of actual solutions is asserted.

There are finitely many hierarchy cones. A sufficiently small closed
neighborhood of the original covector avoids all cones not containing it.
For every remaining hierarchy, use (3) and maximize the right-hand side
of (4) on that neighborhood. This supplies a common finite upper bound
for all different-color pairs, including exact-collision exclusion, for
the entire full leaf-target neighborhood.

For the lower bound, the actual-arrow window already gives a common
positive lower bound on every actual arrow. The actual underlying graph
of a nonempty selected factor is connected: otherwise the Gale cut
identity on a component not containing the frame would contradict cut
genericity. Connect any two vertices by an actual-arrow path and apply
the ultrametric inequality. All coordinate differences therefore have
valuation at least the actual-arrow lower bound. This proves (1).

## Consequence for the monic-polynomial presentation

In the finite generic selected Q algebra, all the following elements are
units:

\[
Q_i(0),\qquad \operatorname{Res}(Q_i,Q_j)\quad(i\ne j), \tag{5}
\]

with the factors for degree-zero polynomials omitted. Indeed each
geometric point lifts to ordered roots of the `Q_i`. The remainder
conditions imply all the clone row equations, and the actual-arrow
open condition is retained. Equation (1) excludes a zero of any element
in (5). A function that vanishes at no geometric point of a finite
algebra is a unit; reducedness is unnecessary.

Consequently the selected special coefficient algebra is unchanged if
its boundary saturation uses

\[
S_{\rm full}=\prod_iQ_i(0)\prod_{i<j}\operatorname{Res}(Q_i,Q_j)
\]

in place of the actual-arrow boundary polynomial. To see this at the
scheme level, complete the already selected T-flat algebra at the
origin. It is finite and T-torsion-free, and `S_full` is a unit after
inverting T by (5). Any `S_full`-torsion would therefore be T-torsion and
is zero. Additional saturation does not change this completed factor or
its special fiber. The special algebra is already supported at the
origin, so the resulting special quotient is the same finite algebra.

This does **not** authorize same-color discriminant saturation. A repeated
root of one `Q_i` is compatible with (1) and may carry required sign
multiplicity.

## Role in the mutation mechanism

The result allows division by any other-color polynomial in a quotient
ring `R[z]/Q_j` on the generic selected factor, even when that factor was
not an original edge. It also controls newly created arrows after mutation.
It is used below for complementary polynomial factors and their coupled
unit targets, rather than as a separate exclusion catalog.
