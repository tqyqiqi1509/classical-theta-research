from pathlib import Path
from itertools import product
import sys, random, json, time
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'computation'))
from q_degree_descent import mutation, coefficient_rewrite, evaluate_rewrite
from incoming_recursion import IncomingSchur
from arbitrary_endpoint_ray import endpoint


def coeff(B, D, g, p, a):
    if min(p) < 0:
        return 0
    return endpoint(IncomingSchur(B, D), tuple(g),
                    tuple(D[i]*a[i] for i in range(len(D))),
                    tuple(p)).get(tuple(p), 0)


def run(trials=400):
    rng = random.Random(2611132228)
    started = time.time()
    out = []
    all_states = 0; negatives = 0; nonzero = 0; savings = 0
    for it in range(trials):
        n = 2 if it < 160 else 3 if it < 360 else 4
        D = [rng.randint(1, 3) for _ in range(n)]
        B = [[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                b = rng.randint(-2, 2)
                B[i][j] = b * D[j]; B[j][i] = -b * D[i]
        g = [rng.randint(-4, 3) for _ in range(n)]
        p = [rng.randint(0, 3 if n == 2 else 1) for _ in range(n)]
        signs = [rng.choice([-1, 1]) for _ in range(n)] if it % 2 else None
        rewrite = coefficient_rewrite(B, D, g, p, start_base=97,
                                      signs=signs, certify=False)
        values = []
        for state in rewrite['states']:
            values.append(coeff(state['B'], D, state['g'], state['p'], state['a']))
            all_states += 1
            if state['action'] == 'complement':
                k = state['color']
                negatives += state['a'][k] < 0
                bb, gg, pp, aa = mutation(state['B'], state['g'], state['p'], state['a'], k)
                rb, rg, rp, ra = mutation(bb, gg, pp, aa, k)
                assert (rb, rg, rp, ra) == (state['B'], state['g'], state['p'], state['a'])
        expected = values[0]
        assert all(v == expected for v in values), (rewrite, values)
        assert rewrite['status'] != 'zero' or expected == 0, (rewrite, values)
        nonzero += expected > 0
        savings += rewrite['initial_degree'] - rewrite['final_degree']
        row = dict(rewrite=rewrite, coefficient=expected, values=values, pass_check=True)
        out.append(row)
        if it % 25 == 0:
            print(json.dumps(dict(inputs=len(out),states=all_states,
                                  nonzero=nonzero,negative_steps=negatives,
                                  removed_variables=savings,seconds=time.time()-started)),flush=True)
    report = dict(status='PASS', inputs=len(out), states=all_states,
                  nonzero_inputs=nonzero, negative_endpoint_steps=negatives,
                  variables_removed=savings,
                  strict_rewrites=sum(r['rewrite']['rewrites'] for r in out),
                  zero_returns=sum(r['rewrite']['status']=='zero' for r in out),
                  terminal_returns=sum(r['rewrite']['status']=='terminal' for r in out),
                  max_steps=max(r['rewrite']['rewrites'] for r in out),
                  seconds=time.time()-started,
                  note='Independent incoming comparisons; cut conditions checked. Rank certification belongs to the exact algorithm and separate Q cases.',
                  examples=sorted(out,key=lambda r:(-r['rewrite']['rewrites'],-r['coefficient']))[:18])
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='examples'}),flush=True)


if __name__ == '__main__':
    run()
