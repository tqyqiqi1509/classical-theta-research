# A real cluster counterexample to multiplying local factorization ranks

2026-11-13. This example diagnoses a proposed proof step; it is not a
replacement for the general construction or a claimed main result.

Take

\[
B=\begin{pmatrix}0&1\\-1&0\end{pmatrix},\quad D=(1,1),
\quad g=(-m,0),\quad p=(1,1),\quad a=(-1,101),\qquad m\ge2.
\]

Writing `Q_1=z-x_1`, `Q_2=z-x_2`, the two Q equations are

\[
x_1-x_2=(-1)^mT x_1^m,\qquad x_1-x_2=T^{101}.
\]

Hence

\[
x_1^m=(-1)^mT^{100},\qquad x_2=x_1-T^{101}.             \tag{1}
\]

All m generic roots have positive valuation and satisfy the actual-arrow
open condition. The frame difference `x_1` and the arrow difference
`x_1-x_2` are nonzero. For these values of a all cut equations and the
rank genericity conditions are nonzero; this can also be checked by the
three hierarchies on the frame and two mutable leaves.

The selected factor has length m. Yet the selected one-color Weierstrass
degrees are both 1: the first row is dominated by `Q_2`, and the second
by `Q_1`. Each local factorization rank is `binom(1,1)=1`.

Thus two mutually coupled rank-one local factorization algebras can have
a selected global factor of arbitrarily large length, even for classical
A2 input with complete-color separation. A general proof cannot multiply
local Grassmannian ranks. The incoming/outgoing **maximum degree** bound
in `WEIGHTED_Q_BEZOUT_REVIEW.md` instead gives m and is exact here.

At a positive endpoint for the same B,g,p, the outgoing degrees are m and
1, so this does not disprove the positive-endpoint outgoing-only bound.
