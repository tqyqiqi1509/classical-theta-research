# Route and source record: complementary Q factors and support

2026-11-13, 22:13--22:55 UTC. The parent keeps the overall 20-minute run
log; this records the actual mathematical changes in this branch.

## Completed general mechanisms

- The rank-recession theorem bounds every different-color difference,
  not only actual arrows. Exact nonedge collisions were treated by
  arbitrarily deep valuation refinements, not by pretending a deleted
  denominator was already invertible. `COMPLETE_COLOR_SEPARATION.md`.
- Weierstrass complementary factors implement quiver mutation on the
  selected Q factor with explicitly computed coordinate-dependent unit
  targets. New row identities hold in `A[z]/Q_j`, including repeated
  roots. The root-independent preparation unit permits the inverse map.
  `COMPLEMENTARY_Q_MUTATION.md`.
- The coupled units are removed through a genuinely finite flat graph
  family: solve for independent targets, retain smooth source, and use
  the valuation window for strict relative interior. This does not assert
  all special algebras are isomorphic. `COORDINATE_UNIT_DEFORMATION.md`.
- Strict complement degree descent terminates in at most `sum p_i` steps.
  A checked power-curve endpoint search avoids enumerating the full finite
  descent tree while retaining a termination proof. It reduces the actual
  Q calculation, rather than consulting coefficients to choose moves.
- The parent and this branch independently reached the maximum-degree
  binomial bound. A finite flat coefficient power cover gives a short
  weighted Bézout proof directly on the nonreduced isolated Q factor.
  `WEIGHTED_Q_BEZOUT_REVIEW.md`.

The parent independently read and checked the first three proof notes,
including all four endpoint/arrow sign combinations, and reported PASS.
The weighted bound is being sent to a fresh independent reviewer as well.

## Computations actually completed

- Actual Wolfram Language evaluator: 2,080 admissible rank 2--7 matrix
  inputs, 6,806 row identities, 1,018 negative-endpoint inputs, 1,958
  negative phase rows, 2,080 involution checks; all PASS. Code and the
  unmodified tool response are retained in `q_mutation_wolfram.*`.
- Independent incoming oracle: 400 degree-descent inputs and 470 states,
  169 nonzero initial coefficients, 70 strict rewrites, 100 variables
  removed in total, 16 negative-endpoint rewrite steps; all PASS.
  These tests check cut conditions; they do not pretend to certify every
  rank condition. The separate exact algorithm does certify them.
- Six end-to-end rational Q-algebra calculations with exact rank/cut
  certificates and terminal-only evaluation; all agree with the incoming
  oracle. One cyclic case drops from degree 4 to degree 1 in two steps.
- Proved maximum-degree binomial bound: 1,500 skew-symmetrizable inputs,
  24,100 coefficient positions including 9,594 nonzero positions and 628
  signed-endpoint inputs; all PASS.
- Unproved positive-endpoint outgoing-only bound: 1,200 inputs and 11,655
  nonzero positions; no counterexample. This is conjectural, not a theorem.
- Its signed-endpoint/local-rank analogue is false: the explicit A2 family
  `SIGNED_LOCAL_RANK_COUNTEREXAMPLE.md` has two local rank-one factors but
  total length m. Six values of m have exact rank/cut certificates and
  independent coefficient checks. The general symbolic proof is given.

## Routes that did not close support accessibility

1. Deleting one root changes another clone's target exponent by
   `B_ji val(x_j-x)`. This need not be positive or constant among roots of
   one color. Thus local divisor/Schur branching does not supply the
   required same-label support predecessor.
2. Cocyclic bound-quiver modules have accessible nonempty dimension support,
   but no general identification with arbitrary cluster theta coefficients
   has been obtained. Euler characteristic can vanish on a nonempty space;
   positivity alone does not repair this. This was recognized as an old
   gap already recorded in `finite_core_round5/SUPPORT_ACCESSIBILITY_ROUTE.md`.
3. A spherical CoHA module and its attractor-ideal repair had already been
   explored in the earlier package. The known 10-versus-7 discrepancy is
   not rediscovered as new progress here.
4. Multiplying local Grassmannian ranks is invalid; the signed A2 family
   proves this inside the present setting. The outgoing-only bound would
   require an additional all-positive-endpoint argument, perhaps an
   injective stable slot/forest code. Such a code is not currently proved.
5. Balanced terminal inequalities are analogous to old mutation fundamental
   regions and single-centered/quiver-invariant mechanisms. They are not
   by themselves a new finite-support result. This branch did not convert
   them into a list of special-case classifications.

## Primary literature read, with actual scope

### Benini--Park--Zhao, 2014

https://arxiv.org/pdf/1406.2699 ; Section 3.3, equations (3.37)--(3.39),
pp.33--35. Old Q-divisibility and complementary-factor duality are direct
prior art. The paper explicitly limits its solution argument and does not
prove a complete general ring equivalence. Our use is novelty comparison,
not a physical theorem input. The weak-solution warning motivated the
quotient-ring and full-separation proofs.

### Franzen, 2015 and 2020

https://arxiv.org/pdf/1307.3066 ; Theorem 3.1 and Lemma 3.8 were read.
The fine acyclic-quiver Chow presentation and anti-invariant construction
are established precedents for the algebraic pattern, but do not identify
our cyclic selected factor.

https://arxiv.org/pdf/1911.03288 ; Theorem 2 was read. It presents the
equivariant stable/semistable Chow kernels through destabilizing shuffle
products. This does not prove that the selected theta factor is such a
Chow quotient or that root deletion preserves its nonzero support.

### Reineke, 2003; Cheung, 2019

https://arxiv.org/pdf/math/0306185 ; Definition 1.1 and Lemma 1.2 were
read, with the forest-cell statement in the introduction. Generated
noncommutative Hilbert modules give a natural deletion mechanism, but the
required arbitrary-theta realization is absent.

https://arxiv.org/pdf/1906.12299 ; Section 5's Hall theta construction and
the acyclic equivalence statements were checked. The general-label,
arbitrary-cyclic conclusion needed here is not supplied by that source.

### Fei, 2021 version of *Combinatorics of F-polynomials*

https://arxiv.org/pdf/1909.10151 ; Theorems 0.4, 0.7, 0.9 and the stated
conjectures were read. The source distinguishes support saturation from
nonempty submodule support and imposes rigidity/acyclicity in its proved
saturation theorem. It cannot be imported as arbitrary-theta accessibility.

### Manschot--Pioline--Sen, 2013

https://arxiv.org/pdf/1309.7053 ; introduction and the stated status of
generalized mutations were read. Fermi flips and mutation fundamental
regions are old interfaces; the general Coulomb/Higgs and intrinsic-index
claims have explicit conjectural status. They are not theorem inputs here.

### 2026 lead requiring further review

Official https://arxiv.org/abs/2611.07549 confirms Fei, *Arithmetic Kac
Theory for Ramified Species*, v1, 2026-11-05, 47 pages. Metadata and
abstract were checked: its setting is acyclic ramified species and its
claims involve residue degrees and unfolding traces. The full proof has
**not** been strongly audited by this branch. It is retained as a possible
valued-species interface and is not used in any proof above.

The search also found *Arrangements and Likelihood*, DOI
10.1007/s10013-026-00790-1. The publisher's description concerns logarithmic
master-function critical points. Our equations are products of linear
forms at fixed targets, so these are different problems. No result from
that 2026 source is used without a proof-level audit.

No Li--Pan theorem or conclusion is used.

## 23:01 UTC: independent endpoint-germ pressure review

Read the complete dyadic-pressure draft, including its balanced-tree
whole-sequence strengthening, against the earlier stable-ray,
signed-endpoint, and analytic-path proofs. Verdict: PASS for a fixed
integral ray on its stated small domain. The proof uses positivity of
actual endpoint theta expansions before taking the germ; it does not
assert that inverse transport preserves coefficientwise order. The
quadratic prefix theorem becomes exact zero-background sparsity after
inverse transport. The active-subtree code removes any independent
choice of leaf positions, and the balanced-tree refinement supplies a
whole-sequence stretched-exponential estimate.

Two technical interfaces were made explicit: generic endpoints may be
chosen separately at every finite truncation, and the analytic coarse
factor is the unique normal-family limit of uniformly bounded
one-segment transports. See `RAY_PRESSURE_INDEPENDENT_REVIEW.md`.

The proof gives a common domain for bounded primitive integral height;
an integral-height-independent domain has not been proved here. Root
requested a fresh reviewer for the global Gale-to-Q-to-theta interface,
so this branch stops after preserving its completed work. Outgoing-only
binomial bounds and support accessibility remain open. No new numerical
claim about self-endpoint germs is made.
