"""Reproduce the two binomial-bound probes; incoming recursion is the oracle."""
from pathlib import Path
import sys, json, random, time
from math import comb
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'computation'))
from incoming_recursion import IncomingSchur, box
from arbitrary_endpoint_ray import endpoint


def weighted(trials=1500):
    rng=random.Random(2611132258); bad=[]
    checks=nonzero=signed=0; start=time.time()
    for it in range(trials):
        n=2 if it<500 else 3 if it<1300 else 4
        D=[rng.randint(1,4) for _ in range(n)]; B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                b=rng.randint(-3,3); B[i][j]=D[j]*b; B[j][i]=-D[i]*b
        g=tuple(rng.randint(-7,5) for _ in range(n))
        a=tuple((rng.choice([-1,1]) if it%2 else 1)*101**i for i in range(n))
        cap=(3,3) if n==2 else (2,2,1) if n==3 else (1,1,1,1)
        R=IncomingSchur(B,D)
        F=endpoint(R,g,tuple(D[i]*a[i] for i in range(n)),cap)
        signed+=any(v<0 for v in a)
        for p in box(cap):
            if not any(p): continue
            ds=[max(max(g[i],0)+sum(max(B[i][j],0)*p[j] for j in range(n)),
                    max(-g[i],0)+sum(max(-B[i][j],0)*p[j] for j in range(n)))
                for i in range(n)]
            bound=1
            for d,k in zip(ds,p): bound*=comb(d,k) if d>=k else 0
            got=F.get(p,0); checks+=1; nonzero+=got>0
            if not 0<=got<=bound:
                bad.append(dict(B=B,D=D,g=g,a=a,p=p,coefficient=got,
                                bound=bound,degrees=ds)); break
        if bad: break
    result=dict(status='PASS' if not bad else 'FAIL',inputs=it+1,
                coefficient_checks=checks,nonzero_checks=nonzero,
                signed_endpoint_inputs=signed,seconds=time.time()-start,failures=bad)
    (HERE/'weighted_binomial_bound_probe.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


def outgoing(trials=1200):
    rng=random.Random(2611132243); bad=[]; checks=0; start=time.time()
    for it in range(trials):
        n=2 if it<300 else 3 if it<1000 else 4
        D=[rng.randint(1,3) for _ in range(n)]; B=[[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1,n):
                b=rng.randint(-3,3); B[i][j]=D[j]*b; B[j][i]=-D[i]*b
        g=tuple(rng.randint(-5,3) for _ in range(n))
        cap=(3,3) if n==2 else (2,2,2) if n==3 else (1,)*n
        F=IncomingSchur(B,D).theta_prefix(g,cap)
        for p,got in F.items():
            if not any(p): continue
            ds=[max(-g[i],0)+sum(max(-B[i][j],0)*p[j] for j in range(n))
                for i in range(n)]
            bound=1
            for d,k in zip(ds,p): bound*=comb(d,k) if d>=k else 0
            checks+=1
            if got>bound:
                bad.append(dict(B=B,D=D,g=g,p=p,coefficient=got,
                                binomial_bound=bound,degrees=ds)); break
        if bad: break
    result=dict(status='COUNTEREXAMPLE' if bad else 'NO_COUNTEREXAMPLE',
                inputs=it+1,checks=checks,nonzero=checks,
                seconds=time.time()-start,failures=bad)
    (HERE/'directed_binomial_bound_probe.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='outgoing': outgoing()
    else: weighted()
