from pathlib import Path
import json
from q_degree_descent import coefficient_rewrite, evaluate_rewrite
from incoming_recursion import IncomingSchur

cases=[
    ([[0]],[1],[-5],[4]),
    ([[0,1],[-1,0]],[1,1],[-3,-2],[2,2]),
    ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-1,-1],[1,1,1]),
    ([[0,-1,1],[1,0,-1],[-1,1,0]],[1,1,1],[-1,-2,0],[2,1,1]),
    ([[0,3],[-2,0]],[2,3],[-2,1],[2,1]),
    ([[0,1,0],[-1,0,1],[0,-1,0]],[1,1,1],[-1,-1,-1],[1,1,1]),
]
out=[]
for B,D,g,p in cases:
    rewrite=coefficient_rewrite(B,D,g,p)
    value=evaluate_rewrite(rewrite)
    expected=IncomingSchur(B,D).theta_prefix(tuple(g),tuple(p)).get(tuple(p),0)
    result=dict(rewrite=rewrite,result=value,expected=expected,
                match=value['coefficient']==expected)
    assert result['match'],result
    out.append(result)
    Path(__file__).with_name('q_descent_exact_algebras.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(g=g,p=p,rewrites=rewrite['rewrites'],
                         final_degree=rewrite['final_degree'],
                         coefficient=value['coefficient'],expected=expected)),flush=True)
