SeedRandom[2611132230];
pos[x_]:=Max[x,0];
failures={}; cases=0; rowChecks=0; negativeCases=0; involutions=0; phaseMinus=0;
Do[
 n=RandomInteger[{2,7}];
 dd=RandomInteger[{1,4},n];
 bm=ConstantArray[0,{n,n}];
 Do[rr=RandomInteger[{-3,3}];bm[[i,j]]=dd[[j]]rr;bm[[j,i]]=-dd[[i]]rr,{i,n},{j,i+1,n}];
 gg=RandomInteger[{-5,5},n];pp=RandomInteger[{0,4},n];kk=RandomInteger[{1,n}];
 aa=Table[RandomChoice[{-1,1}] 101^(i-1),{i,n}];sg=Sign[aa[[kk]]];
 deg=pos[-sg gg[[kk]]]+Sum[pos[-sg bm[[kk,j]]]pp[[j]],{j,n}];
 If[deg>=pp[[kk]],
  bp=Table[If[i==kk||j==kk,-bm[[i,j]],bm[[i,j]]+pos[bm[[i,kk]]]bm[[kk,j]]+bm[[i,kk]]pos[-bm[[kk,j]]]],{i,n},{j,n}];
  gp=Table[If[i==kk,-gg[[i]],gg[[i]]+pos[bm[[i,kk]]]gg[[kk]]+bm[[i,kk]]pos[-gg[[kk]]]],{i,n}];
  px=ReplacePart[pp,kk->deg-pp[[kk]]];
  ap=Table[If[i==kk,-aa[[i]],aa[[i]]+pos[sg bm[[i,kk]]]aa[[kk]]],{i,n}];
  oldeps=Table[(-1)^(pos[-gg[[i]]]+Sum[pos[-bm[[i,j]]]pp[[j]],{j,n}]),{i,n}];
  neweps=Table[(-1)^(pos[-gp[[i]]]+Sum[pos[-bp[[i,j]]]px[[j]],{j,n}]),{i,n}];
  Do[If[j!=kk,
   bb=bm[[j,kk]];
   desired=If[bb>0,bb Join[{pos[gg[[kk]]]},pos/@bm[[kk]]],If[bb<0,bb Join[{pos[-gg[[kk]]]},pos/@(-bm[[kk]])],ConstantArray[0,n+1]]];
   actual=Join[{gp[[j]]-gg[[j]]},Table[If[l==kk,0,bp[[j,l]]-bm[[j,l]]],{l,n}]];
   If[actual=!=desired,AppendTo[failures,{"exponents",bm,gg,pp,kk,j}]];
   qv=Table[Prime[l+2],{l,n}];qv[[j]]=0;
   akval=37^pos[gg[[kk]]] Product[If[bm[[kk,l]]>0,qv[[l]]^bm[[kk,l]],1],{l,n}];
   ekval=37^pos[-gg[[kk]]] Product[If[bm[[kk,l]]<0,qv[[l]]^(-bm[[kk,l]]),1],{l,n}];
   If[bb!=0,
    (* Use target magnitude |a_k|=1 here; exponent identities already tested above. *)
    pv=If[sg>0,ekval-oldeps[[kk]]2 akval,akval-oldeps[[kk]]2 ekval]/3;
    qp=qv;qp[[kk]]=pv/qv[[kk]];
    r0=oldeps[[j]]37^gg[[j]]Product[If[l==j,1,qv[[l]]^bm[[j,l]]],{l,n}];
    r1=neweps[[j]]37^gp[[j]]Product[If[l==j,1,qp[[l]]^bp[[j,l]]],{l,n}];
    phase=neweps[[j]]oldeps[[j]](-oldeps[[kk]])^pos[sg bb];
    wanted=phase 2^(-sg pos[sg bb])3^bb;
    If[r1/r0=!=wanted,AppendTo[failures,{"phase",bm,gg,pp,kk,j,r1/r0,wanted}]];
    phaseMinus+=Boole[phase==-1];rowChecks++;
   ];
  ],{j,n}];
  backdeg=pos[sg gp[[kk]]]+Sum[pos[sg bp[[kk,j]]]px[[j]],{j,n}];
  backp=ReplacePart[px,kk->backdeg-px[[kk]]];
  backg=Table[If[i==kk,-gp[[i]],gp[[i]]+pos[bp[[i,kk]]]gp[[kk]]+bp[[i,kk]]pos[-gp[[kk]]]],{i,n}];
  backa=Table[If[i==kk,-ap[[i]],ap[[i]]+pos[-sg bp[[i,kk]]]ap[[kk]]],{i,n}];
  If[backp=!=pp||backg=!=gg||backa=!=aa,AppendTo[failures,{"involution",bm,gg,pp,kk}]];
  involutions++;cases++;negativeCases+=Boole[sg<0];
 ],
 {2500}
];
<|"Status"->If[Length[failures]==0,"PASS","FAIL"],"AdmissibleInputs"->cases,"RowChecks"->rowChecks,"NegativeEndpointInputs"->negativeCases,"NegativePhaseRows"->phaseMinus,"InvolutionChecks"->involutions,"Failures"->Take[failures,UpTo[5]]|>
