# Independent review: a binomial bound from the Q equations

2026-11-13, 22:52 UTC. Status: **PASS**, with a shorter proof that needs no
additional Morse perturbation. The finite-factor identification proved
earlier in this run remains an input.

## Bound

For an active color let

\[
A_i^{\deg}=[g_i]_++\sum_j[B_{ij}]_+p_j,\qquad
E_i^{\deg}=[-g_i]_++\sum_j[-B_{ij}]_+p_j,\qquad
d_i=\max(A_i^{\deg},E_i^{\deg}).
\]

For every coefficient at a rank-generic and cut-generic signed endpoint,

\[
\boxed{0\le c_{g,p}(U)\le\prod_i\binom{d_i}{p_i}.}       \tag{1}
\]

Degree-zero colors contribute 1. If `p_i>d_i`, the corresponding binomial
is zero and the coefficient is zero. The bound is independent of endpoint
and symmetrizer, once the exchange matrix conventions are fixed.

## 1. Weighted degrees of the remainder equations

Give `z` weight 1 and each coefficient `c_{i,l}` of a monic `Q_i` weight
`l`. Give T weight zero, since T belongs to the ground field below. Then
`Q_i` is weighted homogeneous of degree `p_i`. Division by this monic
polynomial preserves weighted degrees.

The incoming part of the row polynomial is weighted homogeneous of degree
`A_i^deg`, and its outgoing part has degree `E_i^deg`. Consequently the
coefficient of `z^k` in its remainder modulo `Q_i` has weighted degree at
most

\[
d_i-k,\qquad 0\le k<p_i.                                \tag{2}
\]

This is true for either sign of the endpoint: powers of T are scalars.
It is also true when the coefficients of the remainders couple every
other color. No product-of-local-factorization-ranks argument is used.

## 2. The selected factor really is isolated

Work over a finite ramification of `K=Q((T))`, or an algebraic closure.
Here is an entirely algebraic isolation proof. Set

\[
C=\mathbb Q[T,c]/(J_{\rm rem}:(TS)^\infty),\qquad
A=\varprojlim_m C/T^mC.
\]

The reviewed Q theorem gives finite-dimensional `C/TC` and T-torsion
freeness. Lift a finite basis of `C/TC`. Successive T-adic reduction shows
that these lifts generate A over `Q[[T]]`, so A is finite free over that
DVR. Its generic rank, equal to its special length, is `c_{g,p}(U)`.

Put `C'=Q[[T]] tensor_(Q[T]) C`. The map `C' -> A` is the Noetherian
T-adic completion map and hence is flat. It is also surjective: every
element of A is a finite combination of the chosen lifts with coefficients
in `Q[[T]]`, and all those combinations already belong to C'. Its kernel
is finitely generated, since C' is Noetherian. A surjective flat map with
finitely generated kernel has idempotent kernel. Thus A is an open-and-
closed direct factor of C'.

Both T and S are nonzerodivisors on C by saturation and remain so after
flat completion. After T is inverted, multiplication by S is injective
on the finite-dimensional K-algebra `A_K`, hence bijective. Thus S is a
unit on this factor. Inverting T and S identifies `A_K` with a full finite
Artin direct factor of

\[
K[c,S^{-1}]/J_{\rm rem}.
\]

At its points S is nonzero, so localization does not change the local
rings of the original polynomial system `K[c]/J_rem`. Consequently the
selected algebra is a union of isolated **full** local factors of the
unperturbed n-polynomial system. All nilpotent lengths are retained. No
additional reducedness or analytic-germ claim is required. This is the
same valid fixed-target-field argument proved earlier for clone variables;
it is not the false universal-parameter assertion that a regular element
must be a unit over a higher-dimensional base.

There are exactly `sum p_i` coefficient variables and that many remainder
equations. At each isolated point the local ideal is therefore an
Artinian complete intersection in a regular local ring. Its scheme length
is its ordinary intersection multiplicity.

## 3. A finite flat power cover proves the weighted bound

Set

\[
c_{i,l}=u_{i,l}^{\,l}\qquad(1\le l\le p_i).              \tag{3}
\]

The map of affine spaces is finite flat of degree

\[
W=\prod_i\prod_{l=1}^{p_i}l=\prod_i p_i!.
\]

Indeed its coordinate ring is a free module over the c-coordinate ring,
with basis the monomials `product u_{i,l}^{b_{i,l}}`, `0<=b_{i,l}<l`.
The inverse image of the isolated selected factor is isolated and has
length exactly `W c_{g,p}(U)`. This equality includes ramification over
`c_{i,l}=0`; avoiding the coordinate hyperplanes is unnecessary.

After (3), weighted degree becomes ordinary total degree. The pulled-back
row coefficient in (2) has degree at most `d_i-k`. The ordinary affine
Bézout inequality for isolated zero-dimensional factors, counted with
intersection multiplicity, gives

\[
W c_{g,p}(U)\le\prod_i\prod_{k=0}^{p_i-1}(d_i-k).
\]

Divide by W to obtain (1). This use of Bézout permits other components of
the full polynomial system; only isolated-factor multiplicities are
included on the left. One can obtain the same inequality by perturbing
the equations generically within these degree bounds and conserving each
isolated complete-intersection multiplicity. This is the standard
algebraic Bézout inequality, not a claim of new intersection theory.

If `p_i>d_i`, the polynomial `F_i` has exact degree `d_i` over K and a
nonzero scalar leading coefficient. For unequal incoming/outgoing degrees
this is immediate; for equal degrees its leading coefficient is
`T^[a_i]_+ - epsilon_i T^[-a_i]_+`, nonzero because cut genericity gives
`a_i!=0` for an active color. A monic polynomial of larger degree cannot
divide it over any nonzero coefficient algebra. The remainder ideal is
therefore the unit ideal, proving the zero case of (1).

## 4. Why the new perturbation suggested by the parent also works

The parent proposed perturbing the **polynomial** row by
`T^N P_i(z)`, `deg P_i<=p_i-1`. On the enlarged actual-arrow-open affinoid,
`E_i(x)^{-1}` has a uniform norm bound. Choosing N beyond this bound and
all target exponents turns the perturbation, after division by E_i, into
a uniformly small analytic unit-target perturbation. Solving the equation
for the independent target keeps the source a smooth graph; the tropical
window forces strict interior, so finite flatness follows.

The old equivariant Hermite argument also extends: evaluation at the
distinct coordinate values gives independent conditions, and at a repeated
value the derivative of `P_i/E_i` is an independent Hermite parameter since
E_i is nonzero there. Thus a generic perturbation separates the needed
strata. Since `p_i<=d_i` on a nonzero factor, the polynomial degree does
not exceed d_i.

However none of these additional transversality assertions is needed for
(1): Sections 1--3 work directly with the nonreduced Q factor and avoid
the unnecessary new proof burden.

## 5. Strictly stronger than the earlier raw-clone bound

The previous Morse construction used a perturbation of the rational row
and then cleared its denominator. Its degree bound could include
`E_i^deg+p_i-1`; free Young orbits then divided a Bézout power bound by
`p_i!`. Formula (1) removes that extra degree and uses all weighted
coefficient degrees, giving a falling factorial instead of a power.

For growth estimates it immediately implies

\[
c_{g,p}(U)\le
\frac{\prod_i\bigl(|g_i|+\sum_{j\ne i}|B_{ij}|p_j\bigr)^{p_i}}
     {\prod_i p_i!}.                                    \tag{4}
\]

The diagonal `p_i` contribution from the old majorant has disappeared.
The parent is developing the optimized density and analytic consequences;
this note does not duplicate them.

## 6. Distinguish the still unproved outgoing-only bound

For positive endpoints, experiments support the sharper conjectural
replacement `d_i -> E_i^deg`. It is not a consequence of (1). For signed
endpoints that replacement is false, even if one uses each row's selected
Weierstrass degree. An explicit A2 counterexample is recorded in
`SIGNED_LOCAL_RANK_COUNTEREXAMPLE.md`.

Thus (1) is a proved uniform binomial bound. The outgoing-only version and
support accessibility remain separate open routes.
