# Complementary Q factors and a finite degree-descent rewrite

2026-11-13. Classical skew-symmetric and skew-symmetrizable cluster input.
This note gives a mutation mechanism on the actual coefficient algebras.
The theta coefficient mutation identity is established prior mathematics;
the point here is its realization by complementary distinguished
polynomials with nilpotents retained, including the required unit family.

## 1. Data and degree reflection

Fix `B,D,g,p,a`, with `p` nonnegative integral and `D B` skew-symmetric.
Use the selected positive factor of the monic-Q equations. The endpoint
`a` may have mixed signs and satisfies the rank and cut conditions.
Choose an index `k` with `a_k != 0` and put `sigma=sign(a_k)`.

Define

\[
d_k^\sigma=[-\sigma g_k]_+
             +\sum_j[-\sigma B_{kj}]_+p_j,
\qquad p'_k=d_k^\sigma-p_k,\quad p'_j=p_j\ (j\ne k).       \tag{1}
\]

Let `B'=mu_k B` and

\[
g'_k=-g_k,\qquad
g'_j=g_j+[B_{jk}]_+g_k+B_{jk}[-g_k]_+\quad(j\ne k),       \tag{2}
\]

\[
a'_k=-a_k,\qquad
a'_j=a_j+[\sigma B_{jk}]_+a_k\quad(j\ne k).               \tag{3}
\]

Require that `a'` also be rank-generic and cut-generic for `(B',g',p')`
when `p'_k>=0`. This can always be arranged at the start. On the open
half-space with prescribed `sign(a_k)`, (3) is an invertible integral
linear map. The old and new forbidden conditions therefore pull back to
a finite union of proper rational hyperplanes. Choosing a rational point
off their union, and clearing denominators, gives the required exponents.
For the original positive chart one may make this choice inside the
positive orthant. No coefficient oracle is used.

If `p'_k<0`, the old selected coefficient algebra is zero. If `p'_k>=0`,
the selected finite Q lengths are equal:

\[
\dim\mathcal Q(B,g,p;Da)
=\dim\mathcal Q(B',g',p';Da').                           \tag{4}
\]

The proof below constructs an isomorphism to a precisely specified
coupled-unit Q system, followed by a finite flat unit deformation. It
does not claim an isomorphism between the two displayed special algebras.

## 2. Preparation and complementation

Write

\[
A_i=z^{[g_i]_+}\prod_jQ_j^{[B_{ij}]_+},\qquad
E_i^0=z^{[-g_i]_+}\prod_jQ_j^{[-B_{ij}]_+},\qquad
\epsilon_i=(-1)^{\deg E_i^0}.
\]

The signed row polynomial is

\[
F_i=T^{[a_i]_+}A_i-\epsilon_iT^{[-a_i]_+}E_i^0.          \tag{5}
\]

All `Q_i` are distinguished monic polynomials at the origin. Complete the
other-color coefficient ring at that origin. Formal preparation gives a
monic distinguished `P_k` of degree `d_k^sigma` and a unit `u_k` such that

\[
u_kP_k=
\begin{cases}
E_k^0-\epsilon_kT^{a_k}A_k,& a_k>0,\\
A_k-\epsilon_kT^{-a_k}E_k^0,& a_k<0.
\end{cases}                                             \tag{6}
\]

Here `u_k=1 modulo T^{|a_k|}`. The precise uniform analytic domain and
the unit homotopy are proved in `COORDINATE_UNIT_DEFORMATION.md`.

The old row condition `Q_k divides F_k` is equivalent to `Q_k divides P_k`.
If `p_k>d_k^sigma`, this is impossible for monic polynomials and the
completed row algebra is zero. Otherwise set

\[
Q'_k=P_k/Q_k,\qquad Q'_j=Q_j\ (j\ne k).                \tag{7}
\]

The quotient is monic of degree (1), and its coefficients have positive
valuation. Polynomial division and the relation `Q_k divides P_k` make
(7) valid over nonreduced coefficient rings, not only at simple roots.

## 3. Exact row transformation in quotient rings

Put

\[
R_j(z)=z^{g_j}\prod_lQ_l(z)^{B_{jl}},\qquad
\Gamma_j(z)=\epsilon_jR_j(z).
\]

These expressions are used in the finite algebra `A[z]/Q_j` after T is
inverted. The complete-color-separation lemma makes every different-color
polynomial and `z` a unit there. This includes nonadjacent colors and does
not require `Q_j` to be squarefree.

For `j!=k`, let `b=B_jk`. The matrix and label formulas give the exact
Laurent identities

\[
\frac{R'_j}{R_j}=
\begin{cases}
\left(\dfrac{A_k}{Q_kQ'_k}\right)^b,&b>0,\\
\left(\dfrac{E_k^0}{Q_kQ'_k}\right)^b,&b<0,\\
1,&b=0.
\end{cases}                                             \tag{8}
\]

If `b>0`, the skew-symmetrizer condition implies `B_kj<0`; hence `E_k^0`
vanishes in `A[z]/Q_j`. If `b<0`, `A_k` vanishes there. Substitute (6)
into (8). With

\[
\epsilon'_i=(-1)^{[-g'_i]_++\sum_l[-B'_{il}]_+p'_l},
\]

the transformed equations become

\[
\Gamma'_j(z)=s_jT^{-a'_j}u_k(z)^{B_{jk}}\pmod{Q_j}
\quad(j\ne k),                                         \tag{9}
\]

where

\[
s_j=\epsilon'_j\epsilon_j
                  (-\epsilon_k)^{[\sigma B_{jk}]_+}\in\{1,-1\}.
                                                               \tag{10}
\]

For `sigma=-1`, the exponent arising directly in (8) is a negative integer;
its parity agrees with `[sigma B_jk]_+`, so (10) remains correct.

The row at `k` is

\[
\Gamma'_k=s_kT^{-a'_k}\pmod{Q'_k},\qquad
s_k=\epsilon'_k\epsilon_k.                              \tag{11}
\]

Indeed `Q'_k` divides the same polynomial (5), and
`Gamma'_k=epsilon'_k E_k^0/A_k`. Equations (8)--(11) are identities in
quotient rings. They therefore include every confluent derivative
condition at repeated roots. Checking them only at roots would have been
insufficient.

## 4. New arrows and the inverse map

For a neighbor `j` of `k`, reduction of (6) modulo `Q_j` leaves exactly one
nonzero monomial product. That product is a unit by old complete-color
separation. Thus `P_k` and then `Q'_k` are units modulo `Q_j`. This proves
the required new edge-coprimality without an assumption about strong
solutions. If `g_k!=0`, the same argument at `z=0` proves `Q'_k(0)` is a
unit. Newly created edges between two colors different from `k` are
already covered by the old complete-color separation.

Thus the complementary map lands in the actual-arrow open part of the
new system (9)--(11). Conversely, on this new coupled-unit system the
units have valuation zero. The new endpoint rank and cut conditions give
complete-color separation there as well. The same quotient-ring
identities can therefore be read backwards. The new row at `k` says
`Q'_k divides P_k`, and

\[
Q_k=P_k/Q'_k
\]

recovers the old point and all its nilpotent coefficient relations.
The two constructions are inverse. They preserve positive valuations,
and are an isomorphism of the selected finite generic algebras to the
specified coupled-unit algebra. The degree-zero case `Q'_k=1` is included.

## 5. Removing the coupled units without losing multiplicity

Let

\[
u_{k,s}=1+s(u_k-1),\qquad |s|\le1.
\]

Replace the right side of (9) by
`s_j T^{-a'_j} u_{k,s}^{B_jk}`, keeping (11). These are equivariant analytic
units on a uniform enlarged positive-coordinate domain. The
coordinate-unit deformation theorem proves a finite flat family after
adjoining independent clone targets. On the color-invariant target slice,
the sign isotypic summand is a finite projective direct summand of
constant rank. The analytic remainder/alternant identity identifies it
with the selected Q factor.

At `s=1` this is the algebra reached by the complementary map, and at
`s=0` it has only the constant signs (10)--(11). The full connected
unit-target polyannulus changes those signs to `+1` without changing the
selected length. This proves (4) including all nilpotent contributions.
It is a direct Q-factor proof; theta mutation is not used in the proof.

## 6. A terminating greedy rewrite for a specified coefficient

For the current signed endpoint define `d_i` by (1), using
`sigma_i=sign(a_i)`. The following algorithm is finite.

1. If some `p_i>d_i`, return zero by the one-color factorization argument.
2. If some `0<=d_i-p_i<p_i`, complement that color and replace all data by
   (1)--(3). A deterministic choice is the greatest decrease
   `2p_i-d_i`, with index order breaking ties.
3. Repeat until no such index remains. Evaluate the resulting smaller
   coefficient algebra by its Q remainder presentation.

Each nonzero rewrite decreases `sum p_i` by a positive integer. Thus there
are at most `sum p_i` rewrites. The final degree vector satisfies

\[
2p_i\le d_i\quad\text{for every active color }i.         \tag{12}
\]

The algorithm changes the actual monic factor objects by complements;
it is not merely a numerical lookup of equal theta coefficients. It can
reduce the number of coefficient variables before a Gröbner calculation.
It retains an irreducible coupled core when (12) prevents further degree
descent. No assertion that this core vanishes or has bounded size is made.

For one explicit generic endpoint valid throughout the algorithm, build
the finite tree of all possible strict degree-decreasing reflections,
allowing either endpoint sign at each step. Its depth is at most the
initial `sum p_i`; every branch transformation of `a` is invertible and
linear. Pull back the rank, cut, and coordinate-zero hyperplanes for all
states and select one positive rational `a` outside this finite union.
Only states consistent with its actual signs are used. This avoids
unjustified assumptions that genericity automatically survives mutation.

The rewrite is an enhancement of the specified-coefficient algorithm.
It is **not** a general finite-support certificate for an entire theta
Laurent polynomial: the terminal inequalities (12) may allow arbitrarily
large coupled cores. Establishing a finite-support mechanism remains a
separate task.

## 7. Relation to prior Q-polynomial duality

Benini--Park--Zhao, arXiv:1406.2699, Section 3.3, already formulates monic
Q-polynomial divisibility and complementary factors under quiver duality.
Equations (3.37)--(3.39) and the discussion on pp.33--35 state that the
displayed relations are not a complete general chiral-ring presentation,
use simple-root edge-coprime strong solutions, and allow a strong solution
to map to a weak one. General weak solutions are not covered by their
argument. The original paper was reopened and those passages read directly
on 2026-11-13: https://arxiv.org/pdf/1406.2699 .

Accordingly, complementation and the exchange identities themselves are
not claimed as new. The present mechanism concerns the selected positive
Gale factor of arbitrary classical theta data: complete-color separation,
quotient-ring identities at repeated roots, local distinguished factors,
and the finite-flat removal of the coordinate-dependent Weierstrass unit.
It supplies a rigorous algebraic rewrite for that factor. It does not
claim an equivalence of the physical chiral rings discussed in the source.
