# Independent review of positive endpoint germs and ray pressure

2026-11-13, 23:01 UTC. Reviewer: `q_support_round2`.

## Verdict

**PASS** for the per-integral-direction theorem and for the balanced-tree
whole-sequence strengthening in
`../ray_pressure_mechanism/DYADIC_VANISHING_PRESSURE.md`, version updated
22:58 UTC. The claimed conclusion is local in the analytic seed variables.
The explicit radius may depend on the primitive integral direction. A
common domain for bounded primitive integral height follows from the
uniform analytic path estimate. This review does not claim one common
domain for all primitive directions.

The proof inputs were checked against
`../newton_properties/STABLE_RAY_AND_WALL_RECOVERY.md`,
`../dyck_flow_round2/SIGNED_ENDPOINT_AND_PRODUCT_ALGEBRAS.md`, and
`../dyck_flow_round2/ANALYTIC_PATH_ORDERED_PRODUCTS.md`. In particular, the
covariance orientation was checked directly rather than inferred from a
formal quotient of two positive series.

## 1. The correct endpoint germ

In the established normalization the incoming total automorphism factors
as

\[
C=A_g^- Z_g A_g^+,
\qquad \lambda_g(p)=g^TDp.
\]

For endpoints \(U_\epsilon=Dg+\epsilon v\), with \(v\) strictly positive,
every finite root truncation has the same sign as \(\lambda_g\) for its
nonzero values once \(\epsilon\) is small enough; zero roots acquire
positive sign. Thus its negative factor is exactly \(A_g^-\) through that
truncation. The signed-endpoint identification uses the inverse negative
factor to take a theta expansion in the positive chart to the endpoint
chart. It therefore gives

\[
x^{ng}G_n=(A_g^-)^{-1}(\vartheta_{ng,+}).
\]

This is the asserted direction. The inverse is essential: for rank one,
\(g<0\), the negative factor is the initial wall automorphism and this
formula gives \(G_n=1\), as it should.

Only finite truncations require a generic endpoint. If a selected
\(U_\epsilon\) lies on one of the auxiliary rank hyperplanes, it can be
perturbed inside the same finite cut chamber without changing its finite
scattering transport. Equivalently, choose \(v\) and \(\epsilon\) after
fixing the finite set of coefficients. There is no requirement that one
fixed \(\epsilon>0\) work in every degree. Positivity and compatibility
pass coefficient by coefficient, so

\[
G_n\in 1+\mathbb N[[z_1,\ldots,z_r]].
\]

## 2. Submultiplicativity is obtained before taking the limit

At any common generic endpoint the positive theta multiplication identity
has the form

\[
F_{ng,U}F_{mg,U}
=F_{(n+m)g,U}
 +\sum_{q>0}c_qz^qF_{(n+m)g+Bq,U},
\qquad c_q\ge0.
\]

The exponent is correct because the global summand is
\(y^q\vartheta_{(n+m)g+Bq}\), and after division by
\(x^{(n+m)g}\) its leading monomial is \(z^q\).
Frozen variables are fixed by transport. At any specified root degree
only finitely many summands can contribute. Every remaining series on
the right has nonnegative coefficients at that endpoint. Taking the
positive zero-root germ yields

\[
G_{n+m}\le_{\mathrm{coeff}}G_nG_m.
\]

This argument makes no assertion that \((A_g^-)^{-1}\) preserves
coefficientwise order on arbitrary formal series.

## 3. Stabilization really becomes a zero-background statement

The stable-ray theorem states

\[
\vartheta_{ng,+}=A_g^-(x^{ng})\pmod{\deg>d}
\quad\text{if}\quad n>M_0d^2,
\qquad M_0=\max_{i,j}|D_iB_{ij}|.
\]

Both the factor and its inverse preserve the positive principal-degree
filtration: every nonidentity derivation adds a nonzero positive root.
Applying the inverse therefore proves

\[
G_n=1\pmod{\deg>d}\quad(n>M_0d^2).
\]

This conclusion is stronger than saying that a coefficientwise limit of
\(G_n\) is one. It supplies an exact, uniform vanishing constraint at
every internal node of a recursive multiplication tree. Replacing
\(M_0\) by \(M=\max(1,M_0)\) handles the zero exchange matrix.

## 4. Independent check of the counting estimate

For a dyadic multiplication tree, a node of height \(j\) with positive
degree \(q\) must obey \(2^j\le Mq^2\). Active nodes at one height have
disjoint degree budgets; there are at most
\(p\sqrt M\,2^{-j/2}\) of them for total degree \(p\). Summing the
geometric series gives at most

\[
c_Mp,\qquad c_M=\frac{\sqrt M}{1-2^{-1/2}},
\]

active nodes. An ordered subtree is uniquely encoded by listing, in
depth-first order, whether each node has zero active children, only its
left child, only its right child, or both. The root position and the
underlying tree are fixed. Thus there is no additional choice of
\(p\) leaf positions among \(2^h\) sites. Such an extra factor would
invalidate the useful estimate and is correctly absent from the proof.

All active leaves are terminal leaves: an internal active node cannot
have two zero children. For \(r\) active terminal leaves, the positive
degree assignments are compositions of \(p\), at most \(2^{p-1}\).
The assumed single-leaf coefficient bound gives weight at most \(B^p\).
Hence \(K=2B4^{c_M+1}\) is a valid conservative exponential bound.

The non-dyadic strengthening also passes. In the balanced tree on \(n\)
leaves, with \(h=\lceil\log_2n\rceil\), every depth
\(\ell<h\) node has at least
\(\lfloor n/2^\ell\rfloor\ge n/2^{\ell+1}\) descendants. All terminal
depths are \(h-1\) or \(h\). Summing the active-node bound over depths,
and bounding the last depth by \(p\), gives

\[
L\le\left(1+\frac{2\sqrt M}{\sqrt2-1}\right)p=b_Mp.
\]

The same code and composition bounds give
\(a_n(p)\le K_{\rm all}^p\) for all \(n\), with
\(K_{\rm all}=2B4^{b_M+1}\). The strict condition
\(n>Mp^2\) means the first possibly nonzero degree is
\(\lceil\sqrt{n/M}\rceil\), including the equality case. The geometric
tail estimate in the draft is therefore correctly indexed.

## 5. Analytic passage and an endpoint-limit detail

For a nonnegative radial vector \(w\) with \(\sum w_i=1\), the
all-endpoint estimate yields

\[
[s^p]G_1(sw)
 \le\frac{(\|g\|_\infty+Cp)^p}{p!}
 \le[e(\|g\|_\infty+C)]^p.
\]

The multinomial summation removes the individual \(p_i!\) denominators.
The resulting constants are independent of \(w\), so the one-variable
tree bound applies to absolute multivariable values on an \(\ell^1\)
ball. It proves \(G_n\to1\), locally uniformly, at the stated
stretched-exponential rate in \(\sqrt n\).

For completeness, the analytic meaning of the coarse germ factor can be
justified without claiming that it is the full transport of one fixed
ordinary endpoint. Choose \(\epsilon_d\downarrow0\) so its transport
agrees with \(A_g^-\) through degree \(d\). The one-segment analytic
path theorem provides a common domain and a uniform bound on all their
logarithmic coordinate displacements. This is a normal family; every
subsequential analytic limit has the same stabilized Taylor series.
Uniqueness of analytic continuation identifies the entire limit with
the germ \(A_g^-\). It inherits the common bound \(K_{\rm path}\).
Its coordinate factors are exponentials of holomorphic functions and
therefore are nonzero.

Writing

\[
A_g^-(x^g)=x^gH_g(z),\qquad A_g^-(z_j)=W_{g,j}(z),
\]

the exact formal identity is

\[
F_{ng}(z)=H_g(z)^nG_n(W_g(z)).
\]

It becomes an analytic identity on a sufficiently small common domain,
because both sides have their prescribed convergent Taylor expansions.
Thus on every compact subset with
\(K_{g,\rm all}\sum_j|W_{g,j}(z)|\le q<1\),

\[
\frac{F_{ng}(z)}{H_g(z)^n}
=1+O\!\left(q^{\sqrt{n/M}}\right).
\]

The real pressure is consequently \(\log H_g(z)\) on the corresponding
positive neighborhood. The denominator never vanishes there. Eventual
nonvanishing of the numerator follows from the displayed estimate; it
was not an assumption in the argument.

## 6. Scope of the uniform statements

The proof supplies a common domain when the infinity norm of the
primitive integral generator is bounded. The path map bound is uniform
in the endpoint; the remaining displayed tree constant depends on that
primitive generator. Positive homogeneity extends the result along each
rational ray. Convexity and the pre-existing lower bound \(L\le\Phi\)
then extend equality across any finitely generated cone on which \(L\)
is linear and whose generating rays have a common valid domain.

None of these steps proves an integral-height-independent radius.
Attempting to obtain it by multiplying the individual Weierstrass
divisor ranks is invalid: the signed A2 counterexample in
`SIGNED_LOCAL_RANK_COUNTEREXAMPLE.md` rules out that general shortcut.
Additional structure specific to the self-endpoint germ could still
produce a uniform improvement, but is not an input to the theorem
reviewed here.
