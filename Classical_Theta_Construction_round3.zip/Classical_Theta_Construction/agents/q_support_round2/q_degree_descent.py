"""Complementary distinguished Q-polynomial degree descent.

The algorithm uses only B,D,g,p and exact finite genericity certificates.
No theta coefficient is used to select a rewrite or its endpoint.  The
independent incoming oracle is imported only by the probe runner.
"""
from pathlib import Path
from functools import lru_cache
from itertools import product
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'computation'))


def mutation(B, g, p, a, k):
    n = len(B)
    assert a[k]
    sig = 1 if a[k] > 0 else -1
    degree = max(-sig * g[k], 0) + sum(
        max(-sig * B[k][j], 0) * p[j] for j in range(n))
    bb = tuple(tuple(-B[i][j] if i == k or j == k else
                     B[i][j] + max(B[i][k], 0) * B[k][j]
                     + B[i][k] * max(-B[k][j], 0)
                     for j in range(n)) for i in range(n))
    gg = tuple(-g[i] if i == k else
               g[i] + max(B[i][k], 0) * g[k]
               + B[i][k] * max(-g[k], 0) for i in range(n))
    pp = tuple(degree - p[k] if i == k else p[i] for i in range(n))
    aa = tuple(-a[i] if i == k else
               a[i] + max(sig * B[i][k], 0) * a[k] for i in range(n))
    return bb, gg, pp, aa


def reflected_degrees(B, g, p, a):
    return tuple(max(-(1 if a[i] > 0 else -1) * g[i], 0)
                 + sum(max(-(1 if a[i] > 0 else -1) * B[i][j], 0)
                       * p[j] for j in range(len(B)))
                 for i in range(len(B)))


def raw_descent(B, g, p, a):
    B = tuple(map(tuple, B)); g = tuple(g); p = tuple(p); a = tuple(a)
    states = []
    while True:
        if any(not v for v in a):
            return None
        ds = reflected_degrees(B, g, p, a)
        row = dict(B=B, g=g, p=p, a=a, degrees=ds)
        states.append(row)
        impossible = [i for i in range(len(B)) if p[i] > ds[i]]
        if impossible:
            row.update(action='zero', color=impossible[0])
            return dict(status='zero', states=states,
                        initial_degree=sum(states[0]['p']),
                        final_degree=sum(p), rewrites=len(states)-1)
        candidates = [i for i in range(len(B)) if ds[i] - p[i] < p[i]]
        if not candidates:
            row['action'] = 'terminal'
            return dict(status='terminal', states=states,
                        initial_degree=sum(states[0]['p']),
                        final_degree=sum(p), rewrites=len(states)-1)
        k = min(candidates, key=lambda i: (ds[i] - 2*p[i], i))
        row.update(action='complement', color=k, drop=2*p[k]-ds[k])
        B, g, p, a = mutation(B, g, p, a, k)


@lru_cache(None)
def rank_forms(B, D, g, p):
    from graph_gale_staircase import graph_data, color_generic_weights
    if not any(p):
        return (), (), 0
    colors, eta = graph_data(B, D, g, p)
    _, cert = color_generic_weights(eta, colors, D)
    return (tuple(cert['active_colors']),
            tuple(tuple(f) for f in cert['excluded_forms']),
            cert['hierarchies'])


def certify_endpoint(B, D, g, p, a, rank=True):
    cuts = all(sum(D[i]*a[i]*v[i] for i in range(len(B)))
               for v in product(*(range(t+1) for t in p)) if any(v))
    if not cuts:
        return None
    if not rank:
        return dict(cut_generic=True, rank_checked=False)
    active, forms, nh = rank_forms(tuple(map(tuple, B)), tuple(D),
                                   tuple(g), tuple(p))
    if any(not sum(f[j] * a[i] for j, i in enumerate(active))
           for f in forms):
        return None
    return dict(cut_generic=True, rank_checked=True, hierarchies=nh,
                rank_forms=len(forms))


def coefficient_rewrite(B, D, g, p, start_base=2, signs=None, certify=True):
    """Find a certified endpoint and return a coefficient-preserving rewrite.

    The loop is finite: all strict descent paths have depth at most |p|;
    their forbidden pulled-back forms are finite and nonzero. Along the
    power curve each becomes a nonzero polynomial in the integer base.
    Checking just the realized path avoids enumerating the whole tree.
    """
    signs = signs or (1,) * len(B)
    assert all(x in (-1, 1) for x in signs)
    base = start_base
    rejected = 0
    while True:
        a = tuple(signs[i] * base**i for i in range(len(B)))
        result = raw_descent(B, g, p, a)
        if result is not None:
            good = True
            for state in result['states']:
                cert = certify_endpoint(state['B'], D, state['g'],
                                         state['p'], state['a'], certify)
                if cert is None:
                    good = False
                    break
                state['genericity'] = cert
            if good:
                result.update(D=tuple(D), initial_base=base,
                              rejected_bases=rejected,
                              rank_certified=bool(certify))
                return result
        base += 1
        rejected += 1


def evaluate_rewrite(rewrite):
    """Evaluate only the terminal Q algebra, never an intermediate coefficient."""
    if rewrite['status'] == 'zero':
        return dict(coefficient=0, terminal_algebra=None)
    from quiver_polynomial_staircase import polynomial_coefficient_algebra
    last = rewrite['states'][-1]
    algebra = polynomial_coefficient_algebra(last['B'], rewrite['D'],
                                            last['g'], last['p'],
                                            row_exponents=last['a'])
    return dict(coefficient=algebra['coefficient'], terminal_algebra=algebra)
