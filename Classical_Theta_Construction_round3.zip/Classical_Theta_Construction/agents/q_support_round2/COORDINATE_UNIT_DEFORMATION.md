# Coordinate-dependent unit deformations of the positive factor

2026-11-13. This is the finite-flat step needed by the complementary-Q
construction. It is proved afresh for units depending on the configuration;
constancy for independent constant targets alone would not imply it.

## Setup and conclusion

Let `Gamma_v` be the primitive framed Gale rows. Fix a rank-generic and
cut-generic endpoint `a`, so the full independent-target valuation window
has been proved. Let `G` be a finite product of clone-permutation groups.

On a positive coordinate polydisc containing the selected factor, suppose
`h_v(x,s)` are analytic units, equivariant under `G`, with

\[
\operatorname{val}h_v(x,s)=0
\]

uniformly for `s` in a closed unit polydisc. They must be defined on the
entire slightly enlarged coordinate affinoid used below, not merely at the
solutions. Then the family of positive solutions of

\[
\Gamma_v(x)=q_vT^{-a_v}h_v(x,s)                         \tag{1}
\]

over a sufficiently small full target polyannulus `q` is finite flat. On
the clone-invariant target slice, every `G`-isotypic multiplicity is
constant as `s` varies in the connected unit polydisc. Nonreduced fibers
are included.

## Proof

The valuations of (1) are exactly the original Gale valuation equations
with effective row parameter `a_v-val(q_v)`. The coordinate-dependent
units contribute zero. Hence the same positive lower bounds on coordinates
and the same upper bounds on inverse actual-arrow forms hold uniformly in
`q,s` and in all valued extensions.

Choose coordinate bounds strictly wider than those window bounds and
adjoin inverse actual-arrow variables. Impose (1) in the resulting
relative Tate algebra over the target polyannulus times the `s` polydisc.
All generator bounds are strict at every point. The affinoid morphism has
empty relative boundary and is finite, by the same precise analytic
criterion used in `../gale_boundary_round2/AFFINOID_FINITE_FLAT_BRIDGE.md`.

For flatness, solve (1) for the **independent target coordinates**:

\[
q_v=T^{a_v}\Gamma_v(x)/h_v(x,s).                       \tag{2}
\]

The source is an analytic domain in the graph of this map. The graph is
isomorphic to the open configuration space times the `s` polydisc, so it
is smooth and has the same dimension as the target. In particular its
local rings are Cohen--Macaulay. The target is regular; the finite fibers
have dimension zero. Miracle flatness gives finite flatness. This argument
does not require the `h_v` to be independent of `x`, nor does it infer
smoothness from the row equations at a fixed target.

Restrict to the target slice `q_v=q_color(v)`. The permutation action now
acts fiberwise, and finite flatness is preserved by this base change.
Characteristic zero supplies the idempotent projector for any prescribed
representation. Its image is a finite projective direct summand. Its rank
is constant on the connected parameter base. This proves the isotypic
statement directly; no assumption of simple roots is used.

## The units required for complementary polynomials

Let

\[
F_k=T^{a_k}A_k-\epsilon_k E_k^0,\qquad a_k>0,
\]

where `A_k,E_k^0` are monic products of `z` and the other distinguished
polynomials. Put `e=deg E_k^0`. Formal Weierstrass preparation at the origin
gives

\[
F_k=-\epsilon_k u_k(z)P_k(z),\qquad \deg P_k=e,
\quad u_k\in1+T^{a_k}\mathbb Q[[T,c_{j,l}:j\ne k]][[z]]. \tag{3}
\]

The congruence for the unit follows by uniqueness of preparation after
reduction modulo `T^{a_k}`: there the polynomial is exactly the monic
polynomial `E_k^0` times `-epsilon_k`. All formal coefficients are bounded
for the T-adic norm on rational constants. Consequently (3) converges
uniformly whenever the other polynomial coefficients and `z` have positive
valuation bounded below. The coefficient bounds supplied by a positive
root-coordinate bound are sufficient. Its unit differs from 1 by a
function of valuation at least `a_k` on the entire enlarged positive
coordinate polydisc.

For `a_k<0`, the analogous normalization is

\[
F_k=A_k-\epsilon_kT^{-a_k}E_k^0=u_kP_k,\qquad
\deg P_k=\deg A_k,\quad u_k\in1+T^{-a_k}\mathbb Q[[T,c]][[z]].
                                                               \tag{4}
\]

Set `u_{k,s}=1+s(u_k-1)` for `|s|<=1`. Every positive or negative integer
power of this unit is analytic, invertible, and of valuation zero on the
same domain. Evaluating it at the clone coordinate gives precisely the
equivariant units needed by the new row equations. Thus (1)--(2) apply
to the whole homotopy from the coupled units to constant targets.

Constant phase factors `+1` or `-1` are handled by the already finite flat
full unit-target annulus, rather than by a linear homotopy that might pass
through zero.

## Analytic remainder algebra and limitations

The adjugate-Vandermonde remainder lemma extends to the completed rings:
division by each distinguished monic `Q_i` converges in the coefficient
adic topology, and the alternating projection is continuous and exact.
Thus the sign summand of the clone family is the completed monic-Q
remainder module. The equality of ranks above is consequently an equality
of the lengths of the selected Q factors.

This proves invariance of the finite selected length, and an actual
isomorphism to a Q system with the displayed coupled units when supplied
by a complementary-factor map. It does **not** assert that the special
algebras for all constant and coupled units are isomorphic. Flatness alone
would not justify that stronger conclusion.

The standard analytic and commutative-algebra references are the same
primary statements checked in the finite-flat bridge: Temkin, *Introduction
to Berkovich analytic spaces* (2010), Definition 3.4.9 and Fact 3.4.11(iv);
Stacks Project, tag 00R4. The additional point here is the graph description
(2) for configuration-dependent units, together with their uniform domain.
