"""Exact family check of compressed carriers, including valued normalizations.

This tests the non-unit constant coefficients introduced by compression,
ancestor extraction, sparse bounds, and reconstruction for all positive theta
components of a finite compressed polynomial. It is not a proof of any general
reachability conjecture and does not count a shared coefficient engine as an
independent theta formula.
"""
from pathlib import Path
from math import gcd, lcm
import json, random, time
from compressed_carrier import *


def run():
    rng=random.Random(261114)
    records=[]; started=time.time()
    for n,count in [(2,5),(3,10),(4,6),(5,3)]:
        for case in range(count):
            D=[rng.choice([1,2,3]) for _ in range(n)]
            B=[[0]*n for _ in range(n)]
            for i in range(n):
                for j in range(i+1,n):
                    skew=rng.choice([-1,0,1])*lcm(D[i],D[j])
                    B[i][j]=skew//D[i]; B[j][i]=-skew//D[j]
            variables=PrincipalMutations(B).variables_through_depth(1)
            power=4 if n<=3 else 3
            U=universal_carrier(variables,n,power)
            oracle=Coefficients(B,D)
            summands=0; offleading=0; nonmonomial=0; coefficient_checks=0
            ancestor_checks=0; maximum_multiplicity=0; dilated_bounds=0
            for h,H in U.items():
                C,_=extract_on_ancestors(B,h,H,list(H),oracle)
                recovered={}
                for q,c in C.items():
                    summands+=1; offleading+=any(q)
                    maximum_multiplicity=max(maximum_multiplicity,c)
                    g=shifted(B,h,q)
                    bound=dilated_bound(H,q,1,c)
                    F=oracle.on_support(g,bound)
                    nonmonomial+=len(F)>1
                    for p,a in F.items():
                        assert a<=bound[p]
                        r=add(p,q)
                        recovered[r]=recovered.get(r,0)+c*a
                        coefficient_checks+=1
                    prefix,_=extract_on_ancestors(B,h,H,[q],oracle)
                    assert prefix.get(q)==c
                    ancestor_checks+=1
                    d=0
                    for a in g:d=gcd(d,a)
                    if d>1:
                        primitive=tuple(a//d for a in g)
                        smallbound=dilated_bound(H,q,d,c)
                        small=oracle.on_support(primitive,smallbound)
                        for p,a in small.items():
                            assert a<=smallbound[p]
                            assert a<=F.get(tuple(d*x for x in p),0)
                        dilated_bounds+=1
                assert recovered==H
            record={"B":B,"D":D,"rank":n,"power":power,
                "variables":len(variables),
                "products_compressed":comb(len(variables)+power,power),
                "homogeneous_components":len(U),"Laurent_terms":sum(map(len,U.values())),
                "theta_summands":summands,"off_leading_summands":offleading,
                "nonmonomial_theta_summands":nonmonomial,
                "coefficient_bound_checks":coefficient_checks,
                "ancestor_extraction_checks":ancestor_checks,
                "dilated_bounds_checked":dilated_bounds,
                "maximum_theta_multiplicity":maximum_multiplicity,"status":"PASS"}
            records.append(record)
            print(json.dumps({k:record[k] for k in ["rank","power","theta_summands","off_leading_summands","status"]}),flush=True)
    result={"status":"PASS","seconds":time.time()-started,"cases":len(records),
        "scope":"Exact compressed-product reconstruction and normalization checks; no general coverage conclusion inferred from cases.",
        "totals":{key:sum(r[key] for r in records) for key in
            ["products_compressed","Laurent_terms","theta_summands","off_leading_summands",
             "nonmonomial_theta_summands","coefficient_bound_checks","ancestor_extraction_checks","dilated_bounds_checked"]},
        "records":records}
    Path(__file__).with_name('compression_family_results.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))

if __name__=='__main__':run()
