# Compressed positive carriers and their exact termination domain

Classical cluster algebras, principal coefficients, inverted frozen variables.
Prepared 2026-11-13 UTC. This note extends the executable construction in
`../finite_envelope_review/OFF_LEADING_POSITIVE_CARRIER.md`.

## 1. What is established

The complete finite Laurent polynomial of a theta function can be extracted from
a positive cluster-product carrier. We implement a compressed version which tests
all products up to a fixed length simultaneously and which also allows a positive
integer multiple of the desired label as its detected theta summand.

The exact successful-search domain is the **smallest saturated set of integral
labels containing the cluster monomials and closed under every nonzero theta
product coefficient**. This admits a geometric description: after rational
scaling, it is the finite-step rational broken-line conical hull of the cluster
complex. The geometric identification is a direct consequence of Cheung–Magee–
Nájera Chávez, Theorem 4.10 and Proposition 5.4; it is not a new convexity theorem.
No equality with the entire regular theta set is claimed.

The operational gain is an exact finite output procedure from the seed and a
label on this domain, using the existing prescribed-degree theta algorithm.
Positivity, saturation, and the underlying support domination are established
GHKK mechanisms. This is a constructive consequence of them, not a new
positivity result and not an intrinsic replacement for scattering objects.

## 2. A single polynomial tests all short products

Write the discovered cluster variables as

\[
X_j=x^{v_j}F_j(z),\qquad z_i=y_i x^{B e_i},\qquad
F_j\in\mathbb N[z],\quad F_j(0)=1.
\]

For a positive integer \(m\), form

\[
U_m=(1+X_1+\cdots+X_s)^m
   =\sum_h x^h H_{m,h}(z).
\tag{2.1}
\]

The second equality groups terms by the principal grading
\(\deg x_i=e_i,\deg y_j=-B e_j\). Every product of at most \(m\) of the
\(X_j\)'s occurs with a positive integer coefficient in (2.1). Conversely every
summand is such a product. Thus a theta label occurs in \(U_m\) if and only if
it occurs in at least one product of length at most \(m\).

One can compute (2.1) by repeated sparse multiplication, merging equal
\((h,p)\). This avoids enumerating all multisets of factors. It does not assert a
polynomial-time bound: Laurent supports and mutation expressions can still grow
rapidly.

Each nonzero homogeneous component is a known finite positive sum of cluster
products. Hence it has a finite positive theta expansion

\[
H_{m,h}(z)=\sum_q c_{m,h}(q)z^q F_{h+Bq}(z),
\qquad c_{m,h}(q)\in\mathbb N.
\tag{2.2}
\]

Its constant coefficient need not equal one. Nevertheless, positivity and the
unit leading coefficient of theta functions give

\[
0\le c_{m,h}(q)\le [z^q]H_{m,h},
\qquad \operatorname{supp}c_{m,h}\subseteq\operatorname{supp}H_{m,h}.
\tag{2.3}
\]

For any desired finite set \(Q\) of candidate degrees, only the ancestor set

\[
J_Q=\{r\in\operatorname{supp}H_{m,h}:r\le q
          \text{ coordinatewise for some }q\in Q\}
\]

is needed. In increasing total degree, calculate

\[
c_{m,h}(q)=[z^q]H_{m,h}
 -\sum_{r<q}c_{m,h}(r)a_{h+Br}(q-r).
\tag{2.4}
\]

All terms outside \(J_Q\) are irrelevant to the requested coefficients. All
theta coefficients on the right are finite prescribed-degree computations.

## 3. Detecting a multiple of the desired label

Suppose a finite positive homogeneous carrier \(x^hH(z)\) has

\[
h+Bq=kg,\qquad k\in\mathbb Z_{>0},\qquad c(q)=c>0.
\tag{3.1}
\]

Its selected full principal theta label is \((kg,q)\). Frozen translation by
\(y^{-q}\) aligns it with \((kg,0)\). Positivity therefore gives

\[
c\,a_{kg}(r)\le [z^{q+r}]H \quad(r\ge0).
\tag{3.2}
\]

The positive broken-line scaling argument used in GHKK's saturation proof gives

\[
a_g(p)\le a_{kg}(kp).
\tag{3.3}
\]

For completeness: scale every exponent of a broken line by \(k\), retaining its
geometric image after reparametrization. At a bend whose contribution is
\([t^j]f(t)^a=b>0\), the scaled contribution is
\([t^{kj}]f(t)^{ka}\ge b^k\ge b\). Distinct underlying paths remain distinct.
Thus summing the scaled weights proves (3.3). It does not justify the stronger,
unused inequality \(a_{kg}(kp)\ge a_g(p)^k\).

Combining (3.2) and (3.3),

\[
\boxed{
\operatorname{supp}F_g\subseteq
 \{p\in\mathbb N^n:q+kp\in\operatorname{supp}H\},\qquad
a_g(p)\le\left\lfloor\frac{[z^{q+kp}]H}{c}\right\rfloor.
}
\tag{3.4}
\]

This is a complete finite support bound. Intersect all bounds found in a single
compressed carrier and compute the theta coefficients only on the resulting
finite set. The returned Laurent expression is complete; no empirical
stabilization of a sequence of truncations is used.

The implementation also permits optional pruning by the separately proved Gauss
divisor \(\gcd(g_i)/\gcd(g_i,p_j)\), but this arithmetic result is unnecessary
for the basic algorithm or its termination theorem.

## 4. Exact algebraic characterization of the search domain

Use the full principal lattice \(L=M^\circ\oplus N\). Let \(\Delta\) be the
labels of all global monomials, including frozen units. Let \(S\) be the union of
theta supports of all finite products of these global monomials. The empty
product is included. Define

\[
R=\{u\in L:\ ku\in S\text{ for some }k\in\mathbb Z_{>0}\}.
\tag{4.1}
\]

These are definitions of mathematical sets. They do not assume that a complete
list of cluster variables or regular theta labels is available.

**Proposition 4.1.** \(S\) is intrinsically closed under addition: if
\(u,v\in S\) and \(\alpha(u,v,w)>0\), then \(w\in S\).

**Proof.** Choose products \(P,Q\) with positive coefficients at \(\theta_u\)
and \(\theta_v\). Associativity and nonnegative structure constants imply that
the coefficient of \(\theta_w\) in \(PQ\) is at least
\([\theta_u]P[\theta_v]Q\alpha(u,v,w)>0\). The product \(PQ\) is again a
cluster product. This also proves ordinary additive closure, since the
coefficient at \(\theta_{u+v}\) is one. \(\square\)

**Scaling fact.** If \(\alpha(u,v,w)>0\), then
\(\alpha(ku,kv,kw)>0\) for each positive integer \(k\).

**Proof.** Use the balanced pair of broken lines defining a positive summand of
\(\alpha(u,v,w)\). Scale the labels, all segment exponents, and the geometry by
\(k\). The scattering diagram is conical. All scaled local bend coefficients
are positive by the same elementary coefficient argument as in (3.3). The
scaled pair is balanced at \(kw\) and contributes positively. \(\square\)

**Proposition 4.2.** \(R\) is the smallest saturated, intrinsically
addition-closed subset of \(L\) containing \(\Delta\).

**Proof.** Saturation follows directly from (4.1). If \(u,v\in R\), choose a
common positive integer \(k\) with \(ku,kv\in S\); this is possible by additive
closure of \(S\). Whenever \(\alpha(u,v,w)>0\), the scaling fact and
Proposition 4.1 give \(kw\in S\), so \(w\in R\). Every saturated,
intrinsically addition-closed set containing \(\Delta\) contains the support
of every product of its elements, hence contains \(S\) and then \(R\).
\(\square\)

**Theorem 4.3.** Fair enumeration of mutation depth and compressed-carrier
exponent, with the test (3.1), halts **if and only if** the desired full label
\((g,0)\) lies in \(R\).

**Proof.** Every successful test gives a product component \((kg,q)\); the
frozen unit \(y^{-q}\) gives \((kg,0)\in S\). Conversely, if
\((kg,0)\in S\), choose a finite product witnessing this. Remove its frozen
units, leaving a finite product of cluster variables whose expansion has some
\((kg,q)\), with \(q\ge0\). All of its factors occur at a finite mutation
depth and its length is finite. For a sufficiently large stage, it occurs in
the compressed carrier with a positive coefficient, so (3.1) is detected.
\(\square\)

GHKK's positivity and saturation give \(R\subseteq\Theta\). If
\(\theta_g\) belongs to the ordinary cluster algebra over the inverted frozen
ring, then a finite expression in cluster products shows \((g,0)\in S\), by
comparing its full theta coefficient. Thus the algorithm still halts on every
theta function in that ordinary algebra. The rational leading-carrier domain
is contained in \(R\). A strict enlargement beyond the union of all rational
leading carriers has **not** been proved here.

## 5. Geometric identification using CMN

Let

\[
R_{\mathbb Q}=\mathbb Q_{>0}\,S\subseteq L_{\mathbb Q}.
\]

Then \(R=R_{\mathbb Q}\cap L\). Define the *finite rational broken-line
conical hull* of \(\Delta\) as follows. Start with rational positive multiples
of cluster-monomial labels and the origin. Repeatedly add rational positive
multiples and rational points on broken-line segments with endpoints already
present. Take the union over all finite iterations. This definition deliberately
does not add arbitrary topological limits.

**Proposition 5.1.** \(R_{\mathbb Q}\) equals this finite rational broken-line
conical hull.

**Proof.** The two required translations are established in CMN:

1. Theorem 4.10: a positive balanced pair with initial labels \(p,q\) and final
   label \(r\), together with positive integers \(a,b\), gives a broken-line
   segment from \(p/a\) to \(q/b\) passing through \(r/(a+b)\).
2. Proposition 5.4: a broken-line segment with rational endpoints and a rational
   interior point, after clearing finitely many denominators, gives a positive
   balanced pair whose initial labels are positive integer multiples of the
   endpoints and whose final label is a positive integer multiple of the
   chosen interior point.

For the first inclusion, a theta component of a cluster product is obtained by
finitely many binary products. Apply (1) at each binary product and allow
rational conical scaling; every resulting label lies in the finite hull.

Conversely, suppose two rational points are in \(R_{\mathbb Q}\). Apply (2) to
a segment between them and its desired rational point. Multiplying the entire
configuration by one sufficiently divisible positive integer puts the two
initial labels in \(S\). The scaling fact preserves positivity of the final
coefficient, and Proposition 4.1 then puts the scaled final label in \(S\).
The original rational point is in \(R_{\mathbb Q}\). This proves closure under
each finite hull operation and completes the induction. \(\square\)

This proposition is an effective interpretation of CMN's constructions. Their
published positive-set theorem concerns **closed** subsets of the real
tropicalization. It does not justify replacing the finite rational hull by its
topological closure or identifying that hull with all regular theta labels.
The actual general gap for the present algorithm is precisely whether all
regular labels can be obtained by these finite hull operations, or whether a
different finite-support witness is needed for some of them.

## 6. A coefficient-ring observation about leading carriers

Let \(A_{\rm pol}\) mean the algebra generated by the same cluster variables
over \(\mathbb Z[y_1,\ldots,y_n]\), with principal frozen variables **not**
inverted. If \(\theta_g\in A_{\rm pol}\), then \(g\) is an integral sum of
cluster-variable \(g\)-vectors, so a leading carrier already exists.

Indeed, take a finite polynomial expression in cluster variables and frozen
variables for \(\theta_g\), and take its homogeneous principal-degree \(g\)
part. A term \(y^bP\), with \(b\ge0\), whose product \(P\) has leading
weight \(h\), satisfies \(h-Bb=g\) and contributes
\(x^g z^b H_P(z)\). Since \(F_g(0)=1\), at least one contributing term must
have \(b=0\), hence \(h=g\). Its factor labels sum to \(g\).

This observation limits a possible novelty claim: off-leading detection is
especially relevant to coefficient inversions and practical search efficiency;
it is not a proven strict extension of the global leading-carrier domain in
every coefficient convention.

## 7. Implementation and validation

`compressed_carrier.py` contains exact principal mutations, sparse compressed
powers, target-ray detection, ancestor-only triangular extraction, intersection
of all found sparse bounds, and complete Laurent output. The mutation engine is
imported from the first carrier implementation rather than duplicated.

The initial checks compare compressed powers with an independent enumeration
of commutative products and multinomial coefficients. They cover symmetric and
valued exchange matrices and include non-leading and dilated witnesses. The
record `compressed_carrier_checks.json` gives all exact coefficients and the
complete output certificates. Failure to find a carrier by an optional finite
stage is returned as an incomplete search, never as a negative decision.

## 8. Sources and novelty boundary

- Gross–Hacking–Keel–Kontsevich, *Canonical bases for cluster algebras*,
  Definition-Lemma 6.2, Proposition 6.4, Theorem 7.5.
  https://arxiv.org/abs/1411.1394 and
  https://paulhacking.github.io/canonicalbases.pdf . The support-domination,
  product closure, and saturation mechanisms are already there.
- Cheung–Magee–Nájera Chávez, *Compactifications of cluster varieties and
  convexity*, arXiv:1912.13052v2 (2021), Theorem 4.10, Proposition 5.4,
  Theorem 6.1. https://arxiv.org/abs/1912.13052 . The rational-hull interpretation
  above is a direct corollary of these constructions, not a new convexity
  principle.
- SageMath 10.10 official reference, `theta_basis_F_polynomial`: the documented
  implementation uses the LLZ recursion and explicitly supports only rank two.
  https://doc.sagemath.org/html/en/reference/algebras/sage/algebras/cluster_algebra.html .
  This is a computational comparison only, not a mathematical priority claim.
- Davison–Mandel, arXiv:1910.12915v3, Theorem 1.2: ordinary, middle, upper, and
  canonical algebras are kept distinct. The quantum theorem is not used as an
  input here. Its statement does not establish that the ordinary algebra is
  always spanned by a subset of theta functions.

No Li–Pan conclusion is used.
