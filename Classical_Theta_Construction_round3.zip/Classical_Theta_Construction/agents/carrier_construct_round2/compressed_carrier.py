"""Finite theta output from compressed positive cluster-product carriers.

At a finite mutation depth, U=(1+sum X_i)^m simultaneously contains every
product of the discovered cluster variables of length at most m.  We group U
by the principal grading and only extract structure coefficients below target
degrees.  A target ray k*g may be used, giving a finite sparse bound for g by
positive broken-line dilation.  No claim of termination for every regular
theta label is built into this implementation.

The coefficient engine and exact mutation engine are prior work in the same
research package.  No floating point arithmetic enters the certificates.
"""
from functools import lru_cache
from itertools import combinations_with_replacement
from math import gcd, comb, factorial
from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "agents/finite_envelope_review"))
from positive_carrier import (PrincipalMutations, Coefficients, shifted, add,
                              sub, le, sparse_mul, sparse_terms, product_data,
                              extract_theta_expansion)


def add_polynomial(out, F, scale=1):
    for p, a in F.items():
        out[p] = out.get(p, 0) + scale*a


def graded_mul(A, C):
    """Multiply sums x^h H_h(z), preserving the homogeneous principal weight."""
    out = {}
    for h, F in A.items():
        for k, H in C.items():
            add_polynomial(out.setdefault(add(h, k), {}), sparse_mul(F, H))
    return out


def universal_carrier(variables, n, exponent):
    """Return all homogeneous components of (1+sum(variables))^exponent."""
    zero = (0,)*n
    A = {zero: {zero: 1}}
    for v in variables:
        add_polynomial(A.setdefault(v.g, {}), v.F)
    U = {zero: {zero: 1}}
    for _ in range(exponent):
        U = graded_mul(U, A)
    return U


def integral_ray_multiplier(u, g):
    """Return k>=1 if u=k*g, else None; for g=0 use k=1 only."""
    nonzero = next((i for i, a in enumerate(g) if a), None)
    if nonzero is None:
        return 1 if not any(u) else None
    k, remainder = divmod(u[nonzero], g[nonzero])
    if remainder or k < 1:
        return None
    return k if all(a == k*b for a, b in zip(u, g)) else None


def target_candidates(B, g, U, allow_dilation=True):
    out = {}
    for h, H in U.items():
        qs = []
        for q in H:
            u = shifted(B, h, q)
            k = integral_ray_multiplier(u, g)
            if k and (allow_dilation or k == 1):
                qs.append((q, k))
        if qs:
            out[h] = qs
    return out


def extract_on_ancestors(B, h, H, target_degrees, oracle):
    """Only c(r) with r <= some requested q are needed for c(q)."""
    J = [r for r in H if any(le(r, q) for q in target_degrees)]
    C = {}
    for q in sorted(J, key=lambda p: (sum(p), p)):
        value = H[q] - sum(c*oracle.at(shifted(B, h, r), sub(q, r))
                           for r, c in C.items() if le(r, q))
        assert value >= 0, ("negative positive-product component", h, q, value)
        if value:
            C[q] = value
    return C, len(J)


def dilated_bound(H, q, k, multiplicity):
    """Bounds a_g(p) <= floor(H[q+k*p]/multiplicity)."""
    out = {}
    for r, coefficient in H.items():
        d = sub(r, q)
        if all(a >= 0 and a % k == 0 for a in d):
            p = tuple(a//k for a in d)
            upper = coefficient//multiplicity
            if upper:
                out[p] = upper
    return out


def combine_bounds(bounds):
    assert bounds
    out = bounds[0].copy()
    for bound in bounds[1:]:
        out = {p: min(a, bound[p]) for p, a in out.items() if p in bound}
    return out


def known_gauss_divisor(g, p):
    """Optional sharpening using the separately proved theta Gauss theorem."""
    h = 0
    for a in g:
        h = gcd(h, a)
    if h == 0:
        return 1
    d = h
    for a in p:
        d = gcd(d, a)
    return h//d


def certificate_from_compressed(B, D, g, variables, exponent,
                                allow_dilation=True, gauss_pruning=False,
                                U=None, oracle=None):
    """Return complete theta polynomial with a positive finite certificate."""
    g = tuple(g)
    U = universal_carrier(variables, len(B), exponent) if U is None else U
    oracle = Coefficients(B, D) if oracle is None else oracle
    candidates = target_candidates(B, g, U, allow_dilation)
    witnesses, bounds = [], []
    inspected = 0
    for h, qs in candidates.items():
        H = U[h]
        C, count = extract_on_ancestors(B, h, H, [q for q, _ in qs], oracle)
        inspected += count
        for q, k in qs:
            c = C.get(q, 0)
            if c:
                bound = dilated_bound(H, q, k, c)
                bounds.append(bound)
                witnesses.append({"homogeneous_weight_h": list(h),
                    "root_degree_q": list(q), "dilation_k": k,
                    "theta_multiplicity": c,
                    "individual_bound_size": len(bound),
                    "homogeneous_carrier_F": sparse_terms(H),
                    "ancestor_theta_coefficients": sparse_terms(C)})
    if not bounds:
        return None
    bound = combine_bounds(bounds)
    excluded_by_gauss = []
    if gauss_pruning:
        for p in list(bound):
            divisor = known_gauss_divisor(g, p)
            if bound[p] < divisor:
                excluded_by_gauss.append({"p": list(p), "upper": bound.pop(p),
                                          "divisor": divisor})
    F = oracle.on_support(g, bound)
    assert F.get((0,)*len(B)) == 1
    assert all(0 < a <= bound[p] for p, a in F.items())
    return {"status": "complete by compressed positive carrier", "g": list(g),
        "universal_carrier_exponent": exponent,
        "generator_certificates": [v.certificate() for v in variables],
        "universal_carrier_homogeneous_components": len(U),
        "universal_carrier_laurent_terms": sum(len(H) for H in U.values()),
        "candidate_components": len(candidates),
        "ancestor_degrees_inspected": inspected,
        "witnesses": witnesses, "sparse_upper_bounds": sparse_terms(bound),
        "gauss_pruning_used": gauss_pruning,
        "excluded_by_gauss": excluded_by_gauss,
        "theta_F": sparse_terms(F),
        "theta_Laurent": [{"x_exponent": list(shifted(B, g, p)),
                           "y_exponent": list(p), "coefficient": a}
                          for p, a in sorted(F.items(), key=lambda pc:(sum(pc[0]),pc[0]))],
        "termination_domain": "saturated positive-component closure of cluster labels"}


def search(B, D, target, max_stage=None, allow_dilation=True, gauss_pruning=False):
    """Fair discovery; a stage cap never proves absence of a later carrier."""
    mutation = PrincipalMutations(B)
    oracle = Coefficients(B, D)
    stage = 0
    while max_stage is None or stage <= max_stage:
        variables = mutation.variables_through_depth(stage)
        ans = certificate_from_compressed(B, D, target, variables, stage,
            allow_dilation=allow_dilation, gauss_pruning=gauss_pruning, oracle=oracle)
        if ans is not None:
            ans["discovery_stage"] = stage
            return ans
        stage += 1
    return {"status": "stage limit reached; no negative conclusion", "max_stage": max_stage}


def check_compression(B, depth, exponent):
    """Independent multinomial enumeration vs incremental compressed power."""
    variables = PrincipalMutations(B).variables_through_depth(depth)
    actual = universal_carrier(variables, len(B), exponent)
    expected = {}
    monomials = 0
    for size in range(exponent+1):
        for ids in combinations_with_replacement(range(len(variables)), size):
            factors = [variables[i] for i in ids]
            h, H = product_data(factors, len(B))
            weight = factorial(exponent)//factorial(exponent-size)
            for i in set(ids):
                weight //= factorial(ids.count(i))
            add_polynomial(expected.setdefault(h, {}), H, weight)
            monomials += 1
    assert expected == actual
    return {"B": B, "depth": depth, "exponent": exponent,
            "variables": len(variables), "products_simultaneously_represented": monomials,
            "compressed_components": len(actual),
            "compressed_laurent_terms": sum(len(H) for H in actual.values())}


def run_checks():
    start = time.time()
    cases = [
        ([[0,2],[-2,0]], [1,1], 2, 3, (-1,1)),
        ([[0,3],[-2,0]], [2,3], 1, 3, (-1,1)),
        ([[0,1,0],[-1,0,1],[0,-1,0]], [1,1,1], 2, 2, (-1,0,1)),
        ([[0,2,-2],[-2,0,2],[2,-2,0]], [1,1,1], 1, 3, (1,1,1)),
        ([[0,2,1],[-1,0,1],[-1,-2,0]], [1,2,1], 1, 2, (-1,0,1)),
    ]
    rows, certificates = [], []
    for B, D, depth, exponent, target in cases:
        row = check_compression(B, depth, exponent)
        variables = PrincipalMutations(B).variables_through_depth(depth)
        certificate = certificate_from_compressed(B,D,target,variables,exponent)
        row["target"] = list(target)
        row["status"] = certificate["status"] if certificate else "no witness at this finite stage"
        if certificate:
            row["witness_count"] = len(certificate["witnesses"])
            row["theta_terms"] = len(certificate["theta_F"])
            row["off_leading_witnesses"] = sum(any(w["root_degree_q"]) for w in certificate["witnesses"])
            row["dilated_witnesses"] = sum(w["dilation_k"]>1 for w in certificate["witnesses"])
            row["ancestor_degrees_inspected"] = certificate["ancestor_degrees_inspected"]
            certificates.append(certificate)
        rows.append(row)
    result = {"status":"PASS", "seconds":time.time()-start,
              "checks":rows, "certificates":certificates,
              "scope":"Finite implementation checks; general reachability and termination are proved separately."}
    Path(__file__).with_name("compressed_carrier_checks.json").write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!="certificates"},indent=2))


if __name__ == "__main__":
    run_checks()
