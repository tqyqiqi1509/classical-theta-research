# Literature and route record: compressed positive carriers

Branch started 2026-11-13 approximately 18:13 UTC. Classical only.

## Literature audit

| Source | Material inspected | Result of scrutiny | Use |
|---|---|---|---|
| GHKK, author PDF of *Canonical bases for cluster algebras* | Definitions 7.2–7.4 and complete proof of Theorem 7.5; surrounding ordinary/middle/upper statements | Finite positive products, regularity of every nonzero component, additive closure, and saturation are explicit established results. | Used. The carrier domination is a constructive consequence, not new positivity. |
| Cheung–Magee–Nájera Chávez, arXiv:1912.13052v2 (2021) | Theorem 4.10, Proposition 5.4, the proof of Proposition 5.4 including Lemmas 5.2–5.3 and denominator clearing, Theorem 6.1 | Their two constructions identify positive product outputs with rational interior points of broken-line segments after scaling. No closure operation is needed for each finite construction. | Used to identify the exact rational carrier domain. The geometric identification is a direct corollary. |
| Same CMN paper, Remark 6.2 | Entire remark | Initial-wall-only testing of a convex set containing zero is stated for dimension two / corank-two quotients or fibers. It is not a high-rank finite test. | Not used as a general certificate. No error attributed to the paper. |
| SageMath 10.10 official cluster-algebra reference | `theta_basis_F_polynomial`, `theta_basis_element`, `theta_basis_decomposition`, `upper_bound` | Documented theta F-polynomial algorithm explicitly uses LLZ rank-two recursion and raises `NotImplementedError` above rank two. Upper-bound construction is also documented as unimplemented. | Used only as a current software comparison. Not a mathematical priority claim. |
| Davison–Mandel, arXiv:1910.12915v3 / published Inventiones article | Theorems 1.1–1.2 and the definitions of scattering atlas and the algebra inclusions | Atomicity is with respect to the scattering atlas. The ordinary algebra is included in middle, which is included in upper; this does not supply an arbitrary ordinary-algebra theta-subset basis theorem. | Not used in the classical proof. Prevents importing an absent coverage statement. |
| Akagi–Chen, arXiv:2603.16326v2, *Geometric structures of G-fans associated with rank 3 cluster-cyclic exchange matrices* | Official PDF downloaded; version/date, abstract, introduction, stated scope | Verified v2 dated 8 June 2026; studies rank-three cluster-cyclic G-fans and quadratic upper bounds. Full proofs not yet audited. | Not used. Specialized G-fan geometry would not by itself solve the general positive-component reachability problem. Marked **2026: unadopted, proof audit incomplete**, not marked false. |

Primary URLs:

- https://paulhacking.github.io/canonicalbases.pdf
- https://arxiv.org/abs/1912.13052 and https://arxiv.org/pdf/1912.13052
- https://doc.sagemath.org/html/en/reference/algebras/sage/algebras/cluster_algebra.html
- https://arxiv.org/html/1910.12915v3
- https://arxiv.org/pdf/2603.16326

Root-readable retrieved references: `turn187view0`, `turn188view0`, `turn188view2`
(CMN); `turn163view0`, `turn165view0` (Sage); `turn178view0`, `turn182view0`
(Davison–Mandel). These identifiers are tool receipts; use the actual URLs in
standalone documents. A parent agent should open a reference itself before using
it as a final-response citation.

## Routes explored

1. **Direct off-leading carrier implementation.** The previous reviewer had
   already completed `positive_carrier.py`. Running it passed reconstruction of
   6 products, 31 theta summands, 25 off-leading summands, 30 independent
   exchange-normal-form variables, and one singular mutable-label collision.
   No duplicate implementation was falsely counted as new work.
2. **Compression of all products at a finite search stage.** Successful. The
   single finite polynomial \((1+\sum X_i)^m\) has exactly the union of the
   theta supports of products of length at most \(m\). Principal grading merges
   terms, and ancestor-only extraction computes just the needed coefficients.
3. **Off-leading ray rather than a single label.** Successful. Detecting
   \(\theta_{kg}\) at \(q\) yields the sparse set
   \(\{p:q+kp\in\operatorname{supp}H\}\) for the entire \(\theta_g\).
   This uses established positive broken-line scaling. The new implementation
   searches such rays directly, without an additional unbounded enumeration of
   scale factors for each carrier.
4. **Exact closure description.** Successful. Define \(S\) as cluster-product
   theta supports and \(R=\operatorname{Sat}(S)\). Positive associativity makes
   \(S\) intrinsically closed; positive scaling of balanced broken-line pairs
   makes \(R\) intrinsically closed. It is the smallest saturated positive-
   component-closed set containing cluster monomials. The search halts exactly
   on \(R\).
5. **Geometric translation to a rational hull.** Successful as a direct CMN
   corollary. \(R_{\mathbb Q}\) is the finite-step rational broken-line conical
   hull. Topological boundary limits are not automatically finite witnesses.
6. **Identify this hull with all regular theta labels.** Not proved. The cited
   papers give regularity of reachable labels, not the reverse inclusion.
   No additional small examples were offered as a substitute for this missing
   general implication.
7. **Prove strict enlargement over every rational leading carrier.** Not proved.
   A useful coefficient-ring observation instead shows that theta membership in
   the algebra over non-inverted principal coefficient polynomials already
   forces a leading carrier, by taking the constant F-term in a homogeneous
   expression. Off-leading detection therefore cannot be advertised as a strict
   global enlargement without further work.
8. **Turn CMN initial-wall testing into an arbitrary-rank certificate.** Not used:
   the source explicitly restricts that remark to dimension two. The general
   rational-hull theorem remains useful and is the route adopted here.

## Exact computation record

- `compressed_carrier_checks.json`: compressed powers independently checked
  against enumeration of commutative products with multinomial coefficients;
  examples include valued matrices, off-leading witnesses, and dilated witnesses.
- `compression_family_results.json`: 24 seeded integral matrix cases of ranks
  2–5 with symmetrizers drawn from \(\{1,2,3\}\). These check the rank-independent
  code paths and valued normalization, not the unrestricted coverage theorem.
  Totals: **4,298** cluster products represented; **11,310** Laurent terms;
  **5,762** complete theta summands, including **2,600** off-leading and
  **3,083** nonmonomial summands; **11,844** coefficient bound checks;
  **5,762** ancestor extraction checks; **1,032** dilated carrier checks.
  All passed using exact integers. The theta reconstruction shares the existing
  prescribed-degree engine and is not represented as an independent theta
  formula.
- `wolfram_valued_carrier.json`: independent Wolfram Language exchange/F-normal-
  form calculations for a valued rank-three seed. All three mutation identities
  and the positive-product identity returned `True`; the mutable matrix has a
  one-dimensional kernel while the full principal root map has rank three.
  The initial Wolfram context call returned an internal tool error; the exact
  evaluator calls succeeded. The first residual output was visibly unsimplified,
  so the final call used expanded common denominators and explicit Boolean
  equality checks.

No Li–Pan conclusion or unreviewed 2026 theorem is used by this branch.
