# Sharp source faces and reduction to an arbitrary core

Classical principal coefficients, skew-symmetrizable exchange matrix.  Prepared
2026-11-13, during the fourth finite-support round.  These are explicit
consequences of audited mutation, freezing, and positivity.  They are not a
claim to a new general existence theorem for arbitrary finite theta functions.

## 1. Conventions and statement

Let `D B` be skew-symmetric, with positive integral diagonal `D`.  Write

\[
 \theta_g^B=x^g F_g^B(z),\qquad z_i=y_i x^{B e_i},
 \qquad F_g^B\in\mathbb Z_{\geq0}[[z_1,\ldots,z_n]],
 \quad [z^0]F_g^B=1.
\]

All claims below initially concern formal series.  Let `k` be a source in the
row convention `B_kj >= 0`, and put `J=[n] \ {k}`.  For a label `g`, define

\[
 t=[-g_k]_+,\qquad b_J=g_J+B_{Jk}t.
\]

Then:

\[
 \boxed{\deg_{z_k}F_g^B=t,\qquad
 [z_k^t]F_g^B=F_{b_J}^{B_{JJ}}.}                         \tag{1}
\]

In particular the degree in one variable is finite even when the full series
is not known to be finite.  More precisely, for every `p in N^J` and integer
`0 <= s <= t`,

\[
 0\le [z_k^s z_J^p]F_g^B
 \le {t\choose s}[z_J^p]F_{b_J}^{B_{JJ}}.                 \tag{2}
\]

Consequently,

\[
 \operatorname{pr}_J\operatorname{supp}F_g^B
   =\operatorname{supp}F_{b_J}^{B_{JJ}},                  \tag{3}
\]

and `F_g^B` is a finite polynomial if and only if `F_bJ^BJJ` is.  These
statements do not assume that the middle algebra equals the upper algebra,
that all core labels are finite, that a reddening sequence exists, or that a
potential has been chosen.

## 2. Proof of the top face, without an infinite substitution

Use extended principal exponents `(g,0)` and charge map `p=(B;I)`.  A mutation
at `k` has integral basis change `E`, whose `k`th column is
`-e_k+[-p e_k]_+`, and charge change `F`, whose `k`th row is
`-e_k^T+[B_k*]_+`.  The tropical label map in these coordinates is

\[
 m\longmapsto E\bigl(m+[m_k]_+p e_k\bigr).
\]

For a theta function at an endpoint `Q` in the initial positive chamber,
GHKK Proposition 3.6 transports broken lines bijectively and transports the
final exponent by the *positive endpoint linear piece*.  Subtracting the
transformed initial label from the transformed final exponent gives

\[
 a'_j=a_j\ (j\ne k),\qquad
 a'_k=-a_k+[-g_k]_++\sum_{j\ne k}[-B_{kj}]_+a_j.         \tag{4}
\]

This is a coefficient-preserving transformation of terms, not an equality of
uncontrolled infinite rational substitutions.  At a source, (4) is simply

\[
 a'_k=t-a_k,\qquad a'_J=a_J.                             \tag{5}
\]

Every target charge is nonnegative, hence `a_k <= t`.  The transformed mutable
label and endpoint satisfy

\[
 g'_J=b_J,\quad g'_k=-g_k,\qquad Q'_J=Q_J>0,
 \quad Q'_k=-Q_k<0.                                     \tag{6}
\]

The transformed frozen label may be nonzero when `g_k>0`; it is a fixed
monomial factor and does not change charge coefficients.  In the case
`g_k<=0` this extra frozen shift is zero.

By the freezing theorem, the zero-`k`-charge part of the target theta is the
theta function for the diagram with vertex `k` frozen.  Its mutable matrix is
`B_JJ`, and (6) says that its remaining endpoint is in the positive chamber.
Its charge coefficient series is therefore `F_bJ^BJJ`.  Equation (5) identifies
this zero face with the original top face, proving (1).  The constant
coefficient of the core series is one, so the maximum degree really is `t`.

For completeness, when `g_k>=0`, the degree bound already gives no `k` charge;
freezing in the original seed gives `F_g^B=F_gJ^BJJ`, consistent with (1).

The same argument can be formulated directly in the joint construction:
walls whose degree uses `k` are contained in the half-space `Q_k<=0`, since
new outgoing supports are joint minus nonnegative multiples of `p a` and
`(B a)_k>=0`.  This geometric observation is not needed as a separate proof
input here; the coefficient-preserving mutation formula supplies the cap.

## 3. Proof of the binomial majorant

The adjacent cluster variable at the source is

\[
 x'_k=x^{-e_k-B_{Jk}}(1+z_k).
\]

Here `-e_k-B_Jk` means the vector with `k` coordinate `-1` and `J` coordinates
`-B_Jk`.  In general this is **not** the theta function with label `-e_k`.

Set `b=g-t(-e_k-B_Jk)`.  Then `b_k=[g_k]_+>=0` and `b_J` is the label above.
The previous paragraph gives `F_b^B=F_bJ^BJJ`.  Strong theta positivity, applied
degree by degree to `(x'_k)^t theta_b`, gives

\[
 (1+z_k)^t F_{b_J}^{B_{JJ}}
   =F_g^B+\sum_{q>0}c_q z^q F_{g+Bq}^B,
 \qquad c_q\in\mathbb Z_{\geq0}.                       \tag{7}
\]

The leading term has coefficient one.  Original frozen charge positivity
forces all shifts `q` to be nonnegative.  Equation (7) is valid formally; at
each fixed charge it is a finite equality.  Taking coefficients proves (2).
The top-face equality gives one inclusion in (3), and (2) gives the other.
Finiteness in both directions follows immediately.

## 4. Acyclic source blocks over an arbitrary cyclic core

Suppose the vertices split into `I={i_1,...,i_r}` and `J`, with `B_IJ>=0` and
the order chosen so each `i_l` is a source after earlier `i` vertices are
deleted.  Put `H_ij=[-B_ij]_+` on `I` and define successively

\[
 t_{i_\ell}
 =\left[-g_{i_\ell}
       +\sum_{h<\ell}H_{i_\ell i_h}t_{i_h}\right]_+,
 \qquad b_J=g_J+B_{JI}t.                               \tag{8}
\]

Iterating (1) and (2) proves

\[
 [z_I^t]F_g^B=F_{b_J}^{B_{JJ}},\qquad
 [z_I^s z_J^p]F_g^B
 \le\left(\prod_{i\in I}{t_i\choose s_i}\right)
       [z_J^p]F_{b_J}^{B_{JJ}}.                         \tag{9}
\]

Every coordinate maximum on `I` is exactly `t_i`; all coefficients outside
`0<=s<=t` vanish.  This remains true with arbitrary cyclic `B_JJ`.

Thus the finite theta label set has the exact description

\[
 \Theta_B=\{g\in\mathbb Z^n:
              g_J+B_{JI}t(g_I)\in\Theta_{B_{JJ}}\}.     \tag{10}
\]

The map `(g_I,g_J) -> (g_I,g_J+B_JI t(g_I))` is an integral piecewise-linear
bijection, with explicit inverse obtained by subtraction.  Hence (10)
identifies the finite label set with `Z^I x Theta_BJJ`.  This is a statement
about the finite theta locus, not a claim that this locus is the whole lattice.

If the core polynomial has support `S`, the full polynomial can be recovered
by evaluating the general integer coefficient algorithm only at the finite
candidate set

\[
 \{(s,p):0\le s\le t,\ p\in S\}.                      \tag{11}
\]

The candidate count is `|S| product_i(t_i+1)`.  No equality of upper and
middle algebras enters this reduction.  The unknown finite-support problem
for a core with no eliminable vertices remains substantive.

## 5. Newton face retraction

When finite, let `P_g=Newt(F_g)` and `P_core=Newt(F_bJ)`.  Equations (3) and
(9) show

\[
 P_g\subseteq[0,t]\times P_{\rm core},\qquad
 P_g\cap\{s=t\}=\{t\}\times P_{\rm core},\qquad
 \operatorname{pr}_J P_g=P_{\rm core}.                  \tag{12}
\]

Thus the coordinate projection has the integral affine section `p -> (t,p)`
whose image is a face.  This determines all support directions with zero
`I` component from the core and gives an exact face, not merely an enclosing
box.  It does not determine the interior coefficients or the other faces.

## 6. Exact top multiplication coefficients

For a single source, take any finite list of labels `g^(1),...,g^(r)` and set
`t_i=[-g_k^(i)]_+`, `T=sum t_i`, `b^(i)_J=g^(i)_J+B_Jk t_i`, and
`s=sum g^(i)`.  Write

\[
 \prod_i\theta^B_{g^{(i)}}
   =\sum_{q\ge0}C^B_q\,y^q\theta^B_{s+Bq},
\qquad
 \prod_i\theta^{B_{JJ}}_{b^{(i)}_J}
   =\sum_{p\ge0}C^{\rm core}_p\,
      y_J^p\theta^{B_{JJ}}_{\sum_i b_J^{(i)}+B_{JJ}p}.
\]

For `p in N^J`, define

\[
 \kappa(p)=T-
       \left[-s_k-\sum_{j\in J}B_{kj}p_j\right]_+.
\]

Since `s_k>=-T` and `B_kj>=0`, this is an integer between zero and `T`.
Then

\[
 \boxed{C^B_{(\kappa(p),p)}=C^{\rm core}_p.}             \tag{13}
\]

All other nonzero full coefficients obey

\[
 q_k+[-(s+Bq)_k]_+\le T.                               \tag{14}
\]

To prove this, take the coefficient of `z_k^T` in the positive F-series
expansion of the full product.  The left side becomes the product of the
core top faces.  An output `q` reaches this degree precisely when equality
holds in (14), forcing `q_k=kappa(q_J)`.  For such an output its top-face label
is

\[
 (s+Bq)_J+B_{Jk}[-(s+Bq)_k]_+
 =\sum_i b_J^{(i)}+B_{JJ}q_J.
\]

Pointed triangular independence in the core proves (13).  The argument is
coefficientwise and does not require every theta in sight to be Laurent
finite.  Repeating the one-source construction gives the corresponding
top-face coefficient lift for an acyclic source block; reconstruct the
removed output charges in reverse deletion order.

## 7. Relation to prior work and exact validation

The proof inputs are GHKK, *Canonical bases for cluster algebras*,
arXiv:1411.1394v2, Proposition 3.6 (broken-line mutation), and Qin,
*Applications of the freezing operators on cluster algebras*,
arXiv:2407.03186v1, Theorem 5.2 (zero-charge freezing).  Both were read from
their primary full texts.  Positivity is the established classical theta
positivity theorem, including skew-symmetrizable seed data.

Our own Hexagon 2610.00201v3, Section 9.10, already gives one-way unfreezing,
an inclusion in a core-support box, and transfer of all-label finiteness.
The old package's `ACYCLIC_CREATION_CAPS.md` already has coefficient caps
when the entire matrix is acyclic.  Those facts are not new here.  The
explicit increments recorded here are the sharp recursive maximum, exact
top-face/projection identity over an arbitrary core, label-by-label
if-and-only-if finiteness, and the top multiplication coefficient lift.
They are short consequences of established mutation/freezing machinery;
no claim of priority is made on the basis of not finding the exact display.

`source_face_checks.py` uses an independent incoming Schur coefficient engine
and triangular multiplication subtraction.  It tested 46 matrices of ranks
2 through 5, including cyclic cores and unequal symmetrizers, with 138 labels:
2,107 coefficient inequalities, 1,080 top-face equalities, 1,080 checks just
above the cap, 160 exact core/full multiplication coefficient equalities,
and 173 multiplication support inequalities all passed using exact integers.

## Primary URLs

- https://arxiv.org/html/1411.1394v2
- https://arxiv.org/html/2407.03186v1
- https://hexagonmath.org/2610.00201v3
- https://hexagonmath.org/api/v1/works/2610.00201v3/source?path=quantum_theta.tex

