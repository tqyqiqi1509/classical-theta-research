"""Exact checks of the source face, coefficient cap and top multiplication lift.

The coefficient oracle is the earlier incoming integer Schur recursion.  The
identities tested here are not built into that recursion.  All arithmetic is
integer; the tested cores include cyclic skew-symmetric and valued matrices.
"""
from pathlib import Path
from itertools import product
from math import comb, lcm
import sys, random, json, time

ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT / 'history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents'
sys.path.insert(0, str(OLD))
from incoming_recursion import IncomingSchur, box, le, sub

def add(a, b):
    return tuple(x+y for x,y in zip(a,b))

def prod_prefix(F, G, cap):
    H = {}
    for a, c in F.items():
        for b, d in G.items():
            p = add(a,b)
            if le(p,cap): H[p] = H.get(p,0) + c*d
    return H

def structure(R, gs, cap):
    zero = (0,)*len(cap)
    H = {zero:1}
    for g in gs:
        H = prod_prefix(H, R.theta_prefix(g, cap), cap)
    s = tuple(sum(g[i] for g in gs) for i in range(len(cap)))
    C = {}
    for p in box(cap):
        c = H.get(p,0)
        if not c: continue
        C[p] = c
        F = R.theta_prefix(R.shift(s,p), sub(cap,p))
        for q, d in F.items():
            pq = add(p,q)
            H[pq] = H.get(pq,0) - c*d
    assert not any(H.values())
    return C

def source_data(B,g):
    t = max(-g[0],0)
    return t, tuple(g[j]+B[j][0]*t for j in range(1,len(g)))

def matrix(rng,n,D):
    B = [[0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1,n):
            v = rng.randrange(0,3) if i==0 else rng.randrange(-2,3)
            s = lcm(D[i],D[j])*v
            B[i][j],B[j][i] = s//D[i],-s//D[j]
    return B

def run():
    start=time.time(); rng=random.Random(26111442)
    counts={'coefficient_checks':0,'top_face_checks':0,'zero_above_cap':0,
            'structure_lift_checks':0,'structure_cap_checks':0}
    cases=[]
    for n, reps in [(2,14),(3,14),(4,12),(5,6)]:
        for rep in range(reps):
            D=[1]*n if rep%2==0 else [rng.choice([1,2,3]) for _ in range(n)]
            B=matrix(rng,n,D); R=IncomingSchur(B,D)
            C=[row[1:] for row in B[1:]]; S=IncomingSchur(C,D[1:])
            ccap=(2,)*(n-1) if n<=3 else (1,)*(n-1)
            gs=[]
            for _ in range(3):
                g=(rng.randrange(-3,3),)+tuple(rng.randrange(-3,4) for _ in range(n-1))
                gs.append(g)
                t,b=source_data(B,g)
                cap=(t+1,)+ccap
                F=R.theta_prefix(g,cap); K=S.theta_prefix(b,ccap)
                for q in box(ccap):
                    a=K.get(q,0)
                    assert F.get((t,)+q,0)==a,('face',B,D,g,q,F.get((t,)+q),a)
                    counts['top_face_checks']+=1
                    for k in range(t+1):
                        v=F.get((k,)+q,0)
                        assert 0<=v<=comb(t,k)*a,('cap',B,D,g,k,q,v,a)
                        counts['coefficient_checks']+=1
                    assert not F.get((t+1,)+q,0),('above',B,D,g,q)
                    counts['zero_above_cap']+=1
            # One independent multi-factor triangular expansion per matrix.
            inp=gs[:2] if rep%3 else gs
            ts,bs=zip(*(source_data(B,g) for g in inp)); T=sum(ts)
            if T<=4 and n<=4:
                cp=(1,)*(n-1)
                core=structure(S,bs,cp)
                full=structure(R,inp,(T,)+cp)
                s=tuple(sum(g[i] for g in inp) for i in range(n))
                for q in box(cp):
                    r0=s[0]+sum(B[0][j]*q[j-1] for j in range(1,n))
                    k=T-max(-r0,0)
                    assert 0<=k<=T
                    assert full.get((k,)+q,0)==core.get(q,0),('structure',B,D,inp,q,k,full,core)
                    counts['structure_lift_checks']+=1
                for p,c in full.items():
                    assert c>=0
                    r=R.shift(s,p)
                    assert p[0]+max(-r[0],0)<=T
                    counts['structure_cap_checks']+=1
            cases.append({'rank':n,'B':B,'D':D,'labels':gs,'core_cap':ccap})
    return {'status':'PASS','counts':counts,'cases':cases,'seconds':time.time()-start}

if __name__=='__main__':
    result=run()
    out=Path(__file__).with_name('source_face_checks.json')
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
