# The source filtration on the finite theta algebra

This is an algebraic consequence of `SOURCE_FACE_AND_CORE_RETRACTION.md`.
It uses the maximum degree in the *original principal coefficient* `y_k`.
It is different from taking the minimum degree in the mutable variable `x_k`.
All statements are classical, and no equality with the upper algebra is
assumed.

## 1. Normalize the coefficient variables

Let `k` be a source, `J=[n]\{k}`, and set

\[
 X=x_k,\quad U=y_k,\quad Y_j=y_jX^{B_{kj}}\quad(j\in J).
\]

This is an invertible integral monomial change in the ambient Laurent ring.
The remaining root variables become

\[
 z_j=Y_jx_J^{B_{JJ}e_j}\quad(j\in J),\qquad
 z_k=Ux_J^{B_{Jk}}.
\]

Let `M_B` denote the finite theta algebra with all principal frozen variables
inverted, over `Z`.  Let `M_C` be the corresponding algebra for `C=B_JJ`,
using mutable variables `x_J` and principal coefficients `Y_J`.  For
`g in Theta_B`, put `t=[-g_k]_+`, `b=g_J+B_Jk t`.  The source-face theorem is
exactly the initial-form identity

\[
 \boxed{\operatorname{in}_{\deg U}(\theta_g^B)
       =X^{g_k}U^t\theta_b^C(x_J,Y_J).}                 \tag{1}
\]

The expression on the right is a genuine finite theta function precisely
when the original one is finite.

## 2. No leading cancellation and the associated graded algebra

An integral basis of `M_B` consists of the elements `y^h theta_g^B` with
`h in Z^n` and `g in Theta_B`.  Their highest `U` terms are

\[
 U^{h_k+t}
 X^{g_k-\sum_{j\in J}B_{kj}h_j}
 Y_J^{h_J}\theta_b^C.                                  \tag{2}
\]

The indices in (2) run bijectively over the ordinary integral theta basis of
`M_C[X^{\pm1},U^{\pm1}]`.  Indeed, given `(b,h_J,v,u)`, recover

\[
 g_k=v+B_{kJ}h_J,\quad t=[-g_k]_+,\quad
 g_J=b-B_{Jk}t,\quad h_k=u-t.
\]

The regular-label equivalence in the source-face theorem makes this a
bijection on the finite labels.  Distinct basis elements therefore have
linearly independent highest terms at each fixed `U` degree.  In particular
no highest-degree cancellation occurs in a finite integral theta expansion.

For the increasing filtration

\[
 F_d M_B=\{f\in M_B:\deg_U f\le d\}\quad(d\in\mathbb Z),
\]

we obtain the explicit graded algebra isomorphism

\[
 \boxed{\operatorname{gr}_F M_B
       \simeq M_C[X^{\pm1},U^{\pm1}],}                 \tag{3}
\]

where `U` has degree one and all variables and theta functions in `M_C`, as
well as `X`, have degree zero.  This is an isomorphism over `Z`; it concerns
the middle/finite theta algebras even when neither has been identified with
the corresponding upper algebra.

The top multiplication coefficient formula in Section 6 of the companion
note is the formula for structure constants under (3), in the original
principal root-charge coordinates.  Thus the coefficient shift in that
formula is essential; simply deleting `q_k` would be incorrect.

## 3. A flat algebra degeneration with a specified basis

The extended Rees algebra is

\[
 \mathcal R_F(M_B)=\bigoplus_{d\in\mathbb Z}F_dM_B\,T^d
       \subset M_B[T,T^{-1}].
\]

It is a free `Z[T]` module: for each integral theta basis element `b`, take
the generator `T^{deg_U b} b`.  The no-cancellation statement above says
these are a basis.  Its fiber at `T=1` is `M_B`; its fiber at `T=0` is the
algebra in (3).  This proves flatness without finite-generation assumptions.
If one wants a finite-type geometric family, finite generation must be
checked separately and is not asserted here.

Iterating source deletions gives successive such degenerations.  The exact
core label at the end is the piecewise-linear label in equation (8) of the
companion note.

## 4. Scope and novelty

This is a concrete source-face description, not a replacement for the
remaining construction of the core theta functions.  Coefficient
degenerations, freezing, and source extension filtrations have extensive
prior literature.  GHKK's principal family and Qin's freezing theorem are
directly relevant antecedents.  The particular normalization (1), integral
theta basis identification (2), and finite-label formulation (3) are recorded
here as derived interfaces, with no priority claim based only on a web
search.

Fei--Weyman arXiv:1707.04661v2, Section 4.1, instead studies the filtration by
minus the mutable `x_e` valuation and obtains `A[T]/(x_e T)` under an algebra
generation hypothesis.  Their object is not (3): the filtration, coefficient
normalization, and hypotheses differ.  Their triangular generic-character
formula cannot be used to identify generic characters with theta functions.

