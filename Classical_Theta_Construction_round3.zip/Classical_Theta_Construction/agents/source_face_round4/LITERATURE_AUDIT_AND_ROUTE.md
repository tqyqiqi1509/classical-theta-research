# Source/core route and primary literature audit

Research round: 2026-11-13 approximately 19:52--20:06 UTC.  Only classical
cluster theta functions are used in the proved statements.

## 1. Prior own results: retain the actual novelty boundary

Read the original source of Hexagon 2610.00201v3, *Finite quantum theta
functions for skew-symmetrizable seeds*:

https://hexagonmath.org/api/v1/works/2610.00201v3/source?path=quantum_theta.tex

Section 9.10 already contains one-way acyclic unfreezing.  It defines the
slack vector `t_old=(I+H+...+H^(r-1))[-g_I]_+`, gives a core-support box
inclusion, and proves the sufficient finite-core criterion.  Section 11.7
already transfers upper bases.  The old local `ACYCLIC_CREATION_CAPS.md`
already contains sharp triangular capacities and binomial coefficient caps
when the *whole* exchange matrix is acyclic.

Consequently neither “source extension preserves finiteness” nor “binomial
creation caps in the acyclic case” is new.  The increment here is the exact
top face over an arbitrary cyclic core, projection equality, the
label-specific if-and-only-if, the sharp capacities in that setting, and the
exact lift of top multiplication coefficients.  These follow from established
mutation and freezing, so their usefulness should be assessed as an explicit
interface rather than advertised as a new foundational theta construction.

## 2. Published inputs independently checked

**GHKK, arXiv:1411.1394v2**, Proposition 3.6 and its proof:
https://arxiv.org/html/1411.1394v2

Read the broken-line mutation correspondence and the endpoint-dependent
linear transport of the final exponent.  Subtraction of the transformed
leading exponent gives equation (4) in our source-face note.  At a source
the extra row term vanishes, so the exact reflection is `a'_k=t-a_k`.
Status: correct and directly useful.  It removes any need to substitute
`z_k^-1` into an uncontrolled infinite power series.

**Qin, arXiv:2407.03186v1**, Theorem 5.2 and proof:
https://arxiv.org/html/2407.03186v1

Read the quotient diagram construction and zero-charge broken-line argument.
The zero charge face survives precisely when all bends avoid the frozen
directions.  Status: correct and directly useful.  Applying it after the
source mutation gives the required top face, since the other endpoint
coordinates stay in the positive chamber.

## 3. Strong audit of Fei--Weyman v2 (2026)

**Fei--Weyman, *Extending Upper Cluster Algebras*,
arXiv:1707.04661v2, dated 28 October 2026**:

https://arxiv.org/html/1707.04661v2

This is materially revised from the 2017 version.  The current arguments use
coefficient localization, a special-fiber saturation condition, a source
filtration, and generic presentations.  Read Sections 3.1--4.3 in detail,
and the statement and proof interfaces in Section 5.

### Algebraic steps checked

1. The one-variable intersection normal form and saturation criterion are
   conditional on the stated intersection equality.  The proof lowers the
   degree in the adjacent cluster variable using divisibility in the special
   fiber.  That hypothesis cannot be dropped.
2. The separating grading argument in Proposition 3.5 is valid: homogeneous
   recursion from the least degree proves divisibility saturation when one
   exchange monomial is a unit.  The unit assumption is essential.
3. In Lemma 4.2, once `U=A[x'_e]` is given, repeatedly lowering a leading
   coefficient divisible by `x_e` identifies the filtration with pole order.
   This gives `gr U=A[T]/(x_e T)` by a direct module calculation.  This checked
   algebraic statement is useful as an analogy, not imported into our proof.
4. Proposition 4.4 concerns **generic characters**.  Its Schur-complement
   argument uses Jacobi-finite QP data, no cycles through the source, and a
   generic invertible old-projective block.  Its Grassmannian product occurs
   only on the zero outgoing-degree slice.  This cannot justify a full
   coefficient equality or theta/generic equality.

### A tempting misreading avoided

Example 3.8 shows that the special-fiber saturation can fail when full rank
is absent.  It is not a counterexample to all source-extension results:
the intersection hypothesis of the saturation equivalence may fail there.
For the coefficient-free path `e -> 1 -> 2`, the candidate
`(1+x_1)/(x_e x_2)` passes the initial and individually adjacent Laurent
tests but fails in the seed obtained by mutating both endpoints, where its
expression has denominator `1+x_1`.  Thus one must not replace the full
upper algebra by the adjacent upper bound in that example.

Status: the audited algebraic steps are useful and no error was found in
those steps.  The full generic-basis theorem and its representation-theoretic
dependencies were not re-proved and are not used.  No theta conclusion is
borrowed.  The mixed-sign special-fiber saturation criterion is a possible
future interface, but its Krull and boundary-divisor hypotheses still need
actual verification in a proposed application.

## 4. Routes attempted and disposition

- **First attempt: source-supported walls lie on one side.** A degree
  induction on outgoing supports supplies a geometric explanation.  Replaced
  by the shorter exact GHKK mutation formula to avoid making this a separate
  unproved geometric premise.
- **Infinite rational substitution.** The expression
  `(1+z_k)^t F_{g'}(z_k^-1,...)` suggests the top face but is not by itself a
  proof for infinite theta series.  Replaced by coefficient-preserving
  mutation and zero-charge freezing.
- **Source carrier.** Corrected the label of the adjacent variable: it is
  `-e_k-B_Jk`, not `-e_k`.  This gives the binomial coefficient majorant.
- **Exact multiplication boundary.** Taking the top source degree yields a
  unique lifted root charge, hence a complete equality of the corresponding
  structure coefficients with the core.  Proved and independently tested.
- **Associated graded algebra.** Normalizing `Y_j=y_j x_k^(B_kj)` turns the
  top-face formula into an explicit integral basis of a Laurent extension of
  the core finite theta algebra.  Proof recorded separately.  It does not
  assume upper=middle or finite generation.
- **Generic-character shortcut.** Not used: the new Fei--Weyman triangularity
  is a different basis statement and does not identify interior theta
  coefficients.
- **Global finite support without an eliminable vertex.** Still unresolved.
  The source reduction exposes rather than hides this remaining core task.

## 5. Search record

Queries covered source/sink theta functions, freezing/top faces, Newton
projections, coefficient degenerations, principal partial degenerations, and
source associated-graded algebras.  Read primary GHKK, Qin, current
Fei--Weyman, and the exact own Hexagon source; broad search hits also returned
finite-type Newton and deformation papers, which do not directly address the
arbitrary cyclic core.  A failure to locate the exact formulas is not used as
proof of novelty.

