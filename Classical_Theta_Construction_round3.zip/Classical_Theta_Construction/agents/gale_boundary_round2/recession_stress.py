"""Independent finite stress check of the actual-arrow recession lemma.

The proof is in COLOR_GENERIC_VALUATION_WINDOW.md. This program checks the
specific new risk: a hierarchy feasible on a generic color subspace might
have a nonnegative kernel direction increasing an actual arrow valuation.
No theta coefficient is an input to this program.
"""
from __future__ import annotations
import json
import random
from fractions import Fraction
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.optimize import linprog

HERE=Path(__file__).resolve().parent
rng=random.Random(202611132113)

def hierarchy(leaves):
    if len(leaves)==1:
        return []
    q=list(leaves); rng.shuffle(q)
    k=rng.randrange(1,len(q))
    return hierarchy(q[:k])+hierarchy(q[k:])+[tuple(sorted(q))]

stats={"graphs":0,"hierarchies":0,"singular":0,
       "color_space_contained":0,"positive_feasible":0,
       "recession_tests":0,"nontrivial_recession":0,
       "exact_dual_certificates":0,"dual_reconstruction_failures":0,
       "actual_arrow_recession_failures":0}
failure=[]
for graph_index in range(120):
    m=rng.randrange(2,5)
    counts=[1]*m
    for _ in range(rng.randrange(1, min(5,8-m))):
        counts[rng.randrange(m)]+=1
    colors=[0]+[i+1 for i,c in enumerate(counts) for _ in range(c)]
    n=len(colors)
    small=[[0]*(m+1) for _ in range(m+1)]
    for i in range(m+1):
        for j in range(i+1,m+1):
            small[i][j]=rng.randrange(-3,4)
            small[j][i]=-small[i][j]
    if m==3 and graph_index%3==0:
        r=1+graph_index%4
        for i in range(1,4):
            small[0][i]=1; small[i][0]=-1
        small[1][2]=small[2][3]=small[3][1]=r
        small[2][1]=small[3][2]=small[1][3]=-r
    eta=[[small[colors[i]][colors[j]] for j in range(n)] for i in range(n)]
    U=sp.Matrix([[int(colors[v]==i+1) for i in range(m)] for v in range(1,n)])
    theta=np.array([float(101**(colors[v]-1)) for v in range(1,n)])
    stats["graphs"]+=1
    for _ in range(60):
        nodes=hierarchy(tuple(range(n)))
        M=sp.Matrix([[sum(eta[u][v] for u in S) if v in S else 0
                      for S in nodes] for v in range(1,n)])
        stats["hierarchies"]+=1
        if M.det()!=0:
            continue
        stats["singular"]+=1
        rank=M.rank()
        if M.row_join(U).rank()!=rank:
            continue
        stats["color_space_contained"]+=1
        a=np.array(M.tolist(),dtype=float)
        feasible=linprog(np.zeros(n-1),A_eq=a,b_eq=-theta,
                         bounds=(0,None),method="highs")
        if not feasible.success:
            continue
        stats["positive_feasible"]+=1
        objective=np.array([sum(abs(eta[u][v]) for u in S for v in S if u<v)
                            for S in nodes],dtype=float)
        rec=linprog(-objective,A_eq=np.vstack([a,np.ones(n-1)]),
                    b_eq=np.r_[np.zeros(n-1),1.0],
                    bounds=(0,None),method="highs")
        stats["recession_tests"]+=1
        if not rec.success:
            continue
        stats["nontrivial_recession"]+=1
        if -rec.fun>1e-7:
            stats["actual_arrow_recession_failures"]+=1
            failure.append({"small_eta":small,"counts":counts,"nodes":nodes,
                            "M":M.tolist(),"theta":theta.tolist(),
                            "depth":feasible.x.tolist(),"recession":rec.x.tolist(),
                            "actual_objective":float(-rec.fun)})
            break
        dual=linprog(np.zeros(n-1),A_ub=-a.T,b_ub=-objective,
                     bounds=[(None,None)]*(n-1),method="highs")
        if dual.success:
            u=sp.Matrix([sp.Rational(Fraction(float(x)).limit_denominator(1000000))
                         for x in dual.x])
            slack=M.T*u-sp.Matrix([int(x) for x in objective])
            if all(x>=0 for x in slack):
                stats["exact_dual_certificates"]+=1
            else:
                stats["dual_reconstruction_failures"]+=1
        else:
            stats["dual_reconstruction_failures"]+=1
    if failure:
        break
result={"seed":202611132113,"statistics":stats,"failures":failure,
        "qualification":"Exact ranks and determinants; feasibility screening uses HiGHS doubles. Each reported exact dual certificate is reconstructed over Q and checked by Sympy: M^T u>=actual_arrow_objective. It certifies no nonnegative kernel direction increases an actual edge. No finite test replaces the proof."}
(HERE/'recession_stress.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
