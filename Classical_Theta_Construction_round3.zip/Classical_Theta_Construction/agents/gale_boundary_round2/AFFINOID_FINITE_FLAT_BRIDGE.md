# From a uniform collision window to a finite flat Gale family

Date: 2026-11-13. Independent boundary/flatness branch.

This note supplies the analytic implication needed after the collision-tree
recession lemma. It does not assert that a nonzerodivisor in a finite algebra
over a parameter ring is a unit. That assertion is false. The actual-arrow
valuation window is the extra geometric input.

## 1. Precise input

Let Q be a finite directed multigraph on vertices 0,...,n, with x_0=0.
Parallel arrows may be collected into positive integer multiplicities. There
are no loops; opposite arrows can be retained, although the cluster packet
graphs have no opposite arrows between the same two original vertices.
Write L_e=x_head(e)-x_tail(e), and

    Gamma_v(x) = product_in(v) L_e / product_out(v) L_e.

The framing equation is dependent on the n mutable equations. Fix a rational
netflow theta_0 of sum zero. Suppose there are positive rational numbers
epsilon, delta, M with the following property:

For every complete valued extension of K=C((T)) and every solution of

    Gamma_v(x)=q_v T^(-theta_0(v)),   v=1,...,n,

with |v_T(q_v)| <= epsilon, all x_v of positive valuation, and all actual
arrow differences nonzero, one has

    v_T(x_v) >= delta,
    delta <= v_T(L_e) <= M  for every actual arrow e.             (1)

The inequalities are uniform in the residues of q, not merely in generic
constants. A finite ramified extension clears every rational exponent.

The hierarchy argument gives (1) for theta_0 obtained by a sufficiently
generic original-color covector. Its two ingredients are:

* at theta_0, every nonnegative recession direction of every feasible
  hierarchy affects only monochromatic collisions, hence no actual arrow;
* the finitely many hierarchy cones which are infeasible at theta_0 remain
  infeasible in a neighborhood, while linear programs on the remaining
  cones have bounded actual-arrow objectives on a compact neighborhood.

The lower bound follows from the first root split and the nonzero framed
cut weights. Equal coordinates at nonadjacent vertices are allowed.

## 2. An affinoid family containing precisely the positive factor

Let Y be the closed polyannulus

    |T|^epsilon <= |q_v| <= |T|^(-epsilon), v=1,...,n.

Choose 0<delta'<delta and M'>M. Over Y, form the affinoid space X with
generators x_v and z_e, relations

    L_e z_e = 1,
    Gamma_v(x)=q_v T^(-theta_0(v)),

and bounds

    |x_v| <= |T|^delta',   |z_e| <= |T|^(-M').                    (2)

The rational Gale equations are polynomial in these generators because
every denominator has an inverse z_e. This is a finite presentation of a
relative Tate algebra quotient.

Every point of X is a positive-valuation Gale solution, so (1) applies.
Conversely every positive-valuation solution belongs to X. At every point
of X all the generator inequalities in (2) are strict:

    |x_v| <= |T|^delta < |T|^delta',
    |z_e| <= |T|^(-M) < |T|^(-M').

This is exactly the defining criterion for a point to be in the relative
interior of an affinoid morphism. Thus X -> Y has empty relative boundary.
An affinoid morphism with empty relative boundary is finite. Consequently
X -> Y is finite, including all scheme multiplicities.

This argument does not require a separate assertion that the completed
saturated equations commute with target specialization. The affinoid family
already has every target fiber and keeps all actual arrows invertible.

Primary reference checked: Michael Temkin, *Introduction to Berkovich
analytic spaces*, 2010 lecture notes, Definition 3.4.9, Remark 3.4.10 and
Fact 3.4.11(iv), pp.17-18:
https://berkovich-2010.imj-prg.fr/lecture-notes/Temkin-lecture-notes.pdf
The source states the strict-generator interior criterion and the equivalence
between an empty relative boundary and finiteness. These are standard
Berkovich results, not new assertions of the present project.

## 3. Flatness

The source X can also be viewed as an analytic domain in the graph

    q_v=T^(theta_0(v)) Gamma_v(x)

on the open configuration space where all L_e are nonzero. The graph is
isomorphic to that open subset of affine n-space. Its analytic domains have
regular affinoid local rings and pure dimension n. The target polyannulus
is regular of dimension n.

Since X -> Y is finite, its fibers have dimension zero. At each maximal
point of the source and its image, the two Noetherian local rings have the
same dimension n; the source is regular, hence Cohen--Macaulay. The local
miracle-flatness criterion applies. Therefore the finite morphism is flat.
Flatness of a finite module can be checked at maximal ideals, so this proves
finite flatness over the entire polyannulus. The empty-source case has rank
zero and is included.

Primary criterion checked in full, including its proof:
Stacks Project, Lemma 10.128.1, tag 00R4:
https://stacks.math.columbia.edu/tag/00R4

The connected polyannulus therefore has one constant finite rank. A nearby
strong-generic leaf covector theta is represented in the same family by
q_v=T^(theta_0(v)-theta(v)). Its fiber has the collision-tree/Hensel degree
already proved by the strong-generic branch. The unit targets invariant
under clone permutations lie in this same family and have precisely that
length. There is no unproved inference from equality of two numerical counts
to an equivariant correspondence.

## 4. Invariant polynomial perturbations

Use the primitive Gale row if desired, dividing row v by a positive
integer d_v. Write a_i=theta_0(v)/d_v>0; this is constant on clones of the
same original color i. Let p_i be a polynomial of degree at most n_i-1,
where n_i is the number of clones of color i, and use that same polynomial
at every clone. Its coefficients are parameters in a bounded polydisc H.
For a positive integer N replace the row equations by

    Gamma_v^prim(x)=q_v T^(-a_i)-T^N p_i(x_v).                 (3)

Choose the target polyannulus small enough that epsilon<N+min_i a_i.
On the positive coordinate domain, (3) has the form

    Gamma_v^prim=q_v T^(-a_i)
                   (1-q_v^(-1) T^(N+a_i) p_i(x_v)).

The parenthesized factor has valuation zero. Multiplying the row valuation
by d_v recovers the same raw tropical equations, so the uniform window
applies unchanged. These are polynomial equations after denominators are
cleared; no exponential or logarithm enters their definition.

Apply Sections 2-3 over Y x H. The x,z generators are still strictly inside
their relative bounds, hence the family is finite. Solving for q identifies
the source with an analytic domain in configuration space times H, so it
is regular of the same dimension as Y x H. Miracle flatness applies. The
rank is constant, including at p_i=0.

The bounded parameter polydisc meets the generic open set in the separate
equivariant square-map/Hermite lemma: multiplying coefficients by T^N is
an invertible linear change over K, and a nonzero polynomial cannot vanish
on an entire nonempty polydisc over this infinite field.

For clarity, the degree n_i-1 is enough. If an equality stratum has r
distinct coordinate values of color i, prescribe p_i at these r values.
For each equality block of multiplicity at least two, also prescribe its
derivative to control the normal standard-representation scalar. There
are at most n_i-r such repeated blocks, hence at most n_i Hermite
conditions. The parameter values give the needed transversality on the
fixed stratum, while the extra derivatives keep the normal scalars nonzero.
This is a direct square-map argument and needs no gradient hypothesis.

This supplies the family justification for the separate equivariant
simple-root deformation. It applies simultaneously to the finitely many
fixed-cycle restrictions. That equivariant lemma still has its own proof;
simple roots are not inferred merely from finite flatness.

## 5. Failed universal argument and its repair

The earlier proposed argument was: complete a universally saturated ideal;
it is finite over R[[T]]; Lambda is a nonzerodivisor; therefore Lambda is a
unit after T is inverted. The last implication is false when R is not a
field. For example, with R=k[u],

    A=R[[T]][x]/(x-uT),  Lambda=x,

both T and Lambda are regular and the special support is x=0, but
Lambda=Tu is not a unit in A[T^(-1)]. Boundary loss can occur over u=0.

The phase branch also found an actual cyclic Gale example: the unit
directed triangle with one arrow from each mutable vertex to the frame and
equal theta has degree four for a generic target and no saturated solutions
at all targets equal to one. Therefore a theorem for every original-color
covector and every unit target would be false.

The repair is substantive: choose the original-color covector away from the
finite proper hyperplanes in the hierarchy argument, establish a uniform
actual-arrow window, and work over the resulting full target polyannulus.
The proof of this note then gives finiteness and flatness without that
invalid unit argument.

## 6. Status

The analytic implication (1) -> finite flat family has been independently
checked here. Its standard analytic and commutative-algebra inputs were
read at their precise statements. The collision-tree window is now
written in `agents/phase_descent_round1/COLOR_GENERIC_VALUATION_WINDOW.md`
and was independently read in full here. The retained two-plane memory,
parallel depth absorption, recession argument, full-neighborhood
extension, and cut lower bound pass that review. This conclusion depends
on the stated original-color genericity; the equal-theta triangle is
excluded.

The accompanying `recession_stress.py` and `recession_stress.json` test
the precise remaining recession risk over 7,200 random binary hierarchies
on 120 graphs. There were 64 feasible singular cases with nontrivial
nonnegative recession. Each received an exact rational dual certificate
`M_H^T u >= c`, where `c` is the sum of the actual-arrow valuation
objectives; all inequalities were checked over Q in Sympy. There were
zero failures and zero failed reconstructions. Feasibility screening used
floating-point HiGHS, so the selected sample is not an exhaustive exact
enumeration. These certificates supplement the general proof and do not
replace it.
