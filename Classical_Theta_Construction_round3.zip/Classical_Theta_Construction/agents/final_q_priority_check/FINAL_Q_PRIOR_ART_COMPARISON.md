# Final targeted BPZ priority comparison

2026-11-14, independently checked against the actual primary text. This is a prior-art comparison, not an independent proof audit or a global priority clearance.

## Decision

**Retain only the positive-origin/full-Artin/theta identification as a candidate addition. Downgrade the Q equations, independent node parameters, framing, and polynomial complementation to existing machinery.** No direct equivalence between the retained statement and BPZ's proved result was found.

Primary source: Benini–Park–Zhao, [arXiv:1406.2699v1](https://arxiv.org/pdf/1406.2699v1), especially §3.3, printed pp.31–35. The [arXiv history](https://arxiv.org/abs/1406.2699) lists only v1. The 2015 published article is [doi:10.1007/s00220-015-2452-3](https://doi.org/10.1007/s00220-015-2452-3); its full text was not available in the publisher preview, so this comparison does not assert a line-by-line check of the journal version.

## What the checked source establishes

BPZ (3.27), (3.29)–(3.37) give flavor polynomials, monic divisibility, complementary polynomials, and the dressed cluster exchange. The complementary degree is the full polynomial degree, a maximum. After (3.38), they explicitly leave general twisted-chiral-ring equivalence unproved. Their strong solutions require squarefree individual Q's and coprimality at adjacent nodes. Equations (3.39)–(3.49) transport strong solutions; the concluding paragraph, p.35, says the image can be weak and weak inputs can fail. The paper works with skew-symmetric matrices; §3.1, footnote 24 merely acknowledges the more general skew-symmetrizable setting. No positive-valuation origin factor, nilpotent local-length theorem, or theta-coefficient identification is established there.

## Exact overlap in our presentation

In the skew-symmetric case add a frozen color with \(Q_f(z)=z\) and signed incidences \(B_{if}=g_i\). Let \(\kappa_i=i^{N_a(i)-N_f(i)}\) denote BPZ's row phase. For our unsigned row

\[
T^{a_i}A_i-\lambda_iE_i,
\qquad \kappa_i z_i^{\mathrm{BPZ}}=-\lambda_iT^{-a_i},
\]

the divisibility equation on \(T\ne0\) is exactly the pulled-back BPZ (3.37). Fixed row signs are absorbed into \(\lambda_i\). Taking monic remainders eliminates BPZ's quotient polynomial. Thus choosing independent generic \(\lambda_i\), or \(a_i=1\), does not itself create a new algebraic equation. Saturation is a standard operation; its correctness for the desired selected factor is the theorem that needs proving.

## What remains to be supplied by our two notes

| Claimed ingredient | Precise residual mathematical obligation |
|---|---|
| Universal-unit formula, (1.1)–(1.4) | Prove the all-ones generic-residue window, finiteness of the **entire** positive factor, and the coefficient identification for arbitrary cycles and skew-symmetrizable data. |
| Actual-arrow/frame saturation | Show that this exact open, without a discriminant factor, retains the intended multiplicities; neither generic root counting nor a different saturation suffices. |
| Origin-local special fiber | Prove that completion selects the full positive generic factor and that its special-fiber length is \(a_g(p)\). The local algebra and theta interpretation cannot be inferred from the displayed QQ identity alone. |
| Zero-endpoint mutation, §§3–6 | Prepare the distinguished factor, deform to complete separation through a **finite flat** family, control newly required arrows, retain local Artin factors, remove coupled units, and obtain both length inequalities. |

The zero-endpoint factor has degree \(\min(\alpha_k,\beta_k)\), but this numerical difference is only ordinary tropical/local-root behavior. It is not a defensible independent novelty claim. Likewise the explicit constant-unit birational maps and halfspace certificates should remain implementation or standard-algebra consequences, not headline additions.

The strongest supportable claim is therefore conditional on the internal proof's correctness: **a scheme-theoretic positive-origin realization and length theorem for a particular classical theta coefficient model**, using prior complementary-Q machinery. It is not a proof of equivalence of BPZ's physical chiral rings. BPZ's acknowledged weak-solution gap is evidence against automatic identification with its theorem; it is not by itself evidence that our proposed repair is correct or historically first.

Checked local inputs: `../support_accessibility_fresh/UNIVERSAL_UNIT_COEFFICIENT_ALGEBRAS.md` and `../support_accessibility_fresh/ZERO_ENDPOINT_Q_MUTATION_AND_SUPPORT_CERTIFICATES.md`.
