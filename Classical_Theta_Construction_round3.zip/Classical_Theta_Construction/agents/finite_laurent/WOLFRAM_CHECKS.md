# Exact computational-plugin verification

The Wolfram context search was called at the start of the new arithmetic direction. It found no relevant cluster-theta arithmetic source, so no mathematical assertion was taken from that search.

The Wolfram Language evaluator was then used for exact polynomial checks of the local Frobenius-error lemma. A final repeated call also checked the symbolic Schur coefficient in the independently proved counterexample family.

```wolfram
Clear[x];
ps = {2, 3, 5, 7};
fs = {1 + x, 1 + 2 x + 3 x^2, 1 + 3 x^2 + 2 x^3, 1 - x + 2 x^2};
bad = Reap[
  Do[
    co = CoefficientList[Expand[f^(p a) - (f /. x -> x^p)^a], x];
    If[! And @@ Thread[Mod[co, p^(1 + IntegerExponent[a, p])] == 0],
      Sow[{p, a, f}]],
    {p, ps}, {a, 1, 16}, {f, fs}]
  ][[2]];
<|"localFrobeniusCases" -> 256,
  "failed" -> bad,
  "SchurE3Coefficient" ->
    FullSimplify[(3 (m - 1) - 3 ((m - 1) + 2 (m - 2)) + 6 (m - 3))/6]|>
```

Returned output:

```text
<|"localFrobeniusCases" -> 256, "failed" -> {},
  "SchurE3Coefficient" -> -1|>
```

The tested local assertion includes the prime two and a series with a negative coefficient, as appropriate for the integral-series lemma. Classical positivity is an additional input only for the separate cyclic-decoration argument.

The 22,215 Möbius coefficient positions and the Schur-sign tests were computed separately using exact Python integer arithmetic and the prior package's incoming-Schur engine. Their scripts and JSON outputs are stored in this directory. No floating-point approximation is used in these tests.
