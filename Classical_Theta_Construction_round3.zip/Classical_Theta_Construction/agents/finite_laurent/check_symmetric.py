"""Probe elementary / Schur positivity of theta-ray power sums.

No positivity claim follows from this script. It records counterexamples as
well as successes; exact arithmetic is used throughout.
"""
from itertools import product
from pathlib import Path
import json
import random
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from check_mobius import IncomingSchur


def conv(f, g, cap):
    out = {}
    for p, a in f.items():
        for q, b in g.items():
            r = tuple(x + y for x, y in zip(p, q))
            if all(x <= c for x, c in zip(r, cap)):
                out[r] = out.get(r, 0) + a * b
    return {p: a for p, a in out.items() if a}


def addto(f, g, scalar=1):
    for p, a in g.items():
        f[p] = f.get(p, 0) + scalar * a


def elementary(R, g, cap, degree):
    zero = (0,) * len(g)
    powers = {k: R.theta_prefix(tuple(k * x for x in g), cap)
              for k in range(1, degree + 1)}
    elementarys = {0: {zero: 1}}
    for n in range(1, degree + 1):
        num = {}
        for k in range(1, n + 1):
            addto(num, conv(powers[k], elementarys[n-k], cap), (-1) ** (k-1))
        assert all(a % n == 0 for a in num.values()), (g, n, num)
        elementarys[n] = {p: a // n for p, a in num.items() if a}
    return powers, elementarys


def main():
    started = time.time()
    rng = random.Random(261114)
    seeds = [
        ([[0, 2], [-2, 0]], [1, 1], "kronecker2", (6, 6)),
        ([[0, 3], [-3, 0]], [1, 1], "wild3", (6, 6)),
        ([[0, 3], [-2, 0]], [2, 3], "valued32", (6, 6)),
        ([[0, 2, -2], [-2, 0, 2], [2, -2, 0]], [1, 1, 1], "markov2", (3, 3, 3)),
        ([[0, 2, -2], [-1, 0, 1], [2, -2, 0]], [1, 2, 1], "valuedcycle", (3, 3, 3)),
        ([[0, 1, 2], [-1, 0, 1], [-2, -1, 0]], [1, 1, 1], "acyclic3", (3, 3, 3)),
    ]
    failures = []
    records = []
    for B, D, name, cap in seeds:
        R = IncomingSchur(B, D)
        gs = list(product(range(-3, 4), repeat=2)) if len(D) == 2 else [tuple(rng.randrange(-4, 5) for _ in D) for _ in range(80)]
        checks = 0
        for g in gs:
            p, e = elementary(R, g, cap, 4)
            for n in (2, 3, 4):
                checks += len(list(product(*(range(c + 1) for c in cap))))
                neg = [(q, a) for q, a in e[n].items() if a < 0]
                if neg:
                    rec = {"seed": name, "B": B, "D": D, "g": g,
                           "n": n, "negative": neg, "cap": cap}
                    failures.append(rec)
                    print(json.dumps({"counterexample": rec}), flush=True)
                    (HERE / "symmetric_checks.json").write_text(json.dumps({"records": records, "counterexamples": failures}, indent=2))
        rec = {"seed": name, "labels": len(gs), "checks": checks,
               "counterexamples": sum(x["seed"] == name for x in failures),
               "seconds": time.time() - started}
        records.append(rec)
        print(json.dumps(rec), flush=True)
    out = {"records": records, "counterexamples": failures, "seconds": time.time() - started}
    (HERE / "symmetric_checks.json").write_text(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
