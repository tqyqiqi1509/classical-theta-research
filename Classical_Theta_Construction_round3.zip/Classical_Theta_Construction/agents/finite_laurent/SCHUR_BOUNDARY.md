# The complete-symmetric construction is not generally Schur positive

This is a boundary check for the new positive family \(H_{N,g}\), not a replacement for the general Gauss/Möbius mechanism. It prevents an unjustified extension of that mechanism to all Schur functions.

## An infinite family of exact counterexamples

Let

\[
B=\begin{pmatrix}0&m\\-m&0\end{pmatrix},\qquad m\geq3,
\qquad g=(-1,1).
\]

Use principal coefficients and \(z_1=y_1x_2^{-m}\), \(z_2=y_2x_1^m\). Write

\[
\vartheta_{kg}=x_1^{-k}x_2^k F_{kg}(z_1,z_2).
\]

For \(k=1,2,3\), the coefficients relevant below are

\[
[z_1]F_{kg}=k,\qquad [z_2]F_{kg}=0,\qquad
[z_1z_2]F_{kg}=k(m-k).\tag{1}
\]

These equalities can be checked independently of the previous incoming-Schur implementation using the established rank-two greedy basis, as follows.

### Independent derivation from the greedy recurrence

Cheung–Gross–Muller–Musiker–Rupel–Stella–Williams identify the rank-two theta and greedy bases. Their piecewise-linear \(g\)-to-\(d\) map, after interchanging the two vertex names to match the displayed sign convention for \(B\), sends the label \((-k,k)\) to denominator vector

\[
(a_1,a_2)=(k,k(m-1)).
\]

Thus, after specializing principal coefficients to one,

\[
\vartheta_{kg}=x_1^{-k}x_2^{-k(m-1)}
\sum_{p,q\geq0}c_k(p,q)x_1^{mp}x_2^{mq},
\]

where \(c_k\) is the classical greedy recurrence of Lee–Li–Zelevinsky. The determinant of \(B\) is \(m^2\neq0\), so distinct root degrees remain distinct mutable Laurent monomials after this specialization. Therefore these coefficients also determine the corresponding principal coefficients.

The coefficient at root degree \((r,s)\) is \(c_k(s,k-r)\). On the axis,

\[
c_k(0,q)=\binom{k}{q}.
\]

For \(p=1,q=k-1\), the first branch of LLZ Proposition 1.6 applies because

\[
ma_1q=mk(k-1)\leq mk(m-1)=ma_2p
\quad(k\leq m).
\]

Only its first summand occurs, giving

\[
c_k(1,k-1)=c_k(0,k-1)
\binom{a_2-m(k-1)}1
=k(m-k).
\]

Also \(c_k(1,k)=0\). If \(k\leq m-1\), the same first branch applies and its binomial top is \(-k\), so the result is zero under LLZ's nonnegative binomial convention. If \(k=m\), the second branch applies and all binomial coefficients have top one less than the lower index, so they are zero. These computations prove (1), including the case \(m=k=3\).

### The negative Schur coefficient

Specialize symmetric-function power sums by \(p_k\mapsto\vartheta_{kg}\). The third elementary symmetric function, equivalently the Schur function \(s_{(1,1,1)}\), becomes

\[
E_{3,g}=\frac{
\vartheta_g^3-3\vartheta_g\vartheta_{2g}+2\vartheta_{3g}}6.
\]

All terms have leading factor \(x^{3g}\). Because the \(z_2\) coefficient in each \(F_{kg}\) is zero, the \(z_1z_2\) coefficient is

\[
\begin{aligned}
[x^{3g}z_1z_2]E_{3,g}
&=\frac{3(m-1)-3((m-1)+2(m-2))+2\cdot3(m-3)}6\\
&=\boxed{-1}.
\end{aligned}
\]

Thus the theta-ray power-sum specialization is not generally Schur positive, even for classical skew-symmetric rank-two seeds. It fails throughout the infinite family \(m\geq3\), and the displayed exact coefficient requires no truncation conjecture.

This does not contradict either Möbius positivity or the positivity of the complete-symmetric \(H_{N,g}\). The Euler product for \(H\) contains positive generators in higher \(T\)-degrees; it need not be the character of a positive alphabet of degree-one variables.

## Sources checked

- Lee–Li–Zelevinsky, *Greedy elements in rank 2 cluster algebras*, arXiv:1208.2391v3, Definition 1.3 and Proposition 1.6. https://arxiv.org/html/1208.2391v3
- Cheung–Gross–Muller–Musiker–Rupel–Stella–Williams, *The greedy basis equals the theta basis: a rank two haiku*, arXiv:1508.01404v2, Section 4, Remark 4.5, Theorems 1.1 and 5.1. https://arxiv.org/html/1508.01404v2

Relevant web IDs: `turn79view0`, `turn81view1`, `turn81view0`, `turn83view0`, `turn83view1`. The sign-convention conversion is explicitly made above; the paper's initial root directions have the opposite orientation before the vertex swap.

## Computation record

`check_symmetric.py` first found the minimal instance \(m=3,g=(-1,1)\), with coefficient \(-1\) at root degree \((1,1)\). Additional exact checks were retained in `symmetric_checks.json`, including other rank-two labels and acyclic rank-three examples. The general derivation above supersedes those numerical observations for the stated family. No further enumeration is needed to settle the proposed universal Schur-positivity claim.
