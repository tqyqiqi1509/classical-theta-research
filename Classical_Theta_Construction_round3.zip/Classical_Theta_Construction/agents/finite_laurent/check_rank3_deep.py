"""Reproduce the completed [0,6]^3 Mobius stress run (about 103 seconds)."""
from pathlib import Path
import json
import time
from check_mobius import IncomingSchur, primitive_prefix

HERE = Path(__file__).resolve().parent
started = time.time()
out = []
for B, D in [
    ([[0, 2, -2], [-2, 0, 2], [2, -2, 0]], [1, 1, 1]),
    ([[0, 2, -2], [-1, 0, 1], [2, -2, 0]], [1, 2, 1]),
]:
    engine = IncomingSchur(B, D)
    for g in [(-1, -1, -1), (-2, 1, 1)]:
        for n in [6, 10, 12]:
            a, bi, neg = primitive_prefix(engine, g, n, (6, 6, 6))
            record = {
                "B": B, "D": D, "g": g, "n": n, "cap": (6, 6, 6),
                "checks": 343, "nonintegral": bi, "negative": neg,
                "positive": sum(x > 0 for x in a.values()),
                "seconds": time.time() - started,
            }
            out.append(record)
            print(json.dumps(record), flush=True)
            (HERE / "mobius_checks_rank3_deep.json").write_text(json.dumps({
                "results": out, "seconds": time.time() - started,
            }, indent=2))
