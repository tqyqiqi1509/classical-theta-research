"""Exact stress checks for theta Gauss congruences and Mobius positivity.

The coefficient engine is the prior package's IncomingSchur implementation.
These computations test the new arithmetic claims; they do not prove that
engine's identification with GHKK theta functions.
"""
from pathlib import Path
from itertools import product
from math import gcd
import argparse
import json
import random
import sys
import time

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parents[1] / "history/Higher_Rank_Greedy_Theta_total/Higher_Rank_Greedy_Theta/agents"
sys.path.insert(0, str(ENGINE))
from incoming_recursion import IncomingSchur


def mobius(n):
    answer = 1
    d = 2
    while d * d <= n:
        if n % d == 0:
            n //= d
            answer = -answer
            if n % d == 0:
                return 0
            while n % d == 0:
                n //= d
        d += 1
    return -answer if n > 1 else answer


def primitive_prefix(engine, g, n, cap):
    numerator = {}
    for d in range(1, n + 1):
        if n % d:
            continue
        mu = mobius(d)
        if not mu:
            continue
        prefix = engine.theta_prefix(tuple(n // d * x for x in g),
                                     tuple(c // d for c in cap))
        for q, a in prefix.items():
            p = tuple(d * x for x in q)
            numerator[p] = numerator.get(p, 0) + mu * a
    bad_int = [(q, a) for q, a in numerator.items() if a % n]
    negative = [(q, a) for q, a in numerator.items() if a < 0]
    return numerator, bad_int, negative


def run(deep=False):
    started = time.time()
    records = []
    failures = []
    rng = random.Random(261114)
    seeds = [
        ([[0, 2], [-2, 0]], [1, 1], "kronecker2"),
        ([[0, 3], [-3, 0]], [1, 1], "wild3"),
        ([[0, 3], [-2, 0]], [2, 3], "valued32"),
        ([[0, 2, -2], [-2, 0, 2], [2, -2, 0]], [1, 1, 1], "markov2"),
        ([[0, 2, -2], [-1, 0, 1], [2, -2, 0]], [1, 2, 1], "valuedcycle"),
    ]
    for B, D, name in seeds:
        R = IncomingSchur(B, D)
        rank = len(D)
        if rank == 2:
            gs = list(product(range(-3, 4), repeat=2)) if not deep else [(-1, 1), (-2, 1), (-1, 2)]
            cap = (3, 3) if not deep else (6, 6)
        else:
            gs = [tuple(rng.randrange(-4, 5) for _ in D) for _ in range(60)]
            cap = (2,) * rank
            if deep:
                continue
        rec = {"name": name, "B": B, "D": D, "labels": len(gs),
               "cap": cap, "coefficient_checks": 0, "positive": 0,
               "zero": 0, "largest_coefficient": 0}
        for n in (6, 10, 12):
            for g in gs:
                numerator, bad_int, negative = primitive_prefix(R, g, n, cap)
                rec["coefficient_checks"] += len(list(product(*(range(c + 1) for c in cap))))
                rec["positive"] += sum(a > 0 for a in numerator.values())
                rec["zero"] += sum(a == 0 for a in numerator.values())
                rec["largest_coefficient"] = max(rec["largest_coefficient"], max(numerator.values(), default=0) // n)
                if bad_int or negative:
                    failures.append({"seed": name, "n": n, "g": g,
                                     "nonintegral": bad_int, "negative": negative})
        rec["cache"] = str(R.c.cache_info())
        records.append(rec)
        print(json.dumps(rec), flush=True)
    output = {"status": "FAIL" if failures else "PASS",
              "deep": deep, "records": records, "failures": failures,
              "seconds": time.time() - started}
    name = "mobius_checks_deep.json" if deep else "mobius_checks.json"
    (HERE / name).write_text(json.dumps(output, ensure_ascii=False, indent=2))
    print(json.dumps({"status": output["status"], "seconds": output["seconds"],
                      "output": str(HERE / name)}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--deep", action="store_true")
    run(parser.parse_args().deep)
