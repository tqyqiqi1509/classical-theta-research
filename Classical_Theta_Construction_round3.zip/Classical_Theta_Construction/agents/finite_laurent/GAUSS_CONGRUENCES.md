# Prime-power Gauss congruences for classical cluster theta functions

Status: full proposed proof, independently checked at the proof-skeleton level by the parent agent; requires a fresh detailed mathematical review before being announced as a new theorem. The prime-modulus case is already Mandel's Theorem 4.2. Novelty of the higher prime-power statement remains a literature-search claim, not a priority claim.

## 1. Statement and scope

Fix a classical skew-symmetrizable cluster seed and its principal-coefficient scattering diagram. Let

\[
\vartheta_{g,Q}(x,y)=x^gF_{g,Q}(z),\qquad
z_i=y_i x^{Be_i},\qquad
F_{g,Q}(z)=\sum_{q\in\mathbb N^n}a_{g,Q}(q)z^q.
\]

Here the full monomial lattice is the principal-coefficient lattice \(L\), not merely the mutable \(g\)-lattice. In an integral seed basis it is \(\mathbb Z^n\oplus\mathbb Z^n\), and a monomial in the displayed expansion has full exponent \((g+Bq,q)\). For skew-symmetrizable seeds the basis is the integral basis of \(M^\circ\oplus N\); using that basis is essential.

The assertion is coefficientwise in the positive-root completion. It applies to formal theta series for all integral labels. It does **not** assert that all these series are finite Laurent polynomials. If the label is in the regular theta set \(\Theta\), the same assertions are identities/congruences of finite Laurent polynomials.

Write \(\psi_d(Z^m)=Z^{dm}\) for the integral monomial-substitution operation on the completed group algebra of \(L\). It fixes integer coefficients. For every prime \(\ell\), every \(r\geq1\), every integral label \(g\), and every common generic endpoint \(Q\), the proposed theorem is

\[
\boxed{\vartheta_{\ell^r g,Q}\equiv
\psi_\ell(\vartheta_{\ell^{r-1}g,Q})\pmod {\ell^r}.}\tag{G}
\]

Equivalently,

\[
F_{\ell^r g,Q}(z)\equiv F_{\ell^{r-1}g,Q}(z^\ell)
\pmod {\ell^r}.\tag{G-F}
\]

No restriction \(\ell\nmid d_i\) is needed. The proof uses classical integral wall functions and the integral normal lattice, and uses neither quantum positivity nor a root-of-unity specialization. The prime \(2\) is included.

More generally, replacing \(g\) by \(m g\) gives

\[
F_{ng,Q}(z)\equiv F_{(n/\ell)g,Q}(z^\ell)
\pmod{\ell^{v_\ell(n)}}\qquad(\ell\mid n).\tag{G-n}
\]

## 2. Established inputs and exact overlap with literature

1. GHKK, *Canonical bases for cluster algebras*, Remark 1.27 and Theorem 1.28 in the author PDF, give integral classical wall functions and the wall action \(Z^m\mapsto Z^m f^{\langle n,m\rangle}\), with \(n\) in the integral normal lattice. The same theorem handles skew-symmetrizable seeds. Principal coefficients make the positive-root monoid sharp and its injection into the full monomial lattice explicit.
2. GHKK, Proposition 3.4, gives coefficientwise finite broken-line sums. Definition-Lemma 6.2 and Proposition 6.4 give the multiplication rule by endpoints sufficiently close to the **output** label.
3. Mandel, *Scattering diagrams, theta functions, and refined tropical curve counts*, arXiv:1503.06183v5, Theorem 4.2, proves \(\vartheta_g^\ell\equiv\vartheta_{\ell g}\pmod\ell\). By the freshman's dream this is exactly (G) when \(r=1\). The proof there compares scaled broken lines modulo a prime. It does not state (G) for higher prime powers.

The additional mechanism below tracks the loss of divisibility in every intermediate full lattice exponent. A local error can have a smaller modulus than the desired global modulus, but the accumulated prefix weight supplies exactly the missing power. The argument therefore does more than iterate the prime-modulus theorem, which by itself does not increase the modulus.

URLs:

- https://paulhacking.github.io/canonicalbases.pdf
- https://arxiv.org/html/1503.06183v5

Relevant web retrieval IDs in this agent's context: `turn52view1`, `turn53view1`, `turn54view0`, `turn54view1`, `turn54view2`, `turn52view0`, `turn53view0`. The parent must reopen a source before citing it in the final response.

## 3. Two elementary integral-series lemmas

Let \(f(t)\in1+t\mathbb Z[[t]]\), \(a\in\mathbb Z_{>0}\), and use \(v_\ell(0)=+\infty\).

### Lemma 3.1: a local valuation loss bound

For every \(j\geq1\),

\[
v_\ell([t^j]f(t)^a)\geq
\max\{0,v_\ell(a)-v_\ell(j)\}.\tag{L1}
\]

Indeed, differentiation in \(\mathbb Z[[t]]\) gives

\[
j[t^j]f(t)^a
=a[t^{j-1}]f'(t)f(t)^{a-1}.
\]

The rightmost coefficient is an integer. The inequality follows. This argument includes the cases where the coefficient is zero. For \(j=0\) the coefficient is one, and no exponent change occurs.

### Lemma 3.2: a local Frobenius error bound

For every \(a\geq1\),

\[
f(t)^{\ell a}-f(t^\ell)^a
\in\ell^{1+v_\ell(a)}\mathbb Z[[t]].\tag{L2}
\]

The coefficientwise freshman's dream gives an integral series \(h(t)\) such that

\[
f(t)^\ell=f(t^\ell)+\ell h(t).
\]

In the binomial expansion of its \(a\)-th power, the term indexed by \(1\leq k\leq a\) contains \(\ell^k\binom ak\). The identity

\[
k\binom ak=a\binom{a-1}{k-1}
\]

implies

\[
v_\ell\!\left(\ell^k\binom ak\right)
\geq k+v_\ell(a)-v_\ell(k)
\geq1+v_\ell(a).
\]

The final inequality holds for every prime, including \(\ell=2\), since \(v_\ell(k)\leq k-1\). Thus every term has the required divisibility. In particular,

\[
[t^{\ell j}]f(t)^{\ell a}-[t^j]f(t)^a
\equiv0\pmod{\ell^{1+v_\ell(a)}}.\tag{L2-coeff}
\]

If \(a=0\), both powers are one and their difference is zero; these crossings need no valuation convention for \(a\).

Neither lemma assumes coefficient positivity. The case \(f=1\) is immediate and is included.

## 4. Integral local model, including nonprimitive wall roots

At a generic crossing, combine walls supported on the same local hyperplane if necessary. The broken-line transition has the form

\[
A Z^m\longmapsto
A [t^j]f(t)^a\, Z^{m+jv},
\qquad a=\lambda(m)>0,\tag{W}
\]

where \(\lambda\in L^*\) is an integral normal (or an integral positive multiple of one), \(v\in L\) is primitive, \(\lambda(v)=0\), and \(f\in1+t\mathbb Z[[t]]\). The orientation is chosen according to the crossing; because the broken-line velocity is \(-m\), its wall-crossing exponent is positive.

There is no primitivity assumption on the root attached to the original wall. If its monomial direction is \(w=h v\) with primitive \(v\), write the original series as a series in \(t=Z^v\), inserting zero coefficients in degrees not divisible by \(h\). For example, \((1+Z^w)^c\) becomes \((1+t^h)^c\). The integral normal \(\lambda\) is kept unchanged. This is merely a change of the one-variable notation, so it introduces no denominators and does not change the wall action.

For principal coefficients, the wall direction has the form \((Bn,n)\). If it is divisible by \(h\) in \(L\), its frozen component shows that \(n\) is also divisible by \(h\). Thus the primitive direction is again an integral positive-root direction. Every nonzero bend increases the positive-root degree. This will ensure finite bookkeeping at a prescribed output degree.

For skew-symmetrizable data, the relevant fact is \(\lambda\in\operatorname{Hom}(M^\circ\oplus N,\mathbb Z)\), not that a normal written in a nonintegral ambient basis has integer coordinates. If \(m\in\ell^sL\), then \(\lambda(m)\in\ell^s\mathbb Z\), even when \(\ell\mid d_i\).

## 5. Prefix divisibility invariant

For \(m\in L\), put

\[
s(m)=\max\{s\geq0:m\in\ell^sL\},\qquad s(0)=+\infty.
\]

Suppose a broken line begins with exponent \(\ell^r g\). At every segment let \(A\) be its accumulated integer coefficient and \(m\) its full exponent. Then

\[
\boxed{v_\ell(A)+s(m)\geq r.}\tag{P}
\]

Initially \(A=1\) and \(s(\ell^rg)\geq r\). For an induction step write \(m'=m+jv\), with \(s=s(m)\) and \(t=s(m')\). If \(t\geq s\), multiplying \(A\) by an integer preserves the inequality. If \(t<s\), then primitiveness of \(v\) gives

\[
v_\ell(j)=t.
\]

Indeed, \(m\) is divisible by \(\ell^{t+1}\), whereas \(m'\) is divisible by \(\ell^t\) and not by \(\ell^{t+1}\); hence the same is true of \(jv=m'-m\), and a primitive vector has \(\ell\)-valuation zero. Since \(a=\lambda(m)\), we have \(v_\ell(a)\geq s\). Lemma 3.1 therefore gives

\[
v_\ell([t^j]f(t)^a)\geq s-t,
\]

which supplies the lost divisibility. This proves (P). A zero prefix weight causes no problem: its valuation is infinite.

Consequently, if any segment exponent fails to lie in \(\ell L\), the final weight of that broken line is divisible by \(\ell^r\). Subsequent bends multiply by integers and cannot undo this divisibility. These broken lines can be discarded modulo \(\ell^r\), even if their final exponent later returns to \(\ell L\).

## 6. Comparison of the remaining paths

Retain only broken lines all of whose full segment exponents lie in \(\ell L\). Every bend increment is then \(\ell\)-divisible. Because the one-variable wall direction \(v\) is primitive, its bend index is also \(\ell\)-divisible.

Divide every segment exponent and every bend index by \(\ell\). This preserves the geometric image of the path after reparametrization: if the original path is \(\gamma(t)\), the divided path is \(\delta(t)=\gamma(t/\ell)\). It has the same endpoint \(Q\), the same wall crossings, and initial exponent \(\ell^{r-1}g\). Conversely, multiplying the exponents of a lower path by \(\ell\) preserves its geometric image after the inverse reparametrization.

Some divided local coefficients can be zero although the original coefficient is nonzero. For this reason the comparison is made on **potential geometric skeletons**: a skeleton records the walls, segment exponents, and bend indices satisfying the geometry, and is assigned its product of local coefficients, which is allowed to be zero. The finite union of the upper skeletons and scaled lower skeletons is enough. This avoids assuming a bijection between nonzero-weight broken lines.

Fix a lower skeleton. Immediately before its \(j\)-th bend its full exponent is \(m_j\); write \(s_j=s(m_j)\). Its local weight is

\[
b_j=[t^{u_j}]f_j(t)^{a_j},\qquad a_j=\lambda_j(m_j)>0.
\]

The corresponding upper local weight is

\[
B_j=[t^{\ell u_j}]f_j(t)^{\ell a_j}.
\]

Lemma 3.2 yields

\[
v_\ell(B_j-b_j)\geq1+v_\ell(a_j)\geq1+s_j.\tag{E}
\]

By the prefix invariant applied to the upper skeleton, whose initial exponent is \(\ell^rg\) and whose exponent before this bend is \(\ell m_j\),

\[
v_\ell\left(\prod_{i<j}B_i\right)
\geq\max\{0,r-1-s_j\}.\tag{U}
\]

The elementary telescoping identity

\[
\prod_{j=1}^N B_j-\prod_{j=1}^N b_j
=\sum_{j=1}^N
\left(\prod_{i<j}B_i\right)(B_j-b_j)
\left(\prod_{i>j}b_i\right)
\]

and (E), (U) show that every summand has valuation at least

\[
\max\{0,r-1-s_j\}+1+s_j\geq r.
\]

Thus paired skeleton weights agree modulo \(\ell^r\). This proof remains valid when either weight is zero. Crossings with no bend have local coefficient one on both sides and may simply be omitted from the list.

## 7. Coefficientwise finiteness and conclusion

Fix an output root degree \(q\) for the upper theta series, or any finite root-degree cutoff containing it. Each nontrivial bend has a nonzero positive root increment, so the number of bends is bounded by the total degree. Only finitely many walls are nontrivial to this cutoff, and only finitely many possible segment monomial decorations occur. For a generic endpoint these data give the usual finite broken-line sum (GHKK, Proposition 3.4). The enlarged skeleton list used above is also finite: it is the union of two such finite lists after scaling.

If the upper output exponent is not in \(\ell L\), every contributing path has a nondivisible final segment and therefore weight zero modulo \(\ell^r\) by (P). If it is in \(\ell L\), discard paths that ever leave \(\ell L\), pair the remaining skeletons as in Section 6, and sum their congruences. The result is exactly (G). Since this argument applies to every prescribed coefficient, it proves the formal series congruence without asserting finite Laurent support.

## 8. Structure constants

For a tuple \(\mathbf g=(g_1,\ldots,g_s)\), define the principal-coefficient structure series by

\[
\prod_{i=1}^s\vartheta_{g_i}
=\sum_{q\in\mathbb N^n}c_{\mathbf g}(q)\,y^q
\vartheta_{g_1+\cdots+g_s+Bq}.
\]

The sums are interpreted coefficientwise in the formal completion; regular labels give the usual finite multiplication in the middle algebra. The analogous congruence is

\[
\boxed{c_{\ell^r\mathbf g}(q)\equiv
\begin{cases}
c_{\ell^{r-1}\mathbf g}(q/\ell),&q\in\ell\mathbb N^n,\\
0,&q\notin\ell\mathbb N^n
\end{cases}
\pmod{\ell^r}.}\tag{G-mult}
\]

Here is the necessary endpoint justification. By GHKK's multiplication rule, the coefficient for an output full label

\[
R=(\ell^r\textstyle\sum_i g_i+Bq,q)
\]

is the coefficient of \(Z^R\) in the product of the input theta series evaluated at a generic endpoint sufficiently close to \(R\), to the finite degree under consideration. Apply (G) to every input at that same endpoint. If \(R\notin\ell L\), the substituted product has coefficient zero at \(R\).

If \(q=\ell q'\), then \(R=\ell R'\), where

\[
R'=(\ell^{r-1}\textstyle\sum_i g_i+Bq',q').
\]

Choose a generic \(Q'\) sufficiently close to \(R'\), simultaneously for the finite lower and upper cutoffs, and take \(Q=\ell Q'\). Cluster scattering walls are cones, so radial scaling of the endpoint does not change the coefficients of the theta expansion. The lower coefficient at \(Q\) is therefore the lower coefficient at \(Q'\), and the multiplication rule identifies it with \(c_{\ell^{r-1}\mathbf g}(q')\). This gives (G-mult). The same endpoint argument works for any finite number of factors, or follows by the standard multiple-broken-line version of the rule.

It would be incorrect to extract a structure constant from the product at an arbitrary fixed chamber endpoint. The output-dependent endpoint in this proof is essential.

## 9. Exact elementary divisors

For \(q=(q_1,\ldots,q_n)\), write \(\gcd(N,q)=\gcd(N,q_1,\ldots,q_n)\). The prefix invariant, or repeated use of (G), gives

\[
\boxed{\frac{N}{\gcd(N,q)}\mid a_{Ng,Q}(q).}\tag{D}
\]

For \(q=0\) the divisor is one. For \(q\neq0\), fix \(\ell^r\Vert N\) and put \(t=\min_i v_\ell(q_i)\). If \(t<r\), the full final exponent \((Ng+Bq,q)\) has valuation exactly \(t\): the frozen part has valuation \(t\), and the mutable part is divisible by \(\ell^t\). Invariant (P) gives divisibility by \(\ell^{r-t}\) path by path. Multiplying these prime-power divisors proves (D).

The same divisor divides \(c_{N\mathbf g}(q)\), by repeatedly applying (G-mult) until the root degree is no longer divisible by \(\ell\).

## 10. Integral Möbius primitive functions

Define

\[
\boxed{K_{N,g}:=\frac1N\sum_{d\mid N}\mu(d)\,
\psi_d(\vartheta_{(N/d)g}).}\tag{K}
\]

Then \(K_{N,g}\) has **integer coefficients** in the same completed Laurent algebra. Equivalently,

\[
K_{N,g}=x^{Ng}P_{N,g}(z),\qquad
P_{N,g}(z)=\frac1N\sum_{d\mid N}\mu(d)F_{(N/d)g}(z^d)
\in\mathbb Z[[z]].\tag{K-F}
\]

Proof: for \(\ell^r\Vert N\), write \(N=\ell^r m\) with \(\ell\nmid m\). Group divisors with nonzero Möbius value as \(e\) and \(\ell e\), where \(e\mid m\). The numerator of (K) becomes

\[
\sum_{e\mid m}\mu(e)\psi_e\left(
\vartheta_{(N/e)g}-
\psi_\ell(\vartheta_{(N/(\ell e))g})\right).
\]

Each parenthesis is divisible by \(\ell^r\) by (G-n), and monomial substitution preserves that divisibility. This holds for every prime dividing \(N\), so the numerator is divisible by \(N\).

When \(g\in\Theta\), all positive multiples of \(g\) are in \(\Theta\), and (K) is a finite integral Laurent polynomial in the chosen seed. The conclusion of this section is integrality only. The companion note `MOBIUS_POSITIVITY.md` now gives a separate positive-decoration proof of coefficientwise nonnegativity. The operation \(\psi_d\) is seedwise, so (K) itself is not asserted to define a mutation-invariant global function.

For a fixed root degree \(p\), the diagonal sequences

\[
b_N=a_{Ng}(Np)\quad\hbox{and}\quad
b_N=c_{N\mathbf g}(Np)
\]

satisfy the usual Gauss congruences \(b_N\equiv b_{N/\ell}\pmod{\ell^{v_\ell(N)}}\). Hence

\[
\frac1N\sum_{d\mid N}\mu(N/d)b_d\in\mathbb Z.
\]

Again, this does not claim these integers are nonnegative.

## 11. Computational checks already completed

- The local series lemma (L2) was checked with the Wolfram Language evaluator for 256 exact polynomial/exponent/prime cases, including \(\ell=2\) and a polynomial with a negative coefficient. No failures occurred. The proof in Section 3 is independent of these checks.
- The prior package's independent incoming-Schur implementation checked (G-F) modulo four at 2,666 prescribed coefficients over rank-two symmetric/valued seeds and rank-three cyclic/valued seeds. No failures occurred. These are a consistency check using the prior computational formula, not a replacement for the present proof.
- Separate dilation tests at 2,481 nonzero coefficients found no counterexample to a stronger coefficient inequality \(a_{2g}(2p)\geq a_g(p)^2\), but that inequality is **unproved** and is not used anywhere in this note.

The reproducible script and further Möbius-positivity stress results will be stored next to this note. Negative or inconclusive results must be retained.

## 12. Remaining review questions

1. Verify that the potential-skeleton construction includes every contribution at the chosen finite cutoff, particularly in the nonprimitive-root notation. The proof deliberately permits zero weights on either side.
2. Verify the integral-lattice convention for every intended skew-symmetrizable application. The proof does not permit treating a rational coordinate lattice as integral.
3. Check the structure-constant extension against the output-dependent endpoint convention; it must not be replaced by an arbitrary common endpoint.
4. Search for earlier prime-power, Gauss, Witt, Dold, necklace, or integral multiple-cover statements for cluster theta functions. The known Mandel prime-modulus theorem must be credited prominently.
5. Audit the separate cyclic-word mechanism in `MOBIUS_POSITIVITY.md`; positivity cannot be inferred from integrality alone. That note also distinguishes seedwise primitive functions from the intrinsically defined complete-symmetric theta functions.
