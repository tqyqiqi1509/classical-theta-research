# Finite-Laurent / arithmetic branch: literature and route log

Date: 2026-11-13 UTC (2026-11-14 in the user's working timezone). Work began about 17:10 UTC. This is one agent's branch, not a claim that the full requested nine-hour session has elapsed.

## Literature audit

| Source | Checked content | Decision / relevance |
|---|---|---|
| GHKK, *Canonical bases for cluster algebras*, author PDF | Remark 1.27; Theorem 1.28; Proposition 3.4; Definition-Lemma 6.2; Proposition 6.4; Theorem 7.5 and its saturation proof; relevant distinction between \(\Theta\) and all integral labels | Accepted established inputs: integral positive classical walls, coefficientwise finite broken-line sums, output-dependent endpoint multiplication, regular-label saturation. The support-dilation idea is already in the saturation proof and cannot be claimed new. No quantum assertion is used. |
| Qin, *Bases for upper cluster algebras and tropical points*, arXiv:1902.09507v4 | Injective reachability and green-to-red relation; support-dimension vector and compatible pointedness in Section 3.4; basis theorem in Section 5 | Accepted as an established finite box in its stated injective-reachable hypotheses. Already used in the prior package. Stopped this duplication route. |
| Reading–Stella, *Mutation of Theta Functions*, arXiv:2603.19391v4, SIGMA 22 (2026), 109 | Latest v4/published identity checked; Sections 3.1–3.2 and relevant claims in Sections 5.3–5.5 read | Strong targeted audit of the finite-vs-formal distinction: the small canonical algebra is not an assertion that every formal theta is Laurent finite. Theorems 5.4/5.7 concern dominance/product restrictions, and Theorem 5.14 has additional hypotheses. No unreviewed global theorem from this 2026 paper is used in our arithmetic proof. |
| Mandel, *Scattering diagrams, theta functions, and refined tropical curve counts*, arXiv:1503.06183v5 | Section 4.3, Theorems 4.1–4.3, including the complete proof of classical Theorem 4.2 | Crucial predecessor: prime-modulus Frobenius is known. Our proposed new modulus is \(\ell^r\) for input scale \(\ell^r\). The quantum theorem has odd-root and symmetrizer conditions; it was not used. |
| Moree, *The formal series Witt transform*, arXiv:math/0311194v2, Discrete Mathematics 295 (2005), 143–160 | Definition 1, Theorems 2–4, circular-word proof framework | Exact predecessor for ordinary Witt transforms of powers of one fixed series. On multiplicative theta rays our construction reduces to this known theory. General nonmultiplicative theta rays require the additional skeleton argument. |
| Mandel–Qin, *Bracelets bases are theta bases*, arXiv:2301.11101v3 | Section 4.2: band definition as permutation average, Chebyshev first/second kind; Section A.1 classical skew-symmetrizable conventions | Establishes that the complete-symmetric operation is already the familiar band construction on a simple loop ray. That overlap must be credited. Full arbitrary-seed generalization is the issue; no claim that band itself is new. |
| Qin–Shen, *Band bases as common triangular bases in cluster algebras from surfaces*, arXiv:2606.02164v2 | Author homepage cross-check; official PDF downloaded; introduction, Theorem 1.3 statement, Definition 2.3 read | 2026 strong review still incomplete. The theorem concerns unpunctured surfaces. The necklace language concerns smoothing unknots/strip operations, and is not by itself the cyclic-word argument used here. Do not admit Theorem 1.3 as a verified proof input before the next agent audits it. Full PDF/TXT passed to parent. |
| LLZ, *Greedy elements in rank 2 cluster algebras*, arXiv:1208.2391v3 | Definition 1.3, Proposition 1.6 and coefficient convention | Accepted for an independent exact verification of the general Schur counterexample family. |
| Cheung et al., *The greedy basis equals the theta basis*, arXiv:1508.01404v2 | Theorems 1.1/5.1, Section 4 and Remark 4.5 | Accepted for rank-two theta/greedy identity and the sign-checked \(g\)-to-\(d\) conversion in `SCHUR_BOUNDARY.md`. |
| Qiyue, Hexagon 2610.00201, quantum finite-theta paper | Abstract/provenance only | Not admitted as a proof input. Quantum subject is outside this branch's classical scope. |
| Qiyue, *Positive polytopes and full Fock–Goncharov*, Nov. 2, 2026, Valency work page | Abstract only; prior package's gauge caveat compared | Not admitted as a proof input. A positive polytope does not silently supply the separate along-broken-line convexity hypothesis required by the prior gauge argument. |
| Li Fang / Pan Jie polytope-basis work | No theorem imported | Excluded as requested. |

## Search checkpoints and outcomes

- Initial finite-support searches: reddening, injective reachability, generic bases, finite theta support, Reading–Stella latest version. Outcome: the injective carrier and Qin box already occurred in the previous package. The route was stopped promptly instead of being repackaged.
- Rational cluster-vector certificates: GHKK saturation proof reread. Outcome: a modest effective certificate with exact sparse support pullback and coefficient upper bounds; documented with its limited existence domain.
- Arithmetic novelty searches: `theta functions Gauss congruences`, `cluster theta congruences`, `theta prime powers Frobenius cluster`, `scattering diagrams Gauss congruence`, `cluster Dwork congruences`, `scattering p-adic theta`, `theta functions mod p^r cluster`. Outcome: most hits concerned unrelated analytic theta functions; Mandel's prime-modulus theorem was found and read. No higher prime-power predecessor was located in the checked sources.
- About twenty minutes into the branch, expanded searches to `cluster theta necklace Witt vectors Möbius positivity`, `broken lines Möbius theta`, `cluster primitive Frobenius theta`. Outcome: Moree's old formal Witt transform and classical necklace theory are directly relevant antecedents. The ordinary transform is not new; the theta-ray extension remains to be checked broadly.
- Subsequent searches: `theta band symmetric`, `theta bracelets bands basis`, `Band bases as common triangular bases Qin Shen`. Outcome: the surface band interpretation is old and the 2026 Qin–Shen paper must be reviewed before using its new triangular-basis theorem. The general Schur extension was then tested and disproved, not silently assumed.

Negative search results do not prove priority. The parent should phrase novelty as “no equivalent general statement was found in the checked literature,” pending a wider specialist check.

## Route outcomes

| Route | Outcome | Reason / next mathematical step |
|---|---|---|
| Reprove injective product support bound | Stopped as duplicate | Prior `valued_young_functor_reddening.md`, Sections 8–9, already contains the mechanism and the sharper Qin support box. |
| Claim finite Laurent polynomial for every formal label | Rejected as unsupported | Formal theta labels, \(\Theta\), and ordinary/middle/upper algebras must remain distinct. Reading–Stella does not close this gap. |
| Label-specific rational carrier | Proved conditionally on explicit finite certificate | Provides exact sparse set \(\{p:kp\in\operatorname{supp}H\}\), upper coefficient bounds, and a terminating algorithm on that certificate domain. |
| Strong diagonal inequality \(a_{kg}(kp)\geq a_g(p)^k\) | Unproved; not used | Pathwise scaling controls \(\sum_\gamma w(\gamma)^k\), not the cross terms. Computation is not a proof. |
| Prime-power theorem from quantum Frobenius | Not pursued | Quantum parameter scaling and different root-of-unity orders do not automatically align; would also introduce unnecessary restrictions on primes and \(D\). |
| Classical prefix-valuation compensation | Full proposed proof | Local derivative bound plus full-lattice divisibility supplies the exact missing modulus at every bend. Fresh adversarial reviewer is checking it. |
| Möbius primitive positivity | Full proposed proof | Group by scaled geometry; cyclic action on positive local words counts the numerator. Integrality comes from the prime-power theorem. |
| Global interpretation of seedwise \(K\) | Corrected | Monomial substitution does not commute with mutation. \(K\) is chartwise; \(H\), defined using actual theta functions, is intrinsic. |
| Complete-symmetric \(H_{N,g}\) | Proved from the proposed arithmetic theorem | Integral theta-positive elements by Euler product and unitriangularity; overlaps with surface bands on simple-loop rays. No basis or triangular-basis identification in general. |
| General Schur positivity | Disproved | Infinite family \(B=\left(\begin{smallmatrix}0&m\\-m&0\end{smallmatrix}\right),m\geq3,g=(-1,1)\): the \(E_3\) coefficient at \(x^{3g}z_1z_2\) equals \(-1\). Independently verified from LLZ. |

## Source locations for handoff

- GHKK: https://paulhacking.github.io/canonicalbases.pdf
- Qin: https://arxiv.org/html/1902.09507v4
- Reading–Stella: https://arxiv.org/html/2603.19391v4 and https://sigma-journal.com/2026/109/
- Mandel: https://arxiv.org/html/1503.06183v5
- Moree: https://arxiv.org/html/math/0311194v2
- Mandel–Qin: https://arxiv.org/html/2301.11101v3
- Qin–Shen: https://arxiv.org/pdf/2606.02164v2 ; author confirmation https://sites.google.com/site/qinfanmath/
- LLZ: https://arxiv.org/html/1208.2391v3
- Rank-two theta/greedy: https://arxiv.org/html/1508.01404v2

The original source PDFs in `sources/` are working references, not authored deliverables. The final research ZIP can cite them by URL without redistributing complete third-party papers.
