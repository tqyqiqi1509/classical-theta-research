# Handoff after the analytic convex-body round

2026-11-13. Main proofs are in `ANALYTIC_STABLE_LOG_BODY.md` and `WALL_CURVATURE_AND_EXPOSED_FACES.md`. The two comparison reviews both pass.

## Completed general mechanisms

1. Coarse negative factors are actual one-segment endpoint transports, including arbitrary real labels by a positive zero-root perturbation and uniform analytic tails. This supplies one label-independent analytic domain.
2. Positive wall germs give positive full real bends. Polynomially many finite-order root hyperplanes times a geometric analytic tail makes all negative truncation curvature disappear. The support body realizes the entire inverse-limit fan.
3. Each finite scattering polytope is a scaled Minkowski summand of this naturally evaluated body. This yields a strict global fan comparison, not only generic-facet positivity.
4. Finite theta data give polytopes with certified geometric Hausdorff convergence to the transport body.
5. The new curvature note upgrades convergence to total variation of the distributional Hessians. Its locally absolutely convergent wall formula rules out a Cantor residual. It also proves differentiability at every root-generic label and identifies each exposed face with the transported coarse zero-group body. At a single-wall direction the face is an explicit segment of length `||nu|| log f(Tz)`.
6. The real ray-growth function dominates the stable logarithm. The fixed-label exponential flat comparison and the uniform stretched-exponential body comparison were independently checked including all floors and constants.

## Phi=L routes considered; no identification asserted

### Fixed-label linear stabilization

A genuine O(degree) threshold would imply equality on an explicit sufficiently small ball by the same Cauchy argument. The existing O(degree^2) sign estimate does not provide this. Near a root hyperplane, integer pairings can be one while root size is large, so its quadratic estimate cannot be improved merely by replacing one norm inequality. One possible mechanism would show that a sign-changing wall can actually contribute only after at least `n lambda_g(a)+1` repetitions of its charge, using finite positive binomial exponents. No such broken-line or global-factor theorem was established. A geometric sign change alone must not be counted as an actual contribution.

### Framing copies / connected components

The novelty agent verified Reineke's fixed-stability powers: multiplying the framing vector multiplies the fixed-slope generating function by an exact power, with a forest decomposition in the zero-stability case. This is relevant but not an identification of theta_(ng): its extraction stability depends on the final exponent `ng+Bp`. The missing mechanism must control that moving stability. The factorial Bezout majorant is an upper bound by functional digraphs; it does not identify actual theta coefficients with that graph species, so its connected-component exponential formula cannot be transferred without proof.

### A common complex zero-free domain

If all F_(ng) have a common zero-free disc around the principal central point, their normalized holomorphic logarithms are locally bounded by the scalar majorant and Borel--Caratheodory. Coefficientwise stabilization then forces every normal-family limit to be log H_g, proving Phi=L. The novelty agent wrote this sufficient lemma independently. Positivity on the positive real locus and the existing exponential-in-n upper bound do not supply a zero-free complex disc.

### Rational ray generating functions

A rational recurrence with one nonzero dominant unit branch near z=0 could identify H_g as the exponential growth root. The novelty agent checked Arkani-Hamed--Lam--Spradlin: rationality is an assumption in their definition of ray poles, not a general theorem. Thus this is an interface, not an available proof. Existing Fekete gives the radius `exp(-Phi_z(g))` of the numerical ray generating series, but does not identify it with `H_g(z)^(-1)`.

No counterexample to Phi=L was found or claimed. The fixed-positive-epsilon Hausdorff approximation to the scaling body retains the possible flat error floor. Only the transport body is currently proved to be the geometric N-to-infinity limit of Q_N.

## Suggested fresh review focus

The zero-group face formula in Section 8 of the curvature note is the newest part. Its directional-derivative proof deliberately integrates the uniformly bounded gradient limit along a generic line; dividing the bare coefficient-tail error by the displacement would be invalid. Higher-codimension zero groups are allowed to be noncommutative throughout.
