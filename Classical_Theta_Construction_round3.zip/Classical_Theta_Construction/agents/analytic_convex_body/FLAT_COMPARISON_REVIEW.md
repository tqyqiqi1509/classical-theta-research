# Independent audit of the exponentially flat comparison

2026-11-13. Reviewer: analytic_convex_body. Reviewed file: `../../notes/FG_PAIRING_FLAT_COMPARISON.md`.

## Verdict

**PASS, conditional only on the explicitly cited stable-ray threshold and common analytic majorant/path theorems. No constant correction is needed.** In particular, the numerical choice of degree, its floor, and the extra `+1` in the ray multiplier all satisfy the claimed exponent. The argument compares actual convergent functions and does not exchange a formal coefficient limit with a real limit.

The inequality `L <= Phi` is independently proved in Section 9 of `ANALYTIC_STABLE_LOG_BODY.md`. Its endpoint limit is a limit only of the scalar transport factor; it does not require a boundary value of the endpoint theta function. Uniform one-segment convergence keeps each transformed positive point inside the theta convergence ball and makes the scalar limit legitimate.

## 1. Analytic and majorant estimates

Let `h=log 2`, `G=||g||_infinity`, `S=sum v_i`, and use the constants `R,M_H,A,rho_0` defined in the reviewed note. Since `log H_g(0)=0`, Cauchy's coefficient estimates on the closed radius-R disc give

    |log H_g(sv)| <= M_H rho/(R-rho)
                   <= 2 M_H rho/R,     |s|<=rho<=R/2.

The radius R lies strictly inside the common path domain, so the use of a closed Cauchy circle is valid. Thus `|H_g(sv)^n|<=exp(A n rho)`.

For `rho C S<=1/4`, the small nonnegative solution of `t=rho S exp(Ct)` obeys `t<=2rho S` and `1-Ct>=1/2`. Indeed `t exp(-Ct)` is increasing on `[0,1/C]`, and at `t=2rho S` its value is at least `2rho S exp(-1/2)>rho S`. The scalar digraph majorant therefore gives

    |F_ng(sv)| <= exp(n G t)/(1-Ct)
                <= 2 exp(2 n G S rho)
                <= 2 exp(A n rho).

It follows that `|F_ng-H_g^n|<=3exp(A n rho)`. The argument is uniform over the complex disc and hence supports the subsequent maximum-principle step.

## 2. Exact use of stabilization

The chosen integer symmetrizer makes `M=max |D_i B_ij|` a nonnegative integer. With

    n=M d^2+1,

one has strictly `n>M d^2`. The stable-ray theorem consequently makes `F_ng(sv)-H_g(sv)^n` vanish to order at least `d+1`. Dividing by `s^(d+1)` and applying the maximum principle at radius `rho=2epsilon` proves

    |F_ng(epsilon v)-H_g(epsilon v)^n|
      <=3 exp(2 A n epsilon) 2^(-d-1).

There is no assumption that the two series agree beyond this finite degree. The construction remains valid when M=0, in which case n=1.

At the positive evaluation, `F_ng>=H_g^n>0`. Also the same radial bound at radius epsilon gives `H_g^n>=exp(-A n epsilon)`. Thus

    0 <= Phi-L
      <= (1/n) log(F_ng/H_g^n)
      <= (3/n) exp(3 A n epsilon) 2^(-d-1).

The first upper inequality uses the Fekete infimum, not convergence uniform in n. Every direction of the inequality is correct.

## 3. Floor and exponent calculation

Write

    M'=max(1,M),
    x=h/(6 A M' epsilon),
    d=floor x,
    eta=x-d in [0,1).

The stated epsilon bound ensures `x>=2`. The exponent, including the `+1` in n, satisfies

    3 A n epsilon - (d+1)h
      <= h[(d^2+1)/(2x)-d-1]
       = -h x/2 + h[(eta^2+1)/(2x)-1]
      <= -h x/2
       = -h^2/(12 A M' epsilon).

The middle correction is nonpositive because `eta^2+1<2<=2x`. Finally `3/n<=3`. This proves exactly the advertised estimate

    0 <= Phi_(epsilon v)(g)-L_(epsilon v)(g)
      <= 3 exp(-(log 2)^2/(12 A M' epsilon)).

The restrictions on epsilon also ensure `rho=2epsilon<=rho_0`; there is no radius mismatch.

## 4. Interpretation and remaining mechanism

The error is genuinely exponentially small along each fixed positive coefficient ray. Equality of every algebraic asymptotic coefficient follows, but equality of the functions does not. In particular, a nonzero nonnegative flat discrepancy is compatible with the estimate, and convexity only in the label variable supplies no uniqueness principle in epsilon.

One safe possible route to equality is a proof that the Fekete limit extends analytically across the coefficient-zero point. That analyticity is currently missing; none of the estimates above grants it. The current majorant grows exponentially in the label and does not by itself give a label-independent zero-free complex neighborhood for `F_ng`, so passing holomorphic logarithms to a normal limit is not justified without new input.

No revision to the reviewed note is required.
