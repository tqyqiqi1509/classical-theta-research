# Independent audit of the uniform body comparison

2026-11-13. Reviewed file: `../../notes/UNIFORM_BODY_FLAT_COMPARISON.md`.

## Verdict

**PASS.** The conversion from one integral label to every real label is valid. The extreme-ray bound, orthant decomposition, normalization, cutoff optimization, r=1 case, and the explicit sufficient smallness condition all check. No correction to the mathematical estimates is needed.

## 1. Normalizing the fixed-label theorem

For a nonzero integral u, `G_u<=||u||_1` and `M_H,u=K||u||_1`. Hence its fixed-label constant satisfies

    A_u=max(1,2G_u S,2M_H,u/R_0)<=A_0||u||_1.

Its exponential constant is consequently at least `c_0/||u||_1`. The fixed-label smallness condition follows from

    epsilon||u||_1<=c_0/log 2
       =(log 2)/(12A_0 M').

Dividing the fixed-label gap by `||u||_1` and dropping that denominator in the prefactor is legitimate because this norm is at least one. This proves (1.1) exactly as stated.

## 2. Extreme rays and orthants

Adding all coordinate hyperplanes places every full-dimensional arrangement cone inside a closed orthant and makes it pointed. An extreme ray is the kernel of r-1 independent supporting integral normals. Coordinate-normal entries are at most one, while the entries of Da are at most `D_max N`. Because D is positive integral and N>=1, the latter also bounds the coordinate normals.

The signed-minor vector has coordinates bounded by

    (r-1)! (D_max N)^(r-1).

Dividing by their gcd to get a primitive generator cannot increase its l1 norm. Summing r coordinates gives

    ||u||_1<=r! D_max^(r-1) N^(r-1)=H N^(r-1).

For r=1 the empty determinant is one and the ray generators are 1 and -1; the same formula holds.

A pointed rational cone is the nonnegative span of its extreme rays. As the rays lie in a common orthant, absolute values add coordinatewise and

    sum_j t_j||u_j||_1=||g||_1.

This identity would indeed fail without the orthant refinement; the note supplies the necessary refinement.

## 3. Subadditivity and the two analytic errors

Phi is sublinear, and L_N is linear throughout the chosen closed arrangement cone. Therefore

    Phi(g)-L(g)
       <=sum_j t_j[Phi(u_j)-L(u_j)]
         +sum_j t_j[L(u_j)-L_N(u_j)]
         +L_N(g)-L(g).

The second and third terms have absolute upper bounds `eta_N||g||_1` each. The first is at most the maximum normalized ray gap times `||g||_1`. This proves the factor `2eta_N` in (3.1), with no hidden dependence on the number of extreme rays or decomposition coefficients. Boundary labels can be placed in any adjacent closed full-dimensional cone.

For compact convex bodies, the Hausdorff distance in the infinity norm is the supremum of the absolute difference of support functions on the dual l1 unit sphere. The lower comparison supplies containment, so (3.1) gives the advertised Hausdorff bound.

## 4. Optimization and all smallness conditions

Write `ell=log(R_0/epsilon)` and `x=(c_0/(H epsilon ell))^(1/r)`. For `N=floor x>=1`,

    c_0/(H epsilon N^(r-1))>=x ell.

The given restriction `epsilon<=rho_0/2` implies `epsilon/R_0<=1/4`, hence `ell>=log4>log2`. If x>=1, the inequality above guarantees the required normalized ray smallness condition automatically.

Since `N+1>x`,

    2eta_N <=(8K/3)exp(-x ell)<=4K exp(-x ell).

The first exponential term is at most `3exp(-x ell)`. This proves (4.2), including its prefactor `3+4K`. For r=1 the first exponent is independent of N and equals x ell exactly, so there is no division-by-zero or exceptional optimization step.

For the stated elementary sufficient condition, put t=epsilon/R_0. Then

    epsilon ell=sqrt(epsilon R_0) sqrt(t) log(1/t)
                <=(2/e)sqrt(epsilon R_0)
                <=c_0/H

whenever `epsilon<=c_0^2/(H^2 R_0)` and `0<t<=1`. Thus x>=1. All constants in the note are conservative and correct.

## 5. Necessary interpretation boundary

The current text correctly describes a certified approximation to the scaling body near the coefficient-zero boundary. For a *fixed* positive epsilon, the approximation has the possible flat discrepancy between the two bodies as an error floor. It does not prove that Q_N converges to the scaling body as N tends to infinity; the known geometric convergence is to the transport body. Claiming geometric convergence to the scaling body at fixed epsilon would silently assert the still-open equality of the two bodies.

No change to the reviewed note's present wording is required. The degree-one box is correct: `L_1(g)=sum_i[-g_i]_+ z_i`, so its slope hull is `product_i[-z_i,0]`.
