# Wall curvature and exposed faces of the analytic theta body

2026-11-13. Classical skew-symmetrizable principal coefficients. This is a consequence of the common analytic path domain and the convex body proved in `ANALYTIC_STABLE_LOG_BODY.md`. The proof below controls total variation, rather than inferring a statement about curvature from uniform convergence alone.

## 1. Setup and statement

Fix a positive principal point z in the common domain. Choose R>1 so that Rz is still in that domain, and use the uniform logarithmic bound K. Write

    L(g)=log H_g(z)=sum_(k>=1) ell_k(g),
    U(g;z)=sum_(k>=1) u_k(g),
    ell_k(g)=g dot u_k(g).

The coefficients here are homogeneous in the principal variables: `ell_k` is total principal degree k evaluated at z, not a degree-k polynomial in g. Each ell_k is a continuous homogeneous piecewise-linear function of the real label g. Its possible bends lie on

    H_a={g:(Da) dot g=0},  a in N^r, 0<|a|<=k.

The common Cauchy estimate gives, uniformly in every chamber and every coarse boundary value,

    ||u_k(g)||_infinity <= K R^(-k).                  (1.1)

**Theorem.** The distributional Hessian D_g^2 L is a locally finite positive-semidefinite matrix measure. Its homogeneous-degree expansion converges in total variation on every compact set. This measure is carried by the countable union of positive-root hyperplanes H_a; there is no additional absolutely continuous or Cantor part away from these wall surfaces. More precisely, for primitive positive a set

    nu_a=Da/gcd_i(D_i a_i),
    e_a=nu_a/||nu_a||_2.

At almost every point g of H_a, let f_(a,g) be its combined full local wall function, taking f=1 when the local wall is trivial, and let T_g be the analytic positive coordinate map of the coarse negative factor A_g^-. Then

    D_g^2 L
       =sum_(primitive a>0)
          (nu_a tensor nu_a)/||nu_a||_2
          log f_(a,g)(T_g z) H^(r-1)|_(H_a).          (1.2)

The displayed sum converges absolutely in matrix-measure total variation on compact sets. Intersections of different root hyperplanes are H^(r-1)-null and contribute no missing joint measure. For r=1, H^0 on the unique hyperplane {0} means the unit point mass.

## 2. The finite piecewise-linear Hessian formula

Let p be a continuous function, linear on the chambers of a finite central hyperplane arrangement. Away from chamber boundaries its gradient is constant. Across a facet contained in a hyperplane with a chosen unit normal e, let `v_plus-v_minus` be the gradient jump from the negative to the positive side. Continuity makes this jump parallel to e. Integration by parts on the finitely many chambers gives

    D^2 p=sum_facets (v_plus-v_minus) tensor e
                         H^(r-1)|_facet.             (2.1)

This equality follows by cancellation of the two opposite boundary normals of each internal facet. The ambient function is continuous, so its first derivative has no surface delta term; taking the derivative of its piecewise constant gradient produces precisely (2.1). Codimension-two intersections have no H^(r-1) mass. Convexity of p is not required; the finite measure can be signed.

For r=1, (2.1) is the elementary formula that the second derivative of a continuous piecewise-linear function is the sum of its slope jumps times Dirac masses. This is the convention used throughout.

## 3. Summable total variation of the degree layers

Let B_T be the Euclidean ball of radius T centered at the origin, and let omega_(r-1) denote the volume of the unit ball in dimension r-1, with omega_0=1. There are at most

    M_k=binom(k+r,r)-1

root hyperplanes available through degree k. Distinct positive roots can define the same hyperplane, so this count is an upper bound. For one hyperplane, all of its chamber facets have disjoint interiors; their total H^(r-1) area in B_T is at most `omega_(r-1) T^(r-1)`.

By (1.1) the Euclidean size of every gradient jump of ell_k is at most `2 sqrt(r) K R^(-k)`. Formula (2.1) therefore gives, for the Frobenius matrix norm,

    |D^2 ell_k|(B_T)
      <=2 sqrt(r) K omega_(r-1) T^(r-1) M_k R^(-k).
                                                               (3.1)

In dimension one, T^0=1 and the formula remains valid. Since M_k grows polynomially, the right-hand side is summable in k. Thus

    sum_(k>=1) D^2 ell_k

converges in total variation on B_T. On the other hand, the partial sums of ell_k converge locally uniformly to L, so their Hessians converge distributionally to D^2 L. The two limits agree. This proves the required total-variation convergence, rather than merely weak convergence.

An explicit remainder is available. For any 1<s<R,

    |D^2 L-D^2 L_N|(B_T)
      <=2 sqrt(r) K omega_(r-1) T^(r-1)
          (s/R)^(N+1)
          [((1-s^(-1))^(-r)-1)/(1-s^(-1))].          (3.2)

Indeed `R^(-k)<=(s/R)^(N+1)s^(-k)` for k>N, and

    sum_(k>=1) M_k t^k
       =((1-t)^(-r)-1)/(1-t),       0<t<1.

The exact finite arrangement count is not essential; the polynomial growth and the geometric analytic tail are the decisive facts.

## 4. Why no diffuse curvature is hidden at accumulating walls

Every degree-layer measure is carried by the finite union of its root hyperplanes. Absolute convergence in total variation implies that the sum is carried by

    E=union_(primitive a>0) H_a.

This is a countable Lebesgue-null union. Consequently the distributional Hessian has no Lebesgue-absolutely-continuous part. More strongly, each layer is absolutely continuous on its hyperplanes with respect to H^(r-1), and the summability in (3.1) permits the corresponding densities to be summed in L^1. Thus there is no extra measure on joints or on a limiting set outside the individual wall surfaces. The assertion is about a measure carrier: E may be dense, and its closure may be the entire label space.

The positivity of D^2 L follows from the established convexity of L. It can also be seen directly from the full jump formula in the next section. The standard Alexandrov almost-everywhere Hessian of this convex function is therefore zero almost everywhere; all its curvature is singular wall curvature. This does not mean that L is locally linear at every point outside E, since infinitely many walls may accumulate there.

## 5. Exact normalized wall densities

Fix primitive a and choose g in H_a avoiding every nonparallel root hyperplane. In the convention of `ANALYTIC_STABLE_LOG_BODY.md`, the full one-sided logarithmic slopes satisfy

    U_plus-U_minus=nu_a sigma_a(g),
    sigma_a(g)=log f_(a,g)(T_g z)>=0.                (5.1)

The unit normal from the negative to positive side is `e_a=nu_a/||nu_a||_2`. Substitution in (2.1) yields

    (U_plus-U_minus) tensor e_a
       =(nu_a tensor nu_a)/||nu_a||_2 sigma_a(g).

This is (1.2). Equivalently, writing `w_a=Da` and `delta_a=gcd_i(D_i a_i)`, its matrix factor is

    (w_a tensor w_a)/(delta_a ||w_a||_2).

No extra gcd or symmetrizer factor is omitted. The wall density is strictly positive wherever the full local wall is nontrivial, because f has nonnegative coefficients, a positive nonconstant coefficient, and T_g z is positive.

One can also see absolute summability directly. A primitive normal a has no jump in total degrees less than |a|. Therefore

    ||U_plus-U_minus||_2
       <=2 sqrt(r) K R^(-|a|)/(1-R^(-1)).            (5.2)

Summing this bound over positive primitive charges and multiplying by the area of the corresponding hyperplane section gives another locally finite total-variation bound. Formula (3.2) is stronger for approximation by coefficient degree, because it also controls high-degree corrections on old normals.

## 6. Line restrictions have only summable jumps

Let `gamma(t)=g_0+t v` be a line segment which avoids intersections of distinct root hyperplanes and crosses every hyperplane it meets transversely. The degree-k restriction has derivative jumps whose total absolute mass is at most

    2 ||v||_1 K M_k R^(-k).

These bounds are summable. Hence the second derivative of `L(gamma(t))` is the absolutely convergent pure point measure

    sum_(crossed wall a at t_a)
       |v dot nu_a| log f_(a,gamma(t_a))(T_(gamma(t_a)) z)
       delta_(t_a).                                 (6.1)

All masses are nonnegative. Its first derivative is a constant plus the corresponding absolutely summable step function. There is no Cantor contribution even when crossing times are dense. Uniform convergence by itself would not prove this; the layerwise total-variation estimate does.

## 7. Differentiability outside root hyperplanes

There is a useful stronger consequence of (1.1). Each ell_k has global Lipschitz constant at most `K R^(-k)` for the l1 norm: integrate its bounded finite piecewise constant gradient along a segment. Therefore the tail `L-L_N` has Lipschitz constant at most

    epsilon_N=K R^(-N-1)/(1-R^(-1)).

If g belongs to no root hyperplane, every finite L_N is differentiable in a neighborhood of g, with gradient U_<=N(g). The uniformly small Lipschitz tail proves that L itself is Frechet differentiable at g and

    grad L(g)=U(g;z).

For completeness, subtract the linear function with gradient U(g;z). The finite prefix has zero first-order remainder near g; the tail contributes at most `2 epsilon_N ||h||_1`. First let h tend to zero for fixed N and then let N tend to infinity. Thus the analytic theta body has a unique exposed point in every root-generic direction, including directions at which full scattering chambers do not have an open neighborhood.

## 8. Every exposed face is governed by the coarse zero group

This statement supplies a concrete description even at a joint, where the zero group need not be commutative.

Fix any real g and factor the total element coarsely as

    C=A_g^- Z_g A_g^+.

For a direction h, factor only the zero group Z_g according to the signs of `a^T D h`, and denote its negative factor by B_(g,h)^-. All its roots satisfy `a^T Dg=0`. Put

    U_g=log(x^(-1) A_g^-(x)),
    W_g(h;z)=A_g^-[log(x^(-1) B_(g,h)^-(x))](z).     (8.1)

The vector notation in (8.1) means coordinatewise logarithms. It defines a genuine analytic function on the original common z domain: in every finite degree, the factorization at `g+t h`, t>0 small, has negative factor `A_g^- B_(g,h)^-`; the full transport logarithms have the uniform bound K and uniform Cauchy tails. Therefore

    lim_(t downarrow0) U(g+t h;z)=U_g(z)+W_g(h;z),    (8.2)

and this convergence is analytic in z on smaller closed subdomains. In particular `||W_g(h;z)||_infinity<=2K`. No separate assertion that the transformed point lies in an invariant domain for all zero-group maps is needed. Every zero-group root annihilates x^g, so

    g dot W_g(h;z)=0.                               (8.3)

To extract a directional derivative, do not divide an order-independent analytic-tail error by t. First take h generic so that the line `g+t h` is outside every root hyperplane except at a countable set of t. L is Lipschitz, and Section 7 identifies its derivative at all the remaining points. Integration and the bounded convergence in (8.2) give

    D_h L(g)=h dot U_g(z)+h dot W_g(h;z).             (8.4)

For nongeneric h, the same formula follows by the continuity of the convex directional-derivative support function and the continuous finite zero-group gluing, followed by their uniform analytic tails.

For a homogeneous convex support function, `D_h L(g)` is exactly the support function, in direction h, of the exposed face

    F_g={p in K_z:g dot p=L(g)}.

Thus, after translating by U_g, the face has the fully explicit support function

    h_(F_g-U_g)(h)=h dot W_g(h;z).                   (8.5)

The right side is automatically convex, and its body lies in g-perp by (8.3). The zero group may be nonabelian; its signed factorization, not an assumption of commuting factors, determines the whole face. This is an all-order boundary mechanism.

If g lies on exactly one root hyperplane H_a, the zero group is the single commuting ray group. Formula (8.5) simplifies to an actual exposed edge:

    F_g=U_g(z)+[-nu_a log f_(a,g)(T_g z), 0].        (8.6)

Its Euclidean length is `||nu_a||_2 log f_(a,g)(T_g z)` and its direction is the primitive integral positive normal nu_a. It collapses to a point exactly when the local wall is trivial. If g lies on no root hyperplane, Z_g is trivial and (8.5) gives the singleton already established in Section 7.

## 9. Scope and literature record

The Hessian formula for a finite continuous piecewise-linear function, total-variation convergence, and exposed-face directional derivatives are standard convex analysis. The new mathematical input in this application is the degreewise uniform analytic slope bound combined with the polynomial count of root hyperplanes. It proves that the infinite analytic scattering body retains only the wall curvature and gives its full zero-group face description. No claim is made here about the curvature or full normal fan of the distinct Fekete scaling body.

A targeted literature search on 2026-11-13 for scattering-fan support functions and wall Hessian measures located Reading's *Scattering Fans* and *Compactifications of Cluster Varieties and Convexity*, but did not locate this analytic total-variation conclusion. The search is not a priority proof. These papers are background context, not inputs to Sections 2--8. A 2026 search hit titled *Slicing Support Functions with Recovery Formula and Curvature Identities* was not reviewed and is not used. The main novelty branch retains the Fock--Goncharov and finite-type overlap audit.
