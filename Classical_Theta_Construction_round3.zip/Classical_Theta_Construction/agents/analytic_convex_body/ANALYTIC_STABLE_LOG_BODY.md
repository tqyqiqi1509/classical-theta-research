# A positive-point analytic body realizing the full scattering fan

2026-11-13. Classical skew-symmetric and skew-symmetrizable cluster data.

## 0. Result, dependencies, and the nonclaim

This note proves that the coefficientwise stable theta logarithm has a genuine analytic sum, uniformly in its real label, and that its value at a sufficiently small positive principal point is the support function of a compact convex body. Its normal cones recover the full inverse-limit scattering fan. The construction is an actual analytic evaluation, not a chosen rapidly weighted Minkowski sum of finite polytopes.

The inputs are:

1. the finite signed-factorization and stable-ray theorem in `../newton_properties/STABLE_RAY_AND_WALL_RECOVERY.md`;
2. the continuous finite stable-log maps and finite polytopes in `../stable_hall_interface/POLYTOPAL_STABLE_LOG_THEOREM.md`;
3. the endpoint-uniform theta coefficient bound and the analytic path-product theorem in `../dyck_flow_round2/ANALYTIC_PATH_ORDERED_PRODUCTS.md`.

The all-order analytic body is generally not a polytope, a lattice body, or the Newton polytope of one theta function. In finite type its scalar pairing overlaps the established Fock--Goncharov additive canonical pairing. Priority for the general analytic construction is treated separately by the novelty branch.

In particular, this note does **not** identify the stable logarithm with the asymptotic limit `(1/n)log F_(ng)`. A rigorous inequality connecting them is proved in Section 9; equality is a different question.

## 1. Notation and one explicit common analytic domain

Let B be integral of size r, and let D be a positive integral diagonal matrix with DB skew-symmetric. Write

    z_i=y_i x^(B e_i),
    C=max(1,max_ij |B_ij|),    b=max_ij |B_ij|,
    A=exp(1/C),               q(z)=e C sum_i |z_i|.

Use the negative-to-positive total transport C_tot and the signed factorization

    C_tot=A_g^- Z_g A_g^+,
    lambda_g(a)=a^T Dg.

The superscripts refer to signs of lambda_g in the root grading. At a zero root, the coarse factor A_g^- excludes that root. For integral g the formal stable series and logarithm are

    H_g=x^(-g) A_g^-(x^g),    L(g)=log H_g.

The finite theorem extends each coefficient of L continuously and piecewise linearly to real g.

For definiteness, use the path-product constants with one straight segment. Choose

    0<q_1<1/(1+A),
    delta=A q_1/(1-q_1),
    K_0=A/((1-q_1)(1-delta)),
    K=K_0((1-q_1)^(-r)-1),
    q_*= (q_1/2) exp(-r b K).

On the domain q(z)<q_* every one-segment path transport has holomorphic logarithmic coordinate corrections of absolute value at most K. Its positive real specialization sends positive points to positive points, and all intermediate degree coordinates remain in q<q_1/2. The constants are deliberately coarse.

At x=1,y=z define

    U_i(g;z)=log(x_i^(-1) A_g^-(x_i)),
    L_z(g)=sum_i g_i U_i(g;z).

The logarithms always mean the branches with zero principal constant term.

## 2. The signed factor is the required endpoint transport

For a generic g, A_g^- is the transport from the endpoint Dg to the positive chamber. This is an exact signed-factorization statement, not an analogy.

To compare conventions, Bridgeland's total element is transport from positive to negative and factors as `Phi=Phi_+ Phi_0 Phi_-`. His Lemma 3.2 gives

    Phi_D(theta_1,theta_2)=Pi_-^(theta_2)(Phi)
                              Pi_-^(theta_1)(Phi)^(-1).

Our total element is its inverse. Consequently our negative factor is `Phi_-^(-1)`, which is exactly transport from theta=Dg to a positive endpoint, where the negative factor of Phi is the identity. Equivalently one can prove this directly in every finite root quotient by factoring the path at its intermediate endpoint.

A generic endpoint can be joined to some point of the positive chamber by one straight generic segment: the positive endpoint can be chosen outside the countable union of measure-zero sets corresponding to intersection with a joint or failure of transversality. The resulting transport does not depend on this choice, by formal and analytic consistency. Thus the one-segment constants apply uniformly to every generic g.

For a nongeneric real g, choose

    g_epsilon=g+epsilon D^(-1)(1,...,1),    epsilon>0,

avoiding the countable exceptional values. In every fixed finite root quotient, all roots vanishing at g become positive and every nonzero sign is unchanged for sufficiently small epsilon. Hence the negative factor at g_epsilon is precisely the coarse A_g^- in that quotient. The uniform analytic bounds and radial Cauchy tails below imply convergence of these negative factors, not just coefficientwise convergence. This defines A_g^- analytically for all real g with the same bound.

No commutativity of a higher-codimension zero group is required. The chosen perturbation puts its entire positive-root Lie algebra on the positive side. Any other refinement changes the negative factor by a right factor supported on zero roots; that factor fixes x^g, so the scalar L_z(g) is unchanged.

Primary source read directly: Tom Bridgeland, *Scattering diagrams, Hall algebras and stability conditions*, Algebraic Geometry 4 (2017), Section 3.2, Lemmas 3.1--3.2 and Proposition 3.4, https://content.algebraicgeometry.nl/2017-5/2017-5-027.pdf . The parent should reopen this source before citing it in a final user-facing response.

## 3. Uniform analytic tails and continuity in every label

Fix z with q(z)<q_*, and choose any R>1 such that R q(z)<q_*. The function

    t -> U_i(g;t z)

is holomorphic for |t|<=R and bounded by K, uniformly in all real g. Let U_i,<=N be its total-principal-degree truncation evaluated at z. Cauchy's estimate gives

    |U_i(g;z)-U_i,<=N(g;z)| <= epsilon_N,
    epsilon_N=K R^(-N-1)/(1-R^(-1)).                 (3.1)

The same bound holds for the coarse boundary values described in Section 2, by normal-family convergence and the finite coefficient stabilization.

Write

    L_N(g;z)=sum_i g_i U_i,<=N(g;z).

This is exactly the finite stable-log map evaluated linearly at the fixed point z. The finite gluing theorem makes L_N continuous and piecewise linear, even though U_<=N may jump. Thus

    |L_z(g)-L_N(g;z)| <= ||g||_1 epsilon_N.          (3.2)

The convergence is uniform on compact label sets. It follows that L_z is continuous and positively homogeneous. Since each slope U_<=N is bounded in infinity norm by K+epsilon_N, integrating along a finite piecewise-linear segment and passing to the limit gives

    |L_z(g)-L_z(h)| <= K ||g-h||_1.                 (3.3)

For integral g, H_g is holomorphic and zero-free in q(z)<q_* and is exactly

    H_g(z)=exp(L_z(g)),    |L_z(g)|<=K||g||_1.

This is the analytic sum of the coefficientwise stable series. It is not obtained by exchanging a large-label limit with a formal series.

## 4. Full wall jumps have the convex sign at a positive point

From now on fix z_i>0 with q(z)<q_*.

Take a parameter point g_0 lying on exactly one positive-root hyperplane, with primitive root direction a. It may lie in an arbitrarily refined wall arrangement; avoid all nonparallel root hyperplanes. Let

    delta_a=gcd_i(D_i a_i),    nu_a=Da/delta_a,
    ell_a(g)=a^T Dg.

Let f=1+sum_(k>=1)c_k z^(ka) be the combined local wall function, so c_k>=0. In our negative-to-positive convention the zero factor acts by

    Z(x^g)=x^g f^(-<g,nu_a>).

The finite exact jump formula, now analytically summed, reads

    U^+(g_0;z)-U^-(g_0;z)
       =nu_a [A_g0^-(log f)](z),                  (4.1)

where + is the side ell_a>0. The two boundary refinements use A_g0^- and A_g0^- Z; both are limits of one-segment transports, so their logarithmic coordinate corrections satisfy the same K bound. Consequently the total-degree tail of the jump vector is bounded coordinatewise by 2 epsilon_N.

Let z' be the image of the initial degree point under A_g0^-. Positive real wall maps and their inverses preserve positivity. The uniform logarithmic bound moreover gives

    z_j exp(-r b K) <= z_j' <= z_j exp(r b K),
    q(z')<q_1/2.

Thus

    [A_g0^-(log f)](z)=log f(z')>=0,               (4.2)

strictly positive whenever the wall is nontrivial. This is an actual real inequality for the full function; it does not use dominance of a low-degree truncation.

Along a transverse line with direction v, the jump of the directional slope is

    |<v,nu_a>| log f(z')>=0.

The sign is the same for either direction of crossing.

## 5. Convexity with infinitely many, even dense, walls

The potential difficulty is that L_N at the fixed point z need not itself be convex for every N. Its own finite-polytope theorem may require a smaller evaluation parameter depending on N. We do not make that invalid inference.

Consider a line segment in label space which avoids intersections of nonparallel root hyperplanes and crosses each encountered hyperplane transversely. Such segments are dense among segments with perturbed endpoints. The function L_N restricted to it is continuous and piecewise linear, with at most

    M_N=binom(N+r,r)-1

break points: all its possible walls have positive root degree <=N, and a straight segment meets one root hyperplane at most once.

At each break point, its slope jump is the truncation through degree N of (4.1). The full jump has the convex sign by (4.2). Therefore its negative part is at most

    2 ||v||_1 epsilon_N.

The total negative mass of the distributional second derivative is bounded by

    2 M_N ||v||_1 epsilon_N ->0.                  (5.1)

Here polynomial growth in N is beaten by the uniform geometric Cauchy tail. The functions themselves converge uniformly by (3.2). Testing their distributional second derivatives against any nonnegative smooth compactly supported test function proves that the continuous limit has nonnegative distributional second derivative. It is convex on the segment. Approximation of arbitrary endpoint pairs, followed by continuity, proves that L_z is convex on all of R^r.

This proof handles the accumulation of infinitely many walls and does not assume that the full diagram has locally finite support.

## 6. Every finite scattering polytope is a scaled Minkowski summand

Fix M. Let Phi_M be any one of the previously constructed finite support functions, with its own sufficiently small rational evaluation parameter, and let P_M be its polytope. Its normal fan is the finite scattering fan through principal degree M.

For each effective finite arrangement facet tau, use a primitive root a_tau and write its positive gradient jump as

    grad Phi_M^+ - grad Phi_M^-=beta_tau D a_tau,
    beta_tau>0.

Choose its first nonzero wall term c_tau z^(p_tau), where p_tau=k_tau a_tau and c_tau>0. In the full wall germ at every sufficiently generic point of this finite facet, that term remains present. Positivity and the transport bound yield

    log f(z') >= m_tau,
    m_tau=log(1+c_tau z^(p_tau) exp(-r b K |p_tau|))>0.

Define the explicit positive number

    c_M=min_effective_tau m_tau/(delta_a_tau beta_tau).
                                                               (6.1)

If there are no effective facets, set c_M=1. Formula (4.1) shows that the full slope jump of L_z minus c_M Phi_M has the convex sign at every old effective facet. At new walls the Phi_M jump is zero and the L_z jump is positive.

Apply the proof of Section 5 to L_N-c_M Phi_M for N>=M. At each finite break point the only possible negative error is again at most 2||v||_1 epsilon_N, and there are at most M_N of them. Therefore

    L_z-c_M Phi_M is convex and positively homogeneous.  (6.2)

As it is finite and continuous, it is the support function of a compact convex body K_M'. Consequently the body defined by L_z satisfies

    K_z=c_M P_M+K_M'.                              (6.3)

This is a theorem about the analytic body, not its definition. The constants c_M can shrink with M; no uniform positive lower bound in M is asserted.

## 7. Compact body and exact recovery of the full fan

A finite continuous convex positively homogeneous function is the support function of a unique compact convex body. Hence define K_z by

    h_(K_z)=L_z.

One concrete description is

    K_z=closure conv{U(g;z): g avoids every positive-root hyperplane}.
                                                               (7.1)

To verify this description, apply the approximate supporting inequalities to the finite L_N functions: their total negative slope variation along a segment is bounded by (5.1), while their gradients at a generic g converge to U(g;z). Passing to the limit shows U(g;z) is a subgradient of L_z at g. Homogeneity gives g dot U(g;z)=L_z(g). Density and continuity then prove (7.1).

The K bound implies K_z is contained in [-K,K]^r. On the positive label cone A_g^-=1, so L_z=0 and 0 occurs among the vectors in (7.1). Thus

    0 in K_z subseteq R_<=0^r.

The degree-one finite polytope is a nondegenerate box, and (6.3) makes a positive multiple of it a Minkowski summand. Hence K_z is full dimensional for a full principal seed.

For any real u,v set

    Delta_z(u,v)=L_z(u)+L_z(v)-L_z(u+v).

If u and v belong to a common closed cone of every finite scattering fan, the finite coefficient functions are linear on a common cone at each order. Thus Delta_z(u,v)=0 by (3.2).

Conversely, if they fail to lie in a common closed cone at some finite order M, strict normal-fan recovery for P_M gives

    Phi_M(u)+Phi_M(v)-Phi_M(u+v)>0.

By convexity of (6.2),

    Delta_z(u,v)>=c_M[Phi_M(u)+Phi_M(v)-Phi_M(u+v)]>0.   (7.2)

Therefore

    Delta_z(u,v)=0
    iff u,v share a closed cone at every finite scattering order.
                                                               (7.3)

This is a precise meaning of recovery of the full inverse-limit scattering fan, including limiting cones with empty interior. It also avoids an unjustified argument that only checks generic facets while ignoring segments through joints.

### Full exposed-face inclusion and normal cones (fresh-review strengthening)

The binary compatibility statement (7.3) alone should not be substituted for a proof about all exposed-face normal cones of a general compact body. In particular, a direction exposing a face of a nonpolyhedral body need not lie in the relative interior of that face's normal cone. The following argument supplies the full statement without such an assumption.

Write F_g(K) for the exposed face of a compact convex set K in direction g. Then

    F_g(K_z) subseteq F_h(K_z)
    iff F_g(P_N) subseteq F_h(P_N) for every N,        (7.4)

and consequently

    N_(K_z)(F_g(K_z))
       =intersection_N N_(P_N)(F_g(P_N)).             (7.5)

Here N_K(F) means the directions whose maximizing face contains the whole of F. In particular, equality of exposed faces of K_z is equivalent to equality of the corresponding faces of every P_N. Formula (7.5), rather than a finite-polytope relative-interior convention, is the precise normal-cone assertion.

For the forward implication in (7.4), use K_z=c_N P_N+K_N' from (6.3). An exposed face of a Minkowski sum is the sum of the exposed faces. If some point of F_g(P_N) failed to maximize h, combine it with any point of F_g(K_N'). Its strictly positive h-deficit cannot be canceled by the other summand's nonnegative deficit. This contradicts F_g(K_z) subseteq F_h(K_z).

For the converse, put C_N=N_(P_N)(F_g(P_N)). Since P_N is a finite polytope with the exact finite scattering fan, g lies in the relative interior of C_N, and the hypothesis puts h in C_N. Therefore g-t h remains in C_N for all sufficiently small t>0, with the allowed t depending on N. The scalar finite stable logarithm L_N at our fixed evaluation z is linear on C_N, although it need not be convex at that evaluation. Hence

    D_(-h) L_N(g)=-L_N(h).

The homogeneous-degree slope bounds give a global Lipschitz bound epsilon_N for L_z-L_N in the l1 norm: integrate the bounded finite-piecewise-constant gradients degree by degree and sum their geometric tail. Consequently

    |D_(-h) L_z(g)-D_(-h) L_N(g)|
       <=epsilon_N ||h||_1.

Letting N tend to infinity gives D_(-h)L_z(g)=-L_z(h). For a convex support function, D_(-h)L_z(g)=-min_(v in F_g(K_z)) h dot v. The last equality thus says that every point of F_g(K_z) maximizes h, proving (7.4).

The finite normal cones on the right of (7.5) are precisely the closures of the finite scattering classes of g. Their intersection is the closure of the full scattering class, by the standard inverse-limit segment argument, as in Reading, *Scattering fans*, Proposition 3.8 and Proposition 3.10. Adjoining all cone faces gives the full scattering fan with the stated face-closure convention. No assertion that an infinite scattering class equals the relative interior of its closure is required.

This paragraph was added in the independent review `../convex_face_independent_review/INDEPENDENT_REVIEW.md`.

## 8. Effective Hausdorff approximation from finite theta data

Fix z and R as in Section 3. Take all slopes of the finite piecewise-linear map L_N at this fixed z, and put

    Q_N(z)=conv{U_sigma,<=N(z): sigma a finite arrangement chamber}.

These polytopes need not have exactly the degree-N scattering fan, since L_N need not be convex at this evaluation point. They are nevertheless certified approximations of K_z.

For each generic g the finite slope differs from U(g;z) by at most epsilon_N in infinity norm. Every finite arrangement chamber contains points avoiding all further root hyperplanes, so every displayed finite slope is within epsilon_N of a vector in K_z. Conversely, every vector in (7.1) is within epsilon_N of its finite slope. Taking convex hulls and closure proves

    d_H,infinity(Q_N(z),K_z)<=epsilon_N.             (8.1)

The finite stable-ray theorem reconstructs those coefficient slopes from finitely many theta coefficients at explicitly bounded large integral labels. Therefore (8.1) gives a certified convergent procedure from the coefficient construction to the analytic body. It requires no all-order list of scattering walls and no empirical stabilization.

## 9. Comparison with the Fekete / Fock--Goncharov scaling pairing

On the same positive domain, positivity of theta multiplication implies

    F_((m+n)g)(z)<=F_(mg)(z) F_(ng)(z).

Fekete therefore defines the finite quantity

    Phi_z(g)=lim_(n->infinity) (1/n)log F_(ng)(z)
            =inf_n (1/n)log F_(ng)(z)

for integral g, with the usual homogeneous continuous extension to real labels.

There is a rigorous lower comparison

    L_z(g)<=Phi_z(g).                               (9.1)

Indeed, for a generic endpoint U_epsilon tending from the positive zero-root side to Dg,

    theta_pos,ng=A^-_(U_epsilon)(theta_(U_epsilon,ng)).

At a positive point this gives

    F_(ng)(z)=x^(-ng)A^-_(U_epsilon)(x^(ng))
                  F_(ng,U_epsilon)(z'_epsilon)
              >=x^(-ng)A^-_(U_epsilon)(x^(ng)),

because the second factor has constant coefficient one and all coefficients nonnegative. The transformed point lies in the common theta convergence ball by the path estimate. The first factor converges to H_g(z)^n by the same uniform analytic-tail argument as Section 2. Thus F_(ng)(z)>=H_g(z)^n, proving (9.1) after taking logarithms and the infimum. No limit of the second factor is needed.

In convex-body terms, K_z is contained in the body of the Fekete support function. Equality holds on cluster-complex labels, where theta_(ng)=theta_g^n and stable H_g=F_g. Equality for arbitrary labels is not proved here. The root's separate flat-comparison note investigates the possible discrepancy near z=0.

## 10. What is new in this construction and what is old

The finite stable-log polytopes, the signed-factorization reconstruction, general convex support-function facts, and arbitrary rapidly weighted infinite Minkowski sums are established earlier inputs. The additive asymptotic canonical pairing has a precise Fock--Goncharov antecedent, especially in finite type.

The present construction supplies a different precise package: one actual positive principal point, uniform all-label analytic summation of the stable logarithms, a full-fan compact body at that point, every finite polytope as a scaled Minkowski summand, and an explicit geometric Hausdorff approximation from finite theta coefficients. No claim that its generally real coordinates are lattice Newton data is made.
