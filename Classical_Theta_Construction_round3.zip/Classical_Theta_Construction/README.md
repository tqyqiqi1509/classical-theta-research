# 经典 theta 基：有限系数模型、正分支与 Newton 几何

本包的数学对象是经典丛代数，先处理斜对称矩阵，再以正整数对称化矩阵 D
处理斜对称化矩阵。研究自 2026-11-13 17:09:08 UTC 开始；最终运行信息见
`logs/run.json`。

## 从这里阅读

1. **`MAIN_REPORT_ZH.md`**：主要结果、证明机制、查新判断、适用条件和未解缺口。
2. **`computation/README.md`**：可运行的精确系数、乘法、正导子、切片、完整
   Laurent 计算入口。程序区分精确系数、有限截断和有停止证书的完整输出。
3. **下表中的主证明**：按数学内容组织，不必先读每个分支的工作记录。

## 计算结果的准确含义

| 输入与任务 | 得到的结果与停止依据 |
|---|---|
| B、g、指定次数 p | 一个准确整数系数；有限递推或原点代数给出终止计算。 |
| B、g、源核心证书或成功的有限变异词证书 | 完整有限 Laurent 多项式；支持上界先于系数计算证明。固定词证书的成功性是矩阵级性质。 |
| B、g、一个 Newton 面法向及优化路径 | 面的规范低秩 theta 模型和完整整数坐标变换；不自动覆盖优化路径范围外的法向。 |
| 导子、乘法或切片加指定次数盒 | 盒中每个系数准确；没有额外支持证书时不宣称盒外为零。 |

数值支持证书已归为既有 GHKK 凸性机制的具体推论；Q 方程已有 BPZ 前身。
相应新颖性边界与剩余的完整局部长度内容见主报告第3、4、6节。

## 证明入口

| 内容 | 主证明文件 |
|---|---|
| 只用 T 一次幂的通用符号单位系数代数 | `agents/support_accessibility_fresh/UNIVERSAL_UNIT_COEFFICIENT_ALGEBRAS.md` |
| 任意循环矩阵的全局有限 Q 系数代数 | `agents/global_gale_novelty/Q_POLYNOMIAL_REMAINDER_THEOREM.md` |
| 全局 theta 识别的独立审查 | `agents/global_theta_fresh_attack/INDEPENDENT_GLOBAL_IDENTIFICATION.md` |
| 最后一次 BPZ 原始 Q 方程的精确查重 | `agents/final_q_priority_check/FINAL_Q_PRIOR_ART_COMPARISON.md` |
| 一般单位剩余类与零端点核心的有限平坦性 | `agents/finite_mechanism_fresh_7h/GENERIC_RESIDUE_DETECTOR_WINDOW.md` |
| 原点局部长度的独立证明 | `agents/generic_q_fresh_attack/ORIGIN_TUBE_ALGEBRA_LEMMA.md` |
| 零端点互补 Q 变异与有界支持证书 | `agents/support_accessibility_fresh/ZERO_ENDPOINT_Q_MUTATION_AND_SUPPORT_CERTIFICATES.md` |
| 零端点机制的独立反向审查 | `agents/zero_endpoint_q_fresh_review/INDEPENDENT_ZERO_ENDPOINT_Q_REVIEW.md` |
| 支持证书的既有凸性直接推导与准确作用域 | `agents/zero_endpoint_q_fresh_review/NOVELTY_REDUCTION_AND_CONVEXITY.md` |
| 直接凸性推导与固定法向的独立审查 | `agents/face_graded_algebra/GHKK_DIRECT_SUPPORT_INDEPENDENT_REVIEW.md` |
| 有限 Laurent 的有符号 Newton 包络算法 | `agents/fei_newton_interface/FINITE_LAURENT_ENVELOPE_THEOREM.md` |
| 源块与任意循环核心 | `agents/source_face_round4/SOURCE_FACE_AND_CORE_RETRACTION.md` |
| 全混合正导子与正切片 | `agents/positive_shear_fresh_review/FORMAL_SHEAR_AND_POSITIVE_SLICES.md` |
| 任意优化冻结行的 theta 正性 | `agents/positive_shear_fresh_review/OPTIMIZED_FROZEN_THETA_POSITIVITY.md` |
| Schur 标记与碰撞重数 | `agents/positive_shear_fresh_review/SCHUR_MARKING_MODEL.md` |
| 所有 q 分支的实际内外根层 | `agents/support_accessibility_fresh/FULL_MARKED_Q_LAYER_DECOMPOSITION.md` |
| 素数幂同余和变长词的进位循环作用 | `agents/gauss_adversarial/PREFIX_CARRY_CYCLIC_ACTION.md` |
| 进位作用与正 pre-lambda 构造独立审查 | `agents/carry_csp_review/INDEPENDENT_CARRY_AND_PRELAMBDA_REVIEW.md` |
| 大标签乘法系数的有效正二项式公式 | `notes/STRUCTURE_RAY_POSITIVE_COPIES.md` |
| 含并列最低项的 Newton 面运输 | `agents/newton_faces_fresh_final/TIED_INITIAL_MUTATION_FACE_THEOREM.md` |
| Bongartz 归一化后的单项式面公式 | `agents/newton_faces_fresh_final/BONGARTZ_MONOMIAL_FACE_THEOREM.md` |
| 对偶丛锥上的规范面模型与饱和整数格 | `agents/newton_faces_fresh_final/CANONICAL_FACE_MODEL_ON_DUAL_CLUSTER_CONES.md` |
| 单项式面公式和规范性的独立证明核对 | `agents/generic_q_fresh_attack/BONGARTZ_FACE_INDEPENDENT_PROOF_CHECK.md` |
| 嵌套 Newton 面的相容性 | `agents/newton_faces_fresh_final/ITERATED_FACE_COMPATIBILITY.md` |
| 整个规范初始坐标变换与逐项乘法输出 | `agents/face_graded_algebra/UNIFORM_TORIC_INITIAL_MAP_AND_MINIMAL_STRUCTURE_CONSTANTS.md` |
| 统一 self-germ 主界与射线渐近 | `agents/ray_pressure_mechanism/UNIFORM_SELF_ENDPOINT_MAJORANT.md` |
| 实际解析凸体 | `agents/analytic_convex_body/ANALYTIC_STABLE_LOG_BODY.md` |
| 仿射射线与局部星图前因子 | `agents/affine_ray_zero_system/AFFINE_RAY_ANALYTIC_PREFACTOR.md` |
| 二尺度与真实局部星图继承 | `agents/affine_ray_zero_system/LOCAL_STAR_INHERITANCE_AND_TWO_SCALES.md` |
| 完整乘法分布的局部化 | `agents/affine_ray_zero_system/ANALYTIC_LOCALIZATION_OF_MULTIPLICATION.md` |

`agents/` 还保存了独立验证、计算结果、被修正的路线以及局部查新记录。
`notes/` 保存综合推导和根审查。`logs/` 保存每轮文献与路线更新。
旧轮次中必需的证明依赖只保留了少量文件。第三方论文全文缓存没有打包。

## 阅读状态

主报告明确区分：本轮写出并经过独立审查的证明；已知定理的可用推论；
仍需一般机制的目标。分支旧稿中的候选表述以主报告及其后续审查为准。
未使用 Li–Pan 多面体基结论。数值与符号计算补充证明，不替代一般论证。
